/*
Copyright (c) 2012, The Environmental Council of the States (ECOS)
All rights reserved.
 
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
 
 * Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
 * Neither the name of the ECOS nor the names of its contributors may
   be used to endorse or promote products derived from this software
   without specific prior written permission.
 
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/
/******************************************************************************************************************************
** ObjectName: ICS_FORCE_REISSUANCE
**
** Author: Windsor Solutions, Inc.
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure will force loading a reissuance transaction to correct issues with incorrect dates
**               in ICIS. The procedure can optionally include a mass delete transaction for the permit.
**
** Inputs:       P_PRMT_IDENT:      The NPDES ID for the permit to be reissued (and deleted).
**               P_DELETE_FIRST_YN: Indicates whether the permit is to be mass deleted before reissuance (to clear the dates
**                                  from the last issuance).
**
** Revision History:      
** ----------------------------------------------------------------------------------------------------------------------------
**  Date         Analyst     Description
** ----------------------------------------------------------------------------------------------------------------------------
** 06/04/2013    TConrad     Created for SQL Server.
** 07/01/2013    BRensmith   Convert to Oracle
*/
CREATE OR REPLACE PROCEDURE ICS_FORCE_REISSUANCE
(
P_PRMT_IDENT	CHAR,
P_DELETE_FIRST_YN CHAR := 'N' 
)
AS

 V_COUNT NUMBER;

 BEGIN

-- 1. Check for a pending workflow. If exists, exit.

  SELECT COUNT(1)
    INTO V_COUNT
    FROM ics_subm_track
   WHERE workflow_stat = 'Pending'; 

  IF (V_COUNT > 0) THEN
    BEGIN
      raise_application_error(-20101, 'An existing pending workflow exists. Aborting procedure.');
      RETURN;
    END;
  END IF;

  SELECT COUNT(1)
    INTO V_COUNT
    FROM (SELECT 1 FROM ICS_BASIC_PRMT WHERE PRMT_IDENT = P_PRMT_IDENT
          union
          select 1 from ICS_GNRL_PRMT WHERE PRMT_IDENT = P_PRMT_IDENT
         );
  
  IF (V_COUNT = 0) THEN
    BEGIN
      raise_application_error(-20101, 'No matching permit found. Aborting procedure.');
      RETURN;
    END;
  END IF;

-- 2. Set all transactions to NULL

UPDATE ICS_BASIC_PRMT SET TRANSACTION_TYPE = NULL;
UPDATE ICS_BS_PRMT SET TRANSACTION_TYPE = NULL;
UPDATE ICS_BS_PROG_REP SET TRANSACTION_TYPE = NULL;
UPDATE ICS_CAFO_ANNUL_REP SET TRANSACTION_TYPE = NULL;
UPDATE ICS_CAFO_PRMT SET TRANSACTION_TYPE = NULL;
UPDATE ICS_CMPL_MON SET TRANSACTION_TYPE = NULL;
UPDATE ICS_CMPL_MON_LNK SET TRANSACTION_TYPE = NULL;
UPDATE ICS_CMPL_SCHD SET TRANSACTION_TYPE = NULL;
UPDATE ICS_CSO_EVT_REP SET TRANSACTION_TYPE = NULL;
UPDATE ICS_CSO_PRMT SET TRANSACTION_TYPE = NULL;
UPDATE ICS_DMR_PROG_REP_LNK SET TRANSACTION_TYPE = NULL;
UPDATE ICS_DMR_VIOL SET TRANSACTION_TYPE = NULL;
UPDATE ICS_DSCH_MON_REP SET TRANSACTION_TYPE = NULL;
UPDATE ICS_EFFLU_TRADE_PRTNER SET TRANSACTION_TYPE = NULL;
UPDATE ICS_ENFRC_ACTN_MILESTONE SET TRANSACTION_TYPE = NULL;
UPDATE ICS_ENFRC_ACTN_VIOL_LNK SET TRANSACTION_TYPE = NULL;
UPDATE ICS_FINAL_ORDER_VIOL_LNK SET TRANSACTION_TYPE = NULL;
UPDATE ICS_FRML_ENFRC_ACTN SET TRANSACTION_TYPE = NULL;
UPDATE ICS_GNRL_PRMT SET TRANSACTION_TYPE = NULL;
UPDATE ICS_HIST_PRMT_SCHD_EVTS SET TRANSACTION_TYPE = NULL;
UPDATE ICS_INFRML_ENFRC_ACTN SET TRANSACTION_TYPE = NULL;
UPDATE ICS_LMT_SET SET TRANSACTION_TYPE = NULL;
UPDATE ICS_LMTS SET TRANSACTION_TYPE = NULL;
UPDATE ICS_LOC_LMTS_PROG_REP SET TRANSACTION_TYPE = NULL;
UPDATE ICS_MASTER_GNRL_PRMT SET TRANSACTION_TYPE = NULL;
UPDATE ICS_NARR_COND_SCHD SET TRANSACTION_TYPE = NULL;
UPDATE ICS_PARAM_LMTS SET TRANSACTION_TYPE = NULL;
UPDATE ICS_POTW_PRMT SET TRANSACTION_TYPE = NULL;
UPDATE ICS_PRETR_PERF_SUMM SET TRANSACTION_TYPE = NULL;
UPDATE ICS_PRETR_PRMT SET TRANSACTION_TYPE = NULL;
UPDATE ICS_PRMT_FEATR SET TRANSACTION_TYPE = NULL;
UPDATE ICS_PRMT_REISSU SET TRANSACTION_TYPE = NULL;
UPDATE ICS_PRMT_TERM SET TRANSACTION_TYPE = NULL;
UPDATE ICS_PRMT_TRACK_EVT SET TRANSACTION_TYPE = NULL;
UPDATE ICS_SCHD_EVT_VIOL SET TRANSACTION_TYPE = NULL;
UPDATE ICS_SNGL_EVT_VIOL SET TRANSACTION_TYPE = NULL;
UPDATE ICS_SSO_ANNUL_REP SET TRANSACTION_TYPE = NULL;
UPDATE ICS_SSO_EVT_REP SET TRANSACTION_TYPE = NULL;
UPDATE ICS_SSO_MONTHLY_EVT_REP SET TRANSACTION_TYPE = NULL;
UPDATE ICS_SW_CNST_PRMT SET TRANSACTION_TYPE = NULL;
UPDATE ICS_SW_EVT_REP SET TRANSACTION_TYPE = NULL;
UPDATE ICS_SW_INDST_PRMT SET TRANSACTION_TYPE = NULL;
UPDATE ICS_SWMS_4_LARGE_PRMT SET TRANSACTION_TYPE = NULL;
UPDATE ICS_SWMS_4_PROG_REP SET TRANSACTION_TYPE = NULL;
UPDATE ICS_SWMS_4_SMALL_PRMT SET TRANSACTION_TYPE = NULL;
UPDATE ICS_UNPRMT_FAC SET TRANSACTION_TYPE = NULL;

-- 3. Create a reissuance transaction for the passed-in permit number.

SELECT COUNT(1)
  INTO V_COUNT
  FROM ICS_PRMT_REISSU 
 WHERE PRMT_IDENT = P_PRMT_IDENT;
   
IF (V_COUNT > 0) THEN
	BEGIN

  MERGE INTO ICS_PRMT_REISSU
       USING ICS_BASIC_PRMT
          ON (ICS_PRMT_REISSU.PRMT_IDENT = ICS_BASIC_PRMT.PRMT_IDENT)
  WHEN MATCHED THEN
  UPDATE SET ICS_PRMT_REISSU.PRMT_ISSUE_DATE     = ICS_BASIC_PRMT.PRMT_ISSUE_DATE
           , ICS_PRMT_REISSU.PRMT_EFFECTIVE_DATE = ICS_BASIC_PRMT.PRMT_EFFECTIVE_DATE
           , ICS_PRMT_REISSU.PRMT_EXPR_DATE      = ICS_BASIC_PRMT.PRMT_EXPR_DATE
           , ICS_PRMT_REISSU.TRANSACTION_TYPE    = 'C';

  MERGE INTO ICS_PRMT_REISSU
       USING ICS_GNRL_PRMT
          ON (ICS_PRMT_REISSU.PRMT_IDENT = ICS_GNRL_PRMT.PRMT_IDENT)
  WHEN MATCHED THEN
  UPDATE SET ICS_PRMT_REISSU.PRMT_ISSUE_DATE     = ICS_GNRL_PRMT.PRMT_ISSUE_DATE
           , ICS_PRMT_REISSU.PRMT_EFFECTIVE_DATE = ICS_GNRL_PRMT.PRMT_EFFECTIVE_DATE
           , ICS_PRMT_REISSU.PRMT_EXPR_DATE      = ICS_GNRL_PRMT.PRMT_EXPR_DATE
           , ICS_PRMT_REISSU.TRANSACTION_TYPE    = 'C';

	END;

ELSE

	BEGIN

	INSERT INTO ICS_PRMT_REISSU
		(
	     ICS_PRMT_REISSU_ID
	    ,ICS_PAYLOAD_ID
	    ,SRC_SYSTM_IDENT
	    ,TRANSACTION_TYPE
	    ,PRMT_IDENT
	    ,PRMT_ISSUE_DATE
	    ,PRMT_EFFECTIVE_DATE
	    ,PRMT_EXPR_DATE
		)
	SELECT SYS_GUID()
	      ,'PermitReissuance'
		  ,SRC_SYSTM_IDENT
		  ,'C'
		  ,PRMT_IDENT
		  ,PRMT_ISSUE_DATE
		  ,PRMT_EFFECTIVE_DATE
		  ,PRMT_EXPR_DATE
	 FROM ICS_BASIC_PRMT
	WHERE PRMT_IDENT = P_PRMT_IDENT;

	INSERT INTO ICS_PRMT_REISSU
		(
	     ICS_PRMT_REISSU_ID
	    ,ICS_PAYLOAD_ID
	    ,SRC_SYSTM_IDENT
	    ,TRANSACTION_TYPE
	    ,PRMT_IDENT
	    ,PRMT_ISSUE_DATE
	    ,PRMT_EFFECTIVE_DATE
	    ,PRMT_EXPR_DATE
		)
	SELECT SYS_GUID()
	    ,'PermitReissuance'
		  ,SRC_SYSTM_IDENT
		  ,'C'
		  ,PRMT_IDENT
		  ,PRMT_ISSUE_DATE
		  ,PRMT_EFFECTIVE_DATE
		  ,PRMT_EXPR_DATE
	 FROM ICS_GNRL_PRMT
	WHERE PRMT_IDENT = P_PRMT_IDENT;

	END;

END IF; --IF (V_COUNT > 0)

-- 4. Update the key hashes and data hashes for ICS_PRMT_REISSU

UPDATE ICS_PRMT_REISSU
   SET KEY_HASH = MD5_HASH(ICS_PRMT_REISSU.PRMT_IDENT),
       DATA_HASH = MD5_HASH(ICS_PRMT_REISSU.PRMT_EFFECTIVE_DATE)
 WHERE PRMT_IDENT = P_PRMT_IDENT;

-- 5. If the permit needs to be deleted as well, create a mass delete transaction

IF P_DELETE_FIRST_YN = 'Y' THEN

	BEGIN
  
  -- Remove any old records for ics_basic_prmt
  -- /ICS_BASIC_PRMT/ICS_FAC/ICS_ADDR/ICS_TELEPH
  DELETE
    FROM ics_teleph
   WHERE ics_teleph.ics_addr_id IN
            (SELECT ics_addr.ics_addr_id
               FROM ics_basic_prmt
                    JOIN ics_fac ON ics_fac.ics_basic_prmt_id = ics_basic_prmt.ics_basic_prmt_id
                    JOIN ics_addr ON ics_addr.ics_fac_id = ics_fac.ics_fac_id
                WHERE ics_basic_prmt.prmt_ident = P_PRMT_IDENT
  );
  -- /ICS_BASIC_PRMT/ICS_FAC/ICS_CONTACT/ICS_TELEPH
  DELETE
    FROM ics_teleph
   WHERE ics_teleph.ics_contact_id IN
            (SELECT ics_contact.ics_contact_id
               FROM ics_basic_prmt
                    JOIN ics_fac ON ics_fac.ics_basic_prmt_id = ics_basic_prmt.ics_basic_prmt_id
                    JOIN ics_contact ON ics_contact.ics_fac_id = ics_fac.ics_fac_id
                WHERE ics_basic_prmt.prmt_ident = P_PRMT_IDENT
  );
  -- /ICS_BASIC_PRMT/ICS_ADDR/ICS_TELEPH
  DELETE
    FROM ics_teleph
   WHERE ics_teleph.ics_addr_id IN
            (SELECT ics_addr.ics_addr_id
               FROM ics_basic_prmt
                    JOIN ics_addr ON ics_addr.ics_basic_prmt_id = ics_basic_prmt.ics_basic_prmt_id
                WHERE ics_basic_prmt.prmt_ident = P_PRMT_IDENT
  );
  -- /ICS_BASIC_PRMT/ICS_CONTACT/ICS_TELEPH
  DELETE
    FROM ics_teleph
   WHERE ics_teleph.ics_contact_id IN
            (SELECT ics_contact.ics_contact_id
               FROM ics_basic_prmt
                    JOIN ics_contact ON ics_contact.ics_basic_prmt_id = ics_basic_prmt.ics_basic_prmt_id
                WHERE ics_basic_prmt.prmt_ident = P_PRMT_IDENT
  );
  -- /ICS_BASIC_PRMT/ICS_FAC/ICS_ADDR
  DELETE
    FROM ics_addr
   WHERE ics_addr.ics_fac_id IN
            (SELECT ics_fac.ics_fac_id
               FROM ics_basic_prmt
                    JOIN ics_fac ON ics_fac.ics_basic_prmt_id = ics_basic_prmt.ics_basic_prmt_id
                WHERE ics_basic_prmt.prmt_ident = P_PRMT_IDENT
  );
  -- /ICS_BASIC_PRMT/ICS_FAC/ICS_CONTACT
  DELETE
    FROM ics_contact
   WHERE ics_contact.ics_fac_id IN
            (SELECT ics_fac.ics_fac_id
               FROM ics_basic_prmt
                    JOIN ics_fac ON ics_fac.ics_basic_prmt_id = ics_basic_prmt.ics_basic_prmt_id
                WHERE ics_basic_prmt.prmt_ident = P_PRMT_IDENT
  );
  -- /ICS_BASIC_PRMT/ICS_FAC/ICS_FAC_CLASS
  DELETE
    FROM ics_fac_class
   WHERE ics_fac_class.ics_fac_id IN
            (SELECT ics_fac.ics_fac_id
               FROM ics_basic_prmt
                    JOIN ics_fac ON ics_fac.ics_basic_prmt_id = ics_basic_prmt.ics_basic_prmt_id
                WHERE ics_basic_prmt.prmt_ident = P_PRMT_IDENT
  );
  -- /ICS_BASIC_PRMT/ICS_FAC/ICS_GEO_COORD
  DELETE
    FROM ics_geo_coord
   WHERE ics_geo_coord.ics_fac_id IN
            (SELECT ics_fac.ics_fac_id
               FROM ics_basic_prmt
                    JOIN ics_fac ON ics_fac.ics_basic_prmt_id = ics_basic_prmt.ics_basic_prmt_id
                WHERE ics_basic_prmt.prmt_ident = P_PRMT_IDENT
  );
  -- /ICS_BASIC_PRMT/ICS_FAC/ICS_NAICS_CODE
  DELETE
    FROM ics_naics_code
   WHERE ics_naics_code.ics_fac_id IN
            (SELECT ics_fac.ics_fac_id
               FROM ics_basic_prmt
                    JOIN ics_fac ON ics_fac.ics_basic_prmt_id = ics_basic_prmt.ics_basic_prmt_id
                WHERE ics_basic_prmt.prmt_ident = P_PRMT_IDENT
  );
  -- /ICS_BASIC_PRMT/ICS_FAC/ICS_ORIG_PROGS
  DELETE
    FROM ics_orig_progs
   WHERE ics_orig_progs.ics_fac_id IN
            (SELECT ics_fac.ics_fac_id
               FROM ics_basic_prmt
                    JOIN ics_fac ON ics_fac.ics_basic_prmt_id = ics_basic_prmt.ics_basic_prmt_id
                WHERE ics_basic_prmt.prmt_ident = P_PRMT_IDENT
  );
  -- /ICS_BASIC_PRMT/ICS_FAC/ICS_PLCY
  DELETE
    FROM ics_plcy
   WHERE ics_plcy.ics_fac_id IN
            (SELECT ics_fac.ics_fac_id
               FROM ics_basic_prmt
                    JOIN ics_fac ON ics_fac.ics_basic_prmt_id = ics_basic_prmt.ics_basic_prmt_id
                WHERE ics_basic_prmt.prmt_ident = P_PRMT_IDENT
  );
  -- /ICS_BASIC_PRMT/ICS_FAC/ICS_SIC_CODE
  DELETE
    FROM ics_sic_code
   WHERE ics_sic_code.ics_fac_id IN
            (SELECT ics_fac.ics_fac_id
               FROM ics_basic_prmt
                    JOIN ics_fac ON ics_fac.ics_basic_prmt_id = ics_basic_prmt.ics_basic_prmt_id
                WHERE ics_basic_prmt.prmt_ident = P_PRMT_IDENT
  );
  -- /ICS_BASIC_PRMT/ICS_ADDR
  DELETE
    FROM ics_addr
   WHERE ics_addr.ics_basic_prmt_id IN
            (SELECT ics_basic_prmt.ics_basic_prmt_id
               FROM ics_basic_prmt
                WHERE ics_basic_prmt.prmt_ident = P_PRMT_IDENT
  );
  -- /ICS_BASIC_PRMT/ICS_ASSC_PRMT
  DELETE
    FROM ics_assc_prmt
   WHERE ics_assc_prmt.ics_basic_prmt_id IN
            (SELECT ics_basic_prmt.ics_basic_prmt_id
               FROM ics_basic_prmt
                WHERE ics_basic_prmt.prmt_ident = P_PRMT_IDENT
  );
  -- /ICS_BASIC_PRMT/ICS_CMPL_TRACK_STAT
  DELETE
    FROM ics_cmpl_track_stat
   WHERE ics_cmpl_track_stat.ics_basic_prmt_id IN
            (SELECT ics_basic_prmt.ics_basic_prmt_id
               FROM ics_basic_prmt
                WHERE ics_basic_prmt.prmt_ident = P_PRMT_IDENT
  );
  -- /ICS_BASIC_PRMT/ICS_CONTACT
  DELETE
    FROM ics_contact
   WHERE ics_contact.ics_basic_prmt_id IN
            (SELECT ics_basic_prmt.ics_basic_prmt_id
               FROM ics_basic_prmt
                WHERE ics_basic_prmt.prmt_ident = P_PRMT_IDENT
  );
  -- /ICS_BASIC_PRMT/ICS_EFFLU_GUIDE
  DELETE
    FROM ics_efflu_guide
   WHERE ics_efflu_guide.ics_basic_prmt_id IN
            (SELECT ics_basic_prmt.ics_basic_prmt_id
               FROM ics_basic_prmt
                WHERE ics_basic_prmt.prmt_ident = P_PRMT_IDENT
  );
  -- /ICS_BASIC_PRMT/ICS_FAC
  DELETE
    FROM ics_fac
   WHERE ics_fac.ics_basic_prmt_id IN
            (SELECT ics_basic_prmt.ics_basic_prmt_id
               FROM ics_basic_prmt
                WHERE ics_basic_prmt.prmt_ident = P_PRMT_IDENT
  );
  -- /ICS_BASIC_PRMT/ICS_NAICS_CODE
  DELETE
    FROM ics_naics_code
   WHERE ics_naics_code.ics_basic_prmt_id IN
            (SELECT ics_basic_prmt.ics_basic_prmt_id
               FROM ics_basic_prmt
                WHERE ics_basic_prmt.prmt_ident = P_PRMT_IDENT
  );
  -- /ICS_BASIC_PRMT/ICS_OTHR_PRMTS
  DELETE
    FROM ics_othr_prmts
   WHERE ics_othr_prmts.ics_basic_prmt_id IN
            (SELECT ics_basic_prmt.ics_basic_prmt_id
               FROM ics_basic_prmt
                WHERE ics_basic_prmt.prmt_ident = P_PRMT_IDENT
  );
  -- /ICS_BASIC_PRMT/ICS_SIC_CODE
  DELETE
    FROM ics_sic_code
   WHERE ics_sic_code.ics_basic_prmt_id IN
            (SELECT ics_basic_prmt.ics_basic_prmt_id
               FROM ics_basic_prmt
                WHERE ics_basic_prmt.prmt_ident = P_PRMT_IDENT
  );
  -- /ICS_BASIC_PRMT
  UPDATE ics_basic_prmt
     set src_systm_ident = null
        ,transaction_type = 'D'
        ,transaction_timestamp = null
        ,prmt_type_code = null
        ,agncy_type_code = null
        ,prmt_stat_code = null
        ,prmt_issue_date = null
        ,prmt_effective_date = null
        ,prmt_expr_date = null
        ,reissu_prio_prmt_ind = null
        ,backlog_reason_txt = null
        ,prmt_issuing_org_type_name = null
        ,prmt_appealed_ind = null
        ,prmt_usr_dfnd_dat_elm_1_txt = null
        ,prmt_usr_dfnd_dat_elm_2_txt = null
        ,prmt_usr_dfnd_dat_elm_3_txt = null
        ,prmt_usr_dfnd_dat_elm_4_txt = null
        ,prmt_usr_dfnd_dat_elm_5_txt = null
        ,prmt_cmnts_txt = null
        ,major_minor_rating_code = null
        ,ttl_appl_dsgn_flow_num = null
        ,ttl_appl_aver_flow_num = null
        ,appl_rcvd_date = null
        ,prmt_appl_cmpl_date = null
        ,new_src_ind = null
        ,prmt_st_wtr_body_code = null
        ,prmt_st_wtr_body_name = null
        ,fedr_grant_ind = null
        ,dmr_cognznt_ofcl = null
        ,dmr_cognznt_ofcl_teleph_num = null
        ,sig_iu_ind = null
        ,rcvg_prmt_ident = null
        ,key_hash = MD5_HASH(prmt_ident)
        ,data_hash = MD5_HASH(prmt_ident)
   WHERE prmt_ident = P_PRMT_IDENT
  ;
  
  -- Remove any old records for ics_gnrl_prmt
  -- /ICS_GNRL_PRMT/ICS_FAC/ICS_ADDR/ICS_TELEPH
  DELETE
    FROM ics_teleph
   WHERE ics_teleph.ics_addr_id IN
            (SELECT ics_addr.ics_addr_id
               FROM ics_gnrl_prmt
                    JOIN ics_fac ON ics_fac.ics_gnrl_prmt_id = ics_gnrl_prmt.ics_gnrl_prmt_id
                    JOIN ics_addr ON ics_addr.ics_fac_id = ics_fac.ics_fac_id
                WHERE ics_gnrl_prmt.prmt_ident = P_PRMT_IDENT
  );
  -- /ICS_GNRL_PRMT/ICS_FAC/ICS_CONTACT/ICS_TELEPH
  DELETE
    FROM ics_teleph
   WHERE ics_teleph.ics_contact_id IN
            (SELECT ics_contact.ics_contact_id
               FROM ics_gnrl_prmt
                    JOIN ics_fac ON ics_fac.ics_gnrl_prmt_id = ics_gnrl_prmt.ics_gnrl_prmt_id
                    JOIN ics_contact ON ics_contact.ics_fac_id = ics_fac.ics_fac_id
                WHERE ics_gnrl_prmt.prmt_ident = P_PRMT_IDENT
  );
  -- /ICS_GNRL_PRMT/ICS_ADDR/ICS_TELEPH
  DELETE
    FROM ics_teleph
   WHERE ics_teleph.ics_addr_id IN
            (SELECT ics_addr.ics_addr_id
               FROM ics_gnrl_prmt
                    JOIN ics_addr ON ics_addr.ics_gnrl_prmt_id = ics_gnrl_prmt.ics_gnrl_prmt_id
                WHERE ics_gnrl_prmt.prmt_ident = P_PRMT_IDENT
  );
  -- /ICS_GNRL_PRMT/ICS_CONTACT/ICS_TELEPH
  DELETE
    FROM ics_teleph
   WHERE ics_teleph.ics_contact_id IN
            (SELECT ics_contact.ics_contact_id
               FROM ics_gnrl_prmt
                    JOIN ics_contact ON ics_contact.ics_gnrl_prmt_id = ics_gnrl_prmt.ics_gnrl_prmt_id
                WHERE ics_gnrl_prmt.prmt_ident = P_PRMT_IDENT
  );
  -- /ICS_GNRL_PRMT/ICS_FAC/ICS_ADDR
  DELETE
    FROM ics_addr
   WHERE ics_addr.ics_fac_id IN
            (SELECT ics_fac.ics_fac_id
               FROM ics_gnrl_prmt
                    JOIN ics_fac ON ics_fac.ics_gnrl_prmt_id = ics_gnrl_prmt.ics_gnrl_prmt_id
                WHERE ics_gnrl_prmt.prmt_ident = P_PRMT_IDENT
  );
  -- /ICS_GNRL_PRMT/ICS_FAC/ICS_CONTACT
  DELETE
    FROM ics_contact
   WHERE ics_contact.ics_fac_id IN
            (SELECT ics_fac.ics_fac_id
               FROM ics_gnrl_prmt
                    JOIN ics_fac ON ics_fac.ics_gnrl_prmt_id = ics_gnrl_prmt.ics_gnrl_prmt_id
                WHERE ics_gnrl_prmt.prmt_ident = P_PRMT_IDENT
  );
  -- /ICS_GNRL_PRMT/ICS_FAC/ICS_FAC_CLASS
  DELETE
    FROM ics_fac_class
   WHERE ics_fac_class.ics_fac_id IN
            (SELECT ics_fac.ics_fac_id
               FROM ics_gnrl_prmt
                    JOIN ics_fac ON ics_fac.ics_gnrl_prmt_id = ics_gnrl_prmt.ics_gnrl_prmt_id
                WHERE ics_gnrl_prmt.prmt_ident = P_PRMT_IDENT
  );
  -- /ICS_GNRL_PRMT/ICS_FAC/ICS_GEO_COORD
  DELETE
    FROM ics_geo_coord
   WHERE ics_geo_coord.ics_fac_id IN
            (SELECT ics_fac.ics_fac_id
               FROM ics_gnrl_prmt
                    JOIN ics_fac ON ics_fac.ics_gnrl_prmt_id = ics_gnrl_prmt.ics_gnrl_prmt_id
                WHERE ics_gnrl_prmt.prmt_ident = P_PRMT_IDENT
  );
  -- /ICS_GNRL_PRMT/ICS_FAC/ICS_NAICS_CODE
  DELETE
    FROM ics_naics_code
   WHERE ics_naics_code.ics_fac_id IN
            (SELECT ics_fac.ics_fac_id
               FROM ics_gnrl_prmt
                    JOIN ics_fac ON ics_fac.ics_gnrl_prmt_id = ics_gnrl_prmt.ics_gnrl_prmt_id
                WHERE ics_gnrl_prmt.prmt_ident = P_PRMT_IDENT
  );
  -- /ICS_GNRL_PRMT/ICS_FAC/ICS_ORIG_PROGS
  DELETE
    FROM ics_orig_progs
   WHERE ics_orig_progs.ics_fac_id IN
            (SELECT ics_fac.ics_fac_id
               FROM ics_gnrl_prmt
                    JOIN ics_fac ON ics_fac.ics_gnrl_prmt_id = ics_gnrl_prmt.ics_gnrl_prmt_id
                WHERE ics_gnrl_prmt.prmt_ident = P_PRMT_IDENT
  );
  -- /ICS_GNRL_PRMT/ICS_FAC/ICS_PLCY
  DELETE
    FROM ics_plcy
   WHERE ics_plcy.ics_fac_id IN
            (SELECT ics_fac.ics_fac_id
               FROM ics_gnrl_prmt
                    JOIN ics_fac ON ics_fac.ics_gnrl_prmt_id = ics_gnrl_prmt.ics_gnrl_prmt_id
                WHERE ics_gnrl_prmt.prmt_ident = P_PRMT_IDENT
  );
  -- /ICS_GNRL_PRMT/ICS_FAC/ICS_SIC_CODE
  DELETE
    FROM ics_sic_code
   WHERE ics_sic_code.ics_fac_id IN
            (SELECT ics_fac.ics_fac_id
               FROM ics_gnrl_prmt
                    JOIN ics_fac ON ics_fac.ics_gnrl_prmt_id = ics_gnrl_prmt.ics_gnrl_prmt_id
                WHERE ics_gnrl_prmt.prmt_ident = P_PRMT_IDENT
  );
  -- /ICS_GNRL_PRMT/ICS_ADDR
  DELETE
    FROM ics_addr
   WHERE ics_addr.ics_gnrl_prmt_id IN
            (SELECT ics_gnrl_prmt.ics_gnrl_prmt_id
               FROM ics_gnrl_prmt
                WHERE ics_gnrl_prmt.prmt_ident = P_PRMT_IDENT
  );
  -- /ICS_GNRL_PRMT/ICS_ASSC_PRMT
  DELETE
    FROM ics_assc_prmt
   WHERE ics_assc_prmt.ics_gnrl_prmt_id IN
            (SELECT ics_gnrl_prmt.ics_gnrl_prmt_id
               FROM ics_gnrl_prmt
                WHERE ics_gnrl_prmt.prmt_ident = P_PRMT_IDENT
  );
  -- /ICS_GNRL_PRMT/ICS_CMPL_TRACK_STAT
  DELETE
    FROM ics_cmpl_track_stat
   WHERE ics_cmpl_track_stat.ics_gnrl_prmt_id IN
            (SELECT ics_gnrl_prmt.ics_gnrl_prmt_id
               FROM ics_gnrl_prmt
                WHERE ics_gnrl_prmt.prmt_ident = P_PRMT_IDENT
  );
  -- /ICS_GNRL_PRMT/ICS_CONTACT
  DELETE
    FROM ics_contact
   WHERE ics_contact.ics_gnrl_prmt_id IN
            (SELECT ics_gnrl_prmt.ics_gnrl_prmt_id
               FROM ics_gnrl_prmt
                WHERE ics_gnrl_prmt.prmt_ident = P_PRMT_IDENT
  );
  -- /ICS_GNRL_PRMT/ICS_EFFLU_GUIDE
  DELETE
    FROM ics_efflu_guide
   WHERE ics_efflu_guide.ics_gnrl_prmt_id IN
            (SELECT ics_gnrl_prmt.ics_gnrl_prmt_id
               FROM ics_gnrl_prmt
                WHERE ics_gnrl_prmt.prmt_ident = P_PRMT_IDENT
  );
  -- /ICS_GNRL_PRMT/ICS_FAC
  DELETE
    FROM ics_fac
   WHERE ics_fac.ics_gnrl_prmt_id IN
            (SELECT ics_gnrl_prmt.ics_gnrl_prmt_id
               FROM ics_gnrl_prmt
                WHERE ics_gnrl_prmt.prmt_ident = P_PRMT_IDENT
  );
  -- /ICS_GNRL_PRMT/ICS_NAICS_CODE
  DELETE
    FROM ics_naics_code
   WHERE ics_naics_code.ics_gnrl_prmt_id IN
            (SELECT ics_gnrl_prmt.ics_gnrl_prmt_id
               FROM ics_gnrl_prmt
                WHERE ics_gnrl_prmt.prmt_ident = P_PRMT_IDENT
  );
  -- /ICS_GNRL_PRMT/ICS_OTHR_PRMTS
  DELETE
    FROM ics_othr_prmts
   WHERE ics_othr_prmts.ics_gnrl_prmt_id IN
            (SELECT ics_gnrl_prmt.ics_gnrl_prmt_id
               FROM ics_gnrl_prmt
                WHERE ics_gnrl_prmt.prmt_ident = P_PRMT_IDENT
  );
  -- /ICS_GNRL_PRMT/ICS_SIC_CODE
  DELETE
    FROM ics_sic_code
   WHERE ics_sic_code.ics_gnrl_prmt_id IN
            (SELECT ics_gnrl_prmt.ics_gnrl_prmt_id
               FROM ics_gnrl_prmt
                WHERE ics_gnrl_prmt.prmt_ident = P_PRMT_IDENT
  );
  -- /ICS_GNRL_PRMT
  
  UPDATE ics_gnrl_prmt
     SET src_systm_ident = null
        ,transaction_type = 'D'
        ,transaction_timestamp = null
        ,assc_master_gnrl_prmt_ident = null
        ,prmt_type_code = null
        ,agncy_type_code = null
        ,prmt_stat_code = null
        ,prmt_issue_date = null
        ,prmt_effective_date = null
        ,prmt_expr_date = null
        ,reissu_prio_prmt_ind = null
        ,backlog_reason_txt = null
        ,prmt_issuing_org_type_name = null
        ,prmt_appealed_ind = null
        ,prmt_usr_dfnd_dat_elm_1_txt = null
        ,prmt_usr_dfnd_dat_elm_2_txt = null
        ,prmt_usr_dfnd_dat_elm_3_txt = null
        ,prmt_usr_dfnd_dat_elm_4_txt = null
        ,prmt_usr_dfnd_dat_elm_5_txt = null
        ,prmt_cmnts_txt = null
        ,major_minor_rating_code = null
        ,ttl_appl_dsgn_flow_num = null
        ,ttl_appl_aver_flow_num = null
        ,appl_rcvd_date = null
        ,prmt_appl_cmpl_date = null
        ,new_src_ind = null
        ,prmt_st_wtr_body_code = null
        ,prmt_st_wtr_body_name = null
        ,fedr_grant_ind = null
        ,dmr_cognznt_ofcl = null
        ,dmr_cognznt_ofcl_teleph_num = null
        ,key_hash = MD5_HASH(prmt_ident)
        ,data_hash = MD5_HASH(prmt_ident)
   WHERE prmt_ident = P_PRMT_IDENT;

	END;

END IF; --IF P_DELETE_FIRST_YN = 'Y'

END;