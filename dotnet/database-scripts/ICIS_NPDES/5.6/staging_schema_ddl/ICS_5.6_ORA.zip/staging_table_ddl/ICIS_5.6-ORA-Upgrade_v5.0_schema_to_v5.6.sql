/*
Copyright (c) 2012, The Environmental Council of the States (ECOS)
All rights reserved.
 
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
 
 * Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
 * Neither the name of the ECOS nor the names of its contributors may
   be used to endorse or promote products derived from this software
   without specific prior written permission.
 
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/
/*************************************************************************************************
** ObjectName: ICIS_5.6-ORA-Upgrade_v5.0_schema_to_v5.6.sql
**
** Author: Windsor Solutions, Inc.
**
** Company Name: Windsor Solutions, Inc.
**
** Description:  This script will update an existing ICIS 5.0 database to support the ICIS 5.6
**               XML schema.  This script can be run multiple times without issue.
**
** Revision History:
** ------------------------------------------------------------------------------------------------
** Date          Name        Description
** ------------------------------------------------------------------------------------------------
** 09/26/2016    Windsor     Created
** 09/28/2016    CTyler      Added BASE_TABLE_NAME and ETL_PROCEDURE utility columns to ICS_PAYLOAD
**
*************************************************************************************************/


/********************************************************************************************************  

    CHANGE #1
    Add column CMPL_MON_ACTY_TYPE_CODE to table ICS_CMPL_MON.

*********************************************************************************************************/

DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  /*  Check to see if CMPL_MON_ACTY_TYPE_CODE column exists on the database table ICS_CMPL_MON  */
   SELECT 1
     INTO v_object_ind
     FROM user_tables
     JOIN user_tab_cols
       ON user_tab_cols.table_name = user_tables.table_name
    WHERE user_tables.table_name = 'ICS_CMPL_MON'
      AND user_tab_cols.column_name = 'CMPL_MON_ACTY_TYPE_CODE';
   
   /* The column already exists in schema, bypass creation */
    DBMS_OUTPUT.PUT_LINE( 'The column CMPL_MON_ACTY_TYPE_CODE already existed on ICS_CMPL_MON, schema alteration bypassed!');

EXCEPTION

  WHEN NO_DATA_FOUND THEN  
  
    BEGIN
       
      --  Add new column 
      v_sql_statement := 'ALTER TABLE ICS_CMPL_MON ADD (CMPL_MON_ACTY_TYPE_CODE VARCHAR2(3) NULL)';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The column CMPL_MON_ACTY_TYPE_CODE was added to the table ICS_CMPL_MON!');
      
     END;  

END;
/

COMMENT ON COLUMN "ICS_CMPL_MON"."CMPL_MON_ACTY_TYPE_CODE" IS 'String that represents the type of compliance monitoring activity.  Optional';


/******************************************************************************************************** 
    CHANGE #2
    Create new table ICS_PROG_DEFCY_TYPE as a child of table ICS_CMPL_MON.

*********************************************************************************************************/

DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  /*  Check to see if table ICS_PROG_DEFCY_TYPE exists  */
   SELECT 1
     INTO v_object_ind
     FROM user_tables
    WHERE user_tables.table_name = 'ICS_PROG_DEFCY_TYPE';
   
   /* The column already exists in schema, bypass creation */
    DBMS_OUTPUT.PUT_LINE( 'The table ICS_PROG_DEFCY_TYPE already exists, schema alteration bypassed!');

EXCEPTION

  WHEN NO_DATA_FOUND THEN  
  
    BEGIN
       
      --  Create table
      v_sql_statement := 'CREATE TABLE ICS_PROG_DEFCY_TYPE 
                          (ICS_PROG_DEFCY_TYPE_ID VARCHAR2(36) NOT NULL,
                           ICS_CMPL_MON_ID VARCHAR2(36) NOT NULL,
                           PROG_DEFCY_TYPE_CODE VARCHAR2(3) NOT NULL,
                           DATA_HASH VARCHAR2(32) NULL)';
                           
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The table ICS_PROG_DEFCY_TYPE was added to the schema!');

      v_sql_statement := 'ALTER TABLE ICS_PROG_DEFCY_TYPE ADD ( CONSTRAINT PK_PROG_DEFCY_TYPE PRIMARY KEY(ICS_PROG_DEFCY_TYPE_ID) NOT DEFERRABLE INITIALLY IMMEDIATE)';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The prmary key PK_PROG_DEFCY_TYPE was added to table ICS_PROG_DEFCY_TYPE.');

      v_sql_statement := 'CREATE INDEX IX_PG_DY_TP_ICS_CMPL_MON_ID ON ICS_PROG_DEFCY_TYPE(ICS_CMPL_MON_ID)';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The index IX_PG_DY_TP_ICS_CMPL_MON_ID was added to table ICS_PROG_DEFCY_TYPE.');
      
      v_sql_statement := 'ALTER TABLE ICS_PROG_DEFCY_TYPE ADD CONSTRAINT FK_PROG_DEFCY_TYPE_CMPL_MON FOREIGN KEY(ICS_CMPL_MON_ID) REFERENCES ICS_CMPL_MON(ICS_CMPL_MON_ID) ON DELETE CASCADE NOT DEFERRABLE INITIALLY IMMEDIATE VALIDATE';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The foreign key FK_PROG_DEFCY_TYPE_CMPL_MON was added to table ICS_PROG_DEFCY_TYPE.');
    
     END;  

END;
/


/******************************************************************************************************** 
    CHANGE #3
    Create new table ICS_SEP as a child of table ICS_FINAL_ORDER.

*********************************************************************************************************/

DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  /*  Check to see if table ICS_SEP exists  */
   SELECT 1
     INTO v_object_ind
     FROM user_tables
    WHERE user_tables.table_name = 'ICS_SEP';
   
   /* The column already exists in schema, bypass creation */
    DBMS_OUTPUT.PUT_LINE( 'The table ICS_SEP already exists, schema alteration bypassed!');

EXCEPTION

  WHEN NO_DATA_FOUND THEN  
  
    BEGIN
       
      --  Create table
      v_sql_statement := 'CREATE TABLE ICS_SEP 
                          (ICS_SEP_ID VARCHAR2(36) NOT NULL,
                           ICS_FINAL_ORDER_ID VARCHAR2(36) NOT NULL,
                           SEP_IDENT NUMBER(9,0) NOT NULL,
                           SEP_DESC VARCHAR2(4000) NOT NULL,
                           SEP_PNLTY_ASSESSMENT_AMT NUMBER(17,2) NOT NULL,
                           DATA_HASH VARCHAR2(32) NULL)';

      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The table ICS_SEP was added to the schema!');

      v_sql_statement := 'ALTER TABLE ICS_SEP ADD ( CONSTRAINT PK_SEP PRIMARY KEY(ICS_SEP_ID) NOT DEFERRABLE INITIALLY IMMEDIATE)';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The prmary key PK_SEP was added to table ICS_SEP.');

      v_sql_statement := 'CREATE INDEX IX_SEP_ICS_FINAL_ORDER_ID ON ICS_SEP(ICS_FINAL_ORDER_ID)';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The index IX_SEP_ICS_FINAL_ORDER_ID was added to table ICS_SEP.');
      
      v_sql_statement := 'ALTER TABLE ICS_SEP ADD CONSTRAINT FK_SEP_FINAL_ORDER FOREIGN KEY(ICS_FINAL_ORDER_ID) REFERENCES ICS_FINAL_ORDER(ICS_FINAL_ORDER_ID) ON DELETE CASCADE NOT DEFERRABLE INITIALLY IMMEDIATE VALIDATE';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The foreign key FK_SEP_FINAL_ORDER was added to table ICS_SEP.');
    
     END;  

END;
/


/******************************************************************************************************** 
    CHANGE #4
    Add column LMT_MOD_TYPE_STAY_REASON_TXT to table ICS_LMT.
*********************************************************************************************************/

DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  /*  Check to see if LMT_MOD_TYPE_STAY_REASON_TXT column exists on the database table ICS_LMT  */
   SELECT 1
     INTO v_object_ind
     FROM user_tables
     JOIN user_tab_cols
       ON user_tab_cols.table_name = user_tables.table_name
    WHERE user_tables.table_name = 'ICS_LMT'
      AND user_tab_cols.column_name = 'LMT_MOD_TYPE_STAY_REASON_TXT';
   
   /* The column already exists in schema, bypass creation */
    DBMS_OUTPUT.PUT_LINE( 'The column LMT_MOD_TYPE_STAY_REASON_TXT already existed on ICS_LMT, schema alteration bypassed!');

EXCEPTION

  WHEN NO_DATA_FOUND THEN  
  
    BEGIN
       
      --  Add new column 
      v_sql_statement := 'ALTER TABLE ICS_LMT ADD (LMT_MOD_TYPE_STAY_REASON_TXT VARCHAR2(500) NULL)';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The column LMT_MOD_TYPE_STAY_REASON_TXT was added to the table ICS_LMT!');
      
     END;  

END;
/

COMMENT ON COLUMN "ICS_LMT"."LMT_MOD_TYPE_STAY_REASON_TXT" IS 'String that describes the reason for a stay on a permitted limit.  Optional';


/******************************************************************************************************** 
    CHANGE #5.a
    Add columns MAJOR_MINOR_STAT_IND and MAJOR_MINOR_STAT_START_DATE to table ICS_BASIC_PRMT.
*********************************************************************************************************/

DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  /*  Check to see if MAJOR_MINOR_STAT_IND column exists on the database table ICS_BASIC_PRMT  */
   SELECT 1
     INTO v_object_ind
     FROM user_tables
     JOIN user_tab_cols
       ON user_tab_cols.table_name = user_tables.table_name
    WHERE user_tables.table_name = 'ICS_BASIC_PRMT'
      AND user_tab_cols.column_name = 'MAJOR_MINOR_STAT_IND';
   
   /* The column already exists in schema, bypass creation */
    DBMS_OUTPUT.PUT_LINE( 'The column MAJOR_MINOR_STAT_IND already existed on ICS_BASIC_PRMT, schema alteration bypassed!');

EXCEPTION

  WHEN NO_DATA_FOUND THEN  
  
    BEGIN
       
      --  Add new column 
      v_sql_statement := 'ALTER TABLE ICS_BASIC_PRMT ADD (MAJOR_MINOR_STAT_IND VARCHAR2(1) NULL, MAJOR_MINOR_STAT_START_DATE DATE NULL)';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The columns MAJOR_MINOR_STAT_IND and MAJOR_MINOR_STAT_START_DATE were added to the table ICS_BASIC_PRMT!');
      
     END;  

END;
/

COMMENT ON COLUMN "ICS_BASIC_PRMT"."MAJOR_MINOR_STAT_IND" IS 'The flag to indicate if the permit is a major or minor.  Optional';
COMMENT ON COLUMN "ICS_BASIC_PRMT"."MAJOR_MINOR_STAT_START_DATE" IS 'Major/Minor status start date.  Optional';


/******************************************************************************************************** 
    CHANGE #5.b
    Add columns MAJOR_MINOR_STAT_IND and MAJOR_MINOR_STAT_START_DATE to table ICS_GNRL_PRMT.
*********************************************************************************************************/

DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  /*  Check to see if MAJOR_MINOR_STAT_IND column exists on the database table ICS_GNRL_PRMT  */
   SELECT 1
     INTO v_object_ind
     FROM user_tables
     JOIN user_tab_cols
       ON user_tab_cols.table_name = user_tables.table_name
    WHERE user_tables.table_name = 'ICS_GNRL_PRMT'
      AND user_tab_cols.column_name = 'MAJOR_MINOR_STAT_IND';
   
   /* The column already exists in schema, bypass creation */
    DBMS_OUTPUT.PUT_LINE( 'The column MAJOR_MINOR_STAT_IND already existed on ICS_GNRL_PRMT, schema alteration bypassed!');

EXCEPTION

  WHEN NO_DATA_FOUND THEN  
  
    BEGIN
       
      --  Add new column 
      v_sql_statement := 'ALTER TABLE ICS_GNRL_PRMT ADD (MAJOR_MINOR_STAT_IND VARCHAR2(1) NULL, MAJOR_MINOR_STAT_START_DATE DATE NULL)';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The columns MAJOR_MINOR_STAT_IND and MAJOR_MINOR_STAT_START_DATE were added to the table ICS_GNRL_PRMT!');
      
     END;  

END;
/

COMMENT ON COLUMN "ICS_GNRL_PRMT"."MAJOR_MINOR_STAT_IND" IS 'The flag to indicate if the permit is a major or minor.  Optional';
COMMENT ON COLUMN "ICS_GNRL_PRMT"."MAJOR_MINOR_STAT_START_DATE" IS 'Major/Minor status start date.  Optional';


/******************************************************************************************************** 
    CHANGE #6.a
    Add columns DMR_NON_RCPT_STAT_IND and DMR_NON_RCPT_STAT_START_DATE to table ICS_BASIC_PRMT.
*********************************************************************************************************/

DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  /*  Check to see if DMR_NON_RCPT_STAT_IND column exists on the database table ICS_BASIC_PRMT  */
   SELECT 1
     INTO v_object_ind
     FROM user_tables
     JOIN user_tab_cols
       ON user_tab_cols.table_name = user_tables.table_name
    WHERE user_tables.table_name = 'ICS_BASIC_PRMT'
      AND user_tab_cols.column_name = 'DMR_NON_RCPT_STAT_IND';
   
   /* The column already exists in schema, bypass creation */
    DBMS_OUTPUT.PUT_LINE( 'The column DMR_NON_RCPT_STAT_IND already existed on ICS_BASIC_PRMT, schema alteration bypassed!');

EXCEPTION

  WHEN NO_DATA_FOUND THEN  
  
    BEGIN
       
      --  Add new column 
      v_sql_statement := 'ALTER TABLE ICS_BASIC_PRMT ADD (DMR_NON_RCPT_STAT_IND VARCHAR2(1) NULL, DMR_NON_RCPT_STAT_START_DATE DATE NULL)';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The columns DMR_NON_RCPT_STAT_IND and DMR_NON_RCPT_STAT_START_DATE were added to the table ICS_BASIC_PRMT!');
      
     END;  

END;
/

COMMENT ON COLUMN "ICS_BASIC_PRMT"."DMR_NON_RCPT_STAT_IND" IS 'The flag to indicate if the permit is a major or minor.  Optional';
COMMENT ON COLUMN "ICS_BASIC_PRMT"."DMR_NON_RCPT_STAT_START_DATE" IS 'Major/Minor status start date.  Optional';


/******************************************************************************************************** 
    CHANGE #6.b
    Add columns DMR_NON_RCPT_STAT_IND and DMR_NON_RCPT_STAT_START_DATE to table ICS_GNRL_PRMT.
*********************************************************************************************************/

DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  /*  Check to see if DMR_NON_RCPT_STAT_IND column exists on the database table ICS_GNRL_PRMT  */
   SELECT 1
     INTO v_object_ind
     FROM user_tables
     JOIN user_tab_cols
       ON user_tab_cols.table_name = user_tables.table_name
    WHERE user_tables.table_name = 'ICS_GNRL_PRMT'
      AND user_tab_cols.column_name = 'DMR_NON_RCPT_STAT_IND';
   
   /* The column already exists in schema, bypass creation */
    DBMS_OUTPUT.PUT_LINE( 'The column DMR_NON_RCPT_STAT_IND already existed on ICS_GNRL_PRMT, schema alteration bypassed!');

EXCEPTION

  WHEN NO_DATA_FOUND THEN  
  
    BEGIN
       
      --  Add new column 
      v_sql_statement := 'ALTER TABLE ICS_GNRL_PRMT ADD (DMR_NON_RCPT_STAT_IND VARCHAR2(1) NULL, DMR_NON_RCPT_STAT_START_DATE DATE NULL)';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The columns DMR_NON_RCPT_STAT_IND and DMR_NON_RCPT_STAT_START_DATE were added to the table ICS_GNRL_PRMT!');
      
     END;  

END;
/

COMMENT ON COLUMN "ICS_GNRL_PRMT"."DMR_NON_RCPT_STAT_IND" IS 'The flag to indicate if the permit is a major or minor.  Optional';
COMMENT ON COLUMN "ICS_GNRL_PRMT"."DMR_NON_RCPT_STAT_START_DATE" IS 'Major/Minor status start date.  Optional';


/******************************************************************************************************** 
    CHANGE #7
    Create new table ICS_REP_NON_CMPL_STAT as a child of table ICS_BASIC_PRMT and ICS_GNRL_PERMIT.

*********************************************************************************************************/

DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  /*  Check to see if table ICS_REP_NON_CMPL_STAT exists  */
   SELECT 1
     INTO v_object_ind
     FROM user_tables
    WHERE user_tables.table_name = 'ICS_REP_NON_CMPL_STAT';
   
   /* The column already exists in schema, bypass creation */
    DBMS_OUTPUT.PUT_LINE( 'The table ICS_REP_NON_CMPL_STAT already exists, schema alteration bypassed!');

EXCEPTION

  WHEN NO_DATA_FOUND THEN  
  
    BEGIN
       
      --  Create table
      v_sql_statement := 'CREATE TABLE ICS_REP_NON_CMPL_STAT 
                          (ICS_REP_NON_CMPL_STAT_ID VARCHAR2(36) NOT NULL,
                           ICS_BASIC_PRMT_ID VARCHAR2(36) NULL,
                           ICS_GNRL_PRMT_ID VARCHAR2(36) NULL,
                           REP_NON_CMPL_STAT_CODE_YEAR NUMBER(9,0) NULL,
                           REP_NON_CMPL_STAT_CODE_QUARTER NUMBER(9,0) NULL,
                           REP_NON_CMPL_MANUAL_STAT_CODE VARCHAR2(3) NULL,
                           DATA_HASH VARCHAR2(32) NULL)';

      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The table ICS_REP_NON_CMPL_STAT was added to the schema!');

      v_sql_statement := 'ALTER TABLE ICS_REP_NON_CMPL_STAT ADD ( CONSTRAINT PK_REP_NON_CMPL_STAT PRIMARY KEY(ICS_REP_NON_CMPL_STAT_ID) NOT DEFERRABLE INITIALLY IMMEDIATE)';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The prmary key PK_REP_NON_CMPL_STAT was added to table ICS_REP_NON_CMPL_STAT.');

      v_sql_statement := 'CREATE INDEX IX_REP_NON_CMP_STA_IC_BS_PR_ID ON ICS_REP_NON_CMPL_STAT(ICS_BASIC_PRMT_ID)';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The index IX_REP_NON_CMP_STA_IC_BS_PR_ID was added to table ICS_REP_NON_CMPL_STAT.');
      
      v_sql_statement := 'ALTER TABLE ICS_REP_NON_CMPL_STAT ADD CONSTRAINT FK_REP_NON_CMPL_STAT_BSIC_PRMT FOREIGN KEY(ICS_BASIC_PRMT_ID) REFERENCES ICS_BASIC_PRMT(ICS_BASIC_PRMT_ID) ON DELETE CASCADE NOT DEFERRABLE INITIALLY IMMEDIATE VALIDATE';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The foreign key FK_REP_NON_CMPL_STAT_BSIC_PRMT was added to table ICS_REP_NON_CMPL_STAT.');
 
      v_sql_statement := 'CREATE INDEX IX_REP_NON_CMP_STA_IC_GN_PR_ID ON ICS_REP_NON_CMPL_STAT(ICS_GNRL_PRMT_ID)';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The index IX_REP_NON_CMP_STA_IC_GN_PR_ID was added to table ICS_REP_NON_CMPL_STAT.');
      
      v_sql_statement := 'ALTER TABLE ICS_REP_NON_CMPL_STAT ADD CONSTRAINT FK_REP_NON_CMPL_STAT_GNRL_PRMT FOREIGN KEY(ICS_GNRL_PRMT_ID) REFERENCES ICS_GNRL_PRMT(ICS_GNRL_PRMT_ID) ON DELETE CASCADE NOT DEFERRABLE INITIALLY IMMEDIATE VALIDATE';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The foreign key FK_REP_NON_CMPL_STAT_GNRL_PRMT was added to table ICS_REP_NON_CMPL_STAT.');
      
     END;  

END;
/


/********************************************************************************************************  

    CHANGE #8
    Drop column SNGL_EVT_VIOL_START_DATE from table ICS_SNGL_EVT_VIOL.

*********************************************************************************************************/

DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  /*  Check to see if SNGL_EVT_VIOL_START_DATE column exists on the database table ICS_SNGL_EVT_VIOL  */
   SELECT 1
     INTO v_object_ind
     FROM user_tables
     JOIN user_tab_cols
       ON user_tab_cols.table_name = user_tables.table_name
    WHERE user_tables.table_name = 'ICS_SNGL_EVT_VIOL'
      AND user_tab_cols.column_name = 'SNGL_EVT_VIOL_START_DATE';
   
    BEGIN
       
      --  Drop column 
      v_sql_statement := 'ALTER TABLE ICS_SNGL_EVT_VIOL DROP (SNGL_EVT_VIOL_START_DATE)';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The column SNGL_EVT_VIOL_START_DATE was dropped from the table ICS_SNGL_EVT_VIOL!');
      
     END;  

EXCEPTION

  WHEN NO_DATA_FOUND THEN  

   /* The column does not exist in schema, bypass creation */
    DBMS_OUTPUT.PUT_LINE( 'The column SNGL_EVT_VIOL_START_DATE does not exist on ICS_SNGL_EVT_VIOL, schema alteration bypassed!');  

END;
/


/********************************************************************************************************  

    CHANGE #9.a
    Add column ICS_UNPRMT_FAC_ID to existing table ICS_PRMT_COMP_TYPE and add foreign key to ICS_UNPRMT_FAC.

*********************************************************************************************************/

DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  /*  Check to see if ICS_UNPRMT_FAC_ID column exists on the database table ICS_PRMT_COMP_TYPE  */
   SELECT 1
     INTO v_object_ind
     FROM user_tables
     JOIN user_tab_cols
       ON user_tab_cols.table_name = user_tables.table_name
    WHERE user_tables.table_name = 'ICS_PRMT_COMP_TYPE'
      AND user_tab_cols.column_name = 'ICS_UNPRMT_FAC_ID';
   
   /* The column already exists in schema, bypass creation */
    DBMS_OUTPUT.PUT_LINE( 'The column ICS_UNPRMT_FAC_ID already exists on ICS_PRMT_COMP_TYPE, schema alteration bypassed!');

EXCEPTION

  WHEN NO_DATA_FOUND THEN  
  
    BEGIN
       
      --  Add new column 
      v_sql_statement := 'ALTER TABLE ICS_PRMT_COMP_TYPE ADD (ICS_UNPRMT_FAC_ID VARCHAR2(36) NULL)';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The column ICS_UNPRMT_FAC_ID was added to the table ICS_PRMT_COMP_TYPE!');

      v_sql_statement := 'CREATE INDEX IX_PRMT_COMP_TYPE_UNPRMT_FAC ON ICS_PRMT_COMP_TYPE(ICS_UNPRMT_FAC_ID)';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The index IX_PRMT_COMP_TYPE_UNPRMT_FAC was added to table ICS_PRMT_COMP_TYPE.');
      
      v_sql_statement := 'ALTER TABLE ICS_PRMT_COMP_TYPE ADD CONSTRAINT FK_PRMT_COMP_TYPE_UNPRMT_FAC FOREIGN KEY(ICS_UNPRMT_FAC_ID) REFERENCES ICS_UNPRMT_FAC(ICS_UNPRMT_FAC_ID) ON DELETE CASCADE NOT DEFERRABLE INITIALLY IMMEDIATE VALIDATE';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The foreign key FK_PRMT_COMP_TYPE_UNPRMT_FAC was added to table ICS_PRMT_COMP_TYPE.');
      
     END;  

END;
/

COMMENT ON COLUMN "ICS_PRMT_COMP_TYPE"."ICS_UNPRMT_FAC_ID" IS 'FK to ICS_UNPRMT_FAC Table';

/********************************************************************************************************  

    CHANGE #9.b
    Modify existing foreign key column ICS_MASTER_GNRL_PRMT_ID to allow nulls.

*********************************************************************************************************/

DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  /*  Check to see if ICS_MASTER_GNRL_PRMT_ID column exists on the database table ICS_PRMT_COMP_TYPE  */
   SELECT 1
     INTO v_object_ind
     FROM user_tables
     JOIN user_tab_cols
       ON user_tab_cols.table_name = user_tables.table_name
    WHERE user_tables.table_name = 'ICS_PRMT_COMP_TYPE'
      AND user_tab_cols.column_name = 'ICS_MASTER_GNRL_PRMT_ID'
      AND user_tab_cols.nullable = 'Y';
   
     /* The column is correct in schema */
    DBMS_OUTPUT.PUT_LINE( 'The column ICS_MASTER_GNRL_PRMT_ID on ICS_PRMT_COMP_TYPE is correct, schema alteration bypassed!');

EXCEPTION

  WHEN NO_DATA_FOUND THEN  
  
    BEGIN
       
      --  Modify existing parent foreign key column to allow nulls
      v_sql_statement := 'ALTER TABLE ICS_PRMT_COMP_TYPE MODIFY (ICS_MASTER_GNRL_PRMT_ID VARCHAR2(36) NULL)';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The column ICS_MASTER_GNRL_PRMT_ID on the table ICS_PRMT_COMP_TYPE was modified to allow nulls!');
      
     END; 
     
END;
/


/********************************************************************************************************  

    CHANGE #10.a
    Modify existing column INDST_ACTY_SIZE on table ICS_SW_INDST_PRMT.

*********************************************************************************************************/

DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  /*  Check to see if INDST_ACTY_SIZE column exists on the database table ICS_SW_INDST_PRMT  */
   SELECT 1
     INTO v_object_ind
     FROM user_tables
     JOIN user_tab_cols
       ON user_tab_cols.table_name = user_tables.table_name
    WHERE user_tables.table_name = 'ICS_SW_INDST_PRMT'
      AND user_tab_cols.column_name = 'INDST_ACTY_SIZE'
      AND user_tab_cols.data_type = 'NUMBER';

     /* The column is correct in schema */
    DBMS_OUTPUT.PUT_LINE( 'The column INDST_ACTY_SIZE on ICS_SW_INDST_PRMT is correct, schema alteration bypassed!');

EXCEPTION

  WHEN NO_DATA_FOUND THEN  
  
    BEGIN
       
      --  Modify column to correct data type
      v_sql_statement := 'ALTER TABLE ICS_SW_INDST_PRMT MODIFY (INDST_ACTY_SIZE NUMBER(10,2))';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The column INDST_ACTY_SIZE on the table ICS_SW_INDST_PRMT was modified!');
      
     END; 

END;
/


/********************************************************************************************************  

    CHANGE #10.b
    Modify existing column INDST_ACTY_SIZE on table ICS_SWMS_4_LARGE_PRMT.

*********************************************************************************************************/

DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  /*  Check to see if INDST_ACTY_SIZE column exists on the database table ICS_SW_INDST_PRMT  */
   SELECT 1
     INTO v_object_ind
     FROM user_tables
     JOIN user_tab_cols
       ON user_tab_cols.table_name = user_tables.table_name
    WHERE user_tables.table_name = 'ICS_SWMS_4_LARGE_PRMT'
      AND user_tab_cols.column_name = 'INDST_ACTY_SIZE'
      AND user_tab_cols.data_type = 'NUMBER';

     /* The column is correct in schema */
    DBMS_OUTPUT.PUT_LINE( 'The column INDST_ACTY_SIZE on ICS_SWMS_4_LARGE_PRMT is correct, schema alteration bypassed!');

EXCEPTION

  WHEN NO_DATA_FOUND THEN  
  
    BEGIN
       
      --  Modify column to correct data type
      v_sql_statement := 'ALTER TABLE ICS_SWMS_4_LARGE_PRMT MODIFY (INDST_ACTY_SIZE NUMBER(10,2))';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The column INDST_ACTY_SIZE on the table ICS_SWMS_4_LARGE_PRMT was modified!');
      
     END; 

END;
/


/********************************************************************************************************  

    CHANGE #10.c
    Modify existing column INDST_ACTY_SIZE on table ICS_SWMS_4_SMALL_PRMT.

*********************************************************************************************************/

DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  /*  Check to see if INDST_ACTY_SIZE column exists on the database table ICS_SW_INDST_PRMT  */
   SELECT 1
     INTO v_object_ind
     FROM user_tables
     JOIN user_tab_cols
       ON user_tab_cols.table_name = user_tables.table_name
    WHERE user_tables.table_name = 'ICS_SWMS_4_SMALL_PRMT'
      AND user_tab_cols.column_name = 'INDST_ACTY_SIZE'
      AND user_tab_cols.data_type = 'NUMBER';

     /* The column is correct in schema */
    DBMS_OUTPUT.PUT_LINE( 'The column INDST_ACTY_SIZE on ICS_SWMS_4_SMALL_PRMT is correct, schema alteration bypassed!');

EXCEPTION

  WHEN NO_DATA_FOUND THEN  
  
    BEGIN
       
      --  Modify column to correct data type
      v_sql_statement := 'ALTER TABLE ICS_SWMS_4_SMALL_PRMT MODIFY (INDST_ACTY_SIZE NUMBER(10,2))';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The column INDST_ACTY_SIZE on the table ICS_SWMS_4_SMALL_PRMT was modified!');
      
     END; 

END;
/


/********************************************************************************************************  

    CHANGE #10.d
    Modify existing column INDST_ACTY_SIZE on table ICS_SW_CNST_PRMT.

*********************************************************************************************************/

DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  /*  Check to see if INDST_ACTY_SIZE column exists on the database table ICS_SW_INDST_PRMT  */
   SELECT 1
     INTO v_object_ind
     FROM user_tables
     JOIN user_tab_cols
       ON user_tab_cols.table_name = user_tables.table_name
    WHERE user_tables.table_name = 'ICS_SW_CNST_PRMT'
      AND user_tab_cols.column_name = 'INDST_ACTY_SIZE'
      AND user_tab_cols.data_type = 'NUMBER';

     /* The column is correct in schema */
    DBMS_OUTPUT.PUT_LINE( 'The column INDST_ACTY_SIZE on ICS_SW_CNST_PRMT is correct, schema alteration bypassed!');

EXCEPTION

  WHEN NO_DATA_FOUND THEN  
  
    BEGIN
       
      --  Modify column to correct data type
      v_sql_statement := 'ALTER TABLE ICS_SW_CNST_PRMT MODIFY (INDST_ACTY_SIZE NUMBER(10,2))';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The column INDST_ACTY_SIZE on the table ICS_SW_CNST_PRMT was modified!');
      
     END; 

END;
/


/********************************************************************************************************  

    CHANGE #11
    Modify data type for column PRMT_IDENT on table ICS_SW_INDST_ANNUL_REP to standard format (char(9)).

*********************************************************************************************************/

DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  /*  Check to see if PRMT_IDENT column exists on the database table ICS_SW_INDST_ANNUL_REP  */
   SELECT 1
     INTO v_object_ind
     FROM user_tables
     JOIN user_tab_cols
       ON user_tab_cols.table_name = user_tables.table_name
    WHERE user_tables.table_name = 'ICS_SW_INDST_ANNUL_REP'
      AND user_tab_cols.column_name = 'PRMT_IDENT'
      AND user_tab_cols.data_type = 'CHAR';

       /* The column is already correct in schema, bypass modification */
    DBMS_OUTPUT.PUT_LINE( 'The column PRMT_IDENT on ICS_SW_INDST_ANNUL_REP is already correct, schema alteration bypassed!');
    
EXCEPTION
   
    WHEN NO_DATA_FOUND THEN  
     
    BEGIN

      --  Trim any existing data
      UPDATE ICS_SW_INDST_ANNUL_REP
      SET PRMT_IDENT = SUBSTR(PRMT_IDENT,1,9);  
     
      --  Modify existing column to correct data type
      v_sql_statement := 'ALTER TABLE ICS_SW_INDST_ANNUL_REP MODIFY (PRMT_IDENT CHAR(9))';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The column PRMT_IDENT on the table ICS_SW_INDST_ANNUL_REP was modified!');
      
     END; 

END;
/


/********************************************************************************************************  

    CHANGE #12.a
    Drop column FEDR_FAC_IND from table ICS_FRML_ENFRC_ACTN.

*********************************************************************************************************/

DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  /*  Check to see if FEDR_FAC_IND column exists on the database table ICS_FRML_ENFRC_ACTN  */
   SELECT 1
     INTO v_object_ind
     FROM user_tables
     JOIN user_tab_cols
       ON user_tab_cols.table_name = user_tables.table_name
    WHERE user_tables.table_name = 'ICS_FRML_ENFRC_ACTN'
      AND user_tab_cols.column_name = 'FEDR_FAC_IND';
   
    BEGIN
       
      --  Drop column 
      v_sql_statement := 'ALTER TABLE ICS_FRML_ENFRC_ACTN DROP (FEDR_FAC_IND)';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The column FEDR_FAC_IND was dropped from the table ICS_FRML_ENFRC_ACTN!');
      
     END;  

EXCEPTION

  WHEN NO_DATA_FOUND THEN  

   /* The column does not exist in schema, bypass operation */
    DBMS_OUTPUT.PUT_LINE( 'The column FEDR_FAC_IND does not exist on ICS_FRML_ENFRC_ACTN, schema alteration bypassed!');  

END;
/


/********************************************************************************************************  

    CHANGE #12.b
    Drop column FEDR_FAC_IND_CMNT from table ICS_FRML_ENFRC_ACTN.

*********************************************************************************************************/

DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  /*  Check to see if FEDR_FAC_IND_CMNT column exists on the database table ICS_FRML_ENFRC_ACTN  */
   SELECT 1
     INTO v_object_ind
     FROM user_tables
     JOIN user_tab_cols
       ON user_tab_cols.table_name = user_tables.table_name
    WHERE user_tables.table_name = 'ICS_FRML_ENFRC_ACTN'
      AND user_tab_cols.column_name = 'FEDR_FAC_IND_CMNT';
   
    BEGIN
       
      --  Drop column 
      v_sql_statement := 'ALTER TABLE ICS_FRML_ENFRC_ACTN DROP (FEDR_FAC_IND_CMNT)';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The column FEDR_FAC_IND_CMNT was dropped from the table ICS_FRML_ENFRC_ACTN!');
      
     END;  

EXCEPTION

  WHEN NO_DATA_FOUND THEN  

   /* The column does not exist in schema, bypass operation */
    DBMS_OUTPUT.PUT_LINE( 'The column FEDR_FAC_IND_CMNT does not exist on ICS_FRML_ENFRC_ACTN, schema alteration bypassed!');  

END;
/


/********************************************************************************************************  

    CHANGE #12.c
    Drop column FEDR_FAC_IND from table ICS_INFRML_ENFRC_ACTN.

*********************************************************************************************************/

DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  /*  Check to see if FEDR_FAC_IND column exists on the database table ICS_INFRML_ENFRC_ACTN  */
   SELECT 1
     INTO v_object_ind
     FROM user_tables
     JOIN user_tab_cols
       ON user_tab_cols.table_name = user_tables.table_name
    WHERE user_tables.table_name = 'ICS_INFRML_ENFRC_ACTN'
      AND user_tab_cols.column_name = 'FEDR_FAC_IND';
   
    BEGIN
       
      --  Drop column 
      v_sql_statement := 'ALTER TABLE ICS_INFRML_ENFRC_ACTN DROP (FEDR_FAC_IND)';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The column FEDR_FAC_IND was dropped from the table ICS_INFRML_ENFRC_ACTN!');
      
     END;  

EXCEPTION

  WHEN NO_DATA_FOUND THEN  

   /* The column does not exist in schema, bypass operation */
    DBMS_OUTPUT.PUT_LINE( 'The column FEDR_FAC_IND does not exist on ICS_INFRML_ENFRC_ACTN, schema alteration bypassed!');  

END;
/


/********************************************************************************************************  

    CHANGE #12.d
    Drop column FEDR_FAC_IND_CMNT from table ICS_INFRML_ENFRC_ACTN.

*********************************************************************************************************/

DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  /*  Check to see if FEDR_FAC_IND_CMNT column exists on the database table ICS_INFRML_ENFRC_ACTN  */
   SELECT 1
     INTO v_object_ind
     FROM user_tables
     JOIN user_tab_cols
       ON user_tab_cols.table_name = user_tables.table_name
    WHERE user_tables.table_name = 'ICS_INFRML_ENFRC_ACTN'
      AND user_tab_cols.column_name = 'FEDR_FAC_IND_CMNT';
   
    BEGIN
       
      --  Drop column 
      v_sql_statement := 'ALTER TABLE ICS_INFRML_ENFRC_ACTN DROP (FEDR_FAC_IND_CMNT)';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The column FEDR_FAC_IND_CMNT was dropped from the table ICS_INFRML_ENFRC_ACTN!');
      
     END;  

EXCEPTION

  WHEN NO_DATA_FOUND THEN  

   /* The column does not exist in schema, bypass operation */
    DBMS_OUTPUT.PUT_LINE( 'The column FEDR_FAC_IND_CMNT does not exist on ICS_INFRML_ENFRC_ACTN, schema alteration bypassed!');  

END;
/


/********************************************************************************************************  

    CHANGE #14a
    Add column BASE_TABLE_NAME to table ICS_PAYLOAD.

*********************************************************************************************************/

DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  /*  Check to see if BASE_TABLE_NAME column exists on the database table ICS_PAYLOAD  */
   SELECT 1
     INTO v_object_ind
     FROM user_tables
     JOIN user_tab_cols
       ON user_tab_cols.table_name = user_tables.table_name
    WHERE user_tables.table_name = 'ICS_PAYLOAD'
      AND user_tab_cols.column_name = 'BASE_TABLE_NAME';
   
   /* The column already exists in schema, bypass creation */
    DBMS_OUTPUT.PUT_LINE( 'The column BASE_TABLE_NAME already existed on ICS_PAYLOAD, schema alteration bypassed!');

EXCEPTION

  WHEN NO_DATA_FOUND THEN  
  
    BEGIN
       
      --  Add new column 
      v_sql_statement := 'ALTER TABLE ICS_PAYLOAD ADD (BASE_TABLE_NAME VARCHAR2(30) NULL)';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The column BASE_TABLE_NAME was added to the table ICS_PAYLOAD!');
      
     END;  

END;
/

COMMENT ON COLUMN "ICS_PAYLOAD"."BASE_TABLE_NAME" IS 'Name of the root node table for reference within staging db';

UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_CAFO_ANNUL_REP' WHERE ICS_PAYLOAD_ID = 'CAFOAnnualReport';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_DSCH_MON_REP' WHERE ICS_PAYLOAD_ID = 'DischargeMonitoringReport';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_CMPL_MON' WHERE ICS_PAYLOAD_ID = 'ComplianceMonitoring';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_CAFO_PRMT' WHERE ICS_PAYLOAD_ID = 'CAFOPermit';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_SW_CNST_PRMT' WHERE ICS_PAYLOAD_ID = 'SWConstructionPermit';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_UNPRMT_FAC' WHERE ICS_PAYLOAD_ID = 'UnpermittedFacility';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_PRETR_PRMT' WHERE ICS_PAYLOAD_ID = 'PretreatmentPermit';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_NARR_COND_SCHD' WHERE ICS_PAYLOAD_ID = 'NarrativeConditionSchedule';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_POTW_PRMT' WHERE ICS_PAYLOAD_ID = 'POTWPermit';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_PRMT_TERM' WHERE ICS_PAYLOAD_ID = 'PermitTermination';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_PRMT_TRACK_EVT' WHERE ICS_PAYLOAD_ID = 'PermitTrackingEvent';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_HIST_PRMT_SCHD_EVTS' WHERE ICS_PAYLOAD_ID = 'HistoricalPermitScheduleEvents';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_PARAM_LMTS' WHERE ICS_PAYLOAD_ID = 'ParameterLimits';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_SWMS_4_SMALL_PRMT' WHERE ICS_PAYLOAD_ID = 'SWMS4SmallPermit';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_SWMS_4_LARGE_PRMT' WHERE ICS_PAYLOAD_ID = 'SWMS4LargePermit';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_LMTS' WHERE ICS_PAYLOAD_ID = 'Limits';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_MASTER_GNRL_PRMT' WHERE ICS_PAYLOAD_ID = 'MasterGeneralPermit';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_GNRL_PRMT' WHERE ICS_PAYLOAD_ID = 'GeneralPermit';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_LMT_SET' WHERE ICS_PAYLOAD_ID = 'LimitSet';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_SW_INDST_PRMT' WHERE ICS_PAYLOAD_ID = 'SWIndustrialPermit';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_BS_PRMT' WHERE ICS_PAYLOAD_ID = 'BiosolidsPermit';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_PRMT_FEATR' WHERE ICS_PAYLOAD_ID = 'PermittedFeature';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_BASIC_PRMT' WHERE ICS_PAYLOAD_ID = 'BasicPermit';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_PRMT_REISSU' WHERE ICS_PAYLOAD_ID = 'PermitReissuance';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_CSO_PRMT' WHERE ICS_PAYLOAD_ID = 'CSOPermit';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_CMPL_SCHD' WHERE ICS_PAYLOAD_ID = 'ComplianceSchedule';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_SNGL_EVT_VIOL' WHERE ICS_PAYLOAD_ID = 'SingleEventViolation';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_SCHD_EVT_VIOL' WHERE ICS_PAYLOAD_ID = 'ScheduleEventViolation';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_INFRML_ENFRC_ACTN' WHERE ICS_PAYLOAD_ID = 'InformalEnforcementAction';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_FRML_ENFRC_ACTN' WHERE ICS_PAYLOAD_ID = 'FormalEnforcementAction';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_FINAL_ORDER_VIOL_LNK' WHERE ICS_PAYLOAD_ID = 'FinalOrderViolationLinkage';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_DMR_PROG_REP_LNK' WHERE ICS_PAYLOAD_ID = 'DMRProgramReportLinkage';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_CMPL_MON_LNK' WHERE ICS_PAYLOAD_ID = 'ComplianceMonitoringLinkage';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_ENFRC_ACTN_VIOL_LNK' WHERE ICS_PAYLOAD_ID = 'EnforcementActionViolationLinkage';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_DMR_VIOL' WHERE ICS_PAYLOAD_ID = 'DMRViolation';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_BS_PROG_REP' WHERE ICS_PAYLOAD_ID = 'BiosolidsProgramReport';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_EFFLU_TRADE_PRTNER' WHERE ICS_PAYLOAD_ID = 'EffluentTradePartner';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_ENFRC_ACTN_MILESTONE' WHERE ICS_PAYLOAD_ID = 'EnforcementActionMilestone';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_SW_EVT_REP' WHERE ICS_PAYLOAD_ID = 'SWEventReport';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_SSO_EVT_REP' WHERE ICS_PAYLOAD_ID = 'SSOEventReport';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_SSO_ANNUL_REP' WHERE ICS_PAYLOAD_ID = 'SSOAnnualReport';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_SWMS_4_PROG_REP' WHERE ICS_PAYLOAD_ID = 'SWMS4ProgramReport';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_SSO_MONTHLY_EVT_REP' WHERE ICS_PAYLOAD_ID = 'SSOMonthlyEventReport';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_CSO_EVT_REP' WHERE ICS_PAYLOAD_ID = 'CSOEventReport';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_LOC_LMTS_PROG_REP' WHERE ICS_PAYLOAD_ID = 'LocalLimitsProgramReport';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_PRETR_PERF_SUMM' WHERE ICS_PAYLOAD_ID = 'PretreatmentPerformanceSummary';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_SW_INDST_ANNUL_REP' WHERE ICS_PAYLOAD_ID = 'SWIndustrialAnnualReport';


/********************************************************************************************************  

    CHANGE #14b
    Add column ETL_PROCEDURE to table ICS_PAYLOAD.

*********************************************************************************************************/

DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  /*  Check to see if ETL_PROCEDURE column exists on the database table ICS_PAYLOAD  */
   SELECT 1
     INTO v_object_ind
     FROM user_tables
     JOIN user_tab_cols
       ON user_tab_cols.table_name = user_tables.table_name
    WHERE user_tables.table_name = 'ICS_PAYLOAD'
      AND user_tab_cols.column_name = 'ETL_PROCEDURE';
   
   /* The column already exists in schema, bypass creation */
    DBMS_OUTPUT.PUT_LINE( 'The column ETL_PROCEDURE already existed on ICS_PAYLOAD, schema alteration bypassed!');

EXCEPTION

  WHEN NO_DATA_FOUND THEN  
  
    BEGIN
       
      --  Add new column 
      v_sql_statement := 'ALTER TABLE ICS_PAYLOAD ADD (ETL_PROCEDURE VARCHAR2(30) NULL)';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The column ETL_PROCEDURE was added to the table ICS_PAYLOAD!');
      
     END;  

END;
/

COMMENT ON COLUMN "ICS_PAYLOAD"."ETL_PROCEDURE" IS 'Optional Name of procedure to load data module within staging db';


