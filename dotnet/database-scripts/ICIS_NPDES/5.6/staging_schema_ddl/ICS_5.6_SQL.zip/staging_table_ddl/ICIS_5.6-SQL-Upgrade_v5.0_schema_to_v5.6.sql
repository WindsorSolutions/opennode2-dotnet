/*
Copyright (c) 2012, The Environmental Council of the States (ECOS)
All rights reserved.
 
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
 
 * Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
 * Neither the name of the ECOS nor the names of its contributors may
   be used to endorse or promote products derived from this software
   without specific prior written permission.
 
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/
/*************************************************************************************************
** ObjectName: ICIS_5.6-SQL-Upgrade_v5.0_schema_to_v5.6.sql
**
** Author: Windsor Solutions, Inc.
**
** Company Name: Windsor Solutions, Inc.
**
** Description:  This script will update an existing ICIS 5.0 database to support the ICIS 5.6
**               exchange.  This script can be run multiple times without issue.
**
** Revision History:
** ------------------------------------------------------------------------------------------------
** Date          Name        Description
** ------------------------------------------------------------------------------------------------
** 09/12/2016    Windsor     Created
** 09/26/2016    Windsor     Updated following internal testing.
** 09/28/2016    CTyler      Added BASE_TABLE_NAME and ETL_PROCEDURE utility columns to ICS_PAYLOAD
** 10/13/2016    BRensmith   Fix Typo in ALTER TABLE ICS_PAYLOAD ADD ETL_PROCEDURE at end
**
*************************************************************************************************/


/*  CHANGE #1
    
    Add:  ComplianceMonitoringActivityTypeCode 

*/
IF NOT EXISTS (SELECT columns.name
                 FROM sys.columns
                WHERE object_name(columns.object_id) = 'ICS_CMPL_MON'
                  AND columns.name = 'CMPL_MON_ACTY_TYPE_CODE')
BEGIN

  ALTER TABLE ICS_CMPL_MON ADD CMPL_MON_ACTY_TYPE_CODE [VARCHAR](03) NULL;

END;
GO


/*  CHANGE #2
    
    CREATE TABLE:  ICIS Program Deficiency Type 

*/
IF NOT EXISTS (SELECT tables.name
                 FROM sys.tables
                WHERE tables.name = 'ICS_PROG_DEFCY_TYPE')
  BEGIN

    --  Create ICS_PROG_DEFCY_TYPE, new child table of compliance monitoring
    CREATE TABLE [ICS_PROG_DEFCY_TYPE](
	    [ICS_PROG_DEFCY_TYPE_ID] [varchar](36) NOT NULL,
	    [ICS_CMPL_MON_ID] [varchar](36) NOT NULL,
	    [PROG_DEFCY_TYPE_CODE] [varchar](3) NOT NULL,
     CONSTRAINT [PK_PROG_DEFCY_TYPE] PRIMARY KEY CLUSTERED 
    (
	    [ICS_PROG_DEFCY_TYPE_ID] ASC
    )WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
    ) ON [PRIMARY];

    ALTER TABLE [ICS_PROG_DEFCY_TYPE] ADD DATA_HASH [VARCHAR](100);

    CREATE NONCLUSTERED INDEX [IX_PROG_DEFCY_TYPE_ICS_CMPL_MON_ID] ON [ICS_PROG_DEFCY_TYPE]
    (
	    [ICS_CMPL_MON_ID] ASC
    ) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY];

    ALTER TABLE [ICS_PROG_DEFCY_TYPE]  WITH CHECK ADD  CONSTRAINT [FK_PROG_DEFCY_TYPE_CMPL_MON] FOREIGN KEY([ICS_CMPL_MON_ID])
    REFERENCES [ICS_CMPL_MON] ([ICS_CMPL_MON_ID]) ON DELETE CASCADE;

END;
GO


/*  CHANGE #3
    
    CREATE TABLE:  ICIS Supplemental Environmental Project, a child of FINAL_ORDER 

*/
IF NOT EXISTS (SELECT tables.name
                 FROM sys.tables
                WHERE tables.name = 'ICS_SEP')
  BEGIN

    CREATE TABLE [ICS_SEP](
	    [ICS_SEP_ID] [varchar](36) NOT NULL,
	    [ICS_FINAL_ORDER_ID] [varchar](36) NOT NULL,
	    [SEP_IDENT] INTEGER NOT NULL,
      [SEP_DESC] [varchar](4000) NULL,
      [SEP_PNLTY_ASSESSMENT_AMT] DECIMAL(17,2) NULL,
     CONSTRAINT [PK_SEP] PRIMARY KEY CLUSTERED 
    (
	    [ICS_SEP_ID] ASC
    )WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
    ) ON [PRIMARY];

    ALTER TABLE [ICS_SEP] ADD DATA_HASH [VARCHAR](100);

    CREATE NONCLUSTERED INDEX [IX_SEP_ICS_FINAL_ORDER_ID] ON [ICS_SEP]
    (
	    [ICS_FINAL_ORDER_ID] ASC
    )WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY];
   
    SET ANSI_PADDING ON;

    ALTER TABLE [ICS_SEP]  WITH CHECK ADD  CONSTRAINT [FK_SEP_FINAL_ORDER] FOREIGN KEY([ICS_FINAL_ORDER_ID])
    REFERENCES [ICS_FINAL_ORDER] ([ICS_FINAL_ORDER_ID])
    ON DELETE CASCADE;

END;
GO


/*  CHANGE #4
    
    Alter Table:  ICS_LMT
    Add Column:   LMT_MOD_TYPE_STAY_REASON_TXT
    --Add after LimitModificationEffectiveDate in baseline script

*/
IF NOT EXISTS (SELECT columns.name
                 FROM sys.columns
                WHERE object_name(columns.object_id) = 'ICS_LMT'
                  AND columns.name = 'LMT_MOD_TYPE_STAY_REASON_TXT')
BEGIN

	ALTER TABLE ICS_LMT ADD LMT_MOD_TYPE_STAY_REASON_TXT [varchar](500) NULL;

END;
GO


/*  CHANGE #5.a
    
    Alter Table:  ICS_BASIC_PRMT
    Add Columns:  MAJOR_MINOR_STAT_IND
                  MAJOR_MINOR_STAT_START_DATE

    --  Add after MajorMinorRatingCode in baseline script

*/
IF NOT EXISTS (SELECT columns.name
                 FROM sys.columns
                WHERE object_name(columns.object_id) = 'ICS_BASIC_PRMT'
                  AND columns.name = 'MAJOR_MINOR_STAT_IND')
BEGIN

	ALTER TABLE ICS_BASIC_PRMT ADD MAJOR_MINOR_STAT_IND [char](1) NULL;
	ALTER TABLE ICS_BASIC_PRMT ADD MAJOR_MINOR_STAT_START_DATE DATETIME NULL;

END;
GO


/*  CHANGE #5.b
    
    Alter Table:  ICS_GNRL_PRMT
    Add Columns:  MAJOR_MINOR_STAT_IND
                  MAJOR_MINOR_STAT_START_DATE

    --  Add after MajorMinorRatingCode in baseline script

*/
IF NOT EXISTS (SELECT columns.name
                 FROM sys.columns
                WHERE object_name(columns.object_id) = 'ICS_GNRL_PRMT'
                  AND columns.name = 'MAJOR_MINOR_STAT_IND')
BEGIN

	ALTER TABLE ICS_GNRL_PRMT ADD MAJOR_MINOR_STAT_IND [char](1) NULL;
	ALTER TABLE ICS_GNRL_PRMT ADD MAJOR_MINOR_STAT_START_DATE DATETIME NULL;

END;
GO


/*  CHANGE #6.a
    
    Alter Table:  ICS_BASIC_PRMT
    Add Columns:  DMR_NON_RCPT_STAT_IND
                  DMR_NON_RCPT_STAT_START_DATE

*/
IF NOT EXISTS (SELECT columns.name
                 FROM sys.columns
                WHERE object_name(columns.object_id) = 'ICS_BASIC_PRMT'
                  AND columns.name = 'DMR_NON_RCPT_STAT_IND')
BEGIN

  ALTER TABLE ICS_BASIC_PRMT ADD DMR_NON_RCPT_STAT_IND [char](1) NULL;
	ALTER TABLE ICS_BASIC_PRMT ADD DMR_NON_RCPT_STAT_START_DATE DATETIME NULL;

END;
GO


/*  CHANGE #6.b
    
    Alter Table:  ICS_GNRL_PRMT
    Add Columns:  DMR_NON_RCPT_STAT_IND
                  DMR_NON_RCPT_STAT_START_DATE

*/
IF NOT EXISTS (SELECT columns.name
                 FROM sys.columns
                WHERE object_name(columns.object_id) = 'ICS_GNRL_PRMT'
                  AND columns.name = 'DMR_NON_RCPT_STAT_IND')
BEGIN
	
  ALTER TABLE ICS_GNRL_PRMT ADD DMR_NON_RCPT_STAT_IND [char](1) NULL;
	ALTER TABLE ICS_GNRL_PRMT ADD DMR_NON_RCPT_STAT_START_DATE DATETIME NULL;

END;


/*  CHANGE #7
    
    CREATE TABLE:  ICIS Reportable NonCompliance Status, a child of Basic Permit and
                   General Permit. 

*/
IF NOT EXISTS (SELECT tables.name
                 FROM sys.tables
                WHERE tables.name = 'ICS_REP_NON_CMPL_STAT')
  BEGIN

    CREATE TABLE [dbo].[ICS_REP_NON_CMPL_STAT](
	    [ICS_REP_NON_CMPL_STAT_ID] [varchar](36) NOT NULL,
	    [ICS_BASIC_PRMT_ID] [varchar](36) NULL,
	    [ICS_GNRL_PRMT_ID] [varchar](36) NULL,
	    [REP_NON_CMPL_STAT_CODE_YEAR] [int] NULL,
	    [REP_NON_CMPL_STAT_CODE_QUARTER] [int] NULL,
	    [REP_NON_CMPL_MANUAL_STAT_CODE] [varchar](3) NULL,

     CONSTRAINT [PK_REP_NON_CMPL_STAT] PRIMARY KEY CLUSTERED 
    (
	    [ICS_REP_NON_CMPL_STAT_ID] ASC
    )WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
    ) ON [PRIMARY];

    CREATE NONCLUSTERED INDEX [IX_REP_NON_CMP_STA_IC_BS_PR_ID] ON [dbo].[ICS_REP_NON_CMPL_STAT]
    (
	    [ICS_BASIC_PRMT_ID] ASC
    ) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY];

    CREATE NONCLUSTERED INDEX [IX_REP_NON_CMP_STA_IC_GN_PR_ID] ON [dbo].[ICS_REP_NON_CMPL_STAT]
    (
	    [ICS_GNRL_PRMT_ID] ASC
    ) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

    ALTER TABLE [dbo].[ICS_REP_NON_CMPL_STAT]  WITH CHECK ADD  CONSTRAINT [FK_REP_NON_CMPL_STAT_BSIC_PRMT] FOREIGN KEY([ICS_BASIC_PRMT_ID])
    REFERENCES [dbo].[ICS_BASIC_PRMT] ([ICS_BASIC_PRMT_ID]);

    ALTER TABLE [dbo].[ICS_REP_NON_CMPL_STAT] CHECK CONSTRAINT [FK_REP_NON_CMPL_STAT_BSIC_PRMT];

    ALTER TABLE [dbo].[ICS_REP_NON_CMPL_STAT]  WITH CHECK ADD  CONSTRAINT [FK_REP_NON_CMPL_STAT_GNRL_PRMT] FOREIGN KEY([ICS_GNRL_PRMT_ID])
    REFERENCES [dbo].[ICS_GNRL_PRMT] ([ICS_GNRL_PRMT_ID]);

    ALTER TABLE [dbo].[ICS_REP_NON_CMPL_STAT] CHECK CONSTRAINT [FK_REP_NON_CMPL_STAT_GNRL_PRMT];

    ALTER TABLE [dbo].[ICS_REP_NON_CMPL_STAT] ADD DATA_HASH [VARCHAR](100);

END;
GO


/*  CHANGE #8
    
    Alter Table:  ICS_SNGL_EVT_VIOL
    Drop Column:  SNGL_EVT_VIOL_START_DATE


*/
IF EXISTS (SELECT columns.name
             FROM sys.columns
            WHERE object_name(columns.object_id) = 'ICS_SNGL_EVT_VIOL'
              AND columns.name = 'SNGL_EVT_VIOL_START_DATE')
BEGIN

	ALTER TABLE [ICS_SNGL_EVT_VIOL] DROP COLUMN [SNGL_EVT_VIOL_START_DATE];

END;
GO


/*  CHANGE #9.a
    
    Alter Table:  ICS_PRMT_COMP_TYPE
    Add Column:  ICS_UNPRMT_FAC_ID

--PermitComponentTypeCode as a child of ICS_UNPRMT_FAC, new FK to existing table
*/
IF NOT EXISTS (SELECT columns.name
             FROM sys.columns
            WHERE object_name(columns.object_id) = 'ICS_PRMT_COMP_TYPE'
              AND columns.name = 'ICS_UNPRMT_FAC_ID')
BEGIN

  --  Add new column
	ALTER TABLE [ICS_PRMT_COMP_TYPE] ADD [ICS_UNPRMT_FAC_ID] VARCHAR(36) NULL;

  --  Create foreign key on new column
  ALTER TABLE [ICS_PRMT_COMP_TYPE]  WITH CHECK ADD  CONSTRAINT [FK_PRMT_COMP_TYPE_UNPRMT_FAC] FOREIGN KEY(ICS_UNPRMT_FAC_ID)
  REFERENCES [ICS_UNPRMT_FAC] (ICS_UNPRMT_FAC_ID);

  --  Index new foreign key column
  CREATE INDEX IX_PRMT_COMP_TYPE_UNPRMT_FAC ON ICS_PRMT_COMP_TYPE(ICS_UNPRMT_FAC_ID);

END;
GO


/*  CHANGE #9.b
    
    Alter Table:  ICS_PRMT_COMP_TYPE
    Alter Column:  ICS_MASTER_GNRL_PRMT_ID

*/
IF NOT EXISTS (SELECT columns.*
                 FROM sys.columns
                WHERE object_name(columns.object_id) = 'ICS_PRMT_COMP_TYPE'
                  AND columns.name = 'ICS_MASTER_GNRL_PRMT_ID'
                  AND columns.is_nullable = 1)
BEGIN

	--  Alter column ICS_MASTER_GNRL_PRMT_ID to allow NULL values.
	ALTER TABLE [ICS_PRMT_COMP_TYPE] ALTER COLUMN [ICS_MASTER_GNRL_PRMT_ID] VARCHAR(36) NULL;

END;
GO


/*  CHANGE #10.a
    
    Alter Table:  ICS_ADDR
    Drop Column:  INDST_ACTY_SIZE

*/
IF EXISTS (SELECT columns.*
                 FROM sys.columns
                WHERE object_name(columns.object_id) = 'ICS_ADDR'
                  AND columns.name = 'INDST_ACTY_SIZE')
BEGIN

  --  Drop column INDST_ACTY_SIZE, if exists.
	ALTER TABLE [ICS_ADDR] DROP COLUMN [INDST_ACTY_SIZE];

END;

	
/*  CHANGE #10.b
    
    Alter Table:  ICS_SW_INDST_PRMT
    Alter Column:  INDST_ACTY_SIZE

*/
IF NOT EXISTS (SELECT columns.*
                 FROM sys.columns
                 JOIN sys.types
                   ON types.user_type_id = columns.user_type_id
                WHERE object_name(columns.object_id) = 'ICS_SW_INDST_PRMT'
                  AND columns.name = 'INDST_ACTY_SIZE'
                  AND types.name = 'decimal'
                  and columns.precision = 10
                  and columns.scale = 2)
BEGIN

  --  Alter column INDST_ACTY_SIZE data type
	ALTER TABLE [ICS_SW_INDST_PRMT] ALTER COLUMN [INDST_ACTY_SIZE] DECIMAL(10,2) NULL;

END;
GO
	

/*  CHANGE #10.c
    
    Alter Table:  ICS_SWMS_4_LARGE_PRMT
    Alter Column:  INDST_ACTY_SIZE

*/
IF NOT EXISTS (SELECT columns.name, types.name
                 FROM sys.columns
                 JOIN sys.types
                   ON types.user_type_id = columns.user_type_id
                WHERE object_name(columns.object_id) = 'ICS_SWMS_4_LARGE_PRMT'
                  AND columns.name = 'INDST_ACTY_SIZE'
                  AND types.name = 'decimal'
                  AND columns.precision = 10
                  AND columns.scale = 2)
BEGIN

  --  Alter column ICS_SWMS_4_LARGE_PRMT data type
	ALTER TABLE [ICS_SWMS_4_LARGE_PRMT] ALTER COLUMN [INDST_ACTY_SIZE] DECIMAL(10,2) NULL;

END;
GO
	

/*  CHANGE #10.d
    
    Alter Table:  ICS_SWMS_4_SMALL_PRMT
    Alter Column:  INDST_ACTY_SIZE

*/
IF NOT EXISTS (SELECT columns.name, types.name
                 FROM sys.columns
                 JOIN sys.types
                   ON types.user_type_id = columns.user_type_id
                WHERE object_name(columns.object_id) = 'ICS_SWMS_4_SMALL_PRMT'
                  AND columns.name = 'INDST_ACTY_SIZE'
                  AND types.name = 'decimal'
                  AND columns.precision = 10
                  AND columns.scale = 2)
BEGIN

  --  Alter column ICS_SWMS_4_SMALL_PRMT data type
	ALTER TABLE [ICS_SWMS_4_SMALL_PRMT] ALTER COLUMN [INDST_ACTY_SIZE] DECIMAL(10,2) NULL;

END;
GO

	
/*  CHANGE #10.e
    
    Alter Table:  ICS_SW_CNST_PRMT
    Add Column:  INDST_ACTY_SIZE

*/
IF NOT EXISTS (SELECT columns.name, types.name
                 FROM sys.columns
                 JOIN sys.types
                   ON types.user_type_id = columns.user_type_id
                WHERE object_name(columns.object_id) = 'ICS_SW_CNST_PRMT'
                  AND columns.name = 'INDST_ACTY_SIZE')
BEGIN

  --  Alter column ICS_SWMS_4_SMALL_PRMT data type
	ALTER TABLE [ICS_SW_CNST_PRMT] ADD [INDST_ACTY_SIZE] DECIMAL(10,2) NULL;

END;
GO
	

/*  CHANGE #11.a
    
    Alter Table:  ICS_BASIC_PRMT
    Alter Columns:  TTL_APPL_DSGN_FLOW_NUM 
                    TTL_APPL_AVER_FLOW_NUM

*/
IF NOT EXISTS (SELECT columns.name, types.name, columns.*
                 FROM sys.columns
                 JOIN sys.types
                   ON types.user_type_id = columns.user_type_id
                WHERE object_name(columns.object_id) = 'ICS_BASIC_PRMT'
                  AND columns.name = 'TTL_APPL_DSGN_FLOW_NUM'
                  AND types.name = 'decimal'
                  and columns.precision = 15
                  and columns.scale = 7)
BEGIN

  --  Alter column ICS_SWMS_4_SMALL_PRMT data type
	ALTER TABLE [ICS_BASIC_PRMT] ALTER COLUMN [TTL_APPL_DSGN_FLOW_NUM] DECIMAL(15,7) NULL;
  ALTER TABLE [ICS_BASIC_PRMT] ALTER COLUMN [TTL_APPL_AVER_FLOW_NUM] DECIMAL(15,7) NULL;

END;
GO


/*  CHANGE #11.b
    
    Alter Table:  ICS_GNRL_PRMT
    Alter Columns:  TTL_APPL_DSGN_FLOW_NUM 
                    TTL_APPL_AVER_FLOW_NUM

*/
IF NOT EXISTS (SELECT columns.name, types.name, columns.*
                 FROM sys.columns
                 JOIN sys.types
                   ON types.user_type_id = columns.user_type_id
                WHERE object_name(columns.object_id) = 'ICS_GNRL_PRMT'
                  AND columns.name = 'TTL_APPL_DSGN_FLOW_NUM'
                  AND types.name = 'decimal'
                  and columns.precision = 15
                  and columns.scale = 7)
BEGIN

  --  Alter column ICS_SWMS_4_SMALL_PRMT data type
	ALTER TABLE [ICS_GNRL_PRMT] ALTER COLUMN [TTL_APPL_DSGN_FLOW_NUM] DECIMAL(15,7) NULL;
	ALTER TABLE [ICS_GNRL_PRMT] ALTER COLUMN [TTL_APPL_AVER_FLOW_NUM] DECIMAL(15,7) NULL;

END;
GO


/*  CHANGE #12
    
    Alter Table:  ICS_SW_INDST_ANNUL_REP
    Alter Columns:  PRMT_IDENT

    WARNING  ---->   Potential data alteration!!!

*/
IF NOT EXISTS (SELECT columns.name, types.name, columns.*
                 FROM sys.columns
                 JOIN sys.types
                   ON types.user_type_id = columns.user_type_id
                WHERE object_name(columns.object_id) = 'ICS_SW_INDST_ANNUL_REP'
                  AND columns.name = 'PRMT_IDENT'
                  AND types.name = 'char'
                  and columns.max_length = 9)
BEGIN

  /*

    WARNING  ---->   Potential data alteration!!!

  */

  --  Drop index to allow for datatype alteration.
  DROP INDEX [IX_SW_IN_AN_RE_PR_ID_IN_SW_AN] ON [dbo].[ICS_SW_INDST_ANNUL_REP];

  --  Trim permit identifiers to allow for smaller 9 characters vs original 50
  UPDATE dbo.ICS_SW_INDST_ANNUL_REP
     SET ICS_SW_INDST_ANNUL_REP.PRMT_IDENT = SUBSTRING(ICS_SW_INDST_ANNUL_REP.PRMT_IDENT,1,9);

  --  Alter column ICS_SWMS_4_SMALL_PRMT data type
	ALTER TABLE [ICS_SW_INDST_ANNUL_REP] ALTER COLUMN [PRMT_IDENT] CHAR(9) NOT NULL;

  CREATE UNIQUE NONCLUSTERED INDEX [IX_SW_IN_AN_RE_PR_ID_IN_SW_AN] ON [dbo].[ICS_SW_INDST_ANNUL_REP]
  ( [PRMT_IDENT] ASC
  , [INDST_SW_ANNUL_REP_RCVD_DATE] ASC);

END;
GO

/*  CHANGE #13.a
    
    Alter Table:  ICS_FRML_ENFRC_ACTN
    Drop Column:  FEDR_FAC_IND

*/
IF EXISTS (SELECT columns.*
                 FROM sys.columns
                WHERE object_name(columns.object_id) = 'ICS_FRML_ENFRC_ACTN'
                  AND columns.name = 'FEDR_FAC_IND')
BEGIN

  --  Drop column INDST_ACTY_SIZE, if exists.
	ALTER TABLE ICS_FRML_ENFRC_ACTN DROP COLUMN FEDR_FAC_IND;

END;
GO

/*  CHANGE #13.b
    
    Alter Table:  ICS_FRML_ENFRC_ACTN
    Drop Column:  FEDR_FAC_IND_CMNT

*/
IF EXISTS (SELECT columns.*
                 FROM sys.columns
                WHERE object_name(columns.object_id) = 'ICS_FRML_ENFRC_ACTN'
                  AND columns.name = 'FEDR_FAC_IND_CMNT')
BEGIN

  --  Drop column INDST_ACTY_SIZE, if exists.
	ALTER TABLE ICS_FRML_ENFRC_ACTN DROP COLUMN FEDR_FAC_IND_CMNT;

END;
GO

/*  CHANGE #13.c
    
    Alter Table:  ICS_INFRML_ENFRC_ACTN
    Drop Column:  FEDR_FAC_IND

*/
IF EXISTS (SELECT columns.*
                 FROM sys.columns
                WHERE object_name(columns.object_id) = 'ICS_INFRML_ENFRC_ACTN'
                  AND columns.name = 'FEDR_FAC_IND')
BEGIN

  --  Drop column INDST_ACTY_SIZE, if exists.
	ALTER TABLE ICS_INFRML_ENFRC_ACTN DROP COLUMN FEDR_FAC_IND;

END;
GO

/*  CHANGE #13.d
    
    Alter Table:  ICS_INFRML_ENFRC_ACTN
    Drop Column:  FEDR_FAC_IND_CMNT

*/
IF EXISTS (SELECT columns.*
                 FROM sys.columns
                WHERE object_name(columns.object_id) = 'ICS_INFRML_ENFRC_ACTN'
                  AND columns.name = 'FEDR_FAC_IND_CMNT')
BEGIN

  --  Drop column INDST_ACTY_SIZE, if exists.
	ALTER TABLE ICS_INFRML_ENFRC_ACTN DROP COLUMN FEDR_FAC_IND_CMNT;

END;
GO

/*  CHANGE #14a
    
    Add column BASE_TABLE_NAME to table ICS_PAYLOAD.

*/
IF NOT EXISTS (SELECT columns.name
                 FROM sys.columns
                WHERE object_name(columns.object_id) = 'ICS_PAYLOAD'
                  AND columns.name = 'BASE_TABLE_NAME')
BEGIN

  ALTER TABLE ICS_PAYLOAD ADD BASE_TABLE_NAME [VARCHAR](30) NULL;

END;
GO

UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_CAFO_ANNUL_REP' WHERE ICS_PAYLOAD_ID = 'CAFOAnnualReport';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_DSCH_MON_REP' WHERE ICS_PAYLOAD_ID = 'DischargeMonitoringReport';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_CMPL_MON' WHERE ICS_PAYLOAD_ID = 'ComplianceMonitoring';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_CAFO_PRMT' WHERE ICS_PAYLOAD_ID = 'CAFOPermit';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_SW_CNST_PRMT' WHERE ICS_PAYLOAD_ID = 'SWConstructionPermit';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_UNPRMT_FAC' WHERE ICS_PAYLOAD_ID = 'UnpermittedFacility';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_PRETR_PRMT' WHERE ICS_PAYLOAD_ID = 'PretreatmentPermit';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_NARR_COND_SCHD' WHERE ICS_PAYLOAD_ID = 'NarrativeConditionSchedule';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_POTW_PRMT' WHERE ICS_PAYLOAD_ID = 'POTWPermit';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_PRMT_TERM' WHERE ICS_PAYLOAD_ID = 'PermitTermination';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_PRMT_TRACK_EVT' WHERE ICS_PAYLOAD_ID = 'PermitTrackingEvent';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_HIST_PRMT_SCHD_EVTS' WHERE ICS_PAYLOAD_ID = 'HistoricalPermitScheduleEvents';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_PARAM_LMTS' WHERE ICS_PAYLOAD_ID = 'ParameterLimits';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_SWMS_4_SMALL_PRMT' WHERE ICS_PAYLOAD_ID = 'SWMS4SmallPermit';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_SWMS_4_LARGE_PRMT' WHERE ICS_PAYLOAD_ID = 'SWMS4LargePermit';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_LMTS' WHERE ICS_PAYLOAD_ID = 'Limits';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_MASTER_GNRL_PRMT' WHERE ICS_PAYLOAD_ID = 'MasterGeneralPermit';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_GNRL_PRMT' WHERE ICS_PAYLOAD_ID = 'GeneralPermit';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_LMT_SET' WHERE ICS_PAYLOAD_ID = 'LimitSet';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_SW_INDST_PRMT' WHERE ICS_PAYLOAD_ID = 'SWIndustrialPermit';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_BS_PRMT' WHERE ICS_PAYLOAD_ID = 'BiosolidsPermit';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_PRMT_FEATR' WHERE ICS_PAYLOAD_ID = 'PermittedFeature';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_BASIC_PRMT' WHERE ICS_PAYLOAD_ID = 'BasicPermit';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_PRMT_REISSU' WHERE ICS_PAYLOAD_ID = 'PermitReissuance';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_CSO_PRMT' WHERE ICS_PAYLOAD_ID = 'CSOPermit';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_CMPL_SCHD' WHERE ICS_PAYLOAD_ID = 'ComplianceSchedule';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_SNGL_EVT_VIOL' WHERE ICS_PAYLOAD_ID = 'SingleEventViolation';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_SCHD_EVT_VIOL' WHERE ICS_PAYLOAD_ID = 'ScheduleEventViolation';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_INFRML_ENFRC_ACTN' WHERE ICS_PAYLOAD_ID = 'InformalEnforcementAction';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_FRML_ENFRC_ACTN' WHERE ICS_PAYLOAD_ID = 'FormalEnforcementAction';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_FINAL_ORDER_VIOL_LNK' WHERE ICS_PAYLOAD_ID = 'FinalOrderViolationLinkage';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_DMR_PROG_REP_LNK' WHERE ICS_PAYLOAD_ID = 'DMRProgramReportLinkage';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_CMPL_MON_LNK' WHERE ICS_PAYLOAD_ID = 'ComplianceMonitoringLinkage';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_ENFRC_ACTN_VIOL_LNK' WHERE ICS_PAYLOAD_ID = 'EnforcementActionViolationLinkage';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_DMR_VIOL' WHERE ICS_PAYLOAD_ID = 'DMRViolation';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_BS_PROG_REP' WHERE ICS_PAYLOAD_ID = 'BiosolidsProgramReport';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_EFFLU_TRADE_PRTNER' WHERE ICS_PAYLOAD_ID = 'EffluentTradePartner';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_ENFRC_ACTN_MILESTONE' WHERE ICS_PAYLOAD_ID = 'EnforcementActionMilestone';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_SW_EVT_REP' WHERE ICS_PAYLOAD_ID = 'SWEventReport';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_SSO_EVT_REP' WHERE ICS_PAYLOAD_ID = 'SSOEventReport';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_SSO_ANNUL_REP' WHERE ICS_PAYLOAD_ID = 'SSOAnnualReport';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_SWMS_4_PROG_REP' WHERE ICS_PAYLOAD_ID = 'SWMS4ProgramReport';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_SSO_MONTHLY_EVT_REP' WHERE ICS_PAYLOAD_ID = 'SSOMonthlyEventReport';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_CSO_EVT_REP' WHERE ICS_PAYLOAD_ID = 'CSOEventReport';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_LOC_LMTS_PROG_REP' WHERE ICS_PAYLOAD_ID = 'LocalLimitsProgramReport';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_PRETR_PERF_SUMM' WHERE ICS_PAYLOAD_ID = 'PretreatmentPerformanceSummary';
UPDATE ICS_PAYLOAD SET BASE_TABLE_NAME = 'ICS_SW_INDST_ANNUL_REP' WHERE ICS_PAYLOAD_ID = 'SWIndustrialAnnualReport';
GO

/*  CHANGE #14b
    
    Add column ETL_PROCEDURE to table ICS_PAYLOAD.

*/
IF EXISTS (SELECT columns.name
                 FROM sys.columns
                WHERE object_name(columns.object_id) = 'ICS_PAYLOAD'
                  AND columns.name = 'BETL_PROCEDURE')
BEGIN

  ALTER TABLE ICS_PAYLOAD DROP COLUMN BETL_PROCEDURE;

END;
GO

IF NOT EXISTS (SELECT columns.name
                 FROM sys.columns
                WHERE object_name(columns.object_id) = 'ICS_PAYLOAD'
                  AND columns.name = 'ETL_PROCEDURE')
BEGIN

  ALTER TABLE ICS_PAYLOAD ADD ETL_PROCEDURE [VARCHAR](128) NULL;

END;
GO