DROP PROCEDURE IF EXISTS ics_pat_ics_enfrc_actn_milestone;
CREATE PROCEDURE ics_pat_ics_enfrc_actn_milestone
   (IN  pi_transaction_id  VARCHAR(40)
   ,OUT po_status INT
   ,OUT po_errm   VARCHAR(255))
BEGIN
/******************************************************************************
** Object Name: ics_pat_ics_enfrc_actn_milestone
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  1) Process ICS_ENFRC_ACTN_MILESTONE
**                  called by: ics_process_accepted_trans
**
** Revision History:
** ----------------------------------------------------------------------------
**  Date         Name        Description
** ----------------------------------------------------------------------------
** 20121102      JenGo       Converted from Oracle to MySQL.
**                           Modularized SP, added logging and error-handling
**                           called by: ICS_PROCESS_ACCEPTED_TRANS
** 20121106      JenGo       Modified DELETE FROM ics_flow_icis.ICS_BASIC_PRMT
**                           MySQL errors out when the table being deleted is 
**                           used in the subquery.  To get around this either
**                           create a temp table or enclose the subquery in an
**                           inline view.  
*******************************************************************************/
   DECLARE v_startdtm
          ,v_enddtm     DATETIME;
   DECLARE v_sp_name    VARCHAR(64)  DEFAULT 'ics_pat_ics_enfrc_actn_milestone';
   DECLARE v_errstat    INT DEFAULT 1;
   DECLARE v_errm       VARCHAR(255);
   DECLARE v_marker     VARCHAR(255);
   --
   DECLARE EXIT HANDLER FOR SQLEXCEPTION
      BEGIN  
         ROLLBACK;
         SET po_status = -1;
         SET po_errm   = v_marker;
         CALL ics_etl_log_sp    
            (v_sp_name          -- pi_sp_name
            ,v_marker           -- pi_marker
            ,NULL               -- pi_tgt_tbl
            ,NULL               -- pi_src_tbl
            ,v_startdtm         -- pi_startdtm
            ,NOW()              -- pi_enddtm
            ,'FAILED'           -- pi_process
            ,-1);               -- pi_value
         COMMIT;
      END;
   --
   SET v_startdtm = NOW();

-- Remove any old records for ICS_ENFRC_ACTN_MILESTONE
-- 20121106
-- /ICS_ENFRC_ACTN_MILESTONE
SET v_marker = 'DELETE FROM -- /ICS_ENFRC_ACTN_MILESTONE'; 
DELETE
  FROM ics_flow_icis.ICS_ENFRC_ACTN_MILESTONE
 WHERE ICS_ENFRC_ACTN_MILESTONE.ICS_ENFRC_ACTN_MILESTONE_ID IN
          (SELECT ICS_ENFRC_ACTN_MILESTONE_ID
             FROM (SELECT ICS_ENFRC_ACTN_MILESTONE.ICS_ENFRC_ACTN_MILESTONE_ID
                     FROM ics_flow_icis.ICS_ENFRC_ACTN_MILESTONE
                     LEFT JOIN ICS_SUBM_RESULTS ON ICS_SUBM_RESULTS.KEY_HASH = ICS_ENFRC_ACTN_MILESTONE.KEY_HASH 
                    WHERE (RESULT_TYPE_CODE IN ('Accepted','Warning') AND SUBM_TYPE_NAME = 'EnforcementActionMilestoneSubmission')
                  ) vw
);
-- 20121106
-- Add accepted records for ICS_ENFRC_ACTN_MILESTONE
-- /ICS_ENFRC_ACTN_MILESTONE
SET v_marker = 'INSERT INTO -- /ICS_ENFRC_ACTN_MILESTONE'; 
INSERT INTO ics_flow_icis.ICS_ENFRC_ACTN_MILESTONE
     SELECT ICS_ENFRC_ACTN_MILESTONE.*
       FROM ICS_ENFRC_ACTN_MILESTONE
       WHERE ICS_ENFRC_ACTN_MILESTONE.TRANSACTION_TYPE NOT IN ('D','X')
        AND KEY_HASH IN 
              (SELECT KEY_HASH
                 FROM ICS_SUBM_RESULTS
                WHERE RESULT_TYPE_CODE IN ('Accepted','Warning')
                  AND SUBM_TYPE_NAME = 'EnforcementActionMilestoneSubmission');
   -- -------------- --
   --  END PROCEDURE --
   -- -------------- --
   SET v_marker = 'CALL ics_etl_log_sp END';
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_sp_name     -- pi_marker
      ,NULL          -- pi_tgt_tbl
      ,NULL          -- pi_src_tbl 
      ,v_startdtm    -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'COMPLETED'   -- pi_process
      ,0);           -- pi_value
   --
   SET po_status = 1;
   SET po_errm   = '';
   -- 
END