DROP PROCEDURE IF EXISTS ics_pat_ics_pretr_perf_summ;
CREATE PROCEDURE ics_pat_ics_pretr_perf_summ
   (IN  pi_transaction_id  VARCHAR(40)
   ,OUT po_status INT
   ,OUT po_errm   VARCHAR(255))
BEGIN
/******************************************************************************
** Object Name: ics_pat_ics_pretr_perf_summ
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  1) Process ICS_PRETR_PERF_SUMM
**                  called by: ics_process_accepted_trans
**
** Revision History:
** ----------------------------------------------------------------------------
**  Date         Name        Description
** ----------------------------------------------------------------------------
** 20121102      JenGo       Converted from Oracle to MySQL.
**                           Modularized SP, added logging and error-handling
**                           called by: ICS_PROCESS_ACCEPTED_TRANS
** 20121106      JenGo       Modified DELETE FROM ics_flow_icis.ICS_BASIC_PRMT
**                           MySQL errors out when the table being deleted is 
**                           used in the subquery.  To get around this either
**                           create a temp table or enclose the subquery in an
**                           inline view.  
*******************************************************************************/
   DECLARE v_startdtm
          ,v_enddtm     DATETIME;
   DECLARE v_sp_name    VARCHAR(64)  DEFAULT 'ics_pat_ics_pretr_perf_summ';
   DECLARE v_errstat    INT DEFAULT 1;
   DECLARE v_errm       VARCHAR(255);
   DECLARE v_marker     VARCHAR(255);
   --
   DECLARE EXIT HANDLER FOR SQLEXCEPTION
      BEGIN  
         ROLLBACK;
         SET po_status = -1;
         SET po_errm   = v_marker;
         CALL ics_etl_log_sp    
            (v_sp_name          -- pi_sp_name
            ,v_marker           -- pi_marker
            ,NULL               -- pi_tgt_tbl
            ,NULL               -- pi_src_tbl
            ,v_startdtm         -- pi_startdtm
            ,NOW()              -- pi_enddtm
            ,'FAILED'           -- pi_process
            ,-1);               -- pi_value
         COMMIT;
      END;
   --
   SET v_startdtm = NOW();

-- Remove any old records for ICS_PRETR_PERF_SUMM
-- /ICS_PRETR_PERF_SUMM/ICS_LOC_LMTS/ICS_LOC_LMTS_POLUT
SET v_marker = 'DELETE FROM -- /ICS_PRETR_PERF_SUMM/ICS_LOC_LMTS/ICS_LOC_LMTS_POLUT'; 
DELETE
  FROM ics_flow_icis.ICS_LOC_LMTS_POLUT
 WHERE ICS_LOC_LMTS_POLUT.ICS_LOC_LMTS_ID IN
          (SELECT ICS_LOC_LMTS.ICS_LOC_LMTS_ID
             FROM ics_flow_icis.ICS_PRETR_PERF_SUMM
                 LEFT JOIN ICS_SUBM_RESULTS ON ICS_SUBM_RESULTS.KEY_HASH = ICS_PRETR_PERF_SUMM.KEY_HASH 
                  JOIN ics_flow_icis.ICS_LOC_LMTS ON ICS_LOC_LMTS.ICS_PRETR_PERF_SUMM_ID = ICS_PRETR_PERF_SUMM.ICS_PRETR_PERF_SUMM_ID
              WHERE (RESULT_TYPE_CODE IN ('Accepted','Warning') AND SUBM_TYPE_NAME = 'PretreatmentPerformanceSummarySubmission')
                 OR ICS_PRETR_PERF_SUMM.PRMT_IDENT IN (SELECT PRMT_IDENT FROM ICS_SUBM_RESULTS WHERE SUBM_TYPE_NAME = 'PermitTerminationSubmission' AND RESULT_TYPE_CODE = 'Accepted')
);
-- /ICS_PRETR_PERF_SUMM/ICS_RMVL_CRDTS/ICS_RMVL_CRDTS_POLUT
SET v_marker = 'DELETE FROM -- /ICS_PRETR_PERF_SUMM/ICS_RMVL_CRDTS/ICS_RMVL_CRDTS_POLUT'; 
DELETE
  FROM ics_flow_icis.ICS_RMVL_CRDTS_POLUT
 WHERE ICS_RMVL_CRDTS_POLUT.ICS_RMVL_CRDTS_ID IN
          (SELECT ICS_RMVL_CRDTS.ICS_RMVL_CRDTS_ID
             FROM ics_flow_icis.ICS_PRETR_PERF_SUMM
                 LEFT JOIN ICS_SUBM_RESULTS ON ICS_SUBM_RESULTS.KEY_HASH = ICS_PRETR_PERF_SUMM.KEY_HASH 
                  JOIN ics_flow_icis.ICS_RMVL_CRDTS ON ICS_RMVL_CRDTS.ICS_PRETR_PERF_SUMM_ID = ICS_PRETR_PERF_SUMM.ICS_PRETR_PERF_SUMM_ID
              WHERE (RESULT_TYPE_CODE IN ('Accepted','Warning') AND SUBM_TYPE_NAME = 'PretreatmentPerformanceSummarySubmission')
                 OR ICS_PRETR_PERF_SUMM.PRMT_IDENT IN (SELECT PRMT_IDENT FROM ICS_SUBM_RESULTS WHERE SUBM_TYPE_NAME = 'PermitTerminationSubmission' AND RESULT_TYPE_CODE = 'Accepted')
);
-- /ICS_PRETR_PERF_SUMM/ICS_LOC_LMTS
SET v_marker = 'DELETE FROM -- /ICS_PRETR_PERF_SUMM/ICS_LOC_LMTS'; 
DELETE
  FROM ics_flow_icis.ICS_LOC_LMTS
 WHERE ICS_LOC_LMTS.ICS_PRETR_PERF_SUMM_ID IN
          (SELECT ICS_PRETR_PERF_SUMM.ICS_PRETR_PERF_SUMM_ID
             FROM ics_flow_icis.ICS_PRETR_PERF_SUMM
                 LEFT JOIN ICS_SUBM_RESULTS ON ICS_SUBM_RESULTS.KEY_HASH = ICS_PRETR_PERF_SUMM.KEY_HASH 
              WHERE (RESULT_TYPE_CODE IN ('Accepted','Warning') AND SUBM_TYPE_NAME = 'PretreatmentPerformanceSummarySubmission')
                 OR ICS_PRETR_PERF_SUMM.PRMT_IDENT IN (SELECT PRMT_IDENT FROM ICS_SUBM_RESULTS WHERE SUBM_TYPE_NAME = 'PermitTerminationSubmission' AND RESULT_TYPE_CODE = 'Accepted')
);
-- /ICS_PRETR_PERF_SUMM/ICS_RMVL_CRDTS
SET v_marker = 'DELETE FROM -- /ICS_PRETR_PERF_SUMM/ICS_RMVL_CRDTS'; 
DELETE
  FROM ics_flow_icis.ICS_RMVL_CRDTS
 WHERE ICS_RMVL_CRDTS.ICS_PRETR_PERF_SUMM_ID IN
          (SELECT ICS_PRETR_PERF_SUMM.ICS_PRETR_PERF_SUMM_ID
             FROM ics_flow_icis.ICS_PRETR_PERF_SUMM
                 LEFT JOIN ICS_SUBM_RESULTS ON ICS_SUBM_RESULTS.KEY_HASH = ICS_PRETR_PERF_SUMM.KEY_HASH 
              WHERE (RESULT_TYPE_CODE IN ('Accepted','Warning') AND SUBM_TYPE_NAME = 'PretreatmentPerformanceSummarySubmission')
                 OR ICS_PRETR_PERF_SUMM.PRMT_IDENT IN (SELECT PRMT_IDENT FROM ICS_SUBM_RESULTS WHERE SUBM_TYPE_NAME = 'PermitTerminationSubmission' AND RESULT_TYPE_CODE = 'Accepted')
);

-- 20121106
-- /ICS_PRETR_PERF_SUMM
SET v_marker = 'DELETE FROM -- /ICS_PRETR_PERF_SUMM'; 
DELETE
  FROM ics_flow_icis.ICS_PRETR_PERF_SUMM
 WHERE ICS_PRETR_PERF_SUMM.ICS_PRETR_PERF_SUMM_ID IN
          (SELECT ICS_PRETR_PERF_SUMM_ID
             FROM (SELECT ICS_PRETR_PERF_SUMM.ICS_PRETR_PERF_SUMM_ID
                     FROM ics_flow_icis.ICS_PRETR_PERF_SUMM
                     LEFT JOIN ICS_SUBM_RESULTS 
                       ON ICS_SUBM_RESULTS.KEY_HASH = ICS_PRETR_PERF_SUMM.KEY_HASH 
                    WHERE (    RESULT_TYPE_CODE IN ('Accepted','Warning') 
                           AND SUBM_TYPE_NAME = 'PretreatmentPerformanceSummarySubmission')
                       OR ICS_PRETR_PERF_SUMM.PRMT_IDENT IN (SELECT PRMT_IDENT 
                                                               FROM ICS_SUBM_RESULTS 
                                                              WHERE SUBM_TYPE_NAME = 'PermitTerminationSubmission' 
                                                                AND RESULT_TYPE_CODE = 'Accepted')
                  ) vw
);
-- 20121106


-- Add accepted records for ICS_PRETR_PERF_SUMM
-- /ICS_PRETR_PERF_SUMM
SET v_marker = 'INSERT INTO -- /ICS_PRETR_PERF_SUMM'; 
INSERT INTO ics_flow_icis.ICS_PRETR_PERF_SUMM
     SELECT ICS_PRETR_PERF_SUMM.*
       FROM ICS_PRETR_PERF_SUMM
       WHERE ICS_PRETR_PERF_SUMM.TRANSACTION_TYPE NOT IN ('D','X')
        AND KEY_HASH IN 
              (SELECT KEY_HASH
                 FROM ICS_SUBM_RESULTS
                WHERE RESULT_TYPE_CODE IN ('Accepted','Warning')
                  AND SUBM_TYPE_NAME = 'PretreatmentPerformanceSummarySubmission');

-- /ICS_PRETR_PERF_SUMM/ICS_LOC_LMTS
SET v_marker = 'INSERT INTO -- /ICS_PRETR_PERF_SUMM/ICS_LOC_LMTS'; 
INSERT INTO ics_flow_icis.ICS_LOC_LMTS
     SELECT ICS_LOC_LMTS.*
       FROM ICS_LOC_LMTS
          JOIN ICS_PRETR_PERF_SUMM
            ON ICS_LOC_LMTS.ICS_PRETR_PERF_SUMM_ID = ICS_PRETR_PERF_SUMM.ICS_PRETR_PERF_SUMM_ID
       WHERE ICS_PRETR_PERF_SUMM.TRANSACTION_TYPE NOT IN ('D','X')
        AND KEY_HASH IN 
              (SELECT KEY_HASH
                 FROM ICS_SUBM_RESULTS
                WHERE RESULT_TYPE_CODE IN ('Accepted','Warning')
                  AND SUBM_TYPE_NAME = 'PretreatmentPerformanceSummarySubmission');

-- /ICS_PRETR_PERF_SUMM/ICS_LOC_LMTS/ICS_LOC_LMTS_POLUT
SET v_marker = 'INSERT INTO -- /ICS_PRETR_PERF_SUMM/ICS_LOC_LMTS/ICS_LOC_LMTS_POLUT'; 
INSERT INTO ics_flow_icis.ICS_LOC_LMTS_POLUT
     SELECT ICS_LOC_LMTS_POLUT.*
       FROM ICS_LOC_LMTS_POLUT
          JOIN ICS_LOC_LMTS
            ON ICS_LOC_LMTS_POLUT.ICS_LOC_LMTS_ID = ICS_LOC_LMTS.ICS_LOC_LMTS_ID
          JOIN ICS_PRETR_PERF_SUMM
            ON ICS_LOC_LMTS.ICS_PRETR_PERF_SUMM_ID = ICS_PRETR_PERF_SUMM.ICS_PRETR_PERF_SUMM_ID
       WHERE ICS_PRETR_PERF_SUMM.TRANSACTION_TYPE NOT IN ('D','X')
        AND KEY_HASH IN 
              (SELECT KEY_HASH
                 FROM ICS_SUBM_RESULTS
                WHERE RESULT_TYPE_CODE IN ('Accepted','Warning')
                  AND SUBM_TYPE_NAME = 'PretreatmentPerformanceSummarySubmission');

-- /ICS_PRETR_PERF_SUMM/ICS_RMVL_CRDTS
SET v_marker = 'INSERT INTO -- /ICS_PRETR_PERF_SUMM/ICS_RMVL_CRDTS'; 
INSERT INTO ics_flow_icis.ICS_RMVL_CRDTS
     SELECT ICS_RMVL_CRDTS.*
       FROM ICS_RMVL_CRDTS
          JOIN ICS_PRETR_PERF_SUMM
            ON ICS_RMVL_CRDTS.ICS_PRETR_PERF_SUMM_ID = ICS_PRETR_PERF_SUMM.ICS_PRETR_PERF_SUMM_ID
       WHERE ICS_PRETR_PERF_SUMM.TRANSACTION_TYPE NOT IN ('D','X')
        AND KEY_HASH IN 
              (SELECT KEY_HASH
                 FROM ICS_SUBM_RESULTS
                WHERE RESULT_TYPE_CODE IN ('Accepted','Warning')
                  AND SUBM_TYPE_NAME = 'PretreatmentPerformanceSummarySubmission');

-- /ICS_PRETR_PERF_SUMM/ICS_RMVL_CRDTS/ICS_RMVL_CRDTS_POLUT
SET v_marker = 'INSERT INTO -- /ICS_PRETR_PERF_SUMM/ICS_RMVL_CRDTS/ICS_RMVL_CRDTS_POLUT'; 
INSERT INTO ics_flow_icis.ICS_RMVL_CRDTS_POLUT
     SELECT ICS_RMVL_CRDTS_POLUT.*
       FROM ICS_RMVL_CRDTS_POLUT
          JOIN ICS_RMVL_CRDTS
            ON ICS_RMVL_CRDTS_POLUT.ICS_RMVL_CRDTS_ID = ICS_RMVL_CRDTS.ICS_RMVL_CRDTS_ID
          JOIN ICS_PRETR_PERF_SUMM
            ON ICS_RMVL_CRDTS.ICS_PRETR_PERF_SUMM_ID = ICS_PRETR_PERF_SUMM.ICS_PRETR_PERF_SUMM_ID
       WHERE ICS_PRETR_PERF_SUMM.TRANSACTION_TYPE NOT IN ('D','X')
        AND KEY_HASH IN 
              (SELECT KEY_HASH
                 FROM ICS_SUBM_RESULTS
                WHERE RESULT_TYPE_CODE IN ('Accepted','Warning')
                  AND SUBM_TYPE_NAME = 'PretreatmentPerformanceSummarySubmission');

   -- -------------- --
   --  END PROCEDURE --
   -- -------------- --
   SET v_marker = 'CALL ics_etl_log_sp END';
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_sp_name     -- pi_marker
      ,NULL          -- pi_tgt_tbl
      ,NULL          -- pi_src_tbl 
      ,v_startdtm    -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'COMPLETED'   -- pi_process
      ,0);           -- pi_value
   --
   SET po_status = 1;
   SET po_errm   = '';
   -- 
END