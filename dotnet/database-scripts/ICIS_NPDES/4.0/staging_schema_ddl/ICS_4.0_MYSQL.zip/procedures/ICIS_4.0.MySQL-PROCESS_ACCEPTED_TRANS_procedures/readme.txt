Schemas in this file are hard-coded to the following:
ics_flow_local
ics_flow_icis

To use a different directory, do a global replace of all files within this directory (I would reccomend the free notepadd++ tool for this)  Recommend doing a case sensitive replace without rgex or extensions.

Replacement:  ics_flow_local -> <your schema name for local>
Replacement:  ics_flow_icis. -> <your schema name for icis>.

