DROP PROCEDURE IF EXISTS ics_pat_ics_gnrl_prmt;
CREATE PROCEDURE ics_pat_ics_gnrl_prmt
   (IN  pi_transaction_id  VARCHAR(40)
   ,OUT po_status INT
   ,OUT po_errm   VARCHAR(255))
BEGIN
/******************************************************************************
** Object Name: ics_pat_ics_gnrl_prmt
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  1) Process ICS_GNRL_PRMT
**                  called by: ics_process_accepted_trans
**
** Revision History:
** ----------------------------------------------------------------------------
**  Date         Name        Description
** ----------------------------------------------------------------------------
** 20121102      JenGo       Converted from Oracle to MySQL.
**                           Modularized SP, added logging and error-handling
**                           called by: ICS_PROCESS_ACCEPTED_TRANS
** 20121106      JenGo       Modified DELETE FROM ics_flow_icis.ICS_BASIC_PRMT
**                           MySQL errors out when the table being deleted is 
**                           used in the subquery.  To get around this either
**                           create a temp table or enclose the subquery in an
**                           inline view. 
*******************************************************************************/
   DECLARE v_startdtm
          ,v_enddtm     DATETIME;
   DECLARE v_sp_name    VARCHAR(64)  DEFAULT 'ics_pat_ics_gnrl_prmt';
   DECLARE v_errstat    INT DEFAULT 1;
   DECLARE v_errm       VARCHAR(255);
   DECLARE v_marker     VARCHAR(255);
   --
   DECLARE EXIT HANDLER FOR SQLEXCEPTION
      BEGIN  
         ROLLBACK;
         SET po_status = -1;
         SET po_errm   = v_marker;
         CALL ics_etl_log_sp    
            (v_sp_name          -- pi_sp_name
            ,v_marker           -- pi_marker
            ,NULL               -- pi_tgt_tbl
            ,NULL               -- pi_src_tbl
            ,v_startdtm         -- pi_startdtm
            ,NOW()              -- pi_enddtm
            ,'FAILED'           -- pi_process
            ,-1);               -- pi_value
         COMMIT;
      END;
   --
   SET v_startdtm = NOW();

-- Remove any old records for ICS_GNRL_PRMT
-- /ICS_GNRL_PRMT/ICS_FAC/ICS_ADDR/ICS_TELEPH
SET v_marker = 'DELETE FROM -- /ICS_GNRL_PRMT/ICS_FAC/ICS_ADDR/ICS_TELEPH'; 
DELETE
  FROM ics_flow_icis.ICS_TELEPH
 WHERE ICS_TELEPH.ICS_ADDR_ID IN
          (SELECT ICS_ADDR.ICS_ADDR_ID
             FROM ics_flow_icis.ICS_GNRL_PRMT
                 LEFT JOIN ICS_SUBM_RESULTS ON ICS_SUBM_RESULTS.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH 
                  JOIN ics_flow_icis.ICS_FAC ON ICS_FAC.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
                  JOIN ics_flow_icis.ICS_ADDR ON ICS_ADDR.ICS_FAC_ID = ICS_FAC.ICS_FAC_ID
              WHERE (RESULT_TYPE_CODE IN ('Accepted','Warning') AND SUBM_TYPE_NAME = 'GeneralPermitSubmission')
                 OR ICS_GNRL_PRMT.PRMT_IDENT IN (SELECT PRMT_IDENT FROM ICS_SUBM_RESULTS WHERE SUBM_TYPE_NAME = 'PermitTerminationSubmission' AND RESULT_TYPE_CODE = 'Accepted')
);
-- /ICS_GNRL_PRMT/ICS_FAC/ICS_CONTACT/ICS_TELEPH
SET v_marker = 'DELETE FROM -- /ICS_GNRL_PRMT/ICS_FAC/ICS_CONTACT/ICS_TELEPH'; 
DELETE
  FROM ics_flow_icis.ICS_TELEPH
 WHERE ICS_TELEPH.ICS_CONTACT_ID IN
          (SELECT ICS_CONTACT.ICS_CONTACT_ID
             FROM ics_flow_icis.ICS_GNRL_PRMT
                 LEFT JOIN ICS_SUBM_RESULTS ON ICS_SUBM_RESULTS.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH 
                  JOIN ics_flow_icis.ICS_FAC ON ICS_FAC.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
                  JOIN ics_flow_icis.ICS_CONTACT ON ICS_CONTACT.ICS_FAC_ID = ICS_FAC.ICS_FAC_ID
              WHERE (RESULT_TYPE_CODE IN ('Accepted','Warning') AND SUBM_TYPE_NAME = 'GeneralPermitSubmission')
                 OR ICS_GNRL_PRMT.PRMT_IDENT IN (SELECT PRMT_IDENT FROM ICS_SUBM_RESULTS WHERE SUBM_TYPE_NAME = 'PermitTerminationSubmission' AND RESULT_TYPE_CODE = 'Accepted')
);
-- /ICS_GNRL_PRMT/ICS_ADDR/ICS_TELEPH
SET v_marker = 'DELETE FROM -- /ICS_GNRL_PRMT/ICS_ADDR/ICS_TELEPH'; 
DELETE
  FROM ics_flow_icis.ICS_TELEPH
 WHERE ICS_TELEPH.ICS_ADDR_ID IN
          (SELECT ICS_ADDR.ICS_ADDR_ID
             FROM ics_flow_icis.ICS_GNRL_PRMT
                 LEFT JOIN ICS_SUBM_RESULTS ON ICS_SUBM_RESULTS.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH 
                  JOIN ics_flow_icis.ICS_ADDR ON ICS_ADDR.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
              WHERE (RESULT_TYPE_CODE IN ('Accepted','Warning') AND SUBM_TYPE_NAME = 'GeneralPermitSubmission')
                 OR ICS_GNRL_PRMT.PRMT_IDENT IN (SELECT PRMT_IDENT FROM ICS_SUBM_RESULTS WHERE SUBM_TYPE_NAME = 'PermitTerminationSubmission' AND RESULT_TYPE_CODE = 'Accepted')
);
-- /ICS_GNRL_PRMT/ICS_CONTACT/ICS_TELEPH
SET v_marker = 'DELETE FROM -- /ICS_GNRL_PRMT/ICS_CONTACT/ICS_TELEPH'; 
DELETE
  FROM ics_flow_icis.ICS_TELEPH
 WHERE ICS_TELEPH.ICS_CONTACT_ID IN
          (SELECT ICS_CONTACT.ICS_CONTACT_ID
             FROM ics_flow_icis.ICS_GNRL_PRMT
                 LEFT JOIN ICS_SUBM_RESULTS ON ICS_SUBM_RESULTS.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH 
                  JOIN ics_flow_icis.ICS_CONTACT ON ICS_CONTACT.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
              WHERE (RESULT_TYPE_CODE IN ('Accepted','Warning') AND SUBM_TYPE_NAME = 'GeneralPermitSubmission')
                 OR ICS_GNRL_PRMT.PRMT_IDENT IN (SELECT PRMT_IDENT FROM ICS_SUBM_RESULTS WHERE SUBM_TYPE_NAME = 'PermitTerminationSubmission' AND RESULT_TYPE_CODE = 'Accepted')
);
-- /ICS_GNRL_PRMT/ICS_FAC/ICS_ADDR
SET v_marker = 'DELETE FROM -- /ICS_GNRL_PRMT/ICS_FAC/ICS_ADDR'; 
DELETE
  FROM ics_flow_icis.ICS_ADDR
 WHERE ICS_ADDR.ICS_FAC_ID IN
          (SELECT ICS_FAC.ICS_FAC_ID
             FROM ics_flow_icis.ICS_GNRL_PRMT
                 LEFT JOIN ICS_SUBM_RESULTS ON ICS_SUBM_RESULTS.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH 
                  JOIN ics_flow_icis.ICS_FAC ON ICS_FAC.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
              WHERE (RESULT_TYPE_CODE IN ('Accepted','Warning') AND SUBM_TYPE_NAME = 'GeneralPermitSubmission')
                 OR ICS_GNRL_PRMT.PRMT_IDENT IN (SELECT PRMT_IDENT FROM ICS_SUBM_RESULTS WHERE SUBM_TYPE_NAME = 'PermitTerminationSubmission' AND RESULT_TYPE_CODE = 'Accepted')
);
-- /ICS_GNRL_PRMT/ICS_FAC/ICS_CONTACT
SET v_marker = 'DELETE FROM -- /ICS_GNRL_PRMT/ICS_FAC/ICS_CONTACT'; 
DELETE
  FROM ics_flow_icis.ICS_CONTACT
 WHERE ICS_CONTACT.ICS_FAC_ID IN
          (SELECT ICS_FAC.ICS_FAC_ID
             FROM ics_flow_icis.ICS_GNRL_PRMT
                 LEFT JOIN ICS_SUBM_RESULTS ON ICS_SUBM_RESULTS.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH 
                  JOIN ics_flow_icis.ICS_FAC ON ICS_FAC.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
              WHERE (RESULT_TYPE_CODE IN ('Accepted','Warning') AND SUBM_TYPE_NAME = 'GeneralPermitSubmission')
                 OR ICS_GNRL_PRMT.PRMT_IDENT IN (SELECT PRMT_IDENT FROM ICS_SUBM_RESULTS WHERE SUBM_TYPE_NAME = 'PermitTerminationSubmission' AND RESULT_TYPE_CODE = 'Accepted')
);
-- /ICS_GNRL_PRMT/ICS_FAC/ICS_FAC_CLASS
SET v_marker = 'DELETE FROM -- /ICS_GNRL_PRMT/ICS_FAC/ICS_FAC_CLASS'; 
DELETE
  FROM ics_flow_icis.ICS_FAC_CLASS
 WHERE ICS_FAC_CLASS.ICS_FAC_ID IN
          (SELECT ICS_FAC.ICS_FAC_ID
             FROM ics_flow_icis.ICS_GNRL_PRMT
                 LEFT JOIN ICS_SUBM_RESULTS ON ICS_SUBM_RESULTS.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH 
                  JOIN ics_flow_icis.ICS_FAC ON ICS_FAC.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
              WHERE (RESULT_TYPE_CODE IN ('Accepted','Warning') AND SUBM_TYPE_NAME = 'GeneralPermitSubmission')
                 OR ICS_GNRL_PRMT.PRMT_IDENT IN (SELECT PRMT_IDENT FROM ICS_SUBM_RESULTS WHERE SUBM_TYPE_NAME = 'PermitTerminationSubmission' AND RESULT_TYPE_CODE = 'Accepted')
);
-- /ICS_GNRL_PRMT/ICS_FAC/ICS_GEO_COORD
SET v_marker = 'DELETE FROM -- /ICS_GNRL_PRMT/ICS_FAC/ICS_GEO_COORD'; 
DELETE
  FROM ics_flow_icis.ICS_GEO_COORD
 WHERE ICS_GEO_COORD.ICS_FAC_ID IN
          (SELECT ICS_FAC.ICS_FAC_ID
             FROM ics_flow_icis.ICS_GNRL_PRMT
                 LEFT JOIN ICS_SUBM_RESULTS ON ICS_SUBM_RESULTS.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH 
                  JOIN ics_flow_icis.ICS_FAC ON ICS_FAC.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
              WHERE (RESULT_TYPE_CODE IN ('Accepted','Warning') AND SUBM_TYPE_NAME = 'GeneralPermitSubmission')
                 OR ICS_GNRL_PRMT.PRMT_IDENT IN (SELECT PRMT_IDENT FROM ICS_SUBM_RESULTS WHERE SUBM_TYPE_NAME = 'PermitTerminationSubmission' AND RESULT_TYPE_CODE = 'Accepted')
);
-- /ICS_GNRL_PRMT/ICS_FAC/ICS_NAICS_CODE
SET v_marker = 'DELETE FROM -- /ICS_GNRL_PRMT/ICS_FAC/ICS_NAICS_CODE'; 
DELETE
  FROM ics_flow_icis.ICS_NAICS_CODE
 WHERE ICS_NAICS_CODE.ICS_FAC_ID IN
          (SELECT ICS_FAC.ICS_FAC_ID
             FROM ics_flow_icis.ICS_GNRL_PRMT
                 LEFT JOIN ICS_SUBM_RESULTS ON ICS_SUBM_RESULTS.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH 
                  JOIN ics_flow_icis.ICS_FAC ON ICS_FAC.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
              WHERE (RESULT_TYPE_CODE IN ('Accepted','Warning') AND SUBM_TYPE_NAME = 'GeneralPermitSubmission')
                 OR ICS_GNRL_PRMT.PRMT_IDENT IN (SELECT PRMT_IDENT FROM ICS_SUBM_RESULTS WHERE SUBM_TYPE_NAME = 'PermitTerminationSubmission' AND RESULT_TYPE_CODE = 'Accepted')
);
-- /ICS_GNRL_PRMT/ICS_FAC/ICS_ORIG_PROGS
SET v_marker = 'DELETE FROM -- /ICS_GNRL_PRMT/ICS_FAC/ICS_ORIG_PROGS'; 
DELETE
  FROM ics_flow_icis.ICS_ORIG_PROGS
 WHERE ICS_ORIG_PROGS.ICS_FAC_ID IN
          (SELECT ICS_FAC.ICS_FAC_ID
             FROM ics_flow_icis.ICS_GNRL_PRMT
                 LEFT JOIN ICS_SUBM_RESULTS ON ICS_SUBM_RESULTS.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH 
                  JOIN ics_flow_icis.ICS_FAC ON ICS_FAC.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
              WHERE (RESULT_TYPE_CODE IN ('Accepted','Warning') AND SUBM_TYPE_NAME = 'GeneralPermitSubmission')
                 OR ICS_GNRL_PRMT.PRMT_IDENT IN (SELECT PRMT_IDENT FROM ICS_SUBM_RESULTS WHERE SUBM_TYPE_NAME = 'PermitTerminationSubmission' AND RESULT_TYPE_CODE = 'Accepted')
);
-- /ICS_GNRL_PRMT/ICS_FAC/ICS_PLCY
SET v_marker = 'DELETE FROM -- /ICS_GNRL_PRMT/ICS_FAC/ICS_PLCY'; 
DELETE
  FROM ics_flow_icis.ICS_PLCY
 WHERE ICS_PLCY.ICS_FAC_ID IN
          (SELECT ICS_FAC.ICS_FAC_ID
             FROM ics_flow_icis.ICS_GNRL_PRMT
                 LEFT JOIN ICS_SUBM_RESULTS ON ICS_SUBM_RESULTS.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH 
                  JOIN ics_flow_icis.ICS_FAC ON ICS_FAC.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
              WHERE (RESULT_TYPE_CODE IN ('Accepted','Warning') AND SUBM_TYPE_NAME = 'GeneralPermitSubmission')
                 OR ICS_GNRL_PRMT.PRMT_IDENT IN (SELECT PRMT_IDENT FROM ICS_SUBM_RESULTS WHERE SUBM_TYPE_NAME = 'PermitTerminationSubmission' AND RESULT_TYPE_CODE = 'Accepted')
);
-- /ICS_GNRL_PRMT/ICS_FAC/ICS_SIC_CODE
SET v_marker = 'DELETE FROM -- /ICS_GNRL_PRMT/ICS_FAC/ICS_SIC_CODE'; 
DELETE
  FROM ics_flow_icis.ICS_SIC_CODE
 WHERE ICS_SIC_CODE.ICS_FAC_ID IN
          (SELECT ICS_FAC.ICS_FAC_ID
             FROM ics_flow_icis.ICS_GNRL_PRMT
                 LEFT JOIN ICS_SUBM_RESULTS ON ICS_SUBM_RESULTS.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH 
                  JOIN ics_flow_icis.ICS_FAC ON ICS_FAC.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
              WHERE (RESULT_TYPE_CODE IN ('Accepted','Warning') AND SUBM_TYPE_NAME = 'GeneralPermitSubmission')
                 OR ICS_GNRL_PRMT.PRMT_IDENT IN (SELECT PRMT_IDENT FROM ICS_SUBM_RESULTS WHERE SUBM_TYPE_NAME = 'PermitTerminationSubmission' AND RESULT_TYPE_CODE = 'Accepted')
);
-- /ICS_GNRL_PRMT/ICS_ADDR
SET v_marker = 'DELETE FROM -- /ICS_GNRL_PRMT/ICS_ADDR'; 
DELETE
  FROM ics_flow_icis.ICS_ADDR
 WHERE ICS_ADDR.ICS_GNRL_PRMT_ID IN
          (SELECT ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
             FROM ics_flow_icis.ICS_GNRL_PRMT
                 LEFT JOIN ICS_SUBM_RESULTS ON ICS_SUBM_RESULTS.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH 
              WHERE (RESULT_TYPE_CODE IN ('Accepted','Warning') AND SUBM_TYPE_NAME = 'GeneralPermitSubmission')
                 OR ICS_GNRL_PRMT.PRMT_IDENT IN (SELECT PRMT_IDENT FROM ICS_SUBM_RESULTS WHERE SUBM_TYPE_NAME = 'PermitTerminationSubmission' AND RESULT_TYPE_CODE = 'Accepted')
);
-- /ICS_GNRL_PRMT/ICS_ASSC_PRMT
SET v_marker = 'DELETE FROM -- /ICS_GNRL_PRMT/ICS_ASSC_PRMT'; 
DELETE
  FROM ics_flow_icis.ICS_ASSC_PRMT
 WHERE ICS_ASSC_PRMT.ICS_GNRL_PRMT_ID IN
          (SELECT ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
             FROM ics_flow_icis.ICS_GNRL_PRMT
                 LEFT JOIN ICS_SUBM_RESULTS ON ICS_SUBM_RESULTS.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH 
              WHERE (RESULT_TYPE_CODE IN ('Accepted','Warning') AND SUBM_TYPE_NAME = 'GeneralPermitSubmission')
                 OR ICS_GNRL_PRMT.PRMT_IDENT IN (SELECT PRMT_IDENT FROM ICS_SUBM_RESULTS WHERE SUBM_TYPE_NAME = 'PermitTerminationSubmission' AND RESULT_TYPE_CODE = 'Accepted')
);
-- /ICS_GNRL_PRMT/ICS_CMPL_TRACK_STAT
SET v_marker = 'DELETE FROM -- /ICS_GNRL_PRMT/ICS_CMPL_TRACK_STAT'; 
DELETE
  FROM ics_flow_icis.ICS_CMPL_TRACK_STAT
 WHERE ICS_CMPL_TRACK_STAT.ICS_GNRL_PRMT_ID IN
          (SELECT ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
             FROM ics_flow_icis.ICS_GNRL_PRMT
                 LEFT JOIN ICS_SUBM_RESULTS ON ICS_SUBM_RESULTS.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH 
              WHERE (RESULT_TYPE_CODE IN ('Accepted','Warning') AND SUBM_TYPE_NAME = 'GeneralPermitSubmission')
                 OR ICS_GNRL_PRMT.PRMT_IDENT IN (SELECT PRMT_IDENT FROM ICS_SUBM_RESULTS WHERE SUBM_TYPE_NAME = 'PermitTerminationSubmission' AND RESULT_TYPE_CODE = 'Accepted')
);
-- /ICS_GNRL_PRMT/ICS_CONTACT
SET v_marker = 'DELETE FROM -- /ICS_GNRL_PRMT/ICS_CONTACT'; 
DELETE
  FROM ics_flow_icis.ICS_CONTACT
 WHERE ICS_CONTACT.ICS_GNRL_PRMT_ID IN
          (SELECT ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
             FROM ics_flow_icis.ICS_GNRL_PRMT
                 LEFT JOIN ICS_SUBM_RESULTS ON ICS_SUBM_RESULTS.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH 
              WHERE (RESULT_TYPE_CODE IN ('Accepted','Warning') AND SUBM_TYPE_NAME = 'GeneralPermitSubmission')
                 OR ICS_GNRL_PRMT.PRMT_IDENT IN (SELECT PRMT_IDENT FROM ICS_SUBM_RESULTS WHERE SUBM_TYPE_NAME = 'PermitTerminationSubmission' AND RESULT_TYPE_CODE = 'Accepted')
);
-- /ICS_GNRL_PRMT/ICS_EFFLU_GUIDE
SET v_marker = 'DELETE FROM -- /ICS_GNRL_PRMT/ICS_EFFLU_GUIDE'; 
DELETE
  FROM ics_flow_icis.ICS_EFFLU_GUIDE
 WHERE ICS_EFFLU_GUIDE.ICS_GNRL_PRMT_ID IN
          (SELECT ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
             FROM ics_flow_icis.ICS_GNRL_PRMT
                 LEFT JOIN ICS_SUBM_RESULTS ON ICS_SUBM_RESULTS.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH 
              WHERE (RESULT_TYPE_CODE IN ('Accepted','Warning') AND SUBM_TYPE_NAME = 'GeneralPermitSubmission')
                 OR ICS_GNRL_PRMT.PRMT_IDENT IN (SELECT PRMT_IDENT FROM ICS_SUBM_RESULTS WHERE SUBM_TYPE_NAME = 'PermitTerminationSubmission' AND RESULT_TYPE_CODE = 'Accepted')
);
-- /ICS_GNRL_PRMT/ICS_FAC
SET v_marker = 'DELETE FROM -- /ICS_GNRL_PRMT/ICS_FAC'; 
DELETE
  FROM ics_flow_icis.ICS_FAC
 WHERE ICS_FAC.ICS_GNRL_PRMT_ID IN
          (SELECT ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
             FROM ics_flow_icis.ICS_GNRL_PRMT
                 LEFT JOIN ICS_SUBM_RESULTS ON ICS_SUBM_RESULTS.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH 
              WHERE (RESULT_TYPE_CODE IN ('Accepted','Warning') AND SUBM_TYPE_NAME = 'GeneralPermitSubmission')
                 OR ICS_GNRL_PRMT.PRMT_IDENT IN (SELECT PRMT_IDENT FROM ICS_SUBM_RESULTS WHERE SUBM_TYPE_NAME = 'PermitTerminationSubmission' AND RESULT_TYPE_CODE = 'Accepted')
);
-- /ICS_GNRL_PRMT/ICS_NAICS_CODE
SET v_marker = 'DELETE FROM -- /ICS_GNRL_PRMT/ICS_NAICS_CODE'; 
DELETE
  FROM ics_flow_icis.ICS_NAICS_CODE
 WHERE ICS_NAICS_CODE.ICS_GNRL_PRMT_ID IN
          (SELECT ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
             FROM ics_flow_icis.ICS_GNRL_PRMT
                 LEFT JOIN ICS_SUBM_RESULTS ON ICS_SUBM_RESULTS.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH 
              WHERE (RESULT_TYPE_CODE IN ('Accepted','Warning') AND SUBM_TYPE_NAME = 'GeneralPermitSubmission')
                 OR ICS_GNRL_PRMT.PRMT_IDENT IN (SELECT PRMT_IDENT FROM ICS_SUBM_RESULTS WHERE SUBM_TYPE_NAME = 'PermitTerminationSubmission' AND RESULT_TYPE_CODE = 'Accepted')
);
-- /ICS_GNRL_PRMT/ICS_OTHR_PRMTS
SET v_marker = 'DELETE FROM -- /ICS_GNRL_PRMT/ICS_OTHR_PRMTS'; 
DELETE
  FROM ics_flow_icis.ICS_OTHR_PRMTS
 WHERE ICS_OTHR_PRMTS.ICS_GNRL_PRMT_ID IN
          (SELECT ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
             FROM ics_flow_icis.ICS_GNRL_PRMT
                 LEFT JOIN ICS_SUBM_RESULTS ON ICS_SUBM_RESULTS.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH 
              WHERE (RESULT_TYPE_CODE IN ('Accepted','Warning') AND SUBM_TYPE_NAME = 'GeneralPermitSubmission')
                 OR ICS_GNRL_PRMT.PRMT_IDENT IN (SELECT PRMT_IDENT FROM ICS_SUBM_RESULTS WHERE SUBM_TYPE_NAME = 'PermitTerminationSubmission' AND RESULT_TYPE_CODE = 'Accepted')
);
-- /ICS_GNRL_PRMT/ICS_SIC_CODE
SET v_marker = 'DELETE FROM -- /ICS_GNRL_PRMT/ICS_SIC_CODE'; 
DELETE
  FROM ics_flow_icis.ICS_SIC_CODE
 WHERE ICS_SIC_CODE.ICS_GNRL_PRMT_ID IN
          (SELECT ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
             FROM ics_flow_icis.ICS_GNRL_PRMT
                 LEFT JOIN ICS_SUBM_RESULTS ON ICS_SUBM_RESULTS.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH 
              WHERE (RESULT_TYPE_CODE IN ('Accepted','Warning') AND SUBM_TYPE_NAME = 'GeneralPermitSubmission')
                 OR ICS_GNRL_PRMT.PRMT_IDENT IN (SELECT PRMT_IDENT FROM ICS_SUBM_RESULTS WHERE SUBM_TYPE_NAME = 'PermitTerminationSubmission' AND RESULT_TYPE_CODE = 'Accepted')
);
-- 20121106
-- /ICS_GNRL_PRMT
SET v_marker = 'DELETE FROM -- /ICS_GNRL_PRMT'; 
DELETE
  FROM ics_flow_icis.ICS_GNRL_PRMT
 WHERE ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID IN
          (SELECT ICS_GNRL_PRMT_ID
             FROM (SELECT ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
                     FROM ics_flow_icis.ICS_GNRL_PRMT
                     LEFT JOIN ICS_SUBM_RESULTS 
                       ON ICS_SUBM_RESULTS.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH 
                    WHERE (    RESULT_TYPE_CODE IN ('Accepted','Warning') 
                           AND SUBM_TYPE_NAME = 'GeneralPermitSubmission')
                       OR ICS_GNRL_PRMT.PRMT_IDENT IN (SELECT PRMT_IDENT 
                                                         FROM ICS_SUBM_RESULTS 
                                                        WHERE SUBM_TYPE_NAME = 'PermitTerminationSubmission' 
                                                           AND RESULT_TYPE_CODE = 'Accepted')
                  ) vw
);
-- 20121106

-- Add accepted records for ICS_GNRL_PRMT
-- /ICS_GNRL_PRMT
SET v_marker = 'INSERT INTO -- /ICS_GNRL_PRMT'; 
INSERT INTO ics_flow_icis.ICS_GNRL_PRMT
     SELECT ICS_GNRL_PRMT.*
       FROM ICS_GNRL_PRMT
       WHERE ICS_GNRL_PRMT.TRANSACTION_TYPE NOT IN ('D','X')
        AND KEY_HASH IN 
              (SELECT KEY_HASH
                 FROM ICS_SUBM_RESULTS
                WHERE RESULT_TYPE_CODE IN ('Accepted','Warning')
                  AND SUBM_TYPE_NAME = 'GeneralPermitSubmission');

-- /ICS_GNRL_PRMT/ICS_ADDR
SET v_marker = 'INSERT INTO -- /ICS_GNRL_PRMT/ICS_ADDR'; 
INSERT INTO ics_flow_icis.ICS_ADDR
     SELECT ICS_ADDR.*
       FROM ICS_ADDR
          JOIN ICS_GNRL_PRMT
            ON ICS_ADDR.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
       WHERE ICS_GNRL_PRMT.TRANSACTION_TYPE NOT IN ('D','X')
        AND KEY_HASH IN 
              (SELECT KEY_HASH
                 FROM ICS_SUBM_RESULTS
                WHERE RESULT_TYPE_CODE IN ('Accepted','Warning')
                  AND SUBM_TYPE_NAME = 'GeneralPermitSubmission');

-- /ICS_GNRL_PRMT/ICS_ADDR/ICS_TELEPH
SET v_marker = 'INSERT INTO -- /ICS_GNRL_PRMT/ICS_ADDR/ICS_TELEPH'; 
INSERT INTO ics_flow_icis.ICS_TELEPH
     SELECT ICS_TELEPH.*
       FROM ICS_TELEPH
          JOIN ICS_ADDR
            ON ICS_TELEPH.ICS_ADDR_ID = ICS_ADDR.ICS_ADDR_ID
          JOIN ICS_GNRL_PRMT
            ON ICS_ADDR.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
       WHERE ICS_GNRL_PRMT.TRANSACTION_TYPE NOT IN ('D','X')
        AND KEY_HASH IN 
              (SELECT KEY_HASH
                 FROM ICS_SUBM_RESULTS
                WHERE RESULT_TYPE_CODE IN ('Accepted','Warning')
                  AND SUBM_TYPE_NAME = 'GeneralPermitSubmission');

-- /ICS_GNRL_PRMT/ICS_ASSC_PRMT
SET v_marker = 'INSERT INTO -- /ICS_GNRL_PRMT/ICS_ASSC_PRMT'; 
INSERT INTO ics_flow_icis.ICS_ASSC_PRMT
     SELECT ICS_ASSC_PRMT.*
       FROM ICS_ASSC_PRMT
          JOIN ICS_GNRL_PRMT
            ON ICS_ASSC_PRMT.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
       WHERE ICS_GNRL_PRMT.TRANSACTION_TYPE NOT IN ('D','X')
        AND KEY_HASH IN 
              (SELECT KEY_HASH
                 FROM ICS_SUBM_RESULTS
                WHERE RESULT_TYPE_CODE IN ('Accepted','Warning')
                  AND SUBM_TYPE_NAME = 'GeneralPermitSubmission');

-- /ICS_GNRL_PRMT/ICS_CMPL_TRACK_STAT
SET v_marker = 'INSERT INTO -- /ICS_GNRL_PRMT/ICS_CMPL_TRACK_STAT'; 
INSERT INTO ics_flow_icis.ICS_CMPL_TRACK_STAT
     SELECT ICS_CMPL_TRACK_STAT.*
       FROM ICS_CMPL_TRACK_STAT
          JOIN ICS_GNRL_PRMT
            ON ICS_CMPL_TRACK_STAT.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
       WHERE ICS_GNRL_PRMT.TRANSACTION_TYPE NOT IN ('D','X')
        AND KEY_HASH IN 
              (SELECT KEY_HASH
                 FROM ICS_SUBM_RESULTS
                WHERE RESULT_TYPE_CODE IN ('Accepted','Warning')
                  AND SUBM_TYPE_NAME = 'GeneralPermitSubmission');

-- /ICS_GNRL_PRMT/ICS_CONTACT
SET v_marker = 'INSERT INTO -- /ICS_GNRL_PRMT/ICS_CONTACT'; 
INSERT INTO ics_flow_icis.ICS_CONTACT
     SELECT ICS_CONTACT.*
       FROM ICS_CONTACT
          JOIN ICS_GNRL_PRMT
            ON ICS_CONTACT.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
       WHERE ICS_GNRL_PRMT.TRANSACTION_TYPE NOT IN ('D','X')
        AND KEY_HASH IN 
              (SELECT KEY_HASH
                 FROM ICS_SUBM_RESULTS
                WHERE RESULT_TYPE_CODE IN ('Accepted','Warning')
                  AND SUBM_TYPE_NAME = 'GeneralPermitSubmission');

-- /ICS_GNRL_PRMT/ICS_CONTACT/ICS_TELEPH
SET v_marker = 'INSERT INTO -- /ICS_GNRL_PRMT/ICS_CONTACT/ICS_TELEPH'; 
INSERT INTO ics_flow_icis.ICS_TELEPH
     SELECT ICS_TELEPH.*
       FROM ICS_TELEPH
          JOIN ICS_CONTACT
            ON ICS_TELEPH.ICS_CONTACT_ID = ICS_CONTACT.ICS_CONTACT_ID
          JOIN ICS_GNRL_PRMT
            ON ICS_CONTACT.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
       WHERE ICS_GNRL_PRMT.TRANSACTION_TYPE NOT IN ('D','X')
        AND KEY_HASH IN 
              (SELECT KEY_HASH
                 FROM ICS_SUBM_RESULTS
                WHERE RESULT_TYPE_CODE IN ('Accepted','Warning')
                  AND SUBM_TYPE_NAME = 'GeneralPermitSubmission');

-- /ICS_GNRL_PRMT/ICS_EFFLU_GUIDE
SET v_marker = 'INSERT INTO -- /ICS_GNRL_PRMT/ICS_EFFLU_GUIDE'; 
INSERT INTO ics_flow_icis.ICS_EFFLU_GUIDE
     SELECT ICS_EFFLU_GUIDE.*
       FROM ICS_EFFLU_GUIDE
          JOIN ICS_GNRL_PRMT
            ON ICS_EFFLU_GUIDE.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
       WHERE ICS_GNRL_PRMT.TRANSACTION_TYPE NOT IN ('D','X')
        AND KEY_HASH IN 
              (SELECT KEY_HASH
                 FROM ICS_SUBM_RESULTS
                WHERE RESULT_TYPE_CODE IN ('Accepted','Warning')
                  AND SUBM_TYPE_NAME = 'GeneralPermitSubmission');

-- /ICS_GNRL_PRMT/ICS_FAC
SET v_marker = 'INSERT INTO -- /ICS_GNRL_PRMT/ICS_FAC'; 
INSERT INTO ics_flow_icis.ICS_FAC
     SELECT ICS_FAC.*
       FROM ICS_FAC
          JOIN ICS_GNRL_PRMT
            ON ICS_FAC.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
       WHERE ICS_GNRL_PRMT.TRANSACTION_TYPE NOT IN ('D','X')
        AND KEY_HASH IN 
              (SELECT KEY_HASH
                 FROM ICS_SUBM_RESULTS
                WHERE RESULT_TYPE_CODE IN ('Accepted','Warning')
                  AND SUBM_TYPE_NAME = 'GeneralPermitSubmission');

-- /ICS_GNRL_PRMT/ICS_FAC/ICS_ADDR
SET v_marker = 'INSERT INTO -- /ICS_GNRL_PRMT/ICS_FAC/ICS_ADDR'; 
INSERT INTO ics_flow_icis.ICS_ADDR
     SELECT ICS_ADDR.*
       FROM ICS_ADDR
          JOIN ICS_FAC
            ON ICS_ADDR.ICS_FAC_ID = ICS_FAC.ICS_FAC_ID
          JOIN ICS_GNRL_PRMT
            ON ICS_FAC.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
       WHERE ICS_GNRL_PRMT.TRANSACTION_TYPE NOT IN ('D','X')
        AND KEY_HASH IN 
              (SELECT KEY_HASH
                 FROM ICS_SUBM_RESULTS
                WHERE RESULT_TYPE_CODE IN ('Accepted','Warning')
                  AND SUBM_TYPE_NAME = 'GeneralPermitSubmission');

-- /ICS_GNRL_PRMT/ICS_FAC/ICS_ADDR/ICS_TELEPH
SET v_marker = 'INSERT INTO -- /ICS_GNRL_PRMT/ICS_FAC/ICS_ADDR/ICS_TELEPH'; 
INSERT INTO ics_flow_icis.ICS_TELEPH
     SELECT ICS_TELEPH.*
       FROM ICS_TELEPH
          JOIN ICS_ADDR
            ON ICS_TELEPH.ICS_ADDR_ID = ICS_ADDR.ICS_ADDR_ID
          JOIN ICS_FAC
            ON ICS_ADDR.ICS_FAC_ID = ICS_FAC.ICS_FAC_ID
          JOIN ICS_GNRL_PRMT
            ON ICS_FAC.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
       WHERE ICS_GNRL_PRMT.TRANSACTION_TYPE NOT IN ('D','X')
        AND KEY_HASH IN 
              (SELECT KEY_HASH
                 FROM ICS_SUBM_RESULTS
                WHERE RESULT_TYPE_CODE IN ('Accepted','Warning')
                  AND SUBM_TYPE_NAME = 'GeneralPermitSubmission');

-- /ICS_GNRL_PRMT/ICS_FAC/ICS_CONTACT
SET v_marker = 'INSERT INTO -- /ICS_GNRL_PRMT/ICS_FAC/ICS_CONTACT'; 
INSERT INTO ics_flow_icis.ICS_CONTACT
     SELECT ICS_CONTACT.*
       FROM ICS_CONTACT
          JOIN ICS_FAC
            ON ICS_CONTACT.ICS_FAC_ID = ICS_FAC.ICS_FAC_ID
          JOIN ICS_GNRL_PRMT
            ON ICS_FAC.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
       WHERE ICS_GNRL_PRMT.TRANSACTION_TYPE NOT IN ('D','X')
        AND KEY_HASH IN 
              (SELECT KEY_HASH
                 FROM ICS_SUBM_RESULTS
                WHERE RESULT_TYPE_CODE IN ('Accepted','Warning')
                  AND SUBM_TYPE_NAME = 'GeneralPermitSubmission');

-- /ICS_GNRL_PRMT/ICS_FAC/ICS_CONTACT/ICS_TELEPH
SET v_marker = 'INSERT INTO -- /ICS_GNRL_PRMT/ICS_FAC/ICS_CONTACT/ICS_TELEPH'; 
INSERT INTO ics_flow_icis.ICS_TELEPH
     SELECT ICS_TELEPH.*
       FROM ICS_TELEPH
          JOIN ICS_CONTACT
            ON ICS_TELEPH.ICS_CONTACT_ID = ICS_CONTACT.ICS_CONTACT_ID
          JOIN ICS_FAC
            ON ICS_CONTACT.ICS_FAC_ID = ICS_FAC.ICS_FAC_ID
          JOIN ICS_GNRL_PRMT
            ON ICS_FAC.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
       WHERE ICS_GNRL_PRMT.TRANSACTION_TYPE NOT IN ('D','X')
        AND KEY_HASH IN 
              (SELECT KEY_HASH
                 FROM ICS_SUBM_RESULTS
                WHERE RESULT_TYPE_CODE IN ('Accepted','Warning')
                  AND SUBM_TYPE_NAME = 'GeneralPermitSubmission');

-- /ICS_GNRL_PRMT/ICS_FAC/ICS_FAC_CLASS
SET v_marker = 'INSERT INTO -- /ICS_GNRL_PRMT/ICS_FAC/ICS_FAC_CLASS'; 
INSERT INTO ics_flow_icis.ICS_FAC_CLASS
     SELECT ICS_FAC_CLASS.*
       FROM ICS_FAC_CLASS
          JOIN ICS_FAC
            ON ICS_FAC_CLASS.ICS_FAC_ID = ICS_FAC.ICS_FAC_ID
          JOIN ICS_GNRL_PRMT
            ON ICS_FAC.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
       WHERE ICS_GNRL_PRMT.TRANSACTION_TYPE NOT IN ('D','X')
        AND KEY_HASH IN 
              (SELECT KEY_HASH
                 FROM ICS_SUBM_RESULTS
                WHERE RESULT_TYPE_CODE IN ('Accepted','Warning')
                  AND SUBM_TYPE_NAME = 'GeneralPermitSubmission');

-- /ICS_GNRL_PRMT/ICS_FAC/ICS_GEO_COORD
SET v_marker = 'INSERT INTO -- /ICS_GNRL_PRMT/ICS_FAC/ICS_GEO_COORD'; 
INSERT INTO ics_flow_icis.ICS_GEO_COORD
     SELECT ICS_GEO_COORD.*
       FROM ICS_GEO_COORD
          JOIN ICS_FAC
            ON ICS_GEO_COORD.ICS_FAC_ID = ICS_FAC.ICS_FAC_ID
          JOIN ICS_GNRL_PRMT
            ON ICS_FAC.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
       WHERE ICS_GNRL_PRMT.TRANSACTION_TYPE NOT IN ('D','X')
        AND KEY_HASH IN 
              (SELECT KEY_HASH
                 FROM ICS_SUBM_RESULTS
                WHERE RESULT_TYPE_CODE IN ('Accepted','Warning')
                  AND SUBM_TYPE_NAME = 'GeneralPermitSubmission');

-- /ICS_GNRL_PRMT/ICS_FAC/ICS_NAICS_CODE
SET v_marker = 'INSERT INTO -- /ICS_GNRL_PRMT/ICS_FAC/ICS_NAICS_CODE'; 
INSERT INTO ics_flow_icis.ICS_NAICS_CODE
     SELECT ICS_NAICS_CODE.*
       FROM ICS_NAICS_CODE
          JOIN ICS_FAC
            ON ICS_NAICS_CODE.ICS_FAC_ID = ICS_FAC.ICS_FAC_ID
          JOIN ICS_GNRL_PRMT
            ON ICS_FAC.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
       WHERE ICS_GNRL_PRMT.TRANSACTION_TYPE NOT IN ('D','X')
        AND KEY_HASH IN 
              (SELECT KEY_HASH
                 FROM ICS_SUBM_RESULTS
                WHERE RESULT_TYPE_CODE IN ('Accepted','Warning')
                  AND SUBM_TYPE_NAME = 'GeneralPermitSubmission');

-- /ICS_GNRL_PRMT/ICS_FAC/ICS_ORIG_PROGS
SET v_marker = 'INSERT INTO -- /ICS_GNRL_PRMT/ICS_FAC/ICS_ORIG_PROGS'; 
INSERT INTO ics_flow_icis.ICS_ORIG_PROGS
     SELECT ICS_ORIG_PROGS.*
       FROM ICS_ORIG_PROGS
          JOIN ICS_FAC
            ON ICS_ORIG_PROGS.ICS_FAC_ID = ICS_FAC.ICS_FAC_ID
          JOIN ICS_GNRL_PRMT
            ON ICS_FAC.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
       WHERE ICS_GNRL_PRMT.TRANSACTION_TYPE NOT IN ('D','X')
        AND KEY_HASH IN 
              (SELECT KEY_HASH
                 FROM ICS_SUBM_RESULTS
                WHERE RESULT_TYPE_CODE IN ('Accepted','Warning')
                  AND SUBM_TYPE_NAME = 'GeneralPermitSubmission');

-- /ICS_GNRL_PRMT/ICS_FAC/ICS_PLCY
SET v_marker = 'INSERT INTO -- /ICS_GNRL_PRMT/ICS_FAC/ICS_PLCY'; 
INSERT INTO ics_flow_icis.ICS_PLCY
     SELECT ICS_PLCY.*
       FROM ICS_PLCY
          JOIN ICS_FAC
            ON ICS_PLCY.ICS_FAC_ID = ICS_FAC.ICS_FAC_ID
          JOIN ICS_GNRL_PRMT
            ON ICS_FAC.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
       WHERE ICS_GNRL_PRMT.TRANSACTION_TYPE NOT IN ('D','X')
        AND KEY_HASH IN 
              (SELECT KEY_HASH
                 FROM ICS_SUBM_RESULTS
                WHERE RESULT_TYPE_CODE IN ('Accepted','Warning')
                  AND SUBM_TYPE_NAME = 'GeneralPermitSubmission');

-- /ICS_GNRL_PRMT/ICS_FAC/ICS_SIC_CODE
SET v_marker = 'INSERT INTO -- /ICS_GNRL_PRMT/ICS_FAC/ICS_SIC_CODE'; 
INSERT INTO ics_flow_icis.ICS_SIC_CODE
     SELECT ICS_SIC_CODE.*
       FROM ICS_SIC_CODE
          JOIN ICS_FAC
            ON ICS_SIC_CODE.ICS_FAC_ID = ICS_FAC.ICS_FAC_ID
          JOIN ICS_GNRL_PRMT
            ON ICS_FAC.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
       WHERE ICS_GNRL_PRMT.TRANSACTION_TYPE NOT IN ('D','X')
        AND KEY_HASH IN 
              (SELECT KEY_HASH
                 FROM ICS_SUBM_RESULTS
                WHERE RESULT_TYPE_CODE IN ('Accepted','Warning')
                  AND SUBM_TYPE_NAME = 'GeneralPermitSubmission');

-- /ICS_GNRL_PRMT/ICS_NAICS_CODE
SET v_marker = 'INSERT INTO -- /ICS_GNRL_PRMT/ICS_NAICS_CODE'; 
INSERT INTO ics_flow_icis.ICS_NAICS_CODE
     SELECT ICS_NAICS_CODE.*
       FROM ICS_NAICS_CODE
          JOIN ICS_GNRL_PRMT
            ON ICS_NAICS_CODE.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
       WHERE ICS_GNRL_PRMT.TRANSACTION_TYPE NOT IN ('D','X')
        AND KEY_HASH IN 
              (SELECT KEY_HASH
                 FROM ICS_SUBM_RESULTS
                WHERE RESULT_TYPE_CODE IN ('Accepted','Warning')
                  AND SUBM_TYPE_NAME = 'GeneralPermitSubmission');

-- /ICS_GNRL_PRMT/ICS_OTHR_PRMTS
SET v_marker = 'INSERT INTO -- /ICS_GNRL_PRMT/ICS_OTHR_PRMTS'; 
INSERT INTO ics_flow_icis.ICS_OTHR_PRMTS
     SELECT ICS_OTHR_PRMTS.*
       FROM ICS_OTHR_PRMTS
          JOIN ICS_GNRL_PRMT
            ON ICS_OTHR_PRMTS.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
       WHERE ICS_GNRL_PRMT.TRANSACTION_TYPE NOT IN ('D','X')
        AND KEY_HASH IN 
              (SELECT KEY_HASH
                 FROM ICS_SUBM_RESULTS
                WHERE RESULT_TYPE_CODE IN ('Accepted','Warning')
                  AND SUBM_TYPE_NAME = 'GeneralPermitSubmission');

-- /ICS_GNRL_PRMT/ICS_SIC_CODE
SET v_marker = 'INSERT INTO -- /ICS_GNRL_PRMT/ICS_SIC_CODE'; 
INSERT INTO ics_flow_icis.ICS_SIC_CODE
     SELECT ICS_SIC_CODE.*
       FROM ICS_SIC_CODE
          JOIN ICS_GNRL_PRMT
            ON ICS_SIC_CODE.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
       WHERE ICS_GNRL_PRMT.TRANSACTION_TYPE NOT IN ('D','X')
        AND KEY_HASH IN 
              (SELECT KEY_HASH
                 FROM ICS_SUBM_RESULTS
                WHERE RESULT_TYPE_CODE IN ('Accepted','Warning')
                  AND SUBM_TYPE_NAME = 'GeneralPermitSubmission');
   -- -------------- --
   --  END PROCEDURE --
   -- -------------- --
   SET v_marker = 'CALL ics_etl_log_sp END';
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_sp_name     -- pi_marker
      ,NULL          -- pi_tgt_tbl
      ,NULL          -- pi_src_tbl 
      ,v_startdtm    -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'COMPLETED'   -- pi_process
      ,0);           -- pi_value
   --
   SET po_status = 1;
   SET po_errm   = '';
   -- 
END         