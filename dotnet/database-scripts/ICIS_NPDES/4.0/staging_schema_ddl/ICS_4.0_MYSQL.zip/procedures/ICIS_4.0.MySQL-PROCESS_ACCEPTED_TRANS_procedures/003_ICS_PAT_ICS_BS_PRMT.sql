DROP PROCEDURE IF EXISTS ics_pat_ics_bs_prmt;
CREATE PROCEDURE ics_pat_ics_bs_prmt
   (IN  pi_transaction_id  VARCHAR(40)
   ,OUT po_status INT
   ,OUT po_errm   VARCHAR(255))
BEGIN
/******************************************************************************
** Object Name: ics_pat_ics_bs_prmt
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  1) Process ICS_BS_PRMT
**                  called by: ics_process_accepted_trans
**
** Revision History:
** ----------------------------------------------------------------------------
**  Date         Name        Description
** ----------------------------------------------------------------------------
** 20121102      JenGo       Converted from Oracle to MySQL.
**                           Modularized SP, added logging and error-handling
**                           called by: ICS_PROCESS_ACCEPTED_TRANS
** 20121106      JenGo       Modified DELETE FROM ics_flow_icis.ICS_BS_PRMT
**                           MySQL errors out when the table being deleted is 
**                           used in the subquery.  To get around this either
**                           create a temp table or enclose the subquery in an
**                           inline view. 
*******************************************************************************/
   DECLARE v_startdtm
          ,v_enddtm     DATETIME;
   DECLARE v_sp_name    VARCHAR(64)  DEFAULT 'ics_pat_ics_bs_prmt';
   DECLARE v_errstat    INT DEFAULT 1;
   DECLARE v_errm       VARCHAR(255);
   DECLARE v_marker     VARCHAR(255);
   --
   DECLARE EXIT HANDLER FOR SQLEXCEPTION
      BEGIN  
         ROLLBACK;
         SET po_status = -1;
         SET po_errm   = v_marker;
         CALL ics_etl_log_sp    
            (v_sp_name          -- pi_sp_name
            ,v_marker           -- pi_marker
            ,NULL               -- pi_tgt_tbl
            ,NULL               -- pi_src_tbl
            ,v_startdtm         -- pi_startdtm
            ,NOW()              -- pi_enddtm
            ,'FAILED'           -- pi_process
            ,-1);               -- pi_value
         COMMIT;
      END;
   --
   SET v_startdtm = NOW();
-- Remove any old records for ICS_BS_PRMT
-- /ICS_BS_PRMT/ICS_ADDR/ICS_TELEPH
SET v_marker = 'DELETE FROM -- /ICS_BS_PRMT/ICS_ADDR/ICS_TELEPH'; 
DELETE
  FROM ics_flow_icis.ICS_TELEPH
 WHERE ICS_TELEPH.ICS_ADDR_ID IN
          (SELECT ICS_ADDR.ICS_ADDR_ID
             FROM ics_flow_icis.ICS_BS_PRMT
                 LEFT JOIN ICS_SUBM_RESULTS ON ICS_SUBM_RESULTS.KEY_HASH = ICS_BS_PRMT.KEY_HASH 
                  JOIN ics_flow_icis.ICS_ADDR ON ICS_ADDR.ICS_BS_PRMT_ID = ICS_BS_PRMT.ICS_BS_PRMT_ID
              WHERE (RESULT_TYPE_CODE IN ('Accepted','Warning') AND SUBM_TYPE_NAME = 'BiosolidsPermitSubmission')
                 OR ICS_BS_PRMT.PRMT_IDENT IN (SELECT PRMT_IDENT FROM ICS_SUBM_RESULTS WHERE SUBM_TYPE_NAME = 'PermitTerminationSubmission' AND RESULT_TYPE_CODE = 'Accepted')
);
-- /ICS_BS_PRMT/ICS_CONTACT/ICS_TELEPH
SET v_marker = 'DELETE FROM -- /ICS_BS_PRMT/ICS_CONTACT/ICS_TELEPH'; 
DELETE
  FROM ics_flow_icis.ICS_TELEPH
 WHERE ICS_TELEPH.ICS_CONTACT_ID IN
          (SELECT ICS_CONTACT.ICS_CONTACT_ID
             FROM ics_flow_icis.ICS_BS_PRMT
                 LEFT JOIN ICS_SUBM_RESULTS ON ICS_SUBM_RESULTS.KEY_HASH = ICS_BS_PRMT.KEY_HASH 
                  JOIN ics_flow_icis.ICS_CONTACT ON ICS_CONTACT.ICS_BS_PRMT_ID = ICS_BS_PRMT.ICS_BS_PRMT_ID
              WHERE (RESULT_TYPE_CODE IN ('Accepted','Warning') AND SUBM_TYPE_NAME = 'BiosolidsPermitSubmission')
                 OR ICS_BS_PRMT.PRMT_IDENT IN (SELECT PRMT_IDENT FROM ICS_SUBM_RESULTS WHERE SUBM_TYPE_NAME = 'PermitTerminationSubmission' AND RESULT_TYPE_CODE = 'Accepted')
);
-- /ICS_BS_PRMT/ICS_ADDR
SET v_marker = 'DELETE FROM -- /ICS_BS_PRMT/ICS_ADDR'; 
DELETE
  FROM ics_flow_icis.ICS_ADDR
 WHERE ICS_ADDR.ICS_BS_PRMT_ID IN
          (SELECT ICS_BS_PRMT.ICS_BS_PRMT_ID
             FROM ics_flow_icis.ICS_BS_PRMT
                 LEFT JOIN ICS_SUBM_RESULTS ON ICS_SUBM_RESULTS.KEY_HASH = ICS_BS_PRMT.KEY_HASH 
              WHERE (RESULT_TYPE_CODE IN ('Accepted','Warning') AND SUBM_TYPE_NAME = 'BiosolidsPermitSubmission')
                 OR ICS_BS_PRMT.PRMT_IDENT IN (SELECT PRMT_IDENT FROM ICS_SUBM_RESULTS WHERE SUBM_TYPE_NAME = 'PermitTerminationSubmission' AND RESULT_TYPE_CODE = 'Accepted')
);
-- /ICS_BS_PRMT/ICS_BS_END_USE_DSPL_TYPE
SET v_marker = 'DELETE FROM -- /ICS_BS_PRMT/ICS_BS_END_USE_DSPL_TYPE'; 
DELETE
  FROM ics_flow_icis.ICS_BS_END_USE_DSPL_TYPE
 WHERE ICS_BS_END_USE_DSPL_TYPE.ICS_BS_PRMT_ID IN
          (SELECT ICS_BS_PRMT.ICS_BS_PRMT_ID
             FROM ics_flow_icis.ICS_BS_PRMT
                 LEFT JOIN ICS_SUBM_RESULTS ON ICS_SUBM_RESULTS.KEY_HASH = ICS_BS_PRMT.KEY_HASH 
              WHERE (RESULT_TYPE_CODE IN ('Accepted','Warning') AND SUBM_TYPE_NAME = 'BiosolidsPermitSubmission')
                 OR ICS_BS_PRMT.PRMT_IDENT IN (SELECT PRMT_IDENT FROM ICS_SUBM_RESULTS WHERE SUBM_TYPE_NAME = 'PermitTerminationSubmission' AND RESULT_TYPE_CODE = 'Accepted')
);
-- /ICS_BS_PRMT/ICS_BS_TYPE
SET v_marker = 'DELETE FROM -- /ICS_BS_PRMT/ICS_BS_TYPE'; 
DELETE
  FROM ics_flow_icis.ICS_BS_TYPE
 WHERE ICS_BS_TYPE.ICS_BS_PRMT_ID IN
          (SELECT ICS_BS_PRMT.ICS_BS_PRMT_ID
             FROM ics_flow_icis.ICS_BS_PRMT
                 LEFT JOIN ICS_SUBM_RESULTS ON ICS_SUBM_RESULTS.KEY_HASH = ICS_BS_PRMT.KEY_HASH 
              WHERE (RESULT_TYPE_CODE IN ('Accepted','Warning') AND SUBM_TYPE_NAME = 'BiosolidsPermitSubmission')
                 OR ICS_BS_PRMT.PRMT_IDENT IN (SELECT PRMT_IDENT FROM ICS_SUBM_RESULTS WHERE SUBM_TYPE_NAME = 'PermitTerminationSubmission' AND RESULT_TYPE_CODE = 'Accepted')
);
-- /ICS_BS_PRMT/ICS_CONTACT
SET v_marker = 'DELETE FROM -- /ICS_BS_PRMT/ICS_CONTACT'; 
DELETE
  FROM ics_flow_icis.ICS_CONTACT
 WHERE ICS_CONTACT.ICS_BS_PRMT_ID IN
          (SELECT ICS_BS_PRMT.ICS_BS_PRMT_ID
             FROM ics_flow_icis.ICS_BS_PRMT
                 LEFT JOIN ICS_SUBM_RESULTS ON ICS_SUBM_RESULTS.KEY_HASH = ICS_BS_PRMT.KEY_HASH 
              WHERE (RESULT_TYPE_CODE IN ('Accepted','Warning') AND SUBM_TYPE_NAME = 'BiosolidsPermitSubmission')
                 OR ICS_BS_PRMT.PRMT_IDENT IN (SELECT PRMT_IDENT FROM ICS_SUBM_RESULTS WHERE SUBM_TYPE_NAME = 'PermitTerminationSubmission' AND RESULT_TYPE_CODE = 'Accepted')
);
-- jen: create an inline view inside the subquery, otherwise will get
-- this error: Lookup Error - MySQL Database Error: You can't specify
-- target table 'ICS_BASIC_PRMT' for update in FROM clause
-- /ICS_BS_PRMT
SET v_marker = 'DELETE FROM -- /ICS_BS_PRMT'; 
DELETE
  FROM ics_flow_icis.ICS_BS_PRMT
 WHERE ICS_BS_PRMT.ICS_BS_PRMT_ID IN
          (SELECT ICS_BS_PRMT_ID
             FROM (SELECT ICS_BS_PRMT.ICS_BS_PRMT_ID
                     FROM ics_flow_icis.ICS_BS_PRMT
                     LEFT JOIN ICS_SUBM_RESULTS 
                       ON ICS_SUBM_RESULTS.KEY_HASH = ICS_BS_PRMT.KEY_HASH 
                    WHERE (    RESULT_TYPE_CODE IN ('Accepted','Warning') 
                           AND SUBM_TYPE_NAME = 'BiosolidsPermitSubmission')
                       OR ICS_BS_PRMT.PRMT_IDENT IN (SELECT PRMT_IDENT 
                                                       FROM ICS_SUBM_RESULTS 
                                                      WHERE SUBM_TYPE_NAME = 'PermitTerminationSubmission' 
                                                        AND RESULT_TYPE_CODE = 'Accepted')
                  ) vw
);

-- Add accepted records for ICS_BS_PRMT
-- /ICS_BS_PRMT
SET v_marker = 'INSERT INTO -- /ICS_BS_PRMT'; 
INSERT INTO  ics_flow_icis.ICS_BS_PRMT
     SELECT ICS_BS_PRMT.*
       FROM ICS_BS_PRMT
       WHERE ICS_BS_PRMT.TRANSACTION_TYPE NOT IN ('D','X')
        AND KEY_HASH IN 
              (SELECT KEY_HASH
                 FROM ICS_SUBM_RESULTS
                WHERE RESULT_TYPE_CODE IN ('Accepted','Warning')
                  AND SUBM_TYPE_NAME = 'BiosolidsPermitSubmission');

-- /ICS_BS_PRMT/ICS_ADDR
SET v_marker = 'INSERT INTO -- /ICS_BS_PRMT/ICS_ADDR';  
INSERT INTO  ics_flow_icis.ICS_ADDR
     SELECT ICS_ADDR.*
       FROM ICS_ADDR
          JOIN ICS_BS_PRMT
            ON ICS_ADDR.ICS_BS_PRMT_ID = ICS_BS_PRMT.ICS_BS_PRMT_ID
       WHERE ICS_BS_PRMT.TRANSACTION_TYPE NOT IN ('D','X')
        AND KEY_HASH IN 
              (SELECT KEY_HASH
                 FROM ICS_SUBM_RESULTS
                WHERE RESULT_TYPE_CODE IN ('Accepted','Warning')
                  AND SUBM_TYPE_NAME = 'BiosolidsPermitSubmission');

-- /ICS_BS_PRMT/ICS_ADDR/ICS_TELEPH
SET v_marker = 'INSERT INTO -- /ICS_BS_PRMT/ICS_ADDR/ICS_TELEPH';  
INSERT INTO  ics_flow_icis.ICS_TELEPH
     SELECT ICS_TELEPH.*
       FROM ICS_TELEPH
          JOIN ICS_ADDR
            ON ICS_TELEPH.ICS_ADDR_ID = ICS_ADDR.ICS_ADDR_ID
          JOIN ICS_BS_PRMT
            ON ICS_ADDR.ICS_BS_PRMT_ID = ICS_BS_PRMT.ICS_BS_PRMT_ID
       WHERE ICS_BS_PRMT.TRANSACTION_TYPE NOT IN ('D','X')
        AND KEY_HASH IN 
              (SELECT KEY_HASH
                 FROM ICS_SUBM_RESULTS
                WHERE RESULT_TYPE_CODE IN ('Accepted','Warning')
                  AND SUBM_TYPE_NAME = 'BiosolidsPermitSubmission');

-- /ICS_BS_PRMT/ICS_BS_END_USE_DSPL_TYPE
SET v_marker = 'INSERT INTO -- /ICS_BS_PRMT/ICS_BS_END_USE_DSPL_TYPE';  
INSERT INTO  ics_flow_icis.ICS_BS_END_USE_DSPL_TYPE
     SELECT ICS_BS_END_USE_DSPL_TYPE.*
       FROM ICS_BS_END_USE_DSPL_TYPE
          JOIN ICS_BS_PRMT
            ON ICS_BS_END_USE_DSPL_TYPE.ICS_BS_PRMT_ID = ICS_BS_PRMT.ICS_BS_PRMT_ID
       WHERE ICS_BS_PRMT.TRANSACTION_TYPE NOT IN ('D','X')
        AND KEY_HASH IN 
              (SELECT KEY_HASH
                 FROM ICS_SUBM_RESULTS
                WHERE RESULT_TYPE_CODE IN ('Accepted','Warning')
                  AND SUBM_TYPE_NAME = 'BiosolidsPermitSubmission');

-- /ICS_BS_PRMT/ICS_BS_TYPE
SET v_marker = 'INSERT INTO -- /ICS_BS_PRMT/ICS_BS_TYPE'; 
INSERT INTO  ics_flow_icis.ICS_BS_TYPE
     SELECT ICS_BS_TYPE.*
       FROM ICS_BS_TYPE
          JOIN ICS_BS_PRMT
            ON ICS_BS_TYPE.ICS_BS_PRMT_ID = ICS_BS_PRMT.ICS_BS_PRMT_ID
       WHERE ICS_BS_PRMT.TRANSACTION_TYPE NOT IN ('D','X')
        AND KEY_HASH IN 
              (SELECT KEY_HASH
                 FROM ICS_SUBM_RESULTS
                WHERE RESULT_TYPE_CODE IN ('Accepted','Warning')
                  AND SUBM_TYPE_NAME = 'BiosolidsPermitSubmission');

-- /ICS_BS_PRMT/ICS_CONTACT
SET v_marker = 'INSERT INTO -- /ICS_BS_PRMT/ICS_CONTACT';  
INSERT INTO  ics_flow_icis.ICS_CONTACT
     SELECT ICS_CONTACT.*
       FROM ICS_CONTACT
          JOIN ICS_BS_PRMT
            ON ICS_CONTACT.ICS_BS_PRMT_ID = ICS_BS_PRMT.ICS_BS_PRMT_ID
       WHERE ICS_BS_PRMT.TRANSACTION_TYPE NOT IN ('D','X')
        AND KEY_HASH IN 
              (SELECT KEY_HASH
                 FROM ICS_SUBM_RESULTS
                WHERE RESULT_TYPE_CODE IN ('Accepted','Warning')
                  AND SUBM_TYPE_NAME = 'BiosolidsPermitSubmission');

-- /ICS_BS_PRMT/ICS_CONTACT/ICS_TELEPH
SET v_marker = 'INSERT INTO -- /ICS_BS_PRMT/ICS_CONTACT/ICS_TELEPH';  
INSERT INTO  ics_flow_icis.ICS_TELEPH
     SELECT ICS_TELEPH.*
       FROM ICS_TELEPH
          JOIN ICS_CONTACT
            ON ICS_TELEPH.ICS_CONTACT_ID = ICS_CONTACT.ICS_CONTACT_ID
          JOIN ICS_BS_PRMT
            ON ICS_CONTACT.ICS_BS_PRMT_ID = ICS_BS_PRMT.ICS_BS_PRMT_ID
       WHERE ICS_BS_PRMT.TRANSACTION_TYPE NOT IN ('D','X')
        AND KEY_HASH IN 
              (SELECT KEY_HASH
                 FROM ICS_SUBM_RESULTS
                WHERE RESULT_TYPE_CODE IN ('Accepted','Warning')
                  AND SUBM_TYPE_NAME = 'BiosolidsPermitSubmission');
   -- -------------- --
   --  END PROCEDURE --
   -- -------------- --
   SET v_marker = 'CALL ics_etl_log_sp END';
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_sp_name     -- pi_marker
      ,NULL          -- pi_tgt_tbl
      ,NULL          -- pi_src_tbl 
      ,v_startdtm    -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'COMPLETED'   -- pi_process
      ,0);           -- pi_value
   --
   SET po_status = 1;
   SET po_errm   = '';
   -- 
END