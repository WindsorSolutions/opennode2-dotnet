DROP PROCEDURE IF EXISTS ics_cd_create_cdv_tables;
CREATE PROCEDURE ics_cd_create_cdv_tables
   (IN  pi_tbl_prefix  VARCHAR(3)
   ,OUT po_status INT
   ,OUT po_errm   VARCHAR(255))
BEGIN
/******************************************************************************
** ObjectName: ics_cd_create_cdv_tables
**
** Author: Windsor Solutions, Inc.
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure will detect data changes made within the ICIS 
**               schema and then sets the transaction type flags so the data 
**               can be bundled and submitted to an exchange partner.
**
** Inputs:  -- NA --  
**
**
** Revision History:      
** ----------------------------------------------------------------------------
**  Date         Analyst     Description
** ----------------------------------------------------------------------------
** 08/15/2012    BRensmith   Baseline from v3.1 procedure.
**
** 10/29/2012    Jen Go      Converted from Oracle to MySQL
**                           from:  prod-node-db\ICIS\4.0\db_scripts\Oracle\views
**                           Use physical tables instead of views because MySQL
**                           doesn't allow inline views within views.
**                           called by: ics_change_detection
**                             1) ics_cd_create_cdv_tables
**                             2) ics_cd_updt_ics_tables
**                             3) ics_cd_process_datahash
**                             4) ics_cd_process_ics_tbls
******************************************************************************/
   DECLARE v_startdtm   DATETIME     DEFAULT NOW();
   DECLARE v_startdtm2
          ,v_enddtm     DATETIME;
   DECLARE v_marker     VARCHAR(255);
   DECLARE v_sp_name    VARCHAR(64)  DEFAULT 'ics_cd_create_cdv_tables';
   DECLARE v_tgt_tbl
          ,v_src_tbl    VARCHAR(64);
   DECLARE v_rowcount   INT          DEFAULT 0;
   --
   DECLARE EXIT HANDLER FOR SQLEXCEPTION
      BEGIN  
         -- ROLLBACK;
         SET po_status = -1;
         SET po_errm   = v_marker;
         CALL ics_etl_log_sp    
            (v_sp_name          -- pi_sp_name
            ,v_marker           -- pi_marker
            ,v_tgt_tbl          -- pi_tgt_tbl
            ,v_src_tbl          -- pi_src_tbl
            ,v_startdtm         -- pi_startdtm
            ,NOW()              -- pi_enddtm
            ,'FAILED'           -- pi_process
            ,-1);               -- pi_value
      END;
   IF pi_tbl_prefix = 'CDV' THEN
   -- --------------
   -- CDV_BASIC_PRMT
   -- --------------
   SET v_startdtm2 = NOW();
   SET v_marker    = 'DROP AND CREATE TABLE CDV_BASIC_PRMT';
   SET v_tgt_tbl   = 'CDV_BASIC_PRMT';
   SET v_src_tbl   = 'ICS_BASIC_PRMT';
   DROP TABLE IF EXISTS CDV_BASIC_PRMT;
   CREATE TABLE CDV_BASIC_PRMT
   ENGINE=MyISAM CHARACTER SET utf8
   AS 
   SELECT DISTINCT ICS_MODULE
         ,ICS_BASIC_PRMT.KEY_HASH
         ,CASE ICS_BASIC_PRMT.ACTION_TYPE
          WHEN 'DELETE' THEN 
             (SELECT KEY_HASH
                FROM ics_flow_icis.ICS_BASIC_PRMT TBL
               WHERE TBL.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID)
          ELSE 
             (SELECT KEY_HASH 
                FROM ICS_BASIC_PRMT TBL
               WHERE TBL.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID)
          END AS MODULE_IDENT
         , ICS_BASIC_PRMT.DATA_ELEMENT
         , ICS_BASIC_PRMT.ACTION_TYPE
         , ICS_BASIC_PRMT.ACTION_CODE
      FROM (/*  1 - NEW  */
            SELECT ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID
			           , ICS_BASIC_PRMT.KEY_HASH
                 , 'NEW' AS ACTION_TYPE
                 , 1 AS ACTION_CODE
                 , 'ICS_BASIC_PRMT' AS ICS_MODULE
                 , 'ICS_BASIC_PRMT' AS DATA_ELEMENT
             FROM ICS_BASIC_PRMT
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_BASIC_PRMT TBL
                               WHERE TBL.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH)
           UNION 
           /*  2 - CHANGE  */
           SELECT LOCAL.ICS_BASIC_PRMT_ID
                , LOCAL.KEY_HASH
                , 'CHANGE' AS ACTION_TYPE
                , 2 AS ACTION_CODE
                , 'ICS_BASIC_PRMT' AS ICS_MODULE
                , 'ICS_BASIC_PRMT' AS DATA_ELEMENT
             FROM ICS_BASIC_PRMT LOCAL
             JOIN ics_flow_icis.ICS_BASIC_PRMT ICIS
               ON (ICIS.KEY_HASH = LOCAL.KEY_HASH)
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_BASIC_PRMT 
                               WHERE ICS_BASIC_PRMT.DATA_HASH = LOCAL.DATA_HASH)  
           UNION
           /*  3 - DELETE  */
           SELECT ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID
                , ICS_BASIC_PRMT.KEY_HASH
                , 'DELETE' AS ACTION
                , 3 AS ACTION_CODE
                , 'ICS_BASIC_PRMT' AS ICS_MODULE
                , 'ICS_BASIC_PRMT' AS DATA_ELEMENT
             FROM ics_flow_icis.ICS_BASIC_PRMT
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ICS_BASIC_PRMT TBL
                               WHERE TBL.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH)) ICS_BASIC_PRMT;
   --
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'CTAS'        -- pi_process
      ,1);           -- pi_value
   -- -----------
   -- cdv_bs_prmt
   -- -----------
   SET v_startdtm2 = NOW();
   SET v_marker    = 'DROP AND CREATE TABLE CDV_BS_PRMT';
   SET v_tgt_tbl   = 'CDV_BS_PRMT';
   SET v_src_tbl   = 'ICS_BS_PRMT';
   DROP TABLE IF EXISTS CDV_BS_PRMT;
   CREATE TABLE CDV_BS_PRMT
   ENGINE=MyISAM CHARACTER SET utf8
   AS 
   SELECT DISTINCT ICS_MODULE
         ,ICS_BS_PRMT.KEY_HASH
         ,CASE ICS_BS_PRMT.ACTION_TYPE
          WHEN 'DELETE' THEN 
             (SELECT KEY_HASH
                FROM ics_flow_icis.ICS_BS_PRMT TBL
               WHERE TBL.ICS_BS_PRMT_ID = ICS_BS_PRMT.ICS_BS_PRMT_ID)
          ELSE 
             (SELECT KEY_HASH 
                FROM ICS_BS_PRMT TBL
               WHERE TBL.ICS_BS_PRMT_ID = ICS_BS_PRMT.ICS_BS_PRMT_ID)
          END AS MODULE_IDENT
        , ICS_BS_PRMT.DATA_ELEMENT
        , ICS_BS_PRMT.ACTION_TYPE
        , ICS_BS_PRMT.ACTION_CODE
     FROM (/*  1 - NEW  */
           SELECT ICS_BS_PRMT.ICS_BS_PRMT_ID
			          , ICS_BS_PRMT.KEY_HASH
                , 'NEW' AS ACTION_TYPE
                , 1 AS ACTION_CODE
                , 'ICS_BS_PRMT' AS ICS_MODULE
                , 'ICS_BS_PRMT' AS DATA_ELEMENT
             FROM ICS_BS_PRMT
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_BS_PRMT TBL
                               WHERE TBL.KEY_HASH = ICS_BS_PRMT.KEY_HASH)
           UNION
           /*  2 - CHANGE  */
           SELECT LOCAL.ICS_BS_PRMT_ID
                , LOCAL.KEY_HASH
                , 'CHANGE' AS ACTION_TYPE
                , 2 AS ACTION_CODE
                , 'ICS_BS_PRMT' AS ICS_MODULE
                , 'ICS_BS_PRMT' AS DATA_ELEMENT
             FROM ICS_BS_PRMT LOCAL
             JOIN ics_flow_icis.ICS_BS_PRMT ICIS
               ON (ICIS.KEY_HASH = LOCAL.KEY_HASH)
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_BS_PRMT 
                               WHERE ICS_BS_PRMT.DATA_HASH = LOCAL.DATA_HASH)  
           UNION
           /*  3 - DELETE  */
           SELECT ICS_BS_PRMT.ICS_BS_PRMT_ID
                , ICS_BS_PRMT.KEY_HASH
                , 'DELETE' AS ACTION
                , 3 AS ACTION_CODE
                , 'ICS_BS_PRMT' AS ICS_MODULE
                , 'ICS_BS_PRMT' AS DATA_ELEMENT
             FROM ics_flow_icis.ICS_BS_PRMT
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ICS_BS_PRMT TBL
                               WHERE TBL.KEY_HASH = ICS_BS_PRMT.KEY_HASH)) ICS_BS_PRMT;
   --
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'CTAS'        -- pi_process
      ,1);           -- pi_value
   -- -----------
   -- cdv_cafo_prmt
   -- -----------
   SET v_startdtm2 = NOW();
   SET v_marker    = 'DROP AND CREATE TABLE CDV_CAFO_PRMT';
   SET v_tgt_tbl   = 'CDV_CAFO_PRMT';
   SET v_src_tbl   = 'ICS_CAFO_PRMT';
   DROP TABLE IF EXISTS CDV_CAFO_PRMT;
   CREATE TABLE CDV_CAFO_PRMT 
   ENGINE=MyISAM CHARACTER SET utf8
   AS 
   SELECT DISTINCT ICS_MODULE
        , ICS_CAFO_PRMT.KEY_HASH
        , CASE ICS_CAFO_PRMT.ACTION_TYPE
          WHEN 'DELETE'
          THEN (SELECT KEY_HASH
                  FROM ics_flow_icis.ICS_CAFO_PRMT TBL
                 WHERE TBL.ICS_CAFO_PRMT_ID = ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID)
          ELSE (SELECT KEY_HASH 
                  FROM ICS_CAFO_PRMT TBL
                 WHERE TBL.ICS_CAFO_PRMT_ID = ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID)
          END AS MODULE_IDENT
        , ICS_CAFO_PRMT.DATA_ELEMENT
        , ICS_CAFO_PRMT.ACTION_TYPE
        , ICS_CAFO_PRMT.ACTION_CODE
     FROM (/*  1 - NEW  */
           SELECT ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID
			          , ICS_CAFO_PRMT.KEY_HASH
                , 'NEW' AS ACTION_TYPE
                , 1 AS ACTION_CODE
                , 'ICS_CAFO_PRMT' AS ICS_MODULE
                , 'ICS_CAFO_PRMT' AS DATA_ELEMENT
             FROM ICS_CAFO_PRMT
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_CAFO_PRMT TBL
                               WHERE TBL.KEY_HASH = ICS_CAFO_PRMT.KEY_HASH)
           UNION
           /*  2 - CHANGE  */
           SELECT LOCAL.ICS_CAFO_PRMT_ID
                , LOCAL.KEY_HASH
                , 'CHANGE' AS ACTION_TYPE
                , 2 AS ACTION_CODE
                , 'ICS_CAFO_PRMT' AS ICS_MODULE
                , 'ICS_CAFO_PRMT' AS DATA_ELEMENT
             FROM ICS_CAFO_PRMT LOCAL
             JOIN ics_flow_icis.ICS_CAFO_PRMT ICIS
               ON (ICIS.KEY_HASH = LOCAL.KEY_HASH)
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_CAFO_PRMT 
                               WHERE ICS_CAFO_PRMT.DATA_HASH = LOCAL.DATA_HASH)  
           UNION
           /*  3 - DELETE  */
           SELECT ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID
                , ICS_CAFO_PRMT.KEY_HASH
                , 'DELETE' AS ACTION
                , 3 AS ACTION_CODE
                , 'ICS_CAFO_PRMT' AS ICS_MODULE
                , 'ICS_CAFO_PRMT' AS DATA_ELEMENT
             FROM ics_flow_icis.ICS_CAFO_PRMT
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ICS_CAFO_PRMT TBL
                               WHERE TBL.KEY_HASH = ICS_CAFO_PRMT.KEY_HASH)) ICS_CAFO_PRMT;
   --
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'CTAS'        -- pi_process
      ,1);           -- pi_value
   -- -----------
   -- cdv_cso_prmt
   -- -----------
   SET v_startdtm2 = NOW();
   SET v_marker    = 'DROP AND CREATE TABLE CDV_CSO_PRMT';
   SET v_tgt_tbl   = 'CDV_CSO_PRMT';
   SET v_src_tbl   = 'ICS_CSO_PRMT';
   DROP TABLE IF EXISTS CDV_CSO_PRMT;
   CREATE TABLE CDV_CSO_PRMT 
   ENGINE=MyISAM CHARACTER SET utf8
   AS 
   SELECT DISTINCT ICS_MODULE
        , ICS_CSO_PRMT.KEY_HASH
        , CASE ICS_CSO_PRMT.ACTION_TYPE
            WHEN 'DELETE'
              THEN (SELECT KEY_HASH
                      FROM ics_flow_icis.ICS_CSO_PRMT TBL
                     WHERE TBL.ICS_CSO_PRMT_ID = ICS_CSO_PRMT.ICS_CSO_PRMT_ID)
              ELSE (SELECT KEY_HASH 
                      FROM ICS_CSO_PRMT TBL
                     WHERE TBL.ICS_CSO_PRMT_ID = ICS_CSO_PRMT.ICS_CSO_PRMT_ID)
          END AS MODULE_IDENT
        , ICS_CSO_PRMT.DATA_ELEMENT
        , ICS_CSO_PRMT.ACTION_TYPE
        , ICS_CSO_PRMT.ACTION_CODE
     FROM (/*  1 - NEW  */
           SELECT ICS_CSO_PRMT.ICS_CSO_PRMT_ID
			          , ICS_CSO_PRMT.KEY_HASH
                , 'NEW' AS ACTION_TYPE
                , 1 AS ACTION_CODE
                , 'ICS_CSO_PRMT' AS ICS_MODULE
                , 'ICS_CSO_PRMT' AS DATA_ELEMENT
             FROM ICS_CSO_PRMT
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_CSO_PRMT TBL
                               WHERE TBL.KEY_HASH = ICS_CSO_PRMT.KEY_HASH)
           UNION
           /*  2 - CHANGE  */
           SELECT LOCAL.ICS_CSO_PRMT_ID
                , LOCAL.KEY_HASH
                , 'CHANGE' AS ACTION_TYPE
                , 2 AS ACTION_CODE
                , 'ICS_CSO_PRMT' AS ICS_MODULE
                , 'ICS_CSO_PRMT' AS DATA_ELEMENT
             FROM ICS_CSO_PRMT LOCAL
             JOIN ics_flow_icis.ICS_CSO_PRMT ICIS
               ON (ICIS.KEY_HASH = LOCAL.KEY_HASH)
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_CSO_PRMT 
                               WHERE ICS_CSO_PRMT.DATA_HASH = LOCAL.DATA_HASH)  
           UNION
           /*  3 - DELETE  */
           SELECT ICS_CSO_PRMT.ICS_CSO_PRMT_ID
                , ICS_CSO_PRMT.KEY_HASH
                , 'DELETE' AS ACTION
                , 3 AS ACTION_CODE
                , 'ICS_CSO_PRMT' AS ICS_MODULE
                , 'ICS_CSO_PRMT' AS DATA_ELEMENT
             FROM ics_flow_icis.ICS_CSO_PRMT
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ICS_CSO_PRMT TBL
                               WHERE TBL.KEY_HASH = ICS_CSO_PRMT.KEY_HASH)) ICS_CSO_PRMT;
   --
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'CTAS'        -- pi_process
      ,1);           -- pi_value
   -- -----------
   -- cdv_cmpl_mon
   -- -----------
   SET v_startdtm2 = NOW();
   SET v_marker    = 'DROP AND CREATE TABLE CDV_CMPL_MON';
   SET v_tgt_tbl   = 'CDV_CMPL_MON';
   SET v_src_tbl   = 'ICS_CMPL_MON';
   DROP TABLE IF EXISTS CDV_CMPL_MON;
   CREATE TABLE CDV_CMPL_MON 
   ENGINE=MyISAM CHARACTER SET utf8
   AS 
   SELECT DISTINCT ICS_MODULE
        , ICS_CMPL_MON.KEY_HASH
        , CASE ICS_CMPL_MON.ACTION_TYPE
            WHEN 'DELETE'
              THEN (SELECT KEY_HASH
                      FROM ics_flow_icis.ICS_CMPL_MON TBL
                     WHERE TBL.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID)
              ELSE (SELECT KEY_HASH 
                      FROM ICS_CMPL_MON TBL
                     WHERE TBL.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID)
          END AS MODULE_IDENT
        , ICS_CMPL_MON.DATA_ELEMENT
        , ICS_CMPL_MON.ACTION_TYPE
        , ICS_CMPL_MON.ACTION_CODE
     FROM (/*  1 - NEW  */
           SELECT ICS_CMPL_MON.ICS_CMPL_MON_ID
			          , ICS_CMPL_MON.KEY_HASH
                , 'NEW' AS ACTION_TYPE
                , 1 AS ACTION_CODE
                , 'ICS_CMPL_MON' AS ICS_MODULE
                , 'ICS_CMPL_MON' AS DATA_ELEMENT
             FROM ICS_CMPL_MON
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_CMPL_MON TBL
                               WHERE TBL.KEY_HASH = ICS_CMPL_MON.KEY_HASH)
           UNION
           /*  2 - CHANGE  */
           SELECT LOCAL.ICS_CMPL_MON_ID
                , LOCAL.KEY_HASH
                , 'CHANGE' AS ACTION_TYPE
                , 2 AS ACTION_CODE
                , 'ICS_CMPL_MON' AS ICS_MODULE
                , 'ICS_CMPL_MON' AS DATA_ELEMENT
             FROM ICS_CMPL_MON LOCAL
             JOIN ics_flow_icis.ICS_CMPL_MON ICIS
               ON (ICIS.KEY_HASH = LOCAL.KEY_HASH)
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_CMPL_MON 
                               WHERE ICS_CMPL_MON.DATA_HASH = LOCAL.DATA_HASH)  
           UNION
           /*  3 - DELETE  */
           SELECT ICS_CMPL_MON.ICS_CMPL_MON_ID
                , ICS_CMPL_MON.KEY_HASH
                , 'DELETE' AS ACTION
                , 3 AS ACTION_CODE
                , 'ICS_CMPL_MON' AS ICS_MODULE
                , 'ICS_CMPL_MON' AS DATA_ELEMENT
             FROM ics_flow_icis.ICS_CMPL_MON
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ICS_CMPL_MON TBL
                               WHERE TBL.KEY_HASH = ICS_CMPL_MON.KEY_HASH)) ICS_CMPL_MON;
   --
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'CTAS'        -- pi_process
      ,1);           -- pi_value
   -- -----------
   -- cdv_gnrl_prmt
   -- -----------
   SET v_startdtm2 = NOW();
   SET v_marker    = 'DROP AND CREATE TABLE CDV_GNRL_PRMT';
   SET v_tgt_tbl   = 'CDV_GNRL_PRMT';
   SET v_src_tbl   = 'ICS_GNRL_PRMT';
   DROP TABLE IF EXISTS CDV_GNRL_PRMT;
   CREATE TABLE CDV_GNRL_PRMT 
   ENGINE=MyISAM CHARACTER SET utf8
   AS 
   SELECT DISTINCT ICS_MODULE
        , ICS_GNRL_PRMT.KEY_HASH
        , CASE ICS_GNRL_PRMT.ACTION_TYPE
            WHEN 'DELETE'
              THEN (SELECT KEY_HASH
                      FROM ics_flow_icis.ICS_GNRL_PRMT TBL
                     WHERE TBL.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID)
              ELSE (SELECT KEY_HASH 
                      FROM ICS_GNRL_PRMT TBL
                     WHERE TBL.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID)
          END AS MODULE_IDENT
        , ICS_GNRL_PRMT.DATA_ELEMENT
        , ICS_GNRL_PRMT.ACTION_TYPE
        , ICS_GNRL_PRMT.ACTION_CODE
     FROM (/*  1 - NEW  */
           SELECT ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
			          , ICS_GNRL_PRMT.KEY_HASH
                , 'NEW' AS ACTION_TYPE
                , 1 AS ACTION_CODE
                , 'ICS_GNRL_PRMT' AS ICS_MODULE
                , 'ICS_GNRL_PRMT' AS DATA_ELEMENT
             FROM ICS_GNRL_PRMT
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_GNRL_PRMT TBL
                               WHERE TBL.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH)
           UNION
           /*  2 - CHANGE  */
           SELECT LOCAL.ICS_GNRL_PRMT_ID
                , LOCAL.KEY_HASH
                , 'CHANGE' AS ACTION_TYPE
                , 2 AS ACTION_CODE
                , 'ICS_GNRL_PRMT' AS ICS_MODULE
                , 'ICS_GNRL_PRMT' AS DATA_ELEMENT
             FROM ICS_GNRL_PRMT LOCAL
             JOIN ics_flow_icis.ICS_GNRL_PRMT ICIS
               ON (ICIS.KEY_HASH = LOCAL.KEY_HASH)
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_GNRL_PRMT 
                               WHERE ICS_GNRL_PRMT.DATA_HASH = LOCAL.DATA_HASH)  
           UNION
           /*  3 - DELETE  */
           SELECT ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
                , ICS_GNRL_PRMT.KEY_HASH
                , 'DELETE' AS ACTION
                , 3 AS ACTION_CODE
                , 'ICS_GNRL_PRMT' AS ICS_MODULE
                , 'ICS_GNRL_PRMT' AS DATA_ELEMENT
             FROM ics_flow_icis.ICS_GNRL_PRMT
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ICS_GNRL_PRMT TBL
                               WHERE TBL.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH)) ICS_GNRL_PRMT;
   --
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'CTAS'        -- pi_process
      ,1);           -- pi_value
   -- -------------------
   -- cdv_master_gnrl_prmt
   -- --------------------
   SET v_startdtm2 = NOW();
   SET v_marker    = 'DROP AND CREATE TABLE CDV_MASTER_GNRL_PRMT';
   SET v_tgt_tbl   = 'CDV_MASTER_GNRL_PRMT';
   SET v_src_tbl   = 'ICS_MASTER_GNRL_PRMT';
   DROP TABLE IF EXISTS CDV_MASTER_GNRL_PRMT;
   CREATE TABLE CDV_MASTER_GNRL_PRMT 
   ENGINE=MyISAM CHARACTER SET utf8
   AS 
   SELECT DISTINCT ICS_MODULE
        , ICS_MASTER_GNRL_PRMT.KEY_HASH
        , CASE ICS_MASTER_GNRL_PRMT.ACTION_TYPE
            WHEN 'DELETE'
              THEN (SELECT KEY_HASH
                      FROM ics_flow_icis.ICS_MASTER_GNRL_PRMT TBL
                     WHERE TBL.ICS_MASTER_GNRL_PRMT_ID = ICS_MASTER_GNRL_PRMT.ICS_MASTER_GNRL_PRMT_ID)
              ELSE (SELECT KEY_HASH 
                      FROM ICS_MASTER_GNRL_PRMT TBL
                     WHERE TBL.ICS_MASTER_GNRL_PRMT_ID = ICS_MASTER_GNRL_PRMT.ICS_MASTER_GNRL_PRMT_ID)
          END AS MODULE_IDENT
        , ICS_MASTER_GNRL_PRMT.DATA_ELEMENT
        , ICS_MASTER_GNRL_PRMT.ACTION_TYPE
        , ICS_MASTER_GNRL_PRMT.ACTION_CODE
     FROM (/*  1 - NEW  */
           SELECT ICS_MASTER_GNRL_PRMT.ICS_MASTER_GNRL_PRMT_ID
			          , ICS_MASTER_GNRL_PRMT.KEY_HASH
                , 'NEW' AS ACTION_TYPE
                , 1 AS ACTION_CODE
                , 'ICS_MASTER_GNRL_PRMT' AS ICS_MODULE
                , 'ICS_MASTER_GNRL_PRMT' AS DATA_ELEMENT
             FROM ICS_MASTER_GNRL_PRMT
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_MASTER_GNRL_PRMT TBL
                               WHERE TBL.KEY_HASH = ICS_MASTER_GNRL_PRMT.KEY_HASH)
           UNION
           /*  2 - CHANGE  */
           SELECT LOCAL.ICS_MASTER_GNRL_PRMT_ID
                , LOCAL.KEY_HASH
                , 'CHANGE' AS ACTION_TYPE
                , 2 AS ACTION_CODE
                , 'ICS_MASTER_GNRL_PRMT' AS ICS_MODULE
                , 'ICS_MASTER_GNRL_PRMT' AS DATA_ELEMENT
             FROM ICS_MASTER_GNRL_PRMT LOCAL
             JOIN ics_flow_icis.ICS_MASTER_GNRL_PRMT ICIS
               ON (ICIS.KEY_HASH = LOCAL.KEY_HASH)
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_MASTER_GNRL_PRMT 
                               WHERE ICS_MASTER_GNRL_PRMT.DATA_HASH = LOCAL.DATA_HASH)  
           UNION
           /*  3 - DELETE  */
           SELECT ICS_MASTER_GNRL_PRMT.ICS_MASTER_GNRL_PRMT_ID
                , ICS_MASTER_GNRL_PRMT.KEY_HASH
                , 'DELETE' AS ACTION
                , 3 AS ACTION_CODE
                , 'ICS_MASTER_GNRL_PRMT' AS ICS_MODULE
                , 'ICS_MASTER_GNRL_PRMT' AS DATA_ELEMENT
             FROM ics_flow_icis.ICS_MASTER_GNRL_PRMT
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ICS_MASTER_GNRL_PRMT TBL
                               WHERE TBL.KEY_HASH = ICS_MASTER_GNRL_PRMT.KEY_HASH)) ICS_MASTER_GNRL_PRMT;
   --
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'CTAS'        -- pi_process
      ,1);           -- pi_value
   -- -------------------
   -- cdv_prmt_reissu
   -- --------------------
   SET v_startdtm2 = NOW();
   SET v_marker    = 'DROP AND CREATE TABLE CDV_PRMT_REISSU';
   SET v_tgt_tbl   = 'CDV_PRMT_REISSU';
   SET v_src_tbl   = 'ICS_PRMT_REISSU';
   DROP TABLE IF EXISTS CDV_PRMT_REISSU;
   CREATE TABLE CDV_PRMT_REISSU 
   ENGINE=MyISAM CHARACTER SET utf8
   AS 
   SELECT DISTINCT ICS_MODULE
        , ICS_PRMT_REISSU.KEY_HASH
        , CASE ICS_PRMT_REISSU.ACTION_TYPE
            WHEN 'DELETE'
              THEN (SELECT KEY_HASH
                      FROM ics_flow_icis.ICS_PRMT_REISSU TBL
                     WHERE TBL.ICS_PRMT_REISSU_ID = ICS_PRMT_REISSU.ICS_PRMT_REISSU_ID)
              ELSE (SELECT KEY_HASH 
                      FROM ICS_PRMT_REISSU TBL
                     WHERE TBL.ICS_PRMT_REISSU_ID = ICS_PRMT_REISSU.ICS_PRMT_REISSU_ID)
          END AS MODULE_IDENT
        , ICS_PRMT_REISSU.DATA_ELEMENT
        , ICS_PRMT_REISSU.ACTION_TYPE
        , ICS_PRMT_REISSU.ACTION_CODE
     FROM (/*  1 - NEW  */
           SELECT ICS_PRMT_REISSU.ICS_PRMT_REISSU_ID
			          , ICS_PRMT_REISSU.KEY_HASH
                , 'NEW' AS ACTION_TYPE
                , 1 AS ACTION_CODE
                , 'ICS_PRMT_REISSU' AS ICS_MODULE
                , 'ICS_PRMT_REISSU' AS DATA_ELEMENT
             FROM ICS_PRMT_REISSU
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_PRMT_REISSU TBL
                               WHERE TBL.KEY_HASH = ICS_PRMT_REISSU.KEY_HASH)
           UNION
           /*  2 - CHANGE  */
           SELECT LOCAL.ICS_PRMT_REISSU_ID
                , LOCAL.KEY_HASH
                , 'CHANGE' AS ACTION_TYPE
                , 2 AS ACTION_CODE
                , 'ICS_PRMT_REISSU' AS ICS_MODULE
                , 'ICS_PRMT_REISSU' AS DATA_ELEMENT
             FROM ICS_PRMT_REISSU LOCAL
             JOIN ics_flow_icis.ICS_PRMT_REISSU ICIS
               ON (ICIS.KEY_HASH = LOCAL.KEY_HASH)
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_PRMT_REISSU 
                               WHERE ICS_PRMT_REISSU.DATA_HASH = LOCAL.DATA_HASH)  
           UNION
           /*  3 - DELETE  */
           SELECT ICS_PRMT_REISSU.ICS_PRMT_REISSU_ID
                , ICS_PRMT_REISSU.KEY_HASH
                , 'DELETE' AS ACTION
                , 3 AS ACTION_CODE
                , 'ICS_PRMT_REISSU' AS ICS_MODULE
                , 'ICS_PRMT_REISSU' AS DATA_ELEMENT
             FROM ics_flow_icis.ICS_PRMT_REISSU
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ICS_PRMT_REISSU TBL
                               WHERE TBL.KEY_HASH = ICS_PRMT_REISSU.KEY_HASH)) ICS_PRMT_REISSU;
   --
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'CTAS'        -- pi_process
      ,1);           -- pi_value
   -- -------------------
   -- cdv_prmt_term
   -- --------------------
   SET v_startdtm2 = NOW();
   SET v_marker    = 'DROP AND CREATE TABLE CDV_PRMT_TERM';
   SET v_tgt_tbl   = 'CDV_PRMT_TERM';
   SET v_src_tbl   = 'ICS_PRMT_TERM';
   DROP TABLE IF EXISTS CDV_PRMT_TERM;
   CREATE TABLE CDV_PRMT_TERM 
   ENGINE=MyISAM CHARACTER SET utf8
   AS 
   SELECT DISTINCT ICS_MODULE
        , ICS_PRMT_TERM.KEY_HASH
        , CASE ICS_PRMT_TERM.ACTION_TYPE
            WHEN 'DELETE'
              THEN (SELECT KEY_HASH
                      FROM ics_flow_icis.ICS_PRMT_TERM TBL
                     WHERE TBL.ICS_PRMT_TERM_ID = ICS_PRMT_TERM.ICS_PRMT_TERM_ID)
              ELSE (SELECT KEY_HASH 
                      FROM ICS_PRMT_TERM TBL
                     WHERE TBL.ICS_PRMT_TERM_ID = ICS_PRMT_TERM.ICS_PRMT_TERM_ID)
          END AS MODULE_IDENT
        , ICS_PRMT_TERM.DATA_ELEMENT
        , ICS_PRMT_TERM.ACTION_TYPE
        , ICS_PRMT_TERM.ACTION_CODE
     FROM (/*  1 - NEW  */
           SELECT ICS_PRMT_TERM.ICS_PRMT_TERM_ID
			          , ICS_PRMT_TERM.KEY_HASH
                , 'NEW' AS ACTION_TYPE
                , 1 AS ACTION_CODE
                , 'ICS_PRMT_TERM' AS ICS_MODULE
                , 'ICS_PRMT_TERM' AS DATA_ELEMENT
             FROM ICS_PRMT_TERM
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_PRMT_TERM TBL
                               WHERE TBL.KEY_HASH = ICS_PRMT_TERM.KEY_HASH)
           UNION
           /*  2 - CHANGE  */
           SELECT LOCAL.ICS_PRMT_TERM_ID
                , LOCAL.KEY_HASH
                , 'CHANGE' AS ACTION_TYPE
                , 2 AS ACTION_CODE
                , 'ICS_PRMT_TERM' AS ICS_MODULE
                , 'ICS_PRMT_TERM' AS DATA_ELEMENT
             FROM ICS_PRMT_TERM LOCAL
             JOIN ics_flow_icis.ICS_PRMT_TERM ICIS
               ON (ICIS.KEY_HASH = LOCAL.KEY_HASH)
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_PRMT_TERM 
                               WHERE ICS_PRMT_TERM.DATA_HASH = LOCAL.DATA_HASH)  
           UNION
           /*  3 - DELETE  */
           SELECT ICS_PRMT_TERM.ICS_PRMT_TERM_ID
                , ICS_PRMT_TERM.KEY_HASH
                , 'DELETE' AS ACTION
                , 3 AS ACTION_CODE
                , 'ICS_PRMT_TERM' AS ICS_MODULE
                , 'ICS_PRMT_TERM' AS DATA_ELEMENT
             FROM ics_flow_icis.ICS_PRMT_TERM
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ICS_PRMT_TERM TBL
                               WHERE TBL.KEY_HASH = ICS_PRMT_TERM.KEY_HASH)) ICS_PRMT_TERM;
   --
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'CTAS'        -- pi_process
      ,1);           -- pi_value
   -- -------------------
   -- cdv_prmt_track_evt
   -- --------------------
   SET v_startdtm2 = NOW();
   SET v_marker    = 'DROP AND CREATE TABLE CDV_PRMT_TRACK_EVT';
   SET v_tgt_tbl   = 'CDV_PRMT_TRACK_EVT';
   SET v_src_tbl   = 'ICS_PRMT_TRACK_EVT';
   DROP TABLE IF EXISTS CDV_PRMT_TRACK_EVT;
   CREATE TABLE CDV_PRMT_TRACK_EVT 
   ENGINE=MyISAM CHARACTER SET utf8
   AS 
   SELECT DISTINCT ICS_MODULE
        , ICS_PRMT_TRACK_EVT.KEY_HASH
        , CASE ICS_PRMT_TRACK_EVT.ACTION_TYPE
            WHEN 'DELETE'
              THEN (SELECT KEY_HASH
                      FROM ics_flow_icis.ICS_PRMT_TRACK_EVT TBL
                     WHERE TBL.ICS_PRMT_TRACK_EVT_ID = ICS_PRMT_TRACK_EVT.ICS_PRMT_TRACK_EVT_ID)
              ELSE (SELECT KEY_HASH 
                      FROM ICS_PRMT_TRACK_EVT TBL
                     WHERE TBL.ICS_PRMT_TRACK_EVT_ID = ICS_PRMT_TRACK_EVT.ICS_PRMT_TRACK_EVT_ID)
          END AS MODULE_IDENT
        , ICS_PRMT_TRACK_EVT.DATA_ELEMENT
        , ICS_PRMT_TRACK_EVT.ACTION_TYPE
        , ICS_PRMT_TRACK_EVT.ACTION_CODE
     FROM (/*  1 - NEW  */
           SELECT ICS_PRMT_TRACK_EVT.ICS_PRMT_TRACK_EVT_ID
			          , ICS_PRMT_TRACK_EVT.KEY_HASH
                , 'NEW' AS ACTION_TYPE
                , 1 AS ACTION_CODE
                , 'ICS_PRMT_TRACK_EVT' AS ICS_MODULE
                , 'ICS_PRMT_TRACK_EVT' AS DATA_ELEMENT
             FROM ICS_PRMT_TRACK_EVT
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_PRMT_TRACK_EVT TBL
                               WHERE TBL.KEY_HASH = ICS_PRMT_TRACK_EVT.KEY_HASH)
           UNION
           /*  2 - CHANGE  */
           SELECT LOCAL.ICS_PRMT_TRACK_EVT_ID
                , LOCAL.KEY_HASH
                , 'CHANGE' AS ACTION_TYPE
                , 2 AS ACTION_CODE
                , 'ICS_PRMT_TRACK_EVT' AS ICS_MODULE
                , 'ICS_PRMT_TRACK_EVT' AS DATA_ELEMENT
             FROM ICS_PRMT_TRACK_EVT LOCAL
             JOIN ics_flow_icis.ICS_PRMT_TRACK_EVT ICIS
               ON (ICIS.KEY_HASH = LOCAL.KEY_HASH)
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_PRMT_TRACK_EVT 
                               WHERE ICS_PRMT_TRACK_EVT.DATA_HASH = LOCAL.DATA_HASH)  
           UNION
           /*  3 - DELETE  */
           SELECT ICS_PRMT_TRACK_EVT.ICS_PRMT_TRACK_EVT_ID
                , ICS_PRMT_TRACK_EVT.KEY_HASH
                , 'DELETE' AS ACTION
                , 3 AS ACTION_CODE
                , 'ICS_PRMT_TRACK_EVT' AS ICS_MODULE
                , 'ICS_PRMT_TRACK_EVT' AS DATA_ELEMENT
             FROM ics_flow_icis.ICS_PRMT_TRACK_EVT
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ICS_PRMT_TRACK_EVT TBL
                               WHERE TBL.KEY_HASH = ICS_PRMT_TRACK_EVT.KEY_HASH)) ICS_PRMT_TRACK_EVT;
   --
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'CTAS'        -- pi_process
      ,1);           -- pi_value
   -- -------------------
   -- cdv_potw_prmt
   -- --------------------
   SET v_startdtm2 = NOW();
   SET v_marker    = 'DROP AND CREATE TABLE CDV_POTW_PRMT';
   SET v_tgt_tbl   = 'CDV_POTW_PRMT';
   SET v_src_tbl   = 'ICS_POTW_PRMT';
   DROP TABLE IF EXISTS CDV_POTW_PRMT;
   CREATE TABLE CDV_POTW_PRMT 
   ENGINE=MyISAM CHARACTER SET utf8
   AS 
   SELECT DISTINCT ICS_MODULE
        , ICS_POTW_PRMT.KEY_HASH
        , CASE ICS_POTW_PRMT.ACTION_TYPE
            WHEN 'DELETE'
              THEN (SELECT KEY_HASH
                      FROM ics_flow_icis.ICS_POTW_PRMT TBL
                     WHERE TBL.ICS_POTW_PRMT_ID = ICS_POTW_PRMT.ICS_POTW_PRMT_ID)
              ELSE (SELECT KEY_HASH 
                      FROM ICS_POTW_PRMT TBL
                     WHERE TBL.ICS_POTW_PRMT_ID = ICS_POTW_PRMT.ICS_POTW_PRMT_ID)
          END AS MODULE_IDENT
        , ICS_POTW_PRMT.DATA_ELEMENT
        , ICS_POTW_PRMT.ACTION_TYPE
        , ICS_POTW_PRMT.ACTION_CODE
     FROM (/*  1 - NEW  */
           SELECT ICS_POTW_PRMT.ICS_POTW_PRMT_ID
			          , ICS_POTW_PRMT.KEY_HASH
                , 'NEW' AS ACTION_TYPE
                , 1 AS ACTION_CODE
                , 'ICS_POTW_PRMT' AS ICS_MODULE
                , 'ICS_POTW_PRMT' AS DATA_ELEMENT
             FROM ICS_POTW_PRMT
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_POTW_PRMT TBL
                               WHERE TBL.KEY_HASH = ICS_POTW_PRMT.KEY_HASH)
           UNION
           /*  2 - CHANGE  */
           SELECT LOCAL.ICS_POTW_PRMT_ID
                , LOCAL.KEY_HASH
                , 'CHANGE' AS ACTION_TYPE
                , 2 AS ACTION_CODE
                , 'ICS_POTW_PRMT' AS ICS_MODULE
                , 'ICS_POTW_PRMT' AS DATA_ELEMENT
             FROM ICS_POTW_PRMT LOCAL
             JOIN ics_flow_icis.ICS_POTW_PRMT ICIS
               ON (ICIS.KEY_HASH = LOCAL.KEY_HASH)
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_POTW_PRMT 
                               WHERE ICS_POTW_PRMT.DATA_HASH = LOCAL.DATA_HASH)  
           UNION
           /*  3 - DELETE  */
           SELECT ICS_POTW_PRMT.ICS_POTW_PRMT_ID
                , ICS_POTW_PRMT.KEY_HASH
                , 'DELETE' AS ACTION
                , 3 AS ACTION_CODE
                , 'ICS_POTW_PRMT' AS ICS_MODULE
                , 'ICS_POTW_PRMT' AS DATA_ELEMENT
             FROM ics_flow_icis.ICS_POTW_PRMT
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ICS_POTW_PRMT TBL
                               WHERE TBL.KEY_HASH = ICS_POTW_PRMT.KEY_HASH)) ICS_POTW_PRMT;
   --
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'CTAS'        -- pi_process
      ,1);           -- pi_value
   -- --------------
   -- cdv_pretr_prmt
   -- --------------
   SET v_startdtm2 = NOW();
   SET v_marker    = 'DROP AND CREATE TABLE CDV_PRETR_PRMT';
   SET v_tgt_tbl   = 'CDV_PRETR_PRMT';
   SET v_src_tbl   = 'ICS_PRETR_PRMT';
   DROP TABLE IF EXISTS CDV_PRETR_PRMT;
   CREATE TABLE CDV_PRETR_PRMT 
   ENGINE=MyISAM CHARACTER SET utf8
   AS 
   SELECT DISTINCT ICS_MODULE
        , ICS_PRETR_PRMT.KEY_HASH
        , CASE ICS_PRETR_PRMT.ACTION_TYPE
            WHEN 'DELETE'
              THEN (SELECT KEY_HASH
                      FROM ics_flow_icis.ICS_PRETR_PRMT TBL
                     WHERE TBL.ICS_PRETR_PRMT_ID = ICS_PRETR_PRMT.ICS_PRETR_PRMT_ID)
              ELSE (SELECT KEY_HASH 
                      FROM ICS_PRETR_PRMT TBL
                     WHERE TBL.ICS_PRETR_PRMT_ID = ICS_PRETR_PRMT.ICS_PRETR_PRMT_ID)
          END AS MODULE_IDENT
        , ICS_PRETR_PRMT.DATA_ELEMENT
        , ICS_PRETR_PRMT.ACTION_TYPE
        , ICS_PRETR_PRMT.ACTION_CODE
     FROM (/*  1 - NEW  */
           SELECT ICS_PRETR_PRMT.ICS_PRETR_PRMT_ID
			          , ICS_PRETR_PRMT.KEY_HASH
                , 'NEW' AS ACTION_TYPE
                , 1 AS ACTION_CODE
                , 'ICS_PRETR_PRMT' AS ICS_MODULE
                , 'ICS_PRETR_PRMT' AS DATA_ELEMENT
             FROM ICS_PRETR_PRMT
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_PRETR_PRMT TBL
                               WHERE TBL.KEY_HASH = ICS_PRETR_PRMT.KEY_HASH)
           UNION
           /*  2 - CHANGE  */
           SELECT LOCAL.ICS_PRETR_PRMT_ID
                , LOCAL.KEY_HASH
                , 'CHANGE' AS ACTION_TYPE
                , 2 AS ACTION_CODE
                , 'ICS_PRETR_PRMT' AS ICS_MODULE
                , 'ICS_PRETR_PRMT' AS DATA_ELEMENT
             FROM ICS_PRETR_PRMT LOCAL
             JOIN ics_flow_icis.ICS_PRETR_PRMT ICIS
               ON (ICIS.KEY_HASH = LOCAL.KEY_HASH)
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_PRETR_PRMT 
                               WHERE ICS_PRETR_PRMT.DATA_HASH = LOCAL.DATA_HASH)  
           UNION
           /*  3 - DELETE  */
           SELECT ICS_PRETR_PRMT.ICS_PRETR_PRMT_ID
                , ICS_PRETR_PRMT.KEY_HASH
                , 'DELETE' AS ACTION
                , 3 AS ACTION_CODE
                , 'ICS_PRETR_PRMT' AS ICS_MODULE
                , 'ICS_PRETR_PRMT' AS DATA_ELEMENT
             FROM ics_flow_icis.ICS_PRETR_PRMT
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ICS_PRETR_PRMT TBL
                               WHERE TBL.KEY_HASH = ICS_PRETR_PRMT.KEY_HASH)) ICS_PRETR_PRMT;
   --
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'CTAS'        -- pi_process
      ,1);           -- pi_value
   -- --------------
   -- cdv_sw_cnst_prmt
   -- --------------
   SET v_startdtm2 = NOW();
   SET v_marker    = 'DROP AND CREATE TABLE CDV_SW_CNST_PRMT';
   SET v_tgt_tbl   = 'CDV_SW_CNST_PRMT';
   SET v_src_tbl   = 'ICS_SW_CNST_PRMT';
   DROP TABLE IF EXISTS CDV_SW_CNST_PRMT;
   CREATE TABLE CDV_SW_CNST_PRMT 
   ENGINE=MyISAM CHARACTER SET utf8
   AS 
   SELECT DISTINCT ICS_MODULE
        , ICS_SW_CNST_PRMT.KEY_HASH
        , CASE ICS_SW_CNST_PRMT.ACTION_TYPE
            WHEN 'DELETE'
              THEN (SELECT KEY_HASH
                      FROM ics_flow_icis.ICS_SW_CNST_PRMT TBL
                     WHERE TBL.ICS_SW_CNST_PRMT_ID = ICS_SW_CNST_PRMT.ICS_SW_CNST_PRMT_ID)
              ELSE (SELECT KEY_HASH 
                      FROM ICS_SW_CNST_PRMT TBL
                     WHERE TBL.ICS_SW_CNST_PRMT_ID = ICS_SW_CNST_PRMT.ICS_SW_CNST_PRMT_ID)
          END AS MODULE_IDENT
        , ICS_SW_CNST_PRMT.DATA_ELEMENT
        , ICS_SW_CNST_PRMT.ACTION_TYPE
        , ICS_SW_CNST_PRMT.ACTION_CODE
     FROM (/*  1 - NEW  */
           SELECT ICS_SW_CNST_PRMT.ICS_SW_CNST_PRMT_ID
			          , ICS_SW_CNST_PRMT.KEY_HASH
                , 'NEW' AS ACTION_TYPE
                , 1 AS ACTION_CODE
                , 'ICS_SW_CNST_PRMT' AS ICS_MODULE
                , 'ICS_SW_CNST_PRMT' AS DATA_ELEMENT
             FROM ICS_SW_CNST_PRMT
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_SW_CNST_PRMT TBL
                               WHERE TBL.KEY_HASH = ICS_SW_CNST_PRMT.KEY_HASH)
           UNION
           /*  2 - CHANGE  */
           SELECT LOCAL.ICS_SW_CNST_PRMT_ID
                , LOCAL.KEY_HASH
                , 'CHANGE' AS ACTION_TYPE
                , 2 AS ACTION_CODE
                , 'ICS_SW_CNST_PRMT' AS ICS_MODULE
                , 'ICS_SW_CNST_PRMT' AS DATA_ELEMENT
             FROM ICS_SW_CNST_PRMT LOCAL
             JOIN ics_flow_icis.ICS_SW_CNST_PRMT ICIS
               ON (ICIS.KEY_HASH = LOCAL.KEY_HASH)
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_SW_CNST_PRMT 
                               WHERE ICS_SW_CNST_PRMT.DATA_HASH = LOCAL.DATA_HASH)  
           UNION
           /*  3 - DELETE  */
           SELECT ICS_SW_CNST_PRMT.ICS_SW_CNST_PRMT_ID
                , ICS_SW_CNST_PRMT.KEY_HASH
                , 'DELETE' AS ACTION
                , 3 AS ACTION_CODE
                , 'ICS_SW_CNST_PRMT' AS ICS_MODULE
                , 'ICS_SW_CNST_PRMT' AS DATA_ELEMENT
             FROM ics_flow_icis.ICS_SW_CNST_PRMT
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ICS_SW_CNST_PRMT TBL
                               WHERE TBL.KEY_HASH = ICS_SW_CNST_PRMT.KEY_HASH)) ICS_SW_CNST_PRMT;
   --
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'CTAS'        -- pi_process
      ,1);           -- pi_value
   -- --------------
   -- cdv_sw_indst_prmt
   -- --------------
   SET v_startdtm2 = NOW();
   SET v_marker    = 'DROP AND CREATE TABLE CDV_SW_INDST_PRMT';
   SET v_tgt_tbl   = 'CDV_SW_INDST_PRMT';
   SET v_src_tbl   = 'ICS_SW_INDST_PRMT';
   DROP TABLE IF EXISTS CDV_SW_INDST_PRMT;
   CREATE TABLE CDV_SW_INDST_PRMT 
   ENGINE=MyISAM CHARACTER SET utf8
   AS 
   SELECT DISTINCT ICS_MODULE
        , ICS_SW_INDST_PRMT.KEY_HASH
        , CASE ICS_SW_INDST_PRMT.ACTION_TYPE
            WHEN 'DELETE'
              THEN (SELECT KEY_HASH
                      FROM ics_flow_icis.ICS_SW_INDST_PRMT TBL
                     WHERE TBL.ICS_SW_INDST_PRMT_ID = ICS_SW_INDST_PRMT.ICS_SW_INDST_PRMT_ID)
              ELSE (SELECT KEY_HASH 
                      FROM ICS_SW_INDST_PRMT TBL
                     WHERE TBL.ICS_SW_INDST_PRMT_ID = ICS_SW_INDST_PRMT.ICS_SW_INDST_PRMT_ID)
          END AS MODULE_IDENT
        , ICS_SW_INDST_PRMT.DATA_ELEMENT
        , ICS_SW_INDST_PRMT.ACTION_TYPE
        , ICS_SW_INDST_PRMT.ACTION_CODE
     FROM (/*  1 - NEW  */
           SELECT ICS_SW_INDST_PRMT.ICS_SW_INDST_PRMT_ID
			          , ICS_SW_INDST_PRMT.KEY_HASH
                , 'NEW' AS ACTION_TYPE
                , 1 AS ACTION_CODE
                , 'ICS_SW_INDST_PRMT' AS ICS_MODULE
                , 'ICS_SW_INDST_PRMT' AS DATA_ELEMENT
             FROM ICS_SW_INDST_PRMT
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_SW_INDST_PRMT TBL
                               WHERE TBL.KEY_HASH = ICS_SW_INDST_PRMT.KEY_HASH)
           UNION
           /*  2 - CHANGE  */
           SELECT LOCAL.ICS_SW_INDST_PRMT_ID
                , LOCAL.KEY_HASH
                , 'CHANGE' AS ACTION_TYPE
                , 2 AS ACTION_CODE
                , 'ICS_SW_INDST_PRMT' AS ICS_MODULE
                , 'ICS_SW_INDST_PRMT' AS DATA_ELEMENT
             FROM ICS_SW_INDST_PRMT LOCAL
             JOIN ics_flow_icis.ICS_SW_INDST_PRMT ICIS
               ON (ICIS.KEY_HASH = LOCAL.KEY_HASH)
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_SW_INDST_PRMT 
                               WHERE ICS_SW_INDST_PRMT.DATA_HASH = LOCAL.DATA_HASH)  
           UNION
           /*  3 - DELETE  */
           SELECT ICS_SW_INDST_PRMT.ICS_SW_INDST_PRMT_ID
                , ICS_SW_INDST_PRMT.KEY_HASH
                , 'DELETE' AS ACTION
                , 3 AS ACTION_CODE
                , 'ICS_SW_INDST_PRMT' AS ICS_MODULE
                , 'ICS_SW_INDST_PRMT' AS DATA_ELEMENT
             FROM ics_flow_icis.ICS_SW_INDST_PRMT
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ICS_SW_INDST_PRMT TBL
                               WHERE TBL.KEY_HASH = ICS_SW_INDST_PRMT.KEY_HASH)) ICS_SW_INDST_PRMT;
   --
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'CTAS'        -- pi_process
      ,1);           -- pi_value
   -- ---------------------
   -- cdv_swms_4_large_prmt
   -- ---------------------
   SET v_startdtm2 = NOW();
   SET v_marker    = 'DROP AND CREATE TABLE CDV_SWMS_4_LARGE_PRMT';
   SET v_tgt_tbl   = 'CDV_SWMS_4_LARGE_PRMT';
   SET v_src_tbl   = 'ICS_SWMS_4_LARGE_PRMT';
   DROP TABLE IF EXISTS CDV_SWMS_4_LARGE_PRMT;
   CREATE TABLE CDV_SWMS_4_LARGE_PRMT 
   ENGINE=MyISAM CHARACTER SET utf8
   AS 
   SELECT DISTINCT ICS_MODULE
        , ICS_SWMS_4_LARGE_PRMT.KEY_HASH
        , CASE ICS_SWMS_4_LARGE_PRMT.ACTION_TYPE
            WHEN 'DELETE'
              THEN (SELECT KEY_HASH
                      FROM ics_flow_icis.ICS_SWMS_4_LARGE_PRMT TBL
                     WHERE TBL.ICS_SWMS_4_LARGE_PRMT_ID = ICS_SWMS_4_LARGE_PRMT.ICS_SWMS_4_LARGE_PRMT_ID)
              ELSE (SELECT KEY_HASH 
                      FROM ICS_SWMS_4_LARGE_PRMT TBL
                     WHERE TBL.ICS_SWMS_4_LARGE_PRMT_ID = ICS_SWMS_4_LARGE_PRMT.ICS_SWMS_4_LARGE_PRMT_ID)
          END AS MODULE_IDENT
        , ICS_SWMS_4_LARGE_PRMT.DATA_ELEMENT
        , ICS_SWMS_4_LARGE_PRMT.ACTION_TYPE
        , ICS_SWMS_4_LARGE_PRMT.ACTION_CODE
     FROM (/*  1 - NEW  */
           SELECT ICS_SWMS_4_LARGE_PRMT.ICS_SWMS_4_LARGE_PRMT_ID
			          , ICS_SWMS_4_LARGE_PRMT.KEY_HASH
                , 'NEW' AS ACTION_TYPE
                , 1 AS ACTION_CODE
                , 'ICS_SWMS_4_LARGE_PRMT' AS ICS_MODULE
                , 'ICS_SWMS_4_LARGE_PRMT' AS DATA_ELEMENT
             FROM ICS_SWMS_4_LARGE_PRMT
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_SWMS_4_LARGE_PRMT TBL
                               WHERE TBL.KEY_HASH = ICS_SWMS_4_LARGE_PRMT.KEY_HASH)
           UNION
           /*  2 - CHANGE  */
           SELECT LOCAL.ICS_SWMS_4_LARGE_PRMT_ID
                , LOCAL.KEY_HASH
                , 'CHANGE' AS ACTION_TYPE
                , 2 AS ACTION_CODE
                , 'ICS_SWMS_4_LARGE_PRMT' AS ICS_MODULE
                , 'ICS_SWMS_4_LARGE_PRMT' AS DATA_ELEMENT
             FROM ICS_SWMS_4_LARGE_PRMT LOCAL
             JOIN ics_flow_icis.ICS_SWMS_4_LARGE_PRMT ICIS
               ON (ICIS.KEY_HASH = LOCAL.KEY_HASH)
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_SWMS_4_LARGE_PRMT 
                               WHERE ICS_SWMS_4_LARGE_PRMT.DATA_HASH = LOCAL.DATA_HASH)  
           UNION
           /*  3 - DELETE  */
           SELECT ICS_SWMS_4_LARGE_PRMT.ICS_SWMS_4_LARGE_PRMT_ID
                , ICS_SWMS_4_LARGE_PRMT.KEY_HASH
                , 'DELETE' AS ACTION
                , 3 AS ACTION_CODE
                , 'ICS_SWMS_4_LARGE_PRMT' AS ICS_MODULE
                , 'ICS_SWMS_4_LARGE_PRMT' AS DATA_ELEMENT
             FROM ics_flow_icis.ICS_SWMS_4_LARGE_PRMT
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ICS_SWMS_4_LARGE_PRMT TBL
                               WHERE TBL.KEY_HASH = ICS_SWMS_4_LARGE_PRMT.KEY_HASH)) ICS_SWMS_4_LARGE_PRMT;
   --
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'CTAS'        -- pi_process
      ,1);           -- pi_value
   -- ---------------------
   -- cdv_swms_4_small_prmt
   -- ---------------------
   SET v_startdtm2 = NOW();
   SET v_marker    = 'DROP AND CREATE TABLE CDV_SWMS_4_SMALL_PRMT';
   SET v_tgt_tbl   = 'CDV_SWMS_4_SMALL_PRMT';
   SET v_src_tbl   = 'ICS_SWMS_4_SMALL_PRMT';
   DROP TABLE IF EXISTS CDV_SWMS_4_SMALL_PRMT;
   CREATE TABLE CDV_SWMS_4_SMALL_PRMT 
   ENGINE=MyISAM CHARACTER SET utf8
   AS 
   SELECT DISTINCT ICS_MODULE
        , ICS_SWMS_4_SMALL_PRMT.KEY_HASH
        , CASE ICS_SWMS_4_SMALL_PRMT.ACTION_TYPE
            WHEN 'DELETE'
              THEN (SELECT KEY_HASH
                      FROM ics_flow_icis.ICS_SWMS_4_SMALL_PRMT TBL
                     WHERE TBL.ICS_SWMS_4_SMALL_PRMT_ID = ICS_SWMS_4_SMALL_PRMT.ICS_SWMS_4_SMALL_PRMT_ID)
              ELSE (SELECT KEY_HASH 
                      FROM ICS_SWMS_4_SMALL_PRMT TBL
                     WHERE TBL.ICS_SWMS_4_SMALL_PRMT_ID = ICS_SWMS_4_SMALL_PRMT.ICS_SWMS_4_SMALL_PRMT_ID)
          END AS MODULE_IDENT
        , ICS_SWMS_4_SMALL_PRMT.DATA_ELEMENT
        , ICS_SWMS_4_SMALL_PRMT.ACTION_TYPE
        , ICS_SWMS_4_SMALL_PRMT.ACTION_CODE
     FROM (/*  1 - NEW  */
           SELECT ICS_SWMS_4_SMALL_PRMT.ICS_SWMS_4_SMALL_PRMT_ID
			          , ICS_SWMS_4_SMALL_PRMT.KEY_HASH
                , 'NEW' AS ACTION_TYPE
                , 1 AS ACTION_CODE
                , 'ICS_SWMS_4_SMALL_PRMT' AS ICS_MODULE
                , 'ICS_SWMS_4_SMALL_PRMT' AS DATA_ELEMENT
             FROM ICS_SWMS_4_SMALL_PRMT
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_SWMS_4_SMALL_PRMT TBL
                               WHERE TBL.KEY_HASH = ICS_SWMS_4_SMALL_PRMT.KEY_HASH)
           UNION
           /*  2 - CHANGE  */
           SELECT LOCAL.ICS_SWMS_4_SMALL_PRMT_ID
                , LOCAL.KEY_HASH
                , 'CHANGE' AS ACTION_TYPE
                , 2 AS ACTION_CODE
                , 'ICS_SWMS_4_SMALL_PRMT' AS ICS_MODULE
                , 'ICS_SWMS_4_SMALL_PRMT' AS DATA_ELEMENT
             FROM ICS_SWMS_4_SMALL_PRMT LOCAL
             JOIN ics_flow_icis.ICS_SWMS_4_SMALL_PRMT ICIS
               ON (ICIS.KEY_HASH = LOCAL.KEY_HASH)
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_SWMS_4_SMALL_PRMT 
                               WHERE ICS_SWMS_4_SMALL_PRMT.DATA_HASH = LOCAL.DATA_HASH)  
           UNION
           /*  3 - DELETE  */
           SELECT ICS_SWMS_4_SMALL_PRMT.ICS_SWMS_4_SMALL_PRMT_ID
                , ICS_SWMS_4_SMALL_PRMT.KEY_HASH
                , 'DELETE' AS ACTION
                , 3 AS ACTION_CODE
                , 'ICS_SWMS_4_SMALL_PRMT' AS ICS_MODULE
                , 'ICS_SWMS_4_SMALL_PRMT' AS DATA_ELEMENT
             FROM ics_flow_icis.ICS_SWMS_4_SMALL_PRMT
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ICS_SWMS_4_SMALL_PRMT TBL
                               WHERE TBL.KEY_HASH = ICS_SWMS_4_SMALL_PRMT.KEY_HASH)) ICS_SWMS_4_SMALL_PRMT;
   --
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'CTAS'        -- pi_process
      ,1);           -- pi_value
   -- ---------------------
   -- cdv_unprmt_fac
   -- ---------------------
   SET v_startdtm2 = NOW();
   SET v_marker    = 'DROP AND CREATE TABLE CDV_UNPRMT_FAC';
   SET v_tgt_tbl   = 'CDV_UNPRMT_FAC';
   SET v_src_tbl   = 'ICS_UNPRMT_FAC';
   DROP TABLE IF EXISTS CDV_UNPRMT_FAC;
   CREATE TABLE CDV_UNPRMT_FAC 
   ENGINE=MyISAM CHARACTER SET utf8
   AS 
   SELECT DISTINCT ICS_MODULE
        , ICS_UNPRMT_FAC.KEY_HASH
        , CASE ICS_UNPRMT_FAC.ACTION_TYPE
            WHEN 'DELETE'
              THEN (SELECT KEY_HASH
                      FROM ics_flow_icis.ICS_UNPRMT_FAC TBL
                     WHERE TBL.ICS_UNPRMT_FAC_ID = ICS_UNPRMT_FAC.ICS_UNPRMT_FAC_ID)
              ELSE (SELECT KEY_HASH 
                      FROM ICS_UNPRMT_FAC TBL
                     WHERE TBL.ICS_UNPRMT_FAC_ID = ICS_UNPRMT_FAC.ICS_UNPRMT_FAC_ID)
          END AS MODULE_IDENT
        , ICS_UNPRMT_FAC.DATA_ELEMENT
        , ICS_UNPRMT_FAC.ACTION_TYPE
        , ICS_UNPRMT_FAC.ACTION_CODE
     FROM (/*  1 - NEW  */
           SELECT ICS_UNPRMT_FAC.ICS_UNPRMT_FAC_ID
			          , ICS_UNPRMT_FAC.KEY_HASH
                , 'NEW' AS ACTION_TYPE
                , 1 AS ACTION_CODE
                , 'ICS_UNPRMT_FAC' AS ICS_MODULE
                , 'ICS_UNPRMT_FAC' AS DATA_ELEMENT
             FROM ICS_UNPRMT_FAC
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_UNPRMT_FAC TBL
                               WHERE TBL.KEY_HASH = ICS_UNPRMT_FAC.KEY_HASH)
           UNION
           /*  2 - CHANGE  */
           SELECT LOCAL.ICS_UNPRMT_FAC_ID
                , LOCAL.KEY_HASH
                , 'CHANGE' AS ACTION_TYPE
                , 2 AS ACTION_CODE
                , 'ICS_UNPRMT_FAC' AS ICS_MODULE
                , 'ICS_UNPRMT_FAC' AS DATA_ELEMENT
             FROM ICS_UNPRMT_FAC LOCAL
             JOIN ics_flow_icis.ICS_UNPRMT_FAC ICIS
               ON (ICIS.KEY_HASH = LOCAL.KEY_HASH)
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_UNPRMT_FAC 
                               WHERE ICS_UNPRMT_FAC.DATA_HASH = LOCAL.DATA_HASH)  
           UNION
           /*  3 - DELETE  */
           SELECT ICS_UNPRMT_FAC.ICS_UNPRMT_FAC_ID
                , ICS_UNPRMT_FAC.KEY_HASH
                , 'DELETE' AS ACTION
                , 3 AS ACTION_CODE
                , 'ICS_UNPRMT_FAC' AS ICS_MODULE
                , 'ICS_UNPRMT_FAC' AS DATA_ELEMENT
             FROM ics_flow_icis.ICS_UNPRMT_FAC
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ICS_UNPRMT_FAC TBL
                               WHERE TBL.KEY_HASH = ICS_UNPRMT_FAC.KEY_HASH)) ICS_UNPRMT_FAC;
   --
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'CTAS'        -- pi_process
      ,1);           -- pi_value
   -- ---------------------
   -- cdv_hist_prmt_schd_evts
   -- ---------------------
   SET v_startdtm2 = NOW();
   SET v_marker    = 'DROP AND CREATE TABLE CDV_HIST_PRMT_SCHD_EVTS';
   SET v_tgt_tbl   = 'CDV_HIST_PRMT_SCHD_EVTS';
   SET v_src_tbl   = 'ICS_HIST_PRMT_SCHD_EVTS';
   DROP TABLE IF EXISTS CDV_HIST_PRMT_SCHD_EVTS;
   CREATE TABLE CDV_HIST_PRMT_SCHD_EVTS 
   ENGINE=MyISAM CHARACTER SET utf8
   AS 
   SELECT DISTINCT ICS_MODULE
        , ICS_HIST_PRMT_SCHD_EVTS.KEY_HASH
        , CASE ICS_HIST_PRMT_SCHD_EVTS.ACTION_TYPE
            WHEN 'DELETE'
              THEN (SELECT KEY_HASH
                      FROM ics_flow_icis.ICS_HIST_PRMT_SCHD_EVTS TBL
                     WHERE TBL.ICS_HIST_PRMT_SCHD_EVTS_ID = ICS_HIST_PRMT_SCHD_EVTS.ICS_HIST_PRMT_SCHD_EVTS_ID)
              ELSE (SELECT KEY_HASH 
                      FROM ICS_HIST_PRMT_SCHD_EVTS TBL
                     WHERE TBL.ICS_HIST_PRMT_SCHD_EVTS_ID = ICS_HIST_PRMT_SCHD_EVTS.ICS_HIST_PRMT_SCHD_EVTS_ID)
          END AS MODULE_IDENT
        , ICS_HIST_PRMT_SCHD_EVTS.DATA_ELEMENT
        , ICS_HIST_PRMT_SCHD_EVTS.ACTION_TYPE
        , ICS_HIST_PRMT_SCHD_EVTS.ACTION_CODE
     FROM (/*  1 - NEW  */
           SELECT ICS_HIST_PRMT_SCHD_EVTS.ICS_HIST_PRMT_SCHD_EVTS_ID
			          , ICS_HIST_PRMT_SCHD_EVTS.KEY_HASH
                , 'NEW' AS ACTION_TYPE
                , 1 AS ACTION_CODE
                , 'ICS_HIST_PRMT_SCHD_EVTS' AS ICS_MODULE
                , 'ICS_HIST_PRMT_SCHD_EVTS' AS DATA_ELEMENT
             FROM ICS_HIST_PRMT_SCHD_EVTS
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_HIST_PRMT_SCHD_EVTS TBL
                               WHERE TBL.KEY_HASH = ICS_HIST_PRMT_SCHD_EVTS.KEY_HASH)
           UNION
           /*  2 - CHANGE  */
           SELECT LOCAL.ICS_HIST_PRMT_SCHD_EVTS_ID
                , LOCAL.KEY_HASH
                , 'CHANGE' AS ACTION_TYPE
                , 2 AS ACTION_CODE
                , 'ICS_HIST_PRMT_SCHD_EVTS' AS ICS_MODULE
                , 'ICS_HIST_PRMT_SCHD_EVTS' AS DATA_ELEMENT
             FROM ICS_HIST_PRMT_SCHD_EVTS LOCAL
             JOIN ics_flow_icis.ICS_HIST_PRMT_SCHD_EVTS ICIS
               ON (ICIS.KEY_HASH = LOCAL.KEY_HASH)
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_HIST_PRMT_SCHD_EVTS 
                               WHERE ICS_HIST_PRMT_SCHD_EVTS.DATA_HASH = LOCAL.DATA_HASH)  
           UNION
           /*  3 - DELETE  */
           SELECT ICS_HIST_PRMT_SCHD_EVTS.ICS_HIST_PRMT_SCHD_EVTS_ID
                , ICS_HIST_PRMT_SCHD_EVTS.KEY_HASH
                , 'DELETE' AS ACTION
                , 3 AS ACTION_CODE
                , 'ICS_HIST_PRMT_SCHD_EVTS' AS ICS_MODULE
                , 'ICS_HIST_PRMT_SCHD_EVTS' AS DATA_ELEMENT
             FROM ics_flow_icis.ICS_HIST_PRMT_SCHD_EVTS
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ICS_HIST_PRMT_SCHD_EVTS TBL
                               WHERE TBL.KEY_HASH = ICS_HIST_PRMT_SCHD_EVTS.KEY_HASH)) ICS_HIST_PRMT_SCHD_EVTS;
   --
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'CTAS'        -- pi_process
      ,1);           -- pi_value
   -- ---------------------
   -- cdv_narr_cond_schd
   -- ---------------------
   SET v_startdtm2 = NOW();
   SET v_marker    = 'DROP AND CREATE TABLE CDV_NARR_COND_SCHD';
   SET v_tgt_tbl   = 'CDV_NARR_COND_SCHD';
   SET v_src_tbl   = 'ICS_NARR_COND_SCHD';
   DROP TABLE IF EXISTS CDV_NARR_COND_SCHD;
   CREATE TABLE CDV_NARR_COND_SCHD 
   ENGINE=MyISAM CHARACTER SET utf8
   AS 
   SELECT DISTINCT ICS_MODULE
        , ICS_NARR_COND_SCHD.KEY_HASH
        , CASE ICS_NARR_COND_SCHD.ACTION_TYPE
            WHEN 'DELETE'
              THEN (SELECT KEY_HASH
                      FROM ics_flow_icis.ICS_NARR_COND_SCHD TBL
                     WHERE TBL.ICS_NARR_COND_SCHD_ID = ICS_NARR_COND_SCHD.ICS_NARR_COND_SCHD_ID)
              ELSE (SELECT KEY_HASH 
                      FROM ICS_NARR_COND_SCHD TBL
                     WHERE TBL.ICS_NARR_COND_SCHD_ID = ICS_NARR_COND_SCHD.ICS_NARR_COND_SCHD_ID)
          END AS MODULE_IDENT
        , ICS_NARR_COND_SCHD.DATA_ELEMENT
        , ICS_NARR_COND_SCHD.ACTION_TYPE
        , ICS_NARR_COND_SCHD.ACTION_CODE
     FROM (/*  1 - NEW  */
           SELECT ICS_NARR_COND_SCHD.ICS_NARR_COND_SCHD_ID
			          , ICS_NARR_COND_SCHD.KEY_HASH
                , 'NEW' AS ACTION_TYPE
                , 1 AS ACTION_CODE
                , 'ICS_NARR_COND_SCHD' AS ICS_MODULE
                , 'ICS_NARR_COND_SCHD' AS DATA_ELEMENT
             FROM ICS_NARR_COND_SCHD
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_NARR_COND_SCHD TBL
                               WHERE TBL.KEY_HASH = ICS_NARR_COND_SCHD.KEY_HASH)
           UNION
           /*  2 - CHANGE  */
           SELECT LOCAL.ICS_NARR_COND_SCHD_ID
                , LOCAL.KEY_HASH
                , 'CHANGE' AS ACTION_TYPE
                , 2 AS ACTION_CODE
                , 'ICS_NARR_COND_SCHD' AS ICS_MODULE
                , 'ICS_NARR_COND_SCHD' AS DATA_ELEMENT
             FROM ICS_NARR_COND_SCHD LOCAL
             JOIN ics_flow_icis.ICS_NARR_COND_SCHD ICIS
               ON (ICIS.KEY_HASH = LOCAL.KEY_HASH)
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_NARR_COND_SCHD 
                               WHERE ICS_NARR_COND_SCHD.DATA_HASH = LOCAL.DATA_HASH)  
           UNION
           /*  3 - DELETE  */
           SELECT ICS_NARR_COND_SCHD.ICS_NARR_COND_SCHD_ID
                , ICS_NARR_COND_SCHD.KEY_HASH
                , 'DELETE' AS ACTION
                , 3 AS ACTION_CODE
                , 'ICS_NARR_COND_SCHD' AS ICS_MODULE
                , 'ICS_NARR_COND_SCHD' AS DATA_ELEMENT
             FROM ics_flow_icis.ICS_NARR_COND_SCHD
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ICS_NARR_COND_SCHD TBL
                               WHERE TBL.KEY_HASH = ICS_NARR_COND_SCHD.KEY_HASH)) ICS_NARR_COND_SCHD;
   --
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'CTAS'        -- pi_process
      ,1);           -- pi_value
   -- ---------------------
   -- cdv_prmt_featr
   -- ---------------------
   SET v_startdtm2 = NOW();
   SET v_marker    = 'DROP AND CREATE TABLE CDV_PRMT_FEATR';
   SET v_tgt_tbl   = 'CDV_PRMT_FEATR';
   SET v_src_tbl   = 'ICS_PRMT_FEATR';
   DROP TABLE IF EXISTS CDV_PRMT_FEATR;
   CREATE TABLE CDV_PRMT_FEATR 
   ENGINE=MyISAM CHARACTER SET utf8
   AS 
   SELECT DISTINCT ICS_MODULE
        , ICS_PRMT_FEATR.KEY_HASH
        , CASE ICS_PRMT_FEATR.ACTION_TYPE
            WHEN 'DELETE'
              THEN (SELECT KEY_HASH
                      FROM ics_flow_icis.ICS_PRMT_FEATR TBL
                     WHERE TBL.ICS_PRMT_FEATR_ID = ICS_PRMT_FEATR.ICS_PRMT_FEATR_ID)
              ELSE (SELECT KEY_HASH 
                      FROM ICS_PRMT_FEATR TBL
                     WHERE TBL.ICS_PRMT_FEATR_ID = ICS_PRMT_FEATR.ICS_PRMT_FEATR_ID)
          END AS MODULE_IDENT
        , ICS_PRMT_FEATR.DATA_ELEMENT
        , ICS_PRMT_FEATR.ACTION_TYPE
        , ICS_PRMT_FEATR.ACTION_CODE
     FROM (/*  1 - NEW  */
           SELECT ICS_PRMT_FEATR.ICS_PRMT_FEATR_ID
			          , ICS_PRMT_FEATR.KEY_HASH
                , 'NEW' AS ACTION_TYPE
                , 1 AS ACTION_CODE
                , 'ICS_PRMT_FEATR' AS ICS_MODULE
                , 'ICS_PRMT_FEATR' AS DATA_ELEMENT
             FROM ICS_PRMT_FEATR
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_PRMT_FEATR TBL
                               WHERE TBL.KEY_HASH = ICS_PRMT_FEATR.KEY_HASH)
           UNION
           /*  2 - CHANGE  */
           SELECT LOCAL.ICS_PRMT_FEATR_ID
                , LOCAL.KEY_HASH
                , 'CHANGE' AS ACTION_TYPE
                , 2 AS ACTION_CODE
                , 'ICS_PRMT_FEATR' AS ICS_MODULE
                , 'ICS_PRMT_FEATR' AS DATA_ELEMENT
             FROM ICS_PRMT_FEATR LOCAL
             JOIN ics_flow_icis.ICS_PRMT_FEATR ICIS
               ON (ICIS.KEY_HASH = LOCAL.KEY_HASH)
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_PRMT_FEATR 
                               WHERE ICS_PRMT_FEATR.DATA_HASH = LOCAL.DATA_HASH)  
           UNION
           /*  3 - DELETE  */
           SELECT ICS_PRMT_FEATR.ICS_PRMT_FEATR_ID
                , ICS_PRMT_FEATR.KEY_HASH
                , 'DELETE' AS ACTION
                , 3 AS ACTION_CODE
                , 'ICS_PRMT_FEATR' AS ICS_MODULE
                , 'ICS_PRMT_FEATR' AS DATA_ELEMENT
             FROM ics_flow_icis.ICS_PRMT_FEATR
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ICS_PRMT_FEATR TBL
                               WHERE TBL.KEY_HASH = ICS_PRMT_FEATR.KEY_HASH)) ICS_PRMT_FEATR;
   --
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'CTAS'        -- pi_process
      ,1);           -- pi_value
   -- ---------------------
   -- cdv_lmt_set
   -- ---------------------
   SET v_startdtm2 = NOW();
   SET v_marker    = 'DROP AND CREATE TABLE CDV_LMT_SET';
   SET v_tgt_tbl   = 'CDV_LMT_SET';
   SET v_src_tbl   = 'ICS_LMT_SET';
   DROP TABLE IF EXISTS CDV_LMT_SET;
   CREATE TABLE CDV_LMT_SET 
   ENGINE=MyISAM CHARACTER SET utf8
   AS 
   SELECT DISTINCT ICS_MODULE
        , ICS_LMT_SET.KEY_HASH
        , CASE ICS_LMT_SET.ACTION_TYPE
            WHEN 'DELETE'
              THEN (SELECT KEY_HASH
                      FROM ics_flow_icis.ICS_LMT_SET TBL
                     WHERE TBL.ICS_LMT_SET_ID = ICS_LMT_SET.ICS_LMT_SET_ID)
              ELSE (SELECT KEY_HASH 
                      FROM ICS_LMT_SET TBL
                     WHERE TBL.ICS_LMT_SET_ID = ICS_LMT_SET.ICS_LMT_SET_ID)
          END AS MODULE_IDENT
        , ICS_LMT_SET.DATA_ELEMENT
        , ICS_LMT_SET.ACTION_TYPE
        , ICS_LMT_SET.ACTION_CODE
     FROM (/*  1 - NEW  */
           SELECT ICS_LMT_SET.ICS_LMT_SET_ID
			          , ICS_LMT_SET.KEY_HASH
                , 'NEW' AS ACTION_TYPE
                , 1 AS ACTION_CODE
                , 'ICS_LMT_SET' AS ICS_MODULE
                , 'ICS_LMT_SET' AS DATA_ELEMENT
             FROM ICS_LMT_SET
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_LMT_SET TBL
                               WHERE TBL.KEY_HASH = ICS_LMT_SET.KEY_HASH)
           UNION
           /*  2 - CHANGE  */
           SELECT LOCAL.ICS_LMT_SET_ID
                , LOCAL.KEY_HASH
                , 'CHANGE' AS ACTION_TYPE
                , 2 AS ACTION_CODE
                , 'ICS_LMT_SET' AS ICS_MODULE
                , 'ICS_LMT_SET' AS DATA_ELEMENT
             FROM ICS_LMT_SET LOCAL
             JOIN ics_flow_icis.ICS_LMT_SET ICIS
               ON (ICIS.KEY_HASH = LOCAL.KEY_HASH)
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_LMT_SET 
                               WHERE ICS_LMT_SET.DATA_HASH = LOCAL.DATA_HASH)  
           UNION
           /*  3 - DELETE  */
           SELECT ICS_LMT_SET.ICS_LMT_SET_ID
                , ICS_LMT_SET.KEY_HASH
                , 'DELETE' AS ACTION
                , 3 AS ACTION_CODE
                , 'ICS_LMT_SET' AS ICS_MODULE
                , 'ICS_LMT_SET' AS DATA_ELEMENT
             FROM ics_flow_icis.ICS_LMT_SET
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ICS_LMT_SET TBL
                               WHERE TBL.KEY_HASH = ICS_LMT_SET.KEY_HASH)) ICS_LMT_SET;
   --
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'CTAS'        -- pi_process
      ,1);           -- pi_value
   -- ---------------------
   -- cdv_lmts
   -- ---------------------
   SET v_startdtm2 = NOW();
   SET v_marker    = 'DROP AND CREATE TABLE CDV_LMTS';
   SET v_tgt_tbl   = 'CDV_LMTS';
   SET v_src_tbl   = 'ICS_LMTS';
   DROP TABLE IF EXISTS CDV_LMTS;
   CREATE TABLE CDV_LMTS 
   ENGINE=MyISAM CHARACTER SET utf8
   AS  
   SELECT DISTINCT ICS_MODULE
        , ICS_LMTS.KEY_HASH
        , CASE ICS_LMTS.ACTION_TYPE
            WHEN 'DELETE'
              THEN (SELECT KEY_HASH
                      FROM ics_flow_icis.ICS_LMTS TBL
                     WHERE TBL.ICS_LMTS_ID = ICS_LMTS.ICS_LMTS_ID)
              ELSE (SELECT KEY_HASH 
                      FROM ICS_LMTS TBL
                     WHERE TBL.ICS_LMTS_ID = ICS_LMTS.ICS_LMTS_ID)
          END AS MODULE_IDENT
        , ICS_LMTS.DATA_ELEMENT
        , ICS_LMTS.ACTION_TYPE
        , ICS_LMTS.ACTION_CODE
     FROM (/*  1 - NEW  */
           SELECT ICS_LMTS.ICS_LMTS_ID
			          , ICS_LMTS.KEY_HASH
                , 'NEW' AS ACTION_TYPE
                , 1 AS ACTION_CODE
                , 'ICS_LMTS' AS ICS_MODULE
                , 'ICS_LMTS' AS DATA_ELEMENT
             FROM ICS_LMTS
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_LMTS TBL
                               WHERE TBL.KEY_HASH = ICS_LMTS.KEY_HASH)
           UNION
           /*  2 - CHANGE  */
           SELECT LOCAL.ICS_LMTS_ID
                , LOCAL.KEY_HASH
                , 'CHANGE' AS ACTION_TYPE
                , 2 AS ACTION_CODE
                , 'ICS_LMTS' AS ICS_MODULE
                , 'ICS_LMTS' AS DATA_ELEMENT
             FROM ICS_LMTS LOCAL
             JOIN ics_flow_icis.ICS_LMTS ICIS
               ON (ICIS.KEY_HASH = LOCAL.KEY_HASH)
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_LMTS 
                               WHERE ICS_LMTS.DATA_HASH = LOCAL.DATA_HASH)  
           UNION
           /*  3 - DELETE  */
           SELECT ICS_LMTS.ICS_LMTS_ID
                , ICS_LMTS.KEY_HASH
                , 'DELETE' AS ACTION
                , 3 AS ACTION_CODE
                , 'ICS_LMTS' AS ICS_MODULE
                , 'ICS_LMTS' AS DATA_ELEMENT
             FROM ics_flow_icis.ICS_LMTS
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ICS_LMTS TBL
                               WHERE TBL.KEY_HASH = ICS_LMTS.KEY_HASH)) ICS_LMTS;
   --
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'CTAS'        -- pi_process
      ,1);           -- pi_value
   -- ---------------------
   -- cdv_param_lmts
   -- ---------------------
   SET v_startdtm2 = NOW();
   SET v_marker    = 'DROP AND CREATE TABLE CDV_PARAM_LMTS';
   SET v_tgt_tbl   = 'CDV_PARAM_LMTS';
   SET v_src_tbl   = 'ICS_PARAM_LMTS';
   DROP TABLE IF EXISTS CDV_PARAM_LMTS;
   CREATE TABLE CDV_PARAM_LMTS 
   ENGINE=MyISAM CHARACTER SET utf8
   AS 
   SELECT DISTINCT ICS_MODULE
        , ICS_PARAM_LMTS.KEY_HASH
        , CASE ICS_PARAM_LMTS.ACTION_TYPE
            WHEN 'DELETE'
              THEN (SELECT KEY_HASH
                      FROM ics_flow_icis.ICS_PARAM_LMTS TBL
                     WHERE TBL.ICS_PARAM_LMTS_ID = ICS_PARAM_LMTS.ICS_PARAM_LMTS_ID)
              ELSE (SELECT KEY_HASH 
                      FROM ICS_PARAM_LMTS TBL
                     WHERE TBL.ICS_PARAM_LMTS_ID = ICS_PARAM_LMTS.ICS_PARAM_LMTS_ID)
          END AS MODULE_IDENT
        , ICS_PARAM_LMTS.DATA_ELEMENT
        , ICS_PARAM_LMTS.ACTION_TYPE
        , ICS_PARAM_LMTS.ACTION_CODE
     FROM (/*  1 - NEW  */
           SELECT ICS_PARAM_LMTS.ICS_PARAM_LMTS_ID
			          , ICS_PARAM_LMTS.KEY_HASH
                , 'NEW' AS ACTION_TYPE
                , 1 AS ACTION_CODE
                , 'ICS_PARAM_LMTS' AS ICS_MODULE
                , 'ICS_PARAM_LMTS' AS DATA_ELEMENT
             FROM ICS_PARAM_LMTS
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_PARAM_LMTS TBL
                               WHERE TBL.KEY_HASH = ICS_PARAM_LMTS.KEY_HASH)
           UNION
           /*  2 - CHANGE  */
           SELECT LOCAL.ICS_PARAM_LMTS_ID
                , LOCAL.KEY_HASH
                , 'CHANGE' AS ACTION_TYPE
                , 2 AS ACTION_CODE
                , 'ICS_PARAM_LMTS' AS ICS_MODULE
                , 'ICS_PARAM_LMTS' AS DATA_ELEMENT
             FROM ICS_PARAM_LMTS LOCAL
             JOIN ics_flow_icis.ICS_PARAM_LMTS ICIS
               ON (ICIS.KEY_HASH = LOCAL.KEY_HASH)
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_PARAM_LMTS 
                               WHERE ICS_PARAM_LMTS.DATA_HASH = LOCAL.DATA_HASH)  
           UNION
           /*  3 - DELETE  */
           SELECT ICS_PARAM_LMTS.ICS_PARAM_LMTS_ID
                , ICS_PARAM_LMTS.KEY_HASH
                , 'DELETE' AS ACTION
                , 3 AS ACTION_CODE
                , 'ICS_PARAM_LMTS' AS ICS_MODULE
                , 'ICS_PARAM_LMTS' AS DATA_ELEMENT
             FROM ics_flow_icis.ICS_PARAM_LMTS
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ICS_PARAM_LMTS TBL
                               WHERE TBL.KEY_HASH = ICS_PARAM_LMTS.KEY_HASH)) ICS_PARAM_LMTS;
   --
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'CTAS'        -- pi_process
      ,1);           -- pi_value
   -- ---------------------
   -- cdv_dsch_mon_rep
   -- ---------------------
   SET v_startdtm2 = NOW();
   SET v_marker    = 'DROP AND CREATE TABLE CDV_DSCH_MON_REP';
   SET v_tgt_tbl   = 'CDV_DSCH_MON_REP';
   SET v_src_tbl   = 'ICS_DSCH_MON_REP';
   DROP TABLE IF EXISTS CDV_DSCH_MON_REP;
   CREATE TABLE CDV_DSCH_MON_REP 
   ENGINE=MyISAM CHARACTER SET utf8
   AS 
   SELECT DISTINCT ICS_MODULE
        , ICS_DSCH_MON_REP.KEY_HASH
        , CASE ICS_DSCH_MON_REP.ACTION_TYPE
            WHEN 'DELETE'
              THEN (SELECT KEY_HASH
                      FROM ics_flow_icis.ICS_DSCH_MON_REP TBL
                     WHERE TBL.ICS_DSCH_MON_REP_ID = ICS_DSCH_MON_REP.ICS_DSCH_MON_REP_ID)
              ELSE (SELECT KEY_HASH 
                      FROM ICS_DSCH_MON_REP TBL
                     WHERE TBL.ICS_DSCH_MON_REP_ID = ICS_DSCH_MON_REP.ICS_DSCH_MON_REP_ID)
          END AS MODULE_IDENT
        , ICS_DSCH_MON_REP.DATA_ELEMENT
        , ICS_DSCH_MON_REP.ACTION_TYPE
        , ICS_DSCH_MON_REP.ACTION_CODE
     FROM (/*  1 - NEW  */
           SELECT ICS_DSCH_MON_REP.ICS_DSCH_MON_REP_ID
			          , ICS_DSCH_MON_REP.KEY_HASH
                , 'NEW' AS ACTION_TYPE
                , 1 AS ACTION_CODE
                , 'ICS_DSCH_MON_REP' AS ICS_MODULE
                , 'ICS_DSCH_MON_REP' AS DATA_ELEMENT
             FROM ICS_DSCH_MON_REP
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_DSCH_MON_REP TBL
                               WHERE TBL.KEY_HASH = ICS_DSCH_MON_REP.KEY_HASH)
           UNION
           /*  2 - CHANGE  */
           SELECT LOCAL.ICS_DSCH_MON_REP_ID
                , LOCAL.KEY_HASH
                , 'CHANGE' AS ACTION_TYPE
                , 2 AS ACTION_CODE
                , 'ICS_DSCH_MON_REP' AS ICS_MODULE
                , 'ICS_DSCH_MON_REP' AS DATA_ELEMENT
             FROM ICS_DSCH_MON_REP LOCAL
             JOIN ics_flow_icis.ICS_DSCH_MON_REP ICIS
               ON (ICIS.KEY_HASH = LOCAL.KEY_HASH)
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_DSCH_MON_REP 
                               WHERE ICS_DSCH_MON_REP.DATA_HASH = LOCAL.DATA_HASH)  
           UNION
           /*  3 - DELETE  */
           SELECT ICS_DSCH_MON_REP.ICS_DSCH_MON_REP_ID
                , ICS_DSCH_MON_REP.KEY_HASH
                , 'DELETE' AS ACTION
                , 3 AS ACTION_CODE
                , 'ICS_DSCH_MON_REP' AS ICS_MODULE
                , 'ICS_DSCH_MON_REP' AS DATA_ELEMENT
             FROM ics_flow_icis.ICS_DSCH_MON_REP
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ICS_DSCH_MON_REP TBL
                               WHERE TBL.KEY_HASH = ICS_DSCH_MON_REP.KEY_HASH)) ICS_DSCH_MON_REP;
   --
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'CTAS'        -- pi_process
      ,1);           -- pi_value
   -- ---------------------
   -- cdv_sngl_evt_viol
   -- ---------------------
   SET v_startdtm2 = NOW();
   SET v_marker    = 'DROP AND CREATE TABLE CDV_SNGL_EVT_VIOL';
   SET v_tgt_tbl   = 'CDV_SNGL_EVT_VIOL';
   SET v_src_tbl   = 'ICS_SNGL_EVT_VIOL';
   DROP TABLE IF EXISTS CDV_SNGL_EVT_VIOL;
   CREATE TABLE CDV_SNGL_EVT_VIOL 
   ENGINE=MyISAM CHARACTER SET utf8
   AS 
   SELECT DISTINCT ICS_MODULE
        , ICS_SNGL_EVT_VIOL.KEY_HASH
        , CASE ICS_SNGL_EVT_VIOL.ACTION_TYPE
            WHEN 'DELETE'
              THEN (SELECT KEY_HASH
                      FROM ics_flow_icis.ICS_SNGL_EVT_VIOL TBL
                     WHERE TBL.ICS_SNGL_EVT_VIOL_ID = ICS_SNGL_EVT_VIOL.ICS_SNGL_EVT_VIOL_ID)
              ELSE (SELECT KEY_HASH 
                      FROM ICS_SNGL_EVT_VIOL TBL
                     WHERE TBL.ICS_SNGL_EVT_VIOL_ID = ICS_SNGL_EVT_VIOL.ICS_SNGL_EVT_VIOL_ID)
          END AS MODULE_IDENT
        , ICS_SNGL_EVT_VIOL.DATA_ELEMENT
        , ICS_SNGL_EVT_VIOL.ACTION_TYPE
        , ICS_SNGL_EVT_VIOL.ACTION_CODE
     FROM (/*  1 - NEW  */
           SELECT ICS_SNGL_EVT_VIOL.ICS_SNGL_EVT_VIOL_ID
			          , ICS_SNGL_EVT_VIOL.KEY_HASH
                , 'NEW' AS ACTION_TYPE
                , 1 AS ACTION_CODE
                , 'ICS_SNGL_EVT_VIOL' AS ICS_MODULE
                , 'ICS_SNGL_EVT_VIOL' AS DATA_ELEMENT
             FROM ICS_SNGL_EVT_VIOL
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_SNGL_EVT_VIOL TBL
                               WHERE TBL.KEY_HASH = ICS_SNGL_EVT_VIOL.KEY_HASH)
           UNION
           /*  2 - CHANGE  */
           SELECT LOCAL.ICS_SNGL_EVT_VIOL_ID
                , LOCAL.KEY_HASH
                , 'CHANGE' AS ACTION_TYPE
                , 2 AS ACTION_CODE
                , 'ICS_SNGL_EVT_VIOL' AS ICS_MODULE
                , 'ICS_SNGL_EVT_VIOL' AS DATA_ELEMENT
             FROM ICS_SNGL_EVT_VIOL LOCAL
             JOIN ics_flow_icis.ICS_SNGL_EVT_VIOL ICIS
               ON (ICIS.KEY_HASH = LOCAL.KEY_HASH)
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_SNGL_EVT_VIOL 
                               WHERE ICS_SNGL_EVT_VIOL.DATA_HASH = LOCAL.DATA_HASH)  
           UNION   
           /*  3 - DELETE  */
           SELECT ICS_SNGL_EVT_VIOL.ICS_SNGL_EVT_VIOL_ID
                , ICS_SNGL_EVT_VIOL.KEY_HASH
                , 'DELETE' AS ACTION
                , 3 AS ACTION_CODE
                , 'ICS_SNGL_EVT_VIOL' AS ICS_MODULE
                , 'ICS_SNGL_EVT_VIOL' AS DATA_ELEMENT
             FROM ics_flow_icis.ICS_SNGL_EVT_VIOL
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ICS_SNGL_EVT_VIOL TBL
                               WHERE TBL.KEY_HASH = ICS_SNGL_EVT_VIOL.KEY_HASH)) ICS_SNGL_EVT_VIOL;
   --
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'CTAS'        -- pi_process
      ,1);           -- pi_value
   -- ---------------------
   -- cdv_cmpl_schd
   -- ---------------------
   SET v_startdtm2 = NOW();
   SET v_marker    = 'DROP AND CREATE TABLE CDV_CMPL_SCHD';
   SET v_tgt_tbl   = 'CDV_CMPL_SCHD';
   SET v_src_tbl   = 'ICS_CMPL_SCHD';
   DROP TABLE IF EXISTS CDV_CMPL_SCHD;
   CREATE TABLE CDV_CMPL_SCHD 
   ENGINE=MyISAM CHARACTER SET utf8
   AS 
   SELECT DISTINCT ICS_MODULE
        , ICS_CMPL_SCHD.KEY_HASH
        , CASE ICS_CMPL_SCHD.ACTION_TYPE
            WHEN 'DELETE'
              THEN (SELECT KEY_HASH
                      FROM ics_flow_icis.ICS_CMPL_SCHD TBL
                     WHERE TBL.ICS_CMPL_SCHD_ID = ICS_CMPL_SCHD.ICS_CMPL_SCHD_ID)
              ELSE (SELECT KEY_HASH 
                      FROM ICS_CMPL_SCHD TBL
                     WHERE TBL.ICS_CMPL_SCHD_ID = ICS_CMPL_SCHD.ICS_CMPL_SCHD_ID)
          END AS MODULE_IDENT
        , ICS_CMPL_SCHD.DATA_ELEMENT
        , ICS_CMPL_SCHD.ACTION_TYPE
        , ICS_CMPL_SCHD.ACTION_CODE
     FROM (/*  1 - NEW  */
           SELECT ICS_CMPL_SCHD.ICS_CMPL_SCHD_ID
			          , ICS_CMPL_SCHD.KEY_HASH
                , 'NEW' AS ACTION_TYPE
                , 1 AS ACTION_CODE
                , 'ICS_CMPL_SCHD' AS ICS_MODULE
                , 'ICS_CMPL_SCHD' AS DATA_ELEMENT
             FROM ICS_CMPL_SCHD
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_CMPL_SCHD TBL
                               WHERE TBL.KEY_HASH = ICS_CMPL_SCHD.KEY_HASH)
           UNION
           /*  2 - CHANGE  */
           SELECT LOCAL.ICS_CMPL_SCHD_ID
                , LOCAL.KEY_HASH
                , 'CHANGE' AS ACTION_TYPE
                , 2 AS ACTION_CODE
                , 'ICS_CMPL_SCHD' AS ICS_MODULE
                , 'ICS_CMPL_SCHD' AS DATA_ELEMENT
             FROM ICS_CMPL_SCHD LOCAL
             JOIN ics_flow_icis.ICS_CMPL_SCHD ICIS
               ON (ICIS.KEY_HASH = LOCAL.KEY_HASH)
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_CMPL_SCHD 
                               WHERE ICS_CMPL_SCHD.DATA_HASH = LOCAL.DATA_HASH)  
           UNION
           /*  3 - DELETE  */
           SELECT ICS_CMPL_SCHD.ICS_CMPL_SCHD_ID
                , ICS_CMPL_SCHD.KEY_HASH
                , 'DELETE' AS ACTION
                , 3 AS ACTION_CODE
                , 'ICS_CMPL_SCHD' AS ICS_MODULE
                , 'ICS_CMPL_SCHD' AS DATA_ELEMENT
             FROM ics_flow_icis.ICS_CMPL_SCHD
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ICS_CMPL_SCHD TBL
                               WHERE TBL.KEY_HASH = ICS_CMPL_SCHD.KEY_HASH)) ICS_CMPL_SCHD;
   --
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'CTAS'        -- pi_process
      ,1);           -- pi_value
   -- ---------------------
   -- cdv_dmr_viol
   -- ---------------------
   SET v_startdtm2 = NOW();
   SET v_marker    = 'DROP AND CREATE TABLE CDV_DMR_VIOL';
   SET v_tgt_tbl   = 'CDV_DMR_VIOL';
   SET v_src_tbl   = 'ICS_DMR_VIOL';
   DROP TABLE IF EXISTS CDV_DMR_VIOL;
   CREATE TABLE CDV_DMR_VIOL 
   ENGINE=MyISAM CHARACTER SET utf8
   AS 
   SELECT DISTINCT ICS_MODULE
        , ICS_DMR_VIOL.KEY_HASH
        , CASE ICS_DMR_VIOL.ACTION_TYPE
            WHEN 'DELETE'
              THEN (SELECT KEY_HASH
                      FROM ics_flow_icis.ICS_DMR_VIOL TBL
                     WHERE TBL.ICS_DMR_VIOL_ID = ICS_DMR_VIOL.ICS_DMR_VIOL_ID)
              ELSE (SELECT KEY_HASH 
                      FROM ICS_DMR_VIOL TBL
                     WHERE TBL.ICS_DMR_VIOL_ID = ICS_DMR_VIOL.ICS_DMR_VIOL_ID)
          END AS MODULE_IDENT
        , ICS_DMR_VIOL.DATA_ELEMENT
        , ICS_DMR_VIOL.ACTION_TYPE
        , ICS_DMR_VIOL.ACTION_CODE
     FROM (/*  1 - NEW  */
           SELECT ICS_DMR_VIOL.ICS_DMR_VIOL_ID
			          , ICS_DMR_VIOL.KEY_HASH
                , 'NEW' AS ACTION_TYPE
                , 1 AS ACTION_CODE
                , 'ICS_DMR_VIOL' AS ICS_MODULE
                , 'ICS_DMR_VIOL' AS DATA_ELEMENT
             FROM ICS_DMR_VIOL
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_DMR_VIOL TBL
                               WHERE TBL.KEY_HASH = ICS_DMR_VIOL.KEY_HASH)
           UNION
           /*  2 - CHANGE  */
           SELECT LOCAL.ICS_DMR_VIOL_ID
                , LOCAL.KEY_HASH
                , 'CHANGE' AS ACTION_TYPE
                , 2 AS ACTION_CODE
                , 'ICS_DMR_VIOL' AS ICS_MODULE
                , 'ICS_DMR_VIOL' AS DATA_ELEMENT
             FROM ICS_DMR_VIOL LOCAL
             JOIN ics_flow_icis.ICS_DMR_VIOL ICIS
               ON (ICIS.KEY_HASH = LOCAL.KEY_HASH)
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_DMR_VIOL 
                               WHERE ICS_DMR_VIOL.DATA_HASH = LOCAL.DATA_HASH)  
           UNION
           /*  3 - DELETE  */
           SELECT ICS_DMR_VIOL.ICS_DMR_VIOL_ID
                , ICS_DMR_VIOL.KEY_HASH
                , 'DELETE' AS ACTION
                , 3 AS ACTION_CODE
                , 'ICS_DMR_VIOL' AS ICS_MODULE
                , 'ICS_DMR_VIOL' AS DATA_ELEMENT
             FROM ics_flow_icis.ICS_DMR_VIOL
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ICS_DMR_VIOL TBL
                               WHERE TBL.KEY_HASH = ICS_DMR_VIOL.KEY_HASH)) ICS_DMR_VIOL;
   --
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'CTAS'        -- pi_process
      ,1);           -- pi_value
   -- ---------------------
   -- cdv_efflu_trade_prtner
   -- ---------------------
   SET v_startdtm2 = NOW();
   SET v_marker    = 'DROP AND CREATE TABLE CDV_EFFLU_TRADE_PRTNER';
   SET v_tgt_tbl   = 'CDV_EFFLU_TRADE_PRTNER';
   SET v_src_tbl   = 'ICS_EFFLU_TRADE_PRTNER';
   DROP TABLE IF EXISTS CDV_EFFLU_TRADE_PRTNER;
   CREATE TABLE CDV_EFFLU_TRADE_PRTNER 
   ENGINE=MyISAM CHARACTER SET utf8
   AS 
   SELECT DISTINCT ICS_MODULE
        , ICS_EFFLU_TRADE_PRTNER.KEY_HASH
        , CASE ICS_EFFLU_TRADE_PRTNER.ACTION_TYPE
            WHEN 'DELETE'
              THEN (SELECT KEY_HASH
                      FROM ics_flow_icis.ICS_EFFLU_TRADE_PRTNER TBL
                     WHERE TBL.ICS_EFFLU_TRADE_PRTNER_ID = ICS_EFFLU_TRADE_PRTNER.ICS_EFFLU_TRADE_PRTNER_ID)
              ELSE (SELECT KEY_HASH 
                      FROM ICS_EFFLU_TRADE_PRTNER TBL
                     WHERE TBL.ICS_EFFLU_TRADE_PRTNER_ID = ICS_EFFLU_TRADE_PRTNER.ICS_EFFLU_TRADE_PRTNER_ID)
          END AS MODULE_IDENT
        , ICS_EFFLU_TRADE_PRTNER.DATA_ELEMENT
        , ICS_EFFLU_TRADE_PRTNER.ACTION_TYPE
        , ICS_EFFLU_TRADE_PRTNER.ACTION_CODE
     FROM (/*  1 - NEW  */
           SELECT ICS_EFFLU_TRADE_PRTNER.ICS_EFFLU_TRADE_PRTNER_ID
			          , ICS_EFFLU_TRADE_PRTNER.KEY_HASH
                , 'NEW' AS ACTION_TYPE
                , 1 AS ACTION_CODE
                , 'ICS_EFFLU_TRADE_PRTNER' AS ICS_MODULE
                , 'ICS_EFFLU_TRADE_PRTNER' AS DATA_ELEMENT
             FROM ICS_EFFLU_TRADE_PRTNER
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_EFFLU_TRADE_PRTNER TBL
                               WHERE TBL.KEY_HASH = ICS_EFFLU_TRADE_PRTNER.KEY_HASH)
           UNION
           /*  2 - CHANGE  */
           SELECT LOCAL.ICS_EFFLU_TRADE_PRTNER_ID
                , LOCAL.KEY_HASH
                , 'CHANGE' AS ACTION_TYPE
                , 2 AS ACTION_CODE
                , 'ICS_EFFLU_TRADE_PRTNER' AS ICS_MODULE
                , 'ICS_EFFLU_TRADE_PRTNER' AS DATA_ELEMENT
             FROM ICS_EFFLU_TRADE_PRTNER LOCAL
             JOIN ics_flow_icis.ICS_EFFLU_TRADE_PRTNER ICIS
               ON (ICIS.KEY_HASH = LOCAL.KEY_HASH)
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_EFFLU_TRADE_PRTNER 
                               WHERE ICS_EFFLU_TRADE_PRTNER.DATA_HASH = LOCAL.DATA_HASH)  
           UNION
           /*  3 - DELETE  */
           SELECT ICS_EFFLU_TRADE_PRTNER.ICS_EFFLU_TRADE_PRTNER_ID
                , ICS_EFFLU_TRADE_PRTNER.KEY_HASH
                , 'DELETE' AS ACTION
                , 3 AS ACTION_CODE
                , 'ICS_EFFLU_TRADE_PRTNER' AS ICS_MODULE
                , 'ICS_EFFLU_TRADE_PRTNER' AS DATA_ELEMENT
             FROM ics_flow_icis.ICS_EFFLU_TRADE_PRTNER
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ICS_EFFLU_TRADE_PRTNER TBL
                               WHERE TBL.KEY_HASH = ICS_EFFLU_TRADE_PRTNER.KEY_HASH)) ICS_EFFLU_TRADE_PRTNER;
   --
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'CTAS'        -- pi_process
      ,1);           -- pi_value
   -- ---------------------
   -- cdv_frml_enfrc_actn
   -- ---------------------
   SET v_startdtm2 = NOW();
   SET v_marker    = 'DROP AND CREATE TABLE CDV_FRML_ENFRC_ACTN';
   SET v_tgt_tbl   = 'CDV_FRML_ENFRC_ACTN';
   SET v_src_tbl   = 'ICS_FRML_ENFRC_ACTN';
   DROP TABLE IF EXISTS CDV_FRML_ENFRC_ACTN;
   CREATE TABLE CDV_FRML_ENFRC_ACTN 
   ENGINE=MyISAM CHARACTER SET utf8
   AS 
   SELECT DISTINCT ICS_MODULE
        , ICS_FRML_ENFRC_ACTN.KEY_HASH
        , CASE ICS_FRML_ENFRC_ACTN.ACTION_TYPE
            WHEN 'DELETE'
              THEN (SELECT KEY_HASH
                      FROM ics_flow_icis.ICS_FRML_ENFRC_ACTN TBL
                     WHERE TBL.ICS_FRML_ENFRC_ACTN_ID = ICS_FRML_ENFRC_ACTN.ICS_FRML_ENFRC_ACTN_ID)
              ELSE (SELECT KEY_HASH 
                      FROM ICS_FRML_ENFRC_ACTN TBL
                     WHERE TBL.ICS_FRML_ENFRC_ACTN_ID = ICS_FRML_ENFRC_ACTN.ICS_FRML_ENFRC_ACTN_ID)
          END AS MODULE_IDENT
        , ICS_FRML_ENFRC_ACTN.DATA_ELEMENT
        , ICS_FRML_ENFRC_ACTN.ACTION_TYPE
        , ICS_FRML_ENFRC_ACTN.ACTION_CODE
     FROM (/*  1 - NEW  */
           SELECT ICS_FRML_ENFRC_ACTN.ICS_FRML_ENFRC_ACTN_ID
			          , ICS_FRML_ENFRC_ACTN.KEY_HASH
                , 'NEW' AS ACTION_TYPE
                , 1 AS ACTION_CODE
                , 'ICS_FRML_ENFRC_ACTN' AS ICS_MODULE
                , 'ICS_FRML_ENFRC_ACTN' AS DATA_ELEMENT
             FROM ICS_FRML_ENFRC_ACTN
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_FRML_ENFRC_ACTN TBL
                               WHERE TBL.KEY_HASH = ICS_FRML_ENFRC_ACTN.KEY_HASH)
           UNION
           /*  2 - CHANGE  */
           SELECT LOCAL.ICS_FRML_ENFRC_ACTN_ID
                , LOCAL.KEY_HASH
                , 'CHANGE' AS ACTION_TYPE
                , 2 AS ACTION_CODE
                , 'ICS_FRML_ENFRC_ACTN' AS ICS_MODULE
                , 'ICS_FRML_ENFRC_ACTN' AS DATA_ELEMENT
             FROM ICS_FRML_ENFRC_ACTN LOCAL
             JOIN ics_flow_icis.ICS_FRML_ENFRC_ACTN ICIS
               ON (ICIS.KEY_HASH = LOCAL.KEY_HASH)
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_FRML_ENFRC_ACTN 
                               WHERE ICS_FRML_ENFRC_ACTN.DATA_HASH = LOCAL.DATA_HASH)  
           UNION
           /*  3 - DELETE  */
           SELECT ICS_FRML_ENFRC_ACTN.ICS_FRML_ENFRC_ACTN_ID
                , ICS_FRML_ENFRC_ACTN.KEY_HASH
                , 'DELETE' AS ACTION
                , 3 AS ACTION_CODE
                , 'ICS_FRML_ENFRC_ACTN' AS ICS_MODULE
                , 'ICS_FRML_ENFRC_ACTN' AS DATA_ELEMENT
             FROM ics_flow_icis.ICS_FRML_ENFRC_ACTN
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ICS_FRML_ENFRC_ACTN TBL
                               WHERE TBL.KEY_HASH = ICS_FRML_ENFRC_ACTN.KEY_HASH)) ICS_FRML_ENFRC_ACTN;
   --
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'CTAS'        -- pi_process
      ,1);           -- pi_value
   -- ---------------------
   -- cdv_infrml_enfrc_actn
   -- ---------------------
   SET v_startdtm2 = NOW();
   SET v_marker    = 'DROP AND CREATE TABLE CDV_INFRML_ENFRC_ACTN';
   SET v_tgt_tbl   = 'CDV_INFRML_ENFRC_ACTN';
   SET v_src_tbl   = 'ICS_INFRML_ENFRC_ACTN';
   DROP TABLE IF EXISTS CDV_INFRML_ENFRC_ACTN;
   CREATE TABLE CDV_INFRML_ENFRC_ACTN 
   ENGINE=MyISAM CHARACTER SET utf8
   AS 
   SELECT DISTINCT ICS_MODULE
        , ICS_INFRML_ENFRC_ACTN.KEY_HASH
        , CASE ICS_INFRML_ENFRC_ACTN.ACTION_TYPE
            WHEN 'DELETE'
              THEN (SELECT KEY_HASH
                      FROM ics_flow_icis.ICS_INFRML_ENFRC_ACTN TBL
                     WHERE TBL.ICS_INFRML_ENFRC_ACTN_ID = ICS_INFRML_ENFRC_ACTN.ICS_INFRML_ENFRC_ACTN_ID)
              ELSE (SELECT KEY_HASH 
                      FROM ICS_INFRML_ENFRC_ACTN TBL
                     WHERE TBL.ICS_INFRML_ENFRC_ACTN_ID = ICS_INFRML_ENFRC_ACTN.ICS_INFRML_ENFRC_ACTN_ID)
          END AS MODULE_IDENT
        , ICS_INFRML_ENFRC_ACTN.DATA_ELEMENT
        , ICS_INFRML_ENFRC_ACTN.ACTION_TYPE
        , ICS_INFRML_ENFRC_ACTN.ACTION_CODE
     FROM (/*  1 - NEW  */
           SELECT ICS_INFRML_ENFRC_ACTN.ICS_INFRML_ENFRC_ACTN_ID
			          , ICS_INFRML_ENFRC_ACTN.KEY_HASH
                , 'NEW' AS ACTION_TYPE
                , 1 AS ACTION_CODE
                , 'ICS_INFRML_ENFRC_ACTN' AS ICS_MODULE
                , 'ICS_INFRML_ENFRC_ACTN' AS DATA_ELEMENT
             FROM ICS_INFRML_ENFRC_ACTN
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_INFRML_ENFRC_ACTN TBL
                               WHERE TBL.KEY_HASH = ICS_INFRML_ENFRC_ACTN.KEY_HASH)
           UNION
           /*  2 - CHANGE  */
           SELECT LOCAL.ICS_INFRML_ENFRC_ACTN_ID
                , LOCAL.KEY_HASH
                , 'CHANGE' AS ACTION_TYPE
                , 2 AS ACTION_CODE
                , 'ICS_INFRML_ENFRC_ACTN' AS ICS_MODULE
                , 'ICS_INFRML_ENFRC_ACTN' AS DATA_ELEMENT
             FROM ICS_INFRML_ENFRC_ACTN LOCAL
             JOIN ics_flow_icis.ICS_INFRML_ENFRC_ACTN ICIS
               ON (ICIS.KEY_HASH = LOCAL.KEY_HASH)
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_INFRML_ENFRC_ACTN 
                               WHERE ICS_INFRML_ENFRC_ACTN.DATA_HASH = LOCAL.DATA_HASH)  
           UNION
           /*  3 - DELETE  */
           SELECT ICS_INFRML_ENFRC_ACTN.ICS_INFRML_ENFRC_ACTN_ID
                , ICS_INFRML_ENFRC_ACTN.KEY_HASH
                , 'DELETE' AS ACTION
                , 3 AS ACTION_CODE
                , 'ICS_INFRML_ENFRC_ACTN' AS ICS_MODULE
                , 'ICS_INFRML_ENFRC_ACTN' AS DATA_ELEMENT
             FROM ics_flow_icis.ICS_INFRML_ENFRC_ACTN
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ICS_INFRML_ENFRC_ACTN TBL
                               WHERE TBL.KEY_HASH = ICS_INFRML_ENFRC_ACTN.KEY_HASH)) ICS_INFRML_ENFRC_ACTN;
   --
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'CTAS'        -- pi_process
      ,1);           -- pi_value
   -- ---------------------
   -- cdv_enfrc_actn_milestone
   -- ---------------------
   SET v_startdtm2 = NOW();
   SET v_marker    = 'DROP AND CREATE TABLE CDV_ENFRC_ACTN_MILESTONE';
   SET v_tgt_tbl   = 'CDV_ENFRC_ACTN_MILESTONE';
   SET v_src_tbl   = 'ICS_ENFRC_ACTN_MILESTONE';
   DROP TABLE IF EXISTS CDV_ENFRC_ACTN_MILESTONE;
   CREATE TABLE CDV_ENFRC_ACTN_MILESTONE 
   ENGINE=MyISAM CHARACTER SET utf8
   AS 
   SELECT DISTINCT ICS_MODULE
        , ICS_ENFRC_ACTN_MILESTONE.KEY_HASH
        , CASE ICS_ENFRC_ACTN_MILESTONE.ACTION_TYPE
            WHEN 'DELETE'
              THEN (SELECT KEY_HASH
                      FROM ics_flow_icis.ICS_ENFRC_ACTN_MILESTONE TBL
                     WHERE TBL.ICS_ENFRC_ACTN_MILESTONE_ID = ICS_ENFRC_ACTN_MILESTONE.ICS_ENFRC_ACTN_MILESTONE_ID)
              ELSE (SELECT KEY_HASH 
                      FROM ICS_ENFRC_ACTN_MILESTONE TBL
                     WHERE TBL.ICS_ENFRC_ACTN_MILESTONE_ID = ICS_ENFRC_ACTN_MILESTONE.ICS_ENFRC_ACTN_MILESTONE_ID)
          END AS MODULE_IDENT
        , ICS_ENFRC_ACTN_MILESTONE.DATA_ELEMENT
        , ICS_ENFRC_ACTN_MILESTONE.ACTION_TYPE
        , ICS_ENFRC_ACTN_MILESTONE.ACTION_CODE
     FROM (/*  1 - NEW  */
           SELECT ICS_ENFRC_ACTN_MILESTONE.ICS_ENFRC_ACTN_MILESTONE_ID
			          , ICS_ENFRC_ACTN_MILESTONE.KEY_HASH
                , 'NEW' AS ACTION_TYPE
                , 1 AS ACTION_CODE
                , 'ICS_ENFRC_ACTN_MILESTONE' AS ICS_MODULE
                , 'ICS_ENFRC_ACTN_MILESTONE' AS DATA_ELEMENT
             FROM ICS_ENFRC_ACTN_MILESTONE
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_ENFRC_ACTN_MILESTONE TBL
                               WHERE TBL.KEY_HASH = ICS_ENFRC_ACTN_MILESTONE.KEY_HASH)
           UNION
           /*  2 - CHANGE  */
           SELECT LOCAL.ICS_ENFRC_ACTN_MILESTONE_ID
                , LOCAL.KEY_HASH
                , 'CHANGE' AS ACTION_TYPE
                , 2 AS ACTION_CODE
                , 'ICS_ENFRC_ACTN_MILESTONE' AS ICS_MODULE
                , 'ICS_ENFRC_ACTN_MILESTONE' AS DATA_ELEMENT
             FROM ICS_ENFRC_ACTN_MILESTONE LOCAL
             JOIN ics_flow_icis.ICS_ENFRC_ACTN_MILESTONE ICIS
               ON (ICIS.KEY_HASH = LOCAL.KEY_HASH)
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_ENFRC_ACTN_MILESTONE 
                               WHERE ICS_ENFRC_ACTN_MILESTONE.DATA_HASH = LOCAL.DATA_HASH)  
           UNION
           /*  3 - DELETE  */
           SELECT ICS_ENFRC_ACTN_MILESTONE.ICS_ENFRC_ACTN_MILESTONE_ID
                , ICS_ENFRC_ACTN_MILESTONE.KEY_HASH
                , 'DELETE' AS ACTION
                , 3 AS ACTION_CODE
                , 'ICS_ENFRC_ACTN_MILESTONE' AS ICS_MODULE
                , 'ICS_ENFRC_ACTN_MILESTONE' AS DATA_ELEMENT
             FROM ics_flow_icis.ICS_ENFRC_ACTN_MILESTONE
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ICS_ENFRC_ACTN_MILESTONE TBL
                               WHERE TBL.KEY_HASH = ICS_ENFRC_ACTN_MILESTONE.KEY_HASH)) ICS_ENFRC_ACTN_MILESTONE;
   --
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'CTAS'        -- pi_process
      ,1);           -- pi_value
   -- ---------------------
   -- cdv_cso_evt_rep
   -- ---------------------
   SET v_startdtm2 = NOW();
   SET v_marker    = 'DROP AND CREATE TABLE CDV_CSO_EVT_REP';
   SET v_tgt_tbl   = 'CDV_CSO_EVT_REP';
   SET v_src_tbl   = 'ICS_CSO_EVT_REP';
   DROP TABLE IF EXISTS CDV_CSO_EVT_REP;
   CREATE TABLE CDV_CSO_EVT_REP 
   ENGINE=MyISAM CHARACTER SET utf8
   AS 
   SELECT DISTINCT ICS_MODULE
        , ICS_CSO_EVT_REP.KEY_HASH
        , CASE ICS_CSO_EVT_REP.ACTION_TYPE
            WHEN 'DELETE'
              THEN (SELECT KEY_HASH
                      FROM ics_flow_icis.ICS_CSO_EVT_REP TBL
                     WHERE TBL.ICS_CSO_EVT_REP_ID = ICS_CSO_EVT_REP.ICS_CSO_EVT_REP_ID)
              ELSE (SELECT KEY_HASH 
                      FROM ICS_CSO_EVT_REP TBL
                     WHERE TBL.ICS_CSO_EVT_REP_ID = ICS_CSO_EVT_REP.ICS_CSO_EVT_REP_ID)
          END AS MODULE_IDENT
        , ICS_CSO_EVT_REP.DATA_ELEMENT
        , ICS_CSO_EVT_REP.ACTION_TYPE
        , ICS_CSO_EVT_REP.ACTION_CODE
     FROM (/*  1 - NEW  */
           SELECT ICS_CSO_EVT_REP.ICS_CSO_EVT_REP_ID
			          , ICS_CSO_EVT_REP.KEY_HASH
                , 'NEW' AS ACTION_TYPE
                , 1 AS ACTION_CODE
                , 'ICS_CSO_EVT_REP' AS ICS_MODULE
                , 'ICS_CSO_EVT_REP' AS DATA_ELEMENT
             FROM ICS_CSO_EVT_REP
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_CSO_EVT_REP TBL
                               WHERE TBL.KEY_HASH = ICS_CSO_EVT_REP.KEY_HASH)
           UNION
           /*  2 - CHANGE  */
           SELECT LOCAL.ICS_CSO_EVT_REP_ID
                , LOCAL.KEY_HASH
                , 'CHANGE' AS ACTION_TYPE
                , 2 AS ACTION_CODE
                , 'ICS_CSO_EVT_REP' AS ICS_MODULE
                , 'ICS_CSO_EVT_REP' AS DATA_ELEMENT
             FROM ICS_CSO_EVT_REP LOCAL
             JOIN ics_flow_icis.ICS_CSO_EVT_REP ICIS
               ON (ICIS.KEY_HASH = LOCAL.KEY_HASH)
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_CSO_EVT_REP 
                               WHERE ICS_CSO_EVT_REP.DATA_HASH = LOCAL.DATA_HASH)  
           UNION
           /*  3 - DELETE  */
           SELECT ICS_CSO_EVT_REP.ICS_CSO_EVT_REP_ID
                , ICS_CSO_EVT_REP.KEY_HASH
                , 'DELETE' AS ACTION
                , 3 AS ACTION_CODE
                , 'ICS_CSO_EVT_REP' AS ICS_MODULE
                , 'ICS_CSO_EVT_REP' AS DATA_ELEMENT
             FROM ics_flow_icis.ICS_CSO_EVT_REP
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ICS_CSO_EVT_REP TBL
                               WHERE TBL.KEY_HASH = ICS_CSO_EVT_REP.KEY_HASH)) ICS_CSO_EVT_REP;
   --
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'CTAS'        -- pi_process
      ,1);           -- pi_value
   -- ---------------------
   -- cdv_sw_evt_rep
   -- ---------------------
   SET v_startdtm2 = NOW();
   SET v_marker    = 'DROP AND CREATE TABLE CDV_SW_EVT_REP';
   SET v_tgt_tbl   = 'CDV_SW_EVT_REP';
   SET v_src_tbl   = 'ICS_SW_EVT_REP';
   DROP TABLE IF EXISTS CDV_SW_EVT_REP;
   CREATE TABLE CDV_SW_EVT_REP 
   ENGINE=MyISAM CHARACTER SET utf8
   AS 
   SELECT DISTINCT ICS_MODULE
        , ICS_SW_EVT_REP.KEY_HASH
        , CASE ICS_SW_EVT_REP.ACTION_TYPE
            WHEN 'DELETE'
              THEN (SELECT KEY_HASH
                      FROM ics_flow_icis.ICS_SW_EVT_REP TBL
                     WHERE TBL.ICS_SW_EVT_REP_ID = ICS_SW_EVT_REP.ICS_SW_EVT_REP_ID)
              ELSE (SELECT KEY_HASH 
                      FROM ICS_SW_EVT_REP TBL
                     WHERE TBL.ICS_SW_EVT_REP_ID = ICS_SW_EVT_REP.ICS_SW_EVT_REP_ID)
          END AS MODULE_IDENT
        , ICS_SW_EVT_REP.DATA_ELEMENT
        , ICS_SW_EVT_REP.ACTION_TYPE
        , ICS_SW_EVT_REP.ACTION_CODE
     FROM (/*  1 - NEW  */
           SELECT ICS_SW_EVT_REP.ICS_SW_EVT_REP_ID
			          , ICS_SW_EVT_REP.KEY_HASH
                , 'NEW' AS ACTION_TYPE
                , 1 AS ACTION_CODE
                , 'ICS_SW_EVT_REP' AS ICS_MODULE
                , 'ICS_SW_EVT_REP' AS DATA_ELEMENT
             FROM ICS_SW_EVT_REP
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_SW_EVT_REP TBL
                               WHERE TBL.KEY_HASH = ICS_SW_EVT_REP.KEY_HASH)
           UNION
           /*  2 - CHANGE  */
           SELECT LOCAL.ICS_SW_EVT_REP_ID
                , LOCAL.KEY_HASH
                , 'CHANGE' AS ACTION_TYPE
                , 2 AS ACTION_CODE
                , 'ICS_SW_EVT_REP' AS ICS_MODULE
                , 'ICS_SW_EVT_REP' AS DATA_ELEMENT
             FROM ICS_SW_EVT_REP LOCAL
             JOIN ics_flow_icis.ICS_SW_EVT_REP ICIS
               ON (ICIS.KEY_HASH = LOCAL.KEY_HASH)
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_SW_EVT_REP 
                            WHERE ICS_SW_EVT_REP.DATA_HASH = LOCAL.DATA_HASH)  
           UNION
           /*  3 - DELETE  */
           SELECT ICS_SW_EVT_REP.ICS_SW_EVT_REP_ID
                , ICS_SW_EVT_REP.KEY_HASH
                , 'DELETE' AS ACTION
                , 3 AS ACTION_CODE
                , 'ICS_SW_EVT_REP' AS ICS_MODULE
                , 'ICS_SW_EVT_REP' AS DATA_ELEMENT
             FROM ics_flow_icis.ICS_SW_EVT_REP
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ICS_SW_EVT_REP TBL
                               WHERE TBL.KEY_HASH = ICS_SW_EVT_REP.KEY_HASH)) ICS_SW_EVT_REP;
   --
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'CTAS'        -- pi_process
      ,1);           -- pi_value
   -- ---------------------
   -- cdv_cafo_annul_rep
   -- ---------------------
   SET v_startdtm2 = NOW();
   SET v_marker    = 'DROP AND CREATE TABLE CDV_CAFO_ANNUL_REP';
   SET v_tgt_tbl   = 'CDV_CAFO_ANNUL_REP';
   SET v_src_tbl   = 'ICS_CAFO_ANNUL_REP';
   DROP TABLE IF EXISTS CDV_CAFO_ANNUL_REP;
   CREATE TABLE CDV_CAFO_ANNUL_REP 
   ENGINE=MyISAM CHARACTER SET utf8
   AS
   SELECT DISTINCT ICS_MODULE
        , ICS_CAFO_ANNUL_REP.KEY_HASH
        , CASE ICS_CAFO_ANNUL_REP.ACTION_TYPE
            WHEN 'DELETE'
              THEN (SELECT KEY_HASH
                      FROM ics_flow_icis.ICS_CAFO_ANNUL_REP TBL
                     WHERE TBL.ICS_CAFO_ANNUL_REP_ID = ICS_CAFO_ANNUL_REP.ICS_CAFO_ANNUL_REP_ID)
              ELSE (SELECT KEY_HASH 
                      FROM ICS_CAFO_ANNUL_REP TBL
                     WHERE TBL.ICS_CAFO_ANNUL_REP_ID = ICS_CAFO_ANNUL_REP.ICS_CAFO_ANNUL_REP_ID)
          END AS MODULE_IDENT
        , ICS_CAFO_ANNUL_REP.DATA_ELEMENT
        , ICS_CAFO_ANNUL_REP.ACTION_TYPE
        , ICS_CAFO_ANNUL_REP.ACTION_CODE
     FROM (/*  1 - NEW  */
           SELECT ICS_CAFO_ANNUL_REP.ICS_CAFO_ANNUL_REP_ID
			          , ICS_CAFO_ANNUL_REP.KEY_HASH
                , 'NEW' AS ACTION_TYPE
                , 1 AS ACTION_CODE
                , 'ICS_CAFO_ANNUL_REP' AS ICS_MODULE
                , 'ICS_CAFO_ANNUL_REP' AS DATA_ELEMENT
             FROM ICS_CAFO_ANNUL_REP
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_CAFO_ANNUL_REP TBL
                               WHERE TBL.KEY_HASH = ICS_CAFO_ANNUL_REP.KEY_HASH)
           UNION
           /*  2 - CHANGE  */
           SELECT LOCAL.ICS_CAFO_ANNUL_REP_ID
                , LOCAL.KEY_HASH
                , 'CHANGE' AS ACTION_TYPE
                , 2 AS ACTION_CODE
                , 'ICS_CAFO_ANNUL_REP' AS ICS_MODULE
                , 'ICS_CAFO_ANNUL_REP' AS DATA_ELEMENT
             FROM ICS_CAFO_ANNUL_REP LOCAL
             JOIN ics_flow_icis.ICS_CAFO_ANNUL_REP ICIS
               ON (ICIS.KEY_HASH = LOCAL.KEY_HASH)
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_CAFO_ANNUL_REP 
                               WHERE ICS_CAFO_ANNUL_REP.DATA_HASH = LOCAL.DATA_HASH)  
           UNION
           /*  3 - DELETE  */
           SELECT ICS_CAFO_ANNUL_REP.ICS_CAFO_ANNUL_REP_ID
                , ICS_CAFO_ANNUL_REP.KEY_HASH
                , 'DELETE' AS ACTION
                , 3 AS ACTION_CODE
                , 'ICS_CAFO_ANNUL_REP' AS ICS_MODULE
                , 'ICS_CAFO_ANNUL_REP' AS DATA_ELEMENT
             FROM ics_flow_icis.ICS_CAFO_ANNUL_REP
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ICS_CAFO_ANNUL_REP TBL
                               WHERE TBL.KEY_HASH = ICS_CAFO_ANNUL_REP.KEY_HASH)) ICS_CAFO_ANNUL_REP;
   --
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'CTAS'        -- pi_process
      ,1);           -- pi_value
   -- ---------------------
   -- cdv_loc_lmts_prog_rep
   -- ---------------------
   SET v_startdtm2 = NOW();
   SET v_marker    = 'DROP AND CREATE TABLE CDV_LOC_LMTS_PROG_REP';
   SET v_tgt_tbl   = 'CDV_LOC_LMTS_PROG_REP';
   SET v_src_tbl   = 'ICS_LOC_LMTS_PROG_REP';
   DROP TABLE IF EXISTS CDV_LOC_LMTS_PROG_REP;
   CREATE TABLE CDV_LOC_LMTS_PROG_REP 
   ENGINE=MyISAM CHARACTER SET utf8
   AS
   SELECT DISTINCT ICS_MODULE
        , ICS_LOC_LMTS_PROG_REP.KEY_HASH
        , CASE ICS_LOC_LMTS_PROG_REP.ACTION_TYPE
            WHEN 'DELETE'
              THEN (SELECT KEY_HASH
                      FROM ics_flow_icis.ICS_LOC_LMTS_PROG_REP TBL
                     WHERE TBL.ICS_LOC_LMTS_PROG_REP_ID = ICS_LOC_LMTS_PROG_REP.ICS_LOC_LMTS_PROG_REP_ID)
              ELSE (SELECT KEY_HASH 
                      FROM ICS_LOC_LMTS_PROG_REP TBL
                     WHERE TBL.ICS_LOC_LMTS_PROG_REP_ID = ICS_LOC_LMTS_PROG_REP.ICS_LOC_LMTS_PROG_REP_ID)
          END AS MODULE_IDENT
        , ICS_LOC_LMTS_PROG_REP.DATA_ELEMENT
        , ICS_LOC_LMTS_PROG_REP.ACTION_TYPE
        , ICS_LOC_LMTS_PROG_REP.ACTION_CODE
     FROM (/*  1 - NEW  */
           SELECT ICS_LOC_LMTS_PROG_REP.ICS_LOC_LMTS_PROG_REP_ID
			          , ICS_LOC_LMTS_PROG_REP.KEY_HASH
                , 'NEW' AS ACTION_TYPE
                , 1 AS ACTION_CODE
                , 'ICS_LOC_LMTS_PROG_REP' AS ICS_MODULE
                , 'ICS_LOC_LMTS_PROG_REP' AS DATA_ELEMENT
             FROM ICS_LOC_LMTS_PROG_REP
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_LOC_LMTS_PROG_REP TBL
                               WHERE TBL.KEY_HASH = ICS_LOC_LMTS_PROG_REP.KEY_HASH)
           UNION
           /*  2 - CHANGE  */
           SELECT LOCAL.ICS_LOC_LMTS_PROG_REP_ID
                , LOCAL.KEY_HASH
                , 'CHANGE' AS ACTION_TYPE
                , 2 AS ACTION_CODE
                , 'ICS_LOC_LMTS_PROG_REP' AS ICS_MODULE
                , 'ICS_LOC_LMTS_PROG_REP' AS DATA_ELEMENT
             FROM ICS_LOC_LMTS_PROG_REP LOCAL
             JOIN ics_flow_icis.ICS_LOC_LMTS_PROG_REP ICIS
               ON (ICIS.KEY_HASH = LOCAL.KEY_HASH)
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_LOC_LMTS_PROG_REP 
                               WHERE ICS_LOC_LMTS_PROG_REP.DATA_HASH = LOCAL.DATA_HASH)  
           UNION
           /*  3 - DELETE  */
           SELECT ICS_LOC_LMTS_PROG_REP.ICS_LOC_LMTS_PROG_REP_ID
                , ICS_LOC_LMTS_PROG_REP.KEY_HASH
                , 'DELETE' AS ACTION
                , 3 AS ACTION_CODE
                , 'ICS_LOC_LMTS_PROG_REP' AS ICS_MODULE
                , 'ICS_LOC_LMTS_PROG_REP' AS DATA_ELEMENT
             FROM ics_flow_icis.ICS_LOC_LMTS_PROG_REP
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ICS_LOC_LMTS_PROG_REP TBL
                               WHERE TBL.KEY_HASH = ICS_LOC_LMTS_PROG_REP.KEY_HASH)) ICS_LOC_LMTS_PROG_REP;
   --
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'CTAS'        -- pi_process
      ,1);           -- pi_value
   -- ---------------------
   -- cdv_pretr_perf_summ
   -- ---------------------
   SET v_startdtm2 = NOW();
   SET v_marker    = 'DROP AND CREATE TABLE CDV_PRETR_PERF_SUMM';
   SET v_tgt_tbl   = 'CDV_PRETR_PERF_SUMM';
   SET v_src_tbl   = 'ICS_PRETR_PERF_SUMM';
   DROP TABLE IF EXISTS CDV_PRETR_PERF_SUMM;
   CREATE TABLE CDV_PRETR_PERF_SUMM 
   ENGINE=MyISAM CHARACTER SET utf8
   AS
   SELECT DISTINCT ICS_MODULE
        , ICS_PRETR_PERF_SUMM.KEY_HASH
        , CASE ICS_PRETR_PERF_SUMM.ACTION_TYPE
            WHEN 'DELETE'
              THEN (SELECT KEY_HASH
                      FROM ics_flow_icis.ICS_PRETR_PERF_SUMM TBL
                     WHERE TBL.ICS_PRETR_PERF_SUMM_ID = ICS_PRETR_PERF_SUMM.ICS_PRETR_PERF_SUMM_ID)
              ELSE (SELECT KEY_HASH 
                      FROM ICS_PRETR_PERF_SUMM TBL
                     WHERE TBL.ICS_PRETR_PERF_SUMM_ID = ICS_PRETR_PERF_SUMM.ICS_PRETR_PERF_SUMM_ID)
          END AS MODULE_IDENT
        , ICS_PRETR_PERF_SUMM.DATA_ELEMENT
        , ICS_PRETR_PERF_SUMM.ACTION_TYPE
        , ICS_PRETR_PERF_SUMM.ACTION_CODE
     FROM (/*  1 - NEW  */
           SELECT ICS_PRETR_PERF_SUMM.ICS_PRETR_PERF_SUMM_ID
			          , ICS_PRETR_PERF_SUMM.KEY_HASH
                , 'NEW' AS ACTION_TYPE
                , 1 AS ACTION_CODE
                , 'ICS_PRETR_PERF_SUMM' AS ICS_MODULE
                , 'ICS_PRETR_PERF_SUMM' AS DATA_ELEMENT
             FROM ICS_PRETR_PERF_SUMM
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_PRETR_PERF_SUMM TBL
                               WHERE TBL.KEY_HASH = ICS_PRETR_PERF_SUMM.KEY_HASH)
           UNION
           /*  2 - CHANGE  */
           SELECT LOCAL.ICS_PRETR_PERF_SUMM_ID
                , LOCAL.KEY_HASH
                , 'CHANGE' AS ACTION_TYPE
                , 2 AS ACTION_CODE
                , 'ICS_PRETR_PERF_SUMM' AS ICS_MODULE
                , 'ICS_PRETR_PERF_SUMM' AS DATA_ELEMENT
             FROM ICS_PRETR_PERF_SUMM LOCAL
             JOIN ics_flow_icis.ICS_PRETR_PERF_SUMM ICIS
               ON (ICIS.KEY_HASH = LOCAL.KEY_HASH)
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_PRETR_PERF_SUMM 
                               WHERE ICS_PRETR_PERF_SUMM.DATA_HASH = LOCAL.DATA_HASH)  
           UNION
           /*  3 - DELETE  */
           SELECT ICS_PRETR_PERF_SUMM.ICS_PRETR_PERF_SUMM_ID
                , ICS_PRETR_PERF_SUMM.KEY_HASH
                , 'DELETE' AS ACTION
                , 3 AS ACTION_CODE
                , 'ICS_PRETR_PERF_SUMM' AS ICS_MODULE
                , 'ICS_PRETR_PERF_SUMM' AS DATA_ELEMENT
             FROM ics_flow_icis.ICS_PRETR_PERF_SUMM
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ICS_PRETR_PERF_SUMM TBL
                               WHERE TBL.KEY_HASH = ICS_PRETR_PERF_SUMM.KEY_HASH)) ICS_PRETR_PERF_SUMM;
   --
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'CTAS'        -- pi_process
      ,1);           -- pi_value
   -- ---------------------
   -- cdv_bs_prog_rep
   -- ---------------------
   SET v_startdtm2 = NOW();
   SET v_marker    = 'DROP AND CREATE TABLE CDV_BS_PROG_REP';
   SET v_tgt_tbl   = 'CDV_BS_PROG_REP';
   SET v_src_tbl   = 'ICS_BS_PROG_REP';
   DROP TABLE IF EXISTS CDV_BS_PROG_REP;
   CREATE TABLE CDV_BS_PROG_REP 
   ENGINE=MyISAM CHARACTER SET utf8
   AS
   SELECT DISTINCT ICS_MODULE
        , ICS_BS_PROG_REP.KEY_HASH
        , CASE ICS_BS_PROG_REP.ACTION_TYPE
            WHEN 'DELETE'
              THEN (SELECT KEY_HASH
                      FROM ics_flow_icis.ICS_BS_PROG_REP TBL
                     WHERE TBL.ICS_BS_PROG_REP_ID = ICS_BS_PROG_REP.ICS_BS_PROG_REP_ID)
              ELSE (SELECT KEY_HASH 
                      FROM ICS_BS_PROG_REP TBL
                     WHERE TBL.ICS_BS_PROG_REP_ID = ICS_BS_PROG_REP.ICS_BS_PROG_REP_ID)
          END AS MODULE_IDENT
        , ICS_BS_PROG_REP.DATA_ELEMENT
        , ICS_BS_PROG_REP.ACTION_TYPE
        , ICS_BS_PROG_REP.ACTION_CODE
     FROM (/*  1 - NEW  */
           SELECT ICS_BS_PROG_REP.ICS_BS_PROG_REP_ID
			          , ICS_BS_PROG_REP.KEY_HASH
                , 'NEW' AS ACTION_TYPE
                , 1 AS ACTION_CODE
                , 'ICS_BS_PROG_REP' AS ICS_MODULE
                , 'ICS_BS_PROG_REP' AS DATA_ELEMENT
             FROM ICS_BS_PROG_REP
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_BS_PROG_REP TBL
                               WHERE TBL.KEY_HASH = ICS_BS_PROG_REP.KEY_HASH)
           UNION
           /*  2 - CHANGE  */
           SELECT LOCAL.ICS_BS_PROG_REP_ID
                , LOCAL.KEY_HASH
                , 'CHANGE' AS ACTION_TYPE
                , 2 AS ACTION_CODE
                , 'ICS_BS_PROG_REP' AS ICS_MODULE
                , 'ICS_BS_PROG_REP' AS DATA_ELEMENT
             FROM ICS_BS_PROG_REP LOCAL
             JOIN ics_flow_icis.ICS_BS_PROG_REP ICIS
               ON (ICIS.KEY_HASH = LOCAL.KEY_HASH)
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_BS_PROG_REP 
                               WHERE ICS_BS_PROG_REP.DATA_HASH = LOCAL.DATA_HASH)  
           UNION
           /*  3 - DELETE  */
           SELECT ICS_BS_PROG_REP.ICS_BS_PROG_REP_ID
                , ICS_BS_PROG_REP.KEY_HASH
                , 'DELETE' AS ACTION
                , 3 AS ACTION_CODE
                , 'ICS_BS_PROG_REP' AS ICS_MODULE
                , 'ICS_BS_PROG_REP' AS DATA_ELEMENT
             FROM ics_flow_icis.ICS_BS_PROG_REP
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ICS_BS_PROG_REP TBL
                               WHERE TBL.KEY_HASH = ICS_BS_PROG_REP.KEY_HASH)) ICS_BS_PROG_REP;
   --
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'CTAS'        -- pi_process
      ,1);           -- pi_value
   -- ---------------------
   -- cdv_sso_annul_rep
   -- ---------------------
   SET v_startdtm2 = NOW();
   SET v_marker    = 'DROP AND CREATE TABLE CDV_SSO_ANNUL_REP';
   SET v_tgt_tbl   = 'CDV_SSO_ANNUL_REP';
   SET v_src_tbl   = 'ICS_SSO_ANNUL_REP';
   DROP TABLE IF EXISTS CDV_SSO_ANNUL_REP;
   CREATE TABLE CDV_SSO_ANNUL_REP 
   ENGINE=MyISAM CHARACTER SET utf8
   AS
   SELECT DISTINCT ICS_MODULE
        , ICS_SSO_ANNUL_REP.KEY_HASH
        , CASE ICS_SSO_ANNUL_REP.ACTION_TYPE
            WHEN 'DELETE'
              THEN (SELECT KEY_HASH
                      FROM ics_flow_icis.ICS_SSO_ANNUL_REP TBL
                     WHERE TBL.ICS_SSO_ANNUL_REP_ID = ICS_SSO_ANNUL_REP.ICS_SSO_ANNUL_REP_ID)
              ELSE (SELECT KEY_HASH 
                      FROM ICS_SSO_ANNUL_REP TBL
                     WHERE TBL.ICS_SSO_ANNUL_REP_ID = ICS_SSO_ANNUL_REP.ICS_SSO_ANNUL_REP_ID)
          END AS MODULE_IDENT
        , ICS_SSO_ANNUL_REP.DATA_ELEMENT
        , ICS_SSO_ANNUL_REP.ACTION_TYPE
        , ICS_SSO_ANNUL_REP.ACTION_CODE
     FROM (/*  1 - NEW  */
           SELECT ICS_SSO_ANNUL_REP.ICS_SSO_ANNUL_REP_ID
			          , ICS_SSO_ANNUL_REP.KEY_HASH
                , 'NEW' AS ACTION_TYPE
                , 1 AS ACTION_CODE
                , 'ICS_SSO_ANNUL_REP' AS ICS_MODULE
                , 'ICS_SSO_ANNUL_REP' AS DATA_ELEMENT
             FROM ICS_SSO_ANNUL_REP
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_SSO_ANNUL_REP TBL
                               WHERE TBL.KEY_HASH = ICS_SSO_ANNUL_REP.KEY_HASH)
           UNION
           /*  2 - CHANGE  */
           SELECT LOCAL.ICS_SSO_ANNUL_REP_ID
                , LOCAL.KEY_HASH
                , 'CHANGE' AS ACTION_TYPE
                , 2 AS ACTION_CODE
                , 'ICS_SSO_ANNUL_REP' AS ICS_MODULE
                , 'ICS_SSO_ANNUL_REP' AS DATA_ELEMENT
             FROM ICS_SSO_ANNUL_REP LOCAL
             JOIN ics_flow_icis.ICS_SSO_ANNUL_REP ICIS
               ON (ICIS.KEY_HASH = LOCAL.KEY_HASH)
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_SSO_ANNUL_REP 
                               WHERE ICS_SSO_ANNUL_REP.DATA_HASH = LOCAL.DATA_HASH)  
           UNION
           /*  3 - DELETE  */
           SELECT ICS_SSO_ANNUL_REP.ICS_SSO_ANNUL_REP_ID
                , ICS_SSO_ANNUL_REP.KEY_HASH
                , 'DELETE' AS ACTION
                , 3 AS ACTION_CODE
                , 'ICS_SSO_ANNUL_REP' AS ICS_MODULE
                , 'ICS_SSO_ANNUL_REP' AS DATA_ELEMENT
             FROM ics_flow_icis.ICS_SSO_ANNUL_REP
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ICS_SSO_ANNUL_REP TBL
                               WHERE TBL.KEY_HASH = ICS_SSO_ANNUL_REP.KEY_HASH)) ICS_SSO_ANNUL_REP;
   --
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'CTAS'        -- pi_process
      ,1);           -- pi_value
   -- ---------------------
   -- cdv_sso_evt_rep
   -- ---------------------
   SET v_startdtm2 = NOW();
   SET v_marker    = 'DROP AND CREATE TABLE CDV_SSO_EVT_REP';
   SET v_tgt_tbl   = 'CDV_SSO_EVT_REP';
   SET v_src_tbl   = 'ICS_SSO_EVT_REP';
   DROP TABLE IF EXISTS CDV_SSO_EVT_REP;
   CREATE TABLE CDV_SSO_EVT_REP 
   ENGINE=MyISAM CHARACTER SET utf8
   AS
   SELECT DISTINCT ICS_MODULE
        , ICS_SSO_EVT_REP.KEY_HASH
        , CASE ICS_SSO_EVT_REP.ACTION_TYPE
            WHEN 'DELETE'
              THEN (SELECT KEY_HASH
                      FROM ics_flow_icis.ICS_SSO_EVT_REP TBL
                     WHERE TBL.ICS_SSO_EVT_REP_ID = ICS_SSO_EVT_REP.ICS_SSO_EVT_REP_ID)
              ELSE (SELECT KEY_HASH 
                      FROM ICS_SSO_EVT_REP TBL
                     WHERE TBL.ICS_SSO_EVT_REP_ID = ICS_SSO_EVT_REP.ICS_SSO_EVT_REP_ID)
          END AS MODULE_IDENT
        , ICS_SSO_EVT_REP.DATA_ELEMENT
        , ICS_SSO_EVT_REP.ACTION_TYPE
        , ICS_SSO_EVT_REP.ACTION_CODE
     FROM (/*  1 - NEW  */
           SELECT ICS_SSO_EVT_REP.ICS_SSO_EVT_REP_ID
			          , ICS_SSO_EVT_REP.KEY_HASH
                , 'NEW' AS ACTION_TYPE
                , 1 AS ACTION_CODE
                , 'ICS_SSO_EVT_REP' AS ICS_MODULE
                , 'ICS_SSO_EVT_REP' AS DATA_ELEMENT
             FROM ICS_SSO_EVT_REP
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_SSO_EVT_REP TBL
                               WHERE TBL.KEY_HASH = ICS_SSO_EVT_REP.KEY_HASH)
           UNION
           /*  2 - CHANGE  */
           SELECT LOCAL.ICS_SSO_EVT_REP_ID
                , LOCAL.KEY_HASH
                , 'CHANGE' AS ACTION_TYPE
                , 2 AS ACTION_CODE
                , 'ICS_SSO_EVT_REP' AS ICS_MODULE
                , 'ICS_SSO_EVT_REP' AS DATA_ELEMENT
             FROM ICS_SSO_EVT_REP LOCAL
             JOIN ics_flow_icis.ICS_SSO_EVT_REP ICIS
               ON (ICIS.KEY_HASH = LOCAL.KEY_HASH)
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_SSO_EVT_REP 
                               WHERE ICS_SSO_EVT_REP.DATA_HASH = LOCAL.DATA_HASH)  
           UNION
           /*  3 - DELETE  */
           SELECT ICS_SSO_EVT_REP.ICS_SSO_EVT_REP_ID
                , ICS_SSO_EVT_REP.KEY_HASH
                , 'DELETE' AS ACTION
                , 3 AS ACTION_CODE
                , 'ICS_SSO_EVT_REP' AS ICS_MODULE
                , 'ICS_SSO_EVT_REP' AS DATA_ELEMENT
             FROM ics_flow_icis.ICS_SSO_EVT_REP
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ICS_SSO_EVT_REP TBL
                               WHERE TBL.KEY_HASH = ICS_SSO_EVT_REP.KEY_HASH)) ICS_SSO_EVT_REP;
   --
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'CTAS'        -- pi_process
      ,1);           -- pi_value
   -- ---------------------
   -- cdv_sso_monthly_evt_rep
   -- ---------------------
   SET v_startdtm2 = NOW();
   SET v_marker    = 'DROP AND CREATE TABLE CDV_SSO_MONTHLY_EVT_REP';
   SET v_tgt_tbl   = 'CDV_SSO_MONTHLY_EVT_REP';
   SET v_src_tbl   = 'ICS_SSO_MONTHLY_EVT_REP';
   DROP TABLE IF EXISTS CDV_SSO_MONTHLY_EVT_REP;
   CREATE TABLE CDV_SSO_MONTHLY_EVT_REP 
   ENGINE=MyISAM CHARACTER SET utf8
   AS
   SELECT DISTINCT ICS_MODULE
        , ICS_SSO_MONTHLY_EVT_REP.KEY_HASH
        , CASE ICS_SSO_MONTHLY_EVT_REP.ACTION_TYPE
            WHEN 'DELETE'
              THEN (SELECT KEY_HASH
                      FROM ics_flow_icis.ICS_SSO_MONTHLY_EVT_REP TBL
                     WHERE TBL.ICS_SSO_MONTHLY_EVT_REP_ID = ICS_SSO_MONTHLY_EVT_REP.ICS_SSO_MONTHLY_EVT_REP_ID)
              ELSE (SELECT KEY_HASH 
                      FROM ICS_SSO_MONTHLY_EVT_REP TBL
                     WHERE TBL.ICS_SSO_MONTHLY_EVT_REP_ID = ICS_SSO_MONTHLY_EVT_REP.ICS_SSO_MONTHLY_EVT_REP_ID)
          END AS MODULE_IDENT
        , ICS_SSO_MONTHLY_EVT_REP.DATA_ELEMENT
        , ICS_SSO_MONTHLY_EVT_REP.ACTION_TYPE
        , ICS_SSO_MONTHLY_EVT_REP.ACTION_CODE
     FROM (/*  1 - NEW  */
           SELECT ICS_SSO_MONTHLY_EVT_REP.ICS_SSO_MONTHLY_EVT_REP_ID
			          , ICS_SSO_MONTHLY_EVT_REP.KEY_HASH
                , 'NEW' AS ACTION_TYPE
                , 1 AS ACTION_CODE
                , 'ICS_SSO_MONTHLY_EVT_REP' AS ICS_MODULE
                , 'ICS_SSO_MONTHLY_EVT_REP' AS DATA_ELEMENT
             FROM ICS_SSO_MONTHLY_EVT_REP
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_SSO_MONTHLY_EVT_REP TBL
                               WHERE TBL.KEY_HASH = ICS_SSO_MONTHLY_EVT_REP.KEY_HASH)
           UNION
           /*  2 - CHANGE  */
           SELECT LOCAL.ICS_SSO_MONTHLY_EVT_REP_ID
                , LOCAL.KEY_HASH
                , 'CHANGE' AS ACTION_TYPE
                , 2 AS ACTION_CODE
                , 'ICS_SSO_MONTHLY_EVT_REP' AS ICS_MODULE
                , 'ICS_SSO_MONTHLY_EVT_REP' AS DATA_ELEMENT
             FROM ICS_SSO_MONTHLY_EVT_REP LOCAL
             JOIN ics_flow_icis.ICS_SSO_MONTHLY_EVT_REP ICIS
               ON (ICIS.KEY_HASH = LOCAL.KEY_HASH)
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_SSO_MONTHLY_EVT_REP 
                               WHERE ICS_SSO_MONTHLY_EVT_REP.DATA_HASH = LOCAL.DATA_HASH)  
           UNION
           /*  3 - DELETE  */
           SELECT ICS_SSO_MONTHLY_EVT_REP.ICS_SSO_MONTHLY_EVT_REP_ID
                , ICS_SSO_MONTHLY_EVT_REP.KEY_HASH
                , 'DELETE' AS ACTION
                , 3 AS ACTION_CODE
                , 'ICS_SSO_MONTHLY_EVT_REP' AS ICS_MODULE
                , 'ICS_SSO_MONTHLY_EVT_REP' AS DATA_ELEMENT
             FROM ics_flow_icis.ICS_SSO_MONTHLY_EVT_REP
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ICS_SSO_MONTHLY_EVT_REP TBL
                               WHERE TBL.KEY_HASH = ICS_SSO_MONTHLY_EVT_REP.KEY_HASH)) ICS_SSO_MONTHLY_EVT_REP;
   --
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'CTAS'        -- pi_process
      ,1);           -- pi_value
   -- ---------------------
   -- cdv_swms_4_prog_rep
   -- ---------------------
   SET v_startdtm2 = NOW();
   SET v_marker    = 'DROP AND CREATE TABLE CDV_SWMS_4_PROG_REP';
   SET v_tgt_tbl   = 'CDV_SWMS_4_PROG_REP';
   SET v_src_tbl   = 'ICS_SWMS_4_PROG_REP';
   DROP TABLE IF EXISTS CDV_SWMS_4_PROG_REP;
   CREATE TABLE CDV_SWMS_4_PROG_REP 
   ENGINE=MyISAM CHARACTER SET utf8
   AS
   SELECT DISTINCT ICS_MODULE
        , ICS_SWMS_4_PROG_REP.KEY_HASH
        , CASE ICS_SWMS_4_PROG_REP.ACTION_TYPE
            WHEN 'DELETE'
              THEN (SELECT KEY_HASH
                      FROM ics_flow_icis.ICS_SWMS_4_PROG_REP TBL
                     WHERE TBL.ICS_SWMS_4_PROG_REP_ID = ICS_SWMS_4_PROG_REP.ICS_SWMS_4_PROG_REP_ID)
              ELSE (SELECT KEY_HASH 
                      FROM ICS_SWMS_4_PROG_REP TBL
                     WHERE TBL.ICS_SWMS_4_PROG_REP_ID = ICS_SWMS_4_PROG_REP.ICS_SWMS_4_PROG_REP_ID)
          END AS MODULE_IDENT
        , ICS_SWMS_4_PROG_REP.DATA_ELEMENT
        , ICS_SWMS_4_PROG_REP.ACTION_TYPE
        , ICS_SWMS_4_PROG_REP.ACTION_CODE
     FROM (/*  1 - NEW  */
           SELECT ICS_SWMS_4_PROG_REP.ICS_SWMS_4_PROG_REP_ID
			          , ICS_SWMS_4_PROG_REP.KEY_HASH
                , 'NEW' AS ACTION_TYPE
                , 1 AS ACTION_CODE
                , 'ICS_SWMS_4_PROG_REP' AS ICS_MODULE
                , 'ICS_SWMS_4_PROG_REP' AS DATA_ELEMENT
             FROM ICS_SWMS_4_PROG_REP
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_SWMS_4_PROG_REP TBL
                               WHERE TBL.KEY_HASH = ICS_SWMS_4_PROG_REP.KEY_HASH)
           UNION
           /*  2 - CHANGE  */
           SELECT LOCAL.ICS_SWMS_4_PROG_REP_ID
                , LOCAL.KEY_HASH
                , 'CHANGE' AS ACTION_TYPE
                , 2 AS ACTION_CODE
                , 'ICS_SWMS_4_PROG_REP' AS ICS_MODULE
                , 'ICS_SWMS_4_PROG_REP' AS DATA_ELEMENT
             FROM ICS_SWMS_4_PROG_REP LOCAL
             JOIN ics_flow_icis.ICS_SWMS_4_PROG_REP ICIS
               ON (ICIS.KEY_HASH = LOCAL.KEY_HASH)
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_SWMS_4_PROG_REP 
                               WHERE ICS_SWMS_4_PROG_REP.DATA_HASH = LOCAL.DATA_HASH)  
           UNION
           /*  3 - DELETE  */
           SELECT ICS_SWMS_4_PROG_REP.ICS_SWMS_4_PROG_REP_ID
                , ICS_SWMS_4_PROG_REP.KEY_HASH
                , 'DELETE' AS ACTION
                , 3 AS ACTION_CODE
                , 'ICS_SWMS_4_PROG_REP' AS ICS_MODULE
                , 'ICS_SWMS_4_PROG_REP' AS DATA_ELEMENT
             FROM ics_flow_icis.ICS_SWMS_4_PROG_REP
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ICS_SWMS_4_PROG_REP TBL
                               WHERE TBL.KEY_HASH = ICS_SWMS_4_PROG_REP.KEY_HASH)) ICS_SWMS_4_PROG_REP;
   --
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'CTAS'        -- pi_process
      ,1);           -- pi_value
   -- ---------------------
   -- cdv_schd_evt_viol
   -- ---------------------
   SET v_startdtm2 = NOW();
   SET v_marker    = 'DROP AND CREATE TABLE CDV_SCHD_EVT_VIOL';
   SET v_tgt_tbl   = 'CDV_SCHD_EVT_VIOL';
   SET v_src_tbl   = 'ICS_SCHD_EVT_VIOL';
   DROP TABLE IF EXISTS CDV_SCHD_EVT_VIOL;
   CREATE TABLE CDV_SCHD_EVT_VIOL 
   ENGINE=MyISAM CHARACTER SET utf8
   AS
   SELECT DISTINCT ICS_MODULE
        , ICS_SCHD_EVT_VIOL.KEY_HASH
        , CASE ICS_SCHD_EVT_VIOL.ACTION_TYPE
            WHEN 'DELETE'
              THEN (SELECT KEY_HASH
                      FROM ics_flow_icis.ICS_SCHD_EVT_VIOL TBL
                     WHERE TBL.ICS_SCHD_EVT_VIOL_ID = ICS_SCHD_EVT_VIOL.ICS_SCHD_EVT_VIOL_ID)
              ELSE (SELECT KEY_HASH 
                      FROM ICS_SCHD_EVT_VIOL TBL
                     WHERE TBL.ICS_SCHD_EVT_VIOL_ID = ICS_SCHD_EVT_VIOL.ICS_SCHD_EVT_VIOL_ID)
          END AS MODULE_IDENT
        , ICS_SCHD_EVT_VIOL.DATA_ELEMENT
        , ICS_SCHD_EVT_VIOL.ACTION_TYPE
        , ICS_SCHD_EVT_VIOL.ACTION_CODE
     FROM (/*  1 - NEW  */
           SELECT ICS_SCHD_EVT_VIOL.ICS_SCHD_EVT_VIOL_ID
			          , ICS_SCHD_EVT_VIOL.KEY_HASH
                , 'NEW' AS ACTION_TYPE
                , 1 AS ACTION_CODE
                , 'ICS_SCHD_EVT_VIOL' AS ICS_MODULE
                , 'ICS_SCHD_EVT_VIOL' AS DATA_ELEMENT
             FROM ICS_SCHD_EVT_VIOL
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_SCHD_EVT_VIOL TBL
                               WHERE TBL.KEY_HASH = ICS_SCHD_EVT_VIOL.KEY_HASH)
           UNION
           /*  2 - CHANGE  */
           SELECT LOCAL.ICS_SCHD_EVT_VIOL_ID
                , LOCAL.KEY_HASH
                , 'CHANGE' AS ACTION_TYPE
                , 2 AS ACTION_CODE
                , 'ICS_SCHD_EVT_VIOL' AS ICS_MODULE
                , 'ICS_SCHD_EVT_VIOL' AS DATA_ELEMENT
             FROM ICS_SCHD_EVT_VIOL LOCAL
             JOIN ics_flow_icis.ICS_SCHD_EVT_VIOL ICIS
               ON (ICIS.KEY_HASH = LOCAL.KEY_HASH)
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_SCHD_EVT_VIOL 
                               WHERE ICS_SCHD_EVT_VIOL.DATA_HASH = LOCAL.DATA_HASH)  
           UNION
           /*  3 - DELETE  */
           SELECT ICS_SCHD_EVT_VIOL.ICS_SCHD_EVT_VIOL_ID
                , ICS_SCHD_EVT_VIOL.KEY_HASH
                , 'DELETE' AS ACTION
                , 3 AS ACTION_CODE
                , 'ICS_SCHD_EVT_VIOL' AS ICS_MODULE
                , 'ICS_SCHD_EVT_VIOL' AS DATA_ELEMENT
             FROM ics_flow_icis.ICS_SCHD_EVT_VIOL
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ICS_SCHD_EVT_VIOL TBL
                               WHERE TBL.KEY_HASH = ICS_SCHD_EVT_VIOL.KEY_HASH)) ICS_SCHD_EVT_VIOL;
   --
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'CTAS'        -- pi_process
      ,1);           -- pi_value
   -- ---------------------
   -- cdv_cmpl_mon_lnk
   -- ---------------------
   SET v_startdtm2 = NOW();
   SET v_marker    = 'DROP AND CREATE TABLE CDV_CMPL_MON_LNK';
   SET v_tgt_tbl   = 'CDV_CMPL_MON_LNK';
   SET v_src_tbl   = 'ICS_CMPL_MON_LNK';
   DROP TABLE IF EXISTS CDV_CMPL_MON_LNK;
   CREATE TABLE CDV_CMPL_MON_LNK 
   ENGINE=MyISAM CHARACTER SET utf8
   AS
   SELECT DISTINCT ICS_MODULE
        , ICS_CMPL_MON_LNK.KEY_HASH
        , CASE ICS_CMPL_MON_LNK.ACTION_TYPE
            WHEN 'DELETE'
              THEN (SELECT KEY_HASH
                      FROM ics_flow_icis.ICS_CMPL_MON_LNK TBL
                     WHERE TBL.ICS_CMPL_MON_LNK_ID = ICS_CMPL_MON_LNK.ICS_CMPL_MON_LNK_ID)
              ELSE (SELECT KEY_HASH 
                      FROM ICS_CMPL_MON_LNK TBL
                     WHERE TBL.ICS_CMPL_MON_LNK_ID = ICS_CMPL_MON_LNK.ICS_CMPL_MON_LNK_ID)
          END AS MODULE_IDENT
        , ICS_CMPL_MON_LNK.DATA_ELEMENT
        , ICS_CMPL_MON_LNK.ACTION_TYPE
        , ICS_CMPL_MON_LNK.ACTION_CODE
     FROM (/*  1 - NEW  */
           SELECT ICS_CMPL_MON_LNK.ICS_CMPL_MON_LNK_ID
			          , ICS_CMPL_MON_LNK.KEY_HASH
                , 'NEW' AS ACTION_TYPE
                , 1 AS ACTION_CODE
                , 'ICS_CMPL_MON_LNK' AS ICS_MODULE
                , 'ICS_CMPL_MON_LNK' AS DATA_ELEMENT
             FROM ICS_CMPL_MON_LNK
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_CMPL_MON_LNK TBL
                               WHERE TBL.KEY_HASH = ICS_CMPL_MON_LNK.KEY_HASH)
           UNION
           /*  2 - CHANGE  */
           SELECT LOCAL.ICS_CMPL_MON_LNK_ID
                , LOCAL.KEY_HASH
                , 'CHANGE' AS ACTION_TYPE
                , 2 AS ACTION_CODE
                , 'ICS_CMPL_MON_LNK' AS ICS_MODULE
                , 'ICS_CMPL_MON_LNK' AS DATA_ELEMENT
             FROM ICS_CMPL_MON_LNK LOCAL
             JOIN ics_flow_icis.ICS_CMPL_MON_LNK ICIS
               ON (ICIS.KEY_HASH = LOCAL.KEY_HASH)
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_CMPL_MON_LNK 
                               WHERE ICS_CMPL_MON_LNK.DATA_HASH = LOCAL.DATA_HASH)  
           UNION
           /*  3 - DELETE  */
           SELECT ICS_CMPL_MON_LNK.ICS_CMPL_MON_LNK_ID
                , ICS_CMPL_MON_LNK.KEY_HASH
                , 'DELETE' AS ACTION
                , 3 AS ACTION_CODE
                , 'ICS_CMPL_MON_LNK' AS ICS_MODULE
                , 'ICS_CMPL_MON_LNK' AS DATA_ELEMENT
             FROM ics_flow_icis.ICS_CMPL_MON_LNK
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ICS_CMPL_MON_LNK TBL
                               WHERE TBL.KEY_HASH = ICS_CMPL_MON_LNK.KEY_HASH)) ICS_CMPL_MON_LNK;
   --
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'CTAS'        -- pi_process
      ,1);           -- pi_value
   -- ---------------------
   -- cdv_enfrc_actn_viol_lnk
   -- ---------------------
   SET v_startdtm2 = NOW();
   SET v_marker    = 'DROP AND CREATE TABLE CDV_ENFRC_ACTN_VIOL_LNK';
   SET v_tgt_tbl   = 'CDV_ENFRC_ACTN_VIOL_LNK';
   SET v_src_tbl   = 'ICS_ENFRC_ACTN_VIOL_LNK';
   DROP TABLE IF EXISTS CDV_ENFRC_ACTN_VIOL_LNK;
   CREATE TABLE CDV_ENFRC_ACTN_VIOL_LNK 
   ENGINE=MyISAM CHARACTER SET utf8
   AS
   SELECT DISTINCT ICS_MODULE
        , ICS_ENFRC_ACTN_VIOL_LNK.KEY_HASH
        , CASE ICS_ENFRC_ACTN_VIOL_LNK.ACTION_TYPE
            WHEN 'DELETE'
              THEN (SELECT KEY_HASH
                      FROM ics_flow_icis.ICS_ENFRC_ACTN_VIOL_LNK TBL
                     WHERE TBL.ICS_ENFRC_ACTN_VIOL_LNK_ID = ICS_ENFRC_ACTN_VIOL_LNK.ICS_ENFRC_ACTN_VIOL_LNK_ID)
              ELSE (SELECT KEY_HASH 
                      FROM ICS_ENFRC_ACTN_VIOL_LNK TBL
                     WHERE TBL.ICS_ENFRC_ACTN_VIOL_LNK_ID = ICS_ENFRC_ACTN_VIOL_LNK.ICS_ENFRC_ACTN_VIOL_LNK_ID)
          END AS MODULE_IDENT
        , ICS_ENFRC_ACTN_VIOL_LNK.DATA_ELEMENT
        , ICS_ENFRC_ACTN_VIOL_LNK.ACTION_TYPE
        , ICS_ENFRC_ACTN_VIOL_LNK.ACTION_CODE
     FROM (/*  1 - NEW  */
           SELECT ICS_ENFRC_ACTN_VIOL_LNK.ICS_ENFRC_ACTN_VIOL_LNK_ID
			          , ICS_ENFRC_ACTN_VIOL_LNK.KEY_HASH
                , 'NEW' AS ACTION_TYPE
                , 1 AS ACTION_CODE
                , 'ICS_ENFRC_ACTN_VIOL_LNK' AS ICS_MODULE
                , 'ICS_ENFRC_ACTN_VIOL_LNK' AS DATA_ELEMENT
             FROM ICS_ENFRC_ACTN_VIOL_LNK
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_ENFRC_ACTN_VIOL_LNK TBL
                               WHERE TBL.KEY_HASH = ICS_ENFRC_ACTN_VIOL_LNK.KEY_HASH)
           UNION
           /*  2 - CHANGE  */
           SELECT LOCAL.ICS_ENFRC_ACTN_VIOL_LNK_ID
                , LOCAL.KEY_HASH
                , 'CHANGE' AS ACTION_TYPE
                , 2 AS ACTION_CODE
                , 'ICS_ENFRC_ACTN_VIOL_LNK' AS ICS_MODULE
                , 'ICS_ENFRC_ACTN_VIOL_LNK' AS DATA_ELEMENT
             FROM ICS_ENFRC_ACTN_VIOL_LNK LOCAL
             JOIN ics_flow_icis.ICS_ENFRC_ACTN_VIOL_LNK ICIS
               ON (ICIS.KEY_HASH = LOCAL.KEY_HASH)
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_ENFRC_ACTN_VIOL_LNK 
                               WHERE ICS_ENFRC_ACTN_VIOL_LNK.DATA_HASH = LOCAL.DATA_HASH)  
           UNION
           /*  3 - DELETE  */
           SELECT ICS_ENFRC_ACTN_VIOL_LNK.ICS_ENFRC_ACTN_VIOL_LNK_ID
                , ICS_ENFRC_ACTN_VIOL_LNK.KEY_HASH
                , 'DELETE' AS ACTION
                , 3 AS ACTION_CODE
                , 'ICS_ENFRC_ACTN_VIOL_LNK' AS ICS_MODULE
                , 'ICS_ENFRC_ACTN_VIOL_LNK' AS DATA_ELEMENT
             FROM ics_flow_icis.ICS_ENFRC_ACTN_VIOL_LNK
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ICS_ENFRC_ACTN_VIOL_LNK TBL
                               WHERE TBL.KEY_HASH = ICS_ENFRC_ACTN_VIOL_LNK.KEY_HASH)) ICS_ENFRC_ACTN_VIOL_LNK;
   --
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'CTAS'        -- pi_process
      ,1);           -- pi_value
   -- ---------------------
   -- cdv_dmr_prog_rep_lnk
   -- ---------------------
   SET v_startdtm2 = NOW();
   SET v_marker    = 'DROP AND CREATE TABLE CDV_DMR_PROG_REP_LNK';
   SET v_tgt_tbl   = 'CDV_DMR_PROG_REP_LNK';
   SET v_src_tbl   = 'ICS_DMR_PROG_REP_LNK';
   DROP TABLE IF EXISTS CDV_DMR_PROG_REP_LNK;
   CREATE TABLE CDV_DMR_PROG_REP_LNK 
   ENGINE=MyISAM CHARACTER SET utf8
   AS
   SELECT DISTINCT ICS_MODULE
        , ICS_DMR_PROG_REP_LNK.KEY_HASH
        , CASE ICS_DMR_PROG_REP_LNK.ACTION_TYPE
            WHEN 'DELETE'
              THEN (SELECT KEY_HASH
                      FROM ics_flow_icis.ICS_DMR_PROG_REP_LNK TBL
                     WHERE TBL.ICS_DMR_PROG_REP_LNK_ID = ICS_DMR_PROG_REP_LNK.ICS_DMR_PROG_REP_LNK_ID)
              ELSE (SELECT KEY_HASH 
                      FROM ICS_DMR_PROG_REP_LNK TBL
                     WHERE TBL.ICS_DMR_PROG_REP_LNK_ID = ICS_DMR_PROG_REP_LNK.ICS_DMR_PROG_REP_LNK_ID)
          END AS MODULE_IDENT
        , ICS_DMR_PROG_REP_LNK.DATA_ELEMENT
        , ICS_DMR_PROG_REP_LNK.ACTION_TYPE
        , ICS_DMR_PROG_REP_LNK.ACTION_CODE
     FROM (/*  1 - NEW  */
           SELECT ICS_DMR_PROG_REP_LNK.ICS_DMR_PROG_REP_LNK_ID
			          , ICS_DMR_PROG_REP_LNK.KEY_HASH
                , 'NEW' AS ACTION_TYPE
                , 1 AS ACTION_CODE
                , 'ICS_DMR_PROG_REP_LNK' AS ICS_MODULE
                , 'ICS_DMR_PROG_REP_LNK' AS DATA_ELEMENT
             FROM ICS_DMR_PROG_REP_LNK
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_DMR_PROG_REP_LNK TBL
                               WHERE TBL.KEY_HASH = ICS_DMR_PROG_REP_LNK.KEY_HASH)
           UNION
           /*  2 - CHANGE  */
           SELECT LOCAL.ICS_DMR_PROG_REP_LNK_ID
                , LOCAL.KEY_HASH
                , 'CHANGE' AS ACTION_TYPE
                , 2 AS ACTION_CODE
                , 'ICS_DMR_PROG_REP_LNK' AS ICS_MODULE
                , 'ICS_DMR_PROG_REP_LNK' AS DATA_ELEMENT
             FROM ICS_DMR_PROG_REP_LNK LOCAL
             JOIN ics_flow_icis.ICS_DMR_PROG_REP_LNK ICIS
               ON (ICIS.KEY_HASH = LOCAL.KEY_HASH)
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_DMR_PROG_REP_LNK 
                               WHERE ICS_DMR_PROG_REP_LNK.DATA_HASH = LOCAL.DATA_HASH)  
           UNION
           /*  3 - DELETE  */
           SELECT ICS_DMR_PROG_REP_LNK.ICS_DMR_PROG_REP_LNK_ID
                , ICS_DMR_PROG_REP_LNK.KEY_HASH
                , 'DELETE' AS ACTION
                , 3 AS ACTION_CODE
                , 'ICS_DMR_PROG_REP_LNK' AS ICS_MODULE
                , 'ICS_DMR_PROG_REP_LNK' AS DATA_ELEMENT
             FROM ics_flow_icis.ICS_DMR_PROG_REP_LNK
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ICS_DMR_PROG_REP_LNK TBL
                               WHERE TBL.KEY_HASH = ICS_DMR_PROG_REP_LNK.KEY_HASH)) ICS_DMR_PROG_REP_LNK;
   --
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'CTAS'        -- pi_process
      ,1);           -- pi_value
   -- ---------------------
   -- cdv_final_order_viol_lnk
   -- ---------------------
   SET v_startdtm2 = NOW();
   SET v_marker    = 'DROP AND CREATE TABLE CDV_FINAL_ORDER_VIOL_LNK';
   SET v_tgt_tbl   = 'CDV_FINAL_ORDER_VIOL_LNK';
   SET v_src_tbl   = 'ICS_FINAL_ORDER_VIOL_LNK';
   DROP TABLE IF EXISTS CDV_FINAL_ORDER_VIOL_LNK;
   CREATE TABLE CDV_FINAL_ORDER_VIOL_LNK 
   ENGINE=MyISAM CHARACTER SET utf8
   AS
   SELECT DISTINCT ICS_MODULE
        , ICS_FINAL_ORDER_VIOL_LNK.KEY_HASH
        , CASE ICS_FINAL_ORDER_VIOL_LNK.ACTION_TYPE
            WHEN 'DELETE'
              THEN (SELECT KEY_HASH
                      FROM ics_flow_icis.ICS_FINAL_ORDER_VIOL_LNK TBL
                     WHERE TBL.ICS_FINAL_ORDER_VIOL_LNK_ID = ICS_FINAL_ORDER_VIOL_LNK.ICS_FINAL_ORDER_VIOL_LNK_ID)
              ELSE (SELECT KEY_HASH 
                      FROM ICS_FINAL_ORDER_VIOL_LNK TBL
                     WHERE TBL.ICS_FINAL_ORDER_VIOL_LNK_ID = ICS_FINAL_ORDER_VIOL_LNK.ICS_FINAL_ORDER_VIOL_LNK_ID)
          END AS MODULE_IDENT
        , ICS_FINAL_ORDER_VIOL_LNK.DATA_ELEMENT
        , ICS_FINAL_ORDER_VIOL_LNK.ACTION_TYPE
        , ICS_FINAL_ORDER_VIOL_LNK.ACTION_CODE
     FROM (/*  1 - NEW  */
           SELECT ICS_FINAL_ORDER_VIOL_LNK.ICS_FINAL_ORDER_VIOL_LNK_ID
                , ICS_FINAL_ORDER_VIOL_LNK.KEY_HASH
                , 'NEW' AS ACTION_TYPE
                , 1 AS ACTION_CODE
                , 'ICS_FINAL_ORDER_VIOL_LNK' AS ICS_MODULE
                , 'ICS_FINAL_ORDER_VIOL_LNK' AS DATA_ELEMENT
             FROM ICS_FINAL_ORDER_VIOL_LNK
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_FINAL_ORDER_VIOL_LNK TBL
                               WHERE TBL.KEY_HASH = ICS_FINAL_ORDER_VIOL_LNK.KEY_HASH)
           UNION
           /*  2 - CHANGE  */
           SELECT LOCAL.ICS_FINAL_ORDER_VIOL_LNK_ID
                , LOCAL.KEY_HASH
                , 'CHANGE' AS ACTION_TYPE
                , 2 AS ACTION_CODE
                , 'ICS_FINAL_ORDER_VIOL_LNK' AS ICS_MODULE
                , 'ICS_FINAL_ORDER_VIOL_LNK' AS DATA_ELEMENT
             FROM ICS_FINAL_ORDER_VIOL_LNK LOCAL
             JOIN ics_flow_icis.ICS_FINAL_ORDER_VIOL_LNK ICIS
               ON (ICIS.KEY_HASH = LOCAL.KEY_HASH)
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ics_flow_icis.ICS_FINAL_ORDER_VIOL_LNK 
                               WHERE ICS_FINAL_ORDER_VIOL_LNK.DATA_HASH = LOCAL.DATA_HASH)  
           UNION
           /*  3 - DELETE  */
           SELECT ICS_FINAL_ORDER_VIOL_LNK.ICS_FINAL_ORDER_VIOL_LNK_ID
                , ICS_FINAL_ORDER_VIOL_LNK.KEY_HASH
                , 'DELETE' AS ACTION
                , 3 AS ACTION_CODE
                , 'ICS_FINAL_ORDER_VIOL_LNK' AS ICS_MODULE
                , 'ICS_FINAL_ORDER_VIOL_LNK' AS DATA_ELEMENT
             FROM ics_flow_icis.ICS_FINAL_ORDER_VIOL_LNK
            WHERE NOT EXISTS (SELECT 'X'
                                FROM ICS_FINAL_ORDER_VIOL_LNK TBL
                               WHERE TBL.KEY_HASH = ICS_FINAL_ORDER_VIOL_LNK.KEY_HASH)) ICS_FINAL_ORDER_VIOL_LNK;
   --
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'CTAS'        -- pi_process
      ,1);           -- pi_value
   --
   ELSE
   -- 
   -- NOTE:
   -- The 3 tables below are used in the last CDC SP - cdc_process_ics_tbls_sp
   -- drop & create the tables here, so that when an exception is raised
   -- then we can rollback.
   -- ================
   -- CDC_STG_PROG_LNK
   -- ================
   SET v_marker = 'DROP AND CREATE TABLE CDC_TMP_PROG_LNK';
   DROP TABLE IF EXISTS CDC_TMP_PROG_LNK ;
   CREATE TABLE CDC_TMP_PROG_LNK AS
   SELECT CAST(NULL                    AS BINARY(36)) NEW_ICS_DMR_PROG_REP_LNK_ID
         ,CAST(ICS_DMR_PROG_REP_LNK_ID AS BINARY(36)) ICS_DMR_PROG_REP_LNK_ID
         ,CAST(PRMT_IDENT              AS CHAR(9))    PRMT_IDENT
         ,CAST(PRMT_FEATR_IDENT        AS CHAR(4))    PRMT_FEATR_IDENT
         ,CAST(LMT_SET_DESIGNATOR      AS CHAR(2))    LMT_SET_DESIGNATOR
         ,CAST(MON_PERIOD_END_DATE     AS DATETIME)   MON_PERIOD_END_DATE
         ,CAST(KEY_HASH                AS BINARY(32)) KEY_HASH
         ,CAST(DATA_HASH               AS BINARY(32)) DATA_HASH
     FROM ics_flow_icis.ICS_DMR_PROG_REP_LNK 
    WHERE 1=0;
   -- ====================
   -- CDC_STG_CMPL_MON_LNK
   -- ====================
   SET v_marker = 'DROP AND CREATE TABLE CDC_STG_CMPL_MON_LNK';
   DROP TABLE IF EXISTS CDC_TMP_CMPL_MON_LNK ;  
   CREATE TABLE CDC_TMP_CMPL_MON_LNK AS
   SELECT CAST(NULL                AS BINARY(36))  NEW_ICS_CMPL_MON_LNK_ID
         ,CAST(ICS_CMPL_MON_LNK_ID AS BINARY(36))  ICS_CMPL_MON_LNK_ID
         ,CAST(SRC_SYSTM_IDENT     AS CHAR(50))    SRC_SYSTM_IDENT
         ,CAST(PRMT_IDENT          AS CHAR(9))     PRMT_IDENT
         ,CAST(CMPL_MON_CATG_CODE  AS CHAR(3))     CMPL_MON_CATG_CODE
         ,CAST(CMPL_MON_DATE       AS DATETIME)    CMPL_MON_DATE
         ,CAST(NULL                AS BINARY(32))  KEY_HASH
         ,CAST(NULL                AS BINARY(32))  DATA_HASH
     FROM ics_flow_icis.ICS_CMPL_MON_LNK 
    WHERE 1=0;
   -- ===============
   -- CDC_STG_EAV_LNK
   -- ===============
   SET v_marker = 'DROP AND CREATE TABLE CDC_TMP_EAV_LNK';
   DROP TABLE IF EXISTS CDC_TMP_EAV_LNK ;  
   CREATE TABLE CDC_TMP_EAV_LNK AS
   SELECT CAST(NULL                       AS BINARY(36))  NEW_ICS_ENFRC_ACTN_VIOL_LNK_ID
         ,CAST(ICS_ENFRC_ACTN_VIOL_LNK_ID AS BINARY(36))  ICS_ENFRC_ACTN_VIOL_LNK_ID
         ,CAST(ENFRC_ACTN_IDENT           AS CHAR(20))    ENFRC_ACTN_IDENT
         ,CAST(SRC_SYSTM_IDENT            AS CHAR(50))    SRC_SYSTM_IDENT
         ,CAST(TRANSACTION_TYPE           AS CHAR(1))     TRANSACTION_TYPE
         ,CAST(TRANSACTION_TIMESTAMP      AS DATETIME)    TRANSACTION_TIMESTAMP
         ,CAST(NULL                       AS BINARY(32))  KEY_HASH
         ,CAST(NULL                       AS BINARY(32))  DATA_HASH
     FROM ics_flow_icis.ICS_ENFRC_ACTN_VIOL_LNK
    WHERE 1=0;
   -- ------------
   -- TMP_ICS_HASH
   -- ------------
   SET v_marker = 'DROP AND CREATE TMP_ICS_HASH';
   DROP TABLE IF EXISTS TMP_ICS_HASH;
   CREATE TABLE TMP_ICS_HASH AS
   SELECT CAST(NULL  AS BINARY(32)) KEY_HASH
         ,CAST(NULL  AS BINARY(32)) DATA_HASH
     FROM ICS_PAYLOAD
    WHERE 1=0;
   --
   SET v_marker = 'CREATE INDEX tmp_tmpicshash_keyhash';
   CREATE INDEX tmp_tmpicshash_keyhash ON TMP_ICS_HASH(KEY_HASH);
   -- ----------------
   -- TMP_NEW_ICS_HASH
   -- ----------------
   SET v_marker = 'DROP AND CREATE TMP_NEW_ICS_HASH';
   DROP TABLE IF EXISTS TMP_NEW_ICS_HASH;
   CREATE TABLE TMP_NEW_ICS_HASH AS
   SELECT CAST(NULL  AS BINARY(32)) KEY_HASH
         ,CAST(NULL  AS BINARY(32)) DATA_HASH
     FROM ICS_PAYLOAD
    WHERE 1=0;
   --
   END IF;
    
   -- -------------- --
   --  END PROCEDURE --
   -- -------------- --
   SET v_marker = 'CALL ics_etl_log_sp END';
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_sp_name     -- pi_marker
      ,NULL          -- pi_tgt_tbl
      ,NULL          -- pi_src_tbl 
      ,v_startdtm    -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'COMPLETED'   -- pi_process
      ,0);           -- pi_value
   --
   SET po_status = 0;
   SET po_errm   = 'COMPLETED';
   --
END