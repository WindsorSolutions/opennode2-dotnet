DROP TABLE IF EXISTS stg_permit_main;
CREATE TABLE stg_permit_main
   (PERMIT_ID                     VARCHAR(36) 
   ,PERMIT_CATEGORY_CODE          VARCHAR(50)
   ,PERMIT_TYPE_CODE              VARCHAR(50)
   ,PERMIT_ACTION_ID              VARCHAR(36) 
   ,PERMIT_ACTION_STATUS_CODE     VARCHAR(50)   
   ,PERMIT_ACTION_TYPE_CODE       VARCHAR(50)   
   ,FACILITY_ID                   VARBINARY(36)   
   ,IS_MASTER                     BIT 
   ,ASSC_MASTER_GNRL_PRMT_IDENT   VARCHAR(9)
   ,SRC_SYSTEM_IDENT              VARCHAR(36) 
   ,PRMT_IDENT                    VARCHAR(50) 
   ,ISSUE_DATE                    DATETIME
   ,EFFECTIVE_DATE                DATETIME
   ,EXPIRATION_DATE               DATETIME
   ,PRMT_ISSUE_DATE               DATETIME 
   ,PRMT_EFFECTIVE_DATE           DATETIME 
   ,PRMT_EXPR_DATE                DATETIME 
   ,DMR_COGNZNT_OFCL              VARCHAR(511) 
   ,DMR_COGNZNT_OFCL_TELEPH_NUM   VARCHAR(15)
   ,TTL_APPL_DSGN_FLOW_NUM        DECIMAL(15,7)
   ,TTL_APPL_AVER_FLOW_NUM        DECIMAL(15,7)
   ,APPL_RCVD_DATE                DATETIME
   ,PRMT_APPL_CMPL_DATE           DATETIME
   ,PRMT_USR_DFND_DAT_ELM_1_TXT   VARCHAR(4000) 
   ,PRMT_CMNTS_TXT                VARCHAR(4000) 
   ,ICIS_REF_AFFILIATION_TYPE     VARCHAR(3)
   ,AFFIL_TYPE_TXT                VARCHAR(3) 
   ,ORG_FRML_NAME                 VARCHAR(255) 
   ,MAILING_ADDR_TXT              VARCHAR(100) 
   ,MAILING_ADDR_CITY_NAME        VARCHAR(100) 
   ,MAILING_ADDR_ST_CODE          VARCHAR(2) 
   ,MAILING_ADDR_ZIP_CODE         VARCHAR(50) 
   ,MAILING_ADDR_COUNTRY_CODE     VARCHAR(2) 
   ,FIRST_NAME                    VARCHAR(255) 
   ,LAST_NAME                     VARCHAR(255) 
   ,TITLE                         VARCHAR(50) 
   ,ELEC_ADDR_TXT                 VARCHAR(255) 
   ,EFFLU_GUIDE_CODE              VARCHAR(3)
   ,TELEPH_NUM_TYPE_CODE          VARCHAR(3) 
   ,TELEPHONE_NUMBER              VARCHAR(10) 
   ,TELEPH_EXT_NUM                VARCHAR(20) 
   ,FAC_SITE_NAME                 VARCHAR(250) 
   ,LOC_ADDR_TXT                  VARCHAR(255) 
   ,LOCALITY_NAME                 VARCHAR(100) 
   ,LOC_ST_CODE                   VARCHAR(2) 
   ,LOC_ZIP_CODE                  VARCHAR(50) 
   ,LOC_COUNTRY_CODE              VARCHAR(2) 
   ,FAC_TYPE_OF_OWNERSHIP_CODE    VARCHAR(3) 
   ,LAT_MEAS                      DECIMAL(18,7) 
   ,LONG_MEAS                     DECIMAL(18,7) 
   ,HORZ_ACCURACY_MEAS            INT 
   ,GEOMETRIC_TYPE_CODE           VARCHAR(3) 
   ,HORZ_COLL_METHOD_CODE         VARCHAR(50) 
   ,HORZ_REF_DATUM_CODE           VARCHAR(50) 
   ,REF_POINT_CODE                VARCHAR(50) 
   ,SRC_MAP_SCALE_NUM             INT 
   ,NAICS_CODE                    VARCHAR(6) 
   ,NAICS_PRIMARY_IND_CODE        VARCHAR(1) 
   ,SIC_CODE                      VARCHAR(4) 
   ,SIC_PRIMARY_IND_CODE          VARCHAR(1) 
   ,ICS_BASIC_PRMT_ID             VARBINARY(36) 
   ,ICS_GNRL_PRMT_ID              VARBINARY(36) 
   ,ICS_CONTACT_ID                VARBINARY(36) 
   ,ICS_FAC_ID                    VARBINARY(36) 
   ,ICS_UNPRMT_FAC_ID             VARBINARY(36) 
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `ics_etl_log`;
CREATE TABLE `ics_etl_log`
   (`ics_etl_log_id`          INT           NOT NULL AUTO_INCREMENT
   ,`ics_etl_sp_name`         VARCHAR(64)   NOT NULL
   ,`ics_etl_target_table`    VARCHAR(64)   DEFAULT NULL
   ,`ics_etl_source_table`    VARCHAR(64)   DEFAULT NULL
   ,`ics_etl_sp_marker`       VARCHAR(255)  DEFAULT NULL
   ,`ics_etl_sp_startdtm`     DATETIME      DEFAULT NULL
   ,`ics_etl_sp_enddtm`       DATETIME      DEFAULT NULL
   ,`ics_etl_process`         VARCHAR(30)   DEFAULT NULL
   ,`ics_etl_value`           INT           DEFAULT 0
   ,PRIMARY KEY (`ics_etl_log_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4291 DEFAULT CHARSET=utf8;