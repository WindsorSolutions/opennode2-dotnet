/*
Copyright (c) 2014, The Environmental Council of the States (ECOS)
All rights reserved.
 
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
 
 * Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
 * Neither the name of the ECOS nor the names of its contributors may
   be used to endorse or promote products derived from this software
   without specific prior written permission.
 
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/

/******************************************************************************************************************************
** Object Name:  ICA_DATA_PREP_MASTER
**
** Author:  Windsor Solutions, Inc.
**
** Description:  This is a template stored procedure was developed for processing ICIS data for exchange via OPENNODE2.  This 
**               stored procedure determines if the system state is ready for ICIS data processing, and if so initiate those
**               processes, otherwise it will skip processing until the state of the system is ready for a new batch of ICIS 
**               data processing.
**
** Revision History:      
** ----------------------------------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ----------------------------------------------------------------------------------------------------------------------------
** 07/01/2014    Windsor     Created
**
******************************************************************************************************************************/
CREATE OR REPLACE PROCEDURE "ICA_FLOW_LOCAL"."ICA_DATA_PREP_MASTER" (p_ica_subm_track_id OUT VARCHAR)

AS 

/* 
 * Delare the variable to to hold the newly created row in 
 * ica_subm_track associated with the new workflow
 */
 v_ica_subm_track_id VARCHAR(50); 
 v_error_message VARCHAR(2048);
 v_error_number NUMBER;
 v_process VARCHAR(30);
 e_return EXCEPTION;
 
 v_workflow_cntr NUMBER;

BEGIN 

  v_process := 'ICA_DATA_PREP_MASTER';

 /*  
  *  Ensure there are no existing workflows in process. If there are, quit without returning an ID.
  */
  SELECT COUNT(1)
    INTO v_workflow_cntr
    FROM ica_subm_track
   WHERE workflow_stat = 'Pending'; 

  IF (v_workflow_cntr > 0) THEN
    BEGIN
      p_ica_subm_track_id := NULL;
      RETURN;
    END;
  END IF;
  
  
  
 /* Safe to proceed. Create and commit a new workflow record */
  SELECT SYS_GUID()
    INTO v_ica_subm_track_id
    FROM DUAL;

  INSERT INTO ica_subm_track 
       ( ica_subm_track_id
       , workflow_stat
       , workflow_stat_message) 
  VALUES( v_ica_subm_track_id
        , 'Pending'
        , 'ETL begun');
  COMMIT;
     
 /* 
  *  Call the stored procedure to extract ICIS data from source data database.
  *  NOTE:  This stored procedure will need to be independently developed and 
  *         should populate the set of "LOCAL" ICS staging tables.
  */
  v_process := 'ICA_ETL';
  ICA_ETL;

 /* 
  *  Update the workflow record to track completion of ETL date/time.
  */
  UPDATE ica_subm_track 
     SET etl_cmpl_date_time = SYSDATE() 
       , workflow_stat_message = 'ETL Completed | Begin Change Processing'
   WHERE ica_subm_track_id = v_ica_subm_track_id;

 /* 
  *  Call the stored procedure to compare data changes between LOCAL and ICIS and set
  *  transaction codes for bundling and submission to an exchange partner via OPENNODE.
  */
  v_process := 'ICA_CHANGE_DETECTION';
  ICA_CHANGE_DETECTION;

 /* 
  *  Update the workflow record to track completion of change detection date/time.
  */
 UPDATE ica_subm_track 
    SET det_change_cmpl_date_time = SYSDATE() 
       , workflow_stat_message = 'Change Processing Completed'
  WHERE ica_subm_track_id = v_ica_subm_track_id;

 /* 
  *  Return current workflow identifier
  */
  p_ica_subm_track_id := v_ica_subm_track_id;

 /* 
  *  Add any additional SQL logic required after the change detection process completes.
  */
  --  Add additional database processing here if needed...
  
  /*
   *  Handle any runtime errors
   */
  EXCEPTION WHEN OTHERS THEN
        
    v_error_message := SUBSTR(SQLERRM, 1, 200);
    v_error_number := SQLCODE;
    
    /*  
     *  Set workflow status to failed.
     */
     UPDATE ica_subm_track 
        SET workflow_stat = 'Failed'
          , workflow_stat_message = v_process || ': ' || v_error_message 
      WHERE ica_subm_track_id = v_ica_subm_track_id;

     --Send the error back up to the calling code. If the ETL is being called from the plugin, this will trigger the plugin to log the failure and quit
     p_ica_subm_track_id := 'ICA_DATA_PREP_MASTER Failed:  ' || v_error_number || ' - ' || v_error_message;
     RAISE;

END ICA_DATA_PREP_MASTER;