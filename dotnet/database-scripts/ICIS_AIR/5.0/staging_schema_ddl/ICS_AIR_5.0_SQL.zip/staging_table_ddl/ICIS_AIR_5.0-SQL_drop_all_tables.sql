/*

Copyright (c) 2014, The Environmental Council of the States (ECOS)
All rights reserved.
 
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
 
 * Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
 * Neither the name of the ECOS nor the names of its contributors may
   be used to endorse or promote products derived from this software
   without specific prior written permission.
 
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.

*/

/******************************************************************************************************************
 *
 *  Script Name:  ICIS_AIR_5.0-SQL_drop_all_tables.sql
 *
 *  Company:  Windsor Solutions, Inc.
 *  
 *  Purpose:  This script drops all tables in the ICIS-AIR OpenNode2 Schema.
 *   
 *  Maintenance:
 *  
 *    Analyst         Date            Comment 
 *    ----------      ----------      ------------------------------------------------------------------------------
 *    Windsor         05/13/2014      Created.
 *    Windsor         07/09/2014      Added 4 additional payloads.
 *   
 ******************************************************************************************************************/

-- ICIS Air Schema --
DROP TABLE ICA_OTHR_PATHWAY_ACTY;
DROP TABLE ICA_CASE_FILE_CMNT_TXT;
DROP TABLE ICA_LNK_CASE_FILE;
DROP TABLE ICA_LNK_CMPL_MON;
DROP TABLE ICA_LNK_DA_ENFRC_ACTN;
DROP TABLE ICA_POLUT_DA_CLASS;
DROP TABLE ICA_POLUT_EPA_CLASS;
DROP TABLE ICA_VIOL;
DROP TABLE ICA_CASE_FILE_LNK;
DROP TABLE ICA_CMPL_MON_LNK;
DROP TABLE ICA_CMPL_INSP_TYPE;
DROP TABLE ICA_CMPL_MON_STRGY;
DROP TABLE ICA_ENFRC_ACTN_CMNT_TXT;
DROP TABLE ICA_ENFRC_ACTN_GOV_CNTCT;
DROP TABLE ICA_ENFRC_ACTN_TYPE;
DROP TABLE ICA_ENFRC_AGNCY_TYPE;
DROP TABLE ICA_FAC_IDENT;
DROP TABLE ICA_FINAL_ORDER_FAC_IDENT;
DROP TABLE ICA_GEO_COORD;
DROP TABLE ICA_INFRML_EA_CMNT_TXT;
DROP TABLE ICA_INSP_CMNT_TXT;
DROP TABLE ICA_INSP_GOV_CNTCT;
DROP TABLE ICA_METHOD;
DROP TABLE ICA_NAICS_CODE;
DROP TABLE ICA_NAT_PRIO;
DROP TABLE ICA_POLUT;
DROP TABLE ICA_POLUTS;
DROP TABLE ICA_PORT_SRC;
DROP TABLE ICA_PROG;
DROP TABLE ICA_PROG_SUBPART;
DROP TABLE ICA_PROGS;
DROP TABLE ICA_PROGS_VIOL;
DROP TABLE ICA_RGNL_PRIO;
DROP TABLE ICA_SENS_CMNT_TXT;
DROP TABLE ICA_SIC_CODE;
DROP TABLE ICA_STCK_TST_OBS_AGNCY_TYPE;
DROP TABLE ICA_STCK_TST_PURPOSE;
DROP TABLE ICA_TELEPH;
DROP TABLE ICA_TST_RSLTS;
DROP TABLE ICA_TVACC_REVIEW;
DROP TABLE ICA_UNIVERSE_IND;
DROP TABLE ICA_STCK_TST;
DROP TABLE ICA_FAC_ADDR;
DROP TABLE ICA_DA_FINAL_ORDER;
DROP TABLE ICA_CNTCT;
DROP TABLE ICA_DA_FRML_ENFRC_ACTN;
DROP TABLE ICA_DA_INFRML_ENFRC_ACTN;
DROP TABLE ICA_TVACC;
DROP TABLE ICA_DA_CMPL_MON;
DROP TABLE ICA_FAC;
DROP TABLE ICA_DA_CASE_FILE;
DROP TABLE ICA_DA_ENFRC_ACTN_LNK;
DROP TABLE ICA_DA_ENFRC_ACTN_MILSTN;
DROP TABLE ICA_PAYLOAD;

-- ICIS Air Utility --
DROP TABLE ICA_SUBM_HIST;
DROP TABLE ICA_SUBM_TRACK;
DROP TABLE ICA_SUBM_RSLTS;
DROP TABLE ICA_KEY_HASH;
DROP TABLE ICA_DATA_HASH;