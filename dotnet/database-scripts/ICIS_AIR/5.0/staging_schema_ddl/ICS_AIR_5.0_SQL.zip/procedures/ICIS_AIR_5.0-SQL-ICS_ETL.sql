/*
Copyright (c) 2014, The Environmental Council of the States (ECOS)
All rights reserved.
 
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
 
 * Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
 * Neither the name of the ECOS nor the names of its contributors may
   be used to endorse or promote products derived from this software
   without specific prior written permission.
 
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.ICA_ETL') AND type = N'P')
DROP PROCEDURE dbo.ICA_ETL
GO

/******************************************************************************************************************************
** Object Name: ICA_ETL
**
** Author: Windsor Solutions, Inc.
**
** Description:  This procedure has been developed to extract, transform, and load data from a source information system into
**               a set of LOCAL ICIS staging tables.
**
** Revision History:      
** ----------------------------------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ----------------------------------------------------------------------------------------------------------------------------
** DD/MM/YYYY    XXxxxxx     Created
**
******************************************************************************************************************************/
CREATE PROCEDURE ICA_ETL

AS 

DECLARE @v_text AS NVARCHAR(50);

BEGIN 
  
  /*
   *  ETL ICIS AIR DATA
   */
   SET @v_text = 'Add customized ETL extract logic here.';

  /*
   *  ICA_ETL_FAC
   */
   exec ICA_ETL_FAC;

  /*
   *  ICA_ETL_CASE_FILE_LNK
   */
   exec ICA_ETL_CASE_FILE_LNK;

  /*
   *  ICA_ETL_CMPL_MON_LNK
   */
   exec ICA_ETL_CMPL_MON_LNK;

  /*
   *  ICA_ETL_CMPL_MON_STRGY
   */
   exec ICA_ETL_CMPL_MON_STRGY;

  /*
   *  ICA_ETL_DA_CASE_FILE
   */
   exec ICA_ETL_DA_CASE_FILE;

  /*
   *  ICA_ETL_DA_CMPL_MON
   */
   exec ICA_ETL_DA_CMPL_MON;

  /*
   *  ICA_ETL_DA_ENFRC_ACTN_LNK
   */
   exec ICA_ETL_DA_ENFRC_ACTN_LNK;

  /*
   *  ICA_ETL_DA_ENFRC_ACTN_MILSTN
   */
   exec ICA_ETL_DA_ENFRC_ACTN_MILSTN;

  /*
   *  ICA_ETL_DA_FRML_ENFRC_ACTN
   */
   exec ICA_ETL_DA_FRML_ENFRC_ACTN;

  /*
   *  ICA_ETL_DA_INFRML_ENFRC_ACTN
   */
   exec ICA_ETL_DA_INFRML_ENFRC_ACTN;

  /*
   *  ICA_ETL_POLUTS
   */
   exec ICA_ETL_POLUTS;

  /*
   *  ICA_ETL_PROGS
   */
   exec ICA_ETL_PROGS;

  /*
   *  ICA_ETL_TVACC
   */
   exec ICA_ETL_TVACC;

END;

