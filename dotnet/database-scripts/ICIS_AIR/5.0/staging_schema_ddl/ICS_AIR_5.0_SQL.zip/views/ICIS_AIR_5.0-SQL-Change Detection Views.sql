/*
Copyright (c) 2014, The Environmental Council of the States (ECOS)
All rights reserved.
 
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
 
 * Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
 * Neither the name of the ECOS nor the names of its contributors may
   be used to endorse or promote products derived from this software
   without specific prior written permission.
 
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.cdv_cmpl_mon_strgy') AND type = N'V')
DROP VIEW dbo.cdv_cmpl_mon_strgy
GO

/*************************************************************************************************
** Object Name: cdv_cmpl_mon_strgy
**
** Author: Windsor Solutions, Inc.
**
** Description:  This view identifies data changes within an ICIS-Air module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 07/14/2014    Windsor     Created
** 07/21/2014    KJames      Modified the schema references to ICS_FLOW_ICIS.
**
***************************************************************************************************/
CREATE VIEW cdv_cmpl_mon_strgy AS 
SELECT DISTINCT ica_module
     , ica_cmpl_mon_strgy.key_hash
     , CASE ica_cmpl_mon_strgy.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ica_flow_icis.dbo.ica_cmpl_mon_strgy tbl
                  WHERE tbl.ica_cmpl_mon_strgy_id = ica_cmpl_mon_strgy.ica_cmpl_mon_strgy_id)
           ELSE (SELECT key_hash 
                   FROM ica_cmpl_mon_strgy tbl
                  WHERE tbl.ica_cmpl_mon_strgy_id = ica_cmpl_mon_strgy.ica_cmpl_mon_strgy_id)
       END AS module_ident
     , ica_cmpl_mon_strgy.action_type
     , ica_cmpl_mon_strgy.action_code
  FROM (/*  1 - NEW  */
        SELECT ica_cmpl_mon_strgy.ica_cmpl_mon_strgy_id
			 , ica_cmpl_mon_strgy.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICA_CMPL_MON_STRGY' as ica_module
          FROM ica_cmpl_mon_strgy
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ica_flow_icis.dbo.ica_cmpl_mon_strgy tbl
                            WHERE tbl.key_hash = ica_cmpl_mon_strgy.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ica_cmpl_mon_strgy_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICA_CMPL_MON_STRGY' as ica_module
          FROM ica_cmpl_mon_strgy local
          JOIN ica_flow_icis.dbo.ica_cmpl_mon_strgy icis
            ON (icis.key_hash = local.key_hash)
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ica_flow_icis.dbo.ica_cmpl_mon_strgy 
                            WHERE ica_cmpl_mon_strgy.data_hash = local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ica_cmpl_mon_strgy.ica_cmpl_mon_strgy_id
             , ica_cmpl_mon_strgy.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICA_CMPL_MON_STRGY' as ica_module
          FROM ica_flow_icis.dbo.ica_cmpl_mon_strgy
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ica_cmpl_mon_strgy tbl
                            WHERE tbl.key_hash = ica_cmpl_mon_strgy.key_hash)) ica_cmpl_mon_strgy;
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.cdv_da_cmpl_mon') AND type = N'V')
DROP VIEW dbo.cdv_da_cmpl_mon
GO


/*************************************************************************************************
** ObjectName: cdv_da_cmpl_mon
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS-Air module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 7/14/2014   Windsor      Created
**
***************************************************************************************************/
CREATE VIEW cdv_da_cmpl_mon AS 
SELECT DISTINCT ica_module
, ica_da_cmpl_mon.key_hash
     , CASE ica_da_cmpl_mon.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ica_flow_icis.dbo.ica_da_cmpl_mon tbl
                  WHERE tbl.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id)
           ELSE (SELECT key_hash 
                   FROM ica_da_cmpl_mon tbl
                  WHERE tbl.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id)
       END AS module_ident
     , ica_da_cmpl_mon.action_type
     , ica_da_cmpl_mon.action_code
  FROM (/*  1 - NEW  */
        SELECT ica_da_cmpl_mon.ica_da_cmpl_mon_id
			 , ica_da_cmpl_mon.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICA_DA_CMPL_MON' as ica_module
          FROM ica_da_cmpl_mon
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ica_flow_icis.dbo.ica_da_cmpl_mon tbl
                            WHERE tbl.key_hash = ica_da_cmpl_mon.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ica_da_cmpl_mon_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICA_DA_CMPL_MON' as ica_module
          FROM ica_da_cmpl_mon local
          JOIN ica_flow_icis.dbo.ica_da_cmpl_mon icis
            ON (icis.key_hash = local.key_hash)
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ica_flow_icis.dbo.ica_da_cmpl_mon 
                            WHERE ica_da_cmpl_mon.data_hash = local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ica_da_cmpl_mon.ica_da_cmpl_mon_id
             , ica_da_cmpl_mon.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICA_DA_CMPL_MON' as ica_module
          FROM ica_flow_icis.dbo.ica_da_cmpl_mon
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ica_da_cmpl_mon tbl
                            WHERE tbl.key_hash = ica_da_cmpl_mon.key_hash)) ica_da_cmpl_mon;
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.cdv_da_enfrc_actn_milstn') AND type = N'V')
DROP VIEW dbo.cdv_da_enfrc_actn_milstn
GO


/*************************************************************************************************
** ObjectName: cdv_da_enfrc_actn_milstn
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS-Air module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 7/14/2014   Windsor      Created
**
***************************************************************************************************/
CREATE VIEW cdv_da_enfrc_actn_milstn AS 
SELECT DISTINCT ica_module
, ica_da_enfrc_actn_milstn.key_hash
     , CASE ica_da_enfrc_actn_milstn.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ica_flow_icis.dbo.ica_da_enfrc_actn_milstn tbl
                  WHERE tbl.ica_da_enfrc_actn_milstn_id = ica_da_enfrc_actn_milstn.ica_da_enfrc_actn_milstn_id)
           ELSE (SELECT key_hash 
                   FROM ica_da_enfrc_actn_milstn tbl
                  WHERE tbl.ica_da_enfrc_actn_milstn_id = ica_da_enfrc_actn_milstn.ica_da_enfrc_actn_milstn_id)
       END AS module_ident
     , ica_da_enfrc_actn_milstn.action_type
     , ica_da_enfrc_actn_milstn.action_code
  FROM (/*  1 - NEW  */
        SELECT ica_da_enfrc_actn_milstn.ica_da_enfrc_actn_milstn_id
			 , ica_da_enfrc_actn_milstn.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICA_DA_ENFRC_ACTN_MILSTN' as ica_module
          FROM ica_da_enfrc_actn_milstn
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ica_flow_icis.dbo.ica_da_enfrc_actn_milstn tbl
                            WHERE tbl.key_hash = ica_da_enfrc_actn_milstn.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ica_da_enfrc_actn_milstn_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICA_DA_ENFRC_ACTN_MILSTN' as ica_module
          FROM ica_da_enfrc_actn_milstn local
          JOIN ica_flow_icis.dbo.ica_da_enfrc_actn_milstn icis
            ON (icis.key_hash = local.key_hash)
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ica_flow_icis.dbo.ica_da_enfrc_actn_milstn 
                            WHERE ica_da_enfrc_actn_milstn.data_hash = local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ica_da_enfrc_actn_milstn.ica_da_enfrc_actn_milstn_id
             , ica_da_enfrc_actn_milstn.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICA_DA_ENFRC_ACTN_MILSTN' as ica_module
          FROM ica_flow_icis.dbo.ica_da_enfrc_actn_milstn
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ica_da_enfrc_actn_milstn tbl
                            WHERE tbl.key_hash = ica_da_enfrc_actn_milstn.key_hash)) ica_da_enfrc_actn_milstn;
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.cdv_da_frml_enfrc_actn') AND type = N'V')
DROP VIEW dbo.cdv_da_frml_enfrc_actn
GO


/*************************************************************************************************
** ObjectName: cdv_da_frml_enfrc_actn
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS-Air module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 7/14/2014   Windsor      Created
**
***************************************************************************************************/
CREATE VIEW cdv_da_frml_enfrc_actn AS 
SELECT DISTINCT ica_module
, ica_da_frml_enfrc_actn.key_hash
     , CASE ica_da_frml_enfrc_actn.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ica_flow_icis.dbo.ica_da_frml_enfrc_actn tbl
                  WHERE tbl.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id)
           ELSE (SELECT key_hash 
                   FROM ica_da_frml_enfrc_actn tbl
                  WHERE tbl.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id)
       END AS module_ident
     , ica_da_frml_enfrc_actn.action_type
     , ica_da_frml_enfrc_actn.action_code
  FROM (/*  1 - NEW  */
        SELECT ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
			 , ica_da_frml_enfrc_actn.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICA_DA_FRML_ENFRC_ACTN' as ica_module
          FROM ica_da_frml_enfrc_actn
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ica_flow_icis.dbo.ica_da_frml_enfrc_actn tbl
                            WHERE tbl.key_hash = ica_da_frml_enfrc_actn.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ica_da_frml_enfrc_actn_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICA_DA_FRML_ENFRC_ACTN' as ica_module
          FROM ica_da_frml_enfrc_actn local
          JOIN ica_flow_icis.dbo.ica_da_frml_enfrc_actn icis
            ON (icis.key_hash = local.key_hash)
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ica_flow_icis.dbo.ica_da_frml_enfrc_actn 
                            WHERE ica_da_frml_enfrc_actn.data_hash = local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
             , ica_da_frml_enfrc_actn.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICA_DA_FRML_ENFRC_ACTN' as ica_module
          FROM ica_flow_icis.dbo.ica_da_frml_enfrc_actn
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ica_da_frml_enfrc_actn tbl
                            WHERE tbl.key_hash = ica_da_frml_enfrc_actn.key_hash)) ica_da_frml_enfrc_actn;
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.cdv_da_infrml_enfrc_actn') AND type = N'V')
DROP VIEW dbo.cdv_da_infrml_enfrc_actn
GO


/*************************************************************************************************
** ObjectName: cdv_da_infrml_enfrc_actn
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS-Air module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 7/14/2014   Windsor      Created
**
***************************************************************************************************/
CREATE VIEW cdv_da_infrml_enfrc_actn AS 
SELECT DISTINCT ica_module
, ica_da_infrml_enfrc_actn.key_hash
     , CASE ica_da_infrml_enfrc_actn.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ica_flow_icis.dbo.ica_da_infrml_enfrc_actn tbl
                  WHERE tbl.ica_da_infrml_enfrc_actn_id = ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id)
           ELSE (SELECT key_hash 
                   FROM ica_da_infrml_enfrc_actn tbl
                  WHERE tbl.ica_da_infrml_enfrc_actn_id = ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id)
       END AS module_ident
     , ica_da_infrml_enfrc_actn.action_type
     , ica_da_infrml_enfrc_actn.action_code
  FROM (/*  1 - NEW  */
        SELECT ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
			 , ica_da_infrml_enfrc_actn.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICA_DA_INFRML_ENFRC_ACTN' as ica_module
          FROM ica_da_infrml_enfrc_actn
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ica_flow_icis.dbo.ica_da_infrml_enfrc_actn tbl
                            WHERE tbl.key_hash = ica_da_infrml_enfrc_actn.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ica_da_infrml_enfrc_actn_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICA_DA_INFRML_ENFRC_ACTN' as ica_module
          FROM ica_da_infrml_enfrc_actn local
          JOIN ica_flow_icis.dbo.ica_da_infrml_enfrc_actn icis
            ON (icis.key_hash = local.key_hash)
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ica_flow_icis.dbo.ica_da_infrml_enfrc_actn 
                            WHERE ica_da_infrml_enfrc_actn.data_hash = local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
             , ica_da_infrml_enfrc_actn.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICA_DA_INFRML_ENFRC_ACTN' as ica_module
          FROM ica_flow_icis.dbo.ica_da_infrml_enfrc_actn
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ica_da_infrml_enfrc_actn tbl
                            WHERE tbl.key_hash = ica_da_infrml_enfrc_actn.key_hash)) ica_da_infrml_enfrc_actn;
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.cdv_fac') AND type = N'V')
DROP VIEW dbo.cdv_fac
GO


/*************************************************************************************************
** ObjectName: cdv_fac
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS-Air module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 7/14/2014   Windsor      Created
**
***************************************************************************************************/
CREATE VIEW cdv_fac AS 
SELECT DISTINCT ica_module
, ica_fac.key_hash
     , CASE ica_fac.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ica_flow_icis.dbo.ica_fac tbl
                  WHERE tbl.ica_fac_id = ica_fac.ica_fac_id)
           ELSE (SELECT key_hash 
                   FROM ica_fac tbl
                  WHERE tbl.ica_fac_id = ica_fac.ica_fac_id)
       END AS module_ident
     , ica_fac.action_type
     , ica_fac.action_code
  FROM (/*  1 - NEW  */
        SELECT ica_fac.ica_fac_id
			 , ica_fac.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICA_FAC' as ica_module
          FROM ica_fac
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ica_flow_icis.dbo.ica_fac tbl
                            WHERE tbl.key_hash = ica_fac.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ica_fac_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICA_FAC' as ica_module
          FROM ica_fac local
          JOIN ica_flow_icis.dbo.ica_fac icis
            ON (icis.key_hash = local.key_hash)
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ica_flow_icis.dbo.ica_fac 
                            WHERE ica_fac.data_hash = local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ica_fac.ica_fac_id
             , ica_fac.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICA_FAC' as ica_module
          FROM ica_flow_icis.dbo.ica_fac
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ica_fac tbl
                            WHERE tbl.key_hash = ica_fac.key_hash)) ica_fac;
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.cdv_poluts') AND type = N'V')
DROP VIEW dbo.cdv_poluts
GO


/*************************************************************************************************
** ObjectName: cdv_poluts
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS-Air module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 7/14/2014   Windsor      Created
**
***************************************************************************************************/
CREATE VIEW cdv_poluts AS 
SELECT DISTINCT ica_module
, ica_poluts.key_hash
     , CASE ica_poluts.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ica_flow_icis.dbo.ica_poluts tbl
                  WHERE tbl.ica_poluts_id = ica_poluts.ica_poluts_id)
           ELSE (SELECT key_hash 
                   FROM ica_poluts tbl
                  WHERE tbl.ica_poluts_id = ica_poluts.ica_poluts_id)
       END AS module_ident
     , ica_poluts.action_type
     , ica_poluts.action_code
  FROM (/*  1 - NEW  */
        SELECT ica_poluts.ica_poluts_id
			 , ica_poluts.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICA_POLUTS' as ica_module
          FROM ica_poluts
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ica_flow_icis.dbo.ica_poluts tbl
                            WHERE tbl.key_hash = ica_poluts.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ica_poluts_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICA_POLUTS' as ica_module
          FROM ica_poluts local
          JOIN ica_flow_icis.dbo.ica_poluts icis
            ON (icis.key_hash = local.key_hash)
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ica_flow_icis.dbo.ica_poluts 
                            WHERE ica_poluts.data_hash = local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ica_poluts.ica_poluts_id
             , ica_poluts.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICA_POLUTS' as ica_module
          FROM ica_flow_icis.dbo.ica_poluts
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ica_poluts tbl
                            WHERE tbl.key_hash = ica_poluts.key_hash)) ica_poluts;
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.cdv_progs') AND type = N'V')
DROP VIEW dbo.cdv_progs
GO


/*************************************************************************************************
** ObjectName: cdv_progs
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS-Air module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 7/14/2014   Windsor      Created
**
***************************************************************************************************/
CREATE VIEW cdv_progs AS 
SELECT DISTINCT ica_module
, ica_progs.key_hash
     , CASE ica_progs.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ica_flow_icis.dbo.ica_progs tbl
                  WHERE tbl.ica_progs_id = ica_progs.ica_progs_id)
           ELSE (SELECT key_hash 
                   FROM ica_progs tbl
                  WHERE tbl.ica_progs_id = ica_progs.ica_progs_id)
       END AS module_ident
     , ica_progs.action_type
     , ica_progs.action_code
  FROM (/*  1 - NEW  */
        SELECT ica_progs.ica_progs_id
			 , ica_progs.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICA_PROGS' as ica_module
          FROM ica_progs
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ica_flow_icis.dbo.ica_progs tbl
                            WHERE tbl.key_hash = ica_progs.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ica_progs_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICA_PROGS' as ica_module
          FROM ica_progs local
          JOIN ica_flow_icis.dbo.ica_progs icis
            ON (icis.key_hash = local.key_hash)
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ica_flow_icis.dbo.ica_progs 
                            WHERE ica_progs.data_hash = local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ica_progs.ica_progs_id
             , ica_progs.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICA_PROGS' as ica_module
          FROM ica_flow_icis.dbo.ica_progs
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ica_progs tbl
                            WHERE tbl.key_hash = ica_progs.key_hash)) ica_progs;
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.cdv_tvacc') AND type = N'V')
DROP VIEW dbo.cdv_tvacc
GO


/*************************************************************************************************
** ObjectName: cdv_tvacc
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS-Air module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 7/14/2014   Windsor      Created
**
***************************************************************************************************/
CREATE VIEW cdv_tvacc AS 
SELECT DISTINCT ica_module
, ica_tvacc.key_hash
     , CASE ica_tvacc.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ica_flow_icis.dbo.ica_tvacc tbl
                  WHERE tbl.ica_tvacc_id = ica_tvacc.ica_tvacc_id)
           ELSE (SELECT key_hash 
                   FROM ica_tvacc tbl
                  WHERE tbl.ica_tvacc_id = ica_tvacc.ica_tvacc_id)
       END AS module_ident
     , ica_tvacc.action_type
     , ica_tvacc.action_code
  FROM (/*  1 - NEW  */
        SELECT ica_tvacc.ica_tvacc_id
			 , ica_tvacc.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICA_TVACC' as ica_module
          FROM ica_tvacc
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ica_flow_icis.dbo.ica_tvacc tbl
                            WHERE tbl.key_hash = ica_tvacc.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ica_tvacc_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICA_TVACC' as ica_module
          FROM ica_tvacc local
          JOIN ica_flow_icis.dbo.ica_tvacc icis
            ON (icis.key_hash = local.key_hash)
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ica_flow_icis.dbo.ica_tvacc 
                            WHERE ica_tvacc.data_hash = local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ica_tvacc.ica_tvacc_id
             , ica_tvacc.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICA_TVACC' as ica_module
          FROM ica_flow_icis.dbo.ica_tvacc
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ica_tvacc tbl
                            WHERE tbl.key_hash = ica_tvacc.key_hash)) ica_tvacc;
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.cdv_da_case_file') AND type = N'V')
DROP VIEW dbo.cdv_da_case_file
GO


/*************************************************************************************************
** ObjectName: cdv_da_case_file
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS-Air module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 7/14/2014   Windsor      Created
**
***************************************************************************************************/
CREATE VIEW cdv_da_case_file AS 
SELECT DISTINCT ica_module
, ica_da_case_file.key_hash
     , CASE ica_da_case_file.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ica_flow_icis.dbo.ica_da_case_file tbl
                  WHERE tbl.ica_da_case_file_id = ica_da_case_file.ica_da_case_file_id)
           ELSE (SELECT key_hash 
                   FROM ica_da_case_file tbl
                  WHERE tbl.ica_da_case_file_id = ica_da_case_file.ica_da_case_file_id)
       END AS module_ident
     , ica_da_case_file.action_type
     , ica_da_case_file.action_code
  FROM (/*  1 - NEW  */
        SELECT ica_da_case_file.ica_da_case_file_id
			 , ica_da_case_file.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICA_DA_CASE_FILE' as ica_module
          FROM ica_da_case_file
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ica_flow_icis.dbo.ica_da_case_file tbl
                            WHERE tbl.key_hash = ica_da_case_file.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ica_da_case_file_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICA_DA_CASE_FILE' as ica_module
          FROM ica_da_case_file local
          JOIN ica_flow_icis.dbo.ica_da_case_file icis
            ON (icis.key_hash = local.key_hash)
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ica_flow_icis.dbo.ica_da_case_file 
                            WHERE ica_da_case_file.data_hash = local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ica_da_case_file.ica_da_case_file_id
             , ica_da_case_file.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICA_DA_CASE_FILE' as ica_module
          FROM ica_flow_icis.dbo.ica_da_case_file
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ica_da_case_file tbl
                            WHERE tbl.key_hash = ica_da_case_file.key_hash)) ica_da_case_file;
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.cdv_da_enfrc_actn_lnk') AND type = N'V')
DROP VIEW dbo.cdv_da_enfrc_actn_lnk
GO


/*************************************************************************************************
** ObjectName: cdv_da_enfrc_actn_lnk
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS-Air module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 7/14/2014   Windsor      Created
**
***************************************************************************************************/
CREATE VIEW cdv_da_enfrc_actn_lnk AS 
SELECT DISTINCT ica_module
, ica_da_enfrc_actn_lnk.key_hash
     , CASE ica_da_enfrc_actn_lnk.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ica_flow_icis.dbo.ica_da_enfrc_actn_lnk tbl
                  WHERE tbl.ica_da_enfrc_actn_lnk_id = ica_da_enfrc_actn_lnk.ica_da_enfrc_actn_lnk_id)
           ELSE (SELECT key_hash 
                   FROM ica_da_enfrc_actn_lnk tbl
                  WHERE tbl.ica_da_enfrc_actn_lnk_id = ica_da_enfrc_actn_lnk.ica_da_enfrc_actn_lnk_id)
       END AS module_ident
     , ica_da_enfrc_actn_lnk.action_type
     , ica_da_enfrc_actn_lnk.action_code
  FROM (/*  1 - NEW  */
        SELECT ica_da_enfrc_actn_lnk.ica_da_enfrc_actn_lnk_id
			 , ica_da_enfrc_actn_lnk.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICA_DA_ENFRC_ACTN_LNK' as ica_module
          FROM ica_da_enfrc_actn_lnk
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ica_flow_icis.dbo.ica_da_enfrc_actn_lnk tbl
                            WHERE tbl.key_hash = ica_da_enfrc_actn_lnk.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ica_da_enfrc_actn_lnk_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICA_DA_ENFRC_ACTN_LNK' as ica_module
          FROM ica_da_enfrc_actn_lnk local
          JOIN ica_flow_icis.dbo.ica_da_enfrc_actn_lnk icis
            ON (icis.key_hash = local.key_hash)
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ica_flow_icis.dbo.ica_da_enfrc_actn_lnk 
                            WHERE ica_da_enfrc_actn_lnk.data_hash = local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ica_da_enfrc_actn_lnk.ica_da_enfrc_actn_lnk_id
             , ica_da_enfrc_actn_lnk.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICA_DA_ENFRC_ACTN_LNK' as ica_module
          FROM ica_flow_icis.dbo.ica_da_enfrc_actn_lnk
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ica_da_enfrc_actn_lnk tbl
                            WHERE tbl.key_hash = ica_da_enfrc_actn_lnk.key_hash)) ica_da_enfrc_actn_lnk;
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.cdv_case_file_lnk') AND type = N'V')
DROP VIEW dbo.cdv_case_file_lnk
GO


/*************************************************************************************************
** ObjectName: cdv_case_file_lnk
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS-Air module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 7/14/2014   Windsor      Created
**
***************************************************************************************************/
CREATE VIEW cdv_case_file_lnk AS 
SELECT DISTINCT ica_module
, ica_case_file_lnk.key_hash
     , CASE ica_case_file_lnk.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ica_flow_icis.dbo.ica_case_file_lnk tbl
                  WHERE tbl.ica_case_file_lnk_id = ica_case_file_lnk.ica_case_file_lnk_id)
           ELSE (SELECT key_hash 
                   FROM ica_case_file_lnk tbl
                  WHERE tbl.ica_case_file_lnk_id = ica_case_file_lnk.ica_case_file_lnk_id)
       END AS module_ident
     , ica_case_file_lnk.action_type
     , ica_case_file_lnk.action_code
  FROM (/*  1 - NEW  */
        SELECT ica_case_file_lnk.ica_case_file_lnk_id
			 , ica_case_file_lnk.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICA_CASE_FILE_LNK' as ica_module
          FROM ica_case_file_lnk
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ica_flow_icis.dbo.ica_case_file_lnk tbl
                            WHERE tbl.key_hash = ica_case_file_lnk.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ica_case_file_lnk_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICA_CASE_FILE_LNK' as ica_module
          FROM ica_case_file_lnk local
          JOIN ica_flow_icis.dbo.ica_case_file_lnk icis
            ON (icis.key_hash = local.key_hash)
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ica_flow_icis.dbo.ica_case_file_lnk 
                            WHERE ica_case_file_lnk.data_hash = local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ica_case_file_lnk.ica_case_file_lnk_id
             , ica_case_file_lnk.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICA_CASE_FILE_LNK' as ica_module
          FROM ica_flow_icis.dbo.ica_case_file_lnk
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ica_case_file_lnk tbl
                            WHERE tbl.key_hash = ica_case_file_lnk.key_hash)) ica_case_file_lnk;
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.cdv_cmpl_mon_lnk') AND type = N'V')
DROP VIEW dbo.cdv_cmpl_mon_lnk
GO


/*************************************************************************************************
** ObjectName: cdv_cmpl_mon_lnk
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS-Air module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 7/14/2014   Windsor      Created
**
***************************************************************************************************/
CREATE VIEW cdv_cmpl_mon_lnk AS 
SELECT DISTINCT ica_module
, ica_cmpl_mon_lnk.key_hash
     , CASE ica_cmpl_mon_lnk.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ica_flow_icis.dbo.ica_cmpl_mon_lnk tbl
                  WHERE tbl.ica_cmpl_mon_lnk_id = ica_cmpl_mon_lnk.ica_cmpl_mon_lnk_id)
           ELSE (SELECT key_hash 
                   FROM ica_cmpl_mon_lnk tbl
                  WHERE tbl.ica_cmpl_mon_lnk_id = ica_cmpl_mon_lnk.ica_cmpl_mon_lnk_id)
       END AS module_ident
     , ica_cmpl_mon_lnk.action_type
     , ica_cmpl_mon_lnk.action_code
  FROM (/*  1 - NEW  */
        SELECT ica_cmpl_mon_lnk.ica_cmpl_mon_lnk_id
			 , ica_cmpl_mon_lnk.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICA_CMPL_MON_LNK' as ica_module
          FROM ica_cmpl_mon_lnk
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ica_flow_icis.dbo.ica_cmpl_mon_lnk tbl
                            WHERE tbl.key_hash = ica_cmpl_mon_lnk.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ica_cmpl_mon_lnk_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICA_CMPL_MON_LNK' as ica_module
          FROM ica_cmpl_mon_lnk local
          JOIN ica_flow_icis.dbo.ica_cmpl_mon_lnk icis
            ON (icis.key_hash = local.key_hash)
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ica_flow_icis.dbo.ica_cmpl_mon_lnk 
                            WHERE ica_cmpl_mon_lnk.data_hash = local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ica_cmpl_mon_lnk.ica_cmpl_mon_lnk_id
             , ica_cmpl_mon_lnk.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICA_CMPL_MON_LNK' as ica_module
          FROM ica_flow_icis.dbo.ica_cmpl_mon_lnk
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ica_cmpl_mon_lnk tbl
                            WHERE tbl.key_hash = ica_cmpl_mon_lnk.key_hash)) ica_cmpl_mon_lnk;
GO