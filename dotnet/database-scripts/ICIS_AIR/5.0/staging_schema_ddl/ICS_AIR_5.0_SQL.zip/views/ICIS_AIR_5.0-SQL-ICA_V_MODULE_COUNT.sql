/*
Copyright (c) 2014, The Environmental Council of the States (ECOS)
All rights reserved.
 
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
 
 * Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
 * Neither the name of the ECOS nor the names of its contributors may
   be used to endorse or promote products derived from this software
   without specific prior written permission.
 
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.ica_v_module_count') AND type = N'V')
DROP VIEW dbo.ica_v_module_count
GO

/*************************************************************************************************
** Object Name: ica_v_module_count
**
** Author: Windsor Solutions, Inc.
**
** Description:  This view identifies data changes within an ICIS-Air module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 08/11/2014    Windsor     Created
** 08/11/2014    Windsor     Removed the trans_count_new data element from this database view.
**
***************************************************************************************************/
CREATE VIEW ica_v_module_count
(
  subm_date_time
, subm_transaction_id
, subm_type_name
, trans_count_chng_repl
, trans_count_del_mass_del
, error_count
, warning_count
, accepted_count
, accepted_count_total
) AS
SELECT (SELECT subm_date_time
              FROM ica_subm_track
             WHERE subm_transaction_id = rslt.subm_transaction_id)
             AS subm_date_time
         , subm_transaction_id
         , subm_type_name
         , ISNULL(CASE
             WHEN rslt.subm_type_name = 'AirComplianceMonitoringStrategySubmission'
             THEN
               (SELECT COUNT (1)
                  FROM ica_cmpl_mon_strgy
                 WHERE transaction_type IN ('C', 'R'))
             WHEN rslt.subm_type_name = 'AirDACaseFileSubmission'
             THEN
               (SELECT COUNT (1)
                  FROM ica_da_case_file
                 WHERE transaction_type IN ('C', 'R'))
             WHEN rslt.subm_type_name = 'AirDAComplianceMonitoringSubmission'
             THEN
               (SELECT COUNT (1)
                  FROM ica_da_cmpl_mon
                 WHERE transaction_type IN ('C', 'R'))
             WHEN rslt.subm_type_name = 'AirDAEnforcementActionLinkageSubmission'
             THEN
               (SELECT COUNT (1)
                  FROM ica_da_enfrc_actn_lnk
                 WHERE transaction_type IN ('C', 'R'))
             WHEN rslt.subm_type_name = 'AirDAEnforcementActionMilestoneSubmission'
             THEN
               (SELECT COUNT (1)
                  FROM ica_da_enfrc_actn_milstn
                 WHERE transaction_type IN ('C', 'R'))
             WHEN rslt.subm_type_name = 'AirDAFormalEnforcementActionSubmission'
             THEN
               (SELECT COUNT (1)
                  FROM ica_da_frml_enfrc_actn
                 WHERE transaction_type IN ('C', 'R'))
             WHEN rslt.subm_type_name = 'AirDAInformalEnforcementActionSubmission'
             THEN
               (SELECT COUNT (1)
                  FROM ica_da_infrml_enfrc_actn
                 WHERE transaction_type IN ('C', 'R'))
             WHEN rslt.subm_type_name = 'AirFacilitySubmission'
             THEN
               (SELECT COUNT (1)
                  FROM ica_fac
                 WHERE transaction_type IN ('C', 'R'))
             WHEN rslt.subm_type_name = 'AirPollutantsSubmission'
             THEN
               (SELECT COUNT (1)
                  FROM ica_poluts
                 WHERE transaction_type IN ('C', 'R'))
             WHEN rslt.subm_type_name = 'AirProgramsSubmission'
             THEN
               (SELECT COUNT (1)
                  FROM ica_progs
                 WHERE transaction_type IN ('C', 'R'))
             WHEN rslt.subm_type_name = 'AirTVACCSubmission'
             THEN
               (SELECT COUNT (1)
                  FROM ica_tvacc
                 WHERE transaction_type IN ('C', 'R'))
             WHEN rslt.subm_type_name = 'CaseFileLinkageSubmission'
             THEN
               (SELECT COUNT (1)
                  FROM ica_case_file_lnk
                 WHERE transaction_type IN ('C', 'R'))
             WHEN rslt.subm_type_name = 'ComplianceMonitoringLinkageSubmission'
             THEN
               (SELECT COUNT (1)
                  FROM ica_cmpl_mon_lnk
                 WHERE transaction_type IN ('C', 'R'))
           END,0)
             AS trans_count_chng_repl
         , ISNULL(CASE
             WHEN rslt.subm_type_name = 'AirComplianceMonitoringStrategySubmission'
             THEN
               (SELECT COUNT (1)
                  FROM ica_cmpl_mon_strgy
                 WHERE transaction_type IN ('D', 'X'))
             WHEN rslt.subm_type_name = 'AirDACaseFileSubmission'
             THEN
               (SELECT COUNT (1)
                  FROM ica_da_case_file
                 WHERE transaction_type IN ('D', 'X'))
             WHEN rslt.subm_type_name = 'AirDAComplianceMonitoringSubmission'
             THEN
               (SELECT COUNT (1)
                  FROM ica_da_cmpl_mon
                 WHERE transaction_type IN ('D', 'X'))
             WHEN rslt.subm_type_name = 'AirDAEnforcementActionLinkageSubmission'
             THEN
               (SELECT COUNT (1)
                  FROM ica_da_enfrc_actn_lnk
                 WHERE transaction_type IN ('D', 'X'))
             WHEN rslt.subm_type_name = 'AirDAEnforcementActionMilestoneSubmission'
             THEN
               (SELECT COUNT (1)
                  FROM ica_da_enfrc_actn_milstn
                 WHERE transaction_type IN ('D', 'X'))
             WHEN rslt.subm_type_name = 'AirDAFormalEnforcementActionSubmission'
             THEN
               (SELECT COUNT (1)
                  FROM ica_da_frml_enfrc_actn
                 WHERE transaction_type IN ('D', 'X'))
             WHEN rslt.subm_type_name = 'AirDAInformalEnforcementActionSubmission'
             THEN
               (SELECT COUNT (1)
                  FROM ica_da_infrml_enfrc_actn
                 WHERE transaction_type IN ('D', 'X'))
             WHEN rslt.subm_type_name = 'AirFacilitySubmission'
             THEN
               (SELECT COUNT (1)
                  FROM ica_fac
                 WHERE transaction_type IN ('D', 'X'))
             WHEN rslt.subm_type_name = 'AirPollutantsSubmission'
             THEN
               (SELECT COUNT (1)
                  FROM ica_poluts
                 WHERE transaction_type IN ('D', 'X'))
             WHEN rslt.subm_type_name = 'AirProgramsSubmission'
             THEN
               (SELECT COUNT (1)
                  FROM ica_progs
                 WHERE transaction_type IN ('D', 'X'))
             WHEN rslt.subm_type_name = 'AirTVACCSubmission'
             THEN
               (SELECT COUNT (1)
                  FROM ica_tvacc
                 WHERE transaction_type IN ('D', 'X'))
             WHEN rslt.subm_type_name = 'CaseFileLinkageSubmission'
             THEN
               (SELECT COUNT (1)
                  FROM ica_case_file_lnk
                 WHERE transaction_type IN ('D', 'X'))
             WHEN rslt.subm_type_name = 'ComplianceMonitoringLinkageSubmission'
             THEN
               (SELECT COUNT (1)
                  FROM ica_cmpl_mon_lnk
                 WHERE transaction_type IN ('D', 'X'))
           END,0)
             AS trans_count_del_mass_del
         , ISNULL((SELECT COUNT (1)
              FROM ica_subm_rslts
             WHERE subm_type_name = rslt.subm_type_name
                   AND result_type_code = 'Error'),0)
             AS error_count
         , ISNULL((SELECT COUNT (1)
              FROM ica_subm_rslts
             WHERE subm_type_name = rslt.subm_type_name
                   AND result_type_code = 'Warning'),0)
             AS warning_count
         , ISNULL((SELECT COUNT (1)
              FROM ica_subm_rslts
             WHERE subm_type_name = rslt.subm_type_name
                   AND result_type_code = 'Accepted'),0)
             AS accepted_count
         , ISNULL(CASE
             WHEN rslt.subm_type_name = 'AirComplianceMonitoringStrategySubmission'
             THEN
               (  SELECT COUNT (1) FROM ica_flow_icis.dbo.ica_cmpl_mon_strgy)
             WHEN rslt.subm_type_name = 'AirDACaseFileSubmission'
             THEN
               (  SELECT COUNT (1) FROM ica_flow_icis.dbo.ica_da_case_file)
             WHEN rslt.subm_type_name = 'AirDAComplianceMonitoringSubmission'
             THEN
               (  SELECT COUNT (1) FROM ica_flow_icis.dbo.ica_da_cmpl_mon)
             WHEN rslt.subm_type_name = 'AirDAEnforcementActionLinkageSubmission'
             THEN
               (  SELECT COUNT (1) FROM ica_flow_icis.dbo.ica_da_enfrc_actn_lnk)
             WHEN rslt.subm_type_name = 'AirDAEnforcementActionMilestoneSubmission'
             THEN
               (  SELECT COUNT (1) FROM ica_flow_icis.dbo.ica_da_enfrc_actn_milstn)
             WHEN rslt.subm_type_name = 'AirDAFormalEnforcementActionSubmission'
             THEN
               (  SELECT COUNT (1) FROM ica_flow_icis.dbo.ica_da_frml_enfrc_actn)
             WHEN rslt.subm_type_name = 'AirDAInformalEnforcementActionSubmission'
             THEN
               (  SELECT COUNT (1) FROM ica_flow_icis.dbo.ica_da_infrml_enfrc_actn)
             WHEN rslt.subm_type_name = 'AirFacilitySubmission'
             THEN
               (  SELECT COUNT (1) FROM ica_flow_icis.dbo.ica_fac)
             WHEN rslt.subm_type_name = 'AirPollutantsSubmission'
             THEN
               (  SELECT COUNT (1) FROM ica_flow_icis.dbo.ica_poluts)
             WHEN rslt.subm_type_name = 'AirProgramsSubmission'
             THEN
               (  SELECT COUNT (1) FROM ica_flow_icis.dbo.ica_progs)
             WHEN rslt.subm_type_name = 'AirTVACCSubmission'
             THEN
               (  SELECT COUNT (1) FROM ica_flow_icis.dbo.ica_tvacc)
             WHEN rslt.subm_type_name = 'CaseFileLinkageSubmission'
             THEN
               (  SELECT COUNT (1) FROM ica_flow_icis.dbo.ica_case_file_lnk)
             WHEN rslt.subm_type_name = 'ComplianceMonitoringLinkageSubmission'
             THEN
               (  SELECT COUNT (1) FROM ica_flow_icis.dbo.ica_cmpl_mon_lnk)
           END,0)
             AS accepted_count_total
      FROM ica_subm_rslts rslt
  GROUP BY subm_transaction_id, subm_type_name;
  GO