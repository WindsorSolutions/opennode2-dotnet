/*
Copyright (c) 2014, The Environmental Council of the States (ECOS)
All rights reserved.
 
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
 
 * Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
 * Neither the name of the ECOS nor the names of its contributors may
   be used to endorse or promote products derived from this software
   without specific prior written permission.
 
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/

/*************************************************************************************************
** ObjectName: vw_ica_fac_geo_coord
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view supports the Java OpenNode2 plugin.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/11/2014    Windsor     Created
**
***************************************************************************************************/
CREATE OR REPLACE FORCE VIEW ica_flow_local.vw_ica_fac_geo_coord AS
SELECT ica_fac.*
     , ICA_GEO_COORD_ID
     ,	LAT_MEAS 
     ,	LONG_MEAS
     ,	HORZ_ACCURACY_MEAS
     ,	GEOM_TYPE_CODE
     ,	HORZ_COLL_METHOD_CODE
     ,	HORZ_REF_DATUM_CODE
     ,	REF_POINT_CODE 
     ,	SRC_MAP_SCALE_NUM 
     ,	UTM_COORD_1
     ,	UTM_COORD_2 
     ,	UTM_COORD_3
  FROM ica_flow_local.ica_fac
  LEFT JOIN ica_flow_local.ica_geo_coord
    ON ica_geo_coord.ica_fac_id = ica_fac.ica_fac_id;
/