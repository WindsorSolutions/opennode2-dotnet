/*
Copyright (c) 2014, The Environmental Council of the States (ECOS)
All rights reserved.
 
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
 
 * Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
 * Neither the name of the ECOS nor the names of its contributors may
   be used to endorse or promote products derived from this software
   without specific prior written permission.
 
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/

/******************************************************************************************************************
 *
 *  Script Name:  ICIS_AIR_5.0-SQL-DDL-Patch.sql
 *
 *  Company:  Windsor Solutions, Inc.
 *  
 *  Purpose:  This script will alter an existing ICIS Air database schema.  It can be run repeatedly.  A schema 
 *            alteration will only occur during the first pass.
 *   
 *  Maintenance:
 *  
 *    Analyst         Date            Comment 
 *    ----------      ----------      -----------------------------------------------------------------------------
 *    KJames          01/28/2015      Created 
 *    KJames          02/02/2015      Added alteration of ICA_SUBM_RSLTS to allow up to 10 characters in the 
 *                                    RESULT_CODE column.
 *    KJames          07/06/2015      Modified table ICA_TST_RSTLS.  Altered ALLOWABLE_VALUE and ACTUAL_RESULT
 *                                    from INT to DECIMAL(35,17).
 *    KJames          07/06/2015      Modified ICA_VIOL.  Altered VIOL_PROG_DESC_TXT from VARCHAR(1000) to 
 *                                    VARCHAR(100).
 *    KJames          07/06/2015      Added column FINAL_ORDER_LODGED_DATE to the staging table ICA_DA_FINAL_ORDER.
 *    KJames          07/06/2015      Added staging table ICA_DEMND_STIPULTD_PNLTY to the ICIS Air 5.4 database
 *                                    schema, with index and foreign key ICA_DA_FINAL_ORDER.
 *    KJames          07/10/2015      Corrected the key_hash indexes on the staging table ICA_TVACC so they 
 *                                    apply to the proper staging tables.
 *    KJames          07/10/2015      Altered the script to create or replace the database views and database 
 *                                    procedures.
 *    KJames          07/20/2015      Modified script to alter both ICA_FLOW_LOCAL and ICA_FLOW_ICIS during a 
 *                                    single execution of this patch script.
 *    KJames          08/24/2015      Modified the ICA_PAYLOAD operation name to the proper 
 *                                    CaseFileLinkageSubmission.
 *    KJames          09/21/2015      Modified the key hashing for linkage tables to sync change
 *                                    detection with process accepted transactions.
 *   
 ******************************************************************************************************************/

USE [ICA_FLOW_LOCAL]
GO

/********************************************************************************************************  
    Script Note:  This script will alter the column RESULT_CODE on the ICA_SUBM_RSLTS table from 
                  a VARCHAR(06) to a VARCHAR(10).
*********************************************************************************************************/
BEGIN

  /* Alter ICA_SUBM_RSLTS, add column RESULT_CODE */
  IF EXISTS (SELECT columns.*
               FROM sys.schemas
               JOIN sys.tables
                 ON tables.schema_id = schemas.schema_id
               JOIN sys.columns
                 ON columns.object_id = tables.object_id
              WHERE schemas.name = 'dbo'
                AND tables.name = 'ICA_SUBM_RSLTS'
                AND columns.name = 'RESULT_CODE'
                AND columns.max_length <> 10)
    BEGIN
      ALTER TABLE ICA_SUBM_RSLTS ALTER COLUMN RESULT_CODE VARCHAR(10) NULL;
      PRINT 'The ICA_FLOW_LOCAL column ICA_SUBM_RSLTS.RESULT_CODE was successfully modified to VARCHAR2(10).';
    END
  ELSE
    BEGIN
      PRINT 'The ICA_FLOW_LOCAL column ICA_FLOW_LOCAL.RESULT_CODE was already VARCHAR2(10), schema alteration bypassed!';
    END;
END;

/* ******************************
 *  ICIS Air 5.4 Schema Changes
 * *****************************/

--  First alter the ICIS database objects
USE [ICA_FLOW_ICIS]
GO

/********************************************************************************************************  
    Script Note:  This script will alter the column ALLOWABLE_VALUE on the ICA_TST_RSLTS table from 
                  INT to a DECIMAL(35,17)
*********************************************************************************************************/
BEGIN

  /* Alter ICA_TST_RSLTS, add column ALLOWABLE_VALUE */
  IF EXISTS (SELECT columns.*
               FROM sys.schemas
               JOIN sys.tables
                 ON tables.schema_id = schemas.schema_id
               JOIN sys.columns
                 ON columns.object_id = tables.object_id
              WHERE schemas.name = 'dbo'
                AND tables.name = 'ICA_TST_RSLTS'
                AND columns.name = 'ALLOWABLE_VALUE'
                AND columns.precision = 10
                AND columns.scale = 0)
    BEGIN
      ALTER TABLE ICA_TST_RSLTS ALTER COLUMN ALLOWABLE_VALUE DECIMAL(35,17) NULL;
      PRINT 'The ICA_FLOW_ICIS column ICA_TST_RSLTS.ALLOWABLE_VALUE was successfully modified to DECIMAL(35,17).';
    END
  ELSE
    BEGIN
      PRINT 'The ICA_FLOW_ICIS column ICA_TST_RSLTS.ALLOWABLE_VALUE was already DECIMAL(35,17), schema alteration bypassed!';
    END;
END;


/********************************************************************************************************  
    Script Note:  This script will alter the column ACTUAL_RESULT on the ICA_TST_RSLTS table from 
                  INT to a DECIMAL(35,17)
*********************************************************************************************************/
BEGIN

  /* Alter ICA_TST_RSLTS, add column ALLOWABLE_VALUE */
  IF EXISTS (SELECT columns.*
               FROM sys.schemas
               JOIN sys.tables
                 ON tables.schema_id = schemas.schema_id
               JOIN sys.columns
                 ON columns.object_id = tables.object_id
              WHERE schemas.name = 'dbo'
                AND tables.name = 'ICA_TST_RSLTS'
                AND columns.name = 'ACTUAL_RESULT'
                AND columns.precision = 10
                AND columns.scale = 0)
    BEGIN
      ALTER TABLE ICA_TST_RSLTS ALTER COLUMN ACTUAL_RESULT DECIMAL(35,17) NULL;
      PRINT 'The ICA_FLOW_ICIS column ICA_TST_RSLTS.ACTUAL_RESULT was successfully modified to DECIMAL(35,17).';
    END
  ELSE
    BEGIN
      PRINT 'The ICA_FLOW_ICIS column ICA_TST_RSLTS.ACTUAL_RESULT was already DECIMAL(35,17), schema alteration bypassed!';
    END;
END;
GO


/********************************************************************************************************  
    Script Note:  This script will alter the column ICA_VIOL on the VIOL_PROG_DESC_TXT table from 
                  VARCHAR(1000) to VARCHAR(100).
*********************************************************************************************************/
BEGIN

  /* Alter ICA_VIOL, add column ALLOWABLE_VALUE */
  IF EXISTS (SELECT columns.*
               FROM sys.schemas
               JOIN sys.tables
                 ON tables.schema_id = schemas.schema_id
               JOIN sys.columns
                 ON columns.object_id = tables.object_id
              WHERE schemas.name = 'dbo'
                AND tables.name = 'ICA_VIOL'
                AND columns.name = 'VIOL_PROG_DESC_TXT'
                AND columns.max_length = 1000
                AND columns.max_length <> 100)
    BEGIN
     
      --  Get rid of any characters beyond 100 to avoid issues when altering 
      --  datatype from 1000 to 100.
      UPDATE ICA_VIOL SET VIOL_PROG_DESC_TXT = SUBSTRING(VIOL_PROG_DESC_TXT,1,100);

      ALTER TABLE ICA_VIOL ALTER COLUMN VIOL_PROG_DESC_TXT VARCHAR(100) NULL;
      PRINT 'The ICA_FLOW_ICIS column ICA_VIOL.ACTUAL_RESULT was successfully modified to VARCHAR(100).';
    END
  ELSE
    BEGIN
      PRINT 'The ICA_FLOW_ICIS column ICA_VIOL.ACTUAL_RESULT was already VARCHAR(100), schema alteration bypassed!';
    END;
END;
GO


/********************************************************************************************************  
    Script Note:  This script will add the column FINAL_ORDER_LODGED_DATE onto the ICA_DA_FINAL_ORDER 
                  staging table.
*********************************************************************************************************/
BEGIN

  /* Alter ICA_DA_FINAL_ORDER, add column ICA_DA_FINAL_ORDER */
  IF EXISTS (SELECT columns.*
               FROM sys.schemas
               JOIN sys.tables
                 ON tables.schema_id = schemas.schema_id
               JOIN sys.columns
                 ON columns.object_id = tables.object_id
              WHERE schemas.name = 'dbo'
                AND tables.name = 'ICA_DA_FINAL_ORDER'
                AND columns.name = 'FINAL_ORDER_LODGED_DATE')
    BEGIN
      PRINT 'The ICA_FLOW_ICIS column FINAL_ORDER_LODGED_DATE was already added to ICA_DA_FINAL_ORDER, schema alteration bypassed!';
    END;
  ELSE
    BEGIN
      ALTER TABLE ICA_DA_FINAL_ORDER ADD FINAL_ORDER_LODGED_DATE DATETIME NULL;
      PRINT 'The ICA_FLOW_ICIS column FINAL_ORDER_LODGED_DATE was successfully added to ICA_DA_FINAL_ORDER.';
    END
END;
GO

/********************************************************************************************************  
    Script Note:  This script will add the staging table ICA_DEMND_STIPULTD_PNLTY and related RI
                  components.
*********************************************************************************************************/
BEGIN

  /* Add ICA_DEMND_STIPULTD_PNLTY  */
  IF EXISTS (SELECT 1
               FROM sys.schemas
               JOIN sys.tables
                 ON tables.schema_id = schemas.schema_id
              WHERE schemas.name = 'dbo'
                AND tables.name = 'ICA_DEMND_STIPULTD_PNLTY')
    BEGIN
      PRINT 'The ICA_FLOW_ICIS table ICA_DEMND_STIPULTD_PNLTY has already been created, schema alteration bypassed!';
    END;
  ELSE
    BEGIN

      --  Create new staging table ICA_DEMND_STIPULTD_PNLTY
      CREATE TABLE [dbo].[ICA_DEMND_STIPULTD_PNLTY] (
        [ICA_DEMND_STIPULTD_PNLTY_ID] [varchar](36) NOT NULL,
        [ICA_DA_FINAL_ORDER_ID] [varchar](36) NOT NULL,
        [DEMND_STIPULTD_PNLTY_AMT] [decimal](17,2) NOT NULL,
        [DEMND_STIPULTD_PNLTY_PAID_DATE] [datetime] NOT NULL,
        [DATA_HASH] [varchar](100),
       CONSTRAINT [PK_DEMND_STIPULTD_PNLTY] PRIMARY KEY CLUSTERED 
      (
	      [ICA_DEMND_STIPULTD_PNLTY_ID] ASC
      )WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
      ) ON [PRIMARY];

      --  Create index on foreign key column ICA_DA_FINAL_ORDER_ID to ICA_DA_FINAL_ORDER.
      CREATE NONCLUSTERED INDEX IX_DMN_STP_PNL_ICA_DA_FI_OR_ID ON dbo.ICA_DEMND_STIPULTD_PNLTY(ICA_DA_FINAL_ORDER_ID);

      ALTER TABLE dbo.ICA_DEMND_STIPULTD_PNLTY ADD CONSTRAINT FK_DMND_STPL_PNLT_DA_FINL_ORDR
      FOREIGN KEY(ICA_DA_FINAL_ORDER_ID) REFERENCES dbo.ICA_DA_FINAL_ORDER(ICA_DA_FINAL_ORDER_ID)
      ON DELETE CASCADE ON UPDATE NO ACTION;

      PRINT 'The ICA_FLOW_ICIS table ICA_DEMND_STIPULTD_PNLTY was successfully created.';
    END

END;
GO



/*
 *  Correct key_hash indexes on ICA_TVACC if issue exists, otherwise rebuild indexes.
 */
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_KEY_HASH_CASE_FILE_LNK' and object_id = (select object_id('ICA_TVACC')))
  DROP INDEX ix_key_hash_case_file_lnk ON dbo.ica_tvacc
GO
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_KEY_HASH_CASE_FILE_LNK')
  DROP INDEX ix_key_hash_case_file_lnk ON dbo.ica_case_file_lnk
GO
CREATE INDEX ix_key_hash_case_file_lnk
	ON dbo.ica_case_file_lnk(key_hash)
GO

IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_KEY_HASH_CMPL_MON_LNK' and object_id = (select object_id('ICA_TVACC')))
  DROP INDEX ix_key_hash_cmpl_mon_lnk ON dbo.ica_tvacc
GO
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_KEY_HASH_CMPL_MON_LNK')
  DROP INDEX ix_key_hash_cmpl_mon_lnk ON dbo.ica_cmpl_mon_lnk
GO
CREATE INDEX ix_key_hash_cmpl_mon_lnk
	ON dbo.ica_cmpl_mon_lnk(key_hash)
GO

IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_KEY_HASH_DA_CASE_FILE' and object_id = (select object_id('ICA_TVACC')))
  DROP INDEX ix_key_hash_da_case_file ON dbo.ica_tvacc
GO
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_KEY_HASH_DA_CASE_FILE')
  DROP INDEX ix_key_hash_da_case_file ON dbo.ica_da_case_file
GO
CREATE INDEX IX_KEY_HASH_DA_CASE_FILE
	ON dbo.ICA_DA_CASE_FILE(KEY_HASH)
GO

IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_KEY_HASH_DA_ENFRC_ACTN_LNK' and object_id = (select object_id('ICA_TVACC')))
  DROP INDEX ix_key_hash_da_enfrc_actn_lnk ON dbo.ica_tvacc
GO
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_KEY_HASH_DA_ENFRC_ACTN_LNK')
  DROP INDEX ix_key_hash_da_enfrc_actn_lnk ON dbo.ica_da_enfrc_actn_lnk
GO
CREATE INDEX ix_key_hash_da_enfrc_actn_lnk
	ON dbo.ica_da_enfrc_actn_lnk(key_hash)
GO



--  Now alter the LOCAL database objects
USE [ICA_FLOW_LOCAL]
GO

/********************************************************************************************************  
    Script Note:  This script will alter the column ALLOWABLE_VALUE on the ICA_TST_RSLTS table from 
                  INT to a DECIMAL(35,17)
*********************************************************************************************************/
BEGIN

  /* Alter ICA_TST_RSLTS, add column ALLOWABLE_VALUE */
  IF EXISTS (SELECT columns.*
               FROM sys.schemas
               JOIN sys.tables
                 ON tables.schema_id = schemas.schema_id
               JOIN sys.columns
                 ON columns.object_id = tables.object_id
              WHERE schemas.name = 'dbo'
                AND tables.name = 'ICA_TST_RSLTS'
                AND columns.name = 'ALLOWABLE_VALUE'
                AND columns.precision = 10
                AND columns.scale = 0)
    BEGIN
      ALTER TABLE ICA_TST_RSLTS ALTER COLUMN ALLOWABLE_VALUE DECIMAL(35,17) NULL;
      PRINT 'The ICA_FLOW_LOCAL column ICA_TST_RSLTS.ALLOWABLE_VALUE was successfully modified to DECIMAL(35,17).';
    END
  ELSE
    BEGIN
      PRINT 'The ICA_FLOW_LOCAL column ICA_TST_RSLTS.ALLOWABLE_VALUE was already DECIMAL(35,17), schema alteration bypassed!';
    END;
END;


/********************************************************************************************************  
    Script Note:  This script will alter the column ACTUAL_RESULT on the ICA_TST_RSLTS table from 
                  INT to a DECIMAL(35,17)
*********************************************************************************************************/
BEGIN

  /* Alter ICA_TST_RSLTS, add column ALLOWABLE_VALUE */
  IF EXISTS (SELECT columns.*
               FROM sys.schemas
               JOIN sys.tables
                 ON tables.schema_id = schemas.schema_id
               JOIN sys.columns
                 ON columns.object_id = tables.object_id
              WHERE schemas.name = 'dbo'
                AND tables.name = 'ICA_TST_RSLTS'
                AND columns.name = 'ACTUAL_RESULT'
                AND columns.precision = 10
                AND columns.scale = 0)
    BEGIN
      ALTER TABLE ICA_TST_RSLTS ALTER COLUMN ACTUAL_RESULT DECIMAL(35,17) NULL;
      PRINT 'The ICA_FLOW_LOCAL column ICA_TST_RSLTS.ACTUAL_RESULT was successfully modified to DECIMAL(35,17).';
    END
  ELSE
    BEGIN
      PRINT 'The ICA_FLOW_LOCAL column ICA_TST_RSLTS.ACTUAL_RESULT was already DECIMAL(35,17), schema alteration bypassed!';
    END;
END;
GO


/********************************************************************************************************  
    Script Note:  This script will alter the column ICA_VIOL on the VIOL_PROG_DESC_TXT table from 
                  VARCHAR(1000) to VARCHAR(100).
*********************************************************************************************************/
BEGIN

  /* Alter ICA_VIOL, add column ALLOWABLE_VALUE */
  IF EXISTS (SELECT columns.*
               FROM sys.schemas
               JOIN sys.tables
                 ON tables.schema_id = schemas.schema_id
               JOIN sys.columns
                 ON columns.object_id = tables.object_id
              WHERE schemas.name = 'dbo'
                AND tables.name = 'ICA_VIOL'
                AND columns.name = 'VIOL_PROG_DESC_TXT'
                AND columns.max_length = 1000
                AND columns.max_length <> 100)
    BEGIN
     
      --  Get rid of any characters beyond 100 to avoid issues when altering 
      --  datatype from 1000 to 100.
      UPDATE ICA_VIOL SET VIOL_PROG_DESC_TXT = SUBSTRING(VIOL_PROG_DESC_TXT,1,100);

      ALTER TABLE ICA_VIOL ALTER COLUMN VIOL_PROG_DESC_TXT VARCHAR(100) NULL;
      PRINT 'The ICA_FLOW_LOCAL column ICA_VIOL.ACTUAL_RESULT was successfully modified to VARCHAR(100).';
    END
  ELSE
    BEGIN
      PRINT 'The ICA_FLOW_LOCAL column ICA_VIOL.ACTUAL_RESULT was already VARCHAR(100), schema alteration bypassed!';
    END;
END;
GO


/********************************************************************************************************  
    Script Note:  This script will add the column FINAL_ORDER_LODGED_DATE onto the ICA_DA_FINAL_ORDER 
                  staging table.
*********************************************************************************************************/
BEGIN

  /* Alter ICA_DA_FINAL_ORDER, add column ICA_DA_FINAL_ORDER */
  IF EXISTS (SELECT columns.*
               FROM sys.schemas
               JOIN sys.tables
                 ON tables.schema_id = schemas.schema_id
               JOIN sys.columns
                 ON columns.object_id = tables.object_id
              WHERE schemas.name = 'dbo'
                AND tables.name = 'ICA_DA_FINAL_ORDER'
                AND columns.name = 'FINAL_ORDER_LODGED_DATE')
    BEGIN
      PRINT 'The ICA_FLOW_LOCAL column FINAL_ORDER_LODGED_DATE was already added to ICA_DA_FINAL_ORDER, schema alteration bypassed!';
    END;
  ELSE
    BEGIN
      ALTER TABLE ICA_DA_FINAL_ORDER ADD FINAL_ORDER_LODGED_DATE DATETIME NULL;
      PRINT 'The ICA_FLOW_LOCAL column FINAL_ORDER_LODGED_DATE was successfully added to ICA_DA_FINAL_ORDER.';
    END
END;
GO

/********************************************************************************************************  
    Script Note:  This script will add the staging table ICA_DEMND_STIPULTD_PNLTY and related RI
                  components.
*********************************************************************************************************/
BEGIN

  /* Add ICA_DEMND_STIPULTD_PNLTY  */
  IF EXISTS (SELECT 1
               FROM sys.schemas
               JOIN sys.tables
                 ON tables.schema_id = schemas.schema_id
              WHERE schemas.name = 'dbo'
                AND tables.name = 'ICA_DEMND_STIPULTD_PNLTY')
    BEGIN
      PRINT 'The ICA_FLOW_LOCAL table ICA_DEMND_STIPULTD_PNLTY has already been created, schema alteration bypassed!';
    END;
  ELSE
    BEGIN

      --  Create new staging table ICA_DEMND_STIPULTD_PNLTY
      CREATE TABLE [dbo].[ICA_DEMND_STIPULTD_PNLTY] (
        [ICA_DEMND_STIPULTD_PNLTY_ID] [varchar](36) NOT NULL,
        [ICA_DA_FINAL_ORDER_ID] [varchar](36) NOT NULL,
        [DEMND_STIPULTD_PNLTY_AMT] [decimal](17,2) NOT NULL,
        [DEMND_STIPULTD_PNLTY_PAID_DATE] [datetime] NOT NULL,
        [DATA_HASH] [varchar](100),
       CONSTRAINT [PK_DEMND_STIPULTD_PNLTY] PRIMARY KEY CLUSTERED 
      (
	      [ICA_DEMND_STIPULTD_PNLTY_ID] ASC
      )WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
      ) ON [PRIMARY];

      --  Create index on foreign key column ICA_DA_FINAL_ORDER_ID to ICA_DA_FINAL_ORDER.
      CREATE NONCLUSTERED INDEX IX_DMN_STP_PNL_ICA_DA_FI_OR_ID ON dbo.ICA_DEMND_STIPULTD_PNLTY(ICA_DA_FINAL_ORDER_ID);

      ALTER TABLE dbo.ICA_DEMND_STIPULTD_PNLTY ADD CONSTRAINT FK_DMND_STPL_PNLT_DA_FINL_ORDR
      FOREIGN KEY(ICA_DA_FINAL_ORDER_ID) REFERENCES dbo.ICA_DA_FINAL_ORDER(ICA_DA_FINAL_ORDER_ID)
      ON DELETE CASCADE ON UPDATE NO ACTION;

      PRINT 'The ICA_FLOW_LOCAL table ICA_DEMND_STIPULTD_PNLTY was successfully created.';
    END

END;
GO



/*
 *  Correct key_hash indexes on ICA_TVACC if issue exists, otherwise rebuild indexes.
 */
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_KEY_HASH_CASE_FILE_LNK' and object_id = (select object_id('ICA_TVACC')))
  DROP INDEX ix_key_hash_case_file_lnk ON dbo.ica_tvacc
GO
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_KEY_HASH_CASE_FILE_LNK')
  DROP INDEX ix_key_hash_case_file_lnk ON dbo.ica_case_file_lnk
GO
CREATE INDEX ix_key_hash_case_file_lnk
	ON dbo.ica_case_file_lnk(key_hash)
GO

IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_KEY_HASH_CMPL_MON_LNK' and object_id = (select object_id('ICA_TVACC')))
  DROP INDEX ix_key_hash_cmpl_mon_lnk ON dbo.ica_tvacc
GO
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_KEY_HASH_CMPL_MON_LNK')
  DROP INDEX ix_key_hash_cmpl_mon_lnk ON dbo.ica_cmpl_mon_lnk
GO
CREATE INDEX ix_key_hash_cmpl_mon_lnk
	ON dbo.ica_cmpl_mon_lnk(key_hash)
GO

IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_KEY_HASH_DA_CASE_FILE' and object_id = (select object_id('ICA_TVACC')))
  DROP INDEX ix_key_hash_da_case_file ON dbo.ica_tvacc
GO
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_KEY_HASH_DA_CASE_FILE')
  DROP INDEX ix_key_hash_da_case_file ON dbo.ica_da_case_file
GO
CREATE INDEX IX_KEY_HASH_DA_CASE_FILE
	ON dbo.ICA_DA_CASE_FILE(KEY_HASH)
GO

IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_KEY_HASH_DA_ENFRC_ACTN_LNK' and object_id = (select object_id('ICA_TVACC')))
  DROP INDEX ix_key_hash_da_enfrc_actn_lnk ON dbo.ica_tvacc
GO
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_KEY_HASH_DA_ENFRC_ACTN_LNK')
  DROP INDEX ix_key_hash_da_enfrc_actn_lnk ON dbo.ica_da_enfrc_actn_lnk
GO
CREATE INDEX ix_key_hash_da_enfrc_actn_lnk
	ON dbo.ica_da_enfrc_actn_lnk(key_hash)
GO

/* **************
 * Rebuild views
 * **************/
 USE [ICA_FLOW_LOCAL]
 GO

 IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.vw_ica_poluts_class') AND type = N'V')
   DROP VIEW dbo.vw_ica_poluts_class
 GO

/*************************************************************************************************
** Object Name: vw_ica_polut_class
**
** Author: Windsor Solutions, Inc.
**
** Description:  This database view supports the Java version of OpenNode2.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/11/2014    Windsor     Created
**
***************************************************************************************************/
CREATE VIEW dbo.vw_ica_poluts_class as
SELECT ica_poluts.*
     , ica_polut_da_class.polut_da_class_code
     , ica_polut_da_class.polut_da_class_start_date
     , ica_polut_epa_class.polut_epa_class_code
     , ica_polut_epa_class.polut_epa_class_start_date
  FROM dbo.ica_poluts
  LEFT JOIN dbo.ica_polut_da_class
    ON ica_polut_da_class.ica_poluts_id = ica_poluts.ica_poluts_id
  LEFT JOIN dbo.ica_polut_epa_class
    ON ica_polut_epa_class.ica_poluts_id = ica_poluts.ica_poluts_id;
GO

IF EXISTS(select 1 FROM sys.views where name = 'vw_ica_case_file_lnk')
  DROP VIEW vw_ica_case_file_lnk;
GO
/*************************************************************************************************
** Object Name: VW_ICA_CASE_FILE_LNK
**
** Author: Windsor Solutions, Inc.
**
** Description:  This database view supports the Java version of OpenNode2.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/24/2014    Windsor     Created
**
***************************************************************************************************/
CREATE VIEW dbo.vw_ica_case_file_lnk AS
SELECT
  cfl.ICA_CASE_FILE_LNK_ID,
  cfl.ICA_PAYLOAD_ID,
  cfl.TRANSACTION_TYPE,
  cfl.TRANSACTION_TIMESTAMP,
  cfl.SRC_SYSTM_IDENT,
  cfl.CASE_FILE_IDENT,
  lcf.case_file_ident AS lnk_case_file_ident,
  lcm.cmpl_mon_ident AS lnk_cmpl_mon_ident,
  daea.da_enfrc_actn_ident AS lnk_da_enfrc_actn_ident
FROM ICA_FLOW_LOCAL.dbo.ica_case_file_lnk cfl
LEFT JOIN ICA_FLOW_LOCAL.dbo.ica_lnk_case_file lcf ON cfl.ICA_CASE_FILE_LNK_ID = lcf.ICA_CASE_FILE_LNK_ID
LEFT JOIN ICA_FLOW_LOCAL.dbo.ica_lnk_cmpl_mon lcm ON cfl.ICA_CASE_FILE_LNK_ID = lcm.ICA_CASE_FILE_LNK_ID
LEFT JOIN ICA_FLOW_LOCAL.dbo.ica_lnk_da_enfrc_actn daea ON cfl.ICA_CASE_FILE_LNK_ID = daea.ICA_CASE_FILE_LNK_ID;
GO


IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.vw_ica_cmpl_mon_lnk') AND type = N'V')
DROP VIEW dbo.vw_ica_cmpl_mon_lnk
GO

/*************************************************************************************************
** Object Name: VW_ICA_CMPL_MON_LNK
**
** Author: Windsor Solutions, Inc.
**
** Description:  This database view supports the Java version of OpenNode2.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/24/2014    Windsor     Created
**
***************************************************************************************************/
CREATE VIEW dbo.vw_ica_cmpl_mon_lnk AS
SELECT ica_cmpl_mon_lnk.*
     , ica_lnk_cmpl_mon.cmpl_mon_ident as lnk_cmpl_mon_ident
     , ica_lnk_da_enfrc_actn.da_enfrc_actn_ident as lnk_da_enfrc_actn_ident
  FROM ica_cmpl_mon_lnk
  LEFT JOIN ica_lnk_cmpl_mon
    ON ica_lnk_cmpl_mon.ica_cmpl_mon_lnk_id = ica_cmpl_mon_lnk.ica_cmpl_mon_lnk_id
  LEFT JOIN ica_lnk_da_enfrc_actn
    ON ica_lnk_da_enfrc_actn.ica_cmpl_mon_lnk_id = ica_cmpl_mon_lnk.ica_cmpl_mon_lnk_id;
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.vw_ica_fac_geo_coord') AND type = N'V')
DROP VIEW dbo.vw_ica_fac_geo_coord
GO

/*************************************************************************************************
** Object Name: vw_ica_fac_geo_coord
**
** Author: Windsor Solutions, Inc.
**
** Description:  This database view supports the Java version of OpenNode2.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/11/2014    Windsor     Created
**
***************************************************************************************************/
CREATE VIEW dbo.vw_ica_fac_geo_coord AS
SELECT ica_fac.*
     , ica_geo_coord_id
     ,	lat_meas 
     ,	long_meas
     ,	horz_accuracy_meas
     ,	geom_type_code
     ,	horz_coll_method_code
     ,	horz_ref_datum_code
     ,	ref_point_code 
     ,	src_map_scale_num 
     ,	utm_coord_1
     ,	utm_coord_2 
     ,	utm_coord_3
  FROM ica_fac
  LEFT JOIN ica_geo_coord
    ON ica_geo_coord.ica_fac_id = ica_fac.ica_fac_id;
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.vw_ica_da_enfrc_actn_lnk') AND type = N'V')
DROP VIEW dbo.vw_ica_da_enfrc_actn_lnk
GO

/*************************************************************************************************
** Object Name: VW_ICA_DA_ENFRC_ACTN_LNK
**
** Author: Windsor Solutions, Inc.
**
** Description:  This database view supports the Java version of OpenNode2.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/11/2014    Windsor     Created
**
***************************************************************************************************/
CREATE VIEW vw_ica_da_enfrc_actn_lnk AS
SELECT ica_da_enfrc_actn_lnk.*
     , ica_lnk_da_enfrc_actn.da_enfrc_actn_ident as lnk_da_enfrc_actn_ident
  FROM ica_da_enfrc_actn_lnk
  LEFT JOIN ica_lnk_da_enfrc_actn
    ON ica_lnk_da_enfrc_actn.ica_da_enfrc_actn_lnk_id = ica_da_enfrc_actn_lnk.ica_da_enfrc_actn_lnk_id;
GO



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.ica_v_module_count') AND type = N'V')
DROP VIEW dbo.ica_v_module_count
GO

/*************************************************************************************************
** Object Name: ica_v_module_count
**
** Author: Windsor Solutions, Inc.
**
** Description:  This view identifies data changes within an ICIS-Air module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 08/11/2014    Windsor     Created
** 08/11/2014    Windsor     Removed the trans_count_new data element from this database view.
**
***************************************************************************************************/
CREATE VIEW dbo.ica_v_module_count
(
  subm_date_time
, subm_transaction_id
, subm_type_name
, trans_count_chng_repl
, trans_count_del_mass_del
, error_count
, warning_count
, accepted_count
, accepted_count_total
) AS
SELECT (SELECT subm_date_time
              FROM ica_subm_track
             WHERE subm_transaction_id = rslt.subm_transaction_id)
             AS subm_date_time
         , subm_transaction_id
         , subm_type_name
         , ISNULL(CASE
             WHEN rslt.subm_type_name = 'AirComplianceMonitoringStrategySubmission'
             THEN
               (SELECT COUNT (1)
                  FROM ica_cmpl_mon_strgy
                 WHERE transaction_type IN ('C', 'R'))
             WHEN rslt.subm_type_name = 'AirDACaseFileSubmission'
             THEN
               (SELECT COUNT (1)
                  FROM ica_da_case_file
                 WHERE transaction_type IN ('C', 'R'))
             WHEN rslt.subm_type_name = 'AirDAComplianceMonitoringSubmission'
             THEN
               (SELECT COUNT (1)
                  FROM ica_da_cmpl_mon
                 WHERE transaction_type IN ('C', 'R'))
             WHEN rslt.subm_type_name = 'AirDAEnforcementActionLinkageSubmission'
             THEN
               (SELECT COUNT (1)
                  FROM ica_da_enfrc_actn_lnk
                 WHERE transaction_type IN ('C', 'R'))
             WHEN rslt.subm_type_name = 'AirDAEnforcementActionMilestoneSubmission'
             THEN
               (SELECT COUNT (1)
                  FROM ica_da_enfrc_actn_milstn
                 WHERE transaction_type IN ('C', 'R'))
             WHEN rslt.subm_type_name = 'AirDAFormalEnforcementActionSubmission'
             THEN
               (SELECT COUNT (1)
                  FROM ica_da_frml_enfrc_actn
                 WHERE transaction_type IN ('C', 'R'))
             WHEN rslt.subm_type_name = 'AirDAInformalEnforcementActionSubmission'
             THEN
               (SELECT COUNT (1)
                  FROM ica_da_infrml_enfrc_actn
                 WHERE transaction_type IN ('C', 'R'))
             WHEN rslt.subm_type_name = 'AirFacilitySubmission'
             THEN
               (SELECT COUNT (1)
                  FROM ica_fac
                 WHERE transaction_type IN ('C', 'R'))
             WHEN rslt.subm_type_name = 'AirPollutantsSubmission'
             THEN
               (SELECT COUNT (1)
                  FROM ica_poluts
                 WHERE transaction_type IN ('C', 'R'))
             WHEN rslt.subm_type_name = 'AirProgramsSubmission'
             THEN
               (SELECT COUNT (1)
                  FROM ica_progs
                 WHERE transaction_type IN ('C', 'R'))
             WHEN rslt.subm_type_name = 'AirTVACCSubmission'
             THEN
               (SELECT COUNT (1)
                  FROM ica_tvacc
                 WHERE transaction_type IN ('C', 'R'))
             WHEN rslt.subm_type_name = 'CaseFileLinkageSubmission'
             THEN
               (SELECT COUNT (1)
                  FROM ica_case_file_lnk
                 WHERE transaction_type IN ('C', 'R'))
             WHEN rslt.subm_type_name = 'ComplianceMonitoringLinkageSubmission'
             THEN
               (SELECT COUNT (1)
                  FROM ica_cmpl_mon_lnk
                 WHERE transaction_type IN ('C', 'R'))
           END,0)
             AS trans_count_chng_repl
         , ISNULL(CASE
             WHEN rslt.subm_type_name = 'AirComplianceMonitoringStrategySubmission'
             THEN
               (SELECT COUNT (1)
                  FROM ica_cmpl_mon_strgy
                 WHERE transaction_type IN ('D', 'X'))
             WHEN rslt.subm_type_name = 'AirDACaseFileSubmission'
             THEN
               (SELECT COUNT (1)
                  FROM ica_da_case_file
                 WHERE transaction_type IN ('D', 'X'))
             WHEN rslt.subm_type_name = 'AirDAComplianceMonitoringSubmission'
             THEN
               (SELECT COUNT (1)
                  FROM ica_da_cmpl_mon
                 WHERE transaction_type IN ('D', 'X'))
             WHEN rslt.subm_type_name = 'AirDAEnforcementActionLinkageSubmission'
             THEN
               (SELECT COUNT (1)
                  FROM ica_da_enfrc_actn_lnk
                 WHERE transaction_type IN ('D', 'X'))
             WHEN rslt.subm_type_name = 'AirDAEnforcementActionMilestoneSubmission'
             THEN
               (SELECT COUNT (1)
                  FROM ica_da_enfrc_actn_milstn
                 WHERE transaction_type IN ('D', 'X'))
             WHEN rslt.subm_type_name = 'AirDAFormalEnforcementActionSubmission'
             THEN
               (SELECT COUNT (1)
                  FROM ica_da_frml_enfrc_actn
                 WHERE transaction_type IN ('D', 'X'))
             WHEN rslt.subm_type_name = 'AirDAInformalEnforcementActionSubmission'
             THEN
               (SELECT COUNT (1)
                  FROM ica_da_infrml_enfrc_actn
                 WHERE transaction_type IN ('D', 'X'))
             WHEN rslt.subm_type_name = 'AirFacilitySubmission'
             THEN
               (SELECT COUNT (1)
                  FROM ica_fac
                 WHERE transaction_type IN ('D', 'X'))
             WHEN rslt.subm_type_name = 'AirPollutantsSubmission'
             THEN
               (SELECT COUNT (1)
                  FROM ica_poluts
                 WHERE transaction_type IN ('D', 'X'))
             WHEN rslt.subm_type_name = 'AirProgramsSubmission'
             THEN
               (SELECT COUNT (1)
                  FROM ica_progs
                 WHERE transaction_type IN ('D', 'X'))
             WHEN rslt.subm_type_name = 'AirTVACCSubmission'
             THEN
               (SELECT COUNT (1)
                  FROM ica_tvacc
                 WHERE transaction_type IN ('D', 'X'))
             WHEN rslt.subm_type_name = 'CaseFileLinkageSubmission'
             THEN
               (SELECT COUNT (1)
                  FROM ica_case_file_lnk
                 WHERE transaction_type IN ('D', 'X'))
             WHEN rslt.subm_type_name = 'ComplianceMonitoringLinkageSubmission'
             THEN
               (SELECT COUNT (1)
                  FROM ica_cmpl_mon_lnk
                 WHERE transaction_type IN ('D', 'X'))
           END,0)
             AS trans_count_del_mass_del
         , ISNULL((SELECT COUNT (1)
              FROM ica_subm_rslts
             WHERE subm_type_name = rslt.subm_type_name
                   AND result_type_code = 'Error'),0)
             AS error_count
         , ISNULL((SELECT COUNT (1)
              FROM ica_subm_rslts
             WHERE subm_type_name = rslt.subm_type_name
                   AND result_type_code = 'Warning'),0)
             AS warning_count
         , ISNULL((SELECT COUNT (1)
              FROM ica_subm_rslts
             WHERE subm_type_name = rslt.subm_type_name
                   AND result_type_code = 'Accepted'),0)
             AS accepted_count
         , ISNULL(CASE
             WHEN rslt.subm_type_name = 'AirComplianceMonitoringStrategySubmission'
             THEN
               (  SELECT COUNT (1) FROM ica_flow_icis.dbo.ica_cmpl_mon_strgy)
             WHEN rslt.subm_type_name = 'AirDACaseFileSubmission'
             THEN
               (  SELECT COUNT (1) FROM ica_flow_icis.dbo.ica_da_case_file)
             WHEN rslt.subm_type_name = 'AirDAComplianceMonitoringSubmission'
             THEN
               (  SELECT COUNT (1) FROM ica_flow_icis.dbo.ica_da_cmpl_mon)
             WHEN rslt.subm_type_name = 'AirDAEnforcementActionLinkageSubmission'
             THEN
               (  SELECT COUNT (1) FROM ica_flow_icis.dbo.ica_da_enfrc_actn_lnk)
             WHEN rslt.subm_type_name = 'AirDAEnforcementActionMilestoneSubmission'
             THEN
               (  SELECT COUNT (1) FROM ica_flow_icis.dbo.ica_da_enfrc_actn_milstn)
             WHEN rslt.subm_type_name = 'AirDAFormalEnforcementActionSubmission'
             THEN
               (  SELECT COUNT (1) FROM ica_flow_icis.dbo.ica_da_frml_enfrc_actn)
             WHEN rslt.subm_type_name = 'AirDAInformalEnforcementActionSubmission'
             THEN
               (  SELECT COUNT (1) FROM ica_flow_icis.dbo.ica_da_infrml_enfrc_actn)
             WHEN rslt.subm_type_name = 'AirFacilitySubmission'
             THEN
               (  SELECT COUNT (1) FROM ica_flow_icis.dbo.ica_fac)
             WHEN rslt.subm_type_name = 'AirPollutantsSubmission'
             THEN
               (  SELECT COUNT (1) FROM ica_flow_icis.dbo.ica_poluts)
             WHEN rslt.subm_type_name = 'AirProgramsSubmission'
             THEN
               (  SELECT COUNT (1) FROM ica_flow_icis.dbo.ica_progs)
             WHEN rslt.subm_type_name = 'AirTVACCSubmission'
             THEN
               (  SELECT COUNT (1) FROM ica_flow_icis.dbo.ica_tvacc)
             WHEN rslt.subm_type_name = 'CaseFileLinkageSubmission'
             THEN
               (  SELECT COUNT (1) FROM ica_flow_icis.dbo.ica_case_file_lnk)
             WHEN rslt.subm_type_name = 'ComplianceMonitoringLinkageSubmission'
             THEN
               (  SELECT COUNT (1) FROM ica_flow_icis.dbo.ica_cmpl_mon_lnk)
           END,0)
             AS accepted_count_total
      FROM ica_subm_rslts rslt
  GROUP BY subm_transaction_id, subm_type_name;
  GO


/* ********************
 * Rebuild Procedures
 * ********************/
 USE [ICA_FLOW_LOCAL]
 GO

/*
Copyright (c) 2014, The Environmental Council of the States (ECOS)
All rights reserved.
 
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
 
 * Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
 * Neither the name of the ECOS nor the names of its contributors may
   be used to endorse or promote products derived from this software
   without specific prior written permission.
 
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.ICA_CHANGE_DETECTION') AND type = N'P')
DROP PROCEDURE dbo.ICA_CHANGE_DETECTION
GO

/******************************************************************************************************************************
** Object Name: ICA_CHANGE_DETECTION
**
** Author: Windsor Solutions, Inc.
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure will detect data changes made within the ICIS schema and then sets the transaction type
**               flags so the data can be bundled and submitted to an exchange partner.
**
** Inputs:  -- NA --  
**
**
** Revision History:      
** ----------------------------------------------------------------------------------------------------------------------------
**  Date         Analyst     Description
** ----------------------------------------------------------------------------------------------------------------------------
** 07/18/2014    KJames      Baseline from ICIS v4.0 procedure.
** 07/30/2014    KJames      Moved data element PORT_SRC_IND from ICA_PORT_SRC to ICA_FAC.
** 08/06/2014    KJames      Added data element LOCALITY_NAME to ICA_FAC.
** 08/06/2014    KJames      Added data element LOC_ADDR_COUNTY_CODE to ICA_FAC.
** 09/03/2014    KJames      Added code to hash the linkage tables.
** 09/03/2014    KJames      Added setting of delete transactions of linkage tables.
** 09/04/2014    KJames      Added OTHR_PROG_DESC_TXT to the database tables ICA_DA_FRML_ENFRC_ACTN and
**                           ICA_DA_INFRML_ENFRC_ACTN.
** 10/10/2014    KJames      Added the @v_enabled flag for each payload type to control hashing.
** 10/10/2014    KJames      Futher refined the use of @v_enabled, expanded to prevent the population of 
**                           a disabled payloads transaction_type.
** 01/28/2015    KJames      Added the required field PROG_OPER_STAT_CODE to the logic that builds ICA_PROGS delete records.
** 01/28/2015    KJames      Added the required field FAC_IDENT to the logic that builds ICA_TVACC delete records.
** 01/28/2015    KJames      Added the required field FAC_IDENT to the logic that builds ICA_DA_CASE_FILE delete records.
** 07/06/2015    KJames      Added change processing for new staging table ICA_DEMND_STIPULTD_PNLTY.
** 07/15/2015    KJames      Corrected the database reference for updating ICA_DEMND_STIPULTD_PNLTY data hash.
** 07/15/2015    KJames      Added processing of new data element FINAL_ORDER_LODGED_DATE on ICA_DA_FINAL_ORDER.
** 08/24/2015    KJames      Modified the ICA_PAYLOAD operation name to the proper CaseFileLinkageSubmission.
** 09/21/2015    KJames      Removed SRC_SYSTM_IDENT from the linkage table's key hashing statements.
** 09/21/2015    KJames      Consolidated the key and data hashing for the linkage tables into individual
**                           update statements.
** 03/30/2016    KJames      Altered delete payload logic for linkages to pull parent and related child elements.
**
******************************************************************************************************************************/
CREATE PROCEDURE [dbo].[ICA_CHANGE_DETECTION] AS

SET NOCOUNT ON;

DECLARE @v_sql_statement AS NVARCHAR(4000);
DECLARE @v_sql_param AS NVARCHAR(100);
DECLARE @p_payload_type AS NVARCHAR(50); 

/* Working Hash Variables */
DECLARE @v_data_hash AS VARCHAR(100);
DECLARE @v_key_hash AS VARCHAR(100);
DECLARE @v_all_data_hashes AS VARCHAR(100);  
DECLARE @v_hashed_data_hashes AS VARCHAR(100); 
DECLARE @v_enabled AS CHAR(1);
DECLARE @v_enabled_val AS CHAR(1);

DECLARE payload_type_delete CURSOR 
    FOR SELECT DISTINCT child_table.name child_table_name 
          FROM sys.foreign_key_columns
          JOIN sys.objects child_table
            ON (child_table.object_id = foreign_key_columns.parent_object_id)
          JOIN sys.objects parent_table
            ON (parent_table.object_id = foreign_key_columns.referenced_object_id)
          JOIN sys.schemas
            ON (parent_table.schema_id = schemas.schema_id)    
         WHERE schemas.name = 'dbo'
           AND parent_table.name = 'ICA_PAYLOAD'
         ORDER BY child_table.name;        
         
DECLARE payload_type_process CURSOR 
    FOR SELECT DISTINCT child_table.name child_table_name 
          FROM sys.foreign_key_columns
          JOIN sys.objects child_table
            ON (child_table.object_id = foreign_key_columns.parent_object_id)
          JOIN sys.objects parent_table
            ON (parent_table.object_id = foreign_key_columns.referenced_object_id)
          JOIN sys.schemas
            ON (parent_table.schema_id = schemas.schema_id)    
         WHERE schemas.name = 'dbo'
           AND parent_table.name = 'ICA_PAYLOAD'
           /* The tables in this list will not have related child data, change processing can be skipped */
           AND child_table.name NOT IN ( 'ICA_BS_PROG_REP'
                                       , 'ICA_CSO_EVT_REP'
                                       , 'ICA_DMR_VIOL'
                                       , 'ICA_ENFRC_ACTN_MILESTONE'
                                       , 'ICA_HIST_PRMT_SCHD_EVTS'
                                       , 'ICA_PRMT_REISSU'
                                       , 'ICA_PRMT_TRACK_EVT'
                                       , 'ICA_PRMT_TERM'
                                       , 'ICA_SCHD_EVT_VIOL'
                                       , 'ICA_SNGL_EVT_VIOL'
                                       , 'ICA_SSO_ANNUL_REP'
                                       , 'ICA_SSO_MONTHLY_EVT_REP')
         ORDER BY child_table.name; 
          
                        
DECLARE key_hash CURSOR 
    FOR SELECT ica_key_hash.key_hash 
          FROM ica_key_hash;
                      
DECLARE data_hash CURSOR 
    FOR SELECT ica_data_hash.data_hash 
          FROM ica_data_hash
        ORDER BY data_hash;
                        
BEGIN

 /*  Initialize working table ICA_KEY_HASH */
 DELETE FROM ica_key_hash;

 /*  Initialize working table ICA_DATA_HASH */
 DELETE FROM ica_data_hash;
 
 /*  
  * Reset transaction_type on all payload tables  
  */
  OPEN payload_type_delete;
  
  
  
  /*  Fetch 1st payload type record */
  FETCH NEXT FROM payload_type_delete INTO @p_payload_type;
  WHILE @@FETCH_STATUS = 0
    BEGIN

      /* For each payload type, remove all the transaction codes from the previous run. */
      SET @v_sql_statement = 'UPDATE ' + @p_payload_type + ' SET TRANSACTION_TYPE = NULL , TRANSACTION_TIMESTAMP = NULL';
      EXECUTE sp_executesql @v_sql_statement;

      -- Get the payload type.
      FETCH NEXT FROM payload_type_delete 
      INTO @p_payload_type;

    END;

   CLOSE payload_type_delete;
  
  /*************************************************/  
  /* START - Set all KEY_HASH and DATA_HASH fields */
  /*************************************************/  
  UPDATE ICA_FLOW_LOCAL.dbo.ica_case_file_cmnt_txt
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    case_file_cmnt_txt
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_cmpl_insp_type
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    cmpl_insp_type_code
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_cmpl_mon_strgy
     SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', ICA_FLOW_LOCAL.dbo.ica_cmpl_mon_strgy.fac_ident),
        data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    ISNULL(src_systm_ident,'')
	  + fac_ident
	  + ISNULL(cms_src_catg_code,'')
	  + ISNULL(CONVERT(varchar(50), cms_min_freq),'')
	  + ISNULL(CONVERT(varchar(50), cms_start_date),'')
	  + ISNULL(active_cms_plan_ind,'')
	  + ISNULL(CONVERT(varchar(50), rmvd_plan_date),'')
	  + ISNULL(rsn_chng_cms_cmnts,'')
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_cntct
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    affil_type_txt
	  + first_name
	  + ISNULL(middle_name,'')
	  + last_name
	  + indvl_title_txt
	  + ISNULL(org_frml_name,'')
	  + ISNULL(st_code,'')
	  + ISNULL(rgn_code,'')
	  + ISNULL(elec_addr_txt,'')
	  + ISNULL(CONVERT(varchar(50), start_date_of_cntct_assc),'')
	  + ISNULL(CONVERT(varchar(50), end_date_of_cntct_assc),'')
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_da_case_file
     SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', ICA_FLOW_LOCAL.dbo.ica_da_case_file.case_file_ident),
        data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    ISNULL(src_systm_ident,'')
	  + case_file_ident
	  + ISNULL(case_file_name,'')
	  + ISNULL(lead_agncy_code,'')
	  + fac_ident
	  + ISNULL(othr_prog_desc_txt,'')
	  + ISNULL(sens_data_ind,'')
	  + ISNULL(lead_agncy_chng_sprsed_txt,'')
	  + ISNULL(advise_method_type_code,'')
	  + ISNULL(CONVERT(varchar(50), advise_method_date),'')
	  + ISNULL(case_file_usr_def_fld_1,'')
	  + ISNULL(case_file_usr_def_fld_2,'')
	  + ISNULL(case_file_usr_def_fld_3,'')
	  + ISNULL(CONVERT(varchar(50), case_file_usr_def_fld_4),'')
	  + ISNULL(CONVERT(varchar(50), case_file_usr_def_fld_5),'')
	  + ISNULL(case_file_usr_def_fld_6,'')
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_da_cmpl_mon
     SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', ICA_FLOW_LOCAL.dbo.ica_da_cmpl_mon.cmpl_mon_ident),
        data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    ISNULL(src_systm_ident,'')
	  + cmpl_mon_ident
	  + ISNULL(cmpl_mon_acty_type_code,'')
	  + ISNULL(CONVERT(varchar(50), cmpl_mon_date),'')
	  + ISNULL(CONVERT(varchar(50), cmpl_mon_start_date),'')
	  + ISNULL(cmpl_mon_acty_name,'')
	  + ISNULL(multimedia_ind,'')
	  + ISNULL(CONVERT(varchar(50), cmpl_mon_planned_start_date),'')
	  + ISNULL(CONVERT(varchar(50), cmpl_mon_planned_end_date),'')
	  + ISNULL(deficiencies_obs_ind,'')
	  + ISNULL(lead_agncy_code,'')
	  + ISNULL(othr_prog_desc_txt,'')
	  + ISNULL(othr_agncy_initiative_txt,'')
	  + ISNULL(insp_usr_def_fld_1,'')
	  + ISNULL(insp_usr_def_fld_2,'')
	  + ISNULL(insp_usr_def_fld_3,'')
	  + ISNULL(CONVERT(varchar(50), insp_usr_def_fld_4),'')
	  + ISNULL(CONVERT(varchar(50), insp_usr_def_fld_5),'')
	  + ISNULL(insp_usr_def_fld_6,'')
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_da_enfrc_actn_milstn
     SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', ICA_FLOW_LOCAL.dbo.ica_da_enfrc_actn_milstn.da_enfrc_actn_ident + milstn_type_code),
        data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    ISNULL(src_systm_ident,'')
	  + da_enfrc_actn_ident
	  + milstn_type_code
	  + ISNULL(CONVERT(varchar(50), milstn_planned_date),'')
	  + ISNULL(CONVERT(varchar(50), milstn_actual_date),'')
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_da_final_order
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    CONVERT(varchar(50), final_order_ident)
	  + ISNULL(final_order_type_code,'')
	  + ISNULL(CONVERT(varchar(50), final_order_issued_enterd_date),'')
	  + ISNULL(CONVERT(varchar(50), rslvd_date),'')
	  + ISNULL(CONVERT(varchar(50), cash_civil_pnlty_reqd_amt),'')
	  + ISNULL(othr_cmnts,'')
	  + ISNULL(CONVERT(varchar(50), final_order_lodged_date),'')
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_da_frml_enfrc_actn
     SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', ICA_FLOW_LOCAL.dbo.ica_da_frml_enfrc_actn.da_enfrc_actn_ident),
        data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    ISNULL(src_systm_ident,'')
	  + da_enfrc_actn_ident
	  + ISNULL(enfrc_actn_name,'')
	  + ISNULL(forum,'')
	  + ISNULL(resl_type_code,'')
	  + ISNULL(da_comb_sprsed_eaid,'')
	  + ISNULL(rsn_del_rec,'')
	  + ISNULL(frml_ea_usr_def_fld_1,'')
	  + ISNULL(frml_ea_usr_def_fld_2,'')
	  + ISNULL(frml_ea_usr_def_fld_3,'')
	  + ISNULL(CONVERT(varchar(50), frml_ea_usr_def_fld_4),'')
	  + ISNULL(CONVERT(varchar(50), frml_ea_usr_def_fld_5),'')
	  + ISNULL(frml_ea_usr_def_fld_6,'')
	  + ISNULL(lead_agncy_code,'')
	  + ISNULL(enfrc_agncy_name,'')
	  + ISNULL(othr_agncy_initiative_txt,'')
	  + ISNULL(othr_prog_desc_txt,'')
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_da_infrml_enfrc_actn
     SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', ICA_FLOW_LOCAL.dbo.ica_da_infrml_enfrc_actn.da_enfrc_actn_ident),
        data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    ISNULL(src_systm_ident,'')
	  + da_enfrc_actn_ident
	  + ISNULL(enfrc_actn_type_code,'')
	  + ISNULL(enfrc_actn_name,'')
	  + ISNULL(CONVERT(varchar(50), achieved_date),'')
	  + ISNULL(file_num,'')
	  + ISNULL(rsn_del_rec,'')
	  + ISNULL(infrml_ea_usr_def_fld_1,'')
	  + ISNULL(infrml_ea_usr_def_fld_2,'')
	  + ISNULL(infrml_ea_usr_def_fld_3,'')
	  + ISNULL(CONVERT(varchar(50), infrml_ea_usr_def_fld_4),'')
	  + ISNULL(CONVERT(varchar(50), infrml_ea_usr_def_fld_5),'')
	  + ISNULL(infrml_ea_usr_def_fld_6,'')
	  + ISNULL(lead_agncy_code,'')
	  + ISNULL(enfrc_agncy_name,'')
	  + ISNULL(othr_agncy_initiative_txt,'')
	  + ISNULL(st_sects_viol_txt,'')
	  + ISNULL(othr_prog_desc_txt,'')
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_enfrc_actn_cmnt_txt
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    enfrc_actn_cmnt_txt
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_enfrc_actn_gov_cntct
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    affil_type_txt
	  + ISNULL(elec_addr_txt,'')
	  + ISNULL(CONVERT(varchar(50), start_date_of_cntct_assc),'')
	  + ISNULL(CONVERT(varchar(50), end_date_of_cntct_assc),'')
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_enfrc_actn_type
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    enfrc_actn_type_code
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_enfrc_agncy_type
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    enfrc_agncy_type_code
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_fac
     SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', ICA_FLOW_LOCAL.dbo.ica_fac.fac_ident),
        data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    ISNULL(src_systm_ident,'')
	  + fac_ident
	  + ISNULL(fac_site_name,'')
	  + ISNULL(loc_addr_txt,'')
	  + ISNULL(suppl_loc_txt,'')
	  + ISNULL(loc_addr_city_code,'')
	  + ISNULL(loc_st_code,'')
	  + ISNULL(loc_zip_code,'')
	  + ISNULL(lcon_code,'')
	  + ISNULL(tribal_land_code,'')
	  + ISNULL(fac_desc,'')
	  + ISNULL(fac_type_of_owner_code,'')
	  + ISNULL(reg_num,'')
	  + ISNULL(small_busnss_ind,'')
	  + ISNULL(federally_rep_ind,'')
	  + ISNULL(src_unifm_rsrc_locator_url,'')
	  + ISNULL(envr_justice_code,'')
	  + ISNULL(CONVERT(varchar(50), fac_congr_district_num),'')
	  + ISNULL(fac_usr_def_fld_1,'')
	  + ISNULL(fac_usr_def_fld_2,'')
	  + ISNULL(fac_usr_def_fld_3,'')
	  + ISNULL(fac_usr_def_fld_4,'')
	  + ISNULL(fac_usr_def_fld_5,'')
	  + ISNULL(fac_cmnts,'')
	  + ISNULL(port_src_ind,'')
	  + ISNULL(locality_name,'')
	  + ISNULL(loc_addr_county_code,'')


  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_fac_addr
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    affil_type_txt
	  + ISNULL(org_frml_name,'')
	  + ISNULL(org_duns_num,'')
	  + ISNULL(mailing_addr_txt,'')
	  + ISNULL(suppl_addr_txt,'')
	  + ISNULL(mailing_addr_city_name,'')
	  + ISNULL(mailing_addr_st_code,'')
	  + ISNULL(mailing_addr_zip_code,'')
	  + ISNULL(county_name,'')
	  + ISNULL(mailing_addr_country_code,'')
	  + ISNULL(division_name,'')
	  + ISNULL(loc_province,'')
	  + ISNULL(elec_addr_txt,'')
	  + ISNULL(CONVERT(varchar(50), start_date_of_addr_assc),'')
	  + ISNULL(CONVERT(varchar(50), end_date_of_addr_assc),'')
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_fac_ident
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    fac_ident
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_final_order_fac_ident
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    final_order_fac_ident
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_demnd_stipultd_pnlty
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
      ISNULL(CONVERT(varchar(50), demnd_stipultd_pnlty_amt),'')
	  + ISNULL(CONVERT(varchar(50), demnd_stipultd_pnlty_paid_date),'')
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_geo_coord
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    ISNULL(lat_meas,'')
	  + ISNULL(long_meas,'')
	  + ISNULL(CONVERT(varchar(50), horz_accuracy_meas),'')
	  + ISNULL(geom_type_code,'')
	  + ISNULL(horz_coll_method_code,'')
	  + ISNULL(horz_ref_datum_code,'')
	  + ISNULL(ref_point_code,'')
	  + ISNULL(CONVERT(varchar(50), src_map_scale_num),'')
	  + ISNULL(utm_coord_1,'')
	  + ISNULL(utm_coord_2,'')
	  + ISNULL(utm_coord_3,'')
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_infrml_ea_cmnt_txt
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    infrml_ea_cmnt_txt
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_insp_cmnt_txt
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    insp_cmnt_txt
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_insp_gov_cntct
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    affil_type_txt
	  + ISNULL(elec_addr_txt,'')
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_lnk_case_file
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    case_file_ident
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_lnk_cmpl_mon
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    cmpl_mon_ident
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_lnk_da_enfrc_actn
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    da_enfrc_actn_ident
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_method
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    method_code
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_naics_code
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    naics_code
	  + naics_pri_ind_code
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_nat_prio
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    CONVERT(varchar(50), nat_prio_code)
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_othr_pathway_acty
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    othr_pathway_catg_code
	  + othr_pathway_type_code
	  + CONVERT(varchar(50), othr_pathway_date)
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_payload
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    ISNULL(operation,'')
	  + enabled
	  + auto_gen_deletes);

  UPDATE ICA_FLOW_LOCAL.dbo.ica_polut
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    CONVERT(varchar(50), polut_code)
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_polut_da_class
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    polut_da_class_code
	  + ISNULL(CONVERT(varchar(50), polut_da_class_start_date),'')
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_polut_epa_class
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    polut_epa_class_code
	  + ISNULL(CONVERT(varchar(50), polut_epa_class_start_date),'')
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_poluts
     SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', ICA_FLOW_LOCAL.dbo.ica_poluts.fac_ident + CAST(poluts_code AS VARCHAR(255))),
        data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    ISNULL(src_systm_ident,'')
	  + fac_ident
	  + ISNULL(CONVERT(varchar(50), poluts_code),'')
	  + ISNULL(polut_stat_ind,'')
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_port_src
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  --  port_src_ind
	  --+ 
   port_src_site_name
	  + CONVERT(varchar(50), port_src_start_date)
	  + ISNULL(CONVERT(varchar(50), port_src_end_date),'')
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_prog
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    prog_code
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_prog_subpart
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    prog_subpart_code
	  + ISNULL(prog_subpart_stat_ind,'')
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_progs
     SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', ICA_FLOW_LOCAL.dbo.ica_progs.fac_ident + prog_code),
        data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    ISNULL(src_systm_ident,'')
	  + fac_ident
	  + prog_code
	  + ISNULL(othr_prog_desc_txt,'')
	  + prog_oper_stat_code
	  + ISNULL(CONVERT(varchar(50), prog_oper_stat_start_date),'')
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_progs_viol
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    progs_viol_code
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_rgnl_prio
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    CONVERT(varchar(50), rgnl_prio_code)
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_sens_cmnt_txt
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    sens_cmnt_txt
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_sic_code
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    sic_code
	  + sic_pri_ind_code
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_stck_tst
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    stck_tst_stat_code
	  + stck_tst_cndctr_type_code
	  + ISNULL(stck_ident,'')
	  + ISNULL(othr_stck_tst_purpose_name,'')
	  + ISNULL(CONVERT(varchar(50), stck_tst_rep_rcvd_date),'')
	  + ISNULL(CONVERT(varchar(50), tst_rslts_reviewed_date),'')
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_stck_tst_obs_agncy_type
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    stck_tst_obs_agncy_type_code
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_stck_tst_purpose
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    stck_tst_purpose_code
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_teleph
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    teleph_num_type_code
	  + ISNULL(teleph_num,'')
	  + ISNULL(teleph_ext_num,'')
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_tst_rslts
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    CONVERT(varchar(50), tested_polut_code)
	  + ISNULL(tst_result_code,'')
	  + ISNULL(CONVERT(varchar(50), allowable_value),'')
	  + ISNULL(allowable_unit_code,'')
	  + ISNULL(CONVERT(varchar(50), actual_result),'')
	  + ISNULL(failure_rsn_code,'')
	  + ISNULL(othr_failure_rsn_txt,'')
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_tvacc
     SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', ICA_FLOW_LOCAL.dbo.ica_tvacc.cmpl_mon_ident),
        data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    ISNULL(src_systm_ident,'')
	  + cmpl_mon_ident
	  + ISNULL(CONVERT(varchar(50), cmpl_mon_date),'')
	  + ISNULL(CONVERT(varchar(50), cmpl_mon_start_date),'')
	  + ISNULL(cmpl_mon_acty_name,'')
	  + ISNULL(multimedia_ind,'')
	  + ISNULL(CONVERT(varchar(50), cmpl_mon_planned_start_date),'')
	  + ISNULL(CONVERT(varchar(50), cmpl_mon_planned_end_date),'')
	  + ISNULL(deficiencies_obs_ind,'')
	  + fac_ident
	  + ISNULL(lead_agncy_code,'')
	  + ISNULL(othr_prog_desc_txt,'')
	  + ISNULL(othr_agncy_initiative_txt,'')
	  + ISNULL(insp_usr_def_fld_1,'')
	  + ISNULL(insp_usr_def_fld_2,'')
	  + ISNULL(insp_usr_def_fld_3,'')
	  + ISNULL(CONVERT(varchar(50), insp_usr_def_fld_4),'')
	  + ISNULL(CONVERT(varchar(50), insp_usr_def_fld_5),'')
	  + ISNULL(insp_usr_def_fld_6,'')
	  + ISNULL(prmt_ident,'')
	  + ISNULL(CONVERT(varchar(50), cert_period_start_date),'')
	  + ISNULL(CONVERT(varchar(50), cert_period_end_date),'')
	  + ISNULL(fac_rep_cmpl_stat_code,'')
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_tvacc_review
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    CONVERT(varchar(50), tvacc_reviewed_date)
	  + ISNULL(fac_rep_deviations_ind,'')
	  + ISNULL(prmt_conds_txt,'')
	  + ISNULL(exceed_excurs_ind,'')
	  + ISNULL(reviewer_agncy_code,'')
	  + ISNULL(tvacc_reviewer_name,'')
	  + ISNULL(reviewer_cmnt,'')
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_universe_ind
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    universe_ind_code
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_viol
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    viol_type_code
	  + viol_prog_code
	  + ISNULL(viol_prog_desc_txt,'')
	  + ISNULL(CONVERT(varchar(50), viol_polut_code),'')
	  + ISNULL(CONVERT(varchar(50), frv_dtrmn_date),'')
	  + ISNULL(CONVERT(varchar(50), hpv_day_zero_date),'')
	  + ISNULL(CONVERT(varchar(50), occurrence_start_date),'')
	  + ISNULL(CONVERT(varchar(50), occurrence_end_date),'')
	  + ISNULL(hpv_desgn_rmvl_type_code,'')
	  + ISNULL(CONVERT(varchar(50), hpv_desgn_rmvl_date),'')
	  + ISNULL(CONVERT(varchar(50), claims_num),'')
  );

  /* Linkage Tables */
  UPDATE ica_flow_local.dbo.ica_cmpl_mon_lnk
     SET key_hash = dbo.HASHBYTES_VARCHAR( 'SHA1' , 
                                           ISNULL(ica_cmpl_mon_lnk.cmpl_mon_ident,'')
                                         + ISNULL(ica_lnk_cmpl_mon.cmpl_mon_ident,'')
                                         + ISNULL(ica_lnk_da_enfrc_actn.da_enfrc_actn_ident,''))
       , data_hash = dbo.HASHBYTES_VARCHAR( 'SHA1', 
	                                          ISNULL(ica_cmpl_mon_lnk.src_systm_ident,'')
	                                        + ISNULL(ica_cmpl_mon_lnk.cmpl_mon_ident,''))
    FROM ica_cmpl_mon_lnk
    LEFT JOIN ica_lnk_cmpl_mon on ica_lnk_cmpl_mon.ica_cmpl_mon_lnk_id = ica_cmpl_mon_lnk.ica_cmpl_mon_lnk_id
    LEFT JOIN ica_lnk_da_enfrc_actn on ica_lnk_da_enfrc_actn.ica_cmpl_mon_lnk_id = ica_cmpl_mon_lnk.ica_cmpl_mon_lnk_id;

  UPDATE ica_flow_local.dbo.ica_da_enfrc_actn_lnk
     SET key_hash = dbo.HASHBYTES_VARCHAR( 'SHA1' , 
                                           ISNULL(ica_da_enfrc_actn_lnk.da_enfrc_actn_ident,'')
                                         + ISNULL(ica_lnk_da_enfrc_actn.da_enfrc_actn_ident,''))
       , data_hash = dbo.HASHBYTES_VARCHAR( 'SHA1'
                                          , ISNULL(ica_da_enfrc_actn_lnk.src_systm_ident,'')
	                                        + ISNULL(ica_da_enfrc_actn_lnk.da_enfrc_actn_ident,''))
    FROM ica_da_enfrc_actn_lnk
    LEFT JOIN ica_lnk_da_enfrc_actn on ica_lnk_da_enfrc_actn.ica_da_enfrc_actn_lnk_id = ica_da_enfrc_actn_lnk.ica_da_enfrc_actn_lnk_id;

  UPDATE ica_flow_local.dbo.ica_case_file_lnk
     SET key_hash = dbo.HASHBYTES_VARCHAR( 'SHA1' , 
                                           ISNULL(ica_case_file_lnk.case_file_ident,'')
                                         + ISNULL(ica_lnk_case_file.case_file_ident,'')
                                         + ISNULL(ica_lnk_cmpl_mon.cmpl_mon_ident,'')
                                         + ISNULL(ica_lnk_da_enfrc_actn.da_enfrc_actn_ident,''))
       , data_hash = dbo.HASHBYTES_VARCHAR( 'SHA1'
                                          , ISNULL(ica_case_file_lnk.src_systm_ident,'')
	                                        + ISNULL(ica_case_file_lnk.case_file_ident,''))
    FROM ica_case_file_lnk
    LEFT JOIN ica_lnk_case_file on ica_lnk_case_file.ica_case_file_lnk_id = ica_case_file_lnk.ica_case_file_lnk_id
    LEFT JOIN ica_lnk_cmpl_mon on ica_lnk_cmpl_mon.ica_case_file_lnk_id = ica_case_file_lnk.ica_case_file_lnk_id
    LEFT JOIN ica_lnk_da_enfrc_actn on ica_lnk_da_enfrc_actn.ica_case_file_lnk_id = ica_case_file_lnk.ica_case_file_lnk_id;


  /************************************/  
  /* START - Process DATA_HASH values */
  /* START - Process DATA_HASH values */
  /* START - Process DATA_HASH values */
  /************************************/ 
 
  /* Loop through each payload type, for each loop roll child data_hash values up to the parent payload table */  
  OPEN payload_type_process;

  -- Get 1st payload type
  FETCH NEXT FROM payload_type_process INTO @p_payload_type;
  WHILE @@FETCH_STATUS = 0
    BEGIN

      SET @v_sql_statement = 'SELECT TOP 1 @v_enabled_val = [ENABLED] FROM ICA_PAYLOAD JOIN ' + @p_payload_type +
        ' ON ICA_PAYLOAD.ICA_PAYLOAD_ID = ' + @p_payload_type + '.ICA_PAYLOAD_ID'
      SET @v_sql_param = '@v_enabled_val CHAR(1) OUTPUT';

      EXEC sp_executesql @v_sql_statement, @v_sql_param, @v_enabled_val=@v_enabled OUTPUT;

      SET @v_enabled = ISNULL(@v_enabled, 'N');

      /* Flush the prior payload type's key_hash values */
      DELETE FROM ica_key_hash;
      
      /* Load next key_hash set for current payload type */ 
      SET @v_sql_statement = 'INSERT INTO ica_key_hash SELECT key_hash FROM ' + @p_payload_type; 
      EXECUTE sp_executesql @v_sql_statement;
        
     /* 
      *  Loop through each key in a payload type's key set.  For each key traverse the payload type's data heirarchy
      *  and load the child data_hash values into working table ICA_DATA_HASH for later processing at the end of 
      *  the loop.
      */
      OPEN key_hash;

      /*  Fetch 1st payload type */
      FETCH NEXT FROM key_hash INTO @v_key_hash;
      WHILE @@FETCH_STATUS = 0
        BEGIN    

		    /* Flush the prior payload's data_hash values */
		    DELETE FROM ica_data_hash;

     IF @p_payload_type = 'ICA_CMPL_MON_STRGY' and @v_enabled = 'Y'
        BEGIN

        -- /ICA_CMPL_MON_STRGY
        INSERT INTO ica_data_hash
             SELECT ica_cmpl_mon_strgy.data_hash
               FROM ica_cmpl_mon_strgy
              WHERE ica_cmpl_mon_strgy.key_hash = @v_key_hash;

        END;

     IF @p_payload_type = 'ICA_DA_CMPL_MON' and @v_enabled = 'Y'
        BEGIN

        -- /ICA_DA_CMPL_MON
        INSERT INTO ica_data_hash
             SELECT ica_da_cmpl_mon.data_hash
               FROM ica_da_cmpl_mon
              WHERE ica_da_cmpl_mon.key_hash = @v_key_hash;

        -- /ICA_DA_CMPL_MON/ICA_CMPL_INSP_TYPE
        INSERT INTO ica_data_hash
             SELECT ica_cmpl_insp_type.data_hash
               FROM ica_da_cmpl_mon
               JOIN ica_cmpl_insp_type
                 ON ica_cmpl_insp_type.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
              WHERE ica_da_cmpl_mon.key_hash = @v_key_hash;

        -- /ICA_DA_CMPL_MON/ICA_CNTCT
        INSERT INTO ica_data_hash
             SELECT ica_cntct.data_hash
               FROM ica_da_cmpl_mon
               JOIN ica_cntct
                 ON ica_cntct.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
              WHERE ica_da_cmpl_mon.key_hash = @v_key_hash;

        -- /ICA_DA_CMPL_MON/ICA_CNTCT/ICA_TELEPH
        INSERT INTO ica_data_hash
             SELECT ica_teleph.data_hash
               FROM ica_da_cmpl_mon
               JOIN ica_cntct
                 ON ica_cntct.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
               JOIN ica_teleph
                 ON ica_teleph.ica_cntct_id = ica_cntct.ica_cntct_id
              WHERE ica_da_cmpl_mon.key_hash = @v_key_hash;

        -- /ICA_DA_CMPL_MON/ICA_FAC_IDENT
        INSERT INTO ica_data_hash
             SELECT ica_fac_ident.data_hash
               FROM ica_da_cmpl_mon
               JOIN ica_fac_ident
                 ON ica_fac_ident.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
              WHERE ica_da_cmpl_mon.key_hash = @v_key_hash;

        -- /ICA_DA_CMPL_MON/ICA_INSP_CMNT_TXT
        INSERT INTO ica_data_hash
             SELECT ica_insp_cmnt_txt.data_hash
               FROM ica_da_cmpl_mon
               JOIN ica_insp_cmnt_txt
                 ON ica_insp_cmnt_txt.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
              WHERE ica_da_cmpl_mon.key_hash = @v_key_hash;

        -- /ICA_DA_CMPL_MON/ICA_INSP_GOV_CNTCT
        INSERT INTO ica_data_hash
             SELECT ica_insp_gov_cntct.data_hash
               FROM ica_da_cmpl_mon
               JOIN ica_insp_gov_cntct
                 ON ica_insp_gov_cntct.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
              WHERE ica_da_cmpl_mon.key_hash = @v_key_hash;

        -- /ICA_DA_CMPL_MON/ICA_NAT_PRIO
        INSERT INTO ica_data_hash
             SELECT ica_nat_prio.data_hash
               FROM ica_da_cmpl_mon
               JOIN ica_nat_prio
                 ON ica_nat_prio.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
              WHERE ica_da_cmpl_mon.key_hash = @v_key_hash;

        -- /ICA_DA_CMPL_MON/ICA_POLUT
        INSERT INTO ica_data_hash
             SELECT ica_polut.data_hash
               FROM ica_da_cmpl_mon
               JOIN ica_polut
                 ON ica_polut.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
              WHERE ica_da_cmpl_mon.key_hash = @v_key_hash;

        -- /ICA_DA_CMPL_MON/ICA_PROG
        INSERT INTO ica_data_hash
             SELECT ica_prog.data_hash
               FROM ica_da_cmpl_mon
               JOIN ica_prog
                 ON ica_prog.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
              WHERE ica_da_cmpl_mon.key_hash = @v_key_hash;

        -- /ICA_DA_CMPL_MON/ICA_RGNL_PRIO
        INSERT INTO ica_data_hash
             SELECT ica_rgnl_prio.data_hash
               FROM ica_da_cmpl_mon
               JOIN ica_rgnl_prio
                 ON ica_rgnl_prio.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
              WHERE ica_da_cmpl_mon.key_hash = @v_key_hash;

        -- /ICA_DA_CMPL_MON/ICA_SENS_CMNT_TXT
        INSERT INTO ica_data_hash
             SELECT ica_sens_cmnt_txt.data_hash
               FROM ica_da_cmpl_mon
               JOIN ica_sens_cmnt_txt
                 ON ica_sens_cmnt_txt.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
              WHERE ica_da_cmpl_mon.key_hash = @v_key_hash;

        -- /ICA_DA_CMPL_MON/ICA_STCK_TST
        INSERT INTO ica_data_hash
             SELECT ica_stck_tst.data_hash
               FROM ica_da_cmpl_mon
               JOIN ica_stck_tst
                 ON ica_stck_tst.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
              WHERE ica_da_cmpl_mon.key_hash = @v_key_hash;

        -- /ICA_DA_CMPL_MON/ICA_STCK_TST/ICA_STCK_TST_OBS_AGNCY_TYPE
        INSERT INTO ica_data_hash
             SELECT ica_stck_tst_obs_agncy_type.data_hash
               FROM ica_da_cmpl_mon
               JOIN ica_stck_tst
                 ON ica_stck_tst.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
               JOIN ica_stck_tst_obs_agncy_type
                 ON ica_stck_tst_obs_agncy_type.ica_stck_tst_id = ica_stck_tst.ica_stck_tst_id
              WHERE ica_da_cmpl_mon.key_hash = @v_key_hash;

        -- /ICA_DA_CMPL_MON/ICA_STCK_TST/ICA_STCK_TST_PURPOSE
        INSERT INTO ica_data_hash
             SELECT ica_stck_tst_purpose.data_hash
               FROM ica_da_cmpl_mon
               JOIN ica_stck_tst
                 ON ica_stck_tst.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
               JOIN ica_stck_tst_purpose
                 ON ica_stck_tst_purpose.ica_stck_tst_id = ica_stck_tst.ica_stck_tst_id
              WHERE ica_da_cmpl_mon.key_hash = @v_key_hash;

        -- /ICA_DA_CMPL_MON/ICA_STCK_TST/ICA_TST_RSLTS
        INSERT INTO ica_data_hash
             SELECT ica_tst_rslts.data_hash
               FROM ica_da_cmpl_mon
               JOIN ica_stck_tst
                 ON ica_stck_tst.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
               JOIN ica_tst_rslts
                 ON ica_tst_rslts.ica_stck_tst_id = ica_stck_tst.ica_stck_tst_id
              WHERE ica_da_cmpl_mon.key_hash = @v_key_hash;

        -- /ICA_DA_CMPL_MON/ICA_STCK_TST/ICA_TST_RSLTS/ICA_METHOD
        INSERT INTO ica_data_hash
             SELECT ica_method.data_hash
               FROM ica_da_cmpl_mon
               JOIN ica_stck_tst
                 ON ica_stck_tst.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
               JOIN ica_tst_rslts
                 ON ica_tst_rslts.ica_stck_tst_id = ica_stck_tst.ica_stck_tst_id
               JOIN ica_method
                 ON ica_method.ica_tst_rslts_id = ica_tst_rslts.ica_tst_rslts_id
              WHERE ica_da_cmpl_mon.key_hash = @v_key_hash;

        END;

     IF @p_payload_type = 'ICA_DA_ENFRC_ACTN_MILSTN' and @v_enabled = 'Y'
        BEGIN

        -- /ICA_DA_ENFRC_ACTN_MILSTN
        INSERT INTO ica_data_hash
             SELECT ica_da_enfrc_actn_milstn.data_hash
               FROM ica_da_enfrc_actn_milstn
              WHERE ica_da_enfrc_actn_milstn.key_hash = @v_key_hash;

        END;

     IF @p_payload_type = 'ICA_DA_FRML_ENFRC_ACTN' and @v_enabled = 'Y'
        BEGIN

        -- /ICA_DA_FRML_ENFRC_ACTN
        INSERT INTO ica_data_hash
             SELECT ica_da_frml_enfrc_actn.data_hash
               FROM ica_da_frml_enfrc_actn
              WHERE ica_da_frml_enfrc_actn.key_hash = @v_key_hash;

        -- /ICA_DA_FRML_ENFRC_ACTN/ICA_DA_FINAL_ORDER
        INSERT INTO ica_data_hash
             SELECT ica_da_final_order.data_hash
               FROM ica_da_frml_enfrc_actn
               JOIN ica_da_final_order
                 ON ica_da_final_order.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
              WHERE ica_da_frml_enfrc_actn.key_hash = @v_key_hash;

        -- /ICA_DA_FRML_ENFRC_ACTN/ICA_DA_FINAL_ORDER/ICA_FINAL_ORDER_FAC_IDENT
        INSERT INTO ica_data_hash
             SELECT ica_final_order_fac_ident.data_hash
               FROM ica_da_frml_enfrc_actn
               JOIN ica_da_final_order
                 ON ica_da_final_order.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
               JOIN ica_final_order_fac_ident
                 ON ica_final_order_fac_ident.ica_da_final_order_id = ica_da_final_order.ica_da_final_order_id
              WHERE ica_da_frml_enfrc_actn.key_hash = @v_key_hash;

        -- /ICA_DA_FRML_ENFRC_ACTN/ICA_DA_FINAL_ORDER/ICA_DEMND_STIPULTD_PNLTY
        INSERT INTO ica_data_hash
             SELECT ica_demnd_stipultd_pnlty.data_hash
               FROM ica_da_frml_enfrc_actn
               JOIN ica_da_final_order
                 ON ica_da_final_order.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
               JOIN ica_demnd_stipultd_pnlty
                 ON ica_demnd_stipultd_pnlty.ica_da_final_order_id = ica_da_final_order.ica_da_final_order_id
              WHERE ica_da_frml_enfrc_actn.key_hash = @v_key_hash;

        -- /ICA_DA_FRML_ENFRC_ACTN/ICA_ENFRC_ACTN_CMNT_TXT
        INSERT INTO ica_data_hash
             SELECT ica_enfrc_actn_cmnt_txt.data_hash
               FROM ica_da_frml_enfrc_actn
               JOIN ica_enfrc_actn_cmnt_txt
                 ON ica_enfrc_actn_cmnt_txt.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
              WHERE ica_da_frml_enfrc_actn.key_hash = @v_key_hash;

        -- /ICA_DA_FRML_ENFRC_ACTN/ICA_ENFRC_ACTN_GOV_CNTCT
        INSERT INTO ica_data_hash
             SELECT ica_enfrc_actn_gov_cntct.data_hash
               FROM ica_da_frml_enfrc_actn
               JOIN ica_enfrc_actn_gov_cntct
                 ON ica_enfrc_actn_gov_cntct.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
              WHERE ica_da_frml_enfrc_actn.key_hash = @v_key_hash;

        -- /ICA_DA_FRML_ENFRC_ACTN/ICA_ENFRC_ACTN_TYPE
        INSERT INTO ica_data_hash
             SELECT ica_enfrc_actn_type.data_hash
               FROM ica_da_frml_enfrc_actn
               JOIN ica_enfrc_actn_type
                 ON ica_enfrc_actn_type.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
              WHERE ica_da_frml_enfrc_actn.key_hash = @v_key_hash;

        -- /ICA_DA_FRML_ENFRC_ACTN/ICA_ENFRC_AGNCY_TYPE
        INSERT INTO ica_data_hash
             SELECT ica_enfrc_agncy_type.data_hash
               FROM ica_da_frml_enfrc_actn
               JOIN ica_enfrc_agncy_type
                 ON ica_enfrc_agncy_type.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
              WHERE ica_da_frml_enfrc_actn.key_hash = @v_key_hash;

        -- /ICA_DA_FRML_ENFRC_ACTN/ICA_FAC_IDENT
        INSERT INTO ica_data_hash
             SELECT ica_fac_ident.data_hash
               FROM ica_da_frml_enfrc_actn
               JOIN ica_fac_ident
                 ON ica_fac_ident.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
              WHERE ica_da_frml_enfrc_actn.key_hash = @v_key_hash;

        -- /ICA_DA_FRML_ENFRC_ACTN/ICA_POLUT
        INSERT INTO ica_data_hash
             SELECT ica_polut.data_hash
               FROM ica_da_frml_enfrc_actn
               JOIN ica_polut
                 ON ica_polut.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
              WHERE ica_da_frml_enfrc_actn.key_hash = @v_key_hash;

        -- /ICA_DA_FRML_ENFRC_ACTN/ICA_PROGS_VIOL
        INSERT INTO ica_data_hash
             SELECT ica_progs_viol.data_hash
               FROM ica_da_frml_enfrc_actn
               JOIN ica_progs_viol
                 ON ica_progs_viol.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
              WHERE ica_da_frml_enfrc_actn.key_hash = @v_key_hash;

        -- /ICA_DA_FRML_ENFRC_ACTN/ICA_SENS_CMNT_TXT
        INSERT INTO ica_data_hash
             SELECT ica_sens_cmnt_txt.data_hash
               FROM ica_da_frml_enfrc_actn
               JOIN ica_sens_cmnt_txt
                 ON ica_sens_cmnt_txt.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
              WHERE ica_da_frml_enfrc_actn.key_hash = @v_key_hash;

        END;

     IF @p_payload_type = 'ICA_DA_INFRML_ENFRC_ACTN' and @v_enabled = 'Y'
        BEGIN

        -- /ICA_DA_INFRML_ENFRC_ACTN
        INSERT INTO ica_data_hash
             SELECT ica_da_infrml_enfrc_actn.data_hash
               FROM ica_da_infrml_enfrc_actn
              WHERE ica_da_infrml_enfrc_actn.key_hash = @v_key_hash;

        -- /ICA_DA_INFRML_ENFRC_ACTN/ICA_ENFRC_ACTN_GOV_CNTCT
        INSERT INTO ica_data_hash
             SELECT ica_enfrc_actn_gov_cntct.data_hash
               FROM ica_da_infrml_enfrc_actn
               JOIN ica_enfrc_actn_gov_cntct
                 ON ica_enfrc_actn_gov_cntct.ica_da_infrml_enfrc_actn_id = ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
              WHERE ica_da_infrml_enfrc_actn.key_hash = @v_key_hash;

        -- /ICA_DA_INFRML_ENFRC_ACTN/ICA_ENFRC_AGNCY_TYPE
        INSERT INTO ica_data_hash
             SELECT ica_enfrc_agncy_type.data_hash
               FROM ica_da_infrml_enfrc_actn
               JOIN ica_enfrc_agncy_type
                 ON ica_enfrc_agncy_type.ica_da_infrml_enfrc_actn_id = ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
              WHERE ica_da_infrml_enfrc_actn.key_hash = @v_key_hash;

        -- /ICA_DA_INFRML_ENFRC_ACTN/ICA_FAC_IDENT
        INSERT INTO ica_data_hash
             SELECT ica_fac_ident.data_hash
               FROM ica_da_infrml_enfrc_actn
               JOIN ica_fac_ident
                 ON ica_fac_ident.ica_da_infrml_enfrc_actn_id = ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
              WHERE ica_da_infrml_enfrc_actn.key_hash = @v_key_hash;

        -- /ICA_DA_INFRML_ENFRC_ACTN/ICA_INFRML_EA_CMNT_TXT
        INSERT INTO ica_data_hash
             SELECT ica_infrml_ea_cmnt_txt.data_hash
               FROM ica_da_infrml_enfrc_actn
               JOIN ica_infrml_ea_cmnt_txt
                 ON ica_infrml_ea_cmnt_txt.ica_da_infrml_enfrc_actn_id = ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
              WHERE ica_da_infrml_enfrc_actn.key_hash = @v_key_hash;

        -- /ICA_DA_INFRML_ENFRC_ACTN/ICA_POLUT
        INSERT INTO ica_data_hash
             SELECT ica_polut.data_hash
               FROM ica_da_infrml_enfrc_actn
               JOIN ica_polut
                 ON ica_polut.ica_da_infrml_enfrc_actn_id = ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
              WHERE ica_da_infrml_enfrc_actn.key_hash = @v_key_hash;

        -- /ICA_DA_INFRML_ENFRC_ACTN/ICA_PROGS_VIOL
        INSERT INTO ica_data_hash
             SELECT ica_progs_viol.data_hash
               FROM ica_da_infrml_enfrc_actn
               JOIN ica_progs_viol
                 ON ica_progs_viol.ica_da_infrml_enfrc_actn_id = ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
              WHERE ica_da_infrml_enfrc_actn.key_hash = @v_key_hash;

        -- /ICA_DA_INFRML_ENFRC_ACTN/ICA_SENS_CMNT_TXT
        INSERT INTO ica_data_hash
             SELECT ica_sens_cmnt_txt.data_hash
               FROM ica_da_infrml_enfrc_actn
               JOIN ica_sens_cmnt_txt
                 ON ica_sens_cmnt_txt.ica_da_infrml_enfrc_actn_id = ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
              WHERE ica_da_infrml_enfrc_actn.key_hash = @v_key_hash;

        END;

     IF @p_payload_type = 'ICA_FAC' and @v_enabled = 'Y'
        BEGIN

        -- /ICA_FAC
        INSERT INTO ica_data_hash
             SELECT ica_fac.data_hash
               FROM ica_fac
              WHERE ica_fac.key_hash = @v_key_hash;

        -- /ICA_FAC/ICA_CNTCT
        INSERT INTO ica_data_hash
             SELECT ica_cntct.data_hash
               FROM ica_fac
               JOIN ica_cntct
                 ON ica_cntct.ica_fac_id = ica_fac.ica_fac_id
              WHERE ica_fac.key_hash = @v_key_hash;

        -- /ICA_FAC/ICA_CNTCT/ICA_TELEPH
        INSERT INTO ica_data_hash
             SELECT ica_teleph.data_hash
               FROM ica_fac
               JOIN ica_cntct
                 ON ica_cntct.ica_fac_id = ica_fac.ica_fac_id
               JOIN ica_teleph
                 ON ica_teleph.ica_cntct_id = ica_cntct.ica_cntct_id
              WHERE ica_fac.key_hash = @v_key_hash;

        -- /ICA_FAC/ICA_FAC_ADDR
        INSERT INTO ica_data_hash
             SELECT ica_fac_addr.data_hash
               FROM ica_fac
               JOIN ica_fac_addr
                 ON ica_fac_addr.ica_fac_id = ica_fac.ica_fac_id
              WHERE ica_fac.key_hash = @v_key_hash;

        -- /ICA_FAC/ICA_FAC_ADDR/ICA_TELEPH
        INSERT INTO ica_data_hash
             SELECT ica_teleph.data_hash
               FROM ica_fac
               JOIN ica_fac_addr
                 ON ica_fac_addr.ica_fac_id = ica_fac.ica_fac_id
               JOIN ica_teleph
                 ON ica_teleph.ica_fac_addr_id = ica_fac_addr.ica_fac_addr_id
              WHERE ica_fac.key_hash = @v_key_hash;

        -- /ICA_FAC/ICA_GEO_COORD
        INSERT INTO ica_data_hash
             SELECT ica_geo_coord.data_hash
               FROM ica_fac
               JOIN ica_geo_coord
                 ON ica_geo_coord.ica_fac_id = ica_fac.ica_fac_id
              WHERE ica_fac.key_hash = @v_key_hash;

        -- /ICA_FAC/ICA_NAICA_CODE
        INSERT INTO ica_data_hash
             SELECT ica_naics_code.data_hash
               FROM ica_fac
               JOIN ica_naics_code
                 ON ica_naics_code.ica_fac_id = ica_fac.ica_fac_id
              WHERE ica_fac.key_hash = @v_key_hash;

        -- /ICA_FAC/ICA_PORT_SRC
        INSERT INTO ica_data_hash
             SELECT ica_port_src.data_hash
               FROM ica_fac
               JOIN ica_port_src
                 ON ica_port_src.ica_fac_id = ica_fac.ica_fac_id
              WHERE ica_fac.key_hash = @v_key_hash;

        -- /ICA_FAC/ICA_SIC_CODE
        INSERT INTO ica_data_hash
             SELECT ica_sic_code.data_hash
               FROM ica_fac
               JOIN ica_sic_code
                 ON ica_sic_code.ica_fac_id = ica_fac.ica_fac_id
              WHERE ica_fac.key_hash = @v_key_hash;

        -- /ICA_FAC/ICA_UNIVERSE_IND
        INSERT INTO ica_data_hash
             SELECT ica_universe_ind.data_hash
               FROM ica_fac
               JOIN ica_universe_ind
                 ON ica_universe_ind.ica_fac_id = ica_fac.ica_fac_id
              WHERE ica_fac.key_hash = @v_key_hash;

        END;

     IF @p_payload_type = 'ICA_POLUTS' and @v_enabled = 'Y'
        BEGIN

        -- /ICA_POLUTS
        INSERT INTO ica_data_hash
             SELECT ica_poluts.data_hash
               FROM ica_poluts
              WHERE ica_poluts.key_hash = @v_key_hash;

        -- /ICA_POLUTS/ICA_POLUT_DA_CLASS
        INSERT INTO ica_data_hash
             SELECT ica_polut_da_class.data_hash
               FROM ica_poluts
               JOIN ica_polut_da_class
                 ON ica_polut_da_class.ica_poluts_id = ica_poluts.ica_poluts_id
              WHERE ica_poluts.key_hash = @v_key_hash;

        -- /ICA_POLUTS/ICA_POLUT_EPA_CLASS
        INSERT INTO ica_data_hash
             SELECT ica_polut_epa_class.data_hash
               FROM ica_poluts
               JOIN ica_polut_epa_class
                 ON ica_polut_epa_class.ica_poluts_id = ica_poluts.ica_poluts_id
              WHERE ica_poluts.key_hash = @v_key_hash;

        END;

     IF @p_payload_type = 'ICA_PROGS' and @v_enabled = 'Y'
        BEGIN

        -- /ICA_PROGS
        INSERT INTO ica_data_hash
             SELECT ica_progs.data_hash
               FROM ica_progs
              WHERE ica_progs.key_hash = @v_key_hash;

        -- /ICA_PROGS/ICA_PROG_SUBPART
        INSERT INTO ica_data_hash
             SELECT ica_prog_subpart.data_hash
               FROM ica_progs
               JOIN ica_prog_subpart
                 ON ica_prog_subpart.ica_progs_id = ica_progs.ica_progs_id
              WHERE ica_progs.key_hash = @v_key_hash;

        END;

     IF @p_payload_type = 'ICA_TVACC' and @v_enabled = 'Y'
        BEGIN

        -- /ICA_TVACC
        INSERT INTO ica_data_hash
             SELECT ica_tvacc.data_hash
               FROM ica_tvacc
              WHERE ica_tvacc.key_hash = @v_key_hash;

        -- /ICA_TVACC/ICA_CNTCT
        INSERT INTO ica_data_hash
             SELECT ica_cntct.data_hash
               FROM ica_tvacc
               JOIN ica_cntct
                 ON ica_cntct.ica_tvacc_id = ica_tvacc.ica_tvacc_id
              WHERE ica_tvacc.key_hash = @v_key_hash;

        -- /ICA_TVACC/ICA_CNTCT/ICA_TELEPH
        INSERT INTO ica_data_hash
             SELECT ica_teleph.data_hash
               FROM ica_tvacc
               JOIN ica_cntct
                 ON ica_cntct.ica_tvacc_id = ica_tvacc.ica_tvacc_id
               JOIN ica_teleph
                 ON ica_teleph.ica_cntct_id = ica_cntct.ica_cntct_id
              WHERE ica_tvacc.key_hash = @v_key_hash;

        -- /ICA_TVACC/ICA_INSP_CMNT_TXT
        INSERT INTO ica_data_hash
             SELECT ica_insp_cmnt_txt.data_hash
               FROM ica_tvacc
               JOIN ica_insp_cmnt_txt
                 ON ica_insp_cmnt_txt.ica_tvacc_id = ica_tvacc.ica_tvacc_id
              WHERE ica_tvacc.key_hash = @v_key_hash;

        -- /ICA_TVACC/ICA_INSP_GOV_CNTCT
        INSERT INTO ica_data_hash
             SELECT ica_insp_gov_cntct.data_hash
               FROM ica_tvacc
               JOIN ica_insp_gov_cntct
                 ON ica_insp_gov_cntct.ica_tvacc_id = ica_tvacc.ica_tvacc_id
              WHERE ica_tvacc.key_hash = @v_key_hash;

        -- /ICA_TVACC/ICA_NAT_PRIO
        INSERT INTO ica_data_hash
             SELECT ica_nat_prio.data_hash
               FROM ica_tvacc
               JOIN ica_nat_prio
                 ON ica_nat_prio.ica_tvacc_id = ica_tvacc.ica_tvacc_id
              WHERE ica_tvacc.key_hash = @v_key_hash;

        -- /ICA_TVACC/ICA_POLUT
        INSERT INTO ica_data_hash
             SELECT ica_polut.data_hash
               FROM ica_tvacc
               JOIN ica_polut
                 ON ica_polut.ica_tvacc_id = ica_tvacc.ica_tvacc_id
              WHERE ica_tvacc.key_hash = @v_key_hash;

        -- /ICA_TVACC/ICA_PROG
        INSERT INTO ica_data_hash
             SELECT ica_prog.data_hash
               FROM ica_tvacc
               JOIN ica_prog
                 ON ica_prog.ica_tvacc_id = ica_tvacc.ica_tvacc_id
              WHERE ica_tvacc.key_hash = @v_key_hash;

        -- /ICA_TVACC/ICA_RGNL_PRIO
        INSERT INTO ica_data_hash
             SELECT ica_rgnl_prio.data_hash
               FROM ica_tvacc
               JOIN ica_rgnl_prio
                 ON ica_rgnl_prio.ica_tvacc_id = ica_tvacc.ica_tvacc_id
              WHERE ica_tvacc.key_hash = @v_key_hash;

        -- /ICA_TVACC/ICA_SENS_CMNT_TXT
        INSERT INTO ica_data_hash
             SELECT ica_sens_cmnt_txt.data_hash
               FROM ica_tvacc
               JOIN ica_sens_cmnt_txt
                 ON ica_sens_cmnt_txt.ica_tvacc_id = ica_tvacc.ica_tvacc_id
              WHERE ica_tvacc.key_hash = @v_key_hash;

        -- /ICA_TVACC/ICA_TVACC_REVIEW
        INSERT INTO ica_data_hash
             SELECT ica_tvacc_review.data_hash
               FROM ica_tvacc
               JOIN ica_tvacc_review
                 ON ica_tvacc_review.ica_tvacc_id = ica_tvacc.ica_tvacc_id
              WHERE ica_tvacc.key_hash = @v_key_hash;

        END;

     IF @p_payload_type = 'ICA_DA_CASE_FILE' and @v_enabled = 'Y'
        BEGIN

        -- /ICA_DA_CASE_FILE
        INSERT INTO ica_data_hash
             SELECT ica_da_case_file.data_hash
               FROM ica_da_case_file
              WHERE ica_da_case_file.key_hash = @v_key_hash;

        -- /ICA_DA_CASE_FILE/ICA_CASE_FILE_CMNT_TXT
        INSERT INTO ica_data_hash
             SELECT ica_case_file_cmnt_txt.data_hash
               FROM ica_da_case_file
               JOIN ica_case_file_cmnt_txt
                 ON ica_case_file_cmnt_txt.ica_da_case_file_id = ica_da_case_file.ica_da_case_file_id
              WHERE ica_da_case_file.key_hash = @v_key_hash;

        -- /ICA_DA_CASE_FILE/ICA_OTHR_PATHWAY_ACTY
        INSERT INTO ica_data_hash
             SELECT ica_othr_pathway_acty.data_hash
               FROM ica_da_case_file
               JOIN ica_othr_pathway_acty
                 ON ica_othr_pathway_acty.ica_da_case_file_id = ica_da_case_file.ica_da_case_file_id
              WHERE ica_da_case_file.key_hash = @v_key_hash;

        -- /ICA_DA_CASE_FILE/ICA_POLUT
        INSERT INTO ica_data_hash
             SELECT ica_polut.data_hash
               FROM ica_da_case_file
               JOIN ica_polut
                 ON ica_polut.ica_da_case_file_id = ica_da_case_file.ica_da_case_file_id
              WHERE ica_da_case_file.key_hash = @v_key_hash;

        -- /ICA_DA_CASE_FILE/ICA_PROG
        INSERT INTO ica_data_hash
             SELECT ica_prog.data_hash
               FROM ica_da_case_file
               JOIN ica_prog
                 ON ica_prog.ica_da_case_file_id = ica_da_case_file.ica_da_case_file_id
              WHERE ica_da_case_file.key_hash = @v_key_hash;

        -- /ICA_DA_CASE_FILE/ICA_SENS_CMNT_TXT
        INSERT INTO ica_data_hash
             SELECT ica_sens_cmnt_txt.data_hash
               FROM ica_da_case_file
               JOIN ica_sens_cmnt_txt
                 ON ica_sens_cmnt_txt.ica_da_case_file_id = ica_da_case_file.ica_da_case_file_id
              WHERE ica_da_case_file.key_hash = @v_key_hash;

        -- /ICA_DA_CASE_FILE/ICA_VIOL
        INSERT INTO ica_data_hash
             SELECT ica_viol.data_hash
               FROM ica_da_case_file
               JOIN ica_viol
                 ON ica_viol.ica_da_case_file_id = ica_da_case_file.ica_da_case_file_id
              WHERE ica_da_case_file.key_hash = @v_key_hash;

        END;

     IF @p_payload_type = 'ICA_DA_ENFRC_ACTN_LNK' and @v_enabled = 'Y'
        BEGIN

        -- /ICA_DA_ENFRC_ACTN_LNK
        INSERT INTO ica_data_hash
             SELECT ica_da_enfrc_actn_lnk.data_hash
               FROM ica_da_enfrc_actn_lnk
              WHERE ica_da_enfrc_actn_lnk.key_hash = @v_key_hash;

        -- /ICA_DA_ENFRC_ACTN_LNK/ICA_LNK_DA_ENFRC_ACTN
        INSERT INTO ica_data_hash
             SELECT ica_lnk_da_enfrc_actn.data_hash
               FROM ica_da_enfrc_actn_lnk
               JOIN ica_lnk_da_enfrc_actn
                 ON ica_lnk_da_enfrc_actn.ica_da_enfrc_actn_lnk_id = ica_da_enfrc_actn_lnk.ica_da_enfrc_actn_lnk_id
              WHERE ica_da_enfrc_actn_lnk.key_hash = @v_key_hash;

        END;

     IF @p_payload_type = 'ICA_CASE_FILE_LNK' and @v_enabled = 'Y'
        BEGIN

        -- /ICA_CASE_FILE_LNK
        INSERT INTO ica_data_hash
             SELECT ica_case_file_lnk.data_hash
               FROM ica_case_file_lnk
              WHERE ica_case_file_lnk.key_hash = @v_key_hash;

        -- /ICA_CASE_FILE_LNK/ICA_LNK_CASE_FILE
        INSERT INTO ica_data_hash
             SELECT ica_lnk_case_file.data_hash
               FROM ica_case_file_lnk
               JOIN ica_lnk_case_file
                 ON ica_lnk_case_file.ica_case_file_lnk_id = ica_case_file_lnk.ica_case_file_lnk_id
              WHERE ica_case_file_lnk.key_hash = @v_key_hash;

        -- /ICA_CASE_FILE_LNK/ICA_LNK_CMPL_MON
        INSERT INTO ica_data_hash
             SELECT ica_lnk_cmpl_mon.data_hash
               FROM ica_case_file_lnk
               JOIN ica_lnk_cmpl_mon
                 ON ica_lnk_cmpl_mon.ica_case_file_lnk_id = ica_case_file_lnk.ica_case_file_lnk_id
              WHERE ica_case_file_lnk.key_hash = @v_key_hash;

        -- /ICA_CASE_FILE_LNK/ICA_LNK_DA_ENFRC_ACTN
        INSERT INTO ica_data_hash
             SELECT ica_lnk_da_enfrc_actn.data_hash
               FROM ica_case_file_lnk
               JOIN ica_lnk_da_enfrc_actn
                 ON ica_lnk_da_enfrc_actn.ica_case_file_lnk_id = ica_case_file_lnk.ica_case_file_lnk_id
              WHERE ica_case_file_lnk.key_hash = @v_key_hash;

        END;

     IF @p_payload_type = 'ICA_CMPL_MON_LNK' and @v_enabled = 'Y'
        BEGIN

        -- /ICA_CMPL_MON_LNK
        INSERT INTO ica_data_hash
             SELECT ica_cmpl_mon_lnk.data_hash
               FROM ica_cmpl_mon_lnk
              WHERE ica_cmpl_mon_lnk.key_hash = @v_key_hash;

        -- /ICA_CMPL_MON_LNK/ICA_LNK_CMPL_MON
        INSERT INTO ica_data_hash
             SELECT ica_lnk_cmpl_mon.data_hash
               FROM ica_cmpl_mon_lnk
               JOIN ica_lnk_cmpl_mon
                 ON ica_lnk_cmpl_mon.ica_cmpl_mon_lnk_id = ica_cmpl_mon_lnk.ica_cmpl_mon_lnk_id
              WHERE ica_cmpl_mon_lnk.key_hash = @v_key_hash;

        -- /ICA_CMPL_MON_LNK/ICA_LNK_DA_ENFRC_ACTN
        INSERT INTO ica_data_hash
             SELECT ica_lnk_da_enfrc_actn.data_hash
               FROM ica_cmpl_mon_lnk
               JOIN ica_lnk_da_enfrc_actn
                 ON ica_lnk_da_enfrc_actn.ica_cmpl_mon_lnk_id = ica_cmpl_mon_lnk.ica_cmpl_mon_lnk_id
              WHERE ica_cmpl_mon_lnk.key_hash = @v_key_hash;

        END;




     /*  
      *  Loop through each data_hash value loaded into ICA_DATA_HASH, for each, rehash each data_hash values together to create 
      *  a single data_hash value that represents all the non-key data contained within a payload type / key_hash combination.
      */
		  SET @v_all_data_hashes = NULL;
      OPEN data_hash;

      -- Get 1st payload type
      FETCH NEXT FROM data_hash INTO @v_data_hash;
      WHILE @@FETCH_STATUS = 0
        BEGIN      
            
        /* Append each data hash together into one string value.. */
        SELECT @v_all_data_hashes = dbo.HASHBYTES_VARCHAR('SHA1', COALESCE(@v_all_data_hashes,'#') + @v_data_hash);
        FETCH NEXT FROM data_hash INTO @v_data_hash;

      END; -- data_loop;

    /*  Close the data_hash cursor */
    CLOSE data_hash;
            
          /*  Hash the entire set of data_hash values organized into a single string. */
		  SET @v_hashed_data_hashes = NULL;
          SELECT @v_hashed_data_hashes = @v_all_data_hashes;      
                     
                     
          /*  Load the rehashed value into the payload type table's data_hash column. */
          SET @v_sql_statement = ' UPDATE ' + @p_payload_type + 
                                 '    SET ' + 'data_hash = ' + '''' + @v_hashed_data_hashes +  '''' + 
                                 '  WHERE key_hash = ' + '''' + @v_key_hash + '''';

          EXECUTE sp_executesql @v_sql_statement;                      
          
          /* Get next key_hash value...  */
          FETCH NEXT FROM key_hash INTO @v_key_hash;
                  
        END; -- key_loop   
       
      /*  Close the key_hash cursor */
      CLOSE key_hash;

      /*  Get the next payload type. */
      FETCH NEXT FROM payload_type_process 
      INTO @p_payload_type;
      
    END; -- payload_t--END LOOP module_loop;

  /*  Close payload type cursor */
  CLOSE payload_type_process;
  
  /*  Destroy the payload type cursor */
  DEALLOCATE payload_type_delete;  
  DEALLOCATE payload_type_process;  
  DEALLOCATE data_hash;
  DEALLOCATE key_hash;  
  
  
  /******************************************************************************************************************************
  ** Description:  The following code sets the new, change, replace, etc... ics transaction_type flags throughout the entire ICS 
  **               schema.  Once these flags are set the data will be marked as either new, changed and will allow the OPENNODE2 
  **               plug-in the ability to pull the data, bundle into .xml, and then submit to an exchange partner.
  ******************************************************************************************************************************/
  -- Generates SQL INSERT and UPDATE Statements to set TransactionCode values based on changes to staged data
-- Date Generated: Monday, July 09, 2012

-- Generates SQL INSERT and UPDATE Statements to set TransactionCode values based on changes to staged data
-- Date Generated: Wednesday, July 16, 2014

     -- ICA_CMPL_MON_STRGY - Set New/Replace Transactions
     UPDATE ica_cmpl_mon_strgy
        SET ica_cmpl_mon_strgy.transaction_type = (SELECT CASE cdv_cmpl_mon_strgy.action_code
                                                          WHEN 1 THEN 'R'
                                                          WHEN 2 THEN 'R'
                                                         END AS transaction_type
                                                   FROM cdv_cmpl_mon_strgy
                                                  WHERE cdv_cmpl_mon_strgy.key_hash = ica_cmpl_mon_strgy.key_hash
                                                    AND (SELECT COUNT(1) FROM ica_payload WHERE operation = 'AirComplianceMonitoringStrategySubmission' AND enabled = 'Y') = 1);

     -- ICA_DA_CMPL_MON - Set New/Replace Transactions
     UPDATE ica_da_cmpl_mon
        SET ica_da_cmpl_mon.transaction_type = (SELECT CASE cdv_da_cmpl_mon.action_code
                                                          WHEN 1 THEN 'R'
                                                          WHEN 2 THEN 'R'
                                                         END AS transaction_type
                                                   FROM cdv_da_cmpl_mon
                                                  WHERE cdv_da_cmpl_mon.key_hash = ica_da_cmpl_mon.key_hash
                                                    AND (SELECT COUNT(1) FROM ica_payload WHERE operation = 'AirDAComplianceMonitoringSubmission' AND enabled = 'Y') = 1);

     -- ICA_DA_ENFRC_ACTN_MILSTN - Set New/Replace Transactions
     UPDATE ica_da_enfrc_actn_milstn
        SET ica_da_enfrc_actn_milstn.transaction_type = (SELECT CASE cdv_da_enfrc_actn_milstn.action_code
                                                          WHEN 1 THEN 'R'
                                                          WHEN 2 THEN 'R'
                                                         END AS transaction_type
                                                   FROM cdv_da_enfrc_actn_milstn
                                                  WHERE cdv_da_enfrc_actn_milstn.key_hash = ica_da_enfrc_actn_milstn.key_hash
                                                    AND (SELECT COUNT(1) FROM ica_payload WHERE operation = 'AirDAEnforcementActionMilestoneSubmission' AND enabled = 'Y') = 1);

     -- ICA_DA_FRML_ENFRC_ACTN - Set New/Replace Transactions
     UPDATE ica_da_frml_enfrc_actn
        SET ica_da_frml_enfrc_actn.transaction_type = (SELECT CASE cdv_da_frml_enfrc_actn.action_code
                                                          WHEN 1 THEN 'R'
                                                          WHEN 2 THEN 'R'
                                                         END AS transaction_type
                                                   FROM cdv_da_frml_enfrc_actn
                                                  WHERE cdv_da_frml_enfrc_actn.key_hash = ica_da_frml_enfrc_actn.key_hash
                                                    AND (SELECT COUNT(1) FROM ica_payload WHERE operation = 'AirDAFormalEnforcementActionSubmission' AND enabled = 'Y') = 1);

     -- ICA_DA_INFRML_ENFRC_ACTN - Set New/Replace Transactions
     UPDATE ica_da_infrml_enfrc_actn
        SET ica_da_infrml_enfrc_actn.transaction_type = (SELECT CASE cdv_da_infrml_enfrc_actn.action_code
                                                          WHEN 1 THEN 'R'
                                                          WHEN 2 THEN 'R'
                                                         END AS transaction_type
                                                   FROM cdv_da_infrml_enfrc_actn
                                                  WHERE cdv_da_infrml_enfrc_actn.key_hash = ica_da_infrml_enfrc_actn.key_hash
                                                    AND (SELECT COUNT(1) FROM ica_payload WHERE operation = 'AirDAInformalEnforcementActionSubmission' AND enabled = 'Y') = 1);

     -- ICA_FAC - Set New/Replace Transactions
     UPDATE ica_fac
        SET ica_fac.transaction_type = (SELECT CASE cdv_fac.action_code
                                                          WHEN 1 THEN 'R'
                                                          WHEN 2 THEN 'R'
                                                         END AS transaction_type
                                                   FROM cdv_fac
                                                  WHERE cdv_fac.key_hash = ica_fac.key_hash
                                                    AND (SELECT COUNT(1) FROM ica_payload WHERE operation = 'AirFacilitySubmission' AND enabled = 'Y') = 1);

     -- ICA_POLUTS - Set New/Replace Transactions
     UPDATE ica_poluts
        SET ica_poluts.transaction_type = (SELECT CASE cdv_poluts.action_code
                                                          WHEN 1 THEN 'R'
                                                          WHEN 2 THEN 'R'
                                                         END AS transaction_type
                                                   FROM cdv_poluts
                                                  WHERE cdv_poluts.key_hash = ica_poluts.key_hash
                                                    AND (SELECT COUNT(1) FROM ica_payload WHERE operation = 'AirPollutantsSubmission' AND enabled = 'Y') = 1);

     -- ICA_PROGS - Set New/Replace Transactions
     UPDATE ica_progs
        SET ica_progs.transaction_type = (SELECT CASE cdv_progs.action_code
                                                          WHEN 1 THEN 'R'
                                                          WHEN 2 THEN 'R'
                                                         END AS transaction_type
                                                   FROM cdv_progs
                                                  WHERE cdv_progs.key_hash = ica_progs.key_hash
                                                    AND (SELECT COUNT(1) FROM ica_payload WHERE operation = 'AirProgramsSubmission' AND enabled = 'Y') = 1);

     -- ICA_TVACC - Set New/Replace Transactions
     UPDATE ica_tvacc
        SET ica_tvacc.transaction_type = (SELECT CASE cdv_tvacc.action_code
                                                          WHEN 1 THEN 'R'
                                                          WHEN 2 THEN 'R'
                                                         END AS transaction_type
                                                   FROM cdv_tvacc
                                                  WHERE cdv_tvacc.key_hash = ica_tvacc.key_hash
                                                    AND (SELECT COUNT(1) FROM ica_payload WHERE operation = 'AirTVACCSubmission' AND enabled = 'Y') = 1);

     -- ICA_DA_CASE_FILE - Set New/Replace Transactions
     UPDATE ica_da_case_file
        SET ica_da_case_file.transaction_type = (SELECT CASE cdv_da_case_file.action_code
                                                          WHEN 1 THEN 'R'
                                                          WHEN 2 THEN 'R'
                                                         END AS transaction_type
                                                   FROM cdv_da_case_file
                                                  WHERE cdv_da_case_file.key_hash = ica_da_case_file.key_hash
                                                    AND (SELECT COUNT(1) FROM ica_payload WHERE operation = 'AirDACaseFileSubmission' AND enabled = 'Y') = 1);

     -- ICA_DA_ENFRC_ACTN_LNK - Set New/Replace Transactions
     UPDATE ica_da_enfrc_actn_lnk
        SET ica_da_enfrc_actn_lnk.transaction_type = (SELECT CASE cdv_da_enfrc_actn_lnk.action_code
                                                          WHEN 1 THEN 'R'
                                                          WHEN 2 THEN 'R'
                                                         END AS transaction_type
                                                   FROM cdv_da_enfrc_actn_lnk
                                                  WHERE cdv_da_enfrc_actn_lnk.key_hash = ica_da_enfrc_actn_lnk.key_hash
                                                    AND (SELECT COUNT(1) FROM ica_payload WHERE operation = 'AirDAEnforcementActionLinkageSubmission' AND enabled = 'Y') = 1);

     -- ICA_CASE_FILE_LNK - Set New/Replace Transactions
     UPDATE ica_case_file_lnk
        SET ica_case_file_lnk.transaction_type = (SELECT CASE cdv_case_file_lnk.action_code
                                                          WHEN 1 THEN 'R'
                                                          WHEN 2 THEN 'R'
                                                         END AS transaction_type
                                                   FROM cdv_case_file_lnk
                                                  WHERE cdv_case_file_lnk.key_hash = ica_case_file_lnk.key_hash
                                                    AND (SELECT COUNT(1) FROM ica_payload WHERE operation = 'CaseFileLinkageSubmission' AND enabled = 'Y') = 1);

     -- ICA_CMPL_MON_LNK - Set New/Replace Transactions
     UPDATE ica_cmpl_mon_lnk
        SET ica_cmpl_mon_lnk.transaction_type = (SELECT CASE cdv_cmpl_mon_lnk.action_code
                                                          WHEN 1 THEN 'R'
                                                          WHEN 2 THEN 'R'
                                                         END AS transaction_type
                                                   FROM cdv_cmpl_mon_lnk
                                                  WHERE cdv_cmpl_mon_lnk.key_hash = ica_cmpl_mon_lnk.key_hash
                                                    AND (SELECT COUNT(1) FROM ica_payload WHERE operation = 'ComplianceMonitoringLinkageSubmission' AND enabled = 'Y') = 1);

     -- ICA_CMPL_MON_STRGY - Set Delete Transactions
     INSERT INTO ica_cmpl_mon_strgy
          ( ica_payload_id
          , ica_cmpl_mon_strgy_id
          , transaction_type
          , fac_ident) 
      SELECT ica_cmpl_mon_strgy.ica_payload_id
           , ica_cmpl_mon_strgy.ica_cmpl_mon_strgy_id
           , 'X' AS transaction_type
           , fac_ident
        FROM ica_flow_icis.dbo.ica_cmpl_mon_strgy
       WHERE ica_cmpl_mon_strgy.ica_payload_id in (SELECT ica_payload_id 
                              FROM ica_payload 
                             WHERE operation = 'AirComplianceMonitoringStrategySubmission'
                               AND auto_gen_deletes = 'Y')
         AND ica_cmpl_mon_strgy.key_hash IN (SELECT key_hash
                                           FROM cdv_cmpl_mon_strgy
                                          WHERE cdv_cmpl_mon_strgy.action_type = 'DELETE');

     -- ICA_DA_CMPL_MON - Set Delete Transactions
     INSERT INTO ica_da_cmpl_mon
          ( ica_payload_id
          , ica_da_cmpl_mon_id
          , transaction_type
          , cmpl_mon_ident) 
      SELECT ica_da_cmpl_mon.ica_payload_id
           , ica_da_cmpl_mon.ica_da_cmpl_mon_id
           , 'X' AS transaction_type
           , cmpl_mon_ident
        FROM ica_flow_icis.dbo.ica_da_cmpl_mon
       WHERE ica_da_cmpl_mon.ica_payload_id in (SELECT ica_payload_id 
                              FROM ica_payload 
                             WHERE operation = 'AirDAComplianceMonitoringSubmission'
                               AND auto_gen_deletes = 'Y')
         AND ica_da_cmpl_mon.key_hash IN (SELECT key_hash
                                           FROM cdv_da_cmpl_mon
                                          WHERE cdv_da_cmpl_mon.action_type = 'DELETE');

     -- ICA_DA_ENFRC_ACTN_MILSTN - Set Delete Transactions
     INSERT INTO ica_da_enfrc_actn_milstn
          ( ica_payload_id
          , ica_da_enfrc_actn_milstn_id
          , transaction_type
          , da_enfrc_actn_ident, milstn_type_code) 
      SELECT ica_da_enfrc_actn_milstn.ica_payload_id
           , ica_da_enfrc_actn_milstn.ica_da_enfrc_actn_milstn_id
           , 'X' AS transaction_type
           , da_enfrc_actn_ident, milstn_type_code
        FROM ica_flow_icis.dbo.ica_da_enfrc_actn_milstn
       WHERE ica_da_enfrc_actn_milstn.ica_payload_id in (SELECT ica_payload_id 
                              FROM ica_payload 
                             WHERE operation = 'AirDAEnforcementActionMilestoneSubmission'
                               AND auto_gen_deletes = 'Y')
         AND ica_da_enfrc_actn_milstn.key_hash IN (SELECT key_hash
                                           FROM cdv_da_enfrc_actn_milstn
                                          WHERE cdv_da_enfrc_actn_milstn.action_type = 'DELETE');

     -- ICA_DA_FRML_ENFRC_ACTN - Set Delete Transactions
     INSERT INTO ica_da_frml_enfrc_actn
          ( ica_payload_id
          , ica_da_frml_enfrc_actn_id
          , transaction_type
          , da_enfrc_actn_ident) 
      SELECT ica_da_frml_enfrc_actn.ica_payload_id
           , ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
           , 'X' AS transaction_type
           , da_enfrc_actn_ident
        FROM ica_flow_icis.dbo.ica_da_frml_enfrc_actn
       WHERE ica_da_frml_enfrc_actn.ica_payload_id in (SELECT ica_payload_id 
                              FROM ica_payload 
                             WHERE operation = 'AirDAFormalEnforcementActionSubmission'
                               AND auto_gen_deletes = 'Y')
         AND ica_da_frml_enfrc_actn.key_hash IN (SELECT key_hash
                                           FROM cdv_da_frml_enfrc_actn
                                          WHERE cdv_da_frml_enfrc_actn.action_type = 'DELETE');

     -- ICA_DA_INFRML_ENFRC_ACTN - Set Delete Transactions
     INSERT INTO ica_da_infrml_enfrc_actn
          ( ica_payload_id
          , ica_da_infrml_enfrc_actn_id
          , transaction_type
          , da_enfrc_actn_ident) 
      SELECT ica_da_infrml_enfrc_actn.ica_payload_id
           , ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
           , 'X' AS transaction_type
           , da_enfrc_actn_ident
        FROM ica_flow_icis.dbo.ica_da_infrml_enfrc_actn
       WHERE ica_da_infrml_enfrc_actn.ica_payload_id in (SELECT ica_payload_id 
                              FROM ica_payload 
                             WHERE operation = 'AirDAInformalEnforcementActionSubmission'
                               AND auto_gen_deletes = 'Y')
         AND ica_da_infrml_enfrc_actn.key_hash IN (SELECT key_hash
                                           FROM cdv_da_infrml_enfrc_actn
                                          WHERE cdv_da_infrml_enfrc_actn.action_type = 'DELETE');

     -- ICA_FAC - Set Delete Transactions
     INSERT INTO ica_fac
          ( ica_payload_id
          , ica_fac_id
          , transaction_type
          , fac_ident) 
      SELECT ica_fac.ica_payload_id
           , ica_fac.ica_fac_id
           , 'X' AS transaction_type
           , fac_ident
        FROM ica_flow_icis.dbo.ica_fac
       WHERE ica_fac.ica_payload_id in (SELECT ica_payload_id 
                              FROM ica_payload 
                             WHERE operation = 'AirFacilitySubmission'
                               AND auto_gen_deletes = 'Y')
         AND ica_fac.key_hash IN (SELECT key_hash
                                           FROM cdv_fac
                                          WHERE cdv_fac.action_type = 'DELETE');

     -- ICA_POLUTS - Set Delete Transactions
     INSERT INTO ica_poluts
          ( ica_payload_id
          , ica_poluts_id
          , transaction_type
          , fac_ident, poluts_code) 
      SELECT ica_poluts.ica_payload_id
           , ica_poluts.ica_poluts_id
           , 'X' AS transaction_type
           , fac_ident, poluts_code
        FROM ica_flow_icis.dbo.ica_poluts
       WHERE ica_poluts.ica_payload_id in (SELECT ica_payload_id 
                              FROM ica_payload 
                             WHERE operation = 'AirPollutantsSubmission'
                               AND auto_gen_deletes = 'Y')
         AND ica_poluts.key_hash IN (SELECT key_hash
                                           FROM cdv_poluts
                                          WHERE cdv_poluts.action_type = 'DELETE');

     -- ICA_PROGS - Set Delete Transactions
     INSERT INTO ica_progs
          ( ica_payload_id
          , ica_progs_id
          , transaction_type
          , fac_ident
          , prog_code
          , prog_oper_stat_code) 
      SELECT ica_progs.ica_payload_id
           , ica_progs.ica_progs_id
           , 'X' AS transaction_type
           , fac_ident
           , prog_code
           , prog_oper_stat_code
        FROM ica_flow_icis.dbo.ica_progs
       WHERE ica_progs.ica_payload_id in (SELECT ica_payload_id 
                              FROM ica_payload 
                             WHERE operation = 'AirProgramsSubmission'
                               AND auto_gen_deletes = 'Y')
         AND ica_progs.key_hash IN (SELECT key_hash
                                           FROM cdv_progs
                                          WHERE cdv_progs.action_type = 'DELETE');

     -- ICA_TVACC - Set Delete Transactions
     INSERT INTO ica_tvacc
          ( ica_payload_id
          , ica_tvacc_id
          , transaction_type
          , cmpl_mon_ident
          , fac_ident) 
      SELECT ica_tvacc.ica_payload_id
           , ica_tvacc.ica_tvacc_id
           , 'X' AS transaction_type
           , cmpl_mon_ident
           , fac_ident
        FROM ica_flow_icis.dbo.ica_tvacc
       WHERE ica_tvacc.ica_payload_id in (SELECT ica_payload_id 
                              FROM ica_payload 
                             WHERE operation = 'AirTVACCSubmission'
                               AND auto_gen_deletes = 'Y')
         AND ica_tvacc.key_hash IN (SELECT key_hash
                                           FROM cdv_tvacc
                                          WHERE cdv_tvacc.action_type = 'DELETE');

     -- ICA_DA_CASE_FILE - Set Delete Transactions
     INSERT INTO ica_da_case_file
          ( ica_payload_id
          , ica_da_case_file_id
          , transaction_type
          , case_file_ident
          , fac_ident) 
      SELECT ica_da_case_file.ica_payload_id
           , ica_da_case_file.ica_da_case_file_id
           , 'X' AS transaction_type
           , case_file_ident
           , fac_ident
        FROM ica_flow_icis.dbo.ica_da_case_file
       WHERE ica_da_case_file.ica_payload_id in (SELECT ica_payload_id 
                              FROM ica_payload 
                             WHERE operation = 'AirDACaseFileSubmission'
                               AND auto_gen_deletes = 'Y')
         AND ica_da_case_file.key_hash IN (SELECT key_hash
                                           FROM cdv_da_case_file
                                          WHERE cdv_da_case_file.action_type = 'DELETE');


  /* **********************************************
   * ICA_CASE_FILE_LNK:  Set Delete Transactions
   * **********************************************/
	 DECLARE @tbl_case_file_lnk_id TABLE ( icis_case_file_lnk_id uniqueidentifier
	                                     , local_case_file_lnk_id uniqueidentifier);
	 
	 INSERT INTO @tbl_case_file_lnk_id
   SELECT DISTINCT 
          ica_case_file_lnk.ica_case_file_lnk_id AS icis_case_file_lnk_id
        , NEWID() AS local_case_file_lnk_id
     FROM ica_flow_icis.dbo.ica_case_file_lnk
    WHERE ica_case_file_lnk.key_hash IN (SELECT DISTINCT 
                                                key_hash 
                                           FROM cdv_case_file_lnk
                                          WHERE action_type = 'DELETE');   
        
                                      
      /*  
       *  ICA_CASE_FILE_LNK
       */       
       INSERT INTO ica_case_file_lnk
            ( ica_case_file_lnk_id
            , ica_payload_id
            , transaction_type
            , transaction_timestamp
            , src_systm_ident
            , case_file_ident
            , key_hash
            , data_hash)
       SELECT v_cfl.local_case_file_lnk_id AS ica_case_file_lnk_id
            , (SELECT ica_payload_id
                 FROM ica_payload 
               WHERE operation = 'CaseFileLinkageSubmission') AS ica_payload_id
            , 'X' AS transaction_type
            , ica_case_file_lnk.transaction_timestamp AS transaction_timestamp
            , ica_case_file_lnk.src_systm_ident AS src_systm_ident
            , ica_case_file_lnk.case_file_ident AS case_file_ident
            , NULL AS key_hash
            , NULL AS data_hash
         FROM ica_flow_icis.dbo.ica_case_file_lnk
         JOIN @tbl_case_file_lnk_id AS v_cfl
           ON v_cfl.icis_case_file_lnk_id = ica_case_file_lnk.ica_case_file_lnk_id;


      /*  
       *  ICA_LNK_CASE_FILE
       */       
       INSERT INTO ica_lnk_case_file 
            ( ica_lnk_case_file_id
            , ica_case_file_lnk_id
            , case_file_ident
            , data_hash)
       SELECT NEWID() AS ica_lnk_case_file_id
            , v_cfl.local_case_file_lnk_id AS ica_case_file_lnk_id
            , ica_lnk_case_file.case_file_ident
            , ica_lnk_case_file.data_hash
         FROM ica_flow_icis.dbo.ica_lnk_case_file
         JOIN @tbl_case_file_lnk_id AS v_cfl
           ON v_cfl.icis_case_file_lnk_id = ica_lnk_case_file.ica_case_file_lnk_id;
            
            
      /*  
       *  ICA_LNK_CMPL_MON
       */       
       INSERT INTO ica_lnk_cmpl_mon
            ( ica_lnk_cmpl_mon_id
            , ica_cmpl_mon_lnk_id
            , ica_case_file_lnk_id
            , cmpl_mon_ident
            , data_hash)
       SELECT NEWID() AS ica_lnk_cmpl_mon_id
            , NULL AS ica_cmpl_mon_lnk_id
            , v_cfl.local_case_file_lnk_id AS ica_case_file_lnk_id
            , ica_lnk_cmpl_mon.cmpl_mon_ident
            , ica_lnk_cmpl_mon.data_hash
         FROM ica_flow_icis.dbo.ica_lnk_cmpl_mon
         JOIN @tbl_case_file_lnk_id AS v_cfl
           ON v_cfl.icis_case_file_lnk_id = ica_lnk_cmpl_mon.ica_case_file_lnk_id;
            
            
      /*  
       *  ICA_LNK_DA_ENFRC_ACTN
       */       
       INSERT INTO ica_lnk_da_enfrc_actn
            ( ica_lnk_da_enfrc_actn_id
            , ica_cmpl_mon_lnk_id
            , ica_case_file_lnk_id
            , ica_da_enfrc_actn_lnk_id
            , da_enfrc_actn_ident
            , data_hash)
       SELECT NEWID() AS ica_lnk_da_enfrc_actn_id
            , NULL AS ica_cmpl_mon_lnk_id
            , v_cfl.local_case_file_lnk_id AS ica_case_file_lnk_id
            , NULL AS ica_da_enfrc_actn_lnk_id
            , ica_lnk_da_enfrc_actn.da_enfrc_actn_ident
            , ica_lnk_da_enfrc_actn.data_hash
         FROM ica_flow_icis.dbo.ica_lnk_da_enfrc_actn
         JOIN @tbl_case_file_lnk_id AS v_cfl
           ON v_cfl.icis_case_file_lnk_id = ica_lnk_da_enfrc_actn.ica_case_file_lnk_id;
        
      
  /* **********************************************
   * ICA_CMPL_MON_LNK:  Set Delete Transactions
   * **********************************************/
	 DECLARE @tbl_cmpl_mon_lnk_id TABLE ( icis_cmpl_mon_lnk_id uniqueidentifier
	                                    , local_cmpl_mon_lnk_id uniqueidentifier);
	 
	 INSERT INTO @tbl_cmpl_mon_lnk_id
   SELECT DISTINCT 
          ica_cmpl_mon_lnk.ica_cmpl_mon_lnk_id AS icis_cmpl_mon_lnk_id
        , NEWID() AS local_cmpl_mon_lnk_id
     FROM ica_flow_icis.dbo.ica_cmpl_mon_lnk
    WHERE ica_cmpl_mon_lnk.key_hash IN (SELECT DISTINCT 
                                                key_hash 
                                          FROM cdv_cmpl_mon_lnk
                                         WHERE action_type = 'DELETE');  

     /*  
      *  ICA_CMPL_MON_LNK
      */       
      INSERT INTO ica_cmpl_mon_lnk
           ( ica_cmpl_mon_lnk_id
           , ica_payload_id
           , transaction_type
           , transaction_timestamp
           , src_systm_ident
           , cmpl_mon_ident
           , key_hash
           , data_hash)
      SELECT v_cml.local_cmpl_mon_lnk_id AS ica_cmpl_mon_lnk_id
           , (SELECT ica_payload.ica_payload_id
                FROM ica_payload 
               WHERE ica_payload.operation = 'ComplianceMonitoringLinkageSubmission') AS ica_payload_id
           , 'X' AS transaction_type
           , ica_cmpl_mon_lnk.transaction_timestamp
           , ica_cmpl_mon_lnk.src_systm_ident
           , ica_cmpl_mon_lnk.cmpl_mon_ident
           , NULL AS key_hash
           , NULL AS data_hash
        FROM ica_flow_icis.dbo.ica_cmpl_mon_lnk 
        JOIN @tbl_cmpl_mon_lnk_id AS v_cml
          ON v_cml.icis_cmpl_mon_lnk_id = ica_cmpl_mon_lnk.ica_cmpl_mon_lnk_id;
             
             
     /*  
      *  ICA_LNK_CMPL_MON
      */       
      INSERT INTO ICA_LNK_CMPL_MON
           ( ica_lnk_cmpl_mon_id
           , ica_cmpl_mon_lnk_id
           , ica_case_file_lnk_id
           , cmpl_mon_ident
           , data_hash)
      SELECT NEWID() AS ica_lnk_cmpl_mon_id
           , v_cml.local_cmpl_mon_lnk_id AS ica_cmpl_mon_lnk_id
           , NULL AS ica_case_file_lnk_id
           , ica_lnk_cmpl_mon.cmpl_mon_ident
           , ica_lnk_cmpl_mon.data_hash
        FROM ica_flow_icis.dbo.ica_lnk_cmpl_mon
        JOIN @tbl_cmpl_mon_lnk_id AS v_cml
          ON v_cml.icis_cmpl_mon_lnk_id = ica_lnk_cmpl_mon.ica_cmpl_mon_lnk_id;

            
     /*  
      *  ICA_LNK_DA_ENFRC_ACTN
      */       
      INSERT INTO ICA_LNK_DA_ENFRC_ACTN
           ( ica_lnk_da_enfrc_actn_id
           , ica_cmpl_mon_lnk_id
           , ica_case_file_lnk_id
           , ica_da_enfrc_actn_lnk_id
           , da_enfrc_actn_ident
           , data_hash)
      SELECT NEWID() AS ica_lnk_da_enfrc_actn_id
           , v_cml.local_cmpl_mon_lnk_id AS ica_cmpl_mon_lnk_id
           , NULL AS ica_case_file_lnk_id
           , NULL AS ica_da_enfrc_actn_lnk_id
           , ica_lnk_da_enfrc_actn.da_enfrc_actn_ident
           , ica_lnk_da_enfrc_actn.data_hash
        FROM ica_flow_icis.dbo.ica_lnk_da_enfrc_actn
        JOIN @tbl_cmpl_mon_lnk_id AS v_cml
          ON v_cml.icis_cmpl_mon_lnk_id = ica_lnk_da_enfrc_actn.ica_cmpl_mon_lnk_id;

     
 /* **********************************************
  * ICA_DA_ENFRC_ACTN_LNK:  Set Delete Transactions
  * **********************************************/         
	 DECLARE @tbl_da_enfrc_actn_lnk_id TABLE ( icis_da_enfrc_actn_lnk_id uniqueidentifier
	                                         , local_da_enfrc_actn_lnk_id uniqueidentifier);
	 
	 INSERT INTO @tbl_da_enfrc_actn_lnk_id
   SELECT DISTINCT 
          ica_da_enfrc_actn_lnk.ica_da_enfrc_actn_lnk_id AS icis_da_enfrc_actn_lnk_id
        , NEWID() AS local_da_enfrc_actn_lnk_id
     FROM ica_flow_icis.dbo.ica_da_enfrc_actn_lnk
    WHERE ica_da_enfrc_actn_lnk.key_hash IN (SELECT DISTINCT 
                                                    key_hash 
                                               FROM cdv_da_enfrc_actn_lnk
                                              WHERE action_type = 'DELETE');  


    /*  
     *  ICA_DA_ENFRC_ACTN_LNK
     */       
     INSERT INTO ica_da_enfrc_actn_lnk
          ( ica_da_enfrc_actn_lnk_id
          , ica_payload_id
          , transaction_type
          , transaction_timestamp
          , src_systm_ident
          , da_enfrc_actn_ident
          , key_hash
          , data_hash)
     SELECT v_eal.local_da_enfrc_actn_lnk_id AS ica_da_enfrc_actn_lnk_id
          , (SELECT ica_payload_id
               FROM ica_payload 
              WHERE operation = 'AirDAEnforcementActionLinkageSubmission') AS ica_payload_id
          , 'X' AS transaction_type
          , ica_da_enfrc_actn_lnk.transaction_timestamp
          , ica_da_enfrc_actn_lnk.src_systm_ident
          , ica_da_enfrc_actn_lnk.da_enfrc_actn_ident
          , NULL AS key_hash
          , NULL AS data_hash
       FROM ica_flow_icis.dbo.ica_da_enfrc_actn_lnk 
       JOIN @tbl_da_enfrc_actn_lnk_id AS v_eal
         ON v_eal.icis_da_enfrc_actn_lnk_id = ica_da_enfrc_actn_lnk.ica_da_enfrc_actn_lnk_id;
          
             
    /*  
     *  ICA_LNK_DA_ENFRC_ACTN
     */       
     INSERT INTO ICA_LNK_DA_ENFRC_ACTN
          ( ica_lnk_da_enfrc_actn_id 
          , ica_cmpl_mon_lnk_id 
          , ica_case_file_lnk_id 
          , ica_da_enfrc_actn_lnk_id 
          , da_enfrc_actn_ident 
          , data_hash )
     SELECT NEWID() AS ica_lnk_da_enfrc_actn_id 
          , NULL AS ica_cmpl_mon_lnk_id 
          , NULL AS ica_case_file_lnk_id 
          , v_eal.local_da_enfrc_actn_lnk_id AS ica_da_enfrc_actn_lnk_id 
          , ica_lnk_da_enfrc_actn.da_enfrc_actn_ident 
          , ica_lnk_da_enfrc_actn.data_hash 
      FROM ica_flow_icis.dbo.ica_lnk_da_enfrc_actn 
      JOIN @tbl_da_enfrc_actn_lnk_id AS v_eal
        ON v_eal.icis_da_enfrc_actn_lnk_id = ica_lnk_da_enfrc_actn.ica_da_enfrc_actn_lnk_id;
      
END;
GO


/*
Copyright (c) 2014, The Environmental Council of the States (ECOS)
All rights reserved.
 
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
 
 * Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
 * Neither the name of the ECOS nor the names of its contributors may
   be used to endorse or promote products derived from this software
   without specific prior written permission.
 
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.ICA_PROCESS_ACCEPTED_TRANS') AND type in (N'P', N'PC'))
DROP PROCEDURE dbo.ICA_PROCESS_ACCEPTED_TRANS
GO

/*************************************************************************************************
** Object Name: ica_process_accepted_trans
**
** Author: Windsor Solutions, Inc.
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure uses the data in ICA_SUBM_RSLTS table to copy the data for accepted
**               transactions from the LOCAL to ICIS schema/database. It should only be executed by
**               the OpenNode2 plugin as part of the GetICISStatusAndProcessReports service execution
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 07/18/2014    Windsor     Baseline from v4.0 procedure. 
** 08/11/2014    KJames      Renamed the submission results table.
** 08/11/2014    KJames      Renamed the submission results primary key column.
** 08/11/2014    KJames      Renamed the milestone type code on the submission history table.
** 08/11/2014    KJames      Removed trans_count_new from the submission history load.
** 07/06/2015    KJames      Added processing for new staging table ICA_DEMND_STIPULTD_PNLTY.
** 08/24/2015    KJames      Modified the SUBM_TYPE_NAME for CaseFileLinkageSubmission.
** 09/21/2015    KJames      Modified the key hashing processing for the linkage tables to 
**                           match the process that occurs in change detection.
**
***************************************************************************************************/
CREATE PROCEDURE dbo.ICA_PROCESS_ACCEPTED_TRANS

   @p_transaction_id varchar(50)

AS

-- Stored procedure to move accepted transactions from ICA_FLOW_LOCAL to ICA_FLOW_ICIS.
-- Target Database: SQL Server

--Step 1: Remove processing results from previous submissions
--Step 2: Update key_hash with hashed business key data
--Step 3: Move accepted transactions from LOCAL to ICIS database
--Step 4: Copy business keys where ICIS returnes error that key is already present in ICIS
--Step 5: Record counts into ICA_SUBM_HIST

--Quit procedure if no records are returned relating to the current transaction. ICIS will return an empty processing report
  --if there is a severe error in the ICIS submission processor at EPA
IF (SELECT COUNT(1) FROM ica_subm_rslts WHERE subm_transaction_id = @p_transaction_id) = 0
   RETURN;

--Step 1: Remove processing results from previous submissions
--Step 1: Remove any previous accepted transactions so the procedure does not attempt to move records from previous executions.
DELETE 
  FROM ica_subm_rslts 
 WHERE result_type_code IN ('Accepted','Warning')
   AND subm_transaction_id <> @p_transaction_id;

---------------------------------------------------------
--Step 2: Update key_hash with hashed business key data
---------------------------------------------------------
UPDATE ica_subm_rslts
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', fac_ident)
 WHERE subm_type_name = 'AirComplianceMonitoringStrategySubmission'
   AND subm_transaction_id = @p_transaction_id;

UPDATE ica_subm_rslts
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', cmpl_mon_ident)
 WHERE subm_type_name = 'AirDAComplianceMonitoringSubmission'
   AND subm_transaction_id = @p_transaction_id;

UPDATE ica_subm_rslts
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', da_enfrc_actn_ident + milstn_type_code)
 WHERE subm_type_name = 'AirDAEnforcementActionMilestoneSubmission'
   AND subm_transaction_id = @p_transaction_id;

UPDATE ica_subm_rslts
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', da_enfrc_actn_ident)
 WHERE subm_type_name = 'AirDAFormalEnforcementActionSubmission'
   AND subm_transaction_id = @p_transaction_id;

UPDATE ica_subm_rslts
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', da_enfrc_actn_ident)
 WHERE subm_type_name = 'AirDAInformalEnforcementActionSubmission'
   AND subm_transaction_id = @p_transaction_id;

UPDATE ica_subm_rslts
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', fac_ident)
 WHERE subm_type_name = 'AirFacilitySubmission'
   AND subm_transaction_id = @p_transaction_id;

UPDATE ica_subm_rslts
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', fac_ident + CAST(poluts_code AS VARCHAR(10)))
 WHERE subm_type_name = 'AirPollutantsSubmission'
   AND subm_transaction_id = @p_transaction_id;

UPDATE ica_subm_rslts
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', fac_ident + prog_code)
 WHERE subm_type_name = 'AirProgramsSubmission'
   AND subm_transaction_id = @p_transaction_id;

UPDATE ica_subm_rslts
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', cmpl_mon_ident)
 WHERE subm_type_name = 'AirTVACCSubmission'
   AND subm_transaction_id = @p_transaction_id;

UPDATE ica_subm_rslts
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', case_file_ident)
 WHERE subm_type_name = 'AirDACaseFileSubmission'
   AND subm_transaction_id = @p_transaction_id;

UPDATE ica_subm_rslts
   SET key_hash = dbo.HASHBYTES_VARCHAR( 'SHA1'
                                       , ISNULL(ica_subm_rslts.da_enfrc_actn_ident,'')
                                       + ISNULL(ica_subm_rslts.da_enfrc_actn_ident_2,''))
 WHERE subm_type_name = 'AirDAEnforcementActionLinkageSubmission'
   AND subm_transaction_id = @p_transaction_id;

UPDATE ica_subm_rslts
   SET key_hash = dbo.HASHBYTES_VARCHAR( 'SHA1'
                                       , ISNULL(ica_subm_rslts.case_file_ident,'')
                                       + ISNULL(ica_subm_rslts.case_file_ident_2,'')
                                       + ISNULL(ica_subm_rslts.cmpl_mon_ident,'')
                                       + ISNULL(ica_subm_rslts.da_enfrc_actn_ident,'')
                                       )
 WHERE subm_type_name = 'CaseFileLinkageSubmission'
   AND subm_transaction_id = @p_transaction_id;

UPDATE ica_subm_rslts
   SET key_hash = dbo.HASHBYTES_VARCHAR( 'SHA1'
                                       , ISNULL(ica_subm_rslts.cmpl_mon_ident,'')
                                       + ISNULL(ica_subm_rslts.cmpl_mon_ident_2,'')
                                       + ISNULL(ica_subm_rslts.da_enfrc_actn_ident,'')
                                       )
 WHERE subm_type_name = 'ComplianceMonitoringLinkageSubmission'
   AND subm_transaction_id = @p_transaction_id;

--Delete errors from previous submissions where here is an error for the same key in the current submission
-- ICIS Code!!
    DELETE 
      FROM ica_subm_rslts 
     WHERE result_type_code IN ('Error','Warning')
       AND key_hash IN (SELECT key_hash 
                          FROM ica_subm_rslts 
                         WHERE subm_transaction_id = @p_transaction_id
                           AND result_type_code IN ('Error','Warning'))
       AND subm_transaction_id <> @p_transaction_id;

-- ICIS Air Code!!
DELETE
  FROM ica_subm_rslts
 WHERE subm_type_name IN (SELECT operation 
                            FROM ica_payload
                           WHERE auto_gen_deletes = 'Y')
   AND subm_transaction_id <> @p_transaction_id;


DELETE
  FROM ica_subm_rslts
 WHERE subm_type_name = 'AirComplianceMonitoringStrategySubmission'
   AND subm_transaction_id <> @p_transaction_id
   AND result_type_code = 'Error'
   AND key_hash IN
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE subm_type_name = 'AirComplianceMonitoringStrategySubmission'
                  AND subm_transaction_id = @p_transaction_id);

DELETE
  FROM ica_subm_rslts
 WHERE subm_type_name = 'AirDAComplianceMonitoringSubmission'
   AND subm_transaction_id <> @p_transaction_id
   AND result_type_code = 'Error'
   AND key_hash IN
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE subm_type_name = 'AirDAComplianceMonitoringSubmission'
                  AND subm_transaction_id = @p_transaction_id);

DELETE
  FROM ica_subm_rslts
 WHERE subm_type_name = 'AirDAEnforcementActionMilestoneSubmission'
   AND subm_transaction_id <> @p_transaction_id
   AND result_type_code = 'Error'
   AND key_hash IN
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE subm_type_name = 'AirDAEnforcementActionMilestoneSubmission'
                  AND subm_transaction_id = @p_transaction_id);

DELETE
  FROM ica_subm_rslts
 WHERE subm_type_name = 'AirDAFormalEnforcementActionSubmission'
   AND subm_transaction_id <> @p_transaction_id
   AND result_type_code = 'Error'
   AND key_hash IN
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE subm_type_name = 'AirDAFormalEnforcementActionSubmission'
                  AND subm_transaction_id = @p_transaction_id);

DELETE
  FROM ica_subm_rslts
 WHERE subm_type_name = 'AirDAInformalEnforcementActionSubmission'
   AND subm_transaction_id <> @p_transaction_id
   AND result_type_code = 'Error'
   AND key_hash IN
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE subm_type_name = 'AirDAInformalEnforcementActionSubmission'
                  AND subm_transaction_id = @p_transaction_id);

DELETE
  FROM ica_subm_rslts
 WHERE subm_type_name = 'AirFacilitySubmission'
   AND subm_transaction_id <> @p_transaction_id
   AND result_type_code = 'Error'
   AND key_hash IN
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE subm_type_name = 'AirFacilitySubmission'
                  AND subm_transaction_id = @p_transaction_id);

DELETE
  FROM ica_subm_rslts
 WHERE subm_type_name = 'AirPollutantsSubmission'
   AND subm_transaction_id <> @p_transaction_id
   AND result_type_code = 'Error'
   AND key_hash IN
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE subm_type_name = 'AirPollutantsSubmission'
                  AND subm_transaction_id = @p_transaction_id);

DELETE
  FROM ica_subm_rslts
 WHERE subm_type_name = 'AirProgramsSubmission'
   AND subm_transaction_id <> @p_transaction_id
   AND result_type_code = 'Error'
   AND key_hash IN
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE subm_type_name = 'AirProgramsSubmission'
                  AND subm_transaction_id = @p_transaction_id);

DELETE
  FROM ica_subm_rslts
 WHERE subm_type_name = 'AirTVACCSubmission'
   AND subm_transaction_id <> @p_transaction_id
   AND result_type_code = 'Error'
   AND key_hash IN
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE subm_type_name = 'AirTVACCSubmission'
                  AND subm_transaction_id = @p_transaction_id);

DELETE
  FROM ica_subm_rslts
 WHERE subm_type_name = 'AirDACaseFileSubmission'
   AND subm_transaction_id <> @p_transaction_id
   AND result_type_code = 'Error'
   AND key_hash IN
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE subm_type_name = 'AirDACaseFileSubmission'
                  AND subm_transaction_id = @p_transaction_id);

DELETE
  FROM ica_subm_rslts
 WHERE subm_type_name = 'AirDAEnforcementActionLinkageSubmission'
   AND subm_transaction_id <> @p_transaction_id
   AND result_type_code = 'Error'
   AND key_hash IN
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE subm_type_name = 'AirDAEnforcementActionLinkageSubmission'
                  AND subm_transaction_id = @p_transaction_id);

DELETE
  FROM ica_subm_rslts
 WHERE subm_type_name = 'CaseFileLinkageSubmission'
   AND subm_transaction_id <> @p_transaction_id
   AND result_type_code = 'Error'
   AND key_hash IN
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE subm_type_name = 'CaseFileLinkageSubmission'
                  AND subm_transaction_id = @p_transaction_id);

DELETE
  FROM ica_subm_rslts
 WHERE subm_type_name = 'ComplianceMonitoringLinkageSubmission'
   AND subm_transaction_id <> @p_transaction_id
   AND result_type_code = 'Error'
   AND key_hash IN
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE subm_type_name = 'ComplianceMonitoringLinkageSubmission'
                  AND subm_transaction_id = @p_transaction_id);


 /*
  *  Step 3: Move accepted transactions from LOCAL to ICIS database
  *          FOR EACH PAYLOAD TYPE:
  *          1.  First prune data from the ICA_FLOW_ICIS schema to make room for new data coming across
  *              - Delete for basic permit, general permit, permitted feature, limit set, parameter limit, and limit data
  *                for permits that have been reissued.
  *              - Delete all data for permit that has been terminated 
  *          2.  Second copy accepted data from ICA_FLOW_LOCAL into ICA_FLOW_ICIS.
  */
  
-- Remove any old records for ica_cmpl_mon_strgy
-- /ICA_CMPL_MON_STRGY
DELETE
  FROM ica_flow_icis.dbo.ica_cmpl_mon_strgy
 WHERE ica_cmpl_mon_strgy.ica_cmpl_mon_strgy_id IN
          (SELECT ica_cmpl_mon_strgy.ica_cmpl_mon_strgy_id
             FROM ica_flow_icis.dbo.ica_cmpl_mon_strgy
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_cmpl_mon_strgy.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirComplianceMonitoringStrategySubmission')
);

-- Add accepted records for ica_cmpl_mon_strgy
-- /ICA_CMPL_MON_STRGY
INSERT INTO ica_flow_icis.dbo.ica_cmpl_mon_strgy
     SELECT ica_cmpl_mon_strgy.*
       FROM ica_cmpl_mon_strgy
       WHERE ica_cmpl_mon_strgy.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirComplianceMonitoringStrategySubmission');


-- Remove any old records for ica_da_cmpl_mon
-- /ICA_DA_CMPL_MON/ICA_STCK_TST/ICA_TST_RSLTS/ICA_METHOD
DELETE
  FROM ica_flow_icis.dbo.ica_method
 WHERE ica_method.ica_tst_rslts_id IN
          (SELECT ica_tst_rslts.ica_tst_rslts_id
             FROM ica_flow_icis.dbo.ica_da_cmpl_mon
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_cmpl_mon.key_hash 
                  JOIN ica_flow_icis.dbo.ica_stck_tst ON ica_stck_tst.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
                  JOIN ica_flow_icis.dbo.ica_tst_rslts ON ica_tst_rslts.ica_stck_tst_id = ica_stck_tst.ica_stck_tst_id
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAComplianceMonitoringSubmission')
);
-- /ICA_DA_CMPL_MON/ICA_CNTCT/ICA_TELEPH
DELETE
  FROM ica_flow_icis.dbo.ica_teleph
 WHERE ica_teleph.ica_cntct_id IN
          (SELECT ica_cntct.ica_cntct_id
             FROM ica_flow_icis.dbo.ica_da_cmpl_mon
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_cmpl_mon.key_hash 
                  JOIN ica_flow_icis.dbo.ica_cntct ON ica_cntct.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAComplianceMonitoringSubmission')
);
-- /ICA_DA_CMPL_MON/ICA_STCK_TST/ICA_STCK_TST_OBS_AGNCY_TYPE
DELETE
  FROM ica_flow_icis.dbo.ica_stck_tst_obs_agncy_type
 WHERE ica_stck_tst_obs_agncy_type.ica_stck_tst_id IN
          (SELECT ica_stck_tst.ica_stck_tst_id
             FROM ica_flow_icis.dbo.ica_da_cmpl_mon
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_cmpl_mon.key_hash 
                  JOIN ica_flow_icis.dbo.ica_stck_tst ON ica_stck_tst.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAComplianceMonitoringSubmission')
);
-- /ICA_DA_CMPL_MON/ICA_STCK_TST/ICA_STCK_TST_PURPOSE
DELETE
  FROM ica_flow_icis.dbo.ica_stck_tst_purpose
 WHERE ica_stck_tst_purpose.ica_stck_tst_id IN
          (SELECT ica_stck_tst.ica_stck_tst_id
             FROM ica_flow_icis.dbo.ica_da_cmpl_mon
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_cmpl_mon.key_hash 
                  JOIN ica_flow_icis.dbo.ica_stck_tst ON ica_stck_tst.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAComplianceMonitoringSubmission')
);
-- /ICA_DA_CMPL_MON/ICA_STCK_TST/ICA_TST_RSLTS
DELETE
  FROM ica_flow_icis.dbo.ica_tst_rslts
 WHERE ica_tst_rslts.ica_stck_tst_id IN
          (SELECT ica_stck_tst.ica_stck_tst_id
             FROM ica_flow_icis.dbo.ica_da_cmpl_mon
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_cmpl_mon.key_hash 
                  JOIN ica_flow_icis.dbo.ica_stck_tst ON ica_stck_tst.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAComplianceMonitoringSubmission')
);
-- /ICA_DA_CMPL_MON/ICA_CMPL_INSP_TYPE
DELETE
  FROM ica_flow_icis.dbo.ica_cmpl_insp_type
 WHERE ica_cmpl_insp_type.ica_da_cmpl_mon_id IN
          (SELECT ica_da_cmpl_mon.ica_da_cmpl_mon_id
             FROM ica_flow_icis.dbo.ica_da_cmpl_mon
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_cmpl_mon.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAComplianceMonitoringSubmission')
);
-- /ICA_DA_CMPL_MON/ICA_CNTCT
DELETE
  FROM ica_flow_icis.dbo.ica_cntct
 WHERE ica_cntct.ica_da_cmpl_mon_id IN
          (SELECT ica_da_cmpl_mon.ica_da_cmpl_mon_id
             FROM ica_flow_icis.dbo.ica_da_cmpl_mon
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_cmpl_mon.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAComplianceMonitoringSubmission')
);
-- /ICA_DA_CMPL_MON/ICA_FAC_IDENT
DELETE
  FROM ica_flow_icis.dbo.ica_fac_ident
 WHERE ica_fac_ident.ica_da_cmpl_mon_id IN
          (SELECT ica_da_cmpl_mon.ica_da_cmpl_mon_id
             FROM ica_flow_icis.dbo.ica_da_cmpl_mon
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_cmpl_mon.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAComplianceMonitoringSubmission')
);
-- /ICA_DA_CMPL_MON/ICA_INSP_CMNT_TXT
DELETE
  FROM ica_flow_icis.dbo.ica_insp_cmnt_txt
 WHERE ica_insp_cmnt_txt.ica_da_cmpl_mon_id IN
          (SELECT ica_da_cmpl_mon.ica_da_cmpl_mon_id
             FROM ica_flow_icis.dbo.ica_da_cmpl_mon
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_cmpl_mon.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAComplianceMonitoringSubmission')
);
-- /ICA_DA_CMPL_MON/ICA_INSP_GOV_CNTCT
DELETE
  FROM ica_flow_icis.dbo.ica_insp_gov_cntct
 WHERE ica_insp_gov_cntct.ica_da_cmpl_mon_id IN
          (SELECT ica_da_cmpl_mon.ica_da_cmpl_mon_id
             FROM ica_flow_icis.dbo.ica_da_cmpl_mon
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_cmpl_mon.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAComplianceMonitoringSubmission')
);
-- /ICA_DA_CMPL_MON/ICA_NAT_PRIO
DELETE
  FROM ica_flow_icis.dbo.ica_nat_prio
 WHERE ica_nat_prio.ica_da_cmpl_mon_id IN
          (SELECT ica_da_cmpl_mon.ica_da_cmpl_mon_id
             FROM ica_flow_icis.dbo.ica_da_cmpl_mon
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_cmpl_mon.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAComplianceMonitoringSubmission')
);
-- /ICA_DA_CMPL_MON/ICA_POLUT
DELETE
  FROM ica_flow_icis.dbo.ica_polut
 WHERE ica_polut.ica_da_cmpl_mon_id IN
          (SELECT ica_da_cmpl_mon.ica_da_cmpl_mon_id
             FROM ica_flow_icis.dbo.ica_da_cmpl_mon
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_cmpl_mon.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAComplianceMonitoringSubmission')
);
-- /ICA_DA_CMPL_MON/ICA_PROG
DELETE
  FROM ica_flow_icis.dbo.ica_prog
 WHERE ica_prog.ica_da_cmpl_mon_id IN
          (SELECT ica_da_cmpl_mon.ica_da_cmpl_mon_id
             FROM ica_flow_icis.dbo.ica_da_cmpl_mon
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_cmpl_mon.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAComplianceMonitoringSubmission')
);
-- /ICA_DA_CMPL_MON/ICA_RGNL_PRIO
DELETE
  FROM ica_flow_icis.dbo.ica_rgnl_prio
 WHERE ica_rgnl_prio.ica_da_cmpl_mon_id IN
          (SELECT ica_da_cmpl_mon.ica_da_cmpl_mon_id
             FROM ica_flow_icis.dbo.ica_da_cmpl_mon
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_cmpl_mon.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAComplianceMonitoringSubmission')
);
-- /ICA_DA_CMPL_MON/ICA_SENS_CMNT_TXT
DELETE
  FROM ica_flow_icis.dbo.ica_sens_cmnt_txt
 WHERE ica_sens_cmnt_txt.ica_da_cmpl_mon_id IN
          (SELECT ica_da_cmpl_mon.ica_da_cmpl_mon_id
             FROM ica_flow_icis.dbo.ica_da_cmpl_mon
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_cmpl_mon.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAComplianceMonitoringSubmission')
);
-- /ICA_DA_CMPL_MON/ICA_STCK_TST
DELETE
  FROM ica_flow_icis.dbo.ica_stck_tst
 WHERE ica_stck_tst.ica_da_cmpl_mon_id IN
          (SELECT ica_da_cmpl_mon.ica_da_cmpl_mon_id
             FROM ica_flow_icis.dbo.ica_da_cmpl_mon
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_cmpl_mon.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAComplianceMonitoringSubmission')
);
-- /ICA_DA_CMPL_MON
DELETE
  FROM ica_flow_icis.dbo.ica_da_cmpl_mon
 WHERE ica_da_cmpl_mon.ica_da_cmpl_mon_id IN
          (SELECT ica_da_cmpl_mon.ica_da_cmpl_mon_id
             FROM ica_flow_icis.dbo.ica_da_cmpl_mon
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_cmpl_mon.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAComplianceMonitoringSubmission')
);

-- Add accepted records for ica_da_cmpl_mon
-- /ICA_DA_CMPL_MON
INSERT INTO ica_flow_icis.dbo.ica_da_cmpl_mon
     SELECT ica_da_cmpl_mon.*
       FROM ica_da_cmpl_mon
       WHERE ica_da_cmpl_mon.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAComplianceMonitoringSubmission');

-- /ICA_DA_CMPL_MON/ICA_CMPL_INSP_TYPE
INSERT INTO ica_flow_icis.dbo.ica_cmpl_insp_type
     SELECT ica_cmpl_insp_type.*
       FROM ica_cmpl_insp_type
          JOIN ica_da_cmpl_mon
            ON ica_cmpl_insp_type.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
       WHERE ica_da_cmpl_mon.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAComplianceMonitoringSubmission');

-- /ICA_DA_CMPL_MON/ICA_CNTCT
INSERT INTO ica_flow_icis.dbo.ica_cntct
     SELECT ica_cntct.*
       FROM ica_cntct
          JOIN ica_da_cmpl_mon
            ON ica_cntct.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
       WHERE ica_da_cmpl_mon.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAComplianceMonitoringSubmission');

-- /ICA_DA_CMPL_MON/ICA_CNTCT/ICA_TELEPH
INSERT INTO ica_flow_icis.dbo.ica_teleph
     SELECT ica_teleph.*
       FROM ica_teleph
          JOIN ica_cntct
            ON ica_teleph.ica_cntct_id = ica_cntct.ica_cntct_id
          JOIN ica_da_cmpl_mon
            ON ica_cntct.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
       WHERE ica_da_cmpl_mon.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAComplianceMonitoringSubmission');

-- /ICA_DA_CMPL_MON/ICA_FAC_IDENT
INSERT INTO ica_flow_icis.dbo.ica_fac_ident
     SELECT ica_fac_ident.*
       FROM ica_fac_ident
          JOIN ica_da_cmpl_mon
            ON ica_fac_ident.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
       WHERE ica_da_cmpl_mon.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAComplianceMonitoringSubmission');

-- /ICA_DA_CMPL_MON/ICA_INSP_CMNT_TXT
INSERT INTO ica_flow_icis.dbo.ica_insp_cmnt_txt
     SELECT ica_insp_cmnt_txt.*
       FROM ica_insp_cmnt_txt
          JOIN ica_da_cmpl_mon
            ON ica_insp_cmnt_txt.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
       WHERE ica_da_cmpl_mon.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAComplianceMonitoringSubmission');

-- /ICA_DA_CMPL_MON/ICA_INSP_GOV_CNTCT
INSERT INTO ica_flow_icis.dbo.ica_insp_gov_cntct
     SELECT ica_insp_gov_cntct.*
       FROM ica_insp_gov_cntct
          JOIN ica_da_cmpl_mon
            ON ica_insp_gov_cntct.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
       WHERE ica_da_cmpl_mon.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAComplianceMonitoringSubmission');

-- /ICA_DA_CMPL_MON/ICA_NAT_PRIO
INSERT INTO ica_flow_icis.dbo.ica_nat_prio
     SELECT ica_nat_prio.*
       FROM ica_nat_prio
          JOIN ica_da_cmpl_mon
            ON ica_nat_prio.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
       WHERE ica_da_cmpl_mon.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAComplianceMonitoringSubmission');

-- /ICA_DA_CMPL_MON/ICA_POLUT
INSERT INTO ica_flow_icis.dbo.ica_polut
     SELECT ica_polut.*
       FROM ica_polut
          JOIN ica_da_cmpl_mon
            ON ica_polut.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
       WHERE ica_da_cmpl_mon.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAComplianceMonitoringSubmission');

-- /ICA_DA_CMPL_MON/ICA_PROG
INSERT INTO ica_flow_icis.dbo.ica_prog
     SELECT ica_prog.*
       FROM ica_prog
          JOIN ica_da_cmpl_mon
            ON ica_prog.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
       WHERE ica_da_cmpl_mon.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAComplianceMonitoringSubmission');

-- /ICA_DA_CMPL_MON/ICA_RGNL_PRIO
INSERT INTO ica_flow_icis.dbo.ica_rgnl_prio
     SELECT ica_rgnl_prio.*
       FROM ica_rgnl_prio
          JOIN ica_da_cmpl_mon
            ON ica_rgnl_prio.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
       WHERE ica_da_cmpl_mon.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAComplianceMonitoringSubmission');

-- /ICA_DA_CMPL_MON/ICA_SENS_CMNT_TXT
INSERT INTO ica_flow_icis.dbo.ica_sens_cmnt_txt
     SELECT ica_sens_cmnt_txt.*
       FROM ica_sens_cmnt_txt
          JOIN ica_da_cmpl_mon
            ON ica_sens_cmnt_txt.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
       WHERE ica_da_cmpl_mon.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAComplianceMonitoringSubmission');

-- /ICA_DA_CMPL_MON/ICA_STCK_TST
INSERT INTO ica_flow_icis.dbo.ica_stck_tst
     SELECT ica_stck_tst.*
       FROM ica_stck_tst
          JOIN ica_da_cmpl_mon
            ON ica_stck_tst.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
       WHERE ica_da_cmpl_mon.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAComplianceMonitoringSubmission');

-- /ICA_DA_CMPL_MON/ICA_STCK_TST/ICA_STCK_TST_OBS_AGNCY_TYPE
INSERT INTO ica_flow_icis.dbo.ica_stck_tst_obs_agncy_type
     SELECT ica_stck_tst_obs_agncy_type.*
       FROM ica_stck_tst_obs_agncy_type
          JOIN ica_stck_tst
            ON ica_stck_tst_obs_agncy_type.ica_stck_tst_id = ica_stck_tst.ica_stck_tst_id
          JOIN ica_da_cmpl_mon
            ON ica_stck_tst.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
       WHERE ica_da_cmpl_mon.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAComplianceMonitoringSubmission');

-- /ICA_DA_CMPL_MON/ICA_STCK_TST/ICA_STCK_TST_PURPOSE
INSERT INTO ica_flow_icis.dbo.ica_stck_tst_purpose
     SELECT ica_stck_tst_purpose.*
       FROM ica_stck_tst_purpose
          JOIN ica_stck_tst
            ON ica_stck_tst_purpose.ica_stck_tst_id = ica_stck_tst.ica_stck_tst_id
          JOIN ica_da_cmpl_mon
            ON ica_stck_tst.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
       WHERE ica_da_cmpl_mon.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAComplianceMonitoringSubmission');

-- /ICA_DA_CMPL_MON/ICA_STCK_TST/ICA_TST_RSLTS
INSERT INTO ica_flow_icis.dbo.ica_tst_rslts
     SELECT ica_tst_rslts.*
       FROM ica_tst_rslts
          JOIN ica_stck_tst
            ON ica_tst_rslts.ica_stck_tst_id = ica_stck_tst.ica_stck_tst_id
          JOIN ica_da_cmpl_mon
            ON ica_stck_tst.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
       WHERE ica_da_cmpl_mon.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAComplianceMonitoringSubmission');

-- /ICA_DA_CMPL_MON/ICA_STCK_TST/ICA_TST_RSLTS/ICA_METHOD
INSERT INTO ica_flow_icis.dbo.ica_method
     SELECT ica_method.*
       FROM ica_method
          JOIN ica_tst_rslts
            ON ica_method.ica_tst_rslts_id = ica_tst_rslts.ica_tst_rslts_id
          JOIN ica_stck_tst
            ON ica_tst_rslts.ica_stck_tst_id = ica_stck_tst.ica_stck_tst_id
          JOIN ica_da_cmpl_mon
            ON ica_stck_tst.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
       WHERE ica_da_cmpl_mon.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAComplianceMonitoringSubmission');


-- Remove any old records for ica_da_enfrc_actn_milstn
-- /ICA_DA_ENFRC_ACTN_MILSTN
DELETE
  FROM ica_flow_icis.dbo.ica_da_enfrc_actn_milstn
 WHERE ica_da_enfrc_actn_milstn.ica_da_enfrc_actn_milstn_id IN
          (SELECT ica_da_enfrc_actn_milstn.ica_da_enfrc_actn_milstn_id
             FROM ica_flow_icis.dbo.ica_da_enfrc_actn_milstn
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_enfrc_actn_milstn.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAEnforcementActionMilestoneSubmission')
);

-- Add accepted records for ica_da_enfrc_actn_milstn
-- /ICA_DA_ENFRC_ACTN_MILSTN
INSERT INTO ica_flow_icis.dbo.ica_da_enfrc_actn_milstn
     SELECT ica_da_enfrc_actn_milstn.*
       FROM ica_da_enfrc_actn_milstn
       WHERE ica_da_enfrc_actn_milstn.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAEnforcementActionMilestoneSubmission');


-- Remove any old records for ica_da_frml_enfrc_actn
-- /ICA_DA_FRML_ENFRC_ACTN/ICA_DA_FINAL_ORDER/ICA_FINAL_ORDER_FAC_IDENT
DELETE
  FROM ica_flow_icis.dbo.ica_final_order_fac_ident
 WHERE ica_final_order_fac_ident.ica_da_final_order_id IN
          (SELECT ica_da_final_order.ica_da_final_order_id
             FROM ica_flow_icis.dbo.ica_da_frml_enfrc_actn
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_frml_enfrc_actn.key_hash 
                  JOIN ica_flow_icis.dbo.ica_da_final_order ON ica_da_final_order.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAFormalEnforcementActionSubmission')
);

-- Remove any old records for ica_demnd_stipultd_pnlty
-- /ICA_DA_FRML_ENFRC_ACTN/ICA_DA_FINAL_ORDER/ICA_DEMND_STIPULTD_PNLTY
DELETE
  FROM ica_flow_icis.dbo.ica_demnd_stipultd_pnlty
 WHERE ica_demnd_stipultd_pnlty.ica_da_final_order_id IN
          (SELECT ica_da_final_order.ica_da_final_order_id
             FROM ica_flow_icis.dbo.ica_da_frml_enfrc_actn
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_frml_enfrc_actn.key_hash 
                  JOIN ica_flow_icis.dbo.ica_da_final_order ON ica_da_final_order.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAFormalEnforcementActionSubmission')
);

-- /ICA_DA_FRML_ENFRC_ACTN/ICA_DA_FINAL_ORDER
DELETE
  FROM ica_flow_icis.dbo.ica_da_final_order
 WHERE ica_da_final_order.ica_da_frml_enfrc_actn_id IN
          (SELECT ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
             FROM ica_flow_icis.dbo.ica_da_frml_enfrc_actn
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_frml_enfrc_actn.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAFormalEnforcementActionSubmission')
);
-- /ICA_DA_FRML_ENFRC_ACTN/ICA_ENFRC_ACTN_CMNT_TXT
DELETE
  FROM ica_flow_icis.dbo.ica_enfrc_actn_cmnt_txt
 WHERE ica_enfrc_actn_cmnt_txt.ica_da_frml_enfrc_actn_id IN
          (SELECT ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
             FROM ica_flow_icis.dbo.ica_da_frml_enfrc_actn
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_frml_enfrc_actn.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAFormalEnforcementActionSubmission')
);
-- /ICA_DA_FRML_ENFRC_ACTN/ICA_ENFRC_ACTN_GOV_CNTCT
DELETE
  FROM ica_flow_icis.dbo.ica_enfrc_actn_gov_cntct
 WHERE ica_enfrc_actn_gov_cntct.ica_da_frml_enfrc_actn_id IN
          (SELECT ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
             FROM ica_flow_icis.dbo.ica_da_frml_enfrc_actn
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_frml_enfrc_actn.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAFormalEnforcementActionSubmission')
);
-- /ICA_DA_FRML_ENFRC_ACTN/ICA_ENFRC_ACTN_TYPE
DELETE
  FROM ica_flow_icis.dbo.ica_enfrc_actn_type
 WHERE ica_enfrc_actn_type.ica_da_frml_enfrc_actn_id IN
          (SELECT ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
             FROM ica_flow_icis.dbo.ica_da_frml_enfrc_actn
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_frml_enfrc_actn.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAFormalEnforcementActionSubmission')
);
-- /ICA_DA_FRML_ENFRC_ACTN/ICA_ENFRC_AGNCY_TYPE
DELETE
  FROM ica_flow_icis.dbo.ica_enfrc_agncy_type
 WHERE ica_enfrc_agncy_type.ica_da_frml_enfrc_actn_id IN
          (SELECT ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
             FROM ica_flow_icis.dbo.ica_da_frml_enfrc_actn
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_frml_enfrc_actn.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAFormalEnforcementActionSubmission')
);
-- /ICA_DA_FRML_ENFRC_ACTN/ICA_FAC_IDENT
DELETE
  FROM ica_flow_icis.dbo.ica_fac_ident
 WHERE ica_fac_ident.ica_da_frml_enfrc_actn_id IN
          (SELECT ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
             FROM ica_flow_icis.dbo.ica_da_frml_enfrc_actn
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_frml_enfrc_actn.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAFormalEnforcementActionSubmission')
);
-- /ICA_DA_FRML_ENFRC_ACTN/ICA_POLUT
DELETE
  FROM ica_flow_icis.dbo.ica_polut
 WHERE ica_polut.ica_da_frml_enfrc_actn_id IN
          (SELECT ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
             FROM ica_flow_icis.dbo.ica_da_frml_enfrc_actn
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_frml_enfrc_actn.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAFormalEnforcementActionSubmission')
);
-- /ICA_DA_FRML_ENFRC_ACTN/ICA_PROGS_VIOL
DELETE
  FROM ica_flow_icis.dbo.ica_progs_viol
 WHERE ica_progs_viol.ica_da_frml_enfrc_actn_id IN
          (SELECT ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
             FROM ica_flow_icis.dbo.ica_da_frml_enfrc_actn
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_frml_enfrc_actn.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAFormalEnforcementActionSubmission')
);
-- /ICA_DA_FRML_ENFRC_ACTN/ICA_SENS_CMNT_TXT
DELETE
  FROM ica_flow_icis.dbo.ica_sens_cmnt_txt
 WHERE ica_sens_cmnt_txt.ica_da_frml_enfrc_actn_id IN
          (SELECT ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
             FROM ica_flow_icis.dbo.ica_da_frml_enfrc_actn
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_frml_enfrc_actn.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAFormalEnforcementActionSubmission')
);
-- /ICA_DA_FRML_ENFRC_ACTN
DELETE
  FROM ica_flow_icis.dbo.ica_da_frml_enfrc_actn
 WHERE ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id IN
          (SELECT ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
             FROM ica_flow_icis.dbo.ica_da_frml_enfrc_actn
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_frml_enfrc_actn.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAFormalEnforcementActionSubmission')
);

-- Add accepted records for ica_da_frml_enfrc_actn
-- /ICA_DA_FRML_ENFRC_ACTN
INSERT INTO ica_flow_icis.dbo.ica_da_frml_enfrc_actn
     SELECT ica_da_frml_enfrc_actn.*
       FROM ica_da_frml_enfrc_actn
       WHERE ica_da_frml_enfrc_actn.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAFormalEnforcementActionSubmission');

-- /ICA_DA_FRML_ENFRC_ACTN/ICA_DA_FINAL_ORDER
INSERT INTO ica_flow_icis.dbo.ica_da_final_order
     SELECT ica_da_final_order.*
       FROM ica_da_final_order
          JOIN ica_da_frml_enfrc_actn
            ON ica_da_final_order.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
       WHERE ica_da_frml_enfrc_actn.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAFormalEnforcementActionSubmission');

-- /ICA_DA_FRML_ENFRC_ACTN/ICA_DA_FINAL_ORDER/ICA_FINAL_ORDER_FAC_IDENT
INSERT INTO ica_flow_icis.dbo.ica_final_order_fac_ident
     SELECT ica_final_order_fac_ident.*
       FROM ica_final_order_fac_ident
          JOIN ica_da_final_order
            ON ica_final_order_fac_ident.ica_da_final_order_id = ica_da_final_order.ica_da_final_order_id
          JOIN ica_da_frml_enfrc_actn
            ON ica_da_final_order.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
       WHERE ica_da_frml_enfrc_actn.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAFormalEnforcementActionSubmission');

-- /ICA_DA_FRML_ENFRC_ACTN/ICA_DA_FINAL_ORDER/ICA_DEMND_STIPULTD_PNLTY
INSERT INTO ica_flow_icis.dbo.ica_demnd_stipultd_pnlty
     SELECT ica_demnd_stipultd_pnlty.*
       FROM ica_demnd_stipultd_pnlty
          JOIN ica_da_final_order
            ON ica_demnd_stipultd_pnlty.ica_da_final_order_id = ica_da_final_order.ica_da_final_order_id
          JOIN ica_da_frml_enfrc_actn
            ON ica_da_final_order.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
       WHERE ica_da_frml_enfrc_actn.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAFormalEnforcementActionSubmission');

-- /ICA_DA_FRML_ENFRC_ACTN/ICA_ENFRC_ACTN_CMNT_TXT
INSERT INTO ica_flow_icis.dbo.ica_enfrc_actn_cmnt_txt
     SELECT ica_enfrc_actn_cmnt_txt.*
       FROM ica_enfrc_actn_cmnt_txt
          JOIN ica_da_frml_enfrc_actn
            ON ica_enfrc_actn_cmnt_txt.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
       WHERE ica_da_frml_enfrc_actn.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAFormalEnforcementActionSubmission');

-- /ICA_DA_FRML_ENFRC_ACTN/ICA_ENFRC_ACTN_GOV_CNTCT
INSERT INTO ica_flow_icis.dbo.ica_enfrc_actn_gov_cntct
     SELECT ica_enfrc_actn_gov_cntct.*
       FROM ica_enfrc_actn_gov_cntct
          JOIN ica_da_frml_enfrc_actn
            ON ica_enfrc_actn_gov_cntct.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
       WHERE ica_da_frml_enfrc_actn.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAFormalEnforcementActionSubmission');

-- /ICA_DA_FRML_ENFRC_ACTN/ICA_ENFRC_ACTN_TYPE
INSERT INTO ica_flow_icis.dbo.ica_enfrc_actn_type
     SELECT ica_enfrc_actn_type.*
       FROM ica_enfrc_actn_type
          JOIN ica_da_frml_enfrc_actn
            ON ica_enfrc_actn_type.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
       WHERE ica_da_frml_enfrc_actn.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAFormalEnforcementActionSubmission');

-- /ICA_DA_FRML_ENFRC_ACTN/ICA_ENFRC_AGNCY_TYPE
INSERT INTO ica_flow_icis.dbo.ica_enfrc_agncy_type
     SELECT ica_enfrc_agncy_type.*
       FROM ica_enfrc_agncy_type
          JOIN ica_da_frml_enfrc_actn
            ON ica_enfrc_agncy_type.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
       WHERE ica_da_frml_enfrc_actn.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAFormalEnforcementActionSubmission');

-- /ICA_DA_FRML_ENFRC_ACTN/ICA_FAC_IDENT
INSERT INTO ica_flow_icis.dbo.ica_fac_ident
     SELECT ica_fac_ident.*
       FROM ica_fac_ident
          JOIN ica_da_frml_enfrc_actn
            ON ica_fac_ident.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
       WHERE ica_da_frml_enfrc_actn.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAFormalEnforcementActionSubmission');

-- /ICA_DA_FRML_ENFRC_ACTN/ICA_POLUT
INSERT INTO ica_flow_icis.dbo.ica_polut
     SELECT ica_polut.*
       FROM ica_polut
          JOIN ica_da_frml_enfrc_actn
            ON ica_polut.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
       WHERE ica_da_frml_enfrc_actn.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAFormalEnforcementActionSubmission');

-- /ICA_DA_FRML_ENFRC_ACTN/ICA_PROGS_VIOL
INSERT INTO ica_flow_icis.dbo.ica_progs_viol
     SELECT ica_progs_viol.*
       FROM ica_progs_viol
          JOIN ica_da_frml_enfrc_actn
            ON ica_progs_viol.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
       WHERE ica_da_frml_enfrc_actn.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAFormalEnforcementActionSubmission');

-- /ICA_DA_FRML_ENFRC_ACTN/ICA_SENS_CMNT_TXT
INSERT INTO ica_flow_icis.dbo.ica_sens_cmnt_txt
     SELECT ica_sens_cmnt_txt.*
       FROM ica_sens_cmnt_txt
          JOIN ica_da_frml_enfrc_actn
            ON ica_sens_cmnt_txt.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
       WHERE ica_da_frml_enfrc_actn.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAFormalEnforcementActionSubmission');


-- Remove any old records for ica_da_infrml_enfrc_actn
-- /ICA_DA_INFRML_ENFRC_ACTN/ICA_ENFRC_ACTN_GOV_CNTCT
DELETE
  FROM ica_flow_icis.dbo.ica_enfrc_actn_gov_cntct
 WHERE ica_enfrc_actn_gov_cntct.ica_da_infrml_enfrc_actn_id IN
          (SELECT ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
             FROM ica_flow_icis.dbo.ica_da_infrml_enfrc_actn
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_infrml_enfrc_actn.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAInformalEnforcementActionSubmission')
);
-- /ICA_DA_INFRML_ENFRC_ACTN/ICA_ENFRC_AGNCY_TYPE
DELETE
  FROM ica_flow_icis.dbo.ica_enfrc_agncy_type
 WHERE ica_enfrc_agncy_type.ica_da_infrml_enfrc_actn_id IN
          (SELECT ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
             FROM ica_flow_icis.dbo.ica_da_infrml_enfrc_actn
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_infrml_enfrc_actn.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAInformalEnforcementActionSubmission')
);
-- /ICA_DA_INFRML_ENFRC_ACTN/ICA_FAC_IDENT
DELETE
  FROM ica_flow_icis.dbo.ica_fac_ident
 WHERE ica_fac_ident.ica_da_infrml_enfrc_actn_id IN
          (SELECT ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
             FROM ica_flow_icis.dbo.ica_da_infrml_enfrc_actn
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_infrml_enfrc_actn.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAInformalEnforcementActionSubmission')
);
-- /ICA_DA_INFRML_ENFRC_ACTN/ICA_INFRML_EA_CMNT_TXT
DELETE
  FROM ica_flow_icis.dbo.ica_infrml_ea_cmnt_txt
 WHERE ica_infrml_ea_cmnt_txt.ica_da_infrml_enfrc_actn_id IN
          (SELECT ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
             FROM ica_flow_icis.dbo.ica_da_infrml_enfrc_actn
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_infrml_enfrc_actn.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAInformalEnforcementActionSubmission')
);
-- /ICA_DA_INFRML_ENFRC_ACTN/ICA_POLUT
DELETE
  FROM ica_flow_icis.dbo.ica_polut
 WHERE ica_polut.ica_da_infrml_enfrc_actn_id IN
          (SELECT ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
             FROM ica_flow_icis.dbo.ica_da_infrml_enfrc_actn
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_infrml_enfrc_actn.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAInformalEnforcementActionSubmission')
);
-- /ICA_DA_INFRML_ENFRC_ACTN/ICA_PROGS_VIOL
DELETE
  FROM ica_flow_icis.dbo.ica_progs_viol
 WHERE ica_progs_viol.ica_da_infrml_enfrc_actn_id IN
          (SELECT ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
             FROM ica_flow_icis.dbo.ica_da_infrml_enfrc_actn
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_infrml_enfrc_actn.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAInformalEnforcementActionSubmission')
);
-- /ICA_DA_INFRML_ENFRC_ACTN/ICA_SENS_CMNT_TXT
DELETE
  FROM ica_flow_icis.dbo.ica_sens_cmnt_txt
 WHERE ica_sens_cmnt_txt.ica_da_infrml_enfrc_actn_id IN
          (SELECT ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
             FROM ica_flow_icis.dbo.ica_da_infrml_enfrc_actn
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_infrml_enfrc_actn.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAInformalEnforcementActionSubmission')
);
-- /ICA_DA_INFRML_ENFRC_ACTN
DELETE
  FROM ica_flow_icis.dbo.ica_da_infrml_enfrc_actn
 WHERE ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id IN
          (SELECT ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
             FROM ica_flow_icis.dbo.ica_da_infrml_enfrc_actn
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_infrml_enfrc_actn.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAInformalEnforcementActionSubmission')
);

-- Add accepted records for ica_da_infrml_enfrc_actn
-- /ICA_DA_INFRML_ENFRC_ACTN
INSERT INTO ica_flow_icis.dbo.ica_da_infrml_enfrc_actn
     SELECT ica_da_infrml_enfrc_actn.*
       FROM ica_da_infrml_enfrc_actn
       WHERE ica_da_infrml_enfrc_actn.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAInformalEnforcementActionSubmission');

-- /ICA_DA_INFRML_ENFRC_ACTN/ICA_ENFRC_ACTN_GOV_CNTCT
INSERT INTO ica_flow_icis.dbo.ica_enfrc_actn_gov_cntct
     SELECT ica_enfrc_actn_gov_cntct.*
       FROM ica_enfrc_actn_gov_cntct
          JOIN ica_da_infrml_enfrc_actn
            ON ica_enfrc_actn_gov_cntct.ica_da_infrml_enfrc_actn_id = ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
       WHERE ica_da_infrml_enfrc_actn.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAInformalEnforcementActionSubmission');

-- /ICA_DA_INFRML_ENFRC_ACTN/ICA_ENFRC_AGNCY_TYPE
INSERT INTO ica_flow_icis.dbo.ica_enfrc_agncy_type
     SELECT ica_enfrc_agncy_type.*
       FROM ica_enfrc_agncy_type
          JOIN ica_da_infrml_enfrc_actn
            ON ica_enfrc_agncy_type.ica_da_infrml_enfrc_actn_id = ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
       WHERE ica_da_infrml_enfrc_actn.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAInformalEnforcementActionSubmission');

-- /ICA_DA_INFRML_ENFRC_ACTN/ICA_FAC_IDENT
INSERT INTO ica_flow_icis.dbo.ica_fac_ident
     SELECT ica_fac_ident.*
       FROM ica_fac_ident
          JOIN ica_da_infrml_enfrc_actn
            ON ica_fac_ident.ica_da_infrml_enfrc_actn_id = ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
       WHERE ica_da_infrml_enfrc_actn.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAInformalEnforcementActionSubmission');

-- /ICA_DA_INFRML_ENFRC_ACTN/ICA_INFRML_EA_CMNT_TXT
INSERT INTO ica_flow_icis.dbo.ica_infrml_ea_cmnt_txt
     SELECT ica_infrml_ea_cmnt_txt.*
       FROM ica_infrml_ea_cmnt_txt
          JOIN ica_da_infrml_enfrc_actn
            ON ica_infrml_ea_cmnt_txt.ica_da_infrml_enfrc_actn_id = ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
       WHERE ica_da_infrml_enfrc_actn.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAInformalEnforcementActionSubmission');

-- /ICA_DA_INFRML_ENFRC_ACTN/ICA_POLUT
INSERT INTO ica_flow_icis.dbo.ica_polut
     SELECT ica_polut.*
       FROM ica_polut
          JOIN ica_da_infrml_enfrc_actn
            ON ica_polut.ica_da_infrml_enfrc_actn_id = ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
       WHERE ica_da_infrml_enfrc_actn.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAInformalEnforcementActionSubmission');

-- /ICA_DA_INFRML_ENFRC_ACTN/ICA_PROGS_VIOL
INSERT INTO ica_flow_icis.dbo.ica_progs_viol
     SELECT ica_progs_viol.*
       FROM ica_progs_viol
          JOIN ica_da_infrml_enfrc_actn
            ON ica_progs_viol.ica_da_infrml_enfrc_actn_id = ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
       WHERE ica_da_infrml_enfrc_actn.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAInformalEnforcementActionSubmission');

-- /ICA_DA_INFRML_ENFRC_ACTN/ICA_SENS_CMNT_TXT
INSERT INTO ica_flow_icis.dbo.ica_sens_cmnt_txt
     SELECT ica_sens_cmnt_txt.*
       FROM ica_sens_cmnt_txt
          JOIN ica_da_infrml_enfrc_actn
            ON ica_sens_cmnt_txt.ica_da_infrml_enfrc_actn_id = ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
       WHERE ica_da_infrml_enfrc_actn.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAInformalEnforcementActionSubmission');


-- Remove any old records for ica_fac
-- /ICA_FAC/ICA_CNTCT/ICA_TELEPH
DELETE
  FROM ica_flow_icis.dbo.ica_teleph
 WHERE ica_teleph.ica_cntct_id IN
          (SELECT ica_cntct.ica_cntct_id
             FROM ica_flow_icis.dbo.ica_fac
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_fac.key_hash 
                  JOIN ica_flow_icis.dbo.ica_cntct ON ica_cntct.ica_fac_id = ica_fac.ica_fac_id
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirFacilitySubmission')
);
-- /ICA_FAC/ICA_FAC_ADDR/ICA_TELEPH
DELETE
  FROM ica_flow_icis.dbo.ica_teleph
 WHERE ica_teleph.ica_fac_addr_id IN
          (SELECT ica_fac_addr.ica_fac_addr_id
             FROM ica_flow_icis.dbo.ica_fac
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_fac.key_hash 
                  JOIN ica_flow_icis.dbo.ica_fac_addr ON ica_fac_addr.ica_fac_id = ica_fac.ica_fac_id
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirFacilitySubmission')
);
-- /ICA_FAC/ICA_CNTCT
DELETE
  FROM ica_flow_icis.dbo.ica_cntct
 WHERE ica_cntct.ica_fac_id IN
          (SELECT ica_fac.ica_fac_id
             FROM ica_flow_icis.dbo.ica_fac
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_fac.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirFacilitySubmission')
);
-- /ICA_FAC/ICA_FAC_ADDR
DELETE
  FROM ica_flow_icis.dbo.ica_fac_addr
 WHERE ica_fac_addr.ica_fac_id IN
          (SELECT ica_fac.ica_fac_id
             FROM ica_flow_icis.dbo.ica_fac
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_fac.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirFacilitySubmission')
);
-- /ICA_FAC/ICA_GEO_COORD
DELETE
  FROM ica_flow_icis.dbo.ica_geo_coord
 WHERE ica_geo_coord.ica_fac_id IN
          (SELECT ica_fac.ica_fac_id
             FROM ica_flow_icis.dbo.ica_fac
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_fac.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirFacilitySubmission')
);
-- /ICA_FAC/ICA_NAICS_CODE
DELETE
  FROM ica_flow_icis.dbo.ica_naics_code
 WHERE ica_naics_code.ica_fac_id IN
          (SELECT ica_fac.ica_fac_id
             FROM ica_flow_icis.dbo.ica_fac
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_fac.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirFacilitySubmission')
);
-- /ICA_FAC/ICA_PORT_SRC
DELETE
  FROM ica_flow_icis.dbo.ica_port_src
 WHERE ica_port_src.ica_fac_id IN
          (SELECT ica_fac.ica_fac_id
             FROM ica_flow_icis.dbo.ica_fac
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_fac.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirFacilitySubmission')
);
-- /ICA_FAC/ICA_SIC_CODE
DELETE
  FROM ica_flow_icis.dbo.ica_sic_code
 WHERE ica_sic_code.ica_fac_id IN
          (SELECT ica_fac.ica_fac_id
             FROM ica_flow_icis.dbo.ica_fac
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_fac.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirFacilitySubmission')
);
-- /ICA_FAC/ICA_UNIVERSE_IND
DELETE
  FROM ica_flow_icis.dbo.ica_universe_ind
 WHERE ica_universe_ind.ica_fac_id IN
          (SELECT ica_fac.ica_fac_id
             FROM ica_flow_icis.dbo.ica_fac
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_fac.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirFacilitySubmission')
);
-- /ICA_FAC
DELETE
  FROM ica_flow_icis.dbo.ica_fac
 WHERE ica_fac.ica_fac_id IN
          (SELECT ica_fac.ica_fac_id
             FROM ica_flow_icis.dbo.ica_fac
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_fac.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirFacilitySubmission')
);

-- Add accepted records for ica_fac
-- /ICA_FAC
INSERT INTO ica_flow_icis.dbo.ica_fac
     SELECT ica_fac.*
       FROM ica_fac
       WHERE ica_fac.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirFacilitySubmission');

-- /ICA_FAC/ICA_CNTCT
INSERT INTO ica_flow_icis.dbo.ica_cntct
     SELECT ica_cntct.*
       FROM ica_cntct
          JOIN ica_fac
            ON ica_cntct.ica_fac_id = ica_fac.ica_fac_id
       WHERE ica_fac.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirFacilitySubmission');

-- /ICA_FAC/ICA_CNTCT/ICA_TELEPH
INSERT INTO ica_flow_icis.dbo.ica_teleph
     SELECT ica_teleph.*
       FROM ica_teleph
          JOIN ica_cntct
            ON ica_teleph.ica_cntct_id = ica_cntct.ica_cntct_id
          JOIN ica_fac
            ON ica_cntct.ica_fac_id = ica_fac.ica_fac_id
       WHERE ica_fac.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirFacilitySubmission');

-- /ICA_FAC/ICA_FAC_ADDR
INSERT INTO ica_flow_icis.dbo.ica_fac_addr
     SELECT ica_fac_addr.*
       FROM ica_fac_addr
          JOIN ica_fac
            ON ica_fac_addr.ica_fac_id = ica_fac.ica_fac_id
       WHERE ica_fac.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirFacilitySubmission');

-- /ICA_FAC/ICA_FAC_ADDR/ICA_TELEPH
INSERT INTO ica_flow_icis.dbo.ica_teleph
     SELECT ica_teleph.*
       FROM ica_teleph
          JOIN ica_fac_addr
            ON ica_teleph.ica_fac_addr_id = ica_fac_addr.ica_fac_addr_id
          JOIN ica_fac
            ON ica_fac_addr.ica_fac_id = ica_fac.ica_fac_id
       WHERE ica_fac.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirFacilitySubmission');

-- /ICA_FAC/ICA_GEO_COORD
INSERT INTO ica_flow_icis.dbo.ica_geo_coord
     SELECT ica_geo_coord.*
       FROM ica_geo_coord
          JOIN ica_fac
            ON ica_geo_coord.ica_fac_id = ica_fac.ica_fac_id
       WHERE ica_fac.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirFacilitySubmission');

-- /ICA_FAC/ICA_NAICS_CODE
INSERT INTO ica_flow_icis.dbo.ica_naics_code
     SELECT ica_naics_code.*
       FROM ica_naics_code
          JOIN ica_fac
            ON ica_naics_code.ica_fac_id = ica_fac.ica_fac_id
       WHERE ica_fac.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirFacilitySubmission');

-- /ICA_FAC/ICA_PORT_SRC
INSERT INTO ica_flow_icis.dbo.ica_port_src
     SELECT ica_port_src.*
       FROM ica_port_src
          JOIN ica_fac
            ON ica_port_src.ica_fac_id = ica_fac.ica_fac_id
       WHERE ica_fac.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirFacilitySubmission');

-- /ICA_FAC/ICA_SIC_CODE
INSERT INTO ica_flow_icis.dbo.ica_sic_code
     SELECT ica_sic_code.*
       FROM ica_sic_code
          JOIN ica_fac
            ON ica_sic_code.ica_fac_id = ica_fac.ica_fac_id
       WHERE ica_fac.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirFacilitySubmission');

-- /ICA_FAC/ICA_UNIVERSE_IND
INSERT INTO ica_flow_icis.dbo.ica_universe_ind
     SELECT ica_universe_ind.*
       FROM ica_universe_ind
          JOIN ica_fac
            ON ica_universe_ind.ica_fac_id = ica_fac.ica_fac_id
       WHERE ica_fac.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirFacilitySubmission');


-- Remove any old records for ica_poluts
-- /ICA_POLUTS/ICA_POLUT_DA_CLASS
DELETE
  FROM ica_flow_icis.dbo.ica_polut_da_class
 WHERE ica_polut_da_class.ica_poluts_id IN
          (SELECT ica_poluts.ica_poluts_id
             FROM ica_flow_icis.dbo.ica_poluts
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_poluts.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirPollutantsSubmission')
);
-- /ICA_POLUTS/ICA_POLUT_EPA_CLASS
DELETE
  FROM ica_flow_icis.dbo.ica_polut_epa_class
 WHERE ica_polut_epa_class.ica_poluts_id IN
          (SELECT ica_poluts.ica_poluts_id
             FROM ica_flow_icis.dbo.ica_poluts
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_poluts.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirPollutantsSubmission')
);
-- /ICA_POLUTS
DELETE
  FROM ica_flow_icis.dbo.ica_poluts
 WHERE ica_poluts.ica_poluts_id IN
          (SELECT ica_poluts.ica_poluts_id
             FROM ica_flow_icis.dbo.ica_poluts
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_poluts.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirPollutantsSubmission')
);

-- Add accepted records for ica_poluts
-- /ICA_POLUTS
INSERT INTO ica_flow_icis.dbo.ica_poluts
     SELECT ica_poluts.*
       FROM ica_poluts
       WHERE ica_poluts.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirPollutantsSubmission');

-- /ICA_POLUTS/ICA_POLUT_DA_CLASS
INSERT INTO ica_flow_icis.dbo.ica_polut_da_class
     SELECT ica_polut_da_class.*
       FROM ica_polut_da_class
          JOIN ica_poluts
            ON ica_polut_da_class.ica_poluts_id = ica_poluts.ica_poluts_id
       WHERE ica_poluts.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirPollutantsSubmission');

-- /ICA_POLUTS/ICA_POLUT_EPA_CLASS
INSERT INTO ica_flow_icis.dbo.ica_polut_epa_class
     SELECT ica_polut_epa_class.*
       FROM ica_polut_epa_class
          JOIN ica_poluts
            ON ica_polut_epa_class.ica_poluts_id = ica_poluts.ica_poluts_id
       WHERE ica_poluts.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirPollutantsSubmission');


-- Remove any old records for ica_progs
-- /ICA_PROGS/ICA_PROG_SUBPART
DELETE
  FROM ica_flow_icis.dbo.ica_prog_subpart
 WHERE ica_prog_subpart.ica_progs_id IN
          (SELECT ica_progs.ica_progs_id
             FROM ica_flow_icis.dbo.ica_progs
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_progs.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirProgramsSubmission')
);
-- /ICA_PROGS
DELETE
  FROM ica_flow_icis.dbo.ica_progs
 WHERE ica_progs.ica_progs_id IN
          (SELECT ica_progs.ica_progs_id
             FROM ica_flow_icis.dbo.ica_progs
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_progs.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirProgramsSubmission')
);

-- Add accepted records for ica_progs
-- /ICA_PROGS
INSERT INTO ica_flow_icis.dbo.ica_progs
     SELECT ica_progs.*
       FROM ica_progs
       WHERE ica_progs.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirProgramsSubmission');

-- /ICA_PROGS/ICA_PROG_SUBPART
INSERT INTO ica_flow_icis.dbo.ica_prog_subpart
     SELECT ica_prog_subpart.*
       FROM ica_prog_subpart
          JOIN ica_progs
            ON ica_prog_subpart.ica_progs_id = ica_progs.ica_progs_id
       WHERE ica_progs.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirProgramsSubmission');


-- Remove any old records for ica_tvacc
-- /ICA_TVACC/ICA_CNTCT/ICA_TELEPH
DELETE
  FROM ica_flow_icis.dbo.ica_teleph
 WHERE ica_teleph.ica_cntct_id IN
          (SELECT ica_cntct.ica_cntct_id
             FROM ica_flow_icis.dbo.ica_tvacc
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_tvacc.key_hash 
                  JOIN ica_flow_icis.dbo.ica_cntct ON ica_cntct.ica_tvacc_id = ica_tvacc.ica_tvacc_id
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirTVACCSubmission')
);
-- /ICA_TVACC/ICA_CNTCT
DELETE
  FROM ica_flow_icis.dbo.ica_cntct
 WHERE ica_cntct.ica_tvacc_id IN
          (SELECT ica_tvacc.ica_tvacc_id
             FROM ica_flow_icis.dbo.ica_tvacc
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_tvacc.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirTVACCSubmission')
);
-- /ICA_TVACC/ICA_INSP_CMNT_TXT
DELETE
  FROM ica_flow_icis.dbo.ica_insp_cmnt_txt
 WHERE ica_insp_cmnt_txt.ica_tvacc_id IN
          (SELECT ica_tvacc.ica_tvacc_id
             FROM ica_flow_icis.dbo.ica_tvacc
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_tvacc.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirTVACCSubmission')
);
-- /ICA_TVACC/ICA_INSP_GOV_CNTCT
DELETE
  FROM ica_flow_icis.dbo.ica_insp_gov_cntct
 WHERE ica_insp_gov_cntct.ica_tvacc_id IN
          (SELECT ica_tvacc.ica_tvacc_id
             FROM ica_flow_icis.dbo.ica_tvacc
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_tvacc.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirTVACCSubmission')
);
-- /ICA_TVACC/ICA_NAT_PRIO
DELETE
  FROM ica_flow_icis.dbo.ica_nat_prio
 WHERE ica_nat_prio.ica_tvacc_id IN
          (SELECT ica_tvacc.ica_tvacc_id
             FROM ica_flow_icis.dbo.ica_tvacc
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_tvacc.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirTVACCSubmission')
);
-- /ICA_TVACC/ICA_POLUT
DELETE
  FROM ica_flow_icis.dbo.ica_polut
 WHERE ica_polut.ica_tvacc_id IN
          (SELECT ica_tvacc.ica_tvacc_id
             FROM ica_flow_icis.dbo.ica_tvacc
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_tvacc.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirTVACCSubmission')
);
-- /ICA_TVACC/ICA_PROG
DELETE
  FROM ica_flow_icis.dbo.ica_prog
 WHERE ica_prog.ica_tvacc_id IN
          (SELECT ica_tvacc.ica_tvacc_id
             FROM ica_flow_icis.dbo.ica_tvacc
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_tvacc.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirTVACCSubmission')
);
-- /ICA_TVACC/ICA_RGNL_PRIO
DELETE
  FROM ica_flow_icis.dbo.ica_rgnl_prio
 WHERE ica_rgnl_prio.ica_tvacc_id IN
          (SELECT ica_tvacc.ica_tvacc_id
             FROM ica_flow_icis.dbo.ica_tvacc
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_tvacc.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirTVACCSubmission')
);
-- /ICA_TVACC/ICA_SENS_CMNT_TXT
DELETE
  FROM ica_flow_icis.dbo.ica_sens_cmnt_txt
 WHERE ica_sens_cmnt_txt.ica_tvacc_id IN
          (SELECT ica_tvacc.ica_tvacc_id
             FROM ica_flow_icis.dbo.ica_tvacc
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_tvacc.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirTVACCSubmission')
);
-- /ICA_TVACC/ICA_TVACC_REVIEW
DELETE
  FROM ica_flow_icis.dbo.ica_tvacc_review
 WHERE ica_tvacc_review.ica_tvacc_id IN
          (SELECT ica_tvacc.ica_tvacc_id
             FROM ica_flow_icis.dbo.ica_tvacc
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_tvacc.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirTVACCSubmission')
);
-- /ICA_TVACC
DELETE
  FROM ica_flow_icis.dbo.ica_tvacc
 WHERE ica_tvacc.ica_tvacc_id IN
          (SELECT ica_tvacc.ica_tvacc_id
             FROM ica_flow_icis.dbo.ica_tvacc
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_tvacc.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirTVACCSubmission')
);

-- Add accepted records for ica_tvacc
-- /ICA_TVACC
INSERT INTO ica_flow_icis.dbo.ica_tvacc
     SELECT ica_tvacc.*
       FROM ica_tvacc
       WHERE ica_tvacc.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirTVACCSubmission');

-- /ICA_TVACC/ICA_CNTCT
INSERT INTO ica_flow_icis.dbo.ica_cntct
     SELECT ica_cntct.*
       FROM ica_cntct
          JOIN ica_tvacc
            ON ica_cntct.ica_tvacc_id = ica_tvacc.ica_tvacc_id
       WHERE ica_tvacc.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirTVACCSubmission');

-- /ICA_TVACC/ICA_CNTCT/ICA_TELEPH
INSERT INTO ica_flow_icis.dbo.ica_teleph
     SELECT ica_teleph.*
       FROM ica_teleph
          JOIN ica_cntct
            ON ica_teleph.ica_cntct_id = ica_cntct.ica_cntct_id
          JOIN ica_tvacc
            ON ica_cntct.ica_tvacc_id = ica_tvacc.ica_tvacc_id
       WHERE ica_tvacc.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirTVACCSubmission');

-- /ICA_TVACC/ICA_INSP_CMNT_TXT
INSERT INTO ica_flow_icis.dbo.ica_insp_cmnt_txt
     SELECT ica_insp_cmnt_txt.*
       FROM ica_insp_cmnt_txt
          JOIN ica_tvacc
            ON ica_insp_cmnt_txt.ica_tvacc_id = ica_tvacc.ica_tvacc_id
       WHERE ica_tvacc.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirTVACCSubmission');

-- /ICA_TVACC/ICA_INSP_GOV_CNTCT
INSERT INTO ica_flow_icis.dbo.ica_insp_gov_cntct
     SELECT ica_insp_gov_cntct.*
       FROM ica_insp_gov_cntct
          JOIN ica_tvacc
            ON ica_insp_gov_cntct.ica_tvacc_id = ica_tvacc.ica_tvacc_id
       WHERE ica_tvacc.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirTVACCSubmission');

-- /ICA_TVACC/ICA_NAT_PRIO
INSERT INTO ica_flow_icis.dbo.ica_nat_prio
     SELECT ica_nat_prio.*
       FROM ica_nat_prio
          JOIN ica_tvacc
            ON ica_nat_prio.ica_tvacc_id = ica_tvacc.ica_tvacc_id
       WHERE ica_tvacc.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirTVACCSubmission');

-- /ICA_TVACC/ICA_POLUT
INSERT INTO ica_flow_icis.dbo.ica_polut
     SELECT ica_polut.*
       FROM ica_polut
          JOIN ica_tvacc
            ON ica_polut.ica_tvacc_id = ica_tvacc.ica_tvacc_id
       WHERE ica_tvacc.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirTVACCSubmission');

-- /ICA_TVACC/ICA_PROG
INSERT INTO ica_flow_icis.dbo.ica_prog
     SELECT ica_prog.*
       FROM ica_prog
          JOIN ica_tvacc
            ON ica_prog.ica_tvacc_id = ica_tvacc.ica_tvacc_id
       WHERE ica_tvacc.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirTVACCSubmission');

-- /ICA_TVACC/ICA_RGNL_PRIO
INSERT INTO ica_flow_icis.dbo.ica_rgnl_prio
     SELECT ica_rgnl_prio.*
       FROM ica_rgnl_prio
          JOIN ica_tvacc
            ON ica_rgnl_prio.ica_tvacc_id = ica_tvacc.ica_tvacc_id
       WHERE ica_tvacc.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirTVACCSubmission');

-- /ICA_TVACC/ICA_SENS_CMNT_TXT
INSERT INTO ica_flow_icis.dbo.ica_sens_cmnt_txt
     SELECT ica_sens_cmnt_txt.*
       FROM ica_sens_cmnt_txt
          JOIN ica_tvacc
            ON ica_sens_cmnt_txt.ica_tvacc_id = ica_tvacc.ica_tvacc_id
       WHERE ica_tvacc.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirTVACCSubmission');

-- /ICA_TVACC/ICA_TVACC_REVIEW
INSERT INTO ica_flow_icis.dbo.ica_tvacc_review
     SELECT ica_tvacc_review.*
       FROM ica_tvacc_review
          JOIN ica_tvacc
            ON ica_tvacc_review.ica_tvacc_id = ica_tvacc.ica_tvacc_id
       WHERE ica_tvacc.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirTVACCSubmission');


-- Remove any old records for ica_da_case_file
-- /ICA_DA_CASE_FILE/ICA_CASE_FILE_CMNT_TXT
DELETE
  FROM ica_flow_icis.dbo.ica_case_file_cmnt_txt
 WHERE ica_case_file_cmnt_txt.ica_da_case_file_id IN
          (SELECT ica_da_case_file.ica_da_case_file_id
             FROM ica_flow_icis.dbo.ica_da_case_file
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_case_file.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDACaseFileSubmission')
);
-- /ICA_DA_CASE_FILE/ICA_OTHR_PATHWAY_ACTY
DELETE
  FROM ica_flow_icis.dbo.ica_othr_pathway_acty
 WHERE ica_othr_pathway_acty.ica_da_case_file_id IN
          (SELECT ica_da_case_file.ica_da_case_file_id
             FROM ica_flow_icis.dbo.ica_da_case_file
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_case_file.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDACaseFileSubmission')
);
-- /ICA_DA_CASE_FILE/ICA_POLUT
DELETE
  FROM ica_flow_icis.dbo.ica_polut
 WHERE ica_polut.ica_da_case_file_id IN
          (SELECT ica_da_case_file.ica_da_case_file_id
             FROM ica_flow_icis.dbo.ica_da_case_file
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_case_file.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDACaseFileSubmission')
);
-- /ICA_DA_CASE_FILE/ICA_PROG
DELETE
  FROM ica_flow_icis.dbo.ica_prog
 WHERE ica_prog.ica_da_case_file_id IN
          (SELECT ica_da_case_file.ica_da_case_file_id
             FROM ica_flow_icis.dbo.ica_da_case_file
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_case_file.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDACaseFileSubmission')
);
-- /ICA_DA_CASE_FILE/ICA_SENS_CMNT_TXT
DELETE
  FROM ica_flow_icis.dbo.ica_sens_cmnt_txt
 WHERE ica_sens_cmnt_txt.ica_da_case_file_id IN
          (SELECT ica_da_case_file.ica_da_case_file_id
             FROM ica_flow_icis.dbo.ica_da_case_file
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_case_file.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDACaseFileSubmission')
);
-- /ICA_DA_CASE_FILE/ICA_VIOL
DELETE
  FROM ica_flow_icis.dbo.ica_viol
 WHERE ica_viol.ica_da_case_file_id IN
          (SELECT ica_da_case_file.ica_da_case_file_id
             FROM ica_flow_icis.dbo.ica_da_case_file
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_case_file.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDACaseFileSubmission')
);
-- /ICA_DA_CASE_FILE
DELETE
  FROM ica_flow_icis.dbo.ica_da_case_file
 WHERE ica_da_case_file.ica_da_case_file_id IN
          (SELECT ica_da_case_file.ica_da_case_file_id
             FROM ica_flow_icis.dbo.ica_da_case_file
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_case_file.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDACaseFileSubmission')
);

-- Add accepted records for ica_da_case_file
-- /ICA_DA_CASE_FILE
INSERT INTO ica_flow_icis.dbo.ica_da_case_file
     SELECT ica_da_case_file.*
       FROM ica_da_case_file
       WHERE ica_da_case_file.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDACaseFileSubmission');

-- /ICA_DA_CASE_FILE/ICA_CASE_FILE_CMNT_TXT
INSERT INTO ica_flow_icis.dbo.ica_case_file_cmnt_txt
     SELECT ica_case_file_cmnt_txt.*
       FROM ica_case_file_cmnt_txt
          JOIN ica_da_case_file
            ON ica_case_file_cmnt_txt.ica_da_case_file_id = ica_da_case_file.ica_da_case_file_id
       WHERE ica_da_case_file.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDACaseFileSubmission');

-- /ICA_DA_CASE_FILE/ICA_OTHR_PATHWAY_ACTY
INSERT INTO ica_flow_icis.dbo.ica_othr_pathway_acty
     SELECT ica_othr_pathway_acty.*
       FROM ica_othr_pathway_acty
          JOIN ica_da_case_file
            ON ica_othr_pathway_acty.ica_da_case_file_id = ica_da_case_file.ica_da_case_file_id
       WHERE ica_da_case_file.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDACaseFileSubmission');

-- /ICA_DA_CASE_FILE/ICA_POLUT
INSERT INTO ica_flow_icis.dbo.ica_polut
     SELECT ica_polut.*
       FROM ica_polut
          JOIN ica_da_case_file
            ON ica_polut.ica_da_case_file_id = ica_da_case_file.ica_da_case_file_id
       WHERE ica_da_case_file.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDACaseFileSubmission');

-- /ICA_DA_CASE_FILE/ICA_PROG
INSERT INTO ica_flow_icis.dbo.ica_prog
     SELECT ica_prog.*
       FROM ica_prog
          JOIN ica_da_case_file
            ON ica_prog.ica_da_case_file_id = ica_da_case_file.ica_da_case_file_id
       WHERE ica_da_case_file.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDACaseFileSubmission');

-- /ICA_DA_CASE_FILE/ICA_SENS_CMNT_TXT
INSERT INTO ica_flow_icis.dbo.ica_sens_cmnt_txt
     SELECT ica_sens_cmnt_txt.*
       FROM ica_sens_cmnt_txt
          JOIN ica_da_case_file
            ON ica_sens_cmnt_txt.ica_da_case_file_id = ica_da_case_file.ica_da_case_file_id
       WHERE ica_da_case_file.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDACaseFileSubmission');

-- /ICA_DA_CASE_FILE/ICA_VIOL
INSERT INTO ica_flow_icis.dbo.ica_viol
     SELECT ica_viol.*
       FROM ica_viol
          JOIN ica_da_case_file
            ON ica_viol.ica_da_case_file_id = ica_da_case_file.ica_da_case_file_id
       WHERE ica_da_case_file.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDACaseFileSubmission');


-- Remove any old records for ica_da_enfrc_actn_lnk
-- /ICA_DA_ENFRC_ACTN_LNK/ICA_LNK_DA_ENFRC_ACTN
DELETE
  FROM ica_flow_icis.dbo.ica_lnk_da_enfrc_actn
 WHERE ica_lnk_da_enfrc_actn.ica_da_enfrc_actn_lnk_id IN
          (SELECT ica_da_enfrc_actn_lnk.ica_da_enfrc_actn_lnk_id
             FROM ica_flow_icis.dbo.ica_da_enfrc_actn_lnk
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_enfrc_actn_lnk.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAEnforcementActionLinkageSubmission')
);
-- /ICA_DA_ENFRC_ACTN_LNK
DELETE
  FROM ica_flow_icis.dbo.ica_da_enfrc_actn_lnk
 WHERE ica_da_enfrc_actn_lnk.ica_da_enfrc_actn_lnk_id IN
          (SELECT ica_da_enfrc_actn_lnk.ica_da_enfrc_actn_lnk_id
             FROM ica_flow_icis.dbo.ica_da_enfrc_actn_lnk
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_enfrc_actn_lnk.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAEnforcementActionLinkageSubmission')
);

-- Add accepted records for ica_da_enfrc_actn_lnk
-- /ICA_DA_ENFRC_ACTN_LNK
INSERT INTO ica_flow_icis.dbo.ica_da_enfrc_actn_lnk
     SELECT ica_da_enfrc_actn_lnk.*
       FROM ica_da_enfrc_actn_lnk
       WHERE ica_da_enfrc_actn_lnk.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAEnforcementActionLinkageSubmission');

-- /ICA_DA_ENFRC_ACTN_LNK/ICA_LNK_DA_ENFRC_ACTN
INSERT INTO ica_flow_icis.dbo.ica_lnk_da_enfrc_actn
     SELECT ica_lnk_da_enfrc_actn.*
       FROM ica_lnk_da_enfrc_actn
          JOIN ica_da_enfrc_actn_lnk
            ON ica_lnk_da_enfrc_actn.ica_da_enfrc_actn_lnk_id = ica_da_enfrc_actn_lnk.ica_da_enfrc_actn_lnk_id
       WHERE ica_da_enfrc_actn_lnk.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAEnforcementActionLinkageSubmission');


-- Remove any old records for ica_case_file_lnk
-- /ICA_CASE_FILE_LNK/ICA_LNK_CASE_FILE
DELETE
  FROM ica_flow_icis.dbo.ica_lnk_case_file
 WHERE ica_lnk_case_file.ica_case_file_lnk_id IN
          (SELECT ica_case_file_lnk.ica_case_file_lnk_id
             FROM ica_flow_icis.dbo.ica_case_file_lnk
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_case_file_lnk.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CaseFileLinkageSubmission')
);
-- /ICA_CASE_FILE_LNK/ICA_LNK_CMPL_MON
DELETE
  FROM ica_flow_icis.dbo.ica_lnk_cmpl_mon
 WHERE ica_lnk_cmpl_mon.ica_case_file_lnk_id IN
          (SELECT ica_case_file_lnk.ica_case_file_lnk_id
             FROM ica_flow_icis.dbo.ica_case_file_lnk
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_case_file_lnk.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CaseFileLinkageSubmission')
);
-- /ICA_CASE_FILE_LNK/ICA_LNK_DA_ENFRC_ACTN
DELETE
  FROM ica_flow_icis.dbo.ica_lnk_da_enfrc_actn
 WHERE ica_lnk_da_enfrc_actn.ica_case_file_lnk_id IN
          (SELECT ica_case_file_lnk.ica_case_file_lnk_id
             FROM ica_flow_icis.dbo.ica_case_file_lnk
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_case_file_lnk.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CaseFileLinkageSubmission')
);
-- /ICA_CASE_FILE_LNK
DELETE
  FROM ica_flow_icis.dbo.ica_case_file_lnk
 WHERE ica_case_file_lnk.ica_case_file_lnk_id IN
          (SELECT ica_case_file_lnk.ica_case_file_lnk_id
             FROM ica_flow_icis.dbo.ica_case_file_lnk
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_case_file_lnk.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CaseFileLinkageSubmission')
);

-- Add accepted records for ica_case_file_lnk
-- /ICA_CASE_FILE_LNK
INSERT INTO ica_flow_icis.dbo.ica_case_file_lnk
     SELECT ica_case_file_lnk.*
       FROM ica_case_file_lnk
       WHERE ica_case_file_lnk.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CaseFileLinkageSubmission');

-- /ICA_CASE_FILE_LNK/ICA_LNK_CASE_FILE
INSERT INTO ica_flow_icis.dbo.ica_lnk_case_file
     SELECT ica_lnk_case_file.*
       FROM ica_lnk_case_file
          JOIN ica_case_file_lnk
            ON ica_lnk_case_file.ica_case_file_lnk_id = ica_case_file_lnk.ica_case_file_lnk_id
       WHERE ica_case_file_lnk.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CaseFileLinkageSubmission');

-- /ICA_CASE_FILE_LNK/ICA_LNK_CMPL_MON
INSERT INTO ica_flow_icis.dbo.ica_lnk_cmpl_mon
     SELECT ica_lnk_cmpl_mon.*
       FROM ica_lnk_cmpl_mon
          JOIN ica_case_file_lnk
            ON ica_lnk_cmpl_mon.ica_case_file_lnk_id = ica_case_file_lnk.ica_case_file_lnk_id
       WHERE ica_case_file_lnk.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CaseFileLinkageSubmission');

-- /ICA_CASE_FILE_LNK/ICA_LNK_DA_ENFRC_ACTN
INSERT INTO ica_flow_icis.dbo.ica_lnk_da_enfrc_actn
     SELECT ica_lnk_da_enfrc_actn.*
       FROM ica_lnk_da_enfrc_actn
          JOIN ica_case_file_lnk
            ON ica_lnk_da_enfrc_actn.ica_case_file_lnk_id = ica_case_file_lnk.ica_case_file_lnk_id
       WHERE ica_case_file_lnk.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CaseFileLinkageSubmission');


-- Remove any old records for ica_cmpl_mon_lnk
-- /ICA_CMPL_MON_LNK/ICA_LNK_CMPL_MON
DELETE
  FROM ica_flow_icis.dbo.ica_lnk_cmpl_mon
 WHERE ica_lnk_cmpl_mon.ica_cmpl_mon_lnk_id IN
          (SELECT ica_cmpl_mon_lnk.ica_cmpl_mon_lnk_id
             FROM ica_flow_icis.dbo.ica_cmpl_mon_lnk
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_cmpl_mon_lnk.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringLinkageSubmission')
);
-- /ICA_CMPL_MON_LNK/ICA_LNK_DA_ENFRC_ACTN
DELETE
  FROM ica_flow_icis.dbo.ica_lnk_da_enfrc_actn
 WHERE ica_lnk_da_enfrc_actn.ica_cmpl_mon_lnk_id IN
          (SELECT ica_cmpl_mon_lnk.ica_cmpl_mon_lnk_id
             FROM ica_flow_icis.dbo.ica_cmpl_mon_lnk
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_cmpl_mon_lnk.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringLinkageSubmission')
);
-- /ICA_CMPL_MON_LNK
DELETE
  FROM ica_flow_icis.dbo.ica_cmpl_mon_lnk
 WHERE ica_cmpl_mon_lnk.ica_cmpl_mon_lnk_id IN
          (SELECT ica_cmpl_mon_lnk.ica_cmpl_mon_lnk_id
             FROM ica_flow_icis.dbo.ica_cmpl_mon_lnk
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_cmpl_mon_lnk.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringLinkageSubmission')
);

-- Add accepted records for ica_cmpl_mon_lnk
-- /ICA_CMPL_MON_LNK
INSERT INTO ica_flow_icis.dbo.ica_cmpl_mon_lnk
     SELECT ica_cmpl_mon_lnk.*
       FROM ica_cmpl_mon_lnk
       WHERE ica_cmpl_mon_lnk.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringLinkageSubmission');

-- /ICA_CMPL_MON_LNK/ICA_LNK_CMPL_MON
INSERT INTO ica_flow_icis.dbo.ica_lnk_cmpl_mon
     SELECT ica_lnk_cmpl_mon.*
       FROM ica_lnk_cmpl_mon
          JOIN ica_cmpl_mon_lnk
            ON ica_lnk_cmpl_mon.ica_cmpl_mon_lnk_id = ica_cmpl_mon_lnk.ica_cmpl_mon_lnk_id
       WHERE ica_cmpl_mon_lnk.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringLinkageSubmission');

-- /ICA_CMPL_MON_LNK/ICA_LNK_DA_ENFRC_ACTN
INSERT INTO ica_flow_icis.dbo.ica_lnk_da_enfrc_actn
     SELECT ica_lnk_da_enfrc_actn.*
       FROM ica_lnk_da_enfrc_actn
          JOIN ica_cmpl_mon_lnk
            ON ica_lnk_da_enfrc_actn.ica_cmpl_mon_lnk_id = ica_cmpl_mon_lnk.ica_cmpl_mon_lnk_id
       WHERE ica_cmpl_mon_lnk.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringLinkageSubmission');



----Step 4: Copy business keys where ICIS returnes error that key is already present in ICIS

--  -- Add keys that already exist in ICIS for module ica_basic_prmt
--  INSERT INTO ica_flow_icis.dbo.ica_basic_prmt (ica_payload_id, ica_basic_prmt_id, prmt_ident, key_hash, data_hash)
--       SELECT (SELECT ica_payload_id FROM ica_payload WHERE operation='BasicPermitSubmission') as payload_id, NEWID(), prmt_ident, key_hash, '0' as data_hash
--         FROM ica_subm_rslts
--        WHERE result_code = 'BP060'
--          AND subm_type_name = 'BasicPermitSubmission'
--          AND subm_transaction_id = @p_transaction_id
--          AND key_hash NOT IN (SELECT key_hash FROM ica_flow_icis.dbo.ica_basic_prmt)
--     GROUP BY prmt_ident, key_hash;

--  -- Add keys that already exist in ICIS for module ica_bs_prmt
--  INSERT INTO ica_flow_icis.dbo.ica_bs_prmt (ica_payload_id, ica_bs_prmt_id, prmt_ident, key_hash, data_hash)
--       SELECT (SELECT ica_payload_id FROM ica_payload WHERE operation='BiosolidsPermitSubmission') as payload_id, NEWID(), prmt_ident, key_hash, '0' as data_hash
--         FROM ica_subm_rslts
--        WHERE result_code = 'PC040'
--          AND subm_type_name = 'BiosolidsPermitSubmission'
--          AND subm_transaction_id = @p_transaction_id
--          AND key_hash NOT IN (SELECT key_hash FROM ica_flow_icis.dbo.ica_bs_prmt)
--     GROUP BY prmt_ident, key_hash;

--  -- Add keys that already exist in ICIS for module ica_cafo_prmt
--  INSERT INTO ica_flow_icis.dbo.ica_cafo_prmt (ica_payload_id, ica_cafo_prmt_id, prmt_ident, key_hash, data_hash)
--       SELECT (SELECT ica_payload_id FROM ica_payload WHERE operation='CAFOPermitSubmission') as payload_id, NEWID(), prmt_ident, key_hash, '0' as data_hash
--         FROM ica_subm_rslts
--        WHERE result_code = 'PC040'
--          AND subm_type_name = 'CAFOPermitSubmission'
--          AND subm_transaction_id = @p_transaction_id
--          AND key_hash NOT IN (SELECT key_hash FROM ica_flow_icis.dbo.ica_cafo_prmt)
--     GROUP BY prmt_ident, key_hash;

--  -- Add keys that already exist in ICIS for module ica_cso_prmt
--  INSERT INTO ica_flow_icis.dbo.ica_cso_prmt (ica_payload_id, ica_cso_prmt_id, prmt_ident, key_hash, data_hash)
--       SELECT (SELECT ica_payload_id FROM ica_payload WHERE operation='CSOPermitSubmission') as payload_id, NEWID(), prmt_ident, key_hash, '0' as data_hash
--         FROM ica_subm_rslts
--        WHERE result_code = 'PC040'
--          AND subm_type_name = 'CSOPermitSubmission'
--          AND subm_transaction_id = @p_transaction_id
--          AND key_hash NOT IN (SELECT key_hash FROM ica_flow_icis.dbo.ica_cso_prmt)
--     GROUP BY prmt_ident, key_hash;

--  -- Add keys that already exist in ICIS for module ica_gnrl_prmt
--  INSERT INTO ica_flow_icis.dbo.ica_gnrl_prmt (ica_payload_id, ica_gnrl_prmt_id, prmt_ident, key_hash, data_hash)
--       SELECT (SELECT ica_payload_id FROM ica_payload WHERE operation='GeneralPermitSubmission') as payload_id, NEWID(), prmt_ident, key_hash, '0' as data_hash
--         FROM ica_subm_rslts
--        WHERE result_code = 'BP060'
--          AND subm_type_name = 'GeneralPermitSubmission'
--          AND subm_transaction_id = @p_transaction_id
--          AND key_hash NOT IN (SELECT key_hash FROM ica_flow_icis.dbo.ica_gnrl_prmt)
--     GROUP BY prmt_ident, key_hash;
     
--  -- Add keys that already exist in ICIS for module ica_master_gnrl_prmt
--  INSERT INTO ica_flow_icis.dbo.ica_master_gnrl_prmt (ica_payload_id, ica_master_gnrl_prmt_id, prmt_ident, key_hash, data_hash)
--       SELECT (SELECT ica_payload_id FROM ica_payload WHERE operation='MasterGeneralPermitSubmission') as payload_id, NEWID(), prmt_ident, key_hash, '0' as data_hash
--         FROM ica_subm_rslts
--        WHERE result_code = 'MGP040'
--          AND subm_type_name = 'MasterGeneralPermitSubmission'
--          AND subm_transaction_id = @p_transaction_id
--          AND key_hash NOT IN (SELECT key_hash FROM ica_flow_icis.dbo.ica_master_gnrl_prmt)
--     GROUP BY prmt_ident, key_hash;

--  -- Add keys that already exist in ICIS for module ica_prmt_track_evt
--  INSERT INTO ica_flow_icis.dbo.ica_prmt_track_evt (ica_payload_id, ica_prmt_track_evt_id, prmt_ident,  prmt_track_evt_code,  prmt_track_evt_date, key_hash, data_hash)
--       SELECT (SELECT ica_payload_id FROM ica_payload WHERE operation='PermitTrackingEventSubmission') as payload_id, NEWID(), prmt_ident,  prmt_track_evt_code,  prmt_track_evt_date, key_hash, '0' as data_hash
--         FROM ica_subm_rslts
--        WHERE result_code = 'PTE030'
--          AND subm_type_name = 'PermitTrackingEventSubmission'
--          AND subm_transaction_id = @p_transaction_id
--          AND key_hash NOT IN (SELECT key_hash FROM ica_flow_icis.dbo.ica_prmt_track_evt)
--     GROUP BY prmt_ident,  prmt_track_evt_code,  prmt_track_evt_date, key_hash;

--  -- Add keys that already exist in ICIS for module ica_potw_prmt
--  INSERT INTO ica_flow_icis.dbo.ica_potw_prmt (ica_payload_id, ica_potw_prmt_id, prmt_ident, key_hash, data_hash)
--       SELECT (SELECT ica_payload_id FROM ica_payload WHERE operation='POTWPermitSubmission') as payload_id, NEWID(), prmt_ident, key_hash, '0' as data_hash
--         FROM ica_subm_rslts
--        WHERE result_code = 'PC040'
--          AND subm_type_name = 'POTWPermitSubmission'
--          AND subm_transaction_id = @p_transaction_id
--          AND key_hash NOT IN (SELECT key_hash FROM ica_flow_icis.dbo.ica_potw_prmt)
--     GROUP BY prmt_ident, key_hash;

--  -- Add keys that already exist in ICIS for module ica_pretr_prmt
--  INSERT INTO ica_flow_icis.dbo.ica_pretr_prmt (ica_payload_id, ica_pretr_prmt_id, prmt_ident, key_hash, data_hash)
--       SELECT (SELECT ica_payload_id FROM ica_payload WHERE operation='PretreatmentPermitSubmission') as payload_id, NEWID(), prmt_ident, key_hash, '0' as data_hash
--         FROM ica_subm_rslts
--        WHERE result_code = 'PC040'
--          AND subm_type_name = 'PretreatmentPermitSubmission'
--          AND subm_transaction_id = @p_transaction_id
--          AND key_hash NOT IN (SELECT key_hash FROM ica_flow_icis.dbo.ica_pretr_prmt)
--     GROUP BY prmt_ident, key_hash;

--  -- Add keys that already exist in ICIS for module ica_sw_cnst_prmt
--  INSERT INTO ica_flow_icis.dbo.ica_sw_cnst_prmt (ica_payload_id, ica_sw_cnst_prmt_id, prmt_ident, key_hash, data_hash)
--       SELECT (SELECT ica_payload_id FROM ica_payload WHERE operation='SWConstructionPermitSubmission') as payload_id, NEWID(), prmt_ident, key_hash, '0' as data_hash
--         FROM ica_subm_rslts
--        WHERE result_code = 'PC040'
--          AND subm_type_name = 'SWConstructionPermitSubmission'
--          AND subm_transaction_id = @p_transaction_id
--          AND key_hash NOT IN (SELECT key_hash FROM ica_flow_icis.dbo.ica_sw_cnst_prmt)
--     GROUP BY prmt_ident, key_hash;

--  -- Add keys that already exist in ICIS for module ica_sw_indst_prmt
--  INSERT INTO ica_flow_icis.dbo.ica_sw_indst_prmt (ica_payload_id, ica_sw_indst_prmt_id, prmt_ident, key_hash, data_hash)
--       SELECT (SELECT ica_payload_id FROM ica_payload WHERE operation='SWIndustrialPermitSubmission') as payload_id, NEWID(), prmt_ident, key_hash, '0' as data_hash
--         FROM ica_subm_rslts
--        WHERE result_code = 'PC040'
--          AND subm_type_name = 'SWIndustrialPermitSubmission'
--          AND subm_transaction_id = @p_transaction_id
--          AND key_hash NOT IN (SELECT key_hash FROM ica_flow_icis.dbo.ica_sw_indst_prmt)
--     GROUP BY prmt_ident, key_hash;

--  -- Add keys that already exist in ICIS for module ica_swms_4_large_prmt
--  INSERT INTO ica_flow_icis.dbo.ica_swms_4_large_prmt (ica_payload_id, ica_swms_4_large_prmt_id, prmt_ident, key_hash, data_hash)
--       SELECT (SELECT ica_payload_id FROM ica_payload WHERE operation='SWMS4LargePermitSubmission') as payload_id, NEWID(), prmt_ident, key_hash, '0' as data_hash
--         FROM ica_subm_rslts
--        WHERE result_code = 'PC040'
--          AND subm_type_name = 'SWMS4LargePermitSubmission'
--          AND subm_transaction_id = @p_transaction_id
--          AND key_hash NOT IN (SELECT key_hash FROM ica_flow_icis.dbo.ica_swms_4_large_prmt)
--     GROUP BY prmt_ident, key_hash;

--  -- Add keys that already exist in ICIS for module ica_swms_4_small_prmt
--  INSERT INTO ica_flow_icis.dbo.ica_swms_4_small_prmt (ica_payload_id, ica_swms_4_small_prmt_id, prmt_ident, key_hash, data_hash)
--       SELECT (SELECT ica_payload_id FROM ica_payload WHERE operation='SWMS4SmallPermitSubmission') as payload_id, NEWID(), prmt_ident, key_hash, '0' as data_hash
--         FROM ica_subm_rslts
--        WHERE result_code = 'PC040'
--          AND subm_type_name = 'SWMS4SmallPermitSubmission'
--          AND subm_transaction_id = @p_transaction_id
--          AND key_hash NOT IN (SELECT key_hash FROM ica_flow_icis.dbo.ica_swms_4_small_prmt)
--     GROUP BY prmt_ident, key_hash;

--  -- Add keys that already exist in ICIS for module ica_unprmt_fac
--  INSERT INTO ica_flow_icis.dbo.ica_unprmt_fac (ica_payload_id, ica_unprmt_fac_id, prmt_ident, key_hash, data_hash)
--       SELECT (SELECT ica_payload_id FROM ica_payload WHERE operation='UnpermittedFacilitySubmission') as payload_id, NEWID(), prmt_ident, key_hash, '0' as data_hash
--         FROM ica_subm_rslts
--        WHERE result_code = 'UPF060'
--          AND subm_type_name = 'UnpermittedFacilitySubmission'
--          AND subm_transaction_id = @p_transaction_id
--          AND key_hash NOT IN (SELECT key_hash FROM ica_flow_icis.dbo.ica_unprmt_fac)
--     GROUP BY prmt_ident, key_hash;

--  -- Add keys that already exist in ICIS for module ica_prmt_featr
--  INSERT INTO ica_flow_icis.dbo.ica_prmt_featr (ica_payload_id, ica_prmt_featr_id, prmt_ident,  prmt_featr_ident, key_hash, data_hash)
--       SELECT (SELECT ica_payload_id FROM ica_payload WHERE operation='PermittedFeatureSubmission') as payload_id, NEWID(), prmt_ident,  prmt_featr_ident, key_hash, '0' as data_hash
--         FROM ica_subm_rslts
--        WHERE result_code = 'PF030'
--          AND subm_type_name = 'PermittedFeatureSubmission'
--          AND subm_transaction_id = @p_transaction_id
--          AND key_hash NOT IN (SELECT key_hash FROM ica_flow_icis.dbo.ica_prmt_featr)
--     GROUP BY prmt_ident,  prmt_featr_ident, key_hash;

--  -- Add keys that already exist in ICIS for module ica_lmt_set
--  INSERT INTO ica_flow_icis.dbo.ica_lmt_set (ica_payload_id, ica_lmt_set_id, prmt_ident,  prmt_featr_ident,  lmt_set_designator, LMT_SET_TYPE, key_hash, data_hash)
--       SELECT (SELECT ica_payload_id FROM ica_payload WHERE operation='LimitSetSubmission') as payload_id, NEWID(), prmt_ident,  prmt_featr_ident,  lmt_set_designator, 'S', key_hash, '0' as data_hash
--         FROM ica_subm_rslts
--        WHERE result_code = 'LS060'
--          AND subm_type_name = 'LimitSetSubmission'
--          AND subm_transaction_id = @p_transaction_id
--          AND key_hash NOT IN (SELECT key_hash FROM ica_flow_icis.dbo.ica_lmt_set)
--     GROUP BY prmt_ident,  prmt_featr_ident,  lmt_set_designator, key_hash;

--  -- Add keys that already exist in ICIS for module ica_lmts
--  INSERT INTO ica_flow_icis.dbo.ica_lmts (ica_payload_id, ica_lmts_id, prmt_ident,  prmt_featr_ident,  lmt_set_designator,  param_code,  mon_site_desc_code,  lmt_season_num,  lmt_start_date,  lmt_end_date, key_hash, data_hash)
--       SELECT (SELECT ica_payload_id FROM ica_payload WHERE operation='LimitsSubmission') as payload_id, NEWID(), prmt_ident,  prmt_featr_ident,  lmt_set_designator,  param_code,  mon_site_desc_code,  lmt_season_num,  lmt_start_date,  lmt_end_date, key_hash, '0' as data_hash
--         FROM ica_subm_rslts
--        WHERE result_code = 'LTS050'
--          AND subm_type_name = 'LimitsSubmission'
--          AND subm_transaction_id = @p_transaction_id
--          AND key_hash NOT IN (SELECT key_hash FROM ica_flow_icis.dbo.ica_lmts)
--     GROUP BY prmt_ident,  prmt_featr_ident,  lmt_set_designator,  param_code,  mon_site_desc_code,  lmt_season_num,  lmt_start_date,  lmt_end_date, key_hash;

--  -- Add keys that already exist in ICIS for module ica_cmpl_mon
--  INSERT INTO ica_flow_icis.dbo.ica_cmpl_mon (ica_payload_id, ica_cmpl_mon_id, prmt_ident,  cmpl_mon_catg_code,  cmpl_mon_date, key_hash, data_hash)
--       SELECT (SELECT ica_payload_id FROM ica_payload WHERE operation='ComplianceMonitoringSubmission') as payload_id, NEWID(), prmt_ident,  cmpl_mon_catg_code,  cmpl_mon_date, key_hash, '0' as data_hash
--         FROM ica_subm_rslts
--        WHERE result_code = 'CM030'
--          AND subm_type_name = 'ComplianceMonitoringSubmission'
--          AND subm_transaction_id = @p_transaction_id
--          AND key_hash NOT IN (SELECT key_hash FROM ica_flow_icis.dbo.ica_cmpl_mon)
--     GROUP BY prmt_ident,  cmpl_mon_catg_code,  cmpl_mon_date, key_hash;

--  -- Add keys that already exist in ICIS for module ica_efflu_trade_prtner
--  INSERT INTO ica_flow_icis.dbo.ica_efflu_trade_prtner (ica_payload_id, ica_efflu_trade_prtner_id, prmt_ident,  prmt_featr_ident,  lmt_set_designator,  param_code,  mon_site_desc_code,  lmt_season_num,  lmt_start_date,  lmt_end_date,  lmt_mod_effective_date,  trade_id, key_hash, data_hash)
--       SELECT (SELECT ica_payload_id FROM ica_payload WHERE operation='EffluentTradePartnerSubmission') as payload_id, NEWID(), prmt_ident,  prmt_featr_ident,  lmt_set_designator,  param_code,  mon_site_desc_code,  lmt_season_num,  lmt_start_date,  lmt_end_date,  lmt_mod_effective_date,  trade_id, key_hash, '0' as data_hash
--         FROM ica_subm_rslts
--        WHERE result_code = 'ETP030'
--          AND subm_type_name = 'EffluentTradePartnerSubmission'
--          AND subm_transaction_id = @p_transaction_id
--          AND key_hash NOT IN (SELECT key_hash FROM ica_flow_icis.dbo.ica_efflu_trade_prtner)
--     GROUP BY prmt_ident,  prmt_featr_ident,  lmt_set_designator,  param_code,  mon_site_desc_code,  lmt_season_num,  lmt_start_date,  lmt_end_date,  lmt_mod_effective_date,  trade_id, key_hash;

--  -- Add keys that already exist in ICIS for module ica_frml_enfrc_actn
--  INSERT INTO ica_flow_icis.dbo.ica_frml_enfrc_actn (ica_payload_id, ica_frml_enfrc_actn_id, enfrc_actn_ident, key_hash, data_hash)
--       SELECT (SELECT ica_payload_id FROM ica_payload WHERE operation='FormalEnforcementActionSubmission') as payload_id, NEWID(), enfrc_actn_ident, key_hash, '0' as data_hash
--         FROM ica_subm_rslts
--        WHERE result_code = 'FEA030'
--          AND subm_type_name = 'FormalEnforcementActionSubmission'
--          AND subm_transaction_id = @p_transaction_id
--          AND key_hash NOT IN (SELECT key_hash FROM ica_flow_icis.dbo.ica_frml_enfrc_actn)
--     GROUP BY enfrc_actn_ident, key_hash;

--  -- Add keys that already exist in ICIS for module ica_infrml_enfrc_actn
--  INSERT INTO ica_flow_icis.dbo.ica_infrml_enfrc_actn (ica_payload_id, ica_infrml_enfrc_actn_id, enfrc_actn_ident, key_hash, data_hash)
--       SELECT (SELECT ica_payload_id FROM ica_payload WHERE operation='InformalEnforcementActionSubmission') as payload_id, NEWID(), enfrc_actn_ident, key_hash, '0' as data_hash
--         FROM ica_subm_rslts
--        WHERE result_code IN ('IEA030','FEA030') --added FEA030 because ICIS returns wrong error code in this case 12/27/2012 BRensmith
--          AND subm_type_name = 'InformalEnforcementActionSubmission'
--          AND subm_transaction_id = @p_transaction_id
--          AND key_hash NOT IN (SELECT key_hash FROM ica_flow_icis.dbo.ica_infrml_enfrc_actn)
--     GROUP BY enfrc_actn_ident, key_hash;

--  -- Add keys that already exist in ICIS for module ica_sngl_evt_viol
--  INSERT INTO ica_flow_icis.dbo.ica_sngl_evt_viol (ica_payload_id, ica_sngl_evt_viol_id, prmt_ident,  sngl_evt_viol_code,  sngl_evt_viol_date, key_hash, data_hash)
--       SELECT (SELECT ica_payload_id FROM ica_payload WHERE operation='SingleEventViolationSubmission') as payload_id, NEWID(), prmt_ident,  sngl_evt_viol_code,  sngl_evt_viol_date, key_hash, '0' as data_hash
--         FROM ica_subm_rslts
--        WHERE result_code = 'SEV030'
--          AND subm_type_name = 'SingleEventViolationSubmission'
--          AND subm_transaction_id = @p_transaction_id
--          AND key_hash NOT IN (SELECT key_hash FROM ica_flow_icis.dbo.ica_sngl_evt_viol)
--     GROUP BY prmt_ident,  sngl_evt_viol_code,  sngl_evt_viol_date, key_hash;

--Step 5: Record counts into ICA_SUBM_HIST

--Step 6: Record counts into ICA_SUBM_HIST

INSERT INTO ica_subm_hist (
       ica_subm_hist_id
     , subm_date_time
     , subm_transaction_id
     , subm_type_name
     --, trans_count_new
     , trans_count_chng_repl
     , trans_count_del_mass_del
     , error_count
     , warning_count
     , accepted_count
     , accepted_count_total
     , created_date_time)
SELECT NEWID() AS ica_subm_hist_id
     , subm_date_time
     , subm_transaction_id 
     , subm_type_name
     --, trans_count_new
     , trans_count_chng_repl
     , trans_count_del_mass_del
     , error_count
     , warning_count
     , accepted_count
     , accepted_count_total
     , GETDATE() AS created_date_time
  FROM ica_v_module_count;

GO

/*
Copyright (c) 2014, The Environmental Council of the States (ECOS)
All rights reserved.
 
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
 
 * Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
 * Neither the name of the ECOS nor the names of its contributors may
   be used to endorse or promote products derived from this software
   without specific prior written permission.
 
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/

USE [ICA_FLOW_LOCAL]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.ICA_ICIS_HASH_INITIALIZATION') AND type = N'P')
DROP PROCEDURE dbo.ICA_ICIS_HASH_INITIALIZATION
GO

/******************************************************************************************************************************
** Object Name: ICA_ICIS_HASH_INITIALIZATION
**
** Author: Windsor Solutions, Inc.
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure initializes both the key and data hash columns for all enabled ICIS payloads.
**
** Inputs:  -- NA --  
**
**
** Revision History:      
** ----------------------------------------------------------------------------------------------------------------------------
**  Date         Analyst     Description
** ----------------------------------------------------------------------------------------------------------------------------
** 10/16/2014    KJames      Created
** 03/09/2015    KJames      Added fully qualified table references for linkage table key hashing to resolve SQL 2014
**                           code compatibility issues. (Msg 1013)
** 07/06/2015    KJames      Added hash processing for new staging table ICA_DEMND_STIPULTD_PNLTY.
**
******************************************************************************************************************************/
CREATE PROCEDURE [dbo].[ICA_ICIS_HASH_INITIALIZATION] AS

SET NOCOUNT ON;

DECLARE @v_sql_statement AS NVARCHAR(4000);
DECLARE @v_sql_param AS NVARCHAR(100);
DECLARE @p_payload_type AS NVARCHAR(50); 

/* Working Hash Variables */
DECLARE @v_data_hash AS VARCHAR(100);
DECLARE @v_key_hash AS VARCHAR(100);
DECLARE @v_all_data_hashes AS VARCHAR(100);  
DECLARE @v_hashed_data_hashes AS VARCHAR(100); 
DECLARE @v_enabled AS CHAR(1);
DECLARE @v_enabled_val AS CHAR(1);

DECLARE payload_type_delete CURSOR 
    FOR SELECT DISTINCT child_table.name child_table_name 
          FROM sys.foreign_key_columns
          JOIN sys.objects child_table
            ON (child_table.object_id = foreign_key_columns.parent_object_id)
          JOIN sys.objects parent_table
            ON (parent_table.object_id = foreign_key_columns.referenced_object_id)
          JOIN sys.schemas
            ON (parent_table.schema_id = schemas.schema_id)    
         WHERE schemas.name = 'dbo'
           AND parent_table.name = 'ICA_PAYLOAD'
         ORDER BY child_table.name;        
         
DECLARE payload_type_process CURSOR 
    FOR SELECT DISTINCT child_table.name child_table_name 
          FROM sys.foreign_key_columns
          JOIN sys.objects child_table
            ON (child_table.object_id = foreign_key_columns.parent_object_id)
          JOIN sys.objects parent_table
            ON (parent_table.object_id = foreign_key_columns.referenced_object_id)
          JOIN sys.schemas
            ON (parent_table.schema_id = schemas.schema_id)    
         WHERE schemas.name = 'dbo'
           AND parent_table.name = 'ICA_PAYLOAD'
           /* The tables in this list will not have related child data, change processing can be skipped */
           AND child_table.name NOT IN ( 'ICA_BS_PROG_REP'
                                       , 'ICA_CSO_EVT_REP'
                                       , 'ICA_DMR_VIOL'
                                       , 'ICA_ENFRC_ACTN_MILESTONE'
                                       , 'ICA_HIST_PRMT_SCHD_EVTS'
                                       , 'ICA_PRMT_REISSU'
                                       , 'ICA_PRMT_TRACK_EVT'
                                       , 'ICA_PRMT_TERM'
                                       , 'ICA_SCHD_EVT_VIOL'
                                       , 'ICA_SNGL_EVT_VIOL'
                                       , 'ICA_SSO_ANNUL_REP'
                                       , 'ICA_SSO_MONTHLY_EVT_REP')
         ORDER BY child_table.name; 
          
                        
DECLARE key_hash CURSOR 
    FOR SELECT ica_key_hash.key_hash 
          FROM ica_key_hash;
                      
DECLARE data_hash CURSOR 
    FOR SELECT ica_data_hash.data_hash 
          FROM ica_data_hash
        ORDER BY data_hash;
                        
BEGIN

 /*  Initialize working table ICA_KEY_HASH */
 DELETE FROM ica_key_hash;

 /*  Initialize working table ICA_DATA_HASH */
 DELETE FROM ica_data_hash;
 
 /*  
  * Reset transaction_type on all payload tables  
  */
  OPEN payload_type_delete;
  
  
  
  /*  Fetch 1st payload type record */
  FETCH NEXT FROM payload_type_delete INTO @p_payload_type;
  WHILE @@FETCH_STATUS = 0
    BEGIN

      /* For each payload type, remove all the transaction codes from the previous run. */
      SET @v_sql_statement = 'UPDATE ' + @p_payload_type + ' SET TRANSACTION_TYPE = NULL , TRANSACTION_TIMESTAMP = NULL';
      EXECUTE sp_executesql @v_sql_statement;

      -- Get the payload type.
      FETCH NEXT FROM payload_type_delete 
      INTO @p_payload_type;

    END;

   CLOSE payload_type_delete;
  
  /*************************************************/  
  /* START - Set all KEY_HASH and DATA_HASH fields */
  /*************************************************/  
  UPDATE ica_flow_icis.dbo.ica_case_file_cmnt_txt
      SET data_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', 
	    case_file_cmnt_txt
  );
  UPDATE ica_flow_icis.dbo.ica_case_file_lnk
      SET data_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', 
	    ISNULL(src_systm_ident,'')
	  + case_file_ident
  );
  UPDATE ica_flow_icis.dbo.ica_cmpl_insp_type
      SET data_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', 
	    cmpl_insp_type_code
  );
  UPDATE ica_flow_icis.dbo.ica_cmpl_mon_lnk
      SET data_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', 
	    ISNULL(src_systm_ident,'')
	  + cmpl_mon_ident
  );
  UPDATE ica_flow_icis.dbo.ica_cmpl_mon_strgy
     SET key_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', ica_flow_icis.dbo.ica_cmpl_mon_strgy.fac_ident),
        data_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', 
	    ISNULL(src_systm_ident,'')
	  + fac_ident
	  + ISNULL(cms_src_catg_code,'')
	  + ISNULL(CONVERT(varchar(50), cms_min_freq),'')
	  + ISNULL(CONVERT(varchar(50), cms_start_date),'')
	  + ISNULL(active_cms_plan_ind,'')
	  + ISNULL(CONVERT(varchar(50), rmvd_plan_date),'')
	  + ISNULL(rsn_chng_cms_cmnts,'')
  );
  UPDATE ica_flow_icis.dbo.ica_cntct
      SET data_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', 
	    affil_type_txt
	  + first_name
	  + ISNULL(middle_name,'')
	  + last_name
	  + indvl_title_txt
	  + ISNULL(org_frml_name,'')
	  + ISNULL(st_code,'')
	  + ISNULL(rgn_code,'')
	  + ISNULL(elec_addr_txt,'')
	  + ISNULL(CONVERT(varchar(50), start_date_of_cntct_assc),'')
	  + ISNULL(CONVERT(varchar(50), end_date_of_cntct_assc),'')
  );
  UPDATE ica_flow_icis.dbo.ica_da_case_file
     SET key_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', ica_flow_icis.dbo.ica_da_case_file.case_file_ident),
        data_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', 
	    ISNULL(src_systm_ident,'')
	  + case_file_ident
	  + ISNULL(case_file_name,'')
	  + ISNULL(lead_agncy_code,'')
	  + fac_ident
	  + ISNULL(othr_prog_desc_txt,'')
	  + ISNULL(sens_data_ind,'')
	  + ISNULL(lead_agncy_chng_sprsed_txt,'')
	  + ISNULL(advise_method_type_code,'')
	  + ISNULL(CONVERT(varchar(50), advise_method_date),'')
	  + ISNULL(case_file_usr_def_fld_1,'')
	  + ISNULL(case_file_usr_def_fld_2,'')
	  + ISNULL(case_file_usr_def_fld_3,'')
	  + ISNULL(CONVERT(varchar(50), case_file_usr_def_fld_4),'')
	  + ISNULL(CONVERT(varchar(50), case_file_usr_def_fld_5),'')
	  + ISNULL(case_file_usr_def_fld_6,'')
  );
  UPDATE ica_flow_icis.dbo.ica_da_cmpl_mon
     SET key_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', ica_flow_icis.dbo.ica_da_cmpl_mon.cmpl_mon_ident),
        data_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', 
	    ISNULL(src_systm_ident,'')
	  + cmpl_mon_ident
	  + ISNULL(cmpl_mon_acty_type_code,'')
	  + ISNULL(CONVERT(varchar(50), cmpl_mon_date),'')
	  + ISNULL(CONVERT(varchar(50), cmpl_mon_start_date),'')
	  + ISNULL(cmpl_mon_acty_name,'')
	  + ISNULL(multimedia_ind,'')
	  + ISNULL(CONVERT(varchar(50), cmpl_mon_planned_start_date),'')
	  + ISNULL(CONVERT(varchar(50), cmpl_mon_planned_end_date),'')
	  + ISNULL(deficiencies_obs_ind,'')
	  + ISNULL(lead_agncy_code,'')
	  + ISNULL(othr_prog_desc_txt,'')
	  + ISNULL(othr_agncy_initiative_txt,'')
	  + ISNULL(insp_usr_def_fld_1,'')
	  + ISNULL(insp_usr_def_fld_2,'')
	  + ISNULL(insp_usr_def_fld_3,'')
	  + ISNULL(CONVERT(varchar(50), insp_usr_def_fld_4),'')
	  + ISNULL(CONVERT(varchar(50), insp_usr_def_fld_5),'')
	  + ISNULL(insp_usr_def_fld_6,'')
  );
  UPDATE ica_flow_icis.dbo.ica_da_enfrc_actn_lnk
     SET key_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', ica_flow_icis.dbo.ica_da_enfrc_actn_lnk.da_enfrc_actn_ident),
        data_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', 
	    ISNULL(src_systm_ident,'')
	  + da_enfrc_actn_ident
  );
  UPDATE ica_flow_icis.dbo.ica_da_enfrc_actn_milstn
     SET key_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', ica_flow_icis.dbo.ica_da_enfrc_actn_milstn.da_enfrc_actn_ident + milstn_type_code),
        data_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', 
	    ISNULL(src_systm_ident,'')
	  + da_enfrc_actn_ident
	  + milstn_type_code
	  + ISNULL(CONVERT(varchar(50), milstn_planned_date),'')
	  + ISNULL(CONVERT(varchar(50), milstn_actual_date),'')
  );
  UPDATE ica_flow_icis.dbo.ica_da_final_order
      SET data_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', 
	    CONVERT(varchar(50), final_order_ident)
	  + ISNULL(final_order_type_code,'')
	  + ISNULL(CONVERT(varchar(50), final_order_issued_enterd_date),'')
	  + ISNULL(CONVERT(varchar(50), rslvd_date),'')
	  + ISNULL(CONVERT(varchar(50), cash_civil_pnlty_reqd_amt),'')
	  + ISNULL(othr_cmnts,'')
  );
  UPDATE ica_flow_icis.dbo.ica_da_frml_enfrc_actn
     SET key_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', ica_flow_icis.dbo.ica_da_frml_enfrc_actn.da_enfrc_actn_ident),
        data_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', 
	    ISNULL(src_systm_ident,'')
	  + da_enfrc_actn_ident
	  + ISNULL(enfrc_actn_name,'')
	  + ISNULL(forum,'')
	  + ISNULL(resl_type_code,'')
	  + ISNULL(da_comb_sprsed_eaid,'')
	  + ISNULL(rsn_del_rec,'')
	  + ISNULL(frml_ea_usr_def_fld_1,'')
	  + ISNULL(frml_ea_usr_def_fld_2,'')
	  + ISNULL(frml_ea_usr_def_fld_3,'')
	  + ISNULL(CONVERT(varchar(50), frml_ea_usr_def_fld_4),'')
	  + ISNULL(CONVERT(varchar(50), frml_ea_usr_def_fld_5),'')
	  + ISNULL(frml_ea_usr_def_fld_6,'')
	  + ISNULL(lead_agncy_code,'')
	  + ISNULL(enfrc_agncy_name,'')
	  + ISNULL(othr_agncy_initiative_txt,'')
	  + ISNULL(othr_prog_desc_txt,'')
  );
  UPDATE ica_flow_icis.dbo.ica_da_infrml_enfrc_actn
     SET key_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', ica_flow_icis.dbo.ica_da_infrml_enfrc_actn.da_enfrc_actn_ident),
        data_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', 
	    ISNULL(src_systm_ident,'')
	  + da_enfrc_actn_ident
	  + ISNULL(enfrc_actn_type_code,'')
	  + ISNULL(enfrc_actn_name,'')
	  + ISNULL(CONVERT(varchar(50), achieved_date),'')
	  + ISNULL(file_num,'')
	  + ISNULL(rsn_del_rec,'')
	  + ISNULL(infrml_ea_usr_def_fld_1,'')
	  + ISNULL(infrml_ea_usr_def_fld_2,'')
	  + ISNULL(infrml_ea_usr_def_fld_3,'')
	  + ISNULL(CONVERT(varchar(50), infrml_ea_usr_def_fld_4),'')
	  + ISNULL(CONVERT(varchar(50), infrml_ea_usr_def_fld_5),'')
	  + ISNULL(infrml_ea_usr_def_fld_6,'')
	  + ISNULL(lead_agncy_code,'')
	  + ISNULL(enfrc_agncy_name,'')
	  + ISNULL(othr_agncy_initiative_txt,'')
	  + ISNULL(st_sects_viol_txt,'')
	  + ISNULL(othr_prog_desc_txt,'')
  );
  UPDATE ica_flow_icis.dbo.ica_enfrc_actn_cmnt_txt
      SET data_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', 
	    enfrc_actn_cmnt_txt
  );
  UPDATE ica_flow_icis.dbo.ica_enfrc_actn_gov_cntct
      SET data_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', 
	    affil_type_txt
	  + ISNULL(elec_addr_txt,'')
	  + ISNULL(CONVERT(varchar(50), start_date_of_cntct_assc),'')
	  + ISNULL(CONVERT(varchar(50), end_date_of_cntct_assc),'')
  );
  UPDATE ica_flow_icis.dbo.ica_enfrc_actn_type
      SET data_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', 
	    enfrc_actn_type_code
  );
  UPDATE ica_flow_icis.dbo.ica_enfrc_agncy_type
      SET data_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', 
	    enfrc_agncy_type_code
  );
  UPDATE ica_flow_icis.dbo.ica_fac
     SET key_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', ica_flow_icis.dbo.ica_fac.fac_ident),
        data_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', 
	    ISNULL(src_systm_ident,'')
	  + fac_ident
	  + ISNULL(fac_site_name,'')
	  + ISNULL(loc_addr_txt,'')
	  + ISNULL(suppl_loc_txt,'')
	  + ISNULL(loc_addr_city_code,'')
	  + ISNULL(loc_st_code,'')
	  + ISNULL(loc_zip_code,'')
	  + ISNULL(lcon_code,'')
	  + ISNULL(tribal_land_code,'')
	  + ISNULL(fac_desc,'')
	  + ISNULL(fac_type_of_owner_code,'')
	  + ISNULL(reg_num,'')
	  + ISNULL(small_busnss_ind,'')
	  + ISNULL(federally_rep_ind,'')
	  + ISNULL(src_unifm_rsrc_locator_url,'')
	  + ISNULL(envr_justice_code,'')
	  + ISNULL(CONVERT(varchar(50), fac_congr_district_num),'')
	  + ISNULL(fac_usr_def_fld_1,'')
	  + ISNULL(fac_usr_def_fld_2,'')
	  + ISNULL(fac_usr_def_fld_3,'')
	  + ISNULL(fac_usr_def_fld_4,'')
	  + ISNULL(fac_usr_def_fld_5,'')
	  + ISNULL(fac_cmnts,'')
	  + ISNULL(port_src_ind,'')
	  + ISNULL(locality_name,'')
	  + ISNULL(loc_addr_county_code,'')


  );
  UPDATE ica_flow_icis.dbo.ica_fac_addr
      SET data_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', 
	    affil_type_txt
	  + ISNULL(org_frml_name,'')
	  + ISNULL(org_duns_num,'')
	  + ISNULL(mailing_addr_txt,'')
	  + ISNULL(suppl_addr_txt,'')
	  + ISNULL(mailing_addr_city_name,'')
	  + ISNULL(mailing_addr_st_code,'')
	  + ISNULL(mailing_addr_zip_code,'')
	  + ISNULL(county_name,'')
	  + ISNULL(mailing_addr_country_code,'')
	  + ISNULL(division_name,'')
	  + ISNULL(loc_province,'')
	  + ISNULL(elec_addr_txt,'')
	  + ISNULL(CONVERT(varchar(50), start_date_of_addr_assc),'')
	  + ISNULL(CONVERT(varchar(50), end_date_of_addr_assc),'')
  );
  UPDATE ica_flow_icis.dbo.ica_fac_ident
      SET data_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', 
	    fac_ident
  );
  UPDATE ica_flow_icis.dbo.ica_final_order_fac_ident
      SET data_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', 
	    final_order_fac_ident
  );
  UPDATE ica_flow_icis.dbo.ica_demnd_stipultd_pnlty
      SET data_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', 
      ISNULL(CONVERT(varchar(50), demnd_stipultd_pnlty_amt),'')
	  + ISNULL(CONVERT(varchar(50), demnd_stipultd_pnlty_paid_date),'')
  );
  UPDATE ica_flow_icis.dbo.ica_geo_coord
      SET data_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', 
	    ISNULL(lat_meas,'')
	  + ISNULL(long_meas,'')
	  + ISNULL(CONVERT(varchar(50), horz_accuracy_meas),'')
	  + ISNULL(geom_type_code,'')
	  + ISNULL(horz_coll_method_code,'')
	  + ISNULL(horz_ref_datum_code,'')
	  + ISNULL(ref_point_code,'')
	  + ISNULL(CONVERT(varchar(50), src_map_scale_num),'')
	  + ISNULL(utm_coord_1,'')
	  + ISNULL(utm_coord_2,'')
	  + ISNULL(utm_coord_3,'')
  );
  UPDATE ica_flow_icis.dbo.ica_infrml_ea_cmnt_txt
      SET data_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', 
	    infrml_ea_cmnt_txt
  );
  UPDATE ica_flow_icis.dbo.ica_insp_cmnt_txt
      SET data_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', 
	    insp_cmnt_txt
  );
  UPDATE ica_flow_icis.dbo.ica_insp_gov_cntct
      SET data_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', 
	    affil_type_txt
	  + ISNULL(elec_addr_txt,'')
  );
  UPDATE ica_flow_icis.dbo.ica_lnk_case_file
      SET data_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', 
	    case_file_ident
  );
  UPDATE ica_flow_icis.dbo.ica_lnk_cmpl_mon
      SET data_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', 
	    cmpl_mon_ident
  );
  UPDATE ica_flow_icis.dbo.ica_lnk_da_enfrc_actn
      SET data_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', 
	    da_enfrc_actn_ident
  );
  UPDATE ica_flow_icis.dbo.ica_method
      SET data_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', 
	    method_code
  );
  UPDATE ica_flow_icis.dbo.ica_naics_code
      SET data_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', 
	    naics_code
	  + naics_pri_ind_code
  );
  UPDATE ica_flow_icis.dbo.ica_nat_prio
      SET data_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', 
	    CONVERT(varchar(50), nat_prio_code)
  );
  UPDATE ica_flow_icis.dbo.ica_othr_pathway_acty
      SET data_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', 
	    othr_pathway_catg_code
	  + othr_pathway_type_code
	  + CONVERT(varchar(50), othr_pathway_date)
  );
  UPDATE ica_flow_icis.dbo.ica_payload
      SET data_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', 
	    ISNULL(operation,'')
	  + enabled
	  + auto_gen_deletes);

  UPDATE ica_flow_icis.dbo.ica_polut
      SET data_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', 
	    CONVERT(varchar(50), polut_code)
  );
  UPDATE ica_flow_icis.dbo.ica_polut_da_class
      SET data_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', 
	    polut_da_class_code
	  + ISNULL(CONVERT(varchar(50), polut_da_class_start_date),'')
  );
  UPDATE ica_flow_icis.dbo.ica_polut_epa_class
      SET data_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', 
	    polut_epa_class_code
	  + ISNULL(CONVERT(varchar(50), polut_epa_class_start_date),'')
  );
  UPDATE ica_flow_icis.dbo.ica_poluts
     SET key_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', ica_flow_icis.dbo.ica_poluts.fac_ident + CAST(poluts_code AS VARCHAR(255))),
        data_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', 
	    ISNULL(src_systm_ident,'')
	  + fac_ident
	  + ISNULL(CONVERT(varchar(50), poluts_code),'')
	  + ISNULL(polut_stat_ind,'')
  );
  UPDATE ica_flow_icis.dbo.ica_port_src
      SET data_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', 
	  --  port_src_ind
	  --+ 
   port_src_site_name
	  + CONVERT(varchar(50), port_src_start_date)
	  + ISNULL(CONVERT(varchar(50), port_src_end_date),'')
  );
  UPDATE ica_flow_icis.dbo.ica_prog
      SET data_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', 
	    prog_code
  );
  UPDATE ica_flow_icis.dbo.ica_prog_subpart
      SET data_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', 
	    prog_subpart_code
	  + ISNULL(prog_subpart_stat_ind,'')
  );
  UPDATE ica_flow_icis.dbo.ica_progs
     SET key_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', ica_flow_icis.dbo.ica_progs.fac_ident + prog_code),
        data_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', 
	    ISNULL(src_systm_ident,'')
	  + fac_ident
	  + prog_code
	  + ISNULL(othr_prog_desc_txt,'')
	  + prog_oper_stat_code
	  + ISNULL(CONVERT(varchar(50), prog_oper_stat_start_date),'')
  );
  UPDATE ica_flow_icis.dbo.ica_progs_viol
      SET data_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', 
	    progs_viol_code
  );
  UPDATE ica_flow_icis.dbo.ica_rgnl_prio
      SET data_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', 
	    CONVERT(varchar(50), rgnl_prio_code)
  );
  UPDATE ica_flow_icis.dbo.ica_sens_cmnt_txt
      SET data_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', 
	    sens_cmnt_txt
  );
  UPDATE ica_flow_icis.dbo.ica_sic_code
      SET data_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', 
	    sic_code
	  + sic_pri_ind_code
  );
  UPDATE ica_flow_icis.dbo.ica_stck_tst
      SET data_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', 
	    stck_tst_stat_code
	  + stck_tst_cndctr_type_code
	  + ISNULL(stck_ident,'')
	  + ISNULL(othr_stck_tst_purpose_name,'')
	  + ISNULL(CONVERT(varchar(50), stck_tst_rep_rcvd_date),'')
	  + ISNULL(CONVERT(varchar(50), tst_rslts_reviewed_date),'')
  );
  UPDATE ica_flow_icis.dbo.ica_stck_tst_obs_agncy_type
      SET data_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', 
	    stck_tst_obs_agncy_type_code
  );
  UPDATE ica_flow_icis.dbo.ica_stck_tst_purpose
      SET data_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', 
	    stck_tst_purpose_code
  );
  UPDATE ica_flow_icis.dbo.ica_teleph
      SET data_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', 
	    teleph_num_type_code
	  + ISNULL(teleph_num,'')
	  + ISNULL(teleph_ext_num,'')
  );
  UPDATE ica_flow_icis.dbo.ica_tst_rslts
      SET data_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', 
	    CONVERT(varchar(50), tested_polut_code)
	  + ISNULL(tst_result_code,'')
	  + ISNULL(CONVERT(varchar(50), allowable_value),'')
	  + ISNULL(allowable_unit_code,'')
	  + ISNULL(CONVERT(varchar(50), actual_result),'')
	  + ISNULL(failure_rsn_code,'')
	  + ISNULL(othr_failure_rsn_txt,'')
  );
  UPDATE ica_flow_icis.dbo.ica_tvacc
     SET key_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', ica_flow_icis.dbo.ica_tvacc.cmpl_mon_ident),
        data_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', 
	    ISNULL(src_systm_ident,'')
	  + cmpl_mon_ident
	  + ISNULL(CONVERT(varchar(50), cmpl_mon_date),'')
	  + ISNULL(CONVERT(varchar(50), cmpl_mon_start_date),'')
	  + ISNULL(cmpl_mon_acty_name,'')
	  + ISNULL(multimedia_ind,'')
	  + ISNULL(CONVERT(varchar(50), cmpl_mon_planned_start_date),'')
	  + ISNULL(CONVERT(varchar(50), cmpl_mon_planned_end_date),'')
	  + ISNULL(deficiencies_obs_ind,'')
	  + fac_ident
	  + ISNULL(lead_agncy_code,'')
	  + ISNULL(othr_prog_desc_txt,'')
	  + ISNULL(othr_agncy_initiative_txt,'')
	  + ISNULL(insp_usr_def_fld_1,'')
	  + ISNULL(insp_usr_def_fld_2,'')
	  + ISNULL(insp_usr_def_fld_3,'')
	  + ISNULL(CONVERT(varchar(50), insp_usr_def_fld_4),'')
	  + ISNULL(CONVERT(varchar(50), insp_usr_def_fld_5),'')
	  + ISNULL(insp_usr_def_fld_6,'')
	  + ISNULL(prmt_ident,'')
	  + ISNULL(CONVERT(varchar(50), cert_period_start_date),'')
	  + ISNULL(CONVERT(varchar(50), cert_period_end_date),'')
	  + ISNULL(fac_rep_cmpl_stat_code,'')
  );
  UPDATE ica_flow_icis.dbo.ica_tvacc_review
      SET data_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', 
	    CONVERT(varchar(50), tvacc_reviewed_date)
	  + ISNULL(fac_rep_deviations_ind,'')
	  + ISNULL(prmt_conds_txt,'')
	  + ISNULL(exceed_excurs_ind,'')
	  + ISNULL(reviewer_agncy_code,'')
	  + ISNULL(tvacc_reviewer_name,'')
	  + ISNULL(reviewer_cmnt,'')
  );
  UPDATE ica_flow_icis.dbo.ica_universe_ind
      SET data_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', 
	    universe_ind_code
  );
  UPDATE ica_flow_icis.dbo.ica_viol
      SET data_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', 
	    viol_type_code
	  + viol_prog_code
	  + ISNULL(viol_prog_desc_txt,'')
	  + ISNULL(CONVERT(varchar(50), viol_polut_code),'')
	  + ISNULL(CONVERT(varchar(50), frv_dtrmn_date),'')
	  + ISNULL(CONVERT(varchar(50), hpv_day_zero_date),'')
	  + ISNULL(CONVERT(varchar(50), occurrence_start_date),'')
	  + ISNULL(CONVERT(varchar(50), occurrence_end_date),'')
	  + ISNULL(hpv_desgn_rmvl_type_code,'')
	  + ISNULL(CONVERT(varchar(50), hpv_desgn_rmvl_date),'')
	  + ISNULL(CONVERT(varchar(50), claims_num),'')
  );

  /* Linkage Tables */




  UPDATE ica_flow_icis.dbo.ica_cmpl_mon_lnk
     SET key_hash = ica_flow_local.dbo.HASHBYTES_VARCHAR( 'SHA1' , 
                                           ISNULL(ica_cmpl_mon_lnk.src_systm_ident,'')
                                         + ISNULL(ica_cmpl_mon_lnk.cmpl_mon_ident,'')
                                         + ISNULL(ica_lnk_cmpl_mon.cmpl_mon_ident,'')
                                         + ISNULL(ica_lnk_da_enfrc_actn.da_enfrc_actn_ident,''))
    FROM ica_flow_icis.dbo.ica_cmpl_mon_lnk
    LEFT JOIN ica_lnk_cmpl_mon on ica_lnk_cmpl_mon.ica_cmpl_mon_lnk_id = ica_cmpl_mon_lnk.ica_cmpl_mon_lnk_id
    LEFT JOIN ica_lnk_da_enfrc_actn on ica_lnk_da_enfrc_actn.ica_cmpl_mon_lnk_id = ica_cmpl_mon_lnk.ica_cmpl_mon_lnk_id;




  UPDATE ica_flow_icis.dbo.ica_da_enfrc_actn_lnk
     SET key_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR( 'SHA1' , 
                                           ISNULL(ica_da_enfrc_actn_lnk.src_systm_ident,'')
                                         + ISNULL(ica_da_enfrc_actn_lnk.da_enfrc_actn_ident,'')
                                         + ISNULL(ica_lnk_da_enfrc_actn.da_enfrc_actn_ident,''))
    FROM ica_flow_icis.dbo.ica_da_enfrc_actn_lnk
    LEFT JOIN ica_lnk_da_enfrc_actn on ica_lnk_da_enfrc_actn.ica_da_enfrc_actn_lnk_id = ica_da_enfrc_actn_lnk.ica_da_enfrc_actn_lnk_id;


  UPDATE ica_flow_icis.dbo.ica_case_file_lnk
     SET key_hash = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR( 'SHA1' , 
                                           ISNULL(ica_case_file_lnk.src_systm_ident,'')
                                         + ISNULL(ica_case_file_lnk.case_file_ident,'')
                                         + ISNULL(ica_lnk_case_file.case_file_ident,'')
                                         + ISNULL(ica_lnk_cmpl_mon.cmpl_mon_ident,'')
                                         + ISNULL(ica_lnk_da_enfrc_actn.da_enfrc_actn_ident,''))
    FROM ica_flow_icis.dbo.ica_case_file_lnk
    LEFT JOIN ica_lnk_case_file on ica_lnk_case_file.ica_case_file_lnk_id = ica_case_file_lnk.ica_case_file_lnk_id
    LEFT JOIN ica_lnk_cmpl_mon on ica_lnk_cmpl_mon.ica_case_file_lnk_id = ica_case_file_lnk.ica_case_file_lnk_id
    LEFT JOIN ica_lnk_da_enfrc_actn on ica_lnk_da_enfrc_actn.ica_case_file_lnk_id = ica_case_file_lnk.ica_case_file_lnk_id;


  /************************************/  
  /* START - Process DATA_HASH values */
  /* START - Process DATA_HASH values */
  /* START - Process DATA_HASH values */
  /************************************/ 
 
  /* Loop through each payload type, for each loop roll child data_hash values up to the parent payload table */  
  OPEN payload_type_process;

  -- Get 1st payload type
  FETCH NEXT FROM payload_type_process INTO @p_payload_type;
  WHILE @@FETCH_STATUS = 0
    BEGIN

      SET @v_sql_statement = 'SELECT TOP 1 @v_enabled_val = [ENABLED] FROM ICA_PAYLOAD JOIN ' + @p_payload_type +
        ' ON ICA_PAYLOAD.ICA_PAYLOAD_ID = ' + @p_payload_type + '.ICA_PAYLOAD_ID'
      SET @v_sql_param = '@v_enabled_val CHAR(1) OUTPUT';

      EXEC sp_executesql @v_sql_statement, @v_sql_param, @v_enabled_val=@v_enabled OUTPUT;

      SET @v_enabled = ISNULL(@v_enabled, 'N');

      /* Flush the prior payload type's key_hash values */
      DELETE FROM ica_key_hash;
      
      /* Load next key_hash set for current payload type */ 
      SET @v_sql_statement = 'INSERT INTO ica_key_hash SELECT key_hash FROM ' + @p_payload_type; 
      EXECUTE sp_executesql @v_sql_statement;
        
     /* 
      *  Loop through each key in a payload type's key set.  For each key traverse the payload type's data heirarchy
      *  and load the child data_hash values into working table ICA_DATA_HASH for later processing at the end of 
      *  the loop.
      */
      OPEN key_hash;

      /*  Fetch 1st payload type */
      FETCH NEXT FROM key_hash INTO @v_key_hash;
      WHILE @@FETCH_STATUS = 0
        BEGIN    

		    /* Flush the prior payload's data_hash values */
		    DELETE FROM ica_data_hash;

     IF @p_payload_type = 'ICA_CMPL_MON_STRGY' and @v_enabled = 'Y'
        BEGIN

        -- /ICA_CMPL_MON_STRGY
        INSERT INTO ica_data_hash
             SELECT ica_cmpl_mon_strgy.data_hash
               FROM ica_cmpl_mon_strgy
              WHERE ica_cmpl_mon_strgy.key_hash = @v_key_hash;

        END;

     IF @p_payload_type = 'ICA_DA_CMPL_MON' and @v_enabled = 'Y'
        BEGIN

        -- /ICA_DA_CMPL_MON
        INSERT INTO ica_data_hash
             SELECT ica_da_cmpl_mon.data_hash
               FROM ica_da_cmpl_mon
              WHERE ica_da_cmpl_mon.key_hash = @v_key_hash;

        -- /ICA_DA_CMPL_MON/ICA_CMPL_INSP_TYPE
        INSERT INTO ica_data_hash
             SELECT ica_cmpl_insp_type.data_hash
               FROM ica_da_cmpl_mon
               JOIN ica_cmpl_insp_type
                 ON ica_cmpl_insp_type.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
              WHERE ica_da_cmpl_mon.key_hash = @v_key_hash;

        -- /ICA_DA_CMPL_MON/ICA_CNTCT
        INSERT INTO ica_data_hash
             SELECT ica_cntct.data_hash
               FROM ica_da_cmpl_mon
               JOIN ica_cntct
                 ON ica_cntct.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
              WHERE ica_da_cmpl_mon.key_hash = @v_key_hash;

        -- /ICA_DA_CMPL_MON/ICA_CNTCT/ICA_TELEPH
        INSERT INTO ica_data_hash
             SELECT ica_teleph.data_hash
               FROM ica_da_cmpl_mon
               JOIN ica_cntct
                 ON ica_cntct.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
               JOIN ica_teleph
                 ON ica_teleph.ica_cntct_id = ica_cntct.ica_cntct_id
              WHERE ica_da_cmpl_mon.key_hash = @v_key_hash;

        -- /ICA_DA_CMPL_MON/ICA_FAC_IDENT
        INSERT INTO ica_data_hash
             SELECT ica_fac_ident.data_hash
               FROM ica_da_cmpl_mon
               JOIN ica_fac_ident
                 ON ica_fac_ident.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
              WHERE ica_da_cmpl_mon.key_hash = @v_key_hash;

        -- /ICA_DA_CMPL_MON/ICA_INSP_CMNT_TXT
        INSERT INTO ica_data_hash
             SELECT ica_insp_cmnt_txt.data_hash
               FROM ica_da_cmpl_mon
               JOIN ica_insp_cmnt_txt
                 ON ica_insp_cmnt_txt.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
              WHERE ica_da_cmpl_mon.key_hash = @v_key_hash;

        -- /ICA_DA_CMPL_MON/ICA_INSP_GOV_CNTCT
        INSERT INTO ica_data_hash
             SELECT ica_insp_gov_cntct.data_hash
               FROM ica_da_cmpl_mon
               JOIN ica_insp_gov_cntct
                 ON ica_insp_gov_cntct.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
              WHERE ica_da_cmpl_mon.key_hash = @v_key_hash;

        -- /ICA_DA_CMPL_MON/ICA_NAT_PRIO
        INSERT INTO ica_data_hash
             SELECT ica_nat_prio.data_hash
               FROM ica_da_cmpl_mon
               JOIN ica_nat_prio
                 ON ica_nat_prio.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
              WHERE ica_da_cmpl_mon.key_hash = @v_key_hash;

        -- /ICA_DA_CMPL_MON/ICA_POLUT
        INSERT INTO ica_data_hash
             SELECT ica_polut.data_hash
               FROM ica_da_cmpl_mon
               JOIN ica_polut
                 ON ica_polut.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
              WHERE ica_da_cmpl_mon.key_hash = @v_key_hash;

        -- /ICA_DA_CMPL_MON/ICA_PROG
        INSERT INTO ica_data_hash
             SELECT ica_prog.data_hash
               FROM ica_da_cmpl_mon
               JOIN ica_prog
                 ON ica_prog.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
              WHERE ica_da_cmpl_mon.key_hash = @v_key_hash;

        -- /ICA_DA_CMPL_MON/ICA_RGNL_PRIO
        INSERT INTO ica_data_hash
             SELECT ica_rgnl_prio.data_hash
               FROM ica_da_cmpl_mon
               JOIN ica_rgnl_prio
                 ON ica_rgnl_prio.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
              WHERE ica_da_cmpl_mon.key_hash = @v_key_hash;

        -- /ICA_DA_CMPL_MON/ICA_SENS_CMNT_TXT
        INSERT INTO ica_data_hash
             SELECT ica_sens_cmnt_txt.data_hash
               FROM ica_da_cmpl_mon
               JOIN ica_sens_cmnt_txt
                 ON ica_sens_cmnt_txt.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
              WHERE ica_da_cmpl_mon.key_hash = @v_key_hash;

        -- /ICA_DA_CMPL_MON/ICA_STCK_TST
        INSERT INTO ica_data_hash
             SELECT ica_stck_tst.data_hash
               FROM ica_da_cmpl_mon
               JOIN ica_stck_tst
                 ON ica_stck_tst.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
              WHERE ica_da_cmpl_mon.key_hash = @v_key_hash;

        -- /ICA_DA_CMPL_MON/ICA_STCK_TST/ICA_STCK_TST_OBS_AGNCY_TYPE
        INSERT INTO ica_data_hash
             SELECT ica_stck_tst_obs_agncy_type.data_hash
               FROM ica_da_cmpl_mon
               JOIN ica_stck_tst
                 ON ica_stck_tst.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
               JOIN ica_stck_tst_obs_agncy_type
                 ON ica_stck_tst_obs_agncy_type.ica_stck_tst_id = ica_stck_tst.ica_stck_tst_id
              WHERE ica_da_cmpl_mon.key_hash = @v_key_hash;

        -- /ICA_DA_CMPL_MON/ICA_STCK_TST/ICA_STCK_TST_PURPOSE
        INSERT INTO ica_data_hash
             SELECT ica_stck_tst_purpose.data_hash
               FROM ica_da_cmpl_mon
               JOIN ica_stck_tst
                 ON ica_stck_tst.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
               JOIN ica_stck_tst_purpose
                 ON ica_stck_tst_purpose.ica_stck_tst_id = ica_stck_tst.ica_stck_tst_id
              WHERE ica_da_cmpl_mon.key_hash = @v_key_hash;

        -- /ICA_DA_CMPL_MON/ICA_STCK_TST/ICA_TST_RSLTS
        INSERT INTO ica_data_hash
             SELECT ica_tst_rslts.data_hash
               FROM ica_da_cmpl_mon
               JOIN ica_stck_tst
                 ON ica_stck_tst.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
               JOIN ica_tst_rslts
                 ON ica_tst_rslts.ica_stck_tst_id = ica_stck_tst.ica_stck_tst_id
              WHERE ica_da_cmpl_mon.key_hash = @v_key_hash;

        -- /ICA_DA_CMPL_MON/ICA_STCK_TST/ICA_TST_RSLTS/ICA_METHOD
        INSERT INTO ica_data_hash
             SELECT ica_method.data_hash
               FROM ica_da_cmpl_mon
               JOIN ica_stck_tst
                 ON ica_stck_tst.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
               JOIN ica_tst_rslts
                 ON ica_tst_rslts.ica_stck_tst_id = ica_stck_tst.ica_stck_tst_id
               JOIN ica_method
                 ON ica_method.ica_tst_rslts_id = ica_tst_rslts.ica_tst_rslts_id
              WHERE ica_da_cmpl_mon.key_hash = @v_key_hash;

        END;

     IF @p_payload_type = 'ICA_DA_ENFRC_ACTN_MILSTN' and @v_enabled = 'Y'
        BEGIN

        -- /ICA_DA_ENFRC_ACTN_MILSTN
        INSERT INTO ica_data_hash
             SELECT ica_da_enfrc_actn_milstn.data_hash
               FROM ica_da_enfrc_actn_milstn
              WHERE ica_da_enfrc_actn_milstn.key_hash = @v_key_hash;

        END;

     IF @p_payload_type = 'ICA_DA_FRML_ENFRC_ACTN' and @v_enabled = 'Y'
        BEGIN

        -- /ICA_DA_FRML_ENFRC_ACTN
        INSERT INTO ica_data_hash
             SELECT ica_da_frml_enfrc_actn.data_hash
               FROM ica_da_frml_enfrc_actn
              WHERE ica_da_frml_enfrc_actn.key_hash = @v_key_hash;

        -- /ICA_DA_FRML_ENFRC_ACTN/ICA_DA_FINAL_ORDER
        INSERT INTO ica_data_hash
             SELECT ica_da_final_order.data_hash
               FROM ica_da_frml_enfrc_actn
               JOIN ica_da_final_order
                 ON ica_da_final_order.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
              WHERE ica_da_frml_enfrc_actn.key_hash = @v_key_hash;

        -- /ICA_DA_FRML_ENFRC_ACTN/ICA_DA_FINAL_ORDER/ICA_FINAL_ORDER_FAC_IDENT
        INSERT INTO ica_data_hash
             SELECT ica_final_order_fac_ident.data_hash
               FROM ica_da_frml_enfrc_actn
               JOIN ica_da_final_order
                 ON ica_da_final_order.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
               JOIN ica_final_order_fac_ident
                 ON ica_final_order_fac_ident.ica_da_final_order_id = ica_da_final_order.ica_da_final_order_id
              WHERE ica_da_frml_enfrc_actn.key_hash = @v_key_hash;

        -- /ICA_DA_FRML_ENFRC_ACTN/ICA_DA_FINAL_ORDER/ICA_DEMND_STIPULTD_PNLTY
        INSERT INTO ica_data_hash
             SELECT ica_demnd_stipultd_pnlty.data_hash
               FROM ica_da_frml_enfrc_actn
               JOIN ica_da_final_order
                 ON ica_da_final_order.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
               JOIN ica_demnd_stipultd_pnlty
                 ON ica_demnd_stipultd_pnlty.ica_da_final_order_id = ica_da_final_order.ica_da_final_order_id
              WHERE ica_da_frml_enfrc_actn.key_hash = @v_key_hash;

        -- /ICA_DA_FRML_ENFRC_ACTN/ICA_ENFRC_ACTN_CMNT_TXT
        INSERT INTO ica_data_hash
             SELECT ica_enfrc_actn_cmnt_txt.data_hash
               FROM ica_da_frml_enfrc_actn
               JOIN ica_enfrc_actn_cmnt_txt
                 ON ica_enfrc_actn_cmnt_txt.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
              WHERE ica_da_frml_enfrc_actn.key_hash = @v_key_hash;

        -- /ICA_DA_FRML_ENFRC_ACTN/ICA_ENFRC_ACTN_GOV_CNTCT
        INSERT INTO ica_data_hash
             SELECT ica_enfrc_actn_gov_cntct.data_hash
               FROM ica_da_frml_enfrc_actn
               JOIN ica_enfrc_actn_gov_cntct
                 ON ica_enfrc_actn_gov_cntct.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
              WHERE ica_da_frml_enfrc_actn.key_hash = @v_key_hash;

        -- /ICA_DA_FRML_ENFRC_ACTN/ICA_ENFRC_ACTN_TYPE
        INSERT INTO ica_data_hash
             SELECT ica_enfrc_actn_type.data_hash
               FROM ica_da_frml_enfrc_actn
               JOIN ica_enfrc_actn_type
                 ON ica_enfrc_actn_type.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
              WHERE ica_da_frml_enfrc_actn.key_hash = @v_key_hash;

        -- /ICA_DA_FRML_ENFRC_ACTN/ICA_ENFRC_AGNCY_TYPE
        INSERT INTO ica_data_hash
             SELECT ica_enfrc_agncy_type.data_hash
               FROM ica_da_frml_enfrc_actn
               JOIN ica_enfrc_agncy_type
                 ON ica_enfrc_agncy_type.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
              WHERE ica_da_frml_enfrc_actn.key_hash = @v_key_hash;

        -- /ICA_DA_FRML_ENFRC_ACTN/ICA_FAC_IDENT
        INSERT INTO ica_data_hash
             SELECT ica_fac_ident.data_hash
               FROM ica_da_frml_enfrc_actn
               JOIN ica_fac_ident
                 ON ica_fac_ident.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
              WHERE ica_da_frml_enfrc_actn.key_hash = @v_key_hash;

        -- /ICA_DA_FRML_ENFRC_ACTN/ICA_POLUT
        INSERT INTO ica_data_hash
             SELECT ica_polut.data_hash
               FROM ica_da_frml_enfrc_actn
               JOIN ica_polut
                 ON ica_polut.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
              WHERE ica_da_frml_enfrc_actn.key_hash = @v_key_hash;

        -- /ICA_DA_FRML_ENFRC_ACTN/ICA_PROGS_VIOL
        INSERT INTO ica_data_hash
             SELECT ica_progs_viol.data_hash
               FROM ica_da_frml_enfrc_actn
               JOIN ica_progs_viol
                 ON ica_progs_viol.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
              WHERE ica_da_frml_enfrc_actn.key_hash = @v_key_hash;

        -- /ICA_DA_FRML_ENFRC_ACTN/ICA_SENS_CMNT_TXT
        INSERT INTO ica_data_hash
             SELECT ica_sens_cmnt_txt.data_hash
               FROM ica_da_frml_enfrc_actn
               JOIN ica_sens_cmnt_txt
                 ON ica_sens_cmnt_txt.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
              WHERE ica_da_frml_enfrc_actn.key_hash = @v_key_hash;

        END;

     IF @p_payload_type = 'ICA_DA_INFRML_ENFRC_ACTN' and @v_enabled = 'Y'
        BEGIN

        -- /ICA_DA_INFRML_ENFRC_ACTN
        INSERT INTO ica_data_hash
             SELECT ica_da_infrml_enfrc_actn.data_hash
               FROM ica_da_infrml_enfrc_actn
              WHERE ica_da_infrml_enfrc_actn.key_hash = @v_key_hash;

        -- /ICA_DA_INFRML_ENFRC_ACTN/ICA_ENFRC_ACTN_GOV_CNTCT
        INSERT INTO ica_data_hash
             SELECT ica_enfrc_actn_gov_cntct.data_hash
               FROM ica_da_infrml_enfrc_actn
               JOIN ica_enfrc_actn_gov_cntct
                 ON ica_enfrc_actn_gov_cntct.ica_da_infrml_enfrc_actn_id = ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
              WHERE ica_da_infrml_enfrc_actn.key_hash = @v_key_hash;

        -- /ICA_DA_INFRML_ENFRC_ACTN/ICA_ENFRC_AGNCY_TYPE
        INSERT INTO ica_data_hash
             SELECT ica_enfrc_agncy_type.data_hash
               FROM ica_da_infrml_enfrc_actn
               JOIN ica_enfrc_agncy_type
                 ON ica_enfrc_agncy_type.ica_da_infrml_enfrc_actn_id = ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
              WHERE ica_da_infrml_enfrc_actn.key_hash = @v_key_hash;

        -- /ICA_DA_INFRML_ENFRC_ACTN/ICA_FAC_IDENT
        INSERT INTO ica_data_hash
             SELECT ica_fac_ident.data_hash
               FROM ica_da_infrml_enfrc_actn
               JOIN ica_fac_ident
                 ON ica_fac_ident.ica_da_infrml_enfrc_actn_id = ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
              WHERE ica_da_infrml_enfrc_actn.key_hash = @v_key_hash;

        -- /ICA_DA_INFRML_ENFRC_ACTN/ICA_INFRML_EA_CMNT_TXT
        INSERT INTO ica_data_hash
             SELECT ica_infrml_ea_cmnt_txt.data_hash
               FROM ica_da_infrml_enfrc_actn
               JOIN ica_infrml_ea_cmnt_txt
                 ON ica_infrml_ea_cmnt_txt.ica_da_infrml_enfrc_actn_id = ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
              WHERE ica_da_infrml_enfrc_actn.key_hash = @v_key_hash;

        -- /ICA_DA_INFRML_ENFRC_ACTN/ICA_POLUT
        INSERT INTO ica_data_hash
             SELECT ica_polut.data_hash
               FROM ica_da_infrml_enfrc_actn
               JOIN ica_polut
                 ON ica_polut.ica_da_infrml_enfrc_actn_id = ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
              WHERE ica_da_infrml_enfrc_actn.key_hash = @v_key_hash;

        -- /ICA_DA_INFRML_ENFRC_ACTN/ICA_PROGS_VIOL
        INSERT INTO ica_data_hash
             SELECT ica_progs_viol.data_hash
               FROM ica_da_infrml_enfrc_actn
               JOIN ica_progs_viol
                 ON ica_progs_viol.ica_da_infrml_enfrc_actn_id = ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
              WHERE ica_da_infrml_enfrc_actn.key_hash = @v_key_hash;

        -- /ICA_DA_INFRML_ENFRC_ACTN/ICA_SENS_CMNT_TXT
        INSERT INTO ica_data_hash
             SELECT ica_sens_cmnt_txt.data_hash
               FROM ica_da_infrml_enfrc_actn
               JOIN ica_sens_cmnt_txt
                 ON ica_sens_cmnt_txt.ica_da_infrml_enfrc_actn_id = ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
              WHERE ica_da_infrml_enfrc_actn.key_hash = @v_key_hash;

        END;

     IF @p_payload_type = 'ICA_FAC' and @v_enabled = 'Y'
        BEGIN

        -- /ICA_FAC
        INSERT INTO ica_data_hash
             SELECT ica_fac.data_hash
               FROM ica_fac
              WHERE ica_fac.key_hash = @v_key_hash;

        -- /ICA_FAC/ICA_CNTCT
        INSERT INTO ica_data_hash
             SELECT ica_cntct.data_hash
               FROM ica_fac
               JOIN ica_cntct
                 ON ica_cntct.ica_fac_id = ica_fac.ica_fac_id
              WHERE ica_fac.key_hash = @v_key_hash;

        -- /ICA_FAC/ICA_CNTCT/ICA_TELEPH
        INSERT INTO ica_data_hash
             SELECT ica_teleph.data_hash
               FROM ica_fac
               JOIN ica_cntct
                 ON ica_cntct.ica_fac_id = ica_fac.ica_fac_id
               JOIN ica_teleph
                 ON ica_teleph.ica_cntct_id = ica_cntct.ica_cntct_id
              WHERE ica_fac.key_hash = @v_key_hash;

        -- /ICA_FAC/ICA_FAC_ADDR
        INSERT INTO ica_data_hash
             SELECT ica_fac_addr.data_hash
               FROM ica_fac
               JOIN ica_fac_addr
                 ON ica_fac_addr.ica_fac_id = ica_fac.ica_fac_id
              WHERE ica_fac.key_hash = @v_key_hash;

        -- /ICA_FAC/ICA_FAC_ADDR/ICA_TELEPH
        INSERT INTO ica_data_hash
             SELECT ica_teleph.data_hash
               FROM ica_fac
               JOIN ica_fac_addr
                 ON ica_fac_addr.ica_fac_id = ica_fac.ica_fac_id
               JOIN ica_teleph
                 ON ica_teleph.ica_fac_addr_id = ica_fac_addr.ica_fac_addr_id
              WHERE ica_fac.key_hash = @v_key_hash;

        -- /ICA_FAC/ICA_GEO_COORD
        INSERT INTO ica_data_hash
             SELECT ica_geo_coord.data_hash
               FROM ica_fac
               JOIN ica_geo_coord
                 ON ica_geo_coord.ica_fac_id = ica_fac.ica_fac_id
              WHERE ica_fac.key_hash = @v_key_hash;

        -- /ICA_FAC/ICA_NAICA_CODE
        INSERT INTO ica_data_hash
             SELECT ica_naics_code.data_hash
               FROM ica_fac
               JOIN ica_naics_code
                 ON ica_naics_code.ica_fac_id = ica_fac.ica_fac_id
              WHERE ica_fac.key_hash = @v_key_hash;

        -- /ICA_FAC/ICA_PORT_SRC
        INSERT INTO ica_data_hash
             SELECT ica_port_src.data_hash
               FROM ica_fac
               JOIN ica_port_src
                 ON ica_port_src.ica_fac_id = ica_fac.ica_fac_id
              WHERE ica_fac.key_hash = @v_key_hash;

        -- /ICA_FAC/ICA_SIC_CODE
        INSERT INTO ica_data_hash
             SELECT ica_sic_code.data_hash
               FROM ica_fac
               JOIN ica_sic_code
                 ON ica_sic_code.ica_fac_id = ica_fac.ica_fac_id
              WHERE ica_fac.key_hash = @v_key_hash;

        -- /ICA_FAC/ICA_UNIVERSE_IND
        INSERT INTO ica_data_hash
             SELECT ica_universe_ind.data_hash
               FROM ica_fac
               JOIN ica_universe_ind
                 ON ica_universe_ind.ica_fac_id = ica_fac.ica_fac_id
              WHERE ica_fac.key_hash = @v_key_hash;

        END;

     IF @p_payload_type = 'ICA_POLUTS' and @v_enabled = 'Y'
        BEGIN

        -- /ICA_POLUTS
        INSERT INTO ica_data_hash
             SELECT ica_poluts.data_hash
               FROM ica_poluts
              WHERE ica_poluts.key_hash = @v_key_hash;

        -- /ICA_POLUTS/ICA_POLUT_DA_CLASS
        INSERT INTO ica_data_hash
             SELECT ica_polut_da_class.data_hash
               FROM ica_poluts
               JOIN ica_polut_da_class
                 ON ica_polut_da_class.ica_poluts_id = ica_poluts.ica_poluts_id
              WHERE ica_poluts.key_hash = @v_key_hash;

        -- /ICA_POLUTS/ICA_POLUT_EPA_CLASS
        INSERT INTO ica_data_hash
             SELECT ica_polut_epa_class.data_hash
               FROM ica_poluts
               JOIN ica_polut_epa_class
                 ON ica_polut_epa_class.ica_poluts_id = ica_poluts.ica_poluts_id
              WHERE ica_poluts.key_hash = @v_key_hash;

        END;

     IF @p_payload_type = 'ICA_PROGS' and @v_enabled = 'Y'
        BEGIN

        -- /ICA_PROGS
        INSERT INTO ica_data_hash
             SELECT ica_progs.data_hash
               FROM ica_progs
              WHERE ica_progs.key_hash = @v_key_hash;

        -- /ICA_PROGS/ICA_PROG_SUBPART
        INSERT INTO ica_data_hash
             SELECT ica_prog_subpart.data_hash
               FROM ica_progs
               JOIN ica_prog_subpart
                 ON ica_prog_subpart.ica_progs_id = ica_progs.ica_progs_id
              WHERE ica_progs.key_hash = @v_key_hash;

        END;

     IF @p_payload_type = 'ICA_TVACC' and @v_enabled = 'Y'
        BEGIN

        -- /ICA_TVACC
        INSERT INTO ica_data_hash
             SELECT ica_tvacc.data_hash
               FROM ica_tvacc
              WHERE ica_tvacc.key_hash = @v_key_hash;

        -- /ICA_TVACC/ICA_CNTCT
        INSERT INTO ica_data_hash
             SELECT ica_cntct.data_hash
               FROM ica_tvacc
               JOIN ica_cntct
                 ON ica_cntct.ica_tvacc_id = ica_tvacc.ica_tvacc_id
              WHERE ica_tvacc.key_hash = @v_key_hash;

        -- /ICA_TVACC/ICA_CNTCT/ICA_TELEPH
        INSERT INTO ica_data_hash
             SELECT ica_teleph.data_hash
               FROM ica_tvacc
               JOIN ica_cntct
                 ON ica_cntct.ica_tvacc_id = ica_tvacc.ica_tvacc_id
               JOIN ica_teleph
                 ON ica_teleph.ica_cntct_id = ica_cntct.ica_cntct_id
              WHERE ica_tvacc.key_hash = @v_key_hash;

        -- /ICA_TVACC/ICA_INSP_CMNT_TXT
        INSERT INTO ica_data_hash
             SELECT ica_insp_cmnt_txt.data_hash
               FROM ica_tvacc
               JOIN ica_insp_cmnt_txt
                 ON ica_insp_cmnt_txt.ica_tvacc_id = ica_tvacc.ica_tvacc_id
              WHERE ica_tvacc.key_hash = @v_key_hash;

        -- /ICA_TVACC/ICA_INSP_GOV_CNTCT
        INSERT INTO ica_data_hash
             SELECT ica_insp_gov_cntct.data_hash
               FROM ica_tvacc
               JOIN ica_insp_gov_cntct
                 ON ica_insp_gov_cntct.ica_tvacc_id = ica_tvacc.ica_tvacc_id
              WHERE ica_tvacc.key_hash = @v_key_hash;

        -- /ICA_TVACC/ICA_NAT_PRIO
        INSERT INTO ica_data_hash
             SELECT ica_nat_prio.data_hash
               FROM ica_tvacc
               JOIN ica_nat_prio
                 ON ica_nat_prio.ica_tvacc_id = ica_tvacc.ica_tvacc_id
              WHERE ica_tvacc.key_hash = @v_key_hash;

        -- /ICA_TVACC/ICA_POLUT
        INSERT INTO ica_data_hash
             SELECT ica_polut.data_hash
               FROM ica_tvacc
               JOIN ica_polut
                 ON ica_polut.ica_tvacc_id = ica_tvacc.ica_tvacc_id
              WHERE ica_tvacc.key_hash = @v_key_hash;

        -- /ICA_TVACC/ICA_PROG
        INSERT INTO ica_data_hash
             SELECT ica_prog.data_hash
               FROM ica_tvacc
               JOIN ica_prog
                 ON ica_prog.ica_tvacc_id = ica_tvacc.ica_tvacc_id
              WHERE ica_tvacc.key_hash = @v_key_hash;

        -- /ICA_TVACC/ICA_RGNL_PRIO
        INSERT INTO ica_data_hash
             SELECT ica_rgnl_prio.data_hash
               FROM ica_tvacc
               JOIN ica_rgnl_prio
                 ON ica_rgnl_prio.ica_tvacc_id = ica_tvacc.ica_tvacc_id
              WHERE ica_tvacc.key_hash = @v_key_hash;

        -- /ICA_TVACC/ICA_SENS_CMNT_TXT
        INSERT INTO ica_data_hash
             SELECT ica_sens_cmnt_txt.data_hash
               FROM ica_tvacc
               JOIN ica_sens_cmnt_txt
                 ON ica_sens_cmnt_txt.ica_tvacc_id = ica_tvacc.ica_tvacc_id
              WHERE ica_tvacc.key_hash = @v_key_hash;

        -- /ICA_TVACC/ICA_TVACC_REVIEW
        INSERT INTO ica_data_hash
             SELECT ica_tvacc_review.data_hash
               FROM ica_tvacc
               JOIN ica_tvacc_review
                 ON ica_tvacc_review.ica_tvacc_id = ica_tvacc.ica_tvacc_id
              WHERE ica_tvacc.key_hash = @v_key_hash;

        END;

     IF @p_payload_type = 'ICA_DA_CASE_FILE' and @v_enabled = 'Y'
        BEGIN

        -- /ICA_DA_CASE_FILE
        INSERT INTO ica_data_hash
             SELECT ica_da_case_file.data_hash
               FROM ica_da_case_file
              WHERE ica_da_case_file.key_hash = @v_key_hash;

        -- /ICA_DA_CASE_FILE/ICA_CASE_FILE_CMNT_TXT
        INSERT INTO ica_data_hash
             SELECT ica_case_file_cmnt_txt.data_hash
               FROM ica_da_case_file
               JOIN ica_case_file_cmnt_txt
                 ON ica_case_file_cmnt_txt.ica_da_case_file_id = ica_da_case_file.ica_da_case_file_id
              WHERE ica_da_case_file.key_hash = @v_key_hash;

        -- /ICA_DA_CASE_FILE/ICA_OTHR_PATHWAY_ACTY
        INSERT INTO ica_data_hash
             SELECT ica_othr_pathway_acty.data_hash
               FROM ica_da_case_file
               JOIN ica_othr_pathway_acty
                 ON ica_othr_pathway_acty.ica_da_case_file_id = ica_da_case_file.ica_da_case_file_id
              WHERE ica_da_case_file.key_hash = @v_key_hash;

        -- /ICA_DA_CASE_FILE/ICA_POLUT
        INSERT INTO ica_data_hash
             SELECT ica_polut.data_hash
               FROM ica_da_case_file
               JOIN ica_polut
                 ON ica_polut.ica_da_case_file_id = ica_da_case_file.ica_da_case_file_id
              WHERE ica_da_case_file.key_hash = @v_key_hash;

        -- /ICA_DA_CASE_FILE/ICA_PROG
        INSERT INTO ica_data_hash
             SELECT ica_prog.data_hash
               FROM ica_da_case_file
               JOIN ica_prog
                 ON ica_prog.ica_da_case_file_id = ica_da_case_file.ica_da_case_file_id
              WHERE ica_da_case_file.key_hash = @v_key_hash;

        -- /ICA_DA_CASE_FILE/ICA_SENS_CMNT_TXT
        INSERT INTO ica_data_hash
             SELECT ica_sens_cmnt_txt.data_hash
               FROM ica_da_case_file
               JOIN ica_sens_cmnt_txt
                 ON ica_sens_cmnt_txt.ica_da_case_file_id = ica_da_case_file.ica_da_case_file_id
              WHERE ica_da_case_file.key_hash = @v_key_hash;

        -- /ICA_DA_CASE_FILE/ICA_VIOL
        INSERT INTO ica_data_hash
             SELECT ica_viol.data_hash
               FROM ica_da_case_file
               JOIN ica_viol
                 ON ica_viol.ica_da_case_file_id = ica_da_case_file.ica_da_case_file_id
              WHERE ica_da_case_file.key_hash = @v_key_hash;

        END;

     IF @p_payload_type = 'ICA_DA_ENFRC_ACTN_LNK' and @v_enabled = 'Y'
        BEGIN

        -- /ICA_DA_ENFRC_ACTN_LNK
        INSERT INTO ica_data_hash
             SELECT ica_da_enfrc_actn_lnk.data_hash
               FROM ica_da_enfrc_actn_lnk
              WHERE ica_da_enfrc_actn_lnk.key_hash = @v_key_hash;

        -- /ICA_DA_ENFRC_ACTN_LNK/ICA_LNK_DA_ENFRC_ACTN
        INSERT INTO ica_data_hash
             SELECT ica_lnk_da_enfrc_actn.data_hash
               FROM ica_da_enfrc_actn_lnk
               JOIN ica_lnk_da_enfrc_actn
                 ON ica_lnk_da_enfrc_actn.ica_da_enfrc_actn_lnk_id = ica_da_enfrc_actn_lnk.ica_da_enfrc_actn_lnk_id
              WHERE ica_da_enfrc_actn_lnk.key_hash = @v_key_hash;

        END;

     IF @p_payload_type = 'ICA_CASE_FILE_LNK' and @v_enabled = 'Y'
        BEGIN

        -- /ICA_CASE_FILE_LNK
        INSERT INTO ica_data_hash
             SELECT ica_case_file_lnk.data_hash
               FROM ica_case_file_lnk
              WHERE ica_case_file_lnk.key_hash = @v_key_hash;

        -- /ICA_CASE_FILE_LNK/ICA_LNK_CASE_FILE
        INSERT INTO ica_data_hash
             SELECT ica_lnk_case_file.data_hash
               FROM ica_case_file_lnk
               JOIN ica_lnk_case_file
                 ON ica_lnk_case_file.ica_case_file_lnk_id = ica_case_file_lnk.ica_case_file_lnk_id
              WHERE ica_case_file_lnk.key_hash = @v_key_hash;

        -- /ICA_CASE_FILE_LNK/ICA_LNK_CMPL_MON
        INSERT INTO ica_data_hash
             SELECT ica_lnk_cmpl_mon.data_hash
               FROM ica_case_file_lnk
               JOIN ica_lnk_cmpl_mon
                 ON ica_lnk_cmpl_mon.ica_case_file_lnk_id = ica_case_file_lnk.ica_case_file_lnk_id
              WHERE ica_case_file_lnk.key_hash = @v_key_hash;

        -- /ICA_CASE_FILE_LNK/ICA_LNK_DA_ENFRC_ACTN
        INSERT INTO ica_data_hash
             SELECT ica_lnk_da_enfrc_actn.data_hash
               FROM ica_case_file_lnk
               JOIN ica_lnk_da_enfrc_actn
                 ON ica_lnk_da_enfrc_actn.ica_case_file_lnk_id = ica_case_file_lnk.ica_case_file_lnk_id
              WHERE ica_case_file_lnk.key_hash = @v_key_hash;

        END;

     IF @p_payload_type = 'ICA_CMPL_MON_LNK' and @v_enabled = 'Y'
        BEGIN

        -- /ICA_CMPL_MON_LNK
        INSERT INTO ica_data_hash
             SELECT ica_cmpl_mon_lnk.data_hash
               FROM ica_cmpl_mon_lnk
              WHERE ica_cmpl_mon_lnk.key_hash = @v_key_hash;

        -- /ICA_CMPL_MON_LNK/ICA_LNK_CMPL_MON
        INSERT INTO ica_data_hash
             SELECT ica_lnk_cmpl_mon.data_hash
               FROM ica_cmpl_mon_lnk
               JOIN ica_lnk_cmpl_mon
                 ON ica_lnk_cmpl_mon.ica_cmpl_mon_lnk_id = ica_cmpl_mon_lnk.ica_cmpl_mon_lnk_id
              WHERE ica_cmpl_mon_lnk.key_hash = @v_key_hash;

        -- /ICA_CMPL_MON_LNK/ICA_LNK_DA_ENFRC_ACTN
        INSERT INTO ica_data_hash
             SELECT ica_lnk_da_enfrc_actn.data_hash
               FROM ica_cmpl_mon_lnk
               JOIN ica_lnk_da_enfrc_actn
                 ON ica_lnk_da_enfrc_actn.ica_cmpl_mon_lnk_id = ica_cmpl_mon_lnk.ica_cmpl_mon_lnk_id
              WHERE ica_cmpl_mon_lnk.key_hash = @v_key_hash;

        END;




     /*  
      *  Loop through each data_hash value loaded into ICA_DATA_HASH, for each, rehash each data_hash values together to create 
      *  a single data_hash value that represents all the non-key data contained within a payload type / key_hash combination.
      */
		  SET @v_all_data_hashes = NULL;
      OPEN data_hash;

      -- Get 1st payload type
      FETCH NEXT FROM data_hash INTO @v_data_hash;
      WHILE @@FETCH_STATUS = 0
        BEGIN      
            
        /* Append each data hash together into one string value.. */
        SELECT @v_all_data_hashes = ICA_FLOW_LOCAL.dbo.HASHBYTES_VARCHAR('SHA1', COALESCE(@v_all_data_hashes,'#') + @v_data_hash);
        FETCH NEXT FROM data_hash INTO @v_data_hash;

      END; -- data_loop;

    /*  Close the data_hash cursor */
    CLOSE data_hash;
            
          /*  Hash the entire set of data_hash values organized into a single string. */
		  SET @v_hashed_data_hashes = NULL;
          SELECT @v_hashed_data_hashes = @v_all_data_hashes;      
                     
                     
          /*  Load the rehashed value into the payload type table's data_hash column. */
          SET @v_sql_statement = ' UPDATE ' + @p_payload_type + 
                                 '    SET ' + 'data_hash = ' + '''' + @v_hashed_data_hashes +  '''' + 
                                 '  WHERE key_hash = ' + '''' + @v_key_hash + '''';

          EXECUTE sp_executesql @v_sql_statement;                      
          
          /* Get next key_hash value...  */
          FETCH NEXT FROM key_hash INTO @v_key_hash;
                  
        END; -- key_loop   
       
      /*  Close the key_hash cursor */
      CLOSE key_hash;

      /*  Get the next payload type. */
      FETCH NEXT FROM payload_type_process 
      INTO @p_payload_type;
      
    END; -- payload_t--END LOOP module_loop;

  /*  Close payload type cursor */
  CLOSE payload_type_process;
  
  /*  Destroy the payload type cursor */
  DEALLOCATE payload_type_delete;  
  DEALLOCATE payload_type_process;  
  DEALLOCATE data_hash;
  DEALLOCATE key_hash;
      
END;
GO

/*
Copyright (c) 2014, The Environmental Council of the States (ECOS)
All rights reserved.
 
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
 
 * Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
 * Neither the name of the ECOS nor the names of its contributors may
   be used to endorse or promote products derived from this software
   without specific prior written permission.
 
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/

USE [ICA_FLOW_LOCAL]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.ICA_DATA_PREP_MASTER') AND type = N'P')
DROP PROCEDURE dbo.ICA_DATA_PREP_MASTER
GO

/******************************************************************************************************************************
** Object Name: ICA_DATA_PREP_MASTER
**
** Author:  Windsor Solutions, Inc.
**
** Description:  This is a template stored procedure was developed for processing ICIS data for exchange via OPENNODE2.  This 
**               stored procedure determines if the system state is ready for ICIS data processing, and if so initiate those
**               processes, otherwise it will skip processing until the state of the system is ready for a new batch of ICIS 
**               data processing.
**
** Revision History:      
** ----------------------------------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ----------------------------------------------------------------------------------------------------------------------------
** 03/07/2012    WSolutions     Created
** 09/26/2012    WSolutions     Modified the placement of the commit transaction to within the TRY block, instead of after the
**                              catch block.
** 09/28/2012    WSolutions     Added capture/rethrow of error severity
** 10/16/2014    WSolutions     Removed transaction processing
**
******************************************************************************************************************************/
CREATE PROCEDURE [dbo].[ICA_DATA_PREP_MASTER] @p_ica_subm_track_id AS NVARCHAR(2048) OUTPUT

AS 

/* 
 * Delare the variable to to hold the newly created row in 
 * ica_subm_track associated with the new workflow
 */
 DECLARE @v_ica_subm_track_id NVARCHAR(50); 
 DECLARE @v_error_message NVARCHAR(2048);
 DECLARE @v_error_number INT;
 DECLARE @v_error_severity INT;
 DECLARE @v_process NVARCHAR(30);

BEGIN 

  SET @v_process = 'ICA_DATA_PREP_MASTER';

 /*  
  *  Ensure there are no existing workflows in process. If there are, quit without returning an ID.
  */
  IF (SELECT COUNT(1) AS COUNTER FROM ica_subm_track WHERE workflow_stat = 'Pending') > 0
    BEGIN
      SET @p_ica_subm_track_id = NULL;
      RETURN;
    END;
  
 /* Safe to proceed. Create and commit a new workflow record */
  SELECT @v_ica_subm_track_id = NEWID(); 

  INSERT INTO ica_subm_track 
       ( ica_subm_track_id
       , workflow_stat
       , workflow_stat_message) 
  VALUES( @v_ica_subm_track_id
        , 'Pending'
        , 'ETL begun');

  BEGIN TRY 
     
     /* 
      *  Call the stored procedure to extract ICIS data from source data database.
      *  NOTE:  This stored procedure will need to be independently developed and 
      *         should populate the set of "LOCAL" ICS staging tables.
      */
      SET @v_process = 'EXTRACT_ICIS_DATA';
      EXEC ICA_ETL;

     /* 
      *  Update the workflow record to track completion of ETL date/time.
      */
      UPDATE ica_subm_track 
         SET etl_cmpl_date_time = GETDATE() 
           , workflow_stat_message = 'ETL Completed | Begin Change Processing'
       WHERE ica_subm_track_id = @v_ica_subm_track_id;

     /* 
      *  Call the stored procedure to compare data changes between LOCAL and ICIS and set
      *  transaction codes for bundling and submission to an exchange partner via OPENNODE.
      */
      SET @v_process = 'ICA_DETECT_DATA_CHANGES';
      EXEC ICA_CHANGE_DETECTION;

     /* 
      *  Update the workflow record to track completion of change detection date/time.
      */
     UPDATE ica_subm_track 
        SET det_change_cmpl_date_time = GETDATE() 
           , workflow_stat_message = 'Change Processing Completed'
      WHERE ica_subm_track_id = @v_ica_subm_track_id;

    /* 
     *  Return current workflow identifier
     */
    SET @p_ica_subm_track_id = @v_ica_subm_track_id;

    /* 
     *  Add any additional SQL logic required after the change detection process completes.
     */

     --  Add additional database processing here if needed...

  END TRY 

  /*
   *  Handle any runtime errors
   */
  BEGIN CATCH

    SET @v_error_message = ERROR_MESSAGE();
    SET @v_error_number = ERROR_NUMBER();
    SET @v_error_severity = ERROR_SEVERITY();
    
    /*  
     *  Set workflow status to failed.
     */
     UPDATE ica_subm_track 
        SET workflow_stat = 'Failed'
          , workflow_stat_message = @v_process + ': ' + @v_error_message 
      WHERE ica_subm_track_id = @v_ica_subm_track_id;

     --Send the error back up to the calling code. If the ETL is being called from the plugin, this will trigger the plugin to log the failure and quit
     SET @p_ica_subm_track_id = @v_error_message;
     RAISERROR (@v_error_message, @v_error_severity, 1);

  END CATCH

END ;
GO
