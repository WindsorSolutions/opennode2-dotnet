/*
Copyright (c) 2014, The Environmental Council of the States (ECOS)
All rights reserved.
 
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
 
 * Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
 * Neither the name of the ECOS nor the names of its contributors may
   be used to endorse or promote products derived from this software
   without specific prior written permission.
 
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.ICA_CHANGE_DETECTION') AND type = N'P')
DROP PROCEDURE dbo.ICA_CHANGE_DETECTION
GO

/******************************************************************************************************************************
** Object Name: ICA_CHANGE_DETECTION
**
** Author: Windsor Solutions, Inc.
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure will detect data changes made within the ICIS schema and then sets the transaction type
**               flags so the data can be bundled and submitted to an exchange partner.
**
** Inputs:  -- NA --  
**
**
** Revision History:      
** ----------------------------------------------------------------------------------------------------------------------------
**  Date         Analyst     Description
** ----------------------------------------------------------------------------------------------------------------------------
** 07/18/2014    KJames      Baseline from ICIS v4.0 procedure.
** 07/30/2014    KJames      Moved data element PORT_SRC_IND from ICA_PORT_SRC to ICA_FAC.
** 08/06/2014    KJames      Added data element LOCALITY_NAME to ICA_FAC.
** 08/06/2014    KJames      Added data element LOC_ADDR_COUNTY_CODE to ICA_FAC.
** 09/03/2014    KJames      Added code to hash the linkage tables.
** 09/03/2014    KJames      Added setting of delete transactions of linkage tables.
** 09/04/2014    KJames      Added OTHR_PROG_DESC_TXT to the database tables ICA_DA_FRML_ENFRC_ACTN and
**                           ICA_DA_INFRML_ENFRC_ACTN.
** 10/10/2014    KJames      Added the @v_enabled flag for each payload type to control hashing.
** 10/10/2014    KJames      Futher refined the use of @v_enabled, expanded to prevent the population of 
**                           a disabled payloads transaction_type.
** 01/28/2015    KJames      Added the required field PROG_OPER_STAT_CODE to the logic that builds ICA_PROGS delete records.
** 01/28/2015    KJames      Added the required field FAC_IDENT to the logic that builds ICA_TVACC delete records.
** 01/28/2015    KJames      Added the required field FAC_IDENT to the logic that builds ICA_DA_CASE_FILE delete records.
** 07/06/2015    KJames      Added change processing for new staging table ICA_DEMND_STIPULTD_PNLTY.
** 07/15/2015    KJames      Corrected the database reference for updating ICA_DEMND_STIPULTD_PNLTY data hash.
** 07/15/2015    KJames      Added processing of new data element FINAL_ORDER_LODGED_DATE on ICA_DA_FINAL_ORDER.
** 08/24/2015    KJames      Modified the ICA_PAYLOAD operation name to the proper CaseFileLinkageSubmission.
** 09/21/2015    KJames      Removed SRC_SYSTM_IDENT from the linkage table's key hashing statements.
** 09/21/2015    KJames      Consolidated the key and data hashing for the linkage tables into individual
**                           update statements.
** 03/30/2016    KJames      Altered delete payload logic for linkages to pull parent and related child elements.
**
******************************************************************************************************************************/
CREATE PROCEDURE [dbo].[ICA_CHANGE_DETECTION] AS

SET NOCOUNT ON;

DECLARE @v_sql_statement AS NVARCHAR(4000);
DECLARE @v_sql_param AS NVARCHAR(100);
DECLARE @p_payload_type AS NVARCHAR(50); 

/* Working Hash Variables */
DECLARE @v_data_hash AS VARCHAR(100);
DECLARE @v_key_hash AS VARCHAR(100);
DECLARE @v_all_data_hashes AS VARCHAR(100);  
DECLARE @v_hashed_data_hashes AS VARCHAR(100); 
DECLARE @v_enabled AS CHAR(1);
DECLARE @v_enabled_val AS CHAR(1);

DECLARE payload_type_delete CURSOR 
    FOR SELECT DISTINCT child_table.name child_table_name 
          FROM sys.foreign_key_columns
          JOIN sys.objects child_table
            ON (child_table.object_id = foreign_key_columns.parent_object_id)
          JOIN sys.objects parent_table
            ON (parent_table.object_id = foreign_key_columns.referenced_object_id)
          JOIN sys.schemas
            ON (parent_table.schema_id = schemas.schema_id)    
         WHERE schemas.name = 'dbo'
           AND parent_table.name = 'ICA_PAYLOAD'
         ORDER BY child_table.name;        
         
DECLARE payload_type_process CURSOR 
    FOR SELECT DISTINCT child_table.name child_table_name 
          FROM sys.foreign_key_columns
          JOIN sys.objects child_table
            ON (child_table.object_id = foreign_key_columns.parent_object_id)
          JOIN sys.objects parent_table
            ON (parent_table.object_id = foreign_key_columns.referenced_object_id)
          JOIN sys.schemas
            ON (parent_table.schema_id = schemas.schema_id)    
         WHERE schemas.name = 'dbo'
           AND parent_table.name = 'ICA_PAYLOAD'
           /* The tables in this list will not have related child data, change processing can be skipped */
           AND child_table.name NOT IN ( 'ICA_BS_PROG_REP'
                                       , 'ICA_CSO_EVT_REP'
                                       , 'ICA_DMR_VIOL'
                                       , 'ICA_ENFRC_ACTN_MILESTONE'
                                       , 'ICA_HIST_PRMT_SCHD_EVTS'
                                       , 'ICA_PRMT_REISSU'
                                       , 'ICA_PRMT_TRACK_EVT'
                                       , 'ICA_PRMT_TERM'
                                       , 'ICA_SCHD_EVT_VIOL'
                                       , 'ICA_SNGL_EVT_VIOL'
                                       , 'ICA_SSO_ANNUL_REP'
                                       , 'ICA_SSO_MONTHLY_EVT_REP')
         ORDER BY child_table.name; 
          
                        
DECLARE key_hash CURSOR 
    FOR SELECT ica_key_hash.key_hash 
          FROM ica_key_hash;
                      
DECLARE data_hash CURSOR 
    FOR SELECT ica_data_hash.data_hash 
          FROM ica_data_hash
        ORDER BY data_hash;
                        
BEGIN

 /*  Initialize working table ICA_KEY_HASH */
 DELETE FROM ica_key_hash;

 /*  Initialize working table ICA_DATA_HASH */
 DELETE FROM ica_data_hash;
 
 /*  
  * Reset transaction_type on all payload tables  
  */
  OPEN payload_type_delete;
  
  
  
  /*  Fetch 1st payload type record */
  FETCH NEXT FROM payload_type_delete INTO @p_payload_type;
  WHILE @@FETCH_STATUS = 0
    BEGIN

      /* For each payload type, remove all the transaction codes from the previous run. */
      SET @v_sql_statement = 'UPDATE ' + @p_payload_type + ' SET TRANSACTION_TYPE = NULL , TRANSACTION_TIMESTAMP = NULL';
      EXECUTE sp_executesql @v_sql_statement;

      -- Get the payload type.
      FETCH NEXT FROM payload_type_delete 
      INTO @p_payload_type;

    END;

   CLOSE payload_type_delete;
  
  /*************************************************/  
  /* START - Set all KEY_HASH and DATA_HASH fields */
  /*************************************************/  
  UPDATE ICA_FLOW_LOCAL.dbo.ica_case_file_cmnt_txt
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    case_file_cmnt_txt
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_cmpl_insp_type
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    cmpl_insp_type_code
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_cmpl_mon_strgy
     SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', ICA_FLOW_LOCAL.dbo.ica_cmpl_mon_strgy.fac_ident),
        data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    ISNULL(src_systm_ident,'')
	  + fac_ident
	  + ISNULL(cms_src_catg_code,'')
	  + ISNULL(CONVERT(varchar(50), cms_min_freq),'')
	  + ISNULL(CONVERT(varchar(50), cms_start_date),'')
	  + ISNULL(active_cms_plan_ind,'')
	  + ISNULL(CONVERT(varchar(50), rmvd_plan_date),'')
	  + ISNULL(rsn_chng_cms_cmnts,'')
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_cntct
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    affil_type_txt
	  + first_name
	  + ISNULL(middle_name,'')
	  + last_name
	  + indvl_title_txt
	  + ISNULL(org_frml_name,'')
	  + ISNULL(st_code,'')
	  + ISNULL(rgn_code,'')
	  + ISNULL(elec_addr_txt,'')
	  + ISNULL(CONVERT(varchar(50), start_date_of_cntct_assc),'')
	  + ISNULL(CONVERT(varchar(50), end_date_of_cntct_assc),'')
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_da_case_file
     SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', ICA_FLOW_LOCAL.dbo.ica_da_case_file.case_file_ident),
        data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    ISNULL(src_systm_ident,'')
	  + case_file_ident
	  + ISNULL(case_file_name,'')
	  + ISNULL(lead_agncy_code,'')
	  + fac_ident
	  + ISNULL(othr_prog_desc_txt,'')
	  + ISNULL(sens_data_ind,'')
	  + ISNULL(lead_agncy_chng_sprsed_txt,'')
	  + ISNULL(advise_method_type_code,'')
	  + ISNULL(CONVERT(varchar(50), advise_method_date),'')
	  + ISNULL(case_file_usr_def_fld_1,'')
	  + ISNULL(case_file_usr_def_fld_2,'')
	  + ISNULL(case_file_usr_def_fld_3,'')
	  + ISNULL(CONVERT(varchar(50), case_file_usr_def_fld_4),'')
	  + ISNULL(CONVERT(varchar(50), case_file_usr_def_fld_5),'')
	  + ISNULL(case_file_usr_def_fld_6,'')
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_da_cmpl_mon
     SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', ICA_FLOW_LOCAL.dbo.ica_da_cmpl_mon.cmpl_mon_ident),
        data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    ISNULL(src_systm_ident,'')
	  + cmpl_mon_ident
	  + ISNULL(cmpl_mon_acty_type_code,'')
	  + ISNULL(CONVERT(varchar(50), cmpl_mon_date),'')
	  + ISNULL(CONVERT(varchar(50), cmpl_mon_start_date),'')
	  + ISNULL(cmpl_mon_acty_name,'')
	  + ISNULL(multimedia_ind,'')
	  + ISNULL(CONVERT(varchar(50), cmpl_mon_planned_start_date),'')
	  + ISNULL(CONVERT(varchar(50), cmpl_mon_planned_end_date),'')
	  + ISNULL(deficiencies_obs_ind,'')
	  + ISNULL(lead_agncy_code,'')
	  + ISNULL(othr_prog_desc_txt,'')
	  + ISNULL(othr_agncy_initiative_txt,'')
	  + ISNULL(insp_usr_def_fld_1,'')
	  + ISNULL(insp_usr_def_fld_2,'')
	  + ISNULL(insp_usr_def_fld_3,'')
	  + ISNULL(CONVERT(varchar(50), insp_usr_def_fld_4),'')
	  + ISNULL(CONVERT(varchar(50), insp_usr_def_fld_5),'')
	  + ISNULL(insp_usr_def_fld_6,'')
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_da_enfrc_actn_milstn
     SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', ICA_FLOW_LOCAL.dbo.ica_da_enfrc_actn_milstn.da_enfrc_actn_ident + milstn_type_code),
        data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    ISNULL(src_systm_ident,'')
	  + da_enfrc_actn_ident
	  + milstn_type_code
	  + ISNULL(CONVERT(varchar(50), milstn_planned_date),'')
	  + ISNULL(CONVERT(varchar(50), milstn_actual_date),'')
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_da_final_order
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    CONVERT(varchar(50), final_order_ident)
	  + ISNULL(final_order_type_code,'')
	  + ISNULL(CONVERT(varchar(50), final_order_issued_enterd_date),'')
	  + ISNULL(CONVERT(varchar(50), rslvd_date),'')
	  + ISNULL(CONVERT(varchar(50), cash_civil_pnlty_reqd_amt),'')
	  + ISNULL(othr_cmnts,'')
	  + ISNULL(CONVERT(varchar(50), final_order_lodged_date),'')
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_da_frml_enfrc_actn
     SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', ICA_FLOW_LOCAL.dbo.ica_da_frml_enfrc_actn.da_enfrc_actn_ident),
        data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    ISNULL(src_systm_ident,'')
	  + da_enfrc_actn_ident
	  + ISNULL(enfrc_actn_name,'')
	  + ISNULL(forum,'')
	  + ISNULL(resl_type_code,'')
	  + ISNULL(da_comb_sprsed_eaid,'')
	  + ISNULL(rsn_del_rec,'')
	  + ISNULL(frml_ea_usr_def_fld_1,'')
	  + ISNULL(frml_ea_usr_def_fld_2,'')
	  + ISNULL(frml_ea_usr_def_fld_3,'')
	  + ISNULL(CONVERT(varchar(50), frml_ea_usr_def_fld_4),'')
	  + ISNULL(CONVERT(varchar(50), frml_ea_usr_def_fld_5),'')
	  + ISNULL(frml_ea_usr_def_fld_6,'')
	  + ISNULL(lead_agncy_code,'')
	  + ISNULL(enfrc_agncy_name,'')
	  + ISNULL(othr_agncy_initiative_txt,'')
	  + ISNULL(othr_prog_desc_txt,'')
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_da_infrml_enfrc_actn
     SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', ICA_FLOW_LOCAL.dbo.ica_da_infrml_enfrc_actn.da_enfrc_actn_ident),
        data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    ISNULL(src_systm_ident,'')
	  + da_enfrc_actn_ident
	  + ISNULL(enfrc_actn_type_code,'')
	  + ISNULL(enfrc_actn_name,'')
	  + ISNULL(CONVERT(varchar(50), achieved_date),'')
	  + ISNULL(file_num,'')
	  + ISNULL(rsn_del_rec,'')
	  + ISNULL(infrml_ea_usr_def_fld_1,'')
	  + ISNULL(infrml_ea_usr_def_fld_2,'')
	  + ISNULL(infrml_ea_usr_def_fld_3,'')
	  + ISNULL(CONVERT(varchar(50), infrml_ea_usr_def_fld_4),'')
	  + ISNULL(CONVERT(varchar(50), infrml_ea_usr_def_fld_5),'')
	  + ISNULL(infrml_ea_usr_def_fld_6,'')
	  + ISNULL(lead_agncy_code,'')
	  + ISNULL(enfrc_agncy_name,'')
	  + ISNULL(othr_agncy_initiative_txt,'')
	  + ISNULL(st_sects_viol_txt,'')
	  + ISNULL(othr_prog_desc_txt,'')
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_enfrc_actn_cmnt_txt
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    enfrc_actn_cmnt_txt
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_enfrc_actn_gov_cntct
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    affil_type_txt
	  + ISNULL(elec_addr_txt,'')
	  + ISNULL(CONVERT(varchar(50), start_date_of_cntct_assc),'')
	  + ISNULL(CONVERT(varchar(50), end_date_of_cntct_assc),'')
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_enfrc_actn_type
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    enfrc_actn_type_code
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_enfrc_agncy_type
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    enfrc_agncy_type_code
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_fac
     SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', ICA_FLOW_LOCAL.dbo.ica_fac.fac_ident),
        data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    ISNULL(src_systm_ident,'')
	  + fac_ident
	  + ISNULL(fac_site_name,'')
	  + ISNULL(loc_addr_txt,'')
	  + ISNULL(suppl_loc_txt,'')
	  + ISNULL(loc_addr_city_code,'')
	  + ISNULL(loc_st_code,'')
	  + ISNULL(loc_zip_code,'')
	  + ISNULL(lcon_code,'')
	  + ISNULL(tribal_land_code,'')
	  + ISNULL(fac_desc,'')
	  + ISNULL(fac_type_of_owner_code,'')
	  + ISNULL(reg_num,'')
	  + ISNULL(small_busnss_ind,'')
	  + ISNULL(federally_rep_ind,'')
	  + ISNULL(src_unifm_rsrc_locator_url,'')
	  + ISNULL(envr_justice_code,'')
	  + ISNULL(CONVERT(varchar(50), fac_congr_district_num),'')
	  + ISNULL(fac_usr_def_fld_1,'')
	  + ISNULL(fac_usr_def_fld_2,'')
	  + ISNULL(fac_usr_def_fld_3,'')
	  + ISNULL(fac_usr_def_fld_4,'')
	  + ISNULL(fac_usr_def_fld_5,'')
	  + ISNULL(fac_cmnts,'')
	  + ISNULL(port_src_ind,'')
	  + ISNULL(locality_name,'')
	  + ISNULL(loc_addr_county_code,'')


  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_fac_addr
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    affil_type_txt
	  + ISNULL(org_frml_name,'')
	  + ISNULL(org_duns_num,'')
	  + ISNULL(mailing_addr_txt,'')
	  + ISNULL(suppl_addr_txt,'')
	  + ISNULL(mailing_addr_city_name,'')
	  + ISNULL(mailing_addr_st_code,'')
	  + ISNULL(mailing_addr_zip_code,'')
	  + ISNULL(county_name,'')
	  + ISNULL(mailing_addr_country_code,'')
	  + ISNULL(division_name,'')
	  + ISNULL(loc_province,'')
	  + ISNULL(elec_addr_txt,'')
	  + ISNULL(CONVERT(varchar(50), start_date_of_addr_assc),'')
	  + ISNULL(CONVERT(varchar(50), end_date_of_addr_assc),'')
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_fac_ident
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    fac_ident
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_final_order_fac_ident
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    final_order_fac_ident
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_demnd_stipultd_pnlty
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
      ISNULL(CONVERT(varchar(50), demnd_stipultd_pnlty_amt),'')
	  + ISNULL(CONVERT(varchar(50), demnd_stipultd_pnlty_paid_date),'')
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_geo_coord
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    ISNULL(lat_meas,'')
	  + ISNULL(long_meas,'')
	  + ISNULL(CONVERT(varchar(50), horz_accuracy_meas),'')
	  + ISNULL(geom_type_code,'')
	  + ISNULL(horz_coll_method_code,'')
	  + ISNULL(horz_ref_datum_code,'')
	  + ISNULL(ref_point_code,'')
	  + ISNULL(CONVERT(varchar(50), src_map_scale_num),'')
	  + ISNULL(utm_coord_1,'')
	  + ISNULL(utm_coord_2,'')
	  + ISNULL(utm_coord_3,'')
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_infrml_ea_cmnt_txt
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    infrml_ea_cmnt_txt
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_insp_cmnt_txt
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    insp_cmnt_txt
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_insp_gov_cntct
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    affil_type_txt
	  + ISNULL(elec_addr_txt,'')
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_lnk_case_file
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    case_file_ident
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_lnk_cmpl_mon
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    cmpl_mon_ident
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_lnk_da_enfrc_actn
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    da_enfrc_actn_ident
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_method
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    method_code
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_naics_code
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    naics_code
	  + naics_pri_ind_code
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_nat_prio
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    CONVERT(varchar(50), nat_prio_code)
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_othr_pathway_acty
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    othr_pathway_catg_code
	  + othr_pathway_type_code
	  + CONVERT(varchar(50), othr_pathway_date)
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_payload
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    ISNULL(operation,'')
	  + enabled
	  + auto_gen_deletes);

  UPDATE ICA_FLOW_LOCAL.dbo.ica_polut
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    CONVERT(varchar(50), polut_code)
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_polut_da_class
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    polut_da_class_code
	  + ISNULL(CONVERT(varchar(50), polut_da_class_start_date),'')
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_polut_epa_class
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    polut_epa_class_code
	  + ISNULL(CONVERT(varchar(50), polut_epa_class_start_date),'')
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_poluts
     SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', ICA_FLOW_LOCAL.dbo.ica_poluts.fac_ident + CAST(poluts_code AS VARCHAR(255))),
        data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    ISNULL(src_systm_ident,'')
	  + fac_ident
	  + ISNULL(CONVERT(varchar(50), poluts_code),'')
	  + ISNULL(polut_stat_ind,'')
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_port_src
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  --  port_src_ind
	  --+ 
   port_src_site_name
	  + CONVERT(varchar(50), port_src_start_date)
	  + ISNULL(CONVERT(varchar(50), port_src_end_date),'')
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_prog
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    prog_code
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_prog_subpart
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    prog_subpart_code
	  + ISNULL(prog_subpart_stat_ind,'')
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_progs
     SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', ICA_FLOW_LOCAL.dbo.ica_progs.fac_ident + prog_code),
        data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    ISNULL(src_systm_ident,'')
	  + fac_ident
	  + prog_code
	  + ISNULL(othr_prog_desc_txt,'')
	  + prog_oper_stat_code
	  + ISNULL(CONVERT(varchar(50), prog_oper_stat_start_date),'')
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_progs_viol
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    progs_viol_code
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_rgnl_prio
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    CONVERT(varchar(50), rgnl_prio_code)
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_sens_cmnt_txt
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    sens_cmnt_txt
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_sic_code
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    sic_code
	  + sic_pri_ind_code
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_stck_tst
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    stck_tst_stat_code
	  + stck_tst_cndctr_type_code
	  + ISNULL(stck_ident,'')
	  + ISNULL(othr_stck_tst_purpose_name,'')
	  + ISNULL(CONVERT(varchar(50), stck_tst_rep_rcvd_date),'')
	  + ISNULL(CONVERT(varchar(50), tst_rslts_reviewed_date),'')
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_stck_tst_obs_agncy_type
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    stck_tst_obs_agncy_type_code
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_stck_tst_purpose
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    stck_tst_purpose_code
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_teleph
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    teleph_num_type_code
	  + ISNULL(teleph_num,'')
	  + ISNULL(teleph_ext_num,'')
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_tst_rslts
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    CONVERT(varchar(50), tested_polut_code)
	  + ISNULL(tst_result_code,'')
	  + ISNULL(CONVERT(varchar(50), allowable_value),'')
	  + ISNULL(allowable_unit_code,'')
	  + ISNULL(CONVERT(varchar(50), actual_result),'')
	  + ISNULL(failure_rsn_code,'')
	  + ISNULL(othr_failure_rsn_txt,'')
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_tvacc
     SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', ICA_FLOW_LOCAL.dbo.ica_tvacc.cmpl_mon_ident),
        data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    ISNULL(src_systm_ident,'')
	  + cmpl_mon_ident
	  + ISNULL(CONVERT(varchar(50), cmpl_mon_date),'')
	  + ISNULL(CONVERT(varchar(50), cmpl_mon_start_date),'')
	  + ISNULL(cmpl_mon_acty_name,'')
	  + ISNULL(multimedia_ind,'')
	  + ISNULL(CONVERT(varchar(50), cmpl_mon_planned_start_date),'')
	  + ISNULL(CONVERT(varchar(50), cmpl_mon_planned_end_date),'')
	  + ISNULL(deficiencies_obs_ind,'')
	  + fac_ident
	  + ISNULL(lead_agncy_code,'')
	  + ISNULL(othr_prog_desc_txt,'')
	  + ISNULL(othr_agncy_initiative_txt,'')
	  + ISNULL(insp_usr_def_fld_1,'')
	  + ISNULL(insp_usr_def_fld_2,'')
	  + ISNULL(insp_usr_def_fld_3,'')
	  + ISNULL(CONVERT(varchar(50), insp_usr_def_fld_4),'')
	  + ISNULL(CONVERT(varchar(50), insp_usr_def_fld_5),'')
	  + ISNULL(insp_usr_def_fld_6,'')
	  + ISNULL(prmt_ident,'')
	  + ISNULL(CONVERT(varchar(50), cert_period_start_date),'')
	  + ISNULL(CONVERT(varchar(50), cert_period_end_date),'')
	  + ISNULL(fac_rep_cmpl_stat_code,'')
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_tvacc_review
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    CONVERT(varchar(50), tvacc_reviewed_date)
	  + ISNULL(fac_rep_deviations_ind,'')
	  + ISNULL(prmt_conds_txt,'')
	  + ISNULL(exceed_excurs_ind,'')
	  + ISNULL(reviewer_agncy_code,'')
	  + ISNULL(tvacc_reviewer_name,'')
	  + ISNULL(reviewer_cmnt,'')
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_universe_ind
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    universe_ind_code
  );
  UPDATE ICA_FLOW_LOCAL.dbo.ica_viol
      SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	    viol_type_code
	  + viol_prog_code
	  + ISNULL(viol_prog_desc_txt,'')
	  + ISNULL(CONVERT(varchar(50), viol_polut_code),'')
	  + ISNULL(CONVERT(varchar(50), frv_dtrmn_date),'')
	  + ISNULL(CONVERT(varchar(50), hpv_day_zero_date),'')
	  + ISNULL(CONVERT(varchar(50), occurrence_start_date),'')
	  + ISNULL(CONVERT(varchar(50), occurrence_end_date),'')
	  + ISNULL(hpv_desgn_rmvl_type_code,'')
	  + ISNULL(CONVERT(varchar(50), hpv_desgn_rmvl_date),'')
	  + ISNULL(CONVERT(varchar(50), claims_num),'')
  );

  /* Linkage Tables */
  UPDATE ica_flow_local.dbo.ica_cmpl_mon_lnk
     SET key_hash = dbo.HASHBYTES_VARCHAR( 'SHA1' , 
                                           ISNULL(ica_cmpl_mon_lnk.cmpl_mon_ident,'')
                                         + ISNULL(ica_lnk_cmpl_mon.cmpl_mon_ident,'')
                                         + ISNULL(ica_lnk_da_enfrc_actn.da_enfrc_actn_ident,''))
       , data_hash = dbo.HASHBYTES_VARCHAR( 'SHA1', 
	                                          ISNULL(ica_cmpl_mon_lnk.src_systm_ident,'')
	                                        + ISNULL(ica_cmpl_mon_lnk.cmpl_mon_ident,''))
    FROM ica_cmpl_mon_lnk
    LEFT JOIN ica_lnk_cmpl_mon on ica_lnk_cmpl_mon.ica_cmpl_mon_lnk_id = ica_cmpl_mon_lnk.ica_cmpl_mon_lnk_id
    LEFT JOIN ica_lnk_da_enfrc_actn on ica_lnk_da_enfrc_actn.ica_cmpl_mon_lnk_id = ica_cmpl_mon_lnk.ica_cmpl_mon_lnk_id;

  UPDATE ica_flow_local.dbo.ica_da_enfrc_actn_lnk
     SET key_hash = dbo.HASHBYTES_VARCHAR( 'SHA1' , 
                                           ISNULL(ica_da_enfrc_actn_lnk.da_enfrc_actn_ident,'')
                                         + ISNULL(ica_lnk_da_enfrc_actn.da_enfrc_actn_ident,''))
       , data_hash = dbo.HASHBYTES_VARCHAR( 'SHA1'
                                          , ISNULL(ica_da_enfrc_actn_lnk.src_systm_ident,'')
	                                        + ISNULL(ica_da_enfrc_actn_lnk.da_enfrc_actn_ident,''))
    FROM ica_da_enfrc_actn_lnk
    LEFT JOIN ica_lnk_da_enfrc_actn on ica_lnk_da_enfrc_actn.ica_da_enfrc_actn_lnk_id = ica_da_enfrc_actn_lnk.ica_da_enfrc_actn_lnk_id;

  UPDATE ica_flow_local.dbo.ica_case_file_lnk
     SET key_hash = dbo.HASHBYTES_VARCHAR( 'SHA1' , 
                                           ISNULL(ica_case_file_lnk.case_file_ident,'')
                                         + ISNULL(ica_lnk_case_file.case_file_ident,'')
                                         + ISNULL(ica_lnk_cmpl_mon.cmpl_mon_ident,'')
                                         + ISNULL(ica_lnk_da_enfrc_actn.da_enfrc_actn_ident,''))
       , data_hash = dbo.HASHBYTES_VARCHAR( 'SHA1'
                                          , ISNULL(ica_case_file_lnk.src_systm_ident,'')
	                                        + ISNULL(ica_case_file_lnk.case_file_ident,''))
    FROM ica_case_file_lnk
    LEFT JOIN ica_lnk_case_file on ica_lnk_case_file.ica_case_file_lnk_id = ica_case_file_lnk.ica_case_file_lnk_id
    LEFT JOIN ica_lnk_cmpl_mon on ica_lnk_cmpl_mon.ica_case_file_lnk_id = ica_case_file_lnk.ica_case_file_lnk_id
    LEFT JOIN ica_lnk_da_enfrc_actn on ica_lnk_da_enfrc_actn.ica_case_file_lnk_id = ica_case_file_lnk.ica_case_file_lnk_id;


  /************************************/  
  /* START - Process DATA_HASH values */
  /* START - Process DATA_HASH values */
  /* START - Process DATA_HASH values */
  /************************************/ 
 
  /* Loop through each payload type, for each loop roll child data_hash values up to the parent payload table */  
  OPEN payload_type_process;

  -- Get 1st payload type
  FETCH NEXT FROM payload_type_process INTO @p_payload_type;
  WHILE @@FETCH_STATUS = 0
    BEGIN

      SET @v_sql_statement = 'SELECT TOP 1 @v_enabled_val = [ENABLED] FROM ICA_PAYLOAD JOIN ' + @p_payload_type +
        ' ON ICA_PAYLOAD.ICA_PAYLOAD_ID = ' + @p_payload_type + '.ICA_PAYLOAD_ID'
      SET @v_sql_param = '@v_enabled_val CHAR(1) OUTPUT';

      EXEC sp_executesql @v_sql_statement, @v_sql_param, @v_enabled_val=@v_enabled OUTPUT;

      SET @v_enabled = ISNULL(@v_enabled, 'N');

      /* Flush the prior payload type's key_hash values */
      DELETE FROM ica_key_hash;
      
      /* Load next key_hash set for current payload type */ 
      SET @v_sql_statement = 'INSERT INTO ica_key_hash SELECT key_hash FROM ' + @p_payload_type; 
      EXECUTE sp_executesql @v_sql_statement;
        
     /* 
      *  Loop through each key in a payload type's key set.  For each key traverse the payload type's data heirarchy
      *  and load the child data_hash values into working table ICA_DATA_HASH for later processing at the end of 
      *  the loop.
      */
      OPEN key_hash;

      /*  Fetch 1st payload type */
      FETCH NEXT FROM key_hash INTO @v_key_hash;
      WHILE @@FETCH_STATUS = 0
        BEGIN    

		    /* Flush the prior payload's data_hash values */
		    DELETE FROM ica_data_hash;

     IF @p_payload_type = 'ICA_CMPL_MON_STRGY' and @v_enabled = 'Y'
        BEGIN

        -- /ICA_CMPL_MON_STRGY
        INSERT INTO ica_data_hash
             SELECT ica_cmpl_mon_strgy.data_hash
               FROM ica_cmpl_mon_strgy
              WHERE ica_cmpl_mon_strgy.key_hash = @v_key_hash;

        END;

     IF @p_payload_type = 'ICA_DA_CMPL_MON' and @v_enabled = 'Y'
        BEGIN

        -- /ICA_DA_CMPL_MON
        INSERT INTO ica_data_hash
             SELECT ica_da_cmpl_mon.data_hash
               FROM ica_da_cmpl_mon
              WHERE ica_da_cmpl_mon.key_hash = @v_key_hash;

        -- /ICA_DA_CMPL_MON/ICA_CMPL_INSP_TYPE
        INSERT INTO ica_data_hash
             SELECT ica_cmpl_insp_type.data_hash
               FROM ica_da_cmpl_mon
               JOIN ica_cmpl_insp_type
                 ON ica_cmpl_insp_type.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
              WHERE ica_da_cmpl_mon.key_hash = @v_key_hash;

        -- /ICA_DA_CMPL_MON/ICA_CNTCT
        INSERT INTO ica_data_hash
             SELECT ica_cntct.data_hash
               FROM ica_da_cmpl_mon
               JOIN ica_cntct
                 ON ica_cntct.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
              WHERE ica_da_cmpl_mon.key_hash = @v_key_hash;

        -- /ICA_DA_CMPL_MON/ICA_CNTCT/ICA_TELEPH
        INSERT INTO ica_data_hash
             SELECT ica_teleph.data_hash
               FROM ica_da_cmpl_mon
               JOIN ica_cntct
                 ON ica_cntct.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
               JOIN ica_teleph
                 ON ica_teleph.ica_cntct_id = ica_cntct.ica_cntct_id
              WHERE ica_da_cmpl_mon.key_hash = @v_key_hash;

        -- /ICA_DA_CMPL_MON/ICA_FAC_IDENT
        INSERT INTO ica_data_hash
             SELECT ica_fac_ident.data_hash
               FROM ica_da_cmpl_mon
               JOIN ica_fac_ident
                 ON ica_fac_ident.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
              WHERE ica_da_cmpl_mon.key_hash = @v_key_hash;

        -- /ICA_DA_CMPL_MON/ICA_INSP_CMNT_TXT
        INSERT INTO ica_data_hash
             SELECT ica_insp_cmnt_txt.data_hash
               FROM ica_da_cmpl_mon
               JOIN ica_insp_cmnt_txt
                 ON ica_insp_cmnt_txt.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
              WHERE ica_da_cmpl_mon.key_hash = @v_key_hash;

        -- /ICA_DA_CMPL_MON/ICA_INSP_GOV_CNTCT
        INSERT INTO ica_data_hash
             SELECT ica_insp_gov_cntct.data_hash
               FROM ica_da_cmpl_mon
               JOIN ica_insp_gov_cntct
                 ON ica_insp_gov_cntct.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
              WHERE ica_da_cmpl_mon.key_hash = @v_key_hash;

        -- /ICA_DA_CMPL_MON/ICA_NAT_PRIO
        INSERT INTO ica_data_hash
             SELECT ica_nat_prio.data_hash
               FROM ica_da_cmpl_mon
               JOIN ica_nat_prio
                 ON ica_nat_prio.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
              WHERE ica_da_cmpl_mon.key_hash = @v_key_hash;

        -- /ICA_DA_CMPL_MON/ICA_POLUT
        INSERT INTO ica_data_hash
             SELECT ica_polut.data_hash
               FROM ica_da_cmpl_mon
               JOIN ica_polut
                 ON ica_polut.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
              WHERE ica_da_cmpl_mon.key_hash = @v_key_hash;

        -- /ICA_DA_CMPL_MON/ICA_PROG
        INSERT INTO ica_data_hash
             SELECT ica_prog.data_hash
               FROM ica_da_cmpl_mon
               JOIN ica_prog
                 ON ica_prog.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
              WHERE ica_da_cmpl_mon.key_hash = @v_key_hash;

        -- /ICA_DA_CMPL_MON/ICA_RGNL_PRIO
        INSERT INTO ica_data_hash
             SELECT ica_rgnl_prio.data_hash
               FROM ica_da_cmpl_mon
               JOIN ica_rgnl_prio
                 ON ica_rgnl_prio.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
              WHERE ica_da_cmpl_mon.key_hash = @v_key_hash;

        -- /ICA_DA_CMPL_MON/ICA_SENS_CMNT_TXT
        INSERT INTO ica_data_hash
             SELECT ica_sens_cmnt_txt.data_hash
               FROM ica_da_cmpl_mon
               JOIN ica_sens_cmnt_txt
                 ON ica_sens_cmnt_txt.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
              WHERE ica_da_cmpl_mon.key_hash = @v_key_hash;

        -- /ICA_DA_CMPL_MON/ICA_STCK_TST
        INSERT INTO ica_data_hash
             SELECT ica_stck_tst.data_hash
               FROM ica_da_cmpl_mon
               JOIN ica_stck_tst
                 ON ica_stck_tst.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
              WHERE ica_da_cmpl_mon.key_hash = @v_key_hash;

        -- /ICA_DA_CMPL_MON/ICA_STCK_TST/ICA_STCK_TST_OBS_AGNCY_TYPE
        INSERT INTO ica_data_hash
             SELECT ica_stck_tst_obs_agncy_type.data_hash
               FROM ica_da_cmpl_mon
               JOIN ica_stck_tst
                 ON ica_stck_tst.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
               JOIN ica_stck_tst_obs_agncy_type
                 ON ica_stck_tst_obs_agncy_type.ica_stck_tst_id = ica_stck_tst.ica_stck_tst_id
              WHERE ica_da_cmpl_mon.key_hash = @v_key_hash;

        -- /ICA_DA_CMPL_MON/ICA_STCK_TST/ICA_STCK_TST_PURPOSE
        INSERT INTO ica_data_hash
             SELECT ica_stck_tst_purpose.data_hash
               FROM ica_da_cmpl_mon
               JOIN ica_stck_tst
                 ON ica_stck_tst.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
               JOIN ica_stck_tst_purpose
                 ON ica_stck_tst_purpose.ica_stck_tst_id = ica_stck_tst.ica_stck_tst_id
              WHERE ica_da_cmpl_mon.key_hash = @v_key_hash;

        -- /ICA_DA_CMPL_MON/ICA_STCK_TST/ICA_TST_RSLTS
        INSERT INTO ica_data_hash
             SELECT ica_tst_rslts.data_hash
               FROM ica_da_cmpl_mon
               JOIN ica_stck_tst
                 ON ica_stck_tst.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
               JOIN ica_tst_rslts
                 ON ica_tst_rslts.ica_stck_tst_id = ica_stck_tst.ica_stck_tst_id
              WHERE ica_da_cmpl_mon.key_hash = @v_key_hash;

        -- /ICA_DA_CMPL_MON/ICA_STCK_TST/ICA_TST_RSLTS/ICA_METHOD
        INSERT INTO ica_data_hash
             SELECT ica_method.data_hash
               FROM ica_da_cmpl_mon
               JOIN ica_stck_tst
                 ON ica_stck_tst.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
               JOIN ica_tst_rslts
                 ON ica_tst_rslts.ica_stck_tst_id = ica_stck_tst.ica_stck_tst_id
               JOIN ica_method
                 ON ica_method.ica_tst_rslts_id = ica_tst_rslts.ica_tst_rslts_id
              WHERE ica_da_cmpl_mon.key_hash = @v_key_hash;

        END;

     IF @p_payload_type = 'ICA_DA_ENFRC_ACTN_MILSTN' and @v_enabled = 'Y'
        BEGIN

        -- /ICA_DA_ENFRC_ACTN_MILSTN
        INSERT INTO ica_data_hash
             SELECT ica_da_enfrc_actn_milstn.data_hash
               FROM ica_da_enfrc_actn_milstn
              WHERE ica_da_enfrc_actn_milstn.key_hash = @v_key_hash;

        END;

     IF @p_payload_type = 'ICA_DA_FRML_ENFRC_ACTN' and @v_enabled = 'Y'
        BEGIN

        -- /ICA_DA_FRML_ENFRC_ACTN
        INSERT INTO ica_data_hash
             SELECT ica_da_frml_enfrc_actn.data_hash
               FROM ica_da_frml_enfrc_actn
              WHERE ica_da_frml_enfrc_actn.key_hash = @v_key_hash;

        -- /ICA_DA_FRML_ENFRC_ACTN/ICA_DA_FINAL_ORDER
        INSERT INTO ica_data_hash
             SELECT ica_da_final_order.data_hash
               FROM ica_da_frml_enfrc_actn
               JOIN ica_da_final_order
                 ON ica_da_final_order.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
              WHERE ica_da_frml_enfrc_actn.key_hash = @v_key_hash;

        -- /ICA_DA_FRML_ENFRC_ACTN/ICA_DA_FINAL_ORDER/ICA_FINAL_ORDER_FAC_IDENT
        INSERT INTO ica_data_hash
             SELECT ica_final_order_fac_ident.data_hash
               FROM ica_da_frml_enfrc_actn
               JOIN ica_da_final_order
                 ON ica_da_final_order.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
               JOIN ica_final_order_fac_ident
                 ON ica_final_order_fac_ident.ica_da_final_order_id = ica_da_final_order.ica_da_final_order_id
              WHERE ica_da_frml_enfrc_actn.key_hash = @v_key_hash;

        -- /ICA_DA_FRML_ENFRC_ACTN/ICA_DA_FINAL_ORDER/ICA_DEMND_STIPULTD_PNLTY
        INSERT INTO ica_data_hash
             SELECT ica_demnd_stipultd_pnlty.data_hash
               FROM ica_da_frml_enfrc_actn
               JOIN ica_da_final_order
                 ON ica_da_final_order.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
               JOIN ica_demnd_stipultd_pnlty
                 ON ica_demnd_stipultd_pnlty.ica_da_final_order_id = ica_da_final_order.ica_da_final_order_id
              WHERE ica_da_frml_enfrc_actn.key_hash = @v_key_hash;

        -- /ICA_DA_FRML_ENFRC_ACTN/ICA_ENFRC_ACTN_CMNT_TXT
        INSERT INTO ica_data_hash
             SELECT ica_enfrc_actn_cmnt_txt.data_hash
               FROM ica_da_frml_enfrc_actn
               JOIN ica_enfrc_actn_cmnt_txt
                 ON ica_enfrc_actn_cmnt_txt.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
              WHERE ica_da_frml_enfrc_actn.key_hash = @v_key_hash;

        -- /ICA_DA_FRML_ENFRC_ACTN/ICA_ENFRC_ACTN_GOV_CNTCT
        INSERT INTO ica_data_hash
             SELECT ica_enfrc_actn_gov_cntct.data_hash
               FROM ica_da_frml_enfrc_actn
               JOIN ica_enfrc_actn_gov_cntct
                 ON ica_enfrc_actn_gov_cntct.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
              WHERE ica_da_frml_enfrc_actn.key_hash = @v_key_hash;

        -- /ICA_DA_FRML_ENFRC_ACTN/ICA_ENFRC_ACTN_TYPE
        INSERT INTO ica_data_hash
             SELECT ica_enfrc_actn_type.data_hash
               FROM ica_da_frml_enfrc_actn
               JOIN ica_enfrc_actn_type
                 ON ica_enfrc_actn_type.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
              WHERE ica_da_frml_enfrc_actn.key_hash = @v_key_hash;

        -- /ICA_DA_FRML_ENFRC_ACTN/ICA_ENFRC_AGNCY_TYPE
        INSERT INTO ica_data_hash
             SELECT ica_enfrc_agncy_type.data_hash
               FROM ica_da_frml_enfrc_actn
               JOIN ica_enfrc_agncy_type
                 ON ica_enfrc_agncy_type.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
              WHERE ica_da_frml_enfrc_actn.key_hash = @v_key_hash;

        -- /ICA_DA_FRML_ENFRC_ACTN/ICA_FAC_IDENT
        INSERT INTO ica_data_hash
             SELECT ica_fac_ident.data_hash
               FROM ica_da_frml_enfrc_actn
               JOIN ica_fac_ident
                 ON ica_fac_ident.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
              WHERE ica_da_frml_enfrc_actn.key_hash = @v_key_hash;

        -- /ICA_DA_FRML_ENFRC_ACTN/ICA_POLUT
        INSERT INTO ica_data_hash
             SELECT ica_polut.data_hash
               FROM ica_da_frml_enfrc_actn
               JOIN ica_polut
                 ON ica_polut.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
              WHERE ica_da_frml_enfrc_actn.key_hash = @v_key_hash;

        -- /ICA_DA_FRML_ENFRC_ACTN/ICA_PROGS_VIOL
        INSERT INTO ica_data_hash
             SELECT ica_progs_viol.data_hash
               FROM ica_da_frml_enfrc_actn
               JOIN ica_progs_viol
                 ON ica_progs_viol.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
              WHERE ica_da_frml_enfrc_actn.key_hash = @v_key_hash;

        -- /ICA_DA_FRML_ENFRC_ACTN/ICA_SENS_CMNT_TXT
        INSERT INTO ica_data_hash
             SELECT ica_sens_cmnt_txt.data_hash
               FROM ica_da_frml_enfrc_actn
               JOIN ica_sens_cmnt_txt
                 ON ica_sens_cmnt_txt.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
              WHERE ica_da_frml_enfrc_actn.key_hash = @v_key_hash;

        END;

     IF @p_payload_type = 'ICA_DA_INFRML_ENFRC_ACTN' and @v_enabled = 'Y'
        BEGIN

        -- /ICA_DA_INFRML_ENFRC_ACTN
        INSERT INTO ica_data_hash
             SELECT ica_da_infrml_enfrc_actn.data_hash
               FROM ica_da_infrml_enfrc_actn
              WHERE ica_da_infrml_enfrc_actn.key_hash = @v_key_hash;

        -- /ICA_DA_INFRML_ENFRC_ACTN/ICA_ENFRC_ACTN_GOV_CNTCT
        INSERT INTO ica_data_hash
             SELECT ica_enfrc_actn_gov_cntct.data_hash
               FROM ica_da_infrml_enfrc_actn
               JOIN ica_enfrc_actn_gov_cntct
                 ON ica_enfrc_actn_gov_cntct.ica_da_infrml_enfrc_actn_id = ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
              WHERE ica_da_infrml_enfrc_actn.key_hash = @v_key_hash;

        -- /ICA_DA_INFRML_ENFRC_ACTN/ICA_ENFRC_AGNCY_TYPE
        INSERT INTO ica_data_hash
             SELECT ica_enfrc_agncy_type.data_hash
               FROM ica_da_infrml_enfrc_actn
               JOIN ica_enfrc_agncy_type
                 ON ica_enfrc_agncy_type.ica_da_infrml_enfrc_actn_id = ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
              WHERE ica_da_infrml_enfrc_actn.key_hash = @v_key_hash;

        -- /ICA_DA_INFRML_ENFRC_ACTN/ICA_FAC_IDENT
        INSERT INTO ica_data_hash
             SELECT ica_fac_ident.data_hash
               FROM ica_da_infrml_enfrc_actn
               JOIN ica_fac_ident
                 ON ica_fac_ident.ica_da_infrml_enfrc_actn_id = ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
              WHERE ica_da_infrml_enfrc_actn.key_hash = @v_key_hash;

        -- /ICA_DA_INFRML_ENFRC_ACTN/ICA_INFRML_EA_CMNT_TXT
        INSERT INTO ica_data_hash
             SELECT ica_infrml_ea_cmnt_txt.data_hash
               FROM ica_da_infrml_enfrc_actn
               JOIN ica_infrml_ea_cmnt_txt
                 ON ica_infrml_ea_cmnt_txt.ica_da_infrml_enfrc_actn_id = ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
              WHERE ica_da_infrml_enfrc_actn.key_hash = @v_key_hash;

        -- /ICA_DA_INFRML_ENFRC_ACTN/ICA_POLUT
        INSERT INTO ica_data_hash
             SELECT ica_polut.data_hash
               FROM ica_da_infrml_enfrc_actn
               JOIN ica_polut
                 ON ica_polut.ica_da_infrml_enfrc_actn_id = ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
              WHERE ica_da_infrml_enfrc_actn.key_hash = @v_key_hash;

        -- /ICA_DA_INFRML_ENFRC_ACTN/ICA_PROGS_VIOL
        INSERT INTO ica_data_hash
             SELECT ica_progs_viol.data_hash
               FROM ica_da_infrml_enfrc_actn
               JOIN ica_progs_viol
                 ON ica_progs_viol.ica_da_infrml_enfrc_actn_id = ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
              WHERE ica_da_infrml_enfrc_actn.key_hash = @v_key_hash;

        -- /ICA_DA_INFRML_ENFRC_ACTN/ICA_SENS_CMNT_TXT
        INSERT INTO ica_data_hash
             SELECT ica_sens_cmnt_txt.data_hash
               FROM ica_da_infrml_enfrc_actn
               JOIN ica_sens_cmnt_txt
                 ON ica_sens_cmnt_txt.ica_da_infrml_enfrc_actn_id = ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
              WHERE ica_da_infrml_enfrc_actn.key_hash = @v_key_hash;

        END;

     IF @p_payload_type = 'ICA_FAC' and @v_enabled = 'Y'
        BEGIN

        -- /ICA_FAC
        INSERT INTO ica_data_hash
             SELECT ica_fac.data_hash
               FROM ica_fac
              WHERE ica_fac.key_hash = @v_key_hash;

        -- /ICA_FAC/ICA_CNTCT
        INSERT INTO ica_data_hash
             SELECT ica_cntct.data_hash
               FROM ica_fac
               JOIN ica_cntct
                 ON ica_cntct.ica_fac_id = ica_fac.ica_fac_id
              WHERE ica_fac.key_hash = @v_key_hash;

        -- /ICA_FAC/ICA_CNTCT/ICA_TELEPH
        INSERT INTO ica_data_hash
             SELECT ica_teleph.data_hash
               FROM ica_fac
               JOIN ica_cntct
                 ON ica_cntct.ica_fac_id = ica_fac.ica_fac_id
               JOIN ica_teleph
                 ON ica_teleph.ica_cntct_id = ica_cntct.ica_cntct_id
              WHERE ica_fac.key_hash = @v_key_hash;

        -- /ICA_FAC/ICA_FAC_ADDR
        INSERT INTO ica_data_hash
             SELECT ica_fac_addr.data_hash
               FROM ica_fac
               JOIN ica_fac_addr
                 ON ica_fac_addr.ica_fac_id = ica_fac.ica_fac_id
              WHERE ica_fac.key_hash = @v_key_hash;

        -- /ICA_FAC/ICA_FAC_ADDR/ICA_TELEPH
        INSERT INTO ica_data_hash
             SELECT ica_teleph.data_hash
               FROM ica_fac
               JOIN ica_fac_addr
                 ON ica_fac_addr.ica_fac_id = ica_fac.ica_fac_id
               JOIN ica_teleph
                 ON ica_teleph.ica_fac_addr_id = ica_fac_addr.ica_fac_addr_id
              WHERE ica_fac.key_hash = @v_key_hash;

        -- /ICA_FAC/ICA_GEO_COORD
        INSERT INTO ica_data_hash
             SELECT ica_geo_coord.data_hash
               FROM ica_fac
               JOIN ica_geo_coord
                 ON ica_geo_coord.ica_fac_id = ica_fac.ica_fac_id
              WHERE ica_fac.key_hash = @v_key_hash;

        -- /ICA_FAC/ICA_NAICA_CODE
        INSERT INTO ica_data_hash
             SELECT ica_naics_code.data_hash
               FROM ica_fac
               JOIN ica_naics_code
                 ON ica_naics_code.ica_fac_id = ica_fac.ica_fac_id
              WHERE ica_fac.key_hash = @v_key_hash;

        -- /ICA_FAC/ICA_PORT_SRC
        INSERT INTO ica_data_hash
             SELECT ica_port_src.data_hash
               FROM ica_fac
               JOIN ica_port_src
                 ON ica_port_src.ica_fac_id = ica_fac.ica_fac_id
              WHERE ica_fac.key_hash = @v_key_hash;

        -- /ICA_FAC/ICA_SIC_CODE
        INSERT INTO ica_data_hash
             SELECT ica_sic_code.data_hash
               FROM ica_fac
               JOIN ica_sic_code
                 ON ica_sic_code.ica_fac_id = ica_fac.ica_fac_id
              WHERE ica_fac.key_hash = @v_key_hash;

        -- /ICA_FAC/ICA_UNIVERSE_IND
        INSERT INTO ica_data_hash
             SELECT ica_universe_ind.data_hash
               FROM ica_fac
               JOIN ica_universe_ind
                 ON ica_universe_ind.ica_fac_id = ica_fac.ica_fac_id
              WHERE ica_fac.key_hash = @v_key_hash;

        END;

     IF @p_payload_type = 'ICA_POLUTS' and @v_enabled = 'Y'
        BEGIN

        -- /ICA_POLUTS
        INSERT INTO ica_data_hash
             SELECT ica_poluts.data_hash
               FROM ica_poluts
              WHERE ica_poluts.key_hash = @v_key_hash;

        -- /ICA_POLUTS/ICA_POLUT_DA_CLASS
        INSERT INTO ica_data_hash
             SELECT ica_polut_da_class.data_hash
               FROM ica_poluts
               JOIN ica_polut_da_class
                 ON ica_polut_da_class.ica_poluts_id = ica_poluts.ica_poluts_id
              WHERE ica_poluts.key_hash = @v_key_hash;

        -- /ICA_POLUTS/ICA_POLUT_EPA_CLASS
        INSERT INTO ica_data_hash
             SELECT ica_polut_epa_class.data_hash
               FROM ica_poluts
               JOIN ica_polut_epa_class
                 ON ica_polut_epa_class.ica_poluts_id = ica_poluts.ica_poluts_id
              WHERE ica_poluts.key_hash = @v_key_hash;

        END;

     IF @p_payload_type = 'ICA_PROGS' and @v_enabled = 'Y'
        BEGIN

        -- /ICA_PROGS
        INSERT INTO ica_data_hash
             SELECT ica_progs.data_hash
               FROM ica_progs
              WHERE ica_progs.key_hash = @v_key_hash;

        -- /ICA_PROGS/ICA_PROG_SUBPART
        INSERT INTO ica_data_hash
             SELECT ica_prog_subpart.data_hash
               FROM ica_progs
               JOIN ica_prog_subpart
                 ON ica_prog_subpart.ica_progs_id = ica_progs.ica_progs_id
              WHERE ica_progs.key_hash = @v_key_hash;

        END;

     IF @p_payload_type = 'ICA_TVACC' and @v_enabled = 'Y'
        BEGIN

        -- /ICA_TVACC
        INSERT INTO ica_data_hash
             SELECT ica_tvacc.data_hash
               FROM ica_tvacc
              WHERE ica_tvacc.key_hash = @v_key_hash;

        -- /ICA_TVACC/ICA_CNTCT
        INSERT INTO ica_data_hash
             SELECT ica_cntct.data_hash
               FROM ica_tvacc
               JOIN ica_cntct
                 ON ica_cntct.ica_tvacc_id = ica_tvacc.ica_tvacc_id
              WHERE ica_tvacc.key_hash = @v_key_hash;

        -- /ICA_TVACC/ICA_CNTCT/ICA_TELEPH
        INSERT INTO ica_data_hash
             SELECT ica_teleph.data_hash
               FROM ica_tvacc
               JOIN ica_cntct
                 ON ica_cntct.ica_tvacc_id = ica_tvacc.ica_tvacc_id
               JOIN ica_teleph
                 ON ica_teleph.ica_cntct_id = ica_cntct.ica_cntct_id
              WHERE ica_tvacc.key_hash = @v_key_hash;

        -- /ICA_TVACC/ICA_INSP_CMNT_TXT
        INSERT INTO ica_data_hash
             SELECT ica_insp_cmnt_txt.data_hash
               FROM ica_tvacc
               JOIN ica_insp_cmnt_txt
                 ON ica_insp_cmnt_txt.ica_tvacc_id = ica_tvacc.ica_tvacc_id
              WHERE ica_tvacc.key_hash = @v_key_hash;

        -- /ICA_TVACC/ICA_INSP_GOV_CNTCT
        INSERT INTO ica_data_hash
             SELECT ica_insp_gov_cntct.data_hash
               FROM ica_tvacc
               JOIN ica_insp_gov_cntct
                 ON ica_insp_gov_cntct.ica_tvacc_id = ica_tvacc.ica_tvacc_id
              WHERE ica_tvacc.key_hash = @v_key_hash;

        -- /ICA_TVACC/ICA_NAT_PRIO
        INSERT INTO ica_data_hash
             SELECT ica_nat_prio.data_hash
               FROM ica_tvacc
               JOIN ica_nat_prio
                 ON ica_nat_prio.ica_tvacc_id = ica_tvacc.ica_tvacc_id
              WHERE ica_tvacc.key_hash = @v_key_hash;

        -- /ICA_TVACC/ICA_POLUT
        INSERT INTO ica_data_hash
             SELECT ica_polut.data_hash
               FROM ica_tvacc
               JOIN ica_polut
                 ON ica_polut.ica_tvacc_id = ica_tvacc.ica_tvacc_id
              WHERE ica_tvacc.key_hash = @v_key_hash;

        -- /ICA_TVACC/ICA_PROG
        INSERT INTO ica_data_hash
             SELECT ica_prog.data_hash
               FROM ica_tvacc
               JOIN ica_prog
                 ON ica_prog.ica_tvacc_id = ica_tvacc.ica_tvacc_id
              WHERE ica_tvacc.key_hash = @v_key_hash;

        -- /ICA_TVACC/ICA_RGNL_PRIO
        INSERT INTO ica_data_hash
             SELECT ica_rgnl_prio.data_hash
               FROM ica_tvacc
               JOIN ica_rgnl_prio
                 ON ica_rgnl_prio.ica_tvacc_id = ica_tvacc.ica_tvacc_id
              WHERE ica_tvacc.key_hash = @v_key_hash;

        -- /ICA_TVACC/ICA_SENS_CMNT_TXT
        INSERT INTO ica_data_hash
             SELECT ica_sens_cmnt_txt.data_hash
               FROM ica_tvacc
               JOIN ica_sens_cmnt_txt
                 ON ica_sens_cmnt_txt.ica_tvacc_id = ica_tvacc.ica_tvacc_id
              WHERE ica_tvacc.key_hash = @v_key_hash;

        -- /ICA_TVACC/ICA_TVACC_REVIEW
        INSERT INTO ica_data_hash
             SELECT ica_tvacc_review.data_hash
               FROM ica_tvacc
               JOIN ica_tvacc_review
                 ON ica_tvacc_review.ica_tvacc_id = ica_tvacc.ica_tvacc_id
              WHERE ica_tvacc.key_hash = @v_key_hash;

        END;

     IF @p_payload_type = 'ICA_DA_CASE_FILE' and @v_enabled = 'Y'
        BEGIN

        -- /ICA_DA_CASE_FILE
        INSERT INTO ica_data_hash
             SELECT ica_da_case_file.data_hash
               FROM ica_da_case_file
              WHERE ica_da_case_file.key_hash = @v_key_hash;

        -- /ICA_DA_CASE_FILE/ICA_CASE_FILE_CMNT_TXT
        INSERT INTO ica_data_hash
             SELECT ica_case_file_cmnt_txt.data_hash
               FROM ica_da_case_file
               JOIN ica_case_file_cmnt_txt
                 ON ica_case_file_cmnt_txt.ica_da_case_file_id = ica_da_case_file.ica_da_case_file_id
              WHERE ica_da_case_file.key_hash = @v_key_hash;

        -- /ICA_DA_CASE_FILE/ICA_OTHR_PATHWAY_ACTY
        INSERT INTO ica_data_hash
             SELECT ica_othr_pathway_acty.data_hash
               FROM ica_da_case_file
               JOIN ica_othr_pathway_acty
                 ON ica_othr_pathway_acty.ica_da_case_file_id = ica_da_case_file.ica_da_case_file_id
              WHERE ica_da_case_file.key_hash = @v_key_hash;

        -- /ICA_DA_CASE_FILE/ICA_POLUT
        INSERT INTO ica_data_hash
             SELECT ica_polut.data_hash
               FROM ica_da_case_file
               JOIN ica_polut
                 ON ica_polut.ica_da_case_file_id = ica_da_case_file.ica_da_case_file_id
              WHERE ica_da_case_file.key_hash = @v_key_hash;

        -- /ICA_DA_CASE_FILE/ICA_PROG
        INSERT INTO ica_data_hash
             SELECT ica_prog.data_hash
               FROM ica_da_case_file
               JOIN ica_prog
                 ON ica_prog.ica_da_case_file_id = ica_da_case_file.ica_da_case_file_id
              WHERE ica_da_case_file.key_hash = @v_key_hash;

        -- /ICA_DA_CASE_FILE/ICA_SENS_CMNT_TXT
        INSERT INTO ica_data_hash
             SELECT ica_sens_cmnt_txt.data_hash
               FROM ica_da_case_file
               JOIN ica_sens_cmnt_txt
                 ON ica_sens_cmnt_txt.ica_da_case_file_id = ica_da_case_file.ica_da_case_file_id
              WHERE ica_da_case_file.key_hash = @v_key_hash;

        -- /ICA_DA_CASE_FILE/ICA_VIOL
        INSERT INTO ica_data_hash
             SELECT ica_viol.data_hash
               FROM ica_da_case_file
               JOIN ica_viol
                 ON ica_viol.ica_da_case_file_id = ica_da_case_file.ica_da_case_file_id
              WHERE ica_da_case_file.key_hash = @v_key_hash;

        END;

     IF @p_payload_type = 'ICA_DA_ENFRC_ACTN_LNK' and @v_enabled = 'Y'
        BEGIN

        -- /ICA_DA_ENFRC_ACTN_LNK
        INSERT INTO ica_data_hash
             SELECT ica_da_enfrc_actn_lnk.data_hash
               FROM ica_da_enfrc_actn_lnk
              WHERE ica_da_enfrc_actn_lnk.key_hash = @v_key_hash;

        -- /ICA_DA_ENFRC_ACTN_LNK/ICA_LNK_DA_ENFRC_ACTN
        INSERT INTO ica_data_hash
             SELECT ica_lnk_da_enfrc_actn.data_hash
               FROM ica_da_enfrc_actn_lnk
               JOIN ica_lnk_da_enfrc_actn
                 ON ica_lnk_da_enfrc_actn.ica_da_enfrc_actn_lnk_id = ica_da_enfrc_actn_lnk.ica_da_enfrc_actn_lnk_id
              WHERE ica_da_enfrc_actn_lnk.key_hash = @v_key_hash;

        END;

     IF @p_payload_type = 'ICA_CASE_FILE_LNK' and @v_enabled = 'Y'
        BEGIN

        -- /ICA_CASE_FILE_LNK
        INSERT INTO ica_data_hash
             SELECT ica_case_file_lnk.data_hash
               FROM ica_case_file_lnk
              WHERE ica_case_file_lnk.key_hash = @v_key_hash;

        -- /ICA_CASE_FILE_LNK/ICA_LNK_CASE_FILE
        INSERT INTO ica_data_hash
             SELECT ica_lnk_case_file.data_hash
               FROM ica_case_file_lnk
               JOIN ica_lnk_case_file
                 ON ica_lnk_case_file.ica_case_file_lnk_id = ica_case_file_lnk.ica_case_file_lnk_id
              WHERE ica_case_file_lnk.key_hash = @v_key_hash;

        -- /ICA_CASE_FILE_LNK/ICA_LNK_CMPL_MON
        INSERT INTO ica_data_hash
             SELECT ica_lnk_cmpl_mon.data_hash
               FROM ica_case_file_lnk
               JOIN ica_lnk_cmpl_mon
                 ON ica_lnk_cmpl_mon.ica_case_file_lnk_id = ica_case_file_lnk.ica_case_file_lnk_id
              WHERE ica_case_file_lnk.key_hash = @v_key_hash;

        -- /ICA_CASE_FILE_LNK/ICA_LNK_DA_ENFRC_ACTN
        INSERT INTO ica_data_hash
             SELECT ica_lnk_da_enfrc_actn.data_hash
               FROM ica_case_file_lnk
               JOIN ica_lnk_da_enfrc_actn
                 ON ica_lnk_da_enfrc_actn.ica_case_file_lnk_id = ica_case_file_lnk.ica_case_file_lnk_id
              WHERE ica_case_file_lnk.key_hash = @v_key_hash;

        END;

     IF @p_payload_type = 'ICA_CMPL_MON_LNK' and @v_enabled = 'Y'
        BEGIN

        -- /ICA_CMPL_MON_LNK
        INSERT INTO ica_data_hash
             SELECT ica_cmpl_mon_lnk.data_hash
               FROM ica_cmpl_mon_lnk
              WHERE ica_cmpl_mon_lnk.key_hash = @v_key_hash;

        -- /ICA_CMPL_MON_LNK/ICA_LNK_CMPL_MON
        INSERT INTO ica_data_hash
             SELECT ica_lnk_cmpl_mon.data_hash
               FROM ica_cmpl_mon_lnk
               JOIN ica_lnk_cmpl_mon
                 ON ica_lnk_cmpl_mon.ica_cmpl_mon_lnk_id = ica_cmpl_mon_lnk.ica_cmpl_mon_lnk_id
              WHERE ica_cmpl_mon_lnk.key_hash = @v_key_hash;

        -- /ICA_CMPL_MON_LNK/ICA_LNK_DA_ENFRC_ACTN
        INSERT INTO ica_data_hash
             SELECT ica_lnk_da_enfrc_actn.data_hash
               FROM ica_cmpl_mon_lnk
               JOIN ica_lnk_da_enfrc_actn
                 ON ica_lnk_da_enfrc_actn.ica_cmpl_mon_lnk_id = ica_cmpl_mon_lnk.ica_cmpl_mon_lnk_id
              WHERE ica_cmpl_mon_lnk.key_hash = @v_key_hash;

        END;




     /*  
      *  Loop through each data_hash value loaded into ICA_DATA_HASH, for each, rehash each data_hash values together to create 
      *  a single data_hash value that represents all the non-key data contained within a payload type / key_hash combination.
      */
		  SET @v_all_data_hashes = NULL;
      OPEN data_hash;

      -- Get 1st payload type
      FETCH NEXT FROM data_hash INTO @v_data_hash;
      WHILE @@FETCH_STATUS = 0
        BEGIN      
            
        /* Append each data hash together into one string value.. */
        SELECT @v_all_data_hashes = dbo.HASHBYTES_VARCHAR('SHA1', COALESCE(@v_all_data_hashes,'#') + @v_data_hash);
        FETCH NEXT FROM data_hash INTO @v_data_hash;

      END; -- data_loop;

    /*  Close the data_hash cursor */
    CLOSE data_hash;
            
          /*  Hash the entire set of data_hash values organized into a single string. */
		  SET @v_hashed_data_hashes = NULL;
          SELECT @v_hashed_data_hashes = @v_all_data_hashes;      
                     
                     
          /*  Load the rehashed value into the payload type table's data_hash column. */
          SET @v_sql_statement = ' UPDATE ' + @p_payload_type + 
                                 '    SET ' + 'data_hash = ' + '''' + @v_hashed_data_hashes +  '''' + 
                                 '  WHERE key_hash = ' + '''' + @v_key_hash + '''';

          EXECUTE sp_executesql @v_sql_statement;                      
          
          /* Get next key_hash value...  */
          FETCH NEXT FROM key_hash INTO @v_key_hash;
                  
        END; -- key_loop   
       
      /*  Close the key_hash cursor */
      CLOSE key_hash;

      /*  Get the next payload type. */
      FETCH NEXT FROM payload_type_process 
      INTO @p_payload_type;
      
    END; -- payload_t--END LOOP module_loop;

  /*  Close payload type cursor */
  CLOSE payload_type_process;
  
  /*  Destroy the payload type cursor */
  DEALLOCATE payload_type_delete;  
  DEALLOCATE payload_type_process;  
  DEALLOCATE data_hash;
  DEALLOCATE key_hash;  
  
  
  /******************************************************************************************************************************
  ** Description:  The following code sets the new, change, replace, etc... ics transaction_type flags throughout the entire ICS 
  **               schema.  Once these flags are set the data will be marked as either new, changed and will allow the OPENNODE2 
  **               plug-in the ability to pull the data, bundle into .xml, and then submit to an exchange partner.
  ******************************************************************************************************************************/
  -- Generates SQL INSERT and UPDATE Statements to set TransactionCode values based on changes to staged data
-- Date Generated: Monday, July 09, 2012

-- Generates SQL INSERT and UPDATE Statements to set TransactionCode values based on changes to staged data
-- Date Generated: Wednesday, July 16, 2014

     -- ICA_CMPL_MON_STRGY - Set New/Replace Transactions
     UPDATE ica_cmpl_mon_strgy
        SET ica_cmpl_mon_strgy.transaction_type = (SELECT CASE cdv_cmpl_mon_strgy.action_code
                                                          WHEN 1 THEN 'R'
                                                          WHEN 2 THEN 'R'
                                                         END AS transaction_type
                                                   FROM cdv_cmpl_mon_strgy
                                                  WHERE cdv_cmpl_mon_strgy.key_hash = ica_cmpl_mon_strgy.key_hash
                                                    AND (SELECT COUNT(1) FROM ica_payload WHERE operation = 'AirComplianceMonitoringStrategySubmission' AND enabled = 'Y') = 1);

     -- ICA_DA_CMPL_MON - Set New/Replace Transactions
     UPDATE ica_da_cmpl_mon
        SET ica_da_cmpl_mon.transaction_type = (SELECT CASE cdv_da_cmpl_mon.action_code
                                                          WHEN 1 THEN 'R'
                                                          WHEN 2 THEN 'R'
                                                         END AS transaction_type
                                                   FROM cdv_da_cmpl_mon
                                                  WHERE cdv_da_cmpl_mon.key_hash = ica_da_cmpl_mon.key_hash
                                                    AND (SELECT COUNT(1) FROM ica_payload WHERE operation = 'AirDAComplianceMonitoringSubmission' AND enabled = 'Y') = 1);

     -- ICA_DA_ENFRC_ACTN_MILSTN - Set New/Replace Transactions
     UPDATE ica_da_enfrc_actn_milstn
        SET ica_da_enfrc_actn_milstn.transaction_type = (SELECT CASE cdv_da_enfrc_actn_milstn.action_code
                                                          WHEN 1 THEN 'R'
                                                          WHEN 2 THEN 'R'
                                                         END AS transaction_type
                                                   FROM cdv_da_enfrc_actn_milstn
                                                  WHERE cdv_da_enfrc_actn_milstn.key_hash = ica_da_enfrc_actn_milstn.key_hash
                                                    AND (SELECT COUNT(1) FROM ica_payload WHERE operation = 'AirDAEnforcementActionMilestoneSubmission' AND enabled = 'Y') = 1);

     -- ICA_DA_FRML_ENFRC_ACTN - Set New/Replace Transactions
     UPDATE ica_da_frml_enfrc_actn
        SET ica_da_frml_enfrc_actn.transaction_type = (SELECT CASE cdv_da_frml_enfrc_actn.action_code
                                                          WHEN 1 THEN 'R'
                                                          WHEN 2 THEN 'R'
                                                         END AS transaction_type
                                                   FROM cdv_da_frml_enfrc_actn
                                                  WHERE cdv_da_frml_enfrc_actn.key_hash = ica_da_frml_enfrc_actn.key_hash
                                                    AND (SELECT COUNT(1) FROM ica_payload WHERE operation = 'AirDAFormalEnforcementActionSubmission' AND enabled = 'Y') = 1);

     -- ICA_DA_INFRML_ENFRC_ACTN - Set New/Replace Transactions
     UPDATE ica_da_infrml_enfrc_actn
        SET ica_da_infrml_enfrc_actn.transaction_type = (SELECT CASE cdv_da_infrml_enfrc_actn.action_code
                                                          WHEN 1 THEN 'R'
                                                          WHEN 2 THEN 'R'
                                                         END AS transaction_type
                                                   FROM cdv_da_infrml_enfrc_actn
                                                  WHERE cdv_da_infrml_enfrc_actn.key_hash = ica_da_infrml_enfrc_actn.key_hash
                                                    AND (SELECT COUNT(1) FROM ica_payload WHERE operation = 'AirDAInformalEnforcementActionSubmission' AND enabled = 'Y') = 1);

     -- ICA_FAC - Set New/Replace Transactions
     UPDATE ica_fac
        SET ica_fac.transaction_type = (SELECT CASE cdv_fac.action_code
                                                          WHEN 1 THEN 'R'
                                                          WHEN 2 THEN 'R'
                                                         END AS transaction_type
                                                   FROM cdv_fac
                                                  WHERE cdv_fac.key_hash = ica_fac.key_hash
                                                    AND (SELECT COUNT(1) FROM ica_payload WHERE operation = 'AirFacilitySubmission' AND enabled = 'Y') = 1);

     -- ICA_POLUTS - Set New/Replace Transactions
     UPDATE ica_poluts
        SET ica_poluts.transaction_type = (SELECT CASE cdv_poluts.action_code
                                                          WHEN 1 THEN 'R'
                                                          WHEN 2 THEN 'R'
                                                         END AS transaction_type
                                                   FROM cdv_poluts
                                                  WHERE cdv_poluts.key_hash = ica_poluts.key_hash
                                                    AND (SELECT COUNT(1) FROM ica_payload WHERE operation = 'AirPollutantsSubmission' AND enabled = 'Y') = 1);

     -- ICA_PROGS - Set New/Replace Transactions
     UPDATE ica_progs
        SET ica_progs.transaction_type = (SELECT CASE cdv_progs.action_code
                                                          WHEN 1 THEN 'R'
                                                          WHEN 2 THEN 'R'
                                                         END AS transaction_type
                                                   FROM cdv_progs
                                                  WHERE cdv_progs.key_hash = ica_progs.key_hash
                                                    AND (SELECT COUNT(1) FROM ica_payload WHERE operation = 'AirProgramsSubmission' AND enabled = 'Y') = 1);

     -- ICA_TVACC - Set New/Replace Transactions
     UPDATE ica_tvacc
        SET ica_tvacc.transaction_type = (SELECT CASE cdv_tvacc.action_code
                                                          WHEN 1 THEN 'R'
                                                          WHEN 2 THEN 'R'
                                                         END AS transaction_type
                                                   FROM cdv_tvacc
                                                  WHERE cdv_tvacc.key_hash = ica_tvacc.key_hash
                                                    AND (SELECT COUNT(1) FROM ica_payload WHERE operation = 'AirTVACCSubmission' AND enabled = 'Y') = 1);

     -- ICA_DA_CASE_FILE - Set New/Replace Transactions
     UPDATE ica_da_case_file
        SET ica_da_case_file.transaction_type = (SELECT CASE cdv_da_case_file.action_code
                                                          WHEN 1 THEN 'R'
                                                          WHEN 2 THEN 'R'
                                                         END AS transaction_type
                                                   FROM cdv_da_case_file
                                                  WHERE cdv_da_case_file.key_hash = ica_da_case_file.key_hash
                                                    AND (SELECT COUNT(1) FROM ica_payload WHERE operation = 'AirDACaseFileSubmission' AND enabled = 'Y') = 1);

     -- ICA_DA_ENFRC_ACTN_LNK - Set New/Replace Transactions
     UPDATE ica_da_enfrc_actn_lnk
        SET ica_da_enfrc_actn_lnk.transaction_type = (SELECT CASE cdv_da_enfrc_actn_lnk.action_code
                                                          WHEN 1 THEN 'R'
                                                          WHEN 2 THEN 'R'
                                                         END AS transaction_type
                                                   FROM cdv_da_enfrc_actn_lnk
                                                  WHERE cdv_da_enfrc_actn_lnk.key_hash = ica_da_enfrc_actn_lnk.key_hash
                                                    AND (SELECT COUNT(1) FROM ica_payload WHERE operation = 'AirDAEnforcementActionLinkageSubmission' AND enabled = 'Y') = 1);

     -- ICA_CASE_FILE_LNK - Set New/Replace Transactions
     UPDATE ica_case_file_lnk
        SET ica_case_file_lnk.transaction_type = (SELECT CASE cdv_case_file_lnk.action_code
                                                          WHEN 1 THEN 'R'
                                                          WHEN 2 THEN 'R'
                                                         END AS transaction_type
                                                   FROM cdv_case_file_lnk
                                                  WHERE cdv_case_file_lnk.key_hash = ica_case_file_lnk.key_hash
                                                    AND (SELECT COUNT(1) FROM ica_payload WHERE operation = 'CaseFileLinkageSubmission' AND enabled = 'Y') = 1);

     -- ICA_CMPL_MON_LNK - Set New/Replace Transactions
     UPDATE ica_cmpl_mon_lnk
        SET ica_cmpl_mon_lnk.transaction_type = (SELECT CASE cdv_cmpl_mon_lnk.action_code
                                                          WHEN 1 THEN 'R'
                                                          WHEN 2 THEN 'R'
                                                         END AS transaction_type
                                                   FROM cdv_cmpl_mon_lnk
                                                  WHERE cdv_cmpl_mon_lnk.key_hash = ica_cmpl_mon_lnk.key_hash
                                                    AND (SELECT COUNT(1) FROM ica_payload WHERE operation = 'ComplianceMonitoringLinkageSubmission' AND enabled = 'Y') = 1);

     -- ICA_CMPL_MON_STRGY - Set Delete Transactions
     INSERT INTO ica_cmpl_mon_strgy
          ( ica_payload_id
          , ica_cmpl_mon_strgy_id
          , transaction_type
          , fac_ident) 
      SELECT ica_cmpl_mon_strgy.ica_payload_id
           , ica_cmpl_mon_strgy.ica_cmpl_mon_strgy_id
           , 'X' AS transaction_type
           , fac_ident
        FROM ica_flow_icis.dbo.ica_cmpl_mon_strgy
       WHERE ica_cmpl_mon_strgy.ica_payload_id in (SELECT ica_payload_id 
                              FROM ica_payload 
                             WHERE operation = 'AirComplianceMonitoringStrategySubmission'
                               AND auto_gen_deletes = 'Y')
         AND ica_cmpl_mon_strgy.key_hash IN (SELECT key_hash
                                           FROM cdv_cmpl_mon_strgy
                                          WHERE cdv_cmpl_mon_strgy.action_type = 'DELETE');

     -- ICA_DA_CMPL_MON - Set Delete Transactions
     INSERT INTO ica_da_cmpl_mon
          ( ica_payload_id
          , ica_da_cmpl_mon_id
          , transaction_type
          , cmpl_mon_ident) 
      SELECT ica_da_cmpl_mon.ica_payload_id
           , ica_da_cmpl_mon.ica_da_cmpl_mon_id
           , 'X' AS transaction_type
           , cmpl_mon_ident
        FROM ica_flow_icis.dbo.ica_da_cmpl_mon
       WHERE ica_da_cmpl_mon.ica_payload_id in (SELECT ica_payload_id 
                              FROM ica_payload 
                             WHERE operation = 'AirDAComplianceMonitoringSubmission'
                               AND auto_gen_deletes = 'Y')
         AND ica_da_cmpl_mon.key_hash IN (SELECT key_hash
                                           FROM cdv_da_cmpl_mon
                                          WHERE cdv_da_cmpl_mon.action_type = 'DELETE');

     -- ICA_DA_ENFRC_ACTN_MILSTN - Set Delete Transactions
     INSERT INTO ica_da_enfrc_actn_milstn
          ( ica_payload_id
          , ica_da_enfrc_actn_milstn_id
          , transaction_type
          , da_enfrc_actn_ident, milstn_type_code) 
      SELECT ica_da_enfrc_actn_milstn.ica_payload_id
           , ica_da_enfrc_actn_milstn.ica_da_enfrc_actn_milstn_id
           , 'X' AS transaction_type
           , da_enfrc_actn_ident, milstn_type_code
        FROM ica_flow_icis.dbo.ica_da_enfrc_actn_milstn
       WHERE ica_da_enfrc_actn_milstn.ica_payload_id in (SELECT ica_payload_id 
                              FROM ica_payload 
                             WHERE operation = 'AirDAEnforcementActionMilestoneSubmission'
                               AND auto_gen_deletes = 'Y')
         AND ica_da_enfrc_actn_milstn.key_hash IN (SELECT key_hash
                                           FROM cdv_da_enfrc_actn_milstn
                                          WHERE cdv_da_enfrc_actn_milstn.action_type = 'DELETE');

     -- ICA_DA_FRML_ENFRC_ACTN - Set Delete Transactions
     INSERT INTO ica_da_frml_enfrc_actn
          ( ica_payload_id
          , ica_da_frml_enfrc_actn_id
          , transaction_type
          , da_enfrc_actn_ident) 
      SELECT ica_da_frml_enfrc_actn.ica_payload_id
           , ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
           , 'X' AS transaction_type
           , da_enfrc_actn_ident
        FROM ica_flow_icis.dbo.ica_da_frml_enfrc_actn
       WHERE ica_da_frml_enfrc_actn.ica_payload_id in (SELECT ica_payload_id 
                              FROM ica_payload 
                             WHERE operation = 'AirDAFormalEnforcementActionSubmission'
                               AND auto_gen_deletes = 'Y')
         AND ica_da_frml_enfrc_actn.key_hash IN (SELECT key_hash
                                           FROM cdv_da_frml_enfrc_actn
                                          WHERE cdv_da_frml_enfrc_actn.action_type = 'DELETE');

     -- ICA_DA_INFRML_ENFRC_ACTN - Set Delete Transactions
     INSERT INTO ica_da_infrml_enfrc_actn
          ( ica_payload_id
          , ica_da_infrml_enfrc_actn_id
          , transaction_type
          , da_enfrc_actn_ident) 
      SELECT ica_da_infrml_enfrc_actn.ica_payload_id
           , ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
           , 'X' AS transaction_type
           , da_enfrc_actn_ident
        FROM ica_flow_icis.dbo.ica_da_infrml_enfrc_actn
       WHERE ica_da_infrml_enfrc_actn.ica_payload_id in (SELECT ica_payload_id 
                              FROM ica_payload 
                             WHERE operation = 'AirDAInformalEnforcementActionSubmission'
                               AND auto_gen_deletes = 'Y')
         AND ica_da_infrml_enfrc_actn.key_hash IN (SELECT key_hash
                                           FROM cdv_da_infrml_enfrc_actn
                                          WHERE cdv_da_infrml_enfrc_actn.action_type = 'DELETE');

     -- ICA_FAC - Set Delete Transactions
     INSERT INTO ica_fac
          ( ica_payload_id
          , ica_fac_id
          , transaction_type
          , fac_ident) 
      SELECT ica_fac.ica_payload_id
           , ica_fac.ica_fac_id
           , 'X' AS transaction_type
           , fac_ident
        FROM ica_flow_icis.dbo.ica_fac
       WHERE ica_fac.ica_payload_id in (SELECT ica_payload_id 
                              FROM ica_payload 
                             WHERE operation = 'AirFacilitySubmission'
                               AND auto_gen_deletes = 'Y')
         AND ica_fac.key_hash IN (SELECT key_hash
                                           FROM cdv_fac
                                          WHERE cdv_fac.action_type = 'DELETE');

     -- ICA_POLUTS - Set Delete Transactions
     INSERT INTO ica_poluts
          ( ica_payload_id
          , ica_poluts_id
          , transaction_type
          , fac_ident, poluts_code) 
      SELECT ica_poluts.ica_payload_id
           , ica_poluts.ica_poluts_id
           , 'X' AS transaction_type
           , fac_ident, poluts_code
        FROM ica_flow_icis.dbo.ica_poluts
       WHERE ica_poluts.ica_payload_id in (SELECT ica_payload_id 
                              FROM ica_payload 
                             WHERE operation = 'AirPollutantsSubmission'
                               AND auto_gen_deletes = 'Y')
         AND ica_poluts.key_hash IN (SELECT key_hash
                                           FROM cdv_poluts
                                          WHERE cdv_poluts.action_type = 'DELETE');

     -- ICA_PROGS - Set Delete Transactions
     INSERT INTO ica_progs
          ( ica_payload_id
          , ica_progs_id
          , transaction_type
          , fac_ident
          , prog_code
          , prog_oper_stat_code) 
      SELECT ica_progs.ica_payload_id
           , ica_progs.ica_progs_id
           , 'X' AS transaction_type
           , fac_ident
           , prog_code
           , prog_oper_stat_code
        FROM ica_flow_icis.dbo.ica_progs
       WHERE ica_progs.ica_payload_id in (SELECT ica_payload_id 
                              FROM ica_payload 
                             WHERE operation = 'AirProgramsSubmission'
                               AND auto_gen_deletes = 'Y')
         AND ica_progs.key_hash IN (SELECT key_hash
                                           FROM cdv_progs
                                          WHERE cdv_progs.action_type = 'DELETE');

     -- ICA_TVACC - Set Delete Transactions
     INSERT INTO ica_tvacc
          ( ica_payload_id
          , ica_tvacc_id
          , transaction_type
          , cmpl_mon_ident
          , fac_ident) 
      SELECT ica_tvacc.ica_payload_id
           , ica_tvacc.ica_tvacc_id
           , 'X' AS transaction_type
           , cmpl_mon_ident
           , fac_ident
        FROM ica_flow_icis.dbo.ica_tvacc
       WHERE ica_tvacc.ica_payload_id in (SELECT ica_payload_id 
                              FROM ica_payload 
                             WHERE operation = 'AirTVACCSubmission'
                               AND auto_gen_deletes = 'Y')
         AND ica_tvacc.key_hash IN (SELECT key_hash
                                           FROM cdv_tvacc
                                          WHERE cdv_tvacc.action_type = 'DELETE');

     -- ICA_DA_CASE_FILE - Set Delete Transactions
     INSERT INTO ica_da_case_file
          ( ica_payload_id
          , ica_da_case_file_id
          , transaction_type
          , case_file_ident
          , fac_ident) 
      SELECT ica_da_case_file.ica_payload_id
           , ica_da_case_file.ica_da_case_file_id
           , 'X' AS transaction_type
           , case_file_ident
           , fac_ident
        FROM ica_flow_icis.dbo.ica_da_case_file
       WHERE ica_da_case_file.ica_payload_id in (SELECT ica_payload_id 
                              FROM ica_payload 
                             WHERE operation = 'AirDACaseFileSubmission'
                               AND auto_gen_deletes = 'Y')
         AND ica_da_case_file.key_hash IN (SELECT key_hash
                                           FROM cdv_da_case_file
                                          WHERE cdv_da_case_file.action_type = 'DELETE');


  /* **********************************************
   * ICA_CASE_FILE_LNK:  Set Delete Transactions
   * **********************************************/
	 DECLARE @tbl_case_file_lnk_id TABLE ( icis_case_file_lnk_id uniqueidentifier
	                                     , local_case_file_lnk_id uniqueidentifier);
	 
	 INSERT INTO @tbl_case_file_lnk_id
   SELECT DISTINCT 
          ica_case_file_lnk.ica_case_file_lnk_id AS icis_case_file_lnk_id
        , NEWID() AS local_case_file_lnk_id
     FROM ica_flow_icis.dbo.ica_case_file_lnk
    WHERE ica_case_file_lnk.key_hash IN (SELECT DISTINCT 
                                                key_hash 
                                           FROM cdv_case_file_lnk
                                          WHERE action_type = 'DELETE');   
        
                                      
      /*  
       *  ICA_CASE_FILE_LNK
       */       
       INSERT INTO ica_case_file_lnk
            ( ica_case_file_lnk_id
            , ica_payload_id
            , transaction_type
            , transaction_timestamp
            , src_systm_ident
            , case_file_ident
            , key_hash
            , data_hash)
       SELECT v_cfl.local_case_file_lnk_id AS ica_case_file_lnk_id
            , (SELECT ica_payload_id
                 FROM ica_payload 
               WHERE operation = 'CaseFileLinkageSubmission') AS ica_payload_id
            , 'X' AS transaction_type
            , ica_case_file_lnk.transaction_timestamp AS transaction_timestamp
            , ica_case_file_lnk.src_systm_ident AS src_systm_ident
            , ica_case_file_lnk.case_file_ident AS case_file_ident
            , NULL AS key_hash
            , NULL AS data_hash
         FROM ica_flow_icis.dbo.ica_case_file_lnk
         JOIN @tbl_case_file_lnk_id AS v_cfl
           ON v_cfl.icis_case_file_lnk_id = ica_case_file_lnk.ica_case_file_lnk_id;


      /*  
       *  ICA_LNK_CASE_FILE
       */       
       INSERT INTO ica_lnk_case_file 
            ( ica_lnk_case_file_id
            , ica_case_file_lnk_id
            , case_file_ident
            , data_hash)
       SELECT NEWID() AS ica_lnk_case_file_id
            , v_cfl.local_case_file_lnk_id AS ica_case_file_lnk_id
            , ica_lnk_case_file.case_file_ident
            , ica_lnk_case_file.data_hash
         FROM ica_flow_icis.dbo.ica_lnk_case_file
         JOIN @tbl_case_file_lnk_id AS v_cfl
           ON v_cfl.icis_case_file_lnk_id = ica_lnk_case_file.ica_case_file_lnk_id;
            
            
      /*  
       *  ICA_LNK_CMPL_MON
       */       
       INSERT INTO ica_lnk_cmpl_mon
            ( ica_lnk_cmpl_mon_id
            , ica_cmpl_mon_lnk_id
            , ica_case_file_lnk_id
            , cmpl_mon_ident
            , data_hash)
       SELECT NEWID() AS ica_lnk_cmpl_mon_id
            , NULL AS ica_cmpl_mon_lnk_id
            , v_cfl.local_case_file_lnk_id AS ica_case_file_lnk_id
            , ica_lnk_cmpl_mon.cmpl_mon_ident
            , ica_lnk_cmpl_mon.data_hash
         FROM ica_flow_icis.dbo.ica_lnk_cmpl_mon
         JOIN @tbl_case_file_lnk_id AS v_cfl
           ON v_cfl.icis_case_file_lnk_id = ica_lnk_cmpl_mon.ica_case_file_lnk_id;
            
            
      /*  
       *  ICA_LNK_DA_ENFRC_ACTN
       */       
       INSERT INTO ica_lnk_da_enfrc_actn
            ( ica_lnk_da_enfrc_actn_id
            , ica_cmpl_mon_lnk_id
            , ica_case_file_lnk_id
            , ica_da_enfrc_actn_lnk_id
            , da_enfrc_actn_ident
            , data_hash)
       SELECT NEWID() AS ica_lnk_da_enfrc_actn_id
            , NULL AS ica_cmpl_mon_lnk_id
            , v_cfl.local_case_file_lnk_id AS ica_case_file_lnk_id
            , NULL AS ica_da_enfrc_actn_lnk_id
            , ica_lnk_da_enfrc_actn.da_enfrc_actn_ident
            , ica_lnk_da_enfrc_actn.data_hash
         FROM ica_flow_icis.dbo.ica_lnk_da_enfrc_actn
         JOIN @tbl_case_file_lnk_id AS v_cfl
           ON v_cfl.icis_case_file_lnk_id = ica_lnk_da_enfrc_actn.ica_case_file_lnk_id;
        
      
  /* **********************************************
   * ICA_CMPL_MON_LNK:  Set Delete Transactions
   * **********************************************/
	 DECLARE @tbl_cmpl_mon_lnk_id TABLE ( icis_cmpl_mon_lnk_id uniqueidentifier
	                                    , local_cmpl_mon_lnk_id uniqueidentifier);
	 
	 INSERT INTO @tbl_cmpl_mon_lnk_id
   SELECT DISTINCT 
          ica_cmpl_mon_lnk.ica_cmpl_mon_lnk_id AS icis_cmpl_mon_lnk_id
        , NEWID() AS local_cmpl_mon_lnk_id
     FROM ica_flow_icis.dbo.ica_cmpl_mon_lnk
    WHERE ica_cmpl_mon_lnk.key_hash IN (SELECT DISTINCT 
                                                key_hash 
                                          FROM cdv_cmpl_mon_lnk
                                         WHERE action_type = 'DELETE');  

     /*  
      *  ICA_CMPL_MON_LNK
      */       
      INSERT INTO ica_cmpl_mon_lnk
           ( ica_cmpl_mon_lnk_id
           , ica_payload_id
           , transaction_type
           , transaction_timestamp
           , src_systm_ident
           , cmpl_mon_ident
           , key_hash
           , data_hash)
      SELECT v_cml.local_cmpl_mon_lnk_id AS ica_cmpl_mon_lnk_id
           , (SELECT ica_payload.ica_payload_id
                FROM ica_payload 
               WHERE ica_payload.operation = 'ComplianceMonitoringLinkageSubmission') AS ica_payload_id
           , 'X' AS transaction_type
           , ica_cmpl_mon_lnk.transaction_timestamp
           , ica_cmpl_mon_lnk.src_systm_ident
           , ica_cmpl_mon_lnk.cmpl_mon_ident
           , NULL AS key_hash
           , NULL AS data_hash
        FROM ica_flow_icis.dbo.ica_cmpl_mon_lnk 
        JOIN @tbl_cmpl_mon_lnk_id AS v_cml
          ON v_cml.icis_cmpl_mon_lnk_id = ica_cmpl_mon_lnk.ica_cmpl_mon_lnk_id;
             
             
     /*  
      *  ICA_LNK_CMPL_MON
      */       
      INSERT INTO ICA_LNK_CMPL_MON
           ( ica_lnk_cmpl_mon_id
           , ica_cmpl_mon_lnk_id
           , ica_case_file_lnk_id
           , cmpl_mon_ident
           , data_hash)
      SELECT NEWID() AS ica_lnk_cmpl_mon_id
           , v_cml.local_cmpl_mon_lnk_id AS ica_cmpl_mon_lnk_id
           , NULL AS ica_case_file_lnk_id
           , ica_lnk_cmpl_mon.cmpl_mon_ident
           , ica_lnk_cmpl_mon.data_hash
        FROM ica_flow_icis.dbo.ica_lnk_cmpl_mon
        JOIN @tbl_cmpl_mon_lnk_id AS v_cml
          ON v_cml.icis_cmpl_mon_lnk_id = ica_lnk_cmpl_mon.ica_cmpl_mon_lnk_id;

            
     /*  
      *  ICA_LNK_DA_ENFRC_ACTN
      */       
      INSERT INTO ICA_LNK_DA_ENFRC_ACTN
           ( ica_lnk_da_enfrc_actn_id
           , ica_cmpl_mon_lnk_id
           , ica_case_file_lnk_id
           , ica_da_enfrc_actn_lnk_id
           , da_enfrc_actn_ident
           , data_hash)
      SELECT NEWID() AS ica_lnk_da_enfrc_actn_id
           , v_cml.local_cmpl_mon_lnk_id AS ica_cmpl_mon_lnk_id
           , NULL AS ica_case_file_lnk_id
           , NULL AS ica_da_enfrc_actn_lnk_id
           , ica_lnk_da_enfrc_actn.da_enfrc_actn_ident
           , ica_lnk_da_enfrc_actn.data_hash
        FROM ica_flow_icis.dbo.ica_lnk_da_enfrc_actn
        JOIN @tbl_cmpl_mon_lnk_id AS v_cml
          ON v_cml.icis_cmpl_mon_lnk_id = ica_lnk_da_enfrc_actn.ica_cmpl_mon_lnk_id;

     
 /* **********************************************
  * ICA_DA_ENFRC_ACTN_LNK:  Set Delete Transactions
  * **********************************************/         
	 DECLARE @tbl_da_enfrc_actn_lnk_id TABLE ( icis_da_enfrc_actn_lnk_id uniqueidentifier
	                                         , local_da_enfrc_actn_lnk_id uniqueidentifier);
	 
	 INSERT INTO @tbl_da_enfrc_actn_lnk_id
   SELECT DISTINCT 
          ica_da_enfrc_actn_lnk.ica_da_enfrc_actn_lnk_id AS icis_da_enfrc_actn_lnk_id
        , NEWID() AS local_da_enfrc_actn_lnk_id
     FROM ica_flow_icis.dbo.ica_da_enfrc_actn_lnk
    WHERE ica_da_enfrc_actn_lnk.key_hash IN (SELECT DISTINCT 
                                                    key_hash 
                                               FROM cdv_da_enfrc_actn_lnk
                                              WHERE action_type = 'DELETE');  


    /*  
     *  ICA_DA_ENFRC_ACTN_LNK
     */       
     INSERT INTO ica_da_enfrc_actn_lnk
          ( ica_da_enfrc_actn_lnk_id
          , ica_payload_id
          , transaction_type
          , transaction_timestamp
          , src_systm_ident
          , da_enfrc_actn_ident
          , key_hash
          , data_hash)
     SELECT v_eal.local_da_enfrc_actn_lnk_id AS ica_da_enfrc_actn_lnk_id
          , (SELECT ica_payload_id
               FROM ica_payload 
              WHERE operation = 'AirDAEnforcementActionLinkageSubmission') AS ica_payload_id
          , 'X' AS transaction_type
          , ica_da_enfrc_actn_lnk.transaction_timestamp
          , ica_da_enfrc_actn_lnk.src_systm_ident
          , ica_da_enfrc_actn_lnk.da_enfrc_actn_ident
          , NULL AS key_hash
          , NULL AS data_hash
       FROM ica_flow_icis.dbo.ica_da_enfrc_actn_lnk 
       JOIN @tbl_da_enfrc_actn_lnk_id AS v_eal
         ON v_eal.icis_da_enfrc_actn_lnk_id = ica_da_enfrc_actn_lnk.ica_da_enfrc_actn_lnk_id;
          
             
    /*  
     *  ICA_LNK_DA_ENFRC_ACTN
     */       
     INSERT INTO ICA_LNK_DA_ENFRC_ACTN
          ( ica_lnk_da_enfrc_actn_id 
          , ica_cmpl_mon_lnk_id 
          , ica_case_file_lnk_id 
          , ica_da_enfrc_actn_lnk_id 
          , da_enfrc_actn_ident 
          , data_hash )
     SELECT NEWID() AS ica_lnk_da_enfrc_actn_id 
          , NULL AS ica_cmpl_mon_lnk_id 
          , NULL AS ica_case_file_lnk_id 
          , v_eal.local_da_enfrc_actn_lnk_id AS ica_da_enfrc_actn_lnk_id 
          , ica_lnk_da_enfrc_actn.da_enfrc_actn_ident 
          , ica_lnk_da_enfrc_actn.data_hash 
      FROM ica_flow_icis.dbo.ica_lnk_da_enfrc_actn 
      JOIN @tbl_da_enfrc_actn_lnk_id AS v_eal
        ON v_eal.icis_da_enfrc_actn_lnk_id = ica_lnk_da_enfrc_actn.ica_da_enfrc_actn_lnk_id;
      
END;
GO