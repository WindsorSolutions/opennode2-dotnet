/*
Copyright (c) 2014, The Environmental Council of the States (ECOS)
All rights reserved.
 
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
 
 * Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
 * Neither the name of the ECOS nor the names of its contributors may
   be used to endorse or promote products derived from this software
   without specific prior written permission.
 
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.ICA_PROCESS_ACCEPTED_TRANS') AND type in (N'P', N'PC'))
DROP PROCEDURE dbo.ICA_PROCESS_ACCEPTED_TRANS
GO

/*************************************************************************************************
** Object Name: ica_process_accepted_trans
**
** Author: Windsor Solutions, Inc.
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure uses the data in ICA_SUBM_RSLTS table to copy the data for accepted
**               transactions from the LOCAL to ICIS schema/database. It should only be executed by
**               the OpenNode2 plugin as part of the GetICISStatusAndProcessReports service execution
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 07/18/2014    Windsor     Baseline from v4.0 procedure. 
** 08/11/2014    KJames      Renamed the submission results table.
** 08/11/2014    KJames      Renamed the submission results primary key column.
** 08/11/2014    KJames      Renamed the milestone type code on the submission history table.
** 08/11/2014    KJames      Removed trans_count_new from the submission history load.
** 07/06/2015    KJames      Added processing for new staging table ICA_DEMND_STIPULTD_PNLTY.
** 08/24/2015    KJames      Modified the SUBM_TYPE_NAME for CaseFileLinkageSubmission.
**
***************************************************************************************************/
CREATE PROCEDURE dbo.ICA_PROCESS_ACCEPTED_TRANS

   @p_transaction_id varchar(50)

AS

-- Stored procedure to move accepted transactions from ICA_FLOW_LOCAL to ICA_FLOW_ICIS.
-- Target Database: SQL Server

--Step 1: Remove processing results from previous submissions
--Step 2: Update key_hash with hashed business key data
--Step 3: Move accepted transactions from LOCAL to ICIS database
--Step 4: Copy business keys where ICIS returnes error that key is already present in ICIS
--Step 5: Record counts into ICA_SUBM_HIST

--Quit procedure if no records are returned relating to the current transaction. ICIS will return an empty processing report
  --if there is a severe error in the ICIS submission processor at EPA
IF (SELECT COUNT(1) FROM ica_subm_rslts WHERE subm_transaction_id = @p_transaction_id) = 0
   RETURN;

--Step 1: Remove processing results from previous submissions
--Step 1: Remove any previous accepted transactions so the procedure does not attempt to move records from previous executions.
DELETE 
  FROM ica_subm_rslts 
 WHERE result_type_code IN ('Accepted','Warning')
   AND subm_transaction_id <> @p_transaction_id;

---------------------------------------------------------
--Step 2: Update key_hash with hashed business key data
---------------------------------------------------------
UPDATE ica_subm_rslts
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', fac_ident)
 WHERE subm_type_name = 'AirComplianceMonitoringStrategySubmission'
   AND subm_transaction_id = @p_transaction_id;

UPDATE ica_subm_rslts
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', cmpl_mon_ident)
 WHERE subm_type_name = 'AirDAComplianceMonitoringSubmission'
   AND subm_transaction_id = @p_transaction_id;

UPDATE ica_subm_rslts
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', da_enfrc_actn_ident + milstn_type_code)
 WHERE subm_type_name = 'AirDAEnforcementActionMilestoneSubmission'
   AND subm_transaction_id = @p_transaction_id;

UPDATE ica_subm_rslts
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', da_enfrc_actn_ident)
 WHERE subm_type_name = 'AirDAFormalEnforcementActionSubmission'
   AND subm_transaction_id = @p_transaction_id;

UPDATE ica_subm_rslts
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', da_enfrc_actn_ident)
 WHERE subm_type_name = 'AirDAInformalEnforcementActionSubmission'
   AND subm_transaction_id = @p_transaction_id;

UPDATE ica_subm_rslts
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', fac_ident)
 WHERE subm_type_name = 'AirFacilitySubmission'
   AND subm_transaction_id = @p_transaction_id;

UPDATE ica_subm_rslts
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', fac_ident + CAST(poluts_code AS VARCHAR(10)))
 WHERE subm_type_name = 'AirPollutantsSubmission'
   AND subm_transaction_id = @p_transaction_id;

UPDATE ica_subm_rslts
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', fac_ident + prog_code)
 WHERE subm_type_name = 'AirProgramsSubmission'
   AND subm_transaction_id = @p_transaction_id;

UPDATE ica_subm_rslts
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', cmpl_mon_ident)
 WHERE subm_type_name = 'AirTVACCSubmission'
   AND subm_transaction_id = @p_transaction_id;

UPDATE ica_subm_rslts
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', case_file_ident)
 WHERE subm_type_name = 'AirDACaseFileSubmission'
   AND subm_transaction_id = @p_transaction_id;

UPDATE ica_subm_rslts
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', da_enfrc_actn_ident)
 WHERE subm_type_name = 'AirDAEnforcementActionLinkageSubmission'
   AND subm_transaction_id = @p_transaction_id;

UPDATE ica_subm_rslts
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', case_file_ident)
 WHERE subm_type_name = 'CaseFileLinkageSubmission'
   AND subm_transaction_id = @p_transaction_id;

UPDATE ica_subm_rslts
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', cmpl_mon_ident)
 WHERE subm_type_name = 'ComplianceMonitoringLinkageSubmission'
   AND subm_transaction_id = @p_transaction_id;

--Delete errors from previous submissions where here is an error for the same key in the current submission
-- ICIS Code!!
    DELETE 
      FROM ica_subm_rslts 
     WHERE result_type_code IN ('Error','Warning')
       AND key_hash IN (SELECT key_hash 
                          FROM ica_subm_rslts 
                         WHERE subm_transaction_id = @p_transaction_id
                           AND result_type_code IN ('Error','Warning'))
       AND subm_transaction_id <> @p_transaction_id;

-- ICIS Air Code!!
DELETE
  FROM ica_subm_rslts
 WHERE subm_type_name IN (SELECT operation 
                            FROM ica_payload
                           WHERE auto_gen_deletes = 'Y')
   AND subm_transaction_id <> @p_transaction_id;


DELETE
  FROM ica_subm_rslts
 WHERE subm_type_name = 'AirComplianceMonitoringStrategySubmission'
   AND subm_transaction_id <> @p_transaction_id
   AND result_type_code = 'Error'
   AND key_hash IN
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE subm_type_name = 'AirComplianceMonitoringStrategySubmission'
                  AND subm_transaction_id = @p_transaction_id);

DELETE
  FROM ica_subm_rslts
 WHERE subm_type_name = 'AirDAComplianceMonitoringSubmission'
   AND subm_transaction_id <> @p_transaction_id
   AND result_type_code = 'Error'
   AND key_hash IN
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE subm_type_name = 'AirDAComplianceMonitoringSubmission'
                  AND subm_transaction_id = @p_transaction_id);

DELETE
  FROM ica_subm_rslts
 WHERE subm_type_name = 'AirDAEnforcementActionMilestoneSubmission'
   AND subm_transaction_id <> @p_transaction_id
   AND result_type_code = 'Error'
   AND key_hash IN
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE subm_type_name = 'AirDAEnforcementActionMilestoneSubmission'
                  AND subm_transaction_id = @p_transaction_id);

DELETE
  FROM ica_subm_rslts
 WHERE subm_type_name = 'AirDAFormalEnforcementActionSubmission'
   AND subm_transaction_id <> @p_transaction_id
   AND result_type_code = 'Error'
   AND key_hash IN
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE subm_type_name = 'AirDAFormalEnforcementActionSubmission'
                  AND subm_transaction_id = @p_transaction_id);

DELETE
  FROM ica_subm_rslts
 WHERE subm_type_name = 'AirDAInformalEnforcementActionSubmission'
   AND subm_transaction_id <> @p_transaction_id
   AND result_type_code = 'Error'
   AND key_hash IN
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE subm_type_name = 'AirDAInformalEnforcementActionSubmission'
                  AND subm_transaction_id = @p_transaction_id);

DELETE
  FROM ica_subm_rslts
 WHERE subm_type_name = 'AirFacilitySubmission'
   AND subm_transaction_id <> @p_transaction_id
   AND result_type_code = 'Error'
   AND key_hash IN
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE subm_type_name = 'AirFacilitySubmission'
                  AND subm_transaction_id = @p_transaction_id);

DELETE
  FROM ica_subm_rslts
 WHERE subm_type_name = 'AirPollutantsSubmission'
   AND subm_transaction_id <> @p_transaction_id
   AND result_type_code = 'Error'
   AND key_hash IN
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE subm_type_name = 'AirPollutantsSubmission'
                  AND subm_transaction_id = @p_transaction_id);

DELETE
  FROM ica_subm_rslts
 WHERE subm_type_name = 'AirProgramsSubmission'
   AND subm_transaction_id <> @p_transaction_id
   AND result_type_code = 'Error'
   AND key_hash IN
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE subm_type_name = 'AirProgramsSubmission'
                  AND subm_transaction_id = @p_transaction_id);

DELETE
  FROM ica_subm_rslts
 WHERE subm_type_name = 'AirTVACCSubmission'
   AND subm_transaction_id <> @p_transaction_id
   AND result_type_code = 'Error'
   AND key_hash IN
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE subm_type_name = 'AirTVACCSubmission'
                  AND subm_transaction_id = @p_transaction_id);

DELETE
  FROM ica_subm_rslts
 WHERE subm_type_name = 'AirDACaseFileSubmission'
   AND subm_transaction_id <> @p_transaction_id
   AND result_type_code = 'Error'
   AND key_hash IN
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE subm_type_name = 'AirDACaseFileSubmission'
                  AND subm_transaction_id = @p_transaction_id);

DELETE
  FROM ica_subm_rslts
 WHERE subm_type_name = 'AirDAEnforcementActionLinkageSubmission'
   AND subm_transaction_id <> @p_transaction_id
   AND result_type_code = 'Error'
   AND key_hash IN
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE subm_type_name = 'AirDAEnforcementActionLinkageSubmission'
                  AND subm_transaction_id = @p_transaction_id);

DELETE
  FROM ica_subm_rslts
 WHERE subm_type_name = 'CaseFileLinkageSubmission'
   AND subm_transaction_id <> @p_transaction_id
   AND result_type_code = 'Error'
   AND key_hash IN
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE subm_type_name = 'CaseFileLinkageSubmission'
                  AND subm_transaction_id = @p_transaction_id);

DELETE
  FROM ica_subm_rslts
 WHERE subm_type_name = 'ComplianceMonitoringLinkageSubmission'
   AND subm_transaction_id <> @p_transaction_id
   AND result_type_code = 'Error'
   AND key_hash IN
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE subm_type_name = 'ComplianceMonitoringLinkageSubmission'
                  AND subm_transaction_id = @p_transaction_id);


 /*
  *  Step 3: Move accepted transactions from LOCAL to ICIS database
  *          FOR EACH PAYLOAD TYPE:
  *          1.  First prune data from the ICA_FLOW_ICIS schema to make room for new data coming across
  *              - Delete for basic permit, general permit, permitted feature, limit set, parameter limit, and limit data
  *                for permits that have been reissued.
  *              - Delete all data for permit that has been terminated 
  *          2.  Second copy accepted data from ICA_FLOW_LOCAL into ICA_FLOW_ICIS.
  */
  
-- Remove any old records for ica_cmpl_mon_strgy
-- /ICA_CMPL_MON_STRGY
DELETE
  FROM ica_flow_icis.dbo.ica_cmpl_mon_strgy
 WHERE ica_cmpl_mon_strgy.ica_cmpl_mon_strgy_id IN
          (SELECT ica_cmpl_mon_strgy.ica_cmpl_mon_strgy_id
             FROM ica_flow_icis.dbo.ica_cmpl_mon_strgy
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_cmpl_mon_strgy.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirComplianceMonitoringStrategySubmission')
);

-- Add accepted records for ica_cmpl_mon_strgy
-- /ICA_CMPL_MON_STRGY
INSERT INTO ica_flow_icis.dbo.ica_cmpl_mon_strgy
     SELECT ica_cmpl_mon_strgy.*
       FROM ica_cmpl_mon_strgy
       WHERE ica_cmpl_mon_strgy.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirComplianceMonitoringStrategySubmission');


-- Remove any old records for ica_da_cmpl_mon
-- /ICA_DA_CMPL_MON/ICA_STCK_TST/ICA_TST_RSLTS/ICA_METHOD
DELETE
  FROM ica_flow_icis.dbo.ica_method
 WHERE ica_method.ica_tst_rslts_id IN
          (SELECT ica_tst_rslts.ica_tst_rslts_id
             FROM ica_flow_icis.dbo.ica_da_cmpl_mon
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_cmpl_mon.key_hash 
                  JOIN ica_flow_icis.dbo.ica_stck_tst ON ica_stck_tst.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
                  JOIN ica_flow_icis.dbo.ica_tst_rslts ON ica_tst_rslts.ica_stck_tst_id = ica_stck_tst.ica_stck_tst_id
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAComplianceMonitoringSubmission')
);
-- /ICA_DA_CMPL_MON/ICA_CNTCT/ICA_TELEPH
DELETE
  FROM ica_flow_icis.dbo.ica_teleph
 WHERE ica_teleph.ica_cntct_id IN
          (SELECT ica_cntct.ica_cntct_id
             FROM ica_flow_icis.dbo.ica_da_cmpl_mon
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_cmpl_mon.key_hash 
                  JOIN ica_flow_icis.dbo.ica_cntct ON ica_cntct.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAComplianceMonitoringSubmission')
);
-- /ICA_DA_CMPL_MON/ICA_STCK_TST/ICA_STCK_TST_OBS_AGNCY_TYPE
DELETE
  FROM ica_flow_icis.dbo.ica_stck_tst_obs_agncy_type
 WHERE ica_stck_tst_obs_agncy_type.ica_stck_tst_id IN
          (SELECT ica_stck_tst.ica_stck_tst_id
             FROM ica_flow_icis.dbo.ica_da_cmpl_mon
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_cmpl_mon.key_hash 
                  JOIN ica_flow_icis.dbo.ica_stck_tst ON ica_stck_tst.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAComplianceMonitoringSubmission')
);
-- /ICA_DA_CMPL_MON/ICA_STCK_TST/ICA_STCK_TST_PURPOSE
DELETE
  FROM ica_flow_icis.dbo.ica_stck_tst_purpose
 WHERE ica_stck_tst_purpose.ica_stck_tst_id IN
          (SELECT ica_stck_tst.ica_stck_tst_id
             FROM ica_flow_icis.dbo.ica_da_cmpl_mon
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_cmpl_mon.key_hash 
                  JOIN ica_flow_icis.dbo.ica_stck_tst ON ica_stck_tst.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAComplianceMonitoringSubmission')
);
-- /ICA_DA_CMPL_MON/ICA_STCK_TST/ICA_TST_RSLTS
DELETE
  FROM ica_flow_icis.dbo.ica_tst_rslts
 WHERE ica_tst_rslts.ica_stck_tst_id IN
          (SELECT ica_stck_tst.ica_stck_tst_id
             FROM ica_flow_icis.dbo.ica_da_cmpl_mon
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_cmpl_mon.key_hash 
                  JOIN ica_flow_icis.dbo.ica_stck_tst ON ica_stck_tst.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAComplianceMonitoringSubmission')
);
-- /ICA_DA_CMPL_MON/ICA_CMPL_INSP_TYPE
DELETE
  FROM ica_flow_icis.dbo.ica_cmpl_insp_type
 WHERE ica_cmpl_insp_type.ica_da_cmpl_mon_id IN
          (SELECT ica_da_cmpl_mon.ica_da_cmpl_mon_id
             FROM ica_flow_icis.dbo.ica_da_cmpl_mon
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_cmpl_mon.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAComplianceMonitoringSubmission')
);
-- /ICA_DA_CMPL_MON/ICA_CNTCT
DELETE
  FROM ica_flow_icis.dbo.ica_cntct
 WHERE ica_cntct.ica_da_cmpl_mon_id IN
          (SELECT ica_da_cmpl_mon.ica_da_cmpl_mon_id
             FROM ica_flow_icis.dbo.ica_da_cmpl_mon
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_cmpl_mon.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAComplianceMonitoringSubmission')
);
-- /ICA_DA_CMPL_MON/ICA_FAC_IDENT
DELETE
  FROM ica_flow_icis.dbo.ica_fac_ident
 WHERE ica_fac_ident.ica_da_cmpl_mon_id IN
          (SELECT ica_da_cmpl_mon.ica_da_cmpl_mon_id
             FROM ica_flow_icis.dbo.ica_da_cmpl_mon
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_cmpl_mon.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAComplianceMonitoringSubmission')
);
-- /ICA_DA_CMPL_MON/ICA_INSP_CMNT_TXT
DELETE
  FROM ica_flow_icis.dbo.ica_insp_cmnt_txt
 WHERE ica_insp_cmnt_txt.ica_da_cmpl_mon_id IN
          (SELECT ica_da_cmpl_mon.ica_da_cmpl_mon_id
             FROM ica_flow_icis.dbo.ica_da_cmpl_mon
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_cmpl_mon.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAComplianceMonitoringSubmission')
);
-- /ICA_DA_CMPL_MON/ICA_INSP_GOV_CNTCT
DELETE
  FROM ica_flow_icis.dbo.ica_insp_gov_cntct
 WHERE ica_insp_gov_cntct.ica_da_cmpl_mon_id IN
          (SELECT ica_da_cmpl_mon.ica_da_cmpl_mon_id
             FROM ica_flow_icis.dbo.ica_da_cmpl_mon
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_cmpl_mon.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAComplianceMonitoringSubmission')
);
-- /ICA_DA_CMPL_MON/ICA_NAT_PRIO
DELETE
  FROM ica_flow_icis.dbo.ica_nat_prio
 WHERE ica_nat_prio.ica_da_cmpl_mon_id IN
          (SELECT ica_da_cmpl_mon.ica_da_cmpl_mon_id
             FROM ica_flow_icis.dbo.ica_da_cmpl_mon
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_cmpl_mon.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAComplianceMonitoringSubmission')
);
-- /ICA_DA_CMPL_MON/ICA_POLUT
DELETE
  FROM ica_flow_icis.dbo.ica_polut
 WHERE ica_polut.ica_da_cmpl_mon_id IN
          (SELECT ica_da_cmpl_mon.ica_da_cmpl_mon_id
             FROM ica_flow_icis.dbo.ica_da_cmpl_mon
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_cmpl_mon.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAComplianceMonitoringSubmission')
);
-- /ICA_DA_CMPL_MON/ICA_PROG
DELETE
  FROM ica_flow_icis.dbo.ica_prog
 WHERE ica_prog.ica_da_cmpl_mon_id IN
          (SELECT ica_da_cmpl_mon.ica_da_cmpl_mon_id
             FROM ica_flow_icis.dbo.ica_da_cmpl_mon
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_cmpl_mon.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAComplianceMonitoringSubmission')
);
-- /ICA_DA_CMPL_MON/ICA_RGNL_PRIO
DELETE
  FROM ica_flow_icis.dbo.ica_rgnl_prio
 WHERE ica_rgnl_prio.ica_da_cmpl_mon_id IN
          (SELECT ica_da_cmpl_mon.ica_da_cmpl_mon_id
             FROM ica_flow_icis.dbo.ica_da_cmpl_mon
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_cmpl_mon.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAComplianceMonitoringSubmission')
);
-- /ICA_DA_CMPL_MON/ICA_SENS_CMNT_TXT
DELETE
  FROM ica_flow_icis.dbo.ica_sens_cmnt_txt
 WHERE ica_sens_cmnt_txt.ica_da_cmpl_mon_id IN
          (SELECT ica_da_cmpl_mon.ica_da_cmpl_mon_id
             FROM ica_flow_icis.dbo.ica_da_cmpl_mon
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_cmpl_mon.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAComplianceMonitoringSubmission')
);
-- /ICA_DA_CMPL_MON/ICA_STCK_TST
DELETE
  FROM ica_flow_icis.dbo.ica_stck_tst
 WHERE ica_stck_tst.ica_da_cmpl_mon_id IN
          (SELECT ica_da_cmpl_mon.ica_da_cmpl_mon_id
             FROM ica_flow_icis.dbo.ica_da_cmpl_mon
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_cmpl_mon.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAComplianceMonitoringSubmission')
);
-- /ICA_DA_CMPL_MON
DELETE
  FROM ica_flow_icis.dbo.ica_da_cmpl_mon
 WHERE ica_da_cmpl_mon.ica_da_cmpl_mon_id IN
          (SELECT ica_da_cmpl_mon.ica_da_cmpl_mon_id
             FROM ica_flow_icis.dbo.ica_da_cmpl_mon
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_cmpl_mon.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAComplianceMonitoringSubmission')
);

-- Add accepted records for ica_da_cmpl_mon
-- /ICA_DA_CMPL_MON
INSERT INTO ica_flow_icis.dbo.ica_da_cmpl_mon
     SELECT ica_da_cmpl_mon.*
       FROM ica_da_cmpl_mon
       WHERE ica_da_cmpl_mon.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAComplianceMonitoringSubmission');

-- /ICA_DA_CMPL_MON/ICA_CMPL_INSP_TYPE
INSERT INTO ica_flow_icis.dbo.ica_cmpl_insp_type
     SELECT ica_cmpl_insp_type.*
       FROM ica_cmpl_insp_type
          JOIN ica_da_cmpl_mon
            ON ica_cmpl_insp_type.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
       WHERE ica_da_cmpl_mon.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAComplianceMonitoringSubmission');

-- /ICA_DA_CMPL_MON/ICA_CNTCT
INSERT INTO ica_flow_icis.dbo.ica_cntct
     SELECT ica_cntct.*
       FROM ica_cntct
          JOIN ica_da_cmpl_mon
            ON ica_cntct.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
       WHERE ica_da_cmpl_mon.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAComplianceMonitoringSubmission');

-- /ICA_DA_CMPL_MON/ICA_CNTCT/ICA_TELEPH
INSERT INTO ica_flow_icis.dbo.ica_teleph
     SELECT ica_teleph.*
       FROM ica_teleph
          JOIN ica_cntct
            ON ica_teleph.ica_cntct_id = ica_cntct.ica_cntct_id
          JOIN ica_da_cmpl_mon
            ON ica_cntct.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
       WHERE ica_da_cmpl_mon.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAComplianceMonitoringSubmission');

-- /ICA_DA_CMPL_MON/ICA_FAC_IDENT
INSERT INTO ica_flow_icis.dbo.ica_fac_ident
     SELECT ica_fac_ident.*
       FROM ica_fac_ident
          JOIN ica_da_cmpl_mon
            ON ica_fac_ident.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
       WHERE ica_da_cmpl_mon.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAComplianceMonitoringSubmission');

-- /ICA_DA_CMPL_MON/ICA_INSP_CMNT_TXT
INSERT INTO ica_flow_icis.dbo.ica_insp_cmnt_txt
     SELECT ica_insp_cmnt_txt.*
       FROM ica_insp_cmnt_txt
          JOIN ica_da_cmpl_mon
            ON ica_insp_cmnt_txt.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
       WHERE ica_da_cmpl_mon.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAComplianceMonitoringSubmission');

-- /ICA_DA_CMPL_MON/ICA_INSP_GOV_CNTCT
INSERT INTO ica_flow_icis.dbo.ica_insp_gov_cntct
     SELECT ica_insp_gov_cntct.*
       FROM ica_insp_gov_cntct
          JOIN ica_da_cmpl_mon
            ON ica_insp_gov_cntct.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
       WHERE ica_da_cmpl_mon.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAComplianceMonitoringSubmission');

-- /ICA_DA_CMPL_MON/ICA_NAT_PRIO
INSERT INTO ica_flow_icis.dbo.ica_nat_prio
     SELECT ica_nat_prio.*
       FROM ica_nat_prio
          JOIN ica_da_cmpl_mon
            ON ica_nat_prio.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
       WHERE ica_da_cmpl_mon.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAComplianceMonitoringSubmission');

-- /ICA_DA_CMPL_MON/ICA_POLUT
INSERT INTO ica_flow_icis.dbo.ica_polut
     SELECT ica_polut.*
       FROM ica_polut
          JOIN ica_da_cmpl_mon
            ON ica_polut.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
       WHERE ica_da_cmpl_mon.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAComplianceMonitoringSubmission');

-- /ICA_DA_CMPL_MON/ICA_PROG
INSERT INTO ica_flow_icis.dbo.ica_prog
     SELECT ica_prog.*
       FROM ica_prog
          JOIN ica_da_cmpl_mon
            ON ica_prog.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
       WHERE ica_da_cmpl_mon.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAComplianceMonitoringSubmission');

-- /ICA_DA_CMPL_MON/ICA_RGNL_PRIO
INSERT INTO ica_flow_icis.dbo.ica_rgnl_prio
     SELECT ica_rgnl_prio.*
       FROM ica_rgnl_prio
          JOIN ica_da_cmpl_mon
            ON ica_rgnl_prio.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
       WHERE ica_da_cmpl_mon.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAComplianceMonitoringSubmission');

-- /ICA_DA_CMPL_MON/ICA_SENS_CMNT_TXT
INSERT INTO ica_flow_icis.dbo.ica_sens_cmnt_txt
     SELECT ica_sens_cmnt_txt.*
       FROM ica_sens_cmnt_txt
          JOIN ica_da_cmpl_mon
            ON ica_sens_cmnt_txt.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
       WHERE ica_da_cmpl_mon.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAComplianceMonitoringSubmission');

-- /ICA_DA_CMPL_MON/ICA_STCK_TST
INSERT INTO ica_flow_icis.dbo.ica_stck_tst
     SELECT ica_stck_tst.*
       FROM ica_stck_tst
          JOIN ica_da_cmpl_mon
            ON ica_stck_tst.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
       WHERE ica_da_cmpl_mon.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAComplianceMonitoringSubmission');

-- /ICA_DA_CMPL_MON/ICA_STCK_TST/ICA_STCK_TST_OBS_AGNCY_TYPE
INSERT INTO ica_flow_icis.dbo.ica_stck_tst_obs_agncy_type
     SELECT ica_stck_tst_obs_agncy_type.*
       FROM ica_stck_tst_obs_agncy_type
          JOIN ica_stck_tst
            ON ica_stck_tst_obs_agncy_type.ica_stck_tst_id = ica_stck_tst.ica_stck_tst_id
          JOIN ica_da_cmpl_mon
            ON ica_stck_tst.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
       WHERE ica_da_cmpl_mon.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAComplianceMonitoringSubmission');

-- /ICA_DA_CMPL_MON/ICA_STCK_TST/ICA_STCK_TST_PURPOSE
INSERT INTO ica_flow_icis.dbo.ica_stck_tst_purpose
     SELECT ica_stck_tst_purpose.*
       FROM ica_stck_tst_purpose
          JOIN ica_stck_tst
            ON ica_stck_tst_purpose.ica_stck_tst_id = ica_stck_tst.ica_stck_tst_id
          JOIN ica_da_cmpl_mon
            ON ica_stck_tst.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
       WHERE ica_da_cmpl_mon.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAComplianceMonitoringSubmission');

-- /ICA_DA_CMPL_MON/ICA_STCK_TST/ICA_TST_RSLTS
INSERT INTO ica_flow_icis.dbo.ica_tst_rslts
     SELECT ica_tst_rslts.*
       FROM ica_tst_rslts
          JOIN ica_stck_tst
            ON ica_tst_rslts.ica_stck_tst_id = ica_stck_tst.ica_stck_tst_id
          JOIN ica_da_cmpl_mon
            ON ica_stck_tst.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
       WHERE ica_da_cmpl_mon.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAComplianceMonitoringSubmission');

-- /ICA_DA_CMPL_MON/ICA_STCK_TST/ICA_TST_RSLTS/ICA_METHOD
INSERT INTO ica_flow_icis.dbo.ica_method
     SELECT ica_method.*
       FROM ica_method
          JOIN ica_tst_rslts
            ON ica_method.ica_tst_rslts_id = ica_tst_rslts.ica_tst_rslts_id
          JOIN ica_stck_tst
            ON ica_tst_rslts.ica_stck_tst_id = ica_stck_tst.ica_stck_tst_id
          JOIN ica_da_cmpl_mon
            ON ica_stck_tst.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
       WHERE ica_da_cmpl_mon.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAComplianceMonitoringSubmission');


-- Remove any old records for ica_da_enfrc_actn_milstn
-- /ICA_DA_ENFRC_ACTN_MILSTN
DELETE
  FROM ica_flow_icis.dbo.ica_da_enfrc_actn_milstn
 WHERE ica_da_enfrc_actn_milstn.ica_da_enfrc_actn_milstn_id IN
          (SELECT ica_da_enfrc_actn_milstn.ica_da_enfrc_actn_milstn_id
             FROM ica_flow_icis.dbo.ica_da_enfrc_actn_milstn
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_enfrc_actn_milstn.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAEnforcementActionMilestoneSubmission')
);

-- Add accepted records for ica_da_enfrc_actn_milstn
-- /ICA_DA_ENFRC_ACTN_MILSTN
INSERT INTO ica_flow_icis.dbo.ica_da_enfrc_actn_milstn
     SELECT ica_da_enfrc_actn_milstn.*
       FROM ica_da_enfrc_actn_milstn
       WHERE ica_da_enfrc_actn_milstn.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAEnforcementActionMilestoneSubmission');


-- Remove any old records for ica_da_frml_enfrc_actn
-- /ICA_DA_FRML_ENFRC_ACTN/ICA_DA_FINAL_ORDER/ICA_FINAL_ORDER_FAC_IDENT
DELETE
  FROM ica_flow_icis.dbo.ica_final_order_fac_ident
 WHERE ica_final_order_fac_ident.ica_da_final_order_id IN
          (SELECT ica_da_final_order.ica_da_final_order_id
             FROM ica_flow_icis.dbo.ica_da_frml_enfrc_actn
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_frml_enfrc_actn.key_hash 
                  JOIN ica_flow_icis.dbo.ica_da_final_order ON ica_da_final_order.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAFormalEnforcementActionSubmission')
);

-- Remove any old records for ica_demnd_stipultd_pnlty
-- /ICA_DA_FRML_ENFRC_ACTN/ICA_DA_FINAL_ORDER/ICA_DEMND_STIPULTD_PNLTY
DELETE
  FROM ica_flow_icis.dbo.ica_demnd_stipultd_pnlty
 WHERE ica_demnd_stipultd_pnlty.ica_da_final_order_id IN
          (SELECT ica_da_final_order.ica_da_final_order_id
             FROM ica_flow_icis.dbo.ica_da_frml_enfrc_actn
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_frml_enfrc_actn.key_hash 
                  JOIN ica_flow_icis.dbo.ica_da_final_order ON ica_da_final_order.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAFormalEnforcementActionSubmission')
);

-- /ICA_DA_FRML_ENFRC_ACTN/ICA_DA_FINAL_ORDER
DELETE
  FROM ica_flow_icis.dbo.ica_da_final_order
 WHERE ica_da_final_order.ica_da_frml_enfrc_actn_id IN
          (SELECT ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
             FROM ica_flow_icis.dbo.ica_da_frml_enfrc_actn
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_frml_enfrc_actn.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAFormalEnforcementActionSubmission')
);
-- /ICA_DA_FRML_ENFRC_ACTN/ICA_ENFRC_ACTN_CMNT_TXT
DELETE
  FROM ica_flow_icis.dbo.ica_enfrc_actn_cmnt_txt
 WHERE ica_enfrc_actn_cmnt_txt.ica_da_frml_enfrc_actn_id IN
          (SELECT ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
             FROM ica_flow_icis.dbo.ica_da_frml_enfrc_actn
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_frml_enfrc_actn.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAFormalEnforcementActionSubmission')
);
-- /ICA_DA_FRML_ENFRC_ACTN/ICA_ENFRC_ACTN_GOV_CNTCT
DELETE
  FROM ica_flow_icis.dbo.ica_enfrc_actn_gov_cntct
 WHERE ica_enfrc_actn_gov_cntct.ica_da_frml_enfrc_actn_id IN
          (SELECT ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
             FROM ica_flow_icis.dbo.ica_da_frml_enfrc_actn
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_frml_enfrc_actn.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAFormalEnforcementActionSubmission')
);
-- /ICA_DA_FRML_ENFRC_ACTN/ICA_ENFRC_ACTN_TYPE
DELETE
  FROM ica_flow_icis.dbo.ica_enfrc_actn_type
 WHERE ica_enfrc_actn_type.ica_da_frml_enfrc_actn_id IN
          (SELECT ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
             FROM ica_flow_icis.dbo.ica_da_frml_enfrc_actn
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_frml_enfrc_actn.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAFormalEnforcementActionSubmission')
);
-- /ICA_DA_FRML_ENFRC_ACTN/ICA_ENFRC_AGNCY_TYPE
DELETE
  FROM ica_flow_icis.dbo.ica_enfrc_agncy_type
 WHERE ica_enfrc_agncy_type.ica_da_frml_enfrc_actn_id IN
          (SELECT ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
             FROM ica_flow_icis.dbo.ica_da_frml_enfrc_actn
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_frml_enfrc_actn.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAFormalEnforcementActionSubmission')
);
-- /ICA_DA_FRML_ENFRC_ACTN/ICA_FAC_IDENT
DELETE
  FROM ica_flow_icis.dbo.ica_fac_ident
 WHERE ica_fac_ident.ica_da_frml_enfrc_actn_id IN
          (SELECT ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
             FROM ica_flow_icis.dbo.ica_da_frml_enfrc_actn
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_frml_enfrc_actn.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAFormalEnforcementActionSubmission')
);
-- /ICA_DA_FRML_ENFRC_ACTN/ICA_POLUT
DELETE
  FROM ica_flow_icis.dbo.ica_polut
 WHERE ica_polut.ica_da_frml_enfrc_actn_id IN
          (SELECT ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
             FROM ica_flow_icis.dbo.ica_da_frml_enfrc_actn
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_frml_enfrc_actn.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAFormalEnforcementActionSubmission')
);
-- /ICA_DA_FRML_ENFRC_ACTN/ICA_PROGS_VIOL
DELETE
  FROM ica_flow_icis.dbo.ica_progs_viol
 WHERE ica_progs_viol.ica_da_frml_enfrc_actn_id IN
          (SELECT ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
             FROM ica_flow_icis.dbo.ica_da_frml_enfrc_actn
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_frml_enfrc_actn.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAFormalEnforcementActionSubmission')
);
-- /ICA_DA_FRML_ENFRC_ACTN/ICA_SENS_CMNT_TXT
DELETE
  FROM ica_flow_icis.dbo.ica_sens_cmnt_txt
 WHERE ica_sens_cmnt_txt.ica_da_frml_enfrc_actn_id IN
          (SELECT ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
             FROM ica_flow_icis.dbo.ica_da_frml_enfrc_actn
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_frml_enfrc_actn.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAFormalEnforcementActionSubmission')
);
-- /ICA_DA_FRML_ENFRC_ACTN
DELETE
  FROM ica_flow_icis.dbo.ica_da_frml_enfrc_actn
 WHERE ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id IN
          (SELECT ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
             FROM ica_flow_icis.dbo.ica_da_frml_enfrc_actn
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_frml_enfrc_actn.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAFormalEnforcementActionSubmission')
);

-- Add accepted records for ica_da_frml_enfrc_actn
-- /ICA_DA_FRML_ENFRC_ACTN
INSERT INTO ica_flow_icis.dbo.ica_da_frml_enfrc_actn
     SELECT ica_da_frml_enfrc_actn.*
       FROM ica_da_frml_enfrc_actn
       WHERE ica_da_frml_enfrc_actn.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAFormalEnforcementActionSubmission');

-- /ICA_DA_FRML_ENFRC_ACTN/ICA_DA_FINAL_ORDER
INSERT INTO ica_flow_icis.dbo.ica_da_final_order
     SELECT ica_da_final_order.*
       FROM ica_da_final_order
          JOIN ica_da_frml_enfrc_actn
            ON ica_da_final_order.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
       WHERE ica_da_frml_enfrc_actn.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAFormalEnforcementActionSubmission');

-- /ICA_DA_FRML_ENFRC_ACTN/ICA_DA_FINAL_ORDER/ICA_FINAL_ORDER_FAC_IDENT
INSERT INTO ica_flow_icis.dbo.ica_final_order_fac_ident
     SELECT ica_final_order_fac_ident.*
       FROM ica_final_order_fac_ident
          JOIN ica_da_final_order
            ON ica_final_order_fac_ident.ica_da_final_order_id = ica_da_final_order.ica_da_final_order_id
          JOIN ica_da_frml_enfrc_actn
            ON ica_da_final_order.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
       WHERE ica_da_frml_enfrc_actn.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAFormalEnforcementActionSubmission');

-- /ICA_DA_FRML_ENFRC_ACTN/ICA_DA_FINAL_ORDER/ICA_DEMND_STIPULTD_PNLTY
INSERT INTO ica_flow_icis.dbo.ica_demnd_stipultd_pnlty
     SELECT ica_demnd_stipultd_pnlty.*
       FROM ica_demnd_stipultd_pnlty
          JOIN ica_da_final_order
            ON ica_demnd_stipultd_pnlty.ica_da_final_order_id = ica_da_final_order.ica_da_final_order_id
          JOIN ica_da_frml_enfrc_actn
            ON ica_da_final_order.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
       WHERE ica_da_frml_enfrc_actn.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAFormalEnforcementActionSubmission');

-- /ICA_DA_FRML_ENFRC_ACTN/ICA_ENFRC_ACTN_CMNT_TXT
INSERT INTO ica_flow_icis.dbo.ica_enfrc_actn_cmnt_txt
     SELECT ica_enfrc_actn_cmnt_txt.*
       FROM ica_enfrc_actn_cmnt_txt
          JOIN ica_da_frml_enfrc_actn
            ON ica_enfrc_actn_cmnt_txt.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
       WHERE ica_da_frml_enfrc_actn.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAFormalEnforcementActionSubmission');

-- /ICA_DA_FRML_ENFRC_ACTN/ICA_ENFRC_ACTN_GOV_CNTCT
INSERT INTO ica_flow_icis.dbo.ica_enfrc_actn_gov_cntct
     SELECT ica_enfrc_actn_gov_cntct.*
       FROM ica_enfrc_actn_gov_cntct
          JOIN ica_da_frml_enfrc_actn
            ON ica_enfrc_actn_gov_cntct.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
       WHERE ica_da_frml_enfrc_actn.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAFormalEnforcementActionSubmission');

-- /ICA_DA_FRML_ENFRC_ACTN/ICA_ENFRC_ACTN_TYPE
INSERT INTO ica_flow_icis.dbo.ica_enfrc_actn_type
     SELECT ica_enfrc_actn_type.*
       FROM ica_enfrc_actn_type
          JOIN ica_da_frml_enfrc_actn
            ON ica_enfrc_actn_type.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
       WHERE ica_da_frml_enfrc_actn.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAFormalEnforcementActionSubmission');

-- /ICA_DA_FRML_ENFRC_ACTN/ICA_ENFRC_AGNCY_TYPE
INSERT INTO ica_flow_icis.dbo.ica_enfrc_agncy_type
     SELECT ica_enfrc_agncy_type.*
       FROM ica_enfrc_agncy_type
          JOIN ica_da_frml_enfrc_actn
            ON ica_enfrc_agncy_type.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
       WHERE ica_da_frml_enfrc_actn.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAFormalEnforcementActionSubmission');

-- /ICA_DA_FRML_ENFRC_ACTN/ICA_FAC_IDENT
INSERT INTO ica_flow_icis.dbo.ica_fac_ident
     SELECT ica_fac_ident.*
       FROM ica_fac_ident
          JOIN ica_da_frml_enfrc_actn
            ON ica_fac_ident.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
       WHERE ica_da_frml_enfrc_actn.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAFormalEnforcementActionSubmission');

-- /ICA_DA_FRML_ENFRC_ACTN/ICA_POLUT
INSERT INTO ica_flow_icis.dbo.ica_polut
     SELECT ica_polut.*
       FROM ica_polut
          JOIN ica_da_frml_enfrc_actn
            ON ica_polut.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
       WHERE ica_da_frml_enfrc_actn.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAFormalEnforcementActionSubmission');

-- /ICA_DA_FRML_ENFRC_ACTN/ICA_PROGS_VIOL
INSERT INTO ica_flow_icis.dbo.ica_progs_viol
     SELECT ica_progs_viol.*
       FROM ica_progs_viol
          JOIN ica_da_frml_enfrc_actn
            ON ica_progs_viol.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
       WHERE ica_da_frml_enfrc_actn.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAFormalEnforcementActionSubmission');

-- /ICA_DA_FRML_ENFRC_ACTN/ICA_SENS_CMNT_TXT
INSERT INTO ica_flow_icis.dbo.ica_sens_cmnt_txt
     SELECT ica_sens_cmnt_txt.*
       FROM ica_sens_cmnt_txt
          JOIN ica_da_frml_enfrc_actn
            ON ica_sens_cmnt_txt.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
       WHERE ica_da_frml_enfrc_actn.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAFormalEnforcementActionSubmission');


-- Remove any old records for ica_da_infrml_enfrc_actn
-- /ICA_DA_INFRML_ENFRC_ACTN/ICA_ENFRC_ACTN_GOV_CNTCT
DELETE
  FROM ica_flow_icis.dbo.ica_enfrc_actn_gov_cntct
 WHERE ica_enfrc_actn_gov_cntct.ica_da_infrml_enfrc_actn_id IN
          (SELECT ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
             FROM ica_flow_icis.dbo.ica_da_infrml_enfrc_actn
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_infrml_enfrc_actn.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAInformalEnforcementActionSubmission')
);
-- /ICA_DA_INFRML_ENFRC_ACTN/ICA_ENFRC_AGNCY_TYPE
DELETE
  FROM ica_flow_icis.dbo.ica_enfrc_agncy_type
 WHERE ica_enfrc_agncy_type.ica_da_infrml_enfrc_actn_id IN
          (SELECT ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
             FROM ica_flow_icis.dbo.ica_da_infrml_enfrc_actn
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_infrml_enfrc_actn.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAInformalEnforcementActionSubmission')
);
-- /ICA_DA_INFRML_ENFRC_ACTN/ICA_FAC_IDENT
DELETE
  FROM ica_flow_icis.dbo.ica_fac_ident
 WHERE ica_fac_ident.ica_da_infrml_enfrc_actn_id IN
          (SELECT ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
             FROM ica_flow_icis.dbo.ica_da_infrml_enfrc_actn
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_infrml_enfrc_actn.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAInformalEnforcementActionSubmission')
);
-- /ICA_DA_INFRML_ENFRC_ACTN/ICA_INFRML_EA_CMNT_TXT
DELETE
  FROM ica_flow_icis.dbo.ica_infrml_ea_cmnt_txt
 WHERE ica_infrml_ea_cmnt_txt.ica_da_infrml_enfrc_actn_id IN
          (SELECT ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
             FROM ica_flow_icis.dbo.ica_da_infrml_enfrc_actn
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_infrml_enfrc_actn.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAInformalEnforcementActionSubmission')
);
-- /ICA_DA_INFRML_ENFRC_ACTN/ICA_POLUT
DELETE
  FROM ica_flow_icis.dbo.ica_polut
 WHERE ica_polut.ica_da_infrml_enfrc_actn_id IN
          (SELECT ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
             FROM ica_flow_icis.dbo.ica_da_infrml_enfrc_actn
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_infrml_enfrc_actn.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAInformalEnforcementActionSubmission')
);
-- /ICA_DA_INFRML_ENFRC_ACTN/ICA_PROGS_VIOL
DELETE
  FROM ica_flow_icis.dbo.ica_progs_viol
 WHERE ica_progs_viol.ica_da_infrml_enfrc_actn_id IN
          (SELECT ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
             FROM ica_flow_icis.dbo.ica_da_infrml_enfrc_actn
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_infrml_enfrc_actn.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAInformalEnforcementActionSubmission')
);
-- /ICA_DA_INFRML_ENFRC_ACTN/ICA_SENS_CMNT_TXT
DELETE
  FROM ica_flow_icis.dbo.ica_sens_cmnt_txt
 WHERE ica_sens_cmnt_txt.ica_da_infrml_enfrc_actn_id IN
          (SELECT ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
             FROM ica_flow_icis.dbo.ica_da_infrml_enfrc_actn
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_infrml_enfrc_actn.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAInformalEnforcementActionSubmission')
);
-- /ICA_DA_INFRML_ENFRC_ACTN
DELETE
  FROM ica_flow_icis.dbo.ica_da_infrml_enfrc_actn
 WHERE ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id IN
          (SELECT ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
             FROM ica_flow_icis.dbo.ica_da_infrml_enfrc_actn
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_infrml_enfrc_actn.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAInformalEnforcementActionSubmission')
);

-- Add accepted records for ica_da_infrml_enfrc_actn
-- /ICA_DA_INFRML_ENFRC_ACTN
INSERT INTO ica_flow_icis.dbo.ica_da_infrml_enfrc_actn
     SELECT ica_da_infrml_enfrc_actn.*
       FROM ica_da_infrml_enfrc_actn
       WHERE ica_da_infrml_enfrc_actn.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAInformalEnforcementActionSubmission');

-- /ICA_DA_INFRML_ENFRC_ACTN/ICA_ENFRC_ACTN_GOV_CNTCT
INSERT INTO ica_flow_icis.dbo.ica_enfrc_actn_gov_cntct
     SELECT ica_enfrc_actn_gov_cntct.*
       FROM ica_enfrc_actn_gov_cntct
          JOIN ica_da_infrml_enfrc_actn
            ON ica_enfrc_actn_gov_cntct.ica_da_infrml_enfrc_actn_id = ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
       WHERE ica_da_infrml_enfrc_actn.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAInformalEnforcementActionSubmission');

-- /ICA_DA_INFRML_ENFRC_ACTN/ICA_ENFRC_AGNCY_TYPE
INSERT INTO ica_flow_icis.dbo.ica_enfrc_agncy_type
     SELECT ica_enfrc_agncy_type.*
       FROM ica_enfrc_agncy_type
          JOIN ica_da_infrml_enfrc_actn
            ON ica_enfrc_agncy_type.ica_da_infrml_enfrc_actn_id = ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
       WHERE ica_da_infrml_enfrc_actn.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAInformalEnforcementActionSubmission');

-- /ICA_DA_INFRML_ENFRC_ACTN/ICA_FAC_IDENT
INSERT INTO ica_flow_icis.dbo.ica_fac_ident
     SELECT ica_fac_ident.*
       FROM ica_fac_ident
          JOIN ica_da_infrml_enfrc_actn
            ON ica_fac_ident.ica_da_infrml_enfrc_actn_id = ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
       WHERE ica_da_infrml_enfrc_actn.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAInformalEnforcementActionSubmission');

-- /ICA_DA_INFRML_ENFRC_ACTN/ICA_INFRML_EA_CMNT_TXT
INSERT INTO ica_flow_icis.dbo.ica_infrml_ea_cmnt_txt
     SELECT ica_infrml_ea_cmnt_txt.*
       FROM ica_infrml_ea_cmnt_txt
          JOIN ica_da_infrml_enfrc_actn
            ON ica_infrml_ea_cmnt_txt.ica_da_infrml_enfrc_actn_id = ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
       WHERE ica_da_infrml_enfrc_actn.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAInformalEnforcementActionSubmission');

-- /ICA_DA_INFRML_ENFRC_ACTN/ICA_POLUT
INSERT INTO ica_flow_icis.dbo.ica_polut
     SELECT ica_polut.*
       FROM ica_polut
          JOIN ica_da_infrml_enfrc_actn
            ON ica_polut.ica_da_infrml_enfrc_actn_id = ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
       WHERE ica_da_infrml_enfrc_actn.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAInformalEnforcementActionSubmission');

-- /ICA_DA_INFRML_ENFRC_ACTN/ICA_PROGS_VIOL
INSERT INTO ica_flow_icis.dbo.ica_progs_viol
     SELECT ica_progs_viol.*
       FROM ica_progs_viol
          JOIN ica_da_infrml_enfrc_actn
            ON ica_progs_viol.ica_da_infrml_enfrc_actn_id = ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
       WHERE ica_da_infrml_enfrc_actn.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAInformalEnforcementActionSubmission');

-- /ICA_DA_INFRML_ENFRC_ACTN/ICA_SENS_CMNT_TXT
INSERT INTO ica_flow_icis.dbo.ica_sens_cmnt_txt
     SELECT ica_sens_cmnt_txt.*
       FROM ica_sens_cmnt_txt
          JOIN ica_da_infrml_enfrc_actn
            ON ica_sens_cmnt_txt.ica_da_infrml_enfrc_actn_id = ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
       WHERE ica_da_infrml_enfrc_actn.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAInformalEnforcementActionSubmission');


-- Remove any old records for ica_fac
-- /ICA_FAC/ICA_CNTCT/ICA_TELEPH
DELETE
  FROM ica_flow_icis.dbo.ica_teleph
 WHERE ica_teleph.ica_cntct_id IN
          (SELECT ica_cntct.ica_cntct_id
             FROM ica_flow_icis.dbo.ica_fac
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_fac.key_hash 
                  JOIN ica_flow_icis.dbo.ica_cntct ON ica_cntct.ica_fac_id = ica_fac.ica_fac_id
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirFacilitySubmission')
);
-- /ICA_FAC/ICA_FAC_ADDR/ICA_TELEPH
DELETE
  FROM ica_flow_icis.dbo.ica_teleph
 WHERE ica_teleph.ica_fac_addr_id IN
          (SELECT ica_fac_addr.ica_fac_addr_id
             FROM ica_flow_icis.dbo.ica_fac
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_fac.key_hash 
                  JOIN ica_flow_icis.dbo.ica_fac_addr ON ica_fac_addr.ica_fac_id = ica_fac.ica_fac_id
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirFacilitySubmission')
);
-- /ICA_FAC/ICA_CNTCT
DELETE
  FROM ica_flow_icis.dbo.ica_cntct
 WHERE ica_cntct.ica_fac_id IN
          (SELECT ica_fac.ica_fac_id
             FROM ica_flow_icis.dbo.ica_fac
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_fac.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirFacilitySubmission')
);
-- /ICA_FAC/ICA_FAC_ADDR
DELETE
  FROM ica_flow_icis.dbo.ica_fac_addr
 WHERE ica_fac_addr.ica_fac_id IN
          (SELECT ica_fac.ica_fac_id
             FROM ica_flow_icis.dbo.ica_fac
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_fac.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirFacilitySubmission')
);
-- /ICA_FAC/ICA_GEO_COORD
DELETE
  FROM ica_flow_icis.dbo.ica_geo_coord
 WHERE ica_geo_coord.ica_fac_id IN
          (SELECT ica_fac.ica_fac_id
             FROM ica_flow_icis.dbo.ica_fac
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_fac.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirFacilitySubmission')
);
-- /ICA_FAC/ICA_NAICS_CODE
DELETE
  FROM ica_flow_icis.dbo.ica_naics_code
 WHERE ica_naics_code.ica_fac_id IN
          (SELECT ica_fac.ica_fac_id
             FROM ica_flow_icis.dbo.ica_fac
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_fac.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirFacilitySubmission')
);
-- /ICA_FAC/ICA_PORT_SRC
DELETE
  FROM ica_flow_icis.dbo.ica_port_src
 WHERE ica_port_src.ica_fac_id IN
          (SELECT ica_fac.ica_fac_id
             FROM ica_flow_icis.dbo.ica_fac
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_fac.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirFacilitySubmission')
);
-- /ICA_FAC/ICA_SIC_CODE
DELETE
  FROM ica_flow_icis.dbo.ica_sic_code
 WHERE ica_sic_code.ica_fac_id IN
          (SELECT ica_fac.ica_fac_id
             FROM ica_flow_icis.dbo.ica_fac
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_fac.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirFacilitySubmission')
);
-- /ICA_FAC/ICA_UNIVERSE_IND
DELETE
  FROM ica_flow_icis.dbo.ica_universe_ind
 WHERE ica_universe_ind.ica_fac_id IN
          (SELECT ica_fac.ica_fac_id
             FROM ica_flow_icis.dbo.ica_fac
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_fac.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirFacilitySubmission')
);
-- /ICA_FAC
DELETE
  FROM ica_flow_icis.dbo.ica_fac
 WHERE ica_fac.ica_fac_id IN
          (SELECT ica_fac.ica_fac_id
             FROM ica_flow_icis.dbo.ica_fac
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_fac.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirFacilitySubmission')
);

-- Add accepted records for ica_fac
-- /ICA_FAC
INSERT INTO ica_flow_icis.dbo.ica_fac
     SELECT ica_fac.*
       FROM ica_fac
       WHERE ica_fac.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirFacilitySubmission');

-- /ICA_FAC/ICA_CNTCT
INSERT INTO ica_flow_icis.dbo.ica_cntct
     SELECT ica_cntct.*
       FROM ica_cntct
          JOIN ica_fac
            ON ica_cntct.ica_fac_id = ica_fac.ica_fac_id
       WHERE ica_fac.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirFacilitySubmission');

-- /ICA_FAC/ICA_CNTCT/ICA_TELEPH
INSERT INTO ica_flow_icis.dbo.ica_teleph
     SELECT ica_teleph.*
       FROM ica_teleph
          JOIN ica_cntct
            ON ica_teleph.ica_cntct_id = ica_cntct.ica_cntct_id
          JOIN ica_fac
            ON ica_cntct.ica_fac_id = ica_fac.ica_fac_id
       WHERE ica_fac.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirFacilitySubmission');

-- /ICA_FAC/ICA_FAC_ADDR
INSERT INTO ica_flow_icis.dbo.ica_fac_addr
     SELECT ica_fac_addr.*
       FROM ica_fac_addr
          JOIN ica_fac
            ON ica_fac_addr.ica_fac_id = ica_fac.ica_fac_id
       WHERE ica_fac.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirFacilitySubmission');

-- /ICA_FAC/ICA_FAC_ADDR/ICA_TELEPH
INSERT INTO ica_flow_icis.dbo.ica_teleph
     SELECT ica_teleph.*
       FROM ica_teleph
          JOIN ica_fac_addr
            ON ica_teleph.ica_fac_addr_id = ica_fac_addr.ica_fac_addr_id
          JOIN ica_fac
            ON ica_fac_addr.ica_fac_id = ica_fac.ica_fac_id
       WHERE ica_fac.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirFacilitySubmission');

-- /ICA_FAC/ICA_GEO_COORD
INSERT INTO ica_flow_icis.dbo.ica_geo_coord
     SELECT ica_geo_coord.*
       FROM ica_geo_coord
          JOIN ica_fac
            ON ica_geo_coord.ica_fac_id = ica_fac.ica_fac_id
       WHERE ica_fac.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirFacilitySubmission');

-- /ICA_FAC/ICA_NAICS_CODE
INSERT INTO ica_flow_icis.dbo.ica_naics_code
     SELECT ica_naics_code.*
       FROM ica_naics_code
          JOIN ica_fac
            ON ica_naics_code.ica_fac_id = ica_fac.ica_fac_id
       WHERE ica_fac.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirFacilitySubmission');

-- /ICA_FAC/ICA_PORT_SRC
INSERT INTO ica_flow_icis.dbo.ica_port_src
     SELECT ica_port_src.*
       FROM ica_port_src
          JOIN ica_fac
            ON ica_port_src.ica_fac_id = ica_fac.ica_fac_id
       WHERE ica_fac.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirFacilitySubmission');

-- /ICA_FAC/ICA_SIC_CODE
INSERT INTO ica_flow_icis.dbo.ica_sic_code
     SELECT ica_sic_code.*
       FROM ica_sic_code
          JOIN ica_fac
            ON ica_sic_code.ica_fac_id = ica_fac.ica_fac_id
       WHERE ica_fac.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirFacilitySubmission');

-- /ICA_FAC/ICA_UNIVERSE_IND
INSERT INTO ica_flow_icis.dbo.ica_universe_ind
     SELECT ica_universe_ind.*
       FROM ica_universe_ind
          JOIN ica_fac
            ON ica_universe_ind.ica_fac_id = ica_fac.ica_fac_id
       WHERE ica_fac.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirFacilitySubmission');


-- Remove any old records for ica_poluts
-- /ICA_POLUTS/ICA_POLUT_DA_CLASS
DELETE
  FROM ica_flow_icis.dbo.ica_polut_da_class
 WHERE ica_polut_da_class.ica_poluts_id IN
          (SELECT ica_poluts.ica_poluts_id
             FROM ica_flow_icis.dbo.ica_poluts
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_poluts.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirPollutantsSubmission')
);
-- /ICA_POLUTS/ICA_POLUT_EPA_CLASS
DELETE
  FROM ica_flow_icis.dbo.ica_polut_epa_class
 WHERE ica_polut_epa_class.ica_poluts_id IN
          (SELECT ica_poluts.ica_poluts_id
             FROM ica_flow_icis.dbo.ica_poluts
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_poluts.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirPollutantsSubmission')
);
-- /ICA_POLUTS
DELETE
  FROM ica_flow_icis.dbo.ica_poluts
 WHERE ica_poluts.ica_poluts_id IN
          (SELECT ica_poluts.ica_poluts_id
             FROM ica_flow_icis.dbo.ica_poluts
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_poluts.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirPollutantsSubmission')
);

-- Add accepted records for ica_poluts
-- /ICA_POLUTS
INSERT INTO ica_flow_icis.dbo.ica_poluts
     SELECT ica_poluts.*
       FROM ica_poluts
       WHERE ica_poluts.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirPollutantsSubmission');

-- /ICA_POLUTS/ICA_POLUT_DA_CLASS
INSERT INTO ica_flow_icis.dbo.ica_polut_da_class
     SELECT ica_polut_da_class.*
       FROM ica_polut_da_class
          JOIN ica_poluts
            ON ica_polut_da_class.ica_poluts_id = ica_poluts.ica_poluts_id
       WHERE ica_poluts.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirPollutantsSubmission');

-- /ICA_POLUTS/ICA_POLUT_EPA_CLASS
INSERT INTO ica_flow_icis.dbo.ica_polut_epa_class
     SELECT ica_polut_epa_class.*
       FROM ica_polut_epa_class
          JOIN ica_poluts
            ON ica_polut_epa_class.ica_poluts_id = ica_poluts.ica_poluts_id
       WHERE ica_poluts.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirPollutantsSubmission');


-- Remove any old records for ica_progs
-- /ICA_PROGS/ICA_PROG_SUBPART
DELETE
  FROM ica_flow_icis.dbo.ica_prog_subpart
 WHERE ica_prog_subpart.ica_progs_id IN
          (SELECT ica_progs.ica_progs_id
             FROM ica_flow_icis.dbo.ica_progs
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_progs.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirProgramsSubmission')
);
-- /ICA_PROGS
DELETE
  FROM ica_flow_icis.dbo.ica_progs
 WHERE ica_progs.ica_progs_id IN
          (SELECT ica_progs.ica_progs_id
             FROM ica_flow_icis.dbo.ica_progs
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_progs.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirProgramsSubmission')
);

-- Add accepted records for ica_progs
-- /ICA_PROGS
INSERT INTO ica_flow_icis.dbo.ica_progs
     SELECT ica_progs.*
       FROM ica_progs
       WHERE ica_progs.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirProgramsSubmission');

-- /ICA_PROGS/ICA_PROG_SUBPART
INSERT INTO ica_flow_icis.dbo.ica_prog_subpart
     SELECT ica_prog_subpart.*
       FROM ica_prog_subpart
          JOIN ica_progs
            ON ica_prog_subpart.ica_progs_id = ica_progs.ica_progs_id
       WHERE ica_progs.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirProgramsSubmission');


-- Remove any old records for ica_tvacc
-- /ICA_TVACC/ICA_CNTCT/ICA_TELEPH
DELETE
  FROM ica_flow_icis.dbo.ica_teleph
 WHERE ica_teleph.ica_cntct_id IN
          (SELECT ica_cntct.ica_cntct_id
             FROM ica_flow_icis.dbo.ica_tvacc
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_tvacc.key_hash 
                  JOIN ica_flow_icis.dbo.ica_cntct ON ica_cntct.ica_tvacc_id = ica_tvacc.ica_tvacc_id
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirTVACCSubmission')
);
-- /ICA_TVACC/ICA_CNTCT
DELETE
  FROM ica_flow_icis.dbo.ica_cntct
 WHERE ica_cntct.ica_tvacc_id IN
          (SELECT ica_tvacc.ica_tvacc_id
             FROM ica_flow_icis.dbo.ica_tvacc
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_tvacc.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirTVACCSubmission')
);
-- /ICA_TVACC/ICA_INSP_CMNT_TXT
DELETE
  FROM ica_flow_icis.dbo.ica_insp_cmnt_txt
 WHERE ica_insp_cmnt_txt.ica_tvacc_id IN
          (SELECT ica_tvacc.ica_tvacc_id
             FROM ica_flow_icis.dbo.ica_tvacc
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_tvacc.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirTVACCSubmission')
);
-- /ICA_TVACC/ICA_INSP_GOV_CNTCT
DELETE
  FROM ica_flow_icis.dbo.ica_insp_gov_cntct
 WHERE ica_insp_gov_cntct.ica_tvacc_id IN
          (SELECT ica_tvacc.ica_tvacc_id
             FROM ica_flow_icis.dbo.ica_tvacc
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_tvacc.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirTVACCSubmission')
);
-- /ICA_TVACC/ICA_NAT_PRIO
DELETE
  FROM ica_flow_icis.dbo.ica_nat_prio
 WHERE ica_nat_prio.ica_tvacc_id IN
          (SELECT ica_tvacc.ica_tvacc_id
             FROM ica_flow_icis.dbo.ica_tvacc
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_tvacc.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirTVACCSubmission')
);
-- /ICA_TVACC/ICA_POLUT
DELETE
  FROM ica_flow_icis.dbo.ica_polut
 WHERE ica_polut.ica_tvacc_id IN
          (SELECT ica_tvacc.ica_tvacc_id
             FROM ica_flow_icis.dbo.ica_tvacc
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_tvacc.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirTVACCSubmission')
);
-- /ICA_TVACC/ICA_PROG
DELETE
  FROM ica_flow_icis.dbo.ica_prog
 WHERE ica_prog.ica_tvacc_id IN
          (SELECT ica_tvacc.ica_tvacc_id
             FROM ica_flow_icis.dbo.ica_tvacc
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_tvacc.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirTVACCSubmission')
);
-- /ICA_TVACC/ICA_RGNL_PRIO
DELETE
  FROM ica_flow_icis.dbo.ica_rgnl_prio
 WHERE ica_rgnl_prio.ica_tvacc_id IN
          (SELECT ica_tvacc.ica_tvacc_id
             FROM ica_flow_icis.dbo.ica_tvacc
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_tvacc.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirTVACCSubmission')
);
-- /ICA_TVACC/ICA_SENS_CMNT_TXT
DELETE
  FROM ica_flow_icis.dbo.ica_sens_cmnt_txt
 WHERE ica_sens_cmnt_txt.ica_tvacc_id IN
          (SELECT ica_tvacc.ica_tvacc_id
             FROM ica_flow_icis.dbo.ica_tvacc
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_tvacc.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirTVACCSubmission')
);
-- /ICA_TVACC/ICA_TVACC_REVIEW
DELETE
  FROM ica_flow_icis.dbo.ica_tvacc_review
 WHERE ica_tvacc_review.ica_tvacc_id IN
          (SELECT ica_tvacc.ica_tvacc_id
             FROM ica_flow_icis.dbo.ica_tvacc
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_tvacc.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirTVACCSubmission')
);
-- /ICA_TVACC
DELETE
  FROM ica_flow_icis.dbo.ica_tvacc
 WHERE ica_tvacc.ica_tvacc_id IN
          (SELECT ica_tvacc.ica_tvacc_id
             FROM ica_flow_icis.dbo.ica_tvacc
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_tvacc.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirTVACCSubmission')
);

-- Add accepted records for ica_tvacc
-- /ICA_TVACC
INSERT INTO ica_flow_icis.dbo.ica_tvacc
     SELECT ica_tvacc.*
       FROM ica_tvacc
       WHERE ica_tvacc.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirTVACCSubmission');

-- /ICA_TVACC/ICA_CNTCT
INSERT INTO ica_flow_icis.dbo.ica_cntct
     SELECT ica_cntct.*
       FROM ica_cntct
          JOIN ica_tvacc
            ON ica_cntct.ica_tvacc_id = ica_tvacc.ica_tvacc_id
       WHERE ica_tvacc.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirTVACCSubmission');

-- /ICA_TVACC/ICA_CNTCT/ICA_TELEPH
INSERT INTO ica_flow_icis.dbo.ica_teleph
     SELECT ica_teleph.*
       FROM ica_teleph
          JOIN ica_cntct
            ON ica_teleph.ica_cntct_id = ica_cntct.ica_cntct_id
          JOIN ica_tvacc
            ON ica_cntct.ica_tvacc_id = ica_tvacc.ica_tvacc_id
       WHERE ica_tvacc.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirTVACCSubmission');

-- /ICA_TVACC/ICA_INSP_CMNT_TXT
INSERT INTO ica_flow_icis.dbo.ica_insp_cmnt_txt
     SELECT ica_insp_cmnt_txt.*
       FROM ica_insp_cmnt_txt
          JOIN ica_tvacc
            ON ica_insp_cmnt_txt.ica_tvacc_id = ica_tvacc.ica_tvacc_id
       WHERE ica_tvacc.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirTVACCSubmission');

-- /ICA_TVACC/ICA_INSP_GOV_CNTCT
INSERT INTO ica_flow_icis.dbo.ica_insp_gov_cntct
     SELECT ica_insp_gov_cntct.*
       FROM ica_insp_gov_cntct
          JOIN ica_tvacc
            ON ica_insp_gov_cntct.ica_tvacc_id = ica_tvacc.ica_tvacc_id
       WHERE ica_tvacc.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirTVACCSubmission');

-- /ICA_TVACC/ICA_NAT_PRIO
INSERT INTO ica_flow_icis.dbo.ica_nat_prio
     SELECT ica_nat_prio.*
       FROM ica_nat_prio
          JOIN ica_tvacc
            ON ica_nat_prio.ica_tvacc_id = ica_tvacc.ica_tvacc_id
       WHERE ica_tvacc.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirTVACCSubmission');

-- /ICA_TVACC/ICA_POLUT
INSERT INTO ica_flow_icis.dbo.ica_polut
     SELECT ica_polut.*
       FROM ica_polut
          JOIN ica_tvacc
            ON ica_polut.ica_tvacc_id = ica_tvacc.ica_tvacc_id
       WHERE ica_tvacc.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirTVACCSubmission');

-- /ICA_TVACC/ICA_PROG
INSERT INTO ica_flow_icis.dbo.ica_prog
     SELECT ica_prog.*
       FROM ica_prog
          JOIN ica_tvacc
            ON ica_prog.ica_tvacc_id = ica_tvacc.ica_tvacc_id
       WHERE ica_tvacc.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirTVACCSubmission');

-- /ICA_TVACC/ICA_RGNL_PRIO
INSERT INTO ica_flow_icis.dbo.ica_rgnl_prio
     SELECT ica_rgnl_prio.*
       FROM ica_rgnl_prio
          JOIN ica_tvacc
            ON ica_rgnl_prio.ica_tvacc_id = ica_tvacc.ica_tvacc_id
       WHERE ica_tvacc.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirTVACCSubmission');

-- /ICA_TVACC/ICA_SENS_CMNT_TXT
INSERT INTO ica_flow_icis.dbo.ica_sens_cmnt_txt
     SELECT ica_sens_cmnt_txt.*
       FROM ica_sens_cmnt_txt
          JOIN ica_tvacc
            ON ica_sens_cmnt_txt.ica_tvacc_id = ica_tvacc.ica_tvacc_id
       WHERE ica_tvacc.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirTVACCSubmission');

-- /ICA_TVACC/ICA_TVACC_REVIEW
INSERT INTO ica_flow_icis.dbo.ica_tvacc_review
     SELECT ica_tvacc_review.*
       FROM ica_tvacc_review
          JOIN ica_tvacc
            ON ica_tvacc_review.ica_tvacc_id = ica_tvacc.ica_tvacc_id
       WHERE ica_tvacc.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirTVACCSubmission');


-- Remove any old records for ica_da_case_file
-- /ICA_DA_CASE_FILE/ICA_CASE_FILE_CMNT_TXT
DELETE
  FROM ica_flow_icis.dbo.ica_case_file_cmnt_txt
 WHERE ica_case_file_cmnt_txt.ica_da_case_file_id IN
          (SELECT ica_da_case_file.ica_da_case_file_id
             FROM ica_flow_icis.dbo.ica_da_case_file
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_case_file.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDACaseFileSubmission')
);
-- /ICA_DA_CASE_FILE/ICA_OTHR_PATHWAY_ACTY
DELETE
  FROM ica_flow_icis.dbo.ica_othr_pathway_acty
 WHERE ica_othr_pathway_acty.ica_da_case_file_id IN
          (SELECT ica_da_case_file.ica_da_case_file_id
             FROM ica_flow_icis.dbo.ica_da_case_file
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_case_file.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDACaseFileSubmission')
);
-- /ICA_DA_CASE_FILE/ICA_POLUT
DELETE
  FROM ica_flow_icis.dbo.ica_polut
 WHERE ica_polut.ica_da_case_file_id IN
          (SELECT ica_da_case_file.ica_da_case_file_id
             FROM ica_flow_icis.dbo.ica_da_case_file
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_case_file.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDACaseFileSubmission')
);
-- /ICA_DA_CASE_FILE/ICA_PROG
DELETE
  FROM ica_flow_icis.dbo.ica_prog
 WHERE ica_prog.ica_da_case_file_id IN
          (SELECT ica_da_case_file.ica_da_case_file_id
             FROM ica_flow_icis.dbo.ica_da_case_file
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_case_file.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDACaseFileSubmission')
);
-- /ICA_DA_CASE_FILE/ICA_SENS_CMNT_TXT
DELETE
  FROM ica_flow_icis.dbo.ica_sens_cmnt_txt
 WHERE ica_sens_cmnt_txt.ica_da_case_file_id IN
          (SELECT ica_da_case_file.ica_da_case_file_id
             FROM ica_flow_icis.dbo.ica_da_case_file
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_case_file.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDACaseFileSubmission')
);
-- /ICA_DA_CASE_FILE/ICA_VIOL
DELETE
  FROM ica_flow_icis.dbo.ica_viol
 WHERE ica_viol.ica_da_case_file_id IN
          (SELECT ica_da_case_file.ica_da_case_file_id
             FROM ica_flow_icis.dbo.ica_da_case_file
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_case_file.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDACaseFileSubmission')
);
-- /ICA_DA_CASE_FILE
DELETE
  FROM ica_flow_icis.dbo.ica_da_case_file
 WHERE ica_da_case_file.ica_da_case_file_id IN
          (SELECT ica_da_case_file.ica_da_case_file_id
             FROM ica_flow_icis.dbo.ica_da_case_file
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_case_file.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDACaseFileSubmission')
);

-- Add accepted records for ica_da_case_file
-- /ICA_DA_CASE_FILE
INSERT INTO ica_flow_icis.dbo.ica_da_case_file
     SELECT ica_da_case_file.*
       FROM ica_da_case_file
       WHERE ica_da_case_file.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDACaseFileSubmission');

-- /ICA_DA_CASE_FILE/ICA_CASE_FILE_CMNT_TXT
INSERT INTO ica_flow_icis.dbo.ica_case_file_cmnt_txt
     SELECT ica_case_file_cmnt_txt.*
       FROM ica_case_file_cmnt_txt
          JOIN ica_da_case_file
            ON ica_case_file_cmnt_txt.ica_da_case_file_id = ica_da_case_file.ica_da_case_file_id
       WHERE ica_da_case_file.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDACaseFileSubmission');

-- /ICA_DA_CASE_FILE/ICA_OTHR_PATHWAY_ACTY
INSERT INTO ica_flow_icis.dbo.ica_othr_pathway_acty
     SELECT ica_othr_pathway_acty.*
       FROM ica_othr_pathway_acty
          JOIN ica_da_case_file
            ON ica_othr_pathway_acty.ica_da_case_file_id = ica_da_case_file.ica_da_case_file_id
       WHERE ica_da_case_file.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDACaseFileSubmission');

-- /ICA_DA_CASE_FILE/ICA_POLUT
INSERT INTO ica_flow_icis.dbo.ica_polut
     SELECT ica_polut.*
       FROM ica_polut
          JOIN ica_da_case_file
            ON ica_polut.ica_da_case_file_id = ica_da_case_file.ica_da_case_file_id
       WHERE ica_da_case_file.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDACaseFileSubmission');

-- /ICA_DA_CASE_FILE/ICA_PROG
INSERT INTO ica_flow_icis.dbo.ica_prog
     SELECT ica_prog.*
       FROM ica_prog
          JOIN ica_da_case_file
            ON ica_prog.ica_da_case_file_id = ica_da_case_file.ica_da_case_file_id
       WHERE ica_da_case_file.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDACaseFileSubmission');

-- /ICA_DA_CASE_FILE/ICA_SENS_CMNT_TXT
INSERT INTO ica_flow_icis.dbo.ica_sens_cmnt_txt
     SELECT ica_sens_cmnt_txt.*
       FROM ica_sens_cmnt_txt
          JOIN ica_da_case_file
            ON ica_sens_cmnt_txt.ica_da_case_file_id = ica_da_case_file.ica_da_case_file_id
       WHERE ica_da_case_file.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDACaseFileSubmission');

-- /ICA_DA_CASE_FILE/ICA_VIOL
INSERT INTO ica_flow_icis.dbo.ica_viol
     SELECT ica_viol.*
       FROM ica_viol
          JOIN ica_da_case_file
            ON ica_viol.ica_da_case_file_id = ica_da_case_file.ica_da_case_file_id
       WHERE ica_da_case_file.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDACaseFileSubmission');


-- Remove any old records for ica_da_enfrc_actn_lnk
-- /ICA_DA_ENFRC_ACTN_LNK/ICA_LNK_DA_ENFRC_ACTN
DELETE
  FROM ica_flow_icis.dbo.ica_lnk_da_enfrc_actn
 WHERE ica_lnk_da_enfrc_actn.ica_da_enfrc_actn_lnk_id IN
          (SELECT ica_da_enfrc_actn_lnk.ica_da_enfrc_actn_lnk_id
             FROM ica_flow_icis.dbo.ica_da_enfrc_actn_lnk
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_enfrc_actn_lnk.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAEnforcementActionLinkageSubmission')
);
-- /ICA_DA_ENFRC_ACTN_LNK
DELETE
  FROM ica_flow_icis.dbo.ica_da_enfrc_actn_lnk
 WHERE ica_da_enfrc_actn_lnk.ica_da_enfrc_actn_lnk_id IN
          (SELECT ica_da_enfrc_actn_lnk.ica_da_enfrc_actn_lnk_id
             FROM ica_flow_icis.dbo.ica_da_enfrc_actn_lnk
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_da_enfrc_actn_lnk.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'AirDAEnforcementActionLinkageSubmission')
);

-- Add accepted records for ica_da_enfrc_actn_lnk
-- /ICA_DA_ENFRC_ACTN_LNK
INSERT INTO ica_flow_icis.dbo.ica_da_enfrc_actn_lnk
     SELECT ica_da_enfrc_actn_lnk.*
       FROM ica_da_enfrc_actn_lnk
       WHERE ica_da_enfrc_actn_lnk.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAEnforcementActionLinkageSubmission');

-- /ICA_DA_ENFRC_ACTN_LNK/ICA_LNK_DA_ENFRC_ACTN
INSERT INTO ica_flow_icis.dbo.ica_lnk_da_enfrc_actn
     SELECT ica_lnk_da_enfrc_actn.*
       FROM ica_lnk_da_enfrc_actn
          JOIN ica_da_enfrc_actn_lnk
            ON ica_lnk_da_enfrc_actn.ica_da_enfrc_actn_lnk_id = ica_da_enfrc_actn_lnk.ica_da_enfrc_actn_lnk_id
       WHERE ica_da_enfrc_actn_lnk.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'AirDAEnforcementActionLinkageSubmission');


-- Remove any old records for ica_case_file_lnk
-- /ICA_CASE_FILE_LNK/ICA_LNK_CASE_FILE
DELETE
  FROM ica_flow_icis.dbo.ica_lnk_case_file
 WHERE ica_lnk_case_file.ica_case_file_lnk_id IN
          (SELECT ica_case_file_lnk.ica_case_file_lnk_id
             FROM ica_flow_icis.dbo.ica_case_file_lnk
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_case_file_lnk.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CaseFileLinkageSubmission')
);
-- /ICA_CASE_FILE_LNK/ICA_LNK_CMPL_MON
DELETE
  FROM ica_flow_icis.dbo.ica_lnk_cmpl_mon
 WHERE ica_lnk_cmpl_mon.ica_case_file_lnk_id IN
          (SELECT ica_case_file_lnk.ica_case_file_lnk_id
             FROM ica_flow_icis.dbo.ica_case_file_lnk
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_case_file_lnk.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CaseFileLinkageSubmission')
);
-- /ICA_CASE_FILE_LNK/ICA_LNK_DA_ENFRC_ACTN
DELETE
  FROM ica_flow_icis.dbo.ica_lnk_da_enfrc_actn
 WHERE ica_lnk_da_enfrc_actn.ica_case_file_lnk_id IN
          (SELECT ica_case_file_lnk.ica_case_file_lnk_id
             FROM ica_flow_icis.dbo.ica_case_file_lnk
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_case_file_lnk.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CaseFileLinkageSubmission')
);
-- /ICA_CASE_FILE_LNK
DELETE
  FROM ica_flow_icis.dbo.ica_case_file_lnk
 WHERE ica_case_file_lnk.ica_case_file_lnk_id IN
          (SELECT ica_case_file_lnk.ica_case_file_lnk_id
             FROM ica_flow_icis.dbo.ica_case_file_lnk
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_case_file_lnk.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CaseFileLinkageSubmission')
);

-- Add accepted records for ica_case_file_lnk
-- /ICA_CASE_FILE_LNK
INSERT INTO ica_flow_icis.dbo.ica_case_file_lnk
     SELECT ica_case_file_lnk.*
       FROM ica_case_file_lnk
       WHERE ica_case_file_lnk.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CaseFileLinkageSubmission');

-- /ICA_CASE_FILE_LNK/ICA_LNK_CASE_FILE
INSERT INTO ica_flow_icis.dbo.ica_lnk_case_file
     SELECT ica_lnk_case_file.*
       FROM ica_lnk_case_file
          JOIN ica_case_file_lnk
            ON ica_lnk_case_file.ica_case_file_lnk_id = ica_case_file_lnk.ica_case_file_lnk_id
       WHERE ica_case_file_lnk.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CaseFileLinkageSubmission');

-- /ICA_CASE_FILE_LNK/ICA_LNK_CMPL_MON
INSERT INTO ica_flow_icis.dbo.ica_lnk_cmpl_mon
     SELECT ica_lnk_cmpl_mon.*
       FROM ica_lnk_cmpl_mon
          JOIN ica_case_file_lnk
            ON ica_lnk_cmpl_mon.ica_case_file_lnk_id = ica_case_file_lnk.ica_case_file_lnk_id
       WHERE ica_case_file_lnk.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CaseFileLinkageSubmission');

-- /ICA_CASE_FILE_LNK/ICA_LNK_DA_ENFRC_ACTN
INSERT INTO ica_flow_icis.dbo.ica_lnk_da_enfrc_actn
     SELECT ica_lnk_da_enfrc_actn.*
       FROM ica_lnk_da_enfrc_actn
          JOIN ica_case_file_lnk
            ON ica_lnk_da_enfrc_actn.ica_case_file_lnk_id = ica_case_file_lnk.ica_case_file_lnk_id
       WHERE ica_case_file_lnk.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CaseFileLinkageSubmission');


-- Remove any old records for ica_cmpl_mon_lnk
-- /ICA_CMPL_MON_LNK/ICA_LNK_CMPL_MON
DELETE
  FROM ica_flow_icis.dbo.ica_lnk_cmpl_mon
 WHERE ica_lnk_cmpl_mon.ica_cmpl_mon_lnk_id IN
          (SELECT ica_cmpl_mon_lnk.ica_cmpl_mon_lnk_id
             FROM ica_flow_icis.dbo.ica_cmpl_mon_lnk
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_cmpl_mon_lnk.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringLinkageSubmission')
);
-- /ICA_CMPL_MON_LNK/ICA_LNK_DA_ENFRC_ACTN
DELETE
  FROM ica_flow_icis.dbo.ica_lnk_da_enfrc_actn
 WHERE ica_lnk_da_enfrc_actn.ica_cmpl_mon_lnk_id IN
          (SELECT ica_cmpl_mon_lnk.ica_cmpl_mon_lnk_id
             FROM ica_flow_icis.dbo.ica_cmpl_mon_lnk
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_cmpl_mon_lnk.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringLinkageSubmission')
);
-- /ICA_CMPL_MON_LNK
DELETE
  FROM ica_flow_icis.dbo.ica_cmpl_mon_lnk
 WHERE ica_cmpl_mon_lnk.ica_cmpl_mon_lnk_id IN
          (SELECT ica_cmpl_mon_lnk.ica_cmpl_mon_lnk_id
             FROM ica_flow_icis.dbo.ica_cmpl_mon_lnk
                 LEFT JOIN ica_subm_rslts ON ica_subm_rslts.key_hash = ica_cmpl_mon_lnk.key_hash 
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringLinkageSubmission')
);

-- Add accepted records for ica_cmpl_mon_lnk
-- /ICA_CMPL_MON_LNK
INSERT INTO ica_flow_icis.dbo.ica_cmpl_mon_lnk
     SELECT ica_cmpl_mon_lnk.*
       FROM ica_cmpl_mon_lnk
       WHERE ica_cmpl_mon_lnk.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringLinkageSubmission');

-- /ICA_CMPL_MON_LNK/ICA_LNK_CMPL_MON
INSERT INTO ica_flow_icis.dbo.ica_lnk_cmpl_mon
     SELECT ica_lnk_cmpl_mon.*
       FROM ica_lnk_cmpl_mon
          JOIN ica_cmpl_mon_lnk
            ON ica_lnk_cmpl_mon.ica_cmpl_mon_lnk_id = ica_cmpl_mon_lnk.ica_cmpl_mon_lnk_id
       WHERE ica_cmpl_mon_lnk.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringLinkageSubmission');

-- /ICA_CMPL_MON_LNK/ICA_LNK_DA_ENFRC_ACTN
INSERT INTO ica_flow_icis.dbo.ica_lnk_da_enfrc_actn
     SELECT ica_lnk_da_enfrc_actn.*
       FROM ica_lnk_da_enfrc_actn
          JOIN ica_cmpl_mon_lnk
            ON ica_lnk_da_enfrc_actn.ica_cmpl_mon_lnk_id = ica_cmpl_mon_lnk.ica_cmpl_mon_lnk_id
       WHERE ica_cmpl_mon_lnk.transaction_type NOT IN ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ica_subm_rslts
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringLinkageSubmission');



----Step 4: Copy business keys where ICIS returnes error that key is already present in ICIS

--  -- Add keys that already exist in ICIS for module ica_basic_prmt
--  INSERT INTO ica_flow_icis.dbo.ica_basic_prmt (ica_payload_id, ica_basic_prmt_id, prmt_ident, key_hash, data_hash)
--       SELECT (SELECT ica_payload_id FROM ica_payload WHERE operation='BasicPermitSubmission') as payload_id, NEWID(), prmt_ident, key_hash, '0' as data_hash
--         FROM ica_subm_rslts
--        WHERE result_code = 'BP060'
--          AND subm_type_name = 'BasicPermitSubmission'
--          AND subm_transaction_id = @p_transaction_id
--          AND key_hash NOT IN (SELECT key_hash FROM ica_flow_icis.dbo.ica_basic_prmt)
--     GROUP BY prmt_ident, key_hash;

--  -- Add keys that already exist in ICIS for module ica_bs_prmt
--  INSERT INTO ica_flow_icis.dbo.ica_bs_prmt (ica_payload_id, ica_bs_prmt_id, prmt_ident, key_hash, data_hash)
--       SELECT (SELECT ica_payload_id FROM ica_payload WHERE operation='BiosolidsPermitSubmission') as payload_id, NEWID(), prmt_ident, key_hash, '0' as data_hash
--         FROM ica_subm_rslts
--        WHERE result_code = 'PC040'
--          AND subm_type_name = 'BiosolidsPermitSubmission'
--          AND subm_transaction_id = @p_transaction_id
--          AND key_hash NOT IN (SELECT key_hash FROM ica_flow_icis.dbo.ica_bs_prmt)
--     GROUP BY prmt_ident, key_hash;

--  -- Add keys that already exist in ICIS for module ica_cafo_prmt
--  INSERT INTO ica_flow_icis.dbo.ica_cafo_prmt (ica_payload_id, ica_cafo_prmt_id, prmt_ident, key_hash, data_hash)
--       SELECT (SELECT ica_payload_id FROM ica_payload WHERE operation='CAFOPermitSubmission') as payload_id, NEWID(), prmt_ident, key_hash, '0' as data_hash
--         FROM ica_subm_rslts
--        WHERE result_code = 'PC040'
--          AND subm_type_name = 'CAFOPermitSubmission'
--          AND subm_transaction_id = @p_transaction_id
--          AND key_hash NOT IN (SELECT key_hash FROM ica_flow_icis.dbo.ica_cafo_prmt)
--     GROUP BY prmt_ident, key_hash;

--  -- Add keys that already exist in ICIS for module ica_cso_prmt
--  INSERT INTO ica_flow_icis.dbo.ica_cso_prmt (ica_payload_id, ica_cso_prmt_id, prmt_ident, key_hash, data_hash)
--       SELECT (SELECT ica_payload_id FROM ica_payload WHERE operation='CSOPermitSubmission') as payload_id, NEWID(), prmt_ident, key_hash, '0' as data_hash
--         FROM ica_subm_rslts
--        WHERE result_code = 'PC040'
--          AND subm_type_name = 'CSOPermitSubmission'
--          AND subm_transaction_id = @p_transaction_id
--          AND key_hash NOT IN (SELECT key_hash FROM ica_flow_icis.dbo.ica_cso_prmt)
--     GROUP BY prmt_ident, key_hash;

--  -- Add keys that already exist in ICIS for module ica_gnrl_prmt
--  INSERT INTO ica_flow_icis.dbo.ica_gnrl_prmt (ica_payload_id, ica_gnrl_prmt_id, prmt_ident, key_hash, data_hash)
--       SELECT (SELECT ica_payload_id FROM ica_payload WHERE operation='GeneralPermitSubmission') as payload_id, NEWID(), prmt_ident, key_hash, '0' as data_hash
--         FROM ica_subm_rslts
--        WHERE result_code = 'BP060'
--          AND subm_type_name = 'GeneralPermitSubmission'
--          AND subm_transaction_id = @p_transaction_id
--          AND key_hash NOT IN (SELECT key_hash FROM ica_flow_icis.dbo.ica_gnrl_prmt)
--     GROUP BY prmt_ident, key_hash;
     
--  -- Add keys that already exist in ICIS for module ica_master_gnrl_prmt
--  INSERT INTO ica_flow_icis.dbo.ica_master_gnrl_prmt (ica_payload_id, ica_master_gnrl_prmt_id, prmt_ident, key_hash, data_hash)
--       SELECT (SELECT ica_payload_id FROM ica_payload WHERE operation='MasterGeneralPermitSubmission') as payload_id, NEWID(), prmt_ident, key_hash, '0' as data_hash
--         FROM ica_subm_rslts
--        WHERE result_code = 'MGP040'
--          AND subm_type_name = 'MasterGeneralPermitSubmission'
--          AND subm_transaction_id = @p_transaction_id
--          AND key_hash NOT IN (SELECT key_hash FROM ica_flow_icis.dbo.ica_master_gnrl_prmt)
--     GROUP BY prmt_ident, key_hash;

--  -- Add keys that already exist in ICIS for module ica_prmt_track_evt
--  INSERT INTO ica_flow_icis.dbo.ica_prmt_track_evt (ica_payload_id, ica_prmt_track_evt_id, prmt_ident,  prmt_track_evt_code,  prmt_track_evt_date, key_hash, data_hash)
--       SELECT (SELECT ica_payload_id FROM ica_payload WHERE operation='PermitTrackingEventSubmission') as payload_id, NEWID(), prmt_ident,  prmt_track_evt_code,  prmt_track_evt_date, key_hash, '0' as data_hash
--         FROM ica_subm_rslts
--        WHERE result_code = 'PTE030'
--          AND subm_type_name = 'PermitTrackingEventSubmission'
--          AND subm_transaction_id = @p_transaction_id
--          AND key_hash NOT IN (SELECT key_hash FROM ica_flow_icis.dbo.ica_prmt_track_evt)
--     GROUP BY prmt_ident,  prmt_track_evt_code,  prmt_track_evt_date, key_hash;

--  -- Add keys that already exist in ICIS for module ica_potw_prmt
--  INSERT INTO ica_flow_icis.dbo.ica_potw_prmt (ica_payload_id, ica_potw_prmt_id, prmt_ident, key_hash, data_hash)
--       SELECT (SELECT ica_payload_id FROM ica_payload WHERE operation='POTWPermitSubmission') as payload_id, NEWID(), prmt_ident, key_hash, '0' as data_hash
--         FROM ica_subm_rslts
--        WHERE result_code = 'PC040'
--          AND subm_type_name = 'POTWPermitSubmission'
--          AND subm_transaction_id = @p_transaction_id
--          AND key_hash NOT IN (SELECT key_hash FROM ica_flow_icis.dbo.ica_potw_prmt)
--     GROUP BY prmt_ident, key_hash;

--  -- Add keys that already exist in ICIS for module ica_pretr_prmt
--  INSERT INTO ica_flow_icis.dbo.ica_pretr_prmt (ica_payload_id, ica_pretr_prmt_id, prmt_ident, key_hash, data_hash)
--       SELECT (SELECT ica_payload_id FROM ica_payload WHERE operation='PretreatmentPermitSubmission') as payload_id, NEWID(), prmt_ident, key_hash, '0' as data_hash
--         FROM ica_subm_rslts
--        WHERE result_code = 'PC040'
--          AND subm_type_name = 'PretreatmentPermitSubmission'
--          AND subm_transaction_id = @p_transaction_id
--          AND key_hash NOT IN (SELECT key_hash FROM ica_flow_icis.dbo.ica_pretr_prmt)
--     GROUP BY prmt_ident, key_hash;

--  -- Add keys that already exist in ICIS for module ica_sw_cnst_prmt
--  INSERT INTO ica_flow_icis.dbo.ica_sw_cnst_prmt (ica_payload_id, ica_sw_cnst_prmt_id, prmt_ident, key_hash, data_hash)
--       SELECT (SELECT ica_payload_id FROM ica_payload WHERE operation='SWConstructionPermitSubmission') as payload_id, NEWID(), prmt_ident, key_hash, '0' as data_hash
--         FROM ica_subm_rslts
--        WHERE result_code = 'PC040'
--          AND subm_type_name = 'SWConstructionPermitSubmission'
--          AND subm_transaction_id = @p_transaction_id
--          AND key_hash NOT IN (SELECT key_hash FROM ica_flow_icis.dbo.ica_sw_cnst_prmt)
--     GROUP BY prmt_ident, key_hash;

--  -- Add keys that already exist in ICIS for module ica_sw_indst_prmt
--  INSERT INTO ica_flow_icis.dbo.ica_sw_indst_prmt (ica_payload_id, ica_sw_indst_prmt_id, prmt_ident, key_hash, data_hash)
--       SELECT (SELECT ica_payload_id FROM ica_payload WHERE operation='SWIndustrialPermitSubmission') as payload_id, NEWID(), prmt_ident, key_hash, '0' as data_hash
--         FROM ica_subm_rslts
--        WHERE result_code = 'PC040'
--          AND subm_type_name = 'SWIndustrialPermitSubmission'
--          AND subm_transaction_id = @p_transaction_id
--          AND key_hash NOT IN (SELECT key_hash FROM ica_flow_icis.dbo.ica_sw_indst_prmt)
--     GROUP BY prmt_ident, key_hash;

--  -- Add keys that already exist in ICIS for module ica_swms_4_large_prmt
--  INSERT INTO ica_flow_icis.dbo.ica_swms_4_large_prmt (ica_payload_id, ica_swms_4_large_prmt_id, prmt_ident, key_hash, data_hash)
--       SELECT (SELECT ica_payload_id FROM ica_payload WHERE operation='SWMS4LargePermitSubmission') as payload_id, NEWID(), prmt_ident, key_hash, '0' as data_hash
--         FROM ica_subm_rslts
--        WHERE result_code = 'PC040'
--          AND subm_type_name = 'SWMS4LargePermitSubmission'
--          AND subm_transaction_id = @p_transaction_id
--          AND key_hash NOT IN (SELECT key_hash FROM ica_flow_icis.dbo.ica_swms_4_large_prmt)
--     GROUP BY prmt_ident, key_hash;

--  -- Add keys that already exist in ICIS for module ica_swms_4_small_prmt
--  INSERT INTO ica_flow_icis.dbo.ica_swms_4_small_prmt (ica_payload_id, ica_swms_4_small_prmt_id, prmt_ident, key_hash, data_hash)
--       SELECT (SELECT ica_payload_id FROM ica_payload WHERE operation='SWMS4SmallPermitSubmission') as payload_id, NEWID(), prmt_ident, key_hash, '0' as data_hash
--         FROM ica_subm_rslts
--        WHERE result_code = 'PC040'
--          AND subm_type_name = 'SWMS4SmallPermitSubmission'
--          AND subm_transaction_id = @p_transaction_id
--          AND key_hash NOT IN (SELECT key_hash FROM ica_flow_icis.dbo.ica_swms_4_small_prmt)
--     GROUP BY prmt_ident, key_hash;

--  -- Add keys that already exist in ICIS for module ica_unprmt_fac
--  INSERT INTO ica_flow_icis.dbo.ica_unprmt_fac (ica_payload_id, ica_unprmt_fac_id, prmt_ident, key_hash, data_hash)
--       SELECT (SELECT ica_payload_id FROM ica_payload WHERE operation='UnpermittedFacilitySubmission') as payload_id, NEWID(), prmt_ident, key_hash, '0' as data_hash
--         FROM ica_subm_rslts
--        WHERE result_code = 'UPF060'
--          AND subm_type_name = 'UnpermittedFacilitySubmission'
--          AND subm_transaction_id = @p_transaction_id
--          AND key_hash NOT IN (SELECT key_hash FROM ica_flow_icis.dbo.ica_unprmt_fac)
--     GROUP BY prmt_ident, key_hash;

--  -- Add keys that already exist in ICIS for module ica_prmt_featr
--  INSERT INTO ica_flow_icis.dbo.ica_prmt_featr (ica_payload_id, ica_prmt_featr_id, prmt_ident,  prmt_featr_ident, key_hash, data_hash)
--       SELECT (SELECT ica_payload_id FROM ica_payload WHERE operation='PermittedFeatureSubmission') as payload_id, NEWID(), prmt_ident,  prmt_featr_ident, key_hash, '0' as data_hash
--         FROM ica_subm_rslts
--        WHERE result_code = 'PF030'
--          AND subm_type_name = 'PermittedFeatureSubmission'
--          AND subm_transaction_id = @p_transaction_id
--          AND key_hash NOT IN (SELECT key_hash FROM ica_flow_icis.dbo.ica_prmt_featr)
--     GROUP BY prmt_ident,  prmt_featr_ident, key_hash;

--  -- Add keys that already exist in ICIS for module ica_lmt_set
--  INSERT INTO ica_flow_icis.dbo.ica_lmt_set (ica_payload_id, ica_lmt_set_id, prmt_ident,  prmt_featr_ident,  lmt_set_designator, LMT_SET_TYPE, key_hash, data_hash)
--       SELECT (SELECT ica_payload_id FROM ica_payload WHERE operation='LimitSetSubmission') as payload_id, NEWID(), prmt_ident,  prmt_featr_ident,  lmt_set_designator, 'S', key_hash, '0' as data_hash
--         FROM ica_subm_rslts
--        WHERE result_code = 'LS060'
--          AND subm_type_name = 'LimitSetSubmission'
--          AND subm_transaction_id = @p_transaction_id
--          AND key_hash NOT IN (SELECT key_hash FROM ica_flow_icis.dbo.ica_lmt_set)
--     GROUP BY prmt_ident,  prmt_featr_ident,  lmt_set_designator, key_hash;

--  -- Add keys that already exist in ICIS for module ica_lmts
--  INSERT INTO ica_flow_icis.dbo.ica_lmts (ica_payload_id, ica_lmts_id, prmt_ident,  prmt_featr_ident,  lmt_set_designator,  param_code,  mon_site_desc_code,  lmt_season_num,  lmt_start_date,  lmt_end_date, key_hash, data_hash)
--       SELECT (SELECT ica_payload_id FROM ica_payload WHERE operation='LimitsSubmission') as payload_id, NEWID(), prmt_ident,  prmt_featr_ident,  lmt_set_designator,  param_code,  mon_site_desc_code,  lmt_season_num,  lmt_start_date,  lmt_end_date, key_hash, '0' as data_hash
--         FROM ica_subm_rslts
--        WHERE result_code = 'LTS050'
--          AND subm_type_name = 'LimitsSubmission'
--          AND subm_transaction_id = @p_transaction_id
--          AND key_hash NOT IN (SELECT key_hash FROM ica_flow_icis.dbo.ica_lmts)
--     GROUP BY prmt_ident,  prmt_featr_ident,  lmt_set_designator,  param_code,  mon_site_desc_code,  lmt_season_num,  lmt_start_date,  lmt_end_date, key_hash;

--  -- Add keys that already exist in ICIS for module ica_cmpl_mon
--  INSERT INTO ica_flow_icis.dbo.ica_cmpl_mon (ica_payload_id, ica_cmpl_mon_id, prmt_ident,  cmpl_mon_catg_code,  cmpl_mon_date, key_hash, data_hash)
--       SELECT (SELECT ica_payload_id FROM ica_payload WHERE operation='ComplianceMonitoringSubmission') as payload_id, NEWID(), prmt_ident,  cmpl_mon_catg_code,  cmpl_mon_date, key_hash, '0' as data_hash
--         FROM ica_subm_rslts
--        WHERE result_code = 'CM030'
--          AND subm_type_name = 'ComplianceMonitoringSubmission'
--          AND subm_transaction_id = @p_transaction_id
--          AND key_hash NOT IN (SELECT key_hash FROM ica_flow_icis.dbo.ica_cmpl_mon)
--     GROUP BY prmt_ident,  cmpl_mon_catg_code,  cmpl_mon_date, key_hash;

--  -- Add keys that already exist in ICIS for module ica_efflu_trade_prtner
--  INSERT INTO ica_flow_icis.dbo.ica_efflu_trade_prtner (ica_payload_id, ica_efflu_trade_prtner_id, prmt_ident,  prmt_featr_ident,  lmt_set_designator,  param_code,  mon_site_desc_code,  lmt_season_num,  lmt_start_date,  lmt_end_date,  lmt_mod_effective_date,  trade_id, key_hash, data_hash)
--       SELECT (SELECT ica_payload_id FROM ica_payload WHERE operation='EffluentTradePartnerSubmission') as payload_id, NEWID(), prmt_ident,  prmt_featr_ident,  lmt_set_designator,  param_code,  mon_site_desc_code,  lmt_season_num,  lmt_start_date,  lmt_end_date,  lmt_mod_effective_date,  trade_id, key_hash, '0' as data_hash
--         FROM ica_subm_rslts
--        WHERE result_code = 'ETP030'
--          AND subm_type_name = 'EffluentTradePartnerSubmission'
--          AND subm_transaction_id = @p_transaction_id
--          AND key_hash NOT IN (SELECT key_hash FROM ica_flow_icis.dbo.ica_efflu_trade_prtner)
--     GROUP BY prmt_ident,  prmt_featr_ident,  lmt_set_designator,  param_code,  mon_site_desc_code,  lmt_season_num,  lmt_start_date,  lmt_end_date,  lmt_mod_effective_date,  trade_id, key_hash;

--  -- Add keys that already exist in ICIS for module ica_frml_enfrc_actn
--  INSERT INTO ica_flow_icis.dbo.ica_frml_enfrc_actn (ica_payload_id, ica_frml_enfrc_actn_id, enfrc_actn_ident, key_hash, data_hash)
--       SELECT (SELECT ica_payload_id FROM ica_payload WHERE operation='FormalEnforcementActionSubmission') as payload_id, NEWID(), enfrc_actn_ident, key_hash, '0' as data_hash
--         FROM ica_subm_rslts
--        WHERE result_code = 'FEA030'
--          AND subm_type_name = 'FormalEnforcementActionSubmission'
--          AND subm_transaction_id = @p_transaction_id
--          AND key_hash NOT IN (SELECT key_hash FROM ica_flow_icis.dbo.ica_frml_enfrc_actn)
--     GROUP BY enfrc_actn_ident, key_hash;

--  -- Add keys that already exist in ICIS for module ica_infrml_enfrc_actn
--  INSERT INTO ica_flow_icis.dbo.ica_infrml_enfrc_actn (ica_payload_id, ica_infrml_enfrc_actn_id, enfrc_actn_ident, key_hash, data_hash)
--       SELECT (SELECT ica_payload_id FROM ica_payload WHERE operation='InformalEnforcementActionSubmission') as payload_id, NEWID(), enfrc_actn_ident, key_hash, '0' as data_hash
--         FROM ica_subm_rslts
--        WHERE result_code IN ('IEA030','FEA030') --added FEA030 because ICIS returns wrong error code in this case 12/27/2012 BRensmith
--          AND subm_type_name = 'InformalEnforcementActionSubmission'
--          AND subm_transaction_id = @p_transaction_id
--          AND key_hash NOT IN (SELECT key_hash FROM ica_flow_icis.dbo.ica_infrml_enfrc_actn)
--     GROUP BY enfrc_actn_ident, key_hash;

--  -- Add keys that already exist in ICIS for module ica_sngl_evt_viol
--  INSERT INTO ica_flow_icis.dbo.ica_sngl_evt_viol (ica_payload_id, ica_sngl_evt_viol_id, prmt_ident,  sngl_evt_viol_code,  sngl_evt_viol_date, key_hash, data_hash)
--       SELECT (SELECT ica_payload_id FROM ica_payload WHERE operation='SingleEventViolationSubmission') as payload_id, NEWID(), prmt_ident,  sngl_evt_viol_code,  sngl_evt_viol_date, key_hash, '0' as data_hash
--         FROM ica_subm_rslts
--        WHERE result_code = 'SEV030'
--          AND subm_type_name = 'SingleEventViolationSubmission'
--          AND subm_transaction_id = @p_transaction_id
--          AND key_hash NOT IN (SELECT key_hash FROM ica_flow_icis.dbo.ica_sngl_evt_viol)
--     GROUP BY prmt_ident,  sngl_evt_viol_code,  sngl_evt_viol_date, key_hash;

--Step 5: Record counts into ICA_SUBM_HIST

--Step 6: Record counts into ICA_SUBM_HIST

INSERT INTO ica_subm_hist (
       ica_subm_hist_id
     , subm_date_time
     , subm_transaction_id
     , subm_type_name
     --, trans_count_new
     , trans_count_chng_repl
     , trans_count_del_mass_del
     , error_count
     , warning_count
     , accepted_count
     , accepted_count_total
     , created_date_time)
SELECT NEWID() AS ica_subm_hist_id
     , subm_date_time
     , subm_transaction_id 
     , subm_type_name
     --, trans_count_new
     , trans_count_chng_repl
     , trans_count_del_mass_del
     , error_count
     , warning_count
     , accepted_count
     , accepted_count_total
     , GETDATE() AS created_date_time
  FROM ica_v_module_count;

GO

