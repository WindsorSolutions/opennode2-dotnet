/*
Copyright (c) 2014, The Environmental Council of the States (ECOS)
All rights reserved.
 
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
 
 * Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
 * Neither the name of the ECOS nor the names of its contributors may
   be used to endorse or promote products derived from this software
   without specific prior written permission.
 
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/

USE [ICA_FLOW_LOCAL]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.vw_ica_poluts_class') AND type = N'V')
DROP VIEW dbo.vw_ica_poluts_class
GO

/*************************************************************************************************
** Object Name: vw_ica_polut_class
**
** Author: Windsor Solutions, Inc.
**
** Description:  This database view supports the Java version of OpenNode2.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/11/2014    Windsor     Created
**
***************************************************************************************************/
CREATE VIEW dbo.vw_ica_poluts_class as
SELECT ica_poluts.*
     , ica_polut_da_class.polut_da_class_code
     , ica_polut_da_class.polut_da_class_start_date
     , ica_polut_epa_class.polut_epa_class_code
     , ica_polut_epa_class.polut_epa_class_start_date
  FROM dbo.ica_poluts
  LEFT JOIN dbo.ica_polut_da_class
    ON ica_polut_da_class.ica_poluts_id = ica_poluts.ica_poluts_id
  LEFT JOIN dbo.ica_polut_epa_class
    ON ica_polut_epa_class.ica_poluts_id = ica_poluts.ica_poluts_id;