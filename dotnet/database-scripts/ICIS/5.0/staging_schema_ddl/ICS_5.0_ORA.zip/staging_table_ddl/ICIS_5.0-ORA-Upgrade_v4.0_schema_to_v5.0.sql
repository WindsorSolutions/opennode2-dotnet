/*
Copyright (c) 2012, The Environmental Council of the States (ECOS)
All rights reserved.
 
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
 
 * Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
 * Neither the name of the ECOS nor the names of its contributors may
   be used to endorse or promote products derived from this software
   without specific prior written permission.
 
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/
/*************************************************************************************************
** ObjectName: ICIS_5.0-ORA-Upgrade_v4.0_schema_to_v5.0.sql
**
** Author: Windsor Solutions, Inc.
**
** Company Name: Windsor Solutions, Inc.
**
** Description:  This script will update an existing ICIS 4.0 database to support the ICIS 5.0
**               exchange.  This script can be run multiple times without issue.
**
** Revision History:
** ------------------------------------------------------------------------------------------------
** Date          Name        Description
** ------------------------------------------------------------------------------------------------
** 09/10/2014    Windsor     Created
** 09/18/2014    Windsor     Added column FEDR_CERCLA_DSCH_IND on database table 
** 09/18/2014    Windsor     Added database table ICS_SUBSCTOR_CODE_PLUS_DESC and related keys,
**                           indexes, etc..
** 10/02/2014    Windsor     Moved the field FEDR_CERCLA_DSCH_IND under notice of intent 
**                           instead of notice of termination.
** 10/03/2014    Windsor     Added CMPL_MON_IDENT and CMPL_MON_IDENT_2 to the ICS_SUBM_RESULTS
**                           database table.
** 10/03/2014    Windsor     Moved the table ICS_SUBSCTOR_CODE_PLUS_DESC to be a child of notice
**                           of intent vs. a child of notice of termination.
** 10/23/2014    BRensmith   Add new CDV_SW_INDST_ANNUL_REP view to script
** 
*************************************************************************************************/


/********************************************************************************************************  
    Script Note:  This anonymous block will drop the index IX_CM_MO_PR_ID_CM_MO_CA_CO_CM from the 
                  database table ICS_CMPL_MON, if it exists, otherwise any alterations will be bypassed.
*********************************************************************************************************/
DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  /*  Check to see if IX_CM_MO_PR_ID_CM_MO_CA_CO_CM exists in the schema  */
  SELECT 1
    INTO v_object_ind
    FROM user_indexes
   WHERE table_name = 'ICS_CMPL_MON'
     AND index_name = 'IX_CM_MO_PR_ID_CM_MO_CA_CO_CM';
   
   
    /* Drop Object:  IX_CM_MO_PR_ID_CM_MO_CA_CO_CM */
    BEGIN
      v_sql_statement := 'DROP INDEX ix_cm_mo_pr_id_cm_mo_ca_co_cm';

          EXECUTE IMMEDIATE v_sql_statement;   
          DBMS_OUTPUT.PUT_LINE( 'The index IX_CM_MO_PR_ID_CM_MO_CA_CO_CM was dropped!');
       
    END;  -- IX_CM_MO_PR_ID_CM_MO_CA_CO_CM
   

EXCEPTION

  WHEN NO_DATA_FOUND THEN  
  
      /* The object does not exist in schema, bypass drop */
      DBMS_OUTPUT.PUT_LINE( 'The index IX_CM_MO_PR_ID_CM_MO_CA_CO_CM has already been dropped, schema alteration bypassed!');

END;  -- IX_CM_MO_PR_ID_CM_MO_CA_CO_CM
/


/********************************************************************************************************  
    Script Note:  This anonymous block will drop the index AK_ICS_CMPL_MON from the 
                  database table ICS_CMPL_MON, if it exists, otherwise any alterations will be bypassed.
*********************************************************************************************************/
DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  /*  Check to see if AK_ICS_CMPL_MON exists in the schema  */
  SELECT 1
    INTO v_object_ind
    FROM all_indexes
   WHERE owner = 'ICS_FLOW_LOCAL'
     AND table_name = 'ICS_CMPL_MON'
     AND index_name = 'AK_ICS_CMPL_MON';
   
   
    /* Drop Object:  AK_ICS_CMPL_MON */
    BEGIN
      v_sql_statement := 'DROP INDEX ak_ics_cmpl_mon';

          EXECUTE IMMEDIATE v_sql_statement;   
          DBMS_OUTPUT.PUT_LINE( 'The index ak_ics_cmpl_mon was dropped!');
       
    END;  -- AK_ICS_CMPL_MON
   

EXCEPTION

  WHEN NO_DATA_FOUND THEN  
  
      /* The object does not exist in schema, bypass drop */
      DBMS_OUTPUT.PUT_LINE( 'The index AK_ICS_CMPL_MON has already been dropped, schema alteration bypassed!');

END;  -- AK_ICS_CMPL_MON
/


/********************************************************************************************************  
    Script Note:  This anonymous block will drop the index IX_CMPL_MON_CMPL_MON_IDENT from the 
                  database table ICS_CMPL_MON, if it exists, otherwise any alterations will be bypassed.
*********************************************************************************************************/
DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  /*  Check to see if IX_CMPL_MON_CMPL_MON_IDENT exists in the schema  */
  SELECT 1
    INTO v_object_ind
    FROM all_indexes
   WHERE owner = 'ICS_FLOW_LOCAL'
     AND table_name = 'ICS_CMPL_MON'
     AND index_name = 'IX_CMPL_MON_CMPL_MON_IDENT';
   
   
    /* Drop Object:  IX_CMPL_MON_CMPL_MON_IDENT */
    BEGIN
      v_sql_statement := 'DROP INDEX ix_cmpl_mon_cmpl_mon_ident';

          EXECUTE IMMEDIATE v_sql_statement;   
          DBMS_OUTPUT.PUT_LINE( 'The index IX_CMPL_MON_CMPL_MON_IDENT was dropped!');
       
    END;  -- IX_CMPL_MON_CMPL_MON_IDENT
   

EXCEPTION

  WHEN NO_DATA_FOUND THEN  
  
      /* The object does not exist in schema, bypass drop */
      DBMS_OUTPUT.PUT_LINE( 'The index IX_CMPL_MON_CMPL_MON_IDENT has already been dropped, schema alteration bypassed!');

END;  -- IX_CMPL_MON_CMPL_MON_IDENT
/


/********************************************************************************************************  
    Script Note:  This anonymous block will create a new column on database table ICS_CMPL_MON called
                  CMPL_MON_IDENT.  This column needs a NULL constraint.  Therefore the column must at
                  first be added allowing NULLs, then some data needs to be populated, then the 
                  NULL constraint can be applied.  This block will check for the existence of the new
                  5.0 database column.  If it does not already exist the schema will be updated.
                  Otherwise any alterations will be bypassed. 
*********************************************************************************************************/
DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  /*  Check to see if CMPL_MON_IDENT column exists on the database table ICS_CMPL_MON  */
   SELECT 1
     INTO v_object_ind
     FROM user_tables
     JOIN user_tab_cols
       ON user_tab_cols.table_name = user_tables.table_name
    WHERE user_tables.table_name = 'ICS_CMPL_MON'
      AND user_tab_cols.column_name = 'CMPL_MON_IDENT';
   
   /* The column already exists in schema, bypass creation */
    DBMS_OUTPUT.PUT_LINE( 'The column CMPL_MON_IDENT already existed on ICS_CMPL_MON, schema alteration bypassed!');

EXCEPTION

  WHEN NO_DATA_FOUND THEN  
  
    BEGIN
       
      --  Added new column (NULLABLE)
      v_sql_statement := 'ALTER TABLE ICS_CMPL_MON ADD (CMPL_MON_IDENT VARCHAR2(25) NULL)';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The column CMPL_MON_IDENT was added to the table ICS_CMPL_MON!');
      
      -- Update new colum with data so that NOT NULL constraint can be applied next;
      v_sql_statement := 'UPDATE ICS_CMPL_MON SET CMPL_MON_IDENT = ''TMP'' || SUBSTR(ICS_CMPL_MON_ID,1,20)';
      EXECUTE IMMEDIATE v_sql_statement;     
      DBMS_OUTPUT.PUT_LINE( 'The column CMPL_MON_IDENT was initialized with data!');
      
      --  Apply NOT NULL constraint on new column
      v_sql_statement := 'ALTER TABLE ICS_CMPL_MON MODIFY (CMPL_MON_IDENT VARCHAR2(25) NOT NULL)';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'A NULL constraint was added on column CMPL_MON_IDENT on table ICS_CMPL_MON!');

      --  Create unique index on CMPL_MON_IDENT      
      v_sql_statement := 'CREATE UNIQUE INDEX IX_CMPL_MON_CMPL_MON_IDENT ON ICS_CMPL_MON(CMPL_MON_IDENT)';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'A unique index IX_CMPL_MON_CMPL_MON_IDENT was added on column CMPL_MON_IDENT on table ICS_CMPL_MON!');
       
     END;  -- CMPL_MON_IDENT

END;
/

COMMENT ON COLUMN "ICS_CMPL_MON"."CMPL_MON_IDENT" IS 'String that represents the compliance monitoring identifier.  Optional'
;

/********************************************************************************************************  
    Script Note:  This anonymous block will drop the NULL constraints on the ICS_CMPL_MON database
                  table if they exists on columns 'PRMT_IDENT','CMPL_MON_CATG_CODE', or'CMPL_MON_DATE'.
*********************************************************************************************************/
DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  FOR tbl_col IN (  SELECT DISTINCT
                           user_tab_cols.table_name
                         , user_tab_cols.column_name
                         , user_tab_cols.data_type
                         ,   CASE WHEN user_tab_cols.data_type = 'DATE'
                               THEN NULL
                               ELSE '(' || user_tab_cols.data_length || ')' 
                             END AS data_length
                      FROM user_tab_cols
                     WHERE table_name = 'ICS_CMPL_MON'
                       AND nullable = 'N'
                       AND column_name IN ('PRMT_IDENT','CMPL_MON_CATG_CODE','CMPL_MON_DATE')) LOOP
                       
                       
      v_sql_statement := 'ALTER TABLE ' ||  tbl_col.table_name || ' MODIFY (' || tbl_col.column_name || ' ' ||  tbl_col.data_type || tbl_col.data_length || ' NULL)';
      --DBMS_OUTPUT.PUT_LINE( 'SQL: ' || v_sql_statement);
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The NULL constraint on ICS_CMPL_MON.' || tbl_col.column_name || ' was dropped!');
     
     
  END LOOP;

END;  -- ICS_CMPL_MON, drop null constraints
/



/********************************************************************************************************  
    Script Note:  This anonymous block will drop the index IX_CM_MO_LN_PR_ID_CM_MO_CA_CO from the 
                  database table ICS_CMPL_MON_LNK, if it exists, otherwise any alterations will be bypassed.
*********************************************************************************************************/
DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  /*  Check to see if IX_CM_MO_LN_PR_ID_CM_MO_CA_CO exists in the schema  */
  SELECT 1
    INTO v_object_ind
    FROM user_indexes
   WHERE table_name = 'ICS_CMPL_MON_LNK'
     AND index_name = 'IX_CM_MO_LN_PR_ID_CM_MO_CA_CO';
   
   
    /* Drop Object:  IX_CM_MO_LN_PR_ID_CM_MO_CA_CO */
    BEGIN
      v_sql_statement := 'DROP INDEX ix_cm_mo_ln_pr_id_cm_mo_ca_co';

          EXECUTE IMMEDIATE v_sql_statement;   
          DBMS_OUTPUT.PUT_LINE( 'The index IX_CM_MO_LN_PR_ID_CM_MO_CA_CO was dropped!');
       
    END;  -- IX_CM_MO_LN_PR_ID_CM_MO_CA_CO
   

EXCEPTION

  WHEN NO_DATA_FOUND THEN  
  
      /* The object does not exist in schema, bypass drop */
      DBMS_OUTPUT.PUT_LINE( 'The index IX_CM_MO_LN_PR_ID_CM_MO_CA_CO has already been dropped, schema alteration bypassed!');

END;  -- IX_CM_MO_LN_PR_ID_CM_MO_CA_CO
/


/********************************************************************************************************  
    Script Note:  This anonymous block will drop the columns 'PRMT_IDENT','CMPL_MON_CATG_CODE'
                  and 'CMPL_MON_DATE' from the database table ICS_CMPL_MON_LNK, if they exist.
*********************************************************************************************************/
DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  FOR tbl_col IN (SELECT DISTINCT
                         user_tab_cols.table_name
                       , user_tab_cols.column_name
                    FROM user_tab_cols
                   WHERE table_name = 'ICS_CMPL_MON_LNK'
                     AND column_name IN ('PRMT_IDENT','CMPL_MON_CATG_CODE','CMPL_MON_DATE')) LOOP
                       
    v_sql_statement := 'ALTER TABLE ' ||  tbl_col.table_name || ' DROP COLUMN ' || tbl_col.column_name;
    --DBMS_OUTPUT.PUT_LINE( 'SQL: ' || v_sql_statement);
    EXECUTE IMMEDIATE v_sql_statement;   
    DBMS_OUTPUT.PUT_LINE( 'The column ' || tbl_col.column_name || ' was dropped from the database table ' || tbl_col.table_name);
    
    v_object_ind := 1;
     
  END LOOP;
  
  IF v_object_ind = 0 THEN
    DBMS_OUTPUT.PUT_LINE('The columns PRMT_IDENT, CMPL_MON_CATG_CODE, CMPL_MON_DATE had already been removed from ICS_CMPL_MON_LNK, schema alteration bypassed');
  END IF;
  
END;  -- ICS_CMPL_MON_LNK:  Drop columns
/


/********************************************************************************************************  
    Script Note:  This anonymous block will create a new column on database table ICS_CMPL_MON_LNK called
                  CMPL_MON_IDENT.  This column needs a NULL constraint.  Therefore the column must at
                  first be added allowing NULLs, then some data needs to be populated, then the 
                  NULL constraint can be applied.  This block will check for the existence of the new
                  5.0 database column.  If it does not already exist the schema will be updated.
                  Otherwise any alterations will be bypassed. 
*********************************************************************************************************/
DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  /*  Check to see if CMPL_MON_IDENT column exists on the database table ICS_CMPL_MON_LNK  */
   SELECT 1
     INTO v_object_ind
     FROM user_tables
     JOIN user_tab_cols
       ON user_tab_cols.table_name = user_tables.table_name
    WHERE user_tables.table_name = 'ICS_CMPL_MON_LNK'
      AND user_tab_cols.column_name = 'CMPL_MON_IDENT';
   
   /* The column already exists in schema, bypass creation */
    DBMS_OUTPUT.PUT_LINE( 'The column CMPL_MON_IDENT already exists on ICS_CMPL_MON_LNK, schema alteration bypassed!');

EXCEPTION

  WHEN NO_DATA_FOUND THEN  
  
    BEGIN
       
      --  Added new column (NULLABLE)
      v_sql_statement := 'ALTER TABLE ICS_CMPL_MON_LNK ADD (CMPL_MON_IDENT VARCHAR2(25) NULL)';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The column CMPL_MON_IDENT was added to the table ICS_CMPL_MON_LNK!');

      --  Create unique index on CMPL_MON_IDENT      
      v_sql_statement := 'CREATE UNIQUE INDEX IX_CMPL_MON_LNK_CMPL_MON_IDENT ON ICS_CMPL_MON_LNK(CMPL_MON_IDENT)';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'A unique index IX_CMPL_MON_LNK_CMPL_MON_IDENT was added on column CMPL_MON_IDENT on table ICS_CMPL_MON_LNK!');
       
     END;  -- CMPL_MON_IDENT

END;
/


/********************************************************************************************************  
    Script Note:  This anonymous block will create a new column on database table ICS_FAC called
                  LOC_ADDR_COUNTY_CODE.  This column needs a NULL constraint.  Therefore the column must at
                  first be added allowing NULLs, then some data needs to be populated, then the 
                  NULL constraint can be applied.  This block will check for the existence of the new
                  5.0 database column.  If it does not already exist the schema will be updated.
                  Otherwise any alterations will be bypassed. 
*********************************************************************************************************/
DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  /*  Check to see if LOC_ADDR_COUNTY_CODE column exists on the database table ICS_FAC  */
   SELECT 1
     INTO v_object_ind
     FROM user_tables
     JOIN user_tab_cols
       ON user_tab_cols.table_name = user_tables.table_name
    WHERE user_tables.table_name = 'ICS_FAC'
      AND user_tab_cols.column_name = 'LOC_ADDR_COUNTY_CODE';
   
   /* The column already exists in schema, bypass creation */
    DBMS_OUTPUT.PUT_LINE( 'The column LOC_ADDR_COUNTY_CODE already exists on ICS_FAC, schema alteration bypassed!');

EXCEPTION

  WHEN NO_DATA_FOUND THEN  
  
    BEGIN
       
      --  Added new column (NULLABLE)
      v_sql_statement := 'ALTER TABLE ICS_FAC ADD (LOC_ADDR_COUNTY_CODE VARCHAR2(5) NULL)';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The column LOC_ADDR_COUNTY_CODE was added to the table ICS_FAC!');
       
     END;  -- LOC_ADDR_COUNTY_CODE

END;
/

COMMENT ON COLUMN ICS_FAC.LOC_ADDR_COUNTY_CODE IS 'The code that represents the county code.';



/********************************************************************************************************  
    Script Note:  This anonymous block will create a new column on database table ICS_FAC called
                  LOC_ADDR_CITY_CODE.  This column needs a NULL constraint.  Therefore the column must at
                  first be added allowing NULLs, then some data needs to be populated, then the 
                  NULL constraint can be applied.  This block will check for the existence of the new
                  5.0 database column.  If it does not already exist the schema will be updated.
                  Otherwise any alterations will be bypassed. 
*********************************************************************************************************/
DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  /*  Check to see if LOC_ADDR_CITY_CODE column exists on the database table ICS_FAC  */
   SELECT 1
     INTO v_object_ind
     FROM user_tables
     JOIN user_tab_cols
       ON user_tab_cols.table_name = user_tables.table_name
    WHERE user_tables.table_name = 'ICS_FAC'
      AND user_tab_cols.column_name = 'LOC_ADDR_CITY_CODE';
   
   /* The column already exists in schema, bypass creation */
    DBMS_OUTPUT.PUT_LINE( 'The column LOC_ADDR_CITY_CODE already exists on ICS_FAC, schema alteration bypassed!');

EXCEPTION

  WHEN NO_DATA_FOUND THEN  
  
    BEGIN
       
      --  Added new column (NULLABLE)
      v_sql_statement := 'ALTER TABLE ICS_FAC ADD (LOC_ADDR_CITY_CODE VARCHAR2(12) NULL)';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The column LOC_ADDR_CITY_CODE was added to the table ICS_FAC!');
       
     END;  -- LOC_ADDR_CITY_CODE

END;
/

COMMENT ON COLUMN ICS_FAC.LOC_ADDR_CITY_CODE IS 'The code that represents the city code.';

/********************************************************************************************************  
    Script Note:  This anonymous block will drop the column on database table ICS_GPCF_NO_EXPOSURE called
                  INDST_ACTY_SIZE.  
*********************************************************************************************************/
DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  /*  Check to see if INDST_ACTY_SIZE column exists on the database table ICS_GPCF_NO_EXPOSURE  */
   SELECT 1
     INTO v_object_ind
     FROM user_tables
     JOIN user_tab_cols
       ON user_tab_cols.table_name = user_tables.table_name
    WHERE user_tables.table_name = 'ICS_GPCF_NO_EXPOSURE'
      AND user_tab_cols.column_name = 'INDST_ACTY_SIZE';
      
    --  Added new column (NULLABLE)
    v_sql_statement := 'ALTER TABLE ICS_GPCF_NO_EXPOSURE DROP COLUMN INDST_ACTY_SIZE';
    EXECUTE IMMEDIATE v_sql_statement;   
    DBMS_OUTPUT.PUT_LINE( 'The column INDST_ACTY_SIZE was dropped from the table ICS_GPCF_NO_EXPOSURE!');

EXCEPTION

  WHEN NO_DATA_FOUND THEN  
  
    BEGIN
       
   /* The column already exists in schema, bypass creation */
    DBMS_OUTPUT.PUT_LINE( 'The column INDST_ACTY_SIZE does not exist on ICS_GPCF_NO_EXPOSURE, schema alteration bypassed!');
       
     END;  -- INDST_ACTY_SIZE

END;
/


/********************************************************************************************************  
    Script Note:  This anonymous block will create a new column on database table ICS_SW_INDST_PRMT called
                  INDST_ACTY_SIZE.  This column needs a NULL constraint.  Therefore the column must at
                  first be added allowing NULLs, then some data needs to be populated, then the 
                  NULL constraint can be applied.  This block will check for the existence of the new
                  5.0 database column.  If it does not already exist the schema will be updated.
                  Otherwise any alterations will be bypassed. 
*********************************************************************************************************/
DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  /*  Check to see if INDST_ACTY_SIZE column exists on the database table ICS_SW_INDST_PRMT  */
   SELECT 1
     INTO v_object_ind
     FROM user_tables
     JOIN user_tab_cols
       ON user_tab_cols.table_name = user_tables.table_name
    WHERE user_tables.table_name = 'ICS_SW_INDST_PRMT'
      AND user_tab_cols.column_name = 'INDST_ACTY_SIZE';
   
   /* The column already exists in schema, bypass creation */
    DBMS_OUTPUT.PUT_LINE( 'The column INDST_ACTY_SIZE already exists on ICS_SW_INDST_PRMT, schema alteration bypassed!');

EXCEPTION

  WHEN NO_DATA_FOUND THEN  
  
    BEGIN
       
      --  Added new column (NULLABLE)
      v_sql_statement := 'ALTER TABLE ICS_SW_INDST_PRMT ADD (INDST_ACTY_SIZE INT NULL)';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The column INDST_ACTY_SIZE was added to the table ICS_SW_INDST_PRMT!');
       
     END;  -- INDST_ACTY_SIZE

END;
/


/********************************************************************************************************  
    Script Note:  This anonymous block will drop the columns 'PRMT_IDENT','CMPL_MON_CATG_CODE'
                  and 'CMPL_MON_DATE' from the database table ICS_LNK_ST_CMPL_MON, if they exist.
*********************************************************************************************************/
DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  FOR tbl_col IN (SELECT DISTINCT
                         user_tab_cols.table_name
                       , user_tab_cols.column_name
                    FROM user_tab_cols
                   WHERE table_name = 'ICS_LNK_ST_CMPL_MON'
                     AND column_name IN ('PRMT_IDENT','CMPL_MON_CATG_CODE','CMPL_MON_DATE')) LOOP
                       
    v_sql_statement := 'ALTER TABLE ' ||  tbl_col.table_name || ' DROP COLUMN ' || tbl_col.column_name;
    --DBMS_OUTPUT.PUT_LINE( 'SQL: ' || v_sql_statement);
    EXECUTE IMMEDIATE v_sql_statement;   
    DBMS_OUTPUT.PUT_LINE( 'The column ' || tbl_col.column_name || ' was dropped from the database table ' || tbl_col.table_name);
    
    v_object_ind := 1;
     
  END LOOP;
  
  IF v_object_ind = 0 THEN
    DBMS_OUTPUT.PUT_LINE('The columns PRMT_IDENT, CMPL_MON_CATG_CODE, CMPL_MON_DATE had already been removed from ICS_LNK_ST_CMPL_MON, schema alteration bypassed');
  END IF;
  
END;  -- ICS_LNK_ST_CMPL_MON:  Drop columns
/


/********************************************************************************************************  
    Script Note:  This anonymous block will create a new column on database table ICS_LNK_ST_CMPL_MON called
                  CMPL_MON_IDENT.  This column needs a NULL constraint.  Therefore the column must at
                  first be added allowing NULLs, then some data needs to be populated, then the 
                  NULL constraint can be applied.  This block will check for the existence of the new
                  5.0 database column.  If it does not already exist the schema will be updated.
                  Otherwise any alterations will be bypassed. 
*********************************************************************************************************/
DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  /*  Check to see if CMPL_MON_IDENT column exists on the database table ICS_LNK_ST_CMPL_MON  */
   SELECT 1
     INTO v_object_ind
     FROM user_tables
     JOIN user_tab_cols
       ON user_tab_cols.table_name = user_tables.table_name
    WHERE user_tables.table_name = 'ICS_LNK_ST_CMPL_MON'
      AND user_tab_cols.column_name = 'CMPL_MON_IDENT';
   
   /* The column already exists in schema, bypass creation */
    DBMS_OUTPUT.PUT_LINE( 'The column CMPL_MON_IDENT already exists on ICS_LNK_ST_CMPL_MON, schema alteration bypassed!');

EXCEPTION

  WHEN NO_DATA_FOUND THEN  
  
    BEGIN
       
      --  Added new column (NULLABLE)
      v_sql_statement := 'ALTER TABLE ICS_LNK_ST_CMPL_MON ADD (CMPL_MON_IDENT VARCHAR2(25) NULL)';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The column CMPL_MON_IDENT was added to the table ICS_LNK_ST_CMPL_MON!');
       
     END;  -- CMPL_MON_IDENT

END;
/


/********************************************************************************************************  
    Script Note:  This anonymous block will create a new column on database table ICS_PRMT_FEATR called
                  IMPAIRED_WTR_IND.
*********************************************************************************************************/
DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  /*  Check to see if IMPAIRED_WTR_IND column exists on the database table ICS_PRMT_FEATR  */
   SELECT 1
     INTO v_object_ind
     FROM user_tables
     JOIN user_tab_cols
       ON user_tab_cols.table_name = user_tables.table_name
    WHERE user_tables.table_name = 'ICS_PRMT_FEATR'
      AND user_tab_cols.column_name = 'IMPAIRED_WTR_IND';
   
   /* The column already exists in schema, bypass creation */
    DBMS_OUTPUT.PUT_LINE( 'The column IMPAIRED_WTR_IND already exists on ICS_PRMT_FEATR, schema alteration bypassed!');

EXCEPTION

  WHEN NO_DATA_FOUND THEN  
  
    BEGIN
       
      --  Added new column (NULLABLE)
      v_sql_statement := 'ALTER TABLE ICS_PRMT_FEATR ADD (IMPAIRED_WTR_IND CHAR(1) NULL)';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The column IMPAIRED_WTR_IND was added to the table ICS_PRMT_FEATR!');
       
     END;  -- IMPAIRED_WTR_IND

END;
/


/********************************************************************************************************  
    Script Note:  This anonymous block will create a new column on database table ICS_PRMT_FEATR called
                  TMDL_COMPLETED_IND.
*********************************************************************************************************/
DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  /*  Check to see if TMDL_COMPLETED_IND column exists on the database table ICS_PRMT_FEATR  */
   SELECT 1
     INTO v_object_ind
     FROM user_tables
     JOIN user_tab_cols
       ON user_tab_cols.table_name = user_tables.table_name
    WHERE user_tables.table_name = 'ICS_PRMT_FEATR'
      AND user_tab_cols.column_name = 'TMDL_COMPLETED_IND';
   
   /* The column already exists in schema, bypass creation */
    DBMS_OUTPUT.PUT_LINE( 'The column TMDL_COMPLETED_IND already exists on ICS_PRMT_FEATR, schema alteration bypassed!');

EXCEPTION

  WHEN NO_DATA_FOUND THEN  
  
    BEGIN
       
      --  Added new column (NULLABLE)
      v_sql_statement := 'ALTER TABLE ICS_PRMT_FEATR ADD (TMDL_COMPLETED_IND CHAR(1) NULL)';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The column TMDL_COMPLETED_IND was added to the table ICS_PRMT_FEATR!');
       
     END;  -- TMDL_COMPLETED_IND

END;
/


/********************************************************************************************************  
    Script Note:  This anonymous block will create a new column on database table ICS_SW_INDST_PRMT called
                  WEB_ADDR_URL.
*********************************************************************************************************/
DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  /*  Check to see if WEB_ADDR_URL column exists on the database table ICS_SW_INDST_PRMT  */
   SELECT 1
     INTO v_object_ind
     FROM user_tables
     JOIN user_tab_cols
       ON user_tab_cols.table_name = user_tables.table_name
    WHERE user_tables.table_name = 'ICS_SW_INDST_PRMT'
      AND user_tab_cols.column_name = 'WEB_ADDR_URL';
   
   /* The column already exists in schema, bypass creation */
    DBMS_OUTPUT.PUT_LINE( 'The column WEB_ADDR_URL already exists on ICS_SW_INDST_PRMT, schema alteration bypassed!');

EXCEPTION

  WHEN NO_DATA_FOUND THEN  
  
    BEGIN
       
      --  Added new column (NULLABLE)
      v_sql_statement := 'ALTER TABLE ICS_SW_INDST_PRMT ADD (WEB_ADDR_URL VARCHAR(100) NULL)';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The column WEB_ADDR_URL was added to the table ICS_SW_INDST_PRMT!');
       
     END;  -- WEB_ADDR_URL

END;
/


/********************************************************************************************************  
    Script Note:  This anonymous block will create a new column on database table ICS_SW_INDST_PRMT called
                  ACTIVITIES_EXPOSED_SW_TXT.
*********************************************************************************************************/
DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  /*  Check to see if ACTIVITIES_EXPOSED_SW_TXT column exists on the database table ICS_SW_INDST_PRMT  */
   SELECT 1
     INTO v_object_ind
     FROM user_tables
     JOIN user_tab_cols
       ON user_tab_cols.table_name = user_tables.table_name
    WHERE user_tables.table_name = 'ICS_SW_INDST_PRMT'
      AND user_tab_cols.column_name = 'ACTIVITIES_EXPOSED_SW_TXT';
   
   /* The column already exists in schema, bypass creation */
    DBMS_OUTPUT.PUT_LINE( 'The column ACTIVITIES_EXPOSED_SW_TXT already exists on ICS_SW_INDST_PRMT, schema alteration bypassed!');

EXCEPTION

  WHEN NO_DATA_FOUND THEN  
  
    BEGIN
       
      --  Added new column (NULLABLE)
      v_sql_statement := 'ALTER TABLE ICS_SW_INDST_PRMT ADD (ACTIVITIES_EXPOSED_SW_TXT VARCHAR(4000) NULL)';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The column ACTIVITIES_EXPOSED_SW_TXT was added to the table ICS_SW_INDST_PRMT!');
       
     END;  -- ACTIVITIES_EXPOSED_SW_TXT

END;
/


/********************************************************************************************************  
    Script Note:  This anonymous block will create a new column on database table ICS_SW_INDST_PRMT called
                  ASSC_POLLUTANTS_TXT.
*********************************************************************************************************/
DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  /*  Check to see if ASSC_POLLUTANTS_TXT column exists on the database table ICS_SW_INDST_PRMT  */
   SELECT 1
     INTO v_object_ind
     FROM user_tables
     JOIN user_tab_cols
       ON user_tab_cols.table_name = user_tables.table_name
    WHERE user_tables.table_name = 'ICS_SW_INDST_PRMT'
      AND user_tab_cols.column_name = 'ASSC_POLLUTANTS_TXT';
   
   /* The column already exists in schema, bypass creation */
    DBMS_OUTPUT.PUT_LINE( 'The column ASSC_POLLUTANTS_TXT already exists on ICS_SW_INDST_PRMT, schema alteration bypassed!');

EXCEPTION

  WHEN NO_DATA_FOUND THEN  
  
    BEGIN
       
      --  Added new column (NULLABLE)
      v_sql_statement := 'ALTER TABLE ICS_SW_INDST_PRMT ADD (ASSC_POLLUTANTS_TXT VARCHAR(4000) NULL)';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The column ASSC_POLLUTANTS_TXT was added to the table ICS_SW_INDST_PRMT!');
       
     END;  -- ASSC_POLLUTANTS_TXT

END;
/


/********************************************************************************************************  
    Script Note:  This anonymous block will create a new column on database table ICS_SW_INDST_PRMT called
                  CONTROL_MSR_TXT.
*********************************************************************************************************/
DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  /*  Check to see if CONTROL_MSR_TXT column exists on the database table ICS_SW_INDST_PRMT  */
   SELECT 1
     INTO v_object_ind
     FROM user_tables
     JOIN user_tab_cols
       ON user_tab_cols.table_name = user_tables.table_name
    WHERE user_tables.table_name = 'ICS_SW_INDST_PRMT'
      AND user_tab_cols.column_name = 'CONTROL_MSR_TXT';
   
   /* The column already exists in schema, bypass creation */
    DBMS_OUTPUT.PUT_LINE( 'The column CONTROL_MSR_TXT already exists on ICS_SW_INDST_PRMT, schema alteration bypassed!');

EXCEPTION

  WHEN NO_DATA_FOUND THEN  
  
    BEGIN
       
      --  Added new column (NULLABLE)
      v_sql_statement := 'ALTER TABLE ICS_SW_INDST_PRMT ADD (CONTROL_MSR_TXT VARCHAR(4000) NULL)';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The column CONTROL_MSR_TXT was added to the table ICS_SW_INDST_PRMT!');
       
     END;  -- CONTROL_MSR_TXT

END;
/


/********************************************************************************************************  
    Script Note:  This anonymous block will create a new column on database table ICS_SW_INDST_PRMT called
                  SCHD_CONTROL_MSR_TXT.
*********************************************************************************************************/
DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  /*  Check to see if SCHD_CONTROL_MSR_TXT column exists on the database table ICS_SW_INDST_PRMT  */
   SELECT 1
     INTO v_object_ind
     FROM user_tables
     JOIN user_tab_cols
       ON user_tab_cols.table_name = user_tables.table_name
    WHERE user_tables.table_name = 'ICS_SW_INDST_PRMT'
      AND user_tab_cols.column_name = 'SCHD_CONTROL_MSR_TXT';
   
   /* The column already exists in schema, bypass creation */
    DBMS_OUTPUT.PUT_LINE( 'The column SCHD_CONTROL_MSR_TXT already exists on ICS_SW_INDST_PRMT, schema alteration bypassed!');

EXCEPTION

  WHEN NO_DATA_FOUND THEN  
  
    BEGIN
       
      --  Added new column (NULLABLE)
      v_sql_statement := 'ALTER TABLE ICS_SW_INDST_PRMT ADD (SCHD_CONTROL_MSR_TXT VARCHAR(4000) NULL)';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The column SCHD_CONTROL_MSR_TXT was added to the table ICS_SW_INDST_PRMT!');
       
     END;  -- SCHD_CONTROL_MSR_TXT

END;
/


/********************************************************************************************************  
    Script Note:  This anonymous block will create a new column on database table ICS_SW_INDST_PRMT called
                  TIER_TWO_IND.
*********************************************************************************************************/
DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  /*  Check to see if TIER_TWO_IND column exists on the database table ICS_SW_INDST_PRMT  */
   SELECT 1
     INTO v_object_ind
     FROM user_tables
     JOIN user_tab_cols
       ON user_tab_cols.table_name = user_tables.table_name
    WHERE user_tables.table_name = 'ICS_SW_INDST_PRMT'
      AND user_tab_cols.column_name = 'TIER_TWO_IND';
   
   /* The column already exists in schema, bypass creation */
    DBMS_OUTPUT.PUT_LINE( 'The column TIER_TWO_IND already exists on ICS_SW_INDST_PRMT, schema alteration bypassed!');

EXCEPTION

  WHEN NO_DATA_FOUND THEN  
  
    BEGIN
       
      --  Added new column (NULLABLE)
      v_sql_statement := 'ALTER TABLE ICS_SW_INDST_PRMT ADD (TIER_TWO_IND CHAR(1) NULL)';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The column TIER_TWO_IND was added to the table ICS_SW_INDST_PRMT!');
       
     END;  -- TIER_TWO_IND

END;
/


/********************************************************************************************************  
    Script Note:  This anonymous block will create a new column on database table ICS_SW_INDST_PRMT called
                  TIER_THREE_IND.
*********************************************************************************************************/
DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  /*  Check to see if TIER_THREE_IND column exists on the database table ICS_SW_INDST_PRMT  */
   SELECT 1
     INTO v_object_ind
     FROM user_tables
     JOIN user_tab_cols
       ON user_tab_cols.table_name = user_tables.table_name
    WHERE user_tables.table_name = 'ICS_SW_INDST_PRMT'
      AND user_tab_cols.column_name = 'TIER_THREE_IND';
   
   /* The column already exists in schema, bypass creation */
    DBMS_OUTPUT.PUT_LINE( 'The column TIER_THREE_IND already exists on ICS_SW_INDST_PRMT, schema alteration bypassed!');

EXCEPTION

  WHEN NO_DATA_FOUND THEN  
  
    BEGIN
       
      --  Added new column (NULLABLE)
      v_sql_statement := 'ALTER TABLE ICS_SW_INDST_PRMT ADD (TIER_THREE_IND CHAR(1) NULL)';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The column TIER_THREE_IND was added to the table ICS_SW_INDST_PRMT!');
       
     END;  -- TIER_THREE_IND

END;
/

/********************************************************************************************************  
    Script Note:  This anonymous block will create a new ICIS-NPDES staging table called
                  ICS_SW_INDST_ANNUL_REP, if it does not currently exist in the schema.
*********************************************************************************************************/
DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  /*  Check to see if WEB_ADDR_URL column exists on the database table ICS_SW_INDST_PRMT  */
   SELECT 1
     INTO v_object_ind
     FROM user_tables
    WHERE user_tables.table_name = 'ICS_SW_INDST_ANNUL_REP';
   
   /* The column already exists in schema, bypass creation */
    DBMS_OUTPUT.PUT_LINE( 'The table ICS_SW_INDST_ANNUL_REP already exists, schema alteration bypassed!');

EXCEPTION

  WHEN NO_DATA_FOUND THEN  
  
    BEGIN
       
      --  Added new column (NULLABLE)
      v_sql_statement := 'CREATE TABLE ICS_SW_INDST_ANNUL_REP 
                          (ICS_SW_INDST_ANNUL_REP_ID VARCHAR2(36) NOT NULL,
                           ICS_PAYLOAD_ID VARCHAR2(36) NOT NULL,
                           SRC_SYSTM_IDENT VARCHAR2(50) NULL,
                           TRANSACTION_TYPE CHAR(1) NULL,
                           TRANSACTION_TIMESTAMP DATE NULL,
                           PRMT_IDENT VARCHAR2(50) NOT NULL,
                           INDST_SW_ANNUL_REP_RCVD_DATE DATE NOT NULL,
                           FAC_INSP_SUMM_TXT VARCHAR2(4000) NULL,
                           VISUAL_ASSESSMENT_SUMM_TXT VARCHAR2(4000) NULL,
                           NO_FURTHER_REDUCTION_SUMM_TXT VARCHAR2(4000) NULL,
                           CORR_ACTN_SUMM_TXT VARCHAR2(4000) NULL,
                           KEY_HASH VARCHAR2(32) NULL,
                           DATA_HASH VARCHAR2(32) NULL)';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The table ICS_SW_INDST_ANNUL_REP was added to the schema!');

      v_sql_statement := 'ALTER TABLE ICS_SW_INDST_ANNUL_REP ADD ( CONSTRAINT PK_SW_INDST_ANNUL_REP PRIMARY KEY(ICS_SW_INDST_ANNUL_REP_ID) NOT DEFERRABLE INITIALLY IMMEDIATE)';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The prmary key PK_SW_INDST_ANNUL_REP was added to table ICS_SW_INDST_ANNUL_REP.');

      v_sql_statement := 'CREATE INDEX IX_SW_INDS_ANNL_REP_ICS_PYL_ID ON ICS_SW_INDST_ANNUL_REP(ICS_PAYLOAD_ID)';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The index IX_SW_INDS_ANNL_REP_ICS_PYL_ID was added to table ICS_SW_INDST_ANNUL_REP.');
      
      v_sql_statement := 'CREATE UNIQUE INDEX IX_SW_IN_AN_RE_PR_ID_IN_SW_AN ON ICS_SW_INDST_ANNUL_REP(PRMT_IDENT, INDST_SW_ANNUL_REP_RCVD_DATE)';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The index IX_SW_IN_AN_RE_PR_ID_IN_SW_AN was added to table ICS_SW_INDST_ANNUL_REP.');
      
      v_sql_statement := 'ALTER TABLE ICS_SW_INDST_ANNUL_REP ADD CONSTRAINT FK_SW_INDST_ANNUL_REP_PAYLOAD FOREIGN KEY(ICS_PAYLOAD_ID) REFERENCES ICS_PAYLOAD(ICS_PAYLOAD_ID) ON DELETE CASCADE';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The foreign key FK_SW_INDST_ANNUL_REP_PAYLOAD was added to table ICS_SW_INDST_ANNUL_REP.');
    
     END;  -- ICS_SW_INDST_ANNUL_REP

END;
/


/************************************
 * Alter Table:  ICS_SUBM_RESULTS
 ************************************/
DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  /*  Check to see if INDST_SW_ANNUL_REP_RCVD_DATE column exists on the database table ICS_SUBM_RESULTS  */
   SELECT 1
     INTO v_object_ind
     FROM user_tables
     JOIN user_tab_cols
       ON user_tab_cols.table_name = user_tables.table_name
    WHERE user_tables.table_name = 'ICS_SUBM_RESULTS'
      AND user_tab_cols.column_name = 'INDST_SW_ANNUL_REP_RCVD_DATE';
   
   /* The column already exists in schema, bypass creation */
    DBMS_OUTPUT.PUT_LINE( 'The column INDST_SW_ANNUL_REP_RCVD_DATE already exists on ICS_SUBM_RESULTS, schema alteration bypassed!');

EXCEPTION

  WHEN NO_DATA_FOUND THEN  
  
    BEGIN
       
      --  Added new column (NULLABLE)
      v_sql_statement := 'ALTER TABLE ICS_SUBM_RESULTS ADD (INDST_SW_ANNUL_REP_RCVD_DATE DATE NULL)';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The column INDST_SW_ANNUL_REP_RCVD_DATE was added to the table ICS_SUBM_RESULTS!');
      
       
     END;  -- INDST_SW_ANNUL_REP_RCVD_DATE

END;
/





/************************************
 * Alter Table:  ICS_SUBM_RESULTS
 ************************************/
DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  /*  Check to see if INDST_SW_ANNUL_REP_RCVD_DATE column exists on the database table ICS_SUBM_RESULTS  */
   SELECT 1
     INTO v_object_ind
     FROM user_tables
     JOIN user_tab_cols
       ON user_tab_cols.table_name = user_tables.table_name
    WHERE user_tables.table_name = 'ICS_SUBM_RESULTS'
      AND user_tab_cols.column_name = 'CMPL_MON_IDENT';
   
   /* The column already exists in schema, bypass creation */
    DBMS_OUTPUT.PUT_LINE( 'The column CMPL_MON_IDENT already exists on ICS_SUBM_RESULTS, schema alteration bypassed!');

EXCEPTION

  WHEN NO_DATA_FOUND THEN  
  
    BEGIN
       
      --  Added new column (NULLABLE)
      v_sql_statement := 'ALTER TABLE ICS_SUBM_RESULTS ADD (CMPL_MON_IDENT VARCHAR2(25) NULL)';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The column CMPL_MON_IDENT was added to the table ICS_SUBM_RESULTS!');
      
       
     END;  -- CMPL_MON_IDENT

END;
/



/************************************
 * Alter Table:  ICS_SUBM_RESULTS
 ************************************/
DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  /*  Check to see if INDST_SW_ANNUL_REP_RCVD_DATE column exists on the database table ICS_SUBM_RESULTS  */
   SELECT 1
     INTO v_object_ind
     FROM user_tables
     JOIN user_tab_cols
       ON user_tab_cols.table_name = user_tables.table_name
    WHERE user_tables.table_name = 'ICS_SUBM_RESULTS'
      AND user_tab_cols.column_name = 'CMPL_MON_IDENT_2';
   
   /* The column already exists in schema, bypass creation */
    DBMS_OUTPUT.PUT_LINE( 'The column CMPL_MON_IDENT_2 already exists on ICS_SUBM_RESULTS, schema alteration bypassed!');

EXCEPTION

  WHEN NO_DATA_FOUND THEN  
  
    BEGIN
       
      --  Added new column (NULLABLE)
      v_sql_statement := 'ALTER TABLE ICS_SUBM_RESULTS ADD (CMPL_MON_IDENT_2 VARCHAR2(25) NULL)';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The column CMPL_MON_IDENT_2 was added to the table ICS_SUBM_RESULTS!');
      
       
     END;  -- CMPL_MON_IDENT_2

END;
/
























/********************************************************************************************************  
    Script Note:  This anonymous block will drop the columns 'PRMT_IDENT','CMPL_MON_CATG_CODE'
                  and 'CMPL_MON_DATE' from the database table ICS_SUBM_RESULTS, if they exist.
*********************************************************************************************************/
--DECLARE

--  v_object_ind NUMBER(01) := 0;
--  v_sql_statement VARCHAR2(4000);

--BEGIN 

--  FOR tbl_col IN (SELECT DISTINCT
--                         user_tab_cols.table_name
--                       , user_tab_cols.column_name
--                    FROM user_tab_cols
--                   WHERE table_name = 'ICS_SUBM_RESULTS'
--                     AND column_name IN ('PRMT_ISSUE_DATE')) LOOP
--                       
--    v_sql_statement := 'ALTER TABLE ' ||  tbl_col.table_name || ' DROP COLUMN ' || tbl_col.column_name;
--    EXECUTE IMMEDIATE v_sql_statement;   
--    DBMS_OUTPUT.PUT_LINE( 'The column ' || tbl_col.column_name || ' was dropped from the database table ' || tbl_col.table_name);
--    
--    v_object_ind := 1;
--     
--  END LOOP;
--  
--  IF v_object_ind = 0 THEN
--    DBMS_OUTPUT.PUT_LINE('The columns PRMT_ISSUE_DATE had already been removed from ICS_SUBM_RESULTS, schema alteration bypassed');
--  END IF;
--  
--END;  -- ICS_SUBM_RESULTS:  Drop column
--/



-----$ Alter table dbo.ICS_GPCF_NOTICE_OF_TERM
--IF NOT EXISTS(SELECT * FROM SYS.COLUMNS WHERE OBJECT_ID = OBJECT_ID(N'dbo.ICS_GPCF_NOTICE_OF_TERM') AND NAME = 'FEDR_CERCLA_DSCH_IND')
--BEGIN
--    ALTER TABLE dbo.ICS_GPCF_NOTICE_OF_TERM
--        ADD FEDR_CERCLA_DSCH_IND CHAR(1) NULL
--END
--GO

/********************************************************************************************************  
    Script Note:  This anonymous block will create a new column on database table ICS_GPCF_NOTICE_OF_TERM called
                  FEDR_CERCLA_DSCH_IND.  This column needs a NULL constraint.  Therefore the column must at
                  first be added allowing NULLs, then some data needs to be populated, then the 
                  NULL constraint can be applied.  This block will check for the existence of the new
                  5.0 database column.  If it does not already exist the schema will be updated.
                  Otherwise any alterations will be bypassed. 
*********************************************************************************************************/
DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  /*  Check to see if FEDR_CERCLA_DSCH_IND column exists on the database table ICS_GPCF_NOTICE_OF_TERM  */
   SELECT 1
     INTO v_object_ind
     FROM user_tables
     JOIN user_tab_cols
       ON user_tab_cols.table_name = user_tables.table_name
    WHERE user_tables.table_name = 'ICS_GPCF_NOTICE_OF_INTENT'
      AND user_tab_cols.column_name = 'FEDR_CERCLA_DSCH_IND';
   
   /* The column already exists in schema, bypass creation */
    DBMS_OUTPUT.PUT_LINE( 'The column FEDR_CERCLA_DSCH_IND already exists on ICS_GPCF_NOTICE_OF_INTENT, schema alteration bypassed!');

EXCEPTION

  WHEN NO_DATA_FOUND THEN  
  
    BEGIN
       
      --  Added new column
      v_sql_statement := 'ALTER TABLE ICS_GPCF_NOTICE_OF_INTENT ADD (FEDR_CERCLA_DSCH_IND CHAR(1) NULL)';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The column FEDR_CERCLA_DSCH_IND was added to the table ICS_GPCF_NOTICE_OF_INTENT!');
       
     END;  -- FEDR_CERCLA_DSCH_IND

END;
/

COMMENT ON COLUMN ICS_GPCF_NOTICE_OF_INTENT.FEDR_CERCLA_DSCH_IND IS 'Federal CERCLA Discharge Indicator.';


/********************************************************************************************************  
    Script Note:  This anonymous block will create a new ICIS-NPDES staging table called
                  ICS_SUBSCTOR_CODE_PLUS_DESC if it does not currently exist in the schema.
*********************************************************************************************************/
DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  /*  Check to see if the database table ICS_SUBSCTOR_CODE_PLUS_DESC exists */
   SELECT 1
     INTO v_object_ind
     FROM user_tables
    WHERE user_tables.table_name = 'ICS_SUBSCTOR_CODE_PLUS_DESC';
   
   /* The column already exists in schema, bypass creation */
    DBMS_OUTPUT.PUT_LINE( 'The table ICS_SUBSCTOR_CODE_PLUS_DESC already exists, schema alteration bypassed!');

EXCEPTION

  WHEN NO_DATA_FOUND THEN  
  
    BEGIN
       
      --  Added new column (NULLABLE)
      v_sql_statement := 'CREATE TABLE ICS_SUBSCTOR_CODE_PLUS_DESC 
                          (ICS_SUBSCTOR_CODE_PLUS_DESC_ID VARCHAR2(36) NOT NULL,
                           ICS_GPCF_NOTICE_OF_INTENT_ID VARCHAR2(36) NOT NULL,
                           SUBSCTOR_CODE_PLUS_DESC VARCHAR2(304) NOT NULL,
                           DATA_HASH VARCHAR2(32) NULL)';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The table ICS_SUBSCTOR_CODE_PLUS_DESC was added to the schema!');
      
      v_sql_statement := 'ALTER TABLE ICS_SUBSCTOR_CODE_PLUS_DESC ADD ( CONSTRAINT PK_SUBSCTOR_CODE_PLUS_DESC PRIMARY KEY (ICS_SUBSCTOR_CODE_PLUS_DESC_ID) NOT DEFERRABLE INITIALLY IMMEDIATE)';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The prmary key PK_SUBSCTOR_CODE_PLUS_DESC was added to table ICS_SUBSCTOR_CODE_PLUS_DESC.');
      
      v_sql_statement := 'CREATE INDEX IX_SB_CO_PL_DE_IC_GP_NT_OF_IN ON ICS_SUBSCTOR_CODE_PLUS_DESC(ICS_GPCF_NOTICE_OF_INTENT_ID)';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The index IX_SB_CO_PL_DE_IC_GP_NT_OF_IN was added to table ICS_SUBSCTOR_CODE_PLUS_DESC.');
      
      v_sql_statement := 'ALTER TABLE ICS_SUBSCTOR_CODE_PLUS_DESC ADD CONSTRAINT FK_SBS_COD_PLU_DES_GP_NT_OF_IN FOREIGN KEY(ICS_GPCF_NOTICE_OF_INTENT_ID) REFERENCES ICS_GPCF_NOTICE_OF_INTENT(ICS_GPCF_NOTICE_OF_INTENT_ID) ON DELETE CASCADE';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The foreign key FK_SBS_COD_PLU_DES_GP_NT_OF_IN was added to table ICS_SUBSCTOR_CODE_PLUS_DESC.');
    
     END;  -- ICS_SUBSCTOR_CODE_PLUS_DESC

END;
/

/********************************************************************************************************  
    Script Note:  This anonymous block will alter the column FINAL_ORDER_PRMT_IDENT on database table
                  ICS_FINAL_ORDER_PRMT_IDENT if its determine to not be of type CHAR.
*********************************************************************************************************/
DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  /*  Check to see if FINAL_ORDER_PRMT_IDENT column exists on the database table ICS_FINAL_ORDER_PRMT_IDENT  */
   SELECT 1
     INTO v_object_ind
     FROM user_tables
     JOIN user_tab_cols
       ON user_tab_cols.table_name = user_tables.table_name
    WHERE user_tables.table_name = 'ICS_FINAL_ORDER_PRMT_IDENT'
      AND user_tab_cols.column_name = 'FINAL_ORDER_PRMT_IDENT'
      AND user_tab_cols.data_type = 'CHAR';
   
   /* The column already exists in schema, bypass creation */
    DBMS_OUTPUT.PUT_LINE( 'The column FINAL_ORDER_PRMT_IDENT on ICS_FINAL_ORDER_PRMT_IDENT was already a CHAR data type, schema alteration bypassed!');

EXCEPTION

  WHEN NO_DATA_FOUND THEN  
  
    BEGIN
       
      --  Apply NOT NULL constraint on new column
      v_sql_statement := 'ALTER TABLE ICS_FINAL_ORDER_PRMT_IDENT MODIFY (FINAL_ORDER_PRMT_IDENT CHAR(9))';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The column FINAL_ORDER_PRMT_IDENT on ICS_FINAL_ORDER_PRMT_IDENT was modified to a CHAR data type!');

     END;  -- FINAL_ORDER_PRMT_IDENT

END;
/


/********************************************************************************************************  
    Script Note:  This anonymous block will alter the column PRMT_IDENT on database table
                  ICS_PRMT_IDENT if its determine to not be of type CHAR.
*********************************************************************************************************/
DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  /*  Check to see if PRMT_IDENT column exists on the database table ICS_PRMT_IDENT  */
   SELECT 1
     INTO v_object_ind
     FROM user_tables
     JOIN user_tab_cols
       ON user_tab_cols.table_name = user_tables.table_name
    WHERE user_tables.table_name = 'ICS_PRMT_IDENT'
      AND user_tab_cols.column_name = 'PRMT_IDENT'
      AND user_tab_cols.data_type = 'CHAR';
   
   /* The column already exists in schema, bypass creation */
    DBMS_OUTPUT.PUT_LINE( 'The column PRMT_IDENT on ICS_PRMT_IDENT was already a CHAR data type, schema alteration bypassed!');

EXCEPTION

  WHEN NO_DATA_FOUND THEN  
  
    BEGIN
       
      --  Apply NOT NULL constraint on new column
      v_sql_statement := 'ALTER TABLE ICS_PRMT_IDENT MODIFY (PRMT_IDENT CHAR(9))';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The column PRMT_IDENT on ICS_PRMT_IDENT was modified to a CHAR data type!');

     END;  -- PRMT_IDENT

END;
/

COMMENT ON COLUMN ICS_CMPL_MON_LNK.CMPL_MON_IDENT IS 'String that represents the compliance monitoring identifier.  Optional';




/********************************************************************************************************  
    Script Note:  This anonymous block will alter the data type of the database column KEY_HASH on the
                  table ICS_SUBM_RESULTS from numeric to VARCHAR2.
*********************************************************************************************************/
DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  /*  Check to see if CMPL_MON_IDENT column exists on the database table ICS_CMPL_MON  */
   SELECT 1
     INTO v_object_ind
     FROM user_tables
     JOIN user_tab_cols
       ON user_tab_cols.table_name = user_tables.table_name
    WHERE user_tables.table_name = 'ICS_SUBM_RESULTS'
      AND user_tab_cols.column_name = 'KEY_HASH'
      AND user_tab_cols.data_type <> 'NUMBER';
   
   /* The column already exists in schema, bypass creation */
    DBMS_OUTPUT.PUT_LINE( 'The column KEY_HASH column on ICS_SUBM_RESULTS is already data typed VARCHAR2, schema alteration bypassed!');

EXCEPTION

  WHEN NO_DATA_FOUND THEN  
  
    BEGIN
       
      --  Apply NOT NULL constraint on new column
      v_sql_statement := 'ALTER TABLE ICS_SUBM_RESULTS MODIFY (KEY_HASH VARCHAR2(100))';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'A KEY_HASH column on ICS_SUBM_RESULTS was converted to VARCHAR2!');
       
     END;  -- ICS_SUBM_RESULTS.KEY_HASH

END;
/
/*************************************************************************************************
** ObjectName: cdv_sw_indst_annul_rep
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 10/10/2014    Windsor     Created from 4.1 baseline.
**
***************************************************************************************************/
CREATE OR REPLACE VIEW cdv_sw_indst_annul_rep AS 
SELECT DISTINCT ics_module
, ics_sw_indst_annul_rep.key_hash
     , CASE ics_sw_indst_annul_rep.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ics_sw_indst_annul_rep tbl
                  WHERE tbl.ics_sw_indst_annul_rep_id = ics_sw_indst_annul_rep.ics_sw_indst_annul_rep_id)
           ELSE (SELECT key_hash 
                   FROM ics_sw_indst_annul_rep tbl
                  WHERE tbl.ics_sw_indst_annul_rep_id = ics_sw_indst_annul_rep.ics_sw_indst_annul_rep_id)
       END AS module_ident
     , ics_sw_indst_annul_rep.action_type
     , ics_sw_indst_annul_rep.action_code
  FROM (/*  1 - NEW  */
        SELECT ics_sw_indst_annul_rep.ics_sw_indst_annul_rep_id
    , ics_sw_indst_annul_rep.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_SW_INDST_ANNUL_REP' as ics_module
          FROM ics_sw_indst_annul_rep
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ics_sw_indst_annul_rep tbl
                            WHERE tbl.key_hash = ics_sw_indst_annul_rep.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ics_sw_indst_annul_rep_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_SW_INDST_ANNUL_REP' as ics_module
          FROM ics_sw_indst_annul_rep local
          JOIN ics_flow_icis.ics_sw_indst_annul_rep icis
            ON (icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash)
        UNION
        /*  3 - DELETE  */
        SELECT ics_sw_indst_annul_rep.ics_sw_indst_annul_rep_id
             , ics_sw_indst_annul_rep.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_SW_INDST_ANNUL_REP' as ics_module
          FROM ics_flow_icis.ics_sw_indst_annul_rep
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_sw_indst_annul_rep tbl
                            WHERE tbl.key_hash = ics_sw_indst_annul_rep.key_hash)) ics_sw_indst_annul_rep;
/