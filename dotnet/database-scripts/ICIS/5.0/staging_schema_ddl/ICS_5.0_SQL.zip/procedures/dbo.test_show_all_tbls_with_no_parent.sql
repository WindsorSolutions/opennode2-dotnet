/****** Object:  StoredProcedure [dbo].[test_show_all_tbls_with_no_parent]    Script Date: 01/16/2013 11:48:31 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[test_show_all_tbls_with_no_parent]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[test_show_all_tbls_with_no_parent]
GO

/****** Object:  StoredProcedure [dbo].[test_show_all_tbls_with_no_parent]    Script Date: 01/16/2013 11:48:31 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		TK Conrad (Windsor Solutions, Inc.)
-- Create date: 2013-01-15
-- Description:	Shows all tables where all foreign keys are null
-- =============================================
CREATE PROCEDURE [dbo].[test_show_all_tbls_with_no_parent] 
	-- Add the parameters for the stored procedure here
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
    DECLARE @tbl_name	nvarchar(255)
    DECLARE @SQL nvarchar(1000)
	DECLARE @ParmDef nvarchar(500)
	DECLARE @CountOfRecs int
	DECLARE @CountOfRecsOUT int
	DECLARE @Result varchar(1000)
    DECLARE @rslt_tbl	TABLE
    (
    tbl_name	nvarchar(255),
    count_rec	int
    )
    
    DECLARE tbl_name CURSOR FOR
    SELECT DISTINCT TABLE_NAME FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
    WHERE CONSTRAINT_NAME LIKE 'FK%'
      AND COLUMN_NAME != 'ICS_PAYLOAD_ID'
    ORDER BY TABLE_NAME
    
    OPEN tbl_name
    FETCH NEXT FROM tbl_name INTO @tbl_name
    
    WHILE @@FETCH_STATUS = 0
    BEGIN
    	SELECT @Result = COALESCE(@Result + ',', '') + COLUMN_NAME
		FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
		WHERE TABLE_NAME = @tbl_name
		  AND CONSTRAINT_NAME LIKE 'FK%'
		
		-- SELECT @tbl_name,@Result
		SET @SQL = N'SELECT @CountOfRecsOUT = COUNT(*) FROM ' + @tbl_name + ' WHERE '
		+ CASE WHEN CHARINDEX(',',@Result) = 0
		  THEN ''
		  ELSE N'COALESCE('
		  END
		+ @Result + CASE WHEN CHARINDEX(',',@Result) = 0
		  THEN ''
		  ELSE N')'
		  END
		  + N' IS NULL'
		SET @ParmDef = N'@CountOfRecsOUT INT OUTPUT'
		EXECUTE sp_executesql @SQL,@ParmDef,@CountOfRecsOUT = @CountOfRecs OUTPUT
		INSERT INTO @rslt_tbl
		VALUES (@tbl_name, @CountOfRecs)
		SET @Result = NULL
		FETCH NEXT FROM tbl_name INTO @tbl_name
    END
    
    CLOSE tbl_name
    DEALLOCATE tbl_name
    
    SELECT * FROM @rslt_tbl

END


GO


