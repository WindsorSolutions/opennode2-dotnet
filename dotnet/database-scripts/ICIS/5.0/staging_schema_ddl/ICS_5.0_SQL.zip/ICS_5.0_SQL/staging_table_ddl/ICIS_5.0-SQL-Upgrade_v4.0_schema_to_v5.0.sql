/*
                  
       This script need to be converted to run in an Oracle RDBMS.

*/

/*
Copyright (c) 2012, The Environmental Council of the States (ECOS)
All rights reserved.
 
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
 
 * Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
 * Neither the name of the ECOS nor the names of its contributors may
   be used to endorse or promote products derived from this software
   without specific prior written permission.
 
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/
/*************************************************************************************************
** ObjectName: ICIS_5.0-SQL-Upgrade_v4.0_schema_to_v5.0.sql
**
** Author: Windsor Solutions, Inc.
**
** Company Name: Windsor Solutions, Inc.
**
** Description:  This script will update an existing ICIS 4.0 database to support the ICIS 5.0
**               exchange.  This script can be run multiple times without issue.
**
** Revision History:
** ------------------------------------------------------------------------------------------------
** Date          Name        Description
** ------------------------------------------------------------------------------------------------
** 09/10/2014    Windsor     Created
** 09/18/2014    Windsor     Added column FEDR_CERCLA_DSCH_IND on database table 
**                           ICS_GPCF_NOTICE_OF_TERM.
** 09/18/2014    Windsor     Added column FEDR_CERCLA_DSCH_IND on database table 
** 09/18/2014    Windsor     Added database table ICS_SUBSCTOR_CODE_PLUS_DESC and related keys,
**                           indexes, etc..
** 09/19/2014    KJames      Added the column DATA_HASH to the database table 
**                           ICS_SUBSCTOR_CODE_PLUS_DESC.
** 09/19/2014    KJames      Added the columns KEY_HASH and DATA_HASH to the database table 
**                           ICS_SW_INDST_ANNUL_REP.
** 09/19/2014    KJames      Standardized PRMT_IDENT columns to CHAR(09).
** 09/29/2014    KJames      Altered the modification of ICS_SUBM_RESULTS.  Added CMPL_MON_IDENT
**                           and CMPL_MON_IDENT_2 columns, re-added PRMT_ISSUE_DATE.
** 10/02/2014    KJames      Moved table ICS_SUBSCTOR_CODE_PLUS_DESC to be a child of notice of 
**                           intent vs. notice of termination.
** 10/20/2014    BRensmith   Fix ICS_SUBSCTOR_CODE_PLUS_DESC FK to ICS_GPCF_NOTICE_OF_INTENT
** 10/23/2014    BRensmith   Add new CDV_SW_INDST_ANNUL_REP view to script
** 12/08/2014    TConrad     Pre-populate CMPL_MON_IDENT for ICS_CMPL_MON_LNK with default unique
**                           value in the same manner as done for ICS_CMPL_MON. Set CMPL_MON_IDENT
**                           on ICS_CMPL_MON_LNK to be NOT NULL.
** 12/11/2014    BRensmith   Remove creation of CDV_SW_INDST_ANNL_REPORT
**                           Remove UNIQUE from index on ICS_CMPL_MON_LNK.
** 01/28/2015    KJames      Modified alteration to ICS_CMPL_MON to pre-populate CMPL_MON_IDENT column
**                           before alter the field to NOT NULL.
** 03/12/2015     KJames     Added FILE_NUM to the database table ICS_INFRML_ENFRC_ACTN.
** 03/12/2015     KJames     Added INDST_ACTY_SIZE to the database table ICS_SW_CNST_PRMT.
** 03/12/2015     KJames     Added INDST_ACTY_SIZE to the database table ICS_SWMS_4_LARGE_PRMT.
** 03/12/2015     KJames     Added INDST_ACTY_SIZE to the database table ICS_SWMS_4_SMALL_PRMT.
** 03/12/2015     KJames     Added LOC_ADDR_CITY_CODE to the database table ICS_UNPRMT_FAC.
**
*************************************************************************************************/
SET NOCOUNT ON
GO

/*******************************
 * Alter Table:  ICS_CMPL_MON
 * Change A: Add Compliance Monitoring identifier to ICS_CMPL_MON and change keys
 ******************************/
--  Drop Index:  IX_CM_MO_PR_ID_CM_MO_CA_CO_CM
IF EXISTS(SELECT * FROM DBO.SYSINDEXES WHERE ID = OBJECT_ID(N'dbo.ICS_CMPL_MON') AND NAME = 'IX_CM_MO_PR_ID_CM_MO_CA_CO_CM')
BEGIN
    DROP INDEX dbo.ICS_CMPL_MON.IX_CM_MO_PR_ID_CM_MO_CA_CO_CM
END
GO
--  Add Column:  CMPL_MON_IDENT
--  Added from SQL baseline.
IF NOT EXISTS(SELECT * FROM SYS.COLUMNS WHERE OBJECT_ID = OBJECT_ID(N'dbo.ICS_CMPL_MON') AND NAME = 'CMPL_MON_IDENT')
BEGIN

DECLARE @dynamic_sql NVARCHAR(255);
DECLARE @dynamic_parms NVARCHAR(255);

    --  Add the new column, but initially allow NULL values.
    ALTER TABLE dbo.ICS_CMPL_MON ADD CMPL_MON_IDENT VARCHAR(25) NULL;

    -- Populate the new column with some form of data so that we can enable
    -- the NOT NULL constraint next.
    SET @dynamic_sql = 'UPDATE ICS_CMPL_MON SET CMPL_MON_IDENT = ' + '''' + 'TMP' + '''' + ' + LEFT(ICS_CMPL_MON_ID,20)';
    EXECUTE sp_executesql @dynamic_sql, @dynamic_parms;

END
GO
--  Drop Index:  AK_ICS_CMPL_MON
IF EXISTS(SELECT * FROM DBO.SYSINDEXES WHERE ID = OBJECT_ID(N'dbo.ICS_CMPL_MON') AND NAME = 'AK_ICS_CMPL_MON')
BEGIN
    DROP INDEX dbo.ICS_CMPL_MON.AK_ICS_CMPL_MON
END
GO
--  Drop Index:  IX_CMPL_MON_CMPL_MON_IDENT
IF EXISTS(SELECT * FROM DBO.SYSINDEXES WHERE ID = OBJECT_ID(N'dbo.ICS_CMPL_MON') AND NAME = 'IX_CMPL_MON_CMPL_MON_IDENT')
BEGIN
    DROP INDEX dbo.ICS_CMPL_MON.IX_CMPL_MON_CMPL_MON_IDENT
END
GO

-- Apply NOT NULL constraint to CMPL_MON_IDENT
IF EXISTS(SELECT * FROM SYS.COLUMNS WHERE OBJECT_ID = OBJECT_ID(N'dbo.ICS_CMPL_MON') AND NAME = 'CMPL_MON_IDENT')
BEGIN

DECLARE @dynamic_sql NVARCHAR(255);
DECLARE @dynamic_parms NVARCHAR(255);

    -- Populate the new column with some form of data so that we can enable
    -- the NOT NULL constraint next.
    SET @dynamic_sql = 'UPDATE ICS_CMPL_MON SET CMPL_MON_IDENT = ' + '''' + 'TMP' + '''' + ' + LEFT(ICS_CMPL_MON_ID,20)';
    EXECUTE sp_executesql @dynamic_sql, @dynamic_parms;

    --  Apply the NOT NULL constraint.
    
    ALTER TABLE dbo.ICS_CMPL_MON ALTER COLUMN CMPL_MON_IDENT VARCHAR(25) NOT NULL;
END
GO
-- Remove the NULL constraint on PRMT_IDENT
IF EXISTS(SELECT * FROM SYS.COLUMNS WHERE OBJECT_ID = OBJECT_ID(N'dbo.ICS_CMPL_MON') AND NAME = 'PRMT_IDENT')
BEGIN
    --  Remove the NOT NULL constraint.
    ALTER TABLE dbo.ICS_CMPL_MON ALTER COLUMN PRMT_IDENT CHAR(09) NULL;
END
GO
--  Add Index:  IX_CMPL_MON_CMPL_MON_IDENT
IF NOT EXISTS(SELECT * FROM DBO.SYSINDEXES WHERE ID = OBJECT_ID(N'dbo.ICS_CMPL_MON') AND NAME = 'IX_CMPL_MON_CMPL_MON_IDENT')
    CREATE UNIQUE NONCLUSTERED INDEX IX_CMPL_MON_CMPL_MON_IDENT ON dbo.ICS_CMPL_MON(CMPL_MON_IDENT);
GO
-- Remove the NULL constraint on CMPL_MON_CATG_CODE
IF EXISTS(SELECT * FROM SYS.COLUMNS WHERE OBJECT_ID = OBJECT_ID(N'dbo.ICS_CMPL_MON') AND NAME = 'CMPL_MON_CATG_CODE')
BEGIN
    --  Remove the NOT NULL constraint.
    ALTER TABLE dbo.ICS_CMPL_MON ALTER COLUMN CMPL_MON_CATG_CODE VARCHAR(3) NULL;
END
GO
-- Remove the NULL constraint on CMPL_MON_DATE
IF EXISTS(SELECT * FROM SYS.COLUMNS WHERE OBJECT_ID = OBJECT_ID(N'dbo.ICS_CMPL_MON') AND NAME = 'CMPL_MON_DATE')
BEGIN
    --  Apply the NOT NULL constraint.
    ALTER TABLE dbo.ICS_CMPL_MON ALTER COLUMN CMPL_MON_DATE datetime NULL;
END
GO


/***********************************
 * Alter Table:  ICS_CMPL_MON_LNK
 *  Change B: Update ICS_CMPL_MON_LNK to use new CMPL_MON_IDENT in place of 3 old business key fields
 ***********************************/
-- Drop Index:  IX_CM_MO_LN_PR_ID_CM_MO_CA_CO
IF EXISTS(SELECT * FROM DBO.SYSINDEXES WHERE ID = OBJECT_ID(N'dbo.ICS_CMPL_MON_LNK') AND NAME = 'IX_CM_MO_LN_PR_ID_CM_MO_CA_CO')
BEGIN
    DROP INDEX dbo.ICS_CMPL_MON_LNK.IX_CM_MO_LN_PR_ID_CM_MO_CA_CO
END
GO
-- Drop Column:  PRMT_IDENT
IF EXISTS(SELECT * FROM SYS.COLUMNS WHERE OBJECT_ID = OBJECT_ID(N'dbo.ICS_CMPL_MON_LNK') AND NAME = 'PRMT_IDENT')
BEGIN
    ALTER TABLE dbo.ICS_CMPL_MON_LNK
        DROP COLUMN PRMT_IDENT
END
GO
-- Drop Column:  CMPL_MON_CATG_CODE
IF EXISTS(SELECT * FROM SYS.COLUMNS WHERE OBJECT_ID = OBJECT_ID(N'dbo.ICS_CMPL_MON_LNK') AND NAME = 'CMPL_MON_CATG_CODE')
BEGIN
    ALTER TABLE dbo.ICS_CMPL_MON_LNK
        DROP COLUMN CMPL_MON_CATG_CODE
END
GO
-- Drop Column:  CMPL_MON_DATE
IF EXISTS(SELECT * FROM SYS.COLUMNS WHERE OBJECT_ID = OBJECT_ID(N'dbo.ICS_CMPL_MON_LNK') AND NAME = 'CMPL_MON_DATE')
BEGIN
    ALTER TABLE dbo.ICS_CMPL_MON_LNK
        DROP COLUMN CMPL_MON_DATE
END
GO
-- Add Column:  CMPL_MON_IDENT
IF NOT EXISTS(SELECT * FROM SYS.COLUMNS WHERE OBJECT_ID = OBJECT_ID(N'dbo.ICS_CMPL_MON_LNK') AND NAME = 'CMPL_MON_IDENT')
BEGIN

DECLARE @dynamic_sql NVARCHAR(255);
DECLARE @dynamic_parms NVARCHAR(255);

    ALTER TABLE dbo.ICS_CMPL_MON_LNK
        ADD CMPL_MON_IDENT VARCHAR(25) NULL
    -- Populate the new column with some form of data so that we can enable
    -- the NOT NULL constraint next.

    SET @dynamic_sql = 'UPDATE ICS_CMPL_MON_LNK SET CMPL_MON_IDENT = ' + '''' + 'TMP' + '''' + ' + LEFT(ICS_CMPL_MON_LNK_ID,20)';
    EXECUTE sp_executesql @dynamic_sql, @dynamic_parms;

    ALTER TABLE dbo.ICS_CMPL_MON_LNK ALTER COLUMN CMPL_MON_IDENT VARCHAR(25) NOT NULL;

END
GO
-- Add Index:  IX_CMPL_MON_LNK_CMPL_MON_IDENT
IF NOT EXISTS(SELECT * FROM DBO.SYSINDEXES WHERE ID = OBJECT_ID(N'dbo.ICS_CMPL_MON_LNK') AND NAME = 'IX_CMPL_MON_LNK_CMPL_MON_IDENT')
    CREATE NONCLUSTERED INDEX IX_CMPL_MON_LNK_CMPL_MON_IDENT
        ON dbo.ICS_CMPL_MON_LNK(CMPL_MON_IDENT)
GO


/*************************
 * Alter Table:  ICS_FAC
 *  Change D: Add city and county codes to the facility record.
 *************************/

 --  Add Column:  LOC_ADDR_COUNTY_CODE
IF NOT EXISTS(SELECT * FROM SYS.COLUMNS WHERE OBJECT_ID = OBJECT_ID(N'dbo.ICS_FAC') AND NAME = 'LOC_ADDR_COUNTY_CODE')
BEGIN
    ALTER TABLE dbo.ICS_FAC
        ADD LOC_ADDR_COUNTY_CODE VARCHAR(5) NULL
END
GO
 --  Add Column:  LOC_ADDR_CITY_CODE
IF NOT EXISTS(SELECT * FROM SYS.COLUMNS WHERE OBJECT_ID = OBJECT_ID(N'dbo.ICS_FAC') AND NAME = 'LOC_ADDR_CITY_CODE')
BEGIN
    ALTER TABLE dbo.ICS_FAC
        ADD LOC_ADDR_CITY_CODE VARCHAR(12) NULL
END
GO


/**************************************
 * Alter Table:  ICS_GPCF_NO_EXPOSURE
 * Change F:  Move column INDST_ACTY_SIZE 
              from ICS_GPCF_NO_EXPOSURE 
			  to ICS_SW_INDST_PRMT.
 **************************************/
-- Drop Column:  INDST_ACTY_SIZE
IF EXISTS(SELECT * FROM SYS.COLUMNS WHERE OBJECT_ID = OBJECT_ID(N'dbo.ICS_GPCF_NO_EXPOSURE') AND NAME = 'INDST_ACTY_SIZE')
BEGIN
    ALTER TABLE dbo.ICS_GPCF_NO_EXPOSURE
        DROP COLUMN INDST_ACTY_SIZE
END
GO
-- Add Column:  INDST_ACTY_SIZE
IF NOT EXISTS(SELECT * FROM SYS.COLUMNS WHERE OBJECT_ID = OBJECT_ID(N'dbo.ICS_SW_INDST_PRMT') AND NAME = 'INDST_ACTY_SIZE')
BEGIN
    ALTER TABLE dbo.ICS_SW_INDST_PRMT
        ADD INDST_ACTY_SIZE INT NULL
END
GO


/*************************************
 * Alter Table:  ICS_LNK_ST_CMPL_MON
 *************************************/
-- Drop Column:  PRMT_IDENT
IF EXISTS(SELECT * FROM SYS.COLUMNS WHERE OBJECT_ID = OBJECT_ID(N'dbo.ICS_LNK_ST_CMPL_MON') AND NAME = 'PRMT_IDENT')
BEGIN
    ALTER TABLE dbo.ICS_LNK_ST_CMPL_MON
        DROP COLUMN PRMT_IDENT
END
GO
-- Drop Column:  CMPL_MON_CATG_CODE
IF EXISTS(SELECT * FROM SYS.COLUMNS WHERE OBJECT_ID = OBJECT_ID(N'dbo.ICS_LNK_ST_CMPL_MON') AND NAME = 'CMPL_MON_CATG_CODE')
BEGIN
    ALTER TABLE dbo.ICS_LNK_ST_CMPL_MON
        DROP COLUMN CMPL_MON_CATG_CODE
END
GO
-- Drop Column:  CMPL_MON_DATE
IF EXISTS(SELECT * FROM SYS.COLUMNS WHERE OBJECT_ID = OBJECT_ID(N'dbo.ICS_LNK_ST_CMPL_MON') AND NAME = 'CMPL_MON_DATE')
BEGIN
    ALTER TABLE dbo.ICS_LNK_ST_CMPL_MON
        DROP COLUMN CMPL_MON_DATE
END
GO
-- Add Column:  CMPL_MON_IDENT
IF NOT EXISTS(SELECT * FROM SYS.COLUMNS WHERE OBJECT_ID = OBJECT_ID(N'dbo.ICS_LNK_ST_CMPL_MON') AND NAME = 'CMPL_MON_IDENT')
BEGIN
    ALTER TABLE dbo.ICS_LNK_ST_CMPL_MON
        ADD CMPL_MON_IDENT VARCHAR(25) NULL
END
GO


/*******************************
 * Alter Table:  ICS_PRMT_FEATR
 *  Change E:
 *******************************/
-- Add Column:  IMPAIRED_WTR_IND
IF NOT EXISTS(SELECT * FROM SYS.COLUMNS WHERE OBJECT_ID = OBJECT_ID(N'dbo.ICS_PRMT_FEATR') AND NAME = 'IMPAIRED_WTR_IND')
BEGIN
    ALTER TABLE dbo.ICS_PRMT_FEATR
        ADD IMPAIRED_WTR_IND CHAR(1) NULL
END
GO
-- Add Column:  TMDL_COMPLETED_IND
IF NOT EXISTS(SELECT * FROM SYS.COLUMNS WHERE OBJECT_ID = OBJECT_ID(N'dbo.ICS_PRMT_FEATR') AND NAME = 'TMDL_COMPLETED_IND')
BEGIN
    ALTER TABLE dbo.ICS_PRMT_FEATR
        ADD TMDL_COMPLETED_IND CHAR(1) NULL
END
GO


/***********************************
 * Alter Table:  ICS_SW_INDST_PRMT
 *  Change G:  Add new 4.1 fields
 ***********************************/
-- Add Column:  WEB_ADDR_URL
IF NOT EXISTS(SELECT * FROM SYS.COLUMNS WHERE OBJECT_ID = OBJECT_ID(N'dbo.ICS_SW_INDST_PRMT') AND NAME = 'WEB_ADDR_URL')
BEGIN
    ALTER TABLE dbo.ICS_SW_INDST_PRMT
        ADD WEB_ADDR_URL VARCHAR(100) NULL
END
GO
-- Add Column:  ACTIVITIES_EXPOSED_SW_TXT
IF NOT EXISTS(SELECT * FROM SYS.COLUMNS WHERE OBJECT_ID = OBJECT_ID(N'dbo.ICS_SW_INDST_PRMT') AND NAME = 'ACTIVITIES_EXPOSED_SW_TXT')
BEGIN
    ALTER TABLE dbo.ICS_SW_INDST_PRMT
        ADD ACTIVITIES_EXPOSED_SW_TXT VARCHAR(4000) NULL
END
GO
-- Add Column:  ASSC_POLLUTANTS_TXT
IF NOT EXISTS(SELECT * FROM SYS.COLUMNS WHERE OBJECT_ID = OBJECT_ID(N'dbo.ICS_SW_INDST_PRMT') AND NAME = 'ASSC_POLLUTANTS_TXT')
BEGIN
    ALTER TABLE dbo.ICS_SW_INDST_PRMT
        ADD ASSC_POLLUTANTS_TXT VARCHAR(4000) NULL
END
GO
-- Add Column:  CONTROL_MSR_TXT
IF NOT EXISTS(SELECT * FROM SYS.COLUMNS WHERE OBJECT_ID = OBJECT_ID(N'dbo.ICS_SW_INDST_PRMT') AND NAME = 'CONTROL_MSR_TXT')
BEGIN
    ALTER TABLE dbo.ICS_SW_INDST_PRMT
        ADD CONTROL_MSR_TXT VARCHAR(4000) NULL
END
GO
-- Add Column:  SCHD_CONTROL_MSR_TXT
IF NOT EXISTS(SELECT * FROM SYS.COLUMNS WHERE OBJECT_ID = OBJECT_ID(N'dbo.ICS_SW_INDST_PRMT') AND NAME = 'SCHD_CONTROL_MSR_TXT')
BEGIN
    ALTER TABLE dbo.ICS_SW_INDST_PRMT
        ADD SCHD_CONTROL_MSR_TXT VARCHAR(4000) NULL
END
GO
-- Add Column:  TIER_TWO_IND
IF NOT EXISTS(SELECT * FROM SYS.COLUMNS WHERE OBJECT_ID = OBJECT_ID(N'dbo.ICS_SW_INDST_PRMT') AND NAME = 'TIER_TWO_IND')
BEGIN
    ALTER TABLE dbo.ICS_SW_INDST_PRMT
        ADD TIER_TWO_IND CHAR(1) NULL
END
GO
-- Add Column:  TIER_THREE_IND
IF NOT EXISTS(SELECT * FROM SYS.COLUMNS WHERE OBJECT_ID = OBJECT_ID(N'dbo.ICS_SW_INDST_PRMT') AND NAME = 'TIER_THREE_IND')
BEGIN
    ALTER TABLE dbo.ICS_SW_INDST_PRMT
        ADD TIER_THREE_IND CHAR(1) NULL
END
GO


/*****************************************
 * Create Table:  ICS_SW_INDST_ANNUL_REP
 *****************************************/
IF NOT EXISTS(SELECT * FROM SYS.TABLES WHERE NAME = 'ICS_SW_INDST_ANNUL_REP')

CREATE TABLE [ICS_SW_INDST_ANNUL_REP] ( 
 [ICS_SW_INDST_ANNUL_REP_ID] [varchar](36) NOT NULL,
 [ICS_PAYLOAD_ID] [varchar](36) NOT NULL,
 [SRC_SYSTM_IDENT] [varchar](50) NULL,
 [TRANSACTION_TYPE] [char](1) NULL,
 [TRANSACTION_TIMESTAMP] [datetime] NULL,
 [PRMT_IDENT] [varchar](50) NOT NULL,
 [INDST_SW_ANNUL_REP_RCVD_DATE] [datetime] NOT NULL,
 [FAC_INSP_SUMM_TXT] [varchar](4000) NULL,
 [VISUAL_ASSESSMENT_SUMM_TXT] [varchar](4000) NULL,
 [NO_FURTHER_REDUCTION_SUMM_TXT] [varchar](4000) NULL,
 [CORR_ACTN_SUMM_TXT] [varchar](4000) NULL,
	[KEY_HASH] [varchar](100) NULL,
	[DATA_HASH] [varchar](100) NULL,
 CONSTRAINT [PK_SW_INDST_ANNUL_REP] PRIMARY KEY CLUSTERED 
(
	[ICS_SW_INDST_ANNUL_REP_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
-- Add Index:  IX_SW_INDS_ANNL_REP_ICS_PYL_ID
IF NOT EXISTS(SELECT * FROM DBO.SYSINDEXES WHERE ID = OBJECT_ID(N'dbo.ICS_SW_INDST_ANNUL_REP') AND NAME = 'IX_SW_INDS_ANNL_REP_ICS_PYL_ID')
    CREATE  NONCLUSTERED INDEX IX_SW_INDS_ANNL_REP_ICS_PYL_ID
        ON dbo.ICS_SW_INDST_ANNUL_REP(ICS_PAYLOAD_ID)
GO
-- Add Index:  IX_SW_IN_AN_RE_PR_ID_IN_SW_AN
IF NOT EXISTS(SELECT * FROM DBO.SYSINDEXES WHERE ID = OBJECT_ID(N'dbo.ICS_SW_INDST_ANNUL_REP') AND NAME = 'IX_SW_IN_AN_RE_PR_ID_IN_SW_AN')
    CREATE UNIQUE NONCLUSTERED INDEX IX_SW_IN_AN_RE_PR_ID_IN_SW_AN
        ON dbo.ICS_SW_INDST_ANNUL_REP(PRMT_IDENT, INDST_SW_ANNUL_REP_RCVD_DATE)
GO
-- Add Foreign Key:  FK_SW_INDST_ANNUL_REP_PAYLOAD
IF OBJECT_ID(N'dbo.FK_SW_INDST_ANNUL_REP_PAYLOAD') IS NULL
BEGIN
    ALTER TABLE dbo.ICS_SW_INDST_ANNUL_REP
        ADD CONSTRAINT FK_SW_INDST_ANNUL_REP_PAYLOAD
            FOREIGN KEY(ICS_PAYLOAD_ID)
                REFERENCES dbo.ICS_PAYLOAD(ICS_PAYLOAD_ID)
                    ON DELETE CASCADE
                    ON UPDATE NO ACTION
END
GO


/************************************
 * Alter Table:  ICS_SUBM_RESULTS
 ************************************/
-- Add Column:  INDST_SW_ANNUL_REP_RCVD_DATE
IF NOT EXISTS(SELECT * FROM SYS.COLUMNS WHERE OBJECT_ID = OBJECT_ID(N'dbo.ICS_SUBM_RESULTS') AND NAME = 'INDST_SW_ANNUL_REP_RCVD_DATE')
BEGIN
    ALTER TABLE dbo.ICS_SUBM_RESULTS
        ADD INDST_SW_ANNUL_REP_RCVD_DATE [datetime] NULL
END
GO
-- Add Column:  CMPL_MON_IDENT
IF NOT EXISTS(SELECT * FROM SYS.COLUMNS WHERE OBJECT_ID = OBJECT_ID(N'dbo.ICS_SUBM_RESULTS') AND NAME = 'CMPL_MON_IDENT')
BEGIN
    ALTER TABLE dbo.ICS_SUBM_RESULTS
        ADD CMPL_MON_IDENT[varchar](25) NULL
END
GO

-- Add Column:  CMPL_MON_IDENT
IF NOT EXISTS(SELECT * FROM SYS.COLUMNS WHERE OBJECT_ID = OBJECT_ID(N'dbo.ICS_SUBM_RESULTS') AND NAME = 'CMPL_MON_IDENT_2')
BEGIN
    ALTER TABLE dbo.ICS_SUBM_RESULTS
        ADD CMPL_MON_IDENT_2[varchar](25) NULL
END
GO

-- Drop Column:  PRMT_IDENT
--IF EXISTS(SELECT * FROM SYS.COLUMNS WHERE OBJECT_ID = OBJECT_ID(N'dbo.ICS_SUBM_RESULTS') AND NAME = 'PRMT_ISSUE_DATE')
--BEGIN
--    ALTER TABLE dbo.ICS_SUBM_RESULTS
--        DROP COLUMN PRMT_ISSUE_DATE
--END
--GO

    ------------------------------
--  v5.0 Schema Changes 09/17/2014  --
    ------------------------------

/*****************************************
 * Alter Table:  ICS_GPCF_NOTICE_OF_INTENT
 *****************************************/
IF NOT EXISTS(SELECT * FROM SYS.COLUMNS WHERE OBJECT_ID = OBJECT_ID(N'dbo.ICS_GPCF_NOTICE_OF_INTENT') AND NAME = 'FEDR_CERCLA_DSCH_IND')
BEGIN
    ALTER TABLE dbo.ICS_GPCF_NOTICE_OF_INTENT
        ADD FEDR_CERCLA_DSCH_IND CHAR(1) NULL
END
GO


/*****************************************
 * Create Table:  ICS_SUBSCTOR_CODE_PLUS_DESC
 *****************************************/
--  Create table dbo.ICS_SUBSCTOR_CODE_PLUS_DESC
IF OBJECT_ID(N'dbo.ICS_SUBSCTOR_CODE_PLUS_DESC') IS NULL
BEGIN
    CREATE TABLE dbo.ICS_SUBSCTOR_CODE_PLUS_DESC
    (
        ICS_SUBSCTOR_CODE_PLUS_DESC_ID VARCHAR(36) NOT NULL,
        ICS_GPCF_NOTICE_OF_INTENT_ID VARCHAR(36) NOT NULL,
        SUBSCTOR_CODE_PLUS_DESC VARCHAR(304) NOT NULL,
        DATA_HASH VARCHAR(100) NULL
    )
    ON [PRIMARY] 
END
GO
--- Create Primary Key, Table : dbo.ICS_SUBSCTOR_CODE_PLUS_DESC
IF OBJECT_ID(N'dbo.PK_SUBSCTOR_CODE_PLUS_DESC') IS NULL
    ALTER TABLE dbo.ICS_SUBSCTOR_CODE_PLUS_DESC
        ADD CONSTRAINT PK_SUBSCTOR_CODE_PLUS_DESC PRIMARY KEY CLUSTERED(ICS_SUBSCTOR_CODE_PLUS_DESC_ID)
GO
--- Create Index, Table : dbo.ICS_SUBSCTOR_CODE_PLUS_DESC
IF NOT EXISTS(SELECT * FROM DBO.SYSINDEXES WHERE ID = OBJECT_ID(N'dbo.ICS_SUBSCTOR_CODE_PLUS_DESC') AND NAME = 'IX_SB_CO_PL_DE_IC_GP_NT_OF_IN')
    CREATE  NONCLUSTERED INDEX IX_SB_CO_PL_DE_IC_GP_NT_OF_IN
        ON dbo.ICS_SUBSCTOR_CODE_PLUS_DESC(ICS_GPCF_NOTICE_OF_INTENT_ID)
GO
--- Create Foreign Key, Table : dbo.ICS_SUBSCTOR_CODE_PLUS_DESC: FK_SBS_COD_PLU_DES_GP_NT_OF_IN
IF OBJECT_ID(N'dbo.FK_SBS_COD_PLU_DES_GP_NT_OF_IN') IS NULL
BEGIN
    ALTER TABLE dbo.ICS_SUBSCTOR_CODE_PLUS_DESC
        ADD CONSTRAINT FK_SBS_COD_PLU_DES_GP_NT_OF_IN
            FOREIGN KEY(ICS_GPCF_NOTICE_OF_INTENT_ID)
                REFERENCES dbo.ICS_GPCF_NOTICE_OF_INTENT(ICS_GPCF_NOTICE_OF_INTENT_ID)
                    ON DELETE CASCADE
                    ON UPDATE NO ACTION
END
GO


-- Alter PRMT_IDENT to CHAR vs. orginal VARCHAR.
IF EXISTS(SELECT * FROM SYS.COLUMNS WHERE OBJECT_ID = OBJECT_ID(N'dbo.ICS_PRMT_IDENT') AND NAME = 'PRMT_IDENT')
BEGIN
    --  Remove the NOT NULL constraint.
    ALTER TABLE dbo.ICS_PRMT_IDENT ALTER COLUMN PRMT_IDENT CHAR(09) NOT NULL;
END
GO


-- Alter PRMT_IDENT to CHAR vs. orginal VARCHAR.
IF EXISTS(SELECT * FROM SYS.COLUMNS WHERE OBJECT_ID = OBJECT_ID(N'dbo.ICS_FINAL_ORDER_PRMT_IDENT') AND NAME = 'FINAL_ORDER_PRMT_IDENT')
BEGIN
    --  Remove the NOT NULL constraint.
    ALTER TABLE dbo.ICS_FINAL_ORDER_PRMT_IDENT ALTER COLUMN FINAL_ORDER_PRMT_IDENT CHAR(09) NOT NULL;
END
GO

--  Add Column:  FILE_NUM
--  Added from SQL baseline.
IF NOT EXISTS(SELECT 1 FROM SYS.COLUMNS WHERE OBJECT_ID = OBJECT_ID(N'dbo.ICS_INFRML_ENFRC_ACTN') AND NAME = 'FILE_NUM')
BEGIN

DECLARE @dynamic_sql NVARCHAR(255);
DECLARE @dynamic_parms NVARCHAR(255);

    --  Add the new column, but initially allow NULL values.
    ALTER TABLE dbo.ICS_INFRML_ENFRC_ACTN ADD FILE_NUM VARCHAR(50) NULL;

END
GO



--  Add Column:  INDST_ACTY_SIZE
--  Added from SQL baseline.
IF NOT EXISTS(SELECT 1 FROM SYS.COLUMNS WHERE OBJECT_ID = OBJECT_ID(N'dbo.ICS_SW_CNST_PRMT') AND NAME = 'INDST_ACTY_SIZE')
BEGIN

DECLARE @dynamic_sql NVARCHAR(255);
DECLARE @dynamic_parms NVARCHAR(255);

    --  Add the new column, but initially allow NULL values.
    ALTER TABLE dbo.ICS_SW_CNST_PRMT ADD INDST_ACTY_SIZE INT NULL;

END
GO


--  Add Column:  INDST_ACTY_SIZE
--  Added from SQL baseline.
IF NOT EXISTS(SELECT 1 FROM SYS.COLUMNS WHERE OBJECT_ID = OBJECT_ID(N'dbo.ICS_SWMS_4_LARGE_PRMT') AND NAME = 'INDST_ACTY_SIZE')
BEGIN

DECLARE @dynamic_sql NVARCHAR(255);
DECLARE @dynamic_parms NVARCHAR(255);

    --  Add the new column, but initially allow NULL values.
    ALTER TABLE dbo.ICS_SWMS_4_LARGE_PRMT ADD INDST_ACTY_SIZE INT NULL;

END
GO


--  Add Column:  INDST_ACTY_SIZE
--  Added from SQL baseline.
IF NOT EXISTS(SELECT 1 FROM SYS.COLUMNS WHERE OBJECT_ID = OBJECT_ID(N'dbo.ICS_SWMS_4_SMALL_PRMT') AND NAME = 'INDST_ACTY_SIZE')
BEGIN

DECLARE @dynamic_sql NVARCHAR(255);
DECLARE @dynamic_parms NVARCHAR(255);

    --  Add the new column, but initially allow NULL values.
    ALTER TABLE dbo.ICS_SWMS_4_SMALL_PRMT ADD INDST_ACTY_SIZE INT NULL;

END
GO


--  Add Column:  LOC_ADDR_CITY_CODE
--  Added from SQL baseline.
IF NOT EXISTS(SELECT 1 FROM SYS.COLUMNS WHERE OBJECT_ID = OBJECT_ID(N'dbo.ICS_UNPRMT_FAC') AND NAME = 'LOC_ADDR_CITY_CODE')
BEGIN

DECLARE @dynamic_sql NVARCHAR(255);
DECLARE @dynamic_parms NVARCHAR(255);

    --  Add the new column, but initially allow NULL values.
    ALTER TABLE dbo.ICS_UNPRMT_FAC ADD LOC_ADDR_CITY_CODE VARCHAR(12) NULL;

END
GO

--  Add Column:  LOC_ADDR_CITY_CODE
--  Added from SQL baseline.
IF NOT EXISTS(SELECT 1 FROM SYS.COLUMNS WHERE OBJECT_ID = OBJECT_ID(N'dbo.ICS_UNPRMT_FAC') AND NAME = 'LOC_ADDR_COUNTY_CODE')
BEGIN

DECLARE @dynamic_sql NVARCHAR(255);
DECLARE @dynamic_parms NVARCHAR(255);

    --  Add the new column, but initially allow NULL values.
    ALTER TABLE dbo.ICS_UNPRMT_FAC ADD LOC_ADDR_COUNTY_CODE VARCHAR(5) NULL;

END
GO