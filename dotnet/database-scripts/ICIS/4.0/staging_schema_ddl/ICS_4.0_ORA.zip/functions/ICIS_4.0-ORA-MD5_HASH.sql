CREATE OR REPLACE FUNCTION MD5_HASH (p_string IN VARCHAR2)
  RETURN VARCHAR2
  /************************************************************************************************
** ObjectName: MD5_HASH (Function)
**
** Author: Windsor Solutions, Inc. 
**
** Company Name: Windsor Solutions, Inc
**
** Description:  Returns an MD5 hash for the input string provided
**
**
** Revision History:      
** ----------------------------------------------------------------------------------------------
**  Date         Name        Description
** ----------------------------------------------------------------------------------------------
** 12/04/2012    BRensmith   Created
** 12/07/2012    BRensmith   Updated to use DBMS_CRYPTO package
**
*************************************************************************************************/

IS

e_no_input EXCEPTION;
BEGIN
	IF p_string IS NULL
	THEN
		RAISE e_no_input;
	END IF;

	RETURN TO_CHAR(DBMS_CRYPTO.HASH(TO_CLOB(p_string),DBMS_CRYPTO.HASH_MD5));

EXCEPTION
WHEN e_no_input
THEN
	RETURN NULL;
WHEN OTHERS
THEN
	RAISE;
END;
  
