--Upgrades ICIS table schema from v3.1 to v4.0 for Oracle
--Be sure to run on both the ICS_FLOW_LOCAL and ICS_FLOW_ICIS schemas
--Created by Windsor Solutions, 8/13/2012

--Step 1: Add new fields
  ALTER TABLE ics_sso_evt_rep ADD sso_evt_id NUMBER NOT NULL;
  ALTER TABLE ics_cso_evt_rep ADD cso_evt_id NUMBER NOT NULL;
  ALTER TABLE ics_sw_evt_rep ADD sw_evt_id NUMBER NOT NULL;
  
  ALTER TABLE ics_lnk_sso_evt_rep ADD sso_evt_id NUMBER NOT NULL;
  ALTER TABLE ics_lnk_cso_evt_rep ADD cso_evt_id NUMBER NOT NULL;
  ALTER TABLE ics_lnk_sw_evt_rep ADD sw_evt_id NUMBER NOT NULL;

  ALTER TABLE ics_subm_results ADD evt_id NUMBER NULL;

--Step 2: Add comments
  COMMENT ON COLUMN ics_sso_evt_rep.sso_evt_id IS 'Agency provided unique identifier for the event. Part of ICIS business key';
  COMMENT ON COLUMN ics_cso_evt_rep.cso_evt_id IS 'Agency provided unique identifier for the event. Part of ICIS business key';
  COMMENT ON COLUMN ics_sw_evt_rep.sw_evt_id IS 'Agency provided unique identifier for the event. Part of ICIS business key';
  
  COMMENT ON COLUMN ics_lnk_sso_evt_rep.sso_evt_id IS 'Agency provided unique identifier for the event.';
  COMMENT ON COLUMN ics_lnk_cso_evt_rep.cso_evt_id IS 'Agency provided unique identifier for the event.';
  COMMENT ON COLUMN ics_lnk_sw_evt_rep.sw_evt_id IS 'Agency provided unique identifier for the event.';

  COMMENT ON COLUMN ics_subm_results.evt_id IS 'CSOEventID, SSOEventID or SWEventID, depending on Submission Type';

--Step 3: Recreate Unique Indexes
  DROP INDEX AK_ICS_CSO_EVT_REP;
  CREATE UNIQUE INDEX AK_ICS_CSO_EVT_REP ON ICS_CSO_EVT_REP (PRMT_IDENT, CSO_EVT_DATE, CSO_EVT_ID);
  
  DROP INDEX AK_ICS_SSO_EVT_REP;
  CREATE UNIQUE INDEX AK_ICS_SSO_EVT_REP ON ICS_SSO_EVT_REP (PRMT_IDENT, SSO_EVT_DATE, SSO_EVT_ID);
  
  DROP INDEX AK_ICS_SW_EVT_REP;
  CREATE UNIQUE INDEX AK_ICS_SW_EVT_REP ON ICS_SW_EVT_REP (PRMT_IDENT, DATE_STRM_EVT_SMPL, SW_EVT_ID);
