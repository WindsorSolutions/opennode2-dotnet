/*************************************************************************************************
** ObjectName: ICS_V_ERRORS_BY_ERROR_TYPE
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view provides a count of errors by error type as returned by ICIS in processing reports
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 05/14/2012   Windsor      Created 
** 08/22/2012   Windsor      Added result_type_code to subquery in select list.
**
***************************************************************************************************/
CREATE OR REPLACE FORCE VIEW "ICS_V_ERRORS_BY_ERROR_TYPE" 
  ("SUBM_TYPE_NAME", "ERROR_COUNT", "RESULT_TYPE_CODE", "RESULT_CODE", "FIRST_RESULT_DESC")
  
AS

  SELECT   subm_type_name
         , COUNT(1) AS error_count
         , result_type_code
         , result_code
         , (SELECT result_desc
              FROM ics_subm_results
             WHERE result_code = rslt.result_code
               AND result_type_code = rslt.result_type_code
               AND subm_type_name = rslt.subm_type_name
               AND rownum = 1
          ) AS first_result_desc
 FROM ics_subm_results rslt
GROUP BY subm_type_name,
    result_type_code,
    result_code
ORDER BY subm_type_name,
    COUNT(1) DESC
    
    --SELECT * FROM ics_v_errors_by_error_type;