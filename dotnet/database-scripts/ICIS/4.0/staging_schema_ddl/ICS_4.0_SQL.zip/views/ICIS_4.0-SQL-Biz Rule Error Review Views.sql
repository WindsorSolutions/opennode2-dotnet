IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'ICS_V_BP_BASIC_PRMT_ERRORS') AND type = N'V')
DROP VIEW ICS_V_BP_BASIC_PRMT_ERRORS
GO
CREATE VIEW ICS_V_BP_BASIC_PRMT_ERRORS
AS
/*************************************************************************************************
** ObjectName: ICS_V_BP_BASIC_PRMT_ERRORS
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  Returns the Basic Permit records that return ICIS business rule violations
**
** Revision History:
** ------------------------------------------------------------------------------------------------
** Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 10/29/2012   Windsor      Created 
**
***************************************************************************************************/
SELECT ics_basic_prmt.transaction_type
     , ics_basic_prmt.prmt_ident
     , ics_basic_prmt.prmt_issue_date
     , ics_basic_prmt.prmt_effective_date
     , ics_basic_prmt.prmt_expr_date
     , ics_subm_results.result_code
     , ics_subm_results.result_desc
FROM ics_basic_prmt as ics_basic_prmt 
  JOIN ics_subm_results as ics_subm_results
  on ics_basic_prmt.prmt_ident = ics_subm_results.prmt_ident 
WHERE ics_subm_results.result_type_code = 'Error'
  AND ics_subm_results.subm_type_name = 'BasicPermitSubmission';
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'ICS_V_CM_CMPL_MON_ERRORS') AND type = N'V')
DROP VIEW ICS_V_CM_CMPL_MON_ERRORS
GO
CREATE VIEW ICS_V_CM_CMPL_MON_ERRORS
AS
/*************************************************************************************************
** ObjectName: ICS_V_CM_CMPL_MON_ERRORS
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  Returns the Compliance Monitoring records that return ICIS business rule violations
**
** Revision History:
** ------------------------------------------------------------------------------------------------
** Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 10/29/2012   Windsor     Created 
**
***************************************************************************************************/

SELECT ics_cmpl_mon.prmt_ident
     , ics_cmpl_mon.cmpl_mon_catg_code
     , ics_cmpl_mon.cmpl_mon_date
     , result_code
     , result_desc
  FROM ics_cmpl_mon as ics_cmpl_mon
  JOIN ics_subm_results as ics_subm_results 
    ON ics_subm_results.prmt_ident = ics_cmpl_mon.prmt_ident
   AND ics_subm_results.cmpl_mon_catg_code = ics_cmpl_mon.cmpl_mon_catg_code
   AND ics_subm_results.cmpl_mon_date = ics_cmpl_mon.cmpl_mon_date
 WHERE ics_subm_results.result_type_code IN ('Error','Warning')
   AND ics_subm_results.subm_type_name = 'ComplianceMonitoringSubmission';
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'ICS_V_CS_CMPL_SCHD_ERRORS') AND type = N'V')
DROP VIEW ICS_V_CS_CMPL_SCHD_ERRORS
GO
CREATE VIEW ICS_V_CS_CMPL_SCHD_ERRORS
AS
/*************************************************************************************************
** ObjectName: ICS_V_CS_CMPL_SCHD_ERRORS
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  Returns the Compliance Schedule records that have ICIS business rule violations
**
** Revision History:
** ------------------------------------------------------------------------------------------------
** Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 10/29/2012   Windsor      Created 
**
***************************************************************************************************/

SELECT ics_cmpl_schd.transaction_type
     , ics_cmpl_schd.prmt_ident
     , ics_cmpl_schd.enfrc_actn_ident
     , ics_cmpl_schd.final_order_ident
     , ics_cmpl_schd.cmpl_schd_num
     , ics_cmpl_schd.schd_desc_code
     , ics_subm_results.result_code
     , ics_subm_results.result_desc
FROM ics_cmpl_schd
  JOIN ics_subm_results
    ON ics_cmpl_schd.prmt_ident = ics_subm_results.prmt_ident 
   AND ics_cmpl_schd.enfrc_actn_ident = ics_subm_results.enfrc_actn_ident
   AND ics_cmpl_schd.final_order_ident = ics_subm_results.final_order_ident
   AND ics_cmpl_schd.cmpl_schd_num = ics_subm_results.cmpl_schd_num
   AND ics_cmpl_schd.enfrc_actn_ident = ics_subm_results.enfrc_actn_ident
 WHERE ics_subm_results.result_type_code IN ('Error','Warning')
   AND ics_subm_results.subm_type_name = 'ComplianceScheduleSubmission';
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'ICS_V_DM_DMR_ERRORS') AND type = N'V')
DROP VIEW ICS_V_DM_DMR_ERRORS
GO
CREATE VIEW ICS_V_DM_DMR_ERRORS
AS
/*************************************************************************************************
** ObjectName: ICS_V_DM_DMR_ERRORS
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  Returns the DMR records that return ICIS business rule violations
**
** Revision History:
** ------------------------------------------------------------------------------------------------
** Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 10/29/2012   Windsor      Created 
**
***************************************************************************************************/
SELECT ics_subm_results.result_code
     , ics_subm_results.prmt_ident
     , ics_subm_results.prmt_featr_ident + ics_subm_results.lmt_set_designator limit_set
     , ics_rep_param.param_code 
     , ics_rep_param.mon_site_desc_code mon_loc
     , ics_rep_param.lmt_season_num season
     , ics_subm_results.mon_period_end_date
     , ics_dsch_mon_rep.dmr_no_dsch_ind as NODI
     , (SELECT TOP 1 num_rep_no_dsch_ind + num_cond_qty FROM ics_num_rep WHERE num_rep_code = 'Q1' AND ics_rep_param_id = ics_rep_param.ics_rep_param_id) Q1
     , (SELECT TOP 1 num_rep_no_dsch_ind + num_cond_qty FROM ics_num_rep WHERE num_rep_code = 'Q2' AND ics_rep_param_id = ics_rep_param.ics_rep_param_id) Q2
     , qty_num_rep_unit_meas_code QTY_UNIT
     , (SELECT TOP 1 num_rep_no_dsch_ind + num_cond_qty FROM ics_num_rep WHERE num_rep_code = 'C1' AND ics_rep_param_id = ics_rep_param.ics_rep_param_id) C1
     , (SELECT TOP 1 num_rep_no_dsch_ind + num_cond_qty FROM ics_num_rep WHERE num_rep_code = 'C2' AND ics_rep_param_id = ics_rep_param.ics_rep_param_id) C2
     , (SELECT TOP 1 num_rep_no_dsch_ind + num_cond_qty FROM ics_num_rep WHERE num_rep_code = 'C3' AND ics_rep_param_id = ics_rep_param.ics_rep_param_id) C3
     , concen_num_rep_unit_meas_code CNC_UNIT
     , result_desc
  FROM ics_dsch_mon_rep
    LEFT JOIN ics_rep_param
    ON ics_rep_param.ics_dsch_mon_rep_id = ics_dsch_mon_rep.ics_dsch_mon_rep_id
    JOIN ics_subm_results 
      ON ics_subm_results.prmt_ident = ics_dsch_mon_rep.prmt_ident
     AND ics_subm_results.prmt_featr_ident = ics_dsch_mon_rep.prmt_featr_ident
     AND ics_subm_results.lmt_set_designator = ics_dsch_mon_rep.lmt_set_designator
     AND ics_subm_results.mon_period_end_date = ics_dsch_mon_rep.mon_period_end_date
     AND ics_subm_results.param_code = ics_rep_param.param_code
     AND ics_subm_results.mon_site_desc_code = ics_rep_param.mon_site_desc_code
     AND ics_subm_results.lmt_season_num = ics_rep_param.lmt_season_num
 WHERE ics_subm_results.result_type_code IN ('Error','Warning')
   AND ics_subm_results.subm_type_name = 'DischargeMonitoringReportSubmission';
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'ICS_V_FA_FRML_ENFRC_ACTN_ERR') AND type = N'V')
DROP VIEW ICS_V_FA_FRML_ENFRC_ACTN_ERR
GO
CREATE VIEW ICS_V_FA_FRML_ENFRC_ACTN_ERR
AS
/*************************************************************************************************
** ObjectName: ICS_V_FA_FRML_ENFRC_ACTN_ERR
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  Returns the Formal Enforcement Action records that have ICIS business rule violations
**
** Revision History:
** ------------------------------------------------------------------------------------------------
** Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 10/29/2012   Windsor      Created 
**
***************************************************************************************************/
SELECT ics_frml_enfrc_actn.transaction_type
     , ics_frml_enfrc_actn.enfrc_actn_ident
     , ics_frml_enfrc_actn.forum
     , ics_final_order.final_order_ident
     , ics_final_order.final_order_type_code
     , ics_subm_results.result_code
     , ics_subm_results.result_desc
FROM ics_frml_enfrc_actn
  JOIN ics_subm_results 
    ON ics_frml_enfrc_actn.enfrc_actn_ident = ics_subm_results.enfrc_actn_ident
  LEFT JOIN ics_final_order
         ON ics_final_order.ics_frml_enfrc_actn_id = ics_frml_enfrc_actn.ics_frml_enfrc_actn_id
WHERE ics_subm_results.result_type_code IN ('Error','Warning')
  AND ics_subm_results.subm_type_name = 'FormalEnforcementActionSubmission';
GO


IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'ICS_V_GP_GNRL_PRMT_ERRORS') AND type = N'V')
DROP VIEW ICS_V_GP_GNRL_PRMT_ERRORS
GO
CREATE VIEW ICS_V_GP_GNRL_PRMT_ERRORS
AS
/*************************************************************************************************
** ObjectName: ICS_V_GP_GNRL_PRMT_ERRORS
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  Returns the General Permit records that have ICIS business rule violations
**
** Revision History:
** ------------------------------------------------------------------------------------------------
** Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 10/29/2012   Windsor      Created 
**
***************************************************************************************************/

SELECT ics_gnrl_prmt.transaction_type
     , ics_gnrl_prmt.prmt_ident
     , ics_gnrl_prmt.prmt_issue_date
     , ics_gnrl_prmt.prmt_effective_date
     , ics_gnrl_prmt.prmt_expr_date
     , ics_subm_results.result_code
     , ics_subm_results.result_desc
FROM ics_gnrl_prmt 
  JOIN ics_subm_results
    ON ics_gnrl_prmt.prmt_ident = ics_subm_results.prmt_ident 
WHERE ics_subm_results.result_type_code = 'Error'
  AND ics_subm_results.subm_type_name = 'GeneralPermitSubmission';
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'ICS_V_IA_INF_ENFRC_ACTN') AND type = N'V')
DROP VIEW ICS_V_IA_INF_ENFRC_ACTN
GO
CREATE VIEW ICS_V_IA_INF_ENFRC_ACTN
AS
/*************************************************************************************************
** ObjectName: ICS_V_IA_INF_ENFRC_ACTN
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  Returns the Informal Enforcement Action records that return ICIS business rule violations
**
** Revision History:
** ------------------------------------------------------------------------------------------------
** Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 10/29/2012   Windsor      Created 
**
***************************************************************************************************/
SELECT ics_infrml_enfrc_actn.transaction_type
     , ics_infrml_enfrc_actn.enfrc_actn_ident
     , ics_infrml_enfrc_actn.enfrc_actn_type_code
     , ics_subm_results.result_code
     , ics_subm_results.result_desc
FROM ics_infrml_enfrc_actn  
  JOIN ics_subm_results 
    ON ics_infrml_enfrc_actn.enfrc_actn_ident = ics_subm_results.enfrc_actn_ident
WHERE ics_subm_results.result_type_code IN ('Error','Warning')
  AND ics_subm_results.subm_type_name = 'InformalEnforcementActionSubmission';
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'ICS_V_LS_LIMIT_SET_ERRORS') AND type = N'V')
DROP VIEW ICS_V_LS_LIMIT_SET_ERRORS
GO
CREATE VIEW ICS_V_LS_LIMIT_SET_ERRORS
AS
/*************************************************************************************************
** ObjectName: ICS_V_LS_LIMIT_SET_ERRORS
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  Returns the Limit Set records that return ICIS business rule violations
**
** Revision History:
** ------------------------------------------------------------------------------------------------
** Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 10/29/2012   Windsor     Created 
**
***************************************************************************************************/
SELECT ics_lmt_set.prmt_ident
     , ics_lmt_set.prmt_featr_ident
     , ics_lmt_set.lmt_set_designator
     , ics_lmt_set_schd.initial_mon_date
     , ics_lmt_set_schd.initial_dmr_due_date
     , result_code
     , result_desc
  FROM ics_lmt_set as ics_lmt_set
    JOIN ics_subm_results as ics_subm_results 
      ON ics_subm_results.prmt_ident = ics_lmt_set.prmt_ident
     AND ics_subm_results.prmt_featr_ident = ics_lmt_set.prmt_featr_ident
     AND ics_subm_results.lmt_set_designator = ics_lmt_set.lmt_set_designator
    LEFT JOIN ics_lmt_set_schd as ics_lmt_set_schd
      ON ics_lmt_set_schd.ics_lmt_set_id = ics_lmt_set.ics_lmt_set_id
 WHERE ics_subm_results.result_type_code IN ('Error','Warning')
   AND ics_subm_results.subm_type_name = 'LimitSetSubmission';
GO


IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'ICS_V_MGP_MSTR_GNRL_PRMT_ERR') AND type = N'V')
DROP VIEW ICS_V_MGP_MSTR_GNRL_PRMT_ERR
GO
CREATE VIEW ICS_V_MGP_MSTR_GNRL_PRMT_ERR
AS
/*************************************************************************************************
** ObjectName: ICS_V_MGP_MSTR_GNRL_PRMT_ERR
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  Returns the Master General Permit records that have ICIS business rule violations
**
** Revision History:
** ------------------------------------------------------------------------------------------------
** Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 10/29/2012   Windsor      Created 
**
***************************************************************************************************/
SELECT ics_gnrl_prmt.transaction_type
     , ics_gnrl_prmt.prmt_ident
     , ics_gnrl_prmt.prmt_issue_date
     , ics_gnrl_prmt.prmt_effective_date
     , ics_gnrl_prmt.prmt_expr_date
     , ics_subm_results.result_code
     , ics_subm_results.result_desc
FROM ics_gnrl_prmt 
  JOIN ics_subm_results
    ON ics_gnrl_prmt.prmt_ident = ics_subm_results.prmt_ident 
WHERE ics_subm_results.result_type_code = 'Error'
  AND ics_subm_results.subm_type_name = 'MasterGeneralPermitSubmission';
GO


IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'ICS_V_NC_NARR_COND_SCHD_ERRORS') AND type = N'V')
DROP VIEW ICS_V_NC_NARR_COND_SCHD_ERRORS
GO
CREATE VIEW ICS_V_NC_NARR_COND_SCHD_ERRORS
AS
/*************************************************************************************************
** ObjectName: ICS_V_NC_NARR_COND_SCHD_ERRORS
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  Returns the Narrative Condition Schedule records that return ICIS business rule violations
**
** Revision History:
** ------------------------------------------------------------------------------------------------
** Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 10/29/2012   Windsor     Created 
**
***************************************************************************************************/
SELECT ics_narr_cond_schd.prmt_ident
     , ics_narr_cond_schd.narr_cond_num
     , ics_narr_cond_schd.narr_cond_code
     , result_code
     , result_desc
  FROM ics_narr_cond_schd
    JOIN ics_subm_results 
      ON ics_subm_results.prmt_ident = ics_narr_cond_schd.prmt_ident
     AND ics_subm_results.narr_cond_num = ics_narr_cond_schd.narr_cond_num
 WHERE ics_subm_results.result_type_code = 'Error'
   AND ics_subm_results.subm_type_name = 'NarrativeConditionScheduleSubmission';
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'ICS_V_PF_PRMT_FEATR_ERRORS') AND type = N'V')
DROP VIEW ICS_V_PF_PRMT_FEATR_ERRORS
GO
CREATE VIEW ICS_V_PF_PRMT_FEATR_ERRORS
AS
/*************************************************************************************************
** ObjectName: ICS_V_PF_PRMT_FEATR_ERRORS
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  Returns the Permitted Feature records that return ICIS business rule violations
**
** Revision History:
** ------------------------------------------------------------------------------------------------
** Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 10/29/2012   Windsor      Created 
**
***************************************************************************************************/

SELECT ics_prmt_featr.transaction_type
     , ics_prmt_featr.prmt_ident
     , ics_prmt_featr.prmt_featr_ident
     , ics_subm_results.result_code
     , ics_subm_results.result_desc
FROM ics_prmt_featr as ics_prmt_featr 
  JOIN ics_subm_results as ics_subm_results
    ON ics_prmt_featr.prmt_ident = ics_subm_results.prmt_ident 
   AND ics_prmt_featr.prmt_featr_ident = ics_subm_results.prmt_featr_ident
WHERE ics_subm_results.result_type_code = 'Error'
  AND ics_subm_results.subm_type_name = 'PermittedFeatureSubmission';
GO


IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'ICS_V_PL_PARAM_LMT_ERRORS') AND type = N'V')
DROP VIEW ICS_V_PL_PARAM_LMT_ERRORS
GO
CREATE VIEW ICS_V_PL_PARAM_LMT_ERRORS
AS
/*************************************************************************************************
** ObjectName: ICS_V_PL_PARAM_LMT_ERRORS
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  Returns the Parameter Limit records that return ICIS business rule violations
**
** Revision History:
** ------------------------------------------------------------------------------------------------
** Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 10/29/2012   Windsor      Created 
** 11/01/2012   Windsor      Fix typo in subm_type_name
**
***************************************************************************************************/

SELECT ics_subm_results.result_code
     , ics_subm_results.prmt_ident
     , ics_subm_results.prmt_featr_ident
     , ics_subm_results.lmt_set_designator
     , ics_subm_results.param_code
     , ics_subm_results.mon_site_desc_code
     , ics_subm_results.lmt_season_num
     , ics_lmt.lmt_start_date
     , ics_lmt.lmt_end_date
     , ISNULL((SELECT num_cond_qualifier + num_cond_qty + ' ' + num_cond_stat_base_code FROM ics_num_cond WHERE num_cond_txt = 'Q1' AND ics_lmt_id = ics_lmt.ics_lmt_id),'*****') Q1
     , ISNULL((SELECT num_cond_qualifier + num_cond_qty + ' ' + num_cond_stat_base_code FROM ics_num_cond WHERE num_cond_txt = 'Q2' AND ics_lmt_id = ics_lmt.ics_lmt_id),'*****') Q2
     , qty_num_cond_unit_meas_code QTY_UNIT
     , ISNULL((SELECT num_cond_qualifier + num_cond_qty + ' ' + num_cond_stat_base_code FROM ics_num_cond WHERE num_cond_txt = 'C1' AND ics_lmt_id = ics_lmt.ics_lmt_id),'*****') C1
     , ISNULL((SELECT num_cond_qualifier + num_cond_qty + ' ' + num_cond_stat_base_code FROM ics_num_cond WHERE num_cond_txt = 'C2' AND ics_lmt_id = ics_lmt.ics_lmt_id),'*****') C2
     , ISNULL((SELECT num_cond_qualifier + num_cond_qty + ' ' + num_cond_stat_base_code FROM ics_num_cond WHERE num_cond_txt = 'C3' AND ics_lmt_id = ics_lmt.ics_lmt_id),'*****') C3
     , concen_num_cond_unit_meas_code CNC_UNIT
     , result_desc
  FROM ics_param_lmts ics_param_lmts
  JOIN ics_subm_results ics_subm_results
    ON ics_subm_results.prmt_ident = ics_param_lmts.prmt_ident
   AND ics_subm_results.prmt_featr_ident = ics_param_lmts.prmt_featr_ident
   AND ics_subm_results.lmt_set_designator = ics_param_lmts.lmt_set_designator
   AND ics_subm_results.param_code = ics_param_lmts.param_code
   AND ics_subm_results.mon_site_desc_code = ics_param_lmts.mon_site_desc_code
   AND ics_subm_results.lmt_season_num = ics_param_lmts.lmt_season_num
  LEFT JOIN ics_lmt ics_lmt
    ON ics_lmt.ics_param_lmts_id = ics_param_lmts.ics_param_lmts_id
 WHERE ics_subm_results.result_type_code IN ('Error','Warning')
   AND ics_subm_results.subm_type_name = 'ParameterLimitsSubmission';
GO


IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'ICS_V_PT_PRMT_REISSU_ERRORS') AND type = N'V')
DROP VIEW ICS_V_PT_PRMT_REISSU_ERRORS
GO
CREATE VIEW ICS_V_PT_PRMT_REISSU_ERRORS
AS
/*************************************************************************************************
** ObjectName: ICS_V_PT_PRMT_REISSU_ERRORS
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  Returns the Permit Reissuance records that have ICIS business rule violations
**
** Revision History:
** ------------------------------------------------------------------------------------------------
** Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 10/29/2012   Windsor      Created 
**
***************************************************************************************************/
SELECT ics_prmt_reissu.prmt_ident
     , ics_prmt_reissu.prmt_issue_date
     , ics_prmt_reissu.prmt_effective_date
     , ics_prmt_reissu.prmt_expr_date
     , ics_subm_results.result_code
     , ics_subm_results.result_desc
  FROM ics_prmt_reissu
    JOIN ics_subm_results 
      ON ics_subm_results.prmt_ident = ics_prmt_reissu.prmt_ident
 WHERE ics_subm_results.result_type_code IN ('Error','Warning')
   AND ics_subm_results.subm_type_name = 'PermitReissuanceSubmission';
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'ICS_V_PT_PRMT_TERM_ERRORS') AND type = N'V')
DROP VIEW ICS_V_PT_PRMT_TERM_ERRORS
GO
CREATE VIEW ICS_V_PT_PRMT_TERM_ERRORS
AS
/*************************************************************************************************
** ObjectName: ICS_V_PT_PRMT_TERM_ERRORS
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  Returns the Permit Termination records that have ICIS business rule violations
**
** Revision History:
** ------------------------------------------------------------------------------------------------
** Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 10/18/2012   Windsor      Created 
**
***************************************************************************************************/

SELECT ics_prmt_term.prmt_ident
     , ics_prmt_term.prmt_term_date
     , ics_subm_results.result_code
     , ics_subm_results.result_desc
  FROM ics_prmt_term
    JOIN ics_subm_results 
      ON ics_subm_results.prmt_ident = ics_prmt_term.prmt_ident
 WHERE ics_subm_results.result_type_code IN ('Error','Warning')
  AND ics_subm_results.subm_type_name = 'PermitTerminationSubmission';
GO


IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'ICS_V_PT_PRMT_TRACK_EVT_ERRORS') AND type = N'V')
DROP VIEW ICS_V_PT_PRMT_TRACK_EVT_ERRORS
GO
CREATE VIEW ICS_V_PT_PRMT_TRACK_EVT_ERRORS
AS
/*************************************************************************************************
** ObjectName: ICS_V_PT_PRMT_TRACK_EVT_ERRORS
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  Returns the Permit Tracking Event records that have ICIS business rule violations
**
** Revision History:
** ------------------------------------------------------------------------------------------------
** Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 10/29/2012   Windsor      Created 
**
***************************************************************************************************/
SELECT ics_prmt_track_evt.prmt_ident
     , ics_prmt_track_evt.prmt_track_evt_code
     , ics_prmt_track_evt.prmt_track_evt_date
     , ics_subm_results.result_code
     , ics_subm_results.result_desc
  FROM ics_prmt_track_evt
  JOIN ics_subm_results 
    ON ics_subm_results.prmt_ident = ics_prmt_track_evt.prmt_ident
   AND ics_subm_results.prmt_track_evt_code = ics_prmt_track_evt.prmt_track_evt_code
   AND ics_subm_results.prmt_track_evt_date = ics_prmt_track_evt.prmt_track_evt_date
 WHERE ics_subm_results.result_type_code IN ('Error','Warning')
   AND ics_subm_results.subm_type_name = 'PermitTrackingEventSubmission';
GO