--Upgrades ICIS table schema from v3.1 to v4.0 for SQL Server
--Be sure to run on both the ICS_FLOW_LOCAL and ICS_FLOW_ICIS databases
--Created by Windsor Solutions, 8/13/2012

--Step 1: Add new fields
	ALTER TABLE ics_sso_evt_rep ADD sso_evt_id INT NOT NULL;
	ALTER TABLE ics_cso_evt_rep ADD cso_evt_id INT NOT NULL;
	ALTER TABLE ics_sw_evt_rep ADD sw_evt_id INT NOT NULL;

	ALTER TABLE ics_lnk_sso_evt_rep ADD sso_evt_id INT NOT NULL;
	ALTER TABLE ics_lnk_cso_evt_rep ADD cso_evt_id INT NOT NULL;
	ALTER TABLE ics_lnk_sw_evt_rep ADD sw_evt_id INT NOT NULL;

	ALTER TABLE ics_subm_results ADD evt_id INT NULL;

--Step 2: Add extended properties
	EXEC sys.sp_addextendedproperty @name=N'MS_Description', 
		@value=N'Agency provided unique identifier for the event. Part of ICIS business key.', 
		@level0type=N'SCHEMA',@level0name=N'dbo', 
		@level1type=N'TABLE',@level1name=N'ics_sso_evt_rep', 
		@level2type=N'COLUMN',@level2name=N'sso_evt_id'
	GO

	EXEC sys.sp_addextendedproperty @name=N'MS_Description', 
		@value=N'Agency provided unique identifier for the event. Part of ICIS business key.', 
		@level0type=N'SCHEMA',@level0name=N'dbo', 
		@level1type=N'TABLE',@level1name=N'ics_cso_evt_rep', 
		@level2type=N'COLUMN',@level2name=N'cso_evt_id'
	GO

	EXEC sys.sp_addextendedproperty @name=N'MS_Description', 
		@value=N'Agency provided unique identifier for the event. Part of ICIS business key.', 
		@level0type=N'SCHEMA',@level0name=N'dbo', 
		@level1type=N'TABLE',@level1name=N'ics_sw_evt_rep', 
		@level2type=N'COLUMN',@level2name=N'sw_evt_id'
	GO  

	EXEC sys.sp_addextendedproperty @name=N'MS_Description', 
		@value=N'Agency provided unique identifier for the event.', 
		@level0type=N'SCHEMA',@level0name=N'dbo', 
		@level1type=N'TABLE',@level1name=N'ics_lnk_sso_evt_rep', 
		@level2type=N'COLUMN',@level2name=N'sso_evt_id'
	GO

	EXEC sys.sp_addextendedproperty @name=N'MS_Description', 
		@value=N'Agency provided unique identifier for the event.', 
		@level0type=N'SCHEMA',@level0name=N'dbo', 
		@level1type=N'TABLE',@level1name=N'ics_lnk_cso_evt_rep', 
		@level2type=N'COLUMN',@level2name=N'cso_evt_id'
	GO

	EXEC sys.sp_addextendedproperty @name=N'MS_Description', 
		@value=N'Agency provided unique identifier for the event.', 
		@level0type=N'SCHEMA',@level0name=N'dbo', 
		@level1type=N'TABLE',@level1name=N'ics_lnk_sw_evt_rep', 
		@level2type=N'COLUMN',@level2name=N'sw_evt_id'
	GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', 
		@value=N'CSOEventID, SSOEventID or SWEventID, depending on Submission Type.', 
		@level0type=N'SCHEMA',@level0name=N'dbo', 
		@level1type=N'TABLE',@level1name=N'ics_subm_results', 
		@level2type=N'COLUMN',@level2name=N'evt_id'
	GO

--Step 3: Recreate Unique Indexes
	DROP INDEX ICS_CSO_EVT_REP.AK_ICS_CSO_EVT_REP;
	CREATE UNIQUE INDEX AK_ICS_CSO_EVT_REP ON ICS_CSO_EVT_REP (PRMT_IDENT, CSO_EVT_DATE, CSO_EVT_ID) ON [PRIMARY];

	DROP INDEX ICS_SSO_EVT_REP.AK_ICS_SSO_EVT_REP;
	CREATE UNIQUE INDEX AK_ICS_SSO_EVT_REP ON ICS_SSO_EVT_REP (PRMT_IDENT, SSO_EVT_DATE, SSO_EVT_ID) ON [PRIMARY];

	DROP INDEX ICS_SW_EVT_REP.AK_ICS_SW_EVT_REP;
	CREATE UNIQUE INDEX AK_ICS_SW_EVT_REP ON ICS_SW_EVT_REP (PRMT_IDENT, DATE_STRM_EVT_SMPL, SW_EVT_ID) ON [PRIMARY];
