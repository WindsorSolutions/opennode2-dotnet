DROP VIEW IF EXISTS ICS_V_ANML_TYPE_HIB;
CREATE VIEW ICS_V_ANML_TYPE_HIB AS

/*************************************************************************************************
** ObjectName: ics_v_anml_type_hib
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view is required by the Java ICIS-NPDES plugin for proper serialization of
**               staging table data to XML via the Hibernate framework. This view is not needed for
**               .NET OpenNode2 implementations.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 9/10/2012     Windsor     Created 
**
***************************************************************************************************/
SELECT ICS_ANML_TYPE_ID as ICS_REP_ANML_TYPE_ID
  , null as ICS_CAFO_ANNUL_REP_ID
  , ICS_CAFO_PRMT_ID
  , ICS_CAFO_INSP_ID
  , ANML_TYPE_CODE
  , OTHR_ANML_TYPE_NAME
  , TTL_NUM_EACH_LVSTCK
  , OPEN_CONFINEMNT_CNT
  , HOUSD_UNDR_ROOF_CONFINEMNT_CNT
  , DATA_HASH
FROM ICS_ANML_TYPE;