DELIMITER $$

DROP PROCEDURE IF EXISTS `ics_data_prep_shell` $$
CREATE PROCEDURE `ics_data_prep_shell`(OUT `p_ics_subm_track_id` CHAR(50))
main:BEGIN

    /* 
    * Delare the variable to to hold the newly created row in 
    * ics_subm_track associated with the new workflow
    */
  	DECLARE v_ics_subm_track_id   VARCHAR(50); 
	DECLARE v_error_message       VARCHAR(2048);
   DECLARE v_error_number        INT;
   DECLARE v_process             VARCHAR(30);
   DECLARE v_marker              VARCHAR(255);   
   -- e_return              EXCEPTION;
   DECLARE v_workflow_cntr       INT;

   DECLARE EXIT HANDLER FOR SQLEXCEPTION
      BEGIN
         CALL ics_etl_log_sp
            (v_sp_name          -- pi_sp_name
            ,v_marker           -- pi_marker
            ,NULL               -- pi_tgt_tbl
            ,NULL               -- pi_src_tbl
            ,v_startdtm         -- pi_startdtm
            ,NOW()              -- pi_enddtm
            ,'FAILED'           -- pi_process
            ,-1);               -- pi_value
         COMMIT;
      END;

	SET v_process := 'ICS_DATA_PREP_MASTER';

-- Look for any pending statuses
	SELECT COUNT(1)
	INTO v_workflow_cntr
	FROM ICS_SUBM_TRACK	
	WHERE workflow_stat = 'Pending'; 


-- ok we are good continue
	IF v_workflow_cntr > 0 THEN
	 	SET p_ics_subm_track_id := null;
		LEAVE main;
	END IF;

-- get a GUID for the ID
	SELECT uuid()
	INTO v_ics_subm_track_id ;
	
   INSERT INTO ICS_SUBM_TRACK 
      ( ICS_SUBM_TRACK_ID
       , WORKFLOW_STAT
       , WORKFLOW_STAT_MESSAGE) 
   VALUES
      ( v_ics_subm_track_id
       , 'Pending'
       , 'ETL begun');	
       
 -- set output variable to our Transaction ID      
 SET p_ics_subm_track_id = CAST(v_ics_subm_track_id AS CHAR(36));


  
 -- We would call the ETL here...
   SET v_process := 'ICS_ETL';
   
 -- CALL ETL_PROCEDURE();
 
 -- Update the workflow record to track completion of ETL date/time.
   UPDATE ICS_SUBM_TRACK 
     SET ETL_CMPL_DATE_TIME = SYSDATE() 
       , WORKFLOW_STAT_MESSAGE = 'ETL Completed | Begin Change Processing'
   WHERE ICS_SUBM_TRACK_ID = v_ics_subm_track_id;      

 /* 
  *  Call the stored procedure to compare data changes between LOCAL and ICIS and set
  *  transaction codes for bundling and submission to an exchange partner via OPENNODE.
  */

   SET v_process = 'ICS_CHANGE_DETECTION';
   SET v_marker = 'CALL ics_change_detection';
   CALL ics_change_detection(v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err; 
   END IF;
  --


 /* 
  *  Update the workflow record to track completion of change detection date/time.
  */
 UPDATE ICS_SUBM_TRACK 
    SET det_change_cmpl_date_time = SYSDATE() 
       , WORKFLOW_STAT_MESSAGE = 'Change Processing Completed'
  WHERE ICS_SUBM_TRACK_ID = v_ics_subm_track_id;

  /* 
 *  Add any additional SQL logic required after the change detection process completes.
 *  Note this work will still occur within the named transaction and will be subject to
 *  the current transaction processing workflow.  Any runtime failures here will cause
 *  all pending data changes to rollback to the initial data state before this process
 *  was initiated.
 */
 --  Add additional database processing here if needed...
  
  COMMIT;
END $$

DELIMITER ;