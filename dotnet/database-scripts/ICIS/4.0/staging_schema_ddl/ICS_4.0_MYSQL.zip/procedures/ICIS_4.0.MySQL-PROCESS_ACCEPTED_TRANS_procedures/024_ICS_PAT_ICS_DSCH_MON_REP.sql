USE ga_ics_flow_local;
DROP PROCEDURE IF EXISTS ics_pat_ics_dsch_mon_rep;
CREATE PROCEDURE ics_pat_ics_dsch_mon_rep
   (IN  pi_transaction_id  VARCHAR(40)
   ,OUT po_status INT
   ,OUT po_errm   VARCHAR(255))
BEGIN
/******************************************************************************
** Object Name: ics_pat_ics_dsch_mon_rep
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  1) Process ICS_DSCH_MON_REP
**                  called by: ics_process_accepted_trans
**
** Revision History:
** ----------------------------------------------------------------------------
**  Date         Name        Description
** ----------------------------------------------------------------------------
** 20121102      JenGo       Converted from Oracle to MySQL.
**                           Modularized SP, added logging and error-handling
**                           called by: ICS_PROCESS_ACCEPTED_TRANS
** 20121106      JenGo       Modified DELETE FROM ga_ics_flow_icis.ICS_BASIC_PRMT
**                           MySQL errors out when the table being deleted is 
**                           used in the subquery.  To get around this either
**                           create a temp table or enclose the subquery in an
**                           inline view.  
*******************************************************************************/
   DECLARE v_startdtm
          ,v_enddtm     DATETIME;
   DECLARE v_sp_name    VARCHAR(64)  DEFAULT 'ics_pat_ics_dsch_mon_rep';
   DECLARE v_errstat    INT DEFAULT 1;
   DECLARE v_errm       VARCHAR(255);
   DECLARE v_marker     VARCHAR(255);
   --
   DECLARE EXIT HANDLER FOR SQLEXCEPTION
      BEGIN  
         ROLLBACK;
         SET po_status = -1;
         SET po_errm   = v_marker;
         CALL ics_etl_log_sp    
            (v_sp_name          -- pi_sp_name
            ,v_marker           -- pi_marker
            ,NULL               -- pi_tgt_tbl
            ,NULL               -- pi_src_tbl
            ,v_startdtm         -- pi_startdtm
            ,NOW()              -- pi_enddtm
            ,'FAILED'           -- pi_process
            ,-1);               -- pi_value
         COMMIT;
      END;
   --
   SET v_startdtm = NOW();
-- Remove any old records for ICS_DSCH_MON_REP
-- /ICS_DSCH_MON_REP/ICS_LAND_APPL_SITE/ICS_CROP_TYPES_HARVESTED
SET v_marker = 'DELETE FROM -- /ICS_DSCH_MON_REP/ICS_LAND_APPL_SITE/ICS_CROP_TYPES_HARVESTED'; 
DELETE
  FROM ga_ics_flow_icis.ICS_CROP_TYPES_HARVESTED
 WHERE ICS_CROP_TYPES_HARVESTED.ICS_LAND_APPL_SITE_ID IN
          (SELECT ICS_LAND_APPL_SITE.ICS_LAND_APPL_SITE_ID
             FROM ga_ics_flow_icis.ICS_DSCH_MON_REP
                 LEFT JOIN ICS_SUBM_RESULTS ON ICS_SUBM_RESULTS.KEY_HASH = ICS_DSCH_MON_REP.KEY_HASH 
                  JOIN ga_ics_flow_icis.ICS_LAND_APPL_SITE ON ICS_LAND_APPL_SITE.ICS_DSCH_MON_REP_ID = ICS_DSCH_MON_REP.ICS_DSCH_MON_REP_ID
              WHERE (RESULT_TYPE_CODE IN ('Accepted','Warning') AND SUBM_TYPE_NAME = 'DischargeMonitoringReportSubmission')
                 OR ICS_DSCH_MON_REP.PRMT_IDENT IN (SELECT PRMT_IDENT FROM ICS_SUBM_RESULTS WHERE SUBM_TYPE_NAME = 'PermitTerminationSubmission' AND RESULT_TYPE_CODE = 'Accepted')
);
-- /ICS_DSCH_MON_REP/ICS_LAND_APPL_SITE/ICS_CROP_TYPES_PLANTED
SET v_marker = 'DELETE FROM -- /ICS_DSCH_MON_REP/ICS_LAND_APPL_SITE/ICS_CROP_TYPES_PLANTED'; 
DELETE
  FROM ga_ics_flow_icis.ICS_CROP_TYPES_PLANTED
 WHERE ICS_CROP_TYPES_PLANTED.ICS_LAND_APPL_SITE_ID IN
          (SELECT ICS_LAND_APPL_SITE.ICS_LAND_APPL_SITE_ID
             FROM ga_ics_flow_icis.ICS_DSCH_MON_REP
                 LEFT JOIN ICS_SUBM_RESULTS ON ICS_SUBM_RESULTS.KEY_HASH = ICS_DSCH_MON_REP.KEY_HASH 
                  JOIN ga_ics_flow_icis.ICS_LAND_APPL_SITE ON ICS_LAND_APPL_SITE.ICS_DSCH_MON_REP_ID = ICS_DSCH_MON_REP.ICS_DSCH_MON_REP_ID
              WHERE (RESULT_TYPE_CODE IN ('Accepted','Warning') AND SUBM_TYPE_NAME = 'DischargeMonitoringReportSubmission')
                 OR ICS_DSCH_MON_REP.PRMT_IDENT IN (SELECT PRMT_IDENT FROM ICS_SUBM_RESULTS WHERE SUBM_TYPE_NAME = 'PermitTerminationSubmission' AND RESULT_TYPE_CODE = 'Accepted')
);
-- /ICS_DSCH_MON_REP/ICS_REP_PARAM/ICS_NUM_REP
SET v_marker = 'DELETE FROM -- /ICS_DSCH_MON_REP/ICS_REP_PARAM/ICS_NUM_REP'; 
DELETE
  FROM ga_ics_flow_icis.ICS_NUM_REP
 WHERE ICS_NUM_REP.ICS_REP_PARAM_ID IN
          (SELECT ICS_REP_PARAM.ICS_REP_PARAM_ID
             FROM ga_ics_flow_icis.ICS_DSCH_MON_REP
                 LEFT JOIN ICS_SUBM_RESULTS ON ICS_SUBM_RESULTS.KEY_HASH = ICS_DSCH_MON_REP.KEY_HASH 
                  JOIN ga_ics_flow_icis.ICS_REP_PARAM ON ICS_REP_PARAM.ICS_DSCH_MON_REP_ID = ICS_DSCH_MON_REP.ICS_DSCH_MON_REP_ID
              WHERE (RESULT_TYPE_CODE IN ('Accepted','Warning') AND SUBM_TYPE_NAME = 'DischargeMonitoringReportSubmission')
                 OR ICS_DSCH_MON_REP.PRMT_IDENT IN (SELECT PRMT_IDENT FROM ICS_SUBM_RESULTS WHERE SUBM_TYPE_NAME = 'PermitTerminationSubmission' AND RESULT_TYPE_CODE = 'Accepted')
);
-- /ICS_DSCH_MON_REP/ICS_CO_DSPL_SITE
SET v_marker = 'DELETE FROM -- /ICS_DSCH_MON_REP/ICS_CO_DSPL_SITE'; 
DELETE
  FROM ga_ics_flow_icis.ICS_CO_DSPL_SITE
 WHERE ICS_CO_DSPL_SITE.ICS_DSCH_MON_REP_ID IN
          (SELECT ICS_DSCH_MON_REP.ICS_DSCH_MON_REP_ID
             FROM ga_ics_flow_icis.ICS_DSCH_MON_REP
                 LEFT JOIN ICS_SUBM_RESULTS ON ICS_SUBM_RESULTS.KEY_HASH = ICS_DSCH_MON_REP.KEY_HASH 
              WHERE (RESULT_TYPE_CODE IN ('Accepted','Warning') AND SUBM_TYPE_NAME = 'DischargeMonitoringReportSubmission')
                 OR ICS_DSCH_MON_REP.PRMT_IDENT IN (SELECT PRMT_IDENT FROM ICS_SUBM_RESULTS WHERE SUBM_TYPE_NAME = 'PermitTerminationSubmission' AND RESULT_TYPE_CODE = 'Accepted')
);
-- /ICS_DSCH_MON_REP/ICS_INCIN
SET v_marker = 'DELETE FROM -- /ICS_DSCH_MON_REP/ICS_INCIN'; 
DELETE
  FROM ga_ics_flow_icis.ICS_INCIN
 WHERE ICS_INCIN.ICS_DSCH_MON_REP_ID IN
          (SELECT ICS_DSCH_MON_REP.ICS_DSCH_MON_REP_ID
             FROM ga_ics_flow_icis.ICS_DSCH_MON_REP
                 LEFT JOIN ICS_SUBM_RESULTS ON ICS_SUBM_RESULTS.KEY_HASH = ICS_DSCH_MON_REP.KEY_HASH 
              WHERE (RESULT_TYPE_CODE IN ('Accepted','Warning') AND SUBM_TYPE_NAME = 'DischargeMonitoringReportSubmission')
                 OR ICS_DSCH_MON_REP.PRMT_IDENT IN (SELECT PRMT_IDENT FROM ICS_SUBM_RESULTS WHERE SUBM_TYPE_NAME = 'PermitTerminationSubmission' AND RESULT_TYPE_CODE = 'Accepted')
);
-- /ICS_DSCH_MON_REP/ICS_LAND_APPL_SITE
SET v_marker = 'DELETE FROM -- /ICS_DSCH_MON_REP/ICS_LAND_APPL_SITE'; 
DELETE
  FROM ga_ics_flow_icis.ICS_LAND_APPL_SITE
 WHERE ICS_LAND_APPL_SITE.ICS_DSCH_MON_REP_ID IN
          (SELECT ICS_DSCH_MON_REP.ICS_DSCH_MON_REP_ID
             FROM ga_ics_flow_icis.ICS_DSCH_MON_REP
                 LEFT JOIN ICS_SUBM_RESULTS ON ICS_SUBM_RESULTS.KEY_HASH = ICS_DSCH_MON_REP.KEY_HASH 
              WHERE (RESULT_TYPE_CODE IN ('Accepted','Warning') AND SUBM_TYPE_NAME = 'DischargeMonitoringReportSubmission')
                 OR ICS_DSCH_MON_REP.PRMT_IDENT IN (SELECT PRMT_IDENT FROM ICS_SUBM_RESULTS WHERE SUBM_TYPE_NAME = 'PermitTerminationSubmission' AND RESULT_TYPE_CODE = 'Accepted')
);
-- /ICS_DSCH_MON_REP/ICS_REP_PARAM
SET v_marker = 'DELETE FROM -- /ICS_DSCH_MON_REP/ICS_REP_PARAM'; 
DELETE
  FROM ga_ics_flow_icis.ICS_REP_PARAM
 WHERE ICS_REP_PARAM.ICS_DSCH_MON_REP_ID IN
          (SELECT ICS_DSCH_MON_REP.ICS_DSCH_MON_REP_ID
             FROM ga_ics_flow_icis.ICS_DSCH_MON_REP
                 LEFT JOIN ICS_SUBM_RESULTS ON ICS_SUBM_RESULTS.KEY_HASH = ICS_DSCH_MON_REP.KEY_HASH 
              WHERE (RESULT_TYPE_CODE IN ('Accepted','Warning') AND SUBM_TYPE_NAME = 'DischargeMonitoringReportSubmission')
                 OR ICS_DSCH_MON_REP.PRMT_IDENT IN (SELECT PRMT_IDENT FROM ICS_SUBM_RESULTS WHERE SUBM_TYPE_NAME = 'PermitTerminationSubmission' AND RESULT_TYPE_CODE = 'Accepted')
);
-- /ICS_DSCH_MON_REP/ICS_SURF_DSPL_SITE
SET v_marker = 'DELETE FROM -- /ICS_DSCH_MON_REP/ICS_SURF_DSPL_SITE'; 
DELETE
  FROM ga_ics_flow_icis.ICS_SURF_DSPL_SITE
 WHERE ICS_SURF_DSPL_SITE.ICS_DSCH_MON_REP_ID IN
          (SELECT ICS_DSCH_MON_REP.ICS_DSCH_MON_REP_ID
             FROM ga_ics_flow_icis.ICS_DSCH_MON_REP
                 LEFT JOIN ICS_SUBM_RESULTS ON ICS_SUBM_RESULTS.KEY_HASH = ICS_DSCH_MON_REP.KEY_HASH 
              WHERE (RESULT_TYPE_CODE IN ('Accepted','Warning') AND SUBM_TYPE_NAME = 'DischargeMonitoringReportSubmission')
                 OR ICS_DSCH_MON_REP.PRMT_IDENT IN (SELECT PRMT_IDENT FROM ICS_SUBM_RESULTS WHERE SUBM_TYPE_NAME = 'PermitTerminationSubmission' AND RESULT_TYPE_CODE = 'Accepted')
);

-- 20121106
-- /ICS_DSCH_MON_REP
SET v_marker = 'DELETE FROM -- /ICS_DSCH_MON_REP'; 
DELETE
  FROM ga_ics_flow_icis.ICS_DSCH_MON_REP
 WHERE ICS_DSCH_MON_REP.ICS_DSCH_MON_REP_ID IN
          (SELECT ICS_DSCH_MON_REP_ID
             FROM (SELECT ICS_DSCH_MON_REP.ICS_DSCH_MON_REP_ID
                     FROM ga_ics_flow_icis.ICS_DSCH_MON_REP
                     LEFT JOIN ICS_SUBM_RESULTS 
                       ON ICS_SUBM_RESULTS.KEY_HASH = ICS_DSCH_MON_REP.KEY_HASH 
                    WHERE (    RESULT_TYPE_CODE IN ('Accepted','Warning') 
                           AND SUBM_TYPE_NAME = 'DischargeMonitoringReportSubmission')
                       OR ICS_DSCH_MON_REP.PRMT_IDENT IN (SELECT PRMT_IDENT 
                                                            FROM ICS_SUBM_RESULTS 
                                                           WHERE SUBM_TYPE_NAME = 'PermitTerminationSubmission' 
                                                             AND RESULT_TYPE_CODE = 'Accepted')
                  ) vw
);
-- 20121106


-- Add accepted records for ICS_DSCH_MON_REP
-- /ICS_DSCH_MON_REP
SET v_marker = 'INSERT INTO -- /ICS_DSCH_MON_REP'; 
INSERT INTO ga_ics_flow_icis.ICS_DSCH_MON_REP
     SELECT ICS_DSCH_MON_REP.*
       FROM ICS_DSCH_MON_REP
       WHERE ICS_DSCH_MON_REP.TRANSACTION_TYPE NOT IN ('D','X')
        AND KEY_HASH IN 
              (SELECT KEY_HASH
                 FROM ICS_SUBM_RESULTS
                WHERE RESULT_TYPE_CODE IN ('Accepted','Warning')
                  AND SUBM_TYPE_NAME = 'DischargeMonitoringReportSubmission');

-- /ICS_DSCH_MON_REP/ICS_CO_DSPL_SITE
SET v_marker = 'INSERT INTO -- /ICS_DSCH_MON_REP/ICS_CO_DSPL_SITE'; 
INSERT INTO ga_ics_flow_icis.ICS_CO_DSPL_SITE
     SELECT ICS_CO_DSPL_SITE.*
       FROM ICS_CO_DSPL_SITE
          JOIN ICS_DSCH_MON_REP
            ON ICS_CO_DSPL_SITE.ICS_DSCH_MON_REP_ID = ICS_DSCH_MON_REP.ICS_DSCH_MON_REP_ID
       WHERE ICS_DSCH_MON_REP.TRANSACTION_TYPE NOT IN ('D','X')
        AND KEY_HASH IN 
              (SELECT KEY_HASH
                 FROM ICS_SUBM_RESULTS
                WHERE RESULT_TYPE_CODE IN ('Accepted','Warning')
                  AND SUBM_TYPE_NAME = 'DischargeMonitoringReportSubmission');

-- /ICS_DSCH_MON_REP/ICS_INCIN
SET v_marker = 'INSERT INTO -- /ICS_DSCH_MON_REP/ICS_INCIN'; 
INSERT INTO ga_ics_flow_icis.ICS_INCIN
     SELECT ICS_INCIN.*
       FROM ICS_INCIN
          JOIN ICS_DSCH_MON_REP
            ON ICS_INCIN.ICS_DSCH_MON_REP_ID = ICS_DSCH_MON_REP.ICS_DSCH_MON_REP_ID
       WHERE ICS_DSCH_MON_REP.TRANSACTION_TYPE NOT IN ('D','X')
        AND KEY_HASH IN 
              (SELECT KEY_HASH
                 FROM ICS_SUBM_RESULTS
                WHERE RESULT_TYPE_CODE IN ('Accepted','Warning')
                  AND SUBM_TYPE_NAME = 'DischargeMonitoringReportSubmission');

-- /ICS_DSCH_MON_REP/ICS_LAND_APPL_SITE
SET v_marker = 'INSERT INTO -- /ICS_DSCH_MON_REP/ICS_LAND_APPL_SITE'; 
INSERT INTO ga_ics_flow_icis.ICS_LAND_APPL_SITE
     SELECT ICS_LAND_APPL_SITE.*
       FROM ICS_LAND_APPL_SITE
          JOIN ICS_DSCH_MON_REP
            ON ICS_LAND_APPL_SITE.ICS_DSCH_MON_REP_ID = ICS_DSCH_MON_REP.ICS_DSCH_MON_REP_ID
       WHERE ICS_DSCH_MON_REP.TRANSACTION_TYPE NOT IN ('D','X')
        AND KEY_HASH IN 
              (SELECT KEY_HASH
                 FROM ICS_SUBM_RESULTS
                WHERE RESULT_TYPE_CODE IN ('Accepted','Warning')
                  AND SUBM_TYPE_NAME = 'DischargeMonitoringReportSubmission');

-- /ICS_DSCH_MON_REP/ICS_LAND_APPL_SITE/ICS_CROP_TYPES_HARVESTED
SET v_marker = 'INSERT INTO -- /ICS_DSCH_MON_REP/ICS_LAND_APPL_SITE/ICS_CROP_TYPES_HARVESTED'; 
INSERT INTO ga_ics_flow_icis.ICS_CROP_TYPES_HARVESTED
     SELECT ICS_CROP_TYPES_HARVESTED.*
       FROM ICS_CROP_TYPES_HARVESTED
          JOIN ICS_LAND_APPL_SITE
            ON ICS_CROP_TYPES_HARVESTED.ICS_LAND_APPL_SITE_ID = ICS_LAND_APPL_SITE.ICS_LAND_APPL_SITE_ID
          JOIN ICS_DSCH_MON_REP
            ON ICS_LAND_APPL_SITE.ICS_DSCH_MON_REP_ID = ICS_DSCH_MON_REP.ICS_DSCH_MON_REP_ID
       WHERE ICS_DSCH_MON_REP.TRANSACTION_TYPE NOT IN ('D','X')
        AND KEY_HASH IN 
              (SELECT KEY_HASH
                 FROM ICS_SUBM_RESULTS
                WHERE RESULT_TYPE_CODE IN ('Accepted','Warning')
                  AND SUBM_TYPE_NAME = 'DischargeMonitoringReportSubmission');

-- /ICS_DSCH_MON_REP/ICS_LAND_APPL_SITE/ICS_CROP_TYPES_PLANTED
SET v_marker = 'INSERT INTO -- /ICS_DSCH_MON_REP/ICS_LAND_APPL_SITE/ICS_CROP_TYPES_PLANTED'; 
INSERT INTO ga_ics_flow_icis.ICS_CROP_TYPES_PLANTED
     SELECT ICS_CROP_TYPES_PLANTED.*
       FROM ICS_CROP_TYPES_PLANTED
          JOIN ICS_LAND_APPL_SITE
            ON ICS_CROP_TYPES_PLANTED.ICS_LAND_APPL_SITE_ID = ICS_LAND_APPL_SITE.ICS_LAND_APPL_SITE_ID
          JOIN ICS_DSCH_MON_REP
            ON ICS_LAND_APPL_SITE.ICS_DSCH_MON_REP_ID = ICS_DSCH_MON_REP.ICS_DSCH_MON_REP_ID
       WHERE ICS_DSCH_MON_REP.TRANSACTION_TYPE NOT IN ('D','X')
        AND KEY_HASH IN 
              (SELECT KEY_HASH
                 FROM ICS_SUBM_RESULTS
                WHERE RESULT_TYPE_CODE IN ('Accepted','Warning')
                  AND SUBM_TYPE_NAME = 'DischargeMonitoringReportSubmission');

-- /ICS_DSCH_MON_REP/ICS_REP_PARAM
SET v_marker = 'INSERT INTO -- /ICS_DSCH_MON_REP/ICS_REP_PARAM'; 
INSERT INTO ga_ics_flow_icis.ICS_REP_PARAM
     SELECT ICS_REP_PARAM.*
       FROM ICS_REP_PARAM
          JOIN ICS_DSCH_MON_REP
            ON ICS_REP_PARAM.ICS_DSCH_MON_REP_ID = ICS_DSCH_MON_REP.ICS_DSCH_MON_REP_ID
       WHERE ICS_DSCH_MON_REP.TRANSACTION_TYPE NOT IN ('D','X')
        AND KEY_HASH IN 
              (SELECT KEY_HASH
                 FROM ICS_SUBM_RESULTS
                WHERE RESULT_TYPE_CODE IN ('Accepted','Warning')
                  AND SUBM_TYPE_NAME = 'DischargeMonitoringReportSubmission');

-- /ICS_DSCH_MON_REP/ICS_REP_PARAM/ICS_NUM_REP
SET v_marker = 'INSERT INTO -- /ICS_DSCH_MON_REP/ICS_REP_PARAM/ICS_NUM_REP'; 
INSERT INTO ga_ics_flow_icis.ICS_NUM_REP
     SELECT ICS_NUM_REP.*
       FROM ICS_NUM_REP
          JOIN ICS_REP_PARAM
            ON ICS_NUM_REP.ICS_REP_PARAM_ID = ICS_REP_PARAM.ICS_REP_PARAM_ID
          JOIN ICS_DSCH_MON_REP
            ON ICS_REP_PARAM.ICS_DSCH_MON_REP_ID = ICS_DSCH_MON_REP.ICS_DSCH_MON_REP_ID
       WHERE ICS_DSCH_MON_REP.TRANSACTION_TYPE NOT IN ('D','X')
        AND KEY_HASH IN 
              (SELECT KEY_HASH
                 FROM ICS_SUBM_RESULTS
                WHERE RESULT_TYPE_CODE IN ('Accepted','Warning')
                  AND SUBM_TYPE_NAME = 'DischargeMonitoringReportSubmission');

-- /ICS_DSCH_MON_REP/ICS_SURF_DSPL_SITE
SET v_marker = 'INSERT INTO -- /ICS_DSCH_MON_REP/ICS_SURF_DSPL_SITE'; 
INSERT INTO ga_ics_flow_icis.ICS_SURF_DSPL_SITE
     SELECT ICS_SURF_DSPL_SITE.*
       FROM ICS_SURF_DSPL_SITE
          JOIN ICS_DSCH_MON_REP
            ON ICS_SURF_DSPL_SITE.ICS_DSCH_MON_REP_ID = ICS_DSCH_MON_REP.ICS_DSCH_MON_REP_ID
       WHERE ICS_DSCH_MON_REP.TRANSACTION_TYPE NOT IN ('D','X')
        AND KEY_HASH IN 
              (SELECT KEY_HASH
                 FROM ICS_SUBM_RESULTS
                WHERE RESULT_TYPE_CODE IN ('Accepted','Warning')
                  AND SUBM_TYPE_NAME = 'DischargeMonitoringReportSubmission');
   -- -------------- --
   --  END PROCEDURE --
   -- -------------- --
   SET v_marker = 'CALL ics_etl_log_sp END';
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_sp_name     -- pi_marker
      ,NULL          -- pi_tgt_tbl
      ,NULL          -- pi_src_tbl 
      ,v_startdtm    -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'COMPLETED'   -- pi_process
      ,0);           -- pi_value
   --
   SET po_status = 1;
   SET po_errm   = '';
   -- 
END