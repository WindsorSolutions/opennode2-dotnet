USE ga_ics_flow_local;
DROP PROCEDURE IF EXISTS ics_pat_insrt_icis_tbls;
CREATE PROCEDURE ics_pat_insrt_icis_tbls
   (IN  pi_transaction_id  VARCHAR(40)
   ,OUT po_status INT
   ,OUT po_errm   VARCHAR(255))
BEGIN
/******************************************************************************
** Object Name: ICS_PAT_ICS_PRMT_TERM
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  1) INSERT INTO ICIS tables.
**                  called by: ics_process_accepted_trans
**
** Revision History:
** ----------------------------------------------------------------------------
**  Date         Name        Description
** ----------------------------------------------------------------------------
** 20121102      JenGo       Converted from Oracle to MySQL.
**                           Modularized SP, added logging and error-handling
**                           called by: ICS_PROCESS_ACCEPTED_TRANS
** 20130108      JenGo       Per Bill: ICIS is returning the wrong result code 
**                              when an informal enforcement action already 
**                              exists in ICIS. It should be sending IEA030, 
**                              but instead is sending code FEA030. EPA will 
**                              eventually fix this, but until then, I've 
**                              updated the Oracle and SQL Server versions as 
**                              follows as a workaround - see where:
**                              v_marker = 'INSERT INTO ICS_INFRML_ENFRC_ACTN'
*******************************************************************************/
   DECLARE v_startdtm
          ,v_enddtm     DATETIME;
   DECLARE v_sp_name    VARCHAR(64)  DEFAULT 'ics_pat_insrt_icis_tbls';
   DECLARE v_errstat    INT DEFAULT 1;
   DECLARE v_errm       VARCHAR(255);
   DECLARE v_marker     VARCHAR(255);
   --
   DECLARE v_BasicPermitSubmission
          ,v_BiosolidsPermitSubmission
          ,v_BiosolidsProgramReportSubmission
          ,v_CAFOAnnualReportSubmission
          ,v_CAFOPermitSubmission
          ,v_ComplianceMonitoringSubmission
          ,v_ComplianceMonitoringLinkageSubmission
          ,v_ComplianceScheduleSubmission
          ,v_CSOEventReportSubmission
          ,v_CSOPermitSubmission
          ,v_DischargeMonitoringReportSubmission
          ,v_DMRProgramReportLinkageSubmission
          ,v_DMRViolationSubmission
          ,v_EffluentTradePartnerSubmission
          ,v_EnforcementActionMilestoneSubmission
          ,v_EnforcementActionViolationLinkageSubmission
          ,v_FinalOrderViolationLinkageSubmission
          ,v_FormalEnforcementActionSubmission
          ,v_GeneralPermitSubmission
          ,v_HistoricalPermitScheduleEventsSubmission
          ,v_InformalEnforcementActionSubmission
          ,v_LimitsSubmission
          ,v_LimitSetSubmission
          ,v_LocalLimitsProgramReportSubmission
          ,v_MasterGeneralPermitSubmission
          ,v_NarrativeConditionScheduleSubmission
          ,v_ParameterLimitsSubmission
          ,v_PermitReissuanceSubmission
          ,v_PermittedFeatureSubmission
          ,v_PermitTerminationSubmission
          ,v_PermitTrackingEventSubmission
          ,v_POTWPermitSubmission
          ,v_PretreatmentPerformanceSummarySubmission
          ,v_PretreatmentPermitSubmission
          ,v_ScheduleEventViolationSubmission
          ,v_SingleEventViolationSubmission
          ,v_SSOAnnualReportSubmission
          ,v_SSOEventReportSubmission
          ,v_SSOMonthlyEventReportSubmission
          ,v_SWConstructionPermitSubmission
          ,v_SWEventReportSubmission
          ,v_SWIndustrialPermitSubmission
          ,v_SWMS4LargePermitSubmission
          ,v_SWMS4ProgramReportSubmission
          ,v_SWMS4SmallPermitSubmission
          ,v_UnpermittedFacilitySubmission           VARCHAR(36);
   --
   DECLARE EXIT HANDLER FOR SQLEXCEPTION
      BEGIN  
         ROLLBACK;
         SET po_status = -1;
         SET po_errm   = v_marker;
         -- SELECT 'ERROR ';
         CALL ics_etl_log_sp    
            (v_sp_name          -- pi_sp_name
            ,v_marker           -- pi_marker
            ,NULL               -- pi_tgt_tbl
            ,NULL               -- pi_src_tbl
            ,v_startdtm         -- pi_startdtm
            ,NOW()              -- pi_enddtm
            ,'FAILED'           -- pi_process
            ,-1);               -- pi_value
         COMMIT;
      END;
   SET v_startdtm = NOW();
   -- Step 5: Copy business keys where ICIS returnes error that key is already present in ICIS
   SET v_marker = 'SELECT PAYLOAD_ID';
   SELECT MAX(BasicPermitSubmission)
         ,MAX(BiosolidsPermitSubmission)
         ,MAX(BiosolidsProgramReportSubmission)
         ,MAX(CAFOAnnualReportSubmission)
         ,MAX(CAFOPermitSubmission)
         ,MAX(ComplianceMonitoringSubmission)
         ,MAX(ComplianceMonitoringLinkageSubmission)
         ,MAX(ComplianceScheduleSubmission)
         ,MAX(CSOEventReportSubmission)
         ,MAX(CSOPermitSubmission)
         ,MAX(DischargeMonitoringReportSubmission)
         ,MAX(DMRProgramReportLinkageSubmission)
         ,MAX(DMRViolationSubmission)
         ,MAX(EffluentTradePartnerSubmission)
         ,MAX(EnforcementActionMilestoneSubmission)
         ,MAX(EnforcementActionViolationLinkageSubmission)
         ,MAX(FinalOrderViolationLinkageSubmission)
         ,MAX(FormalEnforcementActionSubmission)
         ,MAX(GeneralPermitSubmission)
         ,MAX(HistoricalPermitScheduleEventsSubmission)
         ,MAX(InformalEnforcementActionSubmission)
         ,MAX(LimitsSubmission)
         ,MAX(LimitSetSubmission)
         ,MAX(LocalLimitsProgramReportSubmission)
         ,MAX(MasterGeneralPermitSubmission)
         ,MAX(NarrativeConditionScheduleSubmission)
         ,MAX(ParameterLimitsSubmission)
         ,MAX(PermitReissuanceSubmission)
         ,MAX(PermittedFeatureSubmission)
         ,MAX(PermitTerminationSubmission)
         ,MAX(PermitTrackingEventSubmission)
         ,MAX(POTWPermitSubmission)
         ,MAX(PretreatmentPerformanceSummarySubmission)
         ,MAX(PretreatmentPermitSubmission)
         ,MAX(ScheduleEventViolationSubmission)
         ,MAX(SingleEventViolationSubmission)
         ,MAX(SSOAnnualReportSubmission)
         ,MAX(SSOEventReportSubmission)
         ,MAX(SSOMonthlyEventReportSubmission)
         ,MAX(SWConstructionPermitSubmission)
         ,MAX(SWEventReportSubmission)
         ,MAX(SWIndustrialPermitSubmission)
         ,MAX(SWMS4LargePermitSubmission)
         ,MAX(SWMS4ProgramReportSubmission)
         ,MAX(SWMS4SmallPermitSubmission)
         ,MAX(UnpermittedFacilitySubmission)
     INTO v_BasicPermitSubmission
         ,v_BiosolidsPermitSubmission
         ,v_BiosolidsProgramReportSubmission
         ,v_CAFOAnnualReportSubmission
         ,v_CAFOPermitSubmission
         ,v_ComplianceMonitoringSubmission
         ,v_ComplianceMonitoringLinkageSubmission
         ,v_ComplianceScheduleSubmission
         ,v_CSOEventReportSubmission
         ,v_CSOPermitSubmission
         ,v_DischargeMonitoringReportSubmission
         ,v_DMRProgramReportLinkageSubmission
         ,v_DMRViolationSubmission
         ,v_EffluentTradePartnerSubmission
         ,v_EnforcementActionMilestoneSubmission
         ,v_EnforcementActionViolationLinkageSubmission
         ,v_FinalOrderViolationLinkageSubmission
         ,v_FormalEnforcementActionSubmission
         ,v_GeneralPermitSubmission
         ,v_HistoricalPermitScheduleEventsSubmission
         ,v_InformalEnforcementActionSubmission
         ,v_LimitsSubmission
         ,v_LimitSetSubmission
         ,v_LocalLimitsProgramReportSubmission
         ,v_MasterGeneralPermitSubmission
         ,v_NarrativeConditionScheduleSubmission
         ,v_ParameterLimitsSubmission
         ,v_PermitReissuanceSubmission
         ,v_PermittedFeatureSubmission
         ,v_PermitTerminationSubmission
         ,v_PermitTrackingEventSubmission
         ,v_POTWPermitSubmission
         ,v_PretreatmentPerformanceSummarySubmission
         ,v_PretreatmentPermitSubmission
         ,v_ScheduleEventViolationSubmission
         ,v_SingleEventViolationSubmission
         ,v_SSOAnnualReportSubmission
         ,v_SSOEventReportSubmission
         ,v_SSOMonthlyEventReportSubmission
         ,v_SWConstructionPermitSubmission
         ,v_SWEventReportSubmission
         ,v_SWIndustrialPermitSubmission
         ,v_SWMS4LargePermitSubmission
         ,v_SWMS4ProgramReportSubmission
         ,v_SWMS4SmallPermitSubmission
         ,v_UnpermittedFacilitySubmission
     FROM (SELECT CASE WHEN OPERATION = 'BasicPermitSubmission' THEN ICS_PAYLOAD_ID ELSE NULL END   BasicPermitSubmission
                 ,CASE WHEN OPERATION = 'BiosolidsPermitSubmission' THEN ICS_PAYLOAD_ID ELSE NULL END   BiosolidsPermitSubmission
                 ,CASE WHEN OPERATION = 'BiosolidsProgramReportSubmission' THEN ICS_PAYLOAD_ID ELSE NULL END   BiosolidsProgramReportSubmission
                 ,CASE WHEN OPERATION = 'CAFOAnnualReportSubmission' THEN ICS_PAYLOAD_ID ELSE NULL END   CAFOAnnualReportSubmission
                 ,CASE WHEN OPERATION = 'CAFOPermitSubmission' THEN ICS_PAYLOAD_ID ELSE NULL END   CAFOPermitSubmission
                 ,CASE WHEN OPERATION = 'ComplianceMonitoringSubmission' THEN ICS_PAYLOAD_ID ELSE NULL END   ComplianceMonitoringSubmission
                 ,CASE WHEN OPERATION = 'ComplianceMonitoringLinkageSubmission' THEN ICS_PAYLOAD_ID ELSE NULL END   ComplianceMonitoringLinkageSubmission
                 ,CASE WHEN OPERATION = 'ComplianceScheduleSubmission' THEN ICS_PAYLOAD_ID ELSE NULL END   ComplianceScheduleSubmission
                 ,CASE WHEN OPERATION = 'CSOEventReportSubmission' THEN ICS_PAYLOAD_ID ELSE NULL END   CSOEventReportSubmission
                 ,CASE WHEN OPERATION = 'CSOPermitSubmission' THEN ICS_PAYLOAD_ID ELSE NULL END   CSOPermitSubmission
                 ,CASE WHEN OPERATION = 'DischargeMonitoringReportSubmission' THEN ICS_PAYLOAD_ID ELSE NULL END   DischargeMonitoringReportSubmission
                 ,CASE WHEN OPERATION = 'DMRProgramReportLinkageSubmission' THEN ICS_PAYLOAD_ID ELSE NULL END   DMRProgramReportLinkageSubmission
                 ,CASE WHEN OPERATION = 'DMRViolationSubmission' THEN ICS_PAYLOAD_ID ELSE NULL END   DMRViolationSubmission
                 ,CASE WHEN OPERATION = 'EffluentTradePartnerSubmission' THEN ICS_PAYLOAD_ID ELSE NULL END   EffluentTradePartnerSubmission
                 ,CASE WHEN OPERATION = 'EnforcementActionMilestoneSubmission' THEN ICS_PAYLOAD_ID ELSE NULL END   EnforcementActionMilestoneSubmission
                 ,CASE WHEN OPERATION = 'EnforcementActionViolationLinkageSubmission' THEN ICS_PAYLOAD_ID ELSE NULL END   EnforcementActionViolationLinkageSubmission
                 ,CASE WHEN OPERATION = 'FinalOrderViolationLinkageSubmission' THEN ICS_PAYLOAD_ID ELSE NULL END   FinalOrderViolationLinkageSubmission
                 ,CASE WHEN OPERATION = 'FormalEnforcementActionSubmission' THEN ICS_PAYLOAD_ID ELSE NULL END   FormalEnforcementActionSubmission
                 ,CASE WHEN OPERATION = 'GeneralPermitSubmission' THEN ICS_PAYLOAD_ID ELSE NULL END   GeneralPermitSubmission
                 ,CASE WHEN OPERATION = 'HistoricalPermitScheduleEventsSubmission' THEN ICS_PAYLOAD_ID ELSE NULL END   HistoricalPermitScheduleEventsSubmission
                 ,CASE WHEN OPERATION = 'InformalEnforcementActionSubmission' THEN ICS_PAYLOAD_ID ELSE NULL END   InformalEnforcementActionSubmission
                 ,CASE WHEN OPERATION = 'LimitsSubmission' THEN ICS_PAYLOAD_ID ELSE NULL END   LimitsSubmission
                 ,CASE WHEN OPERATION = 'LimitSetSubmission' THEN ICS_PAYLOAD_ID ELSE NULL END   LimitSetSubmission
                 ,CASE WHEN OPERATION = 'LocalLimitsProgramReportSubmission' THEN ICS_PAYLOAD_ID ELSE NULL END   LocalLimitsProgramReportSubmission
                 ,CASE WHEN OPERATION = 'MasterGeneralPermitSubmission' THEN ICS_PAYLOAD_ID ELSE NULL END   MasterGeneralPermitSubmission
                 ,CASE WHEN OPERATION = 'NarrativeConditionScheduleSubmission' THEN ICS_PAYLOAD_ID ELSE NULL END   NarrativeConditionScheduleSubmission
                 ,CASE WHEN OPERATION = 'ParameterLimitsSubmission' THEN ICS_PAYLOAD_ID ELSE NULL END   ParameterLimitsSubmission
                 ,CASE WHEN OPERATION = 'PermitReissuanceSubmission' THEN ICS_PAYLOAD_ID ELSE NULL END   PermitReissuanceSubmission
                 ,CASE WHEN OPERATION = 'PermittedFeatureSubmission' THEN ICS_PAYLOAD_ID ELSE NULL END   PermittedFeatureSubmission
                 ,CASE WHEN OPERATION = 'PermitTerminationSubmission' THEN ICS_PAYLOAD_ID ELSE NULL END   PermitTerminationSubmission
                 ,CASE WHEN OPERATION = 'PermitTrackingEventSubmission' THEN ICS_PAYLOAD_ID ELSE NULL END   PermitTrackingEventSubmission
                 ,CASE WHEN OPERATION = 'POTWPermitSubmission' THEN ICS_PAYLOAD_ID ELSE NULL END   POTWPermitSubmission
                 ,CASE WHEN OPERATION = 'PretreatmentPerformanceSummarySubmission' THEN ICS_PAYLOAD_ID ELSE NULL END   PretreatmentPerformanceSummarySubmission
                 ,CASE WHEN OPERATION = 'PretreatmentPermitSubmission' THEN ICS_PAYLOAD_ID ELSE NULL END   PretreatmentPermitSubmission
                 ,CASE WHEN OPERATION = 'ScheduleEventViolationSubmission' THEN ICS_PAYLOAD_ID ELSE NULL END   ScheduleEventViolationSubmission
                 ,CASE WHEN OPERATION = 'SingleEventViolationSubmission' THEN ICS_PAYLOAD_ID ELSE NULL END   SingleEventViolationSubmission
                 ,CASE WHEN OPERATION = 'SSOAnnualReportSubmission' THEN ICS_PAYLOAD_ID ELSE NULL END   SSOAnnualReportSubmission
                 ,CASE WHEN OPERATION = 'SSOEventReportSubmission' THEN ICS_PAYLOAD_ID ELSE NULL END   SSOEventReportSubmission
                 ,CASE WHEN OPERATION = 'SSOMonthlyEventReportSubmission' THEN ICS_PAYLOAD_ID ELSE NULL END   SSOMonthlyEventReportSubmission
                 ,CASE WHEN OPERATION = 'SWConstructionPermitSubmission' THEN ICS_PAYLOAD_ID ELSE NULL END   SWConstructionPermitSubmission
                 ,CASE WHEN OPERATION = 'SWEventReportSubmission' THEN ICS_PAYLOAD_ID ELSE NULL END   SWEventReportSubmission
                 ,CASE WHEN OPERATION = 'SWIndustrialPermitSubmission' THEN ICS_PAYLOAD_ID ELSE NULL END   SWIndustrialPermitSubmission
                 ,CASE WHEN OPERATION = 'SWMS4LargePermitSubmission' THEN ICS_PAYLOAD_ID ELSE NULL END   SWMS4LargePermitSubmission
                 ,CASE WHEN OPERATION = 'SWMS4ProgramReportSubmission' THEN ICS_PAYLOAD_ID ELSE NULL END   SWMS4ProgramReportSubmission
                 ,CASE WHEN OPERATION = 'SWMS4SmallPermitSubmission' THEN ICS_PAYLOAD_ID ELSE NULL END   SWMS4SmallPermitSubmission
                 ,CASE WHEN OPERATION = 'UnpermittedFacilitySubmission' THEN ICS_PAYLOAD_ID ELSE NULL END   UnpermittedFacilitySubmission
             FROM ICS_PAYLOAD ) vw;

  -- Add keys that already exist in ICIS for module ICS_BASIC_PRMT
  SET v_marker = 'INSERT INTO ICS_BASIC_PRMT'; 
  INSERT INTO ga_ics_flow_icis.ICS_BASIC_PRMT (ICS_PAYLOAD_ID, ICS_BASIC_PRMT_ID, PRMT_IDENT, KEY_HASH, DATA_HASH)
       SELECT v_BasicPermitSubmission, UUID(), PRMT_IDENT, KEY_HASH, '0' as DATA_HASH
         FROM ICS_SUBM_RESULTS
        WHERE RESULT_CODE = 'BP060'
          AND SUBM_TYPE_NAME = 'BasicPermitSubmission'
          AND SUBM_TRANSACTION_ID = pi_transaction_id
          AND KEY_HASH NOT IN (SELECT KEY_HASH FROM ga_ics_flow_icis.ICS_BASIC_PRMT)
     GROUP BY PRMT_IDENT, KEY_HASH;

  -- Add keys that already exist in ICIS for module ICS_BS_PRMT
  SET v_marker = 'INSERT INTO ICS_BS_PRMT';
  INSERT INTO ga_ics_flow_icis.ICS_BS_PRMT (ICS_PAYLOAD_ID, ICS_BS_PRMT_ID, PRMT_IDENT, KEY_HASH, DATA_HASH)
       SELECT v_BiosolidsPermitSubmission, UUID(), PRMT_IDENT, KEY_HASH, '0' as DATA_HASH
         FROM ICS_SUBM_RESULTS
        WHERE RESULT_CODE = 'PC040'
          AND SUBM_TYPE_NAME = 'BiosolidsPermitSubmission'
          AND SUBM_TRANSACTION_ID = pi_transaction_id
          AND KEY_HASH NOT IN (SELECT KEY_HASH FROM ga_ics_flow_icis.ICS_BS_PRMT)
     GROUP BY PRMT_IDENT, KEY_HASH;

  -- Add keys that already exist in ICIS for module ICS_CAFO_PRMT
  SET v_marker = 'INSERT INTO ICS_CAFO_PRMT'; 
  INSERT INTO ga_ics_flow_icis.ICS_CAFO_PRMT (ICS_PAYLOAD_ID, ICS_CAFO_PRMT_ID, PRMT_IDENT, KEY_HASH, DATA_HASH)
       SELECT v_CAFOPermitSubmission, UUID(), PRMT_IDENT, KEY_HASH, '0' as DATA_HASH
         FROM ICS_SUBM_RESULTS
        WHERE RESULT_CODE = 'PC040'
          AND SUBM_TYPE_NAME = 'CAFOPermitSubmission'
          AND SUBM_TRANSACTION_ID = pi_transaction_id
          AND KEY_HASH NOT IN (SELECT KEY_HASH FROM ga_ics_flow_icis.ICS_CAFO_PRMT)
     GROUP BY PRMT_IDENT, KEY_HASH;

  -- Add keys that already exist in ICIS for module ICS_CSO_PRMT
  SET v_marker = 'INSERT INTO ICS_CSO_PRMT'; 
  INSERT INTO ga_ics_flow_icis.ICS_CSO_PRMT (ICS_PAYLOAD_ID, ICS_CSO_PRMT_ID, PRMT_IDENT, KEY_HASH, DATA_HASH)
       SELECT v_CSOPermitSubmission, UUID(), PRMT_IDENT, KEY_HASH, '0' as DATA_HASH
         FROM ICS_SUBM_RESULTS
        WHERE RESULT_CODE = 'PC040'
          AND SUBM_TYPE_NAME = 'CSOPermitSubmission'
          AND SUBM_TRANSACTION_ID = pi_transaction_id
          AND KEY_HASH NOT IN (SELECT KEY_HASH FROM ga_ics_flow_icis.ICS_CSO_PRMT)
     GROUP BY PRMT_IDENT, KEY_HASH;

  -- Add keys that already exist in ICIS for module ICS_GNRL_PRMT
  SET v_marker = 'INSERT INTO ICS_GNRL_PRMT'; 
  INSERT INTO ga_ics_flow_icis.ICS_GNRL_PRMT (ICS_PAYLOAD_ID, ICS_GNRL_PRMT_ID, PRMT_IDENT, KEY_HASH, DATA_HASH)
       SELECT v_GeneralPermitSubmission, UUID(), PRMT_IDENT, KEY_HASH, '0' as DATA_HASH
         FROM ICS_SUBM_RESULTS
        WHERE RESULT_CODE = 'BP060'
          AND SUBM_TYPE_NAME = 'GeneralPermitSubmission'
          AND SUBM_TRANSACTION_ID = pi_transaction_id
          AND KEY_HASH NOT IN (SELECT KEY_HASH FROM ga_ics_flow_icis.ICS_GNRL_PRMT)
     GROUP BY PRMT_IDENT, KEY_HASH;
     
  -- Add keys that already exist in ICIS for module ICS_MASTER_GNRL_PRMT
  SET v_marker = 'INSERT INTO ICS_MASTER_GNRL_PRMT'; 
  INSERT INTO ga_ics_flow_icis.ICS_MASTER_GNRL_PRMT (ICS_PAYLOAD_ID, ICS_MASTER_GNRL_PRMT_ID, PRMT_IDENT, KEY_HASH, DATA_HASH)
       SELECT v_MasterGeneralPermitSubmission, UUID(), PRMT_IDENT, KEY_HASH, '0' as DATA_HASH
         FROM ICS_SUBM_RESULTS
        WHERE RESULT_CODE = 'MGP040'
          AND SUBM_TYPE_NAME = 'MasterGeneralPermitSubmission'
          AND SUBM_TRANSACTION_ID = pi_transaction_id
          AND KEY_HASH NOT IN (SELECT KEY_HASH FROM ga_ics_flow_icis.ICS_MASTER_GNRL_PRMT)
     GROUP BY PRMT_IDENT, KEY_HASH;

  -- Add keys that already exist in ICIS for module ICS_PRMT_TRACK_EVT
  SET v_marker = 'INSERT INTO ICS_PRMT_TRACK_EVT'; 
  INSERT INTO ga_ics_flow_icis.ICS_PRMT_TRACK_EVT (ICS_PAYLOAD_ID, ICS_PRMT_TRACK_EVT_ID, PRMT_IDENT,  PRMT_TRACK_EVT_CODE,  PRMT_TRACK_EVT_DATE, KEY_HASH, DATA_HASH)
       SELECT v_PermitTrackingEventSubmission, UUID(), PRMT_IDENT,  PRMT_TRACK_EVT_CODE,  PRMT_TRACK_EVT_DATE, KEY_HASH, '0' as DATA_HASH
         FROM ICS_SUBM_RESULTS
        WHERE RESULT_CODE = 'PTE030'
          AND SUBM_TYPE_NAME = 'PermitTrackingEventSubmission'
          AND SUBM_TRANSACTION_ID = pi_transaction_id
          AND KEY_HASH NOT IN (SELECT KEY_HASH FROM ga_ics_flow_icis.ICS_PRMT_TRACK_EVT)
     GROUP BY PRMT_IDENT,  PRMT_TRACK_EVT_CODE,  PRMT_TRACK_EVT_DATE, KEY_HASH;

  -- Add keys that already exist in ICIS for module ICS_POTW_PRMT
  SET v_marker = 'INSERT INTO ICS_POTW_PRMT'; 
  INSERT INTO ga_ics_flow_icis.ICS_POTW_PRMT (ICS_PAYLOAD_ID, ICS_POTW_PRMT_ID, PRMT_IDENT, KEY_HASH, DATA_HASH)
       SELECT v_POTWPermitSubmission, UUID(), PRMT_IDENT, KEY_HASH, '0' as DATA_HASH
         FROM ICS_SUBM_RESULTS
        WHERE RESULT_CODE = 'PC040'
          AND SUBM_TYPE_NAME = 'POTWPermitSubmission'
          AND SUBM_TRANSACTION_ID = pi_transaction_id
          AND KEY_HASH NOT IN (SELECT KEY_HASH FROM ga_ics_flow_icis.ICS_POTW_PRMT)
     GROUP BY PRMT_IDENT, KEY_HASH;

  -- Add keys that already exist in ICIS for module ICS_PRETR_PRMT
  SET v_marker = 'INSERT INTO ICS_PRETR_PRMT'; 
  INSERT INTO ga_ics_flow_icis.ICS_PRETR_PRMT (ICS_PAYLOAD_ID, ICS_PRETR_PRMT_ID, PRMT_IDENT, KEY_HASH, DATA_HASH)
       SELECT v_PretreatmentPermitSubmission, UUID(), PRMT_IDENT, KEY_HASH, '0' as DATA_HASH
         FROM ICS_SUBM_RESULTS
        WHERE RESULT_CODE = 'PC040'
          AND SUBM_TYPE_NAME = 'PretreatmentPermitSubmission'
          AND SUBM_TRANSACTION_ID = pi_transaction_id
          AND KEY_HASH NOT IN (SELECT KEY_HASH FROM ga_ics_flow_icis.ICS_PRETR_PRMT)
     GROUP BY PRMT_IDENT, KEY_HASH;

  -- Add keys that already exist in ICIS for module ICS_SW_CNST_PRMT
  SET v_marker = 'INSERT INTO ICS_SW_CNST_PRMT'; 
  INSERT INTO ga_ics_flow_icis.ICS_SW_CNST_PRMT (ICS_PAYLOAD_ID, ICS_SW_CNST_PRMT_ID, PRMT_IDENT, KEY_HASH, DATA_HASH)
       SELECT v_SWConstructionPermitSubmission, UUID(), PRMT_IDENT, KEY_HASH, '0' as DATA_HASH
         FROM ICS_SUBM_RESULTS
        WHERE RESULT_CODE = 'PC040'
          AND SUBM_TYPE_NAME = 'SWConstructionPermitSubmission'
          AND SUBM_TRANSACTION_ID = pi_transaction_id
          AND KEY_HASH NOT IN (SELECT KEY_HASH FROM ga_ics_flow_icis.ICS_SW_CNST_PRMT)
     GROUP BY PRMT_IDENT, KEY_HASH;

  -- Add keys that already exist in ICIS for module ICS_SW_INDST_PRMT
  SET v_marker = 'INSERT INTO ICS_SW_INDST_PRMT'; 
  INSERT INTO ga_ics_flow_icis.ICS_SW_INDST_PRMT (ICS_PAYLOAD_ID, ICS_SW_INDST_PRMT_ID, PRMT_IDENT, KEY_HASH, DATA_HASH)
       SELECT v_SWIndustrialPermitSubmission, UUID(), PRMT_IDENT, KEY_HASH, '0' as DATA_HASH
         FROM ICS_SUBM_RESULTS
        WHERE RESULT_CODE = 'PC040'
          AND SUBM_TYPE_NAME = 'SWIndustrialPermitSubmission'
          AND SUBM_TRANSACTION_ID = pi_transaction_id
          AND KEY_HASH NOT IN (SELECT KEY_HASH FROM ga_ics_flow_icis.ICS_SW_INDST_PRMT)
     GROUP BY PRMT_IDENT, KEY_HASH;

  -- Add keys that already exist in ICIS for module ICS_SWMS_4_LARGE_PRMT
  SET v_marker = 'INSERT INTO ICS_SWMS_4_LARGE_PRMT'; 
  INSERT INTO ga_ics_flow_icis.ICS_SWMS_4_LARGE_PRMT (ICS_PAYLOAD_ID, ICS_SWMS_4_LARGE_PRMT_ID, PRMT_IDENT, KEY_HASH, DATA_HASH)
       SELECT v_SWMS4LargePermitSubmission, UUID(), PRMT_IDENT, KEY_HASH, '0' as DATA_HASH
         FROM ICS_SUBM_RESULTS
        WHERE RESULT_CODE = 'PC040'
          AND SUBM_TYPE_NAME = 'SWMS4LargePermitSubmission'
          AND SUBM_TRANSACTION_ID = pi_transaction_id
          AND KEY_HASH NOT IN (SELECT KEY_HASH FROM ga_ics_flow_icis.ICS_SWMS_4_LARGE_PRMT)
     GROUP BY PRMT_IDENT, KEY_HASH;

  -- Add keys that already exist in ICIS for module ICS_SWMS_4_SMALL_PRMT
  SET v_marker = 'INSERT INTO ICS_SWMS_4_SMALL_PRMT'; 
  INSERT INTO ga_ics_flow_icis.ICS_SWMS_4_SMALL_PRMT (ICS_PAYLOAD_ID, ICS_SWMS_4_SMALL_PRMT_ID, PRMT_IDENT, KEY_HASH, DATA_HASH)
       SELECT v_SWMS4SmallPermitSubmission, UUID(), PRMT_IDENT, KEY_HASH, '0' as DATA_HASH
         FROM ICS_SUBM_RESULTS
        WHERE RESULT_CODE = 'PC040'
          AND SUBM_TYPE_NAME = 'SWMS4SmallPermitSubmission'
          AND SUBM_TRANSACTION_ID = pi_transaction_id
          AND KEY_HASH NOT IN (SELECT KEY_HASH FROM ga_ics_flow_icis.ICS_SWMS_4_SMALL_PRMT)
     GROUP BY PRMT_IDENT, KEY_HASH;

  -- Add keys that already exist in ICIS for module ICS_UNPRMT_FAC
  SET v_marker = 'INSERT INTO ICS_UNPRMT_FAC'; 
  INSERT INTO ga_ics_flow_icis.ICS_UNPRMT_FAC (ICS_PAYLOAD_ID, ICS_UNPRMT_FAC_ID, PRMT_IDENT, KEY_HASH, DATA_HASH)
       SELECT v_UnpermittedFacilitySubmission, UUID(), PRMT_IDENT, KEY_HASH, '0' as DATA_HASH
         FROM ICS_SUBM_RESULTS
        WHERE RESULT_CODE = 'UPF060'
          AND SUBM_TYPE_NAME = 'UnpermittedFacilitySubmission'
          AND SUBM_TRANSACTION_ID = pi_transaction_id
          AND KEY_HASH NOT IN (SELECT KEY_HASH FROM ga_ics_flow_icis.ICS_UNPRMT_FAC)
     GROUP BY PRMT_IDENT, KEY_HASH;

  -- Add keys that already exist in ICIS for module ICS_PRMT_FEATR
  SET v_marker = 'INSERT INTO ICS_PRMT_FEATR'; 
  INSERT INTO ga_ics_flow_icis.ICS_PRMT_FEATR (ICS_PAYLOAD_ID, ICS_PRMT_FEATR_ID, PRMT_IDENT,  PRMT_FEATR_IDENT, KEY_HASH, DATA_HASH)
       SELECT v_PermittedFeatureSubmission, UUID(), PRMT_IDENT,  PRMT_FEATR_IDENT, KEY_HASH, '0' as DATA_HASH
         FROM ICS_SUBM_RESULTS
        WHERE RESULT_CODE = 'PF030'
          AND SUBM_TYPE_NAME = 'PermittedFeatureSubmission'
          AND SUBM_TRANSACTION_ID = pi_transaction_id
          AND KEY_HASH NOT IN (SELECT KEY_HASH FROM ga_ics_flow_icis.ICS_PRMT_FEATR)
     GROUP BY PRMT_IDENT,  PRMT_FEATR_IDENT, KEY_HASH;

  -- Add keys that already exist in ICIS for module ICS_LMT_SET
  SET v_marker = 'INSERT INTO ICS_LMT_SET'; 
  INSERT INTO ga_ics_flow_icis.ICS_LMT_SET (ICS_PAYLOAD_ID, ICS_LMT_SET_ID, PRMT_IDENT,  PRMT_FEATR_IDENT,  LMT_SET_DESIGNATOR, LMT_SET_TYPE, KEY_HASH, DATA_HASH)
       SELECT v_LimitSetSubmission, UUID(), PRMT_IDENT,  PRMT_FEATR_IDENT,  LMT_SET_DESIGNATOR, 'S', KEY_HASH, '0' as DATA_HASH
         FROM ICS_SUBM_RESULTS
        WHERE RESULT_CODE = 'LS060'
          AND SUBM_TYPE_NAME = 'LimitSetSubmission'
          AND SUBM_TRANSACTION_ID = pi_transaction_id
          AND KEY_HASH NOT IN (SELECT KEY_HASH FROM ga_ics_flow_icis.ICS_LMT_SET)
     GROUP BY PRMT_IDENT,  PRMT_FEATR_IDENT,  LMT_SET_DESIGNATOR, KEY_HASH;

  -- Add keys that already exist in ICIS for module ICS_LMTS
  SET v_marker = 'INSERT INTO ICS_LMTS'; 
  INSERT INTO ga_ics_flow_icis.ICS_LMTS (ICS_PAYLOAD_ID, ICS_LMTS_ID, PRMT_IDENT,  PRMT_FEATR_IDENT,  LMT_SET_DESIGNATOR,  PARAM_CODE,  MON_SITE_DESC_CODE,  LMT_SEASON_NUM,  LMT_START_DATE,  LMT_END_DATE, KEY_HASH, DATA_HASH)
       SELECT v_LimitsSubmission, UUID(), PRMT_IDENT,  PRMT_FEATR_IDENT,  LMT_SET_DESIGNATOR,  PARAM_CODE,  MON_SITE_DESC_CODE,  LMT_SEASON_NUM,  LMT_START_DATE,  LMT_END_DATE, KEY_HASH, '0' as DATA_HASH
         FROM ICS_SUBM_RESULTS
        WHERE RESULT_CODE = 'LTS050'
          AND SUBM_TYPE_NAME = 'LimitsSubmission'
          AND SUBM_TRANSACTION_ID = pi_transaction_id
          AND KEY_HASH NOT IN (SELECT KEY_HASH FROM ga_ics_flow_icis.ICS_BASIC_PRMT)
     GROUP BY PRMT_IDENT,  PRMT_FEATR_IDENT,  LMT_SET_DESIGNATOR,  PARAM_CODE,  MON_SITE_DESC_CODE,  LMT_SEASON_NUM,  LMT_START_DATE,  LMT_END_DATE, KEY_HASH;

  -- Add keys that already exist in ICIS for module ICS_CMPL_MON
  SET v_marker = 'INSERT INTO ICS_CMPL_MON'; 
  INSERT INTO ga_ics_flow_icis.ICS_CMPL_MON (ICS_PAYLOAD_ID, ICS_CMPL_MON_ID, PRMT_IDENT,  CMPL_MON_CATG_CODE,  CMPL_MON_DATE, KEY_HASH, DATA_HASH)
       SELECT v_ComplianceMonitoringSubmission, UUID(), PRMT_IDENT,  CMPL_MON_CATG_CODE,  CMPL_MON_DATE, KEY_HASH, '0' as DATA_HASH
         FROM ICS_SUBM_RESULTS
        WHERE RESULT_CODE = 'CM030'
          AND SUBM_TYPE_NAME = 'ComplianceMonitoringSubmission'
          AND SUBM_TRANSACTION_ID = pi_transaction_id
          AND KEY_HASH NOT IN (SELECT KEY_HASH FROM ga_ics_flow_icis.ICS_CMPL_MON)
     GROUP BY PRMT_IDENT,  CMPL_MON_CATG_CODE,  CMPL_MON_DATE, KEY_HASH;

  -- Add keys that already exist in ICIS for module ICS_EFFLU_TRADE_PRTNER
  SET v_marker = 'INSERT INTO ICS_EFFLU_TRADE_PRTNER'; 
  INSERT INTO ga_ics_flow_icis.ICS_EFFLU_TRADE_PRTNER (ICS_PAYLOAD_ID, ICS_EFFLU_TRADE_PRTNER_ID, PRMT_IDENT,  PRMT_FEATR_IDENT,  LMT_SET_DESIGNATOR,  PARAM_CODE,  MON_SITE_DESC_CODE,  LMT_SEASON_NUM,  LMT_START_DATE,  LMT_END_DATE,  LMT_MOD_EFFECTIVE_DATE,  TRADE_ID, KEY_HASH, DATA_HASH)
       SELECT v_EffluentTradePartnerSubmission, UUID(), PRMT_IDENT,  PRMT_FEATR_IDENT,  LMT_SET_DESIGNATOR,  PARAM_CODE,  MON_SITE_DESC_CODE,  LMT_SEASON_NUM,  LMT_START_DATE,  LMT_END_DATE,  LMT_MOD_EFFECTIVE_DATE,  TRADE_ID, KEY_HASH, '0' as DATA_HASH
         FROM ICS_SUBM_RESULTS
        WHERE RESULT_CODE = 'ETP030'
          AND SUBM_TYPE_NAME = 'EffluentTradePartnerSubmission'
          AND SUBM_TRANSACTION_ID = pi_transaction_id
          AND KEY_HASH NOT IN (SELECT KEY_HASH FROM ga_ics_flow_icis.ICS_EFFLU_TRADE_PRTNER)
     GROUP BY PRMT_IDENT,  PRMT_FEATR_IDENT,  LMT_SET_DESIGNATOR,  PARAM_CODE,  MON_SITE_DESC_CODE,  LMT_SEASON_NUM,  LMT_START_DATE,  LMT_END_DATE,  LMT_MOD_EFFECTIVE_DATE,  TRADE_ID, KEY_HASH;

  -- Add keys that already exist in ICIS for module ICS_FRML_ENFRC_ACTN
  SET v_marker = 'INSERT INTO ICS_FRML_ENFRC_ACTN'; 
  INSERT INTO ga_ics_flow_icis.ICS_FRML_ENFRC_ACTN (ICS_PAYLOAD_ID, ICS_FRML_ENFRC_ACTN_ID, ENFRC_ACTN_IDENT, KEY_HASH, DATA_HASH)
       SELECT v_FormalEnforcementActionSubmission, UUID(), ENFRC_ACTN_IDENT, KEY_HASH, '0' as DATA_HASH
         FROM ICS_SUBM_RESULTS
        WHERE RESULT_CODE = 'FEA030'
          AND SUBM_TYPE_NAME = 'FormalEnforcementActionSubmission'
          AND SUBM_TRANSACTION_ID = pi_transaction_id
          AND KEY_HASH NOT IN (SELECT KEY_HASH FROM ga_ics_flow_icis.ICS_FRML_ENFRC_ACTN)
     GROUP BY ENFRC_ACTN_IDENT, KEY_HASH;

  -- Add keys that already exist in ICIS for module ICS_INFRML_ENFRC_ACTN
  SET v_marker = 'INSERT INTO ICS_INFRML_ENFRC_ACTN'; 
  INSERT INTO ga_ics_flow_icis.ICS_INFRML_ENFRC_ACTN (ICS_PAYLOAD_ID, ICS_INFRML_ENFRC_ACTN_ID, ENFRC_ACTN_IDENT, KEY_HASH, DATA_HASH)
       SELECT v_InformalEnforcementActionSubmission, UUID(), ENFRC_ACTN_IDENT, KEY_HASH, '0' as DATA_HASH
         FROM ICS_SUBM_RESULTS
        WHERE RESULT_CODE IN ('IEA030','FEA030') -- = 'IEA030'
          AND SUBM_TYPE_NAME = 'InformalEnforcementActionSubmission'
          AND SUBM_TRANSACTION_ID = pi_transaction_id
          AND KEY_HASH NOT IN (SELECT KEY_HASH FROM ga_ics_flow_icis.ICS_INFRML_ENFRC_ACTN)
     GROUP BY ENFRC_ACTN_IDENT, KEY_HASH;

  -- Add keys that already exist in ICIS for module ICS_SNGL_EVT_VIOL
  SET v_marker = 'INSERT INTO ICS_SNGL_EVT_VIOL'; 
  INSERT INTO ga_ics_flow_icis.ICS_SNGL_EVT_VIOL (ICS_PAYLOAD_ID, ICS_SNGL_EVT_VIOL_ID, PRMT_IDENT,  SNGL_EVT_VIOL_CODE,  SNGL_EVT_VIOL_DATE, KEY_HASH, DATA_HASH)
       SELECT v_SingleEventViolationSubmission, UUID(), PRMT_IDENT,  SNGL_EVT_VIOL_CODE,  SNGL_EVT_VIOL_DATE, KEY_HASH, '0' as DATA_HASH
         FROM ICS_SUBM_RESULTS
        WHERE RESULT_CODE = 'SEV030'
          AND SUBM_TYPE_NAME = 'SingleEventViolationSubmission'
          AND SUBM_TRANSACTION_ID = pi_transaction_id
          AND KEY_HASH NOT IN (SELECT KEY_HASH FROM ga_ics_flow_icis.ICS_SNGL_EVT_VIOL)
     GROUP BY PRMT_IDENT,  SNGL_EVT_VIOL_CODE,  SNGL_EVT_VIOL_DATE, KEY_HASH;

-- Step 6: Record counts into ICS_SUBM_HIST

SET v_marker = 'INSERT INTO ICS_SUBM_HIST'; 
INSERT INTO ICS_SUBM_HIST (
       ICS_SUBM_HIST_ID
     , SUBM_DATE_TIME
     , SUBM_TRANSACTION_ID
     , SUBM_TYPE_NAME
     , TRANS_COUNT_NEW
     , TRANS_COUNT_CHNG_REPL
     , TRANS_COUNT_DEL_MASS_DEL
     , ERROR_COUNT
     , WARNING_COUNT
     , ACCEPTED_COUNT
     , ACCEPTED_COUNT_TOTAL
     , CREATED_DATE_TIME)
SELECT UUID() AS ICS_SUBM_HIST_ID
     , SUBM_DATE_TIME
     , SUBM_TRANSACTION_ID 
     , SUBM_TYPE_NAME
     , COALESCE(TRANS_COUNT_NEW, 0)
     , COALESCE(TRANS_COUNT_CHNG_REPL, 0)
     , COALESCE(TRANS_COUNT_DEL_MASS_DEL, 0)
     , ERROR_COUNT
     , WARNING_COUNT
     , ACCEPTED_COUNT
     , COALESCE(ACCEPTED_COUNT_TOTAL, 0)
     , NOW() AS CREATED_DATE_TIME
  FROM ICS_V_MODULE_COUNT;
   --
   SET po_status = 1;
   SET po_errm   = 'COMPLETED';
END;

