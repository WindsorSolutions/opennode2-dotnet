USE ga_ics_flow_local;
DROP PROCEDURE IF EXISTS load_ics_basic_prmt_sp;
CREATE PROCEDURE load_ics_basic_prmt_sp
   (OUT po_status INT
   ,OUT po_errm   VARCHAR(255))
BEGIN
-- ============================================================================
-- MODIFICATION HISTORY
-- Person      Date       Comments
-- ---------   --------   -----------------------------------------------------
-- Jen Go      20120912   Created.  
--
-- ============================================================================
   DECLARE v_startdtm   DATETIME     DEFAULT NOW();
   DECLARE v_enddtm     DATETIME;
   DECLARE v_marker     VARCHAR(255);
   DECLARE v_sp_name    VARCHAR(64)  DEFAULT 'load_ics_basic_prmt_sp';
   DECLARE v_tgt_tbl    VARCHAR(64)  DEFAULT 'ICS_BASIC_PRMT';
   DECLARE v_src_tbl    VARCHAR(64)  DEFAULT 'stg_permit_main';
   DECLARE v_rowcount   INT          DEFAULT 0;
   --
   DECLARE EXIT HANDLER FOR SQLEXCEPTION
      BEGIN  
         ROLLBACK;
         SET po_status = -1;
         SET po_errm   = v_marker;
         CALL ics_etl_log_sp    
            (v_sp_name          -- pi_sp_name
            ,v_marker           -- pi_marker
            ,v_tgt_tbl          -- pi_tgt_tbl
            ,v_src_tbl          -- pi_src_tbl
            ,v_startdtm         -- pi_startdtm
            ,NOW()              -- pi_enddtm
            ,'FAILED'           -- pi_process
            ,-1);               -- pi_value
      END;
   --
   SET v_marker  = 'INSERT INTO ICS_BASIC_PRMT';
   INSERT INTO ICS_BASIC_PRMT
      (ICS_BASIC_PRMT_ID
      ,ICS_PAYLOAD_ID
      ,SRC_SYSTM_IDENT
      ,PRMT_IDENT
      ,PRMT_TYPE_CODE
      ,AGNCY_TYPE_CODE
      ,PRMT_ISSUE_DATE
      ,PRMT_EFFECTIVE_DATE
      ,PRMT_EXPR_DATE
      ,TTL_APPL_DSGN_FLOW_NUM
      ,TTL_APPL_AVER_FLOW_NUM
      ,APPL_RCVD_DATE
      ,PRMT_APPL_CMPL_DATE
      ,DMR_COGNZNT_OFCL
      ,DMR_COGNZNT_OFCL_TELEPH_NUM)
   SELECT DISTINCT ICS_BASIC_PRMT_ID
         ,'BasicPermit'
         ,SRC_SYSTEM_IDENT
         ,PRMT_IDENT
         ,'NPD' -- PRMT_TYPE_CODE
         ,'ST6' -- AGNCY_TYPE_CODE
         ,PRMT_ISSUE_DATE
         ,PRMT_EFFECTIVE_DATE
         ,PRMT_EXPR_DATE
         ,TTL_APPL_DSGN_FLOW_NUM
         ,TTL_APPL_AVER_FLOW_NUM
         ,APPL_RCVD_DATE
         ,PRMT_APPL_CMPL_DATE
         ,DMR_COGNZNT_OFCL
         ,TELEPHONE_NUMBER
     FROM stg_permit_main
    WHERE ICS_BASIC_PRMT_ID IS NOT NULL;
   --
   SET v_rowcount = (SELECT ROW_COUNT());
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm    -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'INSERT'      -- pi_process
      ,v_rowcount);  -- pi_value
   -- -------------- --
   --  END PROCEDURE --
   -- -------------- --
   SET v_marker = 'CALL ics_etl_log_sp END';
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_sp_name     -- pi_marker
      ,NULL          -- pi_tgt_tbl
      ,NULL          -- pi_src_tbl 
      ,v_startdtm    -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'COMPLETED'   -- pi_process
      ,0);           -- pi_value
   --
   SET po_status = 1;
   SET po_errm   = '';
   --
END