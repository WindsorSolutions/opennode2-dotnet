USE ga_ics_flow_local;
DROP PROCEDURE IF EXISTS load_ics_sngl_evt_viol_sp;
CREATE PROCEDURE load_ics_sngl_evt_viol_sp
   (OUT po_status INT
   ,OUT po_errm   VARCHAR(255))
BEGIN
-- ============================================================================
-- MODIFICATION HISTORY
-- Person      Date       Comments
-- ---------   --------   -----------------------------------------------------
-- Jen Go      20120924   Created.  
--
-- ============================================================================
   DECLARE v_startdtm   DATETIME     DEFAULT NOW();
   DECLARE v_enddtm     DATETIME;
   DECLARE v_marker     VARCHAR(255);
   DECLARE v_sp_name    VARCHAR(64)  DEFAULT 'load_ics_sngl_evt_viol_sp';
   DECLARE v_tgt_tbl    VARCHAR(64)  DEFAULT 'ICS_SNGL_EVT_VIOL';
   DECLARE v_src_tbl    VARCHAR(64)  DEFAULT 'VIOLATION;PERMIT';
   DECLARE v_rowcount   INT          DEFAULT 0;
   --
   DECLARE EXIT HANDLER FOR SQLEXCEPTION
      BEGIN  
         ROLLBACK;
         SET po_status = -1;
         SET po_errm   = v_marker;
         CALL ics_etl_log_sp    
            (v_sp_name          -- pi_sp_name
            ,v_marker           -- pi_marker
            ,v_tgt_tbl          -- pi_tgt_tbl
            ,v_src_tbl          -- pi_src_tbl
            ,v_startdtm         -- pi_startdtm
            ,NOW()              -- pi_enddtm
            ,'FAILED'           -- pi_process
            ,-1);               -- pi_value
         COMMIT;
      END;
   --
   SET v_marker = 'SET SESSION group_concat_max_len';
   SET SESSION group_concat_max_len=10000;
   --
   SET v_marker  = 'INSERT INTO ICS_SNGL_EVT_VIOL';
   INSERT INTO ICS_SNGL_EVT_VIOL
      (ICS_SNGL_EVT_VIOL_ID
      ,ICS_PAYLOAD_ID
      ,PRMT_IDENT
      ,SNGL_EVT_VIOL_CODE
      ,SNGL_EVT_VIOL_DATE
      ,SNGL_EVT_CMNT_TXT)
   SELECT UUID()
         ,'SingleEventViolation'
         ,NUMBER
         ,VIOLATION_TYPE_CODE
         ,VIOLATION_DATE
         ,SUBSTRING(COMMENT,1,4000)
     FROM (SELECT DISTINCT pmt.NUMBER
                 ,vio.VIOLATION_TYPE_CODE
                 ,vio.VIOLATION_DATE
                 ,@cmtxt := GROUP_CONCAT(@cmtxt,CHAR(10),vio.COMMENT) COMMENT
             FROM wrp.PERMIT pmt
             JOIN wrp.VIOLATION vio
               ON vio.PERMIT_ID = pmt.PERMIT_ID
             JOIN (SELECT @cmtxt := '') cmtxt
            WHERE vio.INSPECTION_ID IN (SELECT INSPECTION_ID
                                          FROM wrp.INSPECTION)
            GROUP BY pmt.NUMBER
                    ,vio.VIOLATION_TYPE_CODE
                    ,vio.VIOLATION_DATE
          ) vw;
   --
   SET v_rowcount = (SELECT ROW_COUNT());
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm    -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'INSERT'      -- pi_process
      ,v_rowcount);  -- pi_value
   -- -------------- --
   --  END PROCEDURE --
   -- -------------- --
   SET v_marker = 'CALL ics_etl_log_sp END';
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_sp_name     -- pi_marker
      ,NULL          -- pi_tgt_tbl
      ,NULL          -- pi_src_tbl 
      ,v_startdtm    -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'COMPLETED'   -- pi_process
      ,0);           -- pi_value
   --
   SET po_status = 1;
   SET po_errm   = '';
   --
END