USE ga_ics_flow_local;
DROP PROCEDURE IF EXISTS load_ics_geo_coord_sp;
CREATE PROCEDURE load_ics_geo_coord_sp
   (OUT po_status INT
   ,OUT po_errm   VARCHAR(255))
BEGIN
-- ============================================================================
-- MODIFICATION HISTORY
-- Person      Date       Comments
-- ---------   --------   -----------------------------------------------------
-- Jen Go      20120921   Created.  
--                        Sources:
--                          1) stg_permit_main/ICS_UNPRMT_FAC_ID
--                          2) stg_permit_main/ICS_PRMT_FEATR_ID
-- ============================================================================
   DECLARE v_startdtm   DATETIME     DEFAULT NOW();
   DECLARE v_enddtm     DATETIME;
   DECLARE v_marker     VARCHAR(255);
   DECLARE v_sp_name    VARCHAR(64)  DEFAULT 'load_ics_geo_coord_sp';
   DECLARE v_tgt_tbl    VARCHAR(64)  DEFAULT 'ICS_GEO_COORD';
   DECLARE v_src_tbl    VARCHAR(64)  DEFAULT 'stg_permit_main';
   DECLARE v_rowcount   INT          DEFAULT 0;
   --
   DECLARE EXIT HANDLER FOR SQLEXCEPTION
      BEGIN  
         ROLLBACK;
         SET po_status = -1;
         SET po_errm   = v_marker;
         CALL ics_etl_log_sp    
            (v_sp_name          -- pi_sp_name
            ,v_marker           -- pi_marker
            ,v_tgt_tbl          -- pi_tgt_tbl
            ,v_src_tbl          -- pi_src_tbl
            ,v_startdtm         -- pi_startdtm
            ,NOW()              -- pi_enddtm
            ,'FAILED'           -- pi_process
            ,-1);               -- pi_value
      END;
   --
   SET v_marker  = 'INSERT INTO ICS_GEO_COORD';
   INSERT INTO ICS_GEO_COORD
      (ICS_GEO_COORD_ID
      ,ICS_FAC_ID
      ,ICS_UNPRMT_FAC_ID
      ,ICS_PRMT_FEATR_ID
      ,LAT_MEAS
      ,LONG_MEAS
      ,HORZ_ACCURACY_MEAS
      ,GEOMETRIC_TYPE_CODE
      ,HORZ_COLL_METHOD_CODE
      ,HORZ_REF_DATUM_CODE
      ,REF_POINT_CODE
      ,SRC_MAP_SCALE_NUM)
   SELECT UUID()
         ,vw.*
     FROM (SELECT DISTINCT ICS_FAC_ID
                 -- ,ICS_BASIC_PRMT_ID
                 -- ,ICS_GNRL_PRMT_ID
                 ,ICS_UNPRMT_FAC_ID
                 ,NULL              ICS_PRMT_FEATR_ID
                 ,LAT_MEAS
                 ,LONG_MEAS
                 ,HORZ_ACCURACY_MEAS
                 ,'001'     GEOMETRIC_TYPE_CODE
                 ,HORZ_COLL_METHOD_CODE
                 ,HORZ_REF_DATUM_CODE
                 ,REF_POINT_CODE
                 ,SRC_MAP_SCALE_NUM
             FROM stg_permit_main
            WHERE (   LAT_MEAS               IS NOT NULL
                   OR LONG_MEAS              IS NOT NULL
                   OR HORZ_ACCURACY_MEAS     IS NOT NULL
                   OR HORZ_COLL_METHOD_CODE  IS NOT NULL
                   OR HORZ_REF_DATUM_CODE    IS NOT NULL
                   OR REF_POINT_CODE         IS NOT NULL
                   OR SRC_MAP_SCALE_NUM      IS NOT NULL)
              AND (   (    ICS_BASIC_PRMT_ID IS NOT NULL
                       AND ICS_FAC_ID        IS NOT NULL)
                   OR (    ICS_GNRL_PRMT_ID  IS NOT NULL
                       AND ICS_FAC_ID        IS NOT NULL)
                   OR (ICS_UNPRMT_FAC_ID IS NOT NULL) ) 
           UNION ALL
           SELECT DISTINCT NULL -- ICS_FAC_ID
                 -- ,NULL          -- ICS_BASIC_PRMT
                 -- ,NULL          -- ICS_GNRL_PRMT_ID
                 ,NULL          -- ICS_UNPRMT_FAC_ID
                 ,ICS_PRMT_FEATR_ID
                 ,LAT_MEAS
                 ,LONG_MEAS
                 ,HORZ_ACCURACY_MEAS
                 ,NULL          -- GEOMETRIC_TYPE_CODE
                 ,HORZ_COLL_METHOD_CODE
                 ,HORZ_REF_DATUM_CODE
                 ,REF_POINT_CODE
                 ,SRC_MAP_SCALE_NUM
             FROM tmp_stg_prmt_featr
            WHERE (   LAT_MEAS               IS NOT NULL
                   OR LONG_MEAS              IS NOT NULL
                   OR HORZ_ACCURACY_MEAS     IS NOT NULL
                   OR HORZ_COLL_METHOD_CODE  IS NOT NULL
                   OR HORZ_REF_DATUM_CODE    IS NOT NULL
                   OR REF_POINT_CODE         IS NOT NULL
                   OR SRC_MAP_SCALE_NUM      IS NOT NULL)
              AND ICS_PRMT_FEATR_ID IS NOT NULL          
          ) vw;
   --
   SET v_rowcount = (SELECT ROW_COUNT());
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm    -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'INSERT'      -- pi_process
      ,v_rowcount);  -- pi_value
   -- -------------- --
   --  END PROCEDURE --
   -- -------------- --
   SET v_marker = 'CALL ics_etl_log_sp END';
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_sp_name     -- pi_marker
      ,NULL          -- pi_tgt_tbl
      ,NULL          -- pi_src_tbl 
      ,v_startdtm    -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'COMPLETED'   -- pi_process
      ,0);           -- pi_value
   --
   SET po_status = 1;
   SET po_errm   = '';
   --
END