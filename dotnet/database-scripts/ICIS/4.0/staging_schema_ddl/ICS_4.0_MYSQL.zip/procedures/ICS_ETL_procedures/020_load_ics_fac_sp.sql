USE ga_ics_flow_local;
DROP PROCEDURE IF EXISTS load_ics_fac_sp;
CREATE PROCEDURE load_ics_fac_sp
   (OUT po_status INT
   ,OUT po_errm   VARCHAR(255))
BEGIN
-- ============================================================================
-- MODIFICATION HISTORY
-- Person      Date       Comments
-- ---------   --------   -----------------------------------------------------
-- Jen Go      20120912   Created.  
--
-- ============================================================================
   DECLARE v_startdtm   DATETIME     DEFAULT NOW();
   DECLARE v_enddtm     DATETIME;
   DECLARE v_marker     VARCHAR(255);
   DECLARE v_sp_name    VARCHAR(64)  DEFAULT 'load_ics_fac_sp';
   DECLARE v_tgt_tbl    VARCHAR(64)  DEFAULT 'ICS_FAC';
   DECLARE v_src_tbl    VARCHAR(64)  DEFAULT 'stg_permit_main';
   DECLARE v_rowcount   INT          DEFAULT 0;
   --
   DECLARE EXIT HANDLER FOR SQLEXCEPTION
      BEGIN  
         ROLLBACK;
         SET po_status = -1;
         SET po_errm   = CONCAT('Error occurred at ',v_marker);
         CALL ics_etl_log_sp
            (v_sp_name
            ,v_marker
            ,v_tgt_tbl
            ,v_startdtm
            ,v_enddtm
            ,-1
            ,po_errm);
         COMMIT;
      END;
   --
   SET v_marker = 'INSERT INTO ICS_FAC';
   INSERT INTO ICS_FAC
      (ICS_FAC_ID
      ,ICS_BASIC_PRMT_ID
      ,ICS_GNRL_PRMT_ID
      ,FAC_SITE_NAME
      ,LOC_ADDR_TXT
      ,LOCALITY_NAME
      ,LOC_ST_CODE
      ,LOC_ZIP_CODE
      ,LOC_COUNTRY_CODE
      ,FAC_TYPE_OF_OWNERSHIP_CODE)
   SELECT DISTINCT ICS_FAC_ID
         ,ICS_BASIC_PRMT_ID
         ,ICS_GNRL_PRMT_ID
         ,FAC_SITE_NAME
         ,SUBSTRING(LOC_ADDR_TXT,1,50)  -- length() > varchar(50) gets truncated
         ,LOCALITY_NAME
         ,LOC_ST_CODE
         ,LOC_ZIP_CODE
         ,LOC_COUNTRY_CODE
         ,FAC_TYPE_OF_OWNERSHIP_CODE
     FROM stg_permit_main
    WHERE ICS_FAC_ID IS NOT NULL;
   --
   SET v_rowcount = (SELECT ROW_COUNT());
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm    -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'INSERT'      -- pi_process
      ,v_rowcount);  -- pi_value
   --
   -- insert into log table where length() > varchar(50) gets truncated?
   -- 
   -- -------------- --
   --  END PROCEDURE --
   -- -------------- --
   SET v_marker = 'CALL ics_etl_log_sp END';
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_sp_name     -- pi_marker
      ,NULL          -- pi_tgt_tbl
      ,NULL          -- pi_src_tbl 
      ,v_startdtm    -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'COMPLETED'   -- pi_process
      ,0);           -- pi_value
   --
   SET po_status = 1;
   SET po_errm   = '';
   --
END         