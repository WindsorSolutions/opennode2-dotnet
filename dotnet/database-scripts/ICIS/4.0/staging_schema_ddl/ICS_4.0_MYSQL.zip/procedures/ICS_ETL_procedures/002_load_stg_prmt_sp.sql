DROP PROCEDURE IF EXISTS load_stg_prmt_sp;
CREATE PROCEDURE `load_stg_prmt_sp`
   (OUT po_status INT
   ,OUT po_errm   VARCHAR(1000))
BEGIN
-- ============================================================================
-- MODIFICATION HISTORY
-- Person      Date       Comments
-- ---------   --------   -----------------------------------------------------
-- Jen Go      20120920   Created.  
--
-- ============================================================================
   DECLARE v_startdtm   DATETIME     DEFAULT NOW();
   DECLARE v_enddtm     DATETIME;
   DECLARE v_marker     VARCHAR(255);
   DECLARE v_sp_name    VARCHAR(64) DEFAULT 'load_stg_prmt_sp';
   DECLARE v_tgt_tbl
          ,v_src_tbl    VARCHAR(64);
   --
   DECLARE EXIT HANDLER FOR SQLEXCEPTION
      BEGIN  
         ROLLBACK;
         -- GET DIAGNOSTICS CONDITION 1
         --    v_errcode = RETURNED_SQLSTATE, v_errm = MESSAGE_TEXT;
         SET po_status = -1;
         SET po_errm   = v_marker;
         -- 
         CALL ics_etl_log_sp    
            (v_sp_name          -- pi_sp_name
            ,v_marker           -- pi_marker
            ,v_tgt_tbl          -- pi_tgt_tbl
            ,v_src_tbl          -- pi_src_tbl
            ,v_startdtm         -- pi_startdtm
            ,NOW()              -- pi_enddtm
            ,'FAILED'           -- pi_process
            ,-1);               -- pi_value
         --
      END;
   -- -------------------------------------------------------
   -- tmp_stg_basic_prmt_main (ics_basic_prmt; ics_gnrl_prmt)
   -- -------------------------------------------------------
   -- create temp table instead of a view because views error out with 
   -- subqueries.
   --   
   -- create temporary tables for use in inline views, for performance
   SET v_marker = 'DROP AND CREATE TEMPORARY TABLE tmp_affil';
   DROP TABLE IF EXISTS tmp_affl;
   CREATE TEMPORARY TABLE tmp_affl AS
   SELECT affl.AFFILIATION_ID
         ,affl.PERMIT_ACTION_ID
         ,affl.AFFILIATION_TYPE_CODE
         ,affl.ORGANIZATION_ID 
         ,rat.ICIS_REF_AFFILIATION_TYPE
         ,addr.ADDRESS_TYPE_CODE
         ,addr_prsd.STREET_ADDRESS
         ,addr_prsd.LOCALITY
         ,addr_prsd.STATE_CODE
         ,addr_prsd.POSTAL_CODE
         ,addr_prsd.COUNTRY_CODE
         ,prsn.PERSON_ID 
         ,prsn.FIRST_NAME
         ,prsn.LAST_NAME
         ,prsn.TITLE
         ,CASE WHEN rat.ICIS_REF_AFFILIATION_TYPE = 'DMR' AND
                    pc.CONTACT_TYPE_CODE          = 'WPH' THEN
             pc.VALUE 
          END          DMR_TELEPH_NUM
         ,CASE WHEN rat.ICIS_REF_AFFILIATION_TYPE <> 'DMR' AND
                    pc.CONTACT_TYPE_CODE          <> 'WPH' THEN
             pc.VALUE
          ELSE NULL END EMAIL_ADDR
     FROM wrp.AFFILIATION affl
     JOIN wrp.REF_AFFILIATION_TYPE rat
       ON rat.CODE = affl.AFFILIATION_TYPE_CODE
     -- --------
     -- ics_addr
     -- --------
     LEFT OUTER JOIN wrp.ADDRESS addr
       ON addr.AFFILIATION_ID    = affl.AFFILIATION_ID
     -- AND addr.ADDRESS_TYPE_CODE = 'MAIL'
     LEFT OUTER JOIN wrp.ADDRESS_PARSED addr_prsd 
       ON addr_prsd.ADDRESS_ID = addr.ADDRESS_ID
     -- -----------
     -- ics_contact
     -- -----------
     LEFT OUTER JOIN wrp.PERSON prsn
       ON prsn.PERSON_ID = affl.PERSON_ID
     LEFT OUTER JOIN wrp.PERSON_CONTACT pc
       ON pc.PERSON_ID         = prsn.PERSON_ID
      AND pc.CONTACT_TYPE_CODE IN ('EM','WPH')
      -- !('PMA') flow to FACILITY only
    WHERE rat.ICIS_REF_AFFILIATION_TYPE IN ('OWN','OPE','PCT','PMA','DMR');
   --
   SET v_marker = 'CREATE INDEX tmp_ix_affl_prmt_id';
   CREATE INDEX tmp_ix_affl_prmt_id ON tmp_affl(PERMIT_ACTION_ID);
   --
   SET v_marker = 'DROP AND CREATE TEMPORARY TABLE tmp_fac';
   DROP TABLE IF EXISTS tmp_fac;
   CREATE TEMPORARY TABLE tmp_fac AS
   SELECT fac.FACILITY_SITE_NAME
         ,addr.LOCATION_ADDRESS
         ,addr_prsd.LOCALITY
         ,addr_prsd.STATE_CODE
         ,addr_prsd.POSTAL_CODE
         ,addr_prsd.COUNTRY_CODE
         ,fac.FACILITY_ID
         ,loc.HORIZ_ACC_MEASURE
         ,loc.HORIZ_COLL_METH_CODE
         ,loc.HORIZ_REF_DATUM_CODE
         ,loc.REFERENCE_POINT_CODE
         ,loc.SOURCE_MAP_SCALE_NUMBER
         ,loc_coord.LATITUDE
         ,loc_coord.LONGITUDE
         ,fac.OWNERSHIP_TYPE_CODE
         ,rot.ICIS_FACILITY_TYPE_CODE
     FROM wrp.FACILITY fac
     JOIN wrp.LOCATION loc
       ON loc.FACILITY_ID = fac.FACILITY_ID
     LEFT OUTER JOIN wrp.REF_OWNERSHIP_TYPE rot
       ON rot.CODE = fac.OWNERSHIP_TYPE_CODE
     LEFT OUTER JOIN wrp.ADDRESS addr
       ON addr.LOCATION_ID = loc.LOCATION_ID
     LEFT OUTER JOIN wrp.ADDRESS_PARSED addr_prsd
       ON addr_prsd.ADDRESS_ID   = addr.ADDRESS_ID
      AND addr.ADDRESS_TYPE_CODE = 'ST'
     LEFT OUTER JOIN wrp.LOCATION_COORD loc_coord
       ON loc_coord.LOCATION_ID = loc.LOCATION_ID
      AND loc_coord.`INDEX`     = 0;
   --
   SET v_marker = 'CREATE INDEX tmp_ix_fac_facility_id';
   CREATE INDEX tmp_ix_fac_facility_id ON tmp_fac(FACILITY_ID);   
   -- -----------------------
   -- tmp_stg_basic_prmt_main
   -- -----------------------
   SET v_tgt_tbl = 'tmp_stg_basic_prmt_main';
   SET v_marker  = 'DROP TABLE and CREATE TABLE tmp_stg_permit_main (ics_basic_prmt; ics_gnrl_prmt)';
   -- SELECT v_marker; -- jentmp
   --
   DROP TABLE IF EXISTS tmp_stg_prmt_main;
   CREATE TABLE tmp_stg_prmt_main AS
   SELECT PERMIT_ID
         ,PERMIT_CATEGORY_CODE
         ,PERMIT_TYPE_CODE
         ,PERMIT_ACTION_ID
         ,PERMIT_ACTION_STATUS_CODE
         ,PERMIT_ACTION_TYPE_CODE
         ,IS_MASTER
         -- ----------------------------
         -- ics_basic_prmt/ics_gnrl_prmt
         -- ----------------------------
         ,ASSC_MASTER_GNRL_PRMT_IDENT
         ,ICIS_NUMBER
         ,PRMT_IDENT
         ,ISSUE_DATE
         ,EFFECTIVE_DATE
         ,EXPIRATION_DATE
         -- issue_date
         ,PRMT_ISSUE_DATE
         ,PRMT_EFFECTIVE_DATE
         ,PRMT_EXPIRATION_DATE
         ,MAX(TTL_APPL_DSGN_FLOW_NUM) TTL_APPL_DSGN_FLOW_NUM
         ,MAX(TTL_APPL_AVER_FLOW_NUM) TTL_APPL_AVER_FLOW_NUM
         ,APPL_RCVD_DATE
         ,PRMT_APPL_CMPL_DATE
         ,DMR_COGNZNT_OFCL
         ,DMR_COGNZNT_OFCL_TELEPH_NUM
         -- --------- 
         -- ics_addr
         -- ---------
         ,ICIS_REF_AFFILIATION_TYPE
         ,AFFIL_TYPE_TXT
         ,ORG_FRML_NAME
         ,MAILING_ADDR_TXT
         ,MAILING_ADDR_CITY_NAME
         ,MAILING_ADDR_ST_CODE
         ,MAILING_ADDR_ZIP_CODE
         ,MAILING_ADDR_COUNTRY_CODE
         -- -------------
         -- icis_contact
         -- -------------
         ,FIRST_NAME
         ,LAST_NAME
         ,TITLE
         ,ELEC_ADDR_TXT
         -- ---------------
         -- ics_efflu_guide
         -- ---------------
         ,MAX(EFFLU_GUIDE_CODE)  EFFLU_GUIDE_CODE
         -- --------
         -- ics_fac
         -- --------
         ,FACILITY_SITE_NAME
         ,LOC_ADDR_TXT
         ,LOCALITY_NAME
         ,LOC_ST_CODE
         ,LOC_ZIP_CODE
         ,LOC_COUNTRY_CODE
         ,FAC_TYPE_OF_OWNERSHIP_CODE
         -- --------------
         -- ics_geo_coord
         -- --------------
         ,HORIZ_ACC_MEASURE
         ,HORIZ_COLL_METH_CODE
         ,HORIZ_REF_DATUM_CODE
         ,REF_POINT_CODE
         ,SRC_MAP_SCALE_NUM
         ,LAT_MEAS
         ,LONG_MEAS
         ,FACILITY_ID
         -- ----------
         -- ics_naics
         -- ----------
         ,NAICS_CODE
         ,NAICS_PRIMARY_IND_CODE
         -- --------
         -- ics_sic
         -- --------
         ,SIC_CODE
         ,SIC_PRIMARY_IND_CODE
     FROM (SELECT DISTINCT pmt.PERMIT_ID                               PERMIT_ID
                 -- ,pmt.PERMIT_CATEGORY_CODE                             PERMIT_CATEGORY_CODE
                 ,rpc.ICIS_PERMIT_TYPE_CODE                            PERMIT_CATEGORY_CODE
                 ,pmt.PERMIT_TYPE_CODE                                 PERMIT_TYPE_CODE
                 ,pa.PERMIT_ACTION_ID                                  PERMIT_ACTION_ID -- SRC_SYSTEM_IDENT
                 ,pa.PERMIT_ACTION_STATUS_CODE                         PERMIT_ACTION_STATUS_CODE
                 ,pa.PERMIT_ACTION_TYPE_CODE                           PERMIT_ACTION_TYPE_CODE
                 ,pmt.IS_MASTER                                        IS_MASTER
                 -- ----------------------------
                 -- ics_basic_prmt/ics_gnrl_prmt
                 -- ----------------------------
                 ,(SELECT NUMBER
                     FROM wrp.GENERAL_PERMIT
                    WHERE GENERAL_PERMIT_ID = pmt.GENERAL_PERMIT_ID)   ASSC_MASTER_GNRL_PRMT_IDENT
                 ,pmt.ICIS_NUMBER                                      ICIS_NUMBER
                 ,pmt.NUMBER                                           PRMT_IDENT
                 ,pa.ISSUE_DATE                                        ISSUE_DATE
                 ,pa.EFFECTIVE_DATE                                    EFFECTIVE_DATE
                 ,pa.EXPIRATION_DATE                                   EXPIRATION_DATE
                 -- issue_date
                 ,COALESCE(vw_max_pa_dates.MAX_ISSUE_DATE
                          ,pa.ISSUE_DATE)                              PRMT_ISSUE_DATE
                 ,COALESCE(vw_max_pa_dates.MAX_EFFECTIVE_DATE
                          ,pa.EFFECTIVE_DATE)                          PRMT_EFFECTIVE_DATE
                 ,COALESCE(vw_max_pa_dates.MAX_EXPIRATION_DATE
                          ,pa.EXPIRATION_DATE)                         PRMT_EXPIRATION_DATE
                 -- ttl_appl_dsgn_flow_num
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS001' THEN
                     qr.ANSWER_COMMENT
                  ELSE NULL END                                        TTL_APPL_DSGN_FLOW_NUM
                 -- ttl_appl_aver_flow_num
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS002' THEN
                     qr.ANSWER_COMMENT
                  ELSE NULL END                                        TTL_APPL_AVER_FLOW_NUM
                 --
                 ,pam.APPL_RCVD_DATE
                 ,pam.PRMT_APPL_CMPL_DATE
                 -- dmr_cognznt_ofcl
                 ,CASE WHEN vw_addr_cont.ICIS_REF_AFFILIATION_TYPE = 'DMR' THEN
                     CONCAT(vw_addr_cont.FIRST_NAME,' ',vw_addr_cont.LAST_NAME)
                  ELSE NULL
                  END                                                  DMR_COGNZNT_OFCL
                 ,DMR_TELEPH_NUM                                       DMR_COGNZNT_OFCL_TELEPH_NUM
                 -- --------- 
                 -- ics_addr
                 -- ---------
                 ,vw_addr_cont.ICIS_REF_AFFILIATION_TYPE               ICIS_REF_AFFILIATION_TYPE
                 ,'PMA'                                                AFFIL_TYPE_TXT
                 ,(SELECT org.NAME
                     FROM wrp.ORGANIZATION org
                    WHERE org.ORGANIZATION_ID = pa.OWNER_ID)           ORG_FRML_NAME
                 ,vw_addr_cont.STREET_ADDRESS                          MAILING_ADDR_TXT
                 ,vw_addr_cont.LOCALITY                                MAILING_ADDR_CITY_NAME
                 ,vw_addr_cont.STATE_CODE                              MAILING_ADDR_ST_CODE
                 ,vw_addr_cont.POSTAL_CODE                             MAILING_ADDR_ZIP_CODE
                 ,vw_addr_cont.COUNTRY_CODE                            MAILING_ADDR_COUNTRY_CODE
                 -- -------------
                 -- icis_contact
                 -- -------------
                 ,vw_addr_cont.FIRST_NAME                              FIRST_NAME
                 ,vw_addr_cont.LAST_NAME                               LAST_NAME
                 ,vw_addr_cont.TITLE                                   TITLE
                 ,vw_addr_cont.EMAIL_ADDR                              ELEC_ADDR_TXT
                 -- ---------------
                 -- ics_efflu_guide
                 -- ---------------
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS003' THEN
                     rqtc.ICIS_CODE 
                  ELSE NULL END                                        EFFLU_GUIDE_CODE
                 -- --------
                 -- ics_fac
                 -- --------
                 ,vw_fac_loc.FACILITY_SITE_NAME
                 ,vw_fac_loc.LOCATION_ADDRESS                          LOC_ADDR_TXT
                 ,vw_fac_loc.LOCALITY                                  LOCALITY_NAME
                 ,vw_fac_loc.STATE_CODE                                LOC_ST_CODE
                 ,vw_fac_loc.POSTAL_CODE                               LOC_ZIP_CODE
                 ,vw_fac_loc.COUNTRY_CODE                              LOC_COUNTRY_CODE
                 ,vw_fac_loc.ICIS_FACILITY_TYPE_CODE                   FAC_TYPE_OF_OWNERSHIP_CODE
                 -- --------------
                 -- ics_geo_coord
                 -- --------------
                 ,vw_fac_loc.HORIZ_ACC_MEASURE                         HORIZ_ACC_MEASURE
                 ,vw_fac_loc.HORIZ_COLL_METH_CODE                      HORIZ_COLL_METH_CODE
                 ,vw_fac_loc.HORIZ_REF_DATUM_CODE                      HORIZ_REF_DATUM_CODE
                 ,vw_fac_loc.REFERENCE_POINT_CODE                      REF_POINT_CODE
                 ,vw_fac_loc.SOURCE_MAP_SCALE_NUMBER                   SRC_MAP_SCALE_NUM
                 ,vw_fac_loc.LATITUDE                                  LAT_MEAS
                 ,vw_fac_loc.LONGITUDE                                 LONG_MEAS
                 ,pmt.FACILITY_ID                                      FACILITY_ID
                 -- ----------
                 -- ics_naics
                 -- ----------
                 ,fac_naics.NAICS_CODE                                 NAICS_CODE
                 ,CASE WHEN fac_naics.CODE_ORDER = 1 THEN
                      'Y'
                    ELSE
                      'N'
                   END                                                 NAICS_PRIMARY_IND_CODE
                 -- --------
                 -- ics_sic
                 -- --------
                 ,fac_sic.SIC_CODE                                     SIC_CODE
                 ,CASE WHEN fac_sic.CODE_ORDER = 1 THEN
                     'Y'
                  ELSE
                     'N'
                  END                                                  SIC_PRIMARY_IND_CODE
             FROM wrp.PERMIT pmt
             JOIN wrp.REF_PERMIT_CATEGORY rpc
               ON rpc.CODE = pmt.PERMIT_CATEGORY_CODE
             JOIN wrp.PERMIT_ACTION pa
               ON pa.PERMIT_ID = pmt.PERMIT_ID
             -- ---------------
             -- /ics_basic_prmt
             -- ---------------
             -- Select the date from the most recent and valid 
             -- (i.e., PERMIT_ACTION_STATUS_CODE NOT IN ('NOISS','TERM','WITH'))
             -- permit action for this permit where PERMIT_ACTION_TYPE_CODE IN ('NEW','REN').     
             LEFT OUTER JOIN 
                (SELECT ISSUE_DATE      MAX_ISSUE_DATE
                        ,EFFECTIVE_DATE  MAX_EFFECTIVE_DATE
                        ,EXPIRATION_DATE MAX_EXPIRATION_DATE
                        ,PERMIT_ID
                   FROM wrp.PERMIT_ACTION pa
                  WHERE PERMIT_ACTION_TYPE_CODE IN ('NEW','REN')
                    AND PERMIT_ACTION_STATUS_CODE NOT IN ('NOISS','TERM','WITH')
                    AND pa.`VERSION` = (SELECT MAX(pa2.`VERSION`)
                                          FROM wrp.PERMIT_ACTION pa2
                                         WHERE pa2.PERMIT_ID = pa.PERMIT_ID)
                                         GROUP BY PERMIT_ID) vw_max_pa_dates
               ON vw_max_pa_dates.PERMIT_ID = pa.PERMIT_ID
             --
             LEFT OUTER JOIN wrp.QUESTION_RESULT qr
               ON qr.PERMIT_ACTION_ID = pa.PERMIT_ACTION_ID
              AND qr.QUESTION_CODE IN ('ICIS001','ICIS002','ICIS003')
             --
             LEFT OUTER JOIN 
                (SELECT PERMIT_ID
                       ,PERMIT_ACTION_ID
                       ,MAX(APPL_RCVD_DATE)      APPL_RCVD_DATE
                       ,MAX(PRMT_APPL_CMPL_DATE) PRMT_APPL_CMPL_DATE
                   FROM (SELECT pa.PERMIT_ID
                               ,pa.PERMIT_ACTION_ID
                               ,CASE WHEN pam.MILESTONE_TYPE_CODE = 'APPREC' THEN
                                   pam.MILESTONE_DATE
                                END APPL_RCVD_DATE
                               ,CASE WHEN pam.MILESTONE_TYPE_CODE = 'APPCOM' THEN
                                   pam.MILESTONE_DATE
                                END PRMT_APPL_CMPL_DATE
                           FROM wrp.PERMIT_ACTION_MILESTONE pam
                           JOIN wrp.PERMIT_ACTION pa
                             ON pa.PERMIT_ACTION_ID = pam.PERMIT_ACTION_ID
                          WHERE pam.MILESTONE_TYPE_CODE IN ('APPREC','APPCOM')
                            AND pa.PERMIT_ACTION_STATUS_CODE NOT IN ('NOISS','TERM','WITH')
                            AND pa.`VERSION` = (SELECT MAX(pa2.`VERSION`)
                                                  FROM wrp.PERMIT_ACTION pa2
                                                 WHERE pa2.PERMIT_ID = pa.PERMIT_ID)) vw) pam
               ON pam.PERMIT_ID = pa.PERMIT_ID
             -- -----------------------------------------------------
             -- /ics_basic_prmt/ics_addr; /ics_basic_prmt/ics_contact
             -- -----------------------------------------------------
             LEFT OUTER JOIN tmp_affl vw_addr_cont
               ON vw_addr_cont.PERMIT_ACTION_ID = pa.PERMIT_ACTION_ID
             -- -------------------------------
             -- /ics_basic_prmt/ics_efflu_guide
             -- -------------------------------
             LEFT OUTER JOIN wrp.REF_QUESTION_TYPE_CHOICE rqtc
               ON rqtc.CODE = qr.ANSWER_CHOICE
             -- -----------------------
             -- /ics_basic_prmt/ics_fac
             -- -----------------------
             LEFT OUTER JOIN tmp_fac vw_fac_loc
                /* (SELECT fac.FACILITY_SITE_NAME
                       ,addr.LOCATION_ADDRESS
                       ,addr_prsd.LOCALITY
                       ,addr_prsd.STATE_CODE
                       ,addr_prsd.POSTAL_CODE
                       ,addr_prsd.COUNTRY_CODE
                       ,fac.FACILITY_ID
                       ,loc.HORIZ_ACC_MEASURE
                       ,loc.HORIZ_COLL_METH_CODE
                       ,loc.HORIZ_REF_DATUM_CODE
                       ,loc.REFERENCE_POINT_CODE
                       ,loc.SOURCE_MAP_SCALE_NUMBER
                       ,loc_coord.LATITUDE
                       ,loc_coord.LONGITUDE
                       ,fac.OWNERSHIP_TYPE_CODE
                   FROM wrp.FACILITY fac
                   JOIN wrp.LOCATION loc
                     ON loc.FACILITY_ID = fac.FACILITY_ID
                   LEFT OUTER JOIN wrp.ADDRESS addr
                     ON addr.LOCATION_ID = loc.LOCATION_ID
                   LEFT OUTER JOIN wrp.ADDRESS_PARSED addr_prsd
                     ON addr_prsd.ADDRESS_ID   = addr.ADDRESS_ID
                    AND addr.ADDRESS_TYPE_CODE = 'ST'
                   LEFT OUTER JOIN wrp.LOCATION_COORD loc_coord
                     ON loc_coord.LOCATION_ID = loc.LOCATION_ID
                    AND loc_coord.`INDEX`     = 0
                 ) vw_fac_loc */
               ON vw_fac_loc.FACILITY_ID = pmt.FACILITY_ID
             -- ------------------------------
             -- /ics_basic_prmt/ics_naics_code
             -- ------------------------------
             LEFT OUTER JOIN wrp.FACILITY_NAICS fac_naics
               ON fac_naics.FACILITY_ID = pmt.FACILITY_ID
             -- ----------------------------
             -- /ics_basic_prmt/ics_sic_code
             -- ----------------------------
             LEFT OUTER JOIN wrp.FACILITY_SIC fac_sic
               ON fac_sic.FACILITY_ID = pmt.FACILITY_ID
             --
            WHERE 1=1
              -- AND rpc.ICIS_PERMIT_TYPE_CODE IN ('NPD','IIU','APR','GPC')
              AND (   (    rpc.ICIS_PERMIT_TYPE_CODE = 'GPC'
                       AND pmt.PERMIT_TYPE_CODE      IN ('AFO','GEN CW'
                                                        ,'GEN PID','GEN SG'
                                                        ,'GEN WTP','MS4'
                                                        ,'REUSE') )
                   OR rpc.ICIS_PERMIT_TYPE_CODE IN ('NPD','IIU','APR') 
                  )
              AND pa.PERMIT_ACTION_STATUS_CODE = 'EFF'
              AND pmt.PERMIT_STATUS_CODE       IN ('EFF','EXT')
              AND NOT EXISTS (SELECT 1
                                FROM wrp.PERMIT_XREF xref
                               WHERE xref.PERMIT_RELATIONSHIP_TYPE_CODE = 'MGP'
                                 AND xref.PERMIT_ID_CHILD = pmt.PERMIT_ID))vw
    GROUP BY PERMIT_ID,PERMIT_CATEGORY_CODE,PERMIT_TYPE_CODE,PERMIT_ACTION_ID
            ,PERMIT_ACTION_STATUS_CODE,PERMIT_ACTION_TYPE_CODE,IS_MASTER
            ,ASSC_MASTER_GNRL_PRMT_IDENT,ICIS_NUMBER,PRMT_IDENT,ISSUE_DATE
            ,EFFECTIVE_DATE,EXPIRATION_DATE,PRMT_ISSUE_DATE,PRMT_EFFECTIVE_DATE
            ,PRMT_EXPIRATION_DATE,APPL_RCVD_DATE,PRMT_APPL_CMPL_DATE
            ,DMR_COGNZNT_OFCL,DMR_COGNZNT_OFCL_TELEPH_NUM,ICIS_REF_AFFILIATION_TYPE
            ,AFFIL_TYPE_TXT,ORG_FRML_NAME,MAILING_ADDR_TXT,MAILING_ADDR_CITY_NAME
            ,MAILING_ADDR_ST_CODE,MAILING_ADDR_ZIP_CODE,MAILING_ADDR_COUNTRY_CODE
            ,FIRST_NAME,LAST_NAME,TITLE,ELEC_ADDR_TXT,FACILITY_SITE_NAME
            ,LOC_ADDR_TXT,LOCALITY_NAME,LOC_ST_CODE,LOC_ZIP_CODE,LOC_COUNTRY_CODE
            ,FAC_TYPE_OF_OWNERSHIP_CODE,HORIZ_ACC_MEASURE,HORIZ_COLL_METH_CODE
            ,HORIZ_REF_DATUM_CODE,REF_POINT_CODE,SRC_MAP_SCALE_NUM,LAT_MEAS
            ,LONG_MEAS,FACILITY_ID,NAICS_CODE,NAICS_PRIMARY_IND_CODE
            ,SIC_CODE,SIC_PRIMARY_IND_CODE;
   -- ---------------
   -- stg_permit_main
   -- ---------------
   SET v_tgt_tbl = 'stg_permit_main';
   SET v_marker  = 'INSERT INTO stg_permit_main (ics_basic_prmt;ics_gnrl_prmt)';
   -- SELECT v_marker; -- jentmp
   INSERT INTO `stg_permit_main`
   SELECT vw_main.PERMIT_ID
         ,vw_main.PERMIT_CATEGORY_CODE
         ,vw_main.PERMIT_TYPE_CODE
         ,vw_main.PERMIT_ACTION_ID
         ,vw_main.PERMIT_ACTION_STATUS_CODE
         ,vw_main.PERMIT_ACTION_TYPE_CODE
         ,vw_main.FACILITY_ID
         ,vw_main.IS_MASTER
         ,vw_main.ASSC_MASTER_GNRL_PRMT_IDENT
         ,vw_main.ICIS_NUMBER
         ,vw_main.PRMT_IDENT
         ,vw_main.ISSUE_DATE
         ,vw_main.EFFECTIVE_DATE
         ,vw_main.EXPIRATION_DATE
         ,vw_main.PRMT_ISSUE_DATE
         ,vw_main.PRMT_EFFECTIVE_DATE
         ,vw_main.PRMT_EXPIRATION_DATE
         ,vw_main.DMR_COGNZNT_OFCL
         ,vw_main.DMR_COGNZNT_OFCL_TELEPH_NUM
         ,vw_main.TTL_APPL_DSGN_FLOW_NUM
         ,vw_main.TTL_APPL_AVER_FLOW_NUM
         ,vw_main.APPL_RCVD_DATE
         ,vw_main.PRMT_APPL_CMPL_DATE
         ,NULL   -- PRMT_USR_DFND_DAT_ELM_1_TXT
         ,NULL   -- PRMT_CMNTS_TXT
         ,vw_main.ICIS_REF_AFFILIATION_TYPE
         ,vw_main.AFFIL_TYPE_TXT
         ,vw_main.ORG_FRML_NAME
         ,vw_main.MAILING_ADDR_TXT
         ,vw_main.MAILING_ADDR_CITY_NAME
         ,vw_main.MAILING_ADDR_ST_CODE
         ,vw_main.MAILING_ADDR_ZIP_CODE
         ,vw_main.MAILING_ADDR_COUNTRY_CODE
         ,vw_main.FIRST_NAME
         ,vw_main.LAST_NAME
         ,vw_main.TITLE
         ,vw_main.ELEC_ADDR_TXT
         ,vw_main.EFFLU_GUIDE_CODE
         ,NULL  -- not mapped TELEPH_NUM_TYPE_CODE
         ,NULL  -- TELEPHONE_NUMBER
         ,NULL  -- TELEPH_EXT_NUM
         ,vw_main.FACILITY_SITE_NAME
         ,vw_main.LOC_ADDR_TXT
         ,vw_main.LOCALITY_NAME
         ,vw_main.LOC_ST_CODE
         ,vw_main.LOC_ZIP_CODE
         ,vw_main.LOC_COUNTRY_CODE
         ,vw_main.FAC_TYPE_OF_OWNERSHIP_CODE
         ,vw_main.LAT_MEAS
         ,vw_main.LONG_MEAS
         ,vw_main.HORIZ_ACC_MEASURE
         ,'001'
         ,vw_main.HORIZ_COLL_METH_CODE
         ,vw_main.HORIZ_REF_DATUM_CODE
         ,vw_main.REF_POINT_CODE
         ,vw_main.SRC_MAP_SCALE_NUM
         ,vw_main.NAICS_CODE
         ,vw_main.NAICS_PRIMARY_IND_CODE
         ,vw_main.SIC_CODE
         ,vw_main.SIC_PRIMARY_IND_CODE
         -- -----------------
         -- ICS_BASIC_PRMT_ID
         -- -----------------
         ,vw_basic_pmt.ICS_BASIC_PRMT_ID
         -- ----------------
         -- ICS_GNRL_PRMT_ID
         -- ----------------
         ,vw_gnrl_pmt.ICS_GNRL_PRMT_ID
         -- --------------
         -- ICS_CONTACT_ID
         -- --------------
         ,vw_contact.ICS_CONTACT_ID
         -- ----------
         -- ICS_FAC_ID
         -- ----------
         ,vw_fac.ICS_FAC_ID
         -- -----------------
         -- ICS_UNPRMT_FAC_ID
         -- -----------------
         ,NULL   -- ICS_UNPRMT_FAC_ID
     FROM tmp_stg_prmt_main vw_main
     LEFT OUTER JOIN 
        (SELECT UUID() ICS_BASIC_PRMT_ID
               ,PERMIT_ID
           FROM (SELECT DISTINCT PERMIT_ID
                   FROM tmp_stg_prmt_main
                  WHERE PERMIT_CATEGORY_CODE IN ('NPD','IIU','APR')
                    -- AND PERMIT_TYPE_CODE     = 'NPDES'
                ) vw
        ) vw_basic_pmt
       ON vw_basic_pmt.PERMIT_ID = vw_main.PERMIT_ID
     LEFT OUTER JOIN 
        (SELECT UUID() ICS_GNRL_PRMT_ID
               ,PERMIT_ID
           FROM (SELECT DISTINCT PERMIT_ID
                   FROM tmp_stg_prmt_main
                  WHERE PERMIT_CATEGORY_CODE = 'GPC'
                    AND PERMIT_TYPE_CODE IN ('AFO','GEN CW','GEN PID'
                                            ,'GEN SG','GEN WTP'
                                            ,'MS4','REUSE')) vw
        ) vw_gnrl_pmt
       ON vw_gnrl_pmt.PERMIT_ID = vw_main.PERMIT_ID
     LEFT OUTER JOIN
        (SELECT UUID() ICS_CONTACT_ID
               ,vw.*
           FROM (SELECT DISTINCT PERMIT_ID
                       ,FIRST_NAME
                       ,LAST_NAME
                       ,TITLE
                       ,ORG_FRML_NAME
                       -- ,AFFIL_TYPE_TXT
                       ,ELEC_ADDR_TXT
                   FROM tmp_stg_prmt_main 
                  WHERE FIRST_NAME IS NOT NULL
                    AND LAST_NAME  IS NOT NULL
                    AND TITLE      IS NOT NULL
                    -- AND AFFIL_TYPE_TXT IS NOT NULL
                    ) vw
        ) vw_contact
       ON vw_contact.PERMIT_ID      = vw_main.PERMIT_ID
      AND vw_contact.FIRST_NAME     = vw_main.FIRST_NAME
      AND vw_contact.LAST_NAME      = vw_main.LAST_NAME
      AND vw_contact.TITLE          = vw_main.TITLE
      -- AND vw_contact.AFFIL_TYPE_TXT = vw_main.AFFIL_TYPE_TXT
      AND vw_contact.ELEC_ADDR_TXT  = vw_main.ELEC_ADDR_TXT
     LEFT OUTER JOIN 
        (SELECT UUID() ICS_FAC_ID
               ,vw.*
           FROM (SELECT DISTINCT PERMIT_ID
                       ,FACILITY_SITE_NAME
                       ,LOC_ADDR_TXT
                       ,LOCALITY_NAME
                       ,LOC_ST_CODE
                       ,LOC_ZIP_CODE
                       ,LOC_COUNTRY_CODE
                   FROM tmp_stg_prmt_main
                  WHERE FACILITY_SITE_NAME IS NOT NULL) vw
         ) vw_fac
       ON vw_fac.PERMIT_ID = vw_main.PERMIT_ID
      AND vw_fac.FACILITY_SITE_NAME = vw_main.FACILITY_SITE_NAME;
   -- ----------------------------------
   -- tmp_stg_prmt_main (ics_unprmt_fac)
   -- ---------------------------------
   -- create temp table instead of a view because views error out with 
   -- subqueries.
   SET v_tgt_tbl = 'tmp_stg_basic_prmt_main';
   SET v_marker  = 'DROP TABLE and CREATE TABLE tmp_stg_permit_main (ics_unprmt_fac)';
   -- SELECT v_marker; -- jentmp
   --
   DROP TABLE IF EXISTS tmp_stg_prmt_main;
   CREATE TABLE tmp_stg_prmt_main AS   
   SELECT pmt.PERMIT_ID                        PERMIT_ID
         ,pmt.NUMBER                           PRMT_IDENT
         ,pmt.PERMIT_CATEGORY_CODE             PERMIT_CATEGORY_CODE
         ,pmt.PERMIT_TYPE_CODE                 PERMIT_TYPE_CODE
         ,pa.PERMIT_ACTION_ID                  PERMIT_ACTION_ID
         ,pa.PERMIT_ACTION_STATUS_CODE         PERMIT_ACTION_STATUS_CODE
         ,pa.PERMIT_ACTION_TYPE_CODE           PERMIT_ACTION_TYPE_CODE
         ,pmt.IS_MASTER                        IS_MASTER
         ,pmt.FACILITY_ID                      FACILITY_ID
         --
         ,vw_fac_loc.FACILITY_SITE_NAME        FACILITY_SITE_NAME
         ,vw_fac_loc.LOCATION_ADDRESS          LOC_ADDR_TXT
         ,vw_fac_loc.LOCALITY                  LOCALITY_NAME
         ,vw_fac_loc.STATE_CODE                LOC_ST_CODE
         ,vw_fac_loc.POSTAL_CODE               LOC_ZIP_CODE
         ,vw_fac_loc.COUNTRY_CODE              LOC_COUNTRY_CODE
         ,vw_fac_loc.ICIS_FACILITY_TYPE_CODE   FAC_TYPE_OF_OWNERSHIP_CODE
         --
         ,vw_fac_loc.LATITUDE                  LAT_MEAS
         ,vw_fac_loc.LONGITUDE                 LONG_MEAS
         ,vw_fac_loc.HORIZ_ACC_MEASURE         HORZ_ACCURACY_MEAS
         ,'001'                                GEOMETRIC_TYPE_CODE
         ,vw_fac_loc.HORIZ_COLL_METH_CODE      HORZ_COLL_METHOD_CODE
         ,vw_fac_loc.HORIZ_REF_DATUM_CODE      HORZ_REF_DATUM_CODE
         ,vw_fac_loc.REFERENCE_POINT_CODE      REF_POINT_CODE
         ,vw_fac_loc.SOURCE_MAP_SCALE_NUMBER   SRC_MAP_SCALE_NUM
         --
         -- ----------
         -- ics_naics
         -- ----------
         ,fac_naics.NAICS_CODE                 NAICS_CODE
         ,CASE WHEN fac_naics.CODE_ORDER = 1 THEN
              'Y'
            ELSE
              'N'
           END                                 NAICS_PRIMARY_IND_CODE
         -- --------
         -- ics_sic
         -- --------
         ,fac_sic.SIC_CODE                     SIC_CODE
         ,CASE WHEN fac_sic.CODE_ORDER = 1 THEN
             'Y'
          ELSE
             'N'
          END                                  SIC_PRIMARY_IND_CODE
     FROM wrp.PERMIT pmt
     JOIN wrp.PERMIT_ACTION pa
       ON pa.PERMIT_ID = pmt.PERMIT_ID
     -- ---------------
     -- /ics_unprmt_fac
     -- ---------------
     LEFT OUTER JOIN tmp_fac vw_fac_loc
        /*(SELECT fac.FACILITY_SITE_NAME
               ,addr.LOCATION_ADDRESS
               ,addr_prsd.LOCALITY
               ,addr_prsd.STATE_CODE
               ,addr_prsd.POSTAL_CODE
               ,addr_prsd.COUNTRY_CODE
               ,fac.FACILITY_ID
               ,loc.HORIZ_ACC_MEASURE
               ,loc.HORIZ_COLL_METH_CODE
               ,loc.HORIZ_REF_DATUM_CODE
               ,loc.REFERENCE_POINT_CODE
               ,loc.SOURCE_MAP_SCALE_NUMBER
               ,loc_coord.LATITUDE
               ,loc_coord.LONGITUDE
               ,fac.OWNERSHIP_TYPE_CODE
               ,rot.ICIS_FACILITY_TYPE_CODE
           FROM wrp.FACILITY fac
           JOIN wrp.LOCATION loc
             ON loc.FACILITY_ID = fac.FACILITY_ID
           LEFT OUTER JOIN wrp.REF_OWNERSHIP_TYPE rot
             ON rot.CODE = fac.OWNERSHIP_TYPE_CODE
           LEFT OUTER JOIN wrp.ADDRESS addr
             ON addr.LOCATION_ID = loc.LOCATION_ID
           LEFT OUTER JOIN wrp.ADDRESS_PARSED addr_prsd
             ON addr_prsd.ADDRESS_ID   = addr.ADDRESS_ID
            AND addr.ADDRESS_TYPE_CODE = 'ST'
           LEFT OUTER JOIN wrp.LOCATION_COORD loc_coord
             ON loc_coord.LOCATION_ID = loc.LOCATION_ID
            AND loc_coord.`INDEX`     = 0
         ) vw_fac_loc*/
       ON vw_fac_loc.FACILITY_ID = pmt.FACILITY_ID
     -- ------------------------------
     -- /ics_basic_prmt/ics_naics_code
     -- ------------------------------
     LEFT OUTER JOIN wrp.FACILITY_NAICS fac_naics
       ON fac_naics.FACILITY_ID = pmt.FACILITY_ID
     -- ----------------------------
     -- /ics_basic_prmt/ics_sic_code
     -- ----------------------------
     LEFT OUTER JOIN wrp.FACILITY_SIC fac_sic
       ON fac_sic.FACILITY_ID = pmt.FACILITY_ID
     --
    WHERE PERMIT_CATEGORY_CODE = 'UNPER'
      AND pmt.PERMIT_TYPE_CODE = 'UNPER'
      AND pmt.NUMBER           LIKE 'GAU05%';
   --
   -- ---------------
   -- stg_permit_main
   -- ---------------
   SET v_tgt_tbl = 'stg_permit_main';
   SET v_marker  = 'INSERT INTO stg_permit_main (ics_unprmt_fac)';
   -- SELECT v_marker; -- jentmp
   INSERT INTO stg_permit_main
      (PERMIT_ID
      ,PRMT_IDENT
      ,PERMIT_CATEGORY_CODE
      ,PERMIT_TYPE_CODE
      ,PERMIT_ACTION_ID
      ,PERMIT_ACTION_STATUS_CODE
      ,PERMIT_ACTION_TYPE_CODE
      ,IS_MASTER
      ,FACILITY_ID
      ,FAC_SITE_NAME
      ,LOC_ADDR_TXT
      ,LOCALITY_NAME
      ,LOC_ST_CODE
      ,LOC_ZIP_CODE
      ,LOC_COUNTRY_CODE
      ,FAC_TYPE_OF_OWNERSHIP_CODE
      ,LAT_MEAS
      ,LONG_MEAS
      ,HORZ_ACCURACY_MEAS
      ,GEOMETRIC_TYPE_CODE
      ,HORZ_COLL_METHOD_CODE
      ,HORZ_REF_DATUM_CODE
      ,REF_POINT_CODE
      ,SRC_MAP_SCALE_NUM
      ,NAICS_CODE
      ,NAICS_PRIMARY_IND_CODE
      ,SIC_CODE
      ,SIC_PRIMARY_IND_CODE
      ,ICS_UNPRMT_FAC_ID)
   SELECT vw_main.PERMIT_ID
         ,vw_main.PRMT_IDENT
         ,vw_main.PERMIT_CATEGORY_CODE
         ,vw_main.PERMIT_TYPE_CODE
         ,vw_main.PERMIT_ACTION_ID
         ,vw_main.PERMIT_ACTION_STATUS_CODE
         ,vw_main.PERMIT_ACTION_TYPE_CODE
         ,vw_main.IS_MASTER
         ,vw_main.FACILITY_ID
         ,vw_main.FACILITY_SITE_NAME
         ,vw_main.LOC_ADDR_TXT
         ,vw_main.LOCALITY_NAME
         ,vw_main.LOC_ST_CODE
         ,vw_main.LOC_ZIP_CODE
         ,vw_main.LOC_COUNTRY_CODE
         ,vw_main.FAC_TYPE_OF_OWNERSHIP_CODE
         ,vw_main.LAT_MEAS
         ,vw_main.LONG_MEAS
         ,vw_main.HORZ_ACCURACY_MEAS
         ,vw_main.GEOMETRIC_TYPE_CODE
         ,vw_main.HORZ_COLL_METHOD_CODE
         ,vw_main.HORZ_REF_DATUM_CODE
         ,vw_main.REF_POINT_CODE
         ,vw_main.SRC_MAP_SCALE_NUM
         ,vw_main.NAICS_CODE
         ,vw_main.NAICS_PRIMARY_IND_CODE
         ,vw_main.SIC_CODE
         ,vw_main.SIC_PRIMARY_IND_CODE
         ,vw_unprmt.UNPRMT_FAC_ID
     FROM tmp_stg_prmt_main vw_main
     LEFT OUTER JOIN
        (SELECT UUID()  UNPRMT_FAC_ID
               ,PERMIT_ID
           FROM (SELECT DISTINCT PERMIT_ID
                   FROM tmp_stg_prmt_main) vw
        ) vw_unprmt
       ON vw_unprmt.PERMIT_ID = vw_main.PERMIT_ID;
   -- -------------- --
   --  END PROCEDURE --
   -- -------------- --
   SET v_marker = 'CALL ics_etl_log_sp END';
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_sp_name     -- pi_marker
      ,NULL          -- pi_tgt_tbl
      ,NULL          -- pi_src_tbl 
      ,v_startdtm    -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'COMPLETED'   -- pi_process
      ,0);           -- pi_value
   --
   SET po_status = 1;
   SET po_errm   = '';
   --
END;
