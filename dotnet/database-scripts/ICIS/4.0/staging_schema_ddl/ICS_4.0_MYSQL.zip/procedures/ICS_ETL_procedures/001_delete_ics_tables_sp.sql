USE ga_ics_flow_local;
DROP PROCEDURE IF EXISTS delete_ics_tables_sp;
CREATE PROCEDURE delete_ics_tables_sp
   (OUT po_status INT
   ,OUT po_errm   VARCHAR(255))
BEGIN
-- ============================================================================
-- MODIFICATION HISTORY
-- Person      Date       Comments
-- ---------   --------   -----------------------------------------------------
-- Jen Go      20120925   Created.  
--
-- ============================================================================
   DECLARE v_startdtm 
          ,v_startdtm2
          ,v_enddtm        DATETIME;
   DECLARE v_marker        VARCHAR(255);
   DECLARE v_sp_name       VARCHAR(64)     DEFAULT 'delete_ics_tables_sp';
   DECLARE v_sql_stmt      VARCHAR(1000);
   DECLARE v_table_name    VARCHAR(64);
   DECLARE v_nodatafound   BOOLEAN;
   DECLARE v_num_rows      INT DEFAULT 0;   
   --
   DECLARE cur_tbls2del CURSOR FOR
      SELECT TABLE_NAME
            ,CONCAT('DELETE FROM ',TABLE_NAME)
        FROM information_schema.TABLES
       WHERE TABLE_SCHEMA = 'ga_ics_flow_local'
         AND (   TABLE_NAME LIKE 'ICS%'
              OR TABLE_NAME LIKE 'stg%')
         AND TABLE_NAME NOT IN ('ics_etl_log','ICS_PAYLOAD'
                               ,'ICS_V_MODULE_COUNT','ICS_V_ANML_TYPE_HIB')
       ORDER BY TABLE_NAME;
   --
   DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_nodatafound = TRUE;
   DECLARE EXIT HANDLER FOR SQLEXCEPTION
      BEGIN  
         ROLLBACK;
         SET po_status = -1;
         SET po_errm   = v_marker;
         SELECT v_marker;
         -- 
         CALL ics_etl_log_sp    
            (v_sp_name          -- pi_sp_name
            ,v_marker           -- pi_marker
            ,v_tgt_tbl          -- pi_tgt_tbl
            ,v_src_tbl          -- pi_src_tbl
            ,v_startdtm         -- pi_startdtm
            ,NOW()              -- pi_enddtm
            ,'FAILED'           -- pi_process
            ,-1);               -- pi_value
         COMMIT;
      END;
   --
   SET v_startdtm = NOW();
   SET FOREIGN_KEY_CHECKS = 0;
   --
   SET v_marker = 'OPEN cur_tbls2del and loop';
   
   OPEN cur_tbls2del;
   SET v_nodatafound = FALSE;
   tbls2del_loop: LOOP
      FETCH cur_tbls2del
       INTO v_table_name
           ,v_sql_stmt;
      --
      IF v_nodatafound THEN
         SET v_marker = 'END OF LOOP';
         -- SELECT v_table_name; -- JENTMP
         -- CLOSE cur_tbls2del;
         LEAVE tbls2del_loop;
      END IF;
      --
      SET v_startdtm2 = NOW();
      SET v_marker = v_sql_stmt;
      SET @stmt = v_sql_stmt;
      PREPARE stmt FROM @stmt;
      EXECUTE stmt;
      --
      SET v_num_rows = (SELECT FOUND_ROWS());
      INSERT INTO ics_etl_log
       (ics_etl_sp_name
       ,ics_etl_target_table
       ,ics_etl_source_table
       ,ics_etl_sp_marker
       ,ics_etl_sp_startdtm
       ,ics_etl_sp_enddtm
       ,ics_etl_process
       ,ics_etl_value)
      VALUES
         (v_sp_name
         ,v_table_name
         ,NULL
         ,v_sql_stmt
         ,v_startdtm2
         ,NOW()
         ,'SUCCESS'
         ,v_num_rows);
      --
   END LOOP tbls2del_loop;
   --
   CLOSE cur_tbls2del;
   -- COMMIT;
   --
   SET FOREIGN_KEY_CHECKS = 1;
   --
   SET v_marker = 'CALL ics_etl_log_sp END';
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_sp_name     -- pi_marker
      ,NULL          -- pi_tgt_tbl
      ,NULL          -- pi_src_tbl 
      ,v_startdtm    -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'COMPLETED'   -- pi_process
      ,0);           -- pi_value
   --
   SET po_status = 1;
   SET po_errm   = NULL;
   --
END
   