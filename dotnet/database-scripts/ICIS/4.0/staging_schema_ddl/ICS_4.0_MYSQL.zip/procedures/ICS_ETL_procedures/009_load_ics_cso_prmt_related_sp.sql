USE ga_ics_flow_local;
DROP PROCEDURE IF EXISTS load_ics_cso_prmt_related_sp;
CREATE PROCEDURE load_ics_cso_prmt_related_sp
   (OUT po_status INT
   ,OUT po_errm   VARCHAR(255))
BEGIN
-- ============================================================================
-- MODIFICATION HISTORY
-- Person      Date       Comments
-- ---------   --------   -----------------------------------------------------
-- Jen Go      20120924   Created.  
--                        Populate the following tables
--                           1) ICS_CSO_PRMT
--                           2) ICS_SATL_COLL_SYSTM
--                        another SP load_ics_potw_prmt_related_sp inserts into
--                        ICS_SATL_COLL_SYSTM.
-- ============================================================================
   DECLARE v_startdtm   DATETIME     DEFAULT NOW();
   DECLARE v_startdtm2
          ,v_enddtm     DATETIME;
   DECLARE v_marker     VARCHAR(255);
   DECLARE v_sp_name    VARCHAR(64)  DEFAULT 'load_ics_cso_prmt_related_sp';
   DECLARE v_tgt_tbl    VARCHAR(64);
   DECLARE v_src_tbl    VARCHAR(64);
   DECLARE v_rowcount   INT          DEFAULT 0;
   --
   DECLARE EXIT HANDLER FOR SQLEXCEPTION
      BEGIN  
         ROLLBACK;
         SET po_status = -1;
         SET po_errm   = v_marker;
         CALL ics_etl_log_sp    
            (v_sp_name          -- pi_sp_name
            ,v_marker           -- pi_marker
            ,v_tgt_tbl          -- pi_tgt_tbl
            ,v_src_tbl          -- pi_src_tbl
            ,v_startdtm         -- pi_startdtm
            ,NOW()              -- pi_enddtm
            ,'FAILED'           -- pi_process
            ,-1);               -- pi_value
      END;
   --
   SET v_marker ='DROP AND CREATE TABLE tmp_stg_cso_prmt_main';
   DROP TABLE IF EXISTS tmp_stg_cso_prmt_main;
   CREATE TABLE tmp_stg_cso_prmt_main AS
   SELECT PRMT_IDENT
         ,MAX(CSS_POPL_SERVED_NUM)         CSS_POPL_SERVED_NUM
         ,MAX(COMBINED_SEWER_SYSTM_LENGTH) COMBINED_SEWER_SYSTM_LENGTH
         ,MAX(COLL_SYSTM_COMBINED_PERCENT) COLL_SYSTM_COMBINED_PERCENT
         ,MAX(SATL_COLL_SYSTM_IDENT)       SATL_COLL_SYSTM_IDENT
         ,MAX(SATL_COLL_SYSTM_NAME)        SATL_COLL_SYSTM_NAME
    FROM (SELECT stg.PRMT_IDENT
                 --
                ,CASE WHEN qr.QUESTION_CODE = 'ICIS022' THEN
                    qr.ANSWER_COMMENT
                 ELSE NULL END                CSS_POPL_SERVED_NUM
                --
                ,CASE WHEN qr.QUESTION_CODE = 'ICIS023' THEN
                    qr.ANSWER_COMMENT
                 ELSE NULL END                COMBINED_SEWER_SYSTM_LENGTH
                --
                ,CASE WHEN qr.QUESTION_CODE = 'ICIS024' THEN
                    qr.ANSWER_COMMENT
                 ELSE NULL END                COLL_SYSTM_COMBINED_PERCENT
                --
                ,CASE WHEN qr.QUESTION_CODE = 'ICIS025' THEN
                    qr.ANSWER_COMMENT
                 ELSE NULL END                SATL_COLL_SYSTM_IDENT
                --
                ,CASE WHEN qr.QUESTION_CODE = 'ICIS026' THEN
                    qr.ANSWER_COMMENT
                 ELSE NULL END                SATL_COLL_SYSTM_NAME
            FROM stg_permit_main stg
            LEFT OUTER JOIN wrp.QUESTION_RESULT qr
              ON qr.PERMIT_ACTION_ID = stg.PERMIT_ACTION_ID
             AND qr.QUESTION_CODE IN ('ICIS022' 
                                     ,'ICIS023'
                                     ,'ICIS024'
                                     ,'ICIS025'
                                     ,'ICIS026')
           WHERE stg.ICS_GNRL_PRMT_ID IS NOT NULL) vw
    GROUP BY PRMT_IDENT;
   --
   SET v_marker ='DROP AND CREATE TABLE tmp_stg_cso_prmt';
   DROP TABLE IF EXISTS tmp_stg_cso_prmt;
   CREATE TABLE tmp_stg_cso_prmt AS
   SELECT ICS_CSO_PRMT_ID
         ,vw_main.*
     FROM tmp_stg_cso_prmt_main vw_main
     LEFT OUTER JOIN 
        (SELECT UUID() ICS_CSO_PRMT_ID
               ,PRMT_IDENT
           FROM (SELECT DISTINCT PRMT_IDENT
                   FROM tmp_stg_cso_prmt_main) vw
        ) vw_cso
       ON vw_cso.PRMT_IDENT = vw_main.PRMT_IDENT;
   --
   SET v_marker    = 'INSERT INTO ICS_CSO_PRMT';
   SET v_startdtm2 = NOW();
   SET v_tgt_tbl   = 'ICS_CSO_PRMT';
   SET v_src_tbl   = 'tmp_stg_cso_prmt';
   INSERT INTO ICS_CSO_PRMT
      (ICS_CSO_PRMT_ID
      ,ICS_PAYLOAD_ID
      ,PRMT_IDENT
      ,CSS_POPL_SERVED_NUM
      ,COMBINED_SEWER_SYSTM_LENGTH
      ,COLL_SYSTM_COMBINED_PERCENT)
   SELECT DISTINCT ICS_CSO_PRMT_ID
         ,'CSOPermit'
         ,PRMT_IDENT
         ,CSS_POPL_SERVED_NUM
         ,COMBINED_SEWER_SYSTM_LENGTH
         ,COLL_SYSTM_COMBINED_PERCENT
     FROM tmp_stg_cso_prmt;
   --
   SET v_rowcount = (SELECT ROW_COUNT());
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm    -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'INSERT'      -- pi_process
      ,v_rowcount);  -- pi_value
   --
   SET v_marker    = 'INSERT INTO ICS_SATL_COLL_SYSTM';
   SET v_startdtm2 = NOW();
   SET v_tgt_tbl   = 'ICS_SATL_COLL_SYSTM';
   SET v_src_tbl   = 'tmp_stg_cso_prmt';
   INSERT INTO ICS_SATL_COLL_SYSTM
      (ICS_SATL_COLL_SYSTM_ID
      ,ICS_CSO_PRMT_ID
      ,SATL_COLL_SYSTM_IDENT
      ,SATL_COLL_SYSTM_NAME)
   SELECT UUID()  
         ,ICS_CSO_PRMT_ID
         ,SATL_COLL_SYSTM_IDENT
         ,SATL_COLL_SYSTM_NAME
     FROM (SELECT DISTINCT ICS_CSO_PRMT_ID
                 ,SATL_COLL_SYSTM_IDENT
                 ,SATL_COLL_SYSTM_NAME
             FROM tmp_stg_cso_prmt
            WHERE SATL_COLL_SYSTM_IDENT IS NOT NULL
               OR SATL_COLL_SYSTM_NAME  IS NOT NULL) vw;
   --
   SET v_rowcount = (SELECT ROW_COUNT());
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm    -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'INSERT'      -- pi_process
      ,v_rowcount);  -- pi_value
   -- -------------- --
   --  END PROCEDURE --
   -- -------------- --
   SET v_marker = 'CALL ics_etl_log_sp END';
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_sp_name     -- pi_marker
      ,NULL          -- pi_tgt_tbl
      ,NULL          -- pi_src_tbl 
      ,v_startdtm    -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'COMPLETED'   -- pi_process
      ,0);           -- pi_value
   --
   SET po_status = 1;
   SET po_errm   = '';
   --      
END      