USE ga_ics_flow_local;
DROP PROCEDURE IF EXISTS load_ics_cafo_prmt_sp;
CREATE PROCEDURE load_ics_cafo_prmt_sp
   (OUT po_status INT
   ,OUT po_errm   VARCHAR(255))
BEGIN
-- ============================================================================
-- MODIFICATION HISTORY
-- Person      Date       Comments
-- ---------   --------   -----------------------------------------------------
-- Jen Go      20120912   Created.  
--
-- ============================================================================
   DECLARE v_startdtm   DATETIME     DEFAULT NOW();
   DECLARE v_enddtm     DATETIME;
   DECLARE v_marker     VARCHAR(255);
   DECLARE v_sp_name    VARCHAR(64)  DEFAULT 'load_ics_cafo_prmt_sp';
   DECLARE v_tgt_tbl    VARCHAR(64)  DEFAULT 'ICS_CAFO_PRMT';
   DECLARE v_src_tbl    VARCHAR(64)  DEFAULT 'tmp_stg_cafo_prmt';
   DECLARE v_rowcount   INT          DEFAULT 0;
   --
   DECLARE EXIT HANDLER FOR SQLEXCEPTION
      BEGIN  
         ROLLBACK;
         SET po_status = -1;
         SET po_errm   = v_marker;
         CALL ics_etl_log_sp    
            (v_sp_name          -- pi_sp_name
            ,v_marker           -- pi_marker
            ,v_tgt_tbl          -- pi_tgt_tbl
            ,v_src_tbl          -- pi_src_tbl
            ,v_startdtm         -- pi_startdtm
            ,NOW()              -- pi_enddtm
            ,'FAILED'           -- pi_process
            ,-1);               -- pi_value
      END;
   --
   SET v_marker  = 'INSERT INTO ICS_CAFO_PRMT';
   INSERT INTO ICS_CAFO_PRMT
      (ICS_CAFO_PRMT_ID
      ,ICS_PAYLOAD_ID
      ,PRMT_IDENT
      ,CAFO_CLASS_CODE
      ,IS_ANML_FAC_TYPE_CAFO_IND
      ,CAFO_DESGN_DATE
      ,SOLID_MNUR_LTTR_GNRTD_AMT
      ,LIQUID_MNUR_WW_GNRTD_AMT
      ,SOLID_MNUR_LTTR_TRANS_AMT
      ,LIQUID_MNUR_WW_TRANS_AMT
      ,NMP_DVLPD_DATE)
   SELECT DISTINCT ICS_CAFO_PRMT_ID
         ,'CAFOPermit'
         ,PRMT_IDENT
         ,CAFO_CLASS_CODE
         ,IS_ANML_FAC_TYPE_CAFO_IND
         ,CAFO_DESGN_DATE
         ,SOLID_MNUR_LTTR_GNRTD_AMT
         ,LIQUID_MNUR_WW_GNRTD_AMT
         ,SOLID_MNUR_LTTR_TRANS_AMT
         ,LIQUID_MNUR_WW_TRANS_AMT
         ,NMP_DVLPD_DATE
     FROM tmp_stg_cafo_prmt
    WHERE ICS_CAFO_PRMT_ID IS NOT NULL
      AND (   CAFO_CLASS_CODE            IS NOT NULL
           OR IS_ANML_FAC_TYPE_CAFO_IND  IS NOT NULL
           OR CAFO_DESGN_DATE            IS NOT NULL
           OR SOLID_MNUR_LTTR_GNRTD_AMT  IS NOT NULL
           OR LIQUID_MNUR_WW_GNRTD_AMT   IS NOT NULL
           OR SOLID_MNUR_LTTR_TRANS_AMT  IS NOT NULL
           OR LIQUID_MNUR_WW_TRANS_AMT   IS NOT NULL
           OR NMP_DVLPD_DATE             IS NOT NULL);
   --
   SET v_rowcount = (SELECT ROW_COUNT());
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm    -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'INSERT'      -- pi_process
      ,v_rowcount);  -- pi_value
   -- -------------- --
   --  END PROCEDURE --
   -- -------------- --
   SET v_marker = 'CALL ics_etl_log_sp END';
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_sp_name     -- pi_marker
      ,NULL          -- pi_tgt_tbl
      ,NULL          -- pi_src_tbl 
      ,v_startdtm    -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'COMPLETED'   -- pi_process
      ,0);           -- pi_value
   --
   SET po_status = 1;
   SET po_errm   = '';
   --
END