USE ga_ics_flow_local;
DROP PROCEDURE IF EXISTS load_ics_narr_cond_related_sp;
CREATE PROCEDURE load_ics_narr_cond_related_sp
   (OUT po_status INT
   ,OUT po_errm   VARCHAR(255))
BEGIN
-- ============================================================================
-- MODIFICATION HISTORY
-- Person      Date       Comments
-- ---------   --------   -----------------------------------------------------
-- Jen Go      20120924   Created.  
--                        Populate the following tables:
--                           1) ICS_NARR_COND_SCHD
--                           2) ICS_PRMT_SCHD_EVT
-- ============================================================================
   DECLARE v_startdtm    
          ,v_startdtm2
          ,v_enddtm     DATETIME;
   DECLARE v_marker     VARCHAR(255);
   DECLARE v_sp_name    VARCHAR(64)  DEFAULT 'load_ics_narr_cond_related_sp';
   DECLARE v_tgt_tbl    
          ,v_src_tbl    VARCHAR(64);
   DECLARE v_rowcount   INT          DEFAULT 0;
   --
   DECLARE EXIT HANDLER FOR SQLEXCEPTION
      BEGIN  
         ROLLBACK;
         SET po_status = -1;
         SET po_errm   = v_marker;
         -- 
         CALL ics_etl_log_sp    
            (v_sp_name          -- pi_sp_name
            ,v_marker           -- pi_marker
            ,v_tgt_tbl          -- pi_tgt_tbl
            ,v_src_tbl          -- pi_src_tbl
            ,v_startdtm         -- pi_startdtm
            ,NOW()              -- pi_enddtm
            ,'FAILED'           -- pi_process
            ,-1);               -- pi_value
      END;
   --
   SET v_startdtm = NOW();
   SET v_marker = 'DROP AND CREATE TABLE tmp_stg_narr_cond_main';
   -- SELECT v_marker; -- jentmp
   DROP TABLE IF EXISTS tmp_stg_narr_cond_main;
   CREATE TABLE tmp_stg_narr_cond_main AS
   SELECT pmt.PERMIT_ID
         ,schd.SCHEDULE_ID
         -- -------------------
         -- ics_narr_cond_schd
         -- -------------------
         ,pmt.NUMBER                         PRMT_IDENT
         ,schd.NUMBER                        NARR_COND_NUM
         ,rst.ICIS_NARRATIVE_CONDITION_CODE  NARR_COND_CODE
         -- ,schd.COMMENTS   CMNTS
         -- ------------------
         -- ics_prmt_schd_evnt
         -- ------------------
         ,rst.ICIS_SCHEDULE_EVENT_CODE       SCHD_EVT_CODE
         ,subm.DUE_DATE                      SCHD_DATE
         ,subm.RECEIVED_DATE
         ,subm.COMMENT                       SCHD_EVT_CMNTS
     FROM wrp.SCHEDULE schd
     -- JOIN stg_permit_main stg
     --  ON stg.PERMIT_ACTION_ID = schd.PERMIT_ACTION_ID
     JOIN wrp.PERMIT_ACTION pa
       ON pa.PERMIT_ACTION_ID = schd.PERMIT_ACTION_ID
     JOIN wrp.PERMIT pmt
       ON pmt.PERMIT_ID = pa.PERMIT_ID
     LEFT OUTER JOIN wrp.REF_SCHEDULE_TYPE rst
       ON rst.CODE = schd.SCHEDULE_TYPE_CODE
     LEFT OUTER JOIN wrp.SUBMITTAL subm
       ON subm.SCHEDULE_ID = schd.SCHEDULE_ID
    WHERE pa.PERMIT_ACTION_TYPE_CODE IN ('NEW','REN')
      AND pa.`VERSION` = (SELECT MAX(pa2.`VERSION`)
                            FROM wrp.PERMIT_ACTION pa2
                           WHERE pa2.PERMIT_ACTION_TYPE_CODE IN ('NEW','REN')
                             AND pa2.PERMIT_ID = pa.PERMIT_ID);
   --
   SET v_marker = 'DROP AND CREATE TABLE tmp_stg_narr_cond';
   -- SELECT v_marker; -- jentmp
   DROP TABLE IF EXISTS tmp_stg_narr_cond;
   CREATE TABLE tmp_stg_narr_cond AS
   SELECT DISTINCT vw_narr.ICS_NARR_COND_SCHD_ID
         ,vw_main.PRMT_IDENT
         ,vw_main.NARR_COND_NUM
         ,vw_main.NARR_COND_CODE
         ,vw_main.SCHD_EVT_CODE
         ,vw_main.SCHD_DATE
         -- SCHD_REP_RCVD_DATE; SCHD_ACTUL_DATE
         ,vw_main.RECEIVED_DATE
         ,vw_main.SCHD_EVT_CMNTS
     FROM tmp_stg_narr_cond_main vw_main
     JOIN (SELECT UUID() ICS_NARR_COND_SCHD_ID
                 ,PRMT_IDENT
                 ,NARR_COND_NUM
                 ,NARR_COND_CODE
             FROM (SELECT DISTINCT PRMT_IDENT
                         ,NARR_COND_NUM
                         ,NARR_COND_CODE
                     FROM tmp_stg_narr_cond_main) vw
          ) vw_narr
       ON vw_narr.PRMT_IDENT                   = vw_main.PRMT_IDENT
      AND vw_narr.NARR_COND_NUM                = vw_main.NARR_COND_NUM
      AND COALESCE(vw_narr.NARR_COND_CODE,'X') = COALESCE(vw_main.NARR_COND_CODE,'X');
   --
   SET v_marker    = 'INSERT INTO ICS_NARR_COND_SCHD';
   SET v_startdtm2 = NOW();
   SET v_src_tbl   = 'tmp_stg_narr_cond';
   SET v_tgt_tbl   = 'ICS_NARR_COND_SCHD';
   INSERT INTO ICS_NARR_COND_SCHD 
      (ICS_NARR_COND_SCHD_ID
      ,ICS_PAYLOAD_ID
      ,PRMT_IDENT
      ,NARR_COND_NUM
      ,NARR_COND_CODE)
   SELECT DISTINCT ICS_NARR_COND_SCHD_ID
         ,'NarrativeConditionSchedule'
         ,PRMT_IDENT
         ,NARR_COND_NUM
         ,NARR_COND_CODE
     FROM tmp_stg_narr_cond;
   --
   SET v_rowcount = (SELECT ROW_COUNT());
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'INSERT'      -- pi_process
      ,v_rowcount);  -- pi_value
   -- -----------------
   -- ics_prmt_schd_evt
   -- -----------------
   SET v_marker    = 'INSERT INTO ICS_PRMT_SCHD_EVT';
   SET v_startdtm2 = NOW();
   SET v_src_tbl   = 'tmp_stg_narr_cond';
   SET v_tgt_tbl   = 'ICS_PRMT_SCHD_EVT';
   --
   INSERT INTO ICS_PRMT_SCHD_EVT 
      (ICS_PRMT_SCHD_EVT_ID
      ,ICS_NARR_COND_SCHD_ID
      ,SCHD_EVT_CODE
      ,SCHD_DATE
      ,SCHD_REP_RCVD_DATE
      ,SCHD_ACTUL_DATE
      ,SCHD_EVT_CMNTS)
   SELECT UUID()
         ,ICS_NARR_COND_SCHD_ID
         ,SCHD_EVT_CODE
         ,SCHD_DATE
         ,RECEIVED_DATE
         ,RECEIVED_DATE
         ,SCHD_EVT_CMNTS
     FROM tmp_stg_narr_cond
    WHERE SCHD_EVT_CODE IS NOT NULL
      AND SCHD_DATE IS NOT NULL;
   --
   SET v_rowcount = (SELECT ROW_COUNT());
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'INSERT'      -- pi_process
      ,v_rowcount);  -- pi_value
   -- -------------- --
   --  END PROCEDURE --
   -- -------------- --
   SET v_marker = 'CALL ics_etl_log_sp END';
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_sp_name     -- pi_marker
      ,NULL          -- pi_tgt_tbl
      ,NULL          -- pi_src_tbl 
      ,v_startdtm    -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'COMPLETED'   -- pi_process
      ,0);           -- pi_value
   --
   SET po_status = 1;
   SET po_errm   = '';
   -- 
END