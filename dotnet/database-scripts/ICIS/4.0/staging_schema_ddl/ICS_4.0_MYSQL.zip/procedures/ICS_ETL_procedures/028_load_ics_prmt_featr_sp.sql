USE ga_ics_flow_local;
DROP PROCEDURE IF EXISTS load_ics_prmt_featr_sp;
CREATE PROCEDURE load_ics_prmt_featr_sp
   (OUT po_status INT
   ,OUT po_errm   VARCHAR(255))
BEGIN
-- ============================================================================
-- MODIFICATION HISTORY
-- Person      Date       Comments
-- ---------   --------   -----------------------------------------------------
-- Jen Go      20120918   Created.  
--
-- ============================================================================
   DECLARE v_startdtm   DATETIME     DEFAULT NOW();
   DECLARE v_startdtm2
          ,v_enddtm     DATETIME;
   DECLARE v_marker     VARCHAR(255);
   DECLARE v_sp_name    VARCHAR(64)  DEFAULT 'load_ics_prmt_featr_sp';
   DECLARE v_tgt_tbl    VARCHAR(64)  DEFAULT 'ICS_PRMT_FEATR';
   DECLARE v_src_tbl    VARCHAR(64)  DEFAULT 'stg_prmt_featr_main';
   DECLARE v_rowcount   INT          DEFAULT 0;
   --
   DECLARE EXIT HANDLER FOR SQLEXCEPTION
      BEGIN  
         ROLLBACK;
         SET po_status = -1;
         SET po_errm   = v_marker;
         CALL ics_etl_log_sp    
            (v_sp_name          -- pi_sp_name
            ,v_marker           -- pi_marker
            ,v_tgt_tbl          -- pi_tgt_tbl
            ,v_src_tbl          -- pi_src_tbl
            ,v_startdtm         -- pi_startdtm
            ,NOW()              -- pi_enddtm
            ,'FAILED'           -- pi_process
            ,-1);               -- pi_value
      END;
   -- -----------------------
   -- tmp_stg_prmt_featr_main
   -- -----------------------
   -- create temp table instead of a view because views error out with 
   -- subqueries.
   SET v_marker = 'DROP AND CREATE TABLE tmp_stg_prmt_featr_main';
   DROP TABLE IF EXISTS tmp_stg_prmt_featr_main;
   CREATE TABLE tmp_stg_prmt_featr_main AS
   SELECT pmt.PERMIT_ID                                 PERMIT_ID
         ,pmt.FACILITY_ID                               FACILITY_ID
         ,pa.PERMIT_ACTION_ID                           PERMIT_ACTION_ID
         ,pa.PERMIT_ACTION_TYPE_CODE                    PERMIT_ACTION_TYPE_CODE
         ,fac_featr.FACILITY_FEATURE_ID                 FACILITY_FEATURE_ID
         -- --------------
         -- ics_prmt_featr
         -- --------------
         ,pmt.NUMBER                                    PRMT_IDENT
         ,fac_featr.NUMBER                              PRMT_FEATR_IDENT
         ,fac_featr.FF_ICIS_TYPE_CODE                   PRMT_FEATR_TYPE_CODE 
         ,fac_featr.FACILITY_FEATURE_DESCRIP            PRMT_FEATR_DESC
         ,fac_featr.TOTAL_DESIGN_FLOW                   PRMT_FEATR_DSGN_FLOW_NUM
         ,fac_featr.ACTUAL_AVERAGE_FLOW                 PRMT_FEATR_ACTUL_AVER_FLOW_NUM
         ,fac_featr.WATERBODY_CODE                      PRMT_FEATR_ST_WTR_BODY_CODE
         ,loc.RECEIVING_WATER_COMMENT                   PRMT_FEATR_ST_WTR_BODY_NAME
         -- ,fac_featr.ICIS_PRMT_FEATR_USR_DFND_DAT_ELM_1  PRMT_FEATR_USR_DFND_DAT_ELM_1
         -- ,fac_featr.ICIS_PRMT_FEATR_USR_DFND_DAT_ELM_2  PRMT_FEATR_USR_DFND_DAT_ELM_1
         -- -------------
         -- ics_geo_coord
         -- -------------
         ,loc_coord.LATITUDE                            LAT_MEAS
         ,loc_coord.LONGITUDE                           LONG_MEAS
         ,loc.HORIZ_ACC_MEASURE                         HORZ_ACCURACY_MEAS
         ,loc.HORIZ_COLL_METH_CODE                      HORZ_COLL_METHOD_CODE
         ,loc.HORIZ_REF_DATUM_CODE                      HORZ_REF_DATUM_CODE
         ,loc.REFERENCE_POINT_CODE                      REF_POINT_CODE
         ,loc.SOURCE_MAP_SCALE_NUMBER                   SRC_MAP_SCALE_NUM
         -- --------------------------
         -- ics_prmt_featr_trtmnt_type
         -- --------------------------
         ,vw_treat.ICIS_TREATMENT_TYPE_CODE             PRMT_FEATR_TRTMNT_TYPE_CODE
     FROM wrp.PERMIT pmt
     JOIN wrp.PERMIT_ACTION pa
       ON pa.PERMIT_ID = pmt.PERMIT_ID
     JOIN wrp.FACILITY_FEATURE fac_featr
       ON fac_featr.FACILITY_ID = pmt.FACILITY_ID
     LEFT OUTER JOIN wrp.LOCATION loc
       ON loc.FACILITY_ID = fac_featr.FACILITY_ID
     LEFT OUTER JOIN wrp.LOCATION_COORD loc_coord
       ON loc_coord.LOCATION_ID = loc.LOCATION_ID
      AND loc_coord.`INDEX`     = 0
     LEFT OUTER JOIN 
        (SELECT ftt.FACILITY_FEATURE_ID
               ,rtt.ICIS_TREATMENT_TYPE_CODE
           FROM wrp.FF_TREATMENT_TYPE ftt
           JOIN wrp.REF_TREATMENT_TYPE rtt
             ON rtt.CODE = ftt.TREATMENT_TYPE_CODE) vw_treat
      ON vw_treat.FACILITY_FEATURE_ID = fac_featr.FACILITY_FEATURE_ID
    WHERE pmt.PERMIT_ID IN (SELECT PERMIT_ID
                              FROM stg_permit_main
                             WHERE ICS_BASIC_PRMT_ID IS NOT NULL
                                OR ICS_GNRL_PRMT_ID  IS NOT NULL);
   -- -------------------
   -- tmp_stg_prmt_featr
   -- -------------------
   SET v_tgt_tbl = 'tmp_stg_prmt_featr_main';
   SET v_marker  = 'INSERT INTO tmp_stg_prmt_featr';
   --
   DROP TABLE IF EXISTS tmp_stg_prmt_featr; -- stg_prmt_featr_main;
   -- INSERT INTO stg_prmt_featr_main
   CREATE TABLE tmp_stg_prmt_featr AS 
   SELECT vw_main.PERMIT_ID
         ,vw_main.FACILITY_ID
         ,vw_main.PERMIT_ACTION_ID
         ,vw_main.PERMIT_ACTION_TYPE_CODE
         ,vw_main.FACILITY_FEATURE_ID
         -- ,NULL   -- ICIS_NUMBER
         ,vw_main.PRMT_IDENT
         ,vw_main.PRMT_FEATR_IDENT
         ,vw_main.PRMT_FEATR_TYPE_CODE
         ,vw_main.PRMT_FEATR_DESC
         ,vw_main.PRMT_FEATR_DSGN_FLOW_NUM
         ,vw_main.PRMT_FEATR_ACTUL_AVER_FLOW_NUM
         ,vw_main.PRMT_FEATR_ST_WTR_BODY_CODE
         ,vw_main.PRMT_FEATR_ST_WTR_BODY_NAME
         -- ,NULL -- vw_main.PRMT_FEATR_USR_DFND_DAT_ELM_1
         -- ,NULL -- vw_main.PRMT_FEATR_USR_DFND_DAT_ELM_2
         ,vw_main.LAT_MEAS
         ,vw_main.LONG_MEAS
         ,vw_main.HORZ_ACCURACY_MEAS
         ,vw_main.HORZ_COLL_METHOD_CODE
         ,vw_main.HORZ_REF_DATUM_CODE
         ,vw_main.REF_POINT_CODE
         ,vw_main.SRC_MAP_SCALE_NUM
         ,vw_main.PRMT_FEATR_TRTMNT_TYPE_CODE
         ,vw_prmt_featr.ICS_PRMT_FEATR_ID
     FROM tmp_stg_prmt_featr_main vw_main
     LEFT OUTER JOIN
        (SELECT UUID() ICS_PRMT_FEATR_ID
               ,PRMT_IDENT
               ,PRMT_FEATR_IDENT
           FROM (SELECT DISTINCT PRMT_IDENT
                       ,PRMT_FEATR_IDENT
                   FROM tmp_stg_prmt_featr_main) vw
        ) vw_prmt_featr
       ON vw_prmt_featr.PRMT_IDENT = vw_main.PRMT_IDENT
      AND vw_prmt_featr.PRMT_FEATR_IDENT = vw_main.PRMT_FEATR_IDENT;
   -- --------------
   -- ics_prmt_featr
   -- --------------
   SET v_marker    = 'INSERT INTO ICS_PRMT_FEATR';
   SET v_startdtm2 = NOW();
   SET v_src_tbl   = 'tmp_stg_prmt_featr';
   INSERT INTO ICS_PRMT_FEATR
      (ICS_PRMT_FEATR_ID
      ,ICS_PAYLOAD_ID
      ,PRMT_IDENT
      ,PRMT_FEATR_IDENT
      ,PRMT_FEATR_TYPE_CODE
      ,PRMT_FEATR_DESC
      ,PRMT_FEATR_DSGN_FLOW_NUM
      ,PRMT_FEATR_ACTUL_AVER_FLOW_NUM
      ,PRMT_FEATR_ST_WTR_BODY_CODE
      ,PRMT_FEATR_ST_WTR_BODY_NAME
      -- ,PRMT_FEATR_USR_DFND_DAT_ELM_1
      -- ,PRMT_FEATR_USR_DFND_DAT_ELM_2
      )
   SELECT DISTINCT ICS_PRMT_FEATR_ID
         ,'PermittedFeature'
         ,PRMT_IDENT
         ,PRMT_FEATR_IDENT
         ,PRMT_FEATR_TYPE_CODE
         ,PRMT_FEATR_DESC
         ,PRMT_FEATR_DSGN_FLOW_NUM
         ,PRMT_FEATR_ACTUL_AVER_FLOW_NUM
         ,PRMT_FEATR_ST_WTR_BODY_CODE
         ,PRMT_FEATR_ST_WTR_BODY_NAME
         -- ,PRMT_FEATR_USR_DFND_DAT_ELM_1
         -- ,PRMT_FEATR_USR_DFND_DAT_ELM_2
     FROM tmp_stg_prmt_featr;
   --
   SET v_rowcount = (SELECT ROW_COUNT());
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm    -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'INSERT'      -- pi_process
      ,v_rowcount);  -- pi_value
   -- -------------- --
   --  END PROCEDURE --
   -- -------------- --
   SET v_marker = 'CALL ics_etl_log_sp END';
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_sp_name     -- pi_marker
      ,NULL          -- pi_tgt_tbl
      ,NULL          -- pi_src_tbl 
      ,v_startdtm    -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'COMPLETED'   -- pi_process
      ,0);           -- pi_value
   --
   SET po_status = 1;
   SET po_errm   = '';
   --
   --
END