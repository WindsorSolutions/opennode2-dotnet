USE ga_ics_flow_local;
DROP PROCEDURE IF EXISTS load_ics_pretr_prmt_sp;
CREATE PROCEDURE load_ics_pretr_prmt_sp
   (OUT po_status INT
   ,OUT po_errm   VARCHAR(255))
BEGIN
-- ============================================================================
-- MODIFICATION HISTORY
-- Person      Date       Comments
-- ---------   --------   -----------------------------------------------------
-- Jen Go      20120924   Created.  
--
-- ============================================================================
   DECLARE v_startdtm   DATETIME     DEFAULT NOW();
   DECLARE v_enddtm     DATETIME;
   DECLARE v_marker     VARCHAR(255);
   DECLARE v_sp_name    VARCHAR(64)  DEFAULT 'load_ics_pretr_prmt_sp';
   DECLARE v_tgt_tbl    VARCHAR(64)  DEFAULT 'ICS_PRETR_PRMT';
   DECLARE v_src_tbl    VARCHAR(64)  DEFAULT 'tmp_stg_pretr_prmt';
   DECLARE v_rowcount   INT          DEFAULT 0;
   --
   DECLARE EXIT HANDLER FOR SQLEXCEPTION
      BEGIN  
         ROLLBACK;
         SET po_status = -1;
         SET po_errm   = v_marker;
         CALL ics_etl_log_sp    
            (v_sp_name          -- pi_sp_name
            ,v_marker           -- pi_marker
            ,v_tgt_tbl          -- pi_tgt_tbl
            ,v_src_tbl          -- pi_src_tbl
            ,v_startdtm         -- pi_startdtm
            ,NOW()              -- pi_enddtm
            ,'FAILED'           -- pi_process
            ,-1);               -- pi_value
      END;
   --
   SET v_marker = 'DROP AND CREATE TABLE tmp_stg_pretr_prmt_main';
   DROP TABLE IF EXISTS tmp_stg_pretr_prmt_main;
   CREATE TABLE tmp_stg_pretr_prmt_main AS 
   SELECT PERMIT_ID
         ,PRMT_IDENT
         ,PRETR_PROG_REQD_IND_CODE
         ,MAX(CONTROL_AUTH_NPDES_IDENT) CONTROL_AUTH_NPDES_IDENT
         ,MAX(PRETR_PROG_APRVD_DATE)    PRETR_PROG_APRVD_DATE
         ,AFFIL_TYPE_TXT
         ,FIRST_NAME
         ,LAST_NAME
         ,INDVL_TITLE_TXT
         ,ORG_FRML_NAME
         ,ELEC_ADDR_TXT
     FROM (SELECT stg.PERMIT_ID
                 ,stg.PRMT_IDENT
                 ,rqtc.ICIS_CODE   PRETR_PROG_REQD_IND_CODE
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS041' THEN
                     qr.ANSWER_COMMENT
                  ELSE NULL END    CONTROL_AUTH_NPDES_IDENT
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS042' THEN
                     qr.ANSWER_DATE
                  ELSE NULL END    PRETR_PROG_APRVD_DATE
                 --
                 ,vw_affl.AFFIL_TYPE_TXT
                 ,vw_affl.FIRST_NAME
                 ,vw_affl.LAST_NAME
                 ,vw_affl.INDVL_TITLE_TXT
                 ,vw_affl.ORG_FRML_NAME
                 ,vw_affl.ELEC_ADDR_TXT
             FROM stg_permit_main stg
             LEFT OUTER JOIN
                (SELECT affl.PERMIT_ACTION_ID
                       ,rat.ICIS_REF_AFFILIATION_TYPE   AFFIL_TYPE_TXT 
                       ,prsn.FIRST_NAME                 FIRST_NAME
                       ,prsn.LAST_NAME                  LAST_NAME
                       ,prsn.TITLE                      INDVL_TITLE_TXT
                       ,org.NAME                        ORG_FRML_NAME
                       ,pc.VALUE                        ELEC_ADDR_TXT 
                   FROM wrp.AFFILIATION affl
                   LEFT OUTER JOIN wrp.REF_AFFILIATION_TYPE rat
                     ON rat.CODE = affl.AFFILIATION_TYPE_CODE
                    AND rat.ICIS_REF_AFFILIATION_TYPE = 'PRE'
                   LEFT OUTER JOIN wrp.PERSON prsn
                     ON prsn.PERSON_ID = affl.PERSON_ID
                   LEFT OUTER JOIN wrp.PERSON_CONTACT pc
                     ON pc.PERSON_ID         = prsn.PERSON_ID
                    AND pc.CONTACT_TYPE_CODE = 'EM'
                   LEFT OUTER JOIN wrp.ORGANIZATION org
                     ON org.ORGANIZATION_ID = affl.ORGANIZATION_ID) vw_affl
               ON vw_affl.PERMIT_ACTION_ID = stg.PERMIT_ACTION_ID
             LEFT OUTER JOIN wrp.QUESTION_RESULT qr
               ON qr.PERMIT_ACTION_ID = stg.PERMIT_ACTION_ID
              AND qr.QUESTION_CODE IN ('ICIS041','ICIS042')
             LEFT OUTER JOIN wrp.REF_QUESTION_TYPE_CHOICE rqtc
               ON rqtc.CODE        = qr.ANSWER_CHOICE
              AND qr.QUESTION_CODE = 'ICIS040'
             WHERE ICS_GNRL_PRMT_ID IS NOT NULL) vw
    GROUP BY PERMIT_ID
            ,PRMT_IDENT
            ,PRETR_PROG_REQD_IND_CODE
            ,AFFIL_TYPE_TXT
            ,FIRST_NAME
            ,LAST_NAME
            ,INDVL_TITLE_TXT
            ,ORG_FRML_NAME
            ,ELEC_ADDR_TXT;
   --
   -- use stg instead of tmp, since this is needed
   -- when populating ics_contact
   -- maybe I should create the staging table instead?
   SET v_marker = 'DROP AND CREATE TABLE stg_pretr_prmt_main';
   DROP TABLE IF EXISTS tmp_stg_pretr_prmt; -- stg_pretr_prmt_main;
   CREATE TABLE tmp_stg_pretr_prmt AS
   SELECT vw_pretr.ICS_PRETR_PRMT_ID
         ,vw_main.PRMT_IDENT
         ,vw_main.PRETR_PROG_REQD_IND_CODE
         ,vw_main.CONTROL_AUTH_NPDES_IDENT
         ,vw_main.PRETR_PROG_APRVD_DATE
         --
         ,vw_main.AFFIL_TYPE_TXT
         ,vw_main.FIRST_NAME
         ,vw_main.LAST_NAME
         ,vw_main.INDVL_TITLE_TXT
         ,vw_main.ORG_FRML_NAME
         ,vw_main.ELEC_ADDR_TXT
     FROM tmp_stg_pretr_prmt_main vw_main
     JOIN (SELECT UUID()  ICS_PRETR_PRMT_ID
                 ,PERMIT_ID
                 ,PRMT_IDENT
                 ,PRETR_PROG_REQD_IND_CODE
                 ,CONTROL_AUTH_NPDES_IDENT
                 ,PRETR_PROG_APRVD_DATE
             FROM (SELECT DISTINCT PERMIT_ID
                         ,PRMT_IDENT
                         ,PRETR_PROG_REQD_IND_CODE
                         ,CONTROL_AUTH_NPDES_IDENT
                         ,PRETR_PROG_APRVD_DATE
                     FROM tmp_stg_pretr_prmt_main
                    WHERE PRETR_PROG_REQD_IND_CODE IS NOT NULL
                       OR CONTROL_AUTH_NPDES_IDENT IS NOT NULL
                       OR PRETR_PROG_APRVD_DATE    IS NOT NULL) vw
          ) vw_pretr
       ON vw_pretr.PERMIT_ID                = vw_main.PERMIT_ID
      AND vw_pretr.PRMT_IDENT               = vw_main.PRMT_IDENT
      AND vw_pretr.PRETR_PROG_REQD_IND_CODE = vw_main.PRETR_PROG_REQD_IND_CODE
      AND vw_pretr.CONTROL_AUTH_NPDES_IDENT = vw_main.CONTROL_AUTH_NPDES_IDENT
      AND vw_pretr.PRETR_PROG_APRVD_DATE    = vw_main.PRETR_PROG_APRVD_DATE;
   --
   SET v_marker  = 'INSERT INTO ICS_PRETR_PRMT';
   SET v_tgt_tbl = 'ICS_PRETR_PRMT';
   INSERT INTO ICS_PRETR_PRMT
      (ICS_PRETR_PRMT_ID
      ,ICS_PAYLOAD_ID
      ,PRMT_IDENT
      ,PRETR_PROG_REQD_IND_CODE
      ,CONTROL_AUTH_ST_AGNCY_CODE
      ,CONTROL_AUTH_RGNL_AGNCY_CODE
      ,CONTROL_AUTH_NPDES_IDENT
      ,PRETR_PROG_APRVD_DATE)
   SELECT ICS_PRETR_PRMT_ID
         ,'PretreatmentPermit'
         ,PRMT_IDENT
         ,PRETR_PROG_REQD_IND_CODE
         ,'GA'
         ,'04'
         ,CONTROL_AUTH_NPDES_IDENT
         ,PRETR_PROG_APRVD_DATE
     FROM (SELECT DISTINCT ICS_PRETR_PRMT_ID
                 ,PRMT_IDENT
                 ,PRETR_PROG_REQD_IND_CODE
                 ,CONTROL_AUTH_NPDES_IDENT
                 ,PRETR_PROG_APRVD_DATE
             FROM tmp_stg_pretr_prmt) vw;
   -- 
   SET v_rowcount = (SELECT ROW_COUNT());
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm    -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'INSERT'      -- pi_process
      ,v_rowcount);  -- pi_value
   -- insert the rest of the data into ICS_CONTACT using load_ics_contact_sp --
   -- -------------- --
   --  END PROCEDURE --
   -- -------------- --
   SET v_marker = 'CALL ics_etl_log_sp END';
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_sp_name     -- pi_marker
      ,NULL          -- pi_tgt_tbl
      ,NULL          -- pi_src_tbl 
      ,v_startdtm    -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'COMPLETED'   -- pi_process
      ,0);           -- pi_value
   --
   SET po_status = 1;
   SET po_errm   = '';
   --
END