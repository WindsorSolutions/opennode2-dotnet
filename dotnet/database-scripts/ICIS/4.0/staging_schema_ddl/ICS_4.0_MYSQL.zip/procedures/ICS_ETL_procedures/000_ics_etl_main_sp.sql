USE ga_ics_flow_local;
DROP PROCEDURE IF EXISTS ics_etl_main_sp;
CREATE PROCEDURE ics_etl_main_sp()
BEGIN
-- ============================================================================
-- MODIFICATION HISTORY
-- Person      Date       Comments
-- ---------   --------   -----------------------------------------------------
-- Jen Go      20120911   Created.  
--
-- ============================================================================
   DECLARE v_startdtm
          ,v_enddtm     DATETIME;
   DECLARE v_sp_name    VARCHAR(64)   DEFAULT 'ics_etl_main_sp';
   DECLARE v_marker     VARCHAR(255);
   DECLARE v_errstat    INT           DEFAULT 1;
   DECLARE v_errm       VARCHAR(255);
   
   DECLARE EXIT HANDLER FOR SQLEXCEPTION
      BEGIN  
         -- ROLLBACK;
         -- SELECT CONCAT('Error occurred at ',v_marker); 
         -- 
         CALL ics_etl_log_sp    
            (v_sp_name          -- pi_sp_name
            ,v_marker           -- pi_marker
            ,NULL               -- pi_tgt_tbl
            ,NULL               -- pi_src_tbl
            ,v_startdtm         -- pi_startdtm
            ,NOW()              -- pi_enddtm
            ,'FAILED'           -- pi_process
            ,-1);               -- pi_value
         COMMIT;
      END;
   SET v_startdtm = NOW();
   --
   SET v_marker = 'DELETE FROM ics_etl_log';
   DELETE FROM ics_etl_log;
   COMMIT;
   -- --------------------------
   -- deletes ICS and stg tables 
   -- --------------------------
   SET v_marker = 'CALL delete_ics_tables_sp';
   CALL delete_ics_tables_sp(v_errstat,v_errm);
   IF v_errstat < 0 THEN
      SELECT v_marker;
      CALL raise_err;  -- non-existent sp to force error.
   END IF;
   --
   -- ----------------
   -- load_stg_prmt_sp
   -- ----------------
   SET v_marker = 'CALL load_stg_prmt_sp';
   CALL load_stg_prmt_sp(v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- ---------------------
   -- load_stg_cafo_prmt_sp
   -- ---------------------
   SET v_marker = 'CALL load_stg_cafo_prmt_sp';
   CALL load_stg_cafo_prmt_sp(v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- -----------------------------
   -- load_ics_narr_cond_related_sp
   -- -----------------------------
   SET v_marker = 'CALL load_ics_narr_cond_related_sp';
   CALL load_ics_narr_cond_related_sp(v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF; 
   -- -----------------------
   -- load_ics_prmt_reissu_sp
   -- -----------------------
   SET v_marker = 'CALL load_ics_prmt_reissu_sp';
   CALL load_ics_prmt_reissu_sp(v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- ---------------------
   -- load_ics_prmt_term_sp
   -- ---------------------
   SET v_marker = 'CALL load_ics_prmt_term_sp';
   CALL load_ics_prmt_term_sp(v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF; 
   -- --------------------------
   -- load_ics_prmt_track_evt_sp
   -- --------------------------
   SET v_marker = 'CALL load_ics_prmt_track_evt_sp';
   CALL load_ics_prmt_track_evt_sp(v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF; 
   -- the following 2 SPs insert into ICS_SATL_COLL_SYSTM
   -- as child of ICS_CSO_PRMT and ICS_POTW_PRMT
   -- -----------------------------
   -- load_ics_potw_prmt_related_sp
   -- -----------------------------
   SET v_marker = 'CALL load_ics_potw_prmt_related_sp';
   CALL load_ics_potw_prmt_related_sp(v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- ----------------------------
   -- load_ics_cso_prmt_related_sp
   -- ----------------------------
   SET v_marker = 'CALL load_ics_cso_prmt_related_sp';
   CALL load_ics_cso_prmt_related_sp(v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err; 
   END IF;
   -- -----------------------------
   -- load_ics_swms_4_large_prmt_sp
   -- -----------------------------
   SET v_marker = 'CALL load_ics_swms_4_large_prmt_sp';
   CALL load_ics_swms_4_large_prmt_sp(v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF; 
   -- -----------------------------
   -- load_ics_swms_4_small_prmt_sp
   -- -----------------------------
   SET v_marker = 'CALL load_ics_swms_4_small_prmt_sp';
   CALL load_ics_swms_4_small_prmt_sp(v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF; 
   -- ---------------------------
   -- load_stg_swms_4_prog_rep_sp
   -- ---------------------------
   SET v_marker = 'CALL load_stg_swms_4_prog_rep_sp';
   CALL load_stg_swms_4_prog_rep_sp(v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- ---------------------------
   -- load_ics_pretr_perf_summ_sp
   -- ---------------------------
   SET v_marker = 'CALL load_ics_pretr_perf_summ_sp';
   CALL load_ics_pretr_perf_summ_sp(v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- ----------------------
   -- load_ics_basic_prmt_sp
   -- ----------------------
   SET v_marker = 'CALL load_ics_basic_prmt_sp';
   CALL load_ics_basic_prmt_sp(v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- ---------------------
   -- load_ics_gnrl_prmt_sp
   -- ---------------------
   SET v_marker = 'CALL load_ics_gnrl_prmt_sp';
   CALL load_ics_gnrl_prmt_sp(v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- ----------------------
   -- load_ics_unprmt_fac_sp
   -- ----------------------
   SET v_marker = 'CALL load_ics_unprmt_fac_sp';
   CALL load_ics_unprmt_fac_sp(v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- ----------------------
   -- load_ics_pretr_prmt_sp
   -- ----------------------
   SET v_marker = 'CALL load_ics_pretr_prmt_sp';
   CALL load_ics_pretr_prmt_sp(v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- ---------------------
   -- load_ics_cafo_prmt_sp
   -- ---------------------
   SET v_marker = 'CALL load_ics_cafo_prmt_sp';
   CALL load_ics_cafo_prmt_sp(v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- ---------------------------
   -- load_ics_swms_4_prog_rep_sp
   -- ---------------------------
   SET v_marker = 'CALL load_ics_swms_4_prog_rep_sp';
   CALL load_ics_swms_4_prog_rep_sp(v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err; 
   END IF;
   -- ---------------
   -- load_ics_fac_sp
   -- ---------------
   SET v_marker = 'CALL load_ics_fac_sp';
   CALL load_ics_fac_sp(v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- ----------------
   -- load_ics_addr_sp
   -- ----------------
   SET v_marker = 'CALL load_ics_addr_sp';
   CALL load_ics_addr_sp(v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- ------------------------
   -- load_ics_cmpl_related_sp
   -- ------------------------
   -- call here because 
   SET v_marker = 'CALL load_ics_cmpl_related_sp';
   CALL load_ics_cmpl_related_sp(v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF; 
   -- -------------------
   -- load_ics_contact_sp
   -- -------------------
   SET v_marker = 'CALL load_ics_contact_sp';
   CALL load_ics_contact_sp(v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- ----------------------
   -- load_ics_naics_code_sp
   -- ----------------------
   SET v_marker = 'CALL load_ics_naics_code_sp';
   CALL load_ics_naics_code_sp(v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;  -- non-existent sp to force error.
   END IF;
   -- --------------------
   -- load_ics_sic_code_sp
   -- --------------------
   SET v_marker = 'CALL load_ics_sic_code_sp';
   CALL load_ics_sic_code_sp(v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err; 
   END IF;
   -- ----------------
   -- load_ics_plcy_sp
   -- ----------------
   SET v_marker = 'CALL load_ics_plcy_sp';
   CALL load_ics_plcy_sp(v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err; 
   END IF;
   -- ----------------------
   -- load_ics_orig_progs_sp
   -- ----------------------
   SET v_marker = 'CALL load_ics_orig_progs_sp';
   CALL load_ics_orig_progs_sp(v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- ----------------------
   -- load_ics_prmt_featr_sp
   -- ----------------------
   SET v_marker = 'CALL load_ics_prmt_featr_sp';
   CALL load_ics_prmt_featr_sp(v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF; 
   -- ----------------------------------
   -- load_ics_prmt_featr_trtmnt_type_sp
   -- ----------------------------------
   SET v_marker = 'CALL load_ics_prmt_featr_trtmnt_type_sp';
   CALL load_ics_prmt_featr_trtmnt_type_sp(v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err; 
   END IF; 
   -- ---------------------
   -- load_ics_geo_coord_sp
   -- ---------------------
   SET v_marker = 'CALL load_ics_geo_coord_sp';
   CALL load_ics_geo_coord_sp(v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- ---------------------------
   -- load_ics_lmt_set_related_sp
   -- --------------------------- 
   SET v_marker = 'CALL load_ics_lmt_set_related_sp';
   CALL load_ics_lmt_set_related_sp(v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- ------------------------------
   -- load_ics_param_lmts_related_sp
   -- ------------------------------
   SET v_marker = 'CALL load_ics_param_lmts_related_sp';
   CALL load_ics_param_lmts_related_sp(v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF; 
   -- -------------------------
   -- load_ics_sngl_evt_viol_sp
   -- -------------------------
   SET v_marker = 'CALL load_ics_sngl_evt_viol_sp';
   CALL load_ics_sngl_evt_viol_sp(v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;   
   -- --------------------------------
   -- load_ics_cmpl_mon_lnk_related_sp
   -- --------------------------------
   SET v_marker = 'CALL load_ics_cmpl_mon_lnk_related_sp';
   CALL load_ics_cmpl_mon_lnk_related_sp(v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;   
   /*
   -- ~~~~~~~~~~~~~~~~~ --
   -- ~~~~~~~~~~~~~~~~~ --
   -- STOP HERE FOR NOW --
   -- ---------------------
   -- load_ics_anml_type_sp
   -- ---------------------
   SET v_marker = 'CALL load_ics_anml_type_sp';
   CALL load_ics_anml_type_sp(v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- -----------------------
   -- load_ics_containment_sp
   -- -----------------------
   SET v_marker = 'CALL load_ics_containment_sp';
   CALL load_ics_containment_sp(v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err; 
   END IF;
   -- -----------------------------------
   -- load_ics_mnur_lttr_prcss_ww_stor_sp
   -- -----------------------------------
   SET v_marker = 'CALL load_ics_mnur_lttr_prcss_ww_stor_sp';
   CALL load_ics_mnur_lttr_prcss_ww_stor_sp(v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err; 
   END IF;
   --
  */ 
   /*
   -- -----------------------
   -- drop tmp tables created
   -- -----------------------
   DROP TABLE IF EXISTS tmp_stg_pretr_prmt_main;
   DROP TABL EIF EXISTS tmp_stg_pretr_prmt;
   DROP TABLE IF EXISTS tmp_stg_cafo_prmt_main;
   DROP TABLE IF EXISTS tmp_stg_cafo_prmt;
   DROP TABLE IF EXISTS tmp_stg_cmpl;
   DROP TABLE IF EXISTS tmp_stg_cmpl_main;
   DROP TABLE IF EXISTS tmp_stg_cso_prmt;
   DROP TABLE IF EXISTS tmp_stg_cso_prmt_main;
   DROP TABLE IF EXISTS tmp_stg_lmt_set_main;
   DROP TABLE IF EXISTS tmp_stg_narr_cond;
   DROP TABLE IF EXISTS tmp_stg_narr_cond_main;
   DROP TABLE IF EXISTS tmp_stg_potw_prmt;
   DROP TABLE IF EXISTS tmp_stg_potw_prmt_main;
   DROP TABLE IF EXISTS tmp_stg_prmt_main;
   DROP TABLE IF EXISTS tmp_stg_swms_4_prog_rep_main;
   DROP TABLE IF EXISTS tmp_stg_swms_4_prog_rep;
   DROP TABLE IF EXISTS tmp_stg_prmt_featr_main;
   DROP TABLE IF EXISTS tmp_stg_prmt_featr;
   DROP TABLE IF EXISTS tmp_stg_lmt_set_main;
   DROP TABLE IF EXISTS tmp_stg_lmt_set;
   DROP TABLE IF EXISTS tmp_stg_paramlmts_main;
   DROP TABLE IF EXISTS tmp_stg_paramlmts;
   */
   -- ---------------------
   -- ics_change_detection
   -- ---------------------
   SET v_marker = 'CALL ics_change_detection';
   CALL ics_change_detection(v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err; 
   END IF;
   -- --------- --
   -- ENDS HERE --
   -- --------- --
   SET v_marker = 'CALL ics_etl_log_sp end';
   CALL ics_etl_log_sp    
      (v_sp_name          -- pi_sp_name
      ,'ETL completed.'   -- pi_marker
      ,NULL               -- pi_tgt_tbl
      ,NULL               -- pi_src_tbl
      ,v_startdtm         -- pi_startdtm
      ,NOW()              -- pi_enddtm
      ,'COMPLETED'        -- pi_process
      ,0);                -- pi_value
   --
   COMMIT;
   --
END