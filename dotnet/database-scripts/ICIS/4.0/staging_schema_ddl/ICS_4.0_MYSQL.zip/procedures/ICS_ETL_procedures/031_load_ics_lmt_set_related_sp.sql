USE ga_ics_flow_local;
DROP PROCEDURE IF EXISTS load_ics_lmt_set_related_sp;
CREATE PROCEDURE load_ics_lmt_set_related_sp
   (OUT po_status INT
   ,OUT po_errm   VARCHAR(255))
BEGIN
-- ============================================================================
-- MODIFICATION HISTORY
-- Person      Date       Comments
-- ---------   --------   -----------------------------------------------------
-- Jen Go      20120921   Created.  
--                        Populates the following tables
--                          1) ics_lmt_set
--                          2) ics_lmt_set_months_appl
--                          2) ics_lmt_set_schd
--                          2) ics_lmt_set_stat
-- ============================================================================
   DECLARE v_startdtm   DATETIME     DEFAULT NOW();
   DECLARE v_startdtm2
          ,v_enddtm     DATETIME;
   DECLARE v_marker     VARCHAR(255);
   DECLARE v_sp_name    VARCHAR(64)  DEFAULT 'load_ics_lmt_set_related_sp';
   DECLARE v_tgt_tbl    VARCHAR(64);
   DECLARE v_src_tbl    VARCHAR(64);
   DECLARE v_rowcount   INT          DEFAULT 0;
   --
   DECLARE EXIT HANDLER FOR SQLEXCEPTION
      BEGIN  
         ROLLBACK;
         SET po_status = -1;
         SET po_errm   = v_marker;
         CALL ics_etl_log_sp    
            (v_sp_name          -- pi_sp_name
            ,v_marker           -- pi_marker
            ,v_tgt_tbl          -- pi_tgt_tbl
            ,v_src_tbl          -- pi_src_tbl
            ,v_startdtm         -- pi_startdtm
            ,NOW()              -- pi_enddtm
            ,'FAILED'           -- pi_process
            ,-1);               -- pi_value
      END;
   -- --------------------
   -- tmp_stg_lmt_set_main
   -- --------------------
   SET v_marker = 'DROP AND CREATE TABLE tmp_stg_lmt_set_main';
   DROP TABLE IF EXISTS tmp_stg_lmt_set_main;
   CREATE TABLE tmp_stg_lmt_set_main AS
   SELECT stg.PERMIT_ID                          PERMIT_ID
         ,stg.PERMIT_ACTION_ID                   PERMIT_ACTION_ID
         ,stg.PERMIT_ACTION_TYPE_CODE            PERMIT_ACTION_TYPE_CODE
         ,stg.FACILITY_FEATURE_ID                FACILITY_FEATURE_ID
         ,lmt_set.LIMIT_SET_ID                   LIMIT_SET_ID
         ,stg.PRMT_IDENT                         PRMT_IDENT
         ,stg.PRMT_FEATR_IDENT                   PRMT_FEATR_IDENT
         ,lmt_set.DESIGNATOR_CODE                LMT_SET_DESIGNATOR
         ,CASE WHEN lmt_set.IS_PER_DISCHARGE = 1 THEN 
             'U'
          ELSE 
             'S' 
          END                                    LMT_SET_TYPE
         ,lmt_set.DESCRIP                        LMT_SET_NAME_TXT
         ,lmt_set.DMR_PRE_PRINT_CMNTS_TXT        DMR_PRE_PRINT_CMNTS_TXT
         -- -----------------------
         -- ics_lmt_set_months_appl
         -- -----------------------
         ,vw_lsrim.MONTH_NUMBER                  MONTH_NUMBER
         ,vw_lsrim.MONTH_NAME                    MONTH_NAME
         -- ----------------------------------
         -- ics_lmt_set_schd, ics_lmt_set_stat
         -- ---------------------------------
         ,lmt_set.MONITORING_FREQUENCY_TYPE_CODE MONITORING_FREQUENCY_TYPE_CODE
         ,lmt_set.MONITORING_FREQUENCY_VALUE     MONITORING_FREQUENCY_VALUE
         ,lmt_set.SUBMITTAL_FREQUENCY_TYPE_CODE  SUBMITTAL_FREQUENCY_TYPE_CODE
         ,lmt_set.SUBMITTAL_FREQUENCY_VALUE      SUBMITTAL_FREQUENCY_VALUE
         ,lmt_set.MONITORING_FREQUENCY_VALUE  
           * rlft.NUM_MONTHS                     NUM_UNITS_REP_PERIOD_INTEGER
         ,lmt_set.SUBMITTAL_FREQUENCY_VALUE      NUM_SUBM_UNITS_INTEGER
         -- INITIAL_MON_DATE; LMT_SET_MOD_EFFECTIVE_DATE;
         -- LMT_SET_STAT_START_DATE
         ,lmt_set.INITIAL_MONITORING_DATE        INITIAL_MONITORING_DUE_DATE
         ,lmt_set.INITIAL_DMR_DUE_DATE           INITIAL_DMR_DUE_DATE
         ,rpa.ICIS_REF_MODIFICATION_TYPE
         ,CASE WHEN lmt_set.IS_ACTIVE = 1 THEN 'A'
          ELSE 'I' END                           LMT_SET_STAT_IND
     FROM wrp.LIMIT_SET lmt_set
     JOIN tmp_stg_prmt_featr stg
       ON stg.FACILITY_FEATURE_ID = lmt_set.FACILITY_FEATURE_ID
     LEFT OUTER JOIN
        (SELECT LIMIT_SET_ID,MONTH_NUMBER
               ,CASE WHEN MONTH_NUMBER = 1  THEN 'JAN'
                     WHEN MONTH_NUMBER = 2  THEN 'FEB'
                     WHEN MONTH_NUMBER = 3  THEN 'MAR'
                     WHEN MONTH_NUMBER = 4  THEN 'APR'
                     WHEN MONTH_NUMBER = 5  THEN 'MAY'
                     WHEN MONTH_NUMBER = 6  THEN 'JUN'
                     WHEN MONTH_NUMBER = 7  THEN 'JUL'
                     WHEN MONTH_NUMBER = 8  THEN 'AUG'
                     WHEN MONTH_NUMBER = 9  THEN 'SEP'
                     WHEN MONTH_NUMBER = 10 THEN 'OCT'
                     WHEN MONTH_NUMBER = 11 THEN 'NOV'
                     WHEN MONTH_NUMBER = 12 THEN 'DEC'
                END    MONTH_NAME
           FROM wrp.LIMIT_SET_REQ_IN_MONTHS) vw_lsrim
       ON vw_lsrim.LIMIT_SET_ID = lmt_set.LIMIT_SET_ID 
     LEFT OUTER JOIN wrp.REF_PERMIT_ACTION_TYPE rpa
       ON rpa.CODE = stg.PERMIT_ACTION_TYPE_CODE
     LEFT OUTER JOIN wrp.REF_LS_FREQUENCY_TYPE rlft
       ON rlft.CODE = lmt_set.MONITORING_FREQUENCY_TYPE_CODE;
   -- ---------------
   -- tmp_stg_lmt_set
   -- ---------------
   SET v_marker = 'INSERT INTO tmp_stg_lmt_set';
   DROP TABLE IF EXISTS tmp_stg_lmt_set;  -- stg_limit_set_main
   CREATE TABLE tmp_stg_lmt_set AS
   SELECT vw_main.*
         ,vw_lmt_set.ICS_LMT_SET_ID
     FROM tmp_stg_lmt_set_main vw_main
     LEFT OUTER JOIN
        (SELECT UUID()    ICS_LMT_SET_ID
               ,PRMT_IDENT
               ,PRMT_FEATR_IDENT
               ,LMT_SET_DESIGNATOR
           FROM (SELECT DISTINCT PRMT_IDENT
                       ,PRMT_FEATR_IDENT
                       ,LMT_SET_DESIGNATOR
                   FROM tmp_stg_lmt_set_main
                  WHERE LMT_SET_DESIGNATOR IS NOT NULL) vw
        ) vw_lmt_set
       ON vw_lmt_set.PRMT_IDENT         = vw_main.PRMT_IDENT
      AND vw_lmt_set.PRMT_FEATR_IDENT   = vw_main.PRMT_FEATR_IDENT
      AND vw_lmt_set.LMT_SET_DESIGNATOR = vw_main.LMT_SET_DESIGNATOR;
   --
   SET v_marker = 'CREATE INDEX tmp_stg_lmt_set.LIMIT_SET_ID';
   CREATE INDEX tmp_idx_lmtsetid ON tmp_stg_lmt_set(LIMIT_SET_ID);
   -- -----------
   -- ics_lmt_set
   -- -----------
   SET v_startdtm2 = NOW();
   SET v_tgt_tbl   = 'ICS_LMT_SET';
   SET v_src_tbl   = 'tmp_stg_lmt_set';
   SET v_marker    = 'INSERT INTO ICS_LMT_SET';
   INSERT INTO ICS_LMT_SET
      (ICS_LMT_SET_ID
      ,ICS_PAYLOAD_ID
      -- ,SRC_SYSTM_IDENT
      ,PRMT_IDENT
      ,PRMT_FEATR_IDENT
      ,LMT_SET_DESIGNATOR
      ,LMT_SET_TYPE
      ,LMT_SET_NAME_TXT
      ,DMR_PRE_PRINT_CMNTS_TXT)
   SELECT DISTINCT ICS_LMT_SET_ID
         ,'LimitSet'
         -- ,SRC_SYSTM_IDENT
         ,PRMT_IDENT
         ,PRMT_FEATR_IDENT
         ,LMT_SET_DESIGNATOR
         ,LMT_SET_TYPE
         ,LMT_SET_NAME_TXT
         ,DMR_PRE_PRINT_CMNTS_TXT
     FROM tmp_stg_lmt_set;   
   --
   SET v_rowcount = (SELECT ROW_COUNT());
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'INSERT'      -- pi_process
      ,v_rowcount);  -- pi_value 
   -- -----------------------
   -- ics_lmt_set_months_appl
   -- -----------------------
   SET v_startdtm2 = NOW();
   SET v_src_tbl   = 'tmp_stg_lmt_set';
   SET v_tgt_tbl   = 'ICS_LMT_SET_MONTHS_APPL';
   SET v_marker    = 'INSERT INTO ICS_LMT_SET_MONTHS_APPL';
   INSERT INTO ICS_LMT_SET_MONTHS_APPL
      (ICS_LMT_SET_MONTHS_APPL_ID
      ,ICS_LMT_SET_ID
      ,LMT_SET_MONTHS_APPL)
   SELECT UUID()
         ,ICS_LMT_SET_ID
         ,LMT_SET_MONTHS_APPL
     FROM (SELECT DISTINCT ICS_LMT_SET_ID
                 ,MONTH_NAME  LMT_SET_MONTHS_APPL
             FROM tmp_stg_lmt_set) vw;
   --
   SET v_rowcount = (SELECT ROW_COUNT());
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'INSERT'      -- pi_process
      ,v_rowcount);  -- pi_value 
   -- ----------------
   -- ICS_LMT_SET_SCHD
   -- ----------------
   SET v_startdtm2 = NOW();
   SET v_src_tbl   = 'tmp_stg_lmt_set';
   SET v_tgt_tbl   = 'ICS_LMT_SET_SCHD';
   SET v_marker    = 'INSERT INTO ICS_LMT_SET_SCHD';
   INSERT INTO ICS_LMT_SET_SCHD
      (ICS_LMT_SET_SCHD_ID
      ,ICS_LMT_SET_ID
      ,NUM_UNITS_REP_PERIOD_INTEGER
      ,NUM_SUBM_UNITS_INTEGER
      ,INITIAL_MON_DATE
      ,INITIAL_DMR_DUE_DATE
      ,LMT_SET_MOD_EFFECTIVE_DATE)
   SELECT UUID()
         ,ICS_LMT_SET_ID
         ,NUM_UNITS_REP_PERIOD_INTEGER
         ,NUM_SUBM_UNITS_INTEGER
         ,INITIAL_MONITORING_DUE_DATE 
         ,INITIAL_DMR_DUE_DATE
         ,LMT_SET_MOD_EFFECTIVE_DATE
     FROM (SELECT DISTINCT ICS_LMT_SET_ID
                 ,NUM_UNITS_REP_PERIOD_INTEGER
                 ,NUM_SUBM_UNITS_INTEGER
                 ,INITIAL_MONITORING_DUE_DATE
                 ,INITIAL_DMR_DUE_DATE
                 ,INITIAL_MONITORING_DUE_DATE  LMT_SET_MOD_EFFECTIVE_DATE
             FROM tmp_stg_lmt_set) vw;
   --
   SET v_rowcount = (SELECT ROW_COUNT());
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'INSERT'      -- pi_process
      ,v_rowcount);  -- pi_value 
   -- ----------------
   -- ICS_LMT_SET_STAT
   -- ----------------
   SET v_startdtm2 = NOW();
   SET v_src_tbl   = 'tmp_stg_lmt_set';
   SET v_tgt_tbl   = 'ICS_LMT_SET_STAT';
   SET v_marker    = 'INSERT INTO ICS_LMT_SET_STAT';
   INSERT INTO ICS_LMT_SET_STAT
      (ICS_LMT_SET_STAT_ID
      ,ICS_LMT_SET_ID
      ,LMT_SET_STAT_IND
      ,LMT_SET_STAT_START_DATE)
   SELECT UUID()
         ,ICS_LMT_SET_ID
         ,LMT_SET_STAT_IND
         ,INITIAL_MONITORING_DUE_DATE
     FROM (SELECT DISTINCT ICS_LMT_SET_ID
                 ,INITIAL_MONITORING_DUE_DATE  
                 ,LMT_SET_STAT_IND
             FROM tmp_stg_lmt_set) vw;
   --
   SET v_rowcount = (SELECT ROW_COUNT());
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'INSERT'      -- pi_process
      ,v_rowcount);  -- pi_value 
      
   -- -------------- --
   --  END PROCEDURE --
   -- -------------- --
   SET v_marker = 'CALL ics_etl_log_sp END';
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_sp_name     -- pi_marker
      ,NULL          -- pi_tgt_tbl
      ,NULL          -- pi_src_tbl 
      ,v_startdtm    -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'COMPLETED'   -- pi_process
      ,0);           -- pi_value
   --
   SET po_status = 1;
   SET po_errm   = '';
   --
END   