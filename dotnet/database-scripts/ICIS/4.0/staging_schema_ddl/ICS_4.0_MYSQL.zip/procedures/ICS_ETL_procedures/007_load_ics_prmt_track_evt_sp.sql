USE ga_ics_flow_local;
DROP PROCEDURE IF EXISTS load_ics_prmt_track_evt_sp;
CREATE PROCEDURE load_ics_prmt_track_evt_sp
   (OUT po_status INT
   ,OUT po_errm   VARCHAR(255))
BEGIN
-- ============================================================================
-- MODIFICATION HISTORY
-- Person      Date       Comments
-- ---------   --------   -----------------------------------------------------
-- Jen Go      20120924   Created.  
--
-- ============================================================================
   DECLARE v_startdtm   DATETIME     DEFAULT NOW();
   DECLARE v_enddtm     DATETIME;
   DECLARE v_marker     VARCHAR(255);
   DECLARE v_sp_name    VARCHAR(64)  DEFAULT 'load_ics_prmt_track_evt_sp';
   DECLARE v_tgt_tbl    VARCHAR(64)  DEFAULT 'ICS_PRMT_TRACK_EVT';
   DECLARE v_src_tbl    VARCHAR(64)  DEFAULT 'PERMIT_ACTION_MILESTONE';
   DECLARE v_rowcount   INT          DEFAULT 0;
   --
   DECLARE EXIT HANDLER FOR SQLEXCEPTION
      BEGIN  
         ROLLBACK;
         SET po_status = -1;
         SET po_errm   = v_marker;
         CALL ics_etl_log_sp    
            (v_sp_name          -- pi_sp_name
            ,v_marker           -- pi_marker
            ,v_tgt_tbl          -- pi_tgt_tbl
            ,v_src_tbl          -- pi_src_tbl
            ,v_startdtm         -- pi_startdtm
            ,NOW()              -- pi_enddtm
            ,'FAILED'           -- pi_process
            ,-1);               -- pi_value
      END;
   --
   SET v_marker = 'INSERT INTO ICS_PRMT_TRACK_EVT';
   INSERT INTO ICS_PRMT_TRACK_EVT
      (ICS_PRMT_TRACK_EVT_ID
      ,ICS_PAYLOAD_ID
      ,PRMT_IDENT
      ,PRMT_TRACK_EVT_CODE
      ,PRMT_TRACK_EVT_DATE)
   SELECT UUID()
         ,'PermitTrackingEvent'
         ,NUMBER
         ,ICIS_PERM_TRACK_EVENT_CODE
         ,MILESTONE_DATE
     FROM (SELECT DISTINCT pmt.NUMBER
                 ,rmt.ICIS_PERM_TRACK_EVENT_CODE
                 ,pam.MILESTONE_DATE
             FROM wrp.PERMIT pmt
             JOIN wrp.PERMIT_ACTION pa
               ON pa.PERMIT_ID = pmt.PERMIT_ID
             JOIN wrp.PERMIT_ACTION_MILESTONE pam
               ON pam.PERMIT_ACTION_ID = pa.PERMIT_ACTION_ID
             JOIN wrp.REF_MILESTONE_TYPE rmt
               ON rmt.CODE = pam.MILESTONE_TYPE_CODE
            WHERE 1=1 
              AND pmt.PERMIT_CATEGORY_CODE IN ('IND','GPC')
              AND pmt.PERMIT_TYPE_CODE IN ('AFO','GEN CW'
                                          ,'GEN PID','GEN SG'
                                          ,'MS4','REUSE'
                                          -- place holders
                                          ,'CSO','PRETM'
                                          ,'GEN WTP')
              AND pmt.PERMIT_STATUS_CODE       = 'EFF'
              AND pa.PERMIT_ACTION_STATUS_CODE = 'PRO'
              AND rmt.ICIS_PERM_TRACK_EVENT_CODE IS NOT NULL) vw;
   -- 
   SET v_rowcount = (SELECT ROW_COUNT());
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm    -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'INSERT'      -- pi_process
      ,v_rowcount);  -- pi_value
   -- -------------- --
   --  END PROCEDURE --
   -- -------------- --
   SET v_marker = 'CALL ics_etl_log_sp END';
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_sp_name     -- pi_marker
      ,NULL          -- pi_tgt_tbl
      ,NULL          -- pi_src_tbl 
      ,v_startdtm    -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'COMPLETED'   -- pi_process
      ,0);           -- pi_value
   --
   SET po_status = 1;
   SET po_errm   = '';
   --
END