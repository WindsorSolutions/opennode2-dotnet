USE ga_ics_flow_local;
DROP PROCEDURE IF EXISTS load_ics_cmpl_mon_lnk_related_sp;
CREATE PROCEDURE load_ics_cmpl_mon_lnk_related_sp
   (OUT po_status INT
   ,OUT po_errm   VARCHAR(255))
BEGIN
-- ============================================================================
-- MODIFICATION HISTORY
-- Person      Date       Comments
-- ---------   --------   -----------------------------------------------------
-- Jen Go      20120924   Created.
--                        Populate the following:
--                           1) ICS_CMPL_MON_LNK
--                           2) ICS_LNK_SNGL_EVT
-- ============================================================================
   DECLARE v_startdtm   DATETIME     DEFAULT NOW();
   DECLARE v_startdtm2
          ,v_enddtm     DATETIME;
   DECLARE v_marker     VARCHAR(255);
   DECLARE v_sp_name    VARCHAR(64)  DEFAULT 'load_ics_cmpl_mon_lnk_related_sp';
   DECLARE v_tgt_tbl    VARCHAR(64);
   DECLARE v_src_tbl    VARCHAR(64);
   DECLARE v_rowcount   INT          DEFAULT 0;
   --
   DECLARE EXIT HANDLER FOR SQLEXCEPTION
      BEGIN  
         ROLLBACK;
         SET po_status = -1;
         SET po_errm   = v_marker;
         CALL ics_etl_log_sp    
            (v_sp_name          -- pi_sp_name
            ,v_marker           -- pi_marker
            ,v_tgt_tbl          -- pi_tgt_tbl
            ,v_src_tbl          -- pi_src_tbl
            ,v_startdtm         -- pi_startdtm
            ,NOW()              -- pi_enddtm
            ,'FAILED'           -- pi_process
            ,-1);               -- pi_value
         COMMIT;
         --
      END;
   -- --------------------
   -- tmp_load_stg_cmpl_sp
   -- --------------------
   -- create temp table instead of a view because views error out with 
   -- subqueries.
   -- can't use TEMPORARY tables because you can't join them
   SET v_marker  = 'DROP AND CREATE TABLE tmp_stg_cmpl_lnk_main';
   DROP TABLE IF EXISTS tmp_stg_cmpl_lnk_main;
   CREATE TABLE tmp_stg_cmpl_lnk_main AS
   SELECT pmt.PERMIT_ID
         ,insp.INSPECTION_ID
         ,pmt.NUMBER
         ,rcat.CATEGORY
         ,insp.BEGIN_DATE
         ,vio.VIOLATION_TYPE_CODE
         ,vio.VIOLATION_DATE
     FROM wrp.PERMIT pmt
     JOIN wrp.INSPECTION insp
       ON insp.INSPECTION_ID = pmt.PERMIT_ID
     LEFT OUTER JOIN wrp.REF_INSPECTION_REASON_TYPE rirt
       ON rirt.CODE = insp.INSPECTION_REASON_TYPE_CODE
     LEFT OUTER JOIN wrp.REF_COMP_ACT_TYPE rcat
       ON rcat.CODE = rirt.CATEGORY
     LEFT OUTER JOIN wrp.VIOLATION vio
       ON vio.INSPECTION_ID = insp.INSPECTION_ID
    -- should exist in both these tables:
    WHERE pmt.PERMIT_ID IN (SELECT PRMT_IDENT
                              FROM ICS_CMPL_MON
                            UNION
                            SELECT PRMT_IDENT
                              FROM ICS_SNGL_EVT_VIOL);
   -- ----------------
   -- tmp_stg_cmpl_lnk
   -- ----------------
   SET v_marker = 'DROP AND CREATE TABLE tmp_stg_cmpl_lnk';
   DROP TABLE IF EXISTS tmp_stg_cmpl_lnk;
   CREATE TABLE tmp_stg_cmpl_lnk AS
   SELECT vw_lnk.ICS_CMPL_MON_LNK_ID
         ,vw_main.PERMIT_ID
         -- ,vw_main.INSPECTION_NUMBER
         ,vw_main.NUMBER
         ,vw_main.CATEGORY
         ,vw_main.BEGIN_DATE
         ,vw_main.VIOLATION_TYPE_CODE
         ,vw_main.VIOLATION_DATE
     FROM tmp_stg_cmpl_lnk_main vw_main
     LEFT OUTER JOIN 
        (SELECT UUID()  ICS_CMPL_MON_LNK_ID
               ,NUMBER
               ,CATEGORY
               ,BEGIN_DATE
           FROM (SELECT DISTINCT NUMBER
                       ,CATEGORY
                       ,BEGIN_DATE
                   FROM tmp_stg_cmpl_lnk_main) vw ) vw_lnk
       ON vw_lnk.NUMBER     = vw_main.NUMBER
      AND vw_lnk.CATEGORY   = vw_main.CATEGORY
      AND vw_lnk.BEGIN_DATE = vw_main.BEGIN_DATE;
   -- ----------------
   -- ics_cmpl_mon_lnk
   -- ----------------
   SET v_marker    = 'INSERT INTO ICS_CMPL_MON_LNK';
   SET v_tgt_tbl   = 'ICS_CMPL_MON_LNK';
   SET v_src_tbl   = 'tmp_stg_cmpl_lnk';
   SET v_startdtm2 = NOW();
   INSERT INTO ICS_CMPL_MON_LNK
      (ICS_CMPL_MON_LNK_ID
      ,ICS_PAYLOAD_ID
      ,PRMT_IDENT
      ,CMPL_MON_DATE
      ,CMPL_MON_CATG_CODE)
   SELECT DISTINCT ICS_CMPL_MON_LNK_ID
         ,'ComplianceMonitoringLinkageSubmission'
         ,NUMBER
         ,BEGIN_DATE
         ,CATEGORY
     FROM tmp_stg_cmpl_lnk
    WHERE ICS_CMPL_MON_LNK_ID IS NOT NULL;
   -- 
   SET v_rowcount = (SELECT ROW_COUNT());
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'INSERT'      -- pi_process
      ,v_rowcount);  -- pi_value
   -- ----------------
   -- ics_lnk_sngl_evt
   -- ----------------
   SET v_marker    = 'INSERT INTO ICS_LNK_SNGL_EVT';
   SET v_tgt_tbl   = 'ICS_LNK_SNGL_EVT';
   SET v_startdtm2 = NOW();
   SET v_src_tbl   = 'tmp_stg_cmpl_lnk';
   INSERT INTO ICS_LNK_SNGL_EVT
      (ICS_LNK_SNGL_EVT_ID
      ,ICS_CMPL_MON_LNK_ID
      ,PRMT_IDENT
      ,SNGL_EVT_VIOL_CODE
      ,SNGL_EVT_VIOL_DATE)
   SELECT UUID()
         ,ICS_CMPL_MON_LNK_ID
         ,NUMBER
         ,VIOLATION_TYPE_CODE
         ,VIOLATION_DATE
     FROM (SELECT DISTINCT ICS_CMPL_MON_LNK_ID
                 ,NUMBER
                 ,VIOLATION_TYPE_CODE -- SNGL_EVT_VIOL_CODE
                 ,VIOLATION_DATE -- SNGL_EVT_VIOL_DATE
             FROM tmp_stg_cmpl_lnk
            WHERE (NUMBER
                  ,VIOLATION_TYPE_CODE
                  ,VIOLATION_DATE) NOT IN (SELECT PRMT_IDENT
                                                 ,SNGL_EVT_VIOL_CODE
                                                 ,SNGL_EVT_VIOL_DATE
                                             FROM ICS_LNK_SNGL_EVT)
             ) vw;
   -- 
   SET v_rowcount = (SELECT ROW_COUNT());
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'INSERT'      -- pi_process
      ,v_rowcount);  -- pi_value
   -- -------------- --
   --  END PROCEDURE --
   -- -------------- --
   SET v_marker = 'CALL ics_etl_log_sp END';
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_sp_name     -- pi_marker
      ,NULL          -- pi_tgt_tbl
      ,NULL          -- pi_src_tbl 
      ,v_startdtm    -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'COMPLETED'   -- pi_process
      ,0);           -- pi_value
   --
   SET po_status = 1;
   SET po_errm   = '';
   --  
END
