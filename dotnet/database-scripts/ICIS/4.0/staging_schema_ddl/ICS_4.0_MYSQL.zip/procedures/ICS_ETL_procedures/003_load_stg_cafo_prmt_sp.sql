DROP PROCEDURE IF EXISTS ga_ics_flow_local.load_stg_cafo_prmt_sp;
CREATE PROCEDURE `load_stg_cafo_prmt_sp`
   (OUT po_status INT
   ,OUT po_errm   VARCHAR(255))
BEGIN
-- ============================================================================
-- MODIFICATION HISTORY
-- Person      Date       Comments
-- ---------   --------   -----------------------------------------------------
-- Jen Go      20120925   Created.  
--
-- ============================================================================
   DECLARE v_startdtm   DATETIME     DEFAULT NOW();
   DECLARE v_enddtm     DATETIME;
   DECLARE v_marker     VARCHAR(255);
   DECLARE v_sp_name    VARCHAR(64)  DEFAULT 'load_stg_cafo_prmt_sp';
   DECLARE v_tgt_tbl    
          ,v_src_tbl    VARCHAR(64);
   --
   DECLARE EXIT HANDLER FOR SQLEXCEPTION
      BEGIN  
         ROLLBACK;
         SET po_status = -1;
         SET po_errm   = v_marker;
         CALL ics_etl_log_sp    
            (v_sp_name          -- pi_sp_name
            ,v_marker           -- pi_marker
            ,v_tgt_tbl          -- pi_tgt_tbl
            ,v_src_tbl          -- pi_src_tbl
            ,v_startdtm         -- pi_startdtm
            ,NOW()              -- pi_enddtm
            ,'FAILED'           -- pi_process
            ,-1);               -- pi_value
      END;
   -- --------------------------------------
   -- tmp_stg_cafo_prmt_main (ics_cafo_prmt)
   -- --------------------------------------
   -- use temp tables but drop & recreate them
   -- can't use views because inline subqueries allowed in views
   -- can't use TEMPORARY tables because you can't join them with real tables.
   SET v_marker = 'DROP AND CREATE TABLE tmp_stg_cafo_prmt_main';
   -- SELECT v_marker; -- jentmp
   DROP TABLE IF EXISTS tmp_stg_cafo_prmt_main;
   CREATE TABLE tmp_stg_cafo_prmt_main AS
   SELECT stg.PERMIT_ID
         ,stg.PERMIT_ACTION_ID
         ,qr.QUESTION_CODE
         -- -------------
         -- ics_cafo_prmt
         -- -------------
         ,stg.PRMT_IDENT
         ,CASE WHEN qr.QUESTION_CODE = 'ICIS004' THEN
             rqtc.ICIS_CODE
          ELSE NULL END                 CAFO_CLASS_CODE
         --
         ,CASE WHEN qr.QUESTION_CODE = 'ICIS005' THEN
             qr.ANSWER_Y_N_NA
          ELSE NULL END                 IS_ANML_FAC_TYPE_CAFO_IND
         --
         ,CASE WHEN qr.QUESTION_CODE = 'ICIS006' THEN
             qr.ANSWER_DATE
          ELSE NULL END                 CAFO_DESGN_DATE     
         --
         ,CASE WHEN qr.QUESTION_CODE = 'ICIS007' THEN
             qr.ANSWER_COMMENT
          ELSE NULL END                 SOLID_MNUR_LTTR_GNRTD_AMT
         --
         ,CASE WHEN qr.QUESTION_CODE = 'ICIS008' THEN
             qr.ANSWER_COMMENT
          ELSE NULL END                 LIQUID_MNUR_WW_GNRTD_AMT
         --
         ,CASE WHEN qr.QUESTION_CODE = 'ICIS009' THEN
             qr.ANSWER_COMMENT
          ELSE NULL END                 SOLID_MNUR_LTTR_TRANS_AMT
         --
         ,CASE WHEN qr.QUESTION_CODE = 'ICIS010' THEN
             qr.ANSWER_COMMENT
          ELSE NULL END                 LIQUID_MNUR_WW_TRANS_AMT
         --
         ,CASE WHEN qr.QUESTION_CODE = 'ICIS011' THEN
             qr.ANSWER_DATE
          ELSE NULL END                 NMP_DVLPD_DATE
         -- ---------------------
         -- ics_addr; ics_contact
         -- ---------------------
         ,vw_addr_pc.AFFIL_TYPE_TXT
         ,vw_addr_pc.ORG_FRML_NAME
         ,vw_addr_pc.MAILING_ADDR_TXT
         ,vw_addr_pc.MAILING_ADDR_CITY_NAME
         ,vw_addr_pc.MAILING_ADDR_ST_CODE
         ,vw_addr_pc.MAILING_ADDR_ZIP_CODE
         ,vw_addr_pc.MAILING_ADDR_COUNTRY_CODE
         ,vw_addr_pc.FIRST_NAME
         ,vw_addr_pc.LAST_NAME
         ,vw_addr_pc.INDVL_TITLE_TXT
         ,vw_addr_pc.ELEC_ADDR_TXT
         -- -------------
         -- ics_anml_type
         -- -------------
         ,CASE WHEN qr.QUESTION_CODE = 'ICIS012' THEN
             rqtc.ICIS_CODE
          ELSE NULL END                 ANML_TYPE_CODE
         --
         ,CASE WHEN qr.QUESTION_CODE = 'ICIS013' THEN
             qr.ANSWER_COMMENT
          ELSE NULL END                 OTHR_ANML_TYPE_NAME
         --
         ,CASE WHEN qr.QUESTION_CODE = 'ICIS014' THEN
             qr.ANSWER_COMMENT
          ELSE NULL END                 TTL_NUM_EACH_LVSTCK
         -- ---------------
         -- ics_containment
         -- ---------------
         ,CASE WHEN qr.QUESTION_CODE = 'ICIS015' THEN
             rqtc.ICIS_CODE
          ELSE NULL END                 CONTAINMENT_TYPE_CODE
         --
         ,CASE WHEN qr.QUESTION_CODE = 'ICIS016' THEN
             qr.ANSWER_COMMENT
          ELSE NULL END                 OTHR_CONTAINMENT_TYPE_NAME
         --
         ,CASE WHEN qr.QUESTION_CODE = 'ICIS017' THEN
             qr.ANSWER_COMMENT
          ELSE NULL END                 CONTAINMENT_CPCTY_NUM
         -- ---------------------------
         -- ics_mnur_lttr_prcss_ww_stor
         -- ---------------------------
         ,CASE WHEN qr.QUESTION_CODE = 'ICIS018' THEN
             rqtc.ICIS_CODE
          ELSE NULL END                 MNUR_LTTR_PRCSS_WW_STOR_TYPE
         --
         ,CASE WHEN qr.QUESTION_CODE = 'ICIS019' THEN
             qr.ANSWER_COMMENT
          ELSE NULL END                 OTHR_STOR_TYPE_NAME
         --
         ,CASE WHEN qr.QUESTION_CODE = 'ICIS020' THEN
             qr.ANSWER_COMMENT
          ELSE NULL END                 STOR_TTL_CPCTY_MEAS
         --
         ,CASE WHEN qr.QUESTION_CODE = 'ICIS021' THEN
             qr.ANSWER_COMMENT
          ELSE NULL END                 DAYS_OF_STOR
     FROM stg_permit_main stg
     -- --------------------------------------------
     -- ics_cafo_prmt; ics_anml_type
     -- ics_containment; ics_mnur_lttr_prcss_ww_stor
     -- --------------------------------------------
     LEFT OUTER JOIN wrp.QUESTION_RESULT qr
       ON qr.PERMIT_ACTION_ID = stg.PERMIT_ACTION_ID
      AND qr.QUESTION_CODE IN (
                               -- ics_cafo_prmt
                               'ICIS004' 
                              ,'ICIS005'
                              ,'ICIS006'
                              ,'ICIS007'
                              ,'ICIS008'
                              ,'ICIS009'
                              ,'ICIS010'
                              ,'ICIS011'
                              -- ics_anml_type
                              ,'ICIS012' 
                              ,'ICIS013'
                              ,'ICIS014'
                              -- ics_containment
                              ,'ICIS015' 
                              ,'ICIS016'
                              ,'ICIS017'
                              -- ics_mnur_lttr_prcss_ww_stor
                              ,'ICIS018' 
                              ,'ICIS019'
                              ,'ICIS020'
                              ,'ICIS021'
                              )
     LEFT OUTER JOIN wrp.REF_QUESTION_TYPE_CHOICE rqtc
       ON rqtc.CODE = qr.ANSWER_CHOICE
     -- --------
     -- ics_addr
     -- --------
     LEFT OUTER JOIN
        (SELECT affl.AFFILIATION_ID
               ,affl.PERMIT_ACTION_ID
               ,rat.ICIS_REF_AFFILIATION_TYPE  AFFIL_TYPE_TXT
               ,org.NAME                       ORG_FRML_NAME
               ,addr_prsd.STREET_ADDRESS       MAILING_ADDR_TXT
               ,addr_prsd.LOCALITY             MAILING_ADDR_CITY_NAME
               ,addr_prsd.STATE_CODE           MAILING_ADDR_ST_CODE
               ,addr_prsd.POSTAL_CODE          MAILING_ADDR_ZIP_CODE
               ,addr_prsd.COUNTRY_CODE         MAILING_ADDR_COUNTRY_CODE
               ,prsn.FIRST_NAME                FIRST_NAME
               ,prsn.LAST_NAME                 LAST_NAME
               ,prsn.TITLE                     INDVL_TITLE_TXT
               ,pc.VALUE                       ELEC_ADDR_TXT
           FROM wrp.AFFILIATION affl
           JOIN wrp.REF_AFFILIATION_TYPE rat
             ON rat.CODE = affl.AFFILIATION_TYPE_CODE
           LEFT OUTER JOIN wrp.ORGANIZATION org
             ON org.ORGANIZATION_ID = affl.ORGANIZATION_ID
           LEFT OUTER JOIN wrp.ADDRESS addr
             ON addr.AFFILIATION_ID    = affl.AFFILIATION_ID
            AND addr.ADDRESS_TYPE_CODE = 'MAIL'
           LEFT OUTER JOIN wrp.ADDRESS_PARSED addr_prsd
             ON addr_prsd.ADDRESS_ID = addr.ADDRESS_ID
           LEFT OUTER JOIN wrp.PERSON prsn 
             ON prsn.PERSON_ID = affl.PERSON_ID
           LEFT OUTER JOIN wrp.PERSON_CONTACT pc
             ON pc.PERSON_CONTACT_ID = prsn.PERSON_ID
            AND pc.CONTACT_TYPE_CODE = 'EM'
          WHERE rat.ICIS_REF_AFFILIATION_TYPE IN ('CAI','CNC','COS','SOA') 
        ) vw_addr_pc
       ON vw_addr_pc.PERMIT_ACTION_ID = stg.PERMIT_ACTION_ID
    WHERE stg.PERMIT_TYPE_CODE = 'AFO';
   -- -----------------
   -- tmp_stg_cafo_prmt
   -- -----------------
   SET v_marker = 'DROP AND CREATE TABLE tmp_stg_cafo_prmt';
   DROP TABLE IF EXISTS tmp_stg_cafo_prmt;
   CREATE TABLE tmp_stg_cafo_prmt AS
   SELECT vw_main.PERMIT_ID                        PERMIT_ID
         ,vw_main.PERMIT_ACTION_ID                 PERMIT_ACTION_ID
         -- ,NULL -- ,vw_main.QUESTION_CODE
         ,vw_main.PRMT_IDENT                       PRMT_IDENT
         ,MAX(vw_main.CAFO_CLASS_CODE)             CAFO_CLASS_CODE
         ,MAX(vw_main.IS_ANML_FAC_TYPE_CAFO_IND)   IS_ANML_FAC_TYPE_CAFO_IND
         ,MAX(vw_main.CAFO_DESGN_DATE)             CAFO_DESGN_DATE
         ,MAX(vw_main.SOLID_MNUR_LTTR_GNRTD_AMT)   SOLID_MNUR_LTTR_GNRTD_AMT
         ,MAX(vw_main.LIQUID_MNUR_WW_GNRTD_AMT)    LIQUID_MNUR_WW_GNRTD_AMT
         ,MAX(vw_main.SOLID_MNUR_LTTR_TRANS_AMT)   SOLID_MNUR_LTTR_TRANS_AMT
         ,MAX(vw_main.LIQUID_MNUR_WW_TRANS_AMT)    LIQUID_MNUR_WW_TRANS_AMT
         ,MAX(vw_main.NMP_DVLPD_DATE)              NMP_DVLPD_DATE
         --
         ,vw_main.AFFIL_TYPE_TXT                   AFFIL_TYPE_TXT
         ,vw_main.ORG_FRML_NAME                    ORG_FRML_NAME
         ,vw_main.MAILING_ADDR_TXT                 MAILING_ADDR_TXT
         ,vw_main.MAILING_ADDR_CITY_NAME           MAILING_ADDR_CITY_NAME
         ,vw_main.MAILING_ADDR_ST_CODE             MAILING_ADDR_ST_CODE
         ,vw_main.MAILING_ADDR_ZIP_CODE            MAILING_ADDR_ZIP_CODE
         ,vw_main.MAILING_ADDR_COUNTRY_CODE        MAILING_ADDR_COUNTRY_CODE
         --
         ,MAX(vw_main.ANML_TYPE_CODE)              ANML_TYPE_CODE
         ,MAX(vw_main.OTHR_ANML_TYPE_NAME)         OTHR_ANML_TYPE_NAME
         ,MAX(vw_main.TTL_NUM_EACH_LVSTCK)         TTL_NUM_EACH_LVSTCK
         --
         ,vw_main.FIRST_NAME                       FIRST_NAME
         ,vw_main.LAST_NAME                        LAST_NAME
         ,vw_main.INDVL_TITLE_TXT                  INDVL_TITLE_TXT
         ,vw_main.ELEC_ADDR_TXT                    ELEC_ADDR_TXT
         --
         ,MAX(vw_main.CONTAINMENT_TYPE_CODE)       CONTAINMENT_TYPE_CODE
         ,MAX(vw_main.OTHR_CONTAINMENT_TYPE_NAME)  OTHR_CONTAINMENT_TYPE_NAME
         ,MAX(vw_main.CONTAINMENT_CPCTY_NUM)       CONTAINMENT_CPCTY_NUM
         --
         ,MAX(vw_main.MNUR_LTTR_PRCSS_WW_STOR_TYPE)  MNUR_LTTR_PRCSS_WW_STOR_TYPE
         ,MAX(vw_main.OTHR_STOR_TYPE_NAME)           OTHR_STOR_TYPE_NAME
         ,MAX(vw_main.STOR_TTL_CPCTY_MEAS)           STOR_TTL_CPCTY_MEAS
         ,MAX(vw_main.DAYS_OF_STOR)                  DAYS_OF_STOR
         --
         ,vw_cafo.ICS_CAFO_PRMT_ID                   ICS_CAFO_PRMT_ID
     FROM tmp_stg_cafo_prmt_main vw_main
     LEFT OUTER JOIN
        (SELECT UUID() ICS_CAFO_PRMT_ID
               ,PERMIT_ID
           FROM (SELECT DISTINCT PERMIT_ID
                   FROM tmp_stg_cafo_prmt_main) vw
        ) vw_cafo
      ON vw_cafo.PERMIT_ID = vw_main.PERMIT_ID;
   --
   SET v_marker = 'CALL ics_etl_log_sp END';
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_sp_name     -- pi_marker
      ,NULL          -- pi_tgt_tbl
      ,NULL          -- pi_src_tbl 
      ,v_startdtm    -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'COMPLETED'   -- pi_process
      ,0);           -- pi_value
   --
   SET po_status = 1;
   SET po_errm   = NULL;
   --
END   