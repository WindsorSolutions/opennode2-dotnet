DROP PROCEDURE IF EXISTS ga_ics_flow_local.load_ics_cmpl_related_sp;
CREATE PROCEDURE ga_ics_flow_local.`load_ics_cmpl_related_sp`(OUT po_status INT
   ,OUT po_errm   VARCHAR(255))
BEGIN
-- ============================================================================
-- MODIFICATION HISTORY
-- Person      Date       Comments
-- ---------   --------   -----------------------------------------------------
-- Jen Go      20120924   Created.  
--                        Populate the following tables:
--                           1)  ICS_COMPL
--                           2)  ICS_CMPL_INSP_TYPE
--                           3)  ICS_CMPL_MON_ACTN_REASON
--                           4)  ICS_CMPL_MON_AGNCY_TYPE
--                           5)  ICS_CSO_INSP
--                           6)  ICS_PRETR_INSP
--                           7)  ICS_SSO_INSP
--                           8)  ICS_SSO_STPS
--                           9)  ICS_SW_MS_4_INSP
--                           10) ICS_PROG
-- ============================================================================
   DECLARE v_startdtm   DATETIME     DEFAULT NOW();
   DECLARE v_startdtm2
          ,v_enddtm     DATETIME;
   DECLARE v_marker     VARCHAR(255);
   DECLARE v_sp_name    VARCHAR(64)  DEFAULT 'load_ics_cmpl_related_sp';
   DECLARE v_tgt_tbl    VARCHAR(64);
   DECLARE v_src_tbl    VARCHAR(64);
   DECLARE v_rowcount   INT          DEFAULT 0;
   --
   DECLARE EXIT HANDLER FOR SQLEXCEPTION
      BEGIN  
         ROLLBACK;
         SET po_status = -1;
         SET po_errm   = v_marker;
         CALL ics_etl_log_sp    
            (v_sp_name          -- pi_sp_name
            ,v_marker           -- pi_marker
            ,v_tgt_tbl          -- pi_tgt_tbl
            ,v_src_tbl          -- pi_src_tbl
            ,v_startdtm         -- pi_startdtm
            ,NOW()              -- pi_enddtm
            ,'FAILED'           -- pi_process
            ,-1);               -- pi_value
      END;
   -- --------------------
   -- tmp_load_stg_cmpl_sp
   -- --------------------
   -- create temp table instead of a view because views error out with 
   -- subqueries.
   SET v_marker  = 'DROP AND CREATE TABLE tmp_stg_cmpl_main ';
   -- SELECT v_marker; -- jentmp
   DROP TABLE IF EXISTS tmp_stg_cmpl_main;
   CREATE TABLE tmp_stg_cmpl_main AS
   SELECT PERMIT_ID
         ,PRMT_IDENT
         ,CMPL_MON_CATG_CODE
         ,BEGIN_DATE
         ,EPA_ASSIST_IND
         ,ST_FEDR_JOINT_IND
         ,JOINT_INSP_REASON_CODE
         ,ICIS_AGENCY_TYPE
         ,CMPL_MON_ACTN_REASON_CODE
         ,CMPL_INSP_TYPE_CODE
         -- ------------
         -- ics_cso_insp
         -- ------------
         ,MAX(CSO_CSO_EVT_DATE)                     CSO_CSO_EVT_DATE
         ,MAX(CSO_DRY_OR_WET_WEATHER_IND)           CSO_DRY_OR_WET_WEATHER_IND
         ,MAX(CSO_PRMT_FEATR_IDENT)                 CSO_PRMT_FEATR_IDENT
         ,MAX(CSO_LAT_MEAS)                         CSO_LAT_MEAS
         ,MAX(CSO_LONG_MEAS)                        CSO_LONG_MEAS
         ,MAX(CSO_CSO_OVRFLW_LOC_STREET)            CSO_CSO_OVRFLW_LOC_STREET
         ,MAX(CSO_DURATION_CSO_OVRFLW_EVT)          CSO_DURATION_CSO_OVRFLW_EVT
         ,MAX(CSO_DSCH_VOL_TREATED)                 CSO_DSCH_VOL_TREATED
         ,MAX(CSO_DSCH_VOL_UNTREATED)               CSO_DSCH_VOL_UNTREATED
         ,MAX(CSO_CORR_ACTN_TAKEN_DESC_TXT)         CSO_CORR_ACTN_TAKEN_DESC_TXT
         ,MAX(CSO_INCHES_PRECIP)                    CSO_INCHES_PRECIP
         -- --------------
         -- ics_pretr_insp
         -- --------------
         ,MAX(PRETR_SUO_REF)                         PRETR_SUO_REF
         ,MAX(PRETR_SUO_DATE)                        PRETR_SUO_DATE
         ,MAX(PRETR_ACCEPTANCE_HAZ_WASTE)            PRETR_ACCEPTANCE_HAZ_WASTE
         ,MAX(PRETR_ACCEPTANCE_NON_HAZ_INDST_WASTE)  PRETR_ACCEPTANCE_NON_HAZ_INDST_WASTE
         ,MAX(PRETR_ACCEPTANCE_HULED_DOMSTIC_WSTES)  PRETR_ACCEPTANCE_HULED_DOMSTIC_WSTES
         ,MAX(PRETR_ANNUL_PRETR_BUDGET)              PRETR_ANNUL_PRETR_BUDGET
         ,MAX(PRETR_INADEQUACY_SMPL_INSP_IND)        PRETR_INADEQUACY_SMPL_INSP_IND
         ,MAX(PRETR_ADEQUACY_PRETR_RESOURCES)        PRETR_ADEQUACY_PRETR_RESOURCES
         ,MAX(PRETR_DFCNC_IDNTFD_DRNG_IU_FILE_RVIW)  PRETR_DFCNC_IDNTFD_DRNG_IU_FILE_RVIW
         ,MAX(PRETR_CONTROL_MECH_DFCNC)              PRETR_CONTROL_MECH_DFCNC
         ,MAX(PRETR_LEGAL_AUTH_DFCNC)                PRETR_LEGAL_AUTH_DFCNC
         ,MAX(PRETR_DFCNC_INTRPRT_APPL_PRETR_STNDR)  PRETR_DFCNC_INTRPRT_APPL_PRETR_STNDR
         ,MAX(PRETR_DFCNC_DAT_MGMT_PBLC_PRTICIPTON)  PRETR_DFCNC_DAT_MGMT_PBLC_PRTICIPTON
         ,MAX(PRETR_VIOL_IU_SCHD_RMD_MSR)            PRETR_VIOL_IU_SCHD_RMD_MSR
         ,MAX(PRETR_FRML_RSPN_VIOL_IU_SCHD_RMD_MSR)  PRETR_FRML_RSPN_VIOL_IU_SCHD_RMD_MSR
         ,MAX(PRETR_ANNUL_FREQ_INFLUNT_TOXCNT_SMPL)  PRETR_ANNUL_FREQ_INFLUNT_TOXCNT_SMPL
         ,MAX(PRETR_ANNUL_FREQ_EFFLU_TOXCNT_SMPL)    PRETR_ANNUL_FREQ_EFFLU_TOXCNT_SMPL
         ,MAX(PRETR_ANNUL_FREQ_SLDG_TOXCNT_SMPL)     PRETR_ANNUL_FREQ_SLDG_TOXCNT_SMPL
         
         ,MAX(PRETR_SI_US_SNC_WITH_PRETR_SCHD)       PRETR_SI_US_SNC_WITH_PRETR_SCHD
         ,MAX(PRETR_SI_US_SNC_PUBL_NEWSPAPER)        PRETR_SI_US_SNC_PUBL_NEWSPAPER
         ,MAX(PRETR_VIOL_NOTICES_ISSUED_SI_US)       PRETR_VIOL_NOTICES_ISSUED_SI_US
         ,MAX(PRETR_ADMIN_ORDERS_ISSUED_SI_US)       PRETR_ADMIN_ORDERS_ISSUED_SI_US
         ,MAX(PRETR_CIVIL_SUTS_FILD_AGINST_SI_US)    PRETR_CIVIL_SUTS_FILD_AGINST_SI_US
         ,MAX(PRETR_CRIMINL_SUTS_FILD_AGINST_SI_US)  PRETR_CRIMINL_SUTS_FILD_AGINST_SI_US
         ,MAX(PRETR_DOLLAR_AMT_PNLTY_COLL)           PRETR_DOLLAR_AMT_PNLTY_COLL
         ,MAX(PRETR_I_US_WHC_PNLTY_HAV_BEE_COLL)     PRETR_I_US_WHC_PNLTY_HAV_BEE_COLL
         
         
         ,MAX(PRETR_NUM_SI_US)                       PRETR_NUM_SI_US
         ,MAX(PRETR_SI_US_WITHOUT_CONTROL_MECH)      PRETR_SI_US_WITHOUT_CONTROL_MECH
         ,MAX(PRETR_SI_US_NOT_INSPECTED)             PRETR_SI_US_NOT_INSPECTED
         ,MAX(PRETR_SI_US_NOT_SMPL)                  PRETR_SI_US_NOT_SMPL
         ,MAX(PRETR_SI_US_ON_SCHD)                   PRETR_SI_US_ON_SCHD
         ,MAX(PRETR_SI_US_SNC_WITH_PRETR_STNDR)      PRETR_SI_US_SNC_WITH_PRETR_STNDR
         ,MAX(PRETR_SI_US_SNC_WITH_REP_REQS)         PRETR_SI_US_SNC_WITH_REP_REQS
         ,MAX(PRETR_NUM_CI_US)                       PRETR_NUM_CI_US
         ,MAX(PRETR_PASS_THROUGH_INTERFERENCE_IND)   PRETR_PASS_THROUGH_INTERFERENCE_IND 
         
         ,MAX(PRETR_CI_US_IN_SNC)                    PRETR_CI_US_IN_SNC
         -- --------
         -- ics_prog
         -- --------
         ,PROG_CODE
         -- ------------
         -- ics_sso_insp
         -- ------------
         ,MAX(SSO_SSO_EVT_DATE)                      SSO_SSO_EVT_DATE
         ,MAX(SSO_CAUSE_SSO_OVRFLW_EVT)              SSO_CAUSE_SSO_OVRFLW_EVT
         ,MAX(SSO_LAT_MEAS)                          SSO_LAT_MEAS
         ,MAX(SSO_LONG_MEAS)                         SSO_LONG_MEAS
         ,MAX(SSO_SSO_OVRFLW_LOC_STREET)             SSO_SSO_OVRFLW_LOC_STREET
         ,MAX(SSO_DURATION_SSO_OVRFLW_EVT)           SSO_DURATION_SSO_OVRFLW_EVT
         ,MAX(SSO_SSO_VOL)                           SSO_SSO_VOL
         ,MAX(SSO_NAME_RCVG_WTR)                     SSO_NAME_RCVG_WTR
         ,MAX(SSO_DESC_STPS_TAKEN)                   SSO_DESC_STPS_TAKEN
         -- ------------
         -- ics_sso_stps
         -- ------------
         ,MAX(STPS_RDUCE_PREVNT_MITIGTE)             STPS_RDUCE_PREVNT_MITIGTE
         ,MAX(OTHR_STPS_RDUCE_PREVNT_MITIGTE)        OTHR_STPS_RDUCE_PREVNT_MITIGTE
         -- ----------------
         -- ics_sw_ms_4_insp
         -- ----------------
         ,MAX(MS_4_ANNUL_EXPEN_DOLLARS)              MS_4_ANNUL_EXPEN_DOLLARS
         ,MAX(MS_4_ANNUL_EXPEN_YEAR)                 MS_4_ANNUL_EXPEN_YEAR
         ,MAX(MS_4_BUDGET_DOLLARS)                   MS_4_BUDGET_DOLLARS
         ,MAX(MS_4_BUDGET_YEAR)                      MS_4_BUDGET_YEAR
         ,MAX(MAJOR_OUTFALL_EST_MEAS_IND)            MAJOR_OUTFALL_EST_MEAS_IND
         ,MAX(MAJOR_OUTFALL_NUM)                     MAJOR_OUTFALL_NUM
         ,MAX(MINOR_OUTFALL_EST_MEAS_IND)            MINOR_OUTFALL_EST_MEAS_IND
         ,MAX(MINOR_OUTFALL_NUM)                     MINOR_OUTFALL_NUM
         -- ------------------
         -- ics_proj_srcs_fund
         -- ------------------
         ,MAX(PROJ_SRCS_FUND_CODE)                   PROJ_SRCS_FUND_CODE
     FROM (SELECT pmt.PERMIT_ID                                   PERMIT_ID
                 -- --------------------------------------
                 -- ics_cmpl_mon; ics_cmpl_mon_actn_reason
                 -- --------------------------------------
                 ,pmt.NUMBER                                      PRMT_IDENT
                 ,r_inspctn.COMP_MON_CAT                          CMPL_MON_CATG_CODE
                 -- CMPL_MON_DATE, CMPL_MON_START_DATE
                 ,insp.BEGIN_DATE                                 BEGIN_DATE
                 ,r_inspctr.ICIS_EPA_ASSIST_IND                   EPA_ASSIST_IND
                 ,r_inspctr.ICIS_JOINT_INSPECTION_LEAD_PARTY      ST_FEDR_JOINT_IND
                 ,r_inspctr.ICIS_JOINT_INSPECTION_PURPOSE_CODE    JOINT_INSP_REASON_CODE
                 -- LEAD_PARTY; CMPL_MON_AGNCY_TYPE_CODE
                 ,r_inspctr.ICIS_AGENCY_TYPE                      ICIS_AGENCY_TYPE
                 -- 
                 ,rirt.ICIS_REF_ACTIVITY_PURPOSE                  CMPL_MON_ACTN_REASON_CODE
                 -- ------------
                 -- ics_cso_insp
                 -- ------------
                 ,CASE WHEN qr.QUESTION_CODE =  'ICIS_CM001' THEN
                     qr.ANSWER_DATE
                  ELSE NULL END                                   CSO_CSO_EVT_DATE
                 ,CASE WHEN qr.QUESTION_CODE =  'ICIS_CM002' THEN
                     qr.ANSWER_CHOICE
                  ELSE NULL END                                   CSO_DRY_OR_WET_WEATHER_IND
                 ,CASE WHEN qr.QUESTION_CODE =  'ICIS_CM003' THEN
                     qr.ANSWER_COMMENT
                  ELSE NULL END                                   CSO_PRMT_FEATR_IDENT
                 ,CASE WHEN qr.QUESTION_CODE =  'ICIS_CM004' THEN
                     qr.ANSWER_COMMENT
                  ELSE NULL END                                   CSO_LAT_MEAS
                 ,CASE WHEN qr.QUESTION_CODE =  'ICIS_CM005' THEN
                     qr.ANSWER_COMMENT
                  ELSE NULL END                                   CSO_LONG_MEAS
                 ,CASE WHEN qr.QUESTION_CODE =  'ICIS_CM006' THEN
                     qr.ANSWER_COMMENT
                  ELSE NULL END                                   CSO_CSO_OVRFLW_LOC_STREET
                 ,CASE WHEN qr.QUESTION_CODE =  'ICIS_CM007' THEN
                     qr.ANSWER_COMMENT
                  ELSE NULL END                                   CSO_DURATION_CSO_OVRFLW_EVT
                 ,CASE WHEN qr.QUESTION_CODE =  'ICIS_CM008' THEN
                     qr.ANSWER_COMMENT
                  ELSE NULL END                                   CSO_DSCH_VOL_TREATED
                 ,CASE WHEN qr.QUESTION_CODE =  'ICIS_CM009' THEN
                     qr.ANSWER_COMMENT
                  ELSE NULL END                                   CSO_DSCH_VOL_UNTREATED
                 ,CASE WHEN qr.QUESTION_CODE =  'ICIS_CM010' THEN
                     qr.ANSWER_COMMENT
                  ELSE NULL END                                   CSO_CORR_ACTN_TAKEN_DESC_TXT
                 ,CASE WHEN qr.QUESTION_CODE =  'ICIS_CM011' THEN
                     qr.ANSWER_COMMENT
                  ELSE NULL END                                   CSO_INCHES_PRECIP
                 -- ------------------
                 -- ics_cmpl_insp_type
                 -- ------------------
                 ,r_inspctn.COMP_ACT_TYPE                         CMPL_INSP_TYPE_CODE
                 -- ------------------------
                 -- ics_pretr_insp
                 -- ------------------------
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS_CM012' THEN
                     qr.ANSWER_COMMENT
                  ELSE NULL END                                  PRETR_SUO_REF
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS_CM013' THEN
                     qr.ANSWER_DATE
                  ELSE NULL END                                  PRETR_SUO_DATE
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS_CM014' THEN
                     qr.ANSWER_Y_N_NA
                  ELSE NULL END                                  PRETR_ACCEPTANCE_HAZ_WASTE
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS_CM015' THEN
                     qr.ANSWER_Y_N_NA
                  ELSE NULL END                                  PRETR_ACCEPTANCE_NON_HAZ_INDST_WASTE
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS_CM016' THEN
                     qr.ANSWER_Y_N_NA
                  ELSE NULL END                                  PRETR_ACCEPTANCE_HULED_DOMSTIC_WSTES
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS_CM017' THEN
                     qr.ANSWER_COMMENT
                  ELSE NULL END                                  PRETR_ANNUL_PRETR_BUDGET
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS_CM018' THEN
                     qr.ANSWER_Y_N_NA
                  ELSE NULL END                                  PRETR_INADEQUACY_SMPL_INSP_IND
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS_CM019' THEN
                     qr.ANSWER_COMMENT
                  ELSE NULL END                                  PRETR_ADEQUACY_PRETR_RESOURCES
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS_CM020' THEN
                     qr.ANSWER_Y_N_NA
                  ELSE NULL END                                  PRETR_DFCNC_IDNTFD_DRNG_IU_FILE_RVIW
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS_CM021' THEN
                     qr.ANSWER_Y_N_NA
                  ELSE NULL END                                  PRETR_CONTROL_MECH_DFCNC
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS_CM022' THEN
                     qr.ANSWER_Y_N_NA
                  ELSE NULL END                                  PRETR_LEGAL_AUTH_DFCNC
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS_CM023' THEN
                     qr.ANSWER_Y_N_NA
                  ELSE NULL END                                  PRETR_DFCNC_INTRPRT_APPL_PRETR_STNDR
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS_CM024' THEN
                     qr.ANSWER_Y_N_NA
                  ELSE NULL END                                  PRETR_DFCNC_DAT_MGMT_PBLC_PRTICIPTON
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS_CM025' THEN
                     qr.ANSWER_Y_N_NA
                  ELSE NULL END                                  PRETR_VIOL_IU_SCHD_RMD_MSR
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS_CM026' THEN
                     qr.ANSWER_Y_N_NA
                  ELSE NULL END                                  PRETR_FRML_RSPN_VIOL_IU_SCHD_RMD_MSR
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS_CM027' THEN
                     qr.ANSWER_COMMENT
                  ELSE NULL END                                  PRETR_ANNUL_FREQ_INFLUNT_TOXCNT_SMPL
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS_CM028' THEN
                     qr.ANSWER_COMMENT
                  ELSE NULL END                                  PRETR_ANNUL_FREQ_EFFLU_TOXCNT_SMPL
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS_CM029' THEN
                     qr.ANSWER_COMMENT
                  ELSE NULL END                                  PRETR_ANNUL_FREQ_SLDG_TOXCNT_SMPL
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS027' THEN
                     qr.ANSWER_COMMENT
                  ELSE NULL END                                  PRETR_NUM_SI_US
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS028' THEN
                     qr.ANSWER_COMMENT
                  ELSE NULL END                                  PRETR_SI_US_WITHOUT_CONTROL_MECH
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS029' THEN
                     qr.ANSWER_COMMENT
                  ELSE NULL END                                  PRETR_SI_US_NOT_INSPECTED
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS030' THEN
                     qr.ANSWER_COMMENT
                  ELSE NULL END                                  PRETR_SI_US_NOT_SMPL
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS031' THEN
                     qr.ANSWER_COMMENT
                  ELSE NULL END                                  PRETR_SI_US_ON_SCHD
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS032' THEN
                     qr.ANSWER_COMMENT
                  ELSE NULL END                                  PRETR_SI_US_SNC_WITH_PRETR_STNDR
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS033' THEN
                     qr.ANSWER_COMMENT
                  ELSE NULL END                                  PRETR_SI_US_SNC_WITH_REP_REQS
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS_CM037' THEN
                     qr.ANSWER_COMMENT
                  ELSE NULL END                                  PRETR_SI_US_SNC_WITH_PRETR_SCHD
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS_CM038' THEN
                     qr.ANSWER_COMMENT
                  ELSE NULL END                                  PRETR_SI_US_SNC_PUBL_NEWSPAPER
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS_CM039' THEN
                     qr.ANSWER_COMMENT
                  ELSE NULL END                                  PRETR_VIOL_NOTICES_ISSUED_SI_US
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS_CM040' THEN
                     qr.ANSWER_COMMENT
                  ELSE NULL END                                  PRETR_ADMIN_ORDERS_ISSUED_SI_US
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS_CM041' THEN
                     qr.ANSWER_COMMENT
                  ELSE NULL END                                  PRETR_CIVIL_SUTS_FILD_AGINST_SI_US
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS_CM042' THEN
                     qr.ANSWER_COMMENT
                  ELSE NULL END                                  PRETR_CRIMINL_SUTS_FILD_AGINST_SI_US
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS_CM043' THEN
                     qr.ANSWER_COMMENT
                  ELSE NULL END                                  PRETR_DOLLAR_AMT_PNLTY_COLL
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS_CM044' THEN
                     qr.ANSWER_COMMENT
                  ELSE NULL END                                  PRETR_I_US_WHC_PNLTY_HAV_BEE_COLL
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS034' THEN
                     qr.ANSWER_COMMENT
                  ELSE NULL END                                  PRETR_NUM_CI_US
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS035' THEN
                     qr.ANSWER_Y_N_NA
                  ELSE NULL END                                  PRETR_PASS_THROUGH_INTERFERENCE_IND
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS_CM046' THEN
                     qr.ANSWER_COMMENT
                  ELSE NULL END                                  PRETR_CI_US_IN_SNC
                 -- ------------
                 -- ics_sso_insp
                 -- ------------
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS049' THEN
                     qr.ANSWER_DATE
                  ELSE NULL END                                  SSO_SSO_EVT_DATE
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS050' THEN
                     qr.ANSWER_COMMENT
                  ELSE NULL END                                  SSO_CAUSE_SSO_OVRFLW_EVT
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS051' THEN
                     qr.ANSWER_COMMENT
                  ELSE NULL END                                  SSO_LAT_MEAS
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS052' THEN
                     qr.ANSWER_COMMENT
                  ELSE NULL END                                  SSO_LONG_MEAS
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS053' THEN
                     qr.ANSWER_COMMENT
                  ELSE NULL END                                  SSO_SSO_OVRFLW_LOC_STREET
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS054' THEN
                     qr.ANSWER_COMMENT
                  ELSE NULL END                                  SSO_DURATION_SSO_OVRFLW_EVT
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS055' THEN
                     qr.ANSWER_COMMENT
                  ELSE NULL END                                  SSO_SSO_VOL
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS056' THEN
                     qr.ANSWER_COMMENT
                  ELSE NULL END                                  SSO_NAME_RCVG_WTR
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS057' THEN
                     qr.ANSWER_COMMENT
                  ELSE NULL END                                  SSO_DESC_STPS_TAKEN
                 -- ------------
                 -- ics_sso_stps
                 -- ------------
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS059' THEN
                     rqtc.ICIS_CODE
                  ELSE NULL END                                  STPS_RDUCE_PREVNT_MITIGTE
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS060' THEN
                     qr.ANSWER_COMMENT
                  ELSE NULL END                                  OTHR_STPS_RDUCE_PREVNT_MITIGTE
                 -- --------
                 -- ics_prog
                 -- --------
                 ,ip.PROGRAM_CODE                                PROG_CODE
                 -- ----------------
                 -- ics_sw_ms_4_insp
                 -- ----------------
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS083' THEN
                     qr.ANSWER_COMMENT
                  ELSE NULL END                                  MS_4_ANNUL_EXPEN_DOLLARS
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS084' THEN
                     qr.ANSWER_COMMENT
                  ELSE NULL END                                  MS_4_ANNUL_EXPEN_YEAR
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS085' THEN
                     qr.ANSWER_COMMENT
                  ELSE NULL END                                  MS_4_BUDGET_DOLLARS
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS086' THEN
                     qr.ANSWER_COMMENT
                  ELSE NULL END                                  MS_4_BUDGET_YEAR
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS087' THEN
                     rqtc.ICIS_CODE
                  ELSE NULL END                                  MAJOR_OUTFALL_EST_MEAS_IND
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS088' THEN
                     qr.ANSWER_COMMENT
                  ELSE NULL END                                  MAJOR_OUTFALL_NUM
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS089' THEN
                     rqtc.ICIS_CODE
                  ELSE NULL END                                  MINOR_OUTFALL_EST_MEAS_IND
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS090' THEN
                     qr.ANSWER_COMMENT
                  ELSE NULL END                                  MINOR_OUTFALL_NUM
                 -- ------------------
                 -- ics_proj_srcs_fund
                 -- ------------------
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS091' THEN
                     rqtc.ICIS_CODE
                  ELSE NULL END                                  PROJ_SRCS_FUND_CODE
             FROM wrp.INSPECTION insp
             JOIN wrp.PERMIT pmt
               ON pmt.PERMIT_ID = insp.PERMIT_ID
             LEFT OUTER JOIN wrp.REF_INSPECTION_TYPE r_inspctn
               ON r_inspctn.CODE = insp.INSPECTION_TYPE_CODE
             LEFT OUTER JOIN wrp.REF_INSPECTOR_TYPE r_inspctr
               ON r_inspctr.CODE = insp.INSPECTOR_TYPE_CODE
             LEFT OUTER JOIN wrp.REF_INSPECTION_REASON_TYPE rirt
               ON rirt.CODE = insp.INSPECTION_REASON_TYPE_CODE
             LEFT OUTER JOIN wrp.QUESTION_RESULT qr
               ON qr.INSPECTION_ID = insp.INSPECTION_ID
              AND qr.QUESTION_CODE IN (
                                       -- ics_cso_insp
                                       'ICIS_CM001','ICIS_CM002'
                                      ,'ICIS_CM003','ICIS_CM004'
                                      ,'ICIS_CM005','ICIS_CM006'
                                      ,'ICIS_CM007','ICIS_CM008'
                                      ,'ICIS_CM009','ICIS_CM010'
                                      ,'ICIS_CM011'
                                      -- ics_pretr_insp
                                      ,'ICIS_CM012','ICIS_CM013'
                                      ,'ICIS_CM014','ICIS_CM015'
                                      ,'ICIS_CM016','ICIS_CM017'
                                      ,'ICIS_CM018','ICIS_CM019'
                                      ,'ICIS_CM020','ICIS_CM021'
                                      ,'ICIS_CM022','ICIS_CM023'
                                      ,'ICIS_CM024','ICIS_CM025'
                                      ,'ICIS_CM026','ICIS_CM027'
                                      ,'ICIS_CM028','ICIS_CM029'
                                      ,'ICIS027','ICIS028'
                                      ,'ICIS029','ICIS030'
                                      ,'ICIS031','ICIS032'
                                      ,'ICIS033','ICIS034'
                                      ,'ICIS035'
                                      ,'ICIS_CM037','ICIS_CM038'
                                      ,'ICIS_CM039','ICIS_CM040'
                                      ,'ICIS_CM041','ICIS_CM042'
                                      ,'ICIS_CM043','ICIS_CM044'
                                      ,'ICIS_CM046'
                                      -- ics_sso_insp
                                      ,'ICIS_CM049','ICIS_CM050'
                                      ,'ICIS_CM051','ICIS_CM052'
                                      ,'ICIS_CM053','ICIS_CM054'
                                      ,'ICIS_CM055','ICIS_CM056'
                                      ,'ICIS_CM057','ICIS_CM058'
                                      ,'ICIS_CM059','ICIS_CM060'
                                      ,'ICIS_CM061','ICIS_CM062'
                                      -- ics_sso_stps
                                      ,'ICIS_CM059','ICIS_CM060'
                                      -- ics_sw_ms_4_insp
                                      ,'ICIS_CM083','ICIS_CM084'
                                      ,'ICIS_CM085','ICIS_CM086'
                                      ,'ICIS_CM087','ICIS_CM088'
                                      ,'ICIS_CM089','ICIS_CM090'
                                      -- ics_prpj_srcs_fund
                                      ,'ICIS_CM091'
                                      )
             LEFT OUTER JOIN wrp.INSPECTION_PROGRAM ip
               ON ip.INSPECTION_ID = insp.INSPECTION_ID
             LEFT OUTER JOIN wrp.REF_QUESTION_TYPE_CHOICE rqtc
               ON rqtc.CODE = qr.ANSWER_CHOICE
            WHERE insp.BEGIN_DATE IS NOT NULL) vw
    GROUP BY PERMIT_ID
            ,PRMT_IDENT
            ,CMPL_MON_CATG_CODE
            ,BEGIN_DATE
            ,EPA_ASSIST_IND
            ,ST_FEDR_JOINT_IND
            ,JOINT_INSP_REASON_CODE
            ,ICIS_AGENCY_TYPE
            ,CMPL_MON_ACTN_REASON_CODE
            ,CMPL_INSP_TYPE_CODE
            ,PROG_CODE;
   -- -------------
   -- stg_cmpl_main
   -- -------------
   SET v_tgt_tbl = 'stg_cmpl_main';
   SET v_marker  = 'DROP AND CREATE TEMPORARY TABLE tmp_stg_cmpl_main';
   -- SELECT v_marker; -- jentmp
   DROP TABLE IF EXISTS tmp_stg_cmpl;
   CREATE TABLE tmp_stg_cmpl AS
   SELECT vw_cmpl.ICS_CMPL_MON_ID
         ,vw_main.*
     FROM tmp_stg_cmpl_main vw_main
     LEFT OUTER JOIN
        (SELECT UUID()  ICS_CMPL_MON_ID
               ,PRMT_IDENT
               ,CMPL_MON_CATG_CODE
               ,BEGIN_DATE
              -- ,ICIS_AGENCY_TYPE
           FROM (SELECT DISTINCT PRMT_IDENT
                       ,CMPL_MON_CATG_CODE
                       ,BEGIN_DATE
                       -- ,ICIS_AGENCY_TYPE
                   FROM tmp_stg_cmpl_main
                  WHERE PRMT_IDENT         IS NOT NULL
                    AND CMPL_MON_CATG_CODE IS NOT NULL
                    AND BEGIN_DATE         IS NOT NULL) vw
        ) vw_cmpl
       ON vw_cmpl.PRMT_IDENT                     = vw_main.PRMT_IDENT
      AND vw_cmpl.CMPL_MON_CATG_CODE             = vw_main.CMPL_MON_CATG_CODE
      AND vw_cmpl.BEGIN_DATE                     = vw_main.BEGIN_DATE
      -- AND COALESCE(vw_cmpl.ICIS_AGENCY_TYPE,'X') = COALESCE(vw_main.ICIS_AGENCY_TYPE,'X')
      ;
   -- ---------
   -- ics_compl
   -- ---------
   SET v_marker    = 'INSERT INTO ICS_COMPL';
   SET v_startdtm2 = NOW();
   SET v_tgt_tbl   = 'ICS_COMPL';
   SET v_src_tbl   = 'tmp_stg_cmpl';
   INSERT INTO ICS_CMPL_MON
      (ICS_CMPL_MON_ID
      ,ICS_PAYLOAD_ID
      ,PRMT_IDENT
      ,CMPL_MON_CATG_CODE
      ,CMPL_MON_DATE
      ,CMPL_MON_START_DATE
      ,EPA_ASSIST_IND
      ,ST_FEDR_JOINT_IND
      ,JOINT_INSP_REASON_CODE
      -- ,LEAD_PARTY
      )
   SELECT DISTINCT ICS_CMPL_MON_ID
         ,'ComplianceMonitoring'
         ,PRMT_IDENT
         ,CMPL_MON_CATG_CODE
         ,BEGIN_DATE
         ,BEGIN_DATE
         ,EPA_ASSIST_IND
         ,ST_FEDR_JOINT_IND
         ,JOINT_INSP_REASON_CODE
         -- ,ICIS_AGENCY_TYPE
     FROM tmp_stg_cmpl
    WHERE ICS_CMPL_MON_ID IS NOT NULL;
   --
   SET v_rowcount = (SELECT ROW_COUNT());
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'INSERT'      -- pi_process
      ,v_rowcount);  -- pi_value
   -- ------------------
   -- ics_cmpl_insp_type
   -- ------------------
   SET v_marker    = 'INSERT INTO ICS_CMPL_INSP_TYPE';
   SET v_startdtm2 = NOW();
   SET v_tgt_tbl   = 'ICS_CMPL_INSP_TYPE';
   SET v_src_tbl   = 'tmp_stg_cmpl';
   INSERT INTO ICS_CMPL_INSP_TYPE
      (ICS_CMPL_INSP_TYPE_ID
      ,ICS_CMPL_MON_ID
      ,CMPL_INSP_TYPE_CODE)
   SELECT UUID()
         ,ICS_CMPL_MON_ID
         ,CMPL_INSP_TYPE_CODE
    FROM (SELECT DISTINCT CMPL_INSP_TYPE_CODE
                ,ICS_CMPL_MON_ID
            FROM tmp_stg_cmpl
           WHERE ICS_CMPL_MON_ID IS NOT NULL) vw;
   -- 
   SET v_rowcount = (SELECT ROW_COUNT());
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'INSERT'      -- pi_process
      ,v_rowcount);  -- pi_value
   -- ------------------------
   -- ics_cmpl_mon_actn_reason
   -- ------------------------
   SET v_marker    = 'INSERT INTO ICS_CMPL_MON_ACTN_REASON';
   SET v_startdtm2 = NOW();
   SET v_tgt_tbl   = 'ICS_CMPL_MON_ACTN_REASON';
   SET v_src_tbl   = 'tmp_stg_cmpl';
   INSERT INTO ICS_CMPL_MON_ACTN_REASON
      (ICS_CMPL_MON_ACTN_REASON_ID
      ,ICS_CMPL_MON_ID
      ,CMPL_MON_ACTN_REASON_CODE)
   SELECT UUID()
         ,ICS_CMPL_MON_ID
         ,CMPL_MON_ACTN_REASON_CODE
     FROM (SELECT DISTINCT CMPL_MON_ACTN_REASON_CODE
                 ,ICS_CMPL_MON_ID
             FROM tmp_stg_cmpl
            WHERE CMPL_MON_ACTN_REASON_CODE IS NOT NULL 
              AND ICS_CMPL_MON_ID           IS NOT NULL
          ) vw;
   -- 
   SET v_rowcount = (SELECT ROW_COUNT());
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'INSERT'      -- pi_process
      ,v_rowcount);  -- pi_value
   -- -----------------------
   -- ics_cmpl_mon_agncy_type
   -- ------------------------
   SET v_marker    = 'INSERT INTO ICS_CMPL_MON_AGNCY_TYPE';
   SET v_startdtm2 = NOW();
   SET v_tgt_tbl   = 'ICS_CMPL_MON_AGNCY_TYPE';
   SET v_src_tbl   = 'tmp_stg_cmpl';
   INSERT INTO ICS_CMPL_MON_AGNCY_TYPE
      (ICS_CMPL_MON_AGNCY_TYPE_ID
      ,ICS_CMPL_MON_ID
      ,CMPL_MON_AGNCY_TYPE_CODE)
   SELECT UUID()
         ,ICS_CMPL_MON_ID
         ,ICIS_AGENCY_TYPE
     FROM (SELECT DISTINCT ICIS_AGENCY_TYPE
                 ,ICS_CMPL_MON_ID
             FROM tmp_stg_cmpl
            WHERE ICIS_AGENCY_TYPE IS NOT NULL
              AND ICS_CMPL_MON_ID  IS NOT NULL) vw;
   -- 
   SET v_rowcount = (SELECT ROW_COUNT());
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'INSERT'      -- pi_process
      ,v_rowcount);  -- pi_value
   -- ------------
   -- ics_cso_insp
   -- ------------
   SET v_marker    = 'INSERT INTO ICS_CSO_INSP';
   SET v_startdtm2 = NOW();
   SET v_tgt_tbl   = 'ICS_CSO_INSP';
   SET v_src_tbl   = 'tmp_stg_cmpl';
   INSERT INTO ICS_CSO_INSP
      (ICS_CSO_INSP_ID
      ,ICS_CMPL_MON_ID
      ,CSO_EVT_DATE
      ,DRY_OR_WET_WEATHER_IND
      ,PRMT_FEATR_IDENT
      ,LAT_MEAS
      ,LONG_MEAS
      ,CSO_OVRFLW_LOC_STREET
      ,DURATION_CSO_OVRFLW_EVT
      ,DSCH_VOL_TREATED
      ,DSCH_VOL_UNTREATED
      ,CORR_ACTN_TAKEN_DESC_TXT
      ,INCHES_PRECIP)
   SELECT UUID()
         ,vw.*
     FROM (SELECT DISTINCT ICS_CMPL_MON_ID
                 ,CSO_CSO_EVT_DATE
                 ,CSO_DRY_OR_WET_WEATHER_IND
                 ,CSO_PRMT_FEATR_IDENT
                 ,CSO_LAT_MEAS
                 ,CSO_LONG_MEAS
                 ,CSO_CSO_OVRFLW_LOC_STREET
                 ,CSO_DURATION_CSO_OVRFLW_EVT
                 ,CSO_DSCH_VOL_TREATED
                 ,CSO_DSCH_VOL_UNTREATED
                 ,CSO_CORR_ACTN_TAKEN_DESC_TXT
                 ,CSO_INCHES_PRECIP
             FROM tmp_stg_cmpl
            WHERE ICS_CMPL_MON_ID IS NOT NULL
              AND (   CSO_CSO_EVT_DATE             IS NOT NULL
                   OR CSO_DRY_OR_WET_WEATHER_IND   IS NOT NULL
                   OR CSO_PRMT_FEATR_IDENT         IS NOT NULL
                   OR CSO_LAT_MEAS                 IS NOT NULL
                   OR CSO_LONG_MEAS                IS NOT NULL
                   OR CSO_CSO_OVRFLW_LOC_STREET    IS NOT NULL
                   OR CSO_DURATION_CSO_OVRFLW_EVT  IS NOT NULL
                   OR CSO_DSCH_VOL_TREATED         IS NOT NULL
                   OR CSO_DSCH_VOL_UNTREATED       IS NOT NULL
                   OR CSO_CORR_ACTN_TAKEN_DESC_TXT IS NOT NULL 
                   OR CSO_INCHES_PRECIP            IS NOT NULL)
          ) vw;
   -- 
   SET v_rowcount = (SELECT ROW_COUNT());
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'INSERT'      -- pi_process
      ,v_rowcount);  -- pi_value
   -- --------------
   -- ics_pretr_insp
   -- --------------
   SET v_marker    = 'INSERT INTO ICS_PRETR_INSP';
   SET v_startdtm2 = NOW();
   SET v_tgt_tbl   = 'ICS_PRETR_INSP';
   SET v_src_tbl   = 'tmp_stg_cmpl';
   INSERT INTO ICS_PRETR_INSP  
      (ICS_PRETR_INSP_ID
      ,ICS_CMPL_MON_ID
      ,SUO_REF
      ,SUO_DATE
      ,ACCEPTANCE_HAZ_WASTE
      ,ACCEPTANCE_NON_HAZ_INDST_WASTE
      ,ACCEPTANCE_HULED_DOMSTIC_WSTES
      ,ANNUL_PRETR_BUDGET
      ,INADEQUACY_SMPL_INSP_IND
      ,ADEQUACY_PRETR_RESOURCES
      ,DFCNC_IDNTFD_DRNG_IU_FILE_RVIW
      ,CONTROL_MECH_DFCNC
      ,LEGAL_AUTH_DFCNC
      ,DFCNC_INTRPRT_APPL_PRETR_STNDR
      ,DFCNC_DAT_MGMT_PBLC_PRTICIPTON
      ,VIOL_IU_SCHD_RMD_MSR
      ,FRML_RSPN_VIOL_IU_SCHD_RMD_MSR
      ,ANNUL_FREQ_INFLUNT_TOXCNT_SMPL
      ,ANNUL_FREQ_EFFLU_TOXCNT_SMPL
      ,ANNUL_FREQ_SLDG_TOXCNT_SMPL
      ,SI_US_SNC_WITH_PRETR_SCHD
      ,SI_US_SNC_PUBL_NEWSPAPER
      ,VIOL_NOTICES_ISSUED_SI_US
      ,ADMIN_ORDERS_ISSUED_SI_US
      ,CIVIL_SUTS_FILD_AGINST_SI_US
      ,CRIMINL_SUTS_FILD_AGINST_SI_US
      ,DOLLAR_AMT_PNLTY_COLL
      ,I_US_WHC_PNLTY_HAV_BEE_COLL     
      ,NUM_SI_US
      ,SI_US_WITHOUT_CONTROL_MECH
      ,SI_US_NOT_INSPECTED
      ,SI_US_NOT_SMPL
      ,SI_US_ON_SCHD
      ,SI_US_SNC_WITH_PRETR_STNDR
      ,SI_US_SNC_WITH_REP_REQS
      ,NUM_CI_US
      ,PASS_THROUGH_INTERFERENCE_IND 
      ,CI_US_IN_SNC)
   SELECT UUID()
         ,vw.*
     FROM (SELECT DISTINCT ICS_CMPL_MON_ID
                 ,PRETR_SUO_REF
                 ,PRETR_SUO_DATE
                 ,PRETR_ACCEPTANCE_HAZ_WASTE
                 ,PRETR_ACCEPTANCE_NON_HAZ_INDST_WASTE
                 ,PRETR_ACCEPTANCE_HULED_DOMSTIC_WSTES
                 ,PRETR_ANNUL_PRETR_BUDGET
                 ,PRETR_INADEQUACY_SMPL_INSP_IND
                 ,PRETR_ADEQUACY_PRETR_RESOURCES
                 ,PRETR_DFCNC_IDNTFD_DRNG_IU_FILE_RVIW
                 ,PRETR_CONTROL_MECH_DFCNC
                 ,PRETR_LEGAL_AUTH_DFCNC
                 ,PRETR_DFCNC_INTRPRT_APPL_PRETR_STNDR
                 ,PRETR_DFCNC_DAT_MGMT_PBLC_PRTICIPTON
                 ,PRETR_VIOL_IU_SCHD_RMD_MSR
                 ,PRETR_FRML_RSPN_VIOL_IU_SCHD_RMD_MSR
                 ,PRETR_ANNUL_FREQ_INFLUNT_TOXCNT_SMPL
                 ,PRETR_ANNUL_FREQ_EFFLU_TOXCNT_SMPL
                 ,PRETR_ANNUL_FREQ_SLDG_TOXCNT_SMPL
                 ,PRETR_SI_US_SNC_WITH_PRETR_SCHD
                 ,PRETR_SI_US_SNC_PUBL_NEWSPAPER
                 ,PRETR_VIOL_NOTICES_ISSUED_SI_US
                 ,PRETR_ADMIN_ORDERS_ISSUED_SI_US
                 ,PRETR_CIVIL_SUTS_FILD_AGINST_SI_US
                 ,PRETR_CRIMINL_SUTS_FILD_AGINST_SI_US
                 ,PRETR_DOLLAR_AMT_PNLTY_COLL
                 ,PRETR_I_US_WHC_PNLTY_HAV_BEE_COLL     
                 ,PRETR_NUM_SI_US
                 ,PRETR_SI_US_WITHOUT_CONTROL_MECH
                 ,PRETR_SI_US_NOT_INSPECTED
                 ,PRETR_SI_US_NOT_SMPL
                 ,PRETR_SI_US_ON_SCHD
                 ,PRETR_SI_US_SNC_WITH_PRETR_STNDR
                 ,PRETR_SI_US_SNC_WITH_REP_REQS
                 ,PRETR_NUM_CI_US
                 ,PRETR_PASS_THROUGH_INTERFERENCE_IND 
                 ,PRETR_CI_US_IN_SNC
             FROM tmp_stg_cmpl
            WHERE ICS_CMPL_MON_ID IS NOT NULL
              AND (   PRETR_SUO_REF                        IS NOT NULL
                   OR PRETR_SUO_DATE                       IS NOT NULL
                   OR PRETR_ACCEPTANCE_HAZ_WASTE           IS NOT NULL
                   OR PRETR_ACCEPTANCE_NON_HAZ_INDST_WASTE IS NOT NULL
                   OR PRETR_ACCEPTANCE_HULED_DOMSTIC_WSTES IS NOT NULL
                   OR PRETR_ANNUL_PRETR_BUDGET             IS NOT NULL
                   OR PRETR_INADEQUACY_SMPL_INSP_IND       IS NOT NULL
                   OR PRETR_ADEQUACY_PRETR_RESOURCES       IS NOT NULL
                   OR PRETR_DFCNC_IDNTFD_DRNG_IU_FILE_RVIW IS NOT NULL
                   OR PRETR_CONTROL_MECH_DFCNC             IS NOT NULL
                   OR PRETR_LEGAL_AUTH_DFCNC               IS NOT NULL
                   OR PRETR_DFCNC_INTRPRT_APPL_PRETR_STNDR IS NOT NULL
                   OR PRETR_DFCNC_DAT_MGMT_PBLC_PRTICIPTON IS NOT NULL
                   OR PRETR_VIOL_IU_SCHD_RMD_MSR           IS NOT NULL
                   OR PRETR_FRML_RSPN_VIOL_IU_SCHD_RMD_MSR IS NOT NULL
                   OR PRETR_ANNUL_FREQ_INFLUNT_TOXCNT_SMPL IS NOT NULL
                   OR PRETR_ANNUL_FREQ_EFFLU_TOXCNT_SMPL   IS NOT NULL
                   OR PRETR_ANNUL_FREQ_SLDG_TOXCNT_SMPL    IS NOT NULL
                   OR PRETR_SI_US_SNC_WITH_PRETR_SCHD      IS NOT NULL
                   OR PRETR_SI_US_SNC_PUBL_NEWSPAPER       IS NOT NULL
                   OR PRETR_VIOL_NOTICES_ISSUED_SI_US      IS NOT NULL
                   OR PRETR_ADMIN_ORDERS_ISSUED_SI_US      IS NOT NULL
                   OR PRETR_CIVIL_SUTS_FILD_AGINST_SI_US   IS NOT NULL
                   OR PRETR_CRIMINL_SUTS_FILD_AGINST_SI_US IS NOT NULL
                   OR PRETR_DOLLAR_AMT_PNLTY_COLL          IS NOT NULL 
                   OR PRETR_I_US_WHC_PNLTY_HAV_BEE_COLL    IS NOT NULL
                   OR PRETR_NUM_SI_US                      IS NOT NULL
                   OR PRETR_SI_US_WITHOUT_CONTROL_MECH     IS NOT NULL
                   OR PRETR_SI_US_NOT_INSPECTED            IS NOT NULL
                   OR PRETR_SI_US_NOT_SMPL                 IS NOT NULL
                   OR PRETR_SI_US_ON_SCHD                  IS NOT NULL
                   OR PRETR_SI_US_SNC_WITH_PRETR_STNDR     IS NOT NULL
                   OR PRETR_SI_US_SNC_WITH_REP_REQS        IS NOT NULL
                   OR PRETR_NUM_CI_US                      IS NOT NULL
                   OR PRETR_PASS_THROUGH_INTERFERENCE_IND  IS NOT NULL
                   OR PRETR_CI_US_IN_SNC                   IS NOT NULL)
            ) vw;
   -- 
   SET v_rowcount = (SELECT ROW_COUNT());
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'INSERT'      -- pi_process
      ,v_rowcount);  -- pi_value
   -- ---------------------
   -- tmp_stg_sso_insp_main
   -- ---------------------
   SET v_marker = 'DROP AND CREATE TEMPORARY TABLE tmp_stg_sso_insp_main';
   DROP TABLE IF EXISTS tmp_stg_sso_insp_main;
   CREATE TEMPORARY TABLE tmp_stg_sso_insp_main AS
   SELECT DISTINCT sso.*
         ,STPS_RDUCE_PREVNT_MITIGTE
         ,OTHR_STPS_RDUCE_PREVNT_MITIGTE
     FROM tmp_stg_cmpl stg
     LEFT OUTER JOIN
        (SELECT UUID()  ICS_SSO_INSP_ID
               ,vw.*
           FROM (SELECT DISTINCT ICS_CMPL_MON_ID
                       ,SSO_SSO_EVT_DATE
                       ,SSO_CAUSE_SSO_OVRFLW_EVT
                       ,SSO_LAT_MEAS
                       ,SSO_LONG_MEAS
                       ,SSO_SSO_OVRFLW_LOC_STREET
                       ,SSO_DURATION_SSO_OVRFLW_EVT
                       ,SSO_SSO_VOL
                       ,SSO_NAME_RCVG_WTR
                       ,SSO_DESC_STPS_TAKEN
                   FROM tmp_stg_cmpl
                  WHERE ICS_CMPL_MON_ID IS NOT NULL
                    AND (   SSO_SSO_EVT_DATE            IS NOT NULL
                         OR SSO_CAUSE_SSO_OVRFLW_EVT    IS NOT NULL
                         OR SSO_LAT_MEAS                IS NOT NULL
                         OR SSO_LONG_MEAS               IS NOT NULL
                         OR SSO_SSO_OVRFLW_LOC_STREET   IS NOT NULL
                         OR SSO_DURATION_SSO_OVRFLW_EVT IS NOT NULL
                         OR SSO_SSO_VOL                 IS NOT NULL
                         OR SSO_NAME_RCVG_WTR           IS NOT NULL
                         OR SSO_DESC_STPS_TAKEN         IS NOT NULL)
                ) vw
        ) sso
       ON sso.ICS_CMPL_MON_ID                           = stg.ICS_CMPL_MON_ID
      AND COALESCE(sso.SSO_SSO_EVT_DATE,'1970-01-01')   = COALESCE(stg.SSO_SSO_EVT_DATE,'1970-01-01')
      AND COALESCE(sso.SSO_CAUSE_SSO_OVRFLW_EVT,'X')    = COALESCE(stg.SSO_CAUSE_SSO_OVRFLW_EVT,'X')
      AND COALESCE(sso.SSO_LAT_MEAS,0)                  = COALESCE(stg.SSO_LAT_MEAS,0)
      AND COALESCE(sso.SSO_LONG_MEAS,0)                 = COALESCE(stg.SSO_LONG_MEAS,0)
      AND COALESCE(sso.SSO_SSO_OVRFLW_LOC_STREET,'X')   = COALESCE(stg.SSO_SSO_OVRFLW_LOC_STREET,'X')
      AND COALESCE(sso.SSO_DURATION_SSO_OVRFLW_EVT,'X') = COALESCE(stg.SSO_DURATION_SSO_OVRFLW_EVT,'X')
      AND COALESCE(sso.SSO_SSO_VOL,0)                   = COALESCE(stg.SSO_SSO_VOL,0)
      AND COALESCE(sso.SSO_NAME_RCVG_WTR,'X')           = COALESCE(stg.SSO_NAME_RCVG_WTR,'X')
      AND COALESCE(sso.SSO_DESC_STPS_TAKEN,'X')         = COALESCE(stg.SSO_DESC_STPS_TAKEN,'X')
    WHERE ICS_SSO_INSP_ID IS NOT NULL;
      -- AND (    STPS_RDUCE_PREVNT_MITIGTE IS NOT NULL
      --     OR OTHR_STPS_RDUCE_PREVNT_MITIGTE IS NOT NULL);
   -- ------------
   -- ics_sso_insp
   -- ------------
   SET v_marker    = 'INSERT INTO ICS_SSO_INSP';
   SET v_startdtm2 = NOW();
   SET v_tgt_tbl   = 'ICS_SSO_INSP';
   SET v_src_tbl   = 'tmp_stg_sso_insp_main';
   INSERT INTO ICS_SSO_INSP
      (ICS_SSO_INSP_ID
      ,ICS_CMPL_MON_ID
      ,SSO_EVT_DATE
      ,CAUSE_SSO_OVRFLW_EVT
      ,LAT_MEAS
      ,LONG_MEAS
      ,SSO_OVRFLW_LOC_STREET
      ,DURATION_SSO_OVRFLW_EVT
      ,SSO_VOL
      ,NAME_RCVG_WTR
      ,DESC_STPS_TAKEN)
   SELECT DISTINCT ICS_SSO_INSP_ID
         ,ICS_CMPL_MON_ID
         ,SSO_SSO_EVT_DATE
         ,SSO_CAUSE_SSO_OVRFLW_EVT
         ,SSO_LAT_MEAS
         ,SSO_LONG_MEAS
         ,SSO_SSO_OVRFLW_LOC_STREET
         ,SSO_DURATION_SSO_OVRFLW_EVT
         ,SSO_SSO_VOL
         ,SSO_NAME_RCVG_WTR
         ,SSO_DESC_STPS_TAKEN
     FROM tmp_stg_sso_insp_main
    WHERE ICS_SSO_INSP_ID IS NOT NULL
      AND ICS_CMPL_MON_ID IS NOT NULL;
   -- 
   SET v_rowcount = (SELECT ROW_COUNT());
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'INSERT'      -- pi_process
      ,v_rowcount);  -- pi_value
   -- ------------
   -- ics_sso_stps
   -- ------------
   SET v_marker    = 'INSERT INTO ICS_SSO_STPS';
   SET v_startdtm2 = NOW();
   SET v_tgt_tbl   = 'ICS_SSO_STPS';
   SET v_src_tbl   = 'tmp_stg_sso_insp_main';
   INSERT INTO ICS_SSO_STPS
      (ICS_SSO_STPS_ID
      ,ICS_SSO_INSP_ID
      ,STPS_RDUCE_PREVNT_MITIGTE
      ,OTHR_STPS_RDUCE_PREVNT_MITIGTE)
   SELECT UUID()
         ,vw.*
     FROM (SELECT DISTINCT ICS_SSO_INSP_ID
                 ,STPS_RDUCE_PREVNT_MITIGTE
                 ,OTHR_STPS_RDUCE_PREVNT_MITIGTE
             FROM tmp_stg_sso_insp_main
            WHERE STPS_RDUCE_PREVNT_MITIGTE IS NOT NULL) vw;
   -- 
   SET v_rowcount = (SELECT ROW_COUNT());
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'INSERT'      -- pi_process
      ,v_rowcount);  -- pi_value
   -- ----------------
   -- ics_sw_ms_4_insp
   -- ----------------
   SET v_marker    = 'INSERT INTO ICS_SW_MS_4_INSP';
   SET v_startdtm2 = NOW();
   SET v_tgt_tbl   = 'ICS_SW_MS_4_INSP';
   SET v_src_tbl   = 'tmp_stg_cmpl';
   INSERT INTO ICS_SW_MS_4_INSP
      (ICS_SW_MS_4_INSP_ID
      ,ICS_CMPL_MON_ID
      ,MS_4_ANNUL_EXPEN_DOLLARS
      ,MS_4_ANNUL_EXPEN_YEAR
      ,MS_4_BUDGET_DOLLARS
      ,MS_4_BUDGET_YEAR
      ,MAJOR_OUTFALL_EST_MEAS_IND
      ,MAJOR_OUTFALL_NUM
      ,MINOR_OUTFALL_EST_MEAS_IND
      ,MINOR_OUTFALL_NUM)
   SELECT UUID()
          ,vw.*
     FROM (SELECT DISTINCT ICS_CMPL_MON_ID
                 ,MS_4_ANNUL_EXPEN_DOLLARS
                 ,MS_4_ANNUL_EXPEN_YEAR
                 ,MS_4_BUDGET_DOLLARS
                 ,MS_4_BUDGET_YEAR
                 ,MAJOR_OUTFALL_EST_MEAS_IND
                 ,MAJOR_OUTFALL_NUM
                 ,MINOR_OUTFALL_EST_MEAS_IND
                 ,MINOR_OUTFALL_NUM
             FROM tmp_stg_cmpl
            WHERE ICS_CMPL_MON_ID IS NOT NULL
              AND (   MS_4_ANNUL_EXPEN_DOLLARS   IS NOT NULL
                   OR MS_4_ANNUL_EXPEN_YEAR      IS NOT NULL
                   OR MS_4_BUDGET_DOLLARS        IS NOT NULL
                   OR MS_4_BUDGET_YEAR           IS NOT NULL
                   OR MAJOR_OUTFALL_EST_MEAS_IND IS NOT NULL
                   OR MAJOR_OUTFALL_NUM          IS NOT NULL
                   OR MINOR_OUTFALL_EST_MEAS_IND IS NOT NULL
                   OR MINOR_OUTFALL_NUM          IS NOT NULL)) vw;
   -- 
   SET v_rowcount = (SELECT ROW_COUNT());
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'INSERT'      -- pi_process
      ,v_rowcount);  -- pi_value
   -- --------
   -- ics_prog
   -- --------
   SET v_marker    = 'INSERT INTO ICS_PROG';
   SET v_startdtm2 = NOW();
   SET v_tgt_tbl   = 'ICS_PROG';
   SET v_src_tbl   = 'tmp_stg_cmpl';
   INSERT INTO ICS_PROG  
      (ICS_PROG_ID
      ,ICS_CMPL_MON_ID
      ,PROG_CODE)
   SELECT UUID()
         ,ICS_CMPL_MON_ID
         ,PROG_CODE
     FROM (SELECT DISTINCT PROG_CODE
                 ,ICS_CMPL_MON_ID
             FROM tmp_stg_cmpl
            WHERE PROG_CODE       IS NOT NULL
              AND ICS_CMPL_MON_ID IS NOT NULL) vw;
   -- 
   SET v_rowcount = (SELECT ROW_COUNT());
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'INSERT'      -- pi_process
      ,v_rowcount);  -- pi_value
   -- -------------- --
   --  END PROCEDURE --
   -- -------------- --
   SET v_marker = 'CALL ics_etl_log_sp END';
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_sp_name     -- pi_marker
      ,NULL          -- pi_tgt_tbl
      ,NULL          -- pi_src_tbl 
      ,v_startdtm    -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'COMPLETED'   -- pi_process
      ,0);           -- pi_value
   --
   SET po_status = 1;
   SET po_errm   = '';
   --
   --
END;
