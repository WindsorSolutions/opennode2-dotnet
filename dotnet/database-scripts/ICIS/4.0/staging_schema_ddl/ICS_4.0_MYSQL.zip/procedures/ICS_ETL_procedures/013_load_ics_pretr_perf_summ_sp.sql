DROP PROCEDURE IF EXISTS load_ics_pretr_perf_summ_sp;
CREATE PROCEDURE `load_ics_pretr_perf_summ_sp`
   (OUT po_status INT
   ,OUT po_errm   VARCHAR(255))
BEGIN
-- ============================================================================
-- MODIFICATION HISTORY
-- Person      Date       Comments
-- ---------   --------   -----------------------------------------------------
-- Jen Go      20120925   Created.  
--
-- ============================================================================
   DECLARE v_startdtm   DATETIME     DEFAULT NOW();
   DECLARE v_enddtm     DATETIME;
   DECLARE v_marker     VARCHAR(255);
   DECLARE v_sp_name    VARCHAR(64)  DEFAULT 'load_ics_pretr_perf_summ_sp';
   DECLARE v_tgt_tbl    VARCHAR(64)  DEFAULT 'ICS_PRETR_PERF_SUMM';
   DECLARE v_src_tbl    VARCHAR(64)  DEFAULT 'stg_permit_main';
   DECLARE v_rowcount   INT          DEFAULT 0;
   --
   DECLARE EXIT HANDLER FOR SQLEXCEPTION
      BEGIN  
         ROLLBACK;
         SET po_status = -1;
         SET po_errm   = v_marker;
         CALL ics_etl_log_sp    
            (v_sp_name          -- pi_sp_name
            ,v_marker           -- pi_marker
            ,v_tgt_tbl          -- pi_tgt_tbl
            ,v_src_tbl          -- pi_src_tbl
            ,v_startdtm         -- pi_startdtm
            ,NOW()              -- pi_enddtm
            ,'FAILED'           -- pi_process
            ,-1);               -- pi_value
      END;
   -- -------------------------------
   -- tmp_load_ics_pretr_perf_summ_sp
   -- -------------------------------
   SET v_marker = 'DROP AND CREATE TABLE tmp_load_ics_pretr_perf_summ_sp';
   INSERT INTO ICS_PRETR_PERF_SUMM
     (ICS_PRETR_PERF_SUMM_ID
     ,ICS_PAYLOAD_ID
     ,PRMT_IDENT
     ,PRETR_PERF_SUMM_END_DATE
     ,PRETR_PERF_SUMM_START_DATE
     ,NUM_SI_US
     ,SI_US_WITHOUT_CONTROL_MECH
     ,SI_US_NOT_INSPECTED
     ,SI_US_NOT_SMPL
     ,SI_US_ON_SCHD
     ,SI_US_SNC_WITH_PRETR_STNDR
     ,SI_US_SNC_WITH_REP_REQS
     ,NUM_CI_US
     ,PASS_THROUGH_INTERFERENCE_IND)
   SELECT UUID()
         ,'PretreatmentPerformanceSummary'
         ,PRMT_IDENT
         ,PRETR_PERF_SUMM_END_DATE
         ,PRETR_PERF_SUMM_START_DATE
         ,NUM_SI_US
         ,SI_US_WITHOUT_CONTROL_MECH
         ,SI_US_NOT_INSPECTED
         ,SI_US_NOT_SMPL
         ,SI_US_ON_SCHD
         ,SI_US_SNC_WITH_PRETR_STNDR
         ,SI_US_SNC_WITH_REP_REQS
         ,NUM_CI_US
         ,PASS_THROUGH_INTERFERENCE_IND
     FROM (SELECT PRMT_IDENT
                 ,MAX(PRETR_PERF_SUMM_END_DATE) PRETR_PERF_SUMM_END_DATE
                 ,MAX(PRETR_PERF_SUMM_START_DATE) PRETR_PERF_SUMM_START_DATE
                 ,MAX(NUM_SI_US) NUM_SI_US
                 ,MAX(SI_US_WITHOUT_CONTROL_MECH) SI_US_WITHOUT_CONTROL_MECH
                 ,MAX(SI_US_NOT_INSPECTED) SI_US_NOT_INSPECTED
                 ,MAX(SI_US_NOT_SMPL) SI_US_NOT_SMPL
                 ,MAX(SI_US_ON_SCHD) SI_US_ON_SCHD
                 ,MAX(SI_US_SNC_WITH_PRETR_STNDR) SI_US_SNC_WITH_PRETR_STNDR
                 ,MAX(SI_US_SNC_WITH_REP_REQS) SI_US_SNC_WITH_REP_REQS
                 ,MAX(NUM_CI_US) NUM_CI_US
                 ,MAX(PASS_THROUGH_INTERFERENCE_IND) PASS_THROUGH_INTERFERENCE_IND
            FROM (SELECT DISTINCT stg.PRMT_IDENT
                         --
                        ,CASE WHEN qr.QUESTION_CODE = 'ICIS045' THEN
                            qr.ANSWER_DATE
                         ELSE NULL END                 PRETR_PERF_SUMM_END_DATE
                        ,CASE WHEN qr.QUESTION_CODE = 'ICIS046' THEN
                            qr.ANSWER_DATE
                         ELSE NULL END                 PRETR_PERF_SUMM_START_DATE
                        --
                        ,CASE WHEN qr.QUESTION_CODE = 'ICIS047' THEN
                            qr.ANSWER_COMMENT
                         ELSE NULL END                 NUM_SI_US
                        --
                        ,CASE WHEN qr.QUESTION_CODE = 'ICIS048' THEN
                            qr.ANSWER_COMMENT
                         ELSE NULL END                 SI_US_WITHOUT_CONTROL_MECH
                        --
                        ,CASE WHEN qr.QUESTION_CODE = 'ICIS049' THEN
                            qr.ANSWER_COMMENT
                         ELSE NULL END                 SI_US_NOT_INSPECTED
                        --
                        ,CASE WHEN qr.QUESTION_CODE = 'ICIS050' THEN
                            qr.ANSWER_COMMENT
                         ELSE NULL END                 SI_US_NOT_SMPL
                        --
                        ,CASE WHEN qr.QUESTION_CODE = 'ICIS051' THEN
                            qr.ANSWER_COMMENT
                         ELSE NULL END                 SI_US_ON_SCHD          
                        --
                        ,CASE WHEN qr.QUESTION_CODE = 'ICIS052' THEN
                            qr.ANSWER_COMMENT
                         ELSE NULL END                 SI_US_SNC_WITH_PRETR_STNDR
                        --
                        ,CASE WHEN qr.QUESTION_CODE = 'ICIS053' THEN
                            qr.ANSWER_COMMENT
                         ELSE NULL END                 SI_US_SNC_WITH_REP_REQS
                        --
                        ,CASE WHEN qr.QUESTION_CODE = 'ICIS054' THEN
                            qr.ANSWER_COMMENT
                         ELSE NULL END                 NUM_CI_US
                        --
                        ,CASE WHEN qr.QUESTION_CODE = 'ICIS055' THEN
                            qr.ANSWER_Y_N_NA
                         ELSE NULL END                 PASS_THROUGH_INTERFERENCE_IND
                    FROM stg_permit_main stg
                    JOIN wrp.QUESTION_RESULT qr
                      ON qr.PERMIT_ACTION_ID = stg.PERMIT_ACTION_ID
                     AND qr.QUESTION_CODE IN ('ICIS045' 
                                             ,'ICIS046'
                                             ,'ICIS047'
                                             ,'ICIS048'
                                             ,'ICIS049'
                                             ,'ICIS050'
                                             ,'ICIS051'
                                             ,'ICIS052'
                                             ,'ICIS053'
                                             ,'ICIS054'
                                             ,'ICIS055')
                   WHERE ICS_GNRL_PRMT_ID IS NOT NULL) vw1
           GROUP BY PRMT_IDENT
          ) vw1;
   --
   SET v_rowcount = (SELECT ROW_COUNT());
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm    -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'INSERT'      -- pi_process
      ,v_rowcount);  -- pi_value
   --
   -- -------------- --
   --  END PROCEDURE --
   -- -------------- --
   SET v_marker = 'CALL ics_etl_log_sp END';
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_sp_name     -- pi_marker
      ,NULL          -- pi_tgt_tbl
      ,NULL          -- pi_src_tbl 
      ,v_startdtm    -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'COMPLETED'   -- pi_process
      ,0);           -- pi_value
   --
   SET po_status = 1;
   SET po_errm   = '';
   --
END