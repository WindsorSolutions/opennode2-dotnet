USE ga_ics_flow_local;
DROP PROCEDURE IF EXISTS load_ics_contact_sp;
CREATE PROCEDURE load_ics_contact_sp
   (OUT po_status INT
   ,OUT po_errm   VARCHAR(255))
BEGIN
-- ============================================================================
-- MODIFICATION HISTORY
-- Person      Date       Comments
-- ---------   --------   -----------------------------------------------------
-- Jen Go      20120921   Created.  
--                        Sources:
--                          1) stg_permit_main/ICS_BASIC_PRMT_ID
--                          2) stg_permit_main/ICS_GNRL_PRMT_ID
--                          3) stg_permit_main/ICS_FAC_ID
--                          4) stg_pretr_prmt_main/ICS_PRETR_PRMT_ID
--                          5) tmp_stg_cafo_prmt/ICS_CAFO_PRMT_ID
--                          6) tmp_stg_swms_4_prog_rep/ICS_SWMS_4_PROG_REP_ID
-- ============================================================================
   DECLARE v_startdtm   DATETIME     DEFAULT NOW();
   DECLARE v_startdtm2
          ,v_enddtm     DATETIME;
   DECLARE v_marker     VARCHAR(255);
   DECLARE v_sp_name    VARCHAR(64)  DEFAULT 'load_ics_contact_sp';
   DECLARE v_tgt_tbl    VARCHAR(64)  DEFAULT 'ICS_CONTACT';
   DECLARE v_src_tbl    VARCHAR(64);
   DECLARE v_rowcount   INT          DEFAULT 0;
   --
   DECLARE EXIT HANDLER FOR SQLEXCEPTION
      BEGIN  
         ROLLBACK;
         SET po_status = -1;
         SET po_errm   = v_marker;
         CALL ics_etl_log_sp    
            (v_sp_name          -- pi_sp_name
            ,v_marker           -- pi_marker
            ,v_tgt_tbl          -- pi_tgt_tbl
            ,v_src_tbl          -- pi_src_tbl
            ,v_startdtm         -- pi_startdtm
            ,NOW()              -- pi_enddtm
            ,'FAILED'           -- pi_process
            ,-1);               -- pi_value
      END;
   -- ---------------
   -- stg_permit_main
   -- ---------------
   SET v_marker    = 'INSERT INTO ICS_CONTACT USING stg_permit_main';
   SET v_src_tbl   = 'stg_permit_main';
   SET v_startdtm2 = NOW();
   INSERT INTO ICS_CONTACT
      (ICS_CONTACT_ID
      ,ICS_BASIC_PRMT_ID
      ,ICS_GNRL_PRMT_ID
      ,ICS_FAC_ID
      ,ICS_CMPL_MON_ID
      ,AFFIL_TYPE_TXT
      ,FIRST_NAME
      ,LAST_NAME
      ,INDVL_TITLE_TXT
      ,ORG_FRML_NAME
      ,ELEC_ADDR_TXT
      ,ST_CODE)
   SELECT ICS_CONTACT_ID
         ,ICS_BASIC_PRMT_ID
         ,NULL               ICS_GNRL_PRMT_ID
         ,ICS_FAC_ID         ICS_FAC_ID
         ,NULL               ICS_CMPL_MON_ID
         ,AFFIL_TYPE_TXT
         ,FIRST_NAME
         ,LAST_NAME
         ,TITLE
         ,ORG_FRML_NAME
         ,ELEC_ADDR_TXT
         ,NULL               ST_CODE
     FROM stg_permit_main
    WHERE ICS_CONTACT_ID    IS NOT NULL
      AND ICIS_REF_AFFILIATION_TYPE = 'PMA'
      AND ICS_BASIC_PRMT_ID IS NOT NULL
      AND AFFIL_TYPE_TXT    IS NOT NULL
      AND FIRST_NAME        IS NOT NULL
      AND LAST_NAME         IS NOT NULL
   UNION ALL
   SELECT ICS_CONTACT_ID
         ,NULL             ICS_BASIC_PRMT_ID
         ,ICS_GNRL_PRMT_ID ICS_GNRL_PRMT_ID
         ,NULL             ICS_FAC_ID
         ,NULL             ICS_CMPL_MON_ID
         ,AFFIL_TYPE_TXT
         ,FIRST_NAME
         ,LAST_NAME
         ,TITLE
         ,ORG_FRML_NAME
         ,ELEC_ADDR_TXT
         ,NULL             ST_CODE
     FROM stg_permit_main
    WHERE ICS_CONTACT_ID   IS NOT NULL
      AND ICIS_REF_AFFILIATION_TYPE = 'PMA'
      AND ICS_GNRL_PRMT_ID IS NOT NULL
      AND AFFIL_TYPE_TXT   IS NOT NULL
      AND FIRST_NAME       IS NOT NULL
      AND LAST_NAME        IS NOT NULL
   UNION ALL
   SELECT ICS_CONTACT_ID
         ,NULL             ICS_BASIC_PRMT_ID
         ,NULL             ICS_GNRL_PRMT_ID
         ,ICS_FAC_ID       ICS_FAC_ID
         ,NULL             ICS_CMPL_MON_ID
         ,AFFIL_TYPE_TXT
         ,FIRST_NAME
         ,LAST_NAME
         ,TITLE
         ,ORG_FRML_NAME
         ,ELEC_ADDR_TXT
         ,NULL             ST_CODE
     FROM stg_permit_main
    WHERE ICS_CONTACT_ID IS NOT NULL
      AND ICIS_REF_AFFILIATION_TYPE IN ('OWN','OPE','PCT')
      AND ICS_FAC_ID     IS NOT NULL
      AND AFFIL_TYPE_TXT IS NOT NULL
      AND FIRST_NAME     IS NOT NULL
      AND LAST_NAME      IS NOT NULL
   /*UNION ALL
   SELECT DISTINCT ICS_CONTACT_ID
         ,NULL     ICS_BASIC_PRMT_ID
         ,NULL     ICS_GNRL_PRMT_ID
         ,NULL     ICS_FAC_ID
         ,ICS_CMPL_MON_ID
         ,AFFIL_TYPE_TXT
         ,FIRST_NAME
         ,LAST_NAME
         ,TITLE
         ,ORG_FRML_NAME
         ,NULL     ELEC_ADDR_TXT
         ,ST_CODE
     FROM stg_cmpl_main
    WHERE ICS_CONTACT_ID IS NOT NULL
      AND AFFIL_TYPE_TXT IS NOT NULL
      AND FIRST_NAME     IS NOT NULL
      AND LAST_NAME      IS NOT NULL*/
    ;
   --
   SET v_rowcount = (SELECT ROW_COUNT());
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'INSERT'      -- pi_process
      ,v_rowcount);  -- pi_value
   /*
   -- -------------
   -- stg_cmpl_main
   -- -------------
   SET v_marker  = 'INSERT INTO ICS_CONTACT USING stg_cmpl_main';
   INSERT INTO ICS_CONTACT
      (ICS_CONTACT_ID
      ,ICS_CMPL_MON_ID
      ,AFFIL_TYPE_TXT
      ,FIRST_NAME
      ,LAST_NAME
      ,INDVL_TITLE_TXT
      ,ORG_FRML_NAME
      ,ST_CODE)
   SELECT DISTINCT ICS_CONTACT_ID
         ,ICS_CMPL_MON_ID
         ,AFFIL_TYPE_TXT
         ,FIRST_NAME
         ,LAST_NAME
         ,TITLE
         ,ORG_FRML_NAME
         ,ST_CODE
     FROM stg_cmpl_main;   
   --
   SET v_rowcount = (SELECT ROW_COUNT());
   SET v_enddtm   = NOW();
   SET v_marker   = 'CALL ics_etl_log_sp';
   CALL ics_etl_log_sp
      (v_sp_name
      ,v_marker
      ,v_tgt_tbl
      ,v_startdtm
      ,v_enddtm
      ,1
      ,CONCAT(v_tgt_tbl,' Total rows inserted (using stg_cmpl_main) = ',v_rowcount));
   */
   -- -------------------
   -- stg_pretr_prmt_main
   -- -------------------
   SET v_marker    = 'INSERT INTO ICS_CONTACT USING tmp_stg_pretr_prmt';
   SET v_src_tbl   = 'tmp_stg_pretr_prmt';
   SET v_startdtm2 = NOW();
   INSERT INTO ICS_CONTACT
      (ICS_CONTACT_ID
      ,ICS_PRETR_PRMT_ID
      ,AFFIL_TYPE_TXT
      ,FIRST_NAME
      ,LAST_NAME
      ,INDVL_TITLE_TXT
      ,ORG_FRML_NAME
      ,ELEC_ADDR_TXT)
   SELECT UUID()
        ,vw.*
     FROM (SELECT DISTINCT ICS_PRETR_PRMT_ID
                 ,AFFIL_TYPE_TXT
                 ,FIRST_NAME
                 ,LAST_NAME
                 ,INDVL_TITLE_TXT
                 ,ORG_FRML_NAME
                 ,ELEC_ADDR_TXT
             FROM tmp_stg_pretr_prmt -- stg_pretr_prmt_main
            WHERE AFFIL_TYPE_TXT = 'PRE'
              AND FIRST_NAME IS NOT NULL
              AND LAST_NAME  IS NOT NULL) vw;
   --
   SET v_rowcount = (SELECT ROW_COUNT());
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'INSERT'      -- pi_process
      ,v_rowcount);  -- pi_value
   -- -------------
   -- stg_cafo_main
   -- -------------
   SET v_marker    = 'INSERT INTO ICS_CONTACT USING tmp_stg_cafo_prmt';
   SET v_src_tbl   = 'tmp_stg_cafo_prmt';
   SET v_startdtm2 = NOW();   
   INSERT INTO ICS_CONTACT
      (ICS_CONTACT_ID
      ,ICS_PRETR_PRMT_ID
      ,AFFIL_TYPE_TXT
      ,FIRST_NAME
      ,LAST_NAME
      ,INDVL_TITLE_TXT
      ,ORG_FRML_NAME
      ,ELEC_ADDR_TXT)
   SELECT UUID()
        ,vw.*
     FROM (SELECT DISTINCT ICS_CAFO_PRMT_ID
                 ,AFFIL_TYPE_TXT
                 ,FIRST_NAME
                 ,LAST_NAME
                 ,INDVL_TITLE_TXT
                 ,ORG_FRML_NAME
                 ,ELEC_ADDR_TXT
             FROM tmp_stg_cafo_prmt -- stg_cafo_main
            WHERE AFFIL_TYPE_TXT IS NOT NULL
              AND FIRST_NAME     IS NOT NULL
              AND LAST_NAME      IS NOT NULL) vw;
   --
   SET v_rowcount = (SELECT ROW_COUNT());
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'INSERT'      -- pi_process
      ,v_rowcount);  -- pi_value
   -- ---------------------
   -- stg_swms4progrep_main
   -- ---------------------
   SET v_marker    = 'INSERT INTO ICS_CONTACT USING tmp_stg_swms_4_prog_rep';
   SET v_src_tbl   = 'tmp_stg_swms_4_prog_rep';
   SET v_startdtm2 = NOW();   
   INSERT INTO ICS_CONTACT
      (ICS_CONTACT_ID
      ,ICS_PRETR_PRMT_ID
      ,AFFIL_TYPE_TXT
      ,FIRST_NAME
      ,LAST_NAME
      ,INDVL_TITLE_TXT
      ,ORG_FRML_NAME
      ,ELEC_ADDR_TXT)
   SELECT UUID()
        ,vw.*
     FROM (SELECT DISTINCT ICS_SWMS_4_PROG_REP_ID
                 ,AFFIL_TYPE_TXT
                 ,FIRST_NAME
                 ,LAST_NAME
                 ,INDVL_TITLE_TXT
                 ,ORG_FRML_NAME
                 ,ELEC_ADDR_TXT
             FROM tmp_stg_swms_4_prog_rep -- stg_swms4progrep_main
            WHERE AFFIL_TYPE_TXT IS NOT NULL
              AND FIRST_NAME     IS NOT NULL
              AND LAST_NAME      IS NOT NULL) vw;
   --
   SET v_rowcount = (SELECT ROW_COUNT());
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'INSERT'      -- pi_process
      ,v_rowcount);  -- pi_value
   -- -------------- --
   --  END PROCEDURE --
   -- -------------- --
   SET v_marker = 'CALL ics_etl_log_sp END';
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_sp_name     -- pi_marker
      ,NULL          -- pi_tgt_tbl
      ,NULL          -- pi_src_tbl 
      ,v_startdtm    -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'COMPLETED'   -- pi_process
      ,0);           -- pi_value
   --
   SET po_status = 1;
   SET po_errm   = '';
   --
END   