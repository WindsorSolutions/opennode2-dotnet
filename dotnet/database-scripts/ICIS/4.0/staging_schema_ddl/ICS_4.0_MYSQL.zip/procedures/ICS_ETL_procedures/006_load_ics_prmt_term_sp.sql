USE ga_ics_flow_local;
DROP PROCEDURE IF EXISTS load_ics_prmt_term_sp;
CREATE PROCEDURE load_ics_prmt_term_sp
   (OUT po_status INT
   ,OUT po_errm   VARCHAR(255))
BEGIN
-- ============================================================================
-- MODIFICATION HISTORY
-- Person      Date       Comments
-- ---------   --------   -----------------------------------------------------
-- Jen Go      20120924   Created.  
--
-- ============================================================================
   DECLARE v_startdtm   DATETIME     DEFAULT NOW();
   DECLARE v_enddtm     DATETIME;
   DECLARE v_marker     VARCHAR(255);
   DECLARE v_sp_name    VARCHAR(64)  DEFAULT 'load_ics_prmt_term_sp';
   DECLARE v_tgt_tbl    VARCHAR(64)  DEFAULT 'ICS_PRMT_TERM';
   DECLARE v_src_tbl    VARCHAR(64)  DEFAULT 'PERMIT';
   DECLARE v_rowcount   INT          DEFAULT 0;
   --
   DECLARE EXIT HANDLER FOR SQLEXCEPTION
      BEGIN  
         ROLLBACK;
         SET po_status = -1;
         SET po_errm   = v_marker;
         -- 
         CALL ics_etl_log_sp    
            (v_sp_name          -- pi_sp_name
            ,v_marker           -- pi_marker
            ,v_tgt_tbl          -- pi_tgt_tbl
            ,v_src_tbl          -- pi_src_tbl
            ,v_startdtm         -- pi_startdtm
            ,NOW()              -- pi_enddtm
            ,'FAILED'           -- pi_process
            ,-1);               -- pi_value
      END;
   --
   SET v_marker = 'INSERT INTO ICS_PRMT_TERM';
   INSERT INTO ICS_PRMT_TERM
      (ICS_PRMT_TERM_ID
      ,ICS_PAYLOAD_ID
      ,PRMT_IDENT
      ,PRMT_TERM_DATE)
   SELECT UUID()
         ,'PermitTermination'
         ,NUMBER
         ,INACTIVE_DATE
     FROM wrp.PERMIT pmt
    WHERE pmt.PERMIT_CATEGORY_CODE IN ('IND','GPC')
      AND pmt.PERMIT_TYPE_CODE IN ('AFO','GEN CW'
                                  ,'GEN PID','GEN SG'
                                  ,'GEN WTP','MS4','REUSE')
      AND pmt.PERMIT_STATUS_CODE      = 'TERM'
      AND pmt.INACTIVE_DATE_TYPE_CODE = 'TER';
   -- 
   SET v_rowcount = (SELECT ROW_COUNT());
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm    -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'INSERT'      -- pi_process
      ,v_rowcount);  -- pi_value
   -- -------------- --
   --  END PROCEDURE --
   -- -------------- --
   SET v_marker = 'CALL ics_etl_log_sp END';
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_sp_name     -- pi_marker
      ,NULL          -- pi_tgt_tbl
      ,NULL          -- pi_src_tbl 
      ,v_startdtm    -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'COMPLETED'   -- pi_process
      ,0);           -- pi_value
   --
   SET po_status = 1;
   SET po_errm   = '';
   --
   
END