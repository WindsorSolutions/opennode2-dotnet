DROP PROCEDURE IF EXISTS load_stg_swms_4_prog_rep_sp;
CREATE PROCEDURE `load_stg_swms_4_prog_rep_sp`
   (OUT po_status INT
   ,OUT po_errm   VARCHAR(255))
BEGIN
-- ============================================================================
-- MODIFICATION HISTORY
-- Person      Date       Comments
-- ---------   --------   -----------------------------------------------------
-- Jen Go      20120925   Created.  
--
-- ============================================================================
   DECLARE v_startdtm   DATETIME     DEFAULT NOW();
   DECLARE v_enddtm     DATETIME;
   DECLARE v_marker     VARCHAR(255);
   DECLARE v_sp_name    VARCHAR(64)  DEFAULT 'load_stg_swms_4_prog_rep_sp';
   DECLARE v_tgt_tbl    VARCHAR(64);
   DECLARE v_src_tbl    VARCHAR(64);
   --
   DECLARE EXIT HANDLER FOR SQLEXCEPTION
      BEGIN  
         ROLLBACK;
         SET po_status = -1;
         SET po_errm   = v_marker;
         CALL ics_etl_log_sp    
            (v_sp_name          -- pi_sp_name
            ,v_marker           -- pi_marker
            ,v_tgt_tbl          -- pi_tgt_tbl
            ,v_src_tbl          -- pi_src_tbl
            ,v_startdtm         -- pi_startdtm
            ,NOW()              -- pi_enddtm
            ,'FAILED'           -- pi_process
            ,-1);               -- pi_value
      END;
   -- -----------------------
   -- tmp_stg_swms_4_prog_rep
   -- -----------------------
   SET v_marker = 'DROP AND CREATE TABLE tmp_stg_swms_4_prog_rep';
   DROP TABLE IF EXISTS tmp_stg_swms_4_prog_rep_main;
   CREATE TABLE tmp_stg_swms_4_prog_rep_main AS
   SELECT PERMIT_ID
         ,PERMIT_ACTION_ID
         ,QUESTION_CODE
         ,PRMT_IDENT
         ,MAX(SW_MS_4_REP_RCVD_DATE)    SW_MS_4_REP_RCVD_DATE
         ,MAX(MS_4_ANNUL_EXPEN_DOLLARS) MS_4_ANNUL_EXPEN_DOLLARS
         ,MAX(MS_4_ANNUL_EXPEN_YEAR)    MS_4_ANNUL_EXPEN_YEAR
         ,MAX(MS_4_BUDGET_DOLLARS)      MS_4_BUDGET_DOLLARS
         ,MAX(MS_4_BUDGET_YEAR)         MS_4_BUDGET_YEAR
         ,AFFIL_TYPE_TXT
         ,ORG_FRML_NAME
         ,MAILING_ADDR_TXT
         ,MAILING_ADDR_CITY_NAME
         ,MAILING_ADDR_ST_CODE
         ,MAILING_ADDR_ZIP_CODE
         ,MAILING_ADDR_COUNTRY_CODE
         ,FIRST_NAME
         ,LAST_NAME
         ,INDVL_TITLE_TXT
         ,ELEC_ADDR_TXT
     FROM (SELECT stg.PERMIT_ID
                 ,stg.PERMIT_ACTION_ID
                 ,qr.QUESTION_CODE
                 ,stg.PRMT_IDENT
                 --
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS056' THEN
                     qr.ANSWER_DATE
                  ELSE NULL END                     SW_MS_4_REP_RCVD_DATE
                 --
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS057' THEN
                     qr.ANSWER_COMMENT
                  ELSE NULL END                     MS_4_ANNUL_EXPEN_DOLLARS
                 --
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS058' THEN
                     qr.ANSWER_COMMENT
                  ELSE NULL END                     MS_4_ANNUL_EXPEN_YEAR
                 --
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS059' THEN
                     qr.ANSWER_COMMENT
                  ELSE NULL END                     MS_4_BUDGET_DOLLARS
                 --
                 ,CASE WHEN qr.QUESTION_CODE = 'ICIS060' THEN
                     qr.ANSWER_COMMENT
                  ELSE NULL END                     MS_4_BUDGET_YEAR
                 -- ---------------------
                 -- ics_addr; ics_contact
                 -- ---------------------
                 ,vw_addr_pc.AFFIL_TYPE_TXT
                 ,vw_addr_pc.ORG_FRML_NAME
                 ,vw_addr_pc.MAILING_ADDR_TXT
                 ,vw_addr_pc.MAILING_ADDR_CITY_NAME
                 ,vw_addr_pc.MAILING_ADDR_ST_CODE
                 ,vw_addr_pc.MAILING_ADDR_ZIP_CODE
                 ,vw_addr_pc.MAILING_ADDR_COUNTRY_CODE
                 ,vw_addr_pc.FIRST_NAME
                 ,vw_addr_pc.LAST_NAME
                 ,vw_addr_pc.INDVL_TITLE_TXT
                 ,vw_addr_pc.ELEC_ADDR_TXT
             FROM stg_permit_main stg
             LEFT OUTER JOIN wrp.QUESTION_RESULT qr
               ON qr.PERMIT_ACTION_ID = stg.PERMIT_ACTION_ID
              AND qr.QUESTION_CODE IN ('ICIS056' 
                                      ,'ICIS057'
                                      ,'ICIS058'
                                      ,'ICIS059'
                                      ,'ICIS060')
             -- --------
             -- ics_addr
             -- --------
             LEFT OUTER JOIN
                (SELECT affl.AFFILIATION_ID
                       ,affl.PERMIT_ACTION_ID
                       ,rat.ICIS_REF_AFFILIATION_TYPE  AFFIL_TYPE_TXT
                       ,org.NAME                       ORG_FRML_NAME
                       ,addr_prsd.STREET_ADDRESS       MAILING_ADDR_TXT
                       ,addr_prsd.LOCALITY             MAILING_ADDR_CITY_NAME
                       ,addr_prsd.STATE_CODE           MAILING_ADDR_ST_CODE
                       ,addr_prsd.POSTAL_CODE          MAILING_ADDR_ZIP_CODE
                       ,addr_prsd.COUNTRY_CODE         MAILING_ADDR_COUNTRY_CODE
                       ,prsn.FIRST_NAME                FIRST_NAME
                       ,prsn.LAST_NAME                 LAST_NAME
                       ,prsn.TITLE                     INDVL_TITLE_TXT
                       ,pc.VALUE                       ELEC_ADDR_TXT
                   FROM wrp.AFFILIATION affl
                   JOIN wrp.REF_AFFILIATION_TYPE rat
                     ON rat.CODE = affl.AFFILIATION_TYPE_CODE
                   LEFT OUTER JOIN wrp.ORGANIZATION org
                     ON org.ORGANIZATION_ID = affl.ORGANIZATION_ID
                   LEFT OUTER JOIN wrp.ADDRESS addr
                     ON addr.AFFILIATION_ID    = affl.AFFILIATION_ID
                    AND addr.ADDRESS_TYPE_CODE = 'MAIL'
                   LEFT OUTER JOIN wrp.ADDRESS_PARSED addr_prsd
                     ON addr_prsd.ADDRESS_ID = addr.ADDRESS_ID
                   LEFT OUTER JOIN wrp.PERSON prsn 
                     ON prsn.PERSON_ID = affl.PERSON_ID
                   LEFT OUTER JOIN wrp.PERSON_CONTACT pc
                     ON pc.PERSON_CONTACT_ID = prsn.PERSON_ID
                    AND pc.CONTACT_TYPE_CODE = 'EM'
                  WHERE rat.ICIS_REF_AFFILIATION_TYPE = 'SW4'
                ) vw_addr_pc
               ON vw_addr_pc.PERMIT_ACTION_ID = stg.PERMIT_ACTION_ID
            WHERE ICS_GNRL_PRMT_ID IS NOT NULL
              -- AND PERMIT_TYPE_CODE = 'GEN SG';
           ) vw
    GROUP BY PERMIT_ID
            ,PERMIT_ACTION_ID
            ,QUESTION_CODE
            ,PRMT_IDENT
            ,AFFIL_TYPE_TXT
            ,ORG_FRML_NAME
            ,MAILING_ADDR_TXT
            ,MAILING_ADDR_CITY_NAME
            ,MAILING_ADDR_ST_CODE
            ,MAILING_ADDR_ZIP_CODE
            ,MAILING_ADDR_COUNTRY_CODE
            ,FIRST_NAME
            ,LAST_NAME
            ,INDVL_TITLE_TXT
            ,ELEC_ADDR_TXT;
   -- -----------------------
   -- tmp_stg_swms_4_prog_rep
   -- -----------------------
   SET v_marker = 'INSERT INTO tmp_stg_swms_4_prog_rep_main';
   DROP TABLE IF EXISTS tmp_stg_swms_4_prog_rep;
   CREATE TABLE tmp_stg_swms_4_prog_rep AS
   -- INSERT INTO stg_swms4progrep_main
   SELECT vw_main.*
         ,ICS_SWMS_4_PROG_REP_ID
     FROM tmp_stg_swms_4_prog_rep_main vw_main
     LEFT OUTER JOIN 
        (SELECT UUID() ICS_SWMS_4_PROG_REP_ID
               ,PRMT_IDENT
           FROM (SELECT DISTINCT PRMT_IDENT
                   FROM tmp_stg_swms_4_prog_rep_main) vw
        ) vw_swms4
       ON vw_swms4.PRMT_IDENT = vw_main.PRMT_IDENT;
   -- -------------- --
   --  END PROCEDURE --
   -- -------------- --
   SET v_marker = 'CALL ics_etl_log_sp END';
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_sp_name     -- pi_marker
      ,NULL          -- pi_tgt_tbl
      ,NULL          -- pi_src_tbl 
      ,v_startdtm    -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'COMPLETED'   -- pi_process
      ,0);           -- pi_value
   --
   SET po_status = 1;
   SET po_errm   = '';
   --
END