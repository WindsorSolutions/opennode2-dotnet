USE ga_ics_flow_local;
DROP PROCEDURE IF EXISTS load_ics_sic_code_sp;
CREATE PROCEDURE load_ics_sic_code_sp
   (OUT po_status INT
   ,OUT po_errm   VARCHAR(255))
BEGIN
-- ============================================================================
-- MODIFICATION HISTORY
-- Person      Date       Comments
-- ---------   --------   -----------------------------------------------------
-- Jen Go      20120912   Created.  
--                        Sources:
--                          1) stg_permit_main/ICS_BASIC_PRMT_ID
--                          2) stg_permit_main/ICS_GNRL_PRMT_ID
--                          3) stg_permit_main/ICS_UNPRMT_FAC_ID
-- ============================================================================
   DECLARE v_startdtm   DATETIME     DEFAULT NOW();
   DECLARE v_enddtm     DATETIME;
   DECLARE v_marker     VARCHAR(255);
   DECLARE v_sp_name    VARCHAR(64)  DEFAULT 'load_ics_sic_code_sp';
   DECLARE v_tgt_tbl    VARCHAR(64)  DEFAULT 'ICS_SIC_CODE';
   DECLARE v_src_tbl    VARCHAR(64)  DEFAULT 'stg_permit_main';
   DECLARE v_rowcount   INT          DEFAULT 0;
   --
   DECLARE EXIT HANDLER FOR SQLEXCEPTION
      BEGIN  
         ROLLBACK;
         SET po_status = -1;
         SET po_errm   = v_marker;
         CALL ics_etl_log_sp    
            (v_sp_name          -- pi_sp_name
            ,v_marker           -- pi_marker
            ,v_tgt_tbl          -- pi_tgt_tbl
            ,v_src_tbl          -- pi_src_tbl
            ,v_startdtm         -- pi_startdtm
            ,NOW()              -- pi_enddtm
            ,'FAILED'           -- pi_process
            ,-1);               -- pi_value
      END;
   --
   SET v_marker  = 'INSERT INTO ICS_SIC_CODE';
   INSERT INTO ICS_SIC_CODE
      (ICS_SIC_CODE_ID
      ,ICS_FAC_ID
      ,ICS_UNPRMT_FAC_ID
      ,ICS_GNRL_PRMT_ID
      ,ICS_BASIC_PRMT_ID
      ,SIC_CODE
      ,SIC_PRIMARY_IND_CODE)
   SELECT UUID()
         ,vw.*
     FROM ( -- /ics_basic_prmt/ics_fac
           SELECT DISTINCT ICS_FAC_ID ICS_FAC_ID
                 ,NULL                ICS_UNPRMT_FAC_ID
                 ,NULL                ICS_GNRL_PRMT_ID
                 ,ICS_BASIC_PRMT_ID   ICS_BASIC_PRMT_ID
                 ,SIC_CODE
                 ,COALESCE(SIC_PRIMARY_IND_CODE,'N') SIC_PRIMARY_IND_CODE
             FROM stg_permit_main
            WHERE SIC_CODE          IS NOT NULL
              AND ICS_FAC_ID        IS NOT NULL
              AND ICS_BASIC_PRMT_ID IS NOT NULL
           UNION ALL
           -- /ics_gnrl_prmt/ics_fac
           SELECT DISTINCT ICS_FAC_ID  ICS_FAC_ID
                 ,NULL                 ICS_UNPRMT_FAC_ID
                 ,ICS_GNRL_PRMT_ID     ICS_GNRL_PRMT_ID
                 ,NULL                 ICS_BASIC_PRMT_ID
                 ,SIC_CODE
                 ,COALESCE(SIC_PRIMARY_IND_CODE,'N') SIC_PRIMARY_IND_CODE
             FROM stg_permit_main
            WHERE SIC_CODE         IS NOT NULL
              AND ICS_FAC_ID       IS NOT NULL
              AND ICS_GNRL_PRMT_ID IS NOT NULL
           UNION ALL
           -- /ics_unprmt_fac/ics_fac
           SELECT DISTINCT ICS_FAC_ID  ICS_FAC_ID
                 ,ICS_UNPRMT_FAC_ID    ICS_UNPRMT_FAC_ID
                 ,NULL                 ICS_GNRL_PRMT_ID
                 ,NULL                 ICS_BASIC_PRMT_ID
                 ,SIC_CODE
                 ,COALESCE(SIC_PRIMARY_IND_CODE,'N') SIC_PRIMARY_IND_CODE
             FROM stg_permit_main
            WHERE SIC_CODE          IS NOT NULL
              AND ICS_UNPRMT_FAC_ID IS NOT NULL
          ) vw;
/*
     FROM (SELECT DISTINCT ICS_FAC_ID
                 ,ICS_UNPRMT_FAC_ID
                 ,SIC_CODE
                 ,COALESCE(SIC_PRIMARY_IND_CODE,'N') SIC_PRIMARY_IND_CODE
             FROM stg_permit_main
            WHERE SIC_CODE   IS NOT NULL
              AND (   ICS_FAC_ID        IS NOT NULL
                   OR ICS_UNPRMT_FAC_ID IS NOT NULL)
          ) vw;
*/          
   --
   SET v_rowcount = (SELECT ROW_COUNT());
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm    -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'INSERT'      -- pi_process
      ,v_rowcount);  -- pi_value
   -- -------------- --
   --  END PROCEDURE --
   -- -------------- --
   SET v_marker = 'CALL ics_etl_log_sp END';
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_sp_name     -- pi_marker
      ,NULL          -- pi_tgt_tbl
      ,NULL          -- pi_src_tbl 
      ,v_startdtm    -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'COMPLETED'   -- pi_process
      ,0);           -- pi_value
   --
   SET po_status = 1;
   SET po_errm   = '';
   --
   --
END   