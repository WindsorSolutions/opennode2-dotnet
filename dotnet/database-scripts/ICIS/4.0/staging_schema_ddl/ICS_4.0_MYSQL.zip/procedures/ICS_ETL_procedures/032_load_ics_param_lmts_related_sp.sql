USE ga_ics_flow_local;
DROP PROCEDURE IF EXISTS load_ics_param_lmts_related_sp;
CREATE PROCEDURE load_ics_param_lmts_related_sp
   (OUT po_status INT
   ,OUT po_errm   VARCHAR(255))
BEGIN
-- ============================================================================
-- MODIFICATION HISTORY
-- Person      Date       Comments
-- ---------   --------   -----------------------------------------------------
-- Jen Go      20120918   Created.  
--                        Populate the following tables
--                           1) ICS_PARAM_LMTS
--                           2) ICS_LMT
--                           3) ICS_MN_LMT_APPLIES
--                           4) ICS_NUM_COND
-- ============================================================================s
   DECLARE v_startdtm   DATETIME     DEFAULT NOW();
   DECLARE v_startdtm2
          ,v_enddtm     DATETIME;
   DECLARE v_marker     VARCHAR(255);
   DECLARE v_sp_name    VARCHAR(64)  DEFAULT 'load_ics_param_lmts_related_sp';
   DECLARE v_tgt_tbl    VARCHAR(64);
   DECLARE v_src_tbl    VARCHAR(64);
   DECLARE v_rowcount   INT          DEFAULT 0;
   --
   DECLARE EXIT HANDLER FOR SQLEXCEPTION
      BEGIN  
         ROLLBACK;
         SET po_status = -1;
         SET po_errm   = v_marker;
         CALL ics_etl_log_sp    
            (v_sp_name          -- pi_sp_name
            ,v_marker           -- pi_marker
            ,v_tgt_tbl          -- pi_tgt_tbl
            ,v_src_tbl          -- pi_src_tbl
            ,v_startdtm         -- pi_startdtm
            ,NOW()              -- pi_enddtm
            ,'FAILED'           -- pi_process
            ,-1);               -- pi_value
      END;
   -- -----------------------
   -- tmp_stg_paramlmts_main
   -- -----------------------
   SET v_marker = 'DROP AND CREATE TABLE tmp_stg_paramlmts_main';
   DROP TABLE IF EXISTS tmp_stg_paramlmts_main;
   CREATE TABLE `tmp_stg_paramlmts_main` AS
   SELECT stg_lmt.ICS_LMT_SET_ID
         ,stg_lmt.PRMT_IDENT
         ,stg_lmt.PRMT_FEATR_IDENT
         ,stg_lmt.LMT_SET_DESIGNATOR
         ,stg_lmt.PARAM_CODE
         ,stg_lmt.MON_SITE_DESC_CODE
         ,stg_lmt.SEASON_NUMBER
         -- -------
         -- ics_lmt
         -- -------
         ,stg_lmt.LMT_BEGIN_DATE
         ,stg_lmt.LMT_END_DATE
         ,stg_lmt.LMT_TYPE_CODE
         ,stg_lmt.SMPL_TYPE_TXT
         ,stg_lmt.FREQ_OF_ANALYSIS_CODE
         -- Calculate and persist in LIMIT when a limit is modified
         -- in the GUI. If modified and no modification for the permit, use 'PAC'
         ,rpat.ICIS_REF_MODIFICATION_TYPE    LMT_MOD_TYPE_CODE
         ,pa.EFFECTIVE_DATE                  LMT_MOD_EFFECTIVE_DATE
         ,stg_lmt.CONCEN_NUM_COND_UNIT_MEAS_CODE
         ,stg_lmt.QTY_NUM_COND_UNIT_MEAS_CODE
         -- ------------
         -- ics_num_cond
         -- ------------
         ,lmt_val.VALUE_TYPE_CODE            NUM_COND_TXT
         ,lmt_val.VALUE                      NUM_COND_QTY
         ,lmt_val.STATISTICAL_BASE_TYPE_CODE NUM_COND_STAT_BASE_CODE
         ,rvqt.ICIS_CODE                     NUM_COND_QUALIFIER
         ,CASE WHEN lmt_val.IS_OPTIONAL = 1 THEN 'Y' 
          ELSE 'N' END                       NUM_COND_OPT_MON_IND
         ,stg_lmt.LIMIT_ID
     FROM (SELECT DISTINCT stg.ICS_LMT_SET_ID
                 ,stg.PRMT_IDENT
                 ,stg.PRMT_FEATR_IDENT
                 ,stg.LMT_SET_DESIGNATOR
                 ,lmt.PARAMETER_CODE                 PARAM_CODE
                 ,lmt.MONITORING_LOCATION_TYPE_CODE  MON_SITE_DESC_CODE
                 ,lmt.SEASON_NUMBER                  SEASON_NUMBER
                 ,lmt.BEGIN_DATE                     LMT_BEGIN_DATE
                 ,lmt.END_DATE                       LMT_END_DATE
                 ,lmt.LIMIT_TYPE_CODE                LMT_TYPE_CODE
                 ,lmt.SAMPLE_TYPE_CODE               SMPL_TYPE_TXT
                 ,lmt.SAMPLE_FREQUENCY_TYPE_CODE     FREQ_OF_ANALYSIS_CODE
                 ,lmt.UNIT_CODE_C                    CONCEN_NUM_COND_UNIT_MEAS_CODE
                 ,lmt.UNIT_CODE_Q                    QTY_NUM_COND_UNIT_MEAS_CODE
                 --
                 ,stg.LIMIT_SET_ID
                 ,stg.PERMIT_ACTION_ID
                 ,lmt.LIMIT_ID
             FROM wrp.`LIMIT` lmt
             JOIN tmp_stg_lmt_set stg
               ON stg.LIMIT_SET_ID = lmt.LIMIT_SET_ID) stg_lmt
     LEFT OUTER JOIN wrp.PERMIT_ACTION pa
       ON pa.PERMIT_ACTION_ID = stg_lmt.PERMIT_ACTION_ID
     LEFT OUTER JOIN wrp.REF_PERMIT_ACTION_TYPE rpat
       ON rpat.CODE = pa.PERMIT_ACTION_TYPE_CODE
     LEFT OUTER JOIN wrp.LIMIT_VALUE lmt_val
       ON lmt_val.LIMIT_ID = stg_lmt.LIMIT_ID
     LEFT OUTER JOIN wrp.REF_VALUE_QUALIFIER_TYPE rvqt
       ON rvqt.CODE = lmt_val.VALUE_QUALIFIER_TYPE_CODE;
   --
   SET v_marker = 'CREATE INDEX tmp_idx_parms';
   CREATE INDEX tmp_idx_parms ON tmp_stg_paramlmts_main
                                    (PRMT_IDENT,PRMT_FEATR_IDENT
                                    ,LMT_SET_DESIGNATOR,PARAM_CODE
                                    ,MON_SITE_DESC_CODE,SEASON_NUMBER
                                    ,LMT_BEGIN_DATE,LMT_END_DATE);
   ANALYZE TABLE tmp_stg_paramlmts_main;
   -- ------------------
   -- tmp_stg_paramlmts
   -- ------------------
   SET v_marker = 'DROP AND CREATE TABLE tmp_stg_paramlmts';
   DROP TABLE IF EXISTS tmp_stg_paramlmts;
   CREATE TABLE tmp_stg_paramlmts AS
   SELECT vw_main.*
         ,ICS_PARAM_LMTS_ID
         ,ICS_LMT_ID
     FROM tmp_stg_paramlmts_main vw_main
     JOIN (SELECT UUID()     ICS_PARAM_LMTS_ID
                 ,PRMT_IDENT
                 ,PRMT_FEATR_IDENT
                 ,LMT_SET_DESIGNATOR
                 ,PARAM_CODE
                 ,MON_SITE_DESC_CODE
                 ,SEASON_NUMBER
             FROM (SELECT DISTINCT PRMT_IDENT
                         ,PRMT_FEATR_IDENT
                         ,LMT_SET_DESIGNATOR
                         ,PARAM_CODE
                         ,MON_SITE_DESC_CODE
                        ,SEASON_NUMBER
                     FROM tmp_stg_paramlmts_main) vw
        ) vw_params
       ON vw_params.PRMT_IDENT         = vw_main.PRMT_IDENT
      AND vw_params.PRMT_FEATR_IDENT   = vw_main.PRMT_FEATR_IDENT
      AND vw_params.LMT_SET_DESIGNATOR = vw_main.LMT_SET_DESIGNATOR
      AND vw_params.PARAM_CODE         = vw_main.PARAM_CODE
      AND vw_params.MON_SITE_DESC_CODE = vw_main.MON_SITE_DESC_CODE
      AND vw_params.SEASON_NUMBER      = vw_main.SEASON_NUMBER
     LEFT OUTER JOIN
        (SELECT UUID() ICS_LMT_ID
               ,vw.*
           FROM (SELECT DISTINCT PRMT_IDENT
                       ,PRMT_FEATR_IDENT
                       ,LMT_SET_DESIGNATOR
                       ,PARAM_CODE
                       ,MON_SITE_DESC_CODE
                       ,SEASON_NUMBER
                       ,LMT_BEGIN_DATE
                       ,LMT_END_DATE
                       ,LMT_MOD_EFFECTIVE_DATE
                       ,CONCEN_NUM_COND_UNIT_MEAS_CODE
                       ,QTY_NUM_COND_UNIT_MEAS_CODE 
                   FROM tmp_stg_paramlmts_main) vw
        ) vw_lmt
       ON vw_lmt.PRMT_IDENT         = vw_main.PRMT_IDENT
      AND vw_lmt.PRMT_FEATR_IDENT   = vw_main.PRMT_FEATR_IDENT
      AND vw_lmt.LMT_SET_DESIGNATOR = vw_main.LMT_SET_DESIGNATOR
      AND vw_lmt.PARAM_CODE         = vw_main.PARAM_CODE
      AND vw_lmt.MON_SITE_DESC_CODE = vw_main.MON_SITE_DESC_CODE
      AND vw_lmt.SEASON_NUMBER      = vw_main.SEASON_NUMBER
      AND vw_lmt.LMT_BEGIN_DATE     = vw_main.LMT_BEGIN_DATE
      AND vw_lmt.LMT_END_DATE       = vw_main.LMT_END_DATE
      AND COALESCE(vw_lmt.LMT_MOD_EFFECTIVE_DATE,'1900-01-01') = COALESCE(vw_main.LMT_MOD_EFFECTIVE_DATE,'1900-01-01')
      AND COALESCE(vw_lmt.CONCEN_NUM_COND_UNIT_MEAS_CODE,'X')  = COALESCE(vw_main.CONCEN_NUM_COND_UNIT_MEAS_CODE,'X')
      AND COALESCE(vw_lmt.QTY_NUM_COND_UNIT_MEAS_CODE,'X')     = COALESCE(vw_main.QTY_NUM_COND_UNIT_MEAS_CODE,'X');
   --
   SET v_marker = 'CREATE INDEX tmp_idx_stgparm_lmtid';
   CREATE INDEX tmp_idx_stgparm_lmtid ON tmp_stg_paramlmts(LIMIT_ID);
   ANALYZE TABLE tmp_stg_paramlmts;
   -- --------------
   -- ICS_PARAM_LMTS
   -- --------------
   SET v_startdtm2 = NOW();
   SET v_src_tbl   = 'tmp_stg_paramlmts';
   SET v_tgt_tbl   = 'ICS_PARAM_LMTS';
   SET v_marker    = 'INSERT INTO ICS_PARAM_LMTS';
   INSERT INTO ICS_PARAM_LMTS
      (ICS_PARAM_LMTS_ID
      ,ICS_PAYLOAD_ID
      ,PRMT_IDENT
      ,PRMT_FEATR_IDENT
      ,LMT_SET_DESIGNATOR
      ,PARAM_CODE
      ,MON_SITE_DESC_CODE
      ,LMT_SEASON_NUM)
   SELECT DISTINCT ICS_PARAM_LMTS_ID
         ,'ParameterLimits'
         ,PRMT_IDENT
         ,PRMT_FEATR_IDENT
         ,LMT_SET_DESIGNATOR
         ,PARAM_CODE
         ,MON_SITE_DESC_CODE
         ,SEASON_NUMBER
     FROM tmp_stg_paramlmts;
   --
   SET v_rowcount = (SELECT ROW_COUNT());
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'INSERT'      -- pi_process
      ,v_rowcount);  -- pi_value
   -- -------
   -- ICS_LMT
   -- -------
   SET v_startdtm2 = NOW();
   SET v_src_tbl   = 'tmp_stg_paramlmts';
   SET v_tgt_tbl   = 'ICS_LMT';
   SET v_marker    = 'INSERT INTO ICS_LMT';
   INSERT INTO ICS_LMT
      (ICS_LMT_ID
      ,ICS_PARAM_LMTS_ID
      ,LMT_START_DATE
      ,LMT_END_DATE
      ,LMT_TYPE_CODE
      ,SMPL_TYPE_TXT
      ,FREQ_OF_ANALYSIS_CODE
      ,LMT_MOD_TYPE_CODE
      ,LMT_MOD_EFFECTIVE_DATE
      -- ,LMTS_USR_DFND_FLD_1
      -- ,LMTS_USR_DFND_FLD_2
      -- ,LMTS_USR_DFND_FLD_3
      ,CONCEN_NUM_COND_UNIT_MEAS_CODE
      ,QTY_NUM_COND_UNIT_MEAS_CODE)
   SELECT DISTINCT ICS_LMT_ID
         ,ICS_PARAM_LMTS_ID
         ,LMT_BEGIN_DATE -- LMT_START_DATE
         ,LMT_END_DATE
         ,LMT_TYPE_CODE
         ,SMPL_TYPE_TXT
         ,FREQ_OF_ANALYSIS_CODE
         ,LMT_MOD_TYPE_CODE
         ,LMT_MOD_EFFECTIVE_DATE
         -- ,LMTS_USR_DFND_FLD_1
         -- ,LMTS_USR_DFND_FLD_2
         -- ,LMTS_USR_DFND_FLD_3
         ,CONCEN_NUM_COND_UNIT_MEAS_CODE
         ,QTY_NUM_COND_UNIT_MEAS_CODE
     FROM tmp_stg_paramlmts; 
   --
   SET v_rowcount = (SELECT ROW_COUNT());
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'INSERT'      -- pi_process
      ,v_rowcount);  -- pi_value
   -- ------------------
   -- ICS_MN_LMT_APPLIES
   -- ------------------
   SET v_startdtm2 = NOW();
   SET v_src_tbl   = 'tmp_paramlmts';
   SET v_tgt_tbl   = 'ICS_MN_LMT_APPLIES';
   SET v_marker    = 'INSERT INTO ICS_MN_LMT_APPLIES';
   INSERT INTO ICS_MN_LMT_APPLIES
      (ICS_MN_LMT_APPLIES_ID
      ,ICS_LMT_ID
      ,MN_LMT_APPLIES)
   SELECT UUID()
         ,ICS_LMT_ID
         ,MONTH_NAME
     FROM (SELECT DISTINCT stg.ICS_LMT_ID
                 ,MONTH_NAME
             FROM tmp_stg_paramlmts stg
             JOIN (SELECT LIMIT_ID,MONTH_NUMBER
                         ,CASE WHEN MONTH_NUMBER = 1  THEN 'JAN'
                          WHEN MONTH_NUMBER = 2  THEN 'FEB'
                          WHEN MONTH_NUMBER = 3  THEN 'MAR'
                          WHEN MONTH_NUMBER = 4  THEN 'APR'
                          WHEN MONTH_NUMBER = 5  THEN 'MAY'
                          WHEN MONTH_NUMBER = 6  THEN 'JUN'
                          WHEN MONTH_NUMBER = 7  THEN 'JUL'
                          WHEN MONTH_NUMBER = 8  THEN 'AUG'
                          WHEN MONTH_NUMBER = 9  THEN 'SEP'
                          WHEN MONTH_NUMBER = 10 THEN 'OCT'
                          WHEN MONTH_NUMBER = 11 THEN 'NOV'
                          WHEN MONTH_NUMBER = 12 THEN 'DEC'
                          END    MONTH_NAME
                     FROM wrp.LIMIT_REQ_IN_MONTHS) vw_lrim
               ON vw_lrim.LIMIT_ID = stg.LIMIT_ID) vw;
   --
   SET v_rowcount = (SELECT ROW_COUNT());
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'INSERT'      -- pi_process
      ,v_rowcount);  -- pi_value
   -- ------------
   -- ICS_NUM_COND
   -- ------------
   SET v_startdtm2 = NOW();
   SET v_src_tbl   = 'tmp_paramlmts';
   SET v_tgt_tbl   = 'ICS_NUM_COND';
   SET v_marker    = 'INSERT INTO ICS_NUM_COND';
   INSERT INTO ICS_NUM_COND
      (ICS_NUM_COND_ID
      ,ICS_LMT_ID
      ,NUM_COND_TXT
      ,NUM_COND_QTY
      ,NUM_COND_STAT_BASE_CODE
      ,NUM_COND_QUALIFIER
      ,NUM_COND_OPT_MON_IND)
   SELECT UUID()
         ,ICS_LMT_ID
         ,NUM_COND_TXT
         ,NUM_COND_QTY
         ,NUM_COND_STAT_BASE_CODE
         ,NUM_COND_QUALIFIER
         ,NUM_COND_OPT_MON_IND
     FROM (SELECT DISTINCT ICS_LMT_ID
                 ,NUM_COND_TXT
                 ,NUM_COND_QTY
                 ,NUM_COND_STAT_BASE_CODE
                 ,NUM_COND_QUALIFIER
                 ,NUM_COND_OPT_MON_IND
             FROM tmp_stg_paramlmts
            WHERE NUM_COND_TXT IS NOT NULL) vw;
   --
   SET v_rowcount = (SELECT ROW_COUNT());
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_marker      -- pi_marker
      ,v_tgt_tbl     -- pi_tgt_tbl
      ,v_src_tbl     -- pi_src_tbl 
      ,v_startdtm2   -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'INSERT'      -- pi_process
      ,v_rowcount);  -- pi_value
   -- -------------- --
   --  END PROCEDURE --
   -- -------------- --
   SET v_marker = 'CALL ics_etl_log_sp END';
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_sp_name     -- pi_marker
      ,NULL          -- pi_tgt_tbl
      ,NULL          -- pi_src_tbl 
      ,v_startdtm    -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'COMPLETED'   -- pi_process
      ,0);           -- pi_value
   --
   SET po_status = 1;
   SET po_errm   = '';
   --

END