USE ga_ics_flow_local;
DROP PROCEDURE IF EXISTS ics_cd_process_ics_tbls;
CREATE PROCEDURE ics_cd_process_ics_tbls
   (OUT po_status INT
   ,OUT po_errm   VARCHAR(255))
BEGIN
/******************************************************************************
** ObjectName: ics_cd_process_ics_tbls
**
** Author: Windsor Solutions, Inc.
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure will detect data changes made within the ICIS 
**               schema and then sets the transaction type flags so the data 
**               can be bundled and submitted to an exchange partner.
**
** Inputs:  -- NA --  
**
**
** Revision History:      
** ----------------------------------------------------------------------------
**  Date         Analyst     Description
** ----------------------------------------------------------------------------
** 08/15/2012    BRensmith   Baseline from v3.1 procedure.
**
** 10/29/2012    Jen Go      Converted from Oracle to MySQL
**                           called by: ics_change_detection
**                             1) ics_cd_create_cdv_tables
**                             2) ics_cd_updt_ics_tables
**                             3) ics_cd_process_datahash
**                             4) ics_cd_process_ics_tbls
******************************************************************************/
   DECLARE v_startdtm                      DATETIME     DEFAULT NOW();
   DECLARE v_enddtm                        DATETIME;
   DECLARE v_sp_name                       VARCHAR(64)  DEFAULT 'ics_cd_process_ics_tbls';
   DECLARE v_loop_cntr 
          ,v_num_rows                      INT DEFAULT 0;
   DECLARE v_ics_cmpl_mon_lnk_id
          ,v_ics_dmr_prog_rep_lnk_id
          ,v_ics_enfrc_actn_viol_lnk_id    VARBINARY(36);
   DECLARE v_table_name                    VARCHAR(30);
   DECLARE v_client_prefix                 VARCHAR(3)  DEFAULT 'ga_';
   DECLARE v_schema_name                   VARCHAR(27) DEFAULT 'ics_flow_local';
   DECLARE v_marker                        VARCHAR(255);
   DECLARE v_payload_id                    VARCHAR(36);
   --
   DECLARE v_BasicPermitSubmission
          ,v_BiosolidsPermitSubmission
          ,v_BiosolidsProgramReportSubmission
          ,v_CAFOAnnualReportSubmission
          ,v_CAFOPermitSubmission
          ,v_ComplianceMonitoringSubmission
          ,v_ComplianceMonitoringLinkageSubmission
          ,v_ComplianceScheduleSubmission
          ,v_CSOEventReportSubmission
          ,v_CSOPermitSubmission
          ,v_DischargeMonitoringReportSubmission
          ,v_DMRProgramReportLinkageSubmission
          ,v_DMRViolationSubmission
          ,v_EffluentTradePartnerSubmission
          ,v_EnforcementActionMilestoneSubmission
          ,v_EnforcementActionViolationLinkageSubmission
          ,v_FinalOrderViolationLinkageSubmission
          ,v_FormalEnforcementActionSubmission
          ,v_GeneralPermitSubmission
          ,v_HistoricalPermitScheduleEventsSubmission
          ,v_InformalEnforcementActionSubmission
          ,v_LimitsSubmission
          ,v_LimitSetSubmission
          ,v_LocalLimitsProgramReportSubmission
          ,v_MasterGeneralPermitSubmission
          ,v_NarrativeConditionScheduleSubmission
          ,v_ParameterLimitsSubmission
          ,v_PermitReissuanceSubmission
          ,v_PermittedFeatureSubmission
          ,v_PermitTerminationSubmission
          ,v_PermitTrackingEventSubmission
          ,v_POTWPermitSubmission
          ,v_PretreatmentPerformanceSummarySubmission
          ,v_PretreatmentPermitSubmission
          ,v_ScheduleEventViolationSubmission
          ,v_SingleEventViolationSubmission
          ,v_SSOAnnualReportSubmission
          ,v_SSOEventReportSubmission
          ,v_SSOMonthlyEventReportSubmission
          ,v_SWConstructionPermitSubmission
          ,v_SWEventReportSubmission
          ,v_SWIndustrialPermitSubmission
          ,v_SWMS4LargePermitSubmission
          ,v_SWMS4ProgramReportSubmission
          ,v_SWMS4SmallPermitSubmission
          ,v_UnpermittedFacilitySubmission           INT DEFAULT 0;
   --
   DECLARE v_BasicPermitSubmission_PID
          ,v_BiosolidsPermitSubmission_PID
          ,v_BiosolidsProgramReportSubmission_PID
          ,v_CAFOAnnualReportSubmission_PID
          ,v_CAFOPermitSubmission_PID
          ,v_ComplianceMonitoringSubmission_PID
          ,v_ComplianceMonitoringLinkageSubmission_PID
          ,v_ComplianceScheduleSubmission_PID
          ,v_CSOEventReportSubmission_PID
          ,v_CSOPermitSubmission_PID
          ,v_DischargeMonitoringReportSubmission_PID
          ,v_DMRProgramReportLinkageSubmission_PID
          ,v_DMRViolationSubmission_PID
          ,v_EffluentTradePartnerSubmission_PID
          ,v_EnforcementActionMilestoneSubmission_PID
          ,v_EnforcementActionViolationLinkageSubmission_PID
          ,v_FinalOrderViolationLinkageSubmission_PID
          ,v_FormalEnforcementActionSubmission_PID
          ,v_GeneralPermitSubmission_PID
          ,v_HistoricalPermitScheduleEventsSubmission_PID
          ,v_InformalEnforcementActionSubmission_PID
          ,v_LimitsSubmission_PID
          ,v_LimitSetSubmission_PID
          ,v_LocalLimitsProgramReportSubmission_PID
          ,v_MasterGeneralPermitSubmission_PID
          ,v_NarrativeConditionScheduleSubmission_PID
          ,v_ParameterLimitsSubmission_PID
          ,v_PermitReissuanceSubmission_PID
          ,v_PermittedFeatureSubmission_PID
          ,v_PermitTerminationSubmission_PID
          ,v_PermitTrackingEventSubmission_PID
          ,v_POTWPermitSubmission_PID
          ,v_PretreatmentPerformanceSummarySubmission_PID
          ,v_PretreatmentPermitSubmission_PID
          ,v_ScheduleEventViolationSubmission_PID
          ,v_SingleEventViolationSubmission_PID
          ,v_SSOAnnualReportSubmission_PID
          ,v_SSOEventReportSubmission_PID
          ,v_SSOMonthlyEventReportSubmission_PID
          ,v_SWConstructionPermitSubmission_PID
          ,v_SWEventReportSubmission_PID
          ,v_SWIndustrialPermitSubmission_PID
          ,v_SWMS4LargePermitSubmission_PID
          ,v_SWMS4ProgramReportSubmission_PID
          ,v_SWMS4SmallPermitSubmission_PID
          ,v_UnpermittedFacilitySubmission_PID       VARCHAR(36);
   -- ------------------
   -- EXCEPTION HANDLING
   -- ------------------
   DECLARE EXIT HANDLER FOR SQLEXCEPTION
      BEGIN  
         ROLLBACK;
         SET po_status = -1;
         SET po_errm   = v_marker;
         CALL ics_etl_log_sp    
            (v_sp_name          -- pi_sp_name
            ,v_marker           -- pi_marker
            ,NULL               -- pi_tgt_tbl
            ,NULL               -- pi_src_tbl
            ,v_startdtm         -- pi_startdtm
            ,NOW()              -- pi_enddtm
            ,'FAILED'           -- pi_process
            ,-1);               -- pi_value
      END;
 /******************************************************************************************************************************
   ** Description:  The following code sets the new, change, replace, etc... ics transaction_type flags throughout the entire ICS 
   **               schema.  Once these flags are set the data will be marked as either new, changed and will allow the OPENNODE2 
   **               plug-in the ability to pull the data, bundle into .xml, and then submit to an exchange partner.
   ******************************************************************************************************************************/
   SELECT MAX(BasicPermitSubmission)
         ,MAX(BiosolidsPermitSubmission)
         ,MAX(BiosolidsProgramReportSubmission)
         ,MAX(CAFOAnnualReportSubmission)
         ,MAX(CAFOPermitSubmission)
         ,MAX(ComplianceMonitoringSubmission)
         ,MAX(ComplianceMonitoringLinkageSubmission)
         ,MAX(ComplianceScheduleSubmission)
         ,MAX(CSOEventReportSubmission)
         ,MAX(CSOPermitSubmission)
         ,MAX(DischargeMonitoringReportSubmission)
         ,MAX(DMRProgramReportLinkageSubmission)
         ,MAX(DMRViolationSubmission)
         ,MAX(EffluentTradePartnerSubmission)
         ,MAX(EnforcementActionMilestoneSubmission)
         ,MAX(EnforcementActionViolationLinkageSubmission)
         ,MAX(FinalOrderViolationLinkageSubmission)
         ,MAX(FormalEnforcementActionSubmission)
         ,MAX(GeneralPermitSubmission)
         ,MAX(HistoricalPermitScheduleEventsSubmission)
         ,MAX(InformalEnforcementActionSubmission)
         ,MAX(LimitsSubmission)
         ,MAX(LimitSetSubmission)
         ,MAX(LocalLimitsProgramReportSubmission)
         ,MAX(MasterGeneralPermitSubmission)
         ,MAX(NarrativeConditionScheduleSubmission)
         ,MAX(ParameterLimitsSubmission)
         ,MAX(PermitReissuanceSubmission)
         ,MAX(PermittedFeatureSubmission)
         ,MAX(PermitTerminationSubmission)
         ,MAX(PermitTrackingEventSubmission)
         ,MAX(POTWPermitSubmission)
         ,MAX(PretreatmentPerformanceSummarySubmission)
         ,MAX(PretreatmentPermitSubmission)
         ,MAX(ScheduleEventViolationSubmission)
         ,MAX(SingleEventViolationSubmission)
         ,MAX(SSOAnnualReportSubmission)
         ,MAX(SSOEventReportSubmission)
         ,MAX(SSOMonthlyEventReportSubmission)
         ,MAX(SWConstructionPermitSubmission)
         ,MAX(SWEventReportSubmission)
         ,MAX(SWIndustrialPermitSubmission)
         ,MAX(SWMS4LargePermitSubmission)
         ,MAX(SWMS4ProgramReportSubmission)
         ,MAX(SWMS4SmallPermitSubmission)
         ,MAX(UnpermittedFacilitySubmission)
         -- GET_PAYLOAD_ID
         ,MAX(BasicPermitSubmission_PID)
         ,MAX(BiosolidsPermitSubmission_PID)
         ,MAX(BiosolidsProgramReportSubmission_PID)
         ,MAX(CAFOAnnualReportSubmission_PID)
         ,MAX(CAFOPermitSubmission_PID)
         ,MAX(ComplianceMonitoringSubmission_PID)
         ,MAX(ComplianceMonitoringLinkageSubmission_PID)
         ,MAX(ComplianceScheduleSubmission_PID)
         ,MAX(CSOEventReportSubmission_PID)
         ,MAX(CSOPermitSubmission_PID)
         ,MAX(DischargeMonitoringReportSubmission_PID)
         ,MAX(DMRProgramReportLinkageSubmission_PID)
         ,MAX(DMRViolationSubmission_PID)
         ,MAX(EffluentTradePartnerSubmission_PID)
         ,MAX(EnforcementActionMilestoneSubmission_PID)
         ,MAX(EnforcementActionViolationLinkageSubmission_PID)
         ,MAX(FinalOrderViolationLinkageSubmission_PID)
         ,MAX(FormalEnforcementActionSubmission_PID)
         ,MAX(GeneralPermitSubmission_PID)
         ,MAX(HistoricalPermitScheduleEventsSubmission_PID)
         ,MAX(InformalEnforcementActionSubmission_PID)
         ,MAX(LimitsSubmission_PID)
         ,MAX(LimitSetSubmission_PID)
         ,MAX(LocalLimitsProgramReportSubmission_PID)
         ,MAX(MasterGeneralPermitSubmission_PID)
         ,MAX(NarrativeConditionScheduleSubmission_PID)
         ,MAX(ParameterLimitsSubmission_PID)
         ,MAX(PermitReissuanceSubmission_PID)
         ,MAX(PermittedFeatureSubmission_PID)
         ,MAX(PermitTerminationSubmission_PID)
         ,MAX(PermitTrackingEventSubmission_PID)
         ,MAX(POTWPermitSubmission_PID)
         ,MAX(PretreatmentPerformanceSummarySubmission_PID)
         ,MAX(PretreatmentPermitSubmission_PID)
         ,MAX(ScheduleEventViolationSubmission_PID)
         ,MAX(SingleEventViolationSubmission_PID)
         ,MAX(SSOAnnualReportSubmission_PID)
         ,MAX(SSOEventReportSubmission_PID)
         ,MAX(SSOMonthlyEventReportSubmission_PID)
         ,MAX(SWConstructionPermitSubmission_PID)
         ,MAX(SWEventReportSubmission_PID)
         ,MAX(SWIndustrialPermitSubmission_PID)
         ,MAX(SWMS4LargePermitSubmission_PID)
         ,MAX(SWMS4ProgramReportSubmission_PID)
         ,MAX(SWMS4SmallPermitSubmission_PID)
         ,MAX(UnpermittedFacilitySubmission_PID)
     INTO v_BasicPermitSubmission
         ,v_BiosolidsPermitSubmission
         ,v_BiosolidsProgramReportSubmission
         ,v_CAFOAnnualReportSubmission
         ,v_CAFOPermitSubmission
         ,v_ComplianceMonitoringSubmission
         ,v_ComplianceMonitoringLinkageSubmission
         ,v_ComplianceScheduleSubmission
         ,v_CSOEventReportSubmission
         ,v_CSOPermitSubmission
         ,v_DischargeMonitoringReportSubmission
         ,v_DMRProgramReportLinkageSubmission
         ,v_DMRViolationSubmission
         ,v_EffluentTradePartnerSubmission
         ,v_EnforcementActionMilestoneSubmission
         ,v_EnforcementActionViolationLinkageSubmission
         ,v_FinalOrderViolationLinkageSubmission
         ,v_FormalEnforcementActionSubmission
         ,v_GeneralPermitSubmission
         ,v_HistoricalPermitScheduleEventsSubmission
         ,v_InformalEnforcementActionSubmission
         ,v_LimitsSubmission
         ,v_LimitSetSubmission
         ,v_LocalLimitsProgramReportSubmission
         ,v_MasterGeneralPermitSubmission
         ,v_NarrativeConditionScheduleSubmission
         ,v_ParameterLimitsSubmission
         ,v_PermitReissuanceSubmission
         ,v_PermittedFeatureSubmission
         ,v_PermitTerminationSubmission
         ,v_PermitTrackingEventSubmission
         ,v_POTWPermitSubmission
         ,v_PretreatmentPerformanceSummarySubmission
         ,v_PretreatmentPermitSubmission
         ,v_ScheduleEventViolationSubmission
         ,v_SingleEventViolationSubmission
         ,v_SSOAnnualReportSubmission
         ,v_SSOEventReportSubmission
         ,v_SSOMonthlyEventReportSubmission
         ,v_SWConstructionPermitSubmission
         ,v_SWEventReportSubmission
         ,v_SWIndustrialPermitSubmission
         ,v_SWMS4LargePermitSubmission
         ,v_SWMS4ProgramReportSubmission
         ,v_SWMS4SmallPermitSubmission
         ,v_UnpermittedFacilitySubmission
         -- PAYLOAD_ID
         ,v_BasicPermitSubmission_PID
         ,v_BiosolidsPermitSubmission_PID
         ,v_BiosolidsProgramReportSubmission_PID
         ,v_CAFOAnnualReportSubmission_PID
         ,v_CAFOPermitSubmission_PID
         ,v_ComplianceMonitoringSubmission_PID
         ,v_ComplianceMonitoringLinkageSubmission_PID
         ,v_ComplianceScheduleSubmission_PID
         ,v_CSOEventReportSubmission_PID
         ,v_CSOPermitSubmission_PID
         ,v_DischargeMonitoringReportSubmission_PID
         ,v_DMRProgramReportLinkageSubmission_PID
         ,v_DMRViolationSubmission_PID
         ,v_EffluentTradePartnerSubmission_PID
         ,v_EnforcementActionMilestoneSubmission_PID
         ,v_EnforcementActionViolationLinkageSubmission_PID
         ,v_FinalOrderViolationLinkageSubmission_PID
         ,v_FormalEnforcementActionSubmission_PID
         ,v_GeneralPermitSubmission_PID
         ,v_HistoricalPermitScheduleEventsSubmission_PID
         ,v_InformalEnforcementActionSubmission_PID
         ,v_LimitsSubmission_PID
         ,v_LimitSetSubmission_PID
         ,v_LocalLimitsProgramReportSubmission_PID
         ,v_MasterGeneralPermitSubmission_PID
         ,v_NarrativeConditionScheduleSubmission_PID
         ,v_ParameterLimitsSubmission_PID
         ,v_PermitReissuanceSubmission_PID
         ,v_PermittedFeatureSubmission_PID
         ,v_PermitTerminationSubmission_PID
         ,v_PermitTrackingEventSubmission_PID
         ,v_POTWPermitSubmission_PID
         ,v_PretreatmentPerformanceSummarySubmission_PID
         ,v_PretreatmentPermitSubmission_PID
         ,v_ScheduleEventViolationSubmission_PID
         ,v_SingleEventViolationSubmission_PID
         ,v_SSOAnnualReportSubmission_PID
         ,v_SSOEventReportSubmission_PID
         ,v_SSOMonthlyEventReportSubmission_PID
         ,v_SWConstructionPermitSubmission_PID
         ,v_SWEventReportSubmission_PID
         ,v_SWIndustrialPermitSubmission_PID
         ,v_SWMS4LargePermitSubmission_PID
         ,v_SWMS4ProgramReportSubmission_PID
         ,v_SWMS4SmallPermitSubmission_PID
         ,v_UnpermittedFacilitySubmission_PID
     FROM (SELECT CASE WHEN OPERATION = 'BasicPermitSubmission' AND ENABLED = 'Y' THEN 1 ELSE 0 END     BasicPermitSubmission
                 ,CASE WHEN OPERATION = 'BiosolidsPermitSubmission' AND ENABLED = 'Y' THEN 1 ELSE 0 END     BiosolidsPermitSubmission
                 ,CASE WHEN OPERATION = 'BiosolidsProgramReportSubmission' AND ENABLED = 'Y' THEN 1 ELSE 0 END     BiosolidsProgramReportSubmission
                 ,CASE WHEN OPERATION = 'CAFOAnnualReportSubmission' AND ENABLED = 'Y' THEN 1 ELSE 0 END     CAFOAnnualReportSubmission
                 ,CASE WHEN OPERATION = 'CAFOPermitSubmission' AND ENABLED = 'Y' THEN 1 ELSE 0 END     CAFOPermitSubmission
                 ,CASE WHEN OPERATION = 'ComplianceMonitoringSubmission' AND ENABLED = 'Y' THEN 1 ELSE 0 END     ComplianceMonitoringSubmission
                 ,CASE WHEN OPERATION = 'ComplianceMonitoringLinkageSubmission' AND ENABLED = 'Y' THEN 1 ELSE 0 END     ComplianceMonitoringLinkageSubmission
                 ,CASE WHEN OPERATION = 'ComplianceScheduleSubmission' AND ENABLED = 'Y' THEN 1 ELSE 0 END     ComplianceScheduleSubmission
                 ,CASE WHEN OPERATION = 'CSOEventReportSubmission' AND ENABLED = 'Y' THEN 1 ELSE 0 END     CSOEventReportSubmission
                 ,CASE WHEN OPERATION = 'CSOPermitSubmission' AND ENABLED = 'Y' THEN 1 ELSE 0 END     CSOPermitSubmission
                 ,CASE WHEN OPERATION = 'DischargeMonitoringReportSubmission' AND ENABLED = 'Y' THEN 1 ELSE 0 END     DischargeMonitoringReportSubmission
                 ,CASE WHEN OPERATION = 'DMRProgramReportLinkageSubmission' AND ENABLED = 'Y' THEN 1 ELSE 0 END     DMRProgramReportLinkageSubmission
                 ,CASE WHEN OPERATION = 'DMRViolationSubmission' AND ENABLED = 'Y' THEN 1 ELSE 0 END     DMRViolationSubmission
                 ,CASE WHEN OPERATION = 'EffluentTradePartnerSubmission' AND ENABLED = 'Y' THEN 1 ELSE 0 END     EffluentTradePartnerSubmission
                 ,CASE WHEN OPERATION = 'EnforcementActionMilestoneSubmission' AND ENABLED = 'Y' THEN 1 ELSE 0 END     EnforcementActionMilestoneSubmission
                 ,CASE WHEN OPERATION = 'EnforcementActionViolationLinkageSubmission' AND ENABLED = 'Y' THEN 1 ELSE 0 END     EnforcementActionViolationLinkageSubmission
                 ,CASE WHEN OPERATION = 'FinalOrderViolationLinkageSubmission' AND ENABLED = 'Y' THEN 1 ELSE 0 END     FinalOrderViolationLinkageSubmission
                 ,CASE WHEN OPERATION = 'FormalEnforcementActionSubmission' AND ENABLED = 'Y' THEN 1 ELSE 0 END     FormalEnforcementActionSubmission
                 ,CASE WHEN OPERATION = 'GeneralPermitSubmission' AND ENABLED = 'Y' THEN 1 ELSE 0 END     GeneralPermitSubmission
                 ,CASE WHEN OPERATION = 'HistoricalPermitScheduleEventsSubmission' AND ENABLED = 'Y' THEN 1 ELSE 0 END     HistoricalPermitScheduleEventsSubmission
                 ,CASE WHEN OPERATION = 'InformalEnforcementActionSubmission' AND ENABLED = 'Y' THEN 1 ELSE 0 END     InformalEnforcementActionSubmission
                 ,CASE WHEN OPERATION = 'LimitsSubmission' AND ENABLED = 'Y' THEN 1 ELSE 0 END     LimitsSubmission
                 ,CASE WHEN OPERATION = 'LimitSetSubmission' AND ENABLED = 'Y' THEN 1 ELSE 0 END     LimitSetSubmission
                 ,CASE WHEN OPERATION = 'LocalLimitsProgramReportSubmission' AND ENABLED = 'Y' THEN 1 ELSE 0 END     LocalLimitsProgramReportSubmission
                 ,CASE WHEN OPERATION = 'MasterGeneralPermitSubmission' AND ENABLED = 'Y' THEN 1 ELSE 0 END     MasterGeneralPermitSubmission
                 ,CASE WHEN OPERATION = 'NarrativeConditionScheduleSubmission' AND ENABLED = 'Y' THEN 1 ELSE 0 END     NarrativeConditionScheduleSubmission
                 ,CASE WHEN OPERATION = 'ParameterLimitsSubmission' AND ENABLED = 'Y' THEN 1 ELSE 0 END     ParameterLimitsSubmission
                 ,CASE WHEN OPERATION = 'PermitReissuanceSubmission' AND ENABLED = 'Y' THEN 1 ELSE 0 END     PermitReissuanceSubmission
                 ,CASE WHEN OPERATION = 'PermittedFeatureSubmission' AND ENABLED = 'Y' THEN 1 ELSE 0 END     PermittedFeatureSubmission
                 ,CASE WHEN OPERATION = 'PermitTerminationSubmission' AND ENABLED = 'Y' THEN 1 ELSE 0 END     PermitTerminationSubmission
                 ,CASE WHEN OPERATION = 'PermitTrackingEventSubmission' AND ENABLED = 'Y' THEN 1 ELSE 0 END     PermitTrackingEventSubmission
                 ,CASE WHEN OPERATION = 'POTWPermitSubmission' AND ENABLED = 'Y' THEN 1 ELSE 0 END     POTWPermitSubmission
                 ,CASE WHEN OPERATION = 'PretreatmentPerformanceSummarySubmission' AND ENABLED = 'Y' THEN 1 ELSE 0 END     PretreatmentPerformanceSummarySubmission
                 ,CASE WHEN OPERATION = 'PretreatmentPermitSubmission' AND ENABLED = 'Y' THEN 1 ELSE 0 END     PretreatmentPermitSubmission
                 ,CASE WHEN OPERATION = 'ScheduleEventViolationSubmission' AND ENABLED = 'Y' THEN 1 ELSE 0 END     ScheduleEventViolationSubmission
                 ,CASE WHEN OPERATION = 'SingleEventViolationSubmission' AND ENABLED = 'Y' THEN 1 ELSE 0 END     SingleEventViolationSubmission
                 ,CASE WHEN OPERATION = 'SSOAnnualReportSubmission' AND ENABLED = 'Y' THEN 1 ELSE 0 END     SSOAnnualReportSubmission
                 ,CASE WHEN OPERATION = 'SSOEventReportSubmission' AND ENABLED = 'Y' THEN 1 ELSE 0 END     SSOEventReportSubmission
                 ,CASE WHEN OPERATION = 'SSOMonthlyEventReportSubmission' AND ENABLED = 'Y' THEN 1 ELSE 0 END     SSOMonthlyEventReportSubmission
                 ,CASE WHEN OPERATION = 'SWConstructionPermitSubmission' AND ENABLED = 'Y' THEN 1 ELSE 0 END     SWConstructionPermitSubmission
                 ,CASE WHEN OPERATION = 'SWEventReportSubmission' AND ENABLED = 'Y' THEN 1 ELSE 0 END     SWEventReportSubmission
                 ,CASE WHEN OPERATION = 'SWIndustrialPermitSubmission' AND ENABLED = 'Y' THEN 1 ELSE 0 END     SWIndustrialPermitSubmission
                 ,CASE WHEN OPERATION = 'SWMS4LargePermitSubmission' AND ENABLED = 'Y' THEN 1 ELSE 0 END     SWMS4LargePermitSubmission
                 ,CASE WHEN OPERATION = 'SWMS4ProgramReportSubmission' AND ENABLED = 'Y' THEN 1 ELSE 0 END     SWMS4ProgramReportSubmission
                 ,CASE WHEN OPERATION = 'SWMS4SmallPermitSubmission' AND ENABLED = 'Y' THEN 1 ELSE 0 END     SWMS4SmallPermitSubmission
                 ,CASE WHEN OPERATION = 'UnpermittedFacilitySubmission' AND ENABLED = 'Y' THEN 1 ELSE 0 END     UnpermittedFacilitySubmission
                 -- GET PAYLOAD ID
                 ,CASE WHEN OPERATION = 'BasicPermitSubmission' AND ENABLED = 'Y' AND AUTO_GEN_DELETES = 'Y' THEN ICS_PAYLOAD_ID ELSE NULL END     BasicPermitSubmission_PID
                 ,CASE WHEN OPERATION = 'BiosolidsPermitSubmission' AND ENABLED = 'Y' AND AUTO_GEN_DELETES = 'Y' THEN ICS_PAYLOAD_ID ELSE NULL END     BiosolidsPermitSubmission_PID
                 ,CASE WHEN OPERATION = 'BiosolidsProgramReportSubmission' AND ENABLED = 'Y' AND AUTO_GEN_DELETES = 'Y' THEN ICS_PAYLOAD_ID ELSE NULL END     BiosolidsProgramReportSubmission_PID
                 ,CASE WHEN OPERATION = 'CAFOAnnualReportSubmission' AND ENABLED = 'Y' AND AUTO_GEN_DELETES = 'Y' THEN ICS_PAYLOAD_ID ELSE NULL END     CAFOAnnualReportSubmission_PID
                 ,CASE WHEN OPERATION = 'CAFOPermitSubmission' AND ENABLED = 'Y' AND AUTO_GEN_DELETES = 'Y' THEN ICS_PAYLOAD_ID ELSE NULL END     CAFOPermitSubmission_PID
                 ,CASE WHEN OPERATION = 'ComplianceMonitoringSubmission' AND ENABLED = 'Y' AND AUTO_GEN_DELETES = 'Y' THEN ICS_PAYLOAD_ID ELSE NULL END     ComplianceMonitoringSubmission_PID
                 ,CASE WHEN OPERATION = 'ComplianceMonitoringLinkageSubmission' AND ENABLED = 'Y' AND AUTO_GEN_DELETES = 'Y' THEN ICS_PAYLOAD_ID ELSE NULL END     ComplianceMonitoringLinkageSubmission_PID
                 ,CASE WHEN OPERATION = 'ComplianceScheduleSubmission' AND ENABLED = 'Y' AND AUTO_GEN_DELETES = 'Y' THEN ICS_PAYLOAD_ID ELSE NULL END     ComplianceScheduleSubmission_PID
                 ,CASE WHEN OPERATION = 'CSOEventReportSubmission' AND ENABLED = 'Y' AND AUTO_GEN_DELETES = 'Y' THEN ICS_PAYLOAD_ID ELSE NULL END     CSOEventReportSubmission_PID
                 ,CASE WHEN OPERATION = 'CSOPermitSubmission' AND ENABLED = 'Y' AND AUTO_GEN_DELETES = 'Y' THEN ICS_PAYLOAD_ID ELSE NULL END     CSOPermitSubmission_PID
                 ,CASE WHEN OPERATION = 'DischargeMonitoringReportSubmission' AND ENABLED = 'Y' AND AUTO_GEN_DELETES = 'Y' THEN ICS_PAYLOAD_ID ELSE NULL END     DischargeMonitoringReportSubmission_PID
                 ,CASE WHEN OPERATION = 'DMRProgramReportLinkageSubmission' AND ENABLED = 'Y' AND AUTO_GEN_DELETES = 'Y' THEN ICS_PAYLOAD_ID ELSE NULL END     DMRProgramReportLinkageSubmission_PID
                 ,CASE WHEN OPERATION = 'DMRViolationSubmission' AND ENABLED = 'Y' AND AUTO_GEN_DELETES = 'Y' THEN ICS_PAYLOAD_ID ELSE NULL END     DMRViolationSubmission_PID
                 ,CASE WHEN OPERATION = 'EffluentTradePartnerSubmission' AND ENABLED = 'Y' AND AUTO_GEN_DELETES = 'Y' THEN ICS_PAYLOAD_ID ELSE NULL END     EffluentTradePartnerSubmission_PID
                 ,CASE WHEN OPERATION = 'EnforcementActionMilestoneSubmission' AND ENABLED = 'Y' AND AUTO_GEN_DELETES = 'Y' THEN ICS_PAYLOAD_ID ELSE NULL END     EnforcementActionMilestoneSubmission_PID
                 ,CASE WHEN OPERATION = 'EnforcementActionViolationLinkageSubmission' AND ENABLED = 'Y' AND AUTO_GEN_DELETES = 'Y' THEN ICS_PAYLOAD_ID ELSE NULL END     EnforcementActionViolationLinkageSubmission_PID
                 ,CASE WHEN OPERATION = 'FinalOrderViolationLinkageSubmission' AND ENABLED = 'Y' AND AUTO_GEN_DELETES = 'Y' THEN ICS_PAYLOAD_ID ELSE NULL END     FinalOrderViolationLinkageSubmission_PID
                 ,CASE WHEN OPERATION = 'FormalEnforcementActionSubmission' AND ENABLED = 'Y' AND AUTO_GEN_DELETES = 'Y' THEN ICS_PAYLOAD_ID ELSE NULL END     FormalEnforcementActionSubmission_PID
                 ,CASE WHEN OPERATION = 'GeneralPermitSubmission' AND ENABLED = 'Y' AND AUTO_GEN_DELETES = 'Y' THEN ICS_PAYLOAD_ID ELSE NULL END     GeneralPermitSubmission_PID
                 ,CASE WHEN OPERATION = 'HistoricalPermitScheduleEventsSubmission' AND ENABLED = 'Y' AND AUTO_GEN_DELETES = 'Y' THEN ICS_PAYLOAD_ID ELSE NULL END     HistoricalPermitScheduleEventsSubmission_PID
                 ,CASE WHEN OPERATION = 'InformalEnforcementActionSubmission' AND ENABLED = 'Y' AND AUTO_GEN_DELETES = 'Y' THEN ICS_PAYLOAD_ID ELSE NULL END     InformalEnforcementActionSubmission_PID
                 ,CASE WHEN OPERATION = 'LimitsSubmission' AND ENABLED = 'Y' AND AUTO_GEN_DELETES = 'Y' THEN ICS_PAYLOAD_ID ELSE NULL END     LimitsSubmission_PID
                 ,CASE WHEN OPERATION = 'LimitSetSubmission' AND ENABLED = 'Y' AND AUTO_GEN_DELETES = 'Y' THEN ICS_PAYLOAD_ID ELSE NULL END     LimitSetSubmission_PID
                 ,CASE WHEN OPERATION = 'LocalLimitsProgramReportSubmission' AND ENABLED = 'Y' AND AUTO_GEN_DELETES = 'Y' THEN ICS_PAYLOAD_ID ELSE NULL END     LocalLimitsProgramReportSubmission_PID
                 ,CASE WHEN OPERATION = 'MasterGeneralPermitSubmission' AND ENABLED = 'Y' AND AUTO_GEN_DELETES = 'Y' THEN ICS_PAYLOAD_ID ELSE NULL END     MasterGeneralPermitSubmission_PID
                 ,CASE WHEN OPERATION = 'NarrativeConditionScheduleSubmission' AND ENABLED = 'Y' AND AUTO_GEN_DELETES = 'Y' THEN ICS_PAYLOAD_ID ELSE NULL END     NarrativeConditionScheduleSubmission_PID
                 ,CASE WHEN OPERATION = 'ParameterLimitsSubmission' AND ENABLED = 'Y' AND AUTO_GEN_DELETES = 'Y' THEN ICS_PAYLOAD_ID ELSE NULL END     ParameterLimitsSubmission_PID
                 ,CASE WHEN OPERATION = 'PermitReissuanceSubmission' AND ENABLED = 'Y' AND AUTO_GEN_DELETES = 'Y' THEN ICS_PAYLOAD_ID ELSE NULL END     PermitReissuanceSubmission_PID
                 ,CASE WHEN OPERATION = 'PermittedFeatureSubmission' AND ENABLED = 'Y' AND AUTO_GEN_DELETES = 'Y' THEN ICS_PAYLOAD_ID ELSE NULL END     PermittedFeatureSubmission_PID
                 ,CASE WHEN OPERATION = 'PermitTerminationSubmission' AND ENABLED = 'Y' AND AUTO_GEN_DELETES = 'Y' THEN ICS_PAYLOAD_ID ELSE NULL END     PermitTerminationSubmission_PID
                 ,CASE WHEN OPERATION = 'PermitTrackingEventSubmission' AND ENABLED = 'Y' AND AUTO_GEN_DELETES = 'Y' THEN ICS_PAYLOAD_ID ELSE NULL END     PermitTrackingEventSubmission_PID
                 ,CASE WHEN OPERATION = 'POTWPermitSubmission' AND ENABLED = 'Y' AND AUTO_GEN_DELETES = 'Y' THEN ICS_PAYLOAD_ID ELSE NULL END     POTWPermitSubmission_PID
                 ,CASE WHEN OPERATION = 'PretreatmentPerformanceSummarySubmission' AND ENABLED = 'Y' AND AUTO_GEN_DELETES = 'Y' THEN ICS_PAYLOAD_ID ELSE NULL END     PretreatmentPerformanceSummarySubmission_PID
                 ,CASE WHEN OPERATION = 'PretreatmentPermitSubmission' AND ENABLED = 'Y' AND AUTO_GEN_DELETES = 'Y' THEN ICS_PAYLOAD_ID ELSE NULL END     PretreatmentPermitSubmission_PID
                 ,CASE WHEN OPERATION = 'ScheduleEventViolationSubmission' AND ENABLED = 'Y' AND AUTO_GEN_DELETES = 'Y' THEN ICS_PAYLOAD_ID ELSE NULL END     ScheduleEventViolationSubmission_PID
                 ,CASE WHEN OPERATION = 'SingleEventViolationSubmission' AND ENABLED = 'Y' AND AUTO_GEN_DELETES = 'Y' THEN ICS_PAYLOAD_ID ELSE NULL END     SingleEventViolationSubmission_PID
                 ,CASE WHEN OPERATION = 'SSOAnnualReportSubmission' AND ENABLED = 'Y' AND AUTO_GEN_DELETES = 'Y' THEN ICS_PAYLOAD_ID ELSE NULL END     SSOAnnualReportSubmission_PID
                 ,CASE WHEN OPERATION = 'SSOEventReportSubmission' AND ENABLED = 'Y' AND AUTO_GEN_DELETES = 'Y' THEN ICS_PAYLOAD_ID ELSE NULL END     SSOEventReportSubmission_PID
                 ,CASE WHEN OPERATION = 'SSOMonthlyEventReportSubmission' AND ENABLED = 'Y' AND AUTO_GEN_DELETES = 'Y' THEN ICS_PAYLOAD_ID ELSE NULL END     SSOMonthlyEventReportSubmission_PID
                 ,CASE WHEN OPERATION = 'SWConstructionPermitSubmission' AND ENABLED = 'Y' AND AUTO_GEN_DELETES = 'Y' THEN ICS_PAYLOAD_ID ELSE NULL END     SWConstructionPermitSubmission_PID
                 ,CASE WHEN OPERATION = 'SWEventReportSubmission' AND ENABLED = 'Y' AND AUTO_GEN_DELETES = 'Y' THEN ICS_PAYLOAD_ID ELSE NULL END     SWEventReportSubmission_PID
                 ,CASE WHEN OPERATION = 'SWIndustrialPermitSubmission' AND ENABLED = 'Y' AND AUTO_GEN_DELETES = 'Y' THEN ICS_PAYLOAD_ID ELSE NULL END     SWIndustrialPermitSubmission_PID
                 ,CASE WHEN OPERATION = 'SWMS4LargePermitSubmission' AND ENABLED = 'Y' AND AUTO_GEN_DELETES = 'Y' THEN ICS_PAYLOAD_ID ELSE NULL END     SWMS4LargePermitSubmission_PID
                 ,CASE WHEN OPERATION = 'SWMS4ProgramReportSubmission' AND ENABLED = 'Y' AND AUTO_GEN_DELETES = 'Y' THEN ICS_PAYLOAD_ID ELSE NULL END     SWMS4ProgramReportSubmission_PID
                 ,CASE WHEN OPERATION = 'SWMS4SmallPermitSubmission' AND ENABLED = 'Y' AND AUTO_GEN_DELETES = 'Y' THEN ICS_PAYLOAD_ID ELSE NULL END     SWMS4SmallPermitSubmission_PID
                 ,CASE WHEN OPERATION = 'UnpermittedFacilitySubmission' AND ENABLED = 'Y' AND AUTO_GEN_DELETES = 'Y' THEN ICS_PAYLOAD_ID ELSE NULL END     UnpermittedFacilitySubmission_PID
             FROM ICS_PAYLOAD ) vw;
   -- =============================================
   -- ICS_BASIC_PRMT - Set New/Replace Transactions
   -- =============================================
   SET v_marker = 'UPDATE ICS_BASIC_PRMT - Set New/Replace Transactions';
   UPDATE ICS_BASIC_PRMT
      SET ICS_BASIC_PRMT.TRANSACTION_TYPE = (SELECT CASE CDV_BASIC_PRMT.ACTION_CODE
                                                       WHEN 1 THEN 'N'
                                                       WHEN 2 THEN 'R'
                                                    END AS TRANSACTION_TYPE
                                               FROM CDV_BASIC_PRMT
                                              WHERE CDV_BASIC_PRMT.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
                                                AND v_BasicPermitSubmission = 1);
   -- ==========================================
   -- ICS_BS_PRMT - Set New/Replace Transactions
   -- ==========================================
   SET v_marker = 'UPDATE ICS_BS_PRMT - Set New/Replace Transactions';
   UPDATE ICS_BS_PRMT
      SET ICS_BS_PRMT.TRANSACTION_TYPE = (SELECT CASE CDV_BS_PRMT.ACTION_CODE
                                                    WHEN 1 THEN 'N'
                                                    WHEN 2 THEN 'R'
                                                 END AS TRANSACTION_TYPE
                                            FROM CDV_BS_PRMT
                                           WHERE CDV_BS_PRMT.KEY_HASH = ICS_BS_PRMT.KEY_HASH
                                             AND v_BiosolidsPermitSubmission = 1);
   -- ============================================
   -- ICS_CAFO_PRMT - Set New/Replace Transactions
   -- ============================================
   SET v_marker = 'UPDATE ICS_CAFO_PRMT - Set New/Replace Transactions';
   UPDATE ICS_CAFO_PRMT
      SET ICS_CAFO_PRMT.TRANSACTION_TYPE = (SELECT CASE CDV_CAFO_PRMT.ACTION_CODE
                                                      WHEN 1 THEN 'N'
                                                      WHEN 2 THEN 'R'
                                                   END AS TRANSACTION_TYPE
                                              FROM CDV_CAFO_PRMT
                                             WHERE CDV_CAFO_PRMT.KEY_HASH = ICS_CAFO_PRMT.KEY_HASH
                                               AND v_CAFOPermitSubmission = 1);
   -- ===========================================
   -- ICS_CSO_PRMT - Set New/Replace Transactions
   -- ===========================================
   SET v_marker = 'UPDATE ICS_CSO_PRMT - Set New/Replace Transactions';
   UPDATE ICS_CSO_PRMT
      SET ICS_CSO_PRMT.TRANSACTION_TYPE = (SELECT CASE CDV_CSO_PRMT.ACTION_CODE
                                                     WHEN 1 THEN 'N'
                                                     WHEN 2 THEN 'R'
                                                  END AS TRANSACTION_TYPE
                                             FROM CDV_CSO_PRMT
                                            WHERE CDV_CSO_PRMT.KEY_HASH = ICS_CSO_PRMT.KEY_HASH
                                              AND v_CSOPermitSubmission = 1);
   -- ===========================================
   -- ICS_CMPL_MON - Set New/Replace Transactions
   -- ===========================================
   SET v_marker = 'UPDATE ICS_CMPL_MON - Set New/Replace Transactions';
   UPDATE ICS_CMPL_MON
      SET ICS_CMPL_MON.TRANSACTION_TYPE = (SELECT CASE CDV_CMPL_MON.ACTION_CODE
                                                     WHEN 1 THEN 'N'
                                                     WHEN 2 THEN 'R'
                                                  END AS TRANSACTION_TYPE
                                             FROM CDV_CMPL_MON
                                            WHERE CDV_CMPL_MON.KEY_HASH = ICS_CMPL_MON.KEY_HASH
                                              AND v_ComplianceMonitoringSubmission = 1);
   -- ============================================
   -- ICS_GNRL_PRMT - Set New/Replace Transactions
   -- =============================================
   SET v_marker = 'UPDATE ICS_GNRL_PRMT - Set New/Replace Transactions';
   UPDATE ICS_GNRL_PRMT
      SET ICS_GNRL_PRMT.TRANSACTION_TYPE = (SELECT CASE CDV_GNRL_PRMT.ACTION_CODE
                                                      WHEN 1 THEN 'N'
                                                      WHEN 2 THEN 'R'
                                                   END AS TRANSACTION_TYPE
                                              FROM CDV_GNRL_PRMT
                                             WHERE CDV_GNRL_PRMT.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
                                               AND v_GeneralPermitSubmission = 1);
   -- ===================================================
   -- ICS_MASTER_GNRL_PRMT - Set New/Replace Transactions
   -- ===================================================
   SET v_marker = 'UPDATE ICS_MASTER_GNRL_PRMT - Set New/Replace Transactions';
   UPDATE ICS_MASTER_GNRL_PRMT
      SET ICS_MASTER_GNRL_PRMT.TRANSACTION_TYPE = (SELECT CASE CDV_MASTER_GNRL_PRMT.ACTION_CODE
                                                             WHEN 1 THEN 'N'
                                                             WHEN 2 THEN 'R'
                                                          END AS TRANSACTION_TYPE
                                                     FROM CDV_MASTER_GNRL_PRMT
                                                    WHERE CDV_MASTER_GNRL_PRMT.KEY_HASH = ICS_MASTER_GNRL_PRMT.KEY_HASH
                                                      AND v_MasterGeneralPermitSubmission = 1);
   -- ==============================================
   -- ICS_PRMT_REISSU - Set New/Replace Transactions
   -- ==============================================
   SET v_marker = 'UPDATE ICS_PRMT_REISSU - Set New/Replace Transactions';
   UPDATE ICS_PRMT_REISSU
      SET ICS_PRMT_REISSU.TRANSACTION_TYPE = (SELECT CASE CDV_PRMT_REISSU.ACTION_CODE
                                                        WHEN 1 THEN 'C'
                                                        WHEN 2 THEN 'C'
                                                     END AS TRANSACTION_TYPE
                                                FROM CDV_PRMT_REISSU
                                               WHERE CDV_PRMT_REISSU.KEY_HASH = ICS_PRMT_REISSU.KEY_HASH
                                                 AND v_PermitReissuanceSubmission = 1);
   -- ============================================
   -- ICS_PRMT_TERM - Set New/Replace Transactions
   -- ============================================
   SET v_marker = 'UPDATE ICS_PRMT_TERM - Set New/Replace Transactions';
   UPDATE ICS_PRMT_TERM
     SET ICS_PRMT_TERM.TRANSACTION_TYPE = (SELECT CASE CDV_PRMT_TERM.ACTION_CODE
                                                     WHEN 1 THEN 'C'
                                                     WHEN 2 THEN 'C'
                                                  END AS TRANSACTION_TYPE
                                             FROM CDV_PRMT_TERM
                                            WHERE CDV_PRMT_TERM.KEY_HASH = ICS_PRMT_TERM.KEY_HASH
                                              AND v_PermitTerminationSubmission = 1);
   -- =================================================
   -- ICS_PRMT_TRACK_EVT - Set New/Replace Transactions
   -- =================================================
   SET v_marker = 'UPDATE ICS_PRMT_TRACK_EVT - Set New/Replace Transactions';
   UPDATE ICS_PRMT_TRACK_EVT
      SET ICS_PRMT_TRACK_EVT.TRANSACTION_TYPE = (SELECT CASE CDV_PRMT_TRACK_EVT.ACTION_CODE
                                                           WHEN 1 THEN 'N'
                                                           WHEN 2 THEN 'R'
                                                        END AS TRANSACTION_TYPE
                                                   FROM CDV_PRMT_TRACK_EVT
                                                  WHERE CDV_PRMT_TRACK_EVT.KEY_HASH = ICS_PRMT_TRACK_EVT.KEY_HASH
                                                    AND v_PermitTrackingEventSubmission = 1);
   -- ============================================
   -- ICS_POTW_PRMT - Set New/Replace Transactions
   -- ============================================
   SET v_marker = 'UPDATE ICS_POTW_PRMT - Set New/Replace Transactions';
   UPDATE ICS_POTW_PRMT
      SET ICS_POTW_PRMT.TRANSACTION_TYPE = (SELECT CASE CDV_POTW_PRMT.ACTION_CODE
                                                       WHEN 1 THEN 'N'
                                                       WHEN 2 THEN 'R'
                                                   END AS TRANSACTION_TYPE
                                              FROM CDV_POTW_PRMT
                                             WHERE CDV_POTW_PRMT.KEY_HASH = ICS_POTW_PRMT.KEY_HASH
                                               AND v_POTWPermitSubmission = 1);
   -- ===================================================
   -- ICS_PRETR_PRMT - Set New/Replace Transactions
   -- ===================================================
   SET v_marker = 'UPDATE ICS_PRETR_PRMT - Set New/Replace Transactions';
   UPDATE ICS_PRETR_PRMT
      SET ICS_PRETR_PRMT.TRANSACTION_TYPE = (SELECT CASE CDV_PRETR_PRMT.ACTION_CODE
                                                       WHEN 1 THEN 'N'
                                                       WHEN 2 THEN 'R'
                                                    END AS TRANSACTION_TYPE
                                               FROM CDV_PRETR_PRMT
                                              WHERE CDV_PRETR_PRMT.KEY_HASH = ICS_PRETR_PRMT.KEY_HASH
                                                AND v_PretreatmentPermitSubmission = 1);
   -- ===================================================
   -- ICS_SW_CNST_PRMT - Set New/Replace Transactions
   -- ===================================================
   SET v_marker = 'UPDATE ICS_SW_CNST_PRMT - Set New/Replace Transactions';
   UPDATE ICS_SW_CNST_PRMT
      SET ICS_SW_CNST_PRMT.TRANSACTION_TYPE = (SELECT CASE CDV_SW_CNST_PRMT.ACTION_CODE
                                                         WHEN 1 THEN 'N'
                                                         WHEN 2 THEN 'R'
                                                      END AS TRANSACTION_TYPE
                                                 FROM CDV_SW_CNST_PRMT
                                                WHERE CDV_SW_CNST_PRMT.KEY_HASH = ICS_SW_CNST_PRMT.KEY_HASH
                                                  AND v_SWConstructionPermitSubmission = 1);
   -- ===================================================
   -- ICS_SW_INDST_PRMT - Set New/Replace Transactions
   -- ===================================================
   SET v_marker = 'UPDATE ICS_SW_INDST_PRMT - Set New/Replace Transactions';
   UPDATE ICS_SW_INDST_PRMT
      SET ICS_SW_INDST_PRMT.TRANSACTION_TYPE = (SELECT CASE CDV_SW_INDST_PRMT.ACTION_CODE
                                                          WHEN 1 THEN 'N'
                                                          WHEN 2 THEN 'R'
                                                       END AS TRANSACTION_TYPE
                                                  FROM CDV_SW_INDST_PRMT
                                                 WHERE CDV_SW_INDST_PRMT.KEY_HASH = ICS_SW_INDST_PRMT.KEY_HASH
                                                   AND v_SWIndustrialPermitSubmission = 1);
   -- ====================================================
   -- ICS_SWMS_4_LARGE_PRMT - Set New/Replace Transactions
   -- ====================================================
   SET v_marker = 'UPDATE ICS_SWMS_4_LARGE_PRMT - Set New/Replace Transactions';
   UPDATE ICS_SWMS_4_LARGE_PRMT
      SET ICS_SWMS_4_LARGE_PRMT.TRANSACTION_TYPE = (SELECT CASE CDV_SWMS_4_LARGE_PRMT.ACTION_CODE
                                                              WHEN 1 THEN 'N'
                                                              WHEN 2 THEN 'R'
                                                           END AS TRANSACTION_TYPE
                                                      FROM CDV_SWMS_4_LARGE_PRMT
                                                     WHERE CDV_SWMS_4_LARGE_PRMT.KEY_HASH = ICS_SWMS_4_LARGE_PRMT.KEY_HASH
                                                       AND v_SWMS4LargePermitSubmission = 1);
   -- ====================================================
   -- ICS_SWMS_4_SMALL_PRMT - Set New/Replace Transactions
   -- ====================================================
   SET v_marker = 'UPDATE ICS_SWMS_4_SMALL_PRMT - Set New/Replace Transactions';
   UPDATE ICS_SWMS_4_SMALL_PRMT
      SET ICS_SWMS_4_SMALL_PRMT.TRANSACTION_TYPE = (SELECT CASE CDV_SWMS_4_SMALL_PRMT.ACTION_CODE
                                                              WHEN 1 THEN 'N'
                                                              WHEN 2 THEN 'R'
                                                           END AS TRANSACTION_TYPE
                                                      FROM CDV_SWMS_4_SMALL_PRMT
                                                     WHERE CDV_SWMS_4_SMALL_PRMT.KEY_HASH = ICS_SWMS_4_SMALL_PRMT.KEY_HASH
                                                       AND v_SWMS4SmallPermitSubmission = 1);
   -- ====================================================
   -- ICS_UNPRMT_FAC - Set New/Replace Transactions
   -- ====================================================
   SET v_marker = 'UPDATE ICS_UNPRMT_FAC - Set New/Replace Transactions';
   UPDATE ICS_UNPRMT_FAC
      SET ICS_UNPRMT_FAC.TRANSACTION_TYPE = (SELECT CASE CDV_UNPRMT_FAC.ACTION_CODE
                                                       WHEN 1 THEN 'N'
                                                       WHEN 2 THEN 'R'
                                                    END AS TRANSACTION_TYPE
                                               FROM CDV_UNPRMT_FAC
                                              WHERE CDV_UNPRMT_FAC.KEY_HASH = ICS_UNPRMT_FAC.KEY_HASH
                                                AND v_UnpermittedFacilitySubmission = 1);
   -- ======================================================
   -- ICS_HIST_PRMT_SCHD_EVTS - Set New/Replace Transactions
   -- ======================================================
   SET v_marker = 'UPDATE ICS_HIST_PRMT_SCHD_EVTS - Set New/Replace Transactions';
   UPDATE ICS_HIST_PRMT_SCHD_EVTS
      SET ICS_HIST_PRMT_SCHD_EVTS.TRANSACTION_TYPE = (SELECT CASE CDV_HIST_PRMT_SCHD_EVTS.ACTION_CODE
                                                                WHEN 1 THEN 'C'
                                                                WHEN 2 THEN 'C'
                                                             END AS TRANSACTION_TYPE
                                                        FROM CDV_HIST_PRMT_SCHD_EVTS
                                                       WHERE CDV_HIST_PRMT_SCHD_EVTS.KEY_HASH = ICS_HIST_PRMT_SCHD_EVTS.KEY_HASH
                                                         AND v_HistoricalPermitScheduleEventsSubmission = 1);
   -- ======================================================
   -- ICS_NARR_COND_SCHD - Set New/Replace Transactions
   -- ======================================================
   SET v_marker = 'UPDATE ICS_NARR_COND_SCHD - Set New/Replace Transactions';
   UPDATE ICS_NARR_COND_SCHD
      SET ICS_NARR_COND_SCHD.TRANSACTION_TYPE = (SELECT CASE CDV_NARR_COND_SCHD.ACTION_CODE
                                                           WHEN 1 THEN 'R'
                                                           WHEN 2 THEN 'R'
                                                        END AS TRANSACTION_TYPE
                                                   FROM CDV_NARR_COND_SCHD
                                                  WHERE CDV_NARR_COND_SCHD.KEY_HASH = ICS_NARR_COND_SCHD.KEY_HASH
                                                    AND v_NarrativeConditionScheduleSubmission = 1);
   -- ======================================================
   -- ICS_PRMT_FEATR - Set New/Replace Transactions
   -- ======================================================
   SET v_marker = 'UPDATE ICS_PRMT_FEATR - Set New/Replace Transactions';
   UPDATE ICS_PRMT_FEATR
      SET ICS_PRMT_FEATR.TRANSACTION_TYPE = (SELECT CASE CDV_PRMT_FEATR.ACTION_CODE
                                                       WHEN 1 THEN 'N'
                                                       WHEN 2 THEN 'R'
                                                    END AS TRANSACTION_TYPE
                                               FROM CDV_PRMT_FEATR
                                              WHERE CDV_PRMT_FEATR.KEY_HASH = ICS_PRMT_FEATR.KEY_HASH
                                                AND v_PermittedFeatureSubmission = 1);
   -- ======================================================
   -- ICS_LMT_SET - Set New/Replace Transactions
   -- ======================================================
   SET v_marker = 'UPDATE ICS_LMT_SET - Set New/Replace Transactions';
   UPDATE ICS_LMT_SET
      SET ICS_LMT_SET.TRANSACTION_TYPE = (SELECT CASE CDV_LMT_SET.ACTION_CODE
                                                    WHEN 1 THEN 'N'
                                                    WHEN 2 THEN 'R'
                                                 END AS TRANSACTION_TYPE
                                            FROM CDV_LMT_SET
                                           WHERE CDV_LMT_SET.KEY_HASH = ICS_LMT_SET.KEY_HASH
                                             AND v_LimitSetSubmission = 1);
   -- ======================================================
   -- ICS_LMTS - Set New/Replace Transactions
   -- ======================================================
   SET v_marker = 'UPDATE ICS_LMTS - Set New/Replace Transactions';
  UPDATE ICS_LMTS
     SET ICS_LMTS.TRANSACTION_TYPE = (SELECT CASE CDV_LMTS.ACTION_CODE
                                                       WHEN 1 THEN 'N'
                                                       WHEN 2 THEN 'C'
                                                      END AS TRANSACTION_TYPE
                                                FROM CDV_LMTS
                                               WHERE CDV_LMTS.KEY_HASH = ICS_LMTS.KEY_HASH
                                                 AND v_LimitsSubmission = 1);
   -- ======================================================
   -- ICS_PARAM_LMTS - Set New/Replace Transactions
   -- ======================================================
   SET v_marker = 'UPDATE ICS_PARAM_LMTS - Set New/Replace Transactions';
   UPDATE ICS_PARAM_LMTS
      SET ICS_PARAM_LMTS.TRANSACTION_TYPE = (SELECT CASE CDV_PARAM_LMTS.ACTION_CODE
                                                       WHEN 1 THEN 'R'
                                                       WHEN 2 THEN 'R'
                                                    END AS TRANSACTION_TYPE
                                               FROM CDV_PARAM_LMTS
                                              WHERE CDV_PARAM_LMTS.KEY_HASH = ICS_PARAM_LMTS.KEY_HASH
                                                AND v_ParameterLimitsSubmission = 1);
   -- ======================================================
   -- ICS_DSCH_MON_REP - Set New/Replace Transactions
   -- ======================================================
   SET v_marker = 'UPDATE ICS_BASIC_PRMT - Set New/Replace Transactions';
   UPDATE ICS_DSCH_MON_REP
      SET ICS_DSCH_MON_REP.TRANSACTION_TYPE = (SELECT CASE CDV_DSCH_MON_REP.ACTION_CODE
                                                         WHEN 1 THEN 'R'
                                                         WHEN 2 THEN 'R'
                                                      END AS TRANSACTION_TYPE
                                                 FROM CDV_DSCH_MON_REP
                                                WHERE CDV_DSCH_MON_REP.KEY_HASH = ICS_DSCH_MON_REP.KEY_HASH
                                                  AND v_DischargeMonitoringReportSubmission = 1);
   -- ======================================================
   -- ICS_SNGL_EVT_VIOL - Set New/Replace Transactions
   -- ======================================================
   SET v_marker = 'UPDATE ICS_SNGL_EVT_VIOL - Set New/Replace Transactions';
   UPDATE ICS_SNGL_EVT_VIOL
      SET ICS_SNGL_EVT_VIOL.TRANSACTION_TYPE = (SELECT CASE CDV_SNGL_EVT_VIOL.ACTION_CODE
                                                          WHEN 1 THEN 'N'
                                                          WHEN 2 THEN 'R'
                                                       END AS TRANSACTION_TYPE
                                                  FROM CDV_SNGL_EVT_VIOL
                                                 WHERE CDV_SNGL_EVT_VIOL.KEY_HASH = ICS_SNGL_EVT_VIOL.KEY_HASH
                                                   AND v_SingleEventViolationSubmission = 1);
   -- ======================================================
   -- ICS_CMPL_SCHD - Set New/Replace Transactions
   -- ======================================================
   SET v_marker = 'UPDATE ICS_BASIC_PRMT - Set New/Replace Transactions';
   UPDATE ICS_CMPL_SCHD
      SET ICS_CMPL_SCHD.TRANSACTION_TYPE = (SELECT CASE CDV_CMPL_SCHD.ACTION_CODE
                                                      WHEN 1 THEN 'R'
                                                      WHEN 2 THEN 'R'
                                                   END AS TRANSACTION_TYPE
                                              FROM CDV_CMPL_SCHD
                                             WHERE CDV_CMPL_SCHD.KEY_HASH = ICS_CMPL_SCHD.KEY_HASH
                                               AND v_ComplianceScheduleSubmission = 1);
   -- ======================================================
   -- ICS_DMR_VIOL - Set New/Replace Transactions
   -- ======================================================
   SET v_marker = 'UPDATE ICS_DMR_VIOL - Set New/Replace Transactions';
   UPDATE ICS_DMR_VIOL
      SET ICS_DMR_VIOL.TRANSACTION_TYPE = (SELECT CASE CDV_DMR_VIOL.ACTION_CODE
                                                     WHEN 1 THEN 'C'
                                                     WHEN 2 THEN 'C'
                                                   END AS TRANSACTION_TYPE
                                             FROM CDV_DMR_VIOL
                                            WHERE CDV_DMR_VIOL.KEY_HASH = ICS_DMR_VIOL.KEY_HASH
                                              AND v_DMRViolationSubmission = 1);
   -- ======================================================
   -- ICS_EFFLU_TRADE_PRTNER - Set New/Replace Transactions
   -- ======================================================
   SET v_marker = 'UPDATE ICS_EFFLU_TRADE_PRTNER - Set New/Replace Transactions';
   UPDATE ICS_EFFLU_TRADE_PRTNER
      SET ICS_EFFLU_TRADE_PRTNER.TRANSACTION_TYPE = (SELECT CASE CDV_EFFLU_TRADE_PRTNER.ACTION_CODE
                                                               WHEN 1 THEN 'N'
                                                               WHEN 2 THEN 'R'
                                                            END AS TRANSACTION_TYPE
                                                       FROM CDV_EFFLU_TRADE_PRTNER
                                                      WHERE CDV_EFFLU_TRADE_PRTNER.KEY_HASH = ICS_EFFLU_TRADE_PRTNER.KEY_HASH
                                                        AND v_EffluentTradePartnerSubmission = 1);
   -- ======================================================
   -- ICS_FRML_ENFRC_ACTN - Set New/Replace Transactions
   -- ======================================================
   SET v_marker = 'UPDATE ICS_FRML_ENFRC_ACTN - Set New/Replace Transactions';
   UPDATE ICS_FRML_ENFRC_ACTN
      SET ICS_FRML_ENFRC_ACTN.TRANSACTION_TYPE = (SELECT CASE CDV_FRML_ENFRC_ACTN.ACTION_CODE
                                                            WHEN 1 THEN 'N'
                                                            WHEN 2 THEN 'R'
                                                         END AS TRANSACTION_TYPE
                                                    FROM CDV_FRML_ENFRC_ACTN
                                                   WHERE CDV_FRML_ENFRC_ACTN.KEY_HASH = ICS_FRML_ENFRC_ACTN.KEY_HASH
                                                     AND v_FormalEnforcementActionSubmission = 1);
   -- ======================================================
   -- ICS_INFRML_ENFRC_ACTN - Set New/Replace Transactions 
   -- ======================================================
   SET v_marker = 'UPDATE ICS_INFRML_ENFRC_ACTN - Set New/Replace Transactions';
   UPDATE ICS_INFRML_ENFRC_ACTN
      SET ICS_INFRML_ENFRC_ACTN.TRANSACTION_TYPE = (SELECT CASE CDV_INFRML_ENFRC_ACTN.ACTION_CODE
                                                              WHEN 1 THEN 'N'
                                                              WHEN 2 THEN 'R'
                                                           END AS TRANSACTION_TYPE
                                                      FROM CDV_INFRML_ENFRC_ACTN
                                                     WHERE CDV_INFRML_ENFRC_ACTN.KEY_HASH = ICS_INFRML_ENFRC_ACTN.KEY_HASH
                                                       AND v_InformalEnforcementActionSubmission = 1);
   -- =======================================================
   -- ICS_ENFRC_ACTN_MILESTONE - Set New/Replace Transactions
   -- =======================================================
   SET v_marker = 'UPDATE ICS_ENFRC_ACTN_MILESTONE - Set New/Replace Transactions';
   UPDATE ICS_ENFRC_ACTN_MILESTONE
      SET ICS_ENFRC_ACTN_MILESTONE.TRANSACTION_TYPE = (SELECT CASE CDV_ENFRC_ACTN_MILESTONE.ACTION_CODE
                                                                 WHEN 1 THEN 'R'
                                                                 WHEN 2 THEN 'R'
                                                              END AS TRANSACTION_TYPE
                                                         FROM CDV_ENFRC_ACTN_MILESTONE
                                                        WHERE CDV_ENFRC_ACTN_MILESTONE.KEY_HASH = ICS_ENFRC_ACTN_MILESTONE.KEY_HASH
                                                          AND v_EnforcementActionMilestoneSubmission = 1);
   -- =======================================================                                              
   -- ICS_FINAL_ORDER_VIOL_LNK - Set New/Replace Transactions
   -- =======================================================
   SET v_marker = 'UPDATE ICS_FINAL_ORDER_VIOL_LNK - Set New/Replace Transactions';
   UPDATE ICS_FINAL_ORDER_VIOL_LNK
      SET ICS_FINAL_ORDER_VIOL_LNK.TRANSACTION_TYPE = (SELECT CASE CDV_FINAL_ORDER_VIOL_LNK.ACTION_CODE
                                                                 WHEN 1 THEN 'R'
                                                                 WHEN 2 THEN 'R'
                                                              END AS TRANSACTION_TYPE
                                                         FROM CDV_FINAL_ORDER_VIOL_LNK
                                                        WHERE CDV_FINAL_ORDER_VIOL_LNK.KEY_HASH = ICS_FINAL_ORDER_VIOL_LNK.KEY_HASH
                                                          AND v_FinalOrderViolationLinkageSubmission = 1);
   -- =======================================================
   -- ICS_CSO_EVT_REP - Set New/Replace Transactions
   -- =======================================================
   SET v_marker = 'UPDATE ICS_CSO_EVT_REP - Set New/Replace Transactions';
   UPDATE ICS_CSO_EVT_REP
      SET ICS_CSO_EVT_REP.TRANSACTION_TYPE = (SELECT CASE CDV_CSO_EVT_REP.ACTION_CODE
                                                        WHEN 1 THEN 'R'
                                                        WHEN 2 THEN 'R'
                                                     END AS TRANSACTION_TYPE
                                                FROM CDV_CSO_EVT_REP
                                               WHERE CDV_CSO_EVT_REP.KEY_HASH = ICS_CSO_EVT_REP.KEY_HASH
                                                 AND v_CSOEventReportSubmission = 1);
   -- =======================================================
   -- ICS_SW_EVT_REP - Set New/Replace Transactions
   -- =======================================================
   SET v_marker = 'UPDATE ICS_SW_EVT_REP - Set New/Replace Transactions';
   UPDATE ICS_SW_EVT_REP
      SET ICS_SW_EVT_REP.TRANSACTION_TYPE = (SELECT CASE CDV_SW_EVT_REP.ACTION_CODE
                                                       WHEN 1 THEN 'R'
                                                       WHEN 2 THEN 'R'
                                                    END AS TRANSACTION_TYPE
                                               FROM CDV_SW_EVT_REP
                                              WHERE CDV_SW_EVT_REP.KEY_HASH = ICS_SW_EVT_REP.KEY_HASH
                                                AND v_SWEventReportSubmission = 1);
   -- =======================================================
   -- ICS_CAFO_ANNUL_REP - Set New/Replace Transactions
   -- =======================================================
   SET v_marker = 'UPDATE ICS_CAFO_ANNUL_REP - Set New/Replace Transactions';
   UPDATE ICS_CAFO_ANNUL_REP
      SET ICS_CAFO_ANNUL_REP.TRANSACTION_TYPE = (SELECT CASE CDV_CAFO_ANNUL_REP.ACTION_CODE
                                                           WHEN 1 THEN 'R'
                                                           WHEN 2 THEN 'R'
                                                        END AS TRANSACTION_TYPE
                                                   FROM CDV_CAFO_ANNUL_REP
                                                  WHERE CDV_CAFO_ANNUL_REP.KEY_HASH = ICS_CAFO_ANNUL_REP.KEY_HASH
                                                    AND v_CAFOAnnualReportSubmission = 1);
   -- =======================================================
   -- ICS_LOC_LMTS_PROG_REP - Set New/Replace Transactions
   -- =======================================================
   SET v_marker = 'UPDATE ICS_LOC_LMTS_PROG_REP - Set New/Replace Transactions';
   UPDATE ICS_LOC_LMTS_PROG_REP
      SET ICS_LOC_LMTS_PROG_REP.TRANSACTION_TYPE = (SELECT CASE CDV_LOC_LMTS_PROG_REP.ACTION_CODE
                                                              WHEN 1 THEN 'R'
                                                              WHEN 2 THEN 'R'
                                                           END AS TRANSACTION_TYPE
                                                      FROM CDV_LOC_LMTS_PROG_REP
                                                     WHERE CDV_LOC_LMTS_PROG_REP.KEY_HASH = ICS_LOC_LMTS_PROG_REP.KEY_HASH
                                                       AND v_LocalLimitsProgramReportSubmission = 1);
   -- =======================================================
   -- ICS_PRETR_PERF_SUMM - Set New/Replace Transactions
   -- =======================================================
   SET v_marker = 'UPDATE ICS_PRETR_PERF_SUMM - Set New/Replace Transactions';
   UPDATE ICS_PRETR_PERF_SUMM
      SET ICS_PRETR_PERF_SUMM.TRANSACTION_TYPE = (SELECT CASE CDV_PRETR_PERF_SUMM.ACTION_CODE
                                                            WHEN 1 THEN 'R'
                                                            WHEN 2 THEN 'R'
                                                         END AS TRANSACTION_TYPE
                                                    FROM CDV_PRETR_PERF_SUMM
                                                   WHERE CDV_PRETR_PERF_SUMM.KEY_HASH = ICS_PRETR_PERF_SUMM.KEY_HASH
                                                     AND v_PretreatmentPerformanceSummarySubmission = 1);
   -- =======================================================
   -- ICS_BS_PROG_REP - Set New/Replace Transactions
   -- =======================================================
   SET v_marker = 'UPDATE ICS_BS_PROG_REP - Set New/Replace Transactions';
   UPDATE ICS_BS_PROG_REP
      SET ICS_BS_PROG_REP.TRANSACTION_TYPE = (SELECT CASE CDV_BS_PROG_REP.ACTION_CODE
                                                        WHEN 1 THEN 'R'
                                                        WHEN 2 THEN 'R'
                                                     END AS TRANSACTION_TYPE
                                                FROM CDV_BS_PROG_REP
                                               WHERE CDV_BS_PROG_REP.KEY_HASH = ICS_BS_PROG_REP.KEY_HASH
                                                 AND v_BiosolidsProgramReportSubmission = 1);
   -- =======================================================
   -- ICS_SSO_ANNUL_REP - Set New/Replace Transactions
   -- =======================================================
   SET v_marker = 'UPDATE ICS_SSO_ANNUL_REP - Set New/Replace Transactions';
   UPDATE ICS_SSO_ANNUL_REP
      SET ICS_SSO_ANNUL_REP.TRANSACTION_TYPE = (SELECT CASE CDV_SSO_ANNUL_REP.ACTION_CODE
                                                          WHEN 1 THEN 'R'
                                                          WHEN 2 THEN 'R'
                                                       END AS TRANSACTION_TYPE
                                                  FROM CDV_SSO_ANNUL_REP
                                                 WHERE CDV_SSO_ANNUL_REP.KEY_HASH = ICS_SSO_ANNUL_REP.KEY_HASH
                                                   AND v_SSOAnnualReportSubmission = 1);
   -- =======================================================
   -- ICS_SSO_EVT_REP - Set New/Replace Transactions
   -- =======================================================
   SET v_marker = 'UPDATE ICS_SSO_EVT_REP - Set New/Replace Transactions';
   UPDATE ICS_SSO_EVT_REP
      SET ICS_SSO_EVT_REP.TRANSACTION_TYPE = (SELECT CASE CDV_SSO_EVT_REP.ACTION_CODE
                                                        WHEN 1 THEN 'R'
                                                        WHEN 2 THEN 'R'
                                                     END AS TRANSACTION_TYPE
                                                FROM CDV_SSO_EVT_REP
                                               WHERE CDV_SSO_EVT_REP.KEY_HASH = ICS_SSO_EVT_REP.KEY_HASH
                                                 AND v_SSOEventReportSubmission = 1);
   -- =======================================================
   -- ICS_SSO_MONTHLY_EVT_REP - Set New/Replace Transactions
   -- =======================================================
   SET v_marker = 'UPDATE ICS_SSO_MONTHLY_EVT_REP - Set New/Replace Transactions';
   UPDATE ICS_SSO_MONTHLY_EVT_REP
      SET ICS_SSO_MONTHLY_EVT_REP.TRANSACTION_TYPE = (SELECT CASE CDV_SSO_MONTHLY_EVT_REP.ACTION_CODE
                                                                WHEN 1 THEN 'R'
                                                                WHEN 2 THEN 'R'
                                                             END AS TRANSACTION_TYPE
                                                        FROM CDV_SSO_MONTHLY_EVT_REP
                                                       WHERE CDV_SSO_MONTHLY_EVT_REP.KEY_HASH = ICS_SSO_MONTHLY_EVT_REP.KEY_HASH
                                                         AND v_SSOMonthlyEventReportSubmission = 1);
   -- =======================================================
   -- ICS_SWMS_4_PROG_REP - Set New/Replace Transactions
   -- =======================================================
   SET v_marker = 'UPDATE ICS_SWMS_4_PROG_REP - Set New/Replace Transactions';
   UPDATE ICS_SWMS_4_PROG_REP
      SET ICS_SWMS_4_PROG_REP.TRANSACTION_TYPE = (SELECT CASE CDV_SWMS_4_PROG_REP.ACTION_CODE
                                                            WHEN 1 THEN 'R'
                                                            WHEN 2 THEN 'R'
                                                         END AS TRANSACTION_TYPE
                                                     FROM CDV_SWMS_4_PROG_REP
                                                    WHERE CDV_SWMS_4_PROG_REP.KEY_HASH = ICS_SWMS_4_PROG_REP.KEY_HASH
                                                      AND v_SWMS4ProgramReportSubmission = 1);
   -- =======================================================
   -- ICS_SCHD_EVT_VIOL - Set New/Replace Transactions
   -- =======================================================
   SET v_marker = 'UPDATE ICS_SCHD_EVT_VIOL - Set New/Replace Transactions';
   UPDATE ICS_SCHD_EVT_VIOL
      SET ICS_SCHD_EVT_VIOL.TRANSACTION_TYPE = (SELECT CASE CDV_SCHD_EVT_VIOL.ACTION_CODE
                                                          WHEN 1 THEN 'C'
                                                          WHEN 2 THEN 'C'
                                                       END AS TRANSACTION_TYPE
                                                  FROM CDV_SCHD_EVT_VIOL
                                                 WHERE CDV_SCHD_EVT_VIOL.KEY_HASH = ICS_SCHD_EVT_VIOL.KEY_HASH
                                                   AND v_ScheduleEventViolationSubmission = 1);
   -- =======================================================
   -- ICS_CMPL_MON_LNK - Set New/Replace Transactions
   -- =======================================================
   SET v_marker = 'UPDATE ICS_CMPL_MON_LNK - Set New/Replace Transactions';
   UPDATE ICS_CMPL_MON_LNK
      SET ICS_CMPL_MON_LNK.TRANSACTION_TYPE = (SELECT CASE CDV_CMPL_MON_LNK.ACTION_CODE
                                                         WHEN 1 THEN 'R'
                                                         WHEN 2 THEN 'R'
                                                      END AS TRANSACTION_TYPE
                                                 FROM CDV_CMPL_MON_LNK
                                                WHERE CDV_CMPL_MON_LNK.KEY_HASH = ICS_CMPL_MON_LNK.KEY_HASH
                                                  AND v_ComplianceMonitoringLinkageSubmission = 1);
   -- =======================================================
   -- ICS_ENFRC_ACTN_VIOL_LNK - Set New/Replace Transactions
   -- =======================================================
   SET v_marker = 'UPDATE ICS_ENFRC_ACTN_VIOL_LNK - Set New/Replace Transactions';
   UPDATE ICS_ENFRC_ACTN_VIOL_LNK
      SET ICS_ENFRC_ACTN_VIOL_LNK.TRANSACTION_TYPE = (SELECT CASE CDV_ENFRC_ACTN_VIOL_LNK.ACTION_CODE
                                                                WHEN 1 THEN 'R'
                                                                WHEN 2 THEN 'R'
                                                             END AS TRANSACTION_TYPE
                                                        FROM CDV_ENFRC_ACTN_VIOL_LNK
                                                       WHERE CDV_ENFRC_ACTN_VIOL_LNK.KEY_HASH = ICS_ENFRC_ACTN_VIOL_LNK.KEY_HASH
                                                         AND v_EnforcementActionViolationLinkageSubmission = 1);
   -- =======================================================
   -- ICS_DMR_PROG_REP_LNK - Set New/Replace Transactions
   -- =======================================================
   SET v_marker = 'UPDATE ICS_DMR_PROG_REP_LNK - Set New/Replace Transactions';
   UPDATE ICS_DMR_PROG_REP_LNK
      SET ICS_DMR_PROG_REP_LNK.TRANSACTION_TYPE = (SELECT CASE CDV_DMR_PROG_REP_LNK.ACTION_CODE
                                                             WHEN 1 THEN 'R'
                                                             WHEN 2 THEN 'R'
                                                          END AS TRANSACTION_TYPE
                                                     FROM CDV_DMR_PROG_REP_LNK
                                                    WHERE CDV_DMR_PROG_REP_LNK.KEY_HASH = ICS_DMR_PROG_REP_LNK.KEY_HASH
                                                      AND v_DMRProgramReportLinkageSubmission = 1);
   -- =======================================================
   -- ICS_BASIC_PRMT - Set Delete Transactions
   -- =======================================================
   SET v_marker = 'INSERT INTO ICS_BASIC_PRMT - Set Delete Transactions';
   INSERT INTO ICS_BASIC_PRMT
       ( ICS_PAYLOAD_ID
       , ICS_BASIC_PRMT_ID
       , TRANSACTION_TYPE
       , PRMT_IDENT) 
   SELECT ICS_BASIC_PRMT.ICS_PAYLOAD_ID
        , ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID
        , 'D' AS TRANSACTION_TYPE
        , PRMT_IDENT
     FROM ga_ics_flow_icis.ICS_BASIC_PRMT
    WHERE ICS_BASIC_PRMT.ICS_PAYLOAD_ID = v_BasicPermitSubmission_PID
      AND ICS_BASIC_PRMT.KEY_HASH IN (SELECT KEY_HASH
                                        FROM CDV_BASIC_PRMT
                                       WHERE CDV_BASIC_PRMT.ACTION_TYPE = 'DELETE');
   -- =======================================================
   -- ICS_BS_PRMT - Set Delete Transactions
   -- =======================================================
   SET v_marker = 'INSERT INTO ICS_BS_PRMT - Set Delete Transactions';
   INSERT INTO ICS_BS_PRMT
       ( ICS_PAYLOAD_ID
       , ICS_BS_PRMT_ID
       , TRANSACTION_TYPE
       , PRMT_IDENT) 
   SELECT ICS_BS_PRMT.ICS_PAYLOAD_ID
        , ICS_BS_PRMT.ICS_BS_PRMT_ID
        , 'X' AS TRANSACTION_TYPE
        , PRMT_IDENT
     FROM ga_ics_flow_icis.ICS_BS_PRMT
    WHERE ICS_BS_PRMT.ICS_PAYLOAD_ID = v_BiosolidsPermitSubmission_PID
      AND ICS_BS_PRMT.KEY_HASH IN (SELECT KEY_HASH
                                        FROM CDV_BS_PRMT
                                       WHERE CDV_BS_PRMT.ACTION_TYPE = 'DELETE');
   -- =======================================================
   -- ICS_CAFO_PRMT - Set Delete Transactions
   -- =======================================================
   SET v_marker = 'INSERT INTO ICS_CAFO_PRMT - Set Delete Transactions';
   INSERT INTO ICS_CAFO_PRMT
       ( ICS_PAYLOAD_ID
       , ICS_CAFO_PRMT_ID
       , TRANSACTION_TYPE
       , PRMT_IDENT) 
   SELECT ICS_CAFO_PRMT.ICS_PAYLOAD_ID
        , ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID
        , 'X' AS TRANSACTION_TYPE
        , PRMT_IDENT
     FROM ga_ics_flow_icis.ICS_CAFO_PRMT
    WHERE ICS_CAFO_PRMT.ICS_PAYLOAD_ID = v_CAFOPermitSubmission_PID
      AND ICS_CAFO_PRMT.KEY_HASH IN (SELECT KEY_HASH
                                        FROM CDV_CAFO_PRMT
                                       WHERE CDV_CAFO_PRMT.ACTION_TYPE = 'DELETE');
   -- =======================================================
   -- ICS_CSO_PRMT - Set Delete Transactions
   -- =======================================================
   SET v_marker = 'INSERT INTO ICS_CSO_PRMT - Set Delete Transactions';
   INSERT INTO ICS_CSO_PRMT
       ( ICS_PAYLOAD_ID
       , ICS_CSO_PRMT_ID
       , TRANSACTION_TYPE
       , PRMT_IDENT) 
   SELECT ICS_CSO_PRMT.ICS_PAYLOAD_ID
        , ICS_CSO_PRMT.ICS_CSO_PRMT_ID
        , 'X' AS TRANSACTION_TYPE
        , PRMT_IDENT
     FROM ga_ics_flow_icis.ICS_CSO_PRMT
    WHERE ICS_CSO_PRMT.ICS_PAYLOAD_ID = v_CSOPermitSubmission_PID
      AND ICS_CSO_PRMT.KEY_HASH IN (SELECT KEY_HASH
                                        FROM CDV_CSO_PRMT
                                       WHERE CDV_CSO_PRMT.ACTION_TYPE = 'DELETE');
   -- =======================================================
   -- ICS_CMPL_MON - Set Delete Transactions
   -- =======================================================
   SET v_marker = 'INSERT INTO ICS_CMPL_MON - Set Delete Transactions';
   INSERT INTO ICS_CMPL_MON
       ( ICS_PAYLOAD_ID
       , ICS_CMPL_MON_ID
       , TRANSACTION_TYPE
       , PRMT_IDENT, CMPL_MON_CATG_CODE, CMPL_MON_DATE) 
   SELECT ICS_CMPL_MON.ICS_PAYLOAD_ID
        , ICS_CMPL_MON.ICS_CMPL_MON_ID
        , 'X' AS TRANSACTION_TYPE
        , PRMT_IDENT, CMPL_MON_CATG_CODE, CMPL_MON_DATE
     FROM ga_ics_flow_icis.ICS_CMPL_MON
    WHERE ICS_CMPL_MON.ICS_PAYLOAD_ID = v_ComplianceMonitoringSubmission_PID
      AND ICS_CMPL_MON.KEY_HASH IN (SELECT KEY_HASH
                                        FROM CDV_CMPL_MON
                                       WHERE CDV_CMPL_MON.ACTION_TYPE = 'DELETE');
   -- =======================================================
   -- ICS_GNRL_PRMT - Set Delete Transactions
   -- =======================================================
   SET v_marker = 'INSERT INTO ICS_GNRL_PRMT - Set Delete Transactions';
   INSERT INTO ICS_GNRL_PRMT
       ( ICS_PAYLOAD_ID
       , ICS_GNRL_PRMT_ID
       , TRANSACTION_TYPE
       , PRMT_IDENT) 
   SELECT ICS_GNRL_PRMT.ICS_PAYLOAD_ID
        , ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
        , 'D' AS TRANSACTION_TYPE
        , PRMT_IDENT
     FROM ga_ics_flow_icis.ICS_GNRL_PRMT
    WHERE ICS_GNRL_PRMT.ICS_PAYLOAD_ID = v_GeneralPermitSubmission_PID
      AND ICS_GNRL_PRMT.KEY_HASH IN (SELECT KEY_HASH
                                        FROM CDV_GNRL_PRMT
                                       WHERE CDV_GNRL_PRMT.ACTION_TYPE = 'DELETE');
   -- =======================================================
   -- ICS_MASTER_GNRL_PRMT - Set Delete Transactions
   -- =======================================================
   SET v_marker = 'INSERT INTO ICS_MASTER_GNRL_PRMT - Set Delete Transactions';
   INSERT INTO ICS_MASTER_GNRL_PRMT
       ( ICS_PAYLOAD_ID
       , ICS_MASTER_GNRL_PRMT_ID
       , TRANSACTION_TYPE
       , PRMT_IDENT) 
   SELECT ICS_MASTER_GNRL_PRMT.ICS_PAYLOAD_ID
        , ICS_MASTER_GNRL_PRMT.ICS_MASTER_GNRL_PRMT_ID
        , 'D' AS TRANSACTION_TYPE
        , PRMT_IDENT
     FROM ga_ics_flow_icis.ICS_MASTER_GNRL_PRMT
    WHERE ICS_MASTER_GNRL_PRMT.ICS_PAYLOAD_ID = v_MasterGeneralPermitSubmission_PID
      AND ICS_MASTER_GNRL_PRMT.KEY_HASH IN (SELECT KEY_HASH
                                        FROM CDV_MASTER_GNRL_PRMT
                                       WHERE CDV_MASTER_GNRL_PRMT.ACTION_TYPE = 'DELETE');
  
   -- ICS_PRMT_REISSU - Set Delete Transactions
   -- Delete transaction not supported by ICIS for this module
  
   -- ICS_PRMT_TERM - Set Delete Transactions
   -- Delete transaction not supported by ICIS for this module
   -- =======================================================
   -- ICS_PRMT_TRACK_EVT - Set Delete Transactions
   -- =======================================================
   SET v_marker = 'INSERT INTO ICS_PRMT_TRACK_EVT - Set Delete Transactions';
   INSERT INTO ICS_PRMT_TRACK_EVT
       ( ICS_PAYLOAD_ID
       , ICS_PRMT_TRACK_EVT_ID
       , TRANSACTION_TYPE
       , PRMT_IDENT, PRMT_TRACK_EVT_CODE, PRMT_TRACK_EVT_DATE) 
   SELECT ICS_PRMT_TRACK_EVT.ICS_PAYLOAD_ID
        , ICS_PRMT_TRACK_EVT.ICS_PRMT_TRACK_EVT_ID
        , 'X' AS TRANSACTION_TYPE
        , PRMT_IDENT, PRMT_TRACK_EVT_CODE, PRMT_TRACK_EVT_DATE
     FROM ga_ics_flow_icis.ICS_PRMT_TRACK_EVT
    WHERE ICS_PRMT_TRACK_EVT.ICS_PAYLOAD_ID = v_PermitTrackingEventSubmission_PID
      AND ICS_PRMT_TRACK_EVT.KEY_HASH IN (SELECT KEY_HASH
                                        FROM CDV_PRMT_TRACK_EVT
                                       WHERE CDV_PRMT_TRACK_EVT.ACTION_TYPE = 'DELETE');
   -- =======================================================
   -- ICS_POTW_PRMT - Set Delete Transactions
   -- =======================================================
   SET v_marker = 'INSERT INTO ICS_POTW_PRMT - Set Delete Transactions';
   INSERT INTO ICS_POTW_PRMT
       ( ICS_PAYLOAD_ID
       , ICS_POTW_PRMT_ID
       , TRANSACTION_TYPE
       , PRMT_IDENT) 
   SELECT ICS_POTW_PRMT.ICS_PAYLOAD_ID
        , ICS_POTW_PRMT.ICS_POTW_PRMT_ID
        , 'X' AS TRANSACTION_TYPE
        , PRMT_IDENT
     FROM ga_ics_flow_icis.ICS_POTW_PRMT
    WHERE ICS_POTW_PRMT.ICS_PAYLOAD_ID = v_POTWPermitSubmission_PID
      AND ICS_POTW_PRMT.KEY_HASH IN (SELECT KEY_HASH
                                        FROM CDV_POTW_PRMT
                                       WHERE CDV_POTW_PRMT.ACTION_TYPE = 'DELETE');
   -- =======================================================
   -- ICS_PRETR_PRMT - Set Delete Transactions
   -- =======================================================
   SET v_marker = 'INSERT INTO ICS_PRETR_PRMT - Set Delete Transactions';
   INSERT INTO ICS_PRETR_PRMT
       ( ICS_PAYLOAD_ID
       , ICS_PRETR_PRMT_ID
       , TRANSACTION_TYPE
       , PRMT_IDENT) 
   SELECT ICS_PRETR_PRMT.ICS_PAYLOAD_ID
        , ICS_PRETR_PRMT.ICS_PRETR_PRMT_ID
        , 'X' AS TRANSACTION_TYPE
        , PRMT_IDENT
     FROM ga_ics_flow_icis.ICS_PRETR_PRMT
    WHERE ICS_PRETR_PRMT.ICS_PAYLOAD_ID = v_PretreatmentPermitSubmission_PID
      AND ICS_PRETR_PRMT.KEY_HASH IN (SELECT KEY_HASH
                                        FROM CDV_PRETR_PRMT
                                       WHERE CDV_PRETR_PRMT.ACTION_TYPE = 'DELETE');
   -- =======================================================
   -- ICS_SW_CNST_PRMT - Set Delete Transactions
   -- =======================================================
   SET v_marker = 'INSERT INTO ICS_SW_CNST_PRMT - Set Delete Transactions';
   INSERT INTO ICS_SW_CNST_PRMT
       ( ICS_PAYLOAD_ID
       , ICS_SW_CNST_PRMT_ID
       , TRANSACTION_TYPE
       , PRMT_IDENT) 
   SELECT ICS_SW_CNST_PRMT.ICS_PAYLOAD_ID
        , ICS_SW_CNST_PRMT.ICS_SW_CNST_PRMT_ID
        , 'X' AS TRANSACTION_TYPE
        , PRMT_IDENT
     FROM ga_ics_flow_icis.ICS_SW_CNST_PRMT
    WHERE ICS_SW_CNST_PRMT.ICS_PAYLOAD_ID = v_SWConstructionPermitSubmission_PID
      AND ICS_SW_CNST_PRMT.KEY_HASH IN (SELECT KEY_HASH
                                        FROM CDV_SW_CNST_PRMT
                                       WHERE CDV_SW_CNST_PRMT.ACTION_TYPE = 'DELETE');
   -- =======================================================
   -- ICS_SW_INDST_PRMT - Set Delete Transactions
   -- =======================================================
   SET v_marker = 'INSERT INTO ICS_SW_INDST_PRMT - Set Delete Transactions';
   INSERT INTO ICS_SW_INDST_PRMT
       ( ICS_PAYLOAD_ID
       , ICS_SW_INDST_PRMT_ID
       , TRANSACTION_TYPE
       , PRMT_IDENT) 
   SELECT ICS_SW_INDST_PRMT.ICS_PAYLOAD_ID
        , ICS_SW_INDST_PRMT.ICS_SW_INDST_PRMT_ID
        , 'X' AS TRANSACTION_TYPE
        , PRMT_IDENT
     FROM ga_ics_flow_icis.ICS_SW_INDST_PRMT
    WHERE ICS_SW_INDST_PRMT.ICS_PAYLOAD_ID = v_SWIndustrialPermitSubmission_PID
      AND ICS_SW_INDST_PRMT.KEY_HASH IN (SELECT KEY_HASH
                                        FROM CDV_SW_INDST_PRMT
                                       WHERE CDV_SW_INDST_PRMT.ACTION_TYPE = 'DELETE');
   -- =======================================================
   -- ICS_SWMS_4_LARGE_PRMT - Set Delete Transactions
   -- =======================================================
   SET v_marker = 'INSERT INTO ICS_SWMS_4_LARGE_PRMT - Set Delete Transactions';
   INSERT INTO ICS_SWMS_4_LARGE_PRMT
       ( ICS_PAYLOAD_ID
       , ICS_SWMS_4_LARGE_PRMT_ID
       , TRANSACTION_TYPE
       , PRMT_IDENT) 
   SELECT ICS_SWMS_4_LARGE_PRMT.ICS_PAYLOAD_ID
        , ICS_SWMS_4_LARGE_PRMT.ICS_SWMS_4_LARGE_PRMT_ID
        , 'X' AS TRANSACTION_TYPE
        , PRMT_IDENT
     FROM ga_ics_flow_icis.ICS_SWMS_4_LARGE_PRMT
    WHERE ICS_SWMS_4_LARGE_PRMT.ICS_PAYLOAD_ID = v_SWMS4LargePermitSubmission_PID
      AND ICS_SWMS_4_LARGE_PRMT.KEY_HASH IN (SELECT KEY_HASH
                                        FROM CDV_SWMS_4_LARGE_PRMT
                                       WHERE CDV_SWMS_4_LARGE_PRMT.ACTION_TYPE = 'DELETE');
   -- =======================================================
   -- ICS_SWMS_4_SMALL_PRMT - Set Delete Transactions
   -- =======================================================
   SET v_marker = 'INSERT INTO ICS_SWMS_4_SMALL_PRMT - Set Delete Transactions';
   INSERT INTO ICS_SWMS_4_SMALL_PRMT
       ( ICS_PAYLOAD_ID
       , ICS_SWMS_4_SMALL_PRMT_ID
       , TRANSACTION_TYPE
       , PRMT_IDENT) 
   SELECT ICS_SWMS_4_SMALL_PRMT.ICS_PAYLOAD_ID
        , ICS_SWMS_4_SMALL_PRMT.ICS_SWMS_4_SMALL_PRMT_ID
        , 'X' AS TRANSACTION_TYPE
        , PRMT_IDENT
     FROM ga_ics_flow_icis.ICS_SWMS_4_SMALL_PRMT
    WHERE ICS_SWMS_4_SMALL_PRMT.ICS_PAYLOAD_ID = v_SWMS4SmallPermitSubmission_PID
      AND ICS_SWMS_4_SMALL_PRMT.KEY_HASH IN (SELECT KEY_HASH
                                        FROM CDV_SWMS_4_SMALL_PRMT
                                       WHERE CDV_SWMS_4_SMALL_PRMT.ACTION_TYPE = 'DELETE');
   -- =======================================================
   -- ICS_UNPRMT_FAC - Set Delete Transactions
   -- =======================================================
   SET v_marker = 'INSERT INTO ICS_UNPRMT_FAC - Set Delete Transactions';
   INSERT INTO ICS_UNPRMT_FAC
       ( ICS_PAYLOAD_ID
       , ICS_UNPRMT_FAC_ID
       , TRANSACTION_TYPE
       , PRMT_IDENT) 
   SELECT ICS_UNPRMT_FAC.ICS_PAYLOAD_ID
        , ICS_UNPRMT_FAC.ICS_UNPRMT_FAC_ID
        , 'X' AS TRANSACTION_TYPE
        , PRMT_IDENT
     FROM ga_ics_flow_icis.ICS_UNPRMT_FAC
    WHERE ICS_UNPRMT_FAC.ICS_PAYLOAD_ID = v_UnpermittedFacilitySubmission_PID
      AND ICS_UNPRMT_FAC.KEY_HASH IN (SELECT KEY_HASH
                                        FROM CDV_UNPRMT_FAC
                                       WHERE CDV_UNPRMT_FAC.ACTION_TYPE = 'DELETE');
  
  -- ICS_HIST_PRMT_SCHD_EVTS - Set Delete Transactions
  -- Delete transaction not supported by ICIS for this module
   -- =======================================================
   -- ICS_NARR_COND_SCHD - Set Delete Transactions
   -- =======================================================
   SET v_marker = 'INSERT INTO ICS_NARR_COND_SCHD - Set Delete Transactions';
   INSERT INTO ICS_NARR_COND_SCHD
       ( ICS_PAYLOAD_ID
       , ICS_NARR_COND_SCHD_ID
       , TRANSACTION_TYPE
       , PRMT_IDENT, NARR_COND_NUM) 
   SELECT ICS_NARR_COND_SCHD.ICS_PAYLOAD_ID
        , ICS_NARR_COND_SCHD.ICS_NARR_COND_SCHD_ID
        , 'X' AS TRANSACTION_TYPE
        , PRMT_IDENT, NARR_COND_NUM
     FROM ga_ics_flow_icis.ICS_NARR_COND_SCHD
    WHERE ICS_NARR_COND_SCHD.ICS_PAYLOAD_ID = v_NarrativeConditionScheduleSubmission_PID
      AND ICS_NARR_COND_SCHD.KEY_HASH IN (SELECT KEY_HASH
                                        FROM CDV_NARR_COND_SCHD
                                       WHERE CDV_NARR_COND_SCHD.ACTION_TYPE = 'DELETE');
   -- =======================================================
   -- ICS_PRMT_FEATR - Set Delete Transactions
   -- =======================================================
   SET v_marker = 'INSERT INTO ICS_PRMT_FEATR - Set Delete Transactions';
   INSERT INTO ICS_PRMT_FEATR
       ( ICS_PAYLOAD_ID
       , ICS_PRMT_FEATR_ID
       , TRANSACTION_TYPE
       , PRMT_IDENT, PRMT_FEATR_IDENT) 
   SELECT ICS_PRMT_FEATR.ICS_PAYLOAD_ID
        , ICS_PRMT_FEATR.ICS_PRMT_FEATR_ID
        , 'X' AS TRANSACTION_TYPE
        , PRMT_IDENT, PRMT_FEATR_IDENT
     FROM ga_ics_flow_icis.ICS_PRMT_FEATR
    WHERE ICS_PRMT_FEATR.ICS_PAYLOAD_ID = v_PermittedFeatureSubmission_PID
      AND ICS_PRMT_FEATR.KEY_HASH IN (SELECT KEY_HASH
                                        FROM CDV_PRMT_FEATR
                                       WHERE CDV_PRMT_FEATR.ACTION_TYPE = 'DELETE');
   -- =======================================================
   -- ICS_LMT_SET - Set Delete Transactions
   -- =======================================================
   SET v_marker = 'INSERT INTO ICS_LMT_SET - Set Delete Transactions';
   INSERT INTO ICS_LMT_SET
       ( ICS_PAYLOAD_ID
       , ICS_LMT_SET_ID
       , TRANSACTION_TYPE
       , PRMT_IDENT, PRMT_FEATR_IDENT, LMT_SET_DESIGNATOR, LMT_SET_TYPE) 
   SELECT ICS_LMT_SET.ICS_PAYLOAD_ID
        , ICS_LMT_SET.ICS_LMT_SET_ID
        , 'X' AS TRANSACTION_TYPE
        , PRMT_IDENT, PRMT_FEATR_IDENT, LMT_SET_DESIGNATOR, 'S'
     FROM ga_ics_flow_icis.ICS_LMT_SET
    WHERE ICS_LMT_SET.ICS_PAYLOAD_ID = v_LimitSetSubmission_PID
      AND ICS_LMT_SET.KEY_HASH IN (SELECT KEY_HASH
                                        FROM CDV_LMT_SET
                                       WHERE CDV_LMT_SET.ACTION_TYPE = 'DELETE');
   -- =======================================================
   -- ICS_LMTS - Set Delete Transactions
   -- =======================================================
   SET v_marker = 'INSERT INTO ICS_LMTS - Set Delete Transactions';
   INSERT INTO ICS_LMTS
       ( ICS_PAYLOAD_ID
       , ICS_LMTS_ID
       , TRANSACTION_TYPE
       , PRMT_IDENT, PRMT_FEATR_IDENT, LMT_SET_DESIGNATOR
       , PARAM_CODE, MON_SITE_DESC_CODE
       , LMT_SEASON_NUM, LMT_START_DATE, LMT_END_DATE) 
   SELECT ICS_LMTS.ICS_PAYLOAD_ID
        , ICS_LMTS.ICS_LMTS_ID
        , 'X' AS TRANSACTION_TYPE
        , PRMT_IDENT, PRMT_FEATR_IDENT, LMT_SET_DESIGNATOR
        , PARAM_CODE, MON_SITE_DESC_CODE
        , LMT_SEASON_NUM, LMT_START_DATE, LMT_END_DATE
     FROM ga_ics_flow_icis.ICS_LMTS
    WHERE ICS_LMTS.ICS_PAYLOAD_ID = v_LimitsSubmission_PID
      AND ICS_LMTS.KEY_HASH IN (SELECT KEY_HASH
                                        FROM CDV_LMTS
                                       WHERE CDV_LMTS.ACTION_TYPE = 'DELETE');
   -- =======================================================
   -- ICS_PARAM_LMTS - Set Delete Transactions
   -- =======================================================
   SET v_marker = 'INSERT INTO ICS_PARAM_LMTS - Set Delete Transactions';
   INSERT INTO ICS_PARAM_LMTS
       ( ICS_PAYLOAD_ID
       , ICS_PARAM_LMTS_ID
       , TRANSACTION_TYPE
       , PRMT_IDENT, PRMT_FEATR_IDENT, LMT_SET_DESIGNATOR
       , PARAM_CODE, MON_SITE_DESC_CODE, LMT_SEASON_NUM) 
   SELECT ICS_PARAM_LMTS.ICS_PAYLOAD_ID
        , ICS_PARAM_LMTS.ICS_PARAM_LMTS_ID
        , 'X' AS TRANSACTION_TYPE
        , PRMT_IDENT, PRMT_FEATR_IDENT, LMT_SET_DESIGNATOR
        , PARAM_CODE, MON_SITE_DESC_CODE, LMT_SEASON_NUM
     FROM ga_ics_flow_icis.ICS_PARAM_LMTS
    WHERE ICS_PARAM_LMTS.ICS_PAYLOAD_ID = v_ParameterLimitsSubmission_PID
      AND ICS_PARAM_LMTS.KEY_HASH IN (SELECT KEY_HASH
                                        FROM CDV_PARAM_LMTS
                                       WHERE CDV_PARAM_LMTS.ACTION_TYPE = 'DELETE');
   -- =======================================================
   -- ICS_DSCH_MON_REP - Set Delete Transactions
   -- =======================================================
   SET v_marker = 'INSERT INTO ICS_DSCH_MON_REP - Set Delete Transactions';
   INSERT INTO ICS_DSCH_MON_REP
       ( ICS_PAYLOAD_ID
       , ICS_DSCH_MON_REP_ID
       , TRANSACTION_TYPE
       , PRMT_IDENT, PRMT_FEATR_IDENT, LMT_SET_DESIGNATOR, MON_PERIOD_END_DATE) 
   SELECT ICS_DSCH_MON_REP.ICS_PAYLOAD_ID
        , ICS_DSCH_MON_REP.ICS_DSCH_MON_REP_ID
        , 'X' AS TRANSACTION_TYPE
        , PRMT_IDENT, PRMT_FEATR_IDENT, LMT_SET_DESIGNATOR, MON_PERIOD_END_DATE
     FROM ga_ics_flow_icis.ICS_DSCH_MON_REP
    WHERE ICS_DSCH_MON_REP.ICS_PAYLOAD_ID = v_DischargeMonitoringReportSubmission_PID
      AND ICS_DSCH_MON_REP.KEY_HASH IN (SELECT KEY_HASH
                                        FROM CDV_DSCH_MON_REP
                                       WHERE CDV_DSCH_MON_REP.ACTION_TYPE = 'DELETE');
   -- =======================================================
   -- ICS_SNGL_EVT_VIOL - Set Delete Transactions
   -- =======================================================
   SET v_marker = 'INSERT INTO ICS_SNGL_EVT_VIOL - Set Delete Transactions';
   INSERT INTO ICS_SNGL_EVT_VIOL
       ( ICS_PAYLOAD_ID
       , ICS_SNGL_EVT_VIOL_ID
       , TRANSACTION_TYPE
       , PRMT_IDENT, SNGL_EVT_VIOL_CODE, SNGL_EVT_VIOL_DATE) 
   SELECT ICS_SNGL_EVT_VIOL.ICS_PAYLOAD_ID
        , ICS_SNGL_EVT_VIOL.ICS_SNGL_EVT_VIOL_ID
        , 'X' AS TRANSACTION_TYPE
        , PRMT_IDENT, SNGL_EVT_VIOL_CODE, SNGL_EVT_VIOL_DATE
     FROM ga_ics_flow_icis.ICS_SNGL_EVT_VIOL
    WHERE ICS_SNGL_EVT_VIOL.ICS_PAYLOAD_ID = v_SingleEventViolationSubmission_PID
      AND ICS_SNGL_EVT_VIOL.KEY_HASH IN (SELECT KEY_HASH
                                        FROM CDV_SNGL_EVT_VIOL
                                       WHERE CDV_SNGL_EVT_VIOL.ACTION_TYPE = 'DELETE');
   -- =======================================================
   -- ICS_CMPL_SCHD - Set Delete Transactions
   -- =======================================================
   SET v_marker = 'INSERT INTO ICS_CMPL_SCHD - Set Delete Transactions';
   INSERT INTO ICS_CMPL_SCHD
       ( ICS_PAYLOAD_ID
       , ICS_CMPL_SCHD_ID
       , TRANSACTION_TYPE
       , ENFRC_ACTN_IDENT, FINAL_ORDER_IDENT, PRMT_IDENT, CMPL_SCHD_NUM) 
   SELECT ICS_CMPL_SCHD.ICS_PAYLOAD_ID
        , ICS_CMPL_SCHD.ICS_CMPL_SCHD_ID
        , 'X' AS TRANSACTION_TYPE
        , ENFRC_ACTN_IDENT, FINAL_ORDER_IDENT, PRMT_IDENT, CMPL_SCHD_NUM
     FROM ga_ics_flow_icis.ICS_CMPL_SCHD
    WHERE ICS_CMPL_SCHD.ICS_PAYLOAD_ID = v_ComplianceScheduleSubmission_PID
      AND ICS_CMPL_SCHD.KEY_HASH IN (SELECT KEY_HASH
                                        FROM CDV_CMPL_SCHD
                                       WHERE CDV_CMPL_SCHD.ACTION_TYPE = 'DELETE');
  
  -- ICS_DMR_VIOL - Set Delete Transactions
  -- Delete transaction not supported by ICIS for this module
   -- =======================================================
   -- ICS_EFFLU_TRADE_PRTNER - Set Delete Transactions
   -- =======================================================
   SET v_marker = 'INSERT INTO ICS_EFFLU_TRADE_PRTNER - Set Delete Transactions';
   INSERT INTO ICS_EFFLU_TRADE_PRTNER
       ( ICS_PAYLOAD_ID
       , ICS_EFFLU_TRADE_PRTNER_ID
       , TRANSACTION_TYPE
       , PRMT_IDENT, PRMT_FEATR_IDENT, LMT_SET_DESIGNATOR
       , PARAM_CODE, MON_SITE_DESC_CODE, LMT_SEASON_NUM
       , LMT_START_DATE, LMT_END_DATE, LMT_MOD_EFFECTIVE_DATE, TRADE_ID) 
   SELECT ICS_EFFLU_TRADE_PRTNER.ICS_PAYLOAD_ID
        , ICS_EFFLU_TRADE_PRTNER.ICS_EFFLU_TRADE_PRTNER_ID
        , 'X' AS TRANSACTION_TYPE
        , PRMT_IDENT, PRMT_FEATR_IDENT, LMT_SET_DESIGNATOR
        , PARAM_CODE, MON_SITE_DESC_CODE, LMT_SEASON_NUM
        , LMT_START_DATE, LMT_END_DATE, LMT_MOD_EFFECTIVE_DATE, TRADE_ID
     FROM ga_ics_flow_icis.ICS_EFFLU_TRADE_PRTNER
    WHERE ICS_EFFLU_TRADE_PRTNER.ICS_PAYLOAD_ID = v_EffluentTradePartnerSubmission_PID
      AND ICS_EFFLU_TRADE_PRTNER.KEY_HASH IN (SELECT KEY_HASH
                                        FROM CDV_EFFLU_TRADE_PRTNER
                                       WHERE CDV_EFFLU_TRADE_PRTNER.ACTION_TYPE = 'DELETE');
   -- =======================================================
   -- ICS_FRML_ENFRC_ACTN - Set Delete Transactions
   -- =======================================================
   SET v_marker = 'INSERT INTO ICS_FRML_ENFRC_ACTN - Set Delete Transactions';
   INSERT INTO ICS_FRML_ENFRC_ACTN
       ( ICS_PAYLOAD_ID
       , ICS_FRML_ENFRC_ACTN_ID
       , TRANSACTION_TYPE
       , ENFRC_ACTN_IDENT) 
   SELECT ICS_FRML_ENFRC_ACTN.ICS_PAYLOAD_ID
        , ICS_FRML_ENFRC_ACTN.ICS_FRML_ENFRC_ACTN_ID
        , 'X' AS TRANSACTION_TYPE
        , ENFRC_ACTN_IDENT
     FROM ga_ics_flow_icis.ICS_FRML_ENFRC_ACTN
    WHERE ICS_FRML_ENFRC_ACTN.ICS_PAYLOAD_ID = v_FormalEnforcementActionSubmission_PID
      AND ICS_FRML_ENFRC_ACTN.KEY_HASH IN (SELECT KEY_HASH
                                        FROM CDV_FRML_ENFRC_ACTN
                                       WHERE CDV_FRML_ENFRC_ACTN.ACTION_TYPE = 'DELETE');
   -- =======================================================
   -- ICS_INFRML_ENFRC_ACTN - Set Delete Transactions
   -- =======================================================
   SET v_marker = 'INSERT INTO ICS_INFRML_ENFRC_ACTN - Set Delete Transactions';
   INSERT INTO ICS_INFRML_ENFRC_ACTN
       ( ICS_PAYLOAD_ID
       , ICS_INFRML_ENFRC_ACTN_ID
       , TRANSACTION_TYPE
       , ENFRC_ACTN_IDENT) 
   SELECT ICS_INFRML_ENFRC_ACTN.ICS_PAYLOAD_ID
        , ICS_INFRML_ENFRC_ACTN.ICS_INFRML_ENFRC_ACTN_ID
        , 'X' AS TRANSACTION_TYPE
        , ENFRC_ACTN_IDENT
     FROM ga_ics_flow_icis.ICS_INFRML_ENFRC_ACTN
    WHERE ICS_INFRML_ENFRC_ACTN.ICS_PAYLOAD_ID = v_InformalEnforcementActionSubmission_PID
      AND ICS_INFRML_ENFRC_ACTN.KEY_HASH IN (SELECT KEY_HASH
                                        FROM CDV_INFRML_ENFRC_ACTN
                                       WHERE CDV_INFRML_ENFRC_ACTN.ACTION_TYPE = 'DELETE');
  
   -- ICS_ENFRC_ACTN_MILESTONE - Set Delete Transactions
   -- Delete transaction not supported by ICIS for this module
  
   -- ICS_FINAL_ORDER_VIOL_LNK - Set Delete Transactions
   -- Delete transaction not supported by ICIS for this module
   -- =======================================================
   -- ICS_CSO_EVT_REP - Set Delete Transactions
   -- =======================================================
   SET v_marker = 'INSERT INTO ICS_CSO_EVT_REP - Set Delete Transactions';
   INSERT INTO ICS_CSO_EVT_REP
       ( ICS_PAYLOAD_ID
       , ICS_CSO_EVT_REP_ID
       , TRANSACTION_TYPE
       , PRMT_IDENT, CSO_EVT_DATE, CSO_EVT_ID) 
   SELECT ICS_CSO_EVT_REP.ICS_PAYLOAD_ID
        , ICS_CSO_EVT_REP.ICS_CSO_EVT_REP_ID
        , 'X' AS TRANSACTION_TYPE
        , PRMT_IDENT, CSO_EVT_DATE, CSO_EVT_ID
     FROM ga_ics_flow_icis.ICS_CSO_EVT_REP
    WHERE ICS_CSO_EVT_REP.ICS_PAYLOAD_ID = v_CSOEventReportSubmission_PID
      AND ICS_CSO_EVT_REP.KEY_HASH IN (SELECT KEY_HASH
                                        FROM CDV_CSO_EVT_REP
                                       WHERE CDV_CSO_EVT_REP.ACTION_TYPE = 'DELETE');
   -- =======================================================
   -- ICS_SW_EVT_REP - Set Delete Transactions
   -- =======================================================
   SET v_marker = 'INSERT INTO ICS_SW_EVT_REP - Set Delete Transactions';
   INSERT INTO ICS_SW_EVT_REP
       ( ICS_PAYLOAD_ID
       , ICS_SW_EVT_REP_ID
       , TRANSACTION_TYPE
       , PRMT_IDENT, DATE_STRM_EVT_SMPL, SW_EVT_ID) 
   SELECT ICS_SW_EVT_REP.ICS_PAYLOAD_ID
        , ICS_SW_EVT_REP.ICS_SW_EVT_REP_ID
        , 'X' AS TRANSACTION_TYPE
        , PRMT_IDENT, DATE_STRM_EVT_SMPL, SW_EVT_ID
     FROM ga_ics_flow_icis.ICS_SW_EVT_REP
    WHERE ICS_SW_EVT_REP.ICS_PAYLOAD_ID = v_SWEventReportSubmission_PID
      AND ICS_SW_EVT_REP.KEY_HASH IN (SELECT KEY_HASH
                                        FROM CDV_SW_EVT_REP
                                       WHERE CDV_SW_EVT_REP.ACTION_TYPE = 'DELETE');
   -- =======================================================
   -- ICS_CAFO_ANNUL_REP - Set Delete Transactions
   -- =======================================================
   SET v_marker = 'INSERT INTO ICS_CAFO_ANNUL_REP - Set Delete Transactions';
   INSERT INTO ICS_CAFO_ANNUL_REP
       ( ICS_PAYLOAD_ID
       , ICS_CAFO_ANNUL_REP_ID
       , TRANSACTION_TYPE
       , PRMT_IDENT, PRMT_AUTH_REP_RCVD_DATE) 
   SELECT ICS_CAFO_ANNUL_REP.ICS_PAYLOAD_ID
        , ICS_CAFO_ANNUL_REP.ICS_CAFO_ANNUL_REP_ID
        , 'X' AS TRANSACTION_TYPE
        , PRMT_IDENT, PRMT_AUTH_REP_RCVD_DATE
     FROM ga_ics_flow_icis.ICS_CAFO_ANNUL_REP
    WHERE ICS_CAFO_ANNUL_REP.ICS_PAYLOAD_ID = v_CAFOAnnualReportSubmission_PID
      AND ICS_CAFO_ANNUL_REP.KEY_HASH IN (SELECT KEY_HASH
                                        FROM CDV_CAFO_ANNUL_REP
                                       WHERE CDV_CAFO_ANNUL_REP.ACTION_TYPE = 'DELETE');
   -- =======================================================
   -- ICS_LOC_LMTS_PROG_REP - Set Delete Transactions
   -- =======================================================
   SET v_marker = 'INSERT INTO ICS_LOC_LMTS_PROG_REP - Set Delete Transactions';
   INSERT INTO ICS_LOC_LMTS_PROG_REP
       ( ICS_PAYLOAD_ID
       , ICS_LOC_LMTS_PROG_REP_ID
       , TRANSACTION_TYPE
       , PRMT_IDENT, PRMT_AUTH_REP_RCVD_DATE) 
   SELECT ICS_LOC_LMTS_PROG_REP.ICS_PAYLOAD_ID
        , ICS_LOC_LMTS_PROG_REP.ICS_LOC_LMTS_PROG_REP_ID
        , 'X' AS TRANSACTION_TYPE
        , PRMT_IDENT, PRMT_AUTH_REP_RCVD_DATE
     FROM ga_ics_flow_icis.ICS_LOC_LMTS_PROG_REP
    WHERE ICS_LOC_LMTS_PROG_REP.ICS_PAYLOAD_ID = v_LocalLimitsProgramReportSubmission_PID
      AND ICS_LOC_LMTS_PROG_REP.KEY_HASH IN (SELECT KEY_HASH
                                        FROM CDV_LOC_LMTS_PROG_REP
                                       WHERE CDV_LOC_LMTS_PROG_REP.ACTION_TYPE = 'DELETE');
   -- =======================================================
   -- ICS_PRETR_PERF_SUMM - Set Delete Transactions
   -- =======================================================
   SET v_marker = 'INSERT INTO ICS_PRETR_PERF_SUMM - Set Delete Transactions';
   INSERT INTO ICS_PRETR_PERF_SUMM
       ( ICS_PAYLOAD_ID
       , ICS_PRETR_PERF_SUMM_ID
       , TRANSACTION_TYPE
       , PRMT_IDENT, PRETR_PERF_SUMM_END_DATE) 
   SELECT ICS_PRETR_PERF_SUMM.ICS_PAYLOAD_ID
        , ICS_PRETR_PERF_SUMM.ICS_PRETR_PERF_SUMM_ID
        , 'X' AS TRANSACTION_TYPE
        , PRMT_IDENT, PRETR_PERF_SUMM_END_DATE
     FROM ga_ics_flow_icis.ICS_PRETR_PERF_SUMM
    WHERE ICS_PRETR_PERF_SUMM.ICS_PAYLOAD_ID = v_PretreatmentPerformanceSummarySubmission_PID
      AND ICS_PRETR_PERF_SUMM.KEY_HASH IN (SELECT KEY_HASH
                                        FROM CDV_PRETR_PERF_SUMM
                                       WHERE CDV_PRETR_PERF_SUMM.ACTION_TYPE = 'DELETE');
   -- =======================================================
   -- ICS_BS_PROG_REP - Set Delete Transactions
   -- =======================================================
   SET v_marker = 'INSERT INTO ICS_BS_PROG_REP - Set Delete Transactions';
   INSERT INTO ICS_BS_PROG_REP
       ( ICS_PAYLOAD_ID
       , ICS_BS_PROG_REP_ID
       , TRANSACTION_TYPE
       , PRMT_IDENT, REP_COVERAGE_END_DATE) 
   SELECT ICS_BS_PROG_REP.ICS_PAYLOAD_ID
        , ICS_BS_PROG_REP.ICS_BS_PROG_REP_ID
        , 'X' AS TRANSACTION_TYPE
        , PRMT_IDENT, REP_COVERAGE_END_DATE
     FROM ga_ics_flow_icis.ICS_BS_PROG_REP
    WHERE ICS_BS_PROG_REP.ICS_PAYLOAD_ID = v_BiosolidsProgramReportSubmission_PID
      AND ICS_BS_PROG_REP.KEY_HASH IN (SELECT KEY_HASH
                                        FROM CDV_BS_PROG_REP
                                       WHERE CDV_BS_PROG_REP.ACTION_TYPE = 'DELETE');
   -- =======================================================
   -- ICS_SSO_ANNUL_REP - Set Delete Transactions
   -- =======================================================
   SET v_marker = 'INSERT INTO ICS_SSO_ANNUL_REP - Set Delete Transactions';
   INSERT INTO ICS_SSO_ANNUL_REP
       ( ICS_PAYLOAD_ID
       , ICS_SSO_ANNUL_REP_ID
       , TRANSACTION_TYPE
       , PRMT_IDENT, SSO_ANNUL_REP_RCVD_DATE) 
   SELECT ICS_SSO_ANNUL_REP.ICS_PAYLOAD_ID
        , ICS_SSO_ANNUL_REP.ICS_SSO_ANNUL_REP_ID
        , 'X' AS TRANSACTION_TYPE
        , PRMT_IDENT, SSO_ANNUL_REP_RCVD_DATE
     FROM ga_ics_flow_icis.ICS_SSO_ANNUL_REP
    WHERE ICS_SSO_ANNUL_REP.ICS_PAYLOAD_ID = v_SSOAnnualReportSubmission_PID
      AND ICS_SSO_ANNUL_REP.KEY_HASH IN (SELECT KEY_HASH
                                        FROM CDV_SSO_ANNUL_REP
                                       WHERE CDV_SSO_ANNUL_REP.ACTION_TYPE = 'DELETE');
   -- =======================================================
   -- ICS_SSO_EVT_REP - Set Delete Transactions
   -- =======================================================
   SET v_marker = 'INSERT INTO ICS_SSO_EVT_REP - Set Delete Transactions';
   INSERT INTO ICS_SSO_EVT_REP
       ( ICS_PAYLOAD_ID
       , ICS_SSO_EVT_REP_ID
       , TRANSACTION_TYPE
       , PRMT_IDENT, SSO_EVT_DATE, SSO_EVT_ID) 
   SELECT ICS_SSO_EVT_REP.ICS_PAYLOAD_ID
        , ICS_SSO_EVT_REP.ICS_SSO_EVT_REP_ID
        , 'X' AS TRANSACTION_TYPE
        , PRMT_IDENT, SSO_EVT_DATE, SSO_EVT_ID
     FROM ga_ics_flow_icis.ICS_SSO_EVT_REP
    WHERE ICS_SSO_EVT_REP.ICS_PAYLOAD_ID = v_SSOEventReportSubmission_PID
      AND ICS_SSO_EVT_REP.KEY_HASH IN (SELECT KEY_HASH
                                        FROM CDV_SSO_EVT_REP
                                       WHERE CDV_SSO_EVT_REP.ACTION_TYPE = 'DELETE');
   -- =======================================================
   -- ICS_SSO_MONTHLY_EVT_REP - Set Delete Transactions
   -- =======================================================
   SET v_marker = 'INSERT INTO ICS_SSO_MONTHLY_EVT_REP - Set Delete Transactions';
   INSERT INTO ICS_SSO_MONTHLY_EVT_REP
       ( ICS_PAYLOAD_ID
       , ICS_SSO_MONTHLY_EVT_REP_ID
       , TRANSACTION_TYPE
       , PRMT_IDENT, SSO_MONTHLY_REP_RCVD_DATE) 
   SELECT ICS_SSO_MONTHLY_EVT_REP.ICS_PAYLOAD_ID
        , ICS_SSO_MONTHLY_EVT_REP.ICS_SSO_MONTHLY_EVT_REP_ID
        , 'X' AS TRANSACTION_TYPE
        , PRMT_IDENT, SSO_MONTHLY_REP_RCVD_DATE
     FROM ga_ics_flow_icis.ICS_SSO_MONTHLY_EVT_REP
    WHERE ICS_SSO_MONTHLY_EVT_REP.ICS_PAYLOAD_ID = v_SSOMonthlyEventReportSubmission_PID
      AND ICS_SSO_MONTHLY_EVT_REP.KEY_HASH IN (SELECT KEY_HASH
                                        FROM CDV_SSO_MONTHLY_EVT_REP
                                       WHERE CDV_SSO_MONTHLY_EVT_REP.ACTION_TYPE = 'DELETE');
   -- =======================================================
   -- ICS_SWMS_4_PROG_REP - Set Delete Transactions
   -- =======================================================
   SET v_marker = 'INSERT INTO ICS_SWMS_4_PROG_REP - Set Delete Transactions';
   INSERT INTO ICS_SWMS_4_PROG_REP
       ( ICS_PAYLOAD_ID
       , ICS_SWMS_4_PROG_REP_ID
       , TRANSACTION_TYPE
       , PRMT_IDENT, SW_MS_4_REP_RCVD_DATE) 
   SELECT ICS_SWMS_4_PROG_REP.ICS_PAYLOAD_ID
        , ICS_SWMS_4_PROG_REP.ICS_SWMS_4_PROG_REP_ID
        , 'X' AS TRANSACTION_TYPE
        , PRMT_IDENT, SW_MS_4_REP_RCVD_DATE
     FROM ga_ics_flow_icis.ICS_SWMS_4_PROG_REP
    WHERE ICS_SWMS_4_PROG_REP.ICS_PAYLOAD_ID = v_SWMS4ProgramReportSubmission_PID
      AND ICS_SWMS_4_PROG_REP.KEY_HASH IN (SELECT KEY_HASH
                                        FROM CDV_SWMS_4_PROG_REP
                                       WHERE CDV_SWMS_4_PROG_REP.ACTION_TYPE = 'DELETE');
  
   -- ICS_SCHD_EVT_VIOL - Set Delete Transactions
   -- Delete transaction not supported by ICIS for this module
  
   -- ICS_CMPL_MON_LNK - Set Delete Transactions
   /* --------------------------------------------------------------
      ---Conditional biz keys require manual development of SQL for this module!
   INSERT INTO ics_cmpl_mon_lnk
       ( ics_payload_id
       , ics_cmpl_mon_lnk_id
       , transaction_type
       , prmt_ident, cmpl_mon_catg_code, cmpl_mon_date, prmt_ident_2
       , sngl_evt_viol_code, sngl_evt_viol_date, enfrc_actn_ident
       , rep_coverage_end_date, prmt_auth_rep_rcvd_date, cso_evt_date
       , pretr_perf_summ_end_date, sso_annul_rep_rcvd_date, sso_evt_date
       , sso_monthly_rep_rcvd_date, date_strm_evt_smpl
       , sw_ms_4_rep_rcvd_date, cmpl_mon_catg_code_2, cmpl_mon_date_2) 
   SELECT ics_cmpl_mon_lnk.ics_payload_id
        , ics_cmpl_mon_lnk.ics_cmpl_mon_lnk_id
        , 'X' AS transaction_type
        , prmt_ident, cmpl_mon_catg_code, cmpl_mon_date, prmt_ident_2
        , sngl_evt_viol_code, sngl_evt_viol_date, enfrc_actn_ident
        , rep_coverage_end_date, prmt_auth_rep_rcvd_date, cso_evt_date
        , pretr_perf_summ_end_date, sso_annul_rep_rcvd_date, sso_evt_date
        , sso_monthly_rep_rcvd_date, date_strm_evt_smpl
        , sw_ms_4_rep_rcvd_date, cmpl_mon_catg_code_2, cmpl_mon_date_2
     FROM ga_ics_flow_icis.ics_cmpl_mon_lnk
    WHERE ics_cmpl_mon_lnk.ics_payload_id in (SELECT ics_payload_id 
                           FROM ics_payload 
                          WHERE operation = 'ComplianceMonitoringLinkageSubmission'
                            AND auto_gen_deletes = 'Y' AND enabled = 'Y'))
      AND ics_cmpl_mon_lnk.key_hash IN (SELECT key_hash
                                        FROM cdv_cmpl_mon_lnk
                                       WHERE cdv_cmpl_mon_lnk.action_type = 'DELETE');
   */
  
   -- ICS_ENFRC_ACTN_VIOL_LNK - Set Delete Transactions
   -- Delete transaction not supported by ICIS for this module
    
   /* **************************************************
   * ICS_DMR_PROG_REP_LNK:  Set Delete Transactions
   * **************************************************/
   SET v_marker = 'SELECT ICS_PAYLOAD_ID FOR DMRProgramReportLinkageSubmission';
   SELECT ICS_PAYLOAD_ID
     INTO v_payload_id
     FROM ICS_PAYLOAD 
    WHERE OPERATION = 'DMRProgramReportLinkageSubmission';
   -- ==============================================================
   -- NOTE: CTAS doesn't rollback, so don't drop and CTAS here 
   --       drop & create table in cdc_create_cdv_tables_sp
   --
   -- ==============================================================
   -- DROP TABLE IF EXISTS tmp_prog_lnk;
   -- CREATE TABLE tmp_prog_lnk AS
   SET v_marker = 'INSERT INTO CDC_TMP_PROG_LNK';
   INSERT INTO CDC_TMP_PROG_LNK
      (NEW_ICS_DMR_PROG_REP_LNK_ID
      ,ICS_DMR_PROG_REP_LNK_ID
      ,PRMT_IDENT
      ,PRMT_FEATR_IDENT
      ,LMT_SET_DESIGNATOR
      ,MON_PERIOD_END_DATE
      ,KEY_HASH
      ,DATA_HASH)
   SELECT UUID()
         ,vw.*
     FROM (SELECT DISTINCT src.ICS_DMR_PROG_REP_LNK_ID
                 ,src.PRMT_IDENT
                 ,src.PRMT_FEATR_IDENT
                 ,src.LMT_SET_DESIGNATOR
                 ,src.MON_PERIOD_END_DATE
                 ,src.KEY_HASH
                 ,src.DATA_HASH
             FROM ga_ics_flow_icis.ICS_DMR_PROG_REP_LNK src
             JOIN CDV_DMR_PROG_REP_LNK cdv
               ON cdv.KEY_HASH = src.KEY_HASH
            WHERE cdv.ACTION_TYPE = 'DELETE') vw;
   -- --------------------
   -- ICS_DMR_PROG_REP_LNK
   -- --------------------
   SET v_marker = 'INSERT INTO ICS_DMR_PROG_REP_LNK - Set Delete Transactions';
   INSERT INTO ICS_DMR_PROG_REP_LNK
      ( ICS_DMR_PROG_REP_LNK_ID
      , ICS_PAYLOAD_ID
      , TRANSACTION_TYPE
      , PRMT_IDENT
      , PRMT_FEATR_IDENT
      , LMT_SET_DESIGNATOR
      , MON_PERIOD_END_DATE
      , KEY_HASH
      , DATA_HASH) 
   SELECT NEW_ICS_DMR_PROG_REP_LNK_ID
         ,v_payload_id
         ,'X'
         ,PRMT_IDENT
         ,PRMT_FEATR_IDENT
         ,LMT_SET_DESIGNATOR
         ,MON_PERIOD_END_DATE
         ,KEY_HASH
         ,DATA_HASH
     FROM CDC_TMP_PROG_LNK;
   -- --------------
   -- ICS_LNK_BS_REP
   -- --------------
   SET v_marker = 'INSERT INTO ICS_LNK_BS_REP - Set Delete Transactions';
   INSERT INTO ICS_LNK_BS_REP
      ( ICS_LNK_BS_REP_ID
      , ICS_DMR_PROG_REP_LNK_ID
      , ICS_CMPL_MON_LNK_ID
      , PRMT_IDENT
      , REP_COVERAGE_END_DATE
      , DATA_HASH)
   SELECT UUID()
         ,ICS_DMR_PROG_REP_LNK_ID
         ,NULL
         ,PRMT_IDENT
         ,REP_COVERAGE_END_DATE
         ,DATA_HASH
     FROM (SELECT DISTINCT cdc.ICS_DMR_PROG_REP_LNK_ID
                 ,ics.PRMT_IDENT
                 ,ics.REP_COVERAGE_END_DATE
                 ,ics.DATA_HASH
             FROM ga_ics_flow_icis.ICS_LNK_BS_REP ics
             JOIN CDC_TMP_PROG_LNK cdc
               ON cdc.ICS_DMR_PROG_REP_LNK_ID = ics.ICS_DMR_PROG_REP_LNK_ID) vw;
   -- ------------------
   -- ICS_LNK_SW_EVT_REP
   -- ------------------
   SET v_marker = 'INSERT INTO ICS_LNK_SW_EVT_REP - Set Delete Transactions';
   INSERT INTO ICS_LNK_SW_EVT_REP
      ( ICS_LNK_SW_EVT_REP_ID
      , ICS_DMR_PROG_REP_LNK_ID
      , ICS_CMPL_MON_LNK_ID
      , PRMT_IDENT
      , DATE_STRM_EVT_SMPL
      , SW_EVT_ID
      , DATA_HASH)  
   SELECT UUID()
         ,ICS_DMR_PROG_REP_LNK_ID
         ,NULL
         ,PRMT_IDENT
         ,DATE_STRM_EVT_SMPL
         ,SW_EVT_ID
         ,DATA_HASH
     FROM (SELECT DISTINCT cdc.ICS_DMR_PROG_REP_LNK_ID
                 ,ics.PRMT_IDENT
                 ,ics.DATE_STRM_EVT_SMPL
                 ,ics.SW_EVT_ID
                 ,ics.DATA_HASH
             FROM ga_ics_flow_icis.ICS_LNK_SW_EVT_REP ics
             JOIN CDC_TMP_PROG_LNK cdc
               ON cdc.ICS_DMR_PROG_REP_LNK_ID = ics.ICS_DMR_PROG_REP_LNK_ID) vw;
   /* **************************************************
   * ICS_CMPL_MON_LNK:  Set Delete Transactions
   * **************************************************/
   SET v_marker = 'SELECT ICS_PAYLOAD_ID FOR ComplianceMonitoringLinkageSubmission';
   SELECT ICS_PAYLOAD_ID
     INTO v_payload_id
     FROM ICS_PAYLOAD 
    WHERE OPERATION = 'ComplianceMonitoringLinkageSubmission';
   --
   SET v_marker = 'INSERT INTO CDC_TMP_CMPL_MON_LNK - Set Delete Transactions';
   INSERT INTO CDC_TMP_CMPL_MON_LNK
      (NEW_ICS_CMPL_MON_LNK_ID
      ,ICS_CMPL_MON_LNK_ID
      ,SRC_SYSTM_IDENT
      ,PRMT_IDENT
      ,CMPL_MON_CATG_CODE
      ,CMPL_MON_DATE
      ,KEY_HASH
      ,DATA_HASH)
   SELECT UUID()
         ,ICS_CMPL_MON_LNK_ID
         ,SRC_SYSTM_IDENT
         ,PRMT_IDENT
         ,CMPL_MON_CATG_CODE
         ,CMPL_MON_DATE
         ,NULL
         ,NULL
     FROM (SELECT DISTINCT src.ICS_CMPL_MON_LNK_ID
                 ,src.PRMT_IDENT
                 ,src.CMPL_MON_CATG_CODE
                 ,src.CMPL_MON_DATE
                 ,src.SRC_SYSTM_IDENT
             FROM ga_ics_flow_icis.ICS_CMPL_MON_LNK src
             JOIN CDV_CMPL_MON_LNK cdv
               ON cdv.KEY_HASH = src.KEY_HASH
            WHERE cdv.ACTION_TYPE = 'DELETE') vw;
   -- ----------------
   -- ICS_CMPL_MON_LNK
   -- ----------------
   SET v_marker = 'INSERT INTO ICS_CMPL_MON_LNK - Set Delete Transactions';
   INSERT INTO ICS_CMPL_MON_LNK
      ( ICS_CMPL_MON_LNK_ID
      , ICS_PAYLOAD_ID
      , SRC_SYSTM_IDENT
      , TRANSACTION_TYPE
      , TRANSACTION_TIMESTAMP
      , PRMT_IDENT
      , CMPL_MON_CATG_CODE
      , CMPL_MON_DATE
      , KEY_HASH
      , DATA_HASH)
   SELECT NEW_ICS_CMPL_MON_LNK_ID
         ,v_payload_id
         ,SRC_SYSTM_IDENT
         ,'X'
         ,NOW()
         ,PRMT_IDENT
         ,CMPL_MON_CATG_CODE
         ,CMPL_MON_DATE
         ,NULL
         ,NULL
     FROM CDC_TMP_CMPL_MON_LNK;
   -- --------------
   -- ICS_LNK_BS_REP
   -- --------------
   SET v_marker = 'INSERT INTO ICS_LNK_BS_REP - Set Delete Transactions';
   INSERT INTO ICS_LNK_BS_REP
      ( ICS_LNK_BS_REP_ID
      , ICS_DMR_PROG_REP_LNK_ID
      , ICS_CMPL_MON_LNK_ID
      , PRMT_IDENT
      , REP_COVERAGE_END_DATE
      , DATA_HASH)
   SELECT UUID()
         ,NULL
         ,NEW_ICS_CMPL_MON_LNK_ID
         ,PRMT_IDENT
         ,REP_COVERAGE_END_DATE
         ,DATA_HASH
     FROM (SELECT DISTINCT ics.PRMT_IDENT
                 ,ics.REP_COVERAGE_END_DATE
                 ,ics.DATA_HASH
                 ,cdc.NEW_ICS_CMPL_MON_LNK_ID
             FROM ga_ics_flow_icis.ICS_LNK_BS_REP ics
             JOIN CDC_TMP_CMPL_MON_LNK cdc
               ON cdc.ICS_CMPL_MON_LNK_ID = ics.ICS_CMPL_MON_LNK_ID) vw;
   -- -------------------
   -- ICS_LNK_ST_CMPL_MON
   -- -------------------
   SET v_marker = 'INSERT INTO ICS_LNK_ST_CMPL_MON - Set Delete Transactions';
   INSERT INTO ICS_LNK_ST_CMPL_MON
      ( ICS_LNK_ST_CMPL_MON_ID
      , ICS_CMPL_MON_LNK_ID
      , PRMT_IDENT
      , CMPL_MON_CATG_CODE
      , CMPL_MON_DATE
      , DATA_HASH)
   SELECT UUID()
         ,vw.*
     FROM (SELECT DISTINCT cdc.NEW_ICS_CMPL_MON_LNK_ID
                 ,ics.PRMT_IDENT
                 ,ics.CMPL_MON_CATG_CODE
                 ,ics.CMPL_MON_DATE
                 ,ics.DATA_HASH
             FROM ga_ics_flow_icis.ICS_LNK_ST_CMPL_MON ics
             JOIN CDC_TMP_CMPL_MON_LNK cdc
               ON cdc.ICS_CMPL_MON_LNK_ID = ics.ICS_CMPL_MON_LNK_ID) vw;
   -- -----------------
   --  ICS_LNK_SNGL_EVT
   -- -----------------
   SET v_marker = 'INSERT INTO ICS_LNK_SNGL_EVT - Set Delete Transactions';
   INSERT INTO ICS_LNK_SNGL_EVT 
      ( ICS_LNK_SNGL_EVT_ID
      , ICS_CMPL_MON_LNK_ID
      , PRMT_IDENT
      , SNGL_EVT_VIOL_CODE
      , SNGL_EVT_VIOL_DATE
      , DATA_HASH)
   SELECT UUID()
         ,vw.*
     FROM (SELECT DISTINCT cdc.NEW_ICS_CMPL_MON_LNK_ID
                 ,ics.PRMT_IDENT
                 ,ics.SNGL_EVT_VIOL_CODE
                 ,ics.SNGL_EVT_VIOL_DATE
                 ,ics.DATA_HASH
             FROM ga_ics_flow_icis.ICS_LNK_SNGL_EVT ics
             JOIN CDC_TMP_CMPL_MON_LNK cdc
               ON cdc.ICS_CMPL_MON_LNK_ID = ics.ICS_CMPL_MON_LNK_ID) vw;
   -- -------------------
   -- ICS_LNK_CSO_EVT_REP
   -- -------------------
   SET v_marker = 'INSERT INTO ICS_LNK_CSO_EVT_REP - Set Delete Transactions';
   INSERT INTO ICS_LNK_CSO_EVT_REP
      ( ICS_LNK_CSO_EVT_REP_ID
      , ICS_CMPL_MON_LNK_ID
      , PRMT_IDENT
      , CSO_EVT_DATE
      , CSO_EVT_ID
      , DATA_HASH)
   SELECT UUID()
         ,vw.*
     FROM (SELECT DISTINCT cdc.NEW_ICS_CMPL_MON_LNK_ID
                 ,ics.PRMT_IDENT
                 ,ics.CSO_EVT_DATE
                 ,ics.CSO_EVT_ID
                 ,ics.DATA_HASH
             FROM ga_ics_flow_icis.ICS_LNK_CSO_EVT_REP ics
             JOIN CDC_TMP_CMPL_MON_LNK cdc
               ON cdc.ICS_CMPL_MON_LNK_ID = ics.ICS_CMPL_MON_LNK_ID) vw;
   -- ------------------
   -- ICS_LNK_ENFRC_ACTN 
   -- ------------------
   SET v_marker = 'INSERT INTO ICS_LNK_ENFRC_ACTN - Set Delete Transactions';
   INSERT INTO ICS_LNK_ENFRC_ACTN
      ( ICS_LNK_ENFRC_ACTN_ID
      , ICS_CMPL_MON_LNK_ID
      , ENFRC_ACTN_IDENT
      , DATA_HASH)
   SELECT UUID()
         ,vw.*
     FROM (SELECT DISTINCT cdc.NEW_ICS_CMPL_MON_LNK_ID
                 ,ics.ENFRC_ACTN_IDENT
                 ,ics.DATA_HASH
             FROM ga_ics_flow_icis.ICS_LNK_ENFRC_ACTN ics
             JOIN CDC_TMP_CMPL_MON_LNK cdc
               ON cdc.ICS_CMPL_MON_LNK_ID = ics.ICS_CMPL_MON_LNK_ID) vw;
   -- --------------------
   -- ICS_LNK_LOC_LMTS_REP
   -- --------------------
   SET v_marker = 'INSERT INTO ICS_LNK_LOC_LMTS_REP - Set Delete Transactions';
   INSERT INTO ICS_LNK_LOC_LMTS_REP
      ( ICS_LNK_LOC_LMTS_REP_ID
      , ICS_CMPL_MON_LNK_ID
      , PRMT_IDENT
      , PRMT_AUTH_REP_RCVD_DATE
      , DATA_HASH)
   SELECT UUID()
         ,vw.*
     FROM (SELECT DISTINCT cdc.NEW_ICS_CMPL_MON_LNK_ID
                 ,ics.PRMT_IDENT
                 ,ics.PRMT_AUTH_REP_RCVD_DATE
                 ,ics.DATA_HASH
             FROM ga_ics_flow_icis.ICS_LNK_LOC_LMTS_REP ics
             JOIN CDC_TMP_CMPL_MON_LNK cdc
               ON cdc.ICS_CMPL_MON_LNK_ID = ics.ICS_CMPL_MON_LNK_ID) vw;
   -- ---------------------------
   -- ICS_LNK_SSO_MONTHLY_EVT_REP
   -- ---------------------------
   SET v_marker = 'INSERT INTO ICS_LNK_SSO_MONTHLY_EVT_REP - Set Delete Transactions';
   INSERT INTO ICS_LNK_SSO_MONTHLY_EVT_REP
      ( ICS_LNK_SSO_MONTHLY_EVT_REP_ID
      , ICS_CMPL_MON_LNK_ID
      , PRMT_IDENT
      , SSO_MONTHLY_REP_RCVD_DATE
      , DATA_HASH)
   SELECT UUID()
         ,vw.*
     FROM (SELECT DISTINCT cdc.NEW_ICS_CMPL_MON_LNK_ID
                 ,ics.PRMT_IDENT
                 ,ics.SSO_MONTHLY_REP_RCVD_DATE
                 ,ics.DATA_HASH
             FROM ga_ics_flow_icis.ICS_LNK_SSO_MONTHLY_EVT_REP ics
             JOIN CDC_TMP_CMPL_MON_LNK cdc
               ON cdc.ICS_CMPL_MON_LNK_ID = ics.ICS_CMPL_MON_LNK_ID) vw;
   -- ----------------------
   -- ICS_LNK_CAFO_ANNUL_REP
   -- ----------------------
   SET v_marker = 'INSERT INTO ICS_LNK_CAFO_ANNUL_REP - Set Delete Transactions';
   INSERT INTO ICS_LNK_CAFO_ANNUL_REP
      ( ICS_LNK_CAFO_ANNUL_REP_ID
      , ICS_CMPL_MON_LNK_ID
      , PRMT_IDENT
      , PRMT_AUTH_REP_RCVD_DATE
      , DATA_HASH)
   SELECT UUID()
         ,vw.*
     FROM (SELECT DISTINCT cdc.NEW_ICS_CMPL_MON_LNK_ID
                 ,ics.PRMT_IDENT
                 ,ics.PRMT_AUTH_REP_RCVD_DATE
                 ,ics.DATA_HASH
             FROM ga_ics_flow_icis.ICS_LNK_CAFO_ANNUL_REP ics
             JOIN CDC_TMP_CMPL_MON_LNK cdc
               ON cdc.ICS_CMPL_MON_LNK_ID = ics.ICS_CMPL_MON_LNK_ID) vw;
   -- ----------------------
   -- ICS_LNK_PRETR_PERF_REP
   -- ----------------------
   SET v_marker = 'INSERT INTO ICS_LNK_PRETR_PERF_REP - Set Delete Transactions';
   INSERT INTO ICS_LNK_PRETR_PERF_REP
      ( ICS_LNK_PRETR_PERF_REP_ID
      , ICS_CMPL_MON_LNK_ID
      , PRMT_IDENT
      , PRETR_PERF_SUMM_END_DATE
      , DATA_HASH)
   SELECT UUID()
         ,vw.*
     FROM (SELECT DISTINCT cdc.NEW_ICS_CMPL_MON_LNK_ID
                 ,ics.PRMT_IDENT
                 ,ics.PRETR_PERF_SUMM_END_DATE
                 ,ics.DATA_HASH
             FROM ga_ics_flow_icis.ICS_LNK_PRETR_PERF_REP ics
             JOIN CDC_TMP_CMPL_MON_LNK cdc
               ON cdc.ICS_CMPL_MON_LNK_ID = ics.ICS_CMPL_MON_LNK_ID) vw;
   -- -------------------
   -- ICS_LNK_SSO_EVT_REP
   -- -------------------
   SET v_marker = 'INSERT INTO ICS_LNK_SSO_EVT_REP - Set Delete Transactions';
   INSERT INTO ICS_LNK_SSO_EVT_REP
      ( ICS_LNK_SSO_EVT_REP_ID
      , ICS_CMPL_MON_LNK_ID
      , PRMT_IDENT
      , SSO_EVT_DATE
      , SSO_EVT_ID
      , DATA_HASH)
   SELECT UUID()
         ,vw.*
     FROM (SELECT DISTINCT cdc.NEW_ICS_CMPL_MON_LNK_ID
                 ,ics.PRMT_IDENT
                 ,ics.SSO_EVT_DATE
                 ,ics.SSO_EVT_ID
                 ,ics.DATA_HASH
             FROM ga_ics_flow_icis.ICS_LNK_SSO_EVT_REP ics
             JOIN CDC_TMP_CMPL_MON_LNK cdc
               ON cdc.ICS_CMPL_MON_LNK_ID = ics.ICS_CMPL_MON_LNK_ID) vw;
   -- ---------------------
   -- ICS_LNK_FEDR_CMPL_MON
   -- ---------------------
   SET v_marker = 'INSERT INTO ICS_LNK_FEDR_CMPL_MON - Set Delete Transactions';
   INSERT INTO ICS_LNK_FEDR_CMPL_MON
      ( ICS_LNK_FEDR_CMPL_MON_ID
      , ICS_CMPL_MON_LNK_ID
      , PROG_SYSTM_ACRONYM
      , PROG_SYSTM_IDENT
      , FEDR_STATUTE_CODE
      , CMPL_MON_ACTY_TYPE_CODE
      , CMPL_MON_CATG_CODE
      , CMPL_MON_DATE
      , DATA_HASH)
   SELECT UUID()
         ,vw.*
     FROM (SELECT DISTINCT cdc.NEW_ICS_CMPL_MON_LNK_ID
                 ,ics.PROG_SYSTM_ACRONYM
                 ,ics.PROG_SYSTM_IDENT
                 ,ics.FEDR_STATUTE_CODE
                 ,ics.CMPL_MON_ACTY_TYPE_CODE
                 ,ics.CMPL_MON_CATG_CODE
                 ,ics.CMPL_MON_DATE
                 ,ics.DATA_HASH
             FROM ga_ics_flow_icis.ICS_LNK_FEDR_CMPL_MON ics
             JOIN CDC_TMP_CMPL_MON_LNK cdc
               ON cdc.ICS_CMPL_MON_LNK_ID = ics.ICS_CMPL_MON_LNK_ID) vw;
   -- ---------------------
   -- ICS_LNK_SSO_ANNUL_REP
   -- ---------------------
   SET v_marker = 'INSERT INTO ICS_LNK_SSO_ANNUL_REP - Set Delete Transactions';
   INSERT INTO ICS_LNK_SSO_ANNUL_REP
      ( ICS_LNK_SSO_ANNUL_REP_ID
      , ICS_CMPL_MON_LNK_ID
      , PRMT_IDENT
      , SSO_ANNUL_REP_RCVD_DATE
      , DATA_HASH)
   SELECT UUID()
         ,vw.*
     FROM (SELECT DISTINCT cdc.NEW_ICS_CMPL_MON_LNK_ID
                 ,ics.PRMT_IDENT
                 ,ics.SSO_ANNUL_REP_RCVD_DATE
                 ,ics.DATA_HASH
             FROM ga_ics_flow_icis.ICS_LNK_SSO_ANNUL_REP ics
             JOIN CDC_TMP_CMPL_MON_LNK cdc
               ON cdc.ICS_CMPL_MON_LNK_ID = ics.ICS_CMPL_MON_LNK_ID) vw;
   -- ------------------
   -- ICS_LNK_SW_EVT_REP
   -- ------------------
   SET v_marker = 'INSERT INTO ICS_LNK_SW_EVT_REP - Set Delete Transactions';
   INSERT INTO ICS_LNK_SW_EVT_REP
      ( ICS_LNK_SW_EVT_REP_ID
      -- , ICS_DMR_PROG_REP_LNK_ID
      , ICS_CMPL_MON_LNK_ID
      , PRMT_IDENT
      , DATE_STRM_EVT_SMPL
      , SW_EVT_ID
      , DATA_HASH)
   SELECT UUID()
         -- ,NULL
         ,vw.*
     FROM (SELECT DISTINCT cdc.NEW_ICS_CMPL_MON_LNK_ID
                 ,ics.PRMT_IDENT
                 ,ics.DATE_STRM_EVT_SMPL
                 ,ics.SW_EVT_ID
                 ,ics.DATA_HASH
             FROM ga_ics_flow_icis.ICS_LNK_SW_EVT_REP ics
             JOIN CDC_TMP_CMPL_MON_LNK cdc
               ON cdc.ICS_CMPL_MON_LNK_ID = ics.ICS_CMPL_MON_LNK_ID) vw;
   -- ------------------
   -- ICS_LNK_SWMS_4_REP
   -- ------------------
   SET v_marker = 'INSERT INTO ICS_LNK_SWMS_4_REP - Set Delete Transactions';
   INSERT INTO ICS_LNK_SWMS_4_REP
      ( ICS_LNK_SWMS_4_REP_ID
      , ICS_CMPL_MON_LNK_ID
      , PRMT_IDENT
      , SW_MS_4_REP_RCVD_DATE
      , DATA_HASH)
   SELECT UUID()
         ,vw.*
     FROM (SELECT DISTINCT cdc.NEW_ICS_CMPL_MON_LNK_ID
                 ,ics.PRMT_IDENT
                 ,ics.SW_MS_4_REP_RCVD_DATE
                 ,ics.DATA_HASH
             FROM ga_ics_flow_icis.ICS_LNK_SWMS_4_REP ics
             JOIN CDC_TMP_CMPL_MON_LNK cdc
               ON cdc.ICS_CMPL_MON_LNK_ID = ics.ICS_CMPL_MON_LNK_ID) vw;
   /* **************************************************
    * ICS_ENFRC_ACTN_VIOL_LNK:  Set Delete Transactions
    * **************************************************/
   SET v_marker = 'SELECT ICS_PAYLOAD_ID FOR FinalOrderViolationLinkageSubmission';
   SELECT ICS_PAYLOAD_ID
     INTO v_payload_id
     FROM ICS_PAYLOAD 
    WHERE OPERATION = 'FinalOrderViolationLinkageSubmission';
   --
   SET v_marker = 'INSERT INTO ICS_ENFRC_ACTN_VIOL_LNK - Set Delete Transactions';
   INSERT INTO CDC_TMP_EAV_LNK
      (NEW_ICS_ENFRC_ACTN_VIOL_LNK_ID
      ,ICS_ENFRC_ACTN_VIOL_LNK_ID
      ,ENFRC_ACTN_IDENT
      ,SRC_SYSTM_IDENT
      ,TRANSACTION_TYPE
      ,TRANSACTION_TIMESTAMP
      ,KEY_HASH
      ,DATA_HASH)
   SELECT UUID()
         ,ICS_ENFRC_ACTN_VIOL_LNK_ID
         ,ENFRC_ACTN_IDENT
         ,SRC_SYSTM_IDENT
         ,'X'
         ,TRANSACTION_TIMESTAMP
         ,NULL
         ,NULL
     FROM (SELECT DISTINCT src.ICS_ENFRC_ACTN_VIOL_LNK_ID
                 ,src.SRC_SYSTM_IDENT
                 ,src.TRANSACTION_TIMESTAMP
                 ,src.ENFRC_ACTN_IDENT
             FROM ga_ics_flow_icis.ICS_ENFRC_ACTN_VIOL_LNK src
             JOIN CDV_ENFRC_ACTN_VIOL_LNK cdv
               ON cdv.KEY_HASH = src.KEY_HASH
            WHERE cdv.ACTION_TYPE = 'DELETE') vw;
   -- -----------------------
   -- ICS_ENFRC_ACTN_VIOL_LNK
   -- -----------------------
   SET v_marker = 'INSERT INTO ICS_ENFRC_ACTN_VIOL_LNK - Set Delete Transactions';
   INSERT INTO ICS_ENFRC_ACTN_VIOL_LNK
      ( ICS_ENFRC_ACTN_VIOL_LNK_ID
      , ICS_PAYLOAD_ID
      , SRC_SYSTM_IDENT
      , TRANSACTION_TYPE
      , TRANSACTION_TIMESTAMP
      , ENFRC_ACTN_IDENT
      , KEY_HASH
      , DATA_HASH)
   SELECT NEW_ICS_ENFRC_ACTN_VIOL_LNK_ID
         ,v_payload_id
         ,SRC_SYSTM_IDENT
         ,TRANSACTION_TYPE
         ,TRANSACTION_TIMESTAMP
         ,ENFRC_ACTN_IDENT
         ,KEY_HASH
         ,DATA_HASH
     FROM CDC_TMP_EAV_LNK;
   -- ------------------
   -- ICS_PRMT_SCHD_VIOL
   -- ------------------
   SET v_marker = 'INSERT INTO ICS_PRMT_SCHD_VIOL - Set Delete Transactions';
   INSERT INTO ICS_PRMT_SCHD_VIOL
     ( ICS_PRMT_SCHD_VIOL_ID
     , ICS_FINAL_ORDER_VIOL_LNK_ID
     , ICS_ENFRC_ACTN_VIOL_LNK_ID
     , PRMT_IDENT
     , NARR_COND_NUM
     , SCHD_EVT_CODE
     , SCHD_DATE
     , DATA_HASH)
   SELECT UUID()
         ,NULL
         ,vw.*
     FROM (SELECT DISTINCT cdc.NEW_ICS_ENFRC_ACTN_VIOL_LNK_ID
                 ,ics.PRMT_IDENT
                 ,ics.NARR_COND_NUM
                 ,ics.SCHD_EVT_CODE
                 ,ics.SCHD_DATE
                 ,ics.DATA_HASH
             FROM ga_ics_flow_icis.ICS_PRMT_SCHD_VIOL ics
             JOIN CDC_TMP_EAV_LNK cdc
               ON cdc.ICS_ENFRC_ACTN_VIOL_LNK_ID = ics.ICS_ENFRC_ACTN_VIOL_LNK_ID) vw;
   -- ------------------
   -- ICS_CMPL_SCHD_VIOL
   -- ------------------
   SET v_marker = 'INSERT INTO ICS_CMPL_SCHD_VIOL - Set Delete Transactions';
   INSERT INTO ICS_CMPL_SCHD_VIOL
      ( ICS_CMPL_SCHD_VIOL_ID
      , ICS_FINAL_ORDER_VIOL_LNK_ID
      , ICS_ENFRC_ACTN_VIOL_LNK_ID
      , ENFRC_ACTN_IDENT
      , FINAL_ORDER_IDENT
      , PRMT_IDENT
      , CMPL_SCHD_NUM
      , SCHD_EVT_CODE
      , SCHD_DATE
      , DATA_HASH)
   SELECT UUID()
         ,NULL
         ,vw.*
     FROM (SELECT DISTINCT cdc.NEW_ICS_ENFRC_ACTN_VIOL_LNK_ID
                 ,ics.ENFRC_ACTN_IDENT
                 ,ics.FINAL_ORDER_IDENT
                 ,ics.PRMT_IDENT
                 ,ics.CMPL_SCHD_NUM
                 ,ics.SCHD_EVT_CODE
                 ,ics.SCHD_DATE
                 ,ics.DATA_HASH
             FROM ga_ics_flow_icis.ICS_CMPL_SCHD_VIOL ics
             JOIN CDC_TMP_EAV_LNK cdc
               ON cdc.ICS_ENFRC_ACTN_VIOL_LNK_ID = ics.ICS_ENFRC_ACTN_VIOL_LNK_ID) vw;
   -- ---------------------
   -- ICS_DSCH_MON_REP_VIOL
   -- ---------------------
   SET v_marker = 'INSERT INTO ICS_DSCH_MON_REP_VIOL - Set Delete Transactions';
   INSERT INTO ICS_DSCH_MON_REP_VIOL
      ( ICS_DSCH_MON_REP_VIOL_ID
      , ICS_FINAL_ORDER_VIOL_LNK_ID
      , ICS_ENFRC_ACTN_VIOL_LNK_ID
      , PRMT_IDENT
      , PRMT_FEATR_IDENT
      , LMT_SET_DESIGNATOR
      , MON_PERIOD_END_DATE
      , DATA_HASH)
   SELECT UUID()
         ,NULL
         ,vw.*
     FROM (SELECT DISTINCT cdc.NEW_ICS_ENFRC_ACTN_VIOL_LNK_ID
                 ,ics.PRMT_IDENT
                 ,ics.PRMT_FEATR_IDENT
                 ,ics.LMT_SET_DESIGNATOR
                 ,ics.MON_PERIOD_END_DATE
                 ,ics.DATA_HASH
             FROM ga_ics_flow_icis.ICS_DSCH_MON_REP_VIOL ics
             JOIN CDC_TMP_EAV_LNK cdc
               ON cdc.ICS_ENFRC_ACTN_VIOL_LNK_ID = ics.ICS_ENFRC_ACTN_VIOL_LNK_ID) vw;
   -- ---------------------------
   -- ICS_DSCH_MON_REP_PARAM_VIOL
   -- ---------------------------
   SET v_marker = 'INSERT INTO ICS_DSCH_MON_REP_PARAM_VIOL - Set Delete Transactions';
   INSERT INTO ICS_DSCH_MON_REP_PARAM_VIOL
      ( ICS_DSCH_MON_REP_PARAM_VIOL_ID
      , ICS_FINAL_ORDER_VIOL_LNK_ID
      , ICS_ENFRC_ACTN_VIOL_LNK_ID
      , PRMT_IDENT
      , PRMT_FEATR_IDENT
      , LMT_SET_DESIGNATOR
      , MON_PERIOD_END_DATE
      , PARAM_CODE
      , MON_SITE_DESC_CODE
      , LMT_SEASON_NUM
      , DATA_HASH)
   SELECT UUID()
         ,NULL
         ,vw.*
     FROM (SELECT DISTINCT cdc.NEW_ICS_ENFRC_ACTN_VIOL_LNK_ID
                 ,ics.PRMT_IDENT
                 ,ics.PRMT_FEATR_IDENT
                 ,ics.LMT_SET_DESIGNATOR
                 ,ics.MON_PERIOD_END_DATE
                 ,ics.PARAM_CODE
                 ,ics.MON_SITE_DESC_CODE
                 ,ics.LMT_SEASON_NUM
                 ,ics.DATA_HASH
             FROM ga_ics_flow_icis.ICS_DSCH_MON_REP_PARAM_VIOL ics
             JOIN CDC_TMP_EAV_LNK cdc
               ON cdc.ICS_ENFRC_ACTN_VIOL_LNK_ID = ics.ICS_ENFRC_ACTN_VIOL_LNK_ID) vw;
   -- ------------------
   -- ICS_SNGL_EVTS_VIOL
   -- ------------------
   SET v_marker = 'INSERT INTO ICS_SNGL_EVTS_VIOL - Set Delete Transactions';
   INSERT INTO ICS_SNGL_EVTS_VIOL
      ( ICS_SNGL_EVTS_VIOL_ID
      , ICS_FINAL_ORDER_VIOL_LNK_ID
      , ICS_ENFRC_ACTN_VIOL_LNK_ID
      , PRMT_IDENT
      , SNGL_EVT_VIOL_CODE
      , SNGL_EVT_VIOL_DATE
      , DATA_HASH)
   SELECT UUID()
         ,NULL
         ,vw.*
     FROM (SELECT DISTINCT cdc.NEW_ICS_ENFRC_ACTN_VIOL_LNK_ID
                 ,ics.PRMT_IDENT
                 ,ics.SNGL_EVT_VIOL_CODE
                 ,ics.SNGL_EVT_VIOL_DATE
                 ,ics.DATA_HASH
             FROM ga_ics_flow_icis.ICS_SNGL_EVTS_VIOL ics
             JOIN CDC_TMP_EAV_LNK cdc
               ON cdc.ICS_ENFRC_ACTN_VIOL_LNK_ID = ics.ICS_ENFRC_ACTN_VIOL_LNK_ID) vw;
   -- -------------- --
   --  END PROCEDURE --
   -- -------------- --
   SET v_marker = 'CALL ics_etl_log_sp END';
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_sp_name     -- pi_marker
      ,NULL          -- pi_tgt_tbl
      ,NULL          -- pi_src_tbl 
      ,v_startdtm    -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'COMPLETED'   -- pi_process
      ,0);           -- pi_value
   --
   SET po_status = 1;
   SET po_errm   = 'COMPLETED';
END