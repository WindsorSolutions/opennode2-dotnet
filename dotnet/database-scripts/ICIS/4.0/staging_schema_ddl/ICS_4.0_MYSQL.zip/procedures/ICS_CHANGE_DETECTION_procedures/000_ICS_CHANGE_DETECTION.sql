USE ga_ics_flow_local;
DROP PROCEDURE IF EXISTS ics_change_detection;
CREATE PROCEDURE ics_change_detection
   (OUT po_status INT
   ,OUT po_errm   VARCHAR(255))
BEGIN
/******************************************************************************
** ObjectName: ICS_CHANGE_DETECTION
**
** Author: Windsor Solutions, Inc.
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure will detect data changes made within the ICIS 
**               schema and then sets the transaction type flags so the data 
**               can be bundled and submitted to an exchange partner.
**
** Inputs:  -- NA --  
**
**
** Revision History:      
** ----------------------------------------------------------------------------
**  Date         Analyst     Description
** ----------------------------------------------------------------------------
** 08/15/2012    BRensmith   Baseline from v3.1 procedure.
** 08/15/2012    BRensmith   Added v4.0 changes.
** 08/16/2012    BRensmith   removed src_systm_ident from data_hash calculations
**                           per VA DENR suggestion
** 08/17/2012    BRensmith   Use new ENABLED field on ics_payload to bypass
**                           change detection for disabled payload types
** 08/31/2012    BRensmith   Fix setting of DATA_HASH for three tables with no
**                           non-key data (sw inspections)
** 08/31/2012    BRensmith   Fix INSERT of delete transaction for ics_lmt_set
**                           since lmt_set_type is non-nullable.
** 10/02/2012    BRensmith   Added support for FINAL_ORDER_VIOL_LNK submission 
**                           type. Change Hash algorytm from MD2 to SHA1
** 10/03/2012    KJames      Added delete logic for module ICS_ENFRC_ACTN_VIOL_LNK.
** 10/17/2012    BRensmith   Update KEY_HASH for ICS_PRMT_REISSU to be only 
**                           PRMT_IDENT. (Removed PRMT_ISSUE_DATE)
** 10/29/2012    Jen Go      Converted from Oracle to MySQL
**                           Modularized SP, run the below SPs in order:
**                             1) ics_cd_create_cdv_tables
**                             2) ics_cd_updt_ics_tables
**                             3) ics_cd_process_datahash
**                             4) ics_cd_process_ics_tbls
**                           wrapper SP
******************************************************************************/
   DECLARE v_startdtm
          ,v_enddtm     DATETIME;
   DECLARE v_sp_name    VARCHAR(64)  DEFAULT 'ics_change_detection';
   DECLARE v_marker     VARCHAR(255);
   DECLARE v_errstat    INT DEFAULT 1;
   DECLARE v_errm       VARCHAR(255);
   
   DECLARE EXIT HANDLER FOR SQLEXCEPTION
      BEGIN  
         -- ROLLBACK;
         -- SELECT CONCAT('Error occurred at ',v_marker); 
         -- 
		     SET po_status = -1;
		     SET po_errm   = v_marker;
         CALL ics_etl_log_sp    
            (v_sp_name          -- pi_sp_name
            ,v_marker           -- pi_marker
            ,NULL               -- pi_tgt_tbl
            ,NULL               -- pi_src_tbl
            ,v_startdtm         -- pi_startdtm
            ,NOW()              -- pi_enddtm
            ,'FAILED'           -- pi_process
            ,-1);               -- pi_value
         COMMIT;
      END;
   SET v_startdtm = NOW();
   -- ------------------------
   -- ics_cd_create_cdv_tables
   -- ------------------------
   SET v_marker = 'CALL ics_cd_create_cdv_tables';
   CALL ics_cd_create_cdv_tables(v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- ------------------------
   -- ics_cd_updt_ics_tables
   -- ------------------------
   SET v_marker = 'CALL ics_cd_updt_ics_tables';
   CALL ics_cd_updt_ics_tables(v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- ------------------------
   -- ics_cd_process_datahash
   -- ------------------------
   SET v_marker = 'CALL ics_cd_process_datahash';
   CALL ics_cd_process_datahash(v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- ------------------------
   -- ics_cd_process_ics_tbls
   -- ------------------------
   SET v_marker = 'CALL ics_cd_process_ics_tbls';
   CALL ics_cd_process_ics_tbls(v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   --
   -- --------- --
   -- ENDS HERE --
   -- --------- --
   SET v_marker = 'CALL ics_etl_log_sp end';
   CALL ics_etl_log_sp    
      (v_sp_name          -- pi_sp_name
      ,v_sp_name          -- pi_marker
      ,NULL               -- pi_tgt_tbl
      ,NULL               -- pi_src_tbl
      ,v_startdtm         -- pi_startdtm
      ,NOW()              -- pi_enddtm
      ,'COMPLETED'        -- pi_process
      ,0);                -- pi_value
   --
   SET po_status = 0;
   SET po_errm   = '';
   --
END