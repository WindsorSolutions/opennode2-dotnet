USE ga_ics_flow_local;
DROP PROCEDURE IF EXISTS ics_cd_process_datahash;
CREATE PROCEDURE ics_cd_process_datahash
   (OUT po_status INT
   ,OUT po_errm   VARCHAR(255))
BEGIN
/******************************************************************************
** ObjectName: ics_cd_process_datahash
**
** Author: Windsor Solutions, Inc.
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure will detect data changes made within the ICIS 
**               schema and then sets the transaction type flags so the data 
**               can be bundled and submitted to an exchange partner.
**
** Inputs:  -- NA --  
**
**
** Revision History:      
** ----------------------------------------------------------------------------
**  Date         Analyst     Description
** ----------------------------------------------------------------------------
** 08/15/2012    BRensmith   Baseline from v3.1 procedure.
**
** 10/29/2012    Jen Go      Converted from Oracle to MySQL
**                           called by: ics_change_detection
**                             1) ics_cd_create_cdv_tables
**                             2) ics_cd_updt_ics_tables
**                             3) ics_cd_process_datahash
**                             4) ics_cd_process_ics_tbls
******************************************************************************/
   DECLARE v_startdtm             DATETIME     DEFAULT NOW();
   DECLARE v_enddtm               DATETIME;
   DECLARE v_sp_name              VARCHAR(64)  DEFAULT 'ics_cd_process_datahash';
   DECLARE v_sql_statement
          ,v_all_data_hashes      VARCHAR(4000); 
   DECLARE v_hashed_data_hashes
          ,v_loop_cntr 
          ,v_num_rows             INT DEFAULT 0;
   DECLARE v_enabled              CHAR(1);
   DECLARE v_table_name           VARCHAR(30);
   DECLARE v_client_prefix        VARCHAR(3)  DEFAULT 'ga_';
   DECLARE v_schema_name          VARCHAR(27) DEFAULT 'ics_flow_local';
   DECLARE v_marker               VARCHAR(255);
   DECLARE v_nodatafound          BOOLEAN;
   --
   DECLARE payload_type_cur CURSOR FOR
       SELECT TABLE_NAME
         FROM INFORMATION_SCHEMA.REFERENTIAL_CONSTRAINTS
        WHERE CONSTRAINT_SCHEMA     = CONCAT(v_client_prefix,v_schema_name)
          AND REFERENCED_TABLE_NAME = 'ICS_PAYLOAD' ;
   --
   DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_nodatafound = TRUE;
   DECLARE EXIT HANDLER FOR SQLEXCEPTION
      BEGIN  
         ROLLBACK;
         SET po_status = -1;
         SET po_errm   = v_marker;
         CALL ics_etl_log_sp    
            (v_sp_name          -- pi_sp_name
            ,v_marker           -- pi_marker
            ,NULL               -- pi_tgt_tbl
            ,NULL               -- pi_src_tbl
            ,v_startdtm         -- pi_startdtm
            ,NOW()              -- pi_enddtm
            ,'FAILED'           -- pi_process
            ,-1);               -- pi_value
      END;

   -- ================================
   -- START - Process DATA_HASH values
   -- ================================
   SET v_marker = 'OPEN payload_type_cur;Process DATA_HASH values';
   OPEN payload_type_cur;
   SET v_marker = 'payload_loop LOOP';
   payload_loop: LOOP
      --
      FETCH payload_type_cur
       INTO v_table_name;
      --
      IF v_nodatafound THEN
         -- CLOSE payload_loop;
         LEAVE payload_loop;
      END IF;
      --
      SET v_marker  = CONCAT('EXEC ',v_table_name);
      SET v_enabled = 'N';
      SET @sqlstmt = CONCAT('SELECT ENABLED INTO @enabled' 
                           ,' FROM ICS_PAYLOAD JOIN ' 
                           ,v_table_name
                           ,' ON ICS_PAYLOAD.ICS_PAYLOAD_ID = '
                           ,v_table_name
                           ,'.ICS_PAYLOAD_ID LIMIT 1');
      PREPARE v_sql_statement FROM @sqlstmt;
      EXECUTE v_sql_statement;
      SET v_enabled = @enabled; 
      --
      --  Flush the prior payload type's key_hash values
      SET v_marker = 'DELETE FROM ICS_KEY_HASH';
      DELETE FROM ICS_KEY_HASH;
      --
      -- Load next key_hash set for current payload type
      SET v_marker = CONCAT('INSERT INTO ICS_KEY_HASH SELECT KEY_HASH FROM '
                           ,v_table_name);
      SET @sqlstmt = v_marker;
      PREPARE v_sql_statement FROM @sqlstmt;
      EXECUTE v_sql_statement;
      --
      -- Flush the prior payload's data_hash values
      SET v_marker = 'DELETE FROM ics_data_hash';
      DELETE FROM ICS_DATA_HASH;
      -- ==============
      -- ICS_BASIC_PRMT
      -- ==============
      IF v_table_name = 'ICS_BASIC_PRMT' AND 
         v_enabled    = 'Y'              THEN
         -- ----------------
         -- /ICS_BASIC_PRMT
         -- ----------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_BASIC_PRMT';
         INSERT INTO ICS_DATA_HASH
         SELECT DATA_HASH
           FROM ICS_BASIC_PRMT
          WHERE KEY_HASH IN (SELECT KEY_HASH 
                               FROM ICS_KEY_HASH);
         -- ------------------------
         -- /ICS_BASIC_PRMT/ICS_ADDR
         -- ------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_BASIC_PRMT/ICS_ADDR';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_ADDR.DATA_HASH
           FROM ICS_BASIC_PRMT 
           JOIN ICS_ADDR
             ON ICS_ADDR.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID
          WHERE ICS_BASIC_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                              FROM ICS_KEY_HASH);  
         -- -----------------------------------
         -- /ICS_BASIC_PRMT/ICS_ADDR/ICS_TELEPH
         -- -----------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_BASIC_PRMT/ICS_ADDR/ICS_TELEPH';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_TELEPH.DATA_HASH
           FROM ICS_BASIC_PRMT
           JOIN ICS_ADDR
             ON ICS_ADDR.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID
           JOIN ICS_TELEPH
             ON ICS_TELEPH.ICS_ADDR_ID = ICS_ADDR.ICS_ADDR_ID
          WHERE ICS_BASIC_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                   FROM ICS_KEY_HASH);  
         -- -----------------------------
         -- /ICS_BASIC_PRMT/ICS_ASSC_PRMT
         -- -----------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_BASIC_PRMT/ICS_ASSC_PRMT';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_ASSC_PRMT.DATA_HASH
           FROM ICS_BASIC_PRMT
           JOIN ICS_ASSC_PRMT
             ON ICS_ASSC_PRMT.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID
          WHERE ICS_BASIC_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                   FROM ICS_KEY_HASH);  
         -- -----------------------------------
         -- /ICS_BASIC_PRMT/ICS_CMPL_TRACK_STAT
         -- -----------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_BASIC_PRMT/ICS_CMPL_TRACK_STAT';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_CMPL_TRACK_STAT.DATA_HASH
           FROM ICS_BASIC_PRMT
           JOIN ICS_CMPL_TRACK_STAT
             ON ICS_CMPL_TRACK_STAT.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID
          WHERE ICS_BASIC_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                              FROM ICS_KEY_HASH);  
         -- ---------------------------
         -- /ICS_BASIC_PRMT/ICS_CONTACT
         -- ---------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_BASIC_PRMT/ICS_CONTACT';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_CONTACT.DATA_HASH
           FROM ICS_BASIC_PRMT
           JOIN ICS_CONTACT
             ON ICS_CONTACT.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID
          WHERE ICS_BASIC_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                              FROM ICS_KEY_HASH);  
         -- --------------------------------------
         -- /ICS_BASIC_PRMT/ICS_CONTACT/ICS_TELEPH
         -- --------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_BASIC_PRMT/ICS_CONTACT/ICS_TELEPH';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_TELEPH.DATA_HASH
           FROM ICS_BASIC_PRMT
           JOIN ICS_CONTACT
             ON ICS_CONTACT.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID
           JOIN ICS_TELEPH
             ON ICS_TELEPH.ICS_CONTACT_ID = ICS_CONTACT.ICS_CONTACT_ID
          WHERE ICS_BASIC_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                              FROM ICS_KEY_HASH);  
         -- -------------------------------
         -- /ICS_BASIC_PRMT/ICS_EFFLU_GUIDE
         -- -------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_BASIC_PRMT/ICS_EFFLU_GUIDE';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_EFFLU_GUIDE.DATA_HASH
           FROM ICS_BASIC_PRMT
           JOIN ICS_EFFLU_GUIDE
             ON ICS_EFFLU_GUIDE.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID
          WHERE ICS_BASIC_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                              FROM ICS_KEY_HASH);  
         -- -----------------------
         -- /ICS_BASIC_PRMT/ICS_FAC
         -- -----------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_BASIC_PRMT/ICS_FAC';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_FAC.DATA_HASH
           FROM ICS_BASIC_PRMT
           JOIN ICS_FAC
             ON ICS_FAC.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID
          WHERE ICS_BASIC_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                              FROM ICS_KEY_HASH);  
         -- --------------------------------
         -- /ICS_BASIC_PRMT/ICS_FAC/ICS_ADDR
         -- --------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_BASIC_PRMT/ICS_FAC';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_ADDR.DATA_HASH
           FROM ICS_BASIC_PRMT
           JOIN ICS_FAC
             ON ICS_FAC.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID
           JOIN ICS_ADDR
             ON ICS_ADDR.ICS_FAC_ID = ICS_FAC.ICS_FAC_ID
          WHERE ICS_BASIC_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                               FROM ICS_KEY_HASH);  
         -- -------------------------------------------
         -- /ICS_BASIC_PRMT/ICS_FAC/ICS_ADDR/ICS_TELEPH
         -- -------------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_BASIC_PRMT/ICS_FAC/ICS_ADDR/ICS_TELEPH';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_TELEPH.DATA_HASH
           FROM ICS_BASIC_PRMT
           JOIN ICS_FAC
             ON ICS_FAC.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID
           JOIN ICS_ADDR
             ON ICS_ADDR.ICS_FAC_ID = ICS_FAC.ICS_FAC_ID
           JOIN ICS_TELEPH
             ON ICS_TELEPH.ICS_ADDR_ID = ICS_ADDR.ICS_ADDR_ID
          WHERE ICS_BASIC_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                            FROM ICS_KEY_HASH);  
         -- -----------------------------------
         -- /ICS_BASIC_PRMT/ICS_FAC/ICS_CONTACT
         -- -----------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_BASIC_PRMT/ICS_FAC/ICS_CONTACT';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_CONTACT.DATA_HASH
           FROM ICS_BASIC_PRMT
           JOIN ICS_FAC 
             ON ICS_FAC.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID
           JOIN ICS_CONTACT
             ON ICS_CONTACT.ICS_FAC_ID = ICS_FAC.ICS_FAC_ID
          WHERE ICS_BASIC_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                              FROM ICS_KEY_HASH);  
         -- ----------------------------------------------
         -- /ICS_BASIC_PRMT/ICS_FAC/ICS_CONTACT/ICS_TELEPH
         -- ----------------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_BASIC_PRMT/ICS_FAC/ICS_CONTACT/ICS_TELEPH';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_TELEPH.DATA_HASH
           FROM ICS_BASIC_PRMT
           JOIN ICS_FAC
             ON ICS_FAC.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID
           JOIN ICS_CONTACT
             ON ICS_CONTACT.ICS_FAC_ID = ICS_FAC.ICS_FAC_ID
           JOIN ICS_TELEPH
             ON ICS_TELEPH.ICS_CONTACT_ID = ICS_CONTACT.ICS_CONTACT_ID
          WHERE ICS_BASIC_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                              FROM ICS_KEY_HASH);  
         -- -------------------------------------
         -- /ICS_BASIC_PRMT/ICS_FAC/ICS_FAC_CLASS
         -- -------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_BASIC_PRMT/ICS_FAC/ICS_FAC_CLASS';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_FAC_CLASS.DATA_HASH
           FROM ICS_BASIC_PRMT
           JOIN ICS_FAC
             ON ICS_FAC.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID
           JOIN ICS_FAC_CLASS
             ON ICS_FAC_CLASS.ICS_FAC_ID = ICS_FAC.ICS_FAC_ID
          WHERE ICS_BASIC_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                              FROM ICS_KEY_HASH);  
         -- -------------------------------------
         -- /ICS_BASIC_PRMT/ICS_FAC/ICS_GEO_COORD
         -- -------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_BASIC_PRMT/ICS_FAC/ICS_GEO_COORD';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_GEO_COORD.DATA_HASH
           FROM ICS_BASIC_PRMT
           JOIN ICS_FAC 
             ON ICS_FAC.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID
           JOIN ICS_GEO_COORD 
             ON ICS_GEO_COORD.ICS_FAC_ID = ICS_FAC.ICS_FAC_ID
          WHERE ICS_BASIC_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                              FROM ICS_KEY_HASH);  
         -- --------------------------------------
         -- /ICS_BASIC_PRMT/ICS_FAC/ICS_NAICS_CODE
         -- --------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_BASIC_PRMT/ICS_FAC/ICS_NAICS_CODE';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_NAICS_CODE.DATA_HASH
           FROM ICS_BASIC_PRMT 
           JOIN ICS_FAC 
             ON ICS_FAC.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID
           JOIN ICS_NAICS_CODE 
             ON ICS_NAICS_CODE.ICS_FAC_ID = ICS_FAC.ICS_FAC_ID
          WHERE ICS_BASIC_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                              FROM ICS_KEY_HASH);  
         -- --------------------------------------
         -- /ICS_BASIC_PRMT/ICS_FAC/ICS_ORIG_PROGS
         -- --------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_BASIC_PRMT/ICS_FAC/ICS_ORIG_PROGS';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_ORIG_PROGS.DATA_HASH
           FROM ICS_BASIC_PRMT
           JOIN ICS_FAC
             ON ICS_FAC.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID
           JOIN ICS_ORIG_PROGS
             ON ICS_ORIG_PROGS.ICS_FAC_ID = ICS_FAC.ICS_FAC_ID
          WHERE ICS_BASIC_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                              FROM ICS_KEY_HASH);  
         -- --------------------------------
         -- /ICS_BASIC_PRMT/ICS_FAC/ICS_PLCY
         -- --------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_BASIC_PRMT/ICS_FAC/ICS_PLCY';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_PLCY.DATA_HASH
           FROM ICS_BASIC_PRMT
           JOIN ICS_FAC
             ON ICS_FAC.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID
           JOIN ICS_PLCY
             ON ICS_PLCY.ICS_FAC_ID = ICS_FAC.ICS_FAC_ID
          WHERE ICS_BASIC_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                              FROM ICS_KEY_HASH); 
         -- ------------------------------------
         -- /ICS_BASIC_PRMT/ICS_FAC/ICS_SIC_CODE
         -- ------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_BASIC_PRMT/ICS_FAC/ICS_SIC_CODE'; 
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_SIC_CODE.DATA_HASH
           FROM ICS_BASIC_PRMT
           JOIN ICS_FAC
             ON ICS_FAC.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID
           JOIN ICS_SIC_CODE
             ON ICS_SIC_CODE.ICS_FAC_ID = ICS_FAC.ICS_FAC_ID
          WHERE ICS_BASIC_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                              FROM ICS_KEY_HASH); 
         -- ------------------------------
         -- /ICS_BASIC_PRMT/ICS_NAICS_CODE
         -- ------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_BASIC_PRMT/ICS_NAICS_CODE'; 
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_NAICS_CODE.DATA_HASH
           FROM ICS_BASIC_PRMT
           JOIN ICS_NAICS_CODE
             ON ICS_NAICS_CODE.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID
          WHERE ICS_BASIC_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                              FROM ICS_KEY_HASH); 
         -- ------------------------------
         -- /ICS_BASIC_PRMT/ICS_OTHR_PRMTS
         -- ------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_BASIC_PRMT/ICS_OTHR_PRMTS'; 
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_OTHR_PRMTS.DATA_HASH
           FROM ICS_BASIC_PRMT
           JOIN ICS_OTHR_PRMTS
             ON ICS_OTHR_PRMTS.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID
          WHERE ICS_BASIC_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                              FROM ICS_KEY_HASH); 
         -- ----------------------------
         -- /ICS_BASIC_PRMT/ICS_SIC_CODE
         -- ----------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_BASIC_PRMT/ICS_SIC_CODE';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_SIC_CODE.DATA_HASH
           FROM ICS_BASIC_PRMT
           JOIN ICS_SIC_CODE
             ON ICS_SIC_CODE.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID
          WHERE ICS_BASIC_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                              FROM ICS_KEY_HASH); 
      END IF;
      -- ===========
      -- ICS_BS_PRMT
      -- ===========
      IF v_table_name = 'ICS_BS_PRMT' AND 
         v_enabled    = 'Y'           THEN
         -- ------------
         -- /ICS_BS_PRMT
         -- ------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_BS_PRMT'; 
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_BS_PRMT.DATA_HASH
           FROM ICS_BS_PRMT
          WHERE ICS_BS_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                           FROM ICS_KEY_HASH); 
         -- ---------------------
         -- /ICS_BS_PRMT/ICS_ADDR
         -- ---------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_BS_PRMT/ICS_ADDR'; 
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_ADDR.DATA_HASH
           FROM ICS_BS_PRMT
           JOIN ICS_ADDR
             ON ICS_ADDR.ICS_BS_PRMT_ID = ICS_BS_PRMT.ICS_BS_PRMT_ID
          WHERE ICS_BS_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                           FROM ICS_KEY_HASH);
         -- --------------------------------
         -- /ICS_BS_PRMT/ICS_ADDR/ICS_TELEPH
         -- --------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_BS_PRMT/ICS_ADDR/ICS_TELEPH'; 
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_TELEPH.DATA_HASH
           FROM ICS_BS_PRMT
           JOIN ICS_ADDR
             ON ICS_ADDR.ICS_BS_PRMT_ID = ICS_BS_PRMT.ICS_BS_PRMT_ID
           JOIN ICS_TELEPH
             ON ICS_TELEPH.ICS_ADDR_ID = ICS_ADDR.ICS_ADDR_ID
          WHERE ICS_BS_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                           FROM ICS_KEY_HASH);
         -- -------------------------------------
         -- /ICS_BS_PRMT/ICS_BS_END_USE_DSPL_TYPE
         -- -------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_BS_PRMT/ICS_BS_END_USE_DSPL_TYPE'; 
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_BS_END_USE_DSPL_TYPE.DATA_HASH
           FROM ICS_BS_PRMT
           JOIN ICS_BS_END_USE_DSPL_TYPE
             ON ICS_BS_END_USE_DSPL_TYPE.ICS_BS_PRMT_ID = ICS_BS_PRMT.ICS_BS_PRMT_ID
          WHERE ICS_BS_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                           FROM ICS_KEY_HASH);
         -- ------------------------
         -- /ICS_BS_PRMT/ICS_BS_TYPE
         -- ------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_BS_PRMT/ICS_BS_TYPE';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_BS_TYPE.DATA_HASH
           FROM ICS_BS_PRMT
           JOIN ICS_BS_TYPE
             ON ICS_BS_TYPE.ICS_BS_PRMT_ID = ICS_BS_PRMT.ICS_BS_PRMT_ID
          WHERE ICS_BS_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                           FROM ICS_KEY_HASH);
         -- ------------------------
         -- /ICS_BS_PRMT/ICS_CONTACT
         -- ------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_BS_PRMT/ICS_CONTACT';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_CONTACT.DATA_HASH
           FROM ICS_BS_PRMT
           JOIN ICS_CONTACT
             ON ICS_CONTACT.ICS_BS_PRMT_ID = ICS_BS_PRMT.ICS_BS_PRMT_ID
          WHERE ICS_BS_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                           FROM ICS_KEY_HASH);
         -- -----------------------------------
         -- /ICS_BS_PRMT/ICS_CONTACT/ICS_TELEPH
         -- -----------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_BS_PRMT/ICS_CONTACT/ICS_TELEPH';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_TELEPH.DATA_HASH
           FROM ICS_BS_PRMT
           JOIN ICS_CONTACT
             ON ICS_CONTACT.ICS_BS_PRMT_ID = ICS_BS_PRMT.ICS_BS_PRMT_ID
           JOIN ICS_TELEPH
             ON ICS_TELEPH.ICS_CONTACT_ID = ICS_CONTACT.ICS_CONTACT_ID
          WHERE ICS_BS_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                           FROM ICS_KEY_HASH);
      END IF;
      -- =============
      -- ICS_CAFO_PRMT
      -- =============
      IF v_table_name = 'ICS_CAFO_PRMT' AND 
         v_enabled    = 'Y'             THEN
         -- --------------
         -- /ICS_CAFO_PRMT
         -- --------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CAFO_PRMT';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_CAFO_PRMT.DATA_HASH
           FROM ICS_CAFO_PRMT
          WHERE ICS_CAFO_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                             FROM ICS_KEY_HASH);
         -- -----------------------
         -- /ICS_CAFO_PRMT/ICS_ADDR
         -- -----------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CAFO_PRMT/ICS_ADDR';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_ADDR.DATA_HASH
           FROM ICS_CAFO_PRMT
           JOIN ICS_ADDR
             ON ICS_ADDR.ICS_CAFO_PRMT_ID = ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID
          WHERE ICS_CAFO_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                             FROM ICS_KEY_HASH);
         -- -----------------------------------
         -- /ICS_CAFO_PRMT/ICS_ADDR/ICS_TELEPH
         -- ----------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CAFO_PRMT/ICS_ADDR/ICS_TELEPH';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_TELEPH.DATA_HASH
           FROM ICS_CAFO_PRMT
           JOIN ICS_ADDR
             ON ICS_ADDR.ICS_CAFO_PRMT_ID = ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID
           JOIN ICS_TELEPH
             ON ICS_TELEPH.ICS_ADDR_ID = ICS_ADDR.ICS_ADDR_ID
          WHERE ICS_CAFO_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                             FROM ICS_KEY_HASH);
         -- ----------------------------
         -- /ICS_CAFO_PRMT/ICS_ANML_TYPE
         -- ----------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CAFO_PRMT/ICS_ANML_TYPE';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_ANML_TYPE.DATA_HASH
           FROM ICS_CAFO_PRMT
           JOIN ICS_ANML_TYPE
             ON ICS_ANML_TYPE.ICS_CAFO_PRMT_ID = ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID
          WHERE ICS_CAFO_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                             FROM ICS_KEY_HASH);
         -- --------------------------
         -- /ICS_CAFO_PRMT/ICS_CONTACT
         -- --------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CAFO_PRMT/ICS_CONTACT';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_CONTACT.DATA_HASH
           FROM ICS_CAFO_PRMT
           JOIN ICS_CONTACT
             ON ICS_CONTACT.ICS_CAFO_PRMT_ID = ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID
          WHERE ICS_CAFO_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                             FROM ICS_KEY_HASH);
         -- -------------------------------------
         -- /ICS_CAFO_PRMT/ICS_CONTACT/ICS_TELEPH
         -- -------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CAFO_PRMT/ICS_CONTACT/ICS_TELEPH';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_TELEPH.DATA_HASH
           FROM ICS_CAFO_PRMT
           JOIN ICS_CONTACT
             ON ICS_CONTACT.ICS_CAFO_PRMT_ID = ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID
           JOIN ICS_TELEPH
             ON ICS_TELEPH.ICS_CONTACT_ID = ICS_CONTACT.ICS_CONTACT_ID
          WHERE ICS_CAFO_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                             FROM ICS_KEY_HASH);
         -- ------------------------------
         -- /ICS_CAFO_PRMT/ICS_CONTAINMENT
         -- ------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CAFO_PRMT/ICS_CONTAINMENT';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_CONTAINMENT.DATA_HASH
           FROM ICS_CAFO_PRMT
           JOIN ICS_CONTAINMENT
             ON ICS_CONTAINMENT.ICS_CAFO_PRMT_ID = ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID
          WHERE ICS_CAFO_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                             FROM ICS_KEY_HASH);
         -- --------------------------------
         -- /ICS_CAFO_PRMT/ICS_LAND_APPL_BMP
         -- --------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CAFO_PRMT/ICS_LAND_APPL_BMP';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_LAND_APPL_BMP.DATA_HASH
           FROM ICS_CAFO_PRMT
           JOIN ICS_LAND_APPL_BMP
             ON ICS_LAND_APPL_BMP.ICS_CAFO_PRMT_ID = ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID
          WHERE ICS_CAFO_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                             FROM ICS_KEY_HASH);
         -- ------------------------------------------
         -- /ICS_CAFO_PRMT/ICS_MNUR_LTTR_PRCSS_WW_STOR
         -- ------------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CAFO_PRMT/ICS_MNUR_LTTR_PRCSS_WW_STOR';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_MNUR_LTTR_PRCSS_WW_STOR.DATA_HASH
           FROM ICS_CAFO_PRMT
           JOIN ICS_MNUR_LTTR_PRCSS_WW_STOR
             ON ICS_MNUR_LTTR_PRCSS_WW_STOR.ICS_CAFO_PRMT_ID = ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID
          WHERE ICS_CAFO_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                             FROM ICS_KEY_HASH);
      END IF;
      -- ============
      -- ICS_CSO_PRMT
      -- ============
      IF v_table_name = 'ICS_CSO_PRMT' AND 
         v_enabled    = 'Y'            THEN
         -- -------------
         -- /ICS_CSO_PRMT
         -- -------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CAFO_PRMT';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_CSO_PRMT.DATA_HASH
           FROM ICS_CSO_PRMT
          WHERE ICS_CSO_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                             FROM ICS_KEY_HASH);
         -- ---------------------------------
         -- /ICS_CSO_PRMT/ICS_SATL_COLL_SYSTM
         -- ---------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CSO_PRMT/ICS_SATL_COLL_SYSTM';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_SATL_COLL_SYSTM.DATA_HASH
           FROM ICS_CSO_PRMT
           JOIN ICS_SATL_COLL_SYSTM
             ON ICS_SATL_COLL_SYSTM.ICS_CSO_PRMT_ID = ICS_CSO_PRMT.ICS_CSO_PRMT_ID
          WHERE ICS_CSO_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                             FROM ICS_KEY_HASH);
      END IF;
      -- ============
      -- ICS_CMPL_MON
      -- ============
      IF v_table_name = 'ICS_CMPL_MON' AND 
         v_enabled    = 'Y'            THEN
         -- -------------
         -- /ICS_CMPL_MON
         -- -------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CMPL_MON';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_CMPL_MON.DATA_HASH
           FROM ICS_CMPL_MON
          WHERE ICS_CMPL_MON.KEY_HASH IN (SELECT KEY_HASH 
                                             FROM ICS_KEY_HASH);
         -- ---------------------------
         -- /ICS_CMPL_MON/ICS_CAFO_INSP
         -- ---------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CMPL_MON/ICS_CAFO_INSP';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_CAFO_INSP.DATA_HASH
           FROM ICS_CMPL_MON
           JOIN ICS_CAFO_INSP
             ON ICS_CAFO_INSP.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID
          WHERE ICS_CMPL_MON.KEY_HASH IN (SELECT KEY_HASH 
                                             FROM ICS_KEY_HASH);
         -- -----------------------------------------
         -- /ICS_CMPL_MON/ICS_CAFO_INSP/ICS_ANML_TYPE
         -- -----------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CMPL_MON/ICS_CAFO_INSP/ICS_ANML_TYPE';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_ANML_TYPE.DATA_HASH
           FROM ICS_CMPL_MON
           JOIN ICS_CAFO_INSP
             ON ICS_CAFO_INSP.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID
           JOIN ICS_ANML_TYPE
             ON ICS_ANML_TYPE.ICS_CAFO_INSP_ID = ICS_CAFO_INSP.ICS_CAFO_INSP_ID
          WHERE ICS_CMPL_MON.KEY_HASH IN (SELECT KEY_HASH 
                                             FROM ICS_KEY_HASH);
         -- ---------------------------------------------------
         -- /ICS_CMPL_MON/ICS_CAFO_INSP/ICS_CAFO_INSP_VIOL_TYPE
         -- ---------------------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CMPL_MON/ICS_CAFO_INSP/ICS_CAFO_INSP_VIOL_TYPE';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_CAFO_INSP_VIOL_TYPE.DATA_HASH
           FROM ICS_CMPL_MON
           JOIN ICS_CAFO_INSP
             ON ICS_CAFO_INSP.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID
           JOIN ICS_CAFO_INSP_VIOL_TYPE
             ON ICS_CAFO_INSP_VIOL_TYPE.ICS_CAFO_INSP_ID = ICS_CAFO_INSP.ICS_CAFO_INSP_ID
          WHERE ICS_CMPL_MON.KEY_HASH IN (SELECT KEY_HASH 
                                             FROM ICS_KEY_HASH);
         -- -------------------------------------------
         -- /ICS_CMPL_MON/ICS_CAFO_INSP/ICS_CONTAINMENT
         -- -------------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CMPL_MON/ICS_CAFO_INSP/ICS_CONTAINMENT';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_CONTAINMENT.DATA_HASH
           FROM ICS_CMPL_MON
           JOIN ICS_CAFO_INSP
             ON ICS_CAFO_INSP.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID
           JOIN ICS_CONTAINMENT
             ON ICS_CONTAINMENT.ICS_CAFO_INSP_ID = ICS_CAFO_INSP.ICS_CAFO_INSP_ID
          WHERE ICS_CMPL_MON.KEY_HASH IN (SELECT KEY_HASH 
                                             FROM ICS_KEY_HASH);
         -- ---------------------------------------------
         -- /ICS_CMPL_MON/ICS_CAFO_INSP/ICS_LAND_APPL_BMP
         -- ---------------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CMPL_MON/ICS_CAFO_INSP/ICS_LAND_APPL_BMP';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_LAND_APPL_BMP.DATA_HASH
           FROM ICS_CMPL_MON
           JOIN ICS_CAFO_INSP
             ON ICS_CAFO_INSP.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID
           JOIN ICS_LAND_APPL_BMP
             ON ICS_LAND_APPL_BMP.ICS_CAFO_INSP_ID = ICS_CAFO_INSP.ICS_CAFO_INSP_ID
          WHERE ICS_CMPL_MON.KEY_HASH IN (SELECT KEY_HASH 
                                             FROM ICS_KEY_HASH);
         -- -------------------------------------------------------
         -- /ICS_CMPL_MON/ICS_CAFO_INSP/ICS_MNUR_LTTR_PRCSS_WW_STOR
         -- -------------------------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CMPL_MON/ICS_CAFO_INSP/ICS_MNUR_LTTR_PRCSS_WW_STOR';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_MNUR_LTTR_PRCSS_WW_STOR.DATA_HASH
           FROM ICS_CMPL_MON
           JOIN ICS_CAFO_INSP
             ON ICS_CAFO_INSP.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID
           JOIN ICS_MNUR_LTTR_PRCSS_WW_STOR
             ON ICS_MNUR_LTTR_PRCSS_WW_STOR.ICS_CAFO_INSP_ID = ICS_CAFO_INSP.ICS_CAFO_INSP_ID
          WHERE ICS_CMPL_MON.KEY_HASH IN (SELECT KEY_HASH 
                                             FROM ICS_KEY_HASH);
         -- --------------------------------
         -- /ICS_CMPL_MON/ICS_CMPL_INSP_TYPE
         -- --------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CMPL_MON/ICS_CMPL_INSP_TYPE';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_CMPL_INSP_TYPE.DATA_HASH
           FROM ICS_CMPL_MON
           JOIN ICS_CMPL_INSP_TYPE
             ON ICS_CMPL_INSP_TYPE.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID
          WHERE ICS_CMPL_MON.KEY_HASH IN (SELECT KEY_HASH 
                                             FROM ICS_KEY_HASH);
         -- --------------------------------------
         -- /ICS_CMPL_MON/ICS_CMPL_MON_ACTN_REASON
         -- --------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CMPL_MON/ICS_CMPL_MON_ACTN_REASON';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_CMPL_MON_ACTN_REASON.DATA_HASH
           FROM ICS_CMPL_MON
           JOIN ICS_CMPL_MON_ACTN_REASON
             ON ICS_CMPL_MON_ACTN_REASON.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID
          WHERE ICS_CMPL_MON.KEY_HASH IN (SELECT KEY_HASH 
                                             FROM ICS_KEY_HASH);
         -- -------------------------------------
         -- /ICS_CMPL_MON/ICS_CMPL_MON_AGNCY_TYPE
         -- -------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CMPL_MON/ICS_CMPL_MON_AGNCY_TYPE';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_CMPL_MON_AGNCY_TYPE.DATA_HASH
           FROM ICS_CMPL_MON
           JOIN ICS_CMPL_MON_AGNCY_TYPE
             ON ICS_CMPL_MON_AGNCY_TYPE.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID
          WHERE ICS_CMPL_MON.KEY_HASH IN (SELECT KEY_HASH 
                                             FROM ICS_KEY_HASH);
         -- -------------------------
         -- /ICS_CMPL_MON/ICS_CONTACT
         -- -------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CMPL_MON/ICS_CONTACT';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_CONTACT.DATA_HASH
           FROM ICS_CMPL_MON
           JOIN ICS_CONTACT
             ON ICS_CONTACT.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID
          WHERE ICS_CMPL_MON.KEY_HASH IN (SELECT KEY_HASH 
                                             FROM ICS_KEY_HASH);
         -- ------------------------------------
         -- /ICS_CMPL_MON/ICS_CONTACT/ICS_TELEPH
         -- ------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CMPL_MON/ICS_CONTACT/ICS_TELEPH';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_TELEPH.DATA_HASH
           FROM ICS_CMPL_MON
           JOIN ICS_CONTACT
             ON ICS_CONTACT.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID
           JOIN ICS_TELEPH
             ON ICS_TELEPH.ICS_CONTACT_ID = ICS_CONTACT.ICS_CONTACT_ID
          WHERE ICS_CMPL_MON.KEY_HASH IN (SELECT KEY_HASH 
                                             FROM ICS_KEY_HASH);
         -- --------------------------
         -- /ICS_CMPL_MON/ICS_CSO_INSP
         -- --------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CMPL_MON/ICS_CSO_INSP';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_CSO_INSP.DATA_HASH
           FROM ICS_CMPL_MON
           JOIN ICS_CSO_INSP
             ON ICS_CSO_INSP.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID
          WHERE ICS_CMPL_MON.KEY_HASH IN (SELECT KEY_HASH 
                                             FROM ICS_KEY_HASH);
         -- --------------------------
         -- /ICS_CMPL_MON/ICS_NAT_PRIO
         -- --------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CMPL_MON/ICS_NAT_PRIO';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_NAT_PRIO.DATA_HASH
           FROM ICS_CMPL_MON
           JOIN ICS_NAT_PRIO
             ON ICS_NAT_PRIO.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID
          WHERE ICS_CMPL_MON.KEY_HASH IN (SELECT KEY_HASH 
                                             FROM ICS_KEY_HASH);
         -- ----------------------------
         -- /ICS_CMPL_MON/ICS_PRETR_INSP
         -- ----------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CMPL_MON/ICS_PRETR_INSP';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_PRETR_INSP.DATA_HASH
           FROM ICS_CMPL_MON
           JOIN ICS_PRETR_INSP
             ON ICS_PRETR_INSP.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID
          WHERE ICS_CMPL_MON.KEY_HASH IN (SELECT KEY_HASH 
                                             FROM ICS_KEY_HASH);
         -- -----------------------------------------
         -- /ICS_CMPL_MON/ICS_PRETR_INSP/ICS_LOC_LMTS
         -- -----------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CMPL_MON/ICS_PRETR_INSP/ICS_LOC_LMTS';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_LOC_LMTS.DATA_HASH
           FROM ICS_CMPL_MON
           JOIN ICS_PRETR_INSP
             ON ICS_PRETR_INSP.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID
           JOIN ICS_LOC_LMTS
             ON ICS_LOC_LMTS.ICS_PRETR_INSP_ID = ICS_PRETR_INSP.ICS_PRETR_INSP_ID
          WHERE ICS_CMPL_MON.KEY_HASH IN (SELECT KEY_HASH 
                                            FROM ICS_KEY_HASH);
         -- ------------------------------------------------------------
         -- /ICS_CMPL_MON/ICS_PRETR_INSP/ICS_LOC_LMTS/ICS_LOC_LMTS_POLUT
         -- ------------------------------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CMPL_MON/ICS_PRETR_INSP/ICS_LOC_LMTS/ICS_LOC_LMTS_POLUT';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_LOC_LMTS_POLUT.DATA_HASH
           FROM ICS_CMPL_MON
           JOIN ICS_PRETR_INSP
             ON ICS_PRETR_INSP.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID
           JOIN ICS_LOC_LMTS
             ON ICS_LOC_LMTS.ICS_PRETR_INSP_ID = ICS_PRETR_INSP.ICS_PRETR_INSP_ID
           JOIN ICS_LOC_LMTS_POLUT
             ON ICS_LOC_LMTS_POLUT.ICS_LOC_LMTS_ID = ICS_LOC_LMTS.ICS_LOC_LMTS_ID
          WHERE ICS_CMPL_MON.KEY_HASH IN (SELECT KEY_HASH 
                                            FROM ICS_KEY_HASH);
         -- -------------------------------------------
         -- /ICS_CMPL_MON/ICS_PRETR_INSP/ICS_RMVL_CRDTS
         -- -------------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CMPL_MON/ICS_PRETR_INSP/ICS_RMVL_CRDTS';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_RMVL_CRDTS.DATA_HASH
           FROM ICS_CMPL_MON
           JOIN ICS_PRETR_INSP
             ON ICS_PRETR_INSP.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID
           JOIN ICS_RMVL_CRDTS
             ON ICS_RMVL_CRDTS.ICS_PRETR_INSP_ID = ICS_PRETR_INSP.ICS_PRETR_INSP_ID
          WHERE ICS_CMPL_MON.KEY_HASH IN (SELECT KEY_HASH 
                                            FROM ICS_KEY_HASH);
         -- ----------------------------------------------------------------
         -- /ICS_CMPL_MON/ICS_PRETR_INSP/ICS_RMVL_CRDTS/ICS_RMVL_CRDTS_POLUT
         -- ----------------------------------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CMPL_MON/ICS_PRETR_INSP/ICS_RMVL_CRDTS/ICS_RMVL_CRDTS_POLUT';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_RMVL_CRDTS_POLUT.DATA_HASH
           FROM ICS_CMPL_MON
           JOIN ICS_PRETR_INSP
             ON ICS_PRETR_INSP.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID
           JOIN ICS_RMVL_CRDTS
             ON ICS_RMVL_CRDTS.ICS_PRETR_INSP_ID = ICS_PRETR_INSP.ICS_PRETR_INSP_ID
           JOIN ICS_RMVL_CRDTS_POLUT
             ON ICS_RMVL_CRDTS_POLUT.ICS_RMVL_CRDTS_ID = ICS_RMVL_CRDTS.ICS_RMVL_CRDTS_ID
          WHERE ICS_CMPL_MON.KEY_HASH IN (SELECT KEY_HASH 
                                            FROM ICS_KEY_HASH);
         -- ----------------------
         -- /ICS_CMPL_MON/ICS_PROG
         -- ----------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CMPL_MON/ICS_PROG';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_PROG.DATA_HASH
           FROM ICS_CMPL_MON
           JOIN ICS_PROG
             ON ICS_PROG.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID
          WHERE ICS_CMPL_MON.KEY_HASH IN (SELECT KEY_HASH 
                                            FROM ICS_KEY_HASH);
         -- --------------------------
         -- /ICS_CMPL_MON/ICS_SSO_INSP
         -- --------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CMPL_MON/ICS_SSO_INSP';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_SSO_INSP.DATA_HASH
           FROM ICS_CMPL_MON
           JOIN ICS_SSO_INSP
             ON ICS_SSO_INSP.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID
          WHERE ICS_CMPL_MON.KEY_HASH IN (SELECT KEY_HASH 
                                            FROM ICS_KEY_HASH);
         -- ---------------------------------------------
         -- /ICS_CMPL_MON/ICS_SSO_INSP/ICS_IMPACT_SSO_EVT
         -- ---------------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CMPL_MON/ICS_SSO_INSP/ICS_IMPACT_SSO_EVT';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_IMPACT_SSO_EVT.DATA_HASH
           FROM ICS_CMPL_MON
           JOIN ICS_SSO_INSP
             ON ICS_SSO_INSP.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID
           JOIN ICS_IMPACT_SSO_EVT
             ON ICS_IMPACT_SSO_EVT.ICS_SSO_INSP_ID = ICS_SSO_INSP.ICS_SSO_INSP_ID
          WHERE ICS_CMPL_MON.KEY_HASH IN (SELECT KEY_HASH 
                                            FROM ICS_KEY_HASH);
         -- ---------------------------------------
         -- /ICS_CMPL_MON/ICS_SSO_INSP/ICS_SSO_STPS
         -- ---------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CMPL_MON/ICS_SSO_INSP/ICS_SSO_STPS';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_SSO_STPS.DATA_HASH
           FROM ICS_CMPL_MON
           JOIN ICS_SSO_INSP
             ON ICS_SSO_INSP.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID
           JOIN ICS_SSO_STPS
             ON ICS_SSO_STPS.ICS_SSO_INSP_ID = ICS_SSO_INSP.ICS_SSO_INSP_ID
          WHERE ICS_CMPL_MON.KEY_HASH IN (SELECT KEY_HASH 
                                            FROM ICS_KEY_HASH);
         -- ---------------------------------------------
         -- /ICS_CMPL_MON/ICS_SSO_INSP/ICS_SSO_SYSTM_COMP
         -- ---------------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CMPL_MON/ICS_SSO_INSP/ICS_SSO_SYSTM_COMP';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_SSO_SYSTM_COMP.DATA_HASH
           FROM ICS_CMPL_MON
           JOIN ICS_SSO_INSP
             ON ICS_SSO_INSP.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID
           JOIN ICS_SSO_SYSTM_COMP
             ON ICS_SSO_SYSTM_COMP.ICS_SSO_INSP_ID = ICS_SSO_INSP.ICS_SSO_INSP_ID
          WHERE ICS_CMPL_MON.KEY_HASH IN (SELECT KEY_HASH 
                                            FROM ICS_KEY_HASH);
         -- ------------------------------
         -- /ICS_CMPL_MON/ICS_SW_CNST_INSP
         -- ------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CMPL_MON/ICS_SW_CNST_INSP';  
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_SW_CNST_INSP.DATA_HASH
           FROM ICS_CMPL_MON
           JOIN ICS_SW_CNST_INSP
             ON ICS_SW_CNST_INSP.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID
          WHERE ICS_CMPL_MON.KEY_HASH IN (SELECT KEY_HASH 
                                            FROM ICS_KEY_HASH);
         -- -----------------------------------------------------
         -- /ICS_CMPL_MON/ICS_SW_CNST_INSP/ICS_SW_CNST_INDST_INSP
         -- -----------------------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CMPL_MON/ICS_SW_CNST_INSP/ICS_SW_CNST_INDST_INSP';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_SW_CNST_INDST_INSP.DATA_HASH
           FROM ICS_CMPL_MON
           JOIN ICS_SW_CNST_INSP
             ON ICS_SW_CNST_INSP.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID
           JOIN ICS_SW_CNST_INDST_INSP
             ON ICS_SW_CNST_INDST_INSP.ICS_SW_CNST_INSP_ID = ICS_SW_CNST_INSP.ICS_SW_CNST_INSP_ID
          WHERE ICS_CMPL_MON.KEY_HASH IN (SELECT KEY_HASH 
                                            FROM ICS_KEY_HASH);
         -- ------------------------------------------------------
         -- /ICS_CMPL_MON/ICS_SW_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP
         -- ------------------------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CMPL_MON/ICS_SW_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_SW_UNPRMT_CNST_INSP.DATA_HASH
           FROM ICS_CMPL_MON
           JOIN ICS_SW_CNST_INSP
             ON ICS_SW_CNST_INSP.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID
           JOIN ICS_SW_UNPRMT_CNST_INSP
             ON ICS_SW_UNPRMT_CNST_INSP.ICS_SW_CNST_INSP_ID = ICS_SW_CNST_INSP.ICS_SW_CNST_INSP_ID
          WHERE ICS_CMPL_MON.KEY_HASH IN (SELECT KEY_HASH 
                                            FROM ICS_KEY_HASH);
         -- --------------------------------------------------------------------
         -- /ICS_CMPL_MON/ICS_SW_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP/ICS_PROJ_TYPE
         -- --------------------------------------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CMPL_MON/ICS_SW_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP/ICS_PROJ_TYPE';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_PROJ_TYPE.DATA_HASH
           FROM ICS_CMPL_MON
           JOIN ICS_SW_CNST_INSP
             ON ICS_SW_CNST_INSP.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID
           JOIN ICS_SW_UNPRMT_CNST_INSP
             ON ICS_SW_UNPRMT_CNST_INSP.ICS_SW_CNST_INSP_ID = ICS_SW_CNST_INSP.ICS_SW_CNST_INSP_ID
           JOIN ICS_PROJ_TYPE
             ON ICS_PROJ_TYPE.ICS_SW_UNPRMT_CNST_INSP_ID = ICS_SW_UNPRMT_CNST_INSP.ICS_SW_UNPRMT_CNST_INSP_ID
          WHERE ICS_CMPL_MON.KEY_HASH IN (SELECT KEY_HASH 
                                            FROM ICS_KEY_HASH);
         -- ---------------------------------------
         -- /ICS_CMPL_MON/ICS_SW_CNST_NON_CNST_INSP
         -- ---------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CMPL_MON/ICS_SW_CNST_NON_CNST_INSP';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_SW_CNST_NON_CNST_INSP.DATA_HASH
           FROM ICS_CMPL_MON
           JOIN ICS_SW_CNST_NON_CNST_INSP
             ON ICS_SW_CNST_NON_CNST_INSP.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID
          WHERE ICS_CMPL_MON.KEY_HASH IN (SELECT KEY_HASH 
                                            FROM ICS_KEY_HASH);
         -- --------------------------------------------------------------
         -- /ICS_CMPL_MON/ICS_SW_CNST_NON_CNST_INSP/ICS_SW_CNST_INDST_INSP
         -- --------------------------------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CMPL_MON/ICS_SW_CNST_NON_CNST_INSP/ICS_SW_CNST_INDST_INSP';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_SW_CNST_INDST_INSP.DATA_HASH
           FROM ICS_CMPL_MON
           JOIN ICS_SW_CNST_NON_CNST_INSP
             ON ICS_SW_CNST_NON_CNST_INSP.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID
           JOIN ICS_SW_CNST_INDST_INSP
             ON ICS_SW_CNST_INDST_INSP.ICS_SW_CNST_NON_CNST_INSP_ID = ICS_SW_CNST_NON_CNST_INSP.ICS_SW_CNST_NON_CNST_INSP_ID
          WHERE ICS_CMPL_MON.KEY_HASH IN (SELECT KEY_HASH 
                                            FROM ICS_KEY_HASH);
         -- ---------------------------------------------------------------
         -- /ICS_CMPL_MON/ICS_SW_CNST_NON_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP
         -- ---------------------------------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CMPL_MON/ICS_SW_CNST_NON_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_SW_UNPRMT_CNST_INSP.DATA_HASH
           FROM ICS_CMPL_MON
           JOIN ICS_SW_CNST_NON_CNST_INSP
             ON ICS_SW_CNST_NON_CNST_INSP.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID
           JOIN ICS_SW_UNPRMT_CNST_INSP
             ON ICS_SW_UNPRMT_CNST_INSP.ICS_SW_CNST_NON_CNST_INSP_ID = ICS_SW_CNST_NON_CNST_INSP.ICS_SW_CNST_NON_CNST_INSP_ID
          WHERE ICS_CMPL_MON.KEY_HASH IN (SELECT KEY_HASH 
                                            FROM ICS_KEY_HASH);
         -- -----------------------------------------------------------------------------
         -- /ICS_CMPL_MON/ICS_SW_CNST_NON_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP/ICS_PROJ_TYPE
         -- -----------------------------------------------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CMPL_MON/ICS_SW_CNST_NON_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP/ICS_PROJ_TYPE';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_PROJ_TYPE.DATA_HASH
           FROM ICS_CMPL_MON
           JOIN ICS_SW_CNST_NON_CNST_INSP
             ON ICS_SW_CNST_NON_CNST_INSP.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID
           JOIN ICS_SW_UNPRMT_CNST_INSP
             ON ICS_SW_UNPRMT_CNST_INSP.ICS_SW_CNST_NON_CNST_INSP_ID = ICS_SW_CNST_NON_CNST_INSP.ICS_SW_CNST_NON_CNST_INSP_ID
           JOIN ICS_PROJ_TYPE
             ON ICS_PROJ_TYPE.ICS_SW_UNPRMT_CNST_INSP_ID = ICS_SW_UNPRMT_CNST_INSP.ICS_SW_UNPRMT_CNST_INSP_ID
          WHERE ICS_CMPL_MON.KEY_HASH IN (SELECT KEY_HASH 
                                            FROM ICS_KEY_HASH);
         -- ------------------------------
         -- /ICS_CMPL_MON/ICS_SW_MS_4_INSP
         -- ------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CMPL_MON/ICS_SW_MS_4_INSP';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_SW_MS_4_INSP.DATA_HASH
           FROM ICS_CMPL_MON
           JOIN ICS_SW_MS_4_INSP
             ON ICS_SW_MS_4_INSP.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID
          WHERE ICS_CMPL_MON.KEY_HASH IN (SELECT KEY_HASH 
                                            FROM ICS_KEY_HASH);
         -- -------------------------------------------------
         -- /ICS_CMPL_MON/ICS_SW_MS_4_INSP/ICS_PROJ_SRCS_FUND
         -- -------------------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CMPL_MON/ICS_SW_MS_4_INSP/ICS_PROJ_SRCS_FUND';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_PROJ_SRCS_FUND.DATA_HASH
           FROM ICS_CMPL_MON
           JOIN ICS_SW_MS_4_INSP
             ON ICS_SW_MS_4_INSP.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID
           JOIN ICS_PROJ_SRCS_FUND
             ON ICS_PROJ_SRCS_FUND.ICS_SW_MS_4_INSP_ID = ICS_SW_MS_4_INSP.ICS_SW_MS_4_INSP_ID
          WHERE ICS_CMPL_MON.KEY_HASH IN (SELECT KEY_HASH 
                                            FROM ICS_KEY_HASH);
         -- ----------------------------------
         -- /ICS_CMPL_MON/ICS_SW_NON_CNST_INSP
         -- ----------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CMPL_MON/ICS_SW_NON_CNST_INSP';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_SW_NON_CNST_INSP.DATA_HASH
           FROM ICS_CMPL_MON
           JOIN ICS_SW_NON_CNST_INSP
             ON ICS_SW_NON_CNST_INSP.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID
          WHERE ICS_CMPL_MON.KEY_HASH IN (SELECT KEY_HASH 
                                            FROM ICS_KEY_HASH);
         -- ---------------------------------------------------------
         -- /ICS_CMPL_MON/ICS_SW_NON_CNST_INSP/ICS_SW_CNST_INDST_INSP
         -- ---------------------------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CMPL_MON/ICS_SW_NON_CNST_INSP/ICS_SW_CNST_INDST_INSP';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_SW_CNST_INDST_INSP.DATA_HASH
           FROM ICS_CMPL_MON
           JOIN ICS_SW_NON_CNST_INSP
             ON ICS_SW_NON_CNST_INSP.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID
           JOIN ICS_SW_CNST_INDST_INSP
             ON ICS_SW_CNST_INDST_INSP.ICS_SW_NON_CNST_INSP_ID = ICS_SW_NON_CNST_INSP.ICS_SW_NON_CNST_INSP_ID
          WHERE ICS_CMPL_MON.KEY_HASH IN (SELECT KEY_HASH 
                                            FROM ICS_KEY_HASH);
         -- ----------------------------------------------------------
         -- /ICS_CMPL_MON/ICS_SW_NON_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP
         -- ----------------------------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CMPL_MON/ICS_SW_NON_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_SW_UNPRMT_CNST_INSP.DATA_HASH
           FROM ICS_CMPL_MON
           JOIN ICS_SW_NON_CNST_INSP
             ON ICS_SW_NON_CNST_INSP.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID
           JOIN ICS_SW_UNPRMT_CNST_INSP
             ON ICS_SW_UNPRMT_CNST_INSP.ICS_SW_NON_CNST_INSP_ID = ICS_SW_NON_CNST_INSP.ICS_SW_NON_CNST_INSP_ID
          WHERE ICS_CMPL_MON.KEY_HASH IN (SELECT KEY_HASH 
                                            FROM ICS_KEY_HASH);
         -- ------------------------------------------------------------------------
         -- /ICS_CMPL_MON/ICS_SW_NON_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP/ICS_PROJ_TYPE
         -- ------------------------------------------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CMPL_MON/ICS_SW_NON_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP/ICS_PROJ_TYPE';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_PROJ_TYPE.DATA_HASH
           FROM ICS_CMPL_MON
           JOIN ICS_SW_NON_CNST_INSP
             ON ICS_SW_NON_CNST_INSP.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID
           JOIN ICS_SW_UNPRMT_CNST_INSP
             ON ICS_SW_UNPRMT_CNST_INSP.ICS_SW_NON_CNST_INSP_ID = ICS_SW_NON_CNST_INSP.ICS_SW_NON_CNST_INSP_ID
           JOIN ICS_PROJ_TYPE
             ON ICS_PROJ_TYPE.ICS_SW_UNPRMT_CNST_INSP_ID = ICS_SW_UNPRMT_CNST_INSP.ICS_SW_UNPRMT_CNST_INSP_ID
          WHERE ICS_CMPL_MON.KEY_HASH IN (SELECT KEY_HASH 
                                            FROM ICS_KEY_HASH);

      END IF;
      -- =============
      -- ICS_GNRL_PRMT
      -- =============
      IF v_table_name = 'ICS_GNRL_PRMT' AND 
         v_enabled    = 'Y'             THEN
         -- --------------
         -- /ICS_GNRL_PRMT
         -- --------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_GNRL_PRMT';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_GNRL_PRMT.DATA_HASH
           FROM ICS_GNRL_PRMT
          WHERE ICS_GNRL_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                             FROM ICS_KEY_HASH);
         -- -----------------------
         -- /ICS_GNRL_PRMT/ICS_ADDR
         -- -----------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_GNRL_PRMT/ICS_ADDR';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_ADDR.DATA_HASH
           FROM ICS_GNRL_PRMT
           JOIN ICS_ADDR
             ON ICS_ADDR.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
          WHERE ICS_GNRL_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                             FROM ICS_KEY_HASH);
         -- ----------------------------------
         -- /ICS_GNRL_PRMT/ICS_ADDR/ICS_TELEPH
         -- ----------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_GNRL_PRMT/ICS_ADDR/ICS_TELEPH';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_TELEPH.DATA_HASH
           FROM ICS_GNRL_PRMT
           JOIN ICS_ADDR
             ON ICS_ADDR.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
           JOIN ICS_TELEPH
             ON ICS_TELEPH.ICS_ADDR_ID = ICS_ADDR.ICS_ADDR_ID
          WHERE ICS_GNRL_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                             FROM ICS_KEY_HASH);
         -- ----------------------------
         -- /ICS_GNRL_PRMT/ICS_ASSC_PRMT
         -- ----------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_GNRL_PRMT/ICS_ASSC_PRMT';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_ASSC_PRMT.DATA_HASH
           FROM ICS_GNRL_PRMT
           JOIN ICS_ASSC_PRMT
             ON ICS_ASSC_PRMT.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
          WHERE ICS_GNRL_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                             FROM ICS_KEY_HASH);
         -- ----------------------------------
         -- /ICS_GNRL_PRMT/ICS_CMPL_TRACK_STAT
         -- ----------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_GNRL_PRMT/ICS_CMPL_TRACK_STAT';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_CMPL_TRACK_STAT.DATA_HASH
           FROM ICS_GNRL_PRMT
           JOIN ICS_CMPL_TRACK_STAT
             ON ICS_CMPL_TRACK_STAT.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
          WHERE ICS_GNRL_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                             FROM ICS_KEY_HASH);
         -- --------------------------
         -- /ICS_GNRL_PRMT/ICS_CONTACT
         -- --------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_GNRL_PRMT/ICS_CONTACT';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_CONTACT.DATA_HASH
           FROM ICS_GNRL_PRMT
           JOIN ICS_CONTACT
             ON ICS_CONTACT.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
          WHERE ICS_GNRL_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                             FROM ICS_KEY_HASH);
         -- -------------------------------------
         -- /ICS_GNRL_PRMT/ICS_CONTACT/ICS_TELEPH
         -- -------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_GNRL_PRMT/ICS_CONTACT/ICS_TELEPH';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_TELEPH.DATA_HASH
           FROM ICS_GNRL_PRMT
           JOIN ICS_CONTACT
             ON ICS_CONTACT.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
           JOIN ICS_TELEPH
             ON ICS_TELEPH.ICS_CONTACT_ID = ICS_CONTACT.ICS_CONTACT_ID
          WHERE ICS_GNRL_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                             FROM ICS_KEY_HASH);
         -- ------------------------------
         -- /ICS_GNRL_PRMT/ICS_EFFLU_GUIDE
         -- ------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_GNRL_PRMT/ICS_EFFLU_GUIDE';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_EFFLU_GUIDE.DATA_HASH
           FROM ICS_GNRL_PRMT
           JOIN ICS_EFFLU_GUIDE
             ON ICS_EFFLU_GUIDE.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
          WHERE ICS_GNRL_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                              FROM ICS_KEY_HASH);
         -- ----------------------
         -- /ICS_GNRL_PRMT/ICS_FAC
         -- ----------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_GNRL_PRMT/ICS_FAC';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_FAC.DATA_HASH
           FROM ICS_GNRL_PRMT
           JOIN ICS_FAC
             ON ICS_FAC.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
          WHERE ICS_GNRL_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                             FROM ICS_KEY_HASH);
         -- -------------------------------
         -- /ICS_GNRL_PRMT/ICS_FAC/ICS_ADDR
         -- -------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_GNRL_PRMT/ICS_FAC/ICS_ADDR';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_ADDR.DATA_HASH
           FROM ICS_GNRL_PRMT
           JOIN ICS_FAC
             ON ICS_FAC.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
           JOIN ICS_ADDR
             ON ICS_ADDR.ICS_FAC_ID = ICS_FAC.ICS_FAC_ID
          WHERE ICS_GNRL_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                             FROM ICS_KEY_HASH);
         -- ------------------------------------------
         -- /ICS_GNRL_PRMT/ICS_FAC/ICS_ADDR/ICS_TELEPH
         -- ------------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_GNRL_PRMT/ICS_FAC/ICS_ADDR/ICS_TELEPH';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_TELEPH.DATA_HASH
           FROM ICS_GNRL_PRMT
           JOIN ICS_FAC
             ON ICS_FAC.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
           JOIN ICS_ADDR
             ON ICS_ADDR.ICS_FAC_ID = ICS_FAC.ICS_FAC_ID
           JOIN ICS_TELEPH
             ON ICS_TELEPH.ICS_ADDR_ID = ICS_ADDR.ICS_ADDR_ID
          WHERE ICS_GNRL_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                             FROM ICS_KEY_HASH);
         -- ----------------------------------
         -- /ICS_GNRL_PRMT/ICS_FAC/ICS_CONTACT
         -- ----------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_GNRL_PRMT/ICS_FAC/ICS_CONTACT';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_CONTACT.DATA_HASH
           FROM ICS_GNRL_PRMT
           JOIN ICS_FAC
             ON ICS_FAC.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
           JOIN ICS_CONTACT
             ON ICS_CONTACT.ICS_FAC_ID = ICS_FAC.ICS_FAC_ID
          WHERE ICS_GNRL_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                             FROM ICS_KEY_HASH);
         -- ---------------------------------------------
         -- /ICS_GNRL_PRMT/ICS_FAC/ICS_CONTACT/ICS_TELEPH
         -- ---------------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_GNRL_PRMT/ICS_FAC/ICS_CONTACT/ICS_TELEPH';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_TELEPH.DATA_HASH
           FROM ICS_GNRL_PRMT
           JOIN ICS_FAC
             ON ICS_FAC.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
           JOIN ICS_CONTACT
             ON ICS_CONTACT.ICS_FAC_ID = ICS_FAC.ICS_FAC_ID
           JOIN ICS_TELEPH
             ON ICS_TELEPH.ICS_CONTACT_ID = ICS_CONTACT.ICS_CONTACT_ID
          WHERE ICS_GNRL_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                             FROM ICS_KEY_HASH);
         -- ------------------------------------
         -- /ICS_GNRL_PRMT/ICS_FAC/ICS_FAC_CLASS
         -- ------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_GNRL_PRMT/ICS_FAC/ICS_FAC_CLASS';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_FAC_CLASS.DATA_HASH
           FROM ICS_GNRL_PRMT
           JOIN ICS_FAC
             ON ICS_FAC.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
           JOIN ICS_FAC_CLASS
             ON ICS_FAC_CLASS.ICS_FAC_ID = ICS_FAC.ICS_FAC_ID
          WHERE ICS_GNRL_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                             FROM ICS_KEY_HASH);
         -- ------------------------------------
         -- /ICS_GNRL_PRMT/ICS_FAC/ICS_GEO_COORD
         -- ------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_GNRL_PRMT/ICS_FAC/ICS_GEO_COORD';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_GEO_COORD.DATA_HASH
           FROM ICS_GNRL_PRMT
           JOIN ICS_FAC
             ON ICS_FAC.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
           JOIN ICS_GEO_COORD
             ON ICS_GEO_COORD.ICS_FAC_ID = ICS_FAC.ICS_FAC_ID
          WHERE ICS_GNRL_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                             FROM ICS_KEY_HASH);
         -- -------------------------------------
         -- /ICS_GNRL_PRMT/ICS_FAC/ICS_NAICS_CODE
         -- -------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_GNRL_PRMT/ICS_FAC/ICS_NAICS_CODE';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_NAICS_CODE.DATA_HASH
           FROM ICS_GNRL_PRMT
           JOIN ICS_FAC
             ON ICS_FAC.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
           JOIN ICS_NAICS_CODE
             ON ICS_NAICS_CODE.ICS_FAC_ID = ICS_FAC.ICS_FAC_ID
          WHERE ICS_GNRL_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                             FROM ICS_KEY_HASH);
         -- -------------------------------------
         -- /ICS_GNRL_PRMT/ICS_FAC/ICS_ORIG_PROGS
         -- -------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_GNRL_PRMT/ICS_FAC/ICS_ORIG_PROGS';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_ORIG_PROGS.DATA_HASH
           FROM ICS_GNRL_PRMT
           JOIN ICS_FAC
             ON ICS_FAC.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
           JOIN ICS_ORIG_PROGS
             ON ICS_ORIG_PROGS.ICS_FAC_ID = ICS_FAC.ICS_FAC_ID
          WHERE ICS_GNRL_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                             FROM ICS_KEY_HASH);
         -- --------------------------------
         -- /ICS_GNRL_PRMT/ICS_FAC/ICS_PLCY
         -- -------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_GNRL_PRMT/ICS_FAC/ICS_PLCY';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_PLCY.DATA_HASH
           FROM ICS_GNRL_PRMT
           JOIN ICS_FAC
             ON ICS_FAC.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
           JOIN ICS_PLCY
             ON ICS_PLCY.ICS_FAC_ID = ICS_FAC.ICS_FAC_ID
          WHERE ICS_GNRL_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                             FROM ICS_KEY_HASH);
         -- -----------------------------------
         -- /ICS_GNRL_PRMT/ICS_FAC/ICS_SIC_CODE
         -- -----------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_GNRL_PRMT/ICS_FAC/ICS_SIC_CODE';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_SIC_CODE.DATA_HASH
           FROM ICS_GNRL_PRMT
           JOIN ICS_FAC
             ON ICS_FAC.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
           JOIN ICS_SIC_CODE
             ON ICS_SIC_CODE.ICS_FAC_ID = ICS_FAC.ICS_FAC_ID
          WHERE ICS_GNRL_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                             FROM ICS_KEY_HASH);
         -- -----------------------------
         -- /ICS_GNRL_PRMT/ICS_NAICS_CODE
         -- -----------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_GNRL_PRMT/ICS_NAICS_CODE';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_NAICS_CODE.DATA_HASH
           FROM ICS_GNRL_PRMT
           JOIN ICS_NAICS_CODE
             ON ICS_NAICS_CODE.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
          WHERE ICS_GNRL_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                             FROM ICS_KEY_HASH);
         -- -----------------------------
         -- /ICS_GNRL_PRMT/ICS_OTHR_PRMTS
         -- -----------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_GNRL_PRMT/ICS_OTHR_PRMTS';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_OTHR_PRMTS.DATA_HASH
           FROM ICS_GNRL_PRMT
           JOIN ICS_OTHR_PRMTS
             ON ICS_OTHR_PRMTS.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
          WHERE ICS_GNRL_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                             FROM ICS_KEY_HASH);
         -- ---------------------------
         -- /ICS_GNRL_PRMT/ICS_SIC_CODE
         -- ---------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_GNRL_PRMT/ICS_SIC_CODE';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_SIC_CODE.DATA_HASH
           FROM ICS_GNRL_PRMT
           JOIN ICS_SIC_CODE
             ON ICS_SIC_CODE.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
          WHERE ICS_GNRL_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                             FROM ICS_KEY_HASH);
      
      END IF;
      -- ====================
      -- ICS_MASTER_GNRL_PRMT
      -- ====================
      IF v_table_name = 'ICS_MASTER_GNRL_PRMT' AND 
         v_enabled    = 'Y'                    THEN
         -- ---------------------
         -- /ICS_MASTER_GNRL_PRMT
         -- ---------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_MASTER_GNRL_PRMT';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_MASTER_GNRL_PRMT.DATA_HASH
           FROM ICS_MASTER_GNRL_PRMT
          WHERE ICS_MASTER_GNRL_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                                    FROM ICS_KEY_HASH);
         -- -----------------------------------
         -- /ICS_MASTER_GNRL_PRMT/ICS_ASSC_PRMT
         -- -----------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_MASTER_GNRL_PRMT/ICS_ASSC_PRMT';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_ASSC_PRMT.DATA_HASH
           FROM ICS_MASTER_GNRL_PRMT
           JOIN ICS_ASSC_PRMT
             ON ICS_ASSC_PRMT.ICS_MASTER_GNRL_PRMT_ID = ICS_MASTER_GNRL_PRMT.ICS_MASTER_GNRL_PRMT_ID
          WHERE ICS_MASTER_GNRL_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                                    FROM ICS_KEY_HASH);
         -- ---------------------------------
         -- /ICS_MASTER_GNRL_PRMT/ICS_CONTACT
         -- ---------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_MASTER_GNRL_PRMT/ICS_CONTACT';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_CONTACT.DATA_HASH
           FROM ICS_MASTER_GNRL_PRMT
           JOIN ICS_CONTACT
             ON ICS_CONTACT.ICS_MASTER_GNRL_PRMT_ID = ICS_MASTER_GNRL_PRMT.ICS_MASTER_GNRL_PRMT_ID
          WHERE ICS_MASTER_GNRL_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                                    FROM ICS_KEY_HASH);
         -- --------------------------------------------
         -- /ICS_MASTER_GNRL_PRMT/ICS_CONTACT/ICS_TELEPH
         -- --------------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_MASTER_GNRL_PRMT/ICS_CONTACT/ICS_TELEPH';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_TELEPH.DATA_HASH
           FROM ICS_MASTER_GNRL_PRMT
           JOIN ICS_CONTACT
             ON ICS_CONTACT.ICS_MASTER_GNRL_PRMT_ID = ICS_MASTER_GNRL_PRMT.ICS_MASTER_GNRL_PRMT_ID
           JOIN ICS_TELEPH
             ON ICS_TELEPH.ICS_CONTACT_ID = ICS_CONTACT.ICS_CONTACT_ID
          WHERE ICS_MASTER_GNRL_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                                    FROM ICS_KEY_HASH);
         -- ------------------------------------
         -- /ICS_MASTER_GNRL_PRMT/ICS_NAICS_CODE
         -- ------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_MASTER_GNRL_PRMT/ICS_NAICS_CODE';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_NAICS_CODE.DATA_HASH
           FROM ICS_MASTER_GNRL_PRMT
           JOIN ICS_NAICS_CODE
             ON ICS_NAICS_CODE.ICS_MASTER_GNRL_PRMT_ID = ICS_MASTER_GNRL_PRMT.ICS_MASTER_GNRL_PRMT_ID
          WHERE ICS_MASTER_GNRL_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                                    FROM ICS_KEY_HASH);
         -- ------------------------------------
         -- /ICS_MASTER_GNRL_PRMT/ICS_OTHR_PRMTS
         -- ------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_MASTER_GNRL_PRMT/ICS_OTHR_PRMTS';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_OTHR_PRMTS.DATA_HASH
           FROM ICS_MASTER_GNRL_PRMT
           JOIN ICS_OTHR_PRMTS
             ON ICS_OTHR_PRMTS.ICS_MASTER_GNRL_PRMT_ID = ICS_MASTER_GNRL_PRMT.ICS_MASTER_GNRL_PRMT_ID
          WHERE ICS_MASTER_GNRL_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                                    FROM ICS_KEY_HASH);
         -- ----------------------------------------
         -- /ICS_MASTER_GNRL_PRMT/ICS_PRMT_COMP_TYPE
         -- ----------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_MASTER_GNRL_PRMT/ICS_PRMT_COMP_TYPE';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_PRMT_COMP_TYPE.DATA_HASH
           FROM ICS_MASTER_GNRL_PRMT
           JOIN ICS_PRMT_COMP_TYPE
             ON ICS_PRMT_COMP_TYPE.ICS_MASTER_GNRL_PRMT_ID = ICS_MASTER_GNRL_PRMT.ICS_MASTER_GNRL_PRMT_ID
          WHERE ICS_MASTER_GNRL_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                                    FROM ICS_KEY_HASH);
         -- ----------------------------------
         -- /ICS_MASTER_GNRL_PRMT/ICS_SIC_CODE
         -- ----------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_MASTER_GNRL_PRMT/ICS_SIC_CODE';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_SIC_CODE.DATA_HASH
           FROM ICS_MASTER_GNRL_PRMT
           JOIN ICS_SIC_CODE
             ON ICS_SIC_CODE.ICS_MASTER_GNRL_PRMT_ID = ICS_MASTER_GNRL_PRMT.ICS_MASTER_GNRL_PRMT_ID
          WHERE ICS_MASTER_GNRL_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                                    FROM ICS_KEY_HASH);
      END IF;
      -- ===============
      -- ICS_PRMT_REISSU
      -- ===============
      IF v_table_name = 'ICS_PRMT_REISSU' AND 
         v_enabled    = 'Y'               THEN
         -- ----------------
         -- /ICS_PRMT_REISSU
         -- ----------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_PRMT_REISSU';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_PRMT_REISSU.DATA_HASH
           FROM ICS_PRMT_REISSU
          WHERE ICS_PRMT_REISSU.KEY_HASH IN (SELECT KEY_HASH 
                                               FROM ICS_KEY_HASH);
      END IF;
      -- =============
      -- ICS_PRMT_TERM
      -- =============
      IF v_table_name = 'ICS_PRMT_TERM' AND 
         v_enabled     = 'Y'            THEN
         -- --------------
         -- /ICS_PRMT_TERM
         -- --------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_PRMT_TERM';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_PRMT_TERM.DATA_HASH
           FROM ICS_PRMT_TERM
          WHERE ICS_PRMT_TERM.KEY_HASH IN (SELECT KEY_HASH 
                                             FROM ICS_KEY_HASH);
      END IF;
      -- ==================
      -- ICS_PRMT_TRACK_EVT
      -- ==================
      IF v_table_name = 'ICS_PRMT_TRACK_EVT' AND 
         v_enabled    = 'Y'                  THEN
         -- -------------------
         -- /ICS_PRMT_TRACK_EVT
         -- -------------------
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_PRMT_TRACK_EVT.DATA_HASH
           FROM ICS_PRMT_TRACK_EVT
          WHERE ICS_PRMT_TRACK_EVT.KEY_HASH IN (SELECT KEY_HASH 
                                                  FROM ICS_KEY_HASH);
      END IF;
      -- =============
      -- ICS_POTW_PRMT
      -- =============
      IF v_table_name = 'ICS_POTW_PRMT' AND 
         v_enabled    = 'Y'             THEN
         -- --------------
         -- /ICS_POTW_PRMT
         -- --------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_POTW_PRMT';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_POTW_PRMT.DATA_HASH
           FROM ICS_POTW_PRMT
          WHERE ICS_POTW_PRMT.KEY_HASH = KEY_HASH.KEY_HASH;
         -- ----------------------------------
         -- /ICS_POTW_PRMT/ICS_SATL_COLL_SYSTM
         -- ----------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_POTW_PRMT/ICS_SATL_COLL_SYSTM';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_SATL_COLL_SYSTM.DATA_HASH
           FROM ICS_POTW_PRMT
           JOIN ICS_SATL_COLL_SYSTM
             ON ICS_SATL_COLL_SYSTM.ICS_POTW_PRMT_ID = ICS_POTW_PRMT.ICS_POTW_PRMT_ID
          WHERE ICS_POTW_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                             FROM ICS_KEY_HASH);
      END IF;
      -- ==============
      -- ICS_PRETR_PRMT
      -- ==============
      IF v_table_name = 'ICS_PRETR_PRMT' AND 
         v_enabled    = 'Y'              THEN
         -- ---------------
         -- /ICS_PRETR_PRMT
         -- ---------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_PRETR_PRMT';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_PRETR_PRMT.DATA_HASH
           FROM ICS_PRETR_PRMT
          WHERE ICS_PRETR_PRMT.KEY_HASH = KEY_HASH.KEY_HASH;
         -- ---------------------------
         -- /ICS_PRETR_PRMT/ICS_CONTACT
         -- ---------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_PRETR_PRMT';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_CONTACT.DATA_HASH
           FROM ICS_PRETR_PRMT
           JOIN ICS_CONTACT
             ON ICS_CONTACT.ICS_PRETR_PRMT_ID = ICS_PRETR_PRMT.ICS_PRETR_PRMT_ID
          WHERE ICS_PRETR_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                              FROM ICS_KEY_HASH);
         -- --------------------------------------
         -- /ICS_PRETR_PRMT/ICS_CONTACT/ICS_TELEPH
         -- --------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_PRETR_PRMT/ICS_CONTACT/ICS_TELEPH';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_TELEPH.DATA_HASH
           FROM ICS_PRETR_PRMT
           JOIN ICS_CONTACT
             ON ICS_CONTACT.ICS_PRETR_PRMT_ID = ICS_PRETR_PRMT.ICS_PRETR_PRMT_ID
           JOIN ICS_TELEPH
             ON ICS_TELEPH.ICS_CONTACT_ID = ICS_CONTACT.ICS_CONTACT_ID
          WHERE ICS_PRETR_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                              FROM ICS_KEY_HASH);
      END IF;
      -- ================
      -- ICS_SW_CNST_PRMT
      -- ================
      IF v_table_name = 'ICS_SW_CNST_PRMT' AND 
         v_enabled    = 'Y'                THEN
         -- -----------------
         -- /ICS_SW_CNST_PRMT
         -- -----------------
         SET v_marker = 'INSERT INTO ics_data_hash//ICS_SW_CNST_PRMT';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_SW_CNST_PRMT.DATA_HASH
           FROM ICS_SW_CNST_PRMT
          WHERE ICS_SW_CNST_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                                FROM ICS_KEY_HASH);
         -- ---------------------------
         --  /ICS_SW_CNST_PRMT/ICS_ADDR
         -- ---------------------------
         SET v_marker = 'INSERT INTO ics_data_hash /ICS_SW_CNST_PRMT/ICS_ADDR';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_ADDR.DATA_HASH
           FROM ICS_SW_CNST_PRMT
           JOIN ICS_ADDR
             ON ICS_ADDR.ICS_SW_CNST_PRMT_ID = ICS_SW_CNST_PRMT.ICS_SW_CNST_PRMT_ID
          WHERE ICS_SW_CNST_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                                FROM ICS_KEY_HASH);
         -- -------------------------------------
         -- /ICS_SW_CNST_PRMT/ICS_ADDR/ICS_TELEPH
         -- -------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_SW_CNST_PRMT/ICS_ADDR/ICS_TELEPH';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_TELEPH.DATA_HASH
           FROM ICS_SW_CNST_PRMT
           JOIN ICS_ADDR
             ON ICS_ADDR.ICS_SW_CNST_PRMT_ID = ICS_SW_CNST_PRMT.ICS_SW_CNST_PRMT_ID
           JOIN ICS_TELEPH
             ON ICS_TELEPH.ICS_ADDR_ID = ICS_ADDR.ICS_ADDR_ID
          WHERE ICS_SW_CNST_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                                 FROM ICS_KEY_HASH);
         -- -----------------------------
         -- /ICS_SW_CNST_PRMT/ICS_CONTACT
         -- -----------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_SW_CNST_PRMT/ICS_CONTACT';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_CONTACT.DATA_HASH
           FROM ICS_SW_CNST_PRMT
           JOIN ICS_CONTACT
             ON ICS_CONTACT.ICS_SW_CNST_PRMT_ID = ICS_SW_CNST_PRMT.ICS_SW_CNST_PRMT_ID
          WHERE ICS_SW_CNST_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                                FROM ICS_KEY_HASH);
         -- ----------------------------------------
         -- /ICS_SW_CNST_PRMT/ICS_CONTACT/ICS_TELEPH
         -- ----------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_SW_CNST_PRMT/ICS_CONTACT/ICS_TELEPH';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_TELEPH.DATA_HASH
           FROM ICS_SW_CNST_PRMT
           JOIN ICS_CONTACT
             ON ICS_CONTACT.ICS_SW_CNST_PRMT_ID = ICS_SW_CNST_PRMT.ICS_SW_CNST_PRMT_ID
           JOIN ICS_TELEPH
             ON ICS_TELEPH.ICS_CONTACT_ID = ICS_CONTACT.ICS_CONTACT_ID
          WHERE ICS_SW_CNST_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                                FROM ICS_KEY_HASH);
         -- -------------------------------------------
         -- /ICS_SW_CNST_PRMT/ICS_GPCF_NOTICE_OF_INTENT
         -- -------------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_SW_CNST_PRMT/ICS_GPCF_NOTICE_OF_INTENT';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_GPCF_NOTICE_OF_INTENT.DATA_HASH
           FROM ICS_SW_CNST_PRMT
           JOIN ICS_GPCF_NOTICE_OF_INTENT
             ON ICS_GPCF_NOTICE_OF_INTENT.ICS_SW_CNST_PRMT_ID = ICS_SW_CNST_PRMT.ICS_SW_CNST_PRMT_ID
          WHERE ICS_SW_CNST_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                                FROM ICS_KEY_HASH);
         -- -----------------------------------------
         -- /ICS_SW_CNST_PRMT/ICS_GPCF_NOTICE_OF_TERM
         -- -----------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_SW_CNST_PRMT/ICS_GPCF_NOTICE_OF_TERM';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_GPCF_NOTICE_OF_TERM.DATA_HASH
           FROM ICS_SW_CNST_PRMT
           JOIN ICS_GPCF_NOTICE_OF_TERM
             ON ICS_GPCF_NOTICE_OF_TERM.ICS_SW_CNST_PRMT_ID = ICS_SW_CNST_PRMT.ICS_SW_CNST_PRMT_ID
          WHERE ICS_SW_CNST_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                                FROM ICS_KEY_HASH);
      END IF;
      -- =================
      -- ICS_SW_INDST_PRMT
      -- =================
      IF v_table_name = 'ICS_SW_INDST_PRMT' AND 
         v_enabled    = 'Y'                 THEN
         -- ------------------
         -- /ICS_SW_INDST_PRMT
         -- ------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_SW_INDST_PRMT';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_SW_INDST_PRMT.DATA_HASH
           FROM ICS_SW_INDST_PRMT
          WHERE ICS_SW_INDST_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                                FROM ICS_KEY_HASH);
         -- ---------------------------
         -- /ICS_SW_INDST_PRMT/ICS_ADDR
         -- ---------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_SW_INDST_PRMT/ICS_ADDR';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_ADDR.DATA_HASH
           FROM ICS_SW_INDST_PRMT
           JOIN ICS_ADDR
             ON ICS_ADDR.ICS_SW_INDST_PRMT_ID = ICS_SW_INDST_PRMT.ICS_SW_INDST_PRMT_ID
          WHERE ICS_SW_INDST_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                                 FROM ICS_KEY_HASH);
         -- --------------------------------------
         -- /ICS_SW_INDST_PRMT/ICS_ADDR/ICS_TELEPH
         -- --------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_SW_INDST_PRMT/ICS_ADDR/ICS_TELEPH';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_TELEPH.DATA_HASH
           FROM ICS_SW_INDST_PRMT
           JOIN ICS_ADDR
             ON ICS_ADDR.ICS_SW_INDST_PRMT_ID = ICS_SW_INDST_PRMT.ICS_SW_INDST_PRMT_ID
           JOIN ICS_TELEPH
             ON ICS_TELEPH.ICS_ADDR_ID = ICS_ADDR.ICS_ADDR_ID
          WHERE ICS_SW_INDST_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                                 FROM ICS_KEY_HASH);
         -- ------------------------------
         -- /ICS_SW_INDST_PRMT/ICS_CONTACT
         -- ------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_SW_INDST_PRMT/ICS_CONTACT';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_CONTACT.DATA_HASH
           FROM ICS_SW_INDST_PRMT
           JOIN ICS_CONTACT
             ON ICS_CONTACT.ICS_SW_INDST_PRMT_ID = ICS_SW_INDST_PRMT.ICS_SW_INDST_PRMT_ID
          WHERE ICS_SW_INDST_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                                 FROM ICS_KEY_HASH);
         -- -----------------------------------------
         -- /ICS_SW_INDST_PRMT/ICS_CONTACT/ICS_TELEPH
         -- -----------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_SW_INDST_PRMT/ICS_CONTACT/ICS_TELEPH';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_TELEPH.DATA_HASH
           FROM ICS_SW_INDST_PRMT
           JOIN ICS_CONTACT
             ON ICS_CONTACT.ICS_SW_INDST_PRMT_ID = ICS_SW_INDST_PRMT.ICS_SW_INDST_PRMT_ID
           JOIN ICS_TELEPH
             ON ICS_TELEPH.ICS_CONTACT_ID = ICS_CONTACT.ICS_CONTACT_ID
          WHERE ICS_SW_INDST_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                                 FROM ICS_KEY_HASH);
         -- ---------------------------------------
         -- /ICS_SW_INDST_PRMT/ICS_GPCF_NO_EXPOSURE
         -- ---------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_SW_INDST_PRMT/ICS_GPCF_NO_EXPOSURE';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_GPCF_NO_EXPOSURE.DATA_HASH
           FROM ICS_SW_INDST_PRMT
           JOIN ICS_GPCF_NO_EXPOSURE
             ON ICS_GPCF_NO_EXPOSURE.ICS_SW_INDST_PRMT_ID = ICS_SW_INDST_PRMT.ICS_SW_INDST_PRMT_ID
          WHERE ICS_SW_INDST_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                                 FROM ICS_KEY_HASH);
         -- --------------------------------------------
         -- /ICS_SW_INDST_PRMT/ICS_GPCF_NOTICE_OF_INTENT
         -- --------------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_SW_INDST_PRMT/ICS_GPCF_NOTICE_OF_INTENT';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_GPCF_NOTICE_OF_INTENT.DATA_HASH
           FROM ICS_SW_INDST_PRMT
           JOIN ICS_GPCF_NOTICE_OF_INTENT
             ON ICS_GPCF_NOTICE_OF_INTENT.ICS_SW_INDST_PRMT_ID = ICS_SW_INDST_PRMT.ICS_SW_INDST_PRMT_ID
          WHERE ICS_SW_INDST_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                                 FROM ICS_KEY_HASH);
         -- ------------------------------------------
         -- /ICS_SW_INDST_PRMT/ICS_GPCF_NOTICE_OF_TERM
         -- ------------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_SW_INDST_PRMT/ICS_GPCF_NOTICE_OF_TERM';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_GPCF_NOTICE_OF_TERM.DATA_HASH
           FROM ICS_SW_INDST_PRMT
           JOIN ICS_GPCF_NOTICE_OF_TERM
             ON ICS_GPCF_NOTICE_OF_TERM.ICS_SW_INDST_PRMT_ID = ICS_SW_INDST_PRMT.ICS_SW_INDST_PRMT_ID
          WHERE ICS_SW_INDST_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                                 FROM ICS_KEY_HASH);
      END IF;
      -- =====================
      -- ICS_SWMS_4_LARGE_PRMT
      -- =====================
      IF v_table_name = 'ICS_SWMS_4_LARGE_PRMT' AND 
         v_enabled    = 'Y'                     THEN
         -- ----------------------
         -- /ICS_SWMS_4_LARGE_PRMT
         -- ----------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_SWMS_4_LARGE_PRMT';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_SWMS_4_LARGE_PRMT.DATA_HASH
           FROM ICS_SWMS_4_LARGE_PRMT
          WHERE ICS_SWMS_4_LARGE_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                                     FROM ICS_KEY_HASH);
         -- -------------------------------
         -- /ICS_SWMS_4_LARGE_PRMT/ICS_ADDR
         -- -------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_SWMS_4_LARGE_PRMT/ICS_ADDR';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_ADDR.DATA_HASH
           FROM ICS_SWMS_4_LARGE_PRMT
           JOIN ICS_ADDR
             ON ICS_ADDR.ICS_SWMS_4_LARGE_PRMT_ID = ICS_SWMS_4_LARGE_PRMT.ICS_SWMS_4_LARGE_PRMT_ID
          WHERE ICS_SWMS_4_LARGE_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                                     FROM ICS_KEY_HASH);
         -- ------------------------------------------
         -- /ICS_SWMS_4_LARGE_PRMT/ICS_ADDR/ICS_TELEPH
         -- ------------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_SWMS_4_LARGE_PRMT/ICS_ADDR/ICS_TELEPH';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_TELEPH.DATA_HASH
           FROM ICS_SWMS_4_LARGE_PRMT
           JOIN ICS_ADDR
             ON ICS_ADDR.ICS_SWMS_4_LARGE_PRMT_ID = ICS_SWMS_4_LARGE_PRMT.ICS_SWMS_4_LARGE_PRMT_ID
           JOIN ICS_TELEPH
             ON ICS_TELEPH.ICS_ADDR_ID = ICS_ADDR.ICS_ADDR_ID
          WHERE ICS_SWMS_4_LARGE_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                                     FROM ICS_KEY_HASH);
         -- ----------------------------------
         -- /ICS_SWMS_4_LARGE_PRMT/ICS_CONTACT
         -- ----------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_SWMS_4_LARGE_PRMT/ICS_CONTACT';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_CONTACT.DATA_HASH
           FROM ICS_SWMS_4_LARGE_PRMT
           JOIN ICS_CONTACT
             ON ICS_CONTACT.ICS_SWMS_4_LARGE_PRMT_ID = ICS_SWMS_4_LARGE_PRMT.ICS_SWMS_4_LARGE_PRMT_ID
          WHERE ICS_SWMS_4_LARGE_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                                     FROM ICS_KEY_HASH);
         -- ---------------------------------------------
         -- /ICS_SWMS_4_LARGE_PRMT/ICS_CONTACT/ICS_TELEPH
         -- ---------------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_SWMS_4_LARGE_PRMT/ICS_CONTACT/ICS_TELEPH';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_TELEPH.DATA_HASH
           FROM ICS_SWMS_4_LARGE_PRMT
           JOIN ICS_CONTACT
             ON ICS_CONTACT.ICS_SWMS_4_LARGE_PRMT_ID = ICS_SWMS_4_LARGE_PRMT.ICS_SWMS_4_LARGE_PRMT_ID
           JOIN ICS_TELEPH
             ON ICS_TELEPH.ICS_CONTACT_ID = ICS_CONTACT.ICS_CONTACT_ID
          WHERE ICS_SWMS_4_LARGE_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                                     FROM ICS_KEY_HASH);
      END IF;
      -- =====================
      -- ICS_SWMS_4_SMALL_PRMT
      -- =====================
      IF v_table_name = 'ICS_SWMS_4_SMALL_PRMT' AND 
         v_enabled    = 'Y'                     THEN
         -- ----------------------
         -- /ICS_SWMS_4_SMALL_PRMT
         -- ----------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_SWMS_4_SMALL_PRMT';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_SWMS_4_SMALL_PRMT.DATA_HASH
           FROM ICS_SWMS_4_SMALL_PRMT
          WHERE ICS_SWMS_4_SMALL_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                                     FROM ICS_KEY_HASH);
         -- -------------------------------
         -- /ICS_SWMS_4_SMALL_PRMT/ICS_ADDR
         -- -------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_SWMS_4_SMALL_PRMT/ICS_ADDR';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_ADDR.DATA_HASH
           FROM ICS_SWMS_4_SMALL_PRMT
           JOIN ICS_ADDR
             ON ICS_ADDR.ICS_SWMS_4_SMALL_PRMT_ID = ICS_SWMS_4_SMALL_PRMT.ICS_SWMS_4_SMALL_PRMT_ID
          WHERE ICS_SWMS_4_SMALL_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                                     FROM ICS_KEY_HASH);
         -- ------------------------------------------
         -- /ICS_SWMS_4_SMALL_PRMT/ICS_ADDR/ICS_TELEPH
         -- ------------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_SWMS_4_SMALL_PRMT/ICS_ADDR/ICS_TELEPH';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_TELEPH.DATA_HASH
           FROM ICS_SWMS_4_SMALL_PRMT
           JOIN ICS_ADDR
             ON ICS_ADDR.ICS_SWMS_4_SMALL_PRMT_ID = ICS_SWMS_4_SMALL_PRMT.ICS_SWMS_4_SMALL_PRMT_ID
           JOIN ICS_TELEPH
             ON ICS_TELEPH.ICS_ADDR_ID = ICS_ADDR.ICS_ADDR_ID
          WHERE ICS_SWMS_4_SMALL_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                                     FROM ICS_KEY_HASH);
         -- ----------------------------------
         -- /ICS_SWMS_4_SMALL_PRMT/ICS_CONTACT
         -- ----------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_SWMS_4_SMALL_PRMT/ICS_CONTACT';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_CONTACT.DATA_HASH
           FROM ICS_SWMS_4_SMALL_PRMT
           JOIN ICS_CONTACT
             ON ICS_CONTACT.ICS_SWMS_4_SMALL_PRMT_ID = ICS_SWMS_4_SMALL_PRMT.ICS_SWMS_4_SMALL_PRMT_ID
          WHERE ICS_SWMS_4_SMALL_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                                     FROM ICS_KEY_HASH);
         -- ---------------------------------------------
         -- /ICS_SWMS_4_SMALL_PRMT/ICS_CONTACT/ICS_TELEPH
         -- ---------------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_SWMS_4_SMALL_PRMT/ICS_CONTACT/ICS_TELEPH';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_TELEPH.DATA_HASH
           FROM ICS_SWMS_4_SMALL_PRMT
           JOIN ICS_CONTACT
             ON ICS_CONTACT.ICS_SWMS_4_SMALL_PRMT_ID = ICS_SWMS_4_SMALL_PRMT.ICS_SWMS_4_SMALL_PRMT_ID
           JOIN ICS_TELEPH
             ON ICS_TELEPH.ICS_CONTACT_ID = ICS_CONTACT.ICS_CONTACT_ID
          WHERE ICS_SWMS_4_SMALL_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                                     FROM ICS_KEY_HASH);
         -- -------------------------------------------
         -- /ICS_SWMS_4_SMALL_PRMT/ICS_GPCF_CNST_WAIVER
         -- -------------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_SWMS_4_SMALL_PRMT/ICS_GPCF_CNST_WAIVER';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_GPCF_CNST_WAIVER.DATA_HASH
           FROM ICS_SWMS_4_SMALL_PRMT
           JOIN ICS_GPCF_CNST_WAIVER
             ON ICS_GPCF_CNST_WAIVER.ICS_SWMS_4_SMALL_PRMT_ID = ICS_SWMS_4_SMALL_PRMT.ICS_SWMS_4_SMALL_PRMT_ID
          WHERE ICS_SWMS_4_SMALL_PRMT.KEY_HASH IN (SELECT KEY_HASH 
                                                     FROM ICS_KEY_HASH);
      END IF;
      -- ==============
      -- ICS_UNPRMT_FAC
      -- ==============
      IF v_table_name = 'ICS_UNPRMT_FAC' AND 
         v_enabled    = 'Y'              THEN
         -- ---------------
         -- /ICS_UNPRMT_FAC
         -- ---------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_UNPRMT_FAC';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_UNPRMT_FAC.DATA_HASH
           FROM ICS_UNPRMT_FAC
          WHERE ICS_UNPRMT_FAC.KEY_HASH IN (SELECT KEY_HASH 
                                              FROM ICS_KEY_HASH);
         -- ------------------------
         -- /ICS_UNPRMT_FAC/ICS_ADDR
         -- ------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_UNPRMT_FAC/ICS_ADDR';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_ADDR.DATA_HASH
           FROM ICS_UNPRMT_FAC
           JOIN ICS_ADDR
             ON ICS_ADDR.ICS_UNPRMT_FAC_ID = ICS_UNPRMT_FAC.ICS_UNPRMT_FAC_ID
          WHERE ICS_UNPRMT_FAC.KEY_HASH IN (SELECT KEY_HASH 
                                              FROM ICS_KEY_HASH);
         -- -----------------------------------
         -- /ICS_UNPRMT_FAC/ICS_ADDR/ICS_TELEPH
         -- -----------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_UNPRMT_FAC/ICS_ADDR/ICS_TELEPH';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_TELEPH.DATA_HASH
           FROM ICS_UNPRMT_FAC
           JOIN ICS_ADDR
             ON ICS_ADDR.ICS_UNPRMT_FAC_ID = ICS_UNPRMT_FAC.ICS_UNPRMT_FAC_ID
           JOIN ICS_TELEPH
             ON ICS_TELEPH.ICS_ADDR_ID = ICS_ADDR.ICS_ADDR_ID
          WHERE ICS_UNPRMT_FAC.KEY_HASH IN (SELECT KEY_HASH 
                                              FROM ICS_KEY_HASH);
         -- ---------------------------
         -- /ICS_UNPRMT_FAC/ICS_CONTACT
         -- ---------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_UNPRMT_FAC/ICS_CONTACT';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_CONTACT.DATA_HASH
           FROM ICS_UNPRMT_FAC
           JOIN ICS_CONTACT
             ON ICS_CONTACT.ICS_UNPRMT_FAC_ID = ICS_UNPRMT_FAC.ICS_UNPRMT_FAC_ID
          WHERE ICS_UNPRMT_FAC.KEY_HASH IN (SELECT KEY_HASH 
                                              FROM ICS_KEY_HASH);
         -- --------------------------------------
         -- /ICS_UNPRMT_FAC/ICS_CONTACT/ICS_TELEPH
         -- --------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_UNPRMT_FAC/ICS_CONTACT/ICS_TELEPH';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_TELEPH.DATA_HASH
           FROM ICS_UNPRMT_FAC
           JOIN ICS_CONTACT
             ON ICS_CONTACT.ICS_UNPRMT_FAC_ID = ICS_UNPRMT_FAC.ICS_UNPRMT_FAC_ID
           JOIN ICS_TELEPH
             ON ICS_TELEPH.ICS_CONTACT_ID = ICS_CONTACT.ICS_CONTACT_ID
          WHERE ICS_UNPRMT_FAC.KEY_HASH IN (SELECT KEY_HASH 
                                              FROM ICS_KEY_HASH);
         -- -----------------------------
         -- /ICS_UNPRMT_FAC/ICS_FAC_CLASS
         -- -----------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_UNPRMT_FAC/ICS_FAC_CLASS';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_FAC_CLASS.DATA_HASH
           FROM ICS_UNPRMT_FAC
           JOIN ICS_FAC_CLASS
             ON ICS_FAC_CLASS.ICS_UNPRMT_FAC_ID = ICS_UNPRMT_FAC.ICS_UNPRMT_FAC_ID
          WHERE ICS_UNPRMT_FAC.KEY_HASH IN (SELECT KEY_HASH 
                                              FROM ICS_KEY_HASH);
         -- -----------------------------
         -- /ICS_UNPRMT_FAC/ICS_GEO_COORD
         -- -----------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_UNPRMT_FAC/ICS_GEO_COORD';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_GEO_COORD.DATA_HASH
           FROM ICS_UNPRMT_FAC
           JOIN ICS_GEO_COORD
             ON ICS_GEO_COORD.ICS_UNPRMT_FAC_ID = ICS_UNPRMT_FAC.ICS_UNPRMT_FAC_ID
          WHERE ICS_UNPRMT_FAC.KEY_HASH IN (SELECT KEY_HASH 
                                              FROM ICS_KEY_HASH);
         -- ------------------------------
         -- /ICS_UNPRMT_FAC/ICS_NAICS_CODE
         -- ------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_UNPRMT_FAC/ICS_NAICS_CODE';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_NAICS_CODE.DATA_HASH
           FROM ICS_UNPRMT_FAC
           JOIN ICS_NAICS_CODE
             ON ICS_NAICS_CODE.ICS_UNPRMT_FAC_ID = ICS_UNPRMT_FAC.ICS_UNPRMT_FAC_ID
          WHERE ICS_UNPRMT_FAC.KEY_HASH IN (SELECT KEY_HASH 
                                              FROM ICS_KEY_HASH);
         -- ------------------------------
         -- /ICS_UNPRMT_FAC/ICS_ORIG_PROGS
         -- ------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_UNPRMT_FAC/ICS_ORIG_PROGS';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_ORIG_PROGS.DATA_HASH
           FROM ICS_UNPRMT_FAC
           JOIN ICS_ORIG_PROGS
             ON ICS_ORIG_PROGS.ICS_UNPRMT_FAC_ID = ICS_UNPRMT_FAC.ICS_UNPRMT_FAC_ID
          WHERE ICS_UNPRMT_FAC.KEY_HASH IN (SELECT KEY_HASH 
                                              FROM ICS_KEY_HASH);
         -- ------------------
         -- /ICS_UNPRMT_FAC/ICS_PLCY
         -- ------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_UNPRMT_FAC/ICS_PLCY';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_PLCY.DATA_HASH
           FROM ICS_UNPRMT_FAC
           JOIN ICS_PLCY
             ON ICS_PLCY.ICS_UNPRMT_FAC_ID = ICS_UNPRMT_FAC.ICS_UNPRMT_FAC_ID
          WHERE ICS_UNPRMT_FAC.KEY_HASH IN (SELECT KEY_HASH 
                                              FROM ICS_KEY_HASH);
         -- ----------------------------
         -- /ICS_UNPRMT_FAC/ICS_SIC_CODE
         -- ----------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_UNPRMT_FAC/ICS_SIC_CODE';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_SIC_CODE.DATA_HASH
           FROM ICS_UNPRMT_FAC
           JOIN ICS_SIC_CODE
             ON ICS_SIC_CODE.ICS_UNPRMT_FAC_ID = ICS_UNPRMT_FAC.ICS_UNPRMT_FAC_ID
          WHERE ICS_UNPRMT_FAC.KEY_HASH IN (SELECT KEY_HASH 
                                              FROM ICS_KEY_HASH);
      END IF;
      -- =======================
      -- ICS_HIST_PRMT_SCHD_EVTS
      -- =======================
      IF v_table_name = 'ICS_HIST_PRMT_SCHD_EVTS' AND 
         v_enabled    = 'Y'                       THEN
         --
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_HIST_PRMT_SCHD_EVTS';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_HIST_PRMT_SCHD_EVTS.DATA_HASH
           FROM ICS_HIST_PRMT_SCHD_EVTS
          WHERE ICS_HIST_PRMT_SCHD_EVTS.KEY_HASH IN (SELECT KEY_HASH 
                                                       FROM ICS_KEY_HASH);

      END IF;
      -- ==================
      -- ICS_NARR_COND_SCHD
      -- ==================
      IF v_table_name = 'ICS_NARR_COND_SCHD' AND 
         v_enabled    = 'Y'                  THEN
         -- ------------------
         -- /ICS_NARR_COND_SCHD
         -- ------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_NARR_COND_SCHD';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_NARR_COND_SCHD.DATA_HASH
           FROM ICS_NARR_COND_SCHD
          WHERE ICS_NARR_COND_SCHD.KEY_HASH IN (SELECT KEY_HASH 
                                                  FROM ICS_KEY_HASH);
         -- -------------------------------------
         -- /ICS_NARR_COND_SCHD/ICS_PRMT_SCHD_EVT
         -- -------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_NARR_COND_SCHD/ICS_PRMT_SCHD_EVT';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_PRMT_SCHD_EVT.DATA_HASH
           FROM ICS_NARR_COND_SCHD
           JOIN ICS_PRMT_SCHD_EVT
             ON ICS_PRMT_SCHD_EVT.ICS_NARR_COND_SCHD_ID = ICS_NARR_COND_SCHD.ICS_NARR_COND_SCHD_ID
          WHERE ICS_NARR_COND_SCHD.KEY_HASH IN (SELECT KEY_HASH 
                                                  FROM ICS_KEY_HASH);
      END IF;
      -- ==============
      -- ICS_PRMT_FEATR
      -- ==============
      IF v_table_name = 'ICS_PRMT_FEATR' AND 
         v_enabled    = 'Y'              THEN
         -- ---------------
         -- /ICS_PRMT_FEATR
         -- ---------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_PRMT_FEATR';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_PRMT_FEATR.DATA_HASH
           FROM ICS_PRMT_FEATR
          WHERE ICS_PRMT_FEATR.KEY_HASH IN (SELECT KEY_HASH 
                                              FROM ICS_KEY_HASH);
         -- ------------------
         -- /ICS_PRMT_FEATR/ICS_ADDR
         -- ------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_PRMT_FEATR/ICS_ADDR';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_ADDR.DATA_HASH
           FROM ICS_PRMT_FEATR
           JOIN ICS_ADDR
             ON ICS_ADDR.ICS_PRMT_FEATR_ID = ICS_PRMT_FEATR.ICS_PRMT_FEATR_ID
          WHERE ICS_PRMT_FEATR.KEY_HASH IN (SELECT KEY_HASH 
                                              FROM ICS_KEY_HASH);
         -- -----------------------------------
         -- /ICS_PRMT_FEATR/ICS_ADDR/ICS_TELEPH
         -- -----------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_PRMT_FEATR/ICS_ADDR/ICS_TELEPH';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_TELEPH.DATA_HASH
           FROM ICS_PRMT_FEATR
           JOIN ICS_ADDR
             ON ICS_ADDR.ICS_PRMT_FEATR_ID = ICS_PRMT_FEATR.ICS_PRMT_FEATR_ID
           JOIN ICS_TELEPH
             ON ICS_TELEPH.ICS_ADDR_ID = ICS_ADDR.ICS_ADDR_ID
          WHERE ICS_PRMT_FEATR.KEY_HASH IN (SELECT KEY_HASH 
                                              FROM ICS_KEY_HASH);
         -- ---------------------------
         -- /ICS_PRMT_FEATR/ICS_CONTACT
         -- ---------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_PRMT_FEATR/ICS_CONTACT';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_CONTACT.DATA_HASH
           FROM ICS_PRMT_FEATR
           JOIN ICS_CONTACT
             ON ICS_CONTACT.ICS_PRMT_FEATR_ID = ICS_PRMT_FEATR.ICS_PRMT_FEATR_ID
          WHERE ICS_PRMT_FEATR.KEY_HASH IN (SELECT KEY_HASH 
                                              FROM ICS_KEY_HASH);
         -- --------------------------------------
         -- /ICS_PRMT_FEATR/ICS_CONTACT/ICS_TELEPH
         -- --------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_PRMT_FEATR/ICS_CONTACT/ICS_TELEPH';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_TELEPH.DATA_HASH
           FROM ICS_PRMT_FEATR
           JOIN ICS_CONTACT
             ON ICS_CONTACT.ICS_PRMT_FEATR_ID = ICS_PRMT_FEATR.ICS_PRMT_FEATR_ID
           JOIN ICS_TELEPH
             ON ICS_TELEPH.ICS_CONTACT_ID = ICS_CONTACT.ICS_CONTACT_ID
          WHERE ICS_PRMT_FEATR.KEY_HASH IN (SELECT KEY_HASH 
                                              FROM ICS_KEY_HASH);
         -- -----------------------------
         -- /ICS_PRMT_FEATR/ICS_GEO_COORD
         -- -----------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_PRMT_FEATR/ICS_GEO_COORD';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_GEO_COORD.DATA_HASH
           FROM ICS_PRMT_FEATR
           JOIN ICS_GEO_COORD
             ON ICS_GEO_COORD.ICS_PRMT_FEATR_ID = ICS_PRMT_FEATR.ICS_PRMT_FEATR_ID
          WHERE ICS_PRMT_FEATR.KEY_HASH IN (SELECT KEY_HASH 
                                              FROM ICS_KEY_HASH);
         -- -----------------------------------
         -- /ICS_PRMT_FEATR/ICS_PRMT_FEATR_CHAR
         -- -----------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_PRMT_FEATR/ICS_PRMT_FEATR_CHAR';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_PRMT_FEATR_CHAR.DATA_HASH
           FROM ICS_PRMT_FEATR
           JOIN ICS_PRMT_FEATR_CHAR
             ON ICS_PRMT_FEATR_CHAR.ICS_PRMT_FEATR_ID = ICS_PRMT_FEATR.ICS_PRMT_FEATR_ID
          WHERE ICS_PRMT_FEATR.KEY_HASH IN (SELECT KEY_HASH 
                                              FROM ICS_KEY_HASH);
         -- ------------------------------------------
         -- /ICS_PRMT_FEATR/ICS_PRMT_FEATR_TRTMNT_TYPE
         -- ------------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_PRMT_FEATR/ICS_PRMT_FEATR_TRTMNT_TYPE';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_PRMT_FEATR_TRTMNT_TYPE.DATA_HASH
           FROM ICS_PRMT_FEATR
           JOIN ICS_PRMT_FEATR_TRTMNT_TYPE
             ON ICS_PRMT_FEATR_TRTMNT_TYPE.ICS_PRMT_FEATR_ID = ICS_PRMT_FEATR.ICS_PRMT_FEATR_ID
          WHERE ICS_PRMT_FEATR.KEY_HASH IN (SELECT KEY_HASH 
                                              FROM ICS_KEY_HASH);
      END IF;
      -- ===========
      -- ICS_LMT_SET
      -- ===========
      IF v_table_name = 'ICS_LMT_SET' AND 
         v_enabled    = 'Y'           THEN
         -- ------------
         -- /ICS_LMT_SET
         -- ------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_LMT_SET';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_LMT_SET.DATA_HASH
           FROM ICS_LMT_SET
          WHERE ICS_LMT_SET.KEY_HASH IN (SELECT KEY_HASH 
                                           FROM ICS_KEY_HASH);
         -- ------------------------------------
         -- /ICS_LMT_SET/ICS_LMT_SET_MONTHS_APPL
         -- ------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_LMT_SET/ICS_LMT_SET_MONTHS_APPL';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_LMT_SET_MONTHS_APPL.DATA_HASH
           FROM ICS_LMT_SET
           JOIN ICS_LMT_SET_MONTHS_APPL
             ON ICS_LMT_SET_MONTHS_APPL.ICS_LMT_SET_ID = ICS_LMT_SET.ICS_LMT_SET_ID
          WHERE ICS_LMT_SET.KEY_HASH IN (SELECT KEY_HASH 
                                           FROM ICS_KEY_HASH);
         -- -----------------------------
         -- /ICS_LMT_SET/ICS_LMT_SET_SCHD
         -- -----------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_LMT_SET/ICS_LMT_SET_SCHD';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_LMT_SET_SCHD.DATA_HASH
           FROM ICS_LMT_SET
           JOIN ICS_LMT_SET_SCHD
             ON ICS_LMT_SET_SCHD.ICS_LMT_SET_ID = ICS_LMT_SET.ICS_LMT_SET_ID
          WHERE ICS_LMT_SET.KEY_HASH IN (SELECT KEY_HASH 
                                           FROM ICS_KEY_HASH);
         -- -----------------------------
         -- /ICS_LMT_SET/ICS_LMT_SET_STAT
         -- -----------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_LMT_SET/ICS_LMT_SET_STAT';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_LMT_SET_STAT.DATA_HASH
           FROM ICS_LMT_SET
           JOIN ICS_LMT_SET_STAT
             ON ICS_LMT_SET_STAT.ICS_LMT_SET_ID = ICS_LMT_SET.ICS_LMT_SET_ID
          WHERE ICS_LMT_SET.KEY_HASH IN (SELECT KEY_HASH 
                                           FROM ICS_KEY_HASH);
      END IF;
      -- ========
      -- ICS_LMTS
      -- ========
      IF v_table_name = 'ICS_LMTS' AND 
         v_enabled    = 'Y'        THEN
         -- ---------
         -- /ICS_LMTS
         -- ---------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_LMTS';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_LMTS.DATA_HASH
           FROM ICS_LMTS
          WHERE ICS_LMTS.KEY_HASH IN (SELECT KEY_HASH 
                                                FROM ICS_KEY_HASH);
         -- ----------------------------
         -- /ICS_LMTS/ICS_MN_LMT_APPLIES
         -- ----------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_LMTS/ICS_MN_LMT_APPLIES';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_MN_LMT_APPLIES.DATA_HASH
           FROM ICS_LMTS
           JOIN ICS_MN_LMT_APPLIES
             ON ICS_MN_LMT_APPLIES.ICS_LMTS_ID = ICS_LMTS.ICS_LMTS_ID
          WHERE ICS_LMTS.KEY_HASH IN (SELECT KEY_HASH 
                                        FROM ICS_KEY_HASH);
         -- ----------------------
         -- /ICS_LMTS/ICS_NUM_COND
         -- ----------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_LMTS/ICS_NUM_COND';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_NUM_COND.DATA_HASH
           FROM ICS_LMTS
           JOIN ICS_NUM_COND
             ON ICS_NUM_COND.ICS_LMTS_ID = ICS_LMTS.ICS_LMTS_ID
          WHERE ICS_LMTS.KEY_HASH IN (SELECT KEY_HASH 
                                        FROM ICS_KEY_HASH);
      END IF;
      -- ==============
      -- ICS_PARAM_LMTS
      -- ==============
      IF v_table_name = 'ICS_PARAM_LMTS' AND 
         v_enabled    = 'Y'              THEN
         -- ---------------
         -- /ICS_PARAM_LMTS
         -- ---------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_PARAM_LMTS';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_PARAM_LMTS.DATA_HASH
           FROM ICS_PARAM_LMTS
          WHERE ICS_PARAM_LMTS.KEY_HASH IN (SELECT KEY_HASH 
                                              FROM ICS_KEY_HASH);
         -- -----------------------
         -- /ICS_PARAM_LMTS/ICS_LMT
         -- -----------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_PARAM_LMTS/ICS_LMT';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_LMT.DATA_HASH
           FROM ICS_PARAM_LMTS
           JOIN ICS_LMT
             ON ICS_LMT.ICS_PARAM_LMTS_ID = ICS_PARAM_LMTS.ICS_PARAM_LMTS_ID
          WHERE ICS_PARAM_LMTS.KEY_HASH IN (SELECT KEY_HASH 
                                              FROM ICS_KEY_HASH);
         -- ------------------------------------------
         -- /ICS_PARAM_LMTS/ICS_LMT/ICS_MN_LMT_APPLIES
         -- ------------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_PARAM_LMTS/ICS_LMT/ICS_MN_LMT_APPLIES';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_MN_LMT_APPLIES.DATA_HASH
           FROM ICS_PARAM_LMTS
           JOIN ICS_LMT
             ON ICS_LMT.ICS_PARAM_LMTS_ID = ICS_PARAM_LMTS.ICS_PARAM_LMTS_ID
           JOIN ICS_MN_LMT_APPLIES
             ON ICS_MN_LMT_APPLIES.ICS_LMT_ID = ICS_LMT.ICS_LMT_ID
          WHERE ICS_PARAM_LMTS.KEY_HASH IN (SELECT KEY_HASH 
                                              FROM ICS_KEY_HASH);
         -- ------------------------------------
         -- /ICS_PARAM_LMTS/ICS_LMT/ICS_NUM_COND
         -- ------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_PARAM_LMTS/ICS_LMT/ICS_NUM_COND';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_NUM_COND.DATA_HASH
           FROM ICS_PARAM_LMTS
           JOIN ICS_LMT
             ON ICS_LMT.ICS_PARAM_LMTS_ID = ICS_PARAM_LMTS.ICS_PARAM_LMTS_ID
           JOIN ICS_NUM_COND
             ON ICS_NUM_COND.ICS_LMT_ID = ICS_LMT.ICS_LMT_ID
          WHERE ICS_PARAM_LMTS.KEY_HASH IN (SELECT KEY_HASH 
                                              FROM ICS_KEY_HASH);
      END IF;
      -- ================
      -- ICS_DSCH_MON_REP
      -- ================
      IF v_table_name = 'ICS_DSCH_MON_REP' AND 
         v_enabled    = 'Y'                THEN
         -- -----------------
         -- /ICS_DSCH_MON_REP
         -- -----------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_DSCH_MON_REP';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_DSCH_MON_REP.DATA_HASH
           FROM ICS_DSCH_MON_REP
          WHERE ICS_DSCH_MON_REP.KEY_HASH IN (SELECT KEY_HASH 
                                                FROM ICS_KEY_HASH);
         -- ----------------------------------
         -- /ICS_DSCH_MON_REP/ICS_CO_DSPL_SITE
         -- ----------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_DSCH_MON_REP/ICS_CO_DSPL_SITE';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_CO_DSPL_SITE.DATA_HASH
           FROM ICS_DSCH_MON_REP
           JOIN ICS_CO_DSPL_SITE
             ON ICS_CO_DSPL_SITE.ICS_DSCH_MON_REP_ID = ICS_DSCH_MON_REP.ICS_DSCH_MON_REP_ID
          WHERE ICS_DSCH_MON_REP.KEY_HASH IN (SELECT KEY_HASH 
                                                FROM ICS_KEY_HASH);
         -- ---------------------------
         -- /ICS_DSCH_MON_REP/ICS_INCIN
         -- ---------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_DSCH_MON_REP/ICS_INCIN';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_INCIN.DATA_HASH
           FROM ICS_DSCH_MON_REP
           JOIN ICS_INCIN
             ON ICS_INCIN.ICS_DSCH_MON_REP_ID = ICS_DSCH_MON_REP.ICS_DSCH_MON_REP_ID
          WHERE ICS_DSCH_MON_REP.KEY_HASH IN (SELECT KEY_HASH 
                                                FROM ICS_KEY_HASH);
         -- ------------------------------------
         -- /ICS_DSCH_MON_REP/ICS_LAND_APPL_SITE
         -- ------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_DSCH_MON_REP/ICS_LAND_APPL_SITE';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_LAND_APPL_SITE.DATA_HASH
           FROM ICS_DSCH_MON_REP
           JOIN ICS_LAND_APPL_SITE
             ON ICS_LAND_APPL_SITE.ICS_DSCH_MON_REP_ID = ICS_DSCH_MON_REP.ICS_DSCH_MON_REP_ID
          WHERE ICS_DSCH_MON_REP.KEY_HASH IN (SELECT KEY_HASH 
                                                FROM ICS_KEY_HASH);
         -- -------------------------------------------------------------
         -- /ICS_DSCH_MON_REP/ICS_LAND_APPL_SITE/ICS_CROP_TYPES_HARVESTED
         -- -------------------------------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_DSCH_MON_REP/ICS_LAND_APPL_SITE/ICS_CROP_TYPES_HARVESTED';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_CROP_TYPES_HARVESTED.DATA_HASH
           FROM ICS_DSCH_MON_REP
           JOIN ICS_LAND_APPL_SITE
             ON ICS_LAND_APPL_SITE.ICS_DSCH_MON_REP_ID = ICS_DSCH_MON_REP.ICS_DSCH_MON_REP_ID
           JOIN ICS_CROP_TYPES_HARVESTED
             ON ICS_CROP_TYPES_HARVESTED.ICS_LAND_APPL_SITE_ID = ICS_LAND_APPL_SITE.ICS_LAND_APPL_SITE_ID
          WHERE ICS_DSCH_MON_REP.KEY_HASH IN (SELECT KEY_HASH 
                                                FROM ICS_KEY_HASH);
         -- -----------------------------------------------------------
         -- /ICS_DSCH_MON_REP/ICS_LAND_APPL_SITE/ICS_CROP_TYPES_PLANTED
         -- -----------------------------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_DSCH_MON_REP/ICS_LAND_APPL_SITE/ICS_CROP_TYPES_PLANTED';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_CROP_TYPES_PLANTED.DATA_HASH
           FROM ICS_DSCH_MON_REP
           JOIN ICS_LAND_APPL_SITE
             ON ICS_LAND_APPL_SITE.ICS_DSCH_MON_REP_ID = ICS_DSCH_MON_REP.ICS_DSCH_MON_REP_ID
           JOIN ICS_CROP_TYPES_PLANTED
             ON ICS_CROP_TYPES_PLANTED.ICS_LAND_APPL_SITE_ID = ICS_LAND_APPL_SITE.ICS_LAND_APPL_SITE_ID
          WHERE ICS_DSCH_MON_REP.KEY_HASH IN (SELECT KEY_HASH 
                                                FROM ICS_KEY_HASH);
         -- -------------------------------
         -- /ICS_DSCH_MON_REP/ICS_REP_PARAM
         -- --------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_DSCH_MON_REP/ICS_REP_PARAM';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_REP_PARAM.DATA_HASH
           FROM ICS_DSCH_MON_REP
           JOIN ICS_REP_PARAM
             ON ICS_REP_PARAM.ICS_DSCH_MON_REP_ID = ICS_DSCH_MON_REP.ICS_DSCH_MON_REP_ID
          WHERE ICS_DSCH_MON_REP.KEY_HASH IN (SELECT KEY_HASH 
                                                FROM ICS_KEY_HASH);
         -- -------------------------------------------
         -- /ICS_DSCH_MON_REP/ICS_REP_PARAM/ICS_NUM_REP
         -- -------------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_DSCH_MON_REP/ICS_REP_PARAM/ICS_NUM_REP';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_NUM_REP.DATA_HASH
           FROM ICS_DSCH_MON_REP
           JOIN ICS_REP_PARAM
             ON ICS_REP_PARAM.ICS_DSCH_MON_REP_ID = ICS_DSCH_MON_REP.ICS_DSCH_MON_REP_ID
           JOIN ICS_NUM_REP
             ON ICS_NUM_REP.ICS_REP_PARAM_ID = ICS_REP_PARAM.ICS_REP_PARAM_ID
          WHERE ICS_DSCH_MON_REP.KEY_HASH IN (SELECT KEY_HASH 
                                                FROM ICS_KEY_HASH);
         -- ------------------------------------
         -- /ICS_DSCH_MON_REP/ICS_SURF_DSPL_SITE
         -- ------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_DSCH_MON_REP/ICS_SURF_DSPL_SITE';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_SURF_DSPL_SITE.DATA_HASH
           FROM ICS_DSCH_MON_REP
           JOIN ICS_SURF_DSPL_SITE
             ON ICS_SURF_DSPL_SITE.ICS_DSCH_MON_REP_ID = ICS_DSCH_MON_REP.ICS_DSCH_MON_REP_ID
          WHERE ICS_DSCH_MON_REP.KEY_HASH IN (SELECT KEY_HASH 
                                                FROM ICS_KEY_HASH);
      END IF;
      -- =================
      -- ICS_SNGL_EVT_VIOL
      -- =================
      IF v_table_name = 'ICS_SNGL_EVT_VIOL' AND 
         v_enabled    = 'Y'                 THEN
         --
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_SNGL_EVT_VIOL';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_SNGL_EVT_VIOL.DATA_HASH
           FROM ICS_SNGL_EVT_VIOL
          WHERE ICS_SNGL_EVT_VIOL.KEY_HASH IN (SELECT KEY_HASH 
                                                 FROM ICS_KEY_HASH);
      END IF;
      -- =============
      -- ICS_CMPL_SCHD
      -- =============
      IF v_table_name = 'ICS_CMPL_SCHD' AND 
         v_enabled    = 'Y'             THEN
         -- --------------
         -- /ICS_CMPL_SCHD
         -- --------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CMPL_SCHD';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_CMPL_SCHD.DATA_HASH
           FROM ICS_CMPL_SCHD
          WHERE ICS_CMPL_SCHD.KEY_HASH IN (SELECT KEY_HASH 
                                             FROM ICS_KEY_HASH);
         -- --------------------------------
         -- /ICS_CMPL_SCHD/ICS_CMPL_SCHD_EVT
         -- --------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CMPL_SCHD/ICS_CMPL_SCHD_EVT';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_CMPL_SCHD_EVT.DATA_HASH
           FROM ICS_CMPL_SCHD
           JOIN ICS_CMPL_SCHD_EVT
             ON ICS_CMPL_SCHD_EVT.ICS_CMPL_SCHD_ID = ICS_CMPL_SCHD.ICS_CMPL_SCHD_ID
          WHERE ICS_CMPL_SCHD.KEY_HASH IN (SELECT KEY_HASH 
                                             FROM ICS_KEY_HASH);
      END IF;
      -- ============
      -- ICS_DMR_VIOL
      -- ============
      IF v_table_name = 'ICS_DMR_VIOL' AND v_enabled = 'Y' THEN
         --
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_DMR_VIOL';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_DMR_VIOL.DATA_HASH
           FROM ICS_DMR_VIOL
          WHERE ICS_DMR_VIOL.KEY_HASH  IN (SELECT KEY_HASH 
                                             FROM ICS_KEY_HASH);
      END IF;
      -- ======================
      -- ICS_EFFLU_TRADE_PRTNER
      -- ======================
      IF v_table_name = 'ICS_EFFLU_TRADE_PRTNER' AND 
         v_enabled    = 'Y'                      THEN
         -- -----------------------
         -- /ICS_EFFLU_TRADE_PRTNER
         -- -----------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_EFFLU_TRADE_PRTNER';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_EFFLU_TRADE_PRTNER.DATA_HASH
           FROM ICS_EFFLU_TRADE_PRTNER
          WHERE ICS_EFFLU_TRADE_PRTNER.KEY_HASH IN (SELECT KEY_HASH 
                                                      FROM ICS_KEY_HASH);
         -- ---------------------------------------------------
         -- /ICS_EFFLU_TRADE_PRTNER/ICS_EFFLU_TRADE_PRTNER_ADDR
         -- ---------------------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_SW_INDST_PRMT';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_EFFLU_TRADE_PRTNER_ADDR.DATA_HASH
           FROM ICS_EFFLU_TRADE_PRTNER
           JOIN ICS_EFFLU_TRADE_PRTNER_ADDR
             ON ICS_EFFLU_TRADE_PRTNER_ADDR.ICS_EFFLU_TRADE_PRTNER_ID = ICS_EFFLU_TRADE_PRTNER.ICS_EFFLU_TRADE_PRTNER_ID
          WHERE ICS_EFFLU_TRADE_PRTNER.KEY_HASH IN (SELECT KEY_HASH 
                                                      FROM ICS_KEY_HASH);
         -- --------------------------------------------------------------
         -- /ICS_EFFLU_TRADE_PRTNER/ICS_EFFLU_TRADE_PRTNER_ADDR/ICS_TELEPH
         -- --------------------------------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_EFFLU_TRADE_PRTNER/ICS_EFFLU_TRADE_PRTNER_ADDR/ICS_TELEPH';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_TELEPH.DATA_HASH
           FROM ICS_EFFLU_TRADE_PRTNER
           JOIN ICS_EFFLU_TRADE_PRTNER_ADDR
             ON ICS_EFFLU_TRADE_PRTNER_ADDR.ICS_EFFLU_TRADE_PRTNER_ID = ICS_EFFLU_TRADE_PRTNER.ICS_EFFLU_TRADE_PRTNER_ID
           JOIN ICS_TELEPH
             ON ICS_TELEPH.ICS_EFFLU_TRADE_PRTNER_ADDR_ID = ICS_EFFLU_TRADE_PRTNER_ADDR.ICS_EFFLU_TRADE_PRTNER_ADDR_ID
          WHERE ICS_EFFLU_TRADE_PRTNER.KEY_HASH IN (SELECT KEY_HASH 
                                                      FROM ICS_KEY_HASH);
      END IF;
      -- ===================
      -- ICS_FRML_ENFRC_ACTN
      -- ===================
      IF v_table_name = 'ICS_FRML_ENFRC_ACTN' AND 
         v_enabled    = 'Y'                   THEN
         -- --------------------
         -- /ICS_FRML_ENFRC_ACTN
         -- --------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_FRML_ENFRC_ACTN';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_FRML_ENFRC_ACTN.DATA_HASH
           FROM ICS_FRML_ENFRC_ACTN
          WHERE ICS_FRML_ENFRC_ACTN.KEY_HASH IN (SELECT KEY_HASH 
                                                   FROM ICS_KEY_HASH);
         -- -----------------------------------------------
         -- /ICS_FRML_ENFRC_ACTN/ICS_ENFRC_ACTN_GOV_CONTACT
         -- -----------------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_FRML_ENFRC_ACTN/ICS_ENFRC_ACTN_GOV_CONTACT';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_ENFRC_ACTN_GOV_CONTACT.DATA_HASH
           FROM ICS_FRML_ENFRC_ACTN
           JOIN ICS_ENFRC_ACTN_GOV_CONTACT
             ON ICS_ENFRC_ACTN_GOV_CONTACT.ICS_FRML_ENFRC_ACTN_ID = ICS_FRML_ENFRC_ACTN.ICS_FRML_ENFRC_ACTN_ID
          WHERE ICS_FRML_ENFRC_ACTN.KEY_HASH IN (SELECT KEY_HASH 
                                                   FROM ICS_KEY_HASH);
         -- ----------------------------------------
         -- /ICS_FRML_ENFRC_ACTN/ICS_ENFRC_ACTN_TYPE
         -- ----------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_FRML_ENFRC_ACTN/ICS_ENFRC_ACTN_TYPE';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_ENFRC_ACTN_TYPE.DATA_HASH
           FROM ICS_FRML_ENFRC_ACTN
           JOIN ICS_ENFRC_ACTN_TYPE
             ON ICS_ENFRC_ACTN_TYPE.ICS_FRML_ENFRC_ACTN_ID = ICS_FRML_ENFRC_ACTN.ICS_FRML_ENFRC_ACTN_ID
          WHERE ICS_FRML_ENFRC_ACTN.KEY_HASH IN (SELECT KEY_HASH 
                                                   FROM ICS_KEY_HASH);
         -- ------------------------------------
         -- /ICS_FRML_ENFRC_ACTN/ICS_ENFRC_AGNCY
         -- ------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_FRML_ENFRC_ACTN/ICS_ENFRC_AGNCY';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_ENFRC_AGNCY.DATA_HASH
           FROM ICS_FRML_ENFRC_ACTN
           JOIN ICS_ENFRC_AGNCY
             ON ICS_ENFRC_AGNCY.ICS_FRML_ENFRC_ACTN_ID = ICS_FRML_ENFRC_ACTN.ICS_FRML_ENFRC_ACTN_ID
          WHERE ICS_FRML_ENFRC_ACTN.KEY_HASH IN (SELECT KEY_HASH 
                                                   FROM ICS_KEY_HASH);
         -- ------------------------------------
         -- /ICS_FRML_ENFRC_ACTN/ICS_FINAL_ORDER
         -- -------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_FRML_ENFRC_ACTN/ICS_FINAL_ORDER';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_FINAL_ORDER.DATA_HASH
           FROM ICS_FRML_ENFRC_ACTN
           JOIN ICS_FINAL_ORDER
             ON ICS_FINAL_ORDER.ICS_FRML_ENFRC_ACTN_ID = ICS_FRML_ENFRC_ACTN.ICS_FRML_ENFRC_ACTN_ID
          WHERE ICS_FRML_ENFRC_ACTN.KEY_HASH IN (SELECT KEY_HASH 
                                                   FROM ICS_KEY_HASH);
         -- ---------------------------------------------------------------
         -- /ICS_FRML_ENFRC_ACTN/ICS_FINAL_ORDER/ICS_FINAL_ORDER_PRMT_IDENT
         -- ---------------------------------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_FRML_ENFRC_ACTN/ICS_FINAL_ORDER/ICS_FINAL_ORDER_PRMT_IDENT';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_FINAL_ORDER_PRMT_IDENT.DATA_HASH
           FROM ICS_FRML_ENFRC_ACTN
           JOIN ICS_FINAL_ORDER
             ON ICS_FINAL_ORDER.ICS_FRML_ENFRC_ACTN_ID = ICS_FRML_ENFRC_ACTN.ICS_FRML_ENFRC_ACTN_ID
           JOIN ICS_FINAL_ORDER_PRMT_IDENT
             ON ICS_FINAL_ORDER_PRMT_IDENT.ICS_FINAL_ORDER_ID = ICS_FINAL_ORDER.ICS_FINAL_ORDER_ID
          WHERE ICS_FRML_ENFRC_ACTN.KEY_HASH IN (SELECT KEY_HASH 
                                                   FROM ICS_KEY_HASH);
         -- -----------------------------------
         -- /ICS_FRML_ENFRC_ACTN/ICS_PRMT_IDENT
         -- -----------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_FRML_ENFRC_ACTN/ICS_PRMT_IDENT';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_PRMT_IDENT.DATA_HASH
           FROM ICS_FRML_ENFRC_ACTN
           JOIN ICS_PRMT_IDENT
             ON ICS_PRMT_IDENT.ICS_FRML_ENFRC_ACTN_ID = ICS_FRML_ENFRC_ACTN.ICS_FRML_ENFRC_ACTN_ID
          WHERE ICS_FRML_ENFRC_ACTN.KEY_HASH IN (SELECT KEY_HASH 
                                                   FROM ICS_KEY_HASH);
         -- -----------------------------------
         -- /ICS_FRML_ENFRC_ACTN/ICS_PROGS_VIOL
         -- -----------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_FRML_ENFRC_ACTN/ICS_PROGS_VIOL';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_PROGS_VIOL.DATA_HASH
           FROM ICS_FRML_ENFRC_ACTN
           JOIN ICS_PROGS_VIOL
             ON ICS_PROGS_VIOL.ICS_FRML_ENFRC_ACTN_ID = ICS_FRML_ENFRC_ACTN.ICS_FRML_ENFRC_ACTN_ID
          WHERE ICS_FRML_ENFRC_ACTN.KEY_HASH IN (SELECT KEY_HASH 
                                                   FROM ICS_KEY_HASH);
      END IF;
      -- =====================
      -- ICS_INFRML_ENFRC_ACTN
      -- =====================
      IF v_table_name = 'ICS_INFRML_ENFRC_ACTN' AND 
         v_enabled    = 'Y'                     THEN
         -- ----------------------
         -- /ICS_INFRML_ENFRC_ACTN
         -- ----------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_INFRML_ENFRC_ACTN';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_INFRML_ENFRC_ACTN.DATA_HASH
           FROM ICS_INFRML_ENFRC_ACTN
          WHERE ICS_INFRML_ENFRC_ACTN.KEY_HASH IN (SELECT KEY_HASH 
                                                     FROM ICS_KEY_HASH);
         -- -------------------------------------------------
         -- /ICS_INFRML_ENFRC_ACTN/ICS_ENFRC_ACTN_GOV_CONTACT
         -- -------------------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_INFRML_ENFRC_ACTN/ICS_ENFRC_ACTN_GOV_CONTACT';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_ENFRC_ACTN_GOV_CONTACT.DATA_HASH
           FROM ICS_INFRML_ENFRC_ACTN
           JOIN ICS_ENFRC_ACTN_GOV_CONTACT
             ON ICS_ENFRC_ACTN_GOV_CONTACT.ICS_INFRML_ENFRC_ACTN_ID = ICS_INFRML_ENFRC_ACTN.ICS_INFRML_ENFRC_ACTN_ID
          WHERE ICS_INFRML_ENFRC_ACTN.KEY_HASH IN (SELECT KEY_HASH 
                                                     FROM ICS_KEY_HASH);
         -- --------------------------------------
         -- /ICS_INFRML_ENFRC_ACTN/ICS_ENFRC_AGNCY
         -- --------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_INFRML_ENFRC_ACTN/ICS_ENFRC_AGNCY';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_ENFRC_AGNCY.DATA_HASH
           FROM ICS_INFRML_ENFRC_ACTN
           JOIN ICS_ENFRC_AGNCY
             ON ICS_ENFRC_AGNCY.ICS_INFRML_ENFRC_ACTN_ID = ICS_INFRML_ENFRC_ACTN.ICS_INFRML_ENFRC_ACTN_ID
          WHERE ICS_INFRML_ENFRC_ACTN.KEY_HASH IN (SELECT KEY_HASH 
                                                    FROM ICS_KEY_HASH);
         -- -------------------------------------
         -- /ICS_INFRML_ENFRC_ACTN/ICS_PRMT_IDENT
         -- -------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_INFRML_ENFRC_ACTN/ICS_PRMT_IDENT';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_PRMT_IDENT.DATA_HASH
           FROM ICS_INFRML_ENFRC_ACTN
           JOIN ICS_PRMT_IDENT
             ON ICS_PRMT_IDENT.ICS_INFRML_ENFRC_ACTN_ID = ICS_INFRML_ENFRC_ACTN.ICS_INFRML_ENFRC_ACTN_ID
          WHERE ICS_INFRML_ENFRC_ACTN.KEY_HASH IN (SELECT KEY_HASH 
                                                     FROM ICS_KEY_HASH);
         -- -------------------------------------
         -- /ICS_INFRML_ENFRC_ACTN/ICS_PROGS_VIOL
         -- -------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_INFRML_ENFRC_ACTN/ICS_PROGS_VIOL';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_PROGS_VIOL.DATA_HASH
           FROM ICS_INFRML_ENFRC_ACTN
           JOIN ICS_PROGS_VIOL
             ON ICS_PROGS_VIOL.ICS_INFRML_ENFRC_ACTN_ID = ICS_INFRML_ENFRC_ACTN.ICS_INFRML_ENFRC_ACTN_ID
          WHERE ICS_INFRML_ENFRC_ACTN.KEY_HASH IN (SELECT KEY_HASH 
                                                     FROM ICS_KEY_HASH);
      END IF;
      -- ========================
      -- ICS_ENFRC_ACTN_MILESTONE
      -- ========================
      IF v_table_name = 'ICS_ENFRC_ACTN_MILESTONE' AND 
         v_enabled    = 'Y'                        THEN
         --
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_ENFRC_ACTN_MILESTONE';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_ENFRC_ACTN_MILESTONE.DATA_HASH
           FROM ICS_ENFRC_ACTN_MILESTONE
          WHERE ICS_ENFRC_ACTN_MILESTONE.KEY_HASH IN (SELECT KEY_HASH 
                                                        FROM ICS_KEY_HASH);
      END IF;
      -- ===============
      -- ICS_CSO_EVT_REP
      -- ===============
      IF v_table_name = 'ICS_CSO_EVT_REP' AND 
         v_enabled    = 'Y'               THEN
         --
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CSO_EVT_REP';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_CSO_EVT_REP.DATA_HASH
           FROM ICS_CSO_EVT_REP
          WHERE ICS_CSO_EVT_REP.KEY_HASH IN (SELECT KEY_HASH 
                                               FROM ICS_KEY_HASH);
      END IF;
      -- ==============
      -- ICS_SW_EVT_REP
      -- ==============
      IF v_table_name = 'ICS_SW_EVT_REP' AND 
         v_enabled    = 'Y'              THEN
         -- ---------------
         -- /ICS_SW_EVT_REP
         -- ---------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_SW_EVT_REP';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_SW_EVT_REP.DATA_HASH
           FROM ICS_SW_EVT_REP
          WHERE ICS_SW_EVT_REP.KEY_HASH IN (SELECT KEY_HASH 
                                              FROM ICS_KEY_HASH);
         -- ------------------------
         -- /ICS_SW_EVT_REP/ICS_ADDR
         -- ------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_SW_EVT_REP/ICS_ADDR';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_ADDR.DATA_HASH
           FROM ICS_SW_EVT_REP
           JOIN ICS_ADDR
             ON ICS_ADDR.ICS_SW_EVT_REP_ID = ICS_SW_EVT_REP.ICS_SW_EVT_REP_ID
          WHERE ICS_SW_EVT_REP.KEY_HASH IN (SELECT KEY_HASH 
                                              FROM ICS_KEY_HASH);
         -- -----------------------------------
         -- /ICS_SW_EVT_REP/ICS_ADDR/ICS_TELEPH
         -- -----------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_SW_EVT_REP/ICS_ADDR/ICS_TELEPH';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_TELEPH.DATA_HASH
           FROM ICS_SW_EVT_REP
           JOIN ICS_ADDR
             ON ICS_ADDR.ICS_SW_EVT_REP_ID = ICS_SW_EVT_REP.ICS_SW_EVT_REP_ID
           JOIN ICS_TELEPH
             ON ICS_TELEPH.ICS_ADDR_ID = ICS_ADDR.ICS_ADDR_ID
          WHERE ICS_SW_EVT_REP.KEY_HASH IN (SELECT KEY_HASH 
                                              FROM ICS_KEY_HASH);
         -- ---------------------------
         -- /ICS_SW_EVT_REP/ICS_CONTACT
         -- ---------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_SW_EVT_REP/ICS_CONTACT';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_CONTACT.DATA_HASH
           FROM ICS_SW_EVT_REP
           JOIN ICS_CONTACT
             ON ICS_CONTACT.ICS_SW_EVT_REP_ID = ICS_SW_EVT_REP.ICS_SW_EVT_REP_ID
          WHERE ICS_SW_EVT_REP.KEY_HASH IN (SELECT KEY_HASH 
                                              FROM ICS_KEY_HASH);
         -- --------------------------------------
         -- /ICS_SW_EVT_REP/ICS_CONTACT/ICS_TELEPH
         -- --------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_SW_EVT_REP/ICS_CONTACT/ICS_TELEPH';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_TELEPH.DATA_HASH
           FROM ICS_SW_EVT_REP
           JOIN ICS_CONTACT
             ON ICS_CONTACT.ICS_SW_EVT_REP_ID = ICS_SW_EVT_REP.ICS_SW_EVT_REP_ID
           JOIN ICS_TELEPH
             ON ICS_TELEPH.ICS_CONTACT_ID = ICS_CONTACT.ICS_CONTACT_ID
          WHERE ICS_SW_EVT_REP.KEY_HASH IN (SELECT KEY_HASH 
                                              FROM ICS_KEY_HASH);
        END IF;
        -- ==================
        -- ICS_CAFO_ANNUL_REP
        -- ==================
        IF v_table_name = 'ICS_CAFO_ANNUL_REP' AND 
           v_enabled    = 'Y'                  THEN
         -- -------------------
         -- /ICS_CAFO_ANNUL_REP
         -- -------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CAFO_ANNUL_REP';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_CAFO_ANNUL_REP.DATA_HASH
           FROM ICS_CAFO_ANNUL_REP
          WHERE ICS_CAFO_ANNUL_REP.KEY_HASH IN (SELECT KEY_HASH 
                                                  FROM ICS_KEY_HASH);
         -- -------------------------------------
         -- /ICS_CAFO_ANNUL_REP/ICS_REP_ANML_TYPE
         -- -------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CAFO_ANNUL_REP/ICS_REP_ANML_TYPE';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_REP_ANML_TYPE.DATA_HASH
           FROM ICS_CAFO_ANNUL_REP
           JOIN ICS_REP_ANML_TYPE
             ON ICS_REP_ANML_TYPE.ICS_CAFO_ANNUL_REP_ID = ICS_CAFO_ANNUL_REP.ICS_CAFO_ANNUL_REP_ID
          WHERE ICS_CAFO_ANNUL_REP.KEY_HASH IN (SELECT KEY_HASH 
                                                  FROM ICS_KEY_HASH);
      END IF;
      -- =====================
      -- ICS_LOC_LMTS_PROG_REP
      -- =====================
      IF v_table_name = 'ICS_LOC_LMTS_PROG_REP' AND 
         v_enabled    = 'Y'                     THEN
         -- ----------------------
         -- /ICS_LOC_LMTS_PROG_REP
         -- ----------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_LOC_LMTS_PROG_REP';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_LOC_LMTS_PROG_REP.DATA_HASH
           FROM ICS_LOC_LMTS_PROG_REP
          WHERE ICS_LOC_LMTS_PROG_REP.KEY_HASH IN (SELECT KEY_HASH 
                                                     FROM ICS_KEY_HASH);
         -- -----------------------------------
         -- /ICS_LOC_LMTS_PROG_REP/ICS_LOC_LMTS
         -- -----------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_LOC_LMTS_PROG_REP/ICS_LOC_LMTS';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_LOC_LMTS.DATA_HASH
           FROM ICS_LOC_LMTS_PROG_REP
           JOIN ICS_LOC_LMTS
             ON ICS_LOC_LMTS.ICS_LOC_LMTS_PROG_REP_ID = ICS_LOC_LMTS_PROG_REP.ICS_LOC_LMTS_PROG_REP_ID
          WHERE ICS_LOC_LMTS_PROG_REP.KEY_HASH IN (SELECT KEY_HASH 
                                                     FROM ICS_KEY_HASH);
         -- ------------------------------------------------------
         -- /ICS_LOC_LMTS_PROG_REP/ICS_LOC_LMTS/ICS_LOC_LMTS_POLUT
         -- ------------------------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_LOC_LMTS_PROG_REP/ICS_LOC_LMTS/ICS_LOC_LMTS_POLUT';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_LOC_LMTS_POLUT.DATA_HASH
           FROM ICS_LOC_LMTS_PROG_REP
           JOIN ICS_LOC_LMTS
             ON ICS_LOC_LMTS.ICS_LOC_LMTS_PROG_REP_ID = ICS_LOC_LMTS_PROG_REP.ICS_LOC_LMTS_PROG_REP_ID
           JOIN ICS_LOC_LMTS_POLUT
             ON ICS_LOC_LMTS_POLUT.ICS_LOC_LMTS_ID = ICS_LOC_LMTS.ICS_LOC_LMTS_ID
          WHERE ICS_LOC_LMTS_PROG_REP.KEY_HASH IN (SELECT KEY_HASH 
                                                     FROM ICS_KEY_HASH);
         -- -------------------------------------
         -- /ICS_LOC_LMTS_PROG_REP/ICS_RMVL_CRDTS
         -- -------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_LOC_LMTS_PROG_REP/ICS_RMVL_CRDTS';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_RMVL_CRDTS.DATA_HASH
           FROM ICS_LOC_LMTS_PROG_REP
           JOIN ICS_RMVL_CRDTS
             ON ICS_RMVL_CRDTS.ICS_LOC_LMTS_PROG_REP_ID = ICS_LOC_LMTS_PROG_REP.ICS_LOC_LMTS_PROG_REP_ID
          WHERE ICS_LOC_LMTS_PROG_REP.KEY_HASH IN (SELECT KEY_HASH 
                                                     FROM ICS_KEY_HASH);
         -- ----------------------------------------------------------
         -- /ICS_LOC_LMTS_PROG_REP/ICS_RMVL_CRDTS/ICS_RMVL_CRDTS_POLUT
         -- ----------------------------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_LOC_LMTS_PROG_REP/ICS_RMVL_CRDTS/ICS_RMVL_CRDTS_POLUT';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_RMVL_CRDTS_POLUT.DATA_HASH
           FROM ICS_LOC_LMTS_PROG_REP
           JOIN ICS_RMVL_CRDTS
             ON ICS_RMVL_CRDTS.ICS_LOC_LMTS_PROG_REP_ID = ICS_LOC_LMTS_PROG_REP.ICS_LOC_LMTS_PROG_REP_ID
           JOIN ICS_RMVL_CRDTS_POLUT
             ON ICS_RMVL_CRDTS_POLUT.ICS_RMVL_CRDTS_ID = ICS_RMVL_CRDTS.ICS_RMVL_CRDTS_ID
          WHERE ICS_LOC_LMTS_PROG_REP.KEY_HASH IN (SELECT KEY_HASH 
                                                     FROM ICS_KEY_HASH);
      END IF;
      -- ===================
      -- ICS_PRETR_PERF_SUMM
      -- ===================
      IF v_table_name = 'ICS_PRETR_PERF_SUMM' AND 
         v_enabled    = 'Y'                   THEN
         -- --------------------
         -- /ICS_PRETR_PERF_SUMM
         -- --------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_PRETR_PERF_SUMM';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_PRETR_PERF_SUMM.DATA_HASH
           FROM ICS_PRETR_PERF_SUMM
          WHERE ICS_PRETR_PERF_SUMM.KEY_HASH IN (SELECT KEY_HASH 
                                                   FROM ICS_KEY_HASH);
         -- ---------------------------------
         -- /ICS_PRETR_PERF_SUMM/ICS_LOC_LMTS
         -- ---------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_PRETR_PERF_SUMM/ICS_LOC_LMTS';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_LOC_LMTS.DATA_HASH
           FROM ICS_PRETR_PERF_SUMM
           JOIN ICS_LOC_LMTS
             ON ICS_LOC_LMTS.ICS_PRETR_PERF_SUMM_ID = ICS_PRETR_PERF_SUMM.ICS_PRETR_PERF_SUMM_ID
          WHERE ICS_PRETR_PERF_SUMM.KEY_HASH IN (SELECT KEY_HASH 
                                                   FROM ICS_KEY_HASH);
         -- ----------------------------------------------------
         -- /ICS_PRETR_PERF_SUMM/ICS_LOC_LMTS/ICS_LOC_LMTS_POLUT
         -- ----------------------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_PRETR_PERF_SUMM/ICS_LOC_LMTS/ICS_LOC_LMTS_POLUT';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_LOC_LMTS_POLUT.DATA_HASH
           FROM ICS_PRETR_PERF_SUMM
           JOIN ICS_LOC_LMTS
             ON ICS_LOC_LMTS.ICS_PRETR_PERF_SUMM_ID = ICS_PRETR_PERF_SUMM.ICS_PRETR_PERF_SUMM_ID
           JOIN ICS_LOC_LMTS_POLUT
             ON ICS_LOC_LMTS_POLUT.ICS_LOC_LMTS_ID = ICS_LOC_LMTS.ICS_LOC_LMTS_ID
          WHERE ICS_PRETR_PERF_SUMM.KEY_HASH IN (SELECT KEY_HASH 
                                                   FROM ICS_KEY_HASH);
         -- -----------------------------------
         -- /ICS_PRETR_PERF_SUMM/ICS_RMVL_CRDTS
         -- -----------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_PRETR_PERF_SUMM/ICS_RMVL_CRDTS';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_RMVL_CRDTS.DATA_HASH
           FROM ICS_PRETR_PERF_SUMM
           JOIN ICS_RMVL_CRDTS
             ON ICS_RMVL_CRDTS.ICS_PRETR_PERF_SUMM_ID = ICS_PRETR_PERF_SUMM.ICS_PRETR_PERF_SUMM_ID
          WHERE ICS_PRETR_PERF_SUMM.KEY_HASH IN (SELECT KEY_HASH 
                                                   FROM ICS_KEY_HASH);
         -- --------------------------------------------------------
         -- /ICS_PRETR_PERF_SUMM/ICS_RMVL_CRDTS/ICS_RMVL_CRDTS_POLUT
         -- --------------------------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_PRETR_PERF_SUMM/ICS_RMVL_CRDTS/ICS_RMVL_CRDTS_POLUT';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_RMVL_CRDTS_POLUT.DATA_HASH
           FROM ICS_PRETR_PERF_SUMM
           JOIN ICS_RMVL_CRDTS
             ON ICS_RMVL_CRDTS.ICS_PRETR_PERF_SUMM_ID = ICS_PRETR_PERF_SUMM.ICS_PRETR_PERF_SUMM_ID
           JOIN ICS_RMVL_CRDTS_POLUT
             ON ICS_RMVL_CRDTS_POLUT.ICS_RMVL_CRDTS_ID = ICS_RMVL_CRDTS.ICS_RMVL_CRDTS_ID
          WHERE ICS_PRETR_PERF_SUMM.KEY_HASH IN (SELECT KEY_HASH 
                                                   FROM ICS_KEY_HASH);
      END IF;
      -- ===============
      -- ICS_BS_PROG_REP
      -- ===============
      IF v_table_name = 'ICS_BS_PROG_REP' AND 
         v_enabled    = 'Y'               THEN
         --
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_BS_PROG_REP';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_BS_PROG_REP.DATA_HASH
           FROM ICS_BS_PROG_REP
          WHERE ICS_BS_PROG_REP.KEY_HASH IN (SELECT KEY_HASH 
                                               FROM ICS_KEY_HASH);
      END IF;
      -- =================
      -- ICS_SSO_ANNUL_REP
      -- =================
      IF v_table_name = 'ICS_SSO_ANNUL_REP' AND 
         v_enabled    = 'Y'                 THEN
         -- 
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_SSO_ANNUL_REP';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_SSO_ANNUL_REP.DATA_HASH
           FROM ICS_SSO_ANNUL_REP
          WHERE ICS_SSO_ANNUL_REP.KEY_HASH IN (SELECT KEY_HASH 
                                                 FROM ICS_KEY_HASH);
      END IF;
      -- ===============
      -- ICS_SSO_EVT_REP
      -- ===============
      IF v_table_name = 'ICS_SSO_EVT_REP' AND 
         v_enabled    = 'Y'               THEN
         -- ----------------
         -- /ICS_SSO_EVT_REP
         -- ----------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_SSO_EVT_REP';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_SSO_EVT_REP.DATA_HASH
           FROM ICS_SSO_EVT_REP
          WHERE ICS_SSO_EVT_REP.KEY_HASH IN (SELECT KEY_HASH 
                                               FROM ICS_KEY_HASH);
         -- -----------------------------------
         -- /ICS_SSO_EVT_REP/ICS_IMPACT_SSO_EVT
         -- -----------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_SSO_EVT_REP/ICS_IMPACT_SSO_EVT';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_IMPACT_SSO_EVT.DATA_HASH
           FROM ICS_SSO_EVT_REP
           JOIN ICS_IMPACT_SSO_EVT
             ON ICS_IMPACT_SSO_EVT.ICS_SSO_EVT_REP_ID = ICS_SSO_EVT_REP.ICS_SSO_EVT_REP_ID
          WHERE ICS_SSO_EVT_REP.KEY_HASH IN (SELECT KEY_HASH 
                                               FROM ICS_KEY_HASH);
         -- -----------------------------
         -- /ICS_SSO_EVT_REP/ICS_SSO_STPS
         -- -----------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_SSO_EVT_REP/ICS_SSO_STPS';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_SSO_STPS.DATA_HASH
           FROM ICS_SSO_EVT_REP
           JOIN ICS_SSO_STPS
             ON ICS_SSO_STPS.ICS_SSO_EVT_REP_ID = ICS_SSO_EVT_REP.ICS_SSO_EVT_REP_ID
          WHERE ICS_SSO_EVT_REP.KEY_HASH IN (SELECT KEY_HASH 
                                               FROM ICS_KEY_HASH);
         -- -----------------------------------
         -- /ICS_SSO_EVT_REP/ICS_SSO_SYSTM_COMP
         -- -----------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_SSO_EVT_REP/ICS_SSO_SYSTM_COMP';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_SSO_SYSTM_COMP.DATA_HASH
           FROM ICS_SSO_EVT_REP
           JOIN ICS_SSO_SYSTM_COMP
             ON ICS_SSO_SYSTM_COMP.ICS_SSO_EVT_REP_ID = ICS_SSO_EVT_REP.ICS_SSO_EVT_REP_ID
          WHERE ICS_SSO_EVT_REP.KEY_HASH IN (SELECT KEY_HASH 
                                               FROM ICS_KEY_HASH);
      END IF;
      -- =======================
      -- ICS_SSO_MONTHLY_EVT_REP
      -- =======================
      IF v_table_name = 'ICS_SSO_MONTHLY_EVT_REP' AND 
         v_enabled    = 'Y'                       THEN
         --
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_SSO_MONTHLY_EVT_REP';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_SSO_MONTHLY_EVT_REP.DATA_HASH
           FROM ICS_SSO_MONTHLY_EVT_REP
          WHERE ICS_SSO_MONTHLY_EVT_REP.KEY_HASH IN (SELECT KEY_HASH 
                                                       FROM ICS_KEY_HASH);
      END IF;
      -- ===================
      -- ICS_SWMS_4_PROG_REP
      -- ===================
      IF v_table_name = 'ICS_SWMS_4_PROG_REP' AND 
         v_enabled    = 'Y'                   THEN
         -- --------------------
         -- /ICS_SWMS_4_PROG_REP
         -- --------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_SWMS_4_PROG_REP';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_SWMS_4_PROG_REP.DATA_HASH
           FROM ICS_SWMS_4_PROG_REP
          WHERE ICS_SWMS_4_PROG_REP.KEY_HASH IN (SELECT KEY_HASH 
                                                   FROM ICS_KEY_HASH);
         -- -----------------------------
         -- /ICS_SWMS_4_PROG_REP/ICS_ADDR
         -- -----------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_SWMS_4_PROG_REP/ICS_ADDR';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_ADDR.DATA_HASH
           FROM ICS_SWMS_4_PROG_REP
           JOIN ICS_ADDR
             ON ICS_ADDR.ICS_SWMS_4_PROG_REP_ID = ICS_SWMS_4_PROG_REP.ICS_SWMS_4_PROG_REP_ID
          WHERE ICS_SWMS_4_PROG_REP.KEY_HASH IN (SELECT KEY_HASH 
                                                   FROM ICS_KEY_HASH);
         -- ----------------------------------------
         -- /ICS_SWMS_4_PROG_REP/ICS_ADDR/ICS_TELEPH
         -- ----------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_SWMS_4_PROG_REP/ICS_ADDR/ICS_TELEPH';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_TELEPH.DATA_HASH
           FROM ICS_SWMS_4_PROG_REP
           JOIN ICS_ADDR
             ON ICS_ADDR.ICS_SWMS_4_PROG_REP_ID = ICS_SWMS_4_PROG_REP.ICS_SWMS_4_PROG_REP_ID
           JOIN ICS_TELEPH
             ON ICS_TELEPH.ICS_ADDR_ID = ICS_ADDR.ICS_ADDR_ID
          WHERE ICS_SWMS_4_PROG_REP.KEY_HASH IN (SELECT KEY_HASH 
                                                   FROM ICS_KEY_HASH);
         -- --------------------------------
         -- /ICS_SWMS_4_PROG_REP/ICS_CONTACT
         -- --------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_SWMS_4_PROG_REP/ICS_CONTACT';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_CONTACT.DATA_HASH
           FROM ICS_SWMS_4_PROG_REP
           JOIN ICS_CONTACT
             ON ICS_CONTACT.ICS_SWMS_4_PROG_REP_ID = ICS_SWMS_4_PROG_REP.ICS_SWMS_4_PROG_REP_ID
          WHERE ICS_SWMS_4_PROG_REP.KEY_HASH IN (SELECT KEY_HASH 
                                                   FROM ICS_KEY_HASH);
         -- -------------------------------------------
         -- /ICS_SWMS_4_PROG_REP/ICS_CONTACT/ICS_TELEPH
         -- -------------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_SWMS_4_PROG_REP/ICS_CONTACT/ICS_TELEPH';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_TELEPH.DATA_HASH
           FROM ICS_SWMS_4_PROG_REP
           JOIN ICS_CONTACT
             ON ICS_CONTACT.ICS_SWMS_4_PROG_REP_ID = ICS_SWMS_4_PROG_REP.ICS_SWMS_4_PROG_REP_ID
           JOIN ICS_TELEPH
             ON ICS_TELEPH.ICS_CONTACT_ID = ICS_CONTACT.ICS_CONTACT_ID
          WHERE ICS_SWMS_4_PROG_REP.KEY_HASH IN (SELECT KEY_HASH 
                                                   FROM ICS_KEY_HASH);
         -- ---------------------------------------
         -- /ICS_SWMS_4_PROG_REP/ICS_PROJ_SRCS_FUND
         -- ---------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_SWMS_4_PROG_REP/ICS_PROJ_SRCS_FUND';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_PROJ_SRCS_FUND.DATA_HASH
           FROM ICS_SWMS_4_PROG_REP
           JOIN ICS_PROJ_SRCS_FUND
             ON ICS_PROJ_SRCS_FUND.ICS_SWMS_4_PROG_REP_ID = ICS_SWMS_4_PROG_REP.ICS_SWMS_4_PROG_REP_ID
          WHERE ICS_SWMS_4_PROG_REP.KEY_HASH IN (SELECT KEY_HASH 
                                                   FROM ICS_KEY_HASH);
      END IF;
      -- =================
      -- ICS_SCHD_EVT_VIOL
      -- =================
      IF v_table_name = 'ICS_SCHD_EVT_VIOL' AND 
         v_enabled    = 'Y'                 THEN
         -- ------------------
         -- /ICS_SCHD_EVT_VIOL
         -- ------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_SCHD_EVT_VIOL';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_SCHD_EVT_VIOL.DATA_HASH
           FROM ICS_SCHD_EVT_VIOL
          WHERE ICS_SCHD_EVT_VIOL.KEY_HASH IN (SELECT KEY_HASH 
                                                 FROM ICS_KEY_HASH);
         -- ----------------------------------------------
         -- /ICS_SCHD_EVT_VIOL/ICS_CMPL_SCHD_EVT_VIOL_ELEM
         -- ----------------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_SCHD_EVT_VIOL/ICS_CMPL_SCHD_EVT_VIOL_ELEM';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_CMPL_SCHD_EVT_VIOL_ELEM.DATA_HASH
           FROM ICS_SCHD_EVT_VIOL
           JOIN ICS_CMPL_SCHD_EVT_VIOL_ELEM
             ON ICS_CMPL_SCHD_EVT_VIOL_ELEM.ICS_SCHD_EVT_VIOL_ID = ICS_SCHD_EVT_VIOL.ICS_SCHD_EVT_VIOL_ID
          WHERE ICS_SCHD_EVT_VIOL.KEY_HASH IN (SELECT KEY_HASH 
                                                 FROM ICS_KEY_HASH);
         -- ----------------------------------------------
         -- /ICS_SCHD_EVT_VIOL/ICS_PRMT_SCHD_EVT_VIOL_ELEM
         -- ----------------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_SCHD_EVT_VIOL/ICS_PRMT_SCHD_EVT_VIOL_ELEM';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_PRMT_SCHD_EVT_VIOL_ELEM.DATA_HASH
           FROM ICS_SCHD_EVT_VIOL
           JOIN ICS_PRMT_SCHD_EVT_VIOL_ELEM
             ON ICS_PRMT_SCHD_EVT_VIOL_ELEM.ICS_SCHD_EVT_VIOL_ID = ICS_SCHD_EVT_VIOL.ICS_SCHD_EVT_VIOL_ID
          WHERE ICS_SCHD_EVT_VIOL.KEY_HASH IN (SELECT KEY_HASH 
                                                 FROM ICS_KEY_HASH);
      END IF;
      -- ================
      -- ICS_CMPL_MON_LNK
      -- ================
      IF v_table_name = 'ICS_CMPL_MON_LNK' AND 
         v_enabled    = 'Y'                THEN
         -- -----------------
         -- /ICS_CMPL_MON_LNK
         -- -----------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CMPL_MON_LNK';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_CMPL_MON_LNK.DATA_HASH
           FROM ICS_CMPL_MON_LNK
          WHERE ICS_CMPL_MON_LNK.KEY_HASH IN (SELECT KEY_HASH 
                                                FROM ICS_KEY_HASH);
         -- --------------------------------
         -- /ICS_CMPL_MON_LNK/ICS_LNK_BS_REP
         -- --------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash//ICS_CMPL_MON_LNK/ICS_LNK_BS_REP';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_LNK_BS_REP.DATA_HASH
           FROM ICS_CMPL_MON_LNK
           JOIN ICS_LNK_BS_REP
             ON ICS_LNK_BS_REP.ICS_CMPL_MON_LNK_ID = ICS_CMPL_MON_LNK.ICS_CMPL_MON_LNK_ID
          WHERE ICS_CMPL_MON_LNK.KEY_HASH IN (SELECT KEY_HASH 
                                                FROM ICS_KEY_HASH);
         -- ----------------------------------------
         -- /ICS_CMPL_MON_LNK/ICS_LNK_CAFO_ANNUL_REP
         -- ----------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CMPL_MON_LNK/ICS_LNK_CAFO_ANNUL_REP';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_LNK_CAFO_ANNUL_REP.DATA_HASH
           FROM ICS_CMPL_MON_LNK
           JOIN ICS_LNK_CAFO_ANNUL_REP
             ON ICS_LNK_CAFO_ANNUL_REP.ICS_CMPL_MON_LNK_ID = ICS_CMPL_MON_LNK.ICS_CMPL_MON_LNK_ID
          WHERE ICS_CMPL_MON_LNK.KEY_HASH IN (SELECT KEY_HASH 
                                                FROM ICS_KEY_HASH);
         -- -------------------------------------
         -- /ICS_CMPL_MON_LNK/ICS_LNK_CSO_EVT_REP
         -- -------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CMPL_MON_LNK/ICS_LNK_CSO_EVT_REP';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_LNK_CSO_EVT_REP.DATA_HASH
           FROM ICS_CMPL_MON_LNK
           JOIN ICS_LNK_CSO_EVT_REP
             ON ICS_LNK_CSO_EVT_REP.ICS_CMPL_MON_LNK_ID = ICS_CMPL_MON_LNK.ICS_CMPL_MON_LNK_ID
          WHERE ICS_CMPL_MON_LNK.KEY_HASH IN (SELECT KEY_HASH 
                                                FROM ICS_KEY_HASH);
         -- ------------------------------------
         -- /ICS_CMPL_MON_LNK/ICS_LNK_ENFRC_ACTN
         -- ------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CMPL_MON_LNK/ICS_LNK_ENFRC_ACTN';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_LNK_ENFRC_ACTN.DATA_HASH
           FROM ICS_CMPL_MON_LNK
           JOIN ICS_LNK_ENFRC_ACTN
             ON ICS_LNK_ENFRC_ACTN.ICS_CMPL_MON_LNK_ID = ICS_CMPL_MON_LNK.ICS_CMPL_MON_LNK_ID
          WHERE ICS_CMPL_MON_LNK.KEY_HASH IN (SELECT KEY_HASH 
                                                FROM ICS_KEY_HASH);
         -- ---------------------------------------
         -- /ICS_CMPL_MON_LNK/ICS_LNK_FEDR_CMPL_MON
         -- ---------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CMPL_MON_LNK/ICS_LNK_FEDR_CMPL_MON';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_LNK_FEDR_CMPL_MON.DATA_HASH
           FROM ICS_CMPL_MON_LNK
           JOIN ICS_LNK_FEDR_CMPL_MON
             ON ICS_LNK_FEDR_CMPL_MON.ICS_CMPL_MON_LNK_ID = ICS_CMPL_MON_LNK.ICS_CMPL_MON_LNK_ID
          WHERE ICS_CMPL_MON_LNK.KEY_HASH IN (SELECT KEY_HASH 
                                                FROM ICS_KEY_HASH);
         -- --------------------------------------
         -- /ICS_CMPL_MON_LNK/ICS_LNK_LOC_LMTS_REP
         -- --------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CMPL_MON_LNK/ICS_LNK_LOC_LMTS_REP';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_LNK_LOC_LMTS_REP.DATA_HASH
           FROM ICS_CMPL_MON_LNK
           JOIN ICS_LNK_LOC_LMTS_REP
             ON ICS_LNK_LOC_LMTS_REP.ICS_CMPL_MON_LNK_ID = ICS_CMPL_MON_LNK.ICS_CMPL_MON_LNK_ID
          WHERE ICS_CMPL_MON_LNK.KEY_HASH IN (SELECT KEY_HASH 
                                                FROM ICS_KEY_HASH);
         -- ----------------------------------------
         -- /ICS_CMPL_MON_LNK/ICS_LNK_PRETR_PERF_REP
         -- ----------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CMPL_MON_LNK/ICS_LNK_PRETR_PERF_REP';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_LNK_PRETR_PERF_REP.DATA_HASH
           FROM ICS_CMPL_MON_LNK
           JOIN ICS_LNK_PRETR_PERF_REP
             ON ICS_LNK_PRETR_PERF_REP.ICS_CMPL_MON_LNK_ID = ICS_CMPL_MON_LNK.ICS_CMPL_MON_LNK_ID
          WHERE ICS_CMPL_MON_LNK.KEY_HASH IN (SELECT KEY_HASH 
                                                FROM ICS_KEY_HASH);
         -- ----------------------------------
         -- /ICS_CMPL_MON_LNK/ICS_LNK_SNGL_EVT
         -- ----------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CMPL_MON_LNK/ICS_LNK_SNGL_EVT';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_LNK_SNGL_EVT.DATA_HASH
           FROM ICS_CMPL_MON_LNK
           JOIN ICS_LNK_SNGL_EVT
             ON ICS_LNK_SNGL_EVT.ICS_CMPL_MON_LNK_ID = ICS_CMPL_MON_LNK.ICS_CMPL_MON_LNK_ID
          WHERE ICS_CMPL_MON_LNK.KEY_HASH IN (SELECT KEY_HASH 
                                                FROM ICS_KEY_HASH);
         -- ---------------------------------------
         -- /ICS_CMPL_MON_LNK/ICS_LNK_SSO_ANNUL_REP
         -- ---------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CMPL_MON_LNK/ICS_LNK_SSO_ANNUL_REP';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_LNK_SSO_ANNUL_REP.DATA_HASH
           FROM ICS_CMPL_MON_LNK
           JOIN ICS_LNK_SSO_ANNUL_REP
             ON ICS_LNK_SSO_ANNUL_REP.ICS_CMPL_MON_LNK_ID = ICS_CMPL_MON_LNK.ICS_CMPL_MON_LNK_ID
          WHERE ICS_CMPL_MON_LNK.KEY_HASH IN (SELECT KEY_HASH 
                                                FROM ICS_KEY_HASH);
         -- -------------------------------------
         -- /ICS_CMPL_MON_LNK/ICS_LNK_SSO_EVT_REP
         -- -------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CMPL_MON_LNK/ICS_LNK_SSO_EVT_REP';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_LNK_SSO_EVT_REP.DATA_HASH
           FROM ICS_CMPL_MON_LNK
           JOIN ICS_LNK_SSO_EVT_REP
             ON ICS_LNK_SSO_EVT_REP.ICS_CMPL_MON_LNK_ID = ICS_CMPL_MON_LNK.ICS_CMPL_MON_LNK_ID
          WHERE ICS_CMPL_MON_LNK.KEY_HASH IN (SELECT KEY_HASH 
                                                FROM ICS_KEY_HASH);
         -- ---------------------------------------------
         -- /ICS_CMPL_MON_LNK/ICS_LNK_SSO_MONTHLY_EVT_REP
         -- ---------------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CMPL_MON_LNK/ICS_LNK_SSO_MONTHLY_EVT_REP';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_LNK_SSO_MONTHLY_EVT_REP.DATA_HASH
           FROM ICS_CMPL_MON_LNK
           JOIN ICS_LNK_SSO_MONTHLY_EVT_REP
             ON ICS_LNK_SSO_MONTHLY_EVT_REP.ICS_CMPL_MON_LNK_ID = ICS_CMPL_MON_LNK.ICS_CMPL_MON_LNK_ID
          WHERE ICS_CMPL_MON_LNK.KEY_HASH IN (SELECT KEY_HASH 
                                                FROM ICS_KEY_HASH);
         -- -------------------------------------
         -- /ICS_CMPL_MON_LNK/ICS_LNK_ST_CMPL_MON
         -- -------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CMPL_MON_LNK/ICS_LNK_ST_CMPL_MON';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_LNK_ST_CMPL_MON.DATA_HASH
           FROM ICS_CMPL_MON_LNK
           JOIN ICS_LNK_ST_CMPL_MON
             ON ICS_LNK_ST_CMPL_MON.ICS_CMPL_MON_LNK_ID = ICS_CMPL_MON_LNK.ICS_CMPL_MON_LNK_ID
          WHERE ICS_CMPL_MON_LNK.KEY_HASH IN (SELECT KEY_HASH 
                                                FROM ICS_KEY_HASH);
         -- ------------------------------------
         -- /ICS_CMPL_MON_LNK/ICS_LNK_SW_EVT_REP
         -- ------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CMPL_MON_LNK/ICS_LNK_SW_EVT_REP';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_LNK_SW_EVT_REP.DATA_HASH
           FROM ICS_CMPL_MON_LNK
           JOIN ICS_LNK_SW_EVT_REP
             ON ICS_LNK_SW_EVT_REP.ICS_CMPL_MON_LNK_ID = ICS_CMPL_MON_LNK.ICS_CMPL_MON_LNK_ID
          WHERE ICS_CMPL_MON_LNK.KEY_HASH IN (SELECT KEY_HASH 
                                                FROM ICS_KEY_HASH);
         -- ------------------------------------
         -- /ICS_CMPL_MON_LNK/ICS_LNK_SWMS_4_REP
         -- ------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_CMPL_MON_LNK/ICS_LNK_SWMS_4_REP';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_LNK_SWMS_4_REP.DATA_HASH
           FROM ICS_CMPL_MON_LNK
           JOIN ICS_LNK_SWMS_4_REP
             ON ICS_LNK_SWMS_4_REP.ICS_CMPL_MON_LNK_ID = ICS_CMPL_MON_LNK.ICS_CMPL_MON_LNK_ID
          WHERE ICS_CMPL_MON_LNK.KEY_HASH IN (SELECT KEY_HASH 
                                                FROM ICS_KEY_HASH);
      END IF;
      -- =======================
      -- ICS_ENFRC_ACTN_VIOL_LNK
      -- =======================
      IF v_table_name = 'ICS_ENFRC_ACTN_VIOL_LNK' AND 
         v_enabled    = 'Y'                       THEN
         -- ------------------------
         -- /ICS_ENFRC_ACTN_VIOL_LNK
         -- ------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_ENFRC_ACTN_VIOL_LNK';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_ENFRC_ACTN_VIOL_LNK.DATA_HASH
           FROM ICS_ENFRC_ACTN_VIOL_LNK
          WHERE ICS_ENFRC_ACTN_VIOL_LNK.KEY_HASH IN (SELECT KEY_HASH 
                                                       FROM ICS_KEY_HASH);
         -- -------------------------------------------
         -- /ICS_ENFRC_ACTN_VIOL_LNK/ICS_CMPL_SCHD_VIOL
         -- -------------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_ENFRC_ACTN_VIOL_LNK/ICS_CMPL_SCHD_VIOL';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_CMPL_SCHD_VIOL.DATA_HASH
           FROM ICS_ENFRC_ACTN_VIOL_LNK
           JOIN ICS_CMPL_SCHD_VIOL
             ON ICS_CMPL_SCHD_VIOL.ICS_ENFRC_ACTN_VIOL_LNK_ID = ICS_ENFRC_ACTN_VIOL_LNK.ICS_ENFRC_ACTN_VIOL_LNK_ID
          WHERE ICS_ENFRC_ACTN_VIOL_LNK.KEY_HASH IN (SELECT KEY_HASH 
                                                       FROM ICS_KEY_HASH);
         -- ----------------------------------------------------
         -- /ICS_ENFRC_ACTN_VIOL_LNK/ICS_DSCH_MON_REP_PARAM_VIOL
         -- ----------------------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_ENFRC_ACTN_VIOL_LNK/ICS_DSCH_MON_REP_PARAM_VIOL';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_DSCH_MON_REP_PARAM_VIOL.DATA_HASH
           FROM ICS_ENFRC_ACTN_VIOL_LNK
           JOIN ICS_DSCH_MON_REP_PARAM_VIOL
             ON ICS_DSCH_MON_REP_PARAM_VIOL.ICS_ENFRC_ACTN_VIOL_LNK_ID = ICS_ENFRC_ACTN_VIOL_LNK.ICS_ENFRC_ACTN_VIOL_LNK_ID
          WHERE ICS_ENFRC_ACTN_VIOL_LNK.KEY_HASH IN (SELECT KEY_HASH 
                                                       FROM ICS_KEY_HASH);
         -- ----------------------------------------------
         -- /ICS_ENFRC_ACTN_VIOL_LNK/ICS_DSCH_MON_REP_VIOL
         -- ----------------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_ENFRC_ACTN_VIOL_LNK/ICS_DSCH_MON_REP_VIOL';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_DSCH_MON_REP_VIOL.DATA_HASH
           FROM ICS_ENFRC_ACTN_VIOL_LNK
           JOIN ICS_DSCH_MON_REP_VIOL
             ON ICS_DSCH_MON_REP_VIOL.ICS_ENFRC_ACTN_VIOL_LNK_ID = ICS_ENFRC_ACTN_VIOL_LNK.ICS_ENFRC_ACTN_VIOL_LNK_ID
          WHERE ICS_ENFRC_ACTN_VIOL_LNK.KEY_HASH IN (SELECT KEY_HASH 
                                                       FROM ICS_KEY_HASH);
         -- -------------------------------------------
         -- /ICS_ENFRC_ACTN_VIOL_LNK/ICS_PRMT_SCHD_VIOL
         -- -------------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_ENFRC_ACTN_VIOL_LNK/ICS_PRMT_SCHD_VIOL';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_PRMT_SCHD_VIOL.DATA_HASH
           FROM ICS_ENFRC_ACTN_VIOL_LNK
           JOIN ICS_PRMT_SCHD_VIOL
             ON ICS_PRMT_SCHD_VIOL.ICS_ENFRC_ACTN_VIOL_LNK_ID = ICS_ENFRC_ACTN_VIOL_LNK.ICS_ENFRC_ACTN_VIOL_LNK_ID
          WHERE ICS_ENFRC_ACTN_VIOL_LNK.KEY_HASH IN (SELECT KEY_HASH 
                                                       FROM ICS_KEY_HASH);
         -- -------------------------------------------
         -- /ICS_ENFRC_ACTN_VIOL_LNK/ICS_SNGL_EVTS_VIOL
         -- -------------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_ENFRC_ACTN_VIOL_LNK/ICS_SNGL_EVTS_VIOL';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_SNGL_EVTS_VIOL.DATA_HASH
           FROM ICS_ENFRC_ACTN_VIOL_LNK
           JOIN ICS_SNGL_EVTS_VIOL
             ON ICS_SNGL_EVTS_VIOL.ICS_ENFRC_ACTN_VIOL_LNK_ID = ICS_ENFRC_ACTN_VIOL_LNK.ICS_ENFRC_ACTN_VIOL_LNK_ID
          WHERE ICS_ENFRC_ACTN_VIOL_LNK.KEY_HASH IN (SELECT KEY_HASH 
                                                       FROM ICS_KEY_HASH);
      END IF;
      -- ====================
      -- ICS_DMR_PROG_REP_LNK
      -- ====================
      IF v_table_name = 'ICS_DMR_PROG_REP_LNK' AND 
         v_enabled    = 'Y'                    THEN
         -- ---------------------
         -- /ICS_DMR_PROG_REP_LNK
         -- ---------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_DMR_PROG_REP_LNK';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_DMR_PROG_REP_LNK.DATA_HASH
           FROM ICS_DMR_PROG_REP_LNK
          WHERE ICS_DMR_PROG_REP_LNK.KEY_HASH IN (SELECT KEY_HASH 
                                                    FROM ICS_KEY_HASH);
         -- ------------------------------------
         -- /ICS_DMR_PROG_REP_LNK/ICS_LNK_BS_REP
         -- ------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_DMR_PROG_REP_LNK/ICS_LNK_BS_REP';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_LNK_BS_REP.DATA_HASH
           FROM ICS_DMR_PROG_REP_LNK
           JOIN ICS_LNK_BS_REP
             ON ICS_LNK_BS_REP.ICS_DMR_PROG_REP_LNK_ID = ICS_DMR_PROG_REP_LNK.ICS_DMR_PROG_REP_LNK_ID
          WHERE ICS_DMR_PROG_REP_LNK.KEY_HASH IN (SELECT KEY_HASH 
                                                    FROM ICS_KEY_HASH);
         -- ----------------------------------------
         -- /ICS_DMR_PROG_REP_LNK/ICS_LNK_SW_EVT_REP
         -- ----------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_DMR_PROG_REP_LNK/ICS_LNK_SW_EVT_REP';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_LNK_SW_EVT_REP.DATA_HASH
           FROM ICS_DMR_PROG_REP_LNK
           JOIN ICS_LNK_SW_EVT_REP
             ON ICS_LNK_SW_EVT_REP.ICS_DMR_PROG_REP_LNK_ID = ICS_DMR_PROG_REP_LNK.ICS_DMR_PROG_REP_LNK_ID
          WHERE ICS_DMR_PROG_REP_LNK.KEY_HASH IN (SELECT KEY_HASH 
                                                    FROM ICS_KEY_HASH);
      END IF;
      -- ========================
      -- ICS_FINAL_ORDER_VIOL_LNK
      -- ========================
      IF v_table_name = 'ICS_FINAL_ORDER_VIOL_LNK' AND 
         v_enabled    = 'Y'                        THEN
         -- -------------------------
         -- /ICS_FINAL_ORDER_VIOL_LNK
         -- -------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_FINAL_ORDER_VIOL_LNK';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_FINAL_ORDER_VIOL_LNK.DATA_HASH
           FROM ICS_FINAL_ORDER_VIOL_LNK
          WHERE ICS_FINAL_ORDER_VIOL_LNK.KEY_HASH IN (SELECT KEY_HASH 
                                                        FROM ICS_KEY_HASH);
         -- --------------------------------------------
         -- /ICS_FINAL_ORDER_VIOL_LNK/ICS_CMPL_SCHD_VIOL
         -- --------------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_FINAL_ORDER_VIOL_LNK/ICS_CMPL_SCHD_VIOL';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_CMPL_SCHD_VIOL.DATA_HASH
           FROM ICS_FINAL_ORDER_VIOL_LNK
           JOIN ICS_CMPL_SCHD_VIOL
             ON ICS_CMPL_SCHD_VIOL.ICS_FINAL_ORDER_VIOL_LNK_ID = ICS_FINAL_ORDER_VIOL_LNK.ICS_FINAL_ORDER_VIOL_LNK_ID
          WHERE ICS_FINAL_ORDER_VIOL_LNK.KEY_HASH IN (SELECT KEY_HASH 
                                                        FROM ICS_KEY_HASH);
         -- -----------------------------------------------------
         -- /ICS_FINAL_ORDER_VIOL_LNK/ICS_DSCH_MON_REP_PARAM_VIOL
         -- -----------------------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_FINAL_ORDER_VIOL_LNK/ICS_DSCH_MON_REP_PARAM_VIOL';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_DSCH_MON_REP_PARAM_VIOL.DATA_HASH
           FROM ICS_FINAL_ORDER_VIOL_LNK
           JOIN ICS_DSCH_MON_REP_PARAM_VIOL
             ON ICS_DSCH_MON_REP_PARAM_VIOL.ICS_FINAL_ORDER_VIOL_LNK_ID = ICS_FINAL_ORDER_VIOL_LNK.ICS_FINAL_ORDER_VIOL_LNK_ID
          WHERE ICS_FINAL_ORDER_VIOL_LNK.KEY_HASH IN (SELECT KEY_HASH 
                                                        FROM ICS_KEY_HASH);
         -- -----------------------------------------------
         -- /ICS_FINAL_ORDER_VIOL_LNK/ICS_DSCH_MON_REP_VIOL
         -- -----------------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_FINAL_ORDER_VIOL_LNK/ICS_DSCH_MON_REP_VIOL';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_DSCH_MON_REP_VIOL.DATA_HASH
           FROM ICS_FINAL_ORDER_VIOL_LNK
           JOIN ICS_DSCH_MON_REP_VIOL
             ON ICS_DSCH_MON_REP_VIOL.ICS_FINAL_ORDER_VIOL_LNK_ID = ICS_FINAL_ORDER_VIOL_LNK.ICS_FINAL_ORDER_VIOL_LNK_ID
          WHERE ICS_FINAL_ORDER_VIOL_LNK.KEY_HASH IN (SELECT KEY_HASH 
                                                        FROM ICS_KEY_HASH);
         -- --------------------------------------------
         -- /ICS_FINAL_ORDER_VIOL_LNK/ICS_PRMT_SCHD_VIOL
         -- --------------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_FINAL_ORDER_VIOL_LNK/ICS_PRMT_SCHD_VIOL';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_PRMT_SCHD_VIOL.DATA_HASH
           FROM ICS_FINAL_ORDER_VIOL_LNK
           JOIN ICS_PRMT_SCHD_VIOL
             ON ICS_PRMT_SCHD_VIOL.ICS_FINAL_ORDER_VIOL_LNK_ID = ICS_FINAL_ORDER_VIOL_LNK.ICS_FINAL_ORDER_VIOL_LNK_ID
          WHERE ICS_FINAL_ORDER_VIOL_LNK.KEY_HASH IN (SELECT KEY_HASH 
                                                        FROM ICS_KEY_HASH);
         -- --------------------------------------------
         -- /ICS_FINAL_ORDER_VIOL_LNK/ICS_SNGL_EVTS_VIOL
         -- --------------------------------------------
         SET v_marker = 'INSERT INTO ics_data_hash/ICS_FINAL_ORDER_VIOL_LNK/ICS_SNGL_EVTS_VIOL';
         INSERT INTO ICS_DATA_HASH
         SELECT ICS_SNGL_EVTS_VIOL.DATA_HASH
           FROM ICS_FINAL_ORDER_VIOL_LNK
           JOIN ICS_SNGL_EVTS_VIOL
             ON ICS_SNGL_EVTS_VIOL.ICS_FINAL_ORDER_VIOL_LNK_ID = ICS_FINAL_ORDER_VIOL_LNK.ICS_FINAL_ORDER_VIOL_LNK_ID
          WHERE ICS_FINAL_ORDER_VIOL_LNK.KEY_HASH IN (SELECT KEY_HASH 
                                                        FROM ICS_KEY_HASH);
      END IF;
      /*  
      *  Loop through each data_hash value loaded into ICS_DATA_HASH, 
      *  for each, rehash each data_hash values together to create 
      *  a single data_hash value that represents all the non-key 
      *  data contained within a payload type / key_hash combination.
      */
      SET v_marker = 'SET v_all_data_hashes';
      SET v_all_data_hashes := COALESCE( (SELECT MD5(ALL_DATA_HASH)
                                            FROM (SELECT DATA_HASH
                                                        ,@datahash := CONCAT(@datahash,DATA_HASH) ALL_DATA_HASH
                                                        ,@rownbr   := @rownbr + 1                ROWNBR
                                                    FROM (SELECT DATA_HASH
                                                            FROM ICS_DATA_HASH
                                                           ORDER BY DATA_HASH) vw_main
                                                        ,(SELECT @datahash := ''
                                                                ,@rownbr   := 0) vw
                                                 ) vw_dh
                                           ORDER BY ROWNBR DESC LIMIT 1)
                                       ,MD5(0));
      --
      -- Load the rehashed value into the payload type table's data_hash column.
      SET v_marker = CONCAT('UPDATE '
                           ,v_table_name
                           ,' SET DATA_HASH = '
                           ,v_hashed_data_hashes
                           ,' WHERE key_hash IN (SELECT KEY_HASH FROM ICS_KEY_HASH)');
      SET @sqlstmt = v_marker;
      PREPARE v_sql_statement FROM @sqlstmt;
      EXECUTE v_sql_statement;
      --
   END LOOP payload_loop;
   CLOSE payload_type_cur;
   -- -------------- --
   --  END PROCEDURE --
   -- -------------- --
   SET v_marker = 'CALL ics_etl_log_sp END';
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_sp_name     -- pi_marker
      ,NULL          -- pi_tgt_tbl
      ,NULL          -- pi_src_tbl 
      ,v_startdtm    -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'COMPLETED'   -- pi_process
      ,0);           -- pi_value
   --
   SET po_status = 1;
   SET po_errm   = 'COMPLETED';
END