USE ga_ics_flow_local;
DROP PROCEDURE IF EXISTS ics_process_accepted_trans;
CREATE PROCEDURE ics_process_accepted_trans
   (IN  pi_transaction_id  VARCHAR(40))
BEGIN
/******************************************************************************
** Object Name: ics_process_accepted_trans
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure uses the data in ICS_SUBM_RESULTS table to 
**               copy the data for accepted transactions from the LOCAL to
**               ICIS schema/database. It should only be executed by the
**               OpenNode2 plugin as part of the GetICISStatusAndProcessReports
**               service execution
**               -- Step 1: Remove any previous accepted transactions so
**                          the procedure does not attempt to move records
**                          from previous executions.
**               -- Step 2: Update KEY_HASH with hashed business key data
**               -- Step 3: Remove previous error transactions that have were
**                          present in the most recent transaction
**               -- Step 4: Move accepted transactions from LOCAL to ICIS schema
**               -- Step 5: Copy business keys where ICIS returnes error that
**                          key is already present in ICIS
**               -- Step 6: Record counts into ICS_SUBM_HIST
**
** Revision History:
** ----------------------------------------------------------------------------
**  Date         Name        Description
** ----------------------------------------------------------------------------
** 08/15/2012    BRensmith   Baseline from v3.1 procedure.
** 08/15/2012    BRensmith   Added v4.0 changes.
** 08/23/2012    BRensmith   Update WHERE clause in Step 5 INSERTs to avoid 
**                           unique index violations
** 09/28/2012    CTyler      Fix KEYHASH calcuation for prmt_reissu in 
**                           ics_submt_result to use issue date from prmt_reissu
**                           table so KEY_HASH will be consistant with 
**                           calculation in prmt_reissu
** 10/09/2012    BRensmith   Add processing for BP060 'Permit already Exists in
**                           ICIS' for GP sumbmission type.
** 10/16/2012    BRensmith   Refactor DELETE FROM ICS_PRMT_REISSU to improve
**                           performance. Add ENABLED='Y' to STEP 3 DELETE's
**                           WHERE clause.
** 10/17/2012    BRensmith   Update KEY_HASH for ICS_PRMT_REISSU to be only
**                           PRMT_IDENT. (Removed PRMT_ISSUE_DATE)
** 11/02/2012    Jen Go      Converted from Oracle to MySQL.
**                           Modularized SP, added logging and error-handling
*******************************************************************************/
   DECLARE v_startdtm
          ,v_enddtm     DATETIME;
   DECLARE v_sp_name    VARCHAR(64)  DEFAULT 'ics_process_accepted_trans';
   DECLARE v_errstat    INT DEFAULT 1;
   DECLARE v_errm       VARCHAR(255);
   DECLARE v_marker     VARCHAR(255);
   -- 
   DECLARE EXIT HANDLER FOR SQLEXCEPTION
      BEGIN  
         ROLLBACK;
         -- SELECT CONCAT('ERROR: ',v_marker); 
         CALL ics_etl_log_sp    
            (v_sp_name          -- pi_sp_name
            ,v_marker           -- pi_marker
            ,NULL               -- pi_tgt_tbl
            ,NULL               -- pi_src_tbl
            ,v_startdtm         -- pi_startdtm
            ,NOW()              -- pi_enddtm
            ,'FAILED'           -- pi_process
            ,-1);               -- pi_value
         COMMIT;
      END;
   SET v_startdtm = NOW();
   -- -----------------------
   -- DELETE FROM ics_etl_log
   -- -----------------------
   SET v_marker = 'DELETE FROM ics_etl_log';
   DELETE FROM ics_etl_log;
   COMMIT;
   -- -----------------------
   -- TMPDEL_ICS_SUBM_RESULTS
   -- -----------------------
   /* JENTMP
   -- CTAS here, so will be able to rollback;
   SET v_marker = 'DROP TABLE IF EXISTS TMPDEL_ICS_SUBM_RESULTS';
   DROP TABLE IF EXISTS TMPDEL_ICS_SUBM_RESULTS;
   CREATE TABLE TMPDEL_ICS_SUBM_RESULTS AS
   SELECT payload.OPERATION
         ,rslt.KEY_HASH
         ,rslt.SUBM_TRANSACTION_ID
     FROM ICS_SUBM_RESULTS rslt
     JOIN ICS_PAYLOAD payload
       ON payload.OPERATION = rslt.SUBM_TYPE_NAME
    WHERE 1=0;
   -- ------------------------
   -- ics_pat_ics_subm_results
   -- ------------------------
   SET v_marker = 'CALL ics_pat_ics_subm_results';
   CALL ics_pat_ics_subm_results(pi_transaction_id,v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
  */
   -- ----------------------
   -- ics_pat_ics_basic_prmt
   -- ----------------------
   SET v_marker = 'CALL ics_pat_ics_basic_prmt';
   CALL ics_pat_ics_basic_prmt(pi_transaction_id,v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF; 
   -- -------------------
   -- ics_pat_ics_bs_prmt
   -- -------------------
   SET v_marker = 'CALL ics_pat_ics_bs_prmt';
   CALL ics_pat_ics_bs_prmt(pi_transaction_id,v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- ---------------------
   -- ics_pat_ics_cafo_prmt
   -- ---------------------
   SET v_marker = 'CALL ics_pat_ics_cafo_prmt';
   CALL ics_pat_ics_cafo_prmt(pi_transaction_id,v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- --------------------
   -- ics_pat_ics_cso_prmt
   -- --------------------
   SET v_marker = 'CALL ics_pat_ics_cso_prmt';
   CALL ics_pat_ics_cso_prmt(pi_transaction_id,v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- ---------------------
   -- ics_pat_ics_gnrl_prmt
   -- ---------------------
   SET v_marker = 'CALL ics_pat_ics_gnrl_prmt';
   CALL ics_pat_ics_gnrl_prmt(pi_transaction_id,v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- ----------------------------
   -- ics_pat_ics_master_gnrl_prmt
   -- ----------------------------
   SET v_marker = 'CALL ics_pat_ics_master_gnrl_prmt';
   CALL ics_pat_ics_master_gnrl_prmt(pi_transaction_id,v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- ---------------------
   -- ics_pat_ics_prmt_term
   -- ---------------------
   SET v_marker = 'CALL ics_pat_ics_prmt_term';
   CALL ics_pat_ics_prmt_term(pi_transaction_id,v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- --------------------------
   -- ics_pat_ics_prmt_track_evt
   -- --------------------------
   SET v_marker = 'CALL ics_pat_ics_prmt_track_evt';
   CALL ics_pat_ics_prmt_track_evt(pi_transaction_id,v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- -----------------------
   -- ics_pat_ics_prmt_reissu
   -- -----------------------
   SET v_marker = 'CALL ics_pat_ics_prmt_reissu';
   CALL ics_pat_ics_prmt_reissu(pi_transaction_id,v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- ---------------------
   -- ics_pat_ics_potw_prmt
   -- ---------------------
   SET v_marker = 'CALL ics_pat_ics_potw_prmt';
   CALL ics_pat_ics_potw_prmt(pi_transaction_id,v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- ----------------------
   -- ics_pat_ics_pretr_prmt
   -- ----------------------
   SET v_marker = 'CALL ics_pat_ics_pretr_prmt';
   CALL ics_pat_ics_pretr_prmt(pi_transaction_id,v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- ------------------------
   -- ics_pat_ics_sw_cnst_prmt
   -- ------------------------
   SET v_marker = 'CALL ics_pat_ics_sw_cnst_prmt';
   CALL ics_pat_ics_sw_cnst_prmt(pi_transaction_id,v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- -------------------------
   -- ics_pat_ics_sw_indst_prmt
   -- -------------------------
   SET v_marker = 'CALL ics_pat_ics_sw_indst_prmt';
   CALL ics_pat_ics_sw_indst_prmt(pi_transaction_id,v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- -----------------------------
   -- ics_pat_ics_swms_4_large_prmt
   -- -----------------------------
   SET v_marker = 'CALL ics_pat_ics_swms_4_large_prmt';
   CALL ics_pat_ics_swms_4_large_prmt(pi_transaction_id,v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- -----------------------------
   -- ics_pat_ics_swms_4_small_prmt
   -- -----------------------------
   SET v_marker = 'CALL ics_pat_ics_swms_4_small_prmt';
   CALL ics_pat_ics_swms_4_small_prmt(pi_transaction_id,v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- ----------------------
   -- ICS_PAT_ICS_UNPRMT_FAC
   -- ----------------------
   SET v_marker = 'CALL ics_pat_ics_unprmt_fac';
   CALL ics_pat_ics_unprmt_fac(pi_transaction_id,v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- -------------------------------
   -- ics_pat_ics_hist_prmt_schd_evts
   -- -------------------------------
   SET v_marker = 'CALL ics_pat_ics_hist_prmt_schd_evts';
   CALL ics_pat_ics_hist_prmt_schd_evts(pi_transaction_id,v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- --------------------------
   -- ics_pat_ics_narr_cond_schd
   -- --------------------------
   SET v_marker = 'CALL ics_pat_ics_narr_cond_schd';
   CALL ics_pat_ics_narr_cond_schd(pi_transaction_id,v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- ----------------------
   -- ics_pat_ics_prmt_featr
   -- ----------------------
   SET v_marker = 'CALL ics_pat_ics_prmt_featr';
   CALL ics_pat_ics_prmt_featr(pi_transaction_id,v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- -------------------
   -- ics_pat_ics_lmt_set
   -- -------------------
   SET v_marker = 'CALL ics_pat_ics_lmt_set';
   CALL ics_pat_ics_lmt_set(pi_transaction_id,v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- ----------------
   -- ics_pat_ics_lmts
   -- ----------------
   SET v_marker = 'CALL ics_pat_ics_lmts';
   CALL ics_pat_ics_lmts(pi_transaction_id,v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- ----------------------
   -- ics_pat_ics_param_lmts
   -- ----------------------
   SET v_marker = 'CALL ics_pat_ics_param_lmts';
   CALL ics_pat_ics_param_lmts(pi_transaction_id,v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- ------------------------
   -- ics_pat_ics_dsch_mon_rep
   -- ------------------------
   SET v_marker = 'CALL ics_pat_ics_dsch_mon_rep';
   CALL ics_pat_ics_dsch_mon_rep(pi_transaction_id,v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- --------------------
   -- ics_pat_ics_cmpl_mon
   -- --------------------
   SET v_marker = 'CALL ics_pat_ics_cmpl_mon';
   CALL ics_pat_ics_cmpl_mon(pi_transaction_id,v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- ------------------------------
   -- ics_pat_ics_efflu_trade_prtner
   -- ------------------------------
   SET v_marker = 'CALL ics_pat_ics_efflu_trade_prtner';
   CALL ics_pat_ics_efflu_trade_prtner(pi_transaction_id,v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- ---------------------------
   -- ics_pat_ics_frml_enfrc_actn
   -- ---------------------------
   SET v_marker = 'CALL ics_pat_ics_frml_enfrc_actn';
   CALL ics_pat_ics_frml_enfrc_actn(pi_transaction_id,v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- -----------------------------
   -- ics_pat_ics_infrml_enfrc_actn
   -- -----------------------------
   SET v_marker = 'CALL ics_pat_ics_infrml_enfrc_actn';
   CALL ics_pat_ics_infrml_enfrc_actn(pi_transaction_id,v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- ---------------------
   -- ics_pat_ics_cmpl_schd
   -- ---------------------
   SET v_marker = 'CALL ics_pat_ics_cmpl_schd';
   CALL ics_pat_ics_cmpl_schd(pi_transaction_id,v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- --------------------------------
   -- ics_pat_ics_enfrc_actn_milestone
   -- --------------------------------
   SET v_marker = 'CALL ics_pat_ics_enfrc_actn_milestone';
   CALL ics_pat_ics_enfrc_actn_milestone(pi_transaction_id,v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- --------------------
   -- ics_pat_ics_dmr_viol
   -- --------------------
   SET v_marker = 'CALL ics_pat_ics_dmr_viol';
   CALL ics_pat_ics_dmr_viol(pi_transaction_id,v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- -------------------------
   -- ics_pat_ics_sngl_evt_viol
   -- -------------------------
   SET v_marker = 'CALL ics_pat_ics_sngl_evt_viol';
   CALL ics_pat_ics_sngl_evt_viol(pi_transaction_id,v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- -----------------------
   -- ics_pat_ics_cso_evt_rep
   -- -----------------------
   SET v_marker = 'CALL ics_pat_ics_cso_evt_rep';
   CALL ics_pat_ics_cso_evt_rep(pi_transaction_id,v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- ----------------------
   -- ics_pat_ics_sw_evt_rep
   -- ----------------------
   SET v_marker = 'CALL ics_pat_ics_sw_evt_rep';
   CALL ics_pat_ics_sw_evt_rep(pi_transaction_id,v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- --------------------------
   -- ics_pat_ics_cafo_annul_rep
   -- --------------------------
   SET v_marker = 'CALL ics_pat_ics_cafo_annul_rep';
   CALL ics_pat_ics_cafo_annul_rep(pi_transaction_id,v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- -----------------------------
   -- ics_pat_ics_loc_lmts_prog_rep
   -- -----------------------------
   SET v_marker = 'CALL ics_pat_ics_loc_lmts_prog_rep';
   CALL ics_pat_ics_loc_lmts_prog_rep(pi_transaction_id,v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- ---------------------------
   -- ics_pat_ics_pretr_perf_summ
   -- ---------------------------
   SET v_marker = 'CALL ics_pat_ics_pretr_perf_summ';
   CALL ics_pat_ics_pretr_perf_summ(pi_transaction_id,v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- -----------------------
   -- ics_pat_ics_bs_prog_rep
   -- -----------------------
   SET v_marker = 'CALL ics_pat_ics_bs_prog_rep';
   CALL ics_pat_ics_bs_prog_rep(pi_transaction_id,v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- -------------------------
   -- ics_pat_ics_sso_annul_rep
   -- -------------------------
   SET v_marker = 'CALL ics_pat_ics_sso_annul_rep';
   CALL ics_pat_ics_sso_annul_rep(pi_transaction_id,v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- -----------------------
   -- ics_pat_ics_sso_evt_rep
   -- -----------------------
   SET v_marker = 'CALL ics_pat_ics_sso_evt_rep';
   CALL ics_pat_ics_sso_evt_rep(pi_transaction_id,v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- -------------------------------
   -- ics_pat_ics_sso_monthly_evt_rep
   -- -------------------------------
   SET v_marker = 'CALL ics_pat_ics_sso_monthly_evt_rep';
   CALL ics_pat_ics_sso_monthly_evt_rep(pi_transaction_id,v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- ---------------------------
   -- ics_pat_ics_swms_4_prog_rep
   -- ---------------------------
   SET v_marker = 'CALL ics_pat_ics_swms_4_prog_rep';
   CALL ics_pat_ics_swms_4_prog_rep(pi_transaction_id,v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- ------------------------
   -- ics_pat_ics_cmpl_mon_lnk
   -- ------------------------
   SET v_marker = 'CALL ics_pat_ics_cmpl_mon_lnk';
   CALL ics_pat_ics_cmpl_mon_lnk(pi_transaction_id,v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- -------------------------------
   -- ics_pat_ics_enfrc_actn_viol_lnk
   -- -------------------------------
   SET v_marker = 'CALL ics_pat_ics_enfrc_actn_viol_lnk';
   CALL ics_pat_ics_enfrc_actn_viol_lnk(pi_transaction_id,v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- -------------------------
   -- ics_pat_ics_schd_evt_viol
   -- -------------------------
   SET v_marker = 'CALL ics_pat_ics_schd_evt_viol';
   CALL ics_pat_ics_schd_evt_viol(pi_transaction_id,v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- ----------------------------
   -- ics_pat_ics_dmr_prog_rep_lnk
   -- ----------------------------
   SET v_marker = 'CALL ics_pat_ics_dmr_prog_rep_lnk';
   CALL ics_pat_ics_dmr_prog_rep_lnk(pi_transaction_id,v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- -----------------------
   -- ics_pat_insrt_icis_tbls
   -- -----------------------
   SET v_marker = 'CALL ics_pat_insrt_icis_tbls';
   CALL ics_pat_insrt_icis_tbls(pi_transaction_id,v_errstat,v_errm);
   IF v_errstat < 0 THEN
      CALL raise_err;
   END IF;
   -- --------- --
   -- ENDS HERE --
   -- --------- --
   SET v_marker = 'CALL ics_etl_log_sp end';
   CALL ics_etl_log_sp    
      (v_sp_name          -- pi_sp_name
      ,v_sp_name          -- pi_marker
      ,NULL               -- pi_tgt_tbl
      ,NULL               -- pi_src_tbl
      ,v_startdtm         -- pi_startdtm
      ,NOW()              -- pi_enddtm
      ,'COMPLETED'        -- pi_process
      ,0);                -- pi_value
   --
   COMMIT;
   --   
END