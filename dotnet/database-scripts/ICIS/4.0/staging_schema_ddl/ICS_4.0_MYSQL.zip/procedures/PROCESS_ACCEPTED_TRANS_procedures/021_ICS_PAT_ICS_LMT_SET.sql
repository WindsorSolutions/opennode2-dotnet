USE ga_ics_flow_local;
DROP PROCEDURE IF EXISTS ics_pat_ics_lmt_set;
CREATE PROCEDURE ics_pat_ics_lmt_set
   (IN  pi_transaction_id  VARCHAR(40)
   ,OUT po_status INT
   ,OUT po_errm   VARCHAR(255))
BEGIN
/******************************************************************************
** Object Name: ics_pat_ics_lmt_set
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  1) Process ICS_LMT_SET
**                  called by: ics_process_accepted_trans
**
** Revision History:
** ----------------------------------------------------------------------------
**  Date         Name        Description
** ----------------------------------------------------------------------------
** 20121102      JenGo       Converted from Oracle to MySQL.
**                           Modularized SP, added logging and error-handling
**                           called by: ICS_PROCESS_ACCEPTED_TRANS
** 20121106      JenGo       Modified DELETE FROM ga_ics_flow_icis.ICS_BASIC_PRMT
**                           MySQL errors out when the table being deleted is 
**                           used in the subquery.  To get around this either
**                           create a temp table or enclose the subquery in an
**                           inline view.  
*******************************************************************************/
   DECLARE v_startdtm
          ,v_enddtm     DATETIME;
   DECLARE v_sp_name    VARCHAR(64)  DEFAULT 'ics_pat_ics_lmt_set';
   DECLARE v_errstat    INT DEFAULT 1;
   DECLARE v_errm       VARCHAR(255);
   DECLARE v_marker     VARCHAR(255);
   --
   DECLARE EXIT HANDLER FOR SQLEXCEPTION
      BEGIN  
         ROLLBACK;
         SET po_status = -1;
         SET po_errm   = v_marker;
         CALL ics_etl_log_sp    
            (v_sp_name          -- pi_sp_name
            ,v_marker           -- pi_marker
            ,NULL               -- pi_tgt_tbl
            ,NULL               -- pi_src_tbl
            ,v_startdtm         -- pi_startdtm
            ,NOW()              -- pi_enddtm
            ,'FAILED'           -- pi_process
            ,-1);               -- pi_value
         COMMIT;
      END;
   --
   SET v_startdtm = NOW();

-- Remove any old records for ICS_LMT_SET
-- /ICS_LMT_SET/ICS_LMT_SET_MONTHS_APPL
SET v_marker = 'DELETE FROM -- /ICS_LMT_SET/ICS_LMT_SET_MONTHS_APPL'; 
DELETE
  FROM ga_ics_flow_icis.ICS_LMT_SET_MONTHS_APPL
 WHERE ICS_LMT_SET_MONTHS_APPL.ICS_LMT_SET_ID IN
          (SELECT ICS_LMT_SET.ICS_LMT_SET_ID
             FROM ga_ics_flow_icis.ICS_LMT_SET
                 LEFT JOIN ICS_SUBM_RESULTS ON ICS_SUBM_RESULTS.KEY_HASH = ICS_LMT_SET.KEY_HASH 
              WHERE (RESULT_TYPE_CODE IN ('Accepted','Warning') AND SUBM_TYPE_NAME = 'LimitSetSubmission')
                 OR ICS_LMT_SET.PRMT_IDENT IN (SELECT PRMT_IDENT FROM ICS_SUBM_RESULTS WHERE SUBM_TYPE_NAME = 'PermitReissuanceSubmission' AND RESULT_TYPE_CODE = 'Accepted')
                 OR ICS_LMT_SET.PRMT_IDENT IN (SELECT PRMT_IDENT FROM ICS_SUBM_RESULTS WHERE SUBM_TYPE_NAME = 'PermitTerminationSubmission' AND RESULT_TYPE_CODE = 'Accepted')
);
-- /ICS_LMT_SET/ICS_LMT_SET_SCHD
SET v_marker = 'DELETE FROM -- /ICS_LMT_SET/ICS_LMT_SET_SCHD'; 
DELETE
  FROM ga_ics_flow_icis.ICS_LMT_SET_SCHD
 WHERE ICS_LMT_SET_SCHD.ICS_LMT_SET_ID IN
          (SELECT ICS_LMT_SET.ICS_LMT_SET_ID
             FROM ga_ics_flow_icis.ICS_LMT_SET
                 LEFT JOIN ICS_SUBM_RESULTS ON ICS_SUBM_RESULTS.KEY_HASH = ICS_LMT_SET.KEY_HASH 
              WHERE (RESULT_TYPE_CODE IN ('Accepted','Warning') AND SUBM_TYPE_NAME = 'LimitSetSubmission')
                 OR ICS_LMT_SET.PRMT_IDENT IN (SELECT PRMT_IDENT FROM ICS_SUBM_RESULTS WHERE SUBM_TYPE_NAME = 'PermitReissuanceSubmission' AND RESULT_TYPE_CODE = 'Accepted')
                 OR ICS_LMT_SET.PRMT_IDENT IN (SELECT PRMT_IDENT FROM ICS_SUBM_RESULTS WHERE SUBM_TYPE_NAME = 'PermitTerminationSubmission' AND RESULT_TYPE_CODE = 'Accepted')
);
-- /ICS_LMT_SET/ICS_LMT_SET_STAT
SET v_marker = 'DELETE FROM -- /ICS_LMT_SET/ICS_LMT_SET_STAT'; 
DELETE
  FROM ga_ics_flow_icis.ICS_LMT_SET_STAT
 WHERE ICS_LMT_SET_STAT.ICS_LMT_SET_ID IN
          (SELECT ICS_LMT_SET.ICS_LMT_SET_ID
             FROM ga_ics_flow_icis.ICS_LMT_SET
                 LEFT JOIN ICS_SUBM_RESULTS ON ICS_SUBM_RESULTS.KEY_HASH = ICS_LMT_SET.KEY_HASH 
              WHERE (RESULT_TYPE_CODE IN ('Accepted','Warning') AND SUBM_TYPE_NAME = 'LimitSetSubmission')
                 OR ICS_LMT_SET.PRMT_IDENT IN (SELECT PRMT_IDENT FROM ICS_SUBM_RESULTS WHERE SUBM_TYPE_NAME = 'PermitReissuanceSubmission' AND RESULT_TYPE_CODE = 'Accepted')
                 OR ICS_LMT_SET.PRMT_IDENT IN (SELECT PRMT_IDENT FROM ICS_SUBM_RESULTS WHERE SUBM_TYPE_NAME = 'PermitTerminationSubmission' AND RESULT_TYPE_CODE = 'Accepted')
);

-- 20121106
-- /ICS_LMT_SET
SET v_marker = 'DELETE FROM -- /ICS_LMT_SET'; 
DELETE
  FROM ga_ics_flow_icis.ICS_LMT_SET
 WHERE ICS_LMT_SET.ICS_LMT_SET_ID IN
          (SELECT ICS_LMT_SET_ID
             FROM (SELECT ICS_LMT_SET.ICS_LMT_SET_ID
                     FROM ga_ics_flow_icis.ICS_LMT_SET
                     LEFT JOIN ICS_SUBM_RESULTS ON ICS_SUBM_RESULTS.KEY_HASH = ICS_LMT_SET.KEY_HASH 
                    WHERE (    RESULT_TYPE_CODE IN ('Accepted','Warning') 
                           AND SUBM_TYPE_NAME = 'LimitSetSubmission')
                       OR ICS_LMT_SET.PRMT_IDENT IN (SELECT PRMT_IDENT 
                                                       FROM ICS_SUBM_RESULTS 
                                                      WHERE SUBM_TYPE_NAME = 'PermitReissuanceSubmission' 
                                                        AND RESULT_TYPE_CODE = 'Accepted')
                       OR ICS_LMT_SET.PRMT_IDENT IN (SELECT PRMT_IDENT 
                                                       FROM ICS_SUBM_RESULTS 
                                                      WHERE SUBM_TYPE_NAME = 'PermitTerminationSubmission' 
                                                        AND RESULT_TYPE_CODE = 'Accepted')
                  ) vw
);
-- 20121106

-- Add accepted records for ICS_LMT_SET
-- /ICS_LMT_SET
SET v_marker = 'INSERT INTO -- /ICS_LMT_SET'; 
INSERT INTO ga_ics_flow_icis.ICS_LMT_SET
     SELECT ICS_LMT_SET.*
       FROM ICS_LMT_SET
       WHERE ICS_LMT_SET.TRANSACTION_TYPE NOT IN ('D','X')
        AND KEY_HASH IN 
              (SELECT KEY_HASH
                 FROM ICS_SUBM_RESULTS
                WHERE RESULT_TYPE_CODE IN ('Accepted','Warning')
                  AND SUBM_TYPE_NAME = 'LimitSetSubmission');

-- /ICS_LMT_SET/ICS_LMT_SET_MONTHS_APPL
SET v_marker = 'INSERT INTO -- /ICS_LMT_SET/ICS_LMT_SET_MONTHS_APPL'; 
INSERT INTO ga_ics_flow_icis.ICS_LMT_SET_MONTHS_APPL
     SELECT ICS_LMT_SET_MONTHS_APPL.*
       FROM ICS_LMT_SET_MONTHS_APPL
          JOIN ICS_LMT_SET
            ON ICS_LMT_SET_MONTHS_APPL.ICS_LMT_SET_ID = ICS_LMT_SET.ICS_LMT_SET_ID
       WHERE ICS_LMT_SET.TRANSACTION_TYPE NOT IN ('D','X')
        AND KEY_HASH IN 
              (SELECT KEY_HASH
                 FROM ICS_SUBM_RESULTS
                WHERE RESULT_TYPE_CODE IN ('Accepted','Warning')
                  AND SUBM_TYPE_NAME = 'LimitSetSubmission');

-- /ICS_LMT_SET/ICS_LMT_SET_SCHD
SET v_marker = 'INSERT INTO -- /ICS_LMT_SET/ICS_LMT_SET_SCHD'; 
INSERT INTO ga_ics_flow_icis.ICS_LMT_SET_SCHD
     SELECT ICS_LMT_SET_SCHD.*
       FROM ICS_LMT_SET_SCHD
          JOIN ICS_LMT_SET
            ON ICS_LMT_SET_SCHD.ICS_LMT_SET_ID = ICS_LMT_SET.ICS_LMT_SET_ID
       WHERE ICS_LMT_SET.TRANSACTION_TYPE NOT IN ('D','X')
        AND KEY_HASH IN 
              (SELECT KEY_HASH
                 FROM ICS_SUBM_RESULTS
                WHERE RESULT_TYPE_CODE IN ('Accepted','Warning')
                  AND SUBM_TYPE_NAME = 'LimitSetSubmission');

-- /ICS_LMT_SET/ICS_LMT_SET_STAT
SET v_marker = 'INSERT INTO -- /ICS_LMT_SET/ICS_LMT_SET_STAT'; 
INSERT INTO ga_ics_flow_icis.ICS_LMT_SET_STAT
     SELECT ICS_LMT_SET_STAT.*
       FROM ICS_LMT_SET_STAT
          JOIN ICS_LMT_SET
            ON ICS_LMT_SET_STAT.ICS_LMT_SET_ID = ICS_LMT_SET.ICS_LMT_SET_ID
       WHERE ICS_LMT_SET.TRANSACTION_TYPE NOT IN ('D','X')
        AND KEY_HASH IN 
              (SELECT KEY_HASH
                 FROM ICS_SUBM_RESULTS
                WHERE RESULT_TYPE_CODE IN ('Accepted','Warning')
                  AND SUBM_TYPE_NAME = 'LimitSetSubmission');

   -- -------------- --
   --  END PROCEDURE --
   -- -------------- --
   SET v_marker = 'CALL ics_etl_log_sp END';
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_sp_name     -- pi_marker
      ,NULL          -- pi_tgt_tbl
      ,NULL          -- pi_src_tbl 
      ,v_startdtm    -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'COMPLETED'   -- pi_process
      ,0);           -- pi_value
   --
   SET po_status = 1;
   SET po_errm   = '';
   -- 
END   