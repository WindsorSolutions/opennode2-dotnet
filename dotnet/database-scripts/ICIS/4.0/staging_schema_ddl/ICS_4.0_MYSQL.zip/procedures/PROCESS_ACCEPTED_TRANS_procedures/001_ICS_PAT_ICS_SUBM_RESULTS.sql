USE ga_ics_flow_local;
DROP PROCEDURE IF EXISTS ics_pat_ics_subm_results;
CREATE PROCEDURE ics_pat_ics_subm_results
   (IN  pi_transaction_id  VARCHAR(40)
   ,OUT po_status          INT
   ,OUT po_errm            VARCHAR(255))
BEGIN
/******************************************************************************
** Object Name: ics_pat_ics_subm_results
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  1) Process ICS_SUBM_RESULTS by PAYLOAD
**                  called by: ICS_PROCESS_ACCEPTED_TRANS
**
** Revision History:
** ----------------------------------------------------------------------------
**  Date         Name        Description
** ----------------------------------------------------------------------------
** 20121102      JenGo       Converted from Oracle to MySQL.
**                           Modularized SP, added logging and error-handling
**                           COALESCE before CONCATatening before hashing.
**                           called by: ICS_PROCESS_ACCEPTED_TRANS
** 20121106      JenGo       Created a temp table (TMPDEL_ICS_SUBM_RESULTS) to 
**                           hold all the records to be deleted.  
**                           MySQL errors out when the table being deleted is 
**                           used in the subquery.  To get around this either
**                           create a temp table or enclose the subquery in an
**                           inline view.  
*******************************************************************************/
   DECLARE v_startdtm
          ,v_enddtm     DATETIME;
   DECLARE v_sp_name    VARCHAR(64)  DEFAULT 'ics_pat_ics_subm_results';
   DECLARE v_errstat    INT DEFAULT 1;
   DECLARE v_errm       VARCHAR(255);
   DECLARE v_marker     VARCHAR(255);
   --
   DECLARE EXIT HANDLER FOR SQLEXCEPTION
      BEGIN  
         ROLLBACK;
         SET po_status = -1;
         SET po_errm   = v_marker;
         SELECT CONCAT('ERROR: ',v_marker);
         CALL ics_etl_log_sp    
            (v_sp_name          -- pi_sp_name
            ,v_marker           -- pi_marker
            ,NULL               -- pi_tgt_tbl
            ,NULL               -- pi_src_tbl
            ,v_startdtm         -- pi_startdtm
            ,NOW()              -- pi_enddtm
            ,'FAILED'           -- pi_process
            ,-1);               -- pi_value
         COMMIT;
      END;
   --
   SET v_startdtm = NOW();
   --
   -- Step 1: Remove any previous accepted transactions so
   --         the procedure does not attempt to move records
   --         from previous executions.
SET v_marker = 'DELETE FROM ICS_SUBM_RESULTS START';
DELETE FROM ICS_SUBM_RESULTS 
 WHERE RESULT_TYPE_CODE IN ('Accepted','Warning')
   AND SUBM_TRANSACTION_ID <> pi_transaction_id;
 
-- Step 2: Update KEY_HASH with hashed business key data
SET v_marker = 'UPDATE ICS_SUBM_RESULTS - BasicPermitSubmission'; 
UPDATE ICS_SUBM_RESULTS
   SET KEY_HASH = MD5(PRMT_IDENT)
 WHERE SUBM_TYPE_NAME = 'BasicPermitSubmission'
   AND SUBM_TRANSACTION_ID = pi_transaction_id;

SET v_marker = 'UPDATE ICS_SUBM_RESULTS - BiosolidsPermitSubmission'; 
UPDATE ICS_SUBM_RESULTS
   SET KEY_HASH = MD5(PRMT_IDENT)
 WHERE SUBM_TYPE_NAME = 'BiosolidsPermitSubmission'
   AND SUBM_TRANSACTION_ID = pi_transaction_id;

SET v_marker = 'UPDATE ICS_SUBM_RESULTS - CAFOPermitSubmission';  
UPDATE ICS_SUBM_RESULTS
   SET KEY_HASH = MD5(PRMT_IDENT)
 WHERE SUBM_TYPE_NAME = 'CAFOPermitSubmission'
   AND SUBM_TRANSACTION_ID = pi_transaction_id;

SET v_marker = 'UPDATE ICS_SUBM_RESULTS - CSOPermitSubmission';  
UPDATE ICS_SUBM_RESULTS
   SET KEY_HASH = MD5(PRMT_IDENT)
 WHERE SUBM_TYPE_NAME = 'CSOPermitSubmission'
   AND SUBM_TRANSACTION_ID = pi_transaction_id;

SET v_marker = 'UPDATE ICS_SUBM_RESULTS - GeneralPermitSubmission';  
UPDATE ICS_SUBM_RESULTS
   SET KEY_HASH = MD5(PRMT_IDENT)
 WHERE SUBM_TYPE_NAME = 'GeneralPermitSubmission'
   AND SUBM_TRANSACTION_ID = pi_transaction_id;

SET v_marker = 'UPDATE ICS_SUBM_RESULTS - MasterGeneralPermitSubmission';  
UPDATE ICS_SUBM_RESULTS
   SET KEY_HASH = MD5(PRMT_IDENT)
 WHERE SUBM_TYPE_NAME = 'MasterGeneralPermitSubmission'
   AND SUBM_TRANSACTION_ID = pi_transaction_id;

SET v_marker = 'UPDATE ICS_SUBM_RESULTS - PermitReissuanceSubmission';  
UPDATE ICS_SUBM_RESULTS
   SET KEY_HASH = MD5(PRMT_IDENT)
 WHERE SUBM_TYPE_NAME = 'PermitReissuanceSubmission'
   AND SUBM_TRANSACTION_ID = pi_transaction_id;

SET v_marker = 'UPDATE ICS_SUBM_RESULTS - PermitTerminationSubmission';  
UPDATE ICS_SUBM_RESULTS
   SET KEY_HASH = MD5(PRMT_IDENT)
 WHERE SUBM_TYPE_NAME = 'PermitTerminationSubmission'
   AND SUBM_TRANSACTION_ID = pi_transaction_id;

SET v_marker = 'UPDATE ICS_SUBM_RESULTS - PermitTrackingEventSubmission';  
UPDATE ICS_SUBM_RESULTS
   SET KEY_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-'),COALESCE(PRMT_TRACK_EVT_CODE,'-*-'),COALESCE(PRMT_TRACK_EVT_DATE,'-*-')),'-*-',''))
 WHERE SUBM_TYPE_NAME = 'PermitTrackingEventSubmission'
   AND SUBM_TRANSACTION_ID = pi_transaction_id;

SET v_marker = 'UPDATE ICS_SUBM_RESULTS - POTWPermitSubmission';  
UPDATE ICS_SUBM_RESULTS
   SET KEY_HASH = MD5(PRMT_IDENT)
 WHERE SUBM_TYPE_NAME = 'POTWPermitSubmission'
   AND SUBM_TRANSACTION_ID = pi_transaction_id;

SET v_marker = 'UPDATE ICS_SUBM_RESULTS - PretreatmentPermitSubmission';  
UPDATE ICS_SUBM_RESULTS
   SET KEY_HASH = MD5(PRMT_IDENT)
 WHERE SUBM_TYPE_NAME = 'PretreatmentPermitSubmission'
   AND SUBM_TRANSACTION_ID = pi_transaction_id;

SET v_marker = 'UPDATE ICS_SUBM_RESULTS - SWConstructionPermitSubmission';  
UPDATE ICS_SUBM_RESULTS
   SET KEY_HASH = MD5(PRMT_IDENT)
 WHERE SUBM_TYPE_NAME = 'SWConstructionPermitSubmission'
   AND SUBM_TRANSACTION_ID = pi_transaction_id;

SET v_marker = 'UPDATE ICS_SUBM_RESULTS - SWIndustrialPermitSubmission';  
UPDATE ICS_SUBM_RESULTS
   SET KEY_HASH = MD5(PRMT_IDENT)
 WHERE SUBM_TYPE_NAME = 'SWIndustrialPermitSubmission'
   AND SUBM_TRANSACTION_ID = pi_transaction_id;

SET v_marker = 'UPDATE ICS_SUBM_RESULTS - SWMS4LargePermitSubmission';  
UPDATE ICS_SUBM_RESULTS
   SET KEY_HASH = MD5(PRMT_IDENT)
 WHERE SUBM_TYPE_NAME = 'SWMS4LargePermitSubmission'
   AND SUBM_TRANSACTION_ID = pi_transaction_id;

SET v_marker = 'UPDATE ICS_SUBM_RESULTS - SWMS4SmallPermitSubmission';  
UPDATE ICS_SUBM_RESULTS
   SET KEY_HASH = MD5(PRMT_IDENT)
 WHERE SUBM_TYPE_NAME = 'SWMS4SmallPermitSubmission'
   AND SUBM_TRANSACTION_ID = pi_transaction_id;

SET v_marker = 'UPDATE ICS_SUBM_RESULTS - UnpermittedFacilitySubmission';  
UPDATE ICS_SUBM_RESULTS
   SET KEY_HASH = MD5(PRMT_IDENT)
 WHERE SUBM_TYPE_NAME = 'UnpermittedFacilitySubmission'
   AND SUBM_TRANSACTION_ID = pi_transaction_id;

SET v_marker = 'UPDATE ICS_SUBM_RESULTS - HistoricalPermitScheduleEventsSubmission';  
UPDATE ICS_SUBM_RESULTS
   SET KEY_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-'),COALESCE(PRMT_EFFECTIVE_DATE,'-*-'),COALESCE(NARR_COND_NUM,'-*-'),COALESCE(SCHD_EVT_CODE,'-*-'),COALESCE(SCHD_DATE,'-*-'),COALESCE(NARR_COND_NUM,'-*-'),COALESCE(SCHD_EVT_CODE,'-*-'),COALESCE(SCHD_DATE,'-*-')),'-*-',''))
 WHERE SUBM_TYPE_NAME = 'HistoricalPermitScheduleEventsSubmission'
   AND SUBM_TRANSACTION_ID = pi_transaction_id;

SET v_marker = 'UPDATE ICS_SUBM_RESULTS - NarrativeConditionScheduleSubmission';  
UPDATE ICS_SUBM_RESULTS
   SET KEY_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-'),COALESCE(NARR_COND_NUM,'-*-')),'-*-',''))
 WHERE SUBM_TYPE_NAME = 'NarrativeConditionScheduleSubmission'
   AND SUBM_TRANSACTION_ID = pi_transaction_id;

SET v_marker = 'UPDATE ICS_SUBM_RESULTS - PermittedFeatureSubmission';  
UPDATE ICS_SUBM_RESULTS
   SET KEY_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-'),COALESCE(PRMT_FEATR_IDENT,'-*-')),'-*-',''))
 WHERE SUBM_TYPE_NAME = 'PermittedFeatureSubmission'
   AND SUBM_TRANSACTION_ID = pi_transaction_id;

SET v_marker = 'UPDATE ICS_SUBM_RESULTS - LimitSetSubmission';  
UPDATE ICS_SUBM_RESULTS
   SET KEY_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-'),COALESCE(PRMT_FEATR_IDENT,'-*-'),COALESCE(LMT_SET_DESIGNATOR,'-*-')),'-*-',''))
 WHERE SUBM_TYPE_NAME = 'LimitSetSubmission'
   AND SUBM_TRANSACTION_ID = pi_transaction_id;

SET v_marker = 'UPDATE ICS_SUBM_RESULTS - LimitsSubmission';  
UPDATE ICS_SUBM_RESULTS
   SET KEY_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-'),COALESCE(PRMT_FEATR_IDENT,'-*-'),COALESCE(LMT_SET_DESIGNATOR,'-*-'),COALESCE(PARAM_CODE,'-*-'),COALESCE(MON_SITE_DESC_CODE,'-*-'),COALESCE(LMT_SEASON_NUM,'-*-'),COALESCE(LMT_START_DATE,'-*-'),COALESCE(LMT_END_DATE,'-*-')),'-*-',''))
 WHERE SUBM_TYPE_NAME = 'LimitsSubmission'
   AND SUBM_TRANSACTION_ID = pi_transaction_id;

SET v_marker = 'UPDATE ICS_SUBM_RESULTS - ParameterLimitsSubmission';  
UPDATE ICS_SUBM_RESULTS
   SET KEY_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-'),COALESCE(PRMT_FEATR_IDENT,'-*-'),COALESCE(LMT_SET_DESIGNATOR,'-*-'),COALESCE(PARAM_CODE,'-*-'),COALESCE(MON_SITE_DESC_CODE,'-*-'),COALESCE(LMT_SEASON_NUM,'-*-')),'-*-',''))
 WHERE SUBM_TYPE_NAME = 'ParameterLimitsSubmission'
   AND SUBM_TRANSACTION_ID = pi_transaction_id;

SET v_marker = 'UPDATE ICS_SUBM_RESULTS - DischargeMonitoringReportSubmission';  
UPDATE ICS_SUBM_RESULTS
   SET KEY_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-'),COALESCE(PRMT_FEATR_IDENT,'-*-'),COALESCE(LMT_SET_DESIGNATOR,'-*-'),COALESCE(MON_PERIOD_END_DATE,'-*-')),'-*-',''))
 WHERE SUBM_TYPE_NAME = 'DischargeMonitoringReportSubmission'
   AND SUBM_TRANSACTION_ID = pi_transaction_id;

SET v_marker = 'UPDATE ICS_SUBM_RESULTS - ComplianceMonitoringSubmission';  
UPDATE ICS_SUBM_RESULTS
   SET KEY_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-'),COALESCE(CMPL_MON_CATG_CODE,'-*-'),COALESCE(CMPL_MON_DATE,'-*-')),'-*-',''))
 WHERE SUBM_TYPE_NAME = 'ComplianceMonitoringSubmission'
   AND SUBM_TRANSACTION_ID = pi_transaction_id;

SET v_marker = 'UPDATE ICS_SUBM_RESULTS - EffluentTradePartnerSubmission';  
UPDATE ICS_SUBM_RESULTS
   SET KEY_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-'),COALESCE(PRMT_FEATR_IDENT,'-*-'),COALESCE(LMT_SET_DESIGNATOR,'-*-'),COALESCE(PARAM_CODE,'-*-'),COALESCE(MON_SITE_DESC_CODE,'-*-'),COALESCE(LMT_SEASON_NUM,'-*-'),COALESCE(LMT_START_DATE,'-*-'),COALESCE(LMT_END_DATE,'-*-'),COALESCE(LMT_MOD_EFFECTIVE_DATE,'-*-'),COALESCE(TRADE_ID,'-*-')),'-*-',''))
 WHERE SUBM_TYPE_NAME = 'EffluentTradePartnerSubmission'
   AND SUBM_TRANSACTION_ID = pi_transaction_id;

SET v_marker = 'UPDATE ICS_SUBM_RESULTS - FormalEnforcementActionSubmission';  
UPDATE ICS_SUBM_RESULTS
   SET KEY_HASH = MD5(ENFRC_ACTN_IDENT)
 WHERE SUBM_TYPE_NAME = 'FormalEnforcementActionSubmission'
   AND SUBM_TRANSACTION_ID = pi_transaction_id;

SET v_marker = 'UPDATE ICS_SUBM_RESULTS - InformalEnforcementActionSubmission';  
UPDATE ICS_SUBM_RESULTS
   SET KEY_HASH = MD5(ENFRC_ACTN_IDENT)
 WHERE SUBM_TYPE_NAME = 'InformalEnforcementActionSubmission'
   AND SUBM_TRANSACTION_ID = pi_transaction_id;

SET v_marker = 'UPDATE ICS_SUBM_RESULTS - ComplianceScheduleSubmission';  
UPDATE ICS_SUBM_RESULTS
   SET KEY_HASH = MD5(REPLACE(CONCAT(COALESCE(ENFRC_ACTN_IDENT,'-*-'),COALESCE(FINAL_ORDER_IDENT,'-*-'),COALESCE(PRMT_IDENT,'-*-'),COALESCE(CMPL_SCHD_NUM,'-*-')),'-*-',''))
 WHERE SUBM_TYPE_NAME = 'ComplianceScheduleSubmission'
   AND SUBM_TRANSACTION_ID = pi_transaction_id;

SET v_marker = 'UPDATE ICS_SUBM_RESULTS - EnforcementActionMilestoneSubmission';  
UPDATE ICS_SUBM_RESULTS
   SET KEY_HASH = MD5(REPLACE(CONCAT(COALESCE(ENFRC_ACTN_IDENT,'-*-'),COALESCE(MILESTONE_TYPE_CODE,'-*-')),'-*-',''))
 WHERE SUBM_TYPE_NAME = 'EnforcementActionMilestoneSubmission'
   AND SUBM_TRANSACTION_ID = pi_transaction_id;

SET v_marker = 'UPDATE ICS_SUBM_RESULTS - DMRViolationSubmission';  
UPDATE ICS_SUBM_RESULTS
   SET KEY_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-'),COALESCE(PRMT_FEATR_IDENT,'-*-'),COALESCE(LMT_SET_DESIGNATOR,'-*-'),COALESCE(MON_PERIOD_END_DATE,'-*-'),COALESCE(PARAM_CODE,'-*-'),COALESCE(MON_SITE_DESC_CODE,'-*-'),COALESCE(LMT_SEASON_NUM,'-*-'),COALESCE(NUM_REP_CODE,'-*-'),COALESCE(NUM_REP_VIOL_CODE,'-*-')),'-*-',''))
 WHERE SUBM_TYPE_NAME = 'DMRViolationSubmission'
   AND SUBM_TRANSACTION_ID = pi_transaction_id;

SET v_marker = 'UPDATE ICS_SUBM_RESULTS - SingleEventViolationSubmission';  
UPDATE ICS_SUBM_RESULTS
   SET KEY_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-'),COALESCE(SNGL_EVT_VIOL_CODE,'-*-'),COALESCE(SNGL_EVT_VIOL_DATE,'-*-')),'-*-',''))
 WHERE SUBM_TYPE_NAME = 'SingleEventViolationSubmission'
   AND SUBM_TRANSACTION_ID = pi_transaction_id;

SET v_marker = 'UPDATE ICS_SUBM_RESULTS - CSOEventReportSubmission';  
UPDATE ICS_SUBM_RESULTS
   SET KEY_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-'),COALESCE(CSO_EVT_DATE,'-*-'),COALESCE(EVT_ID,'-*-')),'-*-',''))
 WHERE SUBM_TYPE_NAME = 'CSOEventReportSubmission'
   AND SUBM_TRANSACTION_ID = pi_transaction_id;

SET v_marker = 'UPDATE ICS_SUBM_RESULTS - SWEventReportSubmission';  
UPDATE ICS_SUBM_RESULTS
   SET KEY_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-'),COALESCE(DATE_STRM_EVT_SMPL,'-*-'),COALESCE(EVT_ID,'-*-')),'-*-',''))
 WHERE SUBM_TYPE_NAME = 'SWEventReportSubmission'
   AND SUBM_TRANSACTION_ID = pi_transaction_id;

SET v_marker = 'UPDATE ICS_SUBM_RESULTS - CAFOAnnualReportSubmission';  
UPDATE ICS_SUBM_RESULTS
   SET KEY_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-'),COALESCE(PRMT_AUTH_REP_RCVD_DATE,'-*-')),'-*-',''))
 WHERE SUBM_TYPE_NAME = 'CAFOAnnualReportSubmission'
   AND SUBM_TRANSACTION_ID = pi_transaction_id;

SET v_marker = 'UPDATE ICS_SUBM_RESULTS - LocalLimitsProgramReportSubmission';  
UPDATE ICS_SUBM_RESULTS
   SET KEY_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-'),COALESCE(PRMT_AUTH_REP_RCVD_DATE,'-*-')),'-*-',''))
 WHERE SUBM_TYPE_NAME = 'LocalLimitsProgramReportSubmission'
   AND SUBM_TRANSACTION_ID = pi_transaction_id;

SET v_marker = 'UPDATE ICS_SUBM_RESULTS - PretreatmentPerformanceSummarySubmission';  
UPDATE ICS_SUBM_RESULTS
   SET KEY_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-'),COALESCE(PRETR_PERF_SUMM_END_DATE,'-*-')),'-*-',''))
 WHERE SUBM_TYPE_NAME = 'PretreatmentPerformanceSummarySubmission'
   AND SUBM_TRANSACTION_ID = pi_transaction_id;

SET v_marker = 'UPDATE ICS_SUBM_RESULTS - BiosolidsProgramReportSubmission';  
UPDATE ICS_SUBM_RESULTS
   SET KEY_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-'),COALESCE(REP_COVERAGE_END_DATE,'-*-')),'-*-',''))
 WHERE SUBM_TYPE_NAME = 'BiosolidsProgramReportSubmission'
   AND SUBM_TRANSACTION_ID = pi_transaction_id;

SET v_marker = 'UPDATE ICS_SUBM_RESULTS - SSOAnnualReportSubmission';  
UPDATE ICS_SUBM_RESULTS
   SET KEY_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-'),COALESCE(SSO_ANNUL_REP_RCVD_DATE,'-*-')),'-*-',''))
 WHERE SUBM_TYPE_NAME = 'SSOAnnualReportSubmission'
   AND SUBM_TRANSACTION_ID = pi_transaction_id;

SET v_marker = 'UPDATE ICS_SUBM_RESULTS - SSOEventReportSubmission';  
UPDATE ICS_SUBM_RESULTS
   SET KEY_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-'),COALESCE(SSO_EVT_DATE,'-*-'),COALESCE(EVT_ID,'-*-')),'-*-',''))
 WHERE SUBM_TYPE_NAME = 'SSOEventReportSubmission'
   AND SUBM_TRANSACTION_ID = pi_transaction_id;

SET v_marker = 'UPDATE ICS_SUBM_RESULTS - SSOMonthlyEventReportSubmission';  
UPDATE ICS_SUBM_RESULTS
   SET KEY_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-'),COALESCE(SSO_MONTHLY_REP_RCVD_DATE,'-*-')),'-*-',''))
 WHERE SUBM_TYPE_NAME = 'SSOMonthlyEventReportSubmission'
   AND SUBM_TRANSACTION_ID = pi_transaction_id;

SET v_marker = 'UPDATE ICS_SUBM_RESULTS - SWMS4ProgramReportSubmission';  
UPDATE ICS_SUBM_RESULTS
   SET KEY_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-'),COALESCE(SW_MS_4_REP_RCVD_DATE,'-*-')),'-*-',''))
 WHERE SUBM_TYPE_NAME = 'SWMS4ProgramReportSubmission'
   AND SUBM_TRANSACTION_ID = pi_transaction_id;

SET v_marker = 'UPDATE ICS_SUBM_RESULTS - ComplianceMonitoringLinkageSubmission';  
UPDATE ICS_SUBM_RESULTS
   SET KEY_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-'),COALESCE(CMPL_MON_CATG_CODE,'-*-'),COALESCE(CMPL_MON_DATE,'-*-'),COALESCE(PRMT_IDENT_2,'-*-'),COALESCE(SNGL_EVT_VIOL_CODE,'-*-'),COALESCE(SNGL_EVT_VIOL_DATE,'-*-'),COALESCE(ENFRC_ACTN_IDENT,'-*-'),COALESCE(REP_COVERAGE_END_DATE,'-*-'),COALESCE(PRMT_AUTH_REP_RCVD_DATE,'-*-'),COALESCE(CSO_EVT_DATE,'-*-'),COALESCE(PRETR_PERF_SUMM_END_DATE,'-*-'),COALESCE(SSO_ANNUL_REP_RCVD_DATE,'-*-'),COALESCE(SSO_EVT_DATE,'-*-'),COALESCE(SSO_MONTHLY_REP_RCVD_DATE,'-*-'),COALESCE(DATE_STRM_EVT_SMPL,'-*-'),COALESCE(SW_MS_4_REP_RCVD_DATE,'-*-'),COALESCE(CMPL_MON_CATG_CODE_2,'-*-'),COALESCE(CMPL_MON_DATE_2,'-*-'),COALESCE(EVT_ID,'-*-')),'-*-',''))
 WHERE SUBM_TYPE_NAME = 'ComplianceMonitoringLinkageSubmission'
   AND SUBM_TRANSACTION_ID = pi_transaction_id;

SET v_marker = 'UPDATE ICS_SUBM_RESULTS - EnforcementActionViolationLinkageSubmission';  
UPDATE ICS_SUBM_RESULTS
   SET KEY_HASH = MD5(REPLACE(CONCAT(COALESCE(ENFRC_ACTN_IDENT,'-*-'),COALESCE(PRMT_IDENT,'-*-'),COALESCE(NARR_COND_NUM,'-*-'),COALESCE(SCHD_EVT_CODE,'-*-'),COALESCE(SCHD_DATE,'-*-'),COALESCE(ENFRC_ACTN_IDENT_2,'-*-'),COALESCE(FINAL_ORDER_IDENT,'-*-'),COALESCE(PRMT_IDENT_2,'-*-'),COALESCE(CMPL_SCHD_NUM,'-*-'),COALESCE(PRMT_FEATR_IDENT,'-*-'),COALESCE(LMT_SET_DESIGNATOR,'-*-'),COALESCE(PARAM_CODE,'-*-'),COALESCE(MON_SITE_DESC_CODE,'-*-'),COALESCE(LMT_SEASON_NUM,'-*-'),COALESCE(MON_PERIOD_END_DATE,'-*-'),COALESCE(SNGL_EVT_VIOL_CODE,'-*-'),COALESCE(SNGL_EVT_VIOL_DATE,'-*-')),'-*-',''))
 WHERE SUBM_TYPE_NAME = 'EnforcementActionViolationLinkageSubmission'
   AND SUBM_TRANSACTION_ID = pi_transaction_id;

SET v_marker = 'UPDATE ICS_SUBM_RESULTS - ScheduleEventViolationSubmission';  
UPDATE ICS_SUBM_RESULTS
   SET KEY_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-'),COALESCE(NARR_COND_NUM,'-*-'),COALESCE(SCHD_EVT_CODE,'-*-'),COALESCE(SCHD_DATE,'-*-'),COALESCE(SCHD_VIOL_CODE,'-*-'),COALESCE(ENFRC_ACTN_IDENT,'-*-'),COALESCE(FINAL_ORDER_IDENT,'-*-'),COALESCE(CMPL_SCHD_NUM,'-*-')),'-*-',''))
 WHERE SUBM_TYPE_NAME = 'ScheduleEventViolationSubmission'
   AND SUBM_TRANSACTION_ID = pi_transaction_id;

SET v_marker = 'UPDATE ICS_SUBM_RESULTS - DMRProgramReportLinkageSubmission';  
UPDATE ICS_SUBM_RESULTS
   SET KEY_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-'),COALESCE(PRMT_FEATR_IDENT,'-*-'),COALESCE(LMT_SET_DESIGNATOR,'-*-'),COALESCE(MON_PERIOD_END_DATE,'-*-'),COALESCE(PRMT_IDENT_2,'-*-'),COALESCE(REP_COVERAGE_END_DATE,'-*-'),COALESCE(DATE_STRM_EVT_SMPL,'-*-'),COALESCE(EVT_ID,'-*-')),'-*-',''))
 WHERE SUBM_TYPE_NAME = 'DMRProgramReportLinkageSubmission'
   AND SUBM_TRANSACTION_ID = pi_transaction_id;


-- Step 3: Remove previous error transactions that have were resent in the most 
-- recent transaction. Remove all results for 'full replace' submission types 
-- since all errors will be recreated from the latest ICIS processing report.
-- 
-- JenGo 20121106 - Create tmptbl to hold the records to be deleted
-- MySQL errors out when the table being deleted is used in the subquery.  
-- To get around this, either create a tmp table or an enclose the subquery
-- in an inline view
SET v_marker = 'INSERT INTO TMPDEL_ICS_SUBM_RESULTS';
INSERT INTO TMPDEL_ICS_SUBM_RESULTS
SELECT payload.OPERATION
      ,rslt.KEY_HASH
      ,rslt.SUBM_TRANSACTION_ID
  FROM ICS_SUBM_RESULTS rslt
  JOIN ICS_PAYLOAD payload
    ON payload.OPERATION = rslt.SUBM_TYPE_NAME;
--
-- create index here? - jen??
--

SET v_marker = 'DELETE FROM ICS_SUBM_RESULTS - STEP 3'; 
DELETE
  FROM ICS_SUBM_RESULTS
 WHERE SUBM_TYPE_NAME IN (SELECT OPERATION 
                            FROM ICS_PAYLOAD
                           WHERE AUTO_GEN_DELETES = 'Y'
                             AND ENABLED = 'Y')
   AND SUBM_TRANSACTION_ID <> pi_transaction_id;

 -- Remove old errors that are replaced by new errors with matching business key
 -- in latest processing report. This will only affect 'incremental update' submission types
SET v_marker = 'DELETE FROM ICS_SUBM_RESULTS - BasicPermitSubmission'; 
DELETE
  FROM ICS_SUBM_RESULTS
 WHERE SUBM_TYPE_NAME = 'BasicPermitSubmission'
   AND SUBM_TRANSACTION_ID <> pi_transaction_id
   AND RESULT_TYPE_CODE = 'Error'
   AND KEY_HASH IN
              (SELECT KEY_HASH
                 FROM TMPDEL_ICS_SUBM_RESULTS
                WHERE SUBM_TYPE_NAME = 'BasicPermitSubmission'
                  AND SUBM_TRANSACTION_ID = pi_transaction_id);

SET v_marker = 'DELETE FROM ICS_SUBM_RESULTS - BiosolidsPermitSubmission'; 
DELETE
  FROM ICS_SUBM_RESULTS
 WHERE SUBM_TYPE_NAME = 'BiosolidsPermitSubmission'
   AND SUBM_TRANSACTION_ID <> pi_transaction_id
   AND RESULT_TYPE_CODE = 'Error'
   AND KEY_HASH IN
              (SELECT KEY_HASH
                 FROM TMPDEL_ICS_SUBM_RESULTS
                WHERE SUBM_TYPE_NAME = 'BiosolidsPermitSubmission'
                  AND SUBM_TRANSACTION_ID = pi_transaction_id);

SET v_marker = 'DELETE FROM ICS_SUBM_RESULTS - CAFOPermitSubmission'; 
DELETE
  FROM ICS_SUBM_RESULTS
 WHERE SUBM_TYPE_NAME = 'CAFOPermitSubmission'
   AND SUBM_TRANSACTION_ID <> pi_transaction_id
   AND RESULT_TYPE_CODE = 'Error'
   AND KEY_HASH IN
              (SELECT KEY_HASH
                 FROM TMPDEL_ICS_SUBM_RESULTS
                WHERE SUBM_TYPE_NAME = 'CAFOPermitSubmission'
                  AND SUBM_TRANSACTION_ID = pi_transaction_id);

SET v_marker = 'DELETE FROM ICS_SUBM_RESULTS - CSOPermitSubmission'; 
DELETE
  FROM ICS_SUBM_RESULTS
 WHERE SUBM_TYPE_NAME = 'CSOPermitSubmission'
   AND SUBM_TRANSACTION_ID <> pi_transaction_id
   AND RESULT_TYPE_CODE = 'Error'
   AND KEY_HASH IN
              (SELECT KEY_HASH
                 FROM TMPDEL_ICS_SUBM_RESULTS
                WHERE SUBM_TYPE_NAME = 'CSOPermitSubmission'
                  AND SUBM_TRANSACTION_ID = pi_transaction_id);

SET v_marker = 'DELETE FROM ICS_SUBM_RESULTS - GeneralPermitSubmission'; 
DELETE
  FROM ICS_SUBM_RESULTS
 WHERE SUBM_TYPE_NAME = 'GeneralPermitSubmission'
   AND SUBM_TRANSACTION_ID <> pi_transaction_id
   AND RESULT_TYPE_CODE = 'Error'
   AND KEY_HASH IN
              (SELECT KEY_HASH
                 FROM TMPDEL_ICS_SUBM_RESULTS
                WHERE SUBM_TYPE_NAME = 'GeneralPermitSubmission'
                  AND SUBM_TRANSACTION_ID = pi_transaction_id);

SET v_marker = 'DELETE FROM ICS_SUBM_RESULTS - MasterGeneralPermitSubmission'; 
DELETE
  FROM ICS_SUBM_RESULTS
 WHERE SUBM_TYPE_NAME = 'MasterGeneralPermitSubmission'
   AND SUBM_TRANSACTION_ID <> pi_transaction_id
   AND RESULT_TYPE_CODE = 'Error'
   AND KEY_HASH IN
              (SELECT KEY_HASH
                 FROM TMPDEL_ICS_SUBM_RESULTS
                WHERE SUBM_TYPE_NAME = 'MasterGeneralPermitSubmission'
                  AND SUBM_TRANSACTION_ID = pi_transaction_id);

SET v_marker = 'DELETE FROM ICS_SUBM_RESULTS - PermitReissuanceSubmission'; 
DELETE
  FROM ICS_SUBM_RESULTS
 WHERE SUBM_TYPE_NAME = 'PermitReissuanceSubmission'
   AND SUBM_TRANSACTION_ID <> pi_transaction_id
   AND RESULT_TYPE_CODE = 'Error'
   AND KEY_HASH IN
              (SELECT KEY_HASH
                 FROM TMPDEL_ICS_SUBM_RESULTS
                WHERE SUBM_TYPE_NAME = 'PermitReissuanceSubmission'
                  AND SUBM_TRANSACTION_ID = pi_transaction_id);

SET v_marker = 'DELETE FROM ICS_SUBM_RESULTS - PermitTerminationSubmission'; 
DELETE
  FROM ICS_SUBM_RESULTS
 WHERE SUBM_TYPE_NAME = 'PermitTerminationSubmission'
   AND SUBM_TRANSACTION_ID <> pi_transaction_id
   AND RESULT_TYPE_CODE = 'Error'
   AND KEY_HASH IN
              (SELECT KEY_HASH
                 FROM TMPDEL_ICS_SUBM_RESULTS
                WHERE SUBM_TYPE_NAME = 'PermitTerminationSubmission'
                  AND SUBM_TRANSACTION_ID = pi_transaction_id);

SET v_marker = 'DELETE FROM ICS_SUBM_RESULTS - PermitTrackingEventSubmission'; 
DELETE
  FROM ICS_SUBM_RESULTS
 WHERE SUBM_TYPE_NAME = 'PermitTrackingEventSubmission'
   AND SUBM_TRANSACTION_ID <> pi_transaction_id
   AND RESULT_TYPE_CODE = 'Error'
   AND KEY_HASH IN
              (SELECT KEY_HASH
                 FROM TMPDEL_ICS_SUBM_RESULTS
                WHERE SUBM_TYPE_NAME = 'PermitTrackingEventSubmission'
                  AND SUBM_TRANSACTION_ID = pi_transaction_id);

SET v_marker = 'DELETE FROM ICS_SUBM_RESULTS - POTWPermitSubmission'; 
DELETE
  FROM ICS_SUBM_RESULTS
 WHERE SUBM_TYPE_NAME = 'POTWPermitSubmission'
   AND SUBM_TRANSACTION_ID <> pi_transaction_id
   AND RESULT_TYPE_CODE = 'Error'
   AND KEY_HASH IN
              (SELECT KEY_HASH
                 FROM TMPDEL_ICS_SUBM_RESULTS
                WHERE SUBM_TYPE_NAME = 'POTWPermitSubmission'
                  AND SUBM_TRANSACTION_ID = pi_transaction_id);

SET v_marker = 'DELETE FROM ICS_SUBM_RESULTS - PretreatmentPermitSubmission'; 
DELETE
  FROM ICS_SUBM_RESULTS
 WHERE SUBM_TYPE_NAME = 'PretreatmentPermitSubmission'
   AND SUBM_TRANSACTION_ID <> pi_transaction_id
   AND RESULT_TYPE_CODE = 'Error'
   AND KEY_HASH IN
              (SELECT KEY_HASH
                 FROM TMPDEL_ICS_SUBM_RESULTS
                WHERE SUBM_TYPE_NAME = 'PretreatmentPermitSubmission'
                  AND SUBM_TRANSACTION_ID = pi_transaction_id);

SET v_marker = 'DELETE FROM ICS_SUBM_RESULTS - SWConstructionPermitSubmission'; 
DELETE
  FROM ICS_SUBM_RESULTS
 WHERE SUBM_TYPE_NAME = 'SWConstructionPermitSubmission'
   AND SUBM_TRANSACTION_ID <> pi_transaction_id
   AND RESULT_TYPE_CODE = 'Error'
   AND KEY_HASH IN
              (SELECT KEY_HASH
                 FROM TMPDEL_ICS_SUBM_RESULTS
                WHERE SUBM_TYPE_NAME = 'SWConstructionPermitSubmission'
                  AND SUBM_TRANSACTION_ID = pi_transaction_id);

SET v_marker = 'DELETE FROM ICS_SUBM_RESULTS - SWIndustrialPermitSubmission'; 
DELETE
  FROM ICS_SUBM_RESULTS
 WHERE SUBM_TYPE_NAME = 'SWIndustrialPermitSubmission'
   AND SUBM_TRANSACTION_ID <> pi_transaction_id
   AND RESULT_TYPE_CODE = 'Error'
   AND KEY_HASH IN
              (SELECT KEY_HASH
                 FROM TMPDEL_ICS_SUBM_RESULTS
                WHERE SUBM_TYPE_NAME = 'SWIndustrialPermitSubmission'
                  AND SUBM_TRANSACTION_ID = pi_transaction_id);

SET v_marker = 'DELETE FROM ICS_SUBM_RESULTS - SWMS4LargePermitSubmission'; 
DELETE
  FROM ICS_SUBM_RESULTS
 WHERE SUBM_TYPE_NAME = 'SWMS4LargePermitSubmission'
   AND SUBM_TRANSACTION_ID <> pi_transaction_id
   AND RESULT_TYPE_CODE = 'Error'
   AND KEY_HASH IN
              (SELECT KEY_HASH
                 FROM TMPDEL_ICS_SUBM_RESULTS
                WHERE SUBM_TYPE_NAME = 'SWMS4LargePermitSubmission'
                  AND SUBM_TRANSACTION_ID = pi_transaction_id);

SET v_marker = 'DELETE FROM ICS_SUBM_RESULTS - SWMS4SmallPermitSubmission'; 
DELETE
  FROM ICS_SUBM_RESULTS
 WHERE SUBM_TYPE_NAME = 'SWMS4SmallPermitSubmission'
   AND SUBM_TRANSACTION_ID <> pi_transaction_id
   AND RESULT_TYPE_CODE = 'Error'
   AND KEY_HASH IN
              (SELECT KEY_HASH
                 FROM TMPDEL_ICS_SUBM_RESULTS
                WHERE SUBM_TYPE_NAME = 'SWMS4SmallPermitSubmission'
                  AND SUBM_TRANSACTION_ID = pi_transaction_id);

SET v_marker = 'DELETE FROM ICS_SUBM_RESULTS - UnpermittedFacilitySubmission'; 
DELETE
  FROM ICS_SUBM_RESULTS
 WHERE SUBM_TYPE_NAME = 'UnpermittedFacilitySubmission'
   AND SUBM_TRANSACTION_ID <> pi_transaction_id
   AND RESULT_TYPE_CODE = 'Error'
   AND KEY_HASH IN
              (SELECT KEY_HASH
                 FROM TMPDEL_ICS_SUBM_RESULTS
                WHERE SUBM_TYPE_NAME = 'UnpermittedFacilitySubmission'
                  AND SUBM_TRANSACTION_ID = pi_transaction_id);

SET v_marker = 'DELETE FROM ICS_SUBM_RESULTS - HistoricalPermitScheduleEventsSubmission'; 
DELETE
  FROM ICS_SUBM_RESULTS
 WHERE SUBM_TYPE_NAME = 'HistoricalPermitScheduleEventsSubmission'
   AND SUBM_TRANSACTION_ID <> pi_transaction_id
   AND RESULT_TYPE_CODE = 'Error'
   AND KEY_HASH IN
              (SELECT KEY_HASH
                 FROM TMPDEL_ICS_SUBM_RESULTS
                WHERE SUBM_TYPE_NAME = 'HistoricalPermitScheduleEventsSubmission'
                  AND SUBM_TRANSACTION_ID = pi_transaction_id);

SET v_marker = 'DELETE FROM ICS_SUBM_RESULTS - NarrativeConditionScheduleSubmission'; 
DELETE
  FROM ICS_SUBM_RESULTS
 WHERE SUBM_TYPE_NAME = 'NarrativeConditionScheduleSubmission'
   AND SUBM_TRANSACTION_ID <> pi_transaction_id
   AND RESULT_TYPE_CODE = 'Error'
   AND KEY_HASH IN
              (SELECT KEY_HASH
                 FROM TMPDEL_ICS_SUBM_RESULTS
                WHERE SUBM_TYPE_NAME = 'NarrativeConditionScheduleSubmission'
                  AND SUBM_TRANSACTION_ID = pi_transaction_id);

SET v_marker = 'DELETE FROM ICS_SUBM_RESULTS - PermittedFeatureSubmission'; 
DELETE
  FROM ICS_SUBM_RESULTS
 WHERE SUBM_TYPE_NAME = 'PermittedFeatureSubmission'
   AND SUBM_TRANSACTION_ID <> pi_transaction_id
   AND RESULT_TYPE_CODE = 'Error'
   AND KEY_HASH IN
              (SELECT KEY_HASH
                 FROM TMPDEL_ICS_SUBM_RESULTS
                WHERE SUBM_TYPE_NAME = 'PermittedFeatureSubmission'
                  AND SUBM_TRANSACTION_ID = pi_transaction_id);

SET v_marker = 'DELETE FROM ICS_SUBM_RESULTS - LimitSetSubmission'; 
DELETE
  FROM ICS_SUBM_RESULTS
 WHERE SUBM_TYPE_NAME = 'LimitSetSubmission'
   AND SUBM_TRANSACTION_ID <> pi_transaction_id
   AND RESULT_TYPE_CODE = 'Error'
   AND KEY_HASH IN
              (SELECT KEY_HASH
                 FROM TMPDEL_ICS_SUBM_RESULTS
                WHERE SUBM_TYPE_NAME = 'LimitSetSubmission'
                  AND SUBM_TRANSACTION_ID = pi_transaction_id);

SET v_marker = 'DELETE FROM ICS_SUBM_RESULTS - LimitsSubmission'; 
DELETE
  FROM ICS_SUBM_RESULTS
 WHERE SUBM_TYPE_NAME = 'LimitsSubmission'
   AND SUBM_TRANSACTION_ID <> pi_transaction_id
   AND RESULT_TYPE_CODE = 'Error'
   AND KEY_HASH IN
              (SELECT KEY_HASH
                 FROM TMPDEL_ICS_SUBM_RESULTS
                WHERE SUBM_TYPE_NAME = 'LimitsSubmission'
                  AND SUBM_TRANSACTION_ID = pi_transaction_id);

SET v_marker = 'DELETE FROM ICS_SUBM_RESULTS - ParameterLimitsSubmission'; 
DELETE
  FROM ICS_SUBM_RESULTS
 WHERE SUBM_TYPE_NAME = 'ParameterLimitsSubmission'
   AND SUBM_TRANSACTION_ID <> pi_transaction_id
   AND RESULT_TYPE_CODE = 'Error'
   AND KEY_HASH IN
              (SELECT KEY_HASH
                 FROM TMPDEL_ICS_SUBM_RESULTS
                WHERE SUBM_TYPE_NAME = 'ParameterLimitsSubmission'
                  AND SUBM_TRANSACTION_ID = pi_transaction_id);

SET v_marker = 'DELETE FROM ICS_SUBM_RESULTS - DischargeMonitoringReportSubmission'; 
DELETE
  FROM ICS_SUBM_RESULTS
 WHERE SUBM_TYPE_NAME = 'DischargeMonitoringReportSubmission'
   AND SUBM_TRANSACTION_ID <> pi_transaction_id
   AND RESULT_TYPE_CODE = 'Error'
   AND KEY_HASH IN
              (SELECT KEY_HASH
                 FROM TMPDEL_ICS_SUBM_RESULTS
                WHERE SUBM_TYPE_NAME = 'DischargeMonitoringReportSubmission'
                  AND SUBM_TRANSACTION_ID = pi_transaction_id);

SET v_marker = 'DELETE FROM ICS_SUBM_RESULTS - ComplianceMonitoringSubmission'; 
DELETE
  FROM ICS_SUBM_RESULTS
 WHERE SUBM_TYPE_NAME = 'ComplianceMonitoringSubmission'
   AND SUBM_TRANSACTION_ID <> pi_transaction_id
   AND RESULT_TYPE_CODE = 'Error'
   AND KEY_HASH IN
              (SELECT KEY_HASH
                 FROM TMPDEL_ICS_SUBM_RESULTS
                WHERE SUBM_TYPE_NAME = 'ComplianceMonitoringSubmission'
                  AND SUBM_TRANSACTION_ID = pi_transaction_id);

SET v_marker = 'DELETE FROM ICS_SUBM_RESULTS - EffluentTradePartnerSubmission'; 
DELETE
  FROM ICS_SUBM_RESULTS
 WHERE SUBM_TYPE_NAME = 'EffluentTradePartnerSubmission'
   AND SUBM_TRANSACTION_ID <> pi_transaction_id
   AND RESULT_TYPE_CODE = 'Error'
   AND KEY_HASH IN
              (SELECT KEY_HASH
                 FROM TMPDEL_ICS_SUBM_RESULTS
                WHERE SUBM_TYPE_NAME = 'EffluentTradePartnerSubmission'
                  AND SUBM_TRANSACTION_ID = pi_transaction_id);

SET v_marker = 'DELETE FROM ICS_SUBM_RESULTS - FormalEnforcementActionSubmission'; 
DELETE
  FROM ICS_SUBM_RESULTS
 WHERE SUBM_TYPE_NAME = 'FormalEnforcementActionSubmission'
   AND SUBM_TRANSACTION_ID <> pi_transaction_id
   AND RESULT_TYPE_CODE = 'Error'
   AND KEY_HASH IN
              (SELECT KEY_HASH
                 FROM TMPDEL_ICS_SUBM_RESULTS
                WHERE SUBM_TYPE_NAME = 'FormalEnforcementActionSubmission'
                  AND SUBM_TRANSACTION_ID = pi_transaction_id);

SET v_marker = 'DELETE FROM ICS_SUBM_RESULTS - InformalEnforcementActionSubmission'; 
DELETE
  FROM ICS_SUBM_RESULTS
 WHERE SUBM_TYPE_NAME = 'InformalEnforcementActionSubmission'
   AND SUBM_TRANSACTION_ID <> pi_transaction_id
   AND RESULT_TYPE_CODE = 'Error'
   AND KEY_HASH IN
              (SELECT KEY_HASH
                 FROM TMPDEL_ICS_SUBM_RESULTS
                WHERE SUBM_TYPE_NAME = 'InformalEnforcementActionSubmission'
                  AND SUBM_TRANSACTION_ID = pi_transaction_id);

SET v_marker = 'DELETE FROM ICS_SUBM_RESULTS - ComplianceScheduleSubmission'; 
DELETE
  FROM ICS_SUBM_RESULTS
 WHERE SUBM_TYPE_NAME = 'ComplianceScheduleSubmission'
   AND SUBM_TRANSACTION_ID <> pi_transaction_id
   AND RESULT_TYPE_CODE = 'Error'
   AND KEY_HASH IN
              (SELECT KEY_HASH
                 FROM TMPDEL_ICS_SUBM_RESULTS
                WHERE SUBM_TYPE_NAME = 'ComplianceScheduleSubmission'
                  AND SUBM_TRANSACTION_ID = pi_transaction_id);

SET v_marker = 'DELETE FROM ICS_SUBM_RESULTS - EnforcementActionMilestoneSubmission'; 
DELETE
  FROM ICS_SUBM_RESULTS
 WHERE SUBM_TYPE_NAME = 'EnforcementActionMilestoneSubmission'
   AND SUBM_TRANSACTION_ID <> pi_transaction_id
   AND RESULT_TYPE_CODE = 'Error'
   AND KEY_HASH IN
              (SELECT KEY_HASH
                 FROM TMPDEL_ICS_SUBM_RESULTS
                WHERE SUBM_TYPE_NAME = 'EnforcementActionMilestoneSubmission'
                  AND SUBM_TRANSACTION_ID = pi_transaction_id);

SET v_marker = 'DELETE FROM ICS_SUBM_RESULTS - DMRViolationSubmission'; 
DELETE
  FROM ICS_SUBM_RESULTS
 WHERE SUBM_TYPE_NAME = 'DMRViolationSubmission'
   AND SUBM_TRANSACTION_ID <> pi_transaction_id
   AND RESULT_TYPE_CODE = 'Error'
   AND KEY_HASH IN
              (SELECT KEY_HASH
                 FROM TMPDEL_ICS_SUBM_RESULTS
                WHERE SUBM_TYPE_NAME = 'DMRViolationSubmission'
                  AND SUBM_TRANSACTION_ID = pi_transaction_id);

SET v_marker = 'DELETE FROM ICS_SUBM_RESULTS - SingleEventViolationSubmission'; 
DELETE
  FROM ICS_SUBM_RESULTS
 WHERE SUBM_TYPE_NAME = 'SingleEventViolationSubmission'
   AND SUBM_TRANSACTION_ID <> pi_transaction_id
   AND RESULT_TYPE_CODE = 'Error'
   AND KEY_HASH IN
              (SELECT KEY_HASH
                 FROM TMPDEL_ICS_SUBM_RESULTS
                WHERE SUBM_TYPE_NAME = 'SingleEventViolationSubmission'
                  AND SUBM_TRANSACTION_ID = pi_transaction_id);

SET v_marker = 'DELETE FROM ICS_SUBM_RESULTS - CSOEventReportSubmission'; 
DELETE
  FROM ICS_SUBM_RESULTS
 WHERE SUBM_TYPE_NAME = 'CSOEventReportSubmission'
   AND SUBM_TRANSACTION_ID <> pi_transaction_id
   AND RESULT_TYPE_CODE = 'Error'
   AND KEY_HASH IN
              (SELECT KEY_HASH
                 FROM TMPDEL_ICS_SUBM_RESULTS
                WHERE SUBM_TYPE_NAME = 'CSOEventReportSubmission'
                  AND SUBM_TRANSACTION_ID = pi_transaction_id);

SET v_marker = 'DELETE FROM ICS_SUBM_RESULTS - SWEventReportSubmission'; 
DELETE
  FROM ICS_SUBM_RESULTS
 WHERE SUBM_TYPE_NAME = 'SWEventReportSubmission'
   AND SUBM_TRANSACTION_ID <> pi_transaction_id
   AND RESULT_TYPE_CODE = 'Error'
   AND KEY_HASH IN
              (SELECT KEY_HASH
                 FROM TMPDEL_ICS_SUBM_RESULTS
                WHERE SUBM_TYPE_NAME = 'SWEventReportSubmission'
                  AND SUBM_TRANSACTION_ID = pi_transaction_id);

SET v_marker = 'DELETE FROM ICS_SUBM_RESULTS - CAFOAnnualReportSubmission'; 
DELETE
  FROM ICS_SUBM_RESULTS
 WHERE SUBM_TYPE_NAME = 'CAFOAnnualReportSubmission'
   AND SUBM_TRANSACTION_ID <> pi_transaction_id
   AND RESULT_TYPE_CODE = 'Error'
   AND KEY_HASH IN
              (SELECT KEY_HASH
                 FROM TMPDEL_ICS_SUBM_RESULTS
                WHERE SUBM_TYPE_NAME = 'CAFOAnnualReportSubmission'
                  AND SUBM_TRANSACTION_ID = pi_transaction_id);

SET v_marker = 'DELETE FROM ICS_SUBM_RESULTS - LocalLimitsProgramReportSubmission'; 
DELETE
  FROM ICS_SUBM_RESULTS
 WHERE SUBM_TYPE_NAME = 'LocalLimitsProgramReportSubmission'
   AND SUBM_TRANSACTION_ID <> pi_transaction_id
   AND RESULT_TYPE_CODE = 'Error'
   AND KEY_HASH IN
              (SELECT KEY_HASH
                 FROM TMPDEL_ICS_SUBM_RESULTS
                WHERE SUBM_TYPE_NAME = 'LocalLimitsProgramReportSubmission'
                  AND SUBM_TRANSACTION_ID = pi_transaction_id);

SET v_marker = 'DELETE FROM ICS_SUBM_RESULTS - PretreatmentPerformanceSummarySubmission'; 
DELETE
  FROM ICS_SUBM_RESULTS
 WHERE SUBM_TYPE_NAME = 'PretreatmentPerformanceSummarySubmission'
   AND SUBM_TRANSACTION_ID <> pi_transaction_id
   AND RESULT_TYPE_CODE = 'Error'
   AND KEY_HASH IN
              (SELECT KEY_HASH
                 FROM TMPDEL_ICS_SUBM_RESULTS
                WHERE SUBM_TYPE_NAME = 'PretreatmentPerformanceSummarySubmission'
                  AND SUBM_TRANSACTION_ID = pi_transaction_id);

SET v_marker = 'DELETE FROM ICS_SUBM_RESULTS - BiosolidsProgramReportSubmission'; 
DELETE
  FROM ICS_SUBM_RESULTS
 WHERE SUBM_TYPE_NAME = 'BiosolidsProgramReportSubmission'
   AND SUBM_TRANSACTION_ID <> pi_transaction_id
   AND RESULT_TYPE_CODE = 'Error'
   AND KEY_HASH IN
              (SELECT KEY_HASH
                 FROM TMPDEL_ICS_SUBM_RESULTS
                WHERE SUBM_TYPE_NAME = 'BiosolidsProgramReportSubmission'
                  AND SUBM_TRANSACTION_ID = pi_transaction_id);

SET v_marker = 'DELETE FROM ICS_SUBM_RESULTS - SSOAnnualReportSubmission'; 
DELETE
  FROM ICS_SUBM_RESULTS
 WHERE SUBM_TYPE_NAME = 'SSOAnnualReportSubmission'
   AND SUBM_TRANSACTION_ID <> pi_transaction_id
   AND RESULT_TYPE_CODE = 'Error'
   AND KEY_HASH IN
              (SELECT KEY_HASH
                 FROM TMPDEL_ICS_SUBM_RESULTS
                WHERE SUBM_TYPE_NAME = 'SSOAnnualReportSubmission'
                  AND SUBM_TRANSACTION_ID = pi_transaction_id);

SET v_marker = 'DELETE FROM ICS_SUBM_RESULTS - SSOEventReportSubmission'; 
DELETE
  FROM ICS_SUBM_RESULTS
 WHERE SUBM_TYPE_NAME = 'SSOEventReportSubmission'
   AND SUBM_TRANSACTION_ID <> pi_transaction_id
   AND RESULT_TYPE_CODE = 'Error'
   AND KEY_HASH IN
              (SELECT KEY_HASH
                 FROM TMPDEL_ICS_SUBM_RESULTS
                WHERE SUBM_TYPE_NAME = 'SSOEventReportSubmission'
                  AND SUBM_TRANSACTION_ID = pi_transaction_id);

SET v_marker = 'DELETE FROM ICS_SUBM_RESULTS - SSOMonthlyEventReportSubmission'; 
DELETE
  FROM ICS_SUBM_RESULTS
 WHERE SUBM_TYPE_NAME = 'SSOMonthlyEventReportSubmission'
   AND SUBM_TRANSACTION_ID <> pi_transaction_id
   AND RESULT_TYPE_CODE = 'Error'
   AND KEY_HASH IN
              (SELECT KEY_HASH
                 FROM TMPDEL_ICS_SUBM_RESULTS
                WHERE SUBM_TYPE_NAME = 'SSOMonthlyEventReportSubmission'
                  AND SUBM_TRANSACTION_ID = pi_transaction_id);

SET v_marker = 'DELETE FROM ICS_SUBM_RESULTS - SWMS4ProgramReportSubmission'; 
DELETE
  FROM ICS_SUBM_RESULTS
 WHERE SUBM_TYPE_NAME = 'SWMS4ProgramReportSubmission'
   AND SUBM_TRANSACTION_ID <> pi_transaction_id
   AND RESULT_TYPE_CODE = 'Error'
   AND KEY_HASH IN
              (SELECT KEY_HASH
                 FROM TMPDEL_ICS_SUBM_RESULTS
                WHERE SUBM_TYPE_NAME = 'SWMS4ProgramReportSubmission'
                  AND SUBM_TRANSACTION_ID = pi_transaction_id);

SET v_marker = 'DELETE FROM ICS_SUBM_RESULTS - ComplianceMonitoringLinkageSubmission'; 
DELETE
  FROM ICS_SUBM_RESULTS
 WHERE SUBM_TYPE_NAME = 'ComplianceMonitoringLinkageSubmission'
   AND SUBM_TRANSACTION_ID <> pi_transaction_id
   AND RESULT_TYPE_CODE = 'Error'
   AND KEY_HASH IN
              (SELECT KEY_HASH
                 FROM TMPDEL_ICS_SUBM_RESULTS
                WHERE SUBM_TYPE_NAME = 'ComplianceMonitoringLinkageSubmission'
                  AND SUBM_TRANSACTION_ID = pi_transaction_id);

SET v_marker = 'DELETE FROM ICS_SUBM_RESULTS - EnforcementActionViolationLinkageSubmission'; 
DELETE
  FROM ICS_SUBM_RESULTS
 WHERE SUBM_TYPE_NAME = 'EnforcementActionViolationLinkageSubmission'
   AND SUBM_TRANSACTION_ID <> pi_transaction_id
   AND RESULT_TYPE_CODE = 'Error'
   AND KEY_HASH IN
              (SELECT KEY_HASH
                 FROM TMPDEL_ICS_SUBM_RESULTS
                WHERE SUBM_TYPE_NAME = 'EnforcementActionViolationLinkageSubmission'
                  AND SUBM_TRANSACTION_ID = pi_transaction_id);

SET v_marker = 'DELETE FROM ICS_SUBM_RESULTS - ScheduleEventViolationSubmission'; 
DELETE
  FROM ICS_SUBM_RESULTS
 WHERE SUBM_TYPE_NAME = 'ScheduleEventViolationSubmission'
   AND SUBM_TRANSACTION_ID <> pi_transaction_id
   AND RESULT_TYPE_CODE = 'Error'
   AND KEY_HASH IN
              (SELECT KEY_HASH
                 FROM TMPDEL_ICS_SUBM_RESULTS
                WHERE SUBM_TYPE_NAME = 'ScheduleEventViolationSubmission'
                  AND SUBM_TRANSACTION_ID = pi_transaction_id);

SET v_marker = 'DELETE FROM ICS_SUBM_RESULTS - DMRProgramReportLinkageSubmission'; 
DELETE
  FROM ICS_SUBM_RESULTS
 WHERE SUBM_TYPE_NAME = 'DMRProgramReportLinkageSubmission'
   AND SUBM_TRANSACTION_ID <> pi_transaction_id
   AND RESULT_TYPE_CODE = 'Error'
   AND KEY_HASH IN
              (SELECT KEY_HASH
                 FROM TMPDEL_ICS_SUBM_RESULTS
                WHERE SUBM_TYPE_NAME = 'DMRProgramReportLinkageSubmission'
                  AND SUBM_TRANSACTION_ID = pi_transaction_id);

   -- -------------- --
   --  END PROCEDURE --
   -- -------------- --
   SET v_marker = 'CALL ics_etl_log_sp END';
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_sp_name     -- pi_marker
      ,NULL          -- pi_tgt_tbl
      ,NULL          -- pi_src_tbl 
      ,v_startdtm    -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'COMPLETED'   -- pi_process
      ,0);           -- pi_value
   --
   SET po_status = 1;
   SET po_errm   = '';
   -- 
END