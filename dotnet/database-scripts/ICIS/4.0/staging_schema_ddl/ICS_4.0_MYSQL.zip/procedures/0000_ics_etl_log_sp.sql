USE ga_ics_flow_local;
DROP PROCEDURE IF EXISTS ics_etl_log_sp;
CREATE PROCEDURE ics_etl_log_sp
   (pi_sp_name        VARCHAR(64)
   ,pi_marker         VARCHAR(255)
   ,pi_tgt_tbl        VARCHAR(64)
   ,pi_src_tbl        VARCHAR(64)
   ,pi_startdtm       DATETIME
   ,pi_enddtm         DATETIME
   ,pi_process        VARCHAR(30)
   ,pi_value          INT
   )
BEGIN
-- ============================================================================
-- MODIFICATION HISTORY
-- Person      Date       Comments
-- ---------   --------   -----------------------------------------------------
-- Jen Go      20120911   Created.  
--
-- ============================================================================
    --
    DECLARE v_marker  VARCHAR(255);
    DECLARE v_sqlerr  INT;
    --
    -- DECLARE EXIT HANDLER FOR SQLEXCEPTION
    /*DECLARE EXIT HANDLER FOR 1011 SET v_sqlerr = 1011;
    DECLARE EXIT HANDLER FOR 1021 SET v_sqlerr = 1021;
    DECLARE EXIT HANDLER FOR 1022 SET v_sqlerr = 1022;
    DECLARE EXIT HANDLER FOR 1027 SET v_sqlerr = 1027;
    DECLARE EXIT HANDLER FOR 1036 SET v_sqlerr = 1036;
    DECLARE EXIT HANDLER FOR 1048 SET v_sqlerr = 1048;
    DECLARE EXIT HANDLER FOR 1062 SET v_sqlerr = 1062;
    DECLARE EXIT HANDLER FOR 1099 SET v_sqlerr = 1099;
    DECLARE EXIT HANDLER FOR 1100 SET v_sqlerr = 1100;
    DECLARE EXIT HANDLER FOR 1104 SET v_sqlerr = 1104;
    DECLARE EXIT HANDLER FOR 1106 SET v_sqlerr = 1106;
    DECLARE EXIT HANDLER FOR 1114 SET v_sqlerr = 1114;
    DECLARE EXIT HANDLER FOR 1150 SET v_sqlerr = 1150;
    DECLARE EXIT HANDLER FOR 1165 SET v_sqlerr = 1165;
    DECLARE EXIT HANDLER FOR 1242 SET v_sqlerr = 1242;
    DECLARE EXIT HANDLER FOR 1263 SET v_sqlerr = 1263;
    DECLARE EXIT HANDLER FOR 1264 SET v_sqlerr = 1264;
    DECLARE EXIT HANDLER FOR 1265 SET v_sqlerr = 1265;
    DECLARE EXIT HANDLER FOR 1312 SET v_sqlerr = 1312;
    DECLARE EXIT HANDLER FOR 1317 SET v_sqlerr = 1317;
    DECLARE EXIT HANDLER FOR 1319 SET v_sqlerr = 1319;
    DECLARE EXIT HANDLER FOR 1325 SET v_sqlerr = 1325;
    SELECT v_sqlerr;*/
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
       BEGIN  
          ROLLBACK;
          SELECT CONCAT('Error occurred at ',v_marker);
          -- SET po_status = -1;
          -- SET po_err_message = CONCAT('Error occurred at ',v_marker); 
       END;
    --
    /*
    SELECT 'ics_etl_log_sp';
    SELECT CONCAT('pi_sp_name = ',pi_sp_name);
    SELECT CONCAT('pi_tgt_tbl = ',pi_tgt_tbl);
    SELECT CONCAT('pi_marker  = ',pi_marker);
    SELECT CONCAT('pi_startdtm = ',DATE_FORMAT(pi_startdtm,'%e-%M-%Y:%H:%i'));
    SELECT CONCAT('pi_enddtm   = ',DATE_FORMAT(pi_enddtm,'%e-%M-%Y:%H:%i'));
    SELECT CONCAT('pi_errorstate = ',CONVERT(pi_errorstate, CHAR(10) ) );
    SELECT CONCAT('pi_errormessage = ',pi_errormessage);
    */
    SET v_marker = 'INSERT INTO ics_etl_log';
    INSERT INTO ics_etl_log
       (ics_etl_sp_name
       ,ics_etl_target_table
       ,ics_etl_source_table
       ,ics_etl_sp_marker
       ,ics_etl_sp_startdtm
       ,ics_etl_sp_enddtm
       ,ics_etl_process
       ,ics_etl_value)
    -- VALUES
    SELECT 
        pi_sp_name
       ,pi_tgt_tbl
       ,pi_src_tbl
       ,pi_marker
       ,pi_startdtm
       ,pi_enddtm
       ,pi_process
       ,pi_value;
    -- COMMIT;
    --
END