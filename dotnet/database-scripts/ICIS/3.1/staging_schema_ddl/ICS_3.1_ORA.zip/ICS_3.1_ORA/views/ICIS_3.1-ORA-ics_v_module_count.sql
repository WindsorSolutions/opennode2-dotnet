
/*************************************************************************************************
** ObjectName: ics_v_module_count
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view displays a count of accepted, rejected, and warning records for each module
**               Used in process_accepted_transactions procedure to insert into ics_subm_hist
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 4/5/2012      Windsor     Created 
** 5/15/2012     BRensmith   Added columns for count by transaction type
** 5/25/2012     BRensmith   Added column for accepted_count_total
**
***************************************************************************************************/
CREATE OR REPLACE VIEW ics_v_module_count

AS

SELECT (SELECT subm_date_time FROM ics_subm_track WHERE subm_transaction_id = rslt.subm_transaction_id) as subm_date_time
  , subm_transaction_id
  , subm_type_name
  , CASE 
      WHEN rslt.subm_type_name = 'BasicPermitSubmission' THEN (SELECT COUNT(1) FROM ics_basic_prmt WHERE transaction_type='N')
      WHEN rslt.subm_type_name = 'BiosolidsPermitSubmission' THEN (SELECT COUNT(1) FROM ics_bs_prmt WHERE transaction_type='N')
      WHEN rslt.subm_type_name = 'CAFOPermitSubmission' THEN (SELECT COUNT(1) FROM ics_cafo_prmt WHERE transaction_type='N')
      WHEN rslt.subm_type_name = 'CSOPermitSubmission' THEN (SELECT COUNT(1) FROM ics_cso_prmt WHERE transaction_type='N')
      WHEN rslt.subm_type_name = 'ComplianceMonitoringSubmission' THEN (SELECT COUNT(1) FROM ics_cmpl_mon WHERE transaction_type='N')
      WHEN rslt.subm_type_name = 'GeneralPermitSubmission' THEN (SELECT COUNT(1) FROM ics_gnrl_prmt WHERE transaction_type='N')
      WHEN rslt.subm_type_name = 'MasterGeneralPermitSubmission' THEN (SELECT COUNT(1) FROM ics_master_gnrl_prmt WHERE transaction_type='N')
      WHEN rslt.subm_type_name = 'PermitReissuanceSubmission' THEN (SELECT COUNT(1) FROM ics_prmt_reissu WHERE transaction_type='N')
      WHEN rslt.subm_type_name = 'PermitTerminationSubmission' THEN (SELECT COUNT(1) FROM ics_prmt_term WHERE transaction_type='N')
      WHEN rslt.subm_type_name = 'PermitTrackingEventSubmission' THEN (SELECT COUNT(1) FROM ics_prmt_track_evt WHERE transaction_type='N')
      WHEN rslt.subm_type_name = 'POTWPermitSubmission' THEN (SELECT COUNT(1) FROM ics_potw_prmt WHERE transaction_type='N')
      WHEN rslt.subm_type_name = 'PretreatmentPermitSubmission' THEN (SELECT COUNT(1) FROM ics_pretr_prmt WHERE transaction_type='N')
      WHEN rslt.subm_type_name = 'SWConstructionPermitSubmission' THEN (SELECT COUNT(1) FROM ics_sw_cnst_prmt WHERE transaction_type='N')
      WHEN rslt.subm_type_name = 'SWIndustrialPermitSubmission' THEN (SELECT COUNT(1) FROM ics_sw_indst_prmt WHERE transaction_type='N')
      WHEN rslt.subm_type_name = 'SWMS4LargePermitSubmission' THEN (SELECT COUNT(1) FROM ics_swms_4_large_prmt WHERE transaction_type='N')
      WHEN rslt.subm_type_name = 'SWMS4SmallPermitSubmission' THEN (SELECT COUNT(1) FROM ics_swms_4_small_prmt WHERE transaction_type='N')
      WHEN rslt.subm_type_name = 'UnpermittedFacilitySubmission' THEN (SELECT COUNT(1) FROM ics_unprmt_fac WHERE transaction_type='N')
      WHEN rslt.subm_type_name = 'HistoricalPermitScheduleEventsSubmission' THEN (SELECT COUNT(1) FROM ics_hist_prmt_schd_evts WHERE transaction_type='N')
      WHEN rslt.subm_type_name = 'NarrativeConditionScheduleSubmission' THEN (SELECT COUNT(1) FROM ics_narr_cond_schd WHERE transaction_type='N')
      WHEN rslt.subm_type_name = 'PermittedFeatureSubmission' THEN (SELECT COUNT(1) FROM ics_prmt_featr WHERE transaction_type='N')
      WHEN rslt.subm_type_name = 'LimitSetSubmission' THEN (SELECT COUNT(1) FROM ics_lmt_set WHERE transaction_type='N')
      WHEN rslt.subm_type_name = 'LimitsSubmission' THEN (SELECT COUNT(1) FROM ics_lmts WHERE transaction_type='N')
      WHEN rslt.subm_type_name = 'ParameterLimitsSubmission' THEN (SELECT COUNT(1) FROM ics_param_lmts WHERE transaction_type='N')
      WHEN rslt.subm_type_name = 'DischargeMonitoringReportSubmission' THEN (SELECT COUNT(1) FROM ics_dsch_mon_rep WHERE transaction_type='N')
      WHEN rslt.subm_type_name = 'SingleEventViolationSubmission' THEN (SELECT COUNT(1) FROM ics_sngl_evt_viol WHERE transaction_type='N')
      WHEN rslt.subm_type_name = 'ScheduleEventViolationSubmission' THEN (SELECT COUNT(1) FROM ics_schd_evt_viol WHERE transaction_type='N')
      WHEN rslt.subm_type_name = 'ComplianceScheduleSubmission' THEN (SELECT COUNT(1) FROM ics_cmpl_schd WHERE transaction_type='N')
      WHEN rslt.subm_type_name = 'DMRViolationSubmission' THEN (SELECT COUNT(1) FROM ics_dmr_viol WHERE transaction_type='N')
      WHEN rslt.subm_type_name = 'ComplianceMonitoringLinkage' THEN (SELECT COUNT(1) FROM ics_cmpl_mon_lnk WHERE transaction_type='N')
      WHEN rslt.subm_type_name = 'FinalOrderViolationLinkageSubmission' THEN (SELECT COUNT(1) FROM ics_final_order_viol_lnk WHERE transaction_type='N')
      WHEN rslt.subm_type_name = 'EnforcementActionViolationLinkageSubmission' THEN (SELECT COUNT(1) FROM ics_enfrc_actn_viol_lnk WHERE transaction_type='N')
      WHEN rslt.subm_type_name = 'DMRProgramReportLinkageSubmission' THEN (SELECT COUNT(1) FROM ics_dmr_prog_rep_lnk WHERE transaction_type='N')
      WHEN rslt.subm_type_name = 'EffluentTradePartnerSubmission' THEN (SELECT COUNT(1) FROM ics_efflu_trade_prtner WHERE transaction_type='N')
      WHEN rslt.subm_type_name = 'FormalEnforcementActionSubmission' THEN (SELECT COUNT(1) FROM ics_frml_enfrc_actn WHERE transaction_type='N')
      WHEN rslt.subm_type_name = 'InformalEnforcementActionSubmission' THEN (SELECT COUNT(1) FROM ics_infrml_enfrc_actn WHERE transaction_type='N')
      WHEN rslt.subm_type_name = 'EnforcementActionMilestoneSubmission' THEN (SELECT COUNT(1) FROM ics_enfrc_actn_milestone WHERE transaction_type='N')
      WHEN rslt.subm_type_name = 'CSOEventReportSubmission' THEN (SELECT COUNT(1) FROM ics_cso_evt_rep WHERE transaction_type='N')
      WHEN rslt.subm_type_name = 'SWEventReportSubmission' THEN (SELECT COUNT(1) FROM ics_sw_evt_rep WHERE transaction_type='N')
      WHEN rslt.subm_type_name = 'CAFOAnnualReportSubmission' THEN (SELECT COUNT(1) FROM ics_cafo_annul_rep WHERE transaction_type='N')
      WHEN rslt.subm_type_name = 'LocalLimitsProgramReportSubmission' THEN (SELECT COUNT(1) FROM ics_loc_lmts_prog_rep WHERE transaction_type='N')
      WHEN rslt.subm_type_name = 'PretreatmentPerformanceSummarySubmission' THEN (SELECT COUNT(1) FROM ics_pretr_perf_summ WHERE transaction_type='N')
      WHEN rslt.subm_type_name = 'BiosolidsProgramReportSubmission' THEN (SELECT COUNT(1) FROM ics_bs_prog_rep WHERE transaction_type='N')
      WHEN rslt.subm_type_name = 'SSOAnnualReportSubmission' THEN (SELECT COUNT(1) FROM ics_sso_annul_rep WHERE transaction_type='N')
      WHEN rslt.subm_type_name = 'SSOEventReportSubmission' THEN (SELECT COUNT(1) FROM ics_sso_evt_rep WHERE transaction_type='N')
      WHEN rslt.subm_type_name = 'SSOMonthlyEventReportSubmission' THEN (SELECT COUNT(1) FROM ics_sso_monthly_evt_rep WHERE transaction_type='N')
      WHEN rslt.subm_type_name = 'SWMS4ProgramReportSubmission' THEN (SELECT COUNT(1) FROM ics_swms_4_prog_rep WHERE transaction_type='N')
    END as trans_count_new
    , CASE 
      WHEN rslt.subm_type_name = 'BasicPermitSubmission' THEN (SELECT COUNT(1) FROM ics_basic_prmt WHERE transaction_type IN ('C','R'))
      WHEN rslt.subm_type_name = 'BiosolidsPermitSubmission' THEN (SELECT COUNT(1) FROM ics_bs_prmt WHERE transaction_type IN ('C','R'))
      WHEN rslt.subm_type_name = 'CAFOPermitSubmission' THEN (SELECT COUNT(1) FROM ics_cafo_prmt WHERE transaction_type IN ('C','R'))
      WHEN rslt.subm_type_name = 'CSOPermitSubmission' THEN (SELECT COUNT(1) FROM ics_cso_prmt WHERE transaction_type IN ('C','R'))
      WHEN rslt.subm_type_name = 'ComplianceMonitoringSubmission' THEN (SELECT COUNT(1) FROM ics_cmpl_mon WHERE transaction_type IN ('C','R'))
      WHEN rslt.subm_type_name = 'GeneralPermitSubmission' THEN (SELECT COUNT(1) FROM ics_gnrl_prmt WHERE transaction_type IN ('C','R'))
      WHEN rslt.subm_type_name = 'MasterGeneralPermitSubmission' THEN (SELECT COUNT(1) FROM ics_master_gnrl_prmt WHERE transaction_type IN ('C','R'))
      WHEN rslt.subm_type_name = 'PermitReissuanceSubmission' THEN (SELECT COUNT(1) FROM ics_prmt_reissu WHERE transaction_type IN ('C','R'))
      WHEN rslt.subm_type_name = 'PermitTerminationSubmission' THEN (SELECT COUNT(1) FROM ics_prmt_term WHERE transaction_type IN ('C','R'))
      WHEN rslt.subm_type_name = 'PermitTrackingEventSubmission' THEN (SELECT COUNT(1) FROM ics_prmt_track_evt WHERE transaction_type IN ('C','R'))
      WHEN rslt.subm_type_name = 'POTWPermitSubmission' THEN (SELECT COUNT(1) FROM ics_potw_prmt WHERE transaction_type IN ('C','R'))
      WHEN rslt.subm_type_name = 'PretreatmentPermitSubmission' THEN (SELECT COUNT(1) FROM ics_pretr_prmt WHERE transaction_type IN ('C','R'))
      WHEN rslt.subm_type_name = 'SWConstructionPermitSubmission' THEN (SELECT COUNT(1) FROM ics_sw_cnst_prmt WHERE transaction_type IN ('C','R'))
      WHEN rslt.subm_type_name = 'SWIndustrialPermitSubmission' THEN (SELECT COUNT(1) FROM ics_sw_indst_prmt WHERE transaction_type IN ('C','R'))
      WHEN rslt.subm_type_name = 'SWMS4LargePermitSubmission' THEN (SELECT COUNT(1) FROM ics_swms_4_large_prmt WHERE transaction_type IN ('C','R'))
      WHEN rslt.subm_type_name = 'SWMS4SmallPermitSubmission' THEN (SELECT COUNT(1) FROM ics_swms_4_small_prmt WHERE transaction_type IN ('C','R'))
      WHEN rslt.subm_type_name = 'UnpermittedFacilitySubmission' THEN (SELECT COUNT(1) FROM ics_unprmt_fac WHERE transaction_type IN ('C','R'))
      WHEN rslt.subm_type_name = 'HistoricalPermitScheduleEventsSubmission' THEN (SELECT COUNT(1) FROM ics_hist_prmt_schd_evts WHERE transaction_type IN ('C','R'))
      WHEN rslt.subm_type_name = 'NarrativeConditionScheduleSubmission' THEN (SELECT COUNT(1) FROM ics_narr_cond_schd WHERE transaction_type IN ('C','R'))
      WHEN rslt.subm_type_name = 'PermittedFeatureSubmission' THEN (SELECT COUNT(1) FROM ics_prmt_featr WHERE transaction_type IN ('C','R'))
      WHEN rslt.subm_type_name = 'LimitSetSubmission' THEN (SELECT COUNT(1) FROM ics_lmt_set WHERE transaction_type IN ('C','R'))
      WHEN rslt.subm_type_name = 'LimitsSubmission' THEN (SELECT COUNT(1) FROM ics_lmts WHERE transaction_type IN ('C','R'))
      WHEN rslt.subm_type_name = 'ParameterLimitsSubmission' THEN (SELECT COUNT(1) FROM ics_param_lmts WHERE transaction_type IN ('C','R'))
      WHEN rslt.subm_type_name = 'DischargeMonitoringReportSubmission' THEN (SELECT COUNT(1) FROM ics_dsch_mon_rep WHERE transaction_type IN ('C','R'))
      WHEN rslt.subm_type_name = 'SingleEventViolationSubmission' THEN (SELECT COUNT(1) FROM ics_sngl_evt_viol WHERE transaction_type IN ('C','R'))
      WHEN rslt.subm_type_name = 'ScheduleEventViolationSubmission' THEN (SELECT COUNT(1) FROM ics_schd_evt_viol WHERE transaction_type IN ('C','R'))
      WHEN rslt.subm_type_name = 'ComplianceScheduleSubmission' THEN (SELECT COUNT(1) FROM ics_cmpl_schd WHERE transaction_type IN ('C','R'))
      WHEN rslt.subm_type_name = 'DMRViolationSubmission' THEN (SELECT COUNT(1) FROM ics_dmr_viol WHERE transaction_type IN ('C','R'))
      WHEN rslt.subm_type_name = 'ComplianceMonitoringLinkage' THEN (SELECT COUNT(1) FROM ics_cmpl_mon_lnk WHERE transaction_type IN ('C','R'))
      WHEN rslt.subm_type_name = 'FinalOrderViolationLinkageSubmission' THEN (SELECT COUNT(1) FROM ics_final_order_viol_lnk WHERE transaction_type IN ('C','R'))
      WHEN rslt.subm_type_name = 'EnforcementActionViolationLinkageSubmission' THEN (SELECT COUNT(1) FROM ics_enfrc_actn_viol_lnk WHERE transaction_type IN ('C','R'))
      WHEN rslt.subm_type_name = 'DMRProgramReportLinkageSubmission' THEN (SELECT COUNT(1) FROM ics_dmr_prog_rep_lnk WHERE transaction_type IN ('C','R'))
      WHEN rslt.subm_type_name = 'EffluentTradePartnerSubmission' THEN (SELECT COUNT(1) FROM ics_efflu_trade_prtner WHERE transaction_type IN ('C','R'))
      WHEN rslt.subm_type_name = 'FormalEnforcementActionSubmission' THEN (SELECT COUNT(1) FROM ics_frml_enfrc_actn WHERE transaction_type IN ('C','R'))
      WHEN rslt.subm_type_name = 'InformalEnforcementActionSubmission' THEN (SELECT COUNT(1) FROM ics_infrml_enfrc_actn WHERE transaction_type IN ('C','R'))
      WHEN rslt.subm_type_name = 'EnforcementActionMilestoneSubmission' THEN (SELECT COUNT(1) FROM ics_enfrc_actn_milestone WHERE transaction_type IN ('C','R'))
      WHEN rslt.subm_type_name = 'CSOEventReportSubmission' THEN (SELECT COUNT(1) FROM ics_cso_evt_rep WHERE transaction_type IN ('C','R'))
      WHEN rslt.subm_type_name = 'SWEventReportSubmission' THEN (SELECT COUNT(1) FROM ics_sw_evt_rep WHERE transaction_type IN ('C','R'))
      WHEN rslt.subm_type_name = 'CAFOAnnualReportSubmission' THEN (SELECT COUNT(1) FROM ics_cafo_annul_rep WHERE transaction_type IN ('C','R'))
      WHEN rslt.subm_type_name = 'LocalLimitsProgramReportSubmission' THEN (SELECT COUNT(1) FROM ics_loc_lmts_prog_rep WHERE transaction_type IN ('C','R'))
      WHEN rslt.subm_type_name = 'PretreatmentPerformanceSummarySubmission' THEN (SELECT COUNT(1) FROM ics_pretr_perf_summ WHERE transaction_type IN ('C','R'))
      WHEN rslt.subm_type_name = 'BiosolidsProgramReportSubmission' THEN (SELECT COUNT(1) FROM ics_bs_prog_rep WHERE transaction_type IN ('C','R'))
      WHEN rslt.subm_type_name = 'SSOAnnualReportSubmission' THEN (SELECT COUNT(1) FROM ics_sso_annul_rep WHERE transaction_type IN ('C','R'))
      WHEN rslt.subm_type_name = 'SSOEventReportSubmission' THEN (SELECT COUNT(1) FROM ics_sso_evt_rep WHERE transaction_type IN ('C','R'))
      WHEN rslt.subm_type_name = 'SSOMonthlyEventReportSubmission' THEN (SELECT COUNT(1) FROM ics_sso_monthly_evt_rep WHERE transaction_type IN ('C','R'))
      WHEN rslt.subm_type_name = 'SWMS4ProgramReportSubmission' THEN (SELECT COUNT(1) FROM ics_swms_4_prog_rep WHERE transaction_type IN ('C','R'))
    END as trans_count_chng_repl
      , CASE 
      WHEN rslt.subm_type_name = 'BasicPermitSubmission' THEN (SELECT COUNT(1) FROM ics_basic_prmt WHERE transaction_type IN ('D','X'))
      WHEN rslt.subm_type_name = 'BiosolidsPermitSubmission' THEN (SELECT COUNT(1) FROM ics_bs_prmt WHERE transaction_type IN ('D','X'))
      WHEN rslt.subm_type_name = 'CAFOPermitSubmission' THEN (SELECT COUNT(1) FROM ics_cafo_prmt WHERE transaction_type IN ('D','X'))
      WHEN rslt.subm_type_name = 'CSOPermitSubmission' THEN (SELECT COUNT(1) FROM ics_cso_prmt WHERE transaction_type IN ('D','X'))
      WHEN rslt.subm_type_name = 'ComplianceMonitoringSubmission' THEN (SELECT COUNT(1) FROM ics_cmpl_mon WHERE transaction_type IN ('D','X'))
      WHEN rslt.subm_type_name = 'GeneralPermitSubmission' THEN (SELECT COUNT(1) FROM ics_gnrl_prmt WHERE transaction_type IN ('D','X'))
      WHEN rslt.subm_type_name = 'MasterGeneralPermitSubmission' THEN (SELECT COUNT(1) FROM ics_master_gnrl_prmt WHERE transaction_type IN ('D','X'))
      WHEN rslt.subm_type_name = 'PermitReissuanceSubmission' THEN (SELECT COUNT(1) FROM ics_prmt_reissu WHERE transaction_type IN ('D','X'))
      WHEN rslt.subm_type_name = 'PermitTerminationSubmission' THEN (SELECT COUNT(1) FROM ics_prmt_term WHERE transaction_type IN ('D','X'))
      WHEN rslt.subm_type_name = 'PermitTrackingEventSubmission' THEN (SELECT COUNT(1) FROM ics_prmt_track_evt WHERE transaction_type IN ('D','X'))
      WHEN rslt.subm_type_name = 'POTWPermitSubmission' THEN (SELECT COUNT(1) FROM ics_potw_prmt WHERE transaction_type IN ('D','X'))
      WHEN rslt.subm_type_name = 'PretreatmentPermitSubmission' THEN (SELECT COUNT(1) FROM ics_pretr_prmt WHERE transaction_type IN ('D','X'))
      WHEN rslt.subm_type_name = 'SWConstructionPermitSubmission' THEN (SELECT COUNT(1) FROM ics_sw_cnst_prmt WHERE transaction_type IN ('D','X'))
      WHEN rslt.subm_type_name = 'SWIndustrialPermitSubmission' THEN (SELECT COUNT(1) FROM ics_sw_indst_prmt WHERE transaction_type IN ('D','X'))
      WHEN rslt.subm_type_name = 'SWMS4LargePermitSubmission' THEN (SELECT COUNT(1) FROM ics_swms_4_large_prmt WHERE transaction_type IN ('D','X'))
      WHEN rslt.subm_type_name = 'SWMS4SmallPermitSubmission' THEN (SELECT COUNT(1) FROM ics_swms_4_small_prmt WHERE transaction_type IN ('D','X'))
      WHEN rslt.subm_type_name = 'UnpermittedFacilitySubmission' THEN (SELECT COUNT(1) FROM ics_unprmt_fac WHERE transaction_type IN ('D','X'))
      WHEN rslt.subm_type_name = 'HistoricalPermitScheduleEventsSubmission' THEN (SELECT COUNT(1) FROM ics_hist_prmt_schd_evts WHERE transaction_type IN ('D','X'))
      WHEN rslt.subm_type_name = 'NarrativeConditionScheduleSubmission' THEN (SELECT COUNT(1) FROM ics_narr_cond_schd WHERE transaction_type IN ('D','X'))
      WHEN rslt.subm_type_name = 'PermittedFeatureSubmission' THEN (SELECT COUNT(1) FROM ics_prmt_featr WHERE transaction_type IN ('D','X'))
      WHEN rslt.subm_type_name = 'LimitSetSubmission' THEN (SELECT COUNT(1) FROM ics_lmt_set WHERE transaction_type IN ('D','X'))
      WHEN rslt.subm_type_name = 'LimitsSubmission' THEN (SELECT COUNT(1) FROM ics_lmts WHERE transaction_type IN ('D','X'))
      WHEN rslt.subm_type_name = 'ParameterLimitsSubmission' THEN (SELECT COUNT(1) FROM ics_param_lmts WHERE transaction_type IN ('D','X'))
      WHEN rslt.subm_type_name = 'DischargeMonitoringReportSubmission' THEN (SELECT COUNT(1) FROM ics_dsch_mon_rep WHERE transaction_type IN ('D','X'))
      WHEN rslt.subm_type_name = 'SingleEventViolationSubmission' THEN (SELECT COUNT(1) FROM ics_sngl_evt_viol WHERE transaction_type IN ('D','X'))
      WHEN rslt.subm_type_name = 'ScheduleEventViolationSubmission' THEN (SELECT COUNT(1) FROM ics_schd_evt_viol WHERE transaction_type IN ('D','X'))
      WHEN rslt.subm_type_name = 'ComplianceScheduleSubmission' THEN (SELECT COUNT(1) FROM ics_cmpl_schd WHERE transaction_type IN ('D','X'))
      WHEN rslt.subm_type_name = 'DMRViolationSubmission' THEN (SELECT COUNT(1) FROM ics_dmr_viol WHERE transaction_type IN ('D','X'))
      WHEN rslt.subm_type_name = 'ComplianceMonitoringLinkage' THEN (SELECT COUNT(1) FROM ics_cmpl_mon_lnk WHERE transaction_type IN ('D','X'))
      WHEN rslt.subm_type_name = 'FinalOrderViolationLinkageSubmission' THEN (SELECT COUNT(1) FROM ics_final_order_viol_lnk WHERE transaction_type IN ('D','X'))
      WHEN rslt.subm_type_name = 'EnforcementActionViolationLinkageSubmission' THEN (SELECT COUNT(1) FROM ics_enfrc_actn_viol_lnk WHERE transaction_type IN ('D','X'))
      WHEN rslt.subm_type_name = 'DMRProgramReportLinkageSubmission' THEN (SELECT COUNT(1) FROM ics_dmr_prog_rep_lnk WHERE transaction_type IN ('D','X'))
      WHEN rslt.subm_type_name = 'EffluentTradePartnerSubmission' THEN (SELECT COUNT(1) FROM ics_efflu_trade_prtner WHERE transaction_type IN ('D','X'))
      WHEN rslt.subm_type_name = 'FormalEnforcementActionSubmission' THEN (SELECT COUNT(1) FROM ics_frml_enfrc_actn WHERE transaction_type IN ('D','X'))
      WHEN rslt.subm_type_name = 'InformalEnforcementActionSubmission' THEN (SELECT COUNT(1) FROM ics_infrml_enfrc_actn WHERE transaction_type IN ('D','X'))
      WHEN rslt.subm_type_name = 'EnforcementActionMilestoneSubmission' THEN (SELECT COUNT(1) FROM ics_enfrc_actn_milestone WHERE transaction_type IN ('D','X'))
      WHEN rslt.subm_type_name = 'CSOEventReportSubmission' THEN (SELECT COUNT(1) FROM ics_cso_evt_rep WHERE transaction_type IN ('D','X'))
      WHEN rslt.subm_type_name = 'SWEventReportSubmission' THEN (SELECT COUNT(1) FROM ics_sw_evt_rep WHERE transaction_type IN ('D','X'))
      WHEN rslt.subm_type_name = 'CAFOAnnualReportSubmission' THEN (SELECT COUNT(1) FROM ics_cafo_annul_rep WHERE transaction_type IN ('D','X'))
      WHEN rslt.subm_type_name = 'LocalLimitsProgramReportSubmission' THEN (SELECT COUNT(1) FROM ics_loc_lmts_prog_rep WHERE transaction_type IN ('D','X'))
      WHEN rslt.subm_type_name = 'PretreatmentPerformanceSummarySubmission' THEN (SELECT COUNT(1) FROM ics_pretr_perf_summ WHERE transaction_type IN ('D','X'))
      WHEN rslt.subm_type_name = 'BiosolidsProgramReportSubmission' THEN (SELECT COUNT(1) FROM ics_bs_prog_rep WHERE transaction_type IN ('D','X'))
      WHEN rslt.subm_type_name = 'SSOAnnualReportSubmission' THEN (SELECT COUNT(1) FROM ics_sso_annul_rep WHERE transaction_type IN ('D','X'))
      WHEN rslt.subm_type_name = 'SSOEventReportSubmission' THEN (SELECT COUNT(1) FROM ics_sso_evt_rep WHERE transaction_type IN ('D','X'))
      WHEN rslt.subm_type_name = 'SSOMonthlyEventReportSubmission' THEN (SELECT COUNT(1) FROM ics_sso_monthly_evt_rep WHERE transaction_type IN ('D','X'))
      WHEN rslt.subm_type_name = 'SWMS4ProgramReportSubmission' THEN (SELECT COUNT(1) FROM ics_swms_4_prog_rep WHERE transaction_type IN ('D','X'))
    END as trans_count_del_mass_del
  , (  SELECT count(1) 
         FROM ics_subm_results
        WHERE subm_type_name = rslt.subm_type_name
          AND result_type_code = 'Error') as error_count
  , (  SELECT count(1) 
         FROM ics_subm_results
        WHERE subm_type_name = rslt.subm_type_name
          AND result_type_code = 'Warning') as warning_count
, (  SELECT count(1) 
         FROM ics_subm_results
        WHERE subm_type_name = rslt.subm_type_name
          AND result_type_code = 'Accepted') as accepted_count
  , CASE 
      WHEN rslt.subm_type_name = 'BasicPermitSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.ics_basic_prmt)
      WHEN rslt.subm_type_name = 'BiosolidsPermitSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.ics_bs_prmt)
      WHEN rslt.subm_type_name = 'CAFOPermitSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.ics_cafo_prmt)
      WHEN rslt.subm_type_name = 'CSOPermitSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.ics_cso_prmt)
      WHEN rslt.subm_type_name = 'ComplianceMonitoringSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.ics_cmpl_mon)
      WHEN rslt.subm_type_name = 'GeneralPermitSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.ics_gnrl_prmt)
      WHEN rslt.subm_type_name = 'MasterGeneralPermitSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.ics_master_gnrl_prmt)
      WHEN rslt.subm_type_name = 'PermitReissuanceSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.ics_prmt_reissu)
      WHEN rslt.subm_type_name = 'PermitTerminationSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.ics_prmt_term)
      WHEN rslt.subm_type_name = 'PermitTrackingEventSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.ics_prmt_track_evt)
      WHEN rslt.subm_type_name = 'POTWPermitSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.ics_potw_prmt)
      WHEN rslt.subm_type_name = 'PretreatmentPermitSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.ics_pretr_prmt)
      WHEN rslt.subm_type_name = 'SWConstructionPermitSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.ics_sw_cnst_prmt)
      WHEN rslt.subm_type_name = 'SWIndustrialPermitSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.ics_sw_indst_prmt)
      WHEN rslt.subm_type_name = 'SWMS4LargePermitSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.ics_swms_4_large_prmt)
      WHEN rslt.subm_type_name = 'SWMS4SmallPermitSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.ics_swms_4_small_prmt)
      WHEN rslt.subm_type_name = 'UnpermittedFacilitySubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.ics_unprmt_fac)
      WHEN rslt.subm_type_name = 'HistoricalPermitScheduleEventsSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.ics_hist_prmt_schd_evts)
      WHEN rslt.subm_type_name = 'NarrativeConditionScheduleSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.ics_narr_cond_schd)
      WHEN rslt.subm_type_name = 'PermittedFeatureSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.ics_prmt_featr)
      WHEN rslt.subm_type_name = 'LimitSetSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.ics_lmt_set)
      WHEN rslt.subm_type_name = 'LimitsSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.ics_lmts)
      WHEN rslt.subm_type_name = 'ParameterLimitsSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.ics_param_lmts)
      WHEN rslt.subm_type_name = 'DischargeMonitoringReportSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.ics_dsch_mon_rep)
      WHEN rslt.subm_type_name = 'SingleEventViolationSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.ics_sngl_evt_viol)
      WHEN rslt.subm_type_name = 'ScheduleEventViolationSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.ics_schd_evt_viol)
      WHEN rslt.subm_type_name = 'ComplianceScheduleSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.ics_cmpl_schd)
      WHEN rslt.subm_type_name = 'DMRViolationSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.ics_dmr_viol)
      WHEN rslt.subm_type_name = 'ComplianceMonitoringLinkage' THEN (SELECT COUNT(1) FROM ics_flow_icis.ics_cmpl_mon_lnk)
      WHEN rslt.subm_type_name = 'FinalOrderViolationLinkageSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.ics_final_order_viol_lnk)
      WHEN rslt.subm_type_name = 'EnforcementActionViolationLinkageSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.ics_enfrc_actn_viol_lnk)
      WHEN rslt.subm_type_name = 'DMRProgramReportLinkageSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.ics_dmr_prog_rep_lnk)
      WHEN rslt.subm_type_name = 'EffluentTradePartnerSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.ics_efflu_trade_prtner)
      WHEN rslt.subm_type_name = 'FormalEnforcementActionSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.ics_frml_enfrc_actn)
      WHEN rslt.subm_type_name = 'InformalEnforcementActionSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.ics_infrml_enfrc_actn)
      WHEN rslt.subm_type_name = 'EnforcementActionMilestoneSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.ics_enfrc_actn_milestone)
      WHEN rslt.subm_type_name = 'CSOEventReportSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.ics_cso_evt_rep)
      WHEN rslt.subm_type_name = 'SWEventReportSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.ics_sw_evt_rep)
      WHEN rslt.subm_type_name = 'CAFOAnnualReportSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.ics_cafo_annul_rep)
      WHEN rslt.subm_type_name = 'LocalLimitsProgramReportSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.ics_loc_lmts_prog_rep)
      WHEN rslt.subm_type_name = 'PretreatmentPerformanceSummarySubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.ics_pretr_perf_summ)
      WHEN rslt.subm_type_name = 'BiosolidsProgramReportSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.ics_bs_prog_rep)
      WHEN rslt.subm_type_name = 'SSOAnnualReportSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.ics_sso_annul_rep)
      WHEN rslt.subm_type_name = 'SSOEventReportSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.ics_sso_evt_rep)
      WHEN rslt.subm_type_name = 'SSOMonthlyEventReportSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.ics_sso_monthly_evt_rep)
      WHEN rslt.subm_type_name = 'SWMS4ProgramReportSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.ics_swms_4_prog_rep)
    END as accepted_count_total
  FROM ics_subm_results rslt
GROUP BY subm_transaction_id
  , subm_type_name

