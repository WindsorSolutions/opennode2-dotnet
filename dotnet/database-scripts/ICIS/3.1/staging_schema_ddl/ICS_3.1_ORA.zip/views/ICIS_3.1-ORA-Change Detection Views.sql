/*
Copyright (c) 2012, The Environmental Council of the States (ECOS)
All rights reserved.
 
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
 
 * Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
 * Neither the name of the ECOS nor the names of its contributors may
   be used to endorse or promote products derived from this software
   without specific prior written permission.
 
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/
/*************************************************************************************************
** ObjectName: cdv_basic_prmt
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  These views identifies data changes within an ICIS module.  These views
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 03/09/2012     Windsor      Created 
**
***************************************************************************************************/
CREATE OR REPLACE VIEW cdv_basic_prmt AS 
SELECT DISTINCT ics_module
, ics_basic_prmt.key_hash
     , CASE ics_basic_prmt.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ics_basic_prmt tbl
                  WHERE tbl.ics_basic_prmt_id = ics_basic_prmt.ics_basic_prmt_id)
           ELSE (SELECT key_hash 
                   FROM ics_basic_prmt tbl
                  WHERE tbl.ics_basic_prmt_id = ics_basic_prmt.ics_basic_prmt_id)
       END AS module_ident
     , ics_basic_prmt.data_element
     , ics_basic_prmt.action_type
     , ics_basic_prmt.action_code
  FROM (/*  1 - NEW  */
        SELECT ics_basic_prmt.ics_basic_prmt_id
    , ics_basic_prmt.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_BASIC_PRMT' as ics_module
             , 'ICS_BASIC_PRMT' as data_element
          FROM ics_basic_prmt
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ics_basic_prmt tbl
                            WHERE tbl.key_hash = ics_basic_prmt.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ics_basic_prmt_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_BASIC_PRMT' as ics_module
             , 'ICS_BASIC_PRMT' as data_element
          FROM ics_basic_prmt local
          JOIN ics_flow_icis.ics_basic_prmt icis
            ON (icis.key_hash = local.key_hash)
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ics_basic_prmt 
                            WHERE ics_basic_prmt.data_hash = local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ics_basic_prmt.ics_basic_prmt_id
             , ics_basic_prmt.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_BASIC_PRMT' as ics_module
             , 'ICS_BASIC_PRMT' as data_element
          FROM ics_flow_icis.ics_basic_prmt
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_basic_prmt tbl
                            WHERE tbl.key_hash = ics_basic_prmt.key_hash)) ics_basic_prmt;


/*************************************************************************************************
** ObjectName: cdv_bs_prmt
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/9/2012   Windsor      Created 
**
***************************************************************************************************/
CREATE OR REPLACE VIEW cdv_bs_prmt AS 
SELECT DISTINCT ics_module
, ics_bs_prmt.key_hash
     , CASE ics_bs_prmt.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ics_bs_prmt tbl
                  WHERE tbl.ics_bs_prmt_id = ics_bs_prmt.ics_bs_prmt_id)
           ELSE (SELECT key_hash 
                   FROM ics_bs_prmt tbl
                  WHERE tbl.ics_bs_prmt_id = ics_bs_prmt.ics_bs_prmt_id)
       END AS module_ident
     , ics_bs_prmt.data_element
     , ics_bs_prmt.action_type
     , ics_bs_prmt.action_code
  FROM (/*  1 - NEW  */
        SELECT ics_bs_prmt.ics_bs_prmt_id
    , ics_bs_prmt.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_BS_PRMT' as ics_module
             , 'ICS_BS_PRMT' as data_element
          FROM ics_bs_prmt
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ics_bs_prmt tbl
                            WHERE tbl.key_hash = ics_bs_prmt.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ics_bs_prmt_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_BS_PRMT' as ics_module
             , 'ICS_BS_PRMT' as data_element
          FROM ics_bs_prmt local
          JOIN ics_flow_icis.ics_bs_prmt icis
            ON (icis.key_hash = local.key_hash)
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ics_bs_prmt 
                            WHERE ics_bs_prmt.data_hash = local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ics_bs_prmt.ics_bs_prmt_id
             , ics_bs_prmt.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_BS_PRMT' as ics_module
             , 'ICS_BS_PRMT' as data_element
          FROM ics_flow_icis.ics_bs_prmt
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_bs_prmt tbl
                            WHERE tbl.key_hash = ics_bs_prmt.key_hash)) ics_bs_prmt;


/*************************************************************************************************
** ObjectName: cdv_cafo_prmt
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/9/2012   Windsor      Created 
**
***************************************************************************************************/
CREATE OR REPLACE VIEW cdv_cafo_prmt AS 
SELECT DISTINCT ics_module
, ics_cafo_prmt.key_hash
     , CASE ics_cafo_prmt.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ics_cafo_prmt tbl
                  WHERE tbl.ics_cafo_prmt_id = ics_cafo_prmt.ics_cafo_prmt_id)
           ELSE (SELECT key_hash 
                   FROM ics_cafo_prmt tbl
                  WHERE tbl.ics_cafo_prmt_id = ics_cafo_prmt.ics_cafo_prmt_id)
       END AS module_ident
     , ics_cafo_prmt.data_element
     , ics_cafo_prmt.action_type
     , ics_cafo_prmt.action_code
  FROM (/*  1 - NEW  */
        SELECT ics_cafo_prmt.ics_cafo_prmt_id
    , ics_cafo_prmt.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_CAFO_PRMT' as ics_module
             , 'ICS_CAFO_PRMT' as data_element
          FROM ics_cafo_prmt
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ics_cafo_prmt tbl
                            WHERE tbl.key_hash = ics_cafo_prmt.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ics_cafo_prmt_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_CAFO_PRMT' as ics_module
             , 'ICS_CAFO_PRMT' as data_element
          FROM ics_cafo_prmt local
          JOIN ics_flow_icis.ics_cafo_prmt icis
            ON (icis.key_hash = local.key_hash)
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ics_cafo_prmt 
                            WHERE ics_cafo_prmt.data_hash = local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ics_cafo_prmt.ics_cafo_prmt_id
             , ics_cafo_prmt.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_CAFO_PRMT' as ics_module
             , 'ICS_CAFO_PRMT' as data_element
          FROM ics_flow_icis.ics_cafo_prmt
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_cafo_prmt tbl
                            WHERE tbl.key_hash = ics_cafo_prmt.key_hash)) ics_cafo_prmt;


/*************************************************************************************************
** ObjectName: cdv_cso_prmt
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/9/2012   Windsor      Created 
**
***************************************************************************************************/
CREATE OR REPLACE VIEW cdv_cso_prmt AS 
SELECT DISTINCT ics_module
, ics_cso_prmt.key_hash
     , CASE ics_cso_prmt.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ics_cso_prmt tbl
                  WHERE tbl.ics_cso_prmt_id = ics_cso_prmt.ics_cso_prmt_id)
           ELSE (SELECT key_hash 
                   FROM ics_cso_prmt tbl
                  WHERE tbl.ics_cso_prmt_id = ics_cso_prmt.ics_cso_prmt_id)
       END AS module_ident
     , ics_cso_prmt.data_element
     , ics_cso_prmt.action_type
     , ics_cso_prmt.action_code
  FROM (/*  1 - NEW  */
        SELECT ics_cso_prmt.ics_cso_prmt_id
    , ics_cso_prmt.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_CSO_PRMT' as ics_module
             , 'ICS_CSO_PRMT' as data_element
          FROM ics_cso_prmt
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ics_cso_prmt tbl
                            WHERE tbl.key_hash = ics_cso_prmt.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ics_cso_prmt_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_CSO_PRMT' as ics_module
             , 'ICS_CSO_PRMT' as data_element
          FROM ics_cso_prmt local
          JOIN ics_flow_icis.ics_cso_prmt icis
            ON (icis.key_hash = local.key_hash)
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ics_cso_prmt 
                            WHERE ics_cso_prmt.data_hash = local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ics_cso_prmt.ics_cso_prmt_id
             , ics_cso_prmt.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_CSO_PRMT' as ics_module
             , 'ICS_CSO_PRMT' as data_element
          FROM ics_flow_icis.ics_cso_prmt
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_cso_prmt tbl
                            WHERE tbl.key_hash = ics_cso_prmt.key_hash)) ics_cso_prmt;


/*************************************************************************************************
** ObjectName: cdv_cmpl_mon
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/9/2012   Windsor      Created 
**
***************************************************************************************************/
CREATE OR REPLACE VIEW cdv_cmpl_mon AS 
SELECT DISTINCT ics_module
, ics_cmpl_mon.key_hash
     , CASE ics_cmpl_mon.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ics_cmpl_mon tbl
                  WHERE tbl.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id)
           ELSE (SELECT key_hash 
                   FROM ics_cmpl_mon tbl
                  WHERE tbl.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id)
       END AS module_ident
     , ics_cmpl_mon.data_element
     , ics_cmpl_mon.action_type
     , ics_cmpl_mon.action_code
  FROM (/*  1 - NEW  */
        SELECT ics_cmpl_mon.ics_cmpl_mon_id
    , ics_cmpl_mon.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_CMPL_MON' as ics_module
             , 'ICS_CMPL_MON' as data_element
          FROM ics_cmpl_mon
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ics_cmpl_mon tbl
                            WHERE tbl.key_hash = ics_cmpl_mon.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ics_cmpl_mon_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_CMPL_MON' as ics_module
             , 'ICS_CMPL_MON' as data_element
          FROM ics_cmpl_mon local
          JOIN ics_flow_icis.ics_cmpl_mon icis
            ON (icis.key_hash = local.key_hash)
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ics_cmpl_mon 
                            WHERE ics_cmpl_mon.data_hash = local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ics_cmpl_mon.ics_cmpl_mon_id
             , ics_cmpl_mon.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_CMPL_MON' as ics_module
             , 'ICS_CMPL_MON' as data_element
          FROM ics_flow_icis.ics_cmpl_mon
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_cmpl_mon tbl
                            WHERE tbl.key_hash = ics_cmpl_mon.key_hash)) ics_cmpl_mon;


/*************************************************************************************************
** ObjectName: cdv_gnrl_prmt
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/9/2012   Windsor      Created 
**
***************************************************************************************************/
CREATE OR REPLACE VIEW cdv_gnrl_prmt AS 
SELECT DISTINCT ics_module
, ics_gnrl_prmt.key_hash
     , CASE ics_gnrl_prmt.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ics_gnrl_prmt tbl
                  WHERE tbl.ics_gnrl_prmt_id = ics_gnrl_prmt.ics_gnrl_prmt_id)
           ELSE (SELECT key_hash 
                   FROM ics_gnrl_prmt tbl
                  WHERE tbl.ics_gnrl_prmt_id = ics_gnrl_prmt.ics_gnrl_prmt_id)
       END AS module_ident
     , ics_gnrl_prmt.data_element
     , ics_gnrl_prmt.action_type
     , ics_gnrl_prmt.action_code
  FROM (/*  1 - NEW  */
        SELECT ics_gnrl_prmt.ics_gnrl_prmt_id
    , ics_gnrl_prmt.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_GNRL_PRMT' as ics_module
             , 'ICS_GNRL_PRMT' as data_element
          FROM ics_gnrl_prmt
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ics_gnrl_prmt tbl
                            WHERE tbl.key_hash = ics_gnrl_prmt.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ics_gnrl_prmt_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_GNRL_PRMT' as ics_module
             , 'ICS_GNRL_PRMT' as data_element
          FROM ics_gnrl_prmt local
          JOIN ics_flow_icis.ics_gnrl_prmt icis
            ON (icis.key_hash = local.key_hash)
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ics_gnrl_prmt 
                            WHERE ics_gnrl_prmt.data_hash = local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ics_gnrl_prmt.ics_gnrl_prmt_id
             , ics_gnrl_prmt.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_GNRL_PRMT' as ics_module
             , 'ICS_GNRL_PRMT' as data_element
          FROM ics_flow_icis.ics_gnrl_prmt
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_gnrl_prmt tbl
                            WHERE tbl.key_hash = ics_gnrl_prmt.key_hash)) ics_gnrl_prmt;


/*************************************************************************************************
** ObjectName: cdv_master_gnrl_prmt
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/9/2012   Windsor      Created 
**
***************************************************************************************************/
CREATE OR REPLACE VIEW cdv_master_gnrl_prmt AS 
SELECT DISTINCT ics_module
, ics_master_gnrl_prmt.key_hash
     , CASE ics_master_gnrl_prmt.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ics_master_gnrl_prmt tbl
                  WHERE tbl.ics_master_gnrl_prmt_id = ics_master_gnrl_prmt.ics_master_gnrl_prmt_id)
           ELSE (SELECT key_hash 
                   FROM ics_master_gnrl_prmt tbl
                  WHERE tbl.ics_master_gnrl_prmt_id = ics_master_gnrl_prmt.ics_master_gnrl_prmt_id)
       END AS module_ident
     , ics_master_gnrl_prmt.data_element
     , ics_master_gnrl_prmt.action_type
     , ics_master_gnrl_prmt.action_code
  FROM (/*  1 - NEW  */
        SELECT ics_master_gnrl_prmt.ics_master_gnrl_prmt_id
    , ics_master_gnrl_prmt.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_MASTER_GNRL_PRMT' as ics_module
             , 'ICS_MASTER_GNRL_PRMT' as data_element
          FROM ics_master_gnrl_prmt
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ics_master_gnrl_prmt tbl
                            WHERE tbl.key_hash = ics_master_gnrl_prmt.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ics_master_gnrl_prmt_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_MASTER_GNRL_PRMT' as ics_module
             , 'ICS_MASTER_GNRL_PRMT' as data_element
          FROM ics_master_gnrl_prmt local
          JOIN ics_flow_icis.ics_master_gnrl_prmt icis
            ON (icis.key_hash = local.key_hash)
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ics_master_gnrl_prmt 
                            WHERE ics_master_gnrl_prmt.data_hash = local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ics_master_gnrl_prmt.ics_master_gnrl_prmt_id
             , ics_master_gnrl_prmt.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_MASTER_GNRL_PRMT' as ics_module
             , 'ICS_MASTER_GNRL_PRMT' as data_element
          FROM ics_flow_icis.ics_master_gnrl_prmt
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_master_gnrl_prmt tbl
                            WHERE tbl.key_hash = ics_master_gnrl_prmt.key_hash)) ics_master_gnrl_prmt;


/*************************************************************************************************
** ObjectName: cdv_prmt_reissu
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/9/2012   Windsor      Created 
**
***************************************************************************************************/
CREATE OR REPLACE VIEW cdv_prmt_reissu AS 
SELECT DISTINCT ics_module
, ics_prmt_reissu.key_hash
     , CASE ics_prmt_reissu.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ics_prmt_reissu tbl
                  WHERE tbl.ics_prmt_reissu_id = ics_prmt_reissu.ics_prmt_reissu_id)
           ELSE (SELECT key_hash 
                   FROM ics_prmt_reissu tbl
                  WHERE tbl.ics_prmt_reissu_id = ics_prmt_reissu.ics_prmt_reissu_id)
       END AS module_ident
     , ics_prmt_reissu.data_element
     , ics_prmt_reissu.action_type
     , ics_prmt_reissu.action_code
  FROM (/*  1 - NEW  */
        SELECT ics_prmt_reissu.ics_prmt_reissu_id
    , ics_prmt_reissu.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_PRMT_REISSU' as ics_module
             , 'ICS_PRMT_REISSU' as data_element
          FROM ics_prmt_reissu
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ics_prmt_reissu tbl
                            WHERE tbl.key_hash = ics_prmt_reissu.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ics_prmt_reissu_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_PRMT_REISSU' as ics_module
             , 'ICS_PRMT_REISSU' as data_element
          FROM ics_prmt_reissu local
          JOIN ics_flow_icis.ics_prmt_reissu icis
            ON (icis.key_hash = local.key_hash)
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ics_prmt_reissu 
                            WHERE ics_prmt_reissu.data_hash = local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ics_prmt_reissu.ics_prmt_reissu_id
             , ics_prmt_reissu.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_PRMT_REISSU' as ics_module
             , 'ICS_PRMT_REISSU' as data_element
          FROM ics_flow_icis.ics_prmt_reissu
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_prmt_reissu tbl
                            WHERE tbl.key_hash = ics_prmt_reissu.key_hash)) ics_prmt_reissu;


/*************************************************************************************************
** ObjectName: cdv_prmt_term
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/9/2012   Windsor      Created 
**
***************************************************************************************************/
CREATE OR REPLACE VIEW cdv_prmt_term AS 
SELECT DISTINCT ics_module
, ics_prmt_term.key_hash
     , CASE ics_prmt_term.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ics_prmt_term tbl
                  WHERE tbl.ics_prmt_term_id = ics_prmt_term.ics_prmt_term_id)
           ELSE (SELECT key_hash 
                   FROM ics_prmt_term tbl
                  WHERE tbl.ics_prmt_term_id = ics_prmt_term.ics_prmt_term_id)
       END AS module_ident
     , ics_prmt_term.data_element
     , ics_prmt_term.action_type
     , ics_prmt_term.action_code
  FROM (/*  1 - NEW  */
        SELECT ics_prmt_term.ics_prmt_term_id
    , ics_prmt_term.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_PRMT_TERM' as ics_module
             , 'ICS_PRMT_TERM' as data_element
          FROM ics_prmt_term
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ics_prmt_term tbl
                            WHERE tbl.key_hash = ics_prmt_term.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ics_prmt_term_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_PRMT_TERM' as ics_module
             , 'ICS_PRMT_TERM' as data_element
          FROM ics_prmt_term local
          JOIN ics_flow_icis.ics_prmt_term icis
            ON (icis.key_hash = local.key_hash)
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ics_prmt_term 
                            WHERE ics_prmt_term.data_hash = local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ics_prmt_term.ics_prmt_term_id
             , ics_prmt_term.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_PRMT_TERM' as ics_module
             , 'ICS_PRMT_TERM' as data_element
          FROM ics_flow_icis.ics_prmt_term
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_prmt_term tbl
                            WHERE tbl.key_hash = ics_prmt_term.key_hash)) ics_prmt_term;


/*************************************************************************************************
** ObjectName: cdv_prmt_track_evt
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/9/2012   Windsor      Created 
**
***************************************************************************************************/
CREATE OR REPLACE VIEW cdv_prmt_track_evt AS 
SELECT DISTINCT ics_module
, ics_prmt_track_evt.key_hash
     , CASE ics_prmt_track_evt.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ics_prmt_track_evt tbl
                  WHERE tbl.ics_prmt_track_evt_id = ics_prmt_track_evt.ics_prmt_track_evt_id)
           ELSE (SELECT key_hash 
                   FROM ics_prmt_track_evt tbl
                  WHERE tbl.ics_prmt_track_evt_id = ics_prmt_track_evt.ics_prmt_track_evt_id)
       END AS module_ident
     , ics_prmt_track_evt.data_element
     , ics_prmt_track_evt.action_type
     , ics_prmt_track_evt.action_code
  FROM (/*  1 - NEW  */
        SELECT ics_prmt_track_evt.ics_prmt_track_evt_id
    , ics_prmt_track_evt.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_PRMT_TRACK_EVT' as ics_module
             , 'ICS_PRMT_TRACK_EVT' as data_element
          FROM ics_prmt_track_evt
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ics_prmt_track_evt tbl
                            WHERE tbl.key_hash = ics_prmt_track_evt.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ics_prmt_track_evt_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_PRMT_TRACK_EVT' as ics_module
             , 'ICS_PRMT_TRACK_EVT' as data_element
          FROM ics_prmt_track_evt local
          JOIN ics_flow_icis.ics_prmt_track_evt icis
            ON (icis.key_hash = local.key_hash)
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ics_prmt_track_evt 
                            WHERE ics_prmt_track_evt.data_hash = local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ics_prmt_track_evt.ics_prmt_track_evt_id
             , ics_prmt_track_evt.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_PRMT_TRACK_EVT' as ics_module
             , 'ICS_PRMT_TRACK_EVT' as data_element
          FROM ics_flow_icis.ics_prmt_track_evt
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_prmt_track_evt tbl
                            WHERE tbl.key_hash = ics_prmt_track_evt.key_hash)) ics_prmt_track_evt;


/*************************************************************************************************
** ObjectName: cdv_potw_prmt
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/9/2012   Windsor      Created 
**
***************************************************************************************************/
CREATE OR REPLACE VIEW cdv_potw_prmt AS 
SELECT DISTINCT ics_module
, ics_potw_prmt.key_hash
     , CASE ics_potw_prmt.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ics_potw_prmt tbl
                  WHERE tbl.ics_potw_prmt_id = ics_potw_prmt.ics_potw_prmt_id)
           ELSE (SELECT key_hash 
                   FROM ics_potw_prmt tbl
                  WHERE tbl.ics_potw_prmt_id = ics_potw_prmt.ics_potw_prmt_id)
       END AS module_ident
     , ics_potw_prmt.data_element
     , ics_potw_prmt.action_type
     , ics_potw_prmt.action_code
  FROM (/*  1 - NEW  */
        SELECT ics_potw_prmt.ics_potw_prmt_id
    , ics_potw_prmt.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_POTW_PRMT' as ics_module
             , 'ICS_POTW_PRMT' as data_element
          FROM ics_potw_prmt
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ics_potw_prmt tbl
                            WHERE tbl.key_hash = ics_potw_prmt.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ics_potw_prmt_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_POTW_PRMT' as ics_module
             , 'ICS_POTW_PRMT' as data_element
          FROM ics_potw_prmt local
          JOIN ics_flow_icis.ics_potw_prmt icis
            ON (icis.key_hash = local.key_hash)
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ics_potw_prmt 
                            WHERE ics_potw_prmt.data_hash = local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ics_potw_prmt.ics_potw_prmt_id
             , ics_potw_prmt.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_POTW_PRMT' as ics_module
             , 'ICS_POTW_PRMT' as data_element
          FROM ics_flow_icis.ics_potw_prmt
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_potw_prmt tbl
                            WHERE tbl.key_hash = ics_potw_prmt.key_hash)) ics_potw_prmt;


/*************************************************************************************************
** ObjectName: cdv_pretr_prmt
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/9/2012   Windsor      Created 
**
***************************************************************************************************/
CREATE OR REPLACE VIEW cdv_pretr_prmt AS 
SELECT DISTINCT ics_module
, ics_pretr_prmt.key_hash
     , CASE ics_pretr_prmt.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ics_pretr_prmt tbl
                  WHERE tbl.ics_pretr_prmt_id = ics_pretr_prmt.ics_pretr_prmt_id)
           ELSE (SELECT key_hash 
                   FROM ics_pretr_prmt tbl
                  WHERE tbl.ics_pretr_prmt_id = ics_pretr_prmt.ics_pretr_prmt_id)
       END AS module_ident
     , ics_pretr_prmt.data_element
     , ics_pretr_prmt.action_type
     , ics_pretr_prmt.action_code
  FROM (/*  1 - NEW  */
        SELECT ics_pretr_prmt.ics_pretr_prmt_id
    , ics_pretr_prmt.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_PRETR_PRMT' as ics_module
             , 'ICS_PRETR_PRMT' as data_element
          FROM ics_pretr_prmt
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ics_pretr_prmt tbl
                            WHERE tbl.key_hash = ics_pretr_prmt.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ics_pretr_prmt_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_PRETR_PRMT' as ics_module
             , 'ICS_PRETR_PRMT' as data_element
          FROM ics_pretr_prmt local
          JOIN ics_flow_icis.ics_pretr_prmt icis
            ON (icis.key_hash = local.key_hash)
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ics_pretr_prmt 
                            WHERE ics_pretr_prmt.data_hash = local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ics_pretr_prmt.ics_pretr_prmt_id
             , ics_pretr_prmt.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_PRETR_PRMT' as ics_module
             , 'ICS_PRETR_PRMT' as data_element
          FROM ics_flow_icis.ics_pretr_prmt
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_pretr_prmt tbl
                            WHERE tbl.key_hash = ics_pretr_prmt.key_hash)) ics_pretr_prmt;


/*************************************************************************************************
** ObjectName: cdv_sw_cnst_prmt
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/9/2012   Windsor      Created 
**
***************************************************************************************************/
CREATE OR REPLACE VIEW cdv_sw_cnst_prmt AS 
SELECT DISTINCT ics_module
, ics_sw_cnst_prmt.key_hash
     , CASE ics_sw_cnst_prmt.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ics_sw_cnst_prmt tbl
                  WHERE tbl.ics_sw_cnst_prmt_id = ics_sw_cnst_prmt.ics_sw_cnst_prmt_id)
           ELSE (SELECT key_hash 
                   FROM ics_sw_cnst_prmt tbl
                  WHERE tbl.ics_sw_cnst_prmt_id = ics_sw_cnst_prmt.ics_sw_cnst_prmt_id)
       END AS module_ident
     , ics_sw_cnst_prmt.data_element
     , ics_sw_cnst_prmt.action_type
     , ics_sw_cnst_prmt.action_code
  FROM (/*  1 - NEW  */
        SELECT ics_sw_cnst_prmt.ics_sw_cnst_prmt_id
    , ics_sw_cnst_prmt.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_SW_CNST_PRMT' as ics_module
             , 'ICS_SW_CNST_PRMT' as data_element
          FROM ics_sw_cnst_prmt
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ics_sw_cnst_prmt tbl
                            WHERE tbl.key_hash = ics_sw_cnst_prmt.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ics_sw_cnst_prmt_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_SW_CNST_PRMT' as ics_module
             , 'ICS_SW_CNST_PRMT' as data_element
          FROM ics_sw_cnst_prmt local
          JOIN ics_flow_icis.ics_sw_cnst_prmt icis
            ON (icis.key_hash = local.key_hash)
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ics_sw_cnst_prmt 
                            WHERE ics_sw_cnst_prmt.data_hash = local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ics_sw_cnst_prmt.ics_sw_cnst_prmt_id
             , ics_sw_cnst_prmt.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_SW_CNST_PRMT' as ics_module
             , 'ICS_SW_CNST_PRMT' as data_element
          FROM ics_flow_icis.ics_sw_cnst_prmt
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_sw_cnst_prmt tbl
                            WHERE tbl.key_hash = ics_sw_cnst_prmt.key_hash)) ics_sw_cnst_prmt;


/*************************************************************************************************
** ObjectName: cdv_sw_indst_prmt
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/9/2012   Windsor      Created 
**
***************************************************************************************************/
CREATE OR REPLACE VIEW cdv_sw_indst_prmt AS 
SELECT DISTINCT ics_module
, ics_sw_indst_prmt.key_hash
     , CASE ics_sw_indst_prmt.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ics_sw_indst_prmt tbl
                  WHERE tbl.ics_sw_indst_prmt_id = ics_sw_indst_prmt.ics_sw_indst_prmt_id)
           ELSE (SELECT key_hash 
                   FROM ics_sw_indst_prmt tbl
                  WHERE tbl.ics_sw_indst_prmt_id = ics_sw_indst_prmt.ics_sw_indst_prmt_id)
       END AS module_ident
     , ics_sw_indst_prmt.data_element
     , ics_sw_indst_prmt.action_type
     , ics_sw_indst_prmt.action_code
  FROM (/*  1 - NEW  */
        SELECT ics_sw_indst_prmt.ics_sw_indst_prmt_id
    , ics_sw_indst_prmt.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_SW_INDST_PRMT' as ics_module
             , 'ICS_SW_INDST_PRMT' as data_element
          FROM ics_sw_indst_prmt
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ics_sw_indst_prmt tbl
                            WHERE tbl.key_hash = ics_sw_indst_prmt.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ics_sw_indst_prmt_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_SW_INDST_PRMT' as ics_module
             , 'ICS_SW_INDST_PRMT' as data_element
          FROM ics_sw_indst_prmt local
          JOIN ics_flow_icis.ics_sw_indst_prmt icis
            ON (icis.key_hash = local.key_hash)
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ics_sw_indst_prmt 
                            WHERE ics_sw_indst_prmt.data_hash = local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ics_sw_indst_prmt.ics_sw_indst_prmt_id
             , ics_sw_indst_prmt.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_SW_INDST_PRMT' as ics_module
             , 'ICS_SW_INDST_PRMT' as data_element
          FROM ics_flow_icis.ics_sw_indst_prmt
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_sw_indst_prmt tbl
                            WHERE tbl.key_hash = ics_sw_indst_prmt.key_hash)) ics_sw_indst_prmt;


/*************************************************************************************************
** ObjectName: cdv_swms_4_large_prmt
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/9/2012   Windsor      Created 
**
***************************************************************************************************/
CREATE OR REPLACE VIEW cdv_swms_4_large_prmt AS 
SELECT DISTINCT ics_module
, ics_swms_4_large_prmt.key_hash
     , CASE ics_swms_4_large_prmt.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ics_swms_4_large_prmt tbl
                  WHERE tbl.ics_swms_4_large_prmt_id = ics_swms_4_large_prmt.ics_swms_4_large_prmt_id)
           ELSE (SELECT key_hash 
                   FROM ics_swms_4_large_prmt tbl
                  WHERE tbl.ics_swms_4_large_prmt_id = ics_swms_4_large_prmt.ics_swms_4_large_prmt_id)
       END AS module_ident
     , ics_swms_4_large_prmt.data_element
     , ics_swms_4_large_prmt.action_type
     , ics_swms_4_large_prmt.action_code
  FROM (/*  1 - NEW  */
        SELECT ics_swms_4_large_prmt.ics_swms_4_large_prmt_id
    , ics_swms_4_large_prmt.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_SWMS_4_LARGE_PRMT' as ics_module
             , 'ICS_SWMS_4_LARGE_PRMT' as data_element
          FROM ics_swms_4_large_prmt
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ics_swms_4_large_prmt tbl
                            WHERE tbl.key_hash = ics_swms_4_large_prmt.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ics_swms_4_large_prmt_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_SWMS_4_LARGE_PRMT' as ics_module
             , 'ICS_SWMS_4_LARGE_PRMT' as data_element
          FROM ics_swms_4_large_prmt local
          JOIN ics_flow_icis.ics_swms_4_large_prmt icis
            ON (icis.key_hash = local.key_hash)
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ics_swms_4_large_prmt 
                            WHERE ics_swms_4_large_prmt.data_hash = local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ics_swms_4_large_prmt.ics_swms_4_large_prmt_id
             , ics_swms_4_large_prmt.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_SWMS_4_LARGE_PRMT' as ics_module
             , 'ICS_SWMS_4_LARGE_PRMT' as data_element
          FROM ics_flow_icis.ics_swms_4_large_prmt
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_swms_4_large_prmt tbl
                            WHERE tbl.key_hash = ics_swms_4_large_prmt.key_hash)) ics_swms_4_large_prmt;


/*************************************************************************************************
** ObjectName: cdv_swms_4_small_prmt
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/9/2012   Windsor      Created 
**
***************************************************************************************************/
CREATE OR REPLACE VIEW cdv_swms_4_small_prmt AS 
SELECT DISTINCT ics_module
, ics_swms_4_small_prmt.key_hash
     , CASE ics_swms_4_small_prmt.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ics_swms_4_small_prmt tbl
                  WHERE tbl.ics_swms_4_small_prmt_id = ics_swms_4_small_prmt.ics_swms_4_small_prmt_id)
           ELSE (SELECT key_hash 
                   FROM ics_swms_4_small_prmt tbl
                  WHERE tbl.ics_swms_4_small_prmt_id = ics_swms_4_small_prmt.ics_swms_4_small_prmt_id)
       END AS module_ident
     , ics_swms_4_small_prmt.data_element
     , ics_swms_4_small_prmt.action_type
     , ics_swms_4_small_prmt.action_code
  FROM (/*  1 - NEW  */
        SELECT ics_swms_4_small_prmt.ics_swms_4_small_prmt_id
    , ics_swms_4_small_prmt.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_SWMS_4_SMALL_PRMT' as ics_module
             , 'ICS_SWMS_4_SMALL_PRMT' as data_element
          FROM ics_swms_4_small_prmt
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ics_swms_4_small_prmt tbl
                            WHERE tbl.key_hash = ics_swms_4_small_prmt.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ics_swms_4_small_prmt_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_SWMS_4_SMALL_PRMT' as ics_module
             , 'ICS_SWMS_4_SMALL_PRMT' as data_element
          FROM ics_swms_4_small_prmt local
          JOIN ics_flow_icis.ics_swms_4_small_prmt icis
            ON (icis.key_hash = local.key_hash)
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ics_swms_4_small_prmt 
                            WHERE ics_swms_4_small_prmt.data_hash = local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ics_swms_4_small_prmt.ics_swms_4_small_prmt_id
             , ics_swms_4_small_prmt.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_SWMS_4_SMALL_PRMT' as ics_module
             , 'ICS_SWMS_4_SMALL_PRMT' as data_element
          FROM ics_flow_icis.ics_swms_4_small_prmt
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_swms_4_small_prmt tbl
                            WHERE tbl.key_hash = ics_swms_4_small_prmt.key_hash)) ics_swms_4_small_prmt;


/*************************************************************************************************
** ObjectName: cdv_unprmt_fac
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/9/2012   Windsor      Created 
**
***************************************************************************************************/
CREATE OR REPLACE VIEW cdv_unprmt_fac AS 
SELECT DISTINCT ics_module
, ics_unprmt_fac.key_hash
     , CASE ics_unprmt_fac.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ics_unprmt_fac tbl
                  WHERE tbl.ics_unprmt_fac_id = ics_unprmt_fac.ics_unprmt_fac_id)
           ELSE (SELECT key_hash 
                   FROM ics_unprmt_fac tbl
                  WHERE tbl.ics_unprmt_fac_id = ics_unprmt_fac.ics_unprmt_fac_id)
       END AS module_ident
     , ics_unprmt_fac.data_element
     , ics_unprmt_fac.action_type
     , ics_unprmt_fac.action_code
  FROM (/*  1 - NEW  */
        SELECT ics_unprmt_fac.ics_unprmt_fac_id
    , ics_unprmt_fac.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_UNPRMT_FAC' as ics_module
             , 'ICS_UNPRMT_FAC' as data_element
          FROM ics_unprmt_fac
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ics_unprmt_fac tbl
                            WHERE tbl.key_hash = ics_unprmt_fac.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ics_unprmt_fac_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_UNPRMT_FAC' as ics_module
             , 'ICS_UNPRMT_FAC' as data_element
          FROM ics_unprmt_fac local
          JOIN ics_flow_icis.ics_unprmt_fac icis
            ON (icis.key_hash = local.key_hash)
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ics_unprmt_fac 
                            WHERE ics_unprmt_fac.data_hash = local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ics_unprmt_fac.ics_unprmt_fac_id
             , ics_unprmt_fac.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_UNPRMT_FAC' as ics_module
             , 'ICS_UNPRMT_FAC' as data_element
          FROM ics_flow_icis.ics_unprmt_fac
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_unprmt_fac tbl
                            WHERE tbl.key_hash = ics_unprmt_fac.key_hash)) ics_unprmt_fac;


/*************************************************************************************************
** ObjectName: cdv_hist_prmt_schd_evts
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/9/2012   Windsor      Created 
**
***************************************************************************************************/
CREATE OR REPLACE VIEW cdv_hist_prmt_schd_evts AS 
SELECT DISTINCT ics_module
, ics_hist_prmt_schd_evts.key_hash
     , CASE ics_hist_prmt_schd_evts.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ics_hist_prmt_schd_evts tbl
                  WHERE tbl.ics_hist_prmt_schd_evts_id = ics_hist_prmt_schd_evts.ics_hist_prmt_schd_evts_id)
           ELSE (SELECT key_hash 
                   FROM ics_hist_prmt_schd_evts tbl
                  WHERE tbl.ics_hist_prmt_schd_evts_id = ics_hist_prmt_schd_evts.ics_hist_prmt_schd_evts_id)
       END AS module_ident
     , ics_hist_prmt_schd_evts.data_element
     , ics_hist_prmt_schd_evts.action_type
     , ics_hist_prmt_schd_evts.action_code
  FROM (/*  1 - NEW  */
        SELECT ics_hist_prmt_schd_evts.ics_hist_prmt_schd_evts_id
    , ics_hist_prmt_schd_evts.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_HIST_PRMT_SCHD_EVTS' as ics_module
             , 'ICS_HIST_PRMT_SCHD_EVTS' as data_element
          FROM ics_hist_prmt_schd_evts
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ics_hist_prmt_schd_evts tbl
                            WHERE tbl.key_hash = ics_hist_prmt_schd_evts.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ics_hist_prmt_schd_evts_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_HIST_PRMT_SCHD_EVTS' as ics_module
             , 'ICS_HIST_PRMT_SCHD_EVTS' as data_element
          FROM ics_hist_prmt_schd_evts local
          JOIN ics_flow_icis.ics_hist_prmt_schd_evts icis
            ON (icis.key_hash = local.key_hash)
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ics_hist_prmt_schd_evts 
                            WHERE ics_hist_prmt_schd_evts.data_hash = local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ics_hist_prmt_schd_evts.ics_hist_prmt_schd_evts_id
             , ics_hist_prmt_schd_evts.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_HIST_PRMT_SCHD_EVTS' as ics_module
             , 'ICS_HIST_PRMT_SCHD_EVTS' as data_element
          FROM ics_flow_icis.ics_hist_prmt_schd_evts
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_hist_prmt_schd_evts tbl
                            WHERE tbl.key_hash = ics_hist_prmt_schd_evts.key_hash)) ics_hist_prmt_schd_evts;


/*************************************************************************************************
** ObjectName: cdv_narr_cond_schd
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/9/2012   Windsor      Created 
**
***************************************************************************************************/
CREATE OR REPLACE VIEW cdv_narr_cond_schd AS 
SELECT DISTINCT ics_module
, ics_narr_cond_schd.key_hash
     , CASE ics_narr_cond_schd.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ics_narr_cond_schd tbl
                  WHERE tbl.ics_narr_cond_schd_id = ics_narr_cond_schd.ics_narr_cond_schd_id)
           ELSE (SELECT key_hash 
                   FROM ics_narr_cond_schd tbl
                  WHERE tbl.ics_narr_cond_schd_id = ics_narr_cond_schd.ics_narr_cond_schd_id)
       END AS module_ident
     , ics_narr_cond_schd.data_element
     , ics_narr_cond_schd.action_type
     , ics_narr_cond_schd.action_code
  FROM (/*  1 - NEW  */
        SELECT ics_narr_cond_schd.ics_narr_cond_schd_id
    , ics_narr_cond_schd.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_NARR_COND_SCHD' as ics_module
             , 'ICS_NARR_COND_SCHD' as data_element
          FROM ics_narr_cond_schd
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ics_narr_cond_schd tbl
                            WHERE tbl.key_hash = ics_narr_cond_schd.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ics_narr_cond_schd_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_NARR_COND_SCHD' as ics_module
             , 'ICS_NARR_COND_SCHD' as data_element
          FROM ics_narr_cond_schd local
          JOIN ics_flow_icis.ics_narr_cond_schd icis
            ON (icis.key_hash = local.key_hash)
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ics_narr_cond_schd 
                            WHERE ics_narr_cond_schd.data_hash = local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ics_narr_cond_schd.ics_narr_cond_schd_id
             , ics_narr_cond_schd.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_NARR_COND_SCHD' as ics_module
             , 'ICS_NARR_COND_SCHD' as data_element
          FROM ics_flow_icis.ics_narr_cond_schd
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_narr_cond_schd tbl
                            WHERE tbl.key_hash = ics_narr_cond_schd.key_hash)) ics_narr_cond_schd;


/*************************************************************************************************
** ObjectName: cdv_prmt_featr
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/9/2012   Windsor      Created 
**
***************************************************************************************************/
CREATE OR REPLACE VIEW cdv_prmt_featr AS 
SELECT DISTINCT ics_module
, ics_prmt_featr.key_hash
     , CASE ics_prmt_featr.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ics_prmt_featr tbl
                  WHERE tbl.ics_prmt_featr_id = ics_prmt_featr.ics_prmt_featr_id)
           ELSE (SELECT key_hash 
                   FROM ics_prmt_featr tbl
                  WHERE tbl.ics_prmt_featr_id = ics_prmt_featr.ics_prmt_featr_id)
       END AS module_ident
     , ics_prmt_featr.data_element
     , ics_prmt_featr.action_type
     , ics_prmt_featr.action_code
  FROM (/*  1 - NEW  */
        SELECT ics_prmt_featr.ics_prmt_featr_id
    , ics_prmt_featr.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_PRMT_FEATR' as ics_module
             , 'ICS_PRMT_FEATR' as data_element
          FROM ics_prmt_featr
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ics_prmt_featr tbl
                            WHERE tbl.key_hash = ics_prmt_featr.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ics_prmt_featr_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_PRMT_FEATR' as ics_module
             , 'ICS_PRMT_FEATR' as data_element
          FROM ics_prmt_featr local
          JOIN ics_flow_icis.ics_prmt_featr icis
            ON (icis.key_hash = local.key_hash)
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ics_prmt_featr 
                            WHERE ics_prmt_featr.data_hash = local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ics_prmt_featr.ics_prmt_featr_id
             , ics_prmt_featr.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_PRMT_FEATR' as ics_module
             , 'ICS_PRMT_FEATR' as data_element
          FROM ics_flow_icis.ics_prmt_featr
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_prmt_featr tbl
                            WHERE tbl.key_hash = ics_prmt_featr.key_hash)) ics_prmt_featr;


/*************************************************************************************************
** ObjectName: cdv_lmt_set
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/9/2012   Windsor      Created 
**
***************************************************************************************************/
CREATE OR REPLACE VIEW cdv_lmt_set AS 
SELECT DISTINCT ics_module
, ics_lmt_set.key_hash
     , CASE ics_lmt_set.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ics_lmt_set tbl
                  WHERE tbl.ics_lmt_set_id = ics_lmt_set.ics_lmt_set_id)
           ELSE (SELECT key_hash 
                   FROM ics_lmt_set tbl
                  WHERE tbl.ics_lmt_set_id = ics_lmt_set.ics_lmt_set_id)
       END AS module_ident
     , ics_lmt_set.data_element
     , ics_lmt_set.action_type
     , ics_lmt_set.action_code
  FROM (/*  1 - NEW  */
        SELECT ics_lmt_set.ics_lmt_set_id
    , ics_lmt_set.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_LMT_SET' as ics_module
             , 'ICS_LMT_SET' as data_element
          FROM ics_lmt_set
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ics_lmt_set tbl
                            WHERE tbl.key_hash = ics_lmt_set.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ics_lmt_set_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_LMT_SET' as ics_module
             , 'ICS_LMT_SET' as data_element
          FROM ics_lmt_set local
          JOIN ics_flow_icis.ics_lmt_set icis
            ON (icis.key_hash = local.key_hash)
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ics_lmt_set 
                            WHERE ics_lmt_set.data_hash = local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ics_lmt_set.ics_lmt_set_id
             , ics_lmt_set.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_LMT_SET' as ics_module
             , 'ICS_LMT_SET' as data_element
          FROM ics_flow_icis.ics_lmt_set
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_lmt_set tbl
                            WHERE tbl.key_hash = ics_lmt_set.key_hash)) ics_lmt_set;


/*************************************************************************************************
** ObjectName: cdv_lmts
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/9/2012   Windsor      Created 
**
***************************************************************************************************/
CREATE OR REPLACE VIEW cdv_lmts AS 
SELECT DISTINCT ics_module
, ics_lmts.key_hash
     , CASE ics_lmts.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ics_lmts tbl
                  WHERE tbl.ics_lmts_id = ics_lmts.ics_lmts_id)
           ELSE (SELECT key_hash 
                   FROM ics_lmts tbl
                  WHERE tbl.ics_lmts_id = ics_lmts.ics_lmts_id)
       END AS module_ident
     , ics_lmts.data_element
     , ics_lmts.action_type
     , ics_lmts.action_code
  FROM (/*  1 - NEW  */
        SELECT ics_lmts.ics_lmts_id
    , ics_lmts.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_LMTS' as ics_module
             , 'ICS_LMTS' as data_element
          FROM ics_lmts
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ics_lmts tbl
                            WHERE tbl.key_hash = ics_lmts.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ics_lmts_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_LMTS' as ics_module
             , 'ICS_LMTS' as data_element
          FROM ics_lmts local
          JOIN ics_flow_icis.ics_lmts icis
            ON (icis.key_hash = local.key_hash)
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ics_lmts 
                            WHERE ics_lmts.data_hash = local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ics_lmts.ics_lmts_id
             , ics_lmts.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_LMTS' as ics_module
             , 'ICS_LMTS' as data_element
          FROM ics_flow_icis.ics_lmts
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_lmts tbl
                            WHERE tbl.key_hash = ics_lmts.key_hash)) ics_lmts;


/*************************************************************************************************
** ObjectName: cdv_param_lmts
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/9/2012   Windsor      Created 
**
***************************************************************************************************/
CREATE OR REPLACE VIEW cdv_param_lmts AS 
SELECT DISTINCT ics_module
, ics_param_lmts.key_hash
     , CASE ics_param_lmts.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ics_param_lmts tbl
                  WHERE tbl.ics_param_lmts_id = ics_param_lmts.ics_param_lmts_id)
           ELSE (SELECT key_hash 
                   FROM ics_param_lmts tbl
                  WHERE tbl.ics_param_lmts_id = ics_param_lmts.ics_param_lmts_id)
       END AS module_ident
     , ics_param_lmts.data_element
     , ics_param_lmts.action_type
     , ics_param_lmts.action_code
  FROM (/*  1 - NEW  */
        SELECT ics_param_lmts.ics_param_lmts_id
    , ics_param_lmts.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_PARAM_LMTS' as ics_module
             , 'ICS_PARAM_LMTS' as data_element
          FROM ics_param_lmts
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ics_param_lmts tbl
                            WHERE tbl.key_hash = ics_param_lmts.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ics_param_lmts_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_PARAM_LMTS' as ics_module
             , 'ICS_PARAM_LMTS' as data_element
          FROM ics_param_lmts local
          JOIN ics_flow_icis.ics_param_lmts icis
            ON (icis.key_hash = local.key_hash)
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ics_param_lmts 
                            WHERE ics_param_lmts.data_hash = local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ics_param_lmts.ics_param_lmts_id
             , ics_param_lmts.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_PARAM_LMTS' as ics_module
             , 'ICS_PARAM_LMTS' as data_element
          FROM ics_flow_icis.ics_param_lmts
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_param_lmts tbl
                            WHERE tbl.key_hash = ics_param_lmts.key_hash)) ics_param_lmts;


/*************************************************************************************************
** ObjectName: cdv_dsch_mon_rep
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/9/2012   Windsor      Created 
**
***************************************************************************************************/
CREATE OR REPLACE VIEW cdv_dsch_mon_rep AS 
SELECT DISTINCT ics_module
, ics_dsch_mon_rep.key_hash
     , CASE ics_dsch_mon_rep.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ics_dsch_mon_rep tbl
                  WHERE tbl.ics_dsch_mon_rep_id = ics_dsch_mon_rep.ics_dsch_mon_rep_id)
           ELSE (SELECT key_hash 
                   FROM ics_dsch_mon_rep tbl
                  WHERE tbl.ics_dsch_mon_rep_id = ics_dsch_mon_rep.ics_dsch_mon_rep_id)
       END AS module_ident
     , ics_dsch_mon_rep.data_element
     , ics_dsch_mon_rep.action_type
     , ics_dsch_mon_rep.action_code
  FROM (/*  1 - NEW  */
        SELECT ics_dsch_mon_rep.ics_dsch_mon_rep_id
    , ics_dsch_mon_rep.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_DSCH_MON_REP' as ics_module
             , 'ICS_DSCH_MON_REP' as data_element
          FROM ics_dsch_mon_rep
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ics_dsch_mon_rep tbl
                            WHERE tbl.key_hash = ics_dsch_mon_rep.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ics_dsch_mon_rep_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_DSCH_MON_REP' as ics_module
             , 'ICS_DSCH_MON_REP' as data_element
          FROM ics_dsch_mon_rep local
          JOIN ics_flow_icis.ics_dsch_mon_rep icis
            ON (icis.key_hash = local.key_hash)
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ics_dsch_mon_rep 
                            WHERE ics_dsch_mon_rep.data_hash = local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ics_dsch_mon_rep.ics_dsch_mon_rep_id
             , ics_dsch_mon_rep.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_DSCH_MON_REP' as ics_module
             , 'ICS_DSCH_MON_REP' as data_element
          FROM ics_flow_icis.ics_dsch_mon_rep
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_dsch_mon_rep tbl
                            WHERE tbl.key_hash = ics_dsch_mon_rep.key_hash)) ics_dsch_mon_rep;


