/******************************************************************************************************************************
** ProcedureName: ICS_ETL
**
** Description:  This procedure has been developed to extract, transform, and load date from a source information system into
**               a set of LOCAL ICIS staging tables.
**
** Revision History:      
** ----------------------------------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ----------------------------------------------------------------------------------------------------------------------------
** DD/MM/YYYY    XXxxxxx     Created
**
******************************************************************************************************************************/
CREATE OR REPLACE PROCEDURE ICS_ETL

AS 

BEGIN 

  /*
   *  ETL ICIS DATA
   */
   FOR select_rec IN (SELECT 'ADD ICIS EXTRACT LOGIC HERE' FROM DUAL) LOOP
                        
     NULL;

   END LOOP;
   
END ICS_ETL;