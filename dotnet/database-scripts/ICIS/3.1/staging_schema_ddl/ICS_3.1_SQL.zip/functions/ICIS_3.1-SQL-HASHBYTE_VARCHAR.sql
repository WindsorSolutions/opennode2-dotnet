ALTER FUNCTION HASHBYTES_VARCHAR ( @p_algorithm VARCHAR(04)
                                 , @p_string_input VARCHAR(MAX)) 


RETURNS VARCHAR(100)

AS

BEGIN

DECLARE @v_output_text AS VARCHAR(200);
DECLARE @v_hashbytes_binary AS VARBINARY(8000);

SET @v_hashbytes_binary = HASHBYTES(@p_algorithm,@p_string_input);

SELECT @v_output_text = CAST(N'' AS XML).value('xs:base64Binary(xs:hexBinary(sql:column("bin")))', 'VARCHAR(MAX)') 
  FROM ( SELECT @v_hashbytes_binary AS bin ) AS bin_sql_server_temp;
     
 RETURN @v_output_text ; 
   
END;