/*
Copyright (c) 2012, The Environmental Council of the States (ECOS)
All rights reserved.
 
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
 
 * Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
 * Neither the name of the ECOS nor the names of its contributors may
   be used to endorse or promote products derived from this software
   without specific prior written permission.
 
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/
SELECT * 
FROM
(SELECT     o.name AS TABLE_NAME, c.name AS COLUMN_NAME, p.value AS XML_ELEMENT_NAME, CASE WHEN c.isnullable = 0 THEN 'No' ELSE 'Yes' END AS IS_NULLABLE,
                       c.colorder AS COLUMN_ORDER
FROM         sys.sysobjects AS o INNER JOIN
                      sys.syscolumns AS c ON o.id = c.id INNER JOIN
                      sys.objects AS os ON o.id = os.[object_id] INNER JOIN
                      sys.schemas AS s ON os.[schema_id] = s.[schema_id] INNER JOIN
                      sys.systypes AS t ON c.xusertype = t.xtype LEFT OUTER JOIN
                      sys.extended_properties AS p ON p.minor_id = c.colid AND p.major_id = c.id
                      AND p.[name] = 'MS_Description'
WHERE     (o.xtype = 'U') AND (o.name <> 'dtproperties') AND (o.name <> 'sysdiagrams')
UNION
SELECT     o.name AS TABLE_NAME, null as COLUMN_NAME, REPLACE(CONVERT(varchar(100),p.value),'Schema element: ','') AS XML_ELEMENT_NAME, NULL as IS_NULLABLE, NULL as COLUMN_ORDER
FROM         sys.sysobjects AS o INNER JOIN
             sys.objects AS os ON o.id = os.[object_id] INNER JOIN
             sys.schemas AS s ON os.[schema_id] = s.[schema_id] LEFT OUTER JOIN
                      sys.extended_properties AS p ON p.major_id = o.id AND p.minor_id = 0 AND p.[name] = 'MS_Description'
WHERE     (o.xtype = 'U') AND (o.name <> 'dtproperties') AND (o.name <> 'sysdiagrams')
) x
ORDER BY TABLE_NAME, COLUMN_ORDER