/******************************************************************************************************************************
** ProcedureName: ICS_ETL
**
** Description:  This procedure has been developed to extract, transform, and load data from a source information system into
**               a set of LOCAL ICIS staging tables.
**
** Revision History:      
** ----------------------------------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ----------------------------------------------------------------------------------------------------------------------------
** DD/MM/YYYY    XXxxxxx     Created
**
******************************************************************************************************************************/
CREATE PROCEDURE ICS_ETL

AS 

DECLARE @v_text AS NVARCHAR(50);

BEGIN 
  
  /*
   *  ETL ICIS DATA
   */
   SET @v_text = 'Add customized ETL extract logic here.';
      
END;