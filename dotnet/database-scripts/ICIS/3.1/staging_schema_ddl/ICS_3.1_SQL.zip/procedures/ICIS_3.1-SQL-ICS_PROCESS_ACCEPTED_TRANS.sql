IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.ICS_PROCESS_ACCEPTED_TRANS') AND type in (N'P', N'PC'))
DROP PROCEDURE dbo.ics_process_accepted_trans
GO


/*************************************************************************************************
** ObjectName: ics_process_accepted_trans
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure uses the data in ICS_SUBM_RESULTS table to copy the data for accepted
**               transactions from the LOCAL to ICIS schema/database. It should only be executed by
**               the OpenNode2 plugin as part of the GetICISStatusAndProcessReports service execution
**
**  Step 1: Update key_hash with hashed business key data
**  Step 2: Remove previous error transactions that have were resent in the most recent transaction
**  Step 3: Move accepted transactions from LOCAL to ICIS database
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
**  03/09/2012   Windsor     Created 
**
***************************************************************************************************/
CREATE PROCEDURE dbo.ICS_PROCESS_ACCEPTED_TRANS

   @p_transaction_id varchar(50)

AS
 DECLARE @v_error_message NVARCHAR(2048);
 DECLARE @v_error_number INT;
 DECLARE @v_process NVARCHAR(30);
BEGIN TRANSACTION PROCESS_ACCEPTED_TRANS
  BEGIN TRY
 /*  
  *  Step 1: Update key_hash with hashed business key data
  */
  UPDATE ics_subm_results
     SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', prmt_ident)
   WHERE subm_type_name = 'BasicPermitSubmission'
     AND result_type_code IN ('Accepted','Warning');

  UPDATE ics_subm_results
     SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', prmt_ident)
   WHERE subm_type_name = 'BiosolidsPermitSubmission'
     AND result_type_code IN ('Accepted','Warning');

  UPDATE ics_subm_results
     SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', prmt_ident)
   WHERE subm_type_name = 'CAFOPermitSubmission'
     AND result_type_code IN ('Accepted','Warning');

  UPDATE ics_subm_results
     SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', prmt_ident)
   WHERE subm_type_name = 'CSOPermitSubmission'
     AND result_type_code IN ('Accepted','Warning');

  UPDATE ics_subm_results
     SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', prmt_ident +  cmpl_mon_catg_code + CONVERT(varchar(50), cmpl_mon_date))
   WHERE subm_type_name = 'ComplianceMonitoringSubmission'
     AND result_type_code IN ('Accepted','Warning');

  UPDATE ics_subm_results
     SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', prmt_ident)
   WHERE subm_type_name = 'GeneralPermitSubmission'
     AND result_type_code IN ('Accepted','Warning');

  UPDATE ics_subm_results
     SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', prmt_ident)
   WHERE subm_type_name = 'MasterGeneralPermitSubmission'
     AND result_type_code IN ('Accepted','Warning');

  UPDATE ics_subm_results
     SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', prmt_ident + CONVERT(varchar(50), prmt_issue_date))
   WHERE subm_type_name = 'PermitReissuanceSubmission'
     AND result_type_code IN ('Accepted','Warning');

  UPDATE ics_subm_results
     SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', prmt_ident)
   WHERE subm_type_name = 'PermitTerminationSubmission'
     AND result_type_code IN ('Accepted','Warning');

  UPDATE ics_subm_results
     SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', prmt_ident +  prmt_track_evt_code + CONVERT(varchar(50), prmt_track_evt_date))
   WHERE subm_type_name = 'PermitTrackingEventSubmission'
     AND result_type_code IN ('Accepted','Warning');

  UPDATE ics_subm_results
     SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', prmt_ident)
   WHERE subm_type_name = 'POTWPermitSubmission'
     AND result_type_code IN ('Accepted','Warning');

  UPDATE ics_subm_results
     SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', prmt_ident)
   WHERE subm_type_name = 'PretreatmentPermitSubmission'
     AND result_type_code IN ('Accepted','Warning');

  UPDATE ics_subm_results
     SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', prmt_ident)
   WHERE subm_type_name = 'SWConstructionPermitSubmission'
     AND result_type_code IN ('Accepted','Warning');

  UPDATE ics_subm_results
     SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', prmt_ident)
   WHERE subm_type_name = 'SWIndustrialPermitSubmission'
     AND result_type_code IN ('Accepted','Warning');

  UPDATE ics_subm_results
     SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', prmt_ident)
   WHERE subm_type_name = 'SWMS4LargePermitSubmission'
     AND result_type_code IN ('Accepted','Warning');

  UPDATE ics_subm_results
     SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', prmt_ident)
   WHERE subm_type_name = 'SWMS4SmallPermitSubmission'
     AND result_type_code IN ('Accepted','Warning');

  UPDATE ics_subm_results
     SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', prmt_ident)
   WHERE subm_type_name = 'UnpermittedFacilitySubmission'
     AND result_type_code IN ('Accepted','Warning');

  UPDATE ics_subm_results
     SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', prmt_ident + CONVERT(varchar(50), prmt_effective_date) + CONVERT(varchar(50), narr_cond_num) +  schd_evt_code + CONVERT(varchar(50), schd_date))
   WHERE subm_type_name = 'HistoricalPermitScheduleEventsSubmission'
     AND result_type_code IN ('Accepted','Warning');

  UPDATE ics_subm_results
     SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', prmt_ident + CONVERT(varchar(50), narr_cond_num))
   WHERE subm_type_name = 'NarrativeConditionScheduleSubmission'
     AND result_type_code IN ('Accepted','Warning');

  UPDATE ics_subm_results
     SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', prmt_ident +  prmt_featr_ident)
   WHERE subm_type_name = 'PermittedFeatureSubmission'
     AND result_type_code IN ('Accepted','Warning');

  UPDATE ics_subm_results
     SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', prmt_ident +  prmt_featr_ident +  lmt_set_designator)
   WHERE subm_type_name = 'LimitSetSubmission'
     AND result_type_code IN ('Accepted','Warning');

  UPDATE ics_subm_results
     SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', prmt_ident +  prmt_featr_ident +  lmt_set_designator +  param_code +  mon_site_desc_code + CONVERT(varchar(50), lmt_season_num) + CONVERT(varchar(50), lmt_start_date) + CONVERT(varchar(50), lmt_end_date))
   WHERE subm_type_name = 'LimitsSubmission'
     AND result_type_code IN ('Accepted','Warning');

  UPDATE ics_subm_results
     SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', prmt_ident +  prmt_featr_ident +  lmt_set_designator +  param_code +  mon_site_desc_code + CONVERT(varchar(50), lmt_season_num))
   WHERE subm_type_name = 'ParameterLimitsSubmission'
     AND result_type_code IN ('Accepted','Warning');

  UPDATE ics_subm_results
     SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', prmt_ident +  prmt_featr_ident +  lmt_set_designator + CONVERT(varchar(50), mon_period_end_date))
   WHERE subm_type_name = 'DischargeMonitoringReportSubmission'
     AND result_type_code IN ('Accepted','Warning');


 /*  
  *  Step 2: Remove previous error transactions that have were resent in the most recent transaction
  */
  DELETE
    FROM ics_subm_results
   WHERE subm_type_name = 'BasicPermitSubmission'
     AND subm_transaction_id <> @p_transaction_id
     AND result_type_code = 'Error'
     AND key_hash IN
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE subm_type_name = 'BasicPermitSubmission'
                    AND subm_transaction_id = @p_transaction_id);

  DELETE
    FROM ics_subm_results
   WHERE subm_type_name = 'BiosolidsPermitSubmission'
     AND subm_transaction_id <> @p_transaction_id
     AND result_type_code = 'Error'
     AND key_hash IN
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE subm_type_name = 'BiosolidsPermitSubmission'
                    AND subm_transaction_id = @p_transaction_id);

  DELETE
    FROM ics_subm_results
   WHERE subm_type_name = 'CAFOPermitSubmission'
     AND subm_transaction_id <> @p_transaction_id
     AND result_type_code = 'Error'
     AND key_hash IN
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE subm_type_name = 'CAFOPermitSubmission'
                    AND subm_transaction_id = @p_transaction_id);

  DELETE
    FROM ics_subm_results
   WHERE subm_type_name = 'CSOPermitSubmission'
     AND subm_transaction_id <> @p_transaction_id
     AND result_type_code = 'Error'
     AND key_hash IN
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE subm_type_name = 'CSOPermitSubmission'
                    AND subm_transaction_id = @p_transaction_id);

  DELETE
    FROM ics_subm_results
   WHERE subm_type_name = 'ComplianceMonitoringSubmission'
     AND subm_transaction_id <> @p_transaction_id
     AND result_type_code = 'Error'
     AND key_hash IN
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE subm_type_name = 'ComplianceMonitoringSubmission'
                    AND subm_transaction_id = @p_transaction_id);

  DELETE
    FROM ics_subm_results
   WHERE subm_type_name = 'GeneralPermitSubmission'
     AND subm_transaction_id <> @p_transaction_id
     AND result_type_code = 'Error'
     AND key_hash IN
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE subm_type_name = 'GeneralPermitSubmission'
                    AND subm_transaction_id = @p_transaction_id);

  DELETE
    FROM ics_subm_results
   WHERE subm_type_name = 'MasterGeneralPermitSubmission'
     AND subm_transaction_id <> @p_transaction_id
     AND result_type_code = 'Error'
     AND key_hash IN
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE subm_type_name = 'MasterGeneralPermitSubmission'
                    AND subm_transaction_id = @p_transaction_id);

  DELETE
    FROM ics_subm_results
   WHERE subm_type_name = 'PermitReissuanceSubmission'
     AND subm_transaction_id <> @p_transaction_id
     AND result_type_code = 'Error'
     AND key_hash IN
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE subm_type_name = 'PermitReissuanceSubmission'
                    AND subm_transaction_id = @p_transaction_id);

  DELETE
    FROM ics_subm_results
   WHERE subm_type_name = 'PermitTerminationSubmission'
     AND subm_transaction_id <> @p_transaction_id
     AND result_type_code = 'Error'
     AND key_hash IN
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE subm_type_name = 'PermitTerminationSubmission'
                    AND subm_transaction_id = @p_transaction_id);

  DELETE
    FROM ics_subm_results
   WHERE subm_type_name = 'PermitTrackingEventSubmission'
     AND subm_transaction_id <> @p_transaction_id
     AND result_type_code = 'Error'
     AND key_hash IN
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE subm_type_name = 'PermitTrackingEventSubmission'
                    AND subm_transaction_id = @p_transaction_id);

  DELETE
    FROM ics_subm_results
   WHERE subm_type_name = 'POTWPermitSubmission'
     AND subm_transaction_id <> @p_transaction_id
     AND result_type_code = 'Error'
     AND key_hash IN
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE subm_type_name = 'POTWPermitSubmission'
                    AND subm_transaction_id = @p_transaction_id);

  DELETE
    FROM ics_subm_results
   WHERE subm_type_name = 'PretreatmentPermitSubmission'
     AND subm_transaction_id <> @p_transaction_id
     AND result_type_code = 'Error'
     AND key_hash IN
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE subm_type_name = 'PretreatmentPermitSubmission'
                    AND subm_transaction_id = @p_transaction_id);

  DELETE
    FROM ics_subm_results
   WHERE subm_type_name = 'SWConstructionPermitSubmission'
     AND subm_transaction_id <> @p_transaction_id
     AND result_type_code = 'Error'
     AND key_hash IN
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE subm_type_name = 'SWConstructionPermitSubmission'
                    AND subm_transaction_id = @p_transaction_id);

  DELETE
    FROM ics_subm_results
   WHERE subm_type_name = 'SWIndustrialPermitSubmission'
     AND subm_transaction_id <> @p_transaction_id
     AND result_type_code = 'Error'
     AND key_hash IN
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE subm_type_name = 'SWIndustrialPermitSubmission'
                    AND subm_transaction_id = @p_transaction_id);

  DELETE
    FROM ics_subm_results
   WHERE subm_type_name = 'SWMS4LargePermitSubmission'
     AND subm_transaction_id <> @p_transaction_id
     AND result_type_code = 'Error'
     AND key_hash IN
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE subm_type_name = 'SWMS4LargePermitSubmission'
                    AND subm_transaction_id = @p_transaction_id);

  DELETE
    FROM ics_subm_results
   WHERE subm_type_name = 'SWMS4SmallPermitSubmission'
     AND subm_transaction_id <> @p_transaction_id
     AND result_type_code = 'Error'
     AND key_hash IN
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE subm_type_name = 'SWMS4SmallPermitSubmission'
                    AND subm_transaction_id = @p_transaction_id);

  DELETE
    FROM ics_subm_results
   WHERE subm_type_name = 'UnpermittedFacilitySubmission'
     AND subm_transaction_id <> @p_transaction_id
     AND result_type_code = 'Error'
     AND key_hash IN
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE subm_type_name = 'UnpermittedFacilitySubmission'
                    AND subm_transaction_id = @p_transaction_id);

  DELETE
    FROM ics_subm_results
   WHERE subm_type_name = 'HistoricalPermitScheduleEventsSubmission'
     AND subm_transaction_id <> @p_transaction_id
     AND result_type_code = 'Error'
     AND key_hash IN
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE subm_type_name = 'HistoricalPermitScheduleEventsSubmission'
                    AND subm_transaction_id = @p_transaction_id);

  DELETE
    FROM ics_subm_results
   WHERE subm_type_name = 'NarrativeConditionScheduleSubmission'
     AND subm_transaction_id <> @p_transaction_id
     AND result_type_code = 'Error'
     AND key_hash IN
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE subm_type_name = 'NarrativeConditionScheduleSubmission'
                    AND subm_transaction_id = @p_transaction_id);

  DELETE
    FROM ics_subm_results
   WHERE subm_type_name = 'PermittedFeatureSubmission'
     AND subm_transaction_id <> @p_transaction_id
     AND result_type_code = 'Error'
     AND key_hash IN
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE subm_type_name = 'PermittedFeatureSubmission'
                    AND subm_transaction_id = @p_transaction_id);

  DELETE
    FROM ics_subm_results
   WHERE subm_type_name = 'LimitSetSubmission'
     AND subm_transaction_id <> @p_transaction_id
     AND result_type_code = 'Error'
     AND key_hash IN
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE subm_type_name = 'LimitSetSubmission'
                    AND subm_transaction_id = @p_transaction_id);

  DELETE
    FROM ics_subm_results
   WHERE subm_type_name = 'LimitsSubmission'
     AND subm_transaction_id <> @p_transaction_id
     AND result_type_code = 'Error'
     AND key_hash IN
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE subm_type_name = 'LimitsSubmission'
                    AND subm_transaction_id = @p_transaction_id);

  DELETE
    FROM ics_subm_results
   WHERE subm_type_name = 'ParameterLimitsSubmission'
     AND subm_transaction_id <> @p_transaction_id
     AND result_type_code = 'Error'
     AND key_hash IN
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE subm_type_name = 'ParameterLimitsSubmission'
                    AND subm_transaction_id = @p_transaction_id);

  DELETE
    FROM ics_subm_results
   WHERE subm_type_name = 'DischargeMonitoringReportSubmission'
     AND subm_transaction_id <> @p_transaction_id
     AND result_type_code = 'Error'
     AND key_hash IN
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE subm_type_name = 'DischargeMonitoringReportSubmission'
                    AND subm_transaction_id = @p_transaction_id);


  --Step 3: Move accepted transactions from LOCAL to ICIS database
  -- Remove any old records for ics_basic_prmt
  -- /ICS_BASIC_PRMT/ICS_FAC/ICS_ADDR/ICS_TELEPH
  DELETE
    FROM ics_flow_icis..ics_teleph
   WHERE ics_addr_id IN
            (SELECT ics_addr.ics_addr_id
               FROM ics_basic_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_basic_prmt.key_hash 
                    JOIN ics_fac ON ics_fac.ics_basic_prmt_id = ics_basic_prmt.ics_basic_prmt_id
                    JOIN ics_addr ON ics_addr.ics_fac_id = ics_fac.ics_fac_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission');

  -- /ICS_BASIC_PRMT/ICS_FAC/ICS_CONTACT/ICS_TELEPH
  DELETE
    FROM ics_flow_icis..ics_teleph
   WHERE ics_contact_id IN
            (SELECT ics_contact.ics_contact_id
               FROM ics_basic_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_basic_prmt.key_hash 
                    JOIN ics_fac ON ics_fac.ics_basic_prmt_id = ics_basic_prmt.ics_basic_prmt_id
                    JOIN ics_contact ON ics_contact.ics_fac_id = ics_fac.ics_fac_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission');

  -- /ICS_BASIC_PRMT/ICS_ADDR/ICS_TELEPH
  DELETE
    FROM ics_flow_icis..ics_teleph
   WHERE ics_addr_id IN
            (SELECT ics_addr.ics_addr_id
               FROM ics_basic_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_basic_prmt.key_hash 
                    JOIN ics_addr ON ics_addr.ics_basic_prmt_id = ics_basic_prmt.ics_basic_prmt_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission');

  -- /ICS_BASIC_PRMT/ICS_CONTACT/ICS_TELEPH
  DELETE
    FROM ics_flow_icis..ics_teleph
   WHERE ics_contact_id IN
            (SELECT ics_contact.ics_contact_id
               FROM ics_basic_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_basic_prmt.key_hash 
                    JOIN ics_contact ON ics_contact.ics_basic_prmt_id = ics_basic_prmt.ics_basic_prmt_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission');

  -- /ICS_BASIC_PRMT/ICS_FAC/ICS_ADDR
  DELETE
    FROM ics_flow_icis..ics_addr
   WHERE ics_fac_id IN
            (SELECT ics_fac.ics_fac_id
               FROM ics_basic_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_basic_prmt.key_hash 
                    JOIN ics_fac ON ics_fac.ics_basic_prmt_id = ics_basic_prmt.ics_basic_prmt_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission');

  -- /ICS_BASIC_PRMT/ICS_FAC/ICS_CONTACT
  DELETE
    FROM ics_flow_icis..ics_contact
   WHERE ics_fac_id IN
            (SELECT ics_fac.ics_fac_id
               FROM ics_basic_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_basic_prmt.key_hash 
                    JOIN ics_fac ON ics_fac.ics_basic_prmt_id = ics_basic_prmt.ics_basic_prmt_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission');

  -- /ICS_BASIC_PRMT/ICS_FAC/ICS_FAC_CLASS
  DELETE
    FROM ics_flow_icis..ics_fac_class
   WHERE ics_fac_id IN
            (SELECT ics_fac.ics_fac_id
               FROM ics_basic_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_basic_prmt.key_hash 
                    JOIN ics_fac ON ics_fac.ics_basic_prmt_id = ics_basic_prmt.ics_basic_prmt_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission');

  -- /ICS_BASIC_PRMT/ICS_FAC/ICS_GEO_COORD
  DELETE
    FROM ics_flow_icis..ics_geo_coord
   WHERE ics_fac_id IN
            (SELECT ics_fac.ics_fac_id
               FROM ics_basic_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_basic_prmt.key_hash 
                    JOIN ics_fac ON ics_fac.ics_basic_prmt_id = ics_basic_prmt.ics_basic_prmt_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission');

  -- /ICS_BASIC_PRMT/ICS_FAC/ICS_NAICS_CODE
  DELETE
    FROM ics_flow_icis..ics_naics_code
   WHERE ics_fac_id IN
            (SELECT ics_fac.ics_fac_id
               FROM ics_basic_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_basic_prmt.key_hash 
                    JOIN ics_fac ON ics_fac.ics_basic_prmt_id = ics_basic_prmt.ics_basic_prmt_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission');

  -- /ICS_BASIC_PRMT/ICS_FAC/ICS_ORIG_PROGS
  DELETE
    FROM ics_flow_icis..ics_orig_progs
   WHERE ics_fac_id IN
            (SELECT ics_fac.ics_fac_id
               FROM ics_basic_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_basic_prmt.key_hash 
                    JOIN ics_fac ON ics_fac.ics_basic_prmt_id = ics_basic_prmt.ics_basic_prmt_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission');

  -- /ICS_BASIC_PRMT/ICS_FAC/ICS_PLCY
  DELETE
    FROM ics_flow_icis..ics_plcy
   WHERE ics_fac_id IN
            (SELECT ics_fac.ics_fac_id
               FROM ics_basic_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_basic_prmt.key_hash 
                    JOIN ics_fac ON ics_fac.ics_basic_prmt_id = ics_basic_prmt.ics_basic_prmt_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission');

  -- /ICS_BASIC_PRMT/ICS_FAC/ICS_SIC_CODE
  DELETE
    FROM ics_flow_icis..ics_sic_code
   WHERE ics_fac_id IN
            (SELECT ics_fac.ics_fac_id
               FROM ics_basic_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_basic_prmt.key_hash 
                    JOIN ics_fac ON ics_fac.ics_basic_prmt_id = ics_basic_prmt.ics_basic_prmt_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission');

  -- /ICS_BASIC_PRMT/ICS_ADDR
  DELETE
    FROM ics_flow_icis..ics_addr
   WHERE ics_basic_prmt_id IN
            (SELECT ics_basic_prmt.ics_basic_prmt_id
               FROM ics_basic_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_basic_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission');

  -- /ICS_BASIC_PRMT/ICS_ASSC_PRMT
  DELETE
    FROM ics_flow_icis..ics_assc_prmt
   WHERE ics_basic_prmt_id IN
            (SELECT ics_basic_prmt.ics_basic_prmt_id
               FROM ics_basic_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_basic_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission');

  -- /ICS_BASIC_PRMT/ICS_CMPL_TRACK_STAT
  DELETE
    FROM ics_flow_icis..ics_cmpl_track_stat
   WHERE ics_basic_prmt_id IN
            (SELECT ics_basic_prmt.ics_basic_prmt_id
               FROM ics_basic_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_basic_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission');

  -- /ICS_BASIC_PRMT/ICS_CONTACT
  DELETE
    FROM ics_flow_icis..ics_contact
   WHERE ics_basic_prmt_id IN
            (SELECT ics_basic_prmt.ics_basic_prmt_id
               FROM ics_basic_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_basic_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission');

  -- /ICS_BASIC_PRMT/ICS_EFFLU_GUIDE
  DELETE
    FROM ics_flow_icis..ics_efflu_guide
   WHERE ics_basic_prmt_id IN
            (SELECT ics_basic_prmt.ics_basic_prmt_id
               FROM ics_basic_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_basic_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission');

  -- /ICS_BASIC_PRMT/ICS_FAC
  DELETE
    FROM ics_flow_icis..ics_fac
   WHERE ics_basic_prmt_id IN
            (SELECT ics_basic_prmt.ics_basic_prmt_id
               FROM ics_basic_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_basic_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission');

  -- /ICS_BASIC_PRMT/ICS_NAICS_CODE
  DELETE
    FROM ics_flow_icis..ics_naics_code
   WHERE ics_basic_prmt_id IN
            (SELECT ics_basic_prmt.ics_basic_prmt_id
               FROM ics_basic_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_basic_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission');

  -- /ICS_BASIC_PRMT/ICS_OTHR_PRMTS
  DELETE
    FROM ics_flow_icis..ics_othr_prmts
   WHERE ics_basic_prmt_id IN
            (SELECT ics_basic_prmt.ics_basic_prmt_id
               FROM ics_basic_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_basic_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission');

  -- /ICS_BASIC_PRMT/ICS_SIC_CODE
  DELETE
    FROM ics_flow_icis..ics_sic_code
   WHERE ics_basic_prmt_id IN
            (SELECT ics_basic_prmt.ics_basic_prmt_id
               FROM ics_basic_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_basic_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission');

  -- /ICS_BASIC_PRMT
  DELETE
    FROM ics_flow_icis..ics_basic_prmt
   WHERE ics_basic_prmt_id IN
            (SELECT ics_basic_prmt.ics_basic_prmt_id
               FROM ics_basic_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_basic_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission');


  -- Add accepted records for ics_basic_prmt
  -- /ICS_BASIC_PRMT
  INSERT INTO ics_flow_icis..ics_basic_prmt
       SELECT ics_basic_prmt.*
         FROM ics_basic_prmt
         WHERE ics_basic_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'BasicPermitSubmission');

  -- /ICS_BASIC_PRMT/ICS_ADDR
  INSERT INTO ics_flow_icis..ics_addr
       SELECT ics_addr.*
         FROM ics_addr
            JOIN ics_basic_prmt
              ON ics_addr.ics_basic_prmt_id = ics_basic_prmt.ics_basic_prmt_id
         WHERE ics_basic_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'BasicPermitSubmission');

  -- /ICS_BASIC_PRMT/ICS_ADDR/ICS_TELEPH
  INSERT INTO ics_flow_icis..ics_teleph
       SELECT ics_teleph.*
         FROM ics_teleph
            JOIN ics_addr
              ON ics_teleph.ics_addr_id = ics_addr.ics_addr_id
            JOIN ics_basic_prmt
              ON ics_addr.ics_basic_prmt_id = ics_basic_prmt.ics_basic_prmt_id
         WHERE ics_basic_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'BasicPermitSubmission');

  -- /ICS_BASIC_PRMT/ICS_ASSC_PRMT
  INSERT INTO ics_flow_icis..ics_assc_prmt
       SELECT ics_assc_prmt.*
         FROM ics_assc_prmt
            JOIN ics_basic_prmt
              ON ics_assc_prmt.ics_basic_prmt_id = ics_basic_prmt.ics_basic_prmt_id
         WHERE ics_basic_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'BasicPermitSubmission');

  -- /ICS_BASIC_PRMT/ICS_CMPL_TRACK_STAT
  INSERT INTO ics_flow_icis..ics_cmpl_track_stat
       SELECT ics_cmpl_track_stat.*
         FROM ics_cmpl_track_stat
            JOIN ics_basic_prmt
              ON ics_cmpl_track_stat.ics_basic_prmt_id = ics_basic_prmt.ics_basic_prmt_id
         WHERE ics_basic_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'BasicPermitSubmission');

  -- /ICS_BASIC_PRMT/ICS_CONTACT
  INSERT INTO ics_flow_icis..ics_contact
       SELECT ics_contact.*
         FROM ics_contact
            JOIN ics_basic_prmt
              ON ics_contact.ics_basic_prmt_id = ics_basic_prmt.ics_basic_prmt_id
         WHERE ics_basic_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'BasicPermitSubmission');

  -- /ICS_BASIC_PRMT/ICS_CONTACT/ICS_TELEPH
  INSERT INTO ics_flow_icis..ics_teleph
       SELECT ics_teleph.*
         FROM ics_teleph
            JOIN ics_contact
              ON ics_teleph.ics_contact_id = ics_contact.ics_contact_id
            JOIN ics_basic_prmt
              ON ics_contact.ics_basic_prmt_id = ics_basic_prmt.ics_basic_prmt_id
         WHERE ics_basic_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'BasicPermitSubmission');

  -- /ICS_BASIC_PRMT/ICS_EFFLU_GUIDE
  INSERT INTO ics_flow_icis..ics_efflu_guide
       SELECT ics_efflu_guide.*
         FROM ics_efflu_guide
            JOIN ics_basic_prmt
              ON ics_efflu_guide.ics_basic_prmt_id = ics_basic_prmt.ics_basic_prmt_id
         WHERE ics_basic_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'BasicPermitSubmission');

  -- /ICS_BASIC_PRMT/ICS_FAC
  INSERT INTO ics_flow_icis..ics_fac
       SELECT ics_fac.*
         FROM ics_fac
            JOIN ics_basic_prmt
              ON ics_fac.ics_basic_prmt_id = ics_basic_prmt.ics_basic_prmt_id
         WHERE ics_basic_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'BasicPermitSubmission');

  -- /ICS_BASIC_PRMT/ICS_FAC/ICS_ADDR
  INSERT INTO ics_flow_icis..ics_addr
       SELECT ics_addr.*
         FROM ics_addr
            JOIN ics_fac
              ON ics_addr.ics_fac_id = ics_fac.ics_fac_id
            JOIN ics_basic_prmt
              ON ics_fac.ics_basic_prmt_id = ics_basic_prmt.ics_basic_prmt_id
         WHERE ics_basic_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'BasicPermitSubmission');

  -- /ICS_BASIC_PRMT/ICS_FAC/ICS_ADDR/ICS_TELEPH
  INSERT INTO ics_flow_icis..ics_teleph
       SELECT ics_teleph.*
         FROM ics_teleph
            JOIN ics_addr
              ON ics_teleph.ics_addr_id = ics_addr.ics_addr_id
            JOIN ics_fac
              ON ics_addr.ics_fac_id = ics_fac.ics_fac_id
            JOIN ics_basic_prmt
              ON ics_fac.ics_basic_prmt_id = ics_basic_prmt.ics_basic_prmt_id
         WHERE ics_basic_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'BasicPermitSubmission');

  -- /ICS_BASIC_PRMT/ICS_FAC/ICS_CONTACT
  INSERT INTO ics_flow_icis..ics_contact
       SELECT ics_contact.*
         FROM ics_contact
            JOIN ics_fac
              ON ics_contact.ics_fac_id = ics_fac.ics_fac_id
            JOIN ics_basic_prmt
              ON ics_fac.ics_basic_prmt_id = ics_basic_prmt.ics_basic_prmt_id
         WHERE ics_basic_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'BasicPermitSubmission');

  -- /ICS_BASIC_PRMT/ICS_FAC/ICS_CONTACT/ICS_TELEPH
  INSERT INTO ics_flow_icis..ics_teleph
       SELECT ics_teleph.*
         FROM ics_teleph
            JOIN ics_contact
              ON ics_teleph.ics_contact_id = ics_contact.ics_contact_id
            JOIN ics_fac
              ON ics_contact.ics_fac_id = ics_fac.ics_fac_id
            JOIN ics_basic_prmt
              ON ics_fac.ics_basic_prmt_id = ics_basic_prmt.ics_basic_prmt_id
         WHERE ics_basic_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'BasicPermitSubmission');

  -- /ICS_BASIC_PRMT/ICS_FAC/ICS_FAC_CLASS
  INSERT INTO ics_flow_icis..ics_fac_class
       SELECT ics_fac_class.*
         FROM ics_fac_class
            JOIN ics_fac
              ON ics_fac_class.ics_fac_id = ics_fac.ics_fac_id
            JOIN ics_basic_prmt
              ON ics_fac.ics_basic_prmt_id = ics_basic_prmt.ics_basic_prmt_id
         WHERE ics_basic_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'BasicPermitSubmission');

  -- /ICS_BASIC_PRMT/ICS_FAC/ICS_GEO_COORD
  INSERT INTO ics_flow_icis..ics_geo_coord
       SELECT ics_geo_coord.*
         FROM ics_geo_coord
            JOIN ics_fac
              ON ics_geo_coord.ics_fac_id = ics_fac.ics_fac_id
            JOIN ics_basic_prmt
              ON ics_fac.ics_basic_prmt_id = ics_basic_prmt.ics_basic_prmt_id
         WHERE ics_basic_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'BasicPermitSubmission');

  -- /ICS_BASIC_PRMT/ICS_FAC/ICS_NAICS_CODE
  INSERT INTO ics_flow_icis..ics_naics_code
       SELECT ics_naics_code.*
         FROM ics_naics_code
            JOIN ics_fac
              ON ics_naics_code.ics_fac_id = ics_fac.ics_fac_id
            JOIN ics_basic_prmt
              ON ics_fac.ics_basic_prmt_id = ics_basic_prmt.ics_basic_prmt_id
         WHERE ics_basic_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'BasicPermitSubmission');

  -- /ICS_BASIC_PRMT/ICS_FAC/ICS_ORIG_PROGS
  INSERT INTO ics_flow_icis..ics_orig_progs
       SELECT ics_orig_progs.*
         FROM ics_orig_progs
            JOIN ics_fac
              ON ics_orig_progs.ics_fac_id = ics_fac.ics_fac_id
            JOIN ics_basic_prmt
              ON ics_fac.ics_basic_prmt_id = ics_basic_prmt.ics_basic_prmt_id
         WHERE ics_basic_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'BasicPermitSubmission');

  -- /ICS_BASIC_PRMT/ICS_FAC/ICS_PLCY
  INSERT INTO ics_flow_icis..ics_plcy
       SELECT ics_plcy.*
         FROM ics_plcy
            JOIN ics_fac
              ON ics_plcy.ics_fac_id = ics_fac.ics_fac_id
            JOIN ics_basic_prmt
              ON ics_fac.ics_basic_prmt_id = ics_basic_prmt.ics_basic_prmt_id
         WHERE ics_basic_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'BasicPermitSubmission');

  -- /ICS_BASIC_PRMT/ICS_FAC/ICS_SIC_CODE
  INSERT INTO ics_flow_icis..ics_sic_code
       SELECT ics_sic_code.*
         FROM ics_sic_code
            JOIN ics_fac
              ON ics_sic_code.ics_fac_id = ics_fac.ics_fac_id
            JOIN ics_basic_prmt
              ON ics_fac.ics_basic_prmt_id = ics_basic_prmt.ics_basic_prmt_id
         WHERE ics_basic_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'BasicPermitSubmission');

  -- /ICS_BASIC_PRMT/ICS_NAICS_CODE
  INSERT INTO ics_flow_icis..ics_naics_code
       SELECT ics_naics_code.*
         FROM ics_naics_code
            JOIN ics_basic_prmt
              ON ics_naics_code.ics_basic_prmt_id = ics_basic_prmt.ics_basic_prmt_id
         WHERE ics_basic_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'BasicPermitSubmission');

  -- /ICS_BASIC_PRMT/ICS_OTHR_PRMTS
  INSERT INTO ics_flow_icis..ics_othr_prmts
       SELECT ics_othr_prmts.*
         FROM ics_othr_prmts
            JOIN ics_basic_prmt
              ON ics_othr_prmts.ics_basic_prmt_id = ics_basic_prmt.ics_basic_prmt_id
         WHERE ics_basic_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'BasicPermitSubmission');

  -- /ICS_BASIC_PRMT/ICS_SIC_CODE
  INSERT INTO ics_flow_icis..ics_sic_code
       SELECT ics_sic_code.*
         FROM ics_sic_code
            JOIN ics_basic_prmt
              ON ics_sic_code.ics_basic_prmt_id = ics_basic_prmt.ics_basic_prmt_id
         WHERE ics_basic_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'BasicPermitSubmission');


  -- Remove any old records for ics_bs_prmt
  -- /ICS_BS_PRMT/ICS_ADDR/ICS_TELEPH
  DELETE
    FROM ics_flow_icis..ics_teleph
   WHERE ics_addr_id IN
            (SELECT ics_addr.ics_addr_id
               FROM ics_bs_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_bs_prmt.key_hash 
                    JOIN ics_addr ON ics_addr.ics_bs_prmt_id = ics_bs_prmt.ics_bs_prmt_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsPermitSubmission');

  -- /ICS_BS_PRMT/ICS_CONTACT/ICS_TELEPH
  DELETE
    FROM ics_flow_icis..ics_teleph
   WHERE ics_contact_id IN
            (SELECT ics_contact.ics_contact_id
               FROM ics_bs_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_bs_prmt.key_hash 
                    JOIN ics_contact ON ics_contact.ics_bs_prmt_id = ics_bs_prmt.ics_bs_prmt_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsPermitSubmission');

  -- /ICS_BS_PRMT/ICS_ADDR
  DELETE
    FROM ics_flow_icis..ics_addr
   WHERE ics_bs_prmt_id IN
            (SELECT ics_bs_prmt.ics_bs_prmt_id
               FROM ics_bs_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_bs_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsPermitSubmission');

  -- /ICS_BS_PRMT/ICS_BS_END_USE_DSPL_TYPE
  DELETE
    FROM ics_flow_icis..ics_bs_end_use_dspl_type
   WHERE ics_bs_prmt_id IN
            (SELECT ics_bs_prmt.ics_bs_prmt_id
               FROM ics_bs_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_bs_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsPermitSubmission');

  -- /ICS_BS_PRMT/ICS_BS_TYPE
  DELETE
    FROM ics_flow_icis..ics_bs_type
   WHERE ics_bs_prmt_id IN
            (SELECT ics_bs_prmt.ics_bs_prmt_id
               FROM ics_bs_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_bs_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsPermitSubmission');

  -- /ICS_BS_PRMT/ICS_CONTACT
  DELETE
    FROM ics_flow_icis..ics_contact
   WHERE ics_bs_prmt_id IN
            (SELECT ics_bs_prmt.ics_bs_prmt_id
               FROM ics_bs_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_bs_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsPermitSubmission');

  -- /ICS_BS_PRMT
  DELETE
    FROM ics_flow_icis..ics_bs_prmt
   WHERE ics_bs_prmt_id IN
            (SELECT ics_bs_prmt.ics_bs_prmt_id
               FROM ics_bs_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_bs_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsPermitSubmission');


  -- Add accepted records for ics_bs_prmt
  -- /ICS_BS_PRMT
  INSERT INTO ics_flow_icis..ics_bs_prmt
       SELECT ics_bs_prmt.*
         FROM ics_bs_prmt
         WHERE ics_bs_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'BiosolidsPermitSubmission');

  -- /ICS_BS_PRMT/ICS_ADDR
  INSERT INTO ics_flow_icis..ics_addr
       SELECT ics_addr.*
         FROM ics_addr
            JOIN ics_bs_prmt
              ON ics_addr.ics_bs_prmt_id = ics_bs_prmt.ics_bs_prmt_id
         WHERE ics_bs_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'BiosolidsPermitSubmission');

  -- /ICS_BS_PRMT/ICS_ADDR/ICS_TELEPH
  INSERT INTO ics_flow_icis..ics_teleph
       SELECT ics_teleph.*
         FROM ics_teleph
            JOIN ics_addr
              ON ics_teleph.ics_addr_id = ics_addr.ics_addr_id
            JOIN ics_bs_prmt
              ON ics_addr.ics_bs_prmt_id = ics_bs_prmt.ics_bs_prmt_id
         WHERE ics_bs_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'BiosolidsPermitSubmission');

  -- /ICS_BS_PRMT/ICS_BS_END_USE_DSPL_TYPE
  INSERT INTO ics_flow_icis..ics_bs_end_use_dspl_type
       SELECT ics_bs_end_use_dspl_type.*
         FROM ics_bs_end_use_dspl_type
            JOIN ics_bs_prmt
              ON ics_bs_end_use_dspl_type.ics_bs_prmt_id = ics_bs_prmt.ics_bs_prmt_id
         WHERE ics_bs_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'BiosolidsPermitSubmission');

  -- /ICS_BS_PRMT/ICS_BS_TYPE
  INSERT INTO ics_flow_icis..ics_bs_type
       SELECT ics_bs_type.*
         FROM ics_bs_type
            JOIN ics_bs_prmt
              ON ics_bs_type.ics_bs_prmt_id = ics_bs_prmt.ics_bs_prmt_id
         WHERE ics_bs_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'BiosolidsPermitSubmission');

  -- /ICS_BS_PRMT/ICS_CONTACT
  INSERT INTO ics_flow_icis..ics_contact
       SELECT ics_contact.*
         FROM ics_contact
            JOIN ics_bs_prmt
              ON ics_contact.ics_bs_prmt_id = ics_bs_prmt.ics_bs_prmt_id
         WHERE ics_bs_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'BiosolidsPermitSubmission');

  -- /ICS_BS_PRMT/ICS_CONTACT/ICS_TELEPH
  INSERT INTO ics_flow_icis..ics_teleph
       SELECT ics_teleph.*
         FROM ics_teleph
            JOIN ics_contact
              ON ics_teleph.ics_contact_id = ics_contact.ics_contact_id
            JOIN ics_bs_prmt
              ON ics_contact.ics_bs_prmt_id = ics_bs_prmt.ics_bs_prmt_id
         WHERE ics_bs_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'BiosolidsPermitSubmission');


  -- Remove any old records for ics_cafo_prmt
  -- /ICS_CAFO_PRMT/ICS_ADDR/ICS_TELEPH
  DELETE
    FROM ics_flow_icis..ics_teleph
   WHERE ics_addr_id IN
            (SELECT ics_addr.ics_addr_id
               FROM ics_cafo_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_cafo_prmt.key_hash 
                    JOIN ics_addr ON ics_addr.ics_cafo_prmt_id = ics_cafo_prmt.ics_cafo_prmt_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CAFOPermitSubmission');

  -- /ICS_CAFO_PRMT/ICS_CONTACT/ICS_TELEPH
  DELETE
    FROM ics_flow_icis..ics_teleph
   WHERE ics_contact_id IN
            (SELECT ics_contact.ics_contact_id
               FROM ics_cafo_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_cafo_prmt.key_hash 
                    JOIN ics_contact ON ics_contact.ics_cafo_prmt_id = ics_cafo_prmt.ics_cafo_prmt_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CAFOPermitSubmission');

  -- /ICS_CAFO_PRMT/ICS_ADDR
  DELETE
    FROM ics_flow_icis..ics_addr
   WHERE ics_cafo_prmt_id IN
            (SELECT ics_cafo_prmt.ics_cafo_prmt_id
               FROM ics_cafo_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_cafo_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CAFOPermitSubmission');

  -- /ICS_CAFO_PRMT/ICS_ANML_TYPE
  DELETE
    FROM ics_flow_icis..ics_anml_type
   WHERE ics_cafo_prmt_id IN
            (SELECT ics_cafo_prmt.ics_cafo_prmt_id
               FROM ics_cafo_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_cafo_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CAFOPermitSubmission');

  -- /ICS_CAFO_PRMT/ICS_CONTACT
  DELETE
    FROM ics_flow_icis..ics_contact
   WHERE ics_cafo_prmt_id IN
            (SELECT ics_cafo_prmt.ics_cafo_prmt_id
               FROM ics_cafo_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_cafo_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CAFOPermitSubmission');

  -- /ICS_CAFO_PRMT/ICS_CONTAINMENT
  DELETE
    FROM ics_flow_icis..ics_containment
   WHERE ics_cafo_prmt_id IN
            (SELECT ics_cafo_prmt.ics_cafo_prmt_id
               FROM ics_cafo_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_cafo_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CAFOPermitSubmission');

  -- /ICS_CAFO_PRMT/ICS_LAND_APPL_BMP
  DELETE
    FROM ics_flow_icis..ics_land_appl_bmp
   WHERE ics_cafo_prmt_id IN
            (SELECT ics_cafo_prmt.ics_cafo_prmt_id
               FROM ics_cafo_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_cafo_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CAFOPermitSubmission');

  -- /ICS_CAFO_PRMT/ICS_MNUR_LTTR_PRCSS_WW_STOR
  DELETE
    FROM ics_flow_icis..ics_mnur_lttr_prcss_ww_stor
   WHERE ics_cafo_prmt_id IN
            (SELECT ics_cafo_prmt.ics_cafo_prmt_id
               FROM ics_cafo_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_cafo_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CAFOPermitSubmission');

  -- /ICS_CAFO_PRMT
  DELETE
    FROM ics_flow_icis..ics_cafo_prmt
   WHERE ics_cafo_prmt_id IN
            (SELECT ics_cafo_prmt.ics_cafo_prmt_id
               FROM ics_cafo_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_cafo_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CAFOPermitSubmission');


  -- Add accepted records for ics_cafo_prmt
  -- /ICS_CAFO_PRMT
  INSERT INTO ics_flow_icis..ics_cafo_prmt
       SELECT ics_cafo_prmt.*
         FROM ics_cafo_prmt
         WHERE ics_cafo_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'CAFOPermitSubmission');

  -- /ICS_CAFO_PRMT/ICS_ADDR
  INSERT INTO ics_flow_icis..ics_addr
       SELECT ics_addr.*
         FROM ics_addr
            JOIN ics_cafo_prmt
              ON ics_addr.ics_cafo_prmt_id = ics_cafo_prmt.ics_cafo_prmt_id
         WHERE ics_cafo_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'CAFOPermitSubmission');

  -- /ICS_CAFO_PRMT/ICS_ADDR/ICS_TELEPH
  INSERT INTO ics_flow_icis..ics_teleph
       SELECT ics_teleph.*
         FROM ics_teleph
            JOIN ics_addr
              ON ics_teleph.ics_addr_id = ics_addr.ics_addr_id
            JOIN ics_cafo_prmt
              ON ics_addr.ics_cafo_prmt_id = ics_cafo_prmt.ics_cafo_prmt_id
         WHERE ics_cafo_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'CAFOPermitSubmission');

  -- /ICS_CAFO_PRMT/ICS_ANML_TYPE
  INSERT INTO ics_flow_icis..ics_anml_type
       SELECT ics_anml_type.*
         FROM ics_anml_type
            JOIN ics_cafo_prmt
              ON ics_anml_type.ics_cafo_prmt_id = ics_cafo_prmt.ics_cafo_prmt_id
         WHERE ics_cafo_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'CAFOPermitSubmission');

  -- /ICS_CAFO_PRMT/ICS_CONTACT
  INSERT INTO ics_flow_icis..ics_contact
       SELECT ics_contact.*
         FROM ics_contact
            JOIN ics_cafo_prmt
              ON ics_contact.ics_cafo_prmt_id = ics_cafo_prmt.ics_cafo_prmt_id
         WHERE ics_cafo_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'CAFOPermitSubmission');

  -- /ICS_CAFO_PRMT/ICS_CONTACT/ICS_TELEPH
  INSERT INTO ics_flow_icis..ics_teleph
       SELECT ics_teleph.*
         FROM ics_teleph
            JOIN ics_contact
              ON ics_teleph.ics_contact_id = ics_contact.ics_contact_id
            JOIN ics_cafo_prmt
              ON ics_contact.ics_cafo_prmt_id = ics_cafo_prmt.ics_cafo_prmt_id
         WHERE ics_cafo_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'CAFOPermitSubmission');

  -- /ICS_CAFO_PRMT/ICS_CONTAINMENT
  INSERT INTO ics_flow_icis..ics_containment
       SELECT ics_containment.*
         FROM ics_containment
            JOIN ics_cafo_prmt
              ON ics_containment.ics_cafo_prmt_id = ics_cafo_prmt.ics_cafo_prmt_id
         WHERE ics_cafo_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'CAFOPermitSubmission');

  -- /ICS_CAFO_PRMT/ICS_LAND_APPL_BMP
  INSERT INTO ics_flow_icis..ics_land_appl_bmp
       SELECT ics_land_appl_bmp.*
         FROM ics_land_appl_bmp
            JOIN ics_cafo_prmt
              ON ics_land_appl_bmp.ics_cafo_prmt_id = ics_cafo_prmt.ics_cafo_prmt_id
         WHERE ics_cafo_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'CAFOPermitSubmission');

  -- /ICS_CAFO_PRMT/ICS_MNUR_LTTR_PRCSS_WW_STOR
  INSERT INTO ics_flow_icis..ics_mnur_lttr_prcss_ww_stor
       SELECT ics_mnur_lttr_prcss_ww_stor.*
         FROM ics_mnur_lttr_prcss_ww_stor
            JOIN ics_cafo_prmt
              ON ics_mnur_lttr_prcss_ww_stor.ics_cafo_prmt_id = ics_cafo_prmt.ics_cafo_prmt_id
         WHERE ics_cafo_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'CAFOPermitSubmission');


  -- Remove any old records for ics_cso_prmt
  -- /ICS_CSO_PRMT/ICS_SATL_COLL_SYSTM
  DELETE
    FROM ics_flow_icis..ics_satl_coll_systm
   WHERE ics_cso_prmt_id IN
            (SELECT ics_cso_prmt.ics_cso_prmt_id
               FROM ics_cso_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_cso_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CSOPermitSubmission');

  -- /ICS_CSO_PRMT
  DELETE
    FROM ics_flow_icis..ics_cso_prmt
   WHERE ics_cso_prmt_id IN
            (SELECT ics_cso_prmt.ics_cso_prmt_id
               FROM ics_cso_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_cso_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CSOPermitSubmission');


  -- Add accepted records for ics_cso_prmt
  -- /ICS_CSO_PRMT
  INSERT INTO ics_flow_icis..ics_cso_prmt
       SELECT ics_cso_prmt.*
         FROM ics_cso_prmt
         WHERE ics_cso_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'CSOPermitSubmission');

  -- /ICS_CSO_PRMT/ICS_SATL_COLL_SYSTM
  INSERT INTO ics_flow_icis..ics_satl_coll_systm
       SELECT ics_satl_coll_systm.*
         FROM ics_satl_coll_systm
            JOIN ics_cso_prmt
              ON ics_satl_coll_systm.ics_cso_prmt_id = ics_cso_prmt.ics_cso_prmt_id
         WHERE ics_cso_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'CSOPermitSubmission');


  -- Remove any old records for ics_cmpl_mon
  -- /ICS_CMPL_MON/ICS_PRETR_INSP/ICS_LOC_LMTS/ICS_LOC_LMTS_POLUT
  DELETE
    FROM ics_flow_icis..ics_loc_lmts_polut
   WHERE ics_loc_lmts_id IN
            (SELECT ics_loc_lmts.ics_loc_lmts_id
               FROM ics_cmpl_mon
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_cmpl_mon.key_hash 
                    JOIN ics_pretr_insp ON ics_pretr_insp.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id
                    JOIN ics_loc_lmts ON ics_loc_lmts.ics_pretr_insp_id = ics_pretr_insp.ics_pretr_insp_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_PRETR_INSP/ICS_RMVL_CRDTS/ICS_RMVL_CRDTS_POLUT
  DELETE
    FROM ics_flow_icis..ics_rmvl_crdts_polut
   WHERE ics_rmvl_crdts_id IN
            (SELECT ics_rmvl_crdts.ics_rmvl_crdts_id
               FROM ics_cmpl_mon
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_cmpl_mon.key_hash 
                    JOIN ics_pretr_insp ON ics_pretr_insp.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id
                    JOIN ics_rmvl_crdts ON ics_rmvl_crdts.ics_pretr_insp_id = ics_pretr_insp.ics_pretr_insp_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_SW_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP/ICS_PROJ_TYPE
  DELETE
    FROM ics_flow_icis..ics_proj_type
   WHERE ics_sw_unprmt_cnst_insp_id IN
            (SELECT ics_sw_unprmt_cnst_insp.ics_sw_unprmt_cnst_insp_id
               FROM ics_cmpl_mon
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_cmpl_mon.key_hash 
                    JOIN ics_sw_cnst_insp ON ics_sw_cnst_insp.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id
                    JOIN ics_sw_unprmt_cnst_insp ON ics_sw_unprmt_cnst_insp.ics_sw_cnst_insp_id = ics_sw_cnst_insp.ics_sw_cnst_insp_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_SW_CNST_NON_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP/ICS_PROJ_TYPE
  DELETE
    FROM ics_flow_icis..ics_proj_type
   WHERE ics_sw_unprmt_cnst_insp_id IN
            (SELECT ics_sw_unprmt_cnst_insp.ics_sw_unprmt_cnst_insp_id
               FROM ics_cmpl_mon
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_cmpl_mon.key_hash 
                    JOIN ics_sw_cnst_non_cnst_insp ON ics_sw_cnst_non_cnst_insp.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id
                    JOIN ics_sw_unprmt_cnst_insp ON ics_sw_unprmt_cnst_insp.ics_sw_cnst_non_cnst_insp_id = ics_sw_cnst_non_cnst_insp.ics_sw_cnst_non_cnst_insp_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_SW_NON_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP/ICS_PROJ_TYPE
  DELETE
    FROM ics_flow_icis..ics_proj_type
   WHERE ics_sw_unprmt_cnst_insp_id IN
            (SELECT ics_sw_unprmt_cnst_insp.ics_sw_unprmt_cnst_insp_id
               FROM ics_cmpl_mon
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_cmpl_mon.key_hash 
                    JOIN ics_sw_non_cnst_insp ON ics_sw_non_cnst_insp.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id
                    JOIN ics_sw_unprmt_cnst_insp ON ics_sw_unprmt_cnst_insp.ics_sw_non_cnst_insp_id = ics_sw_non_cnst_insp.ics_sw_non_cnst_insp_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_CAFO_INSP/ICS_ANML_TYPE
  DELETE
    FROM ics_flow_icis..ics_anml_type
   WHERE ics_cafo_insp_id IN
            (SELECT ics_cafo_insp.ics_cafo_insp_id
               FROM ics_cmpl_mon
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_cmpl_mon.key_hash 
                    JOIN ics_cafo_insp ON ics_cafo_insp.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_CAFO_INSP/ICS_CAFO_INSP_VIOL_TYPE
  DELETE
    FROM ics_flow_icis..ics_cafo_insp_viol_type
   WHERE ics_cafo_insp_id IN
            (SELECT ics_cafo_insp.ics_cafo_insp_id
               FROM ics_cmpl_mon
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_cmpl_mon.key_hash 
                    JOIN ics_cafo_insp ON ics_cafo_insp.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_CAFO_INSP/ICS_CONTAINMENT
  DELETE
    FROM ics_flow_icis..ics_containment
   WHERE ics_cafo_insp_id IN
            (SELECT ics_cafo_insp.ics_cafo_insp_id
               FROM ics_cmpl_mon
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_cmpl_mon.key_hash 
                    JOIN ics_cafo_insp ON ics_cafo_insp.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_CAFO_INSP/ICS_LAND_APPL_BMP
  DELETE
    FROM ics_flow_icis..ics_land_appl_bmp
   WHERE ics_cafo_insp_id IN
            (SELECT ics_cafo_insp.ics_cafo_insp_id
               FROM ics_cmpl_mon
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_cmpl_mon.key_hash 
                    JOIN ics_cafo_insp ON ics_cafo_insp.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_CAFO_INSP/ICS_MNUR_LTTR_PRCSS_WW_STOR
  DELETE
    FROM ics_flow_icis..ics_mnur_lttr_prcss_ww_stor
   WHERE ics_cafo_insp_id IN
            (SELECT ics_cafo_insp.ics_cafo_insp_id
               FROM ics_cmpl_mon
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_cmpl_mon.key_hash 
                    JOIN ics_cafo_insp ON ics_cafo_insp.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_CONTACT/ICS_TELEPH
  DELETE
    FROM ics_flow_icis..ics_teleph
   WHERE ics_contact_id IN
            (SELECT ics_contact.ics_contact_id
               FROM ics_cmpl_mon
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_cmpl_mon.key_hash 
                    JOIN ics_contact ON ics_contact.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_PRETR_INSP/ICS_LOC_LMTS
  DELETE
    FROM ics_flow_icis..ics_loc_lmts
   WHERE ics_pretr_insp_id IN
            (SELECT ics_pretr_insp.ics_pretr_insp_id
               FROM ics_cmpl_mon
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_cmpl_mon.key_hash 
                    JOIN ics_pretr_insp ON ics_pretr_insp.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_PRETR_INSP/ICS_RMVL_CRDTS
  DELETE
    FROM ics_flow_icis..ics_rmvl_crdts
   WHERE ics_pretr_insp_id IN
            (SELECT ics_pretr_insp.ics_pretr_insp_id
               FROM ics_cmpl_mon
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_cmpl_mon.key_hash 
                    JOIN ics_pretr_insp ON ics_pretr_insp.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_SSO_INSP/ICS_IMPACT_SSO_EVT
  DELETE
    FROM ics_flow_icis..ics_impact_sso_evt
   WHERE ics_sso_insp_id IN
            (SELECT ics_sso_insp.ics_sso_insp_id
               FROM ics_cmpl_mon
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_cmpl_mon.key_hash 
                    JOIN ics_sso_insp ON ics_sso_insp.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_SSO_INSP/ICS_SSO_STPS
  DELETE
    FROM ics_flow_icis..ics_sso_stps
   WHERE ics_sso_insp_id IN
            (SELECT ics_sso_insp.ics_sso_insp_id
               FROM ics_cmpl_mon
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_cmpl_mon.key_hash 
                    JOIN ics_sso_insp ON ics_sso_insp.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_SSO_INSP/ICS_SSO_SYSTM_COMP
  DELETE
    FROM ics_flow_icis..ics_sso_systm_comp
   WHERE ics_sso_insp_id IN
            (SELECT ics_sso_insp.ics_sso_insp_id
               FROM ics_cmpl_mon
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_cmpl_mon.key_hash 
                    JOIN ics_sso_insp ON ics_sso_insp.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_SW_CNST_INSP/ICS_SW_CNST_INDST_INSP
  DELETE
    FROM ics_flow_icis..ics_sw_cnst_indst_insp
   WHERE ics_sw_cnst_insp_id IN
            (SELECT ics_sw_cnst_insp.ics_sw_cnst_insp_id
               FROM ics_cmpl_mon
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_cmpl_mon.key_hash 
                    JOIN ics_sw_cnst_insp ON ics_sw_cnst_insp.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_SW_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP
  DELETE
    FROM ics_flow_icis..ics_sw_unprmt_cnst_insp
   WHERE ics_sw_cnst_insp_id IN
            (SELECT ics_sw_cnst_insp.ics_sw_cnst_insp_id
               FROM ics_cmpl_mon
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_cmpl_mon.key_hash 
                    JOIN ics_sw_cnst_insp ON ics_sw_cnst_insp.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_SW_CNST_NON_CNST_INSP/ICS_SW_CNST_INDST_INSP
  DELETE
    FROM ics_flow_icis..ics_sw_cnst_indst_insp
   WHERE ics_sw_cnst_non_cnst_insp_id IN
            (SELECT ics_sw_cnst_non_cnst_insp.ics_sw_cnst_non_cnst_insp_id
               FROM ics_cmpl_mon
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_cmpl_mon.key_hash 
                    JOIN ics_sw_cnst_non_cnst_insp ON ics_sw_cnst_non_cnst_insp.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_SW_CNST_NON_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP
  DELETE
    FROM ics_flow_icis..ics_sw_unprmt_cnst_insp
   WHERE ics_sw_cnst_non_cnst_insp_id IN
            (SELECT ics_sw_cnst_non_cnst_insp.ics_sw_cnst_non_cnst_insp_id
               FROM ics_cmpl_mon
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_cmpl_mon.key_hash 
                    JOIN ics_sw_cnst_non_cnst_insp ON ics_sw_cnst_non_cnst_insp.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_SW_MS_4_INSP/ICS_PROJ_SRCS_FUND
  DELETE
    FROM ics_flow_icis..ics_proj_srcs_fund
   WHERE ics_sw_ms_4_insp_id IN
            (SELECT ics_sw_ms_4_insp.ics_sw_ms_4_insp_id
               FROM ics_cmpl_mon
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_cmpl_mon.key_hash 
                    JOIN ics_sw_ms_4_insp ON ics_sw_ms_4_insp.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_SW_NON_CNST_INSP/ICS_SW_CNST_INDST_INSP
  DELETE
    FROM ics_flow_icis..ics_sw_cnst_indst_insp
   WHERE ics_sw_non_cnst_insp_id IN
            (SELECT ics_sw_non_cnst_insp.ics_sw_non_cnst_insp_id
               FROM ics_cmpl_mon
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_cmpl_mon.key_hash 
                    JOIN ics_sw_non_cnst_insp ON ics_sw_non_cnst_insp.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_SW_NON_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP
  DELETE
    FROM ics_flow_icis..ics_sw_unprmt_cnst_insp
   WHERE ics_sw_non_cnst_insp_id IN
            (SELECT ics_sw_non_cnst_insp.ics_sw_non_cnst_insp_id
               FROM ics_cmpl_mon
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_cmpl_mon.key_hash 
                    JOIN ics_sw_non_cnst_insp ON ics_sw_non_cnst_insp.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_CAFO_INSP
  DELETE
    FROM ics_flow_icis..ics_cafo_insp
   WHERE ics_cmpl_mon_id IN
            (SELECT ics_cmpl_mon.ics_cmpl_mon_id
               FROM ics_cmpl_mon
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_cmpl_mon.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_CMPL_INSP_TYPE
  DELETE
    FROM ics_flow_icis..ics_cmpl_insp_type
   WHERE ics_cmpl_mon_id IN
            (SELECT ics_cmpl_mon.ics_cmpl_mon_id
               FROM ics_cmpl_mon
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_cmpl_mon.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_CMPL_MON_ACTN_REASON
  DELETE
    FROM ics_flow_icis..ics_cmpl_mon_actn_reason
   WHERE ics_cmpl_mon_id IN
            (SELECT ics_cmpl_mon.ics_cmpl_mon_id
               FROM ics_cmpl_mon
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_cmpl_mon.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_CMPL_MON_AGNCY_TYPE
  DELETE
    FROM ics_flow_icis..ics_cmpl_mon_agncy_type
   WHERE ics_cmpl_mon_id IN
            (SELECT ics_cmpl_mon.ics_cmpl_mon_id
               FROM ics_cmpl_mon
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_cmpl_mon.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_CONTACT
  DELETE
    FROM ics_flow_icis..ics_contact
   WHERE ics_cmpl_mon_id IN
            (SELECT ics_cmpl_mon.ics_cmpl_mon_id
               FROM ics_cmpl_mon
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_cmpl_mon.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_CSO_INSP
  DELETE
    FROM ics_flow_icis..ics_cso_insp
   WHERE ics_cmpl_mon_id IN
            (SELECT ics_cmpl_mon.ics_cmpl_mon_id
               FROM ics_cmpl_mon
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_cmpl_mon.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_NAT_PRIO
  DELETE
    FROM ics_flow_icis..ics_nat_prio
   WHERE ics_cmpl_mon_id IN
            (SELECT ics_cmpl_mon.ics_cmpl_mon_id
               FROM ics_cmpl_mon
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_cmpl_mon.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_PRETR_INSP
  DELETE
    FROM ics_flow_icis..ics_pretr_insp
   WHERE ics_cmpl_mon_id IN
            (SELECT ics_cmpl_mon.ics_cmpl_mon_id
               FROM ics_cmpl_mon
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_cmpl_mon.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_PROG
  DELETE
    FROM ics_flow_icis..ics_prog
   WHERE ics_cmpl_mon_id IN
            (SELECT ics_cmpl_mon.ics_cmpl_mon_id
               FROM ics_cmpl_mon
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_cmpl_mon.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_SSO_INSP
  DELETE
    FROM ics_flow_icis..ics_sso_insp
   WHERE ics_cmpl_mon_id IN
            (SELECT ics_cmpl_mon.ics_cmpl_mon_id
               FROM ics_cmpl_mon
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_cmpl_mon.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_SW_CNST_INSP
  DELETE
    FROM ics_flow_icis..ics_sw_cnst_insp
   WHERE ics_cmpl_mon_id IN
            (SELECT ics_cmpl_mon.ics_cmpl_mon_id
               FROM ics_cmpl_mon
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_cmpl_mon.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_SW_CNST_NON_CNST_INSP
  DELETE
    FROM ics_flow_icis..ics_sw_cnst_non_cnst_insp
   WHERE ics_cmpl_mon_id IN
            (SELECT ics_cmpl_mon.ics_cmpl_mon_id
               FROM ics_cmpl_mon
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_cmpl_mon.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_SW_MS_4_INSP
  DELETE
    FROM ics_flow_icis..ics_sw_ms_4_insp
   WHERE ics_cmpl_mon_id IN
            (SELECT ics_cmpl_mon.ics_cmpl_mon_id
               FROM ics_cmpl_mon
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_cmpl_mon.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_SW_NON_CNST_INSP
  DELETE
    FROM ics_flow_icis..ics_sw_non_cnst_insp
   WHERE ics_cmpl_mon_id IN
            (SELECT ics_cmpl_mon.ics_cmpl_mon_id
               FROM ics_cmpl_mon
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_cmpl_mon.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON
  DELETE
    FROM ics_flow_icis..ics_cmpl_mon
   WHERE ics_cmpl_mon_id IN
            (SELECT ics_cmpl_mon.ics_cmpl_mon_id
               FROM ics_cmpl_mon
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_cmpl_mon.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');


  -- Add accepted records for ics_cmpl_mon
  -- /ICS_CMPL_MON
  INSERT INTO ics_flow_icis..ics_cmpl_mon
       SELECT ics_cmpl_mon.*
         FROM ics_cmpl_mon
         WHERE ics_cmpl_mon.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_CAFO_INSP
  INSERT INTO ics_flow_icis..ics_cafo_insp
       SELECT ics_cafo_insp.*
         FROM ics_cafo_insp
            JOIN ics_cmpl_mon
              ON ics_cafo_insp.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id
         WHERE ics_cmpl_mon.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_CAFO_INSP/ICS_ANML_TYPE
  INSERT INTO ics_flow_icis..ics_anml_type
       SELECT ics_anml_type.*
         FROM ics_anml_type
            JOIN ics_cafo_insp
              ON ics_anml_type.ics_cafo_insp_id = ics_cafo_insp.ics_cafo_insp_id
            JOIN ics_cmpl_mon
              ON ics_cafo_insp.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id
         WHERE ics_cmpl_mon.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_CAFO_INSP/ICS_CAFO_INSP_VIOL_TYPE
  INSERT INTO ics_flow_icis..ics_cafo_insp_viol_type
       SELECT ics_cafo_insp_viol_type.*
         FROM ics_cafo_insp_viol_type
            JOIN ics_cafo_insp
              ON ics_cafo_insp_viol_type.ics_cafo_insp_id = ics_cafo_insp.ics_cafo_insp_id
            JOIN ics_cmpl_mon
              ON ics_cafo_insp.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id
         WHERE ics_cmpl_mon.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_CAFO_INSP/ICS_CONTAINMENT
  INSERT INTO ics_flow_icis..ics_containment
       SELECT ics_containment.*
         FROM ics_containment
            JOIN ics_cafo_insp
              ON ics_containment.ics_cafo_insp_id = ics_cafo_insp.ics_cafo_insp_id
            JOIN ics_cmpl_mon
              ON ics_cafo_insp.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id
         WHERE ics_cmpl_mon.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_CAFO_INSP/ICS_LAND_APPL_BMP
  INSERT INTO ics_flow_icis..ics_land_appl_bmp
       SELECT ics_land_appl_bmp.*
         FROM ics_land_appl_bmp
            JOIN ics_cafo_insp
              ON ics_land_appl_bmp.ics_cafo_insp_id = ics_cafo_insp.ics_cafo_insp_id
            JOIN ics_cmpl_mon
              ON ics_cafo_insp.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id
         WHERE ics_cmpl_mon.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_CAFO_INSP/ICS_MNUR_LTTR_PRCSS_WW_STOR
  INSERT INTO ics_flow_icis..ics_mnur_lttr_prcss_ww_stor
       SELECT ics_mnur_lttr_prcss_ww_stor.*
         FROM ics_mnur_lttr_prcss_ww_stor
            JOIN ics_cafo_insp
              ON ics_mnur_lttr_prcss_ww_stor.ics_cafo_insp_id = ics_cafo_insp.ics_cafo_insp_id
            JOIN ics_cmpl_mon
              ON ics_cafo_insp.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id
         WHERE ics_cmpl_mon.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_CMPL_INSP_TYPE
  INSERT INTO ics_flow_icis..ics_cmpl_insp_type
       SELECT ics_cmpl_insp_type.*
         FROM ics_cmpl_insp_type
            JOIN ics_cmpl_mon
              ON ics_cmpl_insp_type.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id
         WHERE ics_cmpl_mon.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_CMPL_MON_ACTN_REASON
  INSERT INTO ics_flow_icis..ics_cmpl_mon_actn_reason
       SELECT ics_cmpl_mon_actn_reason.*
         FROM ics_cmpl_mon_actn_reason
            JOIN ics_cmpl_mon
              ON ics_cmpl_mon_actn_reason.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id
         WHERE ics_cmpl_mon.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_CMPL_MON_AGNCY_TYPE
  INSERT INTO ics_flow_icis..ics_cmpl_mon_agncy_type
       SELECT ics_cmpl_mon_agncy_type.*
         FROM ics_cmpl_mon_agncy_type
            JOIN ics_cmpl_mon
              ON ics_cmpl_mon_agncy_type.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id
         WHERE ics_cmpl_mon.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_CONTACT
  INSERT INTO ics_flow_icis..ics_contact
       SELECT ics_contact.*
         FROM ics_contact
            JOIN ics_cmpl_mon
              ON ics_contact.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id
         WHERE ics_cmpl_mon.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_CONTACT/ICS_TELEPH
  INSERT INTO ics_flow_icis..ics_teleph
       SELECT ics_teleph.*
         FROM ics_teleph
            JOIN ics_contact
              ON ics_teleph.ics_contact_id = ics_contact.ics_contact_id
            JOIN ics_cmpl_mon
              ON ics_contact.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id
         WHERE ics_cmpl_mon.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_CSO_INSP
  INSERT INTO ics_flow_icis..ics_cso_insp
       SELECT ics_cso_insp.*
         FROM ics_cso_insp
            JOIN ics_cmpl_mon
              ON ics_cso_insp.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id
         WHERE ics_cmpl_mon.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_NAT_PRIO
  INSERT INTO ics_flow_icis..ics_nat_prio
       SELECT ics_nat_prio.*
         FROM ics_nat_prio
            JOIN ics_cmpl_mon
              ON ics_nat_prio.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id
         WHERE ics_cmpl_mon.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_PRETR_INSP
  INSERT INTO ics_flow_icis..ics_pretr_insp
       SELECT ics_pretr_insp.*
         FROM ics_pretr_insp
            JOIN ics_cmpl_mon
              ON ics_pretr_insp.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id
         WHERE ics_cmpl_mon.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_PRETR_INSP/ICS_LOC_LMTS
  INSERT INTO ics_flow_icis..ics_loc_lmts
       SELECT ics_loc_lmts.*
         FROM ics_loc_lmts
            JOIN ics_pretr_insp
              ON ics_loc_lmts.ics_pretr_insp_id = ics_pretr_insp.ics_pretr_insp_id
            JOIN ics_cmpl_mon
              ON ics_pretr_insp.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id
         WHERE ics_cmpl_mon.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_PRETR_INSP/ICS_LOC_LMTS/ICS_LOC_LMTS_POLUT
  INSERT INTO ics_flow_icis..ics_loc_lmts_polut
       SELECT ics_loc_lmts_polut.*
         FROM ics_loc_lmts_polut
            JOIN ics_loc_lmts
              ON ics_loc_lmts_polut.ics_loc_lmts_id = ics_loc_lmts.ics_loc_lmts_id
            JOIN ics_pretr_insp
              ON ics_loc_lmts.ics_pretr_insp_id = ics_pretr_insp.ics_pretr_insp_id
            JOIN ics_cmpl_mon
              ON ics_pretr_insp.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id
         WHERE ics_cmpl_mon.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_PRETR_INSP/ICS_RMVL_CRDTS
  INSERT INTO ics_flow_icis..ics_rmvl_crdts
       SELECT ics_rmvl_crdts.*
         FROM ics_rmvl_crdts
            JOIN ics_pretr_insp
              ON ics_rmvl_crdts.ics_pretr_insp_id = ics_pretr_insp.ics_pretr_insp_id
            JOIN ics_cmpl_mon
              ON ics_pretr_insp.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id
         WHERE ics_cmpl_mon.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_PRETR_INSP/ICS_RMVL_CRDTS/ICS_RMVL_CRDTS_POLUT
  INSERT INTO ics_flow_icis..ics_rmvl_crdts_polut
       SELECT ics_rmvl_crdts_polut.*
         FROM ics_rmvl_crdts_polut
            JOIN ics_rmvl_crdts
              ON ics_rmvl_crdts_polut.ics_rmvl_crdts_id = ics_rmvl_crdts.ics_rmvl_crdts_id
            JOIN ics_pretr_insp
              ON ics_rmvl_crdts.ics_pretr_insp_id = ics_pretr_insp.ics_pretr_insp_id
            JOIN ics_cmpl_mon
              ON ics_pretr_insp.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id
         WHERE ics_cmpl_mon.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_PROG
  INSERT INTO ics_flow_icis..ics_prog
       SELECT ics_prog.*
         FROM ics_prog
            JOIN ics_cmpl_mon
              ON ics_prog.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id
         WHERE ics_cmpl_mon.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_SSO_INSP
  INSERT INTO ics_flow_icis..ics_sso_insp
       SELECT ics_sso_insp.*
         FROM ics_sso_insp
            JOIN ics_cmpl_mon
              ON ics_sso_insp.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id
         WHERE ics_cmpl_mon.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_SSO_INSP/ICS_IMPACT_SSO_EVT
  INSERT INTO ics_flow_icis..ics_impact_sso_evt
       SELECT ics_impact_sso_evt.*
         FROM ics_impact_sso_evt
            JOIN ics_sso_insp
              ON ics_impact_sso_evt.ics_sso_insp_id = ics_sso_insp.ics_sso_insp_id
            JOIN ics_cmpl_mon
              ON ics_sso_insp.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id
         WHERE ics_cmpl_mon.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_SSO_INSP/ICS_SSO_STPS
  INSERT INTO ics_flow_icis..ics_sso_stps
       SELECT ics_sso_stps.*
         FROM ics_sso_stps
            JOIN ics_sso_insp
              ON ics_sso_stps.ics_sso_insp_id = ics_sso_insp.ics_sso_insp_id
            JOIN ics_cmpl_mon
              ON ics_sso_insp.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id
         WHERE ics_cmpl_mon.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_SSO_INSP/ICS_SSO_SYSTM_COMP
  INSERT INTO ics_flow_icis..ics_sso_systm_comp
       SELECT ics_sso_systm_comp.*
         FROM ics_sso_systm_comp
            JOIN ics_sso_insp
              ON ics_sso_systm_comp.ics_sso_insp_id = ics_sso_insp.ics_sso_insp_id
            JOIN ics_cmpl_mon
              ON ics_sso_insp.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id
         WHERE ics_cmpl_mon.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_SW_CNST_INSP
  INSERT INTO ics_flow_icis..ics_sw_cnst_insp
       SELECT ics_sw_cnst_insp.*
         FROM ics_sw_cnst_insp
            JOIN ics_cmpl_mon
              ON ics_sw_cnst_insp.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id
         WHERE ics_cmpl_mon.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_SW_CNST_INSP/ICS_SW_CNST_INDST_INSP
  INSERT INTO ics_flow_icis..ics_sw_cnst_indst_insp
       SELECT ics_sw_cnst_indst_insp.*
         FROM ics_sw_cnst_indst_insp
            JOIN ics_sw_cnst_insp
              ON ics_sw_cnst_indst_insp.ics_sw_cnst_insp_id = ics_sw_cnst_insp.ics_sw_cnst_insp_id
            JOIN ics_cmpl_mon
              ON ics_sw_cnst_insp.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id
         WHERE ics_cmpl_mon.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_SW_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP
  INSERT INTO ics_flow_icis..ics_sw_unprmt_cnst_insp
       SELECT ics_sw_unprmt_cnst_insp.*
         FROM ics_sw_unprmt_cnst_insp
            JOIN ics_sw_cnst_insp
              ON ics_sw_unprmt_cnst_insp.ics_sw_cnst_insp_id = ics_sw_cnst_insp.ics_sw_cnst_insp_id
            JOIN ics_cmpl_mon
              ON ics_sw_cnst_insp.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id
         WHERE ics_cmpl_mon.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_SW_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP/ICS_PROJ_TYPE
  INSERT INTO ics_flow_icis..ics_proj_type
       SELECT ics_proj_type.*
         FROM ics_proj_type
            JOIN ics_sw_unprmt_cnst_insp
              ON ics_proj_type.ics_sw_unprmt_cnst_insp_id = ics_sw_unprmt_cnst_insp.ics_sw_unprmt_cnst_insp_id
            JOIN ics_sw_cnst_insp
              ON ics_sw_unprmt_cnst_insp.ics_sw_cnst_insp_id = ics_sw_cnst_insp.ics_sw_cnst_insp_id
            JOIN ics_cmpl_mon
              ON ics_sw_cnst_insp.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id
         WHERE ics_cmpl_mon.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_SW_CNST_NON_CNST_INSP
  INSERT INTO ics_flow_icis..ics_sw_cnst_non_cnst_insp
       SELECT ics_sw_cnst_non_cnst_insp.*
         FROM ics_sw_cnst_non_cnst_insp
            JOIN ics_cmpl_mon
              ON ics_sw_cnst_non_cnst_insp.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id
         WHERE ics_cmpl_mon.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_SW_CNST_NON_CNST_INSP/ICS_SW_CNST_INDST_INSP
  INSERT INTO ics_flow_icis..ics_sw_cnst_indst_insp
       SELECT ics_sw_cnst_indst_insp.*
         FROM ics_sw_cnst_indst_insp
            JOIN ics_sw_cnst_non_cnst_insp
              ON ics_sw_cnst_indst_insp.ics_sw_cnst_non_cnst_insp_id = ics_sw_cnst_non_cnst_insp.ics_sw_cnst_non_cnst_insp_id
            JOIN ics_cmpl_mon
              ON ics_sw_cnst_non_cnst_insp.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id
         WHERE ics_cmpl_mon.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_SW_CNST_NON_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP
  INSERT INTO ics_flow_icis..ics_sw_unprmt_cnst_insp
       SELECT ics_sw_unprmt_cnst_insp.*
         FROM ics_sw_unprmt_cnst_insp
            JOIN ics_sw_cnst_non_cnst_insp
              ON ics_sw_unprmt_cnst_insp.ics_sw_cnst_non_cnst_insp_id = ics_sw_cnst_non_cnst_insp.ics_sw_cnst_non_cnst_insp_id
            JOIN ics_cmpl_mon
              ON ics_sw_cnst_non_cnst_insp.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id
         WHERE ics_cmpl_mon.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_SW_CNST_NON_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP/ICS_PROJ_TYPE
  INSERT INTO ics_flow_icis..ics_proj_type
       SELECT ics_proj_type.*
         FROM ics_proj_type
            JOIN ics_sw_unprmt_cnst_insp
              ON ics_proj_type.ics_sw_unprmt_cnst_insp_id = ics_sw_unprmt_cnst_insp.ics_sw_unprmt_cnst_insp_id
            JOIN ics_sw_cnst_non_cnst_insp
              ON ics_sw_unprmt_cnst_insp.ics_sw_cnst_non_cnst_insp_id = ics_sw_cnst_non_cnst_insp.ics_sw_cnst_non_cnst_insp_id
            JOIN ics_cmpl_mon
              ON ics_sw_cnst_non_cnst_insp.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id
         WHERE ics_cmpl_mon.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_SW_MS_4_INSP
  INSERT INTO ics_flow_icis..ics_sw_ms_4_insp
       SELECT ics_sw_ms_4_insp.*
         FROM ics_sw_ms_4_insp
            JOIN ics_cmpl_mon
              ON ics_sw_ms_4_insp.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id
         WHERE ics_cmpl_mon.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_SW_MS_4_INSP/ICS_PROJ_SRCS_FUND
  INSERT INTO ics_flow_icis..ics_proj_srcs_fund
       SELECT ics_proj_srcs_fund.*
         FROM ics_proj_srcs_fund
            JOIN ics_sw_ms_4_insp
              ON ics_proj_srcs_fund.ics_sw_ms_4_insp_id = ics_sw_ms_4_insp.ics_sw_ms_4_insp_id
            JOIN ics_cmpl_mon
              ON ics_sw_ms_4_insp.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id
         WHERE ics_cmpl_mon.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_SW_NON_CNST_INSP
  INSERT INTO ics_flow_icis..ics_sw_non_cnst_insp
       SELECT ics_sw_non_cnst_insp.*
         FROM ics_sw_non_cnst_insp
            JOIN ics_cmpl_mon
              ON ics_sw_non_cnst_insp.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id
         WHERE ics_cmpl_mon.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_SW_NON_CNST_INSP/ICS_SW_CNST_INDST_INSP
  INSERT INTO ics_flow_icis..ics_sw_cnst_indst_insp
       SELECT ics_sw_cnst_indst_insp.*
         FROM ics_sw_cnst_indst_insp
            JOIN ics_sw_non_cnst_insp
              ON ics_sw_cnst_indst_insp.ics_sw_non_cnst_insp_id = ics_sw_non_cnst_insp.ics_sw_non_cnst_insp_id
            JOIN ics_cmpl_mon
              ON ics_sw_non_cnst_insp.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id
         WHERE ics_cmpl_mon.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_SW_NON_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP
  INSERT INTO ics_flow_icis..ics_sw_unprmt_cnst_insp
       SELECT ics_sw_unprmt_cnst_insp.*
         FROM ics_sw_unprmt_cnst_insp
            JOIN ics_sw_non_cnst_insp
              ON ics_sw_unprmt_cnst_insp.ics_sw_non_cnst_insp_id = ics_sw_non_cnst_insp.ics_sw_non_cnst_insp_id
            JOIN ics_cmpl_mon
              ON ics_sw_non_cnst_insp.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id
         WHERE ics_cmpl_mon.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'ComplianceMonitoringSubmission');

  -- /ICS_CMPL_MON/ICS_SW_NON_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP/ICS_PROJ_TYPE
  INSERT INTO ics_flow_icis..ics_proj_type
       SELECT ics_proj_type.*
         FROM ics_proj_type
            JOIN ics_sw_unprmt_cnst_insp
              ON ics_proj_type.ics_sw_unprmt_cnst_insp_id = ics_sw_unprmt_cnst_insp.ics_sw_unprmt_cnst_insp_id
            JOIN ics_sw_non_cnst_insp
              ON ics_sw_unprmt_cnst_insp.ics_sw_non_cnst_insp_id = ics_sw_non_cnst_insp.ics_sw_non_cnst_insp_id
            JOIN ics_cmpl_mon
              ON ics_sw_non_cnst_insp.ics_cmpl_mon_id = ics_cmpl_mon.ics_cmpl_mon_id
         WHERE ics_cmpl_mon.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'ComplianceMonitoringSubmission');


  -- Remove any old records for ics_gnrl_prmt
  -- /ICS_GNRL_PRMT/ICS_FAC/ICS_ADDR/ICS_TELEPH
  DELETE
    FROM ics_flow_icis..ics_teleph
   WHERE ics_addr_id IN
            (SELECT ics_addr.ics_addr_id
               FROM ics_gnrl_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_gnrl_prmt.key_hash 
                    JOIN ics_fac ON ics_fac.ics_gnrl_prmt_id = ics_gnrl_prmt.ics_gnrl_prmt_id
                    JOIN ics_addr ON ics_addr.ics_fac_id = ics_fac.ics_fac_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission');

  -- /ICS_GNRL_PRMT/ICS_FAC/ICS_CONTACT/ICS_TELEPH
  DELETE
    FROM ics_flow_icis..ics_teleph
   WHERE ics_contact_id IN
            (SELECT ics_contact.ics_contact_id
               FROM ics_gnrl_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_gnrl_prmt.key_hash 
                    JOIN ics_fac ON ics_fac.ics_gnrl_prmt_id = ics_gnrl_prmt.ics_gnrl_prmt_id
                    JOIN ics_contact ON ics_contact.ics_fac_id = ics_fac.ics_fac_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission');

  -- /ICS_GNRL_PRMT/ICS_ADDR/ICS_TELEPH
  DELETE
    FROM ics_flow_icis..ics_teleph
   WHERE ics_addr_id IN
            (SELECT ics_addr.ics_addr_id
               FROM ics_gnrl_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_gnrl_prmt.key_hash 
                    JOIN ics_addr ON ics_addr.ics_gnrl_prmt_id = ics_gnrl_prmt.ics_gnrl_prmt_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission');

  -- /ICS_GNRL_PRMT/ICS_CONTACT/ICS_TELEPH
  DELETE
    FROM ics_flow_icis..ics_teleph
   WHERE ics_contact_id IN
            (SELECT ics_contact.ics_contact_id
               FROM ics_gnrl_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_gnrl_prmt.key_hash 
                    JOIN ics_contact ON ics_contact.ics_gnrl_prmt_id = ics_gnrl_prmt.ics_gnrl_prmt_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission');

  -- /ICS_GNRL_PRMT/ICS_FAC/ICS_ADDR
  DELETE
    FROM ics_flow_icis..ics_addr
   WHERE ics_fac_id IN
            (SELECT ics_fac.ics_fac_id
               FROM ics_gnrl_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_gnrl_prmt.key_hash 
                    JOIN ics_fac ON ics_fac.ics_gnrl_prmt_id = ics_gnrl_prmt.ics_gnrl_prmt_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission');

  -- /ICS_GNRL_PRMT/ICS_FAC/ICS_CONTACT
  DELETE
    FROM ics_flow_icis..ics_contact
   WHERE ics_fac_id IN
            (SELECT ics_fac.ics_fac_id
               FROM ics_gnrl_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_gnrl_prmt.key_hash 
                    JOIN ics_fac ON ics_fac.ics_gnrl_prmt_id = ics_gnrl_prmt.ics_gnrl_prmt_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission');

  -- /ICS_GNRL_PRMT/ICS_FAC/ICS_FAC_CLASS
  DELETE
    FROM ics_flow_icis..ics_fac_class
   WHERE ics_fac_id IN
            (SELECT ics_fac.ics_fac_id
               FROM ics_gnrl_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_gnrl_prmt.key_hash 
                    JOIN ics_fac ON ics_fac.ics_gnrl_prmt_id = ics_gnrl_prmt.ics_gnrl_prmt_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission');

  -- /ICS_GNRL_PRMT/ICS_FAC/ICS_GEO_COORD
  DELETE
    FROM ics_flow_icis..ics_geo_coord
   WHERE ics_fac_id IN
            (SELECT ics_fac.ics_fac_id
               FROM ics_gnrl_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_gnrl_prmt.key_hash 
                    JOIN ics_fac ON ics_fac.ics_gnrl_prmt_id = ics_gnrl_prmt.ics_gnrl_prmt_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission');

  -- /ICS_GNRL_PRMT/ICS_FAC/ICS_NAICS_CODE
  DELETE
    FROM ics_flow_icis..ics_naics_code
   WHERE ics_fac_id IN
            (SELECT ics_fac.ics_fac_id
               FROM ics_gnrl_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_gnrl_prmt.key_hash 
                    JOIN ics_fac ON ics_fac.ics_gnrl_prmt_id = ics_gnrl_prmt.ics_gnrl_prmt_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission');

  -- /ICS_GNRL_PRMT/ICS_FAC/ICS_ORIG_PROGS
  DELETE
    FROM ics_flow_icis..ics_orig_progs
   WHERE ics_fac_id IN
            (SELECT ics_fac.ics_fac_id
               FROM ics_gnrl_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_gnrl_prmt.key_hash 
                    JOIN ics_fac ON ics_fac.ics_gnrl_prmt_id = ics_gnrl_prmt.ics_gnrl_prmt_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission');

  -- /ICS_GNRL_PRMT/ICS_FAC/ICS_PLCY
  DELETE
    FROM ics_flow_icis..ics_plcy
   WHERE ics_fac_id IN
            (SELECT ics_fac.ics_fac_id
               FROM ics_gnrl_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_gnrl_prmt.key_hash 
                    JOIN ics_fac ON ics_fac.ics_gnrl_prmt_id = ics_gnrl_prmt.ics_gnrl_prmt_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission');

  -- /ICS_GNRL_PRMT/ICS_FAC/ICS_SIC_CODE
  DELETE
    FROM ics_flow_icis..ics_sic_code
   WHERE ics_fac_id IN
            (SELECT ics_fac.ics_fac_id
               FROM ics_gnrl_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_gnrl_prmt.key_hash 
                    JOIN ics_fac ON ics_fac.ics_gnrl_prmt_id = ics_gnrl_prmt.ics_gnrl_prmt_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission');

  -- /ICS_GNRL_PRMT/ICS_ADDR
  DELETE
    FROM ics_flow_icis..ics_addr
   WHERE ics_gnrl_prmt_id IN
            (SELECT ics_gnrl_prmt.ics_gnrl_prmt_id
               FROM ics_gnrl_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_gnrl_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission');

  -- /ICS_GNRL_PRMT/ICS_ASSC_PRMT
  DELETE
    FROM ics_flow_icis..ics_assc_prmt
   WHERE ics_gnrl_prmt_id IN
            (SELECT ics_gnrl_prmt.ics_gnrl_prmt_id
               FROM ics_gnrl_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_gnrl_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission');

  -- /ICS_GNRL_PRMT/ICS_CMPL_TRACK_STAT
  DELETE
    FROM ics_flow_icis..ics_cmpl_track_stat
   WHERE ics_gnrl_prmt_id IN
            (SELECT ics_gnrl_prmt.ics_gnrl_prmt_id
               FROM ics_gnrl_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_gnrl_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission');

  -- /ICS_GNRL_PRMT/ICS_CONTACT
  DELETE
    FROM ics_flow_icis..ics_contact
   WHERE ics_gnrl_prmt_id IN
            (SELECT ics_gnrl_prmt.ics_gnrl_prmt_id
               FROM ics_gnrl_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_gnrl_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission');

  -- /ICS_GNRL_PRMT/ICS_EFFLU_GUIDE
  DELETE
    FROM ics_flow_icis..ics_efflu_guide
   WHERE ics_gnrl_prmt_id IN
            (SELECT ics_gnrl_prmt.ics_gnrl_prmt_id
               FROM ics_gnrl_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_gnrl_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission');

  -- /ICS_GNRL_PRMT/ICS_FAC
  DELETE
    FROM ics_flow_icis..ics_fac
   WHERE ics_gnrl_prmt_id IN
            (SELECT ics_gnrl_prmt.ics_gnrl_prmt_id
               FROM ics_gnrl_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_gnrl_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission');

  -- /ICS_GNRL_PRMT/ICS_NAICS_CODE
  DELETE
    FROM ics_flow_icis..ics_naics_code
   WHERE ics_gnrl_prmt_id IN
            (SELECT ics_gnrl_prmt.ics_gnrl_prmt_id
               FROM ics_gnrl_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_gnrl_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission');

  -- /ICS_GNRL_PRMT/ICS_OTHR_PRMTS
  DELETE
    FROM ics_flow_icis..ics_othr_prmts
   WHERE ics_gnrl_prmt_id IN
            (SELECT ics_gnrl_prmt.ics_gnrl_prmt_id
               FROM ics_gnrl_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_gnrl_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission');

  -- /ICS_GNRL_PRMT/ICS_SIC_CODE
  DELETE
    FROM ics_flow_icis..ics_sic_code
   WHERE ics_gnrl_prmt_id IN
            (SELECT ics_gnrl_prmt.ics_gnrl_prmt_id
               FROM ics_gnrl_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_gnrl_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission');

  -- /ICS_GNRL_PRMT
  DELETE
    FROM ics_flow_icis..ics_gnrl_prmt
   WHERE ics_gnrl_prmt_id IN
            (SELECT ics_gnrl_prmt.ics_gnrl_prmt_id
               FROM ics_gnrl_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_gnrl_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission');


  -- Add accepted records for ics_gnrl_prmt
  -- /ICS_GNRL_PRMT
  INSERT INTO ics_flow_icis..ics_gnrl_prmt
       SELECT ics_gnrl_prmt.*
         FROM ics_gnrl_prmt
         WHERE ics_gnrl_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'GeneralPermitSubmission');

  -- /ICS_GNRL_PRMT/ICS_ADDR
  INSERT INTO ics_flow_icis..ics_addr
       SELECT ics_addr.*
         FROM ics_addr
            JOIN ics_gnrl_prmt
              ON ics_addr.ics_gnrl_prmt_id = ics_gnrl_prmt.ics_gnrl_prmt_id
         WHERE ics_gnrl_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'GeneralPermitSubmission');

  -- /ICS_GNRL_PRMT/ICS_ADDR/ICS_TELEPH
  INSERT INTO ics_flow_icis..ics_teleph
       SELECT ics_teleph.*
         FROM ics_teleph
            JOIN ics_addr
              ON ics_teleph.ics_addr_id = ics_addr.ics_addr_id
            JOIN ics_gnrl_prmt
              ON ics_addr.ics_gnrl_prmt_id = ics_gnrl_prmt.ics_gnrl_prmt_id
         WHERE ics_gnrl_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'GeneralPermitSubmission');

  -- /ICS_GNRL_PRMT/ICS_ASSC_PRMT
  INSERT INTO ics_flow_icis..ics_assc_prmt
       SELECT ics_assc_prmt.*
         FROM ics_assc_prmt
            JOIN ics_gnrl_prmt
              ON ics_assc_prmt.ics_gnrl_prmt_id = ics_gnrl_prmt.ics_gnrl_prmt_id
         WHERE ics_gnrl_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'GeneralPermitSubmission');

  -- /ICS_GNRL_PRMT/ICS_CMPL_TRACK_STAT
  INSERT INTO ics_flow_icis..ics_cmpl_track_stat
       SELECT ics_cmpl_track_stat.*
         FROM ics_cmpl_track_stat
            JOIN ics_gnrl_prmt
              ON ics_cmpl_track_stat.ics_gnrl_prmt_id = ics_gnrl_prmt.ics_gnrl_prmt_id
         WHERE ics_gnrl_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'GeneralPermitSubmission');

  -- /ICS_GNRL_PRMT/ICS_CONTACT
  INSERT INTO ics_flow_icis..ics_contact
       SELECT ics_contact.*
         FROM ics_contact
            JOIN ics_gnrl_prmt
              ON ics_contact.ics_gnrl_prmt_id = ics_gnrl_prmt.ics_gnrl_prmt_id
         WHERE ics_gnrl_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'GeneralPermitSubmission');

  -- /ICS_GNRL_PRMT/ICS_CONTACT/ICS_TELEPH
  INSERT INTO ics_flow_icis..ics_teleph
       SELECT ics_teleph.*
         FROM ics_teleph
            JOIN ics_contact
              ON ics_teleph.ics_contact_id = ics_contact.ics_contact_id
            JOIN ics_gnrl_prmt
              ON ics_contact.ics_gnrl_prmt_id = ics_gnrl_prmt.ics_gnrl_prmt_id
         WHERE ics_gnrl_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'GeneralPermitSubmission');

  -- /ICS_GNRL_PRMT/ICS_EFFLU_GUIDE
  INSERT INTO ics_flow_icis..ics_efflu_guide
       SELECT ics_efflu_guide.*
         FROM ics_efflu_guide
            JOIN ics_gnrl_prmt
              ON ics_efflu_guide.ics_gnrl_prmt_id = ics_gnrl_prmt.ics_gnrl_prmt_id
         WHERE ics_gnrl_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'GeneralPermitSubmission');

  -- /ICS_GNRL_PRMT/ICS_FAC
  INSERT INTO ics_flow_icis..ics_fac
       SELECT ics_fac.*
         FROM ics_fac
            JOIN ics_gnrl_prmt
              ON ics_fac.ics_gnrl_prmt_id = ics_gnrl_prmt.ics_gnrl_prmt_id
         WHERE ics_gnrl_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'GeneralPermitSubmission');

  -- /ICS_GNRL_PRMT/ICS_FAC/ICS_ADDR
  INSERT INTO ics_flow_icis..ics_addr
       SELECT ics_addr.*
         FROM ics_addr
            JOIN ics_fac
              ON ics_addr.ics_fac_id = ics_fac.ics_fac_id
            JOIN ics_gnrl_prmt
              ON ics_fac.ics_gnrl_prmt_id = ics_gnrl_prmt.ics_gnrl_prmt_id
         WHERE ics_gnrl_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'GeneralPermitSubmission');

  -- /ICS_GNRL_PRMT/ICS_FAC/ICS_ADDR/ICS_TELEPH
  INSERT INTO ics_flow_icis..ics_teleph
       SELECT ics_teleph.*
         FROM ics_teleph
            JOIN ics_addr
              ON ics_teleph.ics_addr_id = ics_addr.ics_addr_id
            JOIN ics_fac
              ON ics_addr.ics_fac_id = ics_fac.ics_fac_id
            JOIN ics_gnrl_prmt
              ON ics_fac.ics_gnrl_prmt_id = ics_gnrl_prmt.ics_gnrl_prmt_id
         WHERE ics_gnrl_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'GeneralPermitSubmission');

  -- /ICS_GNRL_PRMT/ICS_FAC/ICS_CONTACT
  INSERT INTO ics_flow_icis..ics_contact
       SELECT ics_contact.*
         FROM ics_contact
            JOIN ics_fac
              ON ics_contact.ics_fac_id = ics_fac.ics_fac_id
            JOIN ics_gnrl_prmt
              ON ics_fac.ics_gnrl_prmt_id = ics_gnrl_prmt.ics_gnrl_prmt_id
         WHERE ics_gnrl_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'GeneralPermitSubmission');

  -- /ICS_GNRL_PRMT/ICS_FAC/ICS_CONTACT/ICS_TELEPH
  INSERT INTO ics_flow_icis..ics_teleph
       SELECT ics_teleph.*
         FROM ics_teleph
            JOIN ics_contact
              ON ics_teleph.ics_contact_id = ics_contact.ics_contact_id
            JOIN ics_fac
              ON ics_contact.ics_fac_id = ics_fac.ics_fac_id
            JOIN ics_gnrl_prmt
              ON ics_fac.ics_gnrl_prmt_id = ics_gnrl_prmt.ics_gnrl_prmt_id
         WHERE ics_gnrl_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'GeneralPermitSubmission');

  -- /ICS_GNRL_PRMT/ICS_FAC/ICS_FAC_CLASS
  INSERT INTO ics_flow_icis..ics_fac_class
       SELECT ics_fac_class.*
         FROM ics_fac_class
            JOIN ics_fac
              ON ics_fac_class.ics_fac_id = ics_fac.ics_fac_id
            JOIN ics_gnrl_prmt
              ON ics_fac.ics_gnrl_prmt_id = ics_gnrl_prmt.ics_gnrl_prmt_id
         WHERE ics_gnrl_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'GeneralPermitSubmission');

  -- /ICS_GNRL_PRMT/ICS_FAC/ICS_GEO_COORD
  INSERT INTO ics_flow_icis..ics_geo_coord
       SELECT ics_geo_coord.*
         FROM ics_geo_coord
            JOIN ics_fac
              ON ics_geo_coord.ics_fac_id = ics_fac.ics_fac_id
            JOIN ics_gnrl_prmt
              ON ics_fac.ics_gnrl_prmt_id = ics_gnrl_prmt.ics_gnrl_prmt_id
         WHERE ics_gnrl_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'GeneralPermitSubmission');

  -- /ICS_GNRL_PRMT/ICS_FAC/ICS_NAICS_CODE
  INSERT INTO ics_flow_icis..ics_naics_code
       SELECT ics_naics_code.*
         FROM ics_naics_code
            JOIN ics_fac
              ON ics_naics_code.ics_fac_id = ics_fac.ics_fac_id
            JOIN ics_gnrl_prmt
              ON ics_fac.ics_gnrl_prmt_id = ics_gnrl_prmt.ics_gnrl_prmt_id
         WHERE ics_gnrl_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'GeneralPermitSubmission');

  -- /ICS_GNRL_PRMT/ICS_FAC/ICS_ORIG_PROGS
  INSERT INTO ics_flow_icis..ics_orig_progs
       SELECT ics_orig_progs.*
         FROM ics_orig_progs
            JOIN ics_fac
              ON ics_orig_progs.ics_fac_id = ics_fac.ics_fac_id
            JOIN ics_gnrl_prmt
              ON ics_fac.ics_gnrl_prmt_id = ics_gnrl_prmt.ics_gnrl_prmt_id
         WHERE ics_gnrl_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'GeneralPermitSubmission');

  -- /ICS_GNRL_PRMT/ICS_FAC/ICS_PLCY
  INSERT INTO ics_flow_icis..ics_plcy
       SELECT ics_plcy.*
         FROM ics_plcy
            JOIN ics_fac
              ON ics_plcy.ics_fac_id = ics_fac.ics_fac_id
            JOIN ics_gnrl_prmt
              ON ics_fac.ics_gnrl_prmt_id = ics_gnrl_prmt.ics_gnrl_prmt_id
         WHERE ics_gnrl_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'GeneralPermitSubmission');

  -- /ICS_GNRL_PRMT/ICS_FAC/ICS_SIC_CODE
  INSERT INTO ics_flow_icis..ics_sic_code
       SELECT ics_sic_code.*
         FROM ics_sic_code
            JOIN ics_fac
              ON ics_sic_code.ics_fac_id = ics_fac.ics_fac_id
            JOIN ics_gnrl_prmt
              ON ics_fac.ics_gnrl_prmt_id = ics_gnrl_prmt.ics_gnrl_prmt_id
         WHERE ics_gnrl_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'GeneralPermitSubmission');

  -- /ICS_GNRL_PRMT/ICS_NAICS_CODE
  INSERT INTO ics_flow_icis..ics_naics_code
       SELECT ics_naics_code.*
         FROM ics_naics_code
            JOIN ics_gnrl_prmt
              ON ics_naics_code.ics_gnrl_prmt_id = ics_gnrl_prmt.ics_gnrl_prmt_id
         WHERE ics_gnrl_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'GeneralPermitSubmission');

  -- /ICS_GNRL_PRMT/ICS_OTHR_PRMTS
  INSERT INTO ics_flow_icis..ics_othr_prmts
       SELECT ics_othr_prmts.*
         FROM ics_othr_prmts
            JOIN ics_gnrl_prmt
              ON ics_othr_prmts.ics_gnrl_prmt_id = ics_gnrl_prmt.ics_gnrl_prmt_id
         WHERE ics_gnrl_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'GeneralPermitSubmission');

  -- /ICS_GNRL_PRMT/ICS_SIC_CODE
  INSERT INTO ics_flow_icis..ics_sic_code
       SELECT ics_sic_code.*
         FROM ics_sic_code
            JOIN ics_gnrl_prmt
              ON ics_sic_code.ics_gnrl_prmt_id = ics_gnrl_prmt.ics_gnrl_prmt_id
         WHERE ics_gnrl_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'GeneralPermitSubmission');


  -- Remove any old records for ics_master_gnrl_prmt
  -- /ICS_MASTER_GNRL_PRMT/ICS_CONTACT/ICS_TELEPH
  DELETE
    FROM ics_flow_icis..ics_teleph
   WHERE ics_contact_id IN
            (SELECT ics_contact.ics_contact_id
               FROM ics_master_gnrl_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_master_gnrl_prmt.key_hash 
                    JOIN ics_contact ON ics_contact.ics_master_gnrl_prmt_id = ics_master_gnrl_prmt.ics_master_gnrl_prmt_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'MasterGeneralPermitSubmission');

  -- /ICS_MASTER_GNRL_PRMT/ICS_ASSC_PRMT
  DELETE
    FROM ics_flow_icis..ics_assc_prmt
   WHERE ics_master_gnrl_prmt_id IN
            (SELECT ics_master_gnrl_prmt.ics_master_gnrl_prmt_id
               FROM ics_master_gnrl_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_master_gnrl_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'MasterGeneralPermitSubmission');

  -- /ICS_MASTER_GNRL_PRMT/ICS_CONTACT
  DELETE
    FROM ics_flow_icis..ics_contact
   WHERE ics_master_gnrl_prmt_id IN
            (SELECT ics_master_gnrl_prmt.ics_master_gnrl_prmt_id
               FROM ics_master_gnrl_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_master_gnrl_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'MasterGeneralPermitSubmission');

  -- /ICS_MASTER_GNRL_PRMT/ICS_NAICS_CODE
  DELETE
    FROM ics_flow_icis..ics_naics_code
   WHERE ics_master_gnrl_prmt_id IN
            (SELECT ics_master_gnrl_prmt.ics_master_gnrl_prmt_id
               FROM ics_master_gnrl_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_master_gnrl_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'MasterGeneralPermitSubmission');

  -- /ICS_MASTER_GNRL_PRMT/ICS_OTHR_PRMTS
  DELETE
    FROM ics_flow_icis..ics_othr_prmts
   WHERE ics_master_gnrl_prmt_id IN
            (SELECT ics_master_gnrl_prmt.ics_master_gnrl_prmt_id
               FROM ics_master_gnrl_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_master_gnrl_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'MasterGeneralPermitSubmission');

  -- /ICS_MASTER_GNRL_PRMT/ICS_PRMT_COMP_TYPE
  DELETE
    FROM ics_flow_icis..ics_prmt_comp_type
   WHERE ics_master_gnrl_prmt_id IN
            (SELECT ics_master_gnrl_prmt.ics_master_gnrl_prmt_id
               FROM ics_master_gnrl_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_master_gnrl_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'MasterGeneralPermitSubmission');

  -- /ICS_MASTER_GNRL_PRMT/ICS_SIC_CODE
  DELETE
    FROM ics_flow_icis..ics_sic_code
   WHERE ics_master_gnrl_prmt_id IN
            (SELECT ics_master_gnrl_prmt.ics_master_gnrl_prmt_id
               FROM ics_master_gnrl_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_master_gnrl_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'MasterGeneralPermitSubmission');

  -- /ICS_MASTER_GNRL_PRMT
  DELETE
    FROM ics_flow_icis..ics_master_gnrl_prmt
   WHERE ics_master_gnrl_prmt_id IN
            (SELECT ics_master_gnrl_prmt.ics_master_gnrl_prmt_id
               FROM ics_master_gnrl_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_master_gnrl_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'MasterGeneralPermitSubmission');


  -- Add accepted records for ics_master_gnrl_prmt
  -- /ICS_MASTER_GNRL_PRMT
  INSERT INTO ics_flow_icis..ics_master_gnrl_prmt
       SELECT ics_master_gnrl_prmt.*
         FROM ics_master_gnrl_prmt
         WHERE ics_master_gnrl_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'MasterGeneralPermitSubmission');

  -- /ICS_MASTER_GNRL_PRMT/ICS_ASSC_PRMT
  INSERT INTO ics_flow_icis..ics_assc_prmt
       SELECT ics_assc_prmt.*
         FROM ics_assc_prmt
            JOIN ics_master_gnrl_prmt
              ON ics_assc_prmt.ics_master_gnrl_prmt_id = ics_master_gnrl_prmt.ics_master_gnrl_prmt_id
         WHERE ics_master_gnrl_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'MasterGeneralPermitSubmission');

  -- /ICS_MASTER_GNRL_PRMT/ICS_CONTACT
  INSERT INTO ics_flow_icis..ics_contact
       SELECT ics_contact.*
         FROM ics_contact
            JOIN ics_master_gnrl_prmt
              ON ics_contact.ics_master_gnrl_prmt_id = ics_master_gnrl_prmt.ics_master_gnrl_prmt_id
         WHERE ics_master_gnrl_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'MasterGeneralPermitSubmission');

  -- /ICS_MASTER_GNRL_PRMT/ICS_CONTACT/ICS_TELEPH
  INSERT INTO ics_flow_icis..ics_teleph
       SELECT ics_teleph.*
         FROM ics_teleph
            JOIN ics_contact
              ON ics_teleph.ics_contact_id = ics_contact.ics_contact_id
            JOIN ics_master_gnrl_prmt
              ON ics_contact.ics_master_gnrl_prmt_id = ics_master_gnrl_prmt.ics_master_gnrl_prmt_id
         WHERE ics_master_gnrl_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'MasterGeneralPermitSubmission');

  -- /ICS_MASTER_GNRL_PRMT/ICS_NAICS_CODE
  INSERT INTO ics_flow_icis..ics_naics_code
       SELECT ics_naics_code.*
         FROM ics_naics_code
            JOIN ics_master_gnrl_prmt
              ON ics_naics_code.ics_master_gnrl_prmt_id = ics_master_gnrl_prmt.ics_master_gnrl_prmt_id
         WHERE ics_master_gnrl_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'MasterGeneralPermitSubmission');

  -- /ICS_MASTER_GNRL_PRMT/ICS_OTHR_PRMTS
  INSERT INTO ics_flow_icis..ics_othr_prmts
       SELECT ics_othr_prmts.*
         FROM ics_othr_prmts
            JOIN ics_master_gnrl_prmt
              ON ics_othr_prmts.ics_master_gnrl_prmt_id = ics_master_gnrl_prmt.ics_master_gnrl_prmt_id
         WHERE ics_master_gnrl_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'MasterGeneralPermitSubmission');

  -- /ICS_MASTER_GNRL_PRMT/ICS_PRMT_COMP_TYPE
  INSERT INTO ics_flow_icis..ics_prmt_comp_type
       SELECT ics_prmt_comp_type.*
         FROM ics_prmt_comp_type
            JOIN ics_master_gnrl_prmt
              ON ics_prmt_comp_type.ics_master_gnrl_prmt_id = ics_master_gnrl_prmt.ics_master_gnrl_prmt_id
         WHERE ics_master_gnrl_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'MasterGeneralPermitSubmission');

  -- /ICS_MASTER_GNRL_PRMT/ICS_SIC_CODE
  INSERT INTO ics_flow_icis..ics_sic_code
       SELECT ics_sic_code.*
         FROM ics_sic_code
            JOIN ics_master_gnrl_prmt
              ON ics_sic_code.ics_master_gnrl_prmt_id = ics_master_gnrl_prmt.ics_master_gnrl_prmt_id
         WHERE ics_master_gnrl_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'MasterGeneralPermitSubmission');


  -- Remove any old records for ics_prmt_reissu
  -- /ICS_PRMT_REISSU
  DELETE
    FROM ics_flow_icis..ics_prmt_reissu
   WHERE ics_prmt_reissu_id IN
            (SELECT ics_prmt_reissu.ics_prmt_reissu_id
               FROM ics_prmt_reissu
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_prmt_reissu.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PermitReissuanceSubmission');


  -- Add accepted records for ics_prmt_reissu
  -- /ICS_PRMT_REISSU
  INSERT INTO ics_flow_icis..ics_prmt_reissu
       SELECT ics_prmt_reissu.*
         FROM ics_prmt_reissu
         WHERE ics_prmt_reissu.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'PermitReissuanceSubmission');


  -- Remove any old records for ics_prmt_term
  -- /ICS_PRMT_TERM
  DELETE
    FROM ics_flow_icis..ics_prmt_term
   WHERE ics_prmt_term_id IN
            (SELECT ics_prmt_term.ics_prmt_term_id
               FROM ics_prmt_term
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_prmt_term.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PermitTerminationSubmission');


  -- Add accepted records for ics_prmt_term
  -- /ICS_PRMT_TERM
  INSERT INTO ics_flow_icis..ics_prmt_term
       SELECT ics_prmt_term.*
         FROM ics_prmt_term
         WHERE ics_prmt_term.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'PermitTerminationSubmission');


  -- Remove any old records for ics_prmt_track_evt
  -- /ICS_PRMT_TRACK_EVT
  DELETE
    FROM ics_flow_icis..ics_prmt_track_evt
   WHERE ics_prmt_track_evt_id IN
            (SELECT ics_prmt_track_evt.ics_prmt_track_evt_id
               FROM ics_prmt_track_evt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_prmt_track_evt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PermitTrackingEventSubmission');


  -- Add accepted records for ics_prmt_track_evt
  -- /ICS_PRMT_TRACK_EVT
  INSERT INTO ics_flow_icis..ics_prmt_track_evt
       SELECT ics_prmt_track_evt.*
         FROM ics_prmt_track_evt
         WHERE ics_prmt_track_evt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'PermitTrackingEventSubmission');


  -- Remove any old records for ics_potw_prmt
  -- /ICS_POTW_PRMT/ICS_SATL_COLL_SYSTM
  DELETE
    FROM ics_flow_icis..ics_satl_coll_systm
   WHERE ics_potw_prmt_id IN
            (SELECT ics_potw_prmt.ics_potw_prmt_id
               FROM ics_potw_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_potw_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'POTWPermitSubmission');

  -- /ICS_POTW_PRMT
  DELETE
    FROM ics_flow_icis..ics_potw_prmt
   WHERE ics_potw_prmt_id IN
            (SELECT ics_potw_prmt.ics_potw_prmt_id
               FROM ics_potw_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_potw_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'POTWPermitSubmission');


  -- Add accepted records for ics_potw_prmt
  -- /ICS_POTW_PRMT
  INSERT INTO ics_flow_icis..ics_potw_prmt
       SELECT ics_potw_prmt.*
         FROM ics_potw_prmt
         WHERE ics_potw_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'POTWPermitSubmission');

  -- /ICS_POTW_PRMT/ICS_SATL_COLL_SYSTM
  INSERT INTO ics_flow_icis..ics_satl_coll_systm
       SELECT ics_satl_coll_systm.*
         FROM ics_satl_coll_systm
            JOIN ics_potw_prmt
              ON ics_satl_coll_systm.ics_potw_prmt_id = ics_potw_prmt.ics_potw_prmt_id
         WHERE ics_potw_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'POTWPermitSubmission');


  -- Remove any old records for ics_pretr_prmt
  -- /ICS_PRETR_PRMT/ICS_CONTACT/ICS_TELEPH
  DELETE
    FROM ics_flow_icis..ics_teleph
   WHERE ics_contact_id IN
            (SELECT ics_contact.ics_contact_id
               FROM ics_pretr_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_pretr_prmt.key_hash 
                    JOIN ics_contact ON ics_contact.ics_pretr_prmt_id = ics_pretr_prmt.ics_pretr_prmt_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PretreatmentPermitSubmission');

  -- /ICS_PRETR_PRMT/ICS_CONTACT
  DELETE
    FROM ics_flow_icis..ics_contact
   WHERE ics_pretr_prmt_id IN
            (SELECT ics_pretr_prmt.ics_pretr_prmt_id
               FROM ics_pretr_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_pretr_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PretreatmentPermitSubmission');

  -- /ICS_PRETR_PRMT
  DELETE
    FROM ics_flow_icis..ics_pretr_prmt
   WHERE ics_pretr_prmt_id IN
            (SELECT ics_pretr_prmt.ics_pretr_prmt_id
               FROM ics_pretr_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_pretr_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PretreatmentPermitSubmission');


  -- Add accepted records for ics_pretr_prmt
  -- /ICS_PRETR_PRMT
  INSERT INTO ics_flow_icis..ics_pretr_prmt
       SELECT ics_pretr_prmt.*
         FROM ics_pretr_prmt
         WHERE ics_pretr_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'PretreatmentPermitSubmission');

  -- /ICS_PRETR_PRMT/ICS_CONTACT
  INSERT INTO ics_flow_icis..ics_contact
       SELECT ics_contact.*
         FROM ics_contact
            JOIN ics_pretr_prmt
              ON ics_contact.ics_pretr_prmt_id = ics_pretr_prmt.ics_pretr_prmt_id
         WHERE ics_pretr_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'PretreatmentPermitSubmission');

  -- /ICS_PRETR_PRMT/ICS_CONTACT/ICS_TELEPH
  INSERT INTO ics_flow_icis..ics_teleph
       SELECT ics_teleph.*
         FROM ics_teleph
            JOIN ics_contact
              ON ics_teleph.ics_contact_id = ics_contact.ics_contact_id
            JOIN ics_pretr_prmt
              ON ics_contact.ics_pretr_prmt_id = ics_pretr_prmt.ics_pretr_prmt_id
         WHERE ics_pretr_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'PretreatmentPermitSubmission');


  -- Remove any old records for ics_sw_cnst_prmt
  -- /ICS_SW_CNST_PRMT/ICS_ADDR/ICS_TELEPH
  DELETE
    FROM ics_flow_icis..ics_teleph
   WHERE ics_addr_id IN
            (SELECT ics_addr.ics_addr_id
               FROM ics_sw_cnst_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_sw_cnst_prmt.key_hash 
                    JOIN ics_addr ON ics_addr.ics_sw_cnst_prmt_id = ics_sw_cnst_prmt.ics_sw_cnst_prmt_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWConstructionPermitSubmission');

  -- /ICS_SW_CNST_PRMT/ICS_CONTACT/ICS_TELEPH
  DELETE
    FROM ics_flow_icis..ics_teleph
   WHERE ics_contact_id IN
            (SELECT ics_contact.ics_contact_id
               FROM ics_sw_cnst_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_sw_cnst_prmt.key_hash 
                    JOIN ics_contact ON ics_contact.ics_sw_cnst_prmt_id = ics_sw_cnst_prmt.ics_sw_cnst_prmt_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWConstructionPermitSubmission');

  -- /ICS_SW_CNST_PRMT/ICS_ADDR
  DELETE
    FROM ics_flow_icis..ics_addr
   WHERE ics_sw_cnst_prmt_id IN
            (SELECT ics_sw_cnst_prmt.ics_sw_cnst_prmt_id
               FROM ics_sw_cnst_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_sw_cnst_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWConstructionPermitSubmission');

  -- /ICS_SW_CNST_PRMT/ICS_CONTACT
  DELETE
    FROM ics_flow_icis..ics_contact
   WHERE ics_sw_cnst_prmt_id IN
            (SELECT ics_sw_cnst_prmt.ics_sw_cnst_prmt_id
               FROM ics_sw_cnst_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_sw_cnst_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWConstructionPermitSubmission');

  -- /ICS_SW_CNST_PRMT/ICS_GPCF_NOTICE_OF_INTENT
  DELETE
    FROM ics_flow_icis..ics_gpcf_notice_of_intent
   WHERE ics_sw_cnst_prmt_id IN
            (SELECT ics_sw_cnst_prmt.ics_sw_cnst_prmt_id
               FROM ics_sw_cnst_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_sw_cnst_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWConstructionPermitSubmission');

  -- /ICS_SW_CNST_PRMT/ICS_GPCF_NOTICE_OF_TERM
  DELETE
    FROM ics_flow_icis..ics_gpcf_notice_of_term
   WHERE ics_sw_cnst_prmt_id IN
            (SELECT ics_sw_cnst_prmt.ics_sw_cnst_prmt_id
               FROM ics_sw_cnst_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_sw_cnst_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWConstructionPermitSubmission');

  -- /ICS_SW_CNST_PRMT
  DELETE
    FROM ics_flow_icis..ics_sw_cnst_prmt
   WHERE ics_sw_cnst_prmt_id IN
            (SELECT ics_sw_cnst_prmt.ics_sw_cnst_prmt_id
               FROM ics_sw_cnst_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_sw_cnst_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWConstructionPermitSubmission');


  -- Add accepted records for ics_sw_cnst_prmt
  -- /ICS_SW_CNST_PRMT
  INSERT INTO ics_flow_icis..ics_sw_cnst_prmt
       SELECT ics_sw_cnst_prmt.*
         FROM ics_sw_cnst_prmt
         WHERE ics_sw_cnst_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'SWConstructionPermitSubmission');

  -- /ICS_SW_CNST_PRMT/ICS_ADDR
  INSERT INTO ics_flow_icis..ics_addr
       SELECT ics_addr.*
         FROM ics_addr
            JOIN ics_sw_cnst_prmt
              ON ics_addr.ics_sw_cnst_prmt_id = ics_sw_cnst_prmt.ics_sw_cnst_prmt_id
         WHERE ics_sw_cnst_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'SWConstructionPermitSubmission');

  -- /ICS_SW_CNST_PRMT/ICS_ADDR/ICS_TELEPH
  INSERT INTO ics_flow_icis..ics_teleph
       SELECT ics_teleph.*
         FROM ics_teleph
            JOIN ics_addr
              ON ics_teleph.ics_addr_id = ics_addr.ics_addr_id
            JOIN ics_sw_cnst_prmt
              ON ics_addr.ics_sw_cnst_prmt_id = ics_sw_cnst_prmt.ics_sw_cnst_prmt_id
         WHERE ics_sw_cnst_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'SWConstructionPermitSubmission');

  -- /ICS_SW_CNST_PRMT/ICS_CONTACT
  INSERT INTO ics_flow_icis..ics_contact
       SELECT ics_contact.*
         FROM ics_contact
            JOIN ics_sw_cnst_prmt
              ON ics_contact.ics_sw_cnst_prmt_id = ics_sw_cnst_prmt.ics_sw_cnst_prmt_id
         WHERE ics_sw_cnst_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'SWConstructionPermitSubmission');

  -- /ICS_SW_CNST_PRMT/ICS_CONTACT/ICS_TELEPH
  INSERT INTO ics_flow_icis..ics_teleph
       SELECT ics_teleph.*
         FROM ics_teleph
            JOIN ics_contact
              ON ics_teleph.ics_contact_id = ics_contact.ics_contact_id
            JOIN ics_sw_cnst_prmt
              ON ics_contact.ics_sw_cnst_prmt_id = ics_sw_cnst_prmt.ics_sw_cnst_prmt_id
         WHERE ics_sw_cnst_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'SWConstructionPermitSubmission');

  -- /ICS_SW_CNST_PRMT/ICS_GPCF_NOTICE_OF_INTENT
  INSERT INTO ics_flow_icis..ics_gpcf_notice_of_intent
       SELECT ics_gpcf_notice_of_intent.*
         FROM ics_gpcf_notice_of_intent
            JOIN ics_sw_cnst_prmt
              ON ics_gpcf_notice_of_intent.ics_sw_cnst_prmt_id = ics_sw_cnst_prmt.ics_sw_cnst_prmt_id
         WHERE ics_sw_cnst_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'SWConstructionPermitSubmission');

  -- /ICS_SW_CNST_PRMT/ICS_GPCF_NOTICE_OF_TERM
  INSERT INTO ics_flow_icis..ics_gpcf_notice_of_term
       SELECT ics_gpcf_notice_of_term.*
         FROM ics_gpcf_notice_of_term
            JOIN ics_sw_cnst_prmt
              ON ics_gpcf_notice_of_term.ics_sw_cnst_prmt_id = ics_sw_cnst_prmt.ics_sw_cnst_prmt_id
         WHERE ics_sw_cnst_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'SWConstructionPermitSubmission');


  -- Remove any old records for ics_sw_indst_prmt
  -- /ICS_SW_INDST_PRMT/ICS_ADDR/ICS_TELEPH
  DELETE
    FROM ics_flow_icis..ics_teleph
   WHERE ics_addr_id IN
            (SELECT ics_addr.ics_addr_id
               FROM ics_sw_indst_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_sw_indst_prmt.key_hash 
                    JOIN ics_addr ON ics_addr.ics_sw_indst_prmt_id = ics_sw_indst_prmt.ics_sw_indst_prmt_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWIndustrialPermitSubmission');

  -- /ICS_SW_INDST_PRMT/ICS_CONTACT/ICS_TELEPH
  DELETE
    FROM ics_flow_icis..ics_teleph
   WHERE ics_contact_id IN
            (SELECT ics_contact.ics_contact_id
               FROM ics_sw_indst_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_sw_indst_prmt.key_hash 
                    JOIN ics_contact ON ics_contact.ics_sw_indst_prmt_id = ics_sw_indst_prmt.ics_sw_indst_prmt_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWIndustrialPermitSubmission');

  -- /ICS_SW_INDST_PRMT/ICS_ADDR
  DELETE
    FROM ics_flow_icis..ics_addr
   WHERE ics_sw_indst_prmt_id IN
            (SELECT ics_sw_indst_prmt.ics_sw_indst_prmt_id
               FROM ics_sw_indst_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_sw_indst_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWIndustrialPermitSubmission');

  -- /ICS_SW_INDST_PRMT/ICS_CONTACT
  DELETE
    FROM ics_flow_icis..ics_contact
   WHERE ics_sw_indst_prmt_id IN
            (SELECT ics_sw_indst_prmt.ics_sw_indst_prmt_id
               FROM ics_sw_indst_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_sw_indst_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWIndustrialPermitSubmission');

  -- /ICS_SW_INDST_PRMT/ICS_GPCF_NO_EXPOSURE
  DELETE
    FROM ics_flow_icis..ics_gpcf_no_exposure
   WHERE ics_sw_indst_prmt_id IN
            (SELECT ics_sw_indst_prmt.ics_sw_indst_prmt_id
               FROM ics_sw_indst_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_sw_indst_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWIndustrialPermitSubmission');

  -- /ICS_SW_INDST_PRMT/ICS_GPCF_NOTICE_OF_INTENT
  DELETE
    FROM ics_flow_icis..ics_gpcf_notice_of_intent
   WHERE ics_sw_indst_prmt_id IN
            (SELECT ics_sw_indst_prmt.ics_sw_indst_prmt_id
               FROM ics_sw_indst_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_sw_indst_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWIndustrialPermitSubmission');

  -- /ICS_SW_INDST_PRMT/ICS_GPCF_NOTICE_OF_TERM
  DELETE
    FROM ics_flow_icis..ics_gpcf_notice_of_term
   WHERE ics_sw_indst_prmt_id IN
            (SELECT ics_sw_indst_prmt.ics_sw_indst_prmt_id
               FROM ics_sw_indst_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_sw_indst_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWIndustrialPermitSubmission');

  -- /ICS_SW_INDST_PRMT
  DELETE
    FROM ics_flow_icis..ics_sw_indst_prmt
   WHERE ics_sw_indst_prmt_id IN
            (SELECT ics_sw_indst_prmt.ics_sw_indst_prmt_id
               FROM ics_sw_indst_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_sw_indst_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWIndustrialPermitSubmission');


  -- Add accepted records for ics_sw_indst_prmt
  -- /ICS_SW_INDST_PRMT
  INSERT INTO ics_flow_icis..ics_sw_indst_prmt
       SELECT ics_sw_indst_prmt.*
         FROM ics_sw_indst_prmt
         WHERE ics_sw_indst_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'SWIndustrialPermitSubmission');

  -- /ICS_SW_INDST_PRMT/ICS_ADDR
  INSERT INTO ics_flow_icis..ics_addr
       SELECT ics_addr.*
         FROM ics_addr
            JOIN ics_sw_indst_prmt
              ON ics_addr.ics_sw_indst_prmt_id = ics_sw_indst_prmt.ics_sw_indst_prmt_id
         WHERE ics_sw_indst_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'SWIndustrialPermitSubmission');

  -- /ICS_SW_INDST_PRMT/ICS_ADDR/ICS_TELEPH
  INSERT INTO ics_flow_icis..ics_teleph
       SELECT ics_teleph.*
         FROM ics_teleph
            JOIN ics_addr
              ON ics_teleph.ics_addr_id = ics_addr.ics_addr_id
            JOIN ics_sw_indst_prmt
              ON ics_addr.ics_sw_indst_prmt_id = ics_sw_indst_prmt.ics_sw_indst_prmt_id
         WHERE ics_sw_indst_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'SWIndustrialPermitSubmission');

  -- /ICS_SW_INDST_PRMT/ICS_CONTACT
  INSERT INTO ics_flow_icis..ics_contact
       SELECT ics_contact.*
         FROM ics_contact
            JOIN ics_sw_indst_prmt
              ON ics_contact.ics_sw_indst_prmt_id = ics_sw_indst_prmt.ics_sw_indst_prmt_id
         WHERE ics_sw_indst_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'SWIndustrialPermitSubmission');

  -- /ICS_SW_INDST_PRMT/ICS_CONTACT/ICS_TELEPH
  INSERT INTO ics_flow_icis..ics_teleph
       SELECT ics_teleph.*
         FROM ics_teleph
            JOIN ics_contact
              ON ics_teleph.ics_contact_id = ics_contact.ics_contact_id
            JOIN ics_sw_indst_prmt
              ON ics_contact.ics_sw_indst_prmt_id = ics_sw_indst_prmt.ics_sw_indst_prmt_id
         WHERE ics_sw_indst_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'SWIndustrialPermitSubmission');

  -- /ICS_SW_INDST_PRMT/ICS_GPCF_NO_EXPOSURE
  INSERT INTO ics_flow_icis..ics_gpcf_no_exposure
       SELECT ics_gpcf_no_exposure.*
         FROM ics_gpcf_no_exposure
            JOIN ics_sw_indst_prmt
              ON ics_gpcf_no_exposure.ics_sw_indst_prmt_id = ics_sw_indst_prmt.ics_sw_indst_prmt_id
         WHERE ics_sw_indst_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'SWIndustrialPermitSubmission');

  -- /ICS_SW_INDST_PRMT/ICS_GPCF_NOTICE_OF_INTENT
  INSERT INTO ics_flow_icis..ics_gpcf_notice_of_intent
       SELECT ics_gpcf_notice_of_intent.*
         FROM ics_gpcf_notice_of_intent
            JOIN ics_sw_indst_prmt
              ON ics_gpcf_notice_of_intent.ics_sw_indst_prmt_id = ics_sw_indst_prmt.ics_sw_indst_prmt_id
         WHERE ics_sw_indst_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'SWIndustrialPermitSubmission');

  -- /ICS_SW_INDST_PRMT/ICS_GPCF_NOTICE_OF_TERM
  INSERT INTO ics_flow_icis..ics_gpcf_notice_of_term
       SELECT ics_gpcf_notice_of_term.*
         FROM ics_gpcf_notice_of_term
            JOIN ics_sw_indst_prmt
              ON ics_gpcf_notice_of_term.ics_sw_indst_prmt_id = ics_sw_indst_prmt.ics_sw_indst_prmt_id
         WHERE ics_sw_indst_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'SWIndustrialPermitSubmission');


  -- Remove any old records for ics_swms_4_large_prmt
  -- /ICS_SWMS_4_LARGE_PRMT/ICS_ADDR/ICS_TELEPH
  DELETE
    FROM ics_flow_icis..ics_teleph
   WHERE ics_addr_id IN
            (SELECT ics_addr.ics_addr_id
               FROM ics_swms_4_large_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_swms_4_large_prmt.key_hash 
                    JOIN ics_addr ON ics_addr.ics_swms_4_large_prmt_id = ics_swms_4_large_prmt.ics_swms_4_large_prmt_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4LargePermitSubmission');

  -- /ICS_SWMS_4_LARGE_PRMT/ICS_CONTACT/ICS_TELEPH
  DELETE
    FROM ics_flow_icis..ics_teleph
   WHERE ics_contact_id IN
            (SELECT ics_contact.ics_contact_id
               FROM ics_swms_4_large_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_swms_4_large_prmt.key_hash 
                    JOIN ics_contact ON ics_contact.ics_swms_4_large_prmt_id = ics_swms_4_large_prmt.ics_swms_4_large_prmt_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4LargePermitSubmission');

  -- /ICS_SWMS_4_LARGE_PRMT/ICS_ADDR
  DELETE
    FROM ics_flow_icis..ics_addr
   WHERE ics_swms_4_large_prmt_id IN
            (SELECT ics_swms_4_large_prmt.ics_swms_4_large_prmt_id
               FROM ics_swms_4_large_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_swms_4_large_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4LargePermitSubmission');

  -- /ICS_SWMS_4_LARGE_PRMT/ICS_CONTACT
  DELETE
    FROM ics_flow_icis..ics_contact
   WHERE ics_swms_4_large_prmt_id IN
            (SELECT ics_swms_4_large_prmt.ics_swms_4_large_prmt_id
               FROM ics_swms_4_large_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_swms_4_large_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4LargePermitSubmission');

  -- /ICS_SWMS_4_LARGE_PRMT
  DELETE
    FROM ics_flow_icis..ics_swms_4_large_prmt
   WHERE ics_swms_4_large_prmt_id IN
            (SELECT ics_swms_4_large_prmt.ics_swms_4_large_prmt_id
               FROM ics_swms_4_large_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_swms_4_large_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4LargePermitSubmission');


  -- Add accepted records for ics_swms_4_large_prmt
  -- /ICS_SWMS_4_LARGE_PRMT
  INSERT INTO ics_flow_icis..ics_swms_4_large_prmt
       SELECT ics_swms_4_large_prmt.*
         FROM ics_swms_4_large_prmt
         WHERE ics_swms_4_large_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'SWMS4LargePermitSubmission');

  -- /ICS_SWMS_4_LARGE_PRMT/ICS_ADDR
  INSERT INTO ics_flow_icis..ics_addr
       SELECT ics_addr.*
         FROM ics_addr
            JOIN ics_swms_4_large_prmt
              ON ics_addr.ics_swms_4_large_prmt_id = ics_swms_4_large_prmt.ics_swms_4_large_prmt_id
         WHERE ics_swms_4_large_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'SWMS4LargePermitSubmission');

  -- /ICS_SWMS_4_LARGE_PRMT/ICS_ADDR/ICS_TELEPH
  INSERT INTO ics_flow_icis..ics_teleph
       SELECT ics_teleph.*
         FROM ics_teleph
            JOIN ics_addr
              ON ics_teleph.ics_addr_id = ics_addr.ics_addr_id
            JOIN ics_swms_4_large_prmt
              ON ics_addr.ics_swms_4_large_prmt_id = ics_swms_4_large_prmt.ics_swms_4_large_prmt_id
         WHERE ics_swms_4_large_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'SWMS4LargePermitSubmission');

  -- /ICS_SWMS_4_LARGE_PRMT/ICS_CONTACT
  INSERT INTO ics_flow_icis..ics_contact
       SELECT ics_contact.*
         FROM ics_contact
            JOIN ics_swms_4_large_prmt
              ON ics_contact.ics_swms_4_large_prmt_id = ics_swms_4_large_prmt.ics_swms_4_large_prmt_id
         WHERE ics_swms_4_large_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'SWMS4LargePermitSubmission');

  -- /ICS_SWMS_4_LARGE_PRMT/ICS_CONTACT/ICS_TELEPH
  INSERT INTO ics_flow_icis..ics_teleph
       SELECT ics_teleph.*
         FROM ics_teleph
            JOIN ics_contact
              ON ics_teleph.ics_contact_id = ics_contact.ics_contact_id
            JOIN ics_swms_4_large_prmt
              ON ics_contact.ics_swms_4_large_prmt_id = ics_swms_4_large_prmt.ics_swms_4_large_prmt_id
         WHERE ics_swms_4_large_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'SWMS4LargePermitSubmission');


  -- Remove any old records for ics_swms_4_small_prmt
  -- /ICS_SWMS_4_SMALL_PRMT/ICS_ADDR/ICS_TELEPH
  DELETE
    FROM ics_flow_icis..ics_teleph
   WHERE ics_addr_id IN
            (SELECT ics_addr.ics_addr_id
               FROM ics_swms_4_small_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_swms_4_small_prmt.key_hash 
                    JOIN ics_addr ON ics_addr.ics_swms_4_small_prmt_id = ics_swms_4_small_prmt.ics_swms_4_small_prmt_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4SmallPermitSubmission');

  -- /ICS_SWMS_4_SMALL_PRMT/ICS_CONTACT/ICS_TELEPH
  DELETE
    FROM ics_flow_icis..ics_teleph
   WHERE ics_contact_id IN
            (SELECT ics_contact.ics_contact_id
               FROM ics_swms_4_small_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_swms_4_small_prmt.key_hash 
                    JOIN ics_contact ON ics_contact.ics_swms_4_small_prmt_id = ics_swms_4_small_prmt.ics_swms_4_small_prmt_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4SmallPermitSubmission');

  -- /ICS_SWMS_4_SMALL_PRMT/ICS_ADDR
  DELETE
    FROM ics_flow_icis..ics_addr
   WHERE ics_swms_4_small_prmt_id IN
            (SELECT ics_swms_4_small_prmt.ics_swms_4_small_prmt_id
               FROM ics_swms_4_small_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_swms_4_small_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4SmallPermitSubmission');

  -- /ICS_SWMS_4_SMALL_PRMT/ICS_CONTACT
  DELETE
    FROM ics_flow_icis..ics_contact
   WHERE ics_swms_4_small_prmt_id IN
            (SELECT ics_swms_4_small_prmt.ics_swms_4_small_prmt_id
               FROM ics_swms_4_small_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_swms_4_small_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4SmallPermitSubmission');

  -- /ICS_SWMS_4_SMALL_PRMT/ICS_GPCF_CNST_WAIVER
  DELETE
    FROM ics_flow_icis..ics_gpcf_cnst_waiver
   WHERE ics_swms_4_small_prmt_id IN
            (SELECT ics_swms_4_small_prmt.ics_swms_4_small_prmt_id
               FROM ics_swms_4_small_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_swms_4_small_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4SmallPermitSubmission');

  -- /ICS_SWMS_4_SMALL_PRMT
  DELETE
    FROM ics_flow_icis..ics_swms_4_small_prmt
   WHERE ics_swms_4_small_prmt_id IN
            (SELECT ics_swms_4_small_prmt.ics_swms_4_small_prmt_id
               FROM ics_swms_4_small_prmt
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_swms_4_small_prmt.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4SmallPermitSubmission');


  -- Add accepted records for ics_swms_4_small_prmt
  -- /ICS_SWMS_4_SMALL_PRMT
  INSERT INTO ics_flow_icis..ics_swms_4_small_prmt
       SELECT ics_swms_4_small_prmt.*
         FROM ics_swms_4_small_prmt
         WHERE ics_swms_4_small_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'SWMS4SmallPermitSubmission');

  -- /ICS_SWMS_4_SMALL_PRMT/ICS_ADDR
  INSERT INTO ics_flow_icis..ics_addr
       SELECT ics_addr.*
         FROM ics_addr
            JOIN ics_swms_4_small_prmt
              ON ics_addr.ics_swms_4_small_prmt_id = ics_swms_4_small_prmt.ics_swms_4_small_prmt_id
         WHERE ics_swms_4_small_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'SWMS4SmallPermitSubmission');

  -- /ICS_SWMS_4_SMALL_PRMT/ICS_ADDR/ICS_TELEPH
  INSERT INTO ics_flow_icis..ics_teleph
       SELECT ics_teleph.*
         FROM ics_teleph
            JOIN ics_addr
              ON ics_teleph.ics_addr_id = ics_addr.ics_addr_id
            JOIN ics_swms_4_small_prmt
              ON ics_addr.ics_swms_4_small_prmt_id = ics_swms_4_small_prmt.ics_swms_4_small_prmt_id
         WHERE ics_swms_4_small_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'SWMS4SmallPermitSubmission');

  -- /ICS_SWMS_4_SMALL_PRMT/ICS_CONTACT
  INSERT INTO ics_flow_icis..ics_contact
       SELECT ics_contact.*
         FROM ics_contact
            JOIN ics_swms_4_small_prmt
              ON ics_contact.ics_swms_4_small_prmt_id = ics_swms_4_small_prmt.ics_swms_4_small_prmt_id
         WHERE ics_swms_4_small_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'SWMS4SmallPermitSubmission');

  -- /ICS_SWMS_4_SMALL_PRMT/ICS_CONTACT/ICS_TELEPH
  INSERT INTO ics_flow_icis..ics_teleph
       SELECT ics_teleph.*
         FROM ics_teleph
            JOIN ics_contact
              ON ics_teleph.ics_contact_id = ics_contact.ics_contact_id
            JOIN ics_swms_4_small_prmt
              ON ics_contact.ics_swms_4_small_prmt_id = ics_swms_4_small_prmt.ics_swms_4_small_prmt_id
         WHERE ics_swms_4_small_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'SWMS4SmallPermitSubmission');

  -- /ICS_SWMS_4_SMALL_PRMT/ICS_GPCF_CNST_WAIVER
  INSERT INTO ics_flow_icis..ics_gpcf_cnst_waiver
       SELECT ics_gpcf_cnst_waiver.*
         FROM ics_gpcf_cnst_waiver
            JOIN ics_swms_4_small_prmt
              ON ics_gpcf_cnst_waiver.ics_swms_4_small_prmt_id = ics_swms_4_small_prmt.ics_swms_4_small_prmt_id
         WHERE ics_swms_4_small_prmt.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'SWMS4SmallPermitSubmission');


  -- Remove any old records for ics_unprmt_fac
  -- /ICS_UNPRMT_FAC/ICS_ADDR/ICS_TELEPH
  DELETE
    FROM ics_flow_icis..ics_teleph
   WHERE ics_addr_id IN
            (SELECT ics_addr.ics_addr_id
               FROM ics_unprmt_fac
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_unprmt_fac.key_hash 
                    JOIN ics_addr ON ics_addr.ics_unprmt_fac_id = ics_unprmt_fac.ics_unprmt_fac_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'UnpermittedFacilitySubmission');

  -- /ICS_UNPRMT_FAC/ICS_CONTACT/ICS_TELEPH
  DELETE
    FROM ics_flow_icis..ics_teleph
   WHERE ics_contact_id IN
            (SELECT ics_contact.ics_contact_id
               FROM ics_unprmt_fac
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_unprmt_fac.key_hash 
                    JOIN ics_contact ON ics_contact.ics_unprmt_fac_id = ics_unprmt_fac.ics_unprmt_fac_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'UnpermittedFacilitySubmission');

  -- /ICS_UNPRMT_FAC/ICS_ADDR
  DELETE
    FROM ics_flow_icis..ics_addr
   WHERE ics_unprmt_fac_id IN
            (SELECT ics_unprmt_fac.ics_unprmt_fac_id
               FROM ics_unprmt_fac
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_unprmt_fac.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'UnpermittedFacilitySubmission');

  -- /ICS_UNPRMT_FAC/ICS_CONTACT
  DELETE
    FROM ics_flow_icis..ics_contact
   WHERE ics_unprmt_fac_id IN
            (SELECT ics_unprmt_fac.ics_unprmt_fac_id
               FROM ics_unprmt_fac
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_unprmt_fac.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'UnpermittedFacilitySubmission');

  -- /ICS_UNPRMT_FAC/ICS_FAC_CLASS
  DELETE
    FROM ics_flow_icis..ics_fac_class
   WHERE ics_unprmt_fac_id IN
            (SELECT ics_unprmt_fac.ics_unprmt_fac_id
               FROM ics_unprmt_fac
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_unprmt_fac.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'UnpermittedFacilitySubmission');

  -- /ICS_UNPRMT_FAC/ICS_GEO_COORD
  DELETE
    FROM ics_flow_icis..ics_geo_coord
   WHERE ics_unprmt_fac_id IN
            (SELECT ics_unprmt_fac.ics_unprmt_fac_id
               FROM ics_unprmt_fac
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_unprmt_fac.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'UnpermittedFacilitySubmission');

  -- /ICS_UNPRMT_FAC/ICS_NAICS_CODE
  DELETE
    FROM ics_flow_icis..ics_naics_code
   WHERE ics_unprmt_fac_id IN
            (SELECT ics_unprmt_fac.ics_unprmt_fac_id
               FROM ics_unprmt_fac
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_unprmt_fac.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'UnpermittedFacilitySubmission');

  -- /ICS_UNPRMT_FAC/ICS_ORIG_PROGS
  DELETE
    FROM ics_flow_icis..ics_orig_progs
   WHERE ics_unprmt_fac_id IN
            (SELECT ics_unprmt_fac.ics_unprmt_fac_id
               FROM ics_unprmt_fac
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_unprmt_fac.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'UnpermittedFacilitySubmission');

  -- /ICS_UNPRMT_FAC/ICS_PLCY
  DELETE
    FROM ics_flow_icis..ics_plcy
   WHERE ics_unprmt_fac_id IN
            (SELECT ics_unprmt_fac.ics_unprmt_fac_id
               FROM ics_unprmt_fac
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_unprmt_fac.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'UnpermittedFacilitySubmission');

  -- /ICS_UNPRMT_FAC/ICS_SIC_CODE
  DELETE
    FROM ics_flow_icis..ics_sic_code
   WHERE ics_unprmt_fac_id IN
            (SELECT ics_unprmt_fac.ics_unprmt_fac_id
               FROM ics_unprmt_fac
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_unprmt_fac.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'UnpermittedFacilitySubmission');

  -- /ICS_UNPRMT_FAC
  DELETE
    FROM ics_flow_icis..ics_unprmt_fac
   WHERE ics_unprmt_fac_id IN
            (SELECT ics_unprmt_fac.ics_unprmt_fac_id
               FROM ics_unprmt_fac
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_unprmt_fac.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'UnpermittedFacilitySubmission');


  -- Add accepted records for ics_unprmt_fac
  -- /ICS_UNPRMT_FAC
  INSERT INTO ics_flow_icis..ics_unprmt_fac
       SELECT ics_unprmt_fac.*
         FROM ics_unprmt_fac
         WHERE ics_unprmt_fac.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'UnpermittedFacilitySubmission');

  -- /ICS_UNPRMT_FAC/ICS_ADDR
  INSERT INTO ics_flow_icis..ics_addr
       SELECT ics_addr.*
         FROM ics_addr
            JOIN ics_unprmt_fac
              ON ics_addr.ics_unprmt_fac_id = ics_unprmt_fac.ics_unprmt_fac_id
         WHERE ics_unprmt_fac.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'UnpermittedFacilitySubmission');

  -- /ICS_UNPRMT_FAC/ICS_ADDR/ICS_TELEPH
  INSERT INTO ics_flow_icis..ics_teleph
       SELECT ics_teleph.*
         FROM ics_teleph
            JOIN ics_addr
              ON ics_teleph.ics_addr_id = ics_addr.ics_addr_id
            JOIN ics_unprmt_fac
              ON ics_addr.ics_unprmt_fac_id = ics_unprmt_fac.ics_unprmt_fac_id
         WHERE ics_unprmt_fac.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'UnpermittedFacilitySubmission');

  -- /ICS_UNPRMT_FAC/ICS_CONTACT
  INSERT INTO ics_flow_icis..ics_contact
       SELECT ics_contact.*
         FROM ics_contact
            JOIN ics_unprmt_fac
              ON ics_contact.ics_unprmt_fac_id = ics_unprmt_fac.ics_unprmt_fac_id
         WHERE ics_unprmt_fac.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'UnpermittedFacilitySubmission');

  -- /ICS_UNPRMT_FAC/ICS_CONTACT/ICS_TELEPH
  INSERT INTO ics_flow_icis..ics_teleph
       SELECT ics_teleph.*
         FROM ics_teleph
            JOIN ics_contact
              ON ics_teleph.ics_contact_id = ics_contact.ics_contact_id
            JOIN ics_unprmt_fac
              ON ics_contact.ics_unprmt_fac_id = ics_unprmt_fac.ics_unprmt_fac_id
         WHERE ics_unprmt_fac.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'UnpermittedFacilitySubmission');

  -- /ICS_UNPRMT_FAC/ICS_FAC_CLASS
  INSERT INTO ics_flow_icis..ics_fac_class
       SELECT ics_fac_class.*
         FROM ics_fac_class
            JOIN ics_unprmt_fac
              ON ics_fac_class.ics_unprmt_fac_id = ics_unprmt_fac.ics_unprmt_fac_id
         WHERE ics_unprmt_fac.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'UnpermittedFacilitySubmission');

  -- /ICS_UNPRMT_FAC/ICS_GEO_COORD
  INSERT INTO ics_flow_icis..ics_geo_coord
       SELECT ics_geo_coord.*
         FROM ics_geo_coord
            JOIN ics_unprmt_fac
              ON ics_geo_coord.ics_unprmt_fac_id = ics_unprmt_fac.ics_unprmt_fac_id
         WHERE ics_unprmt_fac.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'UnpermittedFacilitySubmission');

  -- /ICS_UNPRMT_FAC/ICS_NAICS_CODE
  INSERT INTO ics_flow_icis..ics_naics_code
       SELECT ics_naics_code.*
         FROM ics_naics_code
            JOIN ics_unprmt_fac
              ON ics_naics_code.ics_unprmt_fac_id = ics_unprmt_fac.ics_unprmt_fac_id
         WHERE ics_unprmt_fac.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'UnpermittedFacilitySubmission');

  -- /ICS_UNPRMT_FAC/ICS_ORIG_PROGS
  INSERT INTO ics_flow_icis..ics_orig_progs
       SELECT ics_orig_progs.*
         FROM ics_orig_progs
            JOIN ics_unprmt_fac
              ON ics_orig_progs.ics_unprmt_fac_id = ics_unprmt_fac.ics_unprmt_fac_id
         WHERE ics_unprmt_fac.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'UnpermittedFacilitySubmission');

  -- /ICS_UNPRMT_FAC/ICS_PLCY
  INSERT INTO ics_flow_icis..ics_plcy
       SELECT ics_plcy.*
         FROM ics_plcy
            JOIN ics_unprmt_fac
              ON ics_plcy.ics_unprmt_fac_id = ics_unprmt_fac.ics_unprmt_fac_id
         WHERE ics_unprmt_fac.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'UnpermittedFacilitySubmission');

  -- /ICS_UNPRMT_FAC/ICS_SIC_CODE
  INSERT INTO ics_flow_icis..ics_sic_code
       SELECT ics_sic_code.*
         FROM ics_sic_code
            JOIN ics_unprmt_fac
              ON ics_sic_code.ics_unprmt_fac_id = ics_unprmt_fac.ics_unprmt_fac_id
         WHERE ics_unprmt_fac.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'UnpermittedFacilitySubmission');


  -- Remove any old records for ics_hist_prmt_schd_evts
  -- /ICS_HIST_PRMT_SCHD_EVTS
  DELETE
    FROM ics_flow_icis..ics_hist_prmt_schd_evts
   WHERE ics_hist_prmt_schd_evts_id IN
            (SELECT ics_hist_prmt_schd_evts.ics_hist_prmt_schd_evts_id
               FROM ics_hist_prmt_schd_evts
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_hist_prmt_schd_evts.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'HistoricalPermitScheduleEventsSubmission');


  -- Add accepted records for ics_hist_prmt_schd_evts
  -- /ICS_HIST_PRMT_SCHD_EVTS
  INSERT INTO ics_flow_icis..ics_hist_prmt_schd_evts
       SELECT ics_hist_prmt_schd_evts.*
         FROM ics_hist_prmt_schd_evts
         WHERE ics_hist_prmt_schd_evts.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'HistoricalPermitScheduleEventsSubmission');


  -- Remove any old records for ics_narr_cond_schd
  -- /ICS_NARR_COND_SCHD/ICS_PRMT_SCHD_EVT
  DELETE
    FROM ics_flow_icis..ics_prmt_schd_evt
   WHERE ics_narr_cond_schd_id IN
            (SELECT ics_narr_cond_schd.ics_narr_cond_schd_id
               FROM ics_narr_cond_schd
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_narr_cond_schd.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'NarrativeConditionScheduleSubmission');

  -- /ICS_NARR_COND_SCHD
  DELETE
    FROM ics_flow_icis..ics_narr_cond_schd
   WHERE ics_narr_cond_schd_id IN
            (SELECT ics_narr_cond_schd.ics_narr_cond_schd_id
               FROM ics_narr_cond_schd
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_narr_cond_schd.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'NarrativeConditionScheduleSubmission');


  -- Add accepted records for ics_narr_cond_schd
  -- /ICS_NARR_COND_SCHD
  INSERT INTO ics_flow_icis..ics_narr_cond_schd
       SELECT ics_narr_cond_schd.*
         FROM ics_narr_cond_schd
         WHERE ics_narr_cond_schd.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'NarrativeConditionScheduleSubmission');

  -- /ICS_NARR_COND_SCHD/ICS_PRMT_SCHD_EVT
  INSERT INTO ics_flow_icis..ics_prmt_schd_evt
       SELECT ics_prmt_schd_evt.*
         FROM ics_prmt_schd_evt
            JOIN ics_narr_cond_schd
              ON ics_prmt_schd_evt.ics_narr_cond_schd_id = ics_narr_cond_schd.ics_narr_cond_schd_id
         WHERE ics_narr_cond_schd.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'NarrativeConditionScheduleSubmission');


  -- Remove any old records for ics_prmt_featr
  -- /ICS_PRMT_FEATR/ICS_ADDR/ICS_TELEPH
  DELETE
    FROM ics_flow_icis..ics_teleph
   WHERE ics_addr_id IN
            (SELECT ics_addr.ics_addr_id
               FROM ics_prmt_featr
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_prmt_featr.key_hash 
                    JOIN ics_addr ON ics_addr.ics_prmt_featr_id = ics_prmt_featr.ics_prmt_featr_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PermittedFeatureSubmission');

  -- /ICS_PRMT_FEATR/ICS_CONTACT/ICS_TELEPH
  DELETE
    FROM ics_flow_icis..ics_teleph
   WHERE ics_contact_id IN
            (SELECT ics_contact.ics_contact_id
               FROM ics_prmt_featr
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_prmt_featr.key_hash 
                    JOIN ics_contact ON ics_contact.ics_prmt_featr_id = ics_prmt_featr.ics_prmt_featr_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PermittedFeatureSubmission');

  -- /ICS_PRMT_FEATR/ICS_ADDR
  DELETE
    FROM ics_flow_icis..ics_addr
   WHERE ics_prmt_featr_id IN
            (SELECT ics_prmt_featr.ics_prmt_featr_id
               FROM ics_prmt_featr
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_prmt_featr.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PermittedFeatureSubmission');

  -- /ICS_PRMT_FEATR/ICS_CONTACT
  DELETE
    FROM ics_flow_icis..ics_contact
   WHERE ics_prmt_featr_id IN
            (SELECT ics_prmt_featr.ics_prmt_featr_id
               FROM ics_prmt_featr
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_prmt_featr.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PermittedFeatureSubmission');

  -- /ICS_PRMT_FEATR/ICS_GEO_COORD
  DELETE
    FROM ics_flow_icis..ics_geo_coord
   WHERE ics_prmt_featr_id IN
            (SELECT ics_prmt_featr.ics_prmt_featr_id
               FROM ics_prmt_featr
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_prmt_featr.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PermittedFeatureSubmission');

  -- /ICS_PRMT_FEATR/ICS_PRMT_FEATR_CHAR
  DELETE
    FROM ics_flow_icis..ics_prmt_featr_char
   WHERE ics_prmt_featr_id IN
            (SELECT ics_prmt_featr.ics_prmt_featr_id
               FROM ics_prmt_featr
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_prmt_featr.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PermittedFeatureSubmission');

  -- /ICS_PRMT_FEATR/ICS_PRMT_FEATR_TRTMNT_TYPE
  DELETE
    FROM ics_flow_icis..ics_prmt_featr_trtmnt_type
   WHERE ics_prmt_featr_id IN
            (SELECT ics_prmt_featr.ics_prmt_featr_id
               FROM ics_prmt_featr
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_prmt_featr.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PermittedFeatureSubmission');

  -- /ICS_PRMT_FEATR
  DELETE
    FROM ics_flow_icis..ics_prmt_featr
   WHERE ics_prmt_featr_id IN
            (SELECT ics_prmt_featr.ics_prmt_featr_id
               FROM ics_prmt_featr
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_prmt_featr.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PermittedFeatureSubmission');


  -- Add accepted records for ics_prmt_featr
  -- /ICS_PRMT_FEATR
  INSERT INTO ics_flow_icis..ics_prmt_featr
       SELECT ics_prmt_featr.*
         FROM ics_prmt_featr
         WHERE ics_prmt_featr.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'PermittedFeatureSubmission');

  -- /ICS_PRMT_FEATR/ICS_ADDR
  INSERT INTO ics_flow_icis..ics_addr
       SELECT ics_addr.*
         FROM ics_addr
            JOIN ics_prmt_featr
              ON ics_addr.ics_prmt_featr_id = ics_prmt_featr.ics_prmt_featr_id
         WHERE ics_prmt_featr.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'PermittedFeatureSubmission');

  -- /ICS_PRMT_FEATR/ICS_ADDR/ICS_TELEPH
  INSERT INTO ics_flow_icis..ics_teleph
       SELECT ics_teleph.*
         FROM ics_teleph
            JOIN ics_addr
              ON ics_teleph.ics_addr_id = ics_addr.ics_addr_id
            JOIN ics_prmt_featr
              ON ics_addr.ics_prmt_featr_id = ics_prmt_featr.ics_prmt_featr_id
         WHERE ics_prmt_featr.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'PermittedFeatureSubmission');

  -- /ICS_PRMT_FEATR/ICS_CONTACT
  INSERT INTO ics_flow_icis..ics_contact
       SELECT ics_contact.*
         FROM ics_contact
            JOIN ics_prmt_featr
              ON ics_contact.ics_prmt_featr_id = ics_prmt_featr.ics_prmt_featr_id
         WHERE ics_prmt_featr.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'PermittedFeatureSubmission');

  -- /ICS_PRMT_FEATR/ICS_CONTACT/ICS_TELEPH
  INSERT INTO ics_flow_icis..ics_teleph
       SELECT ics_teleph.*
         FROM ics_teleph
            JOIN ics_contact
              ON ics_teleph.ics_contact_id = ics_contact.ics_contact_id
            JOIN ics_prmt_featr
              ON ics_contact.ics_prmt_featr_id = ics_prmt_featr.ics_prmt_featr_id
         WHERE ics_prmt_featr.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'PermittedFeatureSubmission');

  -- /ICS_PRMT_FEATR/ICS_GEO_COORD
  INSERT INTO ics_flow_icis..ics_geo_coord
       SELECT ics_geo_coord.*
         FROM ics_geo_coord
            JOIN ics_prmt_featr
              ON ics_geo_coord.ics_prmt_featr_id = ics_prmt_featr.ics_prmt_featr_id
         WHERE ics_prmt_featr.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'PermittedFeatureSubmission');

  -- /ICS_PRMT_FEATR/ICS_PRMT_FEATR_CHAR
  INSERT INTO ics_flow_icis..ics_prmt_featr_char
       SELECT ics_prmt_featr_char.*
         FROM ics_prmt_featr_char
            JOIN ics_prmt_featr
              ON ics_prmt_featr_char.ics_prmt_featr_id = ics_prmt_featr.ics_prmt_featr_id
         WHERE ics_prmt_featr.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'PermittedFeatureSubmission');

  -- /ICS_PRMT_FEATR/ICS_PRMT_FEATR_TRTMNT_TYPE
  INSERT INTO ics_flow_icis..ics_prmt_featr_trtmnt_type
       SELECT ics_prmt_featr_trtmnt_type.*
         FROM ics_prmt_featr_trtmnt_type
            JOIN ics_prmt_featr
              ON ics_prmt_featr_trtmnt_type.ics_prmt_featr_id = ics_prmt_featr.ics_prmt_featr_id
         WHERE ics_prmt_featr.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'PermittedFeatureSubmission');


  -- Remove any old records for ics_lmt_set
  -- /ICS_LMT_SET/ICS_LMT_SET_MONTHS_APPL
  DELETE
    FROM ics_flow_icis..ics_lmt_set_months_appl
   WHERE ics_lmt_set_id IN
            (SELECT ics_lmt_set.ics_lmt_set_id
               FROM ics_lmt_set
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_lmt_set.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'LimitSetSubmission');

  -- /ICS_LMT_SET/ICS_LMT_SET_SCHD
  DELETE
    FROM ics_flow_icis..ics_lmt_set_schd
   WHERE ics_lmt_set_id IN
            (SELECT ics_lmt_set.ics_lmt_set_id
               FROM ics_lmt_set
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_lmt_set.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'LimitSetSubmission');

  -- /ICS_LMT_SET/ICS_LMT_SET_STAT
  DELETE
    FROM ics_flow_icis..ics_lmt_set_stat
   WHERE ics_lmt_set_id IN
            (SELECT ics_lmt_set.ics_lmt_set_id
               FROM ics_lmt_set
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_lmt_set.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'LimitSetSubmission');

  -- /ICS_LMT_SET
  DELETE
    FROM ics_flow_icis..ics_lmt_set
   WHERE ics_lmt_set_id IN
            (SELECT ics_lmt_set.ics_lmt_set_id
               FROM ics_lmt_set
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_lmt_set.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'LimitSetSubmission');


  -- Add accepted records for ics_lmt_set
  -- /ICS_LMT_SET
  INSERT INTO ics_flow_icis..ics_lmt_set
       SELECT ics_lmt_set.*
         FROM ics_lmt_set
         WHERE ics_lmt_set.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'LimitSetSubmission');

  -- /ICS_LMT_SET/ICS_LMT_SET_MONTHS_APPL
  INSERT INTO ics_flow_icis..ics_lmt_set_months_appl
       SELECT ics_lmt_set_months_appl.*
         FROM ics_lmt_set_months_appl
            JOIN ics_lmt_set
              ON ics_lmt_set_months_appl.ics_lmt_set_id = ics_lmt_set.ics_lmt_set_id
         WHERE ics_lmt_set.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'LimitSetSubmission');

  -- /ICS_LMT_SET/ICS_LMT_SET_SCHD
  INSERT INTO ics_flow_icis..ics_lmt_set_schd
       SELECT ics_lmt_set_schd.*
         FROM ics_lmt_set_schd
            JOIN ics_lmt_set
              ON ics_lmt_set_schd.ics_lmt_set_id = ics_lmt_set.ics_lmt_set_id
         WHERE ics_lmt_set.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'LimitSetSubmission');

  -- /ICS_LMT_SET/ICS_LMT_SET_STAT
  INSERT INTO ics_flow_icis..ics_lmt_set_stat
       SELECT ics_lmt_set_stat.*
         FROM ics_lmt_set_stat
            JOIN ics_lmt_set
              ON ics_lmt_set_stat.ics_lmt_set_id = ics_lmt_set.ics_lmt_set_id
         WHERE ics_lmt_set.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'LimitSetSubmission');


  -- Remove any old records for ics_lmts
  -- /ICS_LMTS/ICS_MN_LMT_APPLIES
  DELETE
    FROM ics_flow_icis..ics_mn_lmt_applies
   WHERE ics_lmts_id IN
            (SELECT ics_lmts.ics_lmts_id
               FROM ics_lmts
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_lmts.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'LimitsSubmission');

  -- /ICS_LMTS/ICS_NUM_COND
  DELETE
    FROM ics_flow_icis..ics_num_cond
   WHERE ics_lmts_id IN
            (SELECT ics_lmts.ics_lmts_id
               FROM ics_lmts
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_lmts.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'LimitsSubmission');

  -- /ICS_LMTS
  DELETE
    FROM ics_flow_icis..ics_lmts
   WHERE ics_lmts_id IN
            (SELECT ics_lmts.ics_lmts_id
               FROM ics_lmts
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_lmts.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'LimitsSubmission');


  -- Add accepted records for ics_lmts
  -- /ICS_LMTS
  INSERT INTO ics_flow_icis..ics_lmts
       SELECT ics_lmts.*
         FROM ics_lmts
         WHERE ics_lmts.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'LimitsSubmission');

  -- /ICS_LMTS/ICS_MN_LMT_APPLIES
  INSERT INTO ics_flow_icis..ics_mn_lmt_applies
       SELECT ics_mn_lmt_applies.*
         FROM ics_mn_lmt_applies
            JOIN ics_lmts
              ON ics_mn_lmt_applies.ics_lmts_id = ics_lmts.ics_lmts_id
         WHERE ics_lmts.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'LimitsSubmission');

  -- /ICS_LMTS/ICS_NUM_COND
  INSERT INTO ics_flow_icis..ics_num_cond
       SELECT ics_num_cond.*
         FROM ics_num_cond
            JOIN ics_lmts
              ON ics_num_cond.ics_lmts_id = ics_lmts.ics_lmts_id
         WHERE ics_lmts.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'LimitsSubmission');


  -- Remove any old records for ics_param_lmts
  -- /ICS_PARAM_LMTS/ICS_LMT/ICS_MN_LMT_APPLIES
  DELETE
    FROM ics_flow_icis..ics_mn_lmt_applies
   WHERE ics_lmt_id IN
            (SELECT ics_lmt.ics_lmt_id
               FROM ics_param_lmts
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_param_lmts.key_hash 
                    JOIN ics_lmt ON ics_lmt.ics_param_lmts_id = ics_param_lmts.ics_param_lmts_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ParameterLimitsSubmission');

  -- /ICS_PARAM_LMTS/ICS_LMT/ICS_NUM_COND
  DELETE
    FROM ics_flow_icis..ics_num_cond
   WHERE ics_lmt_id IN
            (SELECT ics_lmt.ics_lmt_id
               FROM ics_param_lmts
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_param_lmts.key_hash 
                    JOIN ics_lmt ON ics_lmt.ics_param_lmts_id = ics_param_lmts.ics_param_lmts_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ParameterLimitsSubmission');

  -- /ICS_PARAM_LMTS/ICS_LMT
  DELETE
    FROM ics_flow_icis..ics_lmt
   WHERE ics_param_lmts_id IN
            (SELECT ics_param_lmts.ics_param_lmts_id
               FROM ics_param_lmts
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_param_lmts.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ParameterLimitsSubmission');

  -- /ICS_PARAM_LMTS
  DELETE
    FROM ics_flow_icis..ics_param_lmts
   WHERE ics_param_lmts_id IN
            (SELECT ics_param_lmts.ics_param_lmts_id
               FROM ics_param_lmts
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_param_lmts.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ParameterLimitsSubmission');


  -- Add accepted records for ics_param_lmts
  -- /ICS_PARAM_LMTS
  INSERT INTO ics_flow_icis..ics_param_lmts
       SELECT ics_param_lmts.*
         FROM ics_param_lmts
         WHERE ics_param_lmts.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'ParameterLimitsSubmission');

  -- /ICS_PARAM_LMTS/ICS_LMT
  INSERT INTO ics_flow_icis..ics_lmt
       SELECT ics_lmt.*
         FROM ics_lmt
            JOIN ics_param_lmts
              ON ics_lmt.ics_param_lmts_id = ics_param_lmts.ics_param_lmts_id
         WHERE ics_param_lmts.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'ParameterLimitsSubmission');

  -- /ICS_PARAM_LMTS/ICS_LMT/ICS_MN_LMT_APPLIES
  INSERT INTO ics_flow_icis..ics_mn_lmt_applies
       SELECT ics_mn_lmt_applies.*
         FROM ics_mn_lmt_applies
            JOIN ics_lmt
              ON ics_mn_lmt_applies.ics_lmt_id = ics_lmt.ics_lmt_id
            JOIN ics_param_lmts
              ON ics_lmt.ics_param_lmts_id = ics_param_lmts.ics_param_lmts_id
         WHERE ics_param_lmts.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'ParameterLimitsSubmission');

  -- /ICS_PARAM_LMTS/ICS_LMT/ICS_NUM_COND
  INSERT INTO ics_flow_icis..ics_num_cond
       SELECT ics_num_cond.*
         FROM ics_num_cond
            JOIN ics_lmt
              ON ics_num_cond.ics_lmt_id = ics_lmt.ics_lmt_id
            JOIN ics_param_lmts
              ON ics_lmt.ics_param_lmts_id = ics_param_lmts.ics_param_lmts_id
         WHERE ics_param_lmts.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'ParameterLimitsSubmission');


  -- Remove any old records for ics_dsch_mon_rep
  -- /ICS_DSCH_MON_REP/ICS_LAND_APPL_SITE/ICS_CROP_TYPES_HARVESTED
  DELETE
    FROM ics_flow_icis..ics_crop_types_harvested
   WHERE ics_land_appl_site_id IN
            (SELECT ics_land_appl_site.ics_land_appl_site_id
               FROM ics_dsch_mon_rep
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_dsch_mon_rep.key_hash 
                    JOIN ics_land_appl_site ON ics_land_appl_site.ics_dsch_mon_rep_id = ics_dsch_mon_rep.ics_dsch_mon_rep_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'DischargeMonitoringReportSubmission');

  -- /ICS_DSCH_MON_REP/ICS_LAND_APPL_SITE/ICS_CROP_TYPES_PLANTED
  DELETE
    FROM ics_flow_icis..ics_crop_types_planted
   WHERE ics_land_appl_site_id IN
            (SELECT ics_land_appl_site.ics_land_appl_site_id
               FROM ics_dsch_mon_rep
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_dsch_mon_rep.key_hash 
                    JOIN ics_land_appl_site ON ics_land_appl_site.ics_dsch_mon_rep_id = ics_dsch_mon_rep.ics_dsch_mon_rep_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'DischargeMonitoringReportSubmission');

  -- /ICS_DSCH_MON_REP/ICS_REP_PARAM/ICS_NUM_REP
  DELETE
    FROM ics_flow_icis..ics_num_rep
   WHERE ics_rep_param_id IN
            (SELECT ics_rep_param.ics_rep_param_id
               FROM ics_dsch_mon_rep
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_dsch_mon_rep.key_hash 
                    JOIN ics_rep_param ON ics_rep_param.ics_dsch_mon_rep_id = ics_dsch_mon_rep.ics_dsch_mon_rep_id
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'DischargeMonitoringReportSubmission');

  -- /ICS_DSCH_MON_REP/ICS_CO_DSPL_SITE
  DELETE
    FROM ics_flow_icis..ics_co_dspl_site
   WHERE ics_dsch_mon_rep_id IN
            (SELECT ics_dsch_mon_rep.ics_dsch_mon_rep_id
               FROM ics_dsch_mon_rep
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_dsch_mon_rep.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'DischargeMonitoringReportSubmission');

  -- /ICS_DSCH_MON_REP/ICS_INCIN
  DELETE
    FROM ics_flow_icis..ics_incin
   WHERE ics_dsch_mon_rep_id IN
            (SELECT ics_dsch_mon_rep.ics_dsch_mon_rep_id
               FROM ics_dsch_mon_rep
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_dsch_mon_rep.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'DischargeMonitoringReportSubmission');

  -- /ICS_DSCH_MON_REP/ICS_LAND_APPL_SITE
  DELETE
    FROM ics_flow_icis..ics_land_appl_site
   WHERE ics_dsch_mon_rep_id IN
            (SELECT ics_dsch_mon_rep.ics_dsch_mon_rep_id
               FROM ics_dsch_mon_rep
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_dsch_mon_rep.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'DischargeMonitoringReportSubmission');

  -- /ICS_DSCH_MON_REP/ICS_REP_PARAM
  DELETE
    FROM ics_flow_icis..ics_rep_param
   WHERE ics_dsch_mon_rep_id IN
            (SELECT ics_dsch_mon_rep.ics_dsch_mon_rep_id
               FROM ics_dsch_mon_rep
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_dsch_mon_rep.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'DischargeMonitoringReportSubmission');

  -- /ICS_DSCH_MON_REP/ICS_SURF_DSPL_SITE
  DELETE
    FROM ics_flow_icis..ics_surf_dspl_site
   WHERE ics_dsch_mon_rep_id IN
            (SELECT ics_dsch_mon_rep.ics_dsch_mon_rep_id
               FROM ics_dsch_mon_rep
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_dsch_mon_rep.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'DischargeMonitoringReportSubmission');

  -- /ICS_DSCH_MON_REP
  DELETE
    FROM ics_flow_icis..ics_dsch_mon_rep
   WHERE ics_dsch_mon_rep_id IN
            (SELECT ics_dsch_mon_rep.ics_dsch_mon_rep_id
               FROM ics_dsch_mon_rep
                    JOIN ics_subm_results ON ics_subm_results.key_hash = ics_dsch_mon_rep.key_hash 
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'DischargeMonitoringReportSubmission');


  -- Add accepted records for ics_dsch_mon_rep
  -- /ICS_DSCH_MON_REP
  INSERT INTO ics_flow_icis..ics_dsch_mon_rep
       SELECT ics_dsch_mon_rep.*
         FROM ics_dsch_mon_rep
         WHERE ics_dsch_mon_rep.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'DischargeMonitoringReportSubmission');

  -- /ICS_DSCH_MON_REP/ICS_CO_DSPL_SITE
  INSERT INTO ics_flow_icis..ics_co_dspl_site
       SELECT ics_co_dspl_site.*
         FROM ics_co_dspl_site
            JOIN ics_dsch_mon_rep
              ON ics_co_dspl_site.ics_dsch_mon_rep_id = ics_dsch_mon_rep.ics_dsch_mon_rep_id
         WHERE ics_dsch_mon_rep.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'DischargeMonitoringReportSubmission');

  -- /ICS_DSCH_MON_REP/ICS_INCIN
  INSERT INTO ics_flow_icis..ics_incin
       SELECT ics_incin.*
         FROM ics_incin
            JOIN ics_dsch_mon_rep
              ON ics_incin.ics_dsch_mon_rep_id = ics_dsch_mon_rep.ics_dsch_mon_rep_id
         WHERE ics_dsch_mon_rep.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'DischargeMonitoringReportSubmission');

  -- /ICS_DSCH_MON_REP/ICS_LAND_APPL_SITE
  INSERT INTO ics_flow_icis..ics_land_appl_site
       SELECT ics_land_appl_site.*
         FROM ics_land_appl_site
            JOIN ics_dsch_mon_rep
              ON ics_land_appl_site.ics_dsch_mon_rep_id = ics_dsch_mon_rep.ics_dsch_mon_rep_id
         WHERE ics_dsch_mon_rep.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'DischargeMonitoringReportSubmission');

  -- /ICS_DSCH_MON_REP/ICS_LAND_APPL_SITE/ICS_CROP_TYPES_HARVESTED
  INSERT INTO ics_flow_icis..ics_crop_types_harvested
       SELECT ics_crop_types_harvested.*
         FROM ics_crop_types_harvested
            JOIN ics_land_appl_site
              ON ics_crop_types_harvested.ics_land_appl_site_id = ics_land_appl_site.ics_land_appl_site_id
            JOIN ics_dsch_mon_rep
              ON ics_land_appl_site.ics_dsch_mon_rep_id = ics_dsch_mon_rep.ics_dsch_mon_rep_id
         WHERE ics_dsch_mon_rep.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'DischargeMonitoringReportSubmission');

  -- /ICS_DSCH_MON_REP/ICS_LAND_APPL_SITE/ICS_CROP_TYPES_PLANTED
  INSERT INTO ics_flow_icis..ics_crop_types_planted
       SELECT ics_crop_types_planted.*
         FROM ics_crop_types_planted
            JOIN ics_land_appl_site
              ON ics_crop_types_planted.ics_land_appl_site_id = ics_land_appl_site.ics_land_appl_site_id
            JOIN ics_dsch_mon_rep
              ON ics_land_appl_site.ics_dsch_mon_rep_id = ics_dsch_mon_rep.ics_dsch_mon_rep_id
         WHERE ics_dsch_mon_rep.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'DischargeMonitoringReportSubmission');

  -- /ICS_DSCH_MON_REP/ICS_REP_PARAM
  INSERT INTO ics_flow_icis..ics_rep_param
       SELECT ics_rep_param.*
         FROM ics_rep_param
            JOIN ics_dsch_mon_rep
              ON ics_rep_param.ics_dsch_mon_rep_id = ics_dsch_mon_rep.ics_dsch_mon_rep_id
         WHERE ics_dsch_mon_rep.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'DischargeMonitoringReportSubmission');

  -- /ICS_DSCH_MON_REP/ICS_REP_PARAM/ICS_NUM_REP
  INSERT INTO ics_flow_icis..ics_num_rep
       SELECT ics_num_rep.*
         FROM ics_num_rep
            JOIN ics_rep_param
              ON ics_num_rep.ics_rep_param_id = ics_rep_param.ics_rep_param_id
            JOIN ics_dsch_mon_rep
              ON ics_rep_param.ics_dsch_mon_rep_id = ics_dsch_mon_rep.ics_dsch_mon_rep_id
         WHERE ics_dsch_mon_rep.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'DischargeMonitoringReportSubmission');

  -- /ICS_DSCH_MON_REP/ICS_SURF_DSPL_SITE
  INSERT INTO ics_flow_icis..ics_surf_dspl_site
       SELECT ics_surf_dspl_site.*
         FROM ics_surf_dspl_site
            JOIN ics_dsch_mon_rep
              ON ics_surf_dspl_site.ics_dsch_mon_rep_id = ics_dsch_mon_rep.ics_dsch_mon_rep_id
         WHERE ics_dsch_mon_rep.transaction_type NOT IN ('D','X')
          AND key_hash IN 
                (SELECT key_hash
                   FROM ics_subm_results
                  WHERE result_type_code IN ('Accepted','Warning')
                    AND subm_type_name = 'DischargeMonitoringReportSubmission');

  /*
   *  Remove any previous accepted transactions so the procedure does not attempt to move records from previous executions.
   */
  DELETE 
    FROM ics_subm_results 
   WHERE result_type_code IN ('Accepted','Warning');
 
 
 END TRY
 
 BEGIN CATCH

    SET @v_error_message = ERROR_MESSAGE();
    SET @v_error_number = ERROR_NUMBER();

    /* 
     *  First rollback pending data changes from ICIS ETL and change detection processing 
     */
     ROLLBACK TRANSACTION PROCESS_ACCEPTED_TRANS;

     --Send the error back up to the calling code. If the ETL is being called from the plugin, this will trigger the plugin to log the failure and quit
     RAISERROR (@v_error_message, 10,1);

  END CATCH
  
  /* Commit all data changes */
  COMMIT TRANSACTION PROCESS_ACCEPTED_TRANS;

GO

