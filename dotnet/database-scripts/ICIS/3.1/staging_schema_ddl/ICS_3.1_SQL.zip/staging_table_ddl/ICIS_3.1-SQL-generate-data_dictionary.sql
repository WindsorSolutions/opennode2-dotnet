SELECT * 
FROM
(SELECT     o.name AS TABLE_NAME, c.name AS COLUMN_NAME, p.value AS XML_ELEMENT_NAME, CASE WHEN c.isnullable = 0 THEN 'No' ELSE 'Yes' END AS IS_NULLABLE,
                       c.colorder AS COLUMN_ORDER
FROM         sys.sysobjects AS o INNER JOIN
                      sys.syscolumns AS c ON o.id = c.id INNER JOIN
                      sys.objects AS os ON o.id = os.[object_id] INNER JOIN
                      sys.schemas AS s ON os.[schema_id] = s.[schema_id] INNER JOIN
                      sys.systypes AS t ON c.xusertype = t.xtype LEFT OUTER JOIN
                      sys.extended_properties AS p ON p.minor_id = c.colid AND p.major_id = c.id
                      AND p.[name] = 'MS_Description'
WHERE     (o.xtype = 'U') AND (o.name <> 'dtproperties') AND (o.name <> 'sysdiagrams')
UNION
SELECT     o.name AS TABLE_NAME, null as COLUMN_NAME, REPLACE(CONVERT(varchar(100),p.value),'Schema element: ','') AS XML_ELEMENT_NAME, NULL as IS_NULLABLE, NULL as COLUMN_ORDER
FROM         sys.sysobjects AS o INNER JOIN
             sys.objects AS os ON o.id = os.[object_id] INNER JOIN
             sys.schemas AS s ON os.[schema_id] = s.[schema_id] LEFT OUTER JOIN
                      sys.extended_properties AS p ON p.major_id = o.id AND p.minor_id = 0 AND p.[name] = 'MS_Description'
WHERE     (o.xtype = 'U') AND (o.name <> 'dtproperties') AND (o.name <> 'sysdiagrams')
) x
ORDER BY TABLE_NAME, COLUMN_ORDER