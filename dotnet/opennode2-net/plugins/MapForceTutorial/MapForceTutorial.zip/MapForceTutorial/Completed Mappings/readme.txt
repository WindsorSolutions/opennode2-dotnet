----------------------------------------------------------
MapForce Plugin Development Tutorial - Completed Mappings
----------------------------------------------------------

  In order to utilize the completed mappings, it will be necessary to remap the
  database and schema connections to the database server and schema locations in your environment.


DBtoXML.mdf
-----------

  Repairing the Schema connection (not necessary if you unzip to c:\ )

  1.) Right-click on the XML schema component and choose Properties
  2.) Set the schema file to: c:\MapForceTutorial\BeachNotification_Schema_v2.1\2\1\BEACHES_Notification_v2.1.xsd
  3.) Set the Input and output files to: c:\MapForceTutorial\BeachNotification_Schema_v2.1\Beach_ExampleXMLFile_v2.1.xml

  Repairing the database connection

  4.) Right-click on the database component and choose Properties
  5.) Click the Change button and follow the connection wizard to update the database connection



  

