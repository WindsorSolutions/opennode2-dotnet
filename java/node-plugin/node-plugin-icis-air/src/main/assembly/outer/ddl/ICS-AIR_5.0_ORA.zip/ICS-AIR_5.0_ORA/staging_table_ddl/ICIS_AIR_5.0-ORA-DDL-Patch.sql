/*
Copyright (c) 2014, The Environmental Council of the States (ECOS)
All rights reserved.
 
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
 
 * Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
 * Neither the name of the ECOS nor the names of its contributors may
   be used to endorse or promote products derived from this software
   without specific prior written permission.
 
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/

/******************************************************************************************************************
 *
 *  Script Name:  ICIS_AIR_5.0-SQL-DDL-Patch.sql
 *
 *  Company:  Windsor Solutions, Inc.
 *  
 *  Purpose:  This script will alter an existing ICIS Air database schema.  It can be run repeatedly.  A schema 
 *            alteration will only occur during the first pass.
 *   
 *  Maintenance:
 *  
 *    Analyst         Date            Comment 
 *    ----------      ----------      -----------------------------------------------------------------------------
 *    KJames         01/21/2015       Created 
 *    KJames         01/28/2015       Updated changed detection processing by adding several required fields to the
 *                                    delete payloads.
 *    KJames         01/30/2015       Added alteration of ICA_SUBM_RSLTS to allow up to 10 characters in the 
 *                                    RESULT_CODE column.
 *   
 ******************************************************************************************************************/


/*
 *  Alter Table:  ICA_FAC_IDENT
 */
DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  /*  Check to see if datatype exists on the database table. */
   SELECT 1
     INTO v_object_ind
     FROM all_tab_columns
    WHERE owner = 'ICA_FLOW_LOCAL'
      AND table_name = 'ICA_FAC_IDENT'
      AND column_name = 'FAC_IDENT'
      AND data_type = 'CHAR';
      
      v_sql_statement := 'ALTER TABLE ICA_FLOW_LOCAL.ICA_FAC_IDENT MODIFY FAC_IDENT VARCHAR2(18)';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The column ICA_FAC_IDENT.FAC_IDENT was successfully modified to VARCHAR2(18).');
   
EXCEPTION

  WHEN NO_DATA_FOUND THEN  
  
    BEGIN
       
     /* The datatype already exists in schema, bypass creation */
      DBMS_OUTPUT.PUT_LINE( 'The column ICA_FLOW_LOCAL.FAC_IDENT was already VARCHAR2(18), schema alteration bypassed!');
       
    END;
    
END;
/


/*
 *  Alter Table:  ICA_SUBM_RSLTS
 */
DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  /*  Check to see if datatype exists on the database table. */
   SELECT 1
     INTO v_object_ind
     FROM all_tab_columns
    WHERE owner = 'ICA_FLOW_LOCAL'
      AND table_name = 'ICA_SUBM_RSLTS'
      AND column_name = 'FAC_IDENT'
      AND data_type = 'CHAR';
      
      v_sql_statement := 'ALTER TABLE ICA_FLOW_LOCAL.ICA_SUBM_RSLTS MODIFY FAC_IDENT VARCHAR2(18)';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The column ICA_SUBM_RSLTS.FAC_IDENT was successfully modified to VARCHAR2(18).');
   


EXCEPTION

  WHEN NO_DATA_FOUND THEN  
  
    BEGIN
       
     /* The datatype already exists in schema, bypass creation */
      DBMS_OUTPUT.PUT_LINE( 'The column ICA_FLOW_LOCAL.FAC_IDENT was already VARCHAR2(18), schema alteration bypassed!');
       
    END;
    
END;
/

/*
 *  Alter Table:  ICA_SUBM_RSLTS
 */
DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  /*  Check to see if datatype exists on the database table. */
   SELECT 1
     INTO v_object_ind
     FROM all_tab_columns
    WHERE owner = 'ICA_FLOW_LOCAL'
      AND table_name = 'ICA_SUBM_RSLTS'
      AND column_name = 'RESULT_CODE'
      AND data_type = 'VARCHAR2'
      AND data_length <> 10;
      
      v_sql_statement := 'ALTER TABLE ICA_FLOW_LOCAL.ICA_SUBM_RSLTS MODIFY RESULT_CODE VARCHAR2(10)';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The column ICA_SUBM_RSLTS.RESULT_CODE was successfully modified to VARCHAR2(10).');
   
EXCEPTION

  WHEN NO_DATA_FOUND THEN  
  
    BEGIN
       
     /* The datatype already exists in schema, bypass creation */
      DBMS_OUTPUT.PUT_LINE( 'The column ICA_FLOW_LOCAL.RESULT_CODE was already VARCHAR2(10), schema alteration bypassed!');
       
    END;
    
END;
/

/******************************************************************************************************************************
** Object Name:  ICA_CHANGE_DETECTION
**
** Author:  Windsor Solutions, Inc.
**
** Description:  This procedure will detect data changes made within the ICIS schema and then sets the transaction type
**               flags so the data can be bundled and submitted to an exchange partner.
**
** Inputs:  -- NA --  
**
** Revision History:      
** ----------------------------------------------------------------------------------------------------------------------------
**  Date         Analyst     Description
** ----------------------------------------------------------------------------------------------------------------------------
** 07/01/2014    Windsor    Created
** 07/30/2014    KJames     Altered processing of PORT_SRC_IND.
** 07/30/2014    KJames     Added LOCALITY_NAME and LOC_ADDR_COUNTY_CODE to ICA_FAC change detection.
** 08/07/2014    KJames     Set the delete transaction type codes to 'X'.
** 08/07/2014    KJames     Set the new and update transaction type codes to 'R'.
** 09/03/2014    KJames     Added code to hash the linkage tables.
** 09/03/2014    KJames     Added setting of delete transactions of linkage tables.
** 09/04/2014    KJames     Added OTHR_PROG_DESC_TXT to the database tables ICA_DA_FRML_ENFRC_ACTN and
**                          ICA_DA_INFRML_ENFRC_ACTN.
** 10/10/2014    KJames     Added the v_enabled flag for each payload type to control hashing.
** 10/20/2014    KJames     Removed transaction processing.
** 01/28/2015    KJames     Added the required field PROG_OPER_STAT_CODE to the logic that builds ICA_PROGS delete records.
** 01/28/2015    KJames     Added the required field FAC_IDENT to the logic that builds ICA_TVACC delete records.
** 01/28/2015    KJames     Added the required field FAC_IDENT to the logic that builds ICA_DA_CASE_FILE delete records.
**
******************************************************************************************************************************/
CREATE OR REPLACE PROCEDURE "ICA_FLOW_LOCAL"."ICA_CHANGE_DETECTION"
AS

  v_sql_statement VARCHAR2(4000);
  v_all_data_hashes VARCHAR2(4000);  
  v_hashed_data_hashes VARCHAR2(32);
  v_enabled char(1);

BEGIN

  /*  Initialize working table ICA_KEY_HASH */
  DELETE FROM ica_key_hash;

  /*  Initialize working table ICA_DATA_HASH */
  DELETE FROM ica_data_hash;
  
  /*  
   * Reset transaction_type on all payload tables  
   */
  FOR payload_type IN (SELECT child.table_name
                         FROM user_constraints child
                         LEFT JOIN user_constraints parent
                           ON child.r_constraint_name = parent.constraint_name
                        WHERE child.constraint_type = 'R'
                          AND parent.table_name = 'ICA_PAYLOAD'                           
                        ORDER BY child.table_name) LOOP
       
    /* For each payload type, remove all the transaction codes from the previous run. */
    v_sql_statement := 'UPDATE ' || payload_type.table_name || ' SET TRANSACTION_TYPE = NULL , TRANSACTION_TIMESTAMP = NULL';
    EXECUTE IMMEDIATE v_sql_statement;
  
  END LOOP module_loop;
  

 /*********************************************/  
 /* START - Set KEY_HASH and DATA_HASH fields */
 /* START - Set KEY_HASH and DATA_HASH fields */
 /* START - Set KEY_HASH and DATA_HASH fields */
 /*********************************************/  

  UPDATE ica_flow_local.ica_case_file_cmnt_txt
      SET data_hash = MD5_HASH(
     case_file_cmnt_txt
  );
  UPDATE ica_flow_local.ica_case_file_lnk
      SET data_hash = MD5_HASH(
     src_systm_ident
   ||case_file_ident
  );
  UPDATE ica_flow_local.ica_cmpl_insp_type
      SET data_hash = MD5_HASH(
     cmpl_insp_type_code
  );
  UPDATE ica_flow_local.ica_cmpl_mon_lnk
      SET data_hash = MD5_HASH(
     src_systm_ident
   ||cmpl_mon_ident
  );
  UPDATE ica_flow_local.ica_cmpl_mon_strgy
     SET key_hash = MD5_HASH(ica_flow_local.ica_cmpl_mon_strgy.fac_ident),
        data_hash = MD5_HASH(
     src_systm_ident
   ||fac_ident
   ||cms_src_catg_code
   ||cms_min_freq
   ||cms_start_date
   ||active_cms_plan_ind
   ||rmvd_plan_date
   ||rsn_chng_cms_cmnts
  );
  UPDATE ica_flow_local.ica_cntct
      SET data_hash = MD5_HASH(
     affil_type_txt
   ||first_name
   ||middle_name
   ||last_name
   ||indvl_title_txt
   ||org_frml_name
   ||st_code
   ||rgn_code
   ||elec_addr_txt
   ||start_date_of_cntct_assc
   ||end_date_of_cntct_assc
  );
  UPDATE ica_flow_local.ica_da_case_file
     SET key_hash = MD5_HASH(ica_flow_local.ica_da_case_file.case_file_ident),
        data_hash = MD5_HASH(
     src_systm_ident
   ||case_file_ident
   ||case_file_name
   ||lead_agncy_code
   ||fac_ident
   ||othr_prog_desc_txt
   ||sens_data_ind
   ||lead_agncy_chng_sprsed_txt
   ||advise_method_type_code
   ||advise_method_date
   ||case_file_usr_def_fld_1
   ||case_file_usr_def_fld_2
   ||case_file_usr_def_fld_3
   ||case_file_usr_def_fld_4
   ||case_file_usr_def_fld_5
   ||case_file_usr_def_fld_6
  );
  UPDATE ica_flow_local.ica_da_cmpl_mon
     SET key_hash = MD5_HASH(ica_flow_local.ica_da_cmpl_mon.cmpl_mon_ident),
        data_hash = MD5_HASH(
     src_systm_ident
   ||cmpl_mon_ident
   ||cmpl_mon_acty_type_code
   ||cmpl_mon_date
   ||cmpl_mon_start_date
   ||cmpl_mon_acty_name
   ||multimedia_ind
   ||cmpl_mon_planned_start_date
   ||cmpl_mon_planned_end_date
   ||deficiencies_obs_ind
   ||lead_agncy_code
   ||othr_prog_desc_txt
   ||othr_agncy_initiative_txt
   ||insp_usr_def_fld_1
   ||insp_usr_def_fld_2
   ||insp_usr_def_fld_3
   ||insp_usr_def_fld_4
   ||insp_usr_def_fld_5
   ||insp_usr_def_fld_6
  );
  UPDATE ica_flow_local.ica_da_enfrc_actn_lnk
     SET key_hash = MD5_HASH(ica_flow_local.ica_da_enfrc_actn_lnk.da_enfrc_actn_ident),
        data_hash = MD5_HASH(
     src_systm_ident
   ||da_enfrc_actn_ident
  );
  UPDATE ica_flow_local.ica_da_enfrc_actn_milstn
     SET key_hash = MD5_HASH(ica_flow_local.ica_da_enfrc_actn_milstn.da_enfrc_actn_ident || milstn_type_code),
        data_hash = MD5_HASH(
     src_systm_ident
   ||da_enfrc_actn_ident
   ||milstn_type_code
   ||milstn_planned_date
   ||milstn_actual_date
  );
  UPDATE ica_flow_local.ica_da_final_order
      SET data_hash = MD5_HASH(
     final_order_ident
   ||final_order_type_code
   ||final_order_issued_enterd_date
   ||rslvd_date
   ||cash_civil_pnlty_reqd_amt
   ||othr_cmnts
  );
  UPDATE ica_flow_local.ica_da_frml_enfrc_actn
     SET key_hash = MD5_HASH(ica_flow_local.ica_da_frml_enfrc_actn.da_enfrc_actn_ident),
        data_hash = MD5_HASH(
     src_systm_ident
   ||da_enfrc_actn_ident
   ||enfrc_actn_name
   ||forum
   ||resl_type_code
   ||da_comb_sprsed_eaid
   ||rsn_del_rec
   ||frml_ea_usr_def_fld_1
   ||frml_ea_usr_def_fld_2
   ||frml_ea_usr_def_fld_3
   ||frml_ea_usr_def_fld_4
   ||frml_ea_usr_def_fld_5
   ||frml_ea_usr_def_fld_6
   ||lead_agncy_code
   ||enfrc_agncy_name
   ||othr_agncy_initiative_txt
   ||othr_prog_desc_txt
  );
  UPDATE ica_flow_local.ica_da_infrml_enfrc_actn
     SET key_hash = MD5_HASH(ica_flow_local.ica_da_infrml_enfrc_actn.da_enfrc_actn_ident),
        data_hash = MD5_HASH(
     src_systm_ident
   ||da_enfrc_actn_ident
   ||enfrc_actn_type_code
   ||enfrc_actn_name
   ||achieved_date
   ||file_num
   ||rsn_del_rec
   ||infrml_ea_usr_def_fld_1
   ||infrml_ea_usr_def_fld_2
   ||infrml_ea_usr_def_fld_3
   ||infrml_ea_usr_def_fld_4
   ||infrml_ea_usr_def_fld_5
   ||infrml_ea_usr_def_fld_6
   ||lead_agncy_code
   ||enfrc_agncy_name
   ||othr_agncy_initiative_txt
   ||st_sects_viol_txt
   ||othr_prog_desc_txt
  );
  UPDATE ica_flow_local.ica_enfrc_actn_cmnt_txt
      SET data_hash = MD5_HASH(
     enfrc_actn_cmnt_txt
  );
  UPDATE ica_flow_local.ica_enfrc_actn_gov_cntct
      SET data_hash = MD5_HASH(
     affil_type_txt
   ||elec_addr_txt
   ||start_date_of_cntct_assc
   ||end_date_of_cntct_assc
  );
  UPDATE ica_flow_local.ica_enfrc_actn_type
      SET data_hash = MD5_HASH(
     enfrc_actn_type_code
  );
  UPDATE ica_flow_local.ica_enfrc_agncy_type
      SET data_hash = MD5_HASH(
     enfrc_agncy_type_code
  );
  UPDATE ica_flow_local.ica_fac
     SET key_hash = MD5_HASH(ica_flow_local.ica_fac.fac_ident),
        data_hash = MD5_HASH(
     src_systm_ident
   ||fac_ident
   ||fac_site_name
   ||loc_addr_txt
   ||suppl_loc_txt
   ||loc_addr_city_code
   ||loc_st_code
   ||loc_zip_code
   ||lcon_code
   ||tribal_land_code
   ||fac_desc
   ||fac_type_of_owner_code
   ||reg_num
   ||small_busnss_ind
   ||federally_rep_ind
   ||src_unifm_rsrc_locator_url
   ||envr_justice_code
   ||fac_congr_district_num
   ||fac_usr_def_fld_1
   ||fac_usr_def_fld_2
   ||fac_usr_def_fld_3
   ||fac_usr_def_fld_4
   ||fac_usr_def_fld_5
   ||fac_cmnts
   ||port_src_ind
   ||locality_name
   ||loc_addr_county_code
  );
  UPDATE ica_flow_local.ica_fac_addr
      SET data_hash = MD5_HASH(
     affil_type_txt
   ||org_frml_name
   ||org_duns_num
   ||mailing_addr_txt
   ||suppl_addr_txt
   ||mailing_addr_city_name
   ||mailing_addr_st_code
   ||mailing_addr_zip_code
   ||county_name
   ||mailing_addr_country_code
   ||division_name
   ||loc_province
   ||elec_addr_txt
   ||start_date_of_addr_assc
   ||end_date_of_addr_assc
  );
  UPDATE ica_flow_local.ica_fac_ident
      SET data_hash = MD5_HASH(
     fac_ident
  );
  UPDATE ica_flow_local.ica_final_order_fac_ident
      SET data_hash = MD5_HASH(
     final_order_fac_ident
  );
  UPDATE ica_flow_local.ica_geo_coord
      SET data_hash = MD5_HASH(
     lat_meas
   ||long_meas
   ||horz_accuracy_meas
   ||geom_type_code
   ||horz_coll_method_code
   ||horz_ref_datum_code
   ||ref_point_code
   ||src_map_scale_num
   ||utm_coord_1
   ||utm_coord_2
   ||utm_coord_3
  );
  UPDATE ica_flow_local.ica_infrml_ea_cmnt_txt
      SET data_hash = MD5_HASH(
     infrml_ea_cmnt_txt
  );
  UPDATE ica_flow_local.ica_insp_cmnt_txt
      SET data_hash = MD5_HASH(
     insp_cmnt_txt
  );
  UPDATE ica_flow_local.ica_insp_gov_cntct
      SET data_hash = MD5_HASH(
     affil_type_txt
   ||elec_addr_txt
  );
  UPDATE ica_flow_local.ica_lnk_case_file
      SET data_hash = MD5_HASH(
     case_file_ident
  );
  UPDATE ica_flow_local.ica_lnk_cmpl_mon
      SET data_hash = MD5_HASH(
     cmpl_mon_ident
  );
  UPDATE ica_flow_local.ica_lnk_da_enfrc_actn
      SET data_hash = MD5_HASH(
     da_enfrc_actn_ident
  );
  UPDATE ica_flow_local.ica_method
      SET data_hash = MD5_HASH(
     method_code
  );
  UPDATE ica_flow_local.ica_naics_code
      SET data_hash = MD5_HASH(
     naics_code
   ||naics_pri_ind_code
  );
  UPDATE ica_flow_local.ica_nat_prio
      SET data_hash = MD5_HASH(
     nat_prio_code
  );
  UPDATE ica_flow_local.ica_othr_pathway_acty
      SET data_hash = MD5_HASH(
     othr_pathway_catg_code
   ||othr_pathway_type_code
   ||othr_pathway_date
  );
  UPDATE ica_flow_local.ica_payload
      SET data_hash = MD5_HASH(
     operation
   ||enabled
   ||auto_gen_deletes);

  UPDATE ica_flow_local.ica_polut
      SET data_hash = MD5_HASH(
     polut_code
  );
  UPDATE ica_flow_local.ica_polut_da_class
      SET data_hash = MD5_HASH(
     polut_da_class_code
   ||polut_da_class_start_date
  );
  UPDATE ica_flow_local.ica_polut_epa_class
      SET data_hash = MD5_HASH(
     polut_epa_class_code
   ||polut_epa_class_start_date
  );
  UPDATE ica_flow_local.ica_poluts
     SET key_hash = MD5_HASH(ica_flow_local.ica_poluts.fac_ident || poluts_code),
        data_hash = MD5_HASH(
     src_systm_ident
   ||fac_ident
   ||poluts_code
   ||polut_stat_ind
  );
  UPDATE ica_flow_local.ica_port_src
      SET data_hash = MD5_HASH(
   port_src_site_name
   ||port_src_start_date
   ||port_src_end_date
  );
  UPDATE ica_flow_local.ica_prog
      SET data_hash = MD5_HASH(
     prog_code
  );
  UPDATE ica_flow_local.ica_prog_subpart
      SET data_hash = MD5_HASH(
     prog_subpart_code
   ||prog_subpart_stat_ind
  );
  UPDATE ica_flow_local.ica_progs
     SET key_hash = MD5_HASH(ica_flow_local.ica_progs.fac_ident || prog_code),
        data_hash = MD5_HASH(
     src_systm_ident
   ||fac_ident
   ||prog_code
   ||othr_prog_desc_txt
   ||prog_oper_stat_code
   ||prog_oper_stat_start_date
  );
  UPDATE ica_flow_local.ica_progs_viol
      SET data_hash = MD5_HASH(
     progs_viol_code
  );
  UPDATE ica_flow_local.ica_rgnl_prio
      SET data_hash = MD5_HASH(
     rgnl_prio_code
  );
  UPDATE ica_flow_local.ica_sens_cmnt_txt
      SET data_hash = MD5_HASH(
     sens_cmnt_txt
  );
  UPDATE ica_flow_local.ica_sic_code
      SET data_hash = MD5_HASH(
     sic_code
   ||sic_pri_ind_code
  );
  UPDATE ica_flow_local.ica_stck_tst
      SET data_hash = MD5_HASH(
     stck_tst_stat_code
   ||stck_tst_cndctr_type_code
   ||stck_ident
   ||othr_stck_tst_purpose_name
   ||stck_tst_rep_rcvd_date
   ||tst_rslts_reviewed_date
  );
  UPDATE ica_flow_local.ica_stck_tst_obs_agncy_type
      SET data_hash = MD5_HASH(
     stck_tst_obs_agncy_type_code
  );
  UPDATE ica_flow_local.ica_stck_tst_purpose
      SET data_hash = MD5_HASH(
     stck_tst_purpose_code
  );
  UPDATE ica_flow_local.ica_teleph
      SET data_hash = MD5_HASH(
     teleph_num_type_code
   ||teleph_num
   ||teleph_ext_num
  );
  UPDATE ica_flow_local.ica_tst_rslts
      SET data_hash = MD5_HASH(
     tested_polut_code
   ||tst_result_code
   ||allowable_value
   ||allowable_unit_code
   ||actual_result
   ||failure_rsn_code
   ||othr_failure_rsn_txt
  );
  UPDATE ica_flow_local.ica_tvacc
     SET key_hash = MD5_HASH(ica_flow_local.ica_tvacc.cmpl_mon_ident),
        data_hash = MD5_HASH(
     src_systm_ident
   ||cmpl_mon_ident
   ||cmpl_mon_date
   ||cmpl_mon_start_date
   ||cmpl_mon_acty_name
   ||multimedia_ind
   ||cmpl_mon_planned_start_date
   ||cmpl_mon_planned_end_date
   ||deficiencies_obs_ind
   ||fac_ident
   ||lead_agncy_code
   ||othr_prog_desc_txt
   ||othr_agncy_initiative_txt
   ||insp_usr_def_fld_1
   ||insp_usr_def_fld_2
   ||insp_usr_def_fld_3
   ||insp_usr_def_fld_4
   ||insp_usr_def_fld_5
   ||insp_usr_def_fld_6
   ||prmt_ident
   ||cert_period_start_date
   ||cert_period_end_date
   ||fac_rep_cmpl_stat_code
  );
  UPDATE ica_flow_local.ica_tvacc_review
      SET data_hash = MD5_HASH(
     tvacc_reviewed_date
   ||fac_rep_deviations_ind
   ||prmt_conds_txt
   ||exceed_excurs_ind
   ||reviewer_agncy_code
   ||tvacc_reviewer_name
   ||reviewer_cmnt
  );
  UPDATE ica_flow_local.ica_universe_ind
      SET data_hash = MD5_HASH(
     universe_ind_code
  );
  UPDATE ica_flow_local.ica_viol
      SET data_hash = MD5_HASH(
     viol_type_code
   ||viol_prog_code
   ||viol_prog_desc_txt
   ||viol_polut_code
   ||frv_dtrmn_date
   ||hpv_day_zero_date
   ||occurrence_start_date
   ||occurrence_end_date
   ||hpv_desgn_rmvl_type_code
   ||hpv_desgn_rmvl_date
   ||claims_num
  );
  
  
  /* Linkage Tables */
  UPDATE ica_flow_local.ica_cmpl_mon_lnk
     SET key_hash = (SELECT MD5_HASH( ica_cmpl_mon_lnk.src_systm_ident
                                   || ica_cmpl_mon_lnk.cmpl_mon_ident
                                   || ica_lnk_cmpl_mon.cmpl_mon_ident
                                   || ica_lnk_da_enfrc_actn.da_enfrc_actn_ident)
                      FROM ica_cmpl_mon_lnk inner_lnk
                      LEFT JOIN ica_lnk_cmpl_mon on ica_lnk_cmpl_mon.ica_cmpl_mon_lnk_id = inner_lnk.ica_cmpl_mon_lnk_id
                      LEFT JOIN ica_lnk_da_enfrc_actn on ica_lnk_da_enfrc_actn.ica_cmpl_mon_lnk_id = inner_lnk.ica_cmpl_mon_lnk_id
                     WHERE inner_lnk.ica_cmpl_mon_lnk_id = ica_cmpl_mon_lnk.ica_cmpl_mon_lnk_id
                    );



  UPDATE ica_flow_local.ica_da_enfrc_actn_lnk
     SET key_hash = (SELECT MD5_HASH( ica_da_enfrc_actn_lnk.src_systm_ident
                                   || ica_da_enfrc_actn_lnk.da_enfrc_actn_ident
                                   || ica_lnk_da_enfrc_actn.da_enfrc_actn_ident)
                       FROM ica_da_enfrc_actn_lnk inner_lnk
                       LEFT JOIN ica_lnk_da_enfrc_actn on ica_lnk_da_enfrc_actn.ica_da_enfrc_actn_lnk_id = inner_lnk.ica_da_enfrc_actn_lnk_id
                      WHERE inner_lnk.ica_da_enfrc_actn_lnk_id = ica_da_enfrc_actn_lnk.ica_da_enfrc_actn_lnk_id
                    );


  UPDATE ica_flow_local.ica_case_file_lnk
     SET key_hash = (SELECT MD5_HASH( ica_case_file_lnk.src_systm_ident
                                   || ica_case_file_lnk.case_file_ident
                                   || ica_lnk_case_file.case_file_ident
                                   || ica_lnk_cmpl_mon.cmpl_mon_ident
                                   || ica_lnk_da_enfrc_actn.da_enfrc_actn_ident)
                       FROM ica_case_file_lnk inner_lnk
                       LEFT JOIN ica_lnk_case_file on ica_lnk_case_file.ica_case_file_lnk_id = inner_lnk.ica_case_file_lnk_id
                       LEFT JOIN ica_lnk_cmpl_mon on ica_lnk_cmpl_mon.ica_case_file_lnk_id = inner_lnk.ica_case_file_lnk_id
                       LEFT JOIN ica_lnk_da_enfrc_actn on ica_lnk_da_enfrc_actn.ica_case_file_lnk_id = inner_lnk.ica_case_file_lnk_id
                      WHERE inner_lnk.ica_case_file_lnk_id = ica_case_file_lnk.ica_case_file_lnk_id
                    );


 /************************************/  
 /* START - Process DATA_HASH values */
 /* START - Process DATA_HASH values */
 /* START - Process DATA_HASH values */
 /************************************/ 
 
  /* Loop through each payload type, for each loop roll child data_hash values up to the parent payload table */  
  <<module_loop>>
  FOR payload_type IN (SELECT child.table_name
                         FROM user_constraints child
                         LEFT JOIN user_constraints parent
                           ON child.r_constraint_name = parent.constraint_name
                        WHERE child.constraint_type = 'R'
                          AND parent.table_name = 'ICA_PAYLOAD'  
                          /* The tables in this list will not have related child data, change processing can be skipped */
                          AND child.table_name NOT IN ( 'ICA_BS_PROG_REP'
                                                      , 'ICA_CSO_EVT_REP'
                                                      , 'ICA_DMR_VIOL'
                                                      , 'ICA_ENFRC_ACTN_MILESTONE'
                                                      , 'ICA_HIST_PRMT_SCHD_EVTS'
                                                      , 'ICA_PRMT_REISSU'
                                                      , 'ICA_PRMT_TRACK_EVT'
                                                      , 'ICA_PRMT_TERM'
                                                      , 'ICA_SCHD_EVT_VIOL'
                                                      , 'ICA_SNGL_EVT_VIOL'
                                                      , 'ICA_SSO_ANNUL_REP'
                                                      , 'ICA_SSO_MONTHLY_EVT_REP')                  
                        ORDER BY child.table_name
                        ) LOOP

    BEGIN
         
      EXECUTE IMMEDIATE 'SELECT ENABLED FROM ICA_PAYLOAD JOIN ' || payload_type.table_name || 
        ' ON ICA_PAYLOAD.ICA_PAYLOAD_ID = ' || payload_type.table_name || '.ICA_PAYLOAD_ID WHERE ROWNUM = 1' INTO v_enabled;

    EXCEPTION WHEN NO_DATA_FOUND THEN
        
        v_enabled := 'N';
    END;

    /* Flush the prior payload type's key_hash values */
    DELETE FROM ica_key_hash;
    
    /* Load next key_hash set for current payload type */ 
    v_sql_statement := 'INSERT INTO ica_key_hash SELECT key_hash FROM ' || payload_type.table_name; 
    EXECUTE IMMEDIATE v_sql_statement;

      
    /* 
     *  Loop through each key in a payload type's key set.  For each key traverse the payload type's data heirarchy
     *  and load the child data_hash values into working table ICA_DATA_HASH for later processing at the end of 
     *  the loop.
     */
    <<key_loop>>
    FOR key_hash IN (SELECT ica_key_hash.key_hash FROM ica_key_hash) LOOP
    
      /* Flush the prior payload's data_hash values */
      DELETE FROM ica_data_hash;

      IF payload_type.table_name = 'ICA_CMPL_MON_STRGY' AND v_enabled = 'Y' THEN

         -- /ICA_CMPL_MON_STRGY
         INSERT INTO ica_data_hash
              SELECT ica_cmpl_mon_strgy.data_hash
                FROM ica_cmpl_mon_strgy
               WHERE ica_cmpl_mon_strgy.key_hash = key_hash.key_hash;

      END IF;

      IF payload_type.table_name = 'ICA_DA_CMPL_MON' AND v_enabled = 'Y' THEN

         -- /ICA_DA_CMPL_MON
         INSERT INTO ica_data_hash
              SELECT ica_da_cmpl_mon.data_hash
                FROM ica_da_cmpl_mon
               WHERE ica_da_cmpl_mon.key_hash = key_hash.key_hash;

         -- /ICA_DA_CMPL_MON/ICA_CMPL_INSP_TYPE
         INSERT INTO ica_data_hash
              SELECT ica_cmpl_insp_type.data_hash
                FROM ica_da_cmpl_mon
                JOIN ica_cmpl_insp_type
                  ON ica_cmpl_insp_type.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
               WHERE ica_da_cmpl_mon.key_hash = key_hash.key_hash;

         -- /ICA_DA_CMPL_MON/ICA_CNTCT
         INSERT INTO ica_data_hash
              SELECT ica_cntct.data_hash
                FROM ica_da_cmpl_mon
                JOIN ica_cntct
                  ON ica_cntct.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
               WHERE ica_da_cmpl_mon.key_hash = key_hash.key_hash;

         -- /ICA_DA_CMPL_MON/ICA_CNTCT/ICA_TELEPH
         INSERT INTO ica_data_hash
              SELECT ica_teleph.data_hash
                FROM ica_da_cmpl_mon
                JOIN ica_cntct
                  ON ica_cntct.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
                JOIN ica_teleph
                  ON ica_teleph.ica_cntct_id = ica_cntct.ica_cntct_id
               WHERE ica_da_cmpl_mon.key_hash = key_hash.key_hash;

         -- /ICA_DA_CMPL_MON/ICA_FAC_IDENT
         INSERT INTO ica_data_hash
              SELECT ica_fac_ident.data_hash
                FROM ica_da_cmpl_mon
                JOIN ica_fac_ident
                  ON ica_fac_ident.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
               WHERE ica_da_cmpl_mon.key_hash = key_hash.key_hash;

         -- /ICA_DA_CMPL_MON/ICA_INSP_CMNT_TXT
         INSERT INTO ica_data_hash
              SELECT ica_insp_cmnt_txt.data_hash
                FROM ica_da_cmpl_mon
                JOIN ica_insp_cmnt_txt
                  ON ica_insp_cmnt_txt.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
               WHERE ica_da_cmpl_mon.key_hash = key_hash.key_hash;

         -- /ICA_DA_CMPL_MON/ICA_INSP_GOV_CNTCT
         INSERT INTO ica_data_hash
              SELECT ica_insp_gov_cntct.data_hash
                FROM ica_da_cmpl_mon
                JOIN ica_insp_gov_cntct
                  ON ica_insp_gov_cntct.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
               WHERE ica_da_cmpl_mon.key_hash = key_hash.key_hash;

         -- /ICA_DA_CMPL_MON/ICA_NAT_PRIO
         INSERT INTO ica_data_hash
              SELECT ica_nat_prio.data_hash
                FROM ica_da_cmpl_mon
                JOIN ica_nat_prio
                  ON ica_nat_prio.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
               WHERE ica_da_cmpl_mon.key_hash = key_hash.key_hash;

         -- /ICA_DA_CMPL_MON/ICA_POLUT
         INSERT INTO ica_data_hash
              SELECT ica_polut.data_hash
                FROM ica_da_cmpl_mon
                JOIN ica_polut
                  ON ica_polut.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
               WHERE ica_da_cmpl_mon.key_hash = key_hash.key_hash;

         -- /ICA_DA_CMPL_MON/ICA_PROG
         INSERT INTO ica_data_hash
              SELECT ica_prog.data_hash
                FROM ica_da_cmpl_mon
                JOIN ica_prog
                  ON ica_prog.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
               WHERE ica_da_cmpl_mon.key_hash = key_hash.key_hash;

         -- /ICA_DA_CMPL_MON/ICA_RGNL_PRIO
         INSERT INTO ica_data_hash
              SELECT ica_rgnl_prio.data_hash
                FROM ica_da_cmpl_mon
                JOIN ica_rgnl_prio
                  ON ica_rgnl_prio.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
               WHERE ica_da_cmpl_mon.key_hash = key_hash.key_hash;

         -- /ICA_DA_CMPL_MON/ICA_SENS_CMNT_TXT
         INSERT INTO ica_data_hash
              SELECT ica_sens_cmnt_txt.data_hash
                FROM ica_da_cmpl_mon
                JOIN ica_sens_cmnt_txt
                  ON ica_sens_cmnt_txt.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
               WHERE ica_da_cmpl_mon.key_hash = key_hash.key_hash;

         -- /ICA_DA_CMPL_MON/ICA_STCK_TST
         INSERT INTO ica_data_hash
              SELECT ica_stck_tst.data_hash
                FROM ica_da_cmpl_mon
                JOIN ica_stck_tst
                  ON ica_stck_tst.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
               WHERE ica_da_cmpl_mon.key_hash = key_hash.key_hash;

         -- /ICA_DA_CMPL_MON/ICA_STCK_TST/ICA_STCK_TST_OBS_AGNCY_TYPE
         INSERT INTO ica_data_hash
              SELECT ica_stck_tst_obs_agncy_type.data_hash
                FROM ica_da_cmpl_mon
                JOIN ica_stck_tst
                  ON ica_stck_tst.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
                JOIN ica_stck_tst_obs_agncy_type
                  ON ica_stck_tst_obs_agncy_type.ica_stck_tst_id = ica_stck_tst.ica_stck_tst_id
               WHERE ica_da_cmpl_mon.key_hash = key_hash.key_hash;

         -- /ICA_DA_CMPL_MON/ICA_STCK_TST/ICA_STCK_TST_PURPOSE
         INSERT INTO ica_data_hash
              SELECT ica_stck_tst_purpose.data_hash
                FROM ica_da_cmpl_mon
                JOIN ica_stck_tst
                  ON ica_stck_tst.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
                JOIN ica_stck_tst_purpose
                  ON ica_stck_tst_purpose.ica_stck_tst_id = ica_stck_tst.ica_stck_tst_id
               WHERE ica_da_cmpl_mon.key_hash = key_hash.key_hash;

         -- /ICA_DA_CMPL_MON/ICA_STCK_TST/ICA_TST_RSLTS
         INSERT INTO ica_data_hash
              SELECT ica_tst_rslts.data_hash
                FROM ica_da_cmpl_mon
                JOIN ica_stck_tst
                  ON ica_stck_tst.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
                JOIN ica_tst_rslts
                  ON ica_tst_rslts.ica_stck_tst_id = ica_stck_tst.ica_stck_tst_id
               WHERE ica_da_cmpl_mon.key_hash = key_hash.key_hash;

         -- /ICA_DA_CMPL_MON/ICA_STCK_TST/ICA_TST_RSLTS/ICA_METHOD
         INSERT INTO ica_data_hash
              SELECT ica_method.data_hash
                FROM ica_da_cmpl_mon
                JOIN ica_stck_tst
                  ON ica_stck_tst.ica_da_cmpl_mon_id = ica_da_cmpl_mon.ica_da_cmpl_mon_id
                JOIN ica_tst_rslts
                  ON ica_tst_rslts.ica_stck_tst_id = ica_stck_tst.ica_stck_tst_id
                JOIN ica_method
                  ON ica_method.ica_tst_rslts_id = ica_tst_rslts.ica_tst_rslts_id
               WHERE ica_da_cmpl_mon.key_hash = key_hash.key_hash;

      END IF;

      IF payload_type.table_name = 'ICA_DA_ENFRC_ACTN_MILSTN' AND v_enabled = 'Y' THEN

         -- /ICA_DA_ENFRC_ACTN_MILSTN
         INSERT INTO ica_data_hash
              SELECT ica_da_enfrc_actn_milstn.data_hash
                FROM ica_da_enfrc_actn_milstn
               WHERE ica_da_enfrc_actn_milstn.key_hash = key_hash.key_hash;

      END IF;

      IF payload_type.table_name = 'ICA_DA_FRML_ENFRC_ACTN' AND v_enabled = 'Y' THEN

         -- /ICA_DA_FRML_ENFRC_ACTN
         INSERT INTO ica_data_hash
              SELECT ica_da_frml_enfrc_actn.data_hash
                FROM ica_da_frml_enfrc_actn
               WHERE ica_da_frml_enfrc_actn.key_hash = key_hash.key_hash;

         -- /ICA_DA_FRML_ENFRC_ACTN/ICA_DA_FINAL_ORDER
         INSERT INTO ica_data_hash
              SELECT ica_da_final_order.data_hash
                FROM ica_da_frml_enfrc_actn
                JOIN ica_da_final_order
                  ON ica_da_final_order.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
               WHERE ica_da_frml_enfrc_actn.key_hash = key_hash.key_hash;

         -- /ICA_DA_FRML_ENFRC_ACTN/ICA_DA_FINAL_ORDER/ICA_FINAL_ORDER_FAC_IDENT
         INSERT INTO ica_data_hash
              SELECT ica_final_order_fac_ident.data_hash
                FROM ica_da_frml_enfrc_actn
                JOIN ica_da_final_order
                  ON ica_da_final_order.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
                JOIN ica_final_order_fac_ident
                  ON ica_final_order_fac_ident.ica_da_final_order_id = ica_da_final_order.ica_da_final_order_id
               WHERE ica_da_frml_enfrc_actn.key_hash = key_hash.key_hash;

         -- /ICA_DA_FRML_ENFRC_ACTN/ICA_ENFRC_ACTN_CMNT_TXT
         INSERT INTO ica_data_hash
              SELECT ica_enfrc_actn_cmnt_txt.data_hash
                FROM ica_da_frml_enfrc_actn
                JOIN ica_enfrc_actn_cmnt_txt
                  ON ica_enfrc_actn_cmnt_txt.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
               WHERE ica_da_frml_enfrc_actn.key_hash = key_hash.key_hash;

         -- /ICA_DA_FRML_ENFRC_ACTN/ICA_ENFRC_ACTN_GOV_CNTCT
         INSERT INTO ica_data_hash
              SELECT ica_enfrc_actn_gov_cntct.data_hash
                FROM ica_da_frml_enfrc_actn
                JOIN ica_enfrc_actn_gov_cntct
                  ON ica_enfrc_actn_gov_cntct.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
               WHERE ica_da_frml_enfrc_actn.key_hash = key_hash.key_hash;

         -- /ICA_DA_FRML_ENFRC_ACTN/ICA_ENFRC_ACTN_TYPE
         INSERT INTO ica_data_hash
              SELECT ica_enfrc_actn_type.data_hash
                FROM ica_da_frml_enfrc_actn
                JOIN ica_enfrc_actn_type
                  ON ica_enfrc_actn_type.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
               WHERE ica_da_frml_enfrc_actn.key_hash = key_hash.key_hash;

         -- /ICA_DA_FRML_ENFRC_ACTN/ICA_ENFRC_AGNCY_TYPE
         INSERT INTO ica_data_hash
              SELECT ica_enfrc_agncy_type.data_hash
                FROM ica_da_frml_enfrc_actn
                JOIN ica_enfrc_agncy_type
                  ON ica_enfrc_agncy_type.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
               WHERE ica_da_frml_enfrc_actn.key_hash = key_hash.key_hash;

         -- /ICA_DA_FRML_ENFRC_ACTN/ICA_FAC_IDENT
         INSERT INTO ica_data_hash
              SELECT ica_fac_ident.data_hash
                FROM ica_da_frml_enfrc_actn
                JOIN ica_fac_ident
                  ON ica_fac_ident.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
               WHERE ica_da_frml_enfrc_actn.key_hash = key_hash.key_hash;

         -- /ICA_DA_FRML_ENFRC_ACTN/ICA_POLUT
         INSERT INTO ica_data_hash
              SELECT ica_polut.data_hash
                FROM ica_da_frml_enfrc_actn
                JOIN ica_polut
                  ON ica_polut.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
               WHERE ica_da_frml_enfrc_actn.key_hash = key_hash.key_hash;

         -- /ICA_DA_FRML_ENFRC_ACTN/ICA_PROGS_VIOL
         INSERT INTO ica_data_hash
              SELECT ica_progs_viol.data_hash
                FROM ica_da_frml_enfrc_actn
                JOIN ica_progs_viol
                  ON ica_progs_viol.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
               WHERE ica_da_frml_enfrc_actn.key_hash = key_hash.key_hash;

         -- /ICA_DA_FRML_ENFRC_ACTN/ICA_SENS_CMNT_TXT
         INSERT INTO ica_data_hash
              SELECT ica_sens_cmnt_txt.data_hash
                FROM ica_da_frml_enfrc_actn
                JOIN ica_sens_cmnt_txt
                  ON ica_sens_cmnt_txt.ica_da_frml_enfrc_actn_id = ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
               WHERE ica_da_frml_enfrc_actn.key_hash = key_hash.key_hash;

      END IF;

      IF payload_type.table_name = 'ICA_DA_INFRML_ENFRC_ACTN' AND v_enabled = 'Y' THEN

         -- /ICA_DA_INFRML_ENFRC_ACTN
         INSERT INTO ica_data_hash
              SELECT ica_da_infrml_enfrc_actn.data_hash
                FROM ica_da_infrml_enfrc_actn
               WHERE ica_da_infrml_enfrc_actn.key_hash = key_hash.key_hash;

         -- /ICA_DA_INFRML_ENFRC_ACTN/ICA_ENFRC_ACTN_GOV_CNTCT
         INSERT INTO ica_data_hash
              SELECT ica_enfrc_actn_gov_cntct.data_hash
                FROM ica_da_infrml_enfrc_actn
                JOIN ica_enfrc_actn_gov_cntct
                  ON ica_enfrc_actn_gov_cntct.ica_da_infrml_enfrc_actn_id = ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
               WHERE ica_da_infrml_enfrc_actn.key_hash = key_hash.key_hash;

         -- /ICA_DA_INFRML_ENFRC_ACTN/ICA_ENFRC_AGNCY_TYPE
         INSERT INTO ica_data_hash
              SELECT ica_enfrc_agncy_type.data_hash
                FROM ica_da_infrml_enfrc_actn
                JOIN ica_enfrc_agncy_type
                  ON ica_enfrc_agncy_type.ica_da_infrml_enfrc_actn_id = ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
               WHERE ica_da_infrml_enfrc_actn.key_hash = key_hash.key_hash;

         -- /ICA_DA_INFRML_ENFRC_ACTN/ICA_FAC_IDENT
         INSERT INTO ica_data_hash
              SELECT ica_fac_ident.data_hash
                FROM ica_da_infrml_enfrc_actn
                JOIN ica_fac_ident
                  ON ica_fac_ident.ica_da_infrml_enfrc_actn_id = ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
               WHERE ica_da_infrml_enfrc_actn.key_hash = key_hash.key_hash;

         -- /ICA_DA_INFRML_ENFRC_ACTN/ICA_INFRML_EA_CMNT_TXT
         INSERT INTO ica_data_hash
              SELECT ica_infrml_ea_cmnt_txt.data_hash
                FROM ica_da_infrml_enfrc_actn
                JOIN ica_infrml_ea_cmnt_txt
                  ON ica_infrml_ea_cmnt_txt.ica_da_infrml_enfrc_actn_id = ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
               WHERE ica_da_infrml_enfrc_actn.key_hash = key_hash.key_hash;

         -- /ICA_DA_INFRML_ENFRC_ACTN/ICA_POLUT
         INSERT INTO ica_data_hash
              SELECT ica_polut.data_hash
                FROM ica_da_infrml_enfrc_actn
                JOIN ica_polut
                  ON ica_polut.ica_da_infrml_enfrc_actn_id = ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
               WHERE ica_da_infrml_enfrc_actn.key_hash = key_hash.key_hash;

         -- /ICA_DA_INFRML_ENFRC_ACTN/ICA_PROGS_VIOL
         INSERT INTO ica_data_hash
              SELECT ica_progs_viol.data_hash
                FROM ica_da_infrml_enfrc_actn
                JOIN ica_progs_viol
                  ON ica_progs_viol.ica_da_infrml_enfrc_actn_id = ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
               WHERE ica_da_infrml_enfrc_actn.key_hash = key_hash.key_hash;

         -- /ICA_DA_INFRML_ENFRC_ACTN/ICA_SENS_CMNT_TXT
         INSERT INTO ica_data_hash
              SELECT ica_sens_cmnt_txt.data_hash
                FROM ica_da_infrml_enfrc_actn
                JOIN ica_sens_cmnt_txt
                  ON ica_sens_cmnt_txt.ica_da_infrml_enfrc_actn_id = ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
               WHERE ica_da_infrml_enfrc_actn.key_hash = key_hash.key_hash;

      END IF;

      IF payload_type.table_name = 'ICA_FAC' AND v_enabled = 'Y' THEN

         -- /ICA_FAC
         INSERT INTO ica_data_hash
              SELECT ica_fac.data_hash
                FROM ica_fac
               WHERE ica_fac.key_hash = key_hash.key_hash;

         -- /ICA_FAC/ICA_CNTCT
         INSERT INTO ica_data_hash
              SELECT ica_cntct.data_hash
                FROM ica_fac
                JOIN ica_cntct
                  ON ica_cntct.ica_fac_id = ica_fac.ica_fac_id
               WHERE ica_fac.key_hash = key_hash.key_hash;

         -- /ICA_FAC/ICA_CNTCT/ICA_TELEPH
         INSERT INTO ica_data_hash
              SELECT ica_teleph.data_hash
                FROM ica_fac
                JOIN ica_cntct
                  ON ica_cntct.ica_fac_id = ica_fac.ica_fac_id
                JOIN ica_teleph
                  ON ica_teleph.ica_cntct_id = ica_cntct.ica_cntct_id
               WHERE ica_fac.key_hash = key_hash.key_hash;

         -- /ICA_FAC/ICA_FAC_ADDR
         INSERT INTO ica_data_hash
              SELECT ica_fac_addr.data_hash
                FROM ica_fac
                JOIN ica_fac_addr
                  ON ica_fac_addr.ica_fac_id = ica_fac.ica_fac_id
               WHERE ica_fac.key_hash = key_hash.key_hash;

         -- /ICA_FAC/ICA_FAC_ADDR/ICA_TELEPH
         INSERT INTO ica_data_hash
              SELECT ica_teleph.data_hash
                FROM ica_fac
                JOIN ica_fac_addr
                  ON ica_fac_addr.ica_fac_id = ica_fac.ica_fac_id
                JOIN ica_teleph
                  ON ica_teleph.ica_fac_addr_id = ica_fac_addr.ica_fac_addr_id
               WHERE ica_fac.key_hash = key_hash.key_hash;

         -- /ICA_FAC/ICA_GEO_COORD
         INSERT INTO ica_data_hash
              SELECT ica_geo_coord.data_hash
                FROM ica_fac
                JOIN ica_geo_coord
                  ON ica_geo_coord.ica_fac_id = ica_fac.ica_fac_id
               WHERE ica_fac.key_hash = key_hash.key_hash;

         -- /ICA_FAC/ICA_NAICS_CODE
         INSERT INTO ica_data_hash
              SELECT ica_naics_code.data_hash
                FROM ica_fac
                JOIN ica_naics_code
                  ON ica_naics_code.ica_fac_id = ica_fac.ica_fac_id
               WHERE ica_fac.key_hash = key_hash.key_hash;

         -- /ICA_FAC/ICA_PORT_SRC
         INSERT INTO ica_data_hash
              SELECT ica_port_src.data_hash
                FROM ica_fac
                JOIN ica_port_src
                  ON ica_port_src.ica_fac_id = ica_fac.ica_fac_id
               WHERE ica_fac.key_hash = key_hash.key_hash;

         -- /ICA_FAC/ICA_SIC_CODE
         INSERT INTO ica_data_hash
              SELECT ica_sic_code.data_hash
                FROM ica_fac
                JOIN ica_sic_code
                  ON ica_sic_code.ica_fac_id = ica_fac.ica_fac_id
               WHERE ica_fac.key_hash = key_hash.key_hash;

         -- /ICA_FAC/ICA_UNIVERSE_IND
         INSERT INTO ica_data_hash
              SELECT ica_universe_ind.data_hash
                FROM ica_fac
                JOIN ica_universe_ind
                  ON ica_universe_ind.ica_fac_id = ica_fac.ica_fac_id
               WHERE ica_fac.key_hash = key_hash.key_hash;

      END IF;

      IF payload_type.table_name = 'ICA_POLUTS' AND v_enabled = 'Y' THEN

         -- /ICA_POLUTS
         INSERT INTO ica_data_hash
              SELECT ica_poluts.data_hash
                FROM ica_poluts
               WHERE ica_poluts.key_hash = key_hash.key_hash;

         -- /ICA_POLUTS/ICA_POLUT_DA_CLASS
         INSERT INTO ica_data_hash
              SELECT ica_polut_da_class.data_hash
                FROM ica_poluts
                JOIN ica_polut_da_class
                  ON ica_polut_da_class.ica_poluts_id = ica_poluts.ica_poluts_id
               WHERE ica_poluts.key_hash = key_hash.key_hash;

         -- /ICA_POLUTS/ICA_POLUT_EPA_CLASS
         INSERT INTO ica_data_hash
              SELECT ica_polut_epa_class.data_hash
                FROM ica_poluts
                JOIN ica_polut_epa_class
                  ON ica_polut_epa_class.ica_poluts_id = ica_poluts.ica_poluts_id
               WHERE ica_poluts.key_hash = key_hash.key_hash;

      END IF;

      IF payload_type.table_name = 'ICA_PROGS' AND v_enabled = 'Y' THEN

         -- /ICA_PROGS
         INSERT INTO ica_data_hash
              SELECT ica_progs.data_hash
                FROM ica_progs
               WHERE ica_progs.key_hash = key_hash.key_hash;

         -- /ICA_PROGS/ICA_PROG_SUBPART
         INSERT INTO ica_data_hash
              SELECT ica_prog_subpart.data_hash
                FROM ica_progs
                JOIN ica_prog_subpart
                  ON ica_prog_subpart.ica_progs_id = ica_progs.ica_progs_id
               WHERE ica_progs.key_hash = key_hash.key_hash;

      END IF;

      IF payload_type.table_name = 'ICA_TVACC' AND v_enabled = 'Y' THEN

         -- /ICA_TVACC
         INSERT INTO ica_data_hash
              SELECT ica_tvacc.data_hash
                FROM ica_tvacc
               WHERE ica_tvacc.key_hash = key_hash.key_hash;

         -- /ICA_TVACC/ICA_CNTCT
         INSERT INTO ica_data_hash
              SELECT ica_cntct.data_hash
                FROM ica_tvacc
                JOIN ica_cntct
                  ON ica_cntct.ica_tvacc_id = ica_tvacc.ica_tvacc_id
               WHERE ica_tvacc.key_hash = key_hash.key_hash;

         -- /ICA_TVACC/ICA_CNTCT/ICA_TELEPH
         INSERT INTO ica_data_hash
              SELECT ica_teleph.data_hash
                FROM ica_tvacc
                JOIN ica_cntct
                  ON ica_cntct.ica_tvacc_id = ica_tvacc.ica_tvacc_id
                JOIN ica_teleph
                  ON ica_teleph.ica_cntct_id = ica_cntct.ica_cntct_id
               WHERE ica_tvacc.key_hash = key_hash.key_hash;

         -- /ICA_TVACC/ICA_INSP_CMNT_TXT
         INSERT INTO ica_data_hash
              SELECT ica_insp_cmnt_txt.data_hash
                FROM ica_tvacc
                JOIN ica_insp_cmnt_txt
                  ON ica_insp_cmnt_txt.ica_tvacc_id = ica_tvacc.ica_tvacc_id
               WHERE ica_tvacc.key_hash = key_hash.key_hash;

         -- /ICA_TVACC/ICA_INSP_GOV_CNTCT
         INSERT INTO ica_data_hash
              SELECT ica_insp_gov_cntct.data_hash
                FROM ica_tvacc
                JOIN ica_insp_gov_cntct
                  ON ica_insp_gov_cntct.ica_tvacc_id = ica_tvacc.ica_tvacc_id
               WHERE ica_tvacc.key_hash = key_hash.key_hash;

         -- /ICA_TVACC/ICA_NAT_PRIO
         INSERT INTO ica_data_hash
              SELECT ica_nat_prio.data_hash
                FROM ica_tvacc
                JOIN ica_nat_prio
                  ON ica_nat_prio.ica_tvacc_id = ica_tvacc.ica_tvacc_id
               WHERE ica_tvacc.key_hash = key_hash.key_hash;

         -- /ICA_TVACC/ICA_POLUT
         INSERT INTO ica_data_hash
              SELECT ica_polut.data_hash
                FROM ica_tvacc
                JOIN ica_polut
                  ON ica_polut.ica_tvacc_id = ica_tvacc.ica_tvacc_id
               WHERE ica_tvacc.key_hash = key_hash.key_hash;

         -- /ICA_TVACC/ICA_PROG
         INSERT INTO ica_data_hash
              SELECT ica_prog.data_hash
                FROM ica_tvacc
                JOIN ica_prog
                  ON ica_prog.ica_tvacc_id = ica_tvacc.ica_tvacc_id
               WHERE ica_tvacc.key_hash = key_hash.key_hash;

         -- /ICA_TVACC/ICA_RGNL_PRIO
         INSERT INTO ica_data_hash
              SELECT ica_rgnl_prio.data_hash
                FROM ica_tvacc
                JOIN ica_rgnl_prio
                  ON ica_rgnl_prio.ica_tvacc_id = ica_tvacc.ica_tvacc_id
               WHERE ica_tvacc.key_hash = key_hash.key_hash;

         -- /ICA_TVACC/ICA_SENS_CMNT_TXT
         INSERT INTO ica_data_hash
              SELECT ica_sens_cmnt_txt.data_hash
                FROM ica_tvacc
                JOIN ica_sens_cmnt_txt
                  ON ica_sens_cmnt_txt.ica_tvacc_id = ica_tvacc.ica_tvacc_id
               WHERE ica_tvacc.key_hash = key_hash.key_hash;

         -- /ICA_TVACC/ICA_TVACC_REVIEW
         INSERT INTO ica_data_hash
              SELECT ica_tvacc_review.data_hash
                FROM ica_tvacc
                JOIN ica_tvacc_review
                  ON ica_tvacc_review.ica_tvacc_id = ica_tvacc.ica_tvacc_id
               WHERE ica_tvacc.key_hash = key_hash.key_hash;

      END IF;

      IF payload_type.table_name = 'ICA_DA_CASE_FILE' AND v_enabled = 'Y' THEN

         -- /ICA_DA_CASE_FILE
         INSERT INTO ica_data_hash
              SELECT ica_da_case_file.data_hash
                FROM ica_da_case_file
               WHERE ica_da_case_file.key_hash = key_hash.key_hash;

         -- /ICA_DA_CASE_FILE/ICA_CASE_FILE_CMNT_TXT
         INSERT INTO ica_data_hash
              SELECT ica_case_file_cmnt_txt.data_hash
                FROM ica_da_case_file
                JOIN ica_case_file_cmnt_txt
                  ON ica_case_file_cmnt_txt.ica_da_case_file_id = ica_da_case_file.ica_da_case_file_id
               WHERE ica_da_case_file.key_hash = key_hash.key_hash;

         -- /ICA_DA_CASE_FILE/ICA_OTHR_PATHWAY_ACTY
         INSERT INTO ica_data_hash
              SELECT ica_othr_pathway_acty.data_hash
                FROM ica_da_case_file
                JOIN ica_othr_pathway_acty
                  ON ica_othr_pathway_acty.ica_da_case_file_id = ica_da_case_file.ica_da_case_file_id
               WHERE ica_da_case_file.key_hash = key_hash.key_hash;

         -- /ICA_DA_CASE_FILE/ICA_POLUT
         INSERT INTO ica_data_hash
              SELECT ica_polut.data_hash
                FROM ica_da_case_file
                JOIN ica_polut
                  ON ica_polut.ica_da_case_file_id = ica_da_case_file.ica_da_case_file_id
               WHERE ica_da_case_file.key_hash = key_hash.key_hash;

         -- /ICA_DA_CASE_FILE/ICA_PROG
         INSERT INTO ica_data_hash
              SELECT ica_prog.data_hash
                FROM ica_da_case_file
                JOIN ica_prog
                  ON ica_prog.ica_da_case_file_id = ica_da_case_file.ica_da_case_file_id
               WHERE ica_da_case_file.key_hash = key_hash.key_hash;

         -- /ICA_DA_CASE_FILE/ICA_SENS_CMNT_TXT
         INSERT INTO ica_data_hash
              SELECT ica_sens_cmnt_txt.data_hash
                FROM ica_da_case_file
                JOIN ica_sens_cmnt_txt
                  ON ica_sens_cmnt_txt.ica_da_case_file_id = ica_da_case_file.ica_da_case_file_id
               WHERE ica_da_case_file.key_hash = key_hash.key_hash;

         -- /ICA_DA_CASE_FILE/ICA_VIOL
         INSERT INTO ica_data_hash
              SELECT ica_viol.data_hash
                FROM ica_da_case_file
                JOIN ica_viol
                  ON ica_viol.ica_da_case_file_id = ica_da_case_file.ica_da_case_file_id
               WHERE ica_da_case_file.key_hash = key_hash.key_hash;

      END IF;

      IF payload_type.table_name = 'ICA_DA_ENFRC_ACTN_LNK' AND v_enabled = 'Y' THEN

         -- /ICA_DA_ENFRC_ACTN_LNK
         INSERT INTO ica_data_hash
              SELECT ica_da_enfrc_actn_lnk.data_hash
                FROM ica_da_enfrc_actn_lnk
               WHERE ica_da_enfrc_actn_lnk.key_hash = key_hash.key_hash;

         -- /ICA_DA_ENFRC_ACTN_LNK/ICA_LNK_DA_ENFRC_ACTN
         INSERT INTO ica_data_hash
              SELECT ica_lnk_da_enfrc_actn.data_hash
                FROM ica_da_enfrc_actn_lnk
                JOIN ica_lnk_da_enfrc_actn
                  ON ica_lnk_da_enfrc_actn.ica_da_enfrc_actn_lnk_id = ica_da_enfrc_actn_lnk.ica_da_enfrc_actn_lnk_id
               WHERE ica_da_enfrc_actn_lnk.key_hash = key_hash.key_hash;

      END IF;

      IF payload_type.table_name = 'ICA_CASE_FILE_LNK' AND v_enabled = 'Y' THEN

         -- /ICA_CASE_FILE_LNK
         INSERT INTO ica_data_hash
              SELECT ica_case_file_lnk.data_hash
                FROM ica_case_file_lnk
               WHERE ica_case_file_lnk.key_hash = key_hash.key_hash;

         -- /ICA_CASE_FILE_LNK/ICA_LNK_CASE_FILE
         INSERT INTO ica_data_hash
              SELECT ica_lnk_case_file.data_hash
                FROM ica_case_file_lnk
                JOIN ica_lnk_case_file
                  ON ica_lnk_case_file.ica_case_file_lnk_id = ica_case_file_lnk.ica_case_file_lnk_id
               WHERE ica_case_file_lnk.key_hash = key_hash.key_hash;

         -- /ICA_CASE_FILE_LNK/ICA_LNK_CMPL_MON
         INSERT INTO ica_data_hash
              SELECT ica_lnk_cmpl_mon.data_hash
                FROM ica_case_file_lnk
                JOIN ica_lnk_cmpl_mon
                  ON ica_lnk_cmpl_mon.ica_case_file_lnk_id = ica_case_file_lnk.ica_case_file_lnk_id
               WHERE ica_case_file_lnk.key_hash = key_hash.key_hash;

         -- /ICA_CASE_FILE_LNK/ICA_LNK_DA_ENFRC_ACTN
         INSERT INTO ica_data_hash
              SELECT ica_lnk_da_enfrc_actn.data_hash
                FROM ica_case_file_lnk
                JOIN ica_lnk_da_enfrc_actn
                  ON ica_lnk_da_enfrc_actn.ica_case_file_lnk_id = ica_case_file_lnk.ica_case_file_lnk_id
               WHERE ica_case_file_lnk.key_hash = key_hash.key_hash;

      END IF;

      IF payload_type.table_name = 'ICA_CMPL_MON_LNK' AND v_enabled = 'Y' THEN

         -- /ICA_CMPL_MON_LNK
         INSERT INTO ica_data_hash
              SELECT ica_cmpl_mon_lnk.data_hash
                FROM ica_cmpl_mon_lnk
               WHERE ica_cmpl_mon_lnk.key_hash = key_hash.key_hash;

         -- /ICA_CMPL_MON_LNK/ICA_LNK_CMPL_MON
         INSERT INTO ica_data_hash
              SELECT ica_lnk_cmpl_mon.data_hash
                FROM ica_cmpl_mon_lnk
                JOIN ica_lnk_cmpl_mon
                  ON ica_lnk_cmpl_mon.ica_cmpl_mon_lnk_id = ica_cmpl_mon_lnk.ica_cmpl_mon_lnk_id
               WHERE ica_cmpl_mon_lnk.key_hash = key_hash.key_hash;

         -- /ICA_CMPL_MON_LNK/ICA_LNK_DA_ENFRC_ACTN
         INSERT INTO ica_data_hash
              SELECT ica_lnk_da_enfrc_actn.data_hash
                FROM ica_cmpl_mon_lnk
                JOIN ica_lnk_da_enfrc_actn
                  ON ica_lnk_da_enfrc_actn.ica_cmpl_mon_lnk_id = ica_cmpl_mon_lnk.ica_cmpl_mon_lnk_id
               WHERE ica_cmpl_mon_lnk.key_hash = key_hash.key_hash;

      END IF;

     /*  
      *  Loop through each data_hash value loaded into ICA_DATA_HASH, for each, rehash each data_hash values together to create 
      *  a single data_hash value that represents all the non-key data contained within a payload type / key_hash combination.
      */
      <<data_loop>>
      v_all_data_hashes := NULL;
      FOR data_hash IN (SELECT ica_data_hash.data_hash FROM ica_data_hash ORDER BY data_hash)  LOOP
      
        /* Append each data hash together into one string value.. */
        SELECT MD5_HASH(v_all_data_hashes || data_hash.data_hash)
          INTO v_all_data_hashes
          FROM DUAL;
          
      END LOOP data_loop;
        
      /*  Hash the entire set of data_hash values organized into a single string. */
      v_hashed_data_hashes := NULL;
      SELECT NVL(MD5_HASH(v_all_data_hashes),0) 
        INTO v_hashed_data_hashes 
        FROM DUAL;
                 
      /*  Load the rehashed value into the payload type table's data_hash column. */
      v_sql_statement := 'UPDATE ' || payload_type.table_name || ' SET data_hash = ''' || v_hashed_data_hashes || ''' WHERE key_hash = ''' || key_hash.key_hash || '''';
      EXECUTE IMMEDIATE v_sql_statement;                      
                       
    END LOOP key_loop;    
    
  END LOOP module_loop;
   

  /******************************************************************************************************************************
  ** Description:  The following code sets the new, change, replace, etc... ica transaction_type flags throughout the entire ICA 
  **               schema.  Once these flags are set the data will be marked as either new, changed and will allow the OPENNODE2 
  **               plug-in the ability to pull the data, bundle into .xml, and then submit to an exchange partner.
  ******************************************************************************************************************************/
  -- ICA_CMPL_MON_STRGY - Set New/Replace Transactions
  UPDATE ica_cmpl_mon_strgy
     SET ica_cmpl_mon_strgy.transaction_type = (SELECT CASE cdv_cmpl_mon_strgy.action_code
                                                       WHEN 1 THEN 'R'
                                                       WHEN 2 THEN 'R'
                                                      END AS transaction_type
                                                FROM cdv_cmpl_mon_strgy
                                               WHERE cdv_cmpl_mon_strgy.key_hash = ica_cmpl_mon_strgy.key_hash);

  -- ICA_DA_CMPL_MON - Set New/Replace Transactions
  UPDATE ica_da_cmpl_mon
     SET ica_da_cmpl_mon.transaction_type = (SELECT CASE cdv_da_cmpl_mon.action_code
                                                       WHEN 1 THEN 'R'
                                                       WHEN 2 THEN 'R'
                                                      END AS transaction_type
                                                FROM cdv_da_cmpl_mon
                                               WHERE cdv_da_cmpl_mon.key_hash = ica_da_cmpl_mon.key_hash);

  -- ICA_DA_ENFRC_ACTN_MILSTN - Set New/Replace Transactions
  UPDATE ica_da_enfrc_actn_milstn
     SET ica_da_enfrc_actn_milstn.transaction_type = (SELECT CASE cdv_da_enfrc_actn_milstn.action_code
                                                       WHEN 1 THEN 'R'
                                                       WHEN 2 THEN 'R'
                                                      END AS transaction_type
                                                FROM cdv_da_enfrc_actn_milstn
                                               WHERE cdv_da_enfrc_actn_milstn.key_hash = ica_da_enfrc_actn_milstn.key_hash);

  -- ICA_DA_FRML_ENFRC_ACTN - Set New/Replace Transactions
  UPDATE ica_da_frml_enfrc_actn
     SET ica_da_frml_enfrc_actn.transaction_type = (SELECT CASE cdv_da_frml_enfrc_actn.action_code
                                                       WHEN 1 THEN 'R'
                                                       WHEN 2 THEN 'R'
                                                      END AS transaction_type
                                                FROM cdv_da_frml_enfrc_actn
                                               WHERE cdv_da_frml_enfrc_actn.key_hash = ica_da_frml_enfrc_actn.key_hash);

  -- ICA_DA_INFRML_ENFRC_ACTN - Set New/Replace Transactions
  UPDATE ica_da_infrml_enfrc_actn
     SET ica_da_infrml_enfrc_actn.transaction_type = (SELECT CASE cdv_da_infrml_enfrc_actn.action_code
                                                       WHEN 1 THEN 'R'
                                                       WHEN 2 THEN 'R'
                                                      END AS transaction_type
                                                FROM cdv_da_infrml_enfrc_actn
                                               WHERE cdv_da_infrml_enfrc_actn.key_hash = ica_da_infrml_enfrc_actn.key_hash);

  -- ICA_FAC - Set New/Replace Transactions
  UPDATE ica_fac
     SET ica_fac.transaction_type = (SELECT CASE cdv_fac.action_code
                                                       WHEN 1 THEN 'R'
                                                       WHEN 2 THEN 'R'
                                                      END AS transaction_type
                                                FROM cdv_fac
                                               WHERE cdv_fac.key_hash = ica_fac.key_hash);

  -- ICA_POLUTS - Set New/Replace Transactions
  UPDATE ica_poluts
     SET ica_poluts.transaction_type = (SELECT CASE cdv_poluts.action_code
                                                       WHEN 1 THEN 'R'
                                                       WHEN 2 THEN 'R'
                                                      END AS transaction_type
                                                FROM cdv_poluts
                                               WHERE cdv_poluts.key_hash = ica_poluts.key_hash);

  -- ICA_PROGS - Set New/Replace Transactions
  UPDATE ica_progs
     SET ica_progs.transaction_type = (SELECT CASE cdv_progs.action_code
                                                       WHEN 1 THEN 'R'
                                                       WHEN 2 THEN 'R'
                                                      END AS transaction_type
                                                FROM cdv_progs
                                               WHERE cdv_progs.key_hash = ica_progs.key_hash);

  -- ICA_TVACC - Set New/Replace Transactions
  UPDATE ica_tvacc
     SET ica_tvacc.transaction_type = (SELECT CASE cdv_tvacc.action_code
                                                       WHEN 1 THEN 'R'
                                                       WHEN 2 THEN 'R'
                                                      END AS transaction_type
                                                FROM cdv_tvacc
                                               WHERE cdv_tvacc.key_hash = ica_tvacc.key_hash);

  -- ICA_DA_CASE_FILE - Set New/Replace Transactions
  UPDATE ica_da_case_file
     SET ica_da_case_file.transaction_type = (SELECT CASE cdv_da_case_file.action_code
                                                       WHEN 1 THEN 'R'
                                                       WHEN 2 THEN 'R'
                                                      END AS transaction_type
                                                FROM cdv_da_case_file
                                               WHERE cdv_da_case_file.key_hash = ica_da_case_file.key_hash);

  -- ICA_DA_ENFRC_ACTN_LNK - Set New/Replace Transactions
  UPDATE ica_da_enfrc_actn_lnk
     SET ica_da_enfrc_actn_lnk.transaction_type = (SELECT CASE cdv_da_enfrc_actn_lnk.action_code
                                                       WHEN 1 THEN 'R'
                                                       WHEN 2 THEN 'R'
                                                      END AS transaction_type
                                                FROM cdv_da_enfrc_actn_lnk
                                               WHERE cdv_da_enfrc_actn_lnk.key_hash = ica_da_enfrc_actn_lnk.key_hash);

  -- ICA_CASE_FILE_LNK - Set New/Replace Transactions
  UPDATE ica_case_file_lnk
     SET ica_case_file_lnk.transaction_type = (SELECT CASE cdv_case_file_lnk.action_code
                                                       WHEN 1 THEN 'R'
                                                       WHEN 2 THEN 'R'
                                                      END AS transaction_type
                                                FROM cdv_case_file_lnk
                                               WHERE cdv_case_file_lnk.key_hash = ica_case_file_lnk.key_hash);

  -- ICA_CMPL_MON_LNK - Set New/Replace Transactions
  UPDATE ica_cmpl_mon_lnk
     SET ica_cmpl_mon_lnk.transaction_type = (SELECT CASE cdv_cmpl_mon_lnk.action_code
                                                       WHEN 1 THEN 'R'
                                                       WHEN 2 THEN 'R'
                                                      END AS transaction_type
                                                FROM cdv_cmpl_mon_lnk
                                               WHERE cdv_cmpl_mon_lnk.key_hash = ica_cmpl_mon_lnk.key_hash);

  -- ICA_CMPL_MON_STRGY - Set Delete Transactions
  INSERT INTO ica_cmpl_mon_strgy
       ( ica_payload_id
       , ica_cmpl_mon_strgy_id
       , transaction_type
       , fac_ident) 
   SELECT ica_cmpl_mon_strgy.ica_payload_id
        , ica_cmpl_mon_strgy.ica_cmpl_mon_strgy_id
        , 'X' AS transaction_type
        , fac_ident
     FROM ica_flow_icis.ica_cmpl_mon_strgy
    WHERE ica_cmpl_mon_strgy.ica_payload_id in (SELECT ica_payload_id 
                           FROM ica_payload 
                          WHERE operation = 'AirComplianceMonitoringStrategySubmission'
                            AND auto_gen_deletes = 'Y')
      AND ica_cmpl_mon_strgy.key_hash IN (SELECT key_hash
                                        FROM cdv_cmpl_mon_strgy
                                       WHERE cdv_cmpl_mon_strgy.action_type = 'DELETE');

  -- ICA_DA_CMPL_MON - Set Delete Transactions
  INSERT INTO ica_da_cmpl_mon
       ( ica_payload_id
       , ica_da_cmpl_mon_id
       , transaction_type
       , cmpl_mon_ident) 
   SELECT ica_da_cmpl_mon.ica_payload_id
        , ica_da_cmpl_mon.ica_da_cmpl_mon_id
        , 'X' AS transaction_type
        , cmpl_mon_ident
     FROM ica_flow_icis.ica_da_cmpl_mon
    WHERE ica_da_cmpl_mon.ica_payload_id in (SELECT ica_payload_id 
                           FROM ica_payload 
                          WHERE operation = 'AirDAComplianceMonitoringSubmission'
                            AND auto_gen_deletes = 'Y')
      AND ica_da_cmpl_mon.key_hash IN (SELECT key_hash
                                        FROM cdv_da_cmpl_mon
                                       WHERE cdv_da_cmpl_mon.action_type = 'DELETE');

  -- ICA_DA_ENFRC_ACTN_MILSTN - Set Delete Transactions
  INSERT INTO ica_da_enfrc_actn_milstn
       ( ica_payload_id
       , ica_da_enfrc_actn_milstn_id
       , transaction_type
       , da_enfrc_actn_ident
       , milstn_type_code) 
   SELECT ica_da_enfrc_actn_milstn.ica_payload_id
        , ica_da_enfrc_actn_milstn.ica_da_enfrc_actn_milstn_id
        , 'X' AS transaction_type
        , da_enfrc_actn_ident
        , milstn_type_code
     FROM ica_flow_icis.ica_da_enfrc_actn_milstn
    WHERE ica_da_enfrc_actn_milstn.ica_payload_id in (SELECT ica_payload_id 
                           FROM ica_payload 
                          WHERE operation = 'AirDAEnforcementActionMilestoneSubmission'
                            AND auto_gen_deletes = 'Y')
      AND ica_da_enfrc_actn_milstn.key_hash IN (SELECT key_hash
                                        FROM cdv_da_enfrc_actn_milstn
                                       WHERE cdv_da_enfrc_actn_milstn.action_type = 'DELETE');

  -- ICA_DA_FRML_ENFRC_ACTN - Set Delete Transactions
  INSERT INTO ica_da_frml_enfrc_actn
       ( ica_payload_id
       , ica_da_frml_enfrc_actn_id
       , transaction_type
       , da_enfrc_actn_ident) 
   SELECT ica_da_frml_enfrc_actn.ica_payload_id
        , ica_da_frml_enfrc_actn.ica_da_frml_enfrc_actn_id
        , 'X' AS transaction_type
        , da_enfrc_actn_ident
     FROM ica_flow_icis.ica_da_frml_enfrc_actn
    WHERE ica_da_frml_enfrc_actn.ica_payload_id in (SELECT ica_payload_id 
                           FROM ica_payload 
                          WHERE operation = 'AirDAFormalEnforcementActionSubmission'
                            AND auto_gen_deletes = 'Y')
      AND ica_da_frml_enfrc_actn.key_hash IN (SELECT key_hash
                                        FROM cdv_da_frml_enfrc_actn
                                       WHERE cdv_da_frml_enfrc_actn.action_type = 'DELETE');

  -- ICA_DA_INFRML_ENFRC_ACTN - Set Delete Transactions
  INSERT INTO ica_da_infrml_enfrc_actn
       ( ica_payload_id
       , ica_da_infrml_enfrc_actn_id
       , transaction_type
       , da_enfrc_actn_ident) 
   SELECT ica_da_infrml_enfrc_actn.ica_payload_id
        , ica_da_infrml_enfrc_actn.ica_da_infrml_enfrc_actn_id
        , 'X' AS transaction_type
        , da_enfrc_actn_ident
     FROM ica_flow_icis.ica_da_infrml_enfrc_actn
    WHERE ica_da_infrml_enfrc_actn.ica_payload_id in (SELECT ica_payload_id 
                           FROM ica_payload 
                          WHERE operation = 'AirDAInformalEnforcementActionSubmission'
                            AND auto_gen_deletes = 'Y')
      AND ica_da_infrml_enfrc_actn.key_hash IN (SELECT key_hash
                                        FROM cdv_da_infrml_enfrc_actn
                                       WHERE cdv_da_infrml_enfrc_actn.action_type = 'DELETE');

  -- ICA_FAC - Set Delete Transactions
  INSERT INTO ica_fac
       ( ica_payload_id
       , ica_fac_id
       , transaction_type
       , fac_ident) 
   SELECT ica_fac.ica_payload_id
        , ica_fac.ica_fac_id
        , 'X' AS transaction_type
        , fac_ident
     FROM ica_flow_icis.ica_fac
    WHERE ica_fac.ica_payload_id in (SELECT ica_payload_id 
                           FROM ica_payload 
                          WHERE operation = 'AirFacilitySubmission'
                            AND auto_gen_deletes = 'Y')
      AND ica_fac.key_hash IN (SELECT key_hash
                                        FROM cdv_fac
                                       WHERE cdv_fac.action_type = 'DELETE');

  -- ICA_POLUTS - Set Delete Transactions
  INSERT INTO ica_poluts
       ( ica_payload_id
       , ica_poluts_id
       , transaction_type
       , fac_ident
       , poluts_code) 
   SELECT ica_poluts.ica_payload_id
        , ica_poluts.ica_poluts_id
        , 'X' AS transaction_type
        , fac_ident
        , poluts_code
     FROM ica_flow_icis.ica_poluts
    WHERE ica_poluts.ica_payload_id in (SELECT ica_payload_id 
                           FROM ica_payload 
                          WHERE operation = 'AirPollutantsSubmission'
                            AND auto_gen_deletes = 'Y')
      AND ica_poluts.key_hash IN (SELECT key_hash
                                        FROM cdv_poluts
                                       WHERE cdv_poluts.action_type = 'DELETE');

  -- ICA_PROGS - Set Delete Transactions
  INSERT INTO ica_progs
       ( ica_payload_id
       , ica_progs_id
       , transaction_type
       , fac_ident
       , prog_code
       , prog_oper_stat_code) 
   SELECT ica_progs.ica_payload_id
        , ica_progs.ica_progs_id
        , 'X' AS transaction_type
        , fac_ident
        , prog_code
        , prog_oper_stat_code
     FROM ica_flow_icis.ica_progs
    WHERE ica_progs.ica_payload_id in (SELECT ica_payload_id 
                           FROM ica_payload 
                          WHERE operation = 'AirProgramsSubmission'
                            AND auto_gen_deletes = 'Y')
      AND ica_progs.key_hash IN (SELECT key_hash
                                        FROM cdv_progs
                                       WHERE cdv_progs.action_type = 'DELETE');



  -- ICA_TVACC - Set Delete Transactions
  INSERT INTO ica_tvacc
       ( ica_payload_id
       , ica_tvacc_id
       , transaction_type
       , cmpl_mon_ident
       , fac_ident)
   SELECT ica_tvacc.ica_payload_id
        , ica_tvacc.ica_tvacc_id
        , 'X' AS transaction_type
        , cmpl_mon_ident
        , fac_ident
     FROM ica_flow_icis.ica_tvacc
    WHERE ica_tvacc.ica_payload_id in (SELECT ica_payload_id 
                           FROM ica_payload 
                          WHERE operation = 'AirTVACCSubmission'
                            AND auto_gen_deletes = 'Y')
      AND ica_tvacc.key_hash IN (SELECT key_hash
                                        FROM cdv_tvacc
                                       WHERE cdv_tvacc.action_type = 'DELETE');

  -- ICA_DA_CASE_FILE - Set Delete Transactions
  INSERT INTO ica_da_case_file
       ( ica_payload_id
       , ica_da_case_file_id
       , transaction_type
       , case_file_ident
       , fac_ident) 
   SELECT ica_da_case_file.ica_payload_id
        , ica_da_case_file.ica_da_case_file_id
        , 'X' AS transaction_type
        , case_file_ident
        , fac_ident
     FROM ica_flow_icis.ica_da_case_file
    WHERE ica_da_case_file.ica_payload_id in (SELECT ica_payload_id 
                           FROM ica_payload 
                          WHERE operation = 'AirDACaseFileSubmission'
                            AND auto_gen_deletes = 'Y')
      AND ica_da_case_file.key_hash IN (SELECT key_hash
                                        FROM cdv_da_case_file
                                       WHERE cdv_da_case_file.action_type = 'DELETE');

  -- ICA_DA_ENFRC_ACTN_LNK - Set Delete Transactions
  INSERT INTO ica_da_enfrc_actn_lnk
       ( ica_payload_id
       , ica_da_enfrc_actn_lnk_id
       , transaction_type
       , da_enfrc_actn_ident) 
   SELECT ica_da_enfrc_actn_lnk.ica_payload_id
        , ica_da_enfrc_actn_lnk.ica_da_enfrc_actn_lnk_id
        , 'X' AS transaction_type
        , da_enfrc_actn_ident
     FROM ica_flow_icis.ica_da_enfrc_actn_lnk
    WHERE ica_da_enfrc_actn_lnk.ica_payload_id in (SELECT ica_payload_id 
                           FROM ica_payload 
                          WHERE operation = 'AirDAEnforcementActionLinkageSubmission'
                            AND auto_gen_deletes = 'Y')
      AND ica_da_enfrc_actn_lnk.key_hash IN (SELECT key_hash
                                        FROM cdv_da_enfrc_actn_lnk
                                       WHERE cdv_da_enfrc_actn_lnk.action_type = 'DELETE');

  -- ICA_CASE_FILE_LNK - Set Delete Transactions
  INSERT INTO ica_case_file_lnk
       ( ica_payload_id
       , ica_case_file_lnk_id
       , transaction_type
       , case_file_ident) 
   SELECT ica_case_file_lnk.ica_payload_id
        , ica_case_file_lnk.ica_case_file_lnk_id
        , 'X' AS transaction_type
        , case_file_ident
     FROM ica_flow_icis.ica_case_file_lnk
    WHERE ica_case_file_lnk.ica_payload_id in (SELECT ica_payload_id 
                                                 FROM ica_payload 
                                                WHERE operation = 'AirDACaseFileLinkageSubmission'
                                                  AND auto_gen_deletes = 'Y')
      AND ica_case_file_lnk.key_hash IN (SELECT key_hash
                                           FROM cdv_case_file_lnk
                                          WHERE cdv_case_file_lnk.action_type = 'DELETE');

  -- ICA_CMPL_MON_LNK - Set Delete Transactions
  INSERT INTO ica_cmpl_mon_lnk
       ( ica_payload_id
       , ica_cmpl_mon_lnk_id
       , transaction_type
       , cmpl_mon_ident) 
   SELECT ica_cmpl_mon_lnk.ica_payload_id
        , ica_cmpl_mon_lnk.ica_cmpl_mon_lnk_id
        , 'X' AS transaction_type
        , cmpl_mon_ident
     FROM ica_flow_icis.ica_cmpl_mon_lnk
    WHERE ica_cmpl_mon_lnk.ica_payload_id in (SELECT ica_payload_id 
                                                FROM ica_payload 
                                               WHERE operation = 'ComplianceMonitoringLinkageSubmission'
                                                 AND auto_gen_deletes = 'Y')
      AND ica_cmpl_mon_lnk.key_hash IN (SELECT key_hash
                                          FROM cdv_cmpl_mon_lnk
                                         WHERE cdv_cmpl_mon_lnk.action_type = 'DELETE');
     
 END;
/