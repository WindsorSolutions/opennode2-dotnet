USE ga_ics_flow_local;
DROP PROCEDURE IF EXISTS ics_cd_updt_ics_tables;
CREATE PROCEDURE ics_cd_updt_ics_tables
   (OUT po_status INT
   ,OUT po_errm   VARCHAR(255))
BEGIN
/******************************************************************************
** ObjectName: ics_cd_updt_ics_tables
**
** Author: Windsor Solutions, Inc.
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure will detect data changes made within the ICIS 
**               schema and then sets the transaction type flags so the data 
**               can be bundled and submitted to an exchange partner.
**
** Inputs:  -- NA --  
**
**
** Revision History:      
** ----------------------------------------------------------------------------
**  Date         Analyst     Description
** ----------------------------------------------------------------------------
** 08/15/2012    BRensmith   Baseline from v3.1 procedure.
**
** 10/29/2012    Jen Go      Converted from Oracle to MySQL
**                           called by: ics_change_detection
**                             1) ics_cd_create_cdv_tables
**                             2) ics_cd_updt_ics_tables
**                             3) ics_cd_process_datahash
**                             4) ics_cd_process_ics_tbls
** 01/08/2013    KJames      Added UPPER to all textual business key fields 
**                           during key_hash generation, for ICS_LMT_SET.
** 01/08/2013    KJames      Added CAST function to final order linkage hashing.
******************************************************************************/
   DECLARE v_startdtm             DATETIME     DEFAULT NOW();
   DECLARE v_enddtm               DATETIME;
   DECLARE v_sp_name              VARCHAR(64)  DEFAULT 'ics_cd_updt_ics_tables';
   DECLARE v_sql_statement        VARCHAR(4000); 
   DECLARE v_num_rows             INT DEFAULT 0;
   DECLARE v_table_name           VARCHAR(30);
   DECLARE v_client_prefix        VARCHAR(3)  DEFAULT 'ga_';
   DECLARE v_schema_name          VARCHAR(27) DEFAULT 'ics_flow_local';
   DECLARE v_marker               VARCHAR(255);
   DECLARE v_nodatafound          BOOLEAN;
   --
   DECLARE payload_type_cur CURSOR FOR
       SELECT TABLE_NAME
         FROM INFORMATION_SCHEMA.REFERENTIAL_CONSTRAINTS
        WHERE CONSTRAINT_SCHEMA     = CONCAT(v_client_prefix,v_schema_name)
          AND REFERENCED_TABLE_NAME = 'ICS_PAYLOAD' ;
   --
   DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_nodatafound = TRUE;
   DECLARE EXIT HANDLER FOR SQLEXCEPTION
      BEGIN  
         ROLLBACK;
         SET po_status = -1;
         SET po_errm   = v_marker;
         SELECT CONCAT('ERROR: ',v_marker);
         CALL ics_etl_log_sp    
            (v_sp_name          -- pi_sp_name
            ,v_marker           -- pi_marker
            ,NULL               -- pi_tgt_tbl
            ,NULL               -- pi_src_tbl
            ,v_startdtm         -- pi_startdtm
            ,NOW()              -- pi_enddtm
            ,'FAILED'           -- pi_process
            ,-1);               -- pi_value
      END;
  
   SET v_marker = 'DELETE FROM ics_key_hash';
   --  Initialize working table ICS_KEY_HASH
   DELETE FROM ICS_KEY_HASH;
   SET v_marker = 'DELETE FROM ics_data_hash';
   -- Initialize working table ICS_DATA_HASH 
   DELETE FROM ICS_DATA_HASH;
   -- --------------------------------------------
   -- Reset transaction_type on all payload tables  
   -- --------------------------------------------
   SET v_marker = 'OPEN payload_type_cur';
   OPEN payload_type_cur;
   SET v_nodatafound = FALSE;
   payload_loop: LOOP
      --
      FETCH payload_type_cur
       INTO v_table_name;
      --
      IF v_nodatafound THEN
         -- CLOSE payload_loop;
         LEAVE payload_loop;
      END IF;
      --
      SET v_marker = CONCAT('UPDATE ',v_table_name
                           ,' SET TRANSACTION_TYPE = NULL , TRANSACTION_TIMESTAMP = NULL');
      SET @sqlstmt = v_marker;
      PREPARE v_sql_statement FROM @sqlstmt;
      EXECUTE v_sql_statement;
      --
   END LOOP payload_loop;
   CLOSE payload_type_cur;
   -- =========================================
   -- START - Set KEY_HASH and DATA_HASH fields
   -- =========================================
   -- ---------------
   -- UPDATE ics_addr
   -- ---------------
   SET v_marker = 'UPDATE ICS_ADDR 1';
   UPDATE ICS_ADDR
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(AFFIL_TYPE_TXT,'-*-')
                                        ,COALESCE(ORG_FRML_NAME,'-*-')
                                        ,COALESCE(ORG_DUNS_NUM,'-*-')
                                        ,COALESCE(MAILING_ADDR_TXT,'-*-')
                                        ,COALESCE(SUPPL_ADDR_TXT,'-*-')
                                        ,COALESCE(MAILING_ADDR_CITY_NAME,'-*-')
                                        ,COALESCE(MAILING_ADDR_ST_CODE,'-*-')
                                        ,COALESCE(MAILING_ADDR_ZIP_CODE,'-*-')
                                        ,COALESCE(COUNTY_NAME,'-*-')
                                        ,COALESCE(MAILING_ADDR_COUNTRY_CODE,'-*-')
                                        ,COALESCE(DIVISION_NAME,'-*-')
                                        ,COALESCE(LOC_PROVINCE,'-*-')
                                        ,COALESCE(ELEC_ADDR_TXT,'-*-')
                                        ,COALESCE(START_DATE_OF_ADDR_ASSC,'-*-')
                                        ,COALESCE(END_DATE_OF_ADDR_ASSC,'-*-'))
                                 ,'-*-','')
                          );
   -- --------------------
   -- UPDATE ICS_ANML_TYPE
   -- --------------------
   SET v_marker = 'UPDATE ICS_ANML_TYPE 1';
   UPDATE ICS_ANML_TYPE
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(ANML_TYPE_CODE,'-*-')
                                        ,COALESCE(OTHR_ANML_TYPE_NAME,'-*-')
                                        ,COALESCE(TTL_NUM_EACH_LVSTCK,'-*-')
                                        ,COALESCE(OPEN_CONFINEMNT_CNT,'-*-')
                                        ,COALESCE(HOUSD_UNDR_ROOF_CONFINEMNT_CNT,'-*-'))
                                 ,'-*-','')
                         );
   -- --------------------
   -- UPDATE ICS_ASSC_PRMT
   -- --------------------
   SET v_marker = 'UPDATE ICS_ASSC_PRMT 1';
   UPDATE ICS_ASSC_PRMT
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(ASSC_PRMT_IDENT,'-*-')
                                        ,COALESCE(ASSC_PRMT_REASON_CODE,'-*-'))
                                 ,'-*-','')
                         );
   -- ---------------------
   -- UPDATE ICS_BASIC_PRMT
   -- ---------------------
   SET v_marker = 'UPDATE ICS_BASIC_PRMT 1';
   UPDATE ICS_BASIC_PRMT
     SET KEY_HASH  = MD5(PRMT_IDENT)
        ,DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                       ,COALESCE(PRMT_TYPE_CODE,'-*-')
                                       ,COALESCE(AGNCY_TYPE_CODE,'-*-')
                                       ,COALESCE(PRMT_STAT_CODE,'-*-')
                                       ,COALESCE(PRMT_ISSUE_DATE,'-*-')
                                       ,COALESCE(PRMT_EFFECTIVE_DATE,'-*-')
                                       ,COALESCE(PRMT_EXPR_DATE,'-*-')
                                       ,COALESCE(REISSU_PRIO_PRMT_IND,'-*-')
                                       ,COALESCE(BACKLOG_REASON_TXT,'-*-')
                                       ,COALESCE(PRMT_ISSUING_ORG_TYPE_NAME,'-*-')
                                       ,COALESCE(PRMT_APPEALED_IND,'-*-')
                                       ,COALESCE(PRMT_USR_DFND_DAT_ELM_1_TXT,'-*-')
                                       ,COALESCE(PRMT_USR_DFND_DAT_ELM_2_TXT,'-*-')
                                       ,COALESCE(PRMT_USR_DFND_DAT_ELM_3_TXT,'-*-')
                                       ,COALESCE(PRMT_USR_DFND_DAT_ELM_4_TXT,'-*-')
                                       ,COALESCE(PRMT_USR_DFND_DAT_ELM_5_TXT,'-*-')
                                       ,COALESCE(PRMT_CMNTS_TXT,'-*-')
                                       ,COALESCE(MAJOR_MINOR_RATING_CODE,'-*-')
                                       ,COALESCE(TTL_APPL_DSGN_FLOW_NUM,'-*-')
                                       ,COALESCE(TTL_APPL_AVER_FLOW_NUM,'-*-')
                                       ,COALESCE(APPL_RCVD_DATE,'-*-')
                                       ,COALESCE(PRMT_APPL_CMPL_DATE,'-*-')
                                       ,COALESCE(NEW_SRC_IND,'-*-')
                                       ,COALESCE(PRMT_ST_WTR_BODY_CODE,'-*-')
                                       ,COALESCE(PRMT_ST_WTR_BODY_NAME,'-*-')
                                       ,COALESCE(FEDR_GRANT_IND,'-*-')
                                       ,COALESCE(DMR_COGNZNT_OFCL,'-*-')
                                       ,COALESCE(DMR_COGNZNT_OFCL_TELEPH_NUM,'-*-')
                                       ,COALESCE(SIG_IU_IND,'-*-')
                                       ,COALESCE(RCVG_PRMT_IDENT,'-*-'))
                                 ,'-*-','')
                         );
   -- --------------------------------
   -- UPDATE ICS_BS_END_USE_DSPL_TYPE
   -- -------------------------------
   SET v_marker = 'UPDATE ICS_BS_END_USE_DSPL_TYPE 1';
   UPDATE ICS_BS_END_USE_DSPL_TYPE
      SET DATA_HASH = MD5(BS_END_USE_DSPL_TYPE_CODE);
   -- ------------------
   -- UPDATE ICS_BS_PRMT
   -- ------------------
   SET v_marker = 'UPDATE ICS_BS_PRMT 1';
   UPDATE ICS_BS_PRMT
      SET KEY_HASH  = MD5(PRMT_IDENT)
         ,DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(EQ_PROD_DIST_MARKETED_AMT,'-*-')
                                        ,COALESCE(LAND_APPLIED_AMT,'-*-')
                                        ,COALESCE(INCINERATED_AMT,'-*-')
                                        ,COALESCE(CODISPOSED_IN_MSW_LANDFILL_AMT,'-*-')
                                        ,COALESCE(SURF_DSPL_AMT,'-*-')
                                        ,COALESCE(MNGED_OTHR_MTHDS_AMT,'-*-')
                                        ,COALESCE(RCVD_OFFSITE_SRCS_AMT,'-*-')
                                        ,COALESCE(TRANSFERRED_AMT,'-*-')
                                        ,COALESCE(DISPOSED_OUT_OF_ST_AMT,'-*-')
                                        ,COALESCE(BENEF_USED_OUT_OF_ST_AMT,'-*-')
                                        ,COALESCE(MNGED_OTHR_MTHDS_OUT_OF_ST_AMT,'-*-')
                                        ,COALESCE(TTL_REMOVED_AMT,'-*-')
                                        ,COALESCE(ANNUL_DRY_SLDG_PROD_NUM,'-*-'))
                                 ,'-*-','')
                         );
   -- ----------------------
   -- UPDATE ICS_BS_PROG_REP
   -- ----------------------
   SET v_marker = 'UPDATE ICS_BS_PROG_REP 1';
   UPDATE ICS_BS_PROG_REP
      SET KEY_HASH  = MD5(REPLACE(CONCAT(COALESCE(ICS_BS_PROG_REP.PRMT_IDENT,'-*-')
                                        ,COALESCE(REP_COVERAGE_END_DATE,'-*-'))
                                 ,'-*-','')
                         )
         ,DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(REP_COVERAGE_END_DATE,'-*-')
                                        ,COALESCE(NUM_OF_REP_UNITS,'-*-')
                                        ,COALESCE(EQ_PROD_DIST_MARKETED_AMT,'-*-')
                                        ,COALESCE(LAND_APPLIED_AMT,'-*-')
                                        ,COALESCE(INCINERATED_AMT,'-*-')
                                        ,COALESCE(CODISPOSED_IN_MSW_LANDFILL_AMT,'-*-')
                                        ,COALESCE(SURF_DSPL_AMT,'-*-')
                                        ,COALESCE(MNGED_OTHR_MTHDS_AMT,'-*-')
                                        ,COALESCE(RCVD_OFFSITE_SRCS_AMT,'-*-')
                                        ,COALESCE(TRANSFERRED_AMT,'-*-')
                                        ,COALESCE(DISPOSED_OUT_OF_ST_AMT,'-*-')
                                        ,COALESCE(BENEF_USED_OUT_OF_ST_AMT,'-*-')
                                        ,COALESCE(MNGED_OTHR_MTHDS_OUT_OF_ST_AMT,'-*-')
                                        ,COALESCE(TTL_REMOVED_AMT,'-*-')
                                        ,COALESCE(ANNUL_DRY_SLDG_PROD_NUM,'-*-')
                                        ,COALESCE(ANNUL_LOADING_PARAM_DATE,'-*-')
                                        ,COALESCE(ANNUL_LOADING_BS_GAL,'-*-')
                                        ,COALESCE(ANNUL_LOADING_BS_DMT,'-*-')
                                        ,COALESCE(ANNUL_LOADING_NUTR_NITROGEN,'-*-')
                                        ,COALESCE(ANNUL_LOADING_NUTR_PHOSPH,'-*-')
                                        ,COALESCE(TTL_NUM_LAND_APPL_VIOL,'-*-')
                                        ,COALESCE(TTL_NUM_INCIN_VIOL,'-*-')
                                        ,COALESCE(TTL_NUM_DIST_MARKETING_VIOL,'-*-')
                                        ,COALESCE(TTL_NUM_SLDG_RLT_MGMT_PRC_VIOL,'-*-')
                                        ,COALESCE(TTL_NUM_SURF_DSPL_VIOL,'-*-')
                                        ,COALESCE(TTL_NUM_OTHR_SLDG_VIOL,'-*-')
                                        ,COALESCE(TTL_NUM_CODISPOSAL_VIOL,'-*-')
                                        ,COALESCE(BS_REP_CMNTS,'-*-'))
                                 ,'-*-','')
                         );
   -- ------------------
   -- UPDATE ICS_BS_TYPE
   -- ------------------
   SET v_marker = 'UPDATE ICS_BS_TYPE 1';
   UPDATE ICS_BS_TYPE
      SET DATA_HASH = MD5(BS_TYPE_CODE);
   -- -------------------------
   -- UPDATE ICS_CAFO_ANNUL_REP
   -- -------------------------
   SET v_marker = 'UPDATE ICS_CAFO_ANNUL_REP 1';
   UPDATE ICS_CAFO_ANNUL_REP
     SET KEY_HASH  = MD5(REPLACE(CONCAT(COALESCE(ICS_CAFO_ANNUL_REP.PRMT_IDENT,'-*-')
                                       ,COALESCE(PRMT_AUTH_REP_RCVD_DATE,'-*-'))
                                 ,'-*-','')
                         )
        ,DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                       ,COALESCE(PRMT_AUTH_REP_RCVD_DATE,'-*-')
                                       ,COALESCE(DSCH_DRNG_YEAR_PROD_AREA_IND,'-*-')
                                       ,COALESCE(SOLID_MNUR_LTTR_GNRTD_AMT,'-*-')
                                       ,COALESCE(LIQUID_MNUR_WW_GNRTD_AMT,'-*-')
                                       ,COALESCE(SOLID_MNUR_LTTR_TRANS_AMT,'-*-')
                                       ,COALESCE(LIQUID_MNUR_WW_TRANS_AMT,'-*-')
                                       ,COALESCE(NMP_DVLPD_CERT_PLNR_APRVD_IND,'-*-')
                                       ,COALESCE(TTL_NUM_ACRES_NMP_IDNTFD,'-*-')
                                       ,COALESCE(TTL_NUM_ACRES_USED_LAND_APPL,'-*-'))
                                 ,'-*-','')
                         );
   -- --------------------
   -- UPDATE ICS_CAFO_INSP
   -- --------------------
   SET v_marker = 'UPDATE ICS_CAFO_INSP 1';
   UPDATE ICS_CAFO_INSP
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(CAFO_CLASS_CODE,'-*-')
                                        ,COALESCE(IS_ANML_FAC_TYPE_CAFO_IND,'-*-')
                                        ,COALESCE(CAFO_DESGN_DATE,'-*-')
                                        ,COALESCE(CAFO_DESGN_REASON_TXT,'-*-')
                                        ,COALESCE(DSCH_DRNG_YEAR_PROD_AREA_IND,'-*-')
                                        ,COALESCE(NUM_ACRES_CONTRB_DRAIN,'-*-')
                                        ,COALESCE(APPL_MEAS_AVAIL_LAND_NUM,'-*-')
                                        ,COALESCE(SOLID_MNUR_LTTR_GNRTD_AMT,'-*-')
                                        ,COALESCE(LIQUID_MNUR_WW_GNRTD_AMT,'-*-')
                                        ,COALESCE(SOLID_MNUR_LTTR_TRANS_AMT,'-*-')
                                        ,COALESCE(LIQUID_MNUR_WW_TRANS_AMT,'-*-')
                                        ,COALESCE(NMP_DVLPD_CERT_PLNR_APRVD_IND,'-*-')
                                        ,COALESCE(NMP_DVLPD_DATE,'-*-')
                                        ,COALESCE(NMP_LAST_UPDATED_DATE,'-*-')
                                        ,COALESCE(ENVR_MGMT_SYSTM_IND,'-*-')
                                        ,COALESCE(EMS_DVLPD_DATE,'-*-')
                                        ,COALESCE(EMS_LAST_UPDATED_DATE,'-*-')
                                        ,COALESCE(LVSTCK_MAX_CPCTY_NUM,'-*-')
                                        ,COALESCE(LVSTCK_CPCTY_DTRMN_BS_UPON_NUM,'-*-')
                                        ,COALESCE(AUTH_LVSTCK_CPCTY_NUM,'-*-'))
                                 ,'-*-','')
                         );
   -- ------------------------------
   -- UPDATE ICS_CAFO_INSP_VIOL_TYPE
   -- ------------------------------
   SET v_marker = 'UPDATE ICS_CAFO_INSP_VIOL_TYPE 1';
   UPDATE ICS_CAFO_INSP_VIOL_TYPE
      SET DATA_HASH = MD5(CAFO_INSP_VIOL_TYPE_CODE);
   -- --------------------
   -- UPDATE ICS_CAFO_PRMT
   -- --------------------
   SET v_marker = 'UPDATE ICS_CAFO_PRMT 1';
   UPDATE ICS_CAFO_PRMT
      SET KEY_HASH  = MD5(PRMT_IDENT)
         ,DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(CAFO_CLASS_CODE,'-*-')
                                        ,COALESCE(IS_ANML_FAC_TYPE_CAFO_IND,'-*-')
                                        ,COALESCE(CAFO_DESGN_DATE,'-*-')
                                        ,COALESCE(CAFO_DESGN_REASON_TXT,'-*-')
                                        ,COALESCE(NUM_ACRES_CONTRB_DRAIN,'-*-')
                                        ,COALESCE(APPL_MEAS_AVAIL_LAND_NUM,'-*-')
                                        ,COALESCE(SOLID_MNUR_LTTR_GNRTD_AMT,'-*-')
                                        ,COALESCE(LIQUID_MNUR_WW_GNRTD_AMT,'-*-')
                                        ,COALESCE(SOLID_MNUR_LTTR_TRANS_AMT,'-*-')
                                        ,COALESCE(LIQUID_MNUR_WW_TRANS_AMT,'-*-')
                                        ,COALESCE(NMP_DVLPD_CERT_PLNR_APRVD_IND,'-*-')
                                        ,COALESCE(NMP_DVLPD_DATE,'-*-')
                                        ,COALESCE(NMP_LAST_UPDATED_DATE,'-*-')
                                        ,COALESCE(ENVR_MGMT_SYSTM_IND,'-*-')
                                        ,COALESCE(EMS_DVLPD_DATE,'-*-')
                                        ,COALESCE(EMS_LAST_UPDATED_DATE,'-*-')
                                        ,COALESCE(LVSTCK_MAX_CPCTY_NUM,'-*-')
                                        ,COALESCE(LVSTCK_CPCTY_DTRMN_BS_UPON_NUM,'-*-')
                                        ,COALESCE(AUTH_LVSTCK_CPCTY_NUM,'-*-')
                                        ,COALESCE(LEGAL_DESC_TXT,'-*-'))
                                 ,'-*-','')
                         );
   -- -------------------------
   -- UPDATE ICS_CMPL_INSP_TYPE
   -- -------------------------
   SET v_marker = 'UPDATE ICS_CMPL_INSP_TYPE 1';
   UPDATE ICS_CMPL_INSP_TYPE
      SET DATA_HASH = MD5(CMPL_INSP_TYPE_CODE);
   -- -------------------
   -- UPDATE ICS_CMPL_MON
   -- -------------------
   SET v_marker = 'UPDATE ICS_CMPL_MON 1';
   UPDATE ICS_CMPL_MON
      SET KEY_HASH  = MD5(REPLACE(CONCAT(COALESCE(ICS_CMPL_MON.PRMT_IDENT,'-*-')
                                        ,COALESCE(CMPL_MON_CATG_CODE,'-*-')
                                        ,COALESCE(CMPL_MON_DATE,'-*-'))
                                 ,'-*-','')
                         )
         ,DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(CMPL_MON_CATG_CODE,'-*-')
                                        ,COALESCE(CMPL_MON_DATE,'-*-')
                                        ,COALESCE(CMPL_MON_START_DATE,'-*-')
                                        ,COALESCE(CMPL_MON_ACTY_NAME,'-*-')
                                        ,COALESCE(BIOMON_INSP_METHOD,'-*-')
                                        ,COALESCE(CMPL_MON_AGNCY_CODE,'-*-')
                                        ,COALESCE(ST_STATUTE_VIOL_NAME,'-*-')
                                        ,COALESCE(EPA_ASSIST_IND,'-*-')
                                        ,COALESCE(ST_FEDR_JOINT_IND,'-*-')
                                        ,COALESCE(JOINT_INSP_REASON_CODE,'-*-')
                                        ,COALESCE(LEAD_PARTY,'-*-')
                                        ,COALESCE(NUM_DAYS_PHYS_COND_ACTY,'-*-')
                                        ,COALESCE(NUM_HOURS_PHYS_COND_ACTY,'-*-')
                                        ,COALESCE(CMPL_MON_ACTN_OUTCOME_CODE,'-*-')
                                        ,COALESCE(INSP_RATING_CODE,'-*-')
                                        ,COALESCE(MULTIMEDIA_IND,'-*-')
                                        ,COALESCE(FEDR_FAC_IND,'-*-')
                                        ,COALESCE(FEDR_FAC_IND_CMNT,'-*-')
                                        ,COALESCE(INSP_USR_DFND_FLD_1,'-*-')
                                        ,COALESCE(INSP_USR_DFND_FLD_2,'-*-')
                                        ,COALESCE(INSP_USR_DFND_FLD_3,'-*-')
                                        ,COALESCE(INSP_USR_DFND_FLD_4,'-*-')
                                        ,COALESCE(INSP_USR_DFND_FLD_5,'-*-')
                                        ,COALESCE(INSP_USR_DFND_FLD_6,'-*-')
                                        ,COALESCE(INSP_CMNT_TXT,'-*-'))
                                 ,'-*-','')
                         );
   -- -------------------------------
   -- UPDATE ICS_CMPL_MON_ACTN_REASON
   -- -------------------------------
   SET v_marker = 'UPDATE ICS_CMPL_MON_ACTN_REASON 1';
   UPDATE ICS_CMPL_MON_ACTN_REASON
      SET DATA_HASH = MD5(CMPL_MON_ACTN_REASON_CODE);
   -- ------------------------------
   -- UPDATE ICS_CMPL_MON_AGNCY_TYPE
   -- ------------------------------
   SET v_marker = 'UPDATE ICS_CMPL_MON_AGNCY_TYPE 1';
   UPDATE ICS_CMPL_MON_AGNCY_TYPE
      SET DATA_HASH = MD5(CMPL_MON_AGNCY_TYPE_CODE);
   -- -----------------------
   -- UPDATE ICS_CMPL_MON_LNK
   -- -----------------------
   -- ROOT TABLE HAS CONDITIONAL KEY, SKIPPING KEY_HASH CREATION
   SET v_marker = 'UPDATE ICS_CMPL_MON_LNK 1';
   UPDATE ICS_CMPL_MON_LNK
     SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                       ,COALESCE(CMPL_MON_CATG_CODE,'-*-')
                                       ,COALESCE(CMPL_MON_DATE,'-*-'))
                                 ,'-*-','')
                         );
   -- --------------------
   -- UPDATE ICS_CMPL_SCHD
   -- --------------------
   SET v_marker = 'UPDATE ICS_CMPL_SCHD 1';
   UPDATE ICS_CMPL_SCHD
      SET KEY_HASH  = MD5(REPLACE(CONCAT(COALESCE(ICS_CMPL_SCHD.ENFRC_ACTN_IDENT,'-*-')
                                        ,COALESCE(FINAL_ORDER_IDENT,'-*-')
                                        ,COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(CMPL_SCHD_NUM,'-*-'))
                                 ,'-*-','')
                         )
         ,DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(ENFRC_ACTN_IDENT,'-*-')
                                        ,COALESCE(FINAL_ORDER_IDENT,'-*-')
                                        ,COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(CMPL_SCHD_NUM,'-*-')
                                        ,COALESCE(CMPL_SCHD_CMNTS,'-*-')
                                        ,COALESCE(SCHD_DESC_CODE,'-*-'))
                                 ,'-*-','')
                         );
   -- ------------------------
   -- UPDATE ICS_CMPL_SCHD_EVT
   -- ------------------------
   SET v_marker = 'UPDATE ICS_CMPL_SCHD_EVT 1';
   UPDATE ICS_CMPL_SCHD_EVT
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(SCHD_EVT_CODE,'-*-')
                                        ,COALESCE(SCHD_DATE,'-*-')
                                        ,COALESCE(SCHD_REP_RCVD_DATE,'-*-')
                                        ,COALESCE(SCHD_ACTUL_DATE,'-*-')
                                        ,COALESCE(SCHD_PROJ_DATE,'-*-')
                                        ,COALESCE(SCHD_USR_DFND_DAT_ELM_1,'-*-')
                                        ,COALESCE(SCHD_USR_DFND_DAT_ELM_2,'-*-')
                                        ,COALESCE(SCHD_EVT_CMNTS,'-*-')
                                        ,COALESCE(CMPL_SCHD_PNLTY_AMT,'-*-'))
                                 ,'-*-','')
                         );
   -- ----------------------------------
   -- UPDATE ICS_CMPL_SCHD_EVT_VIOL_ELEM
   -- ----------------------------------
   SET v_marker = 'UPDATE ICS_CMPL_SCHD_EVT_VIOL_ELEM 1';
   UPDATE ICS_CMPL_SCHD_EVT_VIOL_ELEM
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(ENFRC_ACTN_IDENT,'-*-')
                                        ,COALESCE(FINAL_ORDER_IDENT,'-*-')
                                        ,COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(CMPL_SCHD_NUM,'-*-')
                                        ,COALESCE(SCHD_EVT_CODE,'-*-')
                                        ,COALESCE(SCHD_DATE,'-*-')
                                        ,COALESCE(SCHD_VIOL_CODE,'-*-'))
                                 ,'-*-','')
                         );
   -- -------------------------
   -- UPDATE ICS_CMPL_SCHD_VIOL
   -- -------------------------
   SET v_marker = 'UPDATE ICS_CMPL_SCHD_VIOL 1';
   UPDATE ICS_CMPL_SCHD_VIOL
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(ENFRC_ACTN_IDENT,'-*-')
                                        ,COALESCE(FINAL_ORDER_IDENT,'-*-')
                                        ,COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(CMPL_SCHD_NUM,'-*-')
                                        ,COALESCE(SCHD_EVT_CODE,'-*-')
                                        ,COALESCE(SCHD_DATE,'-*-'))
                                 ,'-*-','')
                         );
   -- --------------------------
   -- UPDATE ICS_CMPL_TRACK_STAT
   -- --------------------------
   SET v_marker = 'UPDATE ICS_CMPL_TRACK_STAT 1';
   UPDATE ICS_CMPL_TRACK_STAT
     SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(STAT_CODE,'-*-')
                                       ,COALESCE(STAT_START_DATE,'-*-')
                                       ,COALESCE(STAT_REASON,'-*-'))
                                 ,'-*-','')
                         );
   -- -----------------------
   -- UPDATE ICS_CO_DSPL_SITE
   -- -----------------------
   SET v_marker = 'UPDATE ICS_CO_DSPL_SITE 1';
   UPDATE ICS_CO_DSPL_SITE
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(PART_258_CMPL_IND,'-*-')
                                        ,COALESCE(PAINT_FILTER_TEST_RESULT,'-*-')
                                        ,COALESCE(TCLP_TEST_RESULT,'-*-'))
                                 ,'-*-','')
                         );
   -- ------------------
   -- UPDATE ICS_CONTACT
   -- ------------------
   SET v_marker = 'UPDATE ICS_CONTACT 1';
   UPDATE ICS_CONTACT
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(AFFIL_TYPE_TXT,'-*-')
                                        ,COALESCE(FIRST_NAME,'-*-')
                                        ,COALESCE(MIDDLE_NAME,'-*-')
                                        ,COALESCE(LAST_NAME,'-*-')
                                        ,COALESCE(INDVL_TITLE_TXT,'-*-')
                                        ,COALESCE(ORG_FRML_NAME,'-*-')
                                        ,COALESCE(ST_CODE,'-*-')
                                        ,COALESCE(RGN_CODE,'-*-')
                                        ,COALESCE(ELEC_ADDR_TXT,'-*-')
                                        ,COALESCE(START_DATE_OF_CONTACT_ASSC,'-*-')
                                        ,COALESCE(END_DATE_OF_CONTACT_ASSC,'-*-'))
                                 ,'-*-','')
                         );
   -- ----------------------
   -- UPDATE ICS_CONTAINMENT
   -- ----------------------
   SET v_marker = 'UPDATE ICS_CONTAINMENT 1';
   UPDATE ICS_CONTAINMENT
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(CONTAINMENT_TYPE_CODE,'-*-')
                                        ,COALESCE(OTHR_CONTAINMENT_TYPE_NAME,'-*-')
                                        ,COALESCE(CONTAINMENT_CPCTY_NUM,'-*-'))
                                 ,'-*-','')
                         );
   -- -------------------------------
   -- UPDATE ICS_CROP_TYPES_HARVESTED
   -- -------------------------------
   SET v_marker = 'UPDATE ICS_CROP_TYPES_HARVESTED 1';
   UPDATE ICS_CROP_TYPES_HARVESTED
      SET DATA_HASH = MD5(CROP_TYPES_HARVESTED);
   -- -----------------------------
   -- UPDATE ICS_CROP_TYPES_PLANTED
   -- -----------------------------
   SET v_marker = 'UPDATE ICS_CROP_TYPES_PLANTED 1';
   UPDATE ICS_CROP_TYPES_PLANTED
      SET DATA_HASH = MD5(CROP_TYPES_PLANTED);
   -- ----------------------
   -- UPDATE ICS_CSO_EVT_REP
   -- ----------------------
   SET v_marker = 'UPDATE ICS_CSO_EVT_REP 1';
   UPDATE ICS_CSO_EVT_REP
      SET KEY_HASH  = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(CSO_EVT_DATE,'-*-')
                                        ,COALESCE(CSO_EVT_ID,'-*-'))
                                 ,'-*-','')
                         )
         ,DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(DRY_OR_WET_WEATHER_IND,'-*-')
                                        ,COALESCE(PRMT_FEATR_IDENT,'-*-')
                                        ,COALESCE(LAT_MEAS,'-*-')
                                        ,COALESCE(LONG_MEAS,'-*-')
                                        ,COALESCE(CSO_OVRFLW_LOC_STREET,'-*-')
                                        ,COALESCE(DURATION_CSO_OVRFLW_EVT,'-*-')
                                        ,COALESCE(DSCH_VOL_TREATED,'-*-')
                                        ,COALESCE(DSCH_VOL_UNTREATED,'-*-')
                                        ,COALESCE(CORR_ACTN_TAKEN_DESC_TXT,'-*-')
                                        ,COALESCE(INCHES_PRECIP,'-*-'))
                                 ,'-*-','')
                         );
   -- -------------------
   -- UPDATE ICS_CSO_INSP
   -- -------------------
   SET v_marker = 'UPDATE ICS_CSO_INSP 1';
   UPDATE ICS_CSO_INSP
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(CSO_EVT_DATE,'-*-')
                                        ,COALESCE(DRY_OR_WET_WEATHER_IND,'-*-')
                                        ,COALESCE(PRMT_FEATR_IDENT,'-*-')
                                        ,COALESCE(LAT_MEAS,'-*-')
                                        ,COALESCE(LONG_MEAS,'-*-')
                                        ,COALESCE(CSO_OVRFLW_LOC_STREET,'-*-')
                                        ,COALESCE(DURATION_CSO_OVRFLW_EVT,'-*-')
                                        ,COALESCE(DSCH_VOL_TREATED,'-*-')
                                        ,COALESCE(DSCH_VOL_UNTREATED,'-*-')
                                        ,COALESCE(CORR_ACTN_TAKEN_DESC_TXT,'-*-')
                                        ,COALESCE(INCHES_PRECIP,'-*-'))
                                 ,'-*-','')
                         );
   -- -------------------
   -- UPDATE ICS_CSO_PRMT
   -- -------------------
   SET v_marker = 'UPDATE ICS_CSO_PRMT 1';
   UPDATE ICS_CSO_PRMT
      SET KEY_HASH  = MD5(PRMT_IDENT)
         ,DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(CSS_POPL_SERVED_NUM,'-*-')
                                        ,COALESCE(COMBINED_SEWER_SYSTM_LENGTH,'-*-')
                                        ,COALESCE(COLL_SYSTM_COMBINED_PERCENT,'-*-'))
                                 ,'-*-','')
                         );
   -- ---------------------------
   -- UPDATE ICS_DMR_PROG_REP_LNK
   -- ---------------------------
   SET v_marker = 'UPDATE ICS_DMR_PROG_REP_LNK 1';
   -- ROOT TABLE HAS CONDITIONAL KEY, SKIPPING KEY_HASH CREATION
   UPDATE ICS_DMR_PROG_REP_LNK
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(PRMT_FEATR_IDENT,'-*-')
                                        ,COALESCE(LMT_SET_DESIGNATOR,'-*-')
                                        ,COALESCE(MON_PERIOD_END_DATE,'-*-'))
                                 ,'-*-','')
                         );
   -- -------------------
   -- UPDATE ICS_DMR_VIOL
   -- -------------------
   SET v_marker = 'UPDATE ICS_DMR_VIOL 1';
   UPDATE ICS_DMR_VIOL
      SET KEY_HASH  = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(PRMT_FEATR_IDENT,'-*-')
                                        ,COALESCE(LMT_SET_DESIGNATOR,'-*-')
                                        ,COALESCE(MON_PERIOD_END_DATE,'-*-')
                                        ,COALESCE(PARAM_CODE,'-*-')
                                        ,COALESCE(MON_SITE_DESC_CODE,'-*-')
                                        ,COALESCE(LMT_SEASON_NUM,'-*-')
                                        ,COALESCE(NUM_REP_CODE,'-*-')
                                        ,COALESCE(NUM_REP_VIOL_CODE,'-*-'))
                                 ,'-*-','')
                         )
         ,DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(PRMT_FEATR_IDENT,'-*-')
                                        ,COALESCE(LMT_SET_DESIGNATOR,'-*-')
                                        ,COALESCE(MON_PERIOD_END_DATE,'-*-')
                                        ,COALESCE(PARAM_CODE,'-*-')
                                        ,COALESCE(MON_SITE_DESC_CODE,'-*-')
                                        ,COALESCE(LMT_SEASON_NUM,'-*-')
                                        ,COALESCE(NUM_REP_CODE,'-*-')
                                        ,COALESCE(NUM_REP_VIOL_CODE,'-*-')
                                        ,COALESCE(REP_NON_CMPL_DETECT_CODE,'-*-')
                                        ,COALESCE(REP_NON_CMPL_DETECT_DATE,'-*-')
                                        ,COALESCE(REP_NON_CMPL_RESL_CODE,'-*-')
                                        ,COALESCE(REP_NON_CMPL_RESL_DATE,'-*-'))
                                 ,'-*-','')
                         );
   -- -----------------------
   -- UPDATE ICS_DSCH_MON_REP
   -- -----------------------
   SET v_marker = 'UPDATE ICS_DSCH_MON_REP 1';
   UPDATE ICS_DSCH_MON_REP
      SET KEY_HASH  = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(PRMT_FEATR_IDENT,'-*-')
                                        ,COALESCE(LMT_SET_DESIGNATOR,'-*-')
                                        ,COALESCE(MON_PERIOD_END_DATE,'-*-'))
                                 ,'-*-','')
                         )
         ,DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(PRMT_FEATR_IDENT,'-*-')
                                        ,COALESCE(LMT_SET_DESIGNATOR,'-*-')
                                        ,COALESCE(MON_PERIOD_END_DATE,'-*-')
                                        ,COALESCE(SIGN_DATE,'-*-')
                                        ,COALESCE(PRNCPL_EXEC_OFFCR_FIRST_NAME,'-*-')
                                        ,COALESCE(PRNCPL_EXEC_OFFCR_LAST_NAME,'-*-')
                                        ,COALESCE(PRNCPL_EXEC_OFFCR_TITLE,'-*-')
                                        ,COALESCE(PRNCPL_EXEC_OFFCR_TELEPH,'-*-')
                                        ,COALESCE(SIGN_FIRST_NAME,'-*-')
                                        ,COALESCE(SIGN_LAST_NAME,'-*-')
                                        ,COALESCE(SIGN_TELEPH,'-*-')
                                        ,COALESCE(REP_CMNT_TXT,'-*-')
                                        ,COALESCE(DMR_NO_DSCH_IND,'-*-')
                                        ,COALESCE(DMR_NO_DSCH_RCVD_DATE,'-*-'))
                                 ,'-*-','')
                         );
   -- ----------------------------------
   -- UPDATE ICS_DSCH_MON_REP_PARAM_VIOL
   -- ----------------------------------
   SET v_marker = 'UPDATE ICS_DSCH_MON_REP_PARAM_VIOL 1';
   UPDATE ICS_DSCH_MON_REP_PARAM_VIOL
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(PRMT_FEATR_IDENT,'-*-')
                                        ,COALESCE(LMT_SET_DESIGNATOR,'-*-')
                                        ,COALESCE(MON_PERIOD_END_DATE,'-*-')
                                        ,COALESCE(PARAM_CODE,'-*-')
                                        ,COALESCE(MON_SITE_DESC_CODE,'-*-')
                                        ,COALESCE(LMT_SEASON_NUM,'-*-'))
                                 ,'-*-','')
                         );
   -- ----------------------------
   -- UPDATE ICS_DSCH_MON_REP_VIOL
   -- ----------------------------
   SET v_marker = 'UPDATE ICS_DSCH_MON_REP_VIOL 1';
   UPDATE ICS_DSCH_MON_REP_VIOL
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(PRMT_FEATR_IDENT,'-*-')
                                        ,COALESCE(LMT_SET_DESIGNATOR,'-*-')
                                        ,COALESCE(MON_PERIOD_END_DATE,'-*-'))
                                 ,'-*-','')
                         );
   -- ----------------------
   -- UPDATE ICS_EFFLU_GUIDE
   -- ----------------------
   SET v_marker = 'UPDATE ICS_EFFLU_GUIDE 1';
   UPDATE ICS_EFFLU_GUIDE
      SET DATA_HASH = MD5(EFFLU_GUIDE_CODE);
   -- -----------------------------
   -- UPDATE ICS_EFFLU_TRADE_PRTNER
   -- -----------------------------
   SET v_marker = 'UPDATE ICS_EFFLU_TRADE_PRTNER 1';
   UPDATE ICS_EFFLU_TRADE_PRTNER
      SET KEY_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                       ,COALESCE(PRMT_FEATR_IDENT,'-*-')
                                       ,COALESCE(LMT_SET_DESIGNATOR,'-*-')
                                       ,COALESCE(PARAM_CODE,'-*-')
                                       ,COALESCE(MON_SITE_DESC_CODE,'-*-')
                                       ,COALESCE(LMT_SEASON_NUM,'-*-')
                                       ,COALESCE(LMT_START_DATE,'-*-')
                                       ,COALESCE(LMT_END_DATE,'-*-')
                                       ,COALESCE(LMT_MOD_EFFECTIVE_DATE,'-*-')
                                       ,COALESCE(TRADE_ID,'-*-'))
                                 ,'-*-','')
                         )
         ,DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(PRMT_FEATR_IDENT,'-*-')
                                        ,COALESCE(LMT_SET_DESIGNATOR,'-*-')
                                        ,COALESCE(PARAM_CODE,'-*-')
                                        ,COALESCE(MON_SITE_DESC_CODE,'-*-')
                                        ,COALESCE(LMT_SEASON_NUM,'-*-')
                                        ,COALESCE(LMT_START_DATE,'-*-')
                                        ,COALESCE(LMT_END_DATE,'-*-')
                                        ,COALESCE(LMT_MOD_EFFECTIVE_DATE,'-*-')
                                        ,COALESCE(TRADE_PRTNER_NPDESID,'-*-')
                                        ,COALESCE(TRADE_PRTNER_TYPE,'-*-')
                                        ,COALESCE(TRADE_PRTNER_START_DATE,'-*-')
                                        ,COALESCE(TRADE_PRTNER_END_DATE,'-*-'))
                                 ,'-*-','')
                         );
   -- ----------------------------------
   -- UPDATE ICS_EFFLU_TRADE_PRTNER_ADDR
   -- ----------------------------------
   SET v_marker = 'UPDATE ICS_EFFLU_TRADE_PRTNER_ADDR 1';
   UPDATE ICS_EFFLU_TRADE_PRTNER_ADDR
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(ORG_FRML_NAME,'-*-')
                                        ,COALESCE(ORG_DUNS_NUM,'-*-')
                                        ,COALESCE(LOC_NAME,'-*-')
                                        ,COALESCE(MAILING_ADDR_TXT,'-*-')
                                        ,COALESCE(SUPPL_ADDR_TXT,'-*-')
                                        ,COALESCE(MAILING_ADDR_CITY_NAME,'-*-')
                                        ,COALESCE(MAILING_ADDR_COUNTRY_CODE,'-*-')
                                        ,COALESCE(LOC_PROVINCE,'-*-')
                                        ,COALESCE(MAILING_ADDR_ST_CODE,'-*-')
                                        ,COALESCE(MAILING_ADDR_ZIP_CODE,'-*-')
                                        ,COALESCE(COUNTY_NAME,'-*-')
                                        ,COALESCE(DIVISION_NAME,'-*-')
                                        ,COALESCE(ELEC_ADDR_TXT,'-*-'))
                                 ,'-*-','')
                         );
   -- ---------------------------------
   -- UPDATE ICS_ENFRC_ACTN_GOV_CONTACT
   -- ---------------------------------
   SET v_marker = 'UPDATE ICS_ENFRC_ACTN_GOV_CONTACT 1';
   UPDATE ICS_ENFRC_ACTN_GOV_CONTACT
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(AFFIL_TYPE_TXT,'-*-')
                                        ,COALESCE(ELEC_ADDR_TXT,'-*-')
                                        ,COALESCE(START_DATE_OF_CONTACT_ASSC,'-*-')
                                        ,COALESCE(END_DATE_OF_CONTACT_ASSC,'-*-'))
                                 ,'-*-','')
                         );
   -- -------------------------------
   -- UPDATE ICS_ENFRC_ACTN_MILESTONE
   -- -------------------------------
   SET v_marker = 'UPDATE ICS_ENFRC_ACTN_MILESTONE 1';
   UPDATE ICS_ENFRC_ACTN_MILESTONE
      SET KEY_HASH  = MD5(REPLACE(CONCAT(COALESCE(ENFRC_ACTN_IDENT,'-*-')
                                        ,COALESCE(MILESTONE_TYPE_CODE,'-*-'))
                                 ,'-*-','')
                         )
         ,DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(ENFRC_ACTN_IDENT,'-*-')
                                        ,COALESCE(MILESTONE_TYPE_CODE,'-*-')
                                        ,COALESCE(MILESTONE_PLANNED_DATE,'-*-')
                                        ,COALESCE(MILESTONE_ACTUL_DATE,'-*-'))
                                 ,'-*-','')
                         );
   -- --------------------------
   -- UPDATE ICS_ENFRC_ACTN_TYPE
   -- --------------------------
   SET v_marker = 'UPDATE ICS_ENFRC_ACTN_TYPE 1';
  UPDATE ICS_ENFRC_ACTN_TYPE
     SET DATA_HASH = MD5(ENFRC_ACTN_TYPE_CODE);
   -- ------------------------------
   -- UPDATE ICS_ENFRC_ACTN_VIOL_LNK
   -- ------------------------------
   SET v_marker = 'UPDATE ICS_ENFRC_ACTN_VIOL_LNK 1';
   -- ROOT TABLE HAS CONDITIONAL KEY, SKIPPING KEY_HASH CREATION
   UPDATE ICS_ENFRC_ACTN_VIOL_LNK
      SET DATA_HASH = MD5(ENFRC_ACTN_IDENT);
   -- ----------------------
   -- UPDATE ICS_ENFRC_AGNCY
   -- ----------------------
   SET v_marker = 'UPDATE ICS_ENFRC_AGNCY 1';
   UPDATE ICS_ENFRC_AGNCY
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(ENFRC_AGNCY_TYPE_CODE,'-*-')
                                        ,COALESCE(AGNCY_LEAD_IND,'-*-'))
                                 ,'-*-','')
                         );
   -- --------------
   -- UPDATE ICS_FAC
   -- --------------
   SET v_marker = 'UPDATE ICS_FAC 1';
   UPDATE ICS_FAC
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(FAC_SITE_NAME,'-*-')
                                        ,COALESCE(LOC_ADDR_TXT,'-*-')
                                        ,COALESCE(SUPPL_LOC_TXT,'-*-')
                                        ,COALESCE(LOCALITY_NAME,'-*-')
                                        ,COALESCE(LOC_ST_CODE,'-*-')
                                        ,COALESCE(LOC_ZIP_CODE,'-*-')
                                        ,COALESCE(LOC_COUNTRY_CODE,'-*-')
                                        ,COALESCE(ORG_DUNS_NUM,'-*-')
                                        ,COALESCE(ST_FAC_IDENT,'-*-')
                                        ,COALESCE(ST_RGN_CODE,'-*-')
                                        ,COALESCE(FAC_CONGR_DISTRICT_NUM,'-*-')
                                        ,COALESCE(FAC_TYPE_OF_OWNERSHIP_CODE,'-*-')
                                        ,COALESCE(FEDR_FAC_IDENT_NUM,'-*-')
                                        ,COALESCE(FEDR_AGNCY_CODE,'-*-')
                                        ,COALESCE(TRIBAL_LAND_CODE,'-*-')
                                        ,COALESCE(CNST_PROJ_NAME,'-*-')
                                        ,COALESCE(CNST_PROJ_LAT_MEAS,'-*-')
                                        ,COALESCE(CNST_PROJ_LONG_MEAS,'-*-')
                                        ,COALESCE(SECTION_TOWNSHIP_RNG,'-*-')
                                        ,COALESCE(FAC_CMNTS,'-*-')
                                        ,COALESCE(FAC_USR_DFND_FLD_1,'-*-')
                                        ,COALESCE(FAC_USR_DFND_FLD_2,'-*-')
                                        ,COALESCE(FAC_USR_DFND_FLD_3,'-*-')
                                        ,COALESCE(FAC_USR_DFND_FLD_4,'-*-')
                                        ,COALESCE(FAC_USR_DFND_FLD_5,'-*-'))
                                 ,'-*-','')
                         );
   -- --------------------
   -- UPDATE ICS_FAC_CLASS
   -- --------------------
   SET v_marker = 'UPDATE ICS_FAC_CLASS 1';
   UPDATE ICS_FAC_CLASS
      SET DATA_HASH = MD5(FAC_CLASS);
   -- ----------------------
   -- UPDATE ICS_FINAL_ORDER
   -- ----------------------
   SET v_marker = 'UPDATE ICS_FINAL_ORDER 1';
   UPDATE ICS_FINAL_ORDER
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(FINAL_ORDER_IDENT,'-*-')
                                        ,COALESCE(FINAL_ORDER_TYPE_CODE,'-*-')
                                        ,COALESCE(FINAL_ORDER_ISSUED_ENTERD_DATE,'-*-')
                                        ,COALESCE(NPDES_CLOSED_DATE,'-*-')
                                        ,COALESCE(FINAL_ORDER_QNCR_CMNTS,'-*-')
                                        ,COALESCE(CASH_CIVIL_PNLTY_REQD_AMT,'-*-')
                                        ,COALESCE(OTHR_CMNTS,'-*-'))
                                 ,'-*-','')
                         );
   -- ---------------------------------
   -- UPDATE ICS_FINAL_ORDER_PRMT_IDENT
   -- ---------------------------------
   SET v_marker = 'UPDATE ICS_FINAL_ORDER_PRMT_IDENT 1';
  UPDATE ICS_FINAL_ORDER_PRMT_IDENT
     SET DATA_HASH = MD5(FINAL_ORDER_PRMT_IDENT);
   -- -------------------------------
   -- UPDATE ICS_FINAL_ORDER_VIOL_LNK
   -- -------------------------------
   SET v_marker = 'UPDATE ICS_FINAL_ORDER_VIOL_LNK 1';
   -- ROOT TABLE HAS CONDITIONAL KEY, SKIPPING KEY_HASH CREATION
   UPDATE ICS_FINAL_ORDER_VIOL_LNK
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(ENFRC_ACTN_IDENT,'-*-')
                                        ,COALESCE(CAST(FINAL_ORDER_IDENT AS CHAR),'-*-'))
                                 ,'-*-','')
                         );
   -- --------------------------
   -- UPDATE ICS_FRML_ENFRC_ACTN
   -- --------------------------
   SET v_marker = 'UPDATE ICS_FRML_ENFRC_ACTN 1';
   UPDATE ICS_FRML_ENFRC_ACTN
      SET KEY_HASH  = MD5(ENFRC_ACTN_IDENT)
         ,DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(ENFRC_ACTN_IDENT,'-*-')
                                        ,COALESCE(ENFRC_ACTN_NAME,'-*-')
                                        ,COALESCE(FORUM,'-*-')
                                        ,COALESCE(RESL_TYPE_CODE,'-*-')
                                        ,COALESCE(COMBINED_OR_SUPERSEDED_BY_EAID,'-*-')
                                        ,COALESCE(REASON_DELETING_RECORD,'-*-')
                                        ,COALESCE(FEDR_FAC_IND,'-*-')
                                        ,COALESCE(FEDR_FAC_IND_CMNT,'-*-')
                                        ,COALESCE(FRML_EA_USR_DFND_FLD_1,'-*-')
                                        ,COALESCE(FRML_EA_USR_DFND_FLD_2,'-*-')
                                        ,COALESCE(FRML_EA_USR_DFND_FLD_3,'-*-')
                                        ,COALESCE(FRML_EA_USR_DFND_FLD_4,'-*-')
                                        ,COALESCE(FRML_EA_USR_DFND_FLD_5,'-*-')
                                        ,COALESCE(FRML_EA_USR_DFND_FLD_6,'-*-')
                                        ,COALESCE(ENFRC_AGNCY_NAME,'-*-'))
                                 ,'-*-','')
                         );
   -- --------------------
   -- UPDATE ICS_GEO_COORD
   -- --------------------
   SET v_marker = 'UPDATE ICS_GEO_COORD 1';
   UPDATE ICS_GEO_COORD
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(LAT_MEAS,'-*-')
                                        ,COALESCE(LONG_MEAS,'-*-')
                                        ,COALESCE(HORZ_ACCURACY_MEAS,'-*-')
                                        ,COALESCE(GEOMETRIC_TYPE_CODE,'-*-')
                                        ,COALESCE(HORZ_COLL_METHOD_CODE,'-*-')
                                        ,COALESCE(HORZ_REF_DATUM_CODE,'-*-')
                                        ,COALESCE(REF_POINT_CODE,'-*-')
                                        ,COALESCE(SRC_MAP_SCALE_NUM,'-*-'))
                                 ,'-*-','')
                         );
   -- --------------------
   -- UPDATE ICS_GNRL_PRMT
   -- --------------------
   SET v_marker = 'UPDATE ICS_GNRL_PRMT 1';
   UPDATE ICS_GNRL_PRMT
      SET KEY_HASH  = MD5(PRMT_IDENT)
         ,DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(ASSC_MASTER_GNRL_PRMT_IDENT,'-*-')
                                        ,COALESCE(PRMT_TYPE_CODE,'-*-')
                                        ,COALESCE(AGNCY_TYPE_CODE,'-*-')
                                        ,COALESCE(PRMT_STAT_CODE,'-*-')
                                        ,COALESCE(PRMT_ISSUE_DATE,'-*-')
                                        ,COALESCE(PRMT_EFFECTIVE_DATE,'-*-')
                                        ,COALESCE(PRMT_EXPR_DATE,'-*-')
                                        ,COALESCE(REISSU_PRIO_PRMT_IND,'-*-')
                                        ,COALESCE(BACKLOG_REASON_TXT,'-*-')
                                        ,COALESCE(PRMT_ISSUING_ORG_TYPE_NAME,'-*-')
                                        ,COALESCE(PRMT_APPEALED_IND,'-*-')
                                        ,COALESCE(PRMT_USR_DFND_DAT_ELM_1_TXT,'-*-')
                                        ,COALESCE(PRMT_USR_DFND_DAT_ELM_2_TXT,'-*-')
                                        ,COALESCE(PRMT_USR_DFND_DAT_ELM_3_TXT,'-*-')
                                        ,COALESCE(PRMT_USR_DFND_DAT_ELM_4_TXT,'-*-')
                                        ,COALESCE(PRMT_USR_DFND_DAT_ELM_5_TXT,'-*-')
                                        ,COALESCE(PRMT_CMNTS_TXT,'-*-')
                                        ,COALESCE(MAJOR_MINOR_RATING_CODE,'-*-')
                                        ,COALESCE(TTL_APPL_DSGN_FLOW_NUM,'-*-')
                                        ,COALESCE(TTL_APPL_AVER_FLOW_NUM,'-*-')
                                        ,COALESCE(APPL_RCVD_DATE,'-*-')
                                        ,COALESCE(PRMT_APPL_CMPL_DATE,'-*-')
                                        ,COALESCE(NEW_SRC_IND,'-*-')
                                        ,COALESCE(PRMT_ST_WTR_BODY_CODE,'-*-')
                                        ,COALESCE(PRMT_ST_WTR_BODY_NAME,'-*-')
                                        ,COALESCE(FEDR_GRANT_IND,'-*-')
                                        ,COALESCE(DMR_COGNZNT_OFCL,'-*-')
                                        ,COALESCE(DMR_COGNZNT_OFCL_TELEPH_NUM,'-*-'))
                                 ,'-*-','')
                         );
   -- ---------------------------
   -- UPDATE ICS_GPCF_CNST_WAIVER
   -- ---------------------------
   SET v_marker = 'UPDATE ICS_GPCF_CNST_WAIVER 1';
   UPDATE ICS_GPCF_CNST_WAIVER
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(CNST_WAIVER_AUTH_DATE,'-*-')
                                        ,COALESCE(CNST_WAIVER_CRITERIA_MET_IND,'-*-')
                                        ,COALESCE(CNST_WAIVER_EVAL_BASIS_CODE,'-*-')
                                        ,COALESCE(CNST_WAIVER_EVAL_DATE,'-*-')
                                        ,COALESCE(CNST_WAIVER_POSTMARK_DATE,'-*-')
                                        ,COALESCE(PROJ_ISOERODENT_VALUE,'-*-')
                                        ,COALESCE(PROJ_EST_START_DATE,'-*-')
                                        ,COALESCE(PROJ_EST_COMPLETED_DATE,'-*-'))
                                 ,'-*-','')
                         );
   -- ---------------------------
   -- UPDATE ICS_GPCF_NO_EXPOSURE
   -- ---------------------------
   SET v_marker = 'UPDATE ICS_GPCF_NO_EXPOSURE 1';
   UPDATE ICS_GPCF_NO_EXPOSURE
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(NO_EXPOSURE_AUTH_DATE,'-*-')
                                        ,COALESCE(NO_EXPOSURE_POSTMARK_DATE,'-*-')
                                        ,COALESCE(NO_EXPOSURE_EVAL_DATE,'-*-')
                                        ,COALESCE(NO_EXPOSURE_EVAL_BASIS_CODE,'-*-')
                                        ,COALESCE(NO_EXPOSURE_CRITERIA_MET_IND,'-*-')
                                        ,COALESCE(PAVED_ROOF_SIZE,'-*-')
                                        ,COALESCE(INDST_ACTY_SIZE,'-*-'))
                                 ,'-*-','')
                         );
   -- --------------------------------
   -- UPDATE ICS_GPCF_NOTICE_OF_INTENT
   -- --------------------------------
   SET v_marker = 'UPDATE ICS_GPCF_NOTICE_OF_INTENT 1';
   UPDATE ICS_GPCF_NOTICE_OF_INTENT
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(NOI_SIGN_DATE,'-*-')
                                        ,COALESCE(NOI_POSTMARK_DATE,'-*-')
                                        ,COALESCE(NOI_RCVD_DATE,'-*-')
                                        ,COALESCE(COMPLETE_NOI_RCVD_DATE,'-*-'))
                                 ,'-*-','')
                         );
   -- ------------------------------
   -- UPDATE ICS_GPCF_NOTICE_OF_TERM
   -- ------------------------------
   SET v_marker = 'UPDATE ICS_GPCF_NOTICE_OF_TERM 1';
   UPDATE ICS_GPCF_NOTICE_OF_TERM
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(NOT_TERM_DATE,'-*-')
                                        ,COALESCE(NOT_SIGN_DATE,'-*-')
                                        ,COALESCE(NOT_POSTMARK_DATE,'-*-')
                                        ,COALESCE(NOT_RCVD_DATE,'-*-'))
                                 ,'-*-','')
                         );
   -- ------------------------------
   -- UPDATE ICS_HIST_PRMT_SCHD_EVTS
   -- ------------------------------
   SET v_marker = 'UPDATE ICS_HIST_PRMT_SCHD_EVTS 1';
   UPDATE ICS_HIST_PRMT_SCHD_EVTS
      SET KEY_HASH  = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(PRMT_EFFECTIVE_DATE,'-*-')
                                        ,COALESCE(NARR_COND_NUM,'-*-')
                                        ,COALESCE(SCHD_EVT_CODE,'-*-')
                                        ,COALESCE(SCHD_DATE,'-*-'))
                                 ,'-*-','')
                         )
         ,DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(PRMT_EFFECTIVE_DATE,'-*-')
                                        ,COALESCE(NARR_COND_NUM,'-*-')
                                        ,COALESCE(SCHD_EVT_CODE,'-*-')
                                        ,COALESCE(SCHD_DATE,'-*-')
                                        ,COALESCE(SCHD_REP_RCVD_DATE,'-*-')
                                        ,COALESCE(SCHD_ACTUL_DATE,'-*-')
                                        ,COALESCE(SCHD_PROJ_DATE,'-*-')
                                        ,COALESCE(SCHD_USR_DFND_DAT_ELM_1,'-*-')
                                        ,COALESCE(SCHD_USR_DFND_DAT_ELM_2,'-*-')
                                        ,COALESCE(SCHD_EVT_CMNTS,'-*-'))
                                 ,'-*-','')
                         );
   -- -------------------------
   -- UPDATE ICS_IMPACT_SSO_EVT
   -- -------------------------
   SET v_marker = 'UPDATE ICS_IMPACT_SSO_EVT 1';
   UPDATE ICS_IMPACT_SSO_EVT
      SET DATA_HASH = MD5(IMPACT_SSO_EVT);
   -- ----------------
   -- UPDATE ICS_INCIN
   -- ----------------
   SET v_marker = 'UPDATE ICS_INCIN 1';
   UPDATE ICS_INCIN
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(BERYLLIUM_CMPL_IND,'-*-')
                                        ,COALESCE(MERCURY_CMPL_IND,'-*-'))
                                 ,'-*-','')
                         );
   -- ----------------------------
   -- UPDATE ICS_INFRML_ENFRC_ACTN
   -- ----------------------------
   SET v_marker = 'UPDATE ICS_INFRML_ENFRC_ACTN 1';
   UPDATE ICS_INFRML_ENFRC_ACTN
      SET KEY_HASH  = MD5(ENFRC_ACTN_IDENT)
         ,DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(ENFRC_ACTN_IDENT,'-*-')
                                        ,COALESCE(ENFRC_ACTN_TYPE_CODE,'-*-')
                                        ,COALESCE(ENFRC_ACTN_NAME,'-*-')
                                        ,COALESCE(ACHIEVED_DATE,'-*-')
                                        ,COALESCE(REASON_DELETING_RECORD,'-*-')
                                        ,COALESCE(FEDR_FAC_IND,'-*-')
                                        ,COALESCE(FEDR_FAC_IND_CMNT,'-*-')
                                        ,COALESCE(INFRML_EA_CMNT_TXT,'-*-')
                                        ,COALESCE(INFRML_EA_USR_DFND_FLD_1,'-*-')
                                        ,COALESCE(INFRML_EA_USR_DFND_FLD_2,'-*-')
                                        ,COALESCE(INFRML_EA_USR_DFND_FLD_3,'-*-')
                                        ,COALESCE(INFRML_EA_USR_DFND_FLD_4,'-*-')
                                        ,COALESCE(INFRML_EA_USR_DFND_FLD_5,'-*-')
                                        ,COALESCE(INFRML_EA_USR_DFND_FLD_6,'-*-')
                                        ,COALESCE(ENFRC_AGNCY_NAME,'-*-'))
                                 ,'-*-','')
                         );
   -- ------------------------
   -- UPDATE ICS_LAND_APPL_BMP
   -- ------------------------
   SET v_marker = 'UPDATE ICS_LAND_APPL_BMP 1';
   UPDATE ICS_LAND_APPL_BMP
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(LAND_APPL_BMP_TYPE_CODE,'-*-')
                                        ,COALESCE(OTHR_LAND_APPL_BMP_TYPE_NAME,'-*-'))
                                 ,'-*-','')
                         );
   -- -------------------------
   -- UPDATE ICS_LAND_APPL_SITE
   -- -------------------------
   SET v_marker = 'UPDATE ICS_LAND_APPL_SITE 1';
   UPDATE ICS_LAND_APPL_SITE
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(POLUT_MET_FOR_LAND_APPL,'-*-')
                                        ,COALESCE(PATHOGEN_REDUCTION_IND,'-*-')
                                        ,COALESCE(VECTOR_REDUCTION_IND,'-*-')
                                        ,COALESCE(AGRONOMIC_GAL_RATE_FOR_FLD,'-*-')
                                        ,COALESCE(AGRONOMIC_DMT_RATE_FOR_FLD,'-*-')
                                        ,COALESCE(CLASS_A_ALT_USED,'-*-')
                                        ,COALESCE(CLASS_A_ALTS_TXT,'-*-')
                                        ,COALESCE(CLASS_B_ALT_USED,'-*-')
                                        ,COALESCE(CLASS_B_ALTS_TXT,'-*-')
                                        ,COALESCE(VAR_ALT_USED,'-*-')
                                        ,COALESCE(VAR_ALTS_TXT,'-*-'))
                                 ,'-*-','')
                         );
   -- --------------
   -- UPDATE ICS_LMT
   -- --------------
   SET v_marker = 'UPDATE ICS_LMT 1';
   UPDATE ICS_LMT
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(LMT_START_DATE,'-*-')
                                        ,COALESCE(LMT_END_DATE,'-*-')
                                        ,COALESCE(LMT_TYPE_CODE,'-*-')
                                        ,COALESCE(SMPL_TYPE_TXT,'-*-')
                                        ,COALESCE(FREQ_OF_ANALYSIS_CODE,'-*-')
                                        ,COALESCE(ELIGIBLE_FOR_BURDEN_REDUCTION,'-*-')
                                        ,COALESCE(LMT_STAY_TYPE_CODE,'-*-')
                                        ,COALESCE(STAY_START_DATE,'-*-')
                                        ,COALESCE(STAY_END_DATE,'-*-')
                                        ,COALESCE(STAY_REASON_TXT,'-*-')
                                        ,COALESCE(CALCULATE_VIOL_IND,'-*-')
                                        ,COALESCE(ENFRC_ACTN_IDENT,'-*-')
                                        ,COALESCE(FINAL_ORDER_IDENT,'-*-')
                                        ,COALESCE(BASIS_OF_LMT,'-*-')
                                        ,COALESCE(LMT_MOD_TYPE_CODE,'-*-')
                                        ,COALESCE(LMT_MOD_EFFECTIVE_DATE,'-*-')
                                        ,COALESCE(LMTS_USR_DFND_FLD_1,'-*-')
                                        ,COALESCE(LMTS_USR_DFND_FLD_2,'-*-')
                                        ,COALESCE(LMTS_USR_DFND_FLD_3,'-*-')
                                        ,COALESCE(CONCEN_NUM_COND_UNIT_MEAS_CODE,'-*-')
                                        ,COALESCE(QTY_NUM_COND_UNIT_MEAS_CODE,'-*-'))
                                 ,'-*-','')
                         );
   -- ------------------
   -- UPDATE ICS_LMT_SET
   -- ------------------
   SET v_marker = 'UPDATE ICS_LMT_SET 1';
   UPDATE ICS_LMT_SET
      SET KEY_HASH  = MD5(REPLACE(CONCAT(COALESCE(UPPER(PRMT_IDENT),'-*-')
                                 ,COALESCE(UPPER(PRMT_FEATR_IDENT),'-*-')
                                 ,COALESCE(UPPER(LMT_SET_DESIGNATOR),'-*-'))
                                 ,'-*-','')
                         )
         ,DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(PRMT_FEATR_IDENT,'-*-')
                                        ,COALESCE(LMT_SET_DESIGNATOR,'-*-')
                                        ,COALESCE(LMT_SET_TYPE,'-*-')
                                        ,COALESCE(LMT_SET_NAME_TXT,'-*-')
                                        ,COALESCE(DMR_PRE_PRINT_CMNTS_TXT,'-*-')
                                        ,COALESCE(AGNCY_REVIEWER,'-*-')
                                        ,COALESCE(LMT_SET_USR_DFND_DAT_ELM_1_TXT,'-*-')
                                        ,COALESCE(LMT_SET_USR_DFND_DAT_ELM_2_TXT,'-*-'))
                                 ,'-*-','')
                         );
   -- ------------------------------
   -- UPDATE ICS_LMT_SET_MONTHS_APPL
   -- ------------------------------
   SET v_marker = 'UPDATE ICS_LMT_SET_MONTHS_APPL 1';
   UPDATE ICS_LMT_SET_MONTHS_APPL
      SET DATA_HASH = MD5(LMT_SET_MONTHS_APPL);
   -- -----------------------
   -- UPDATE ICS_LMT_SET_SCHD
   -- -----------------------
   SET v_marker = 'UPDATE ICS_LMT_SET_SCHD 1';
   UPDATE ICS_LMT_SET_SCHD
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(NUM_UNITS_REP_PERIOD_INTEGER,'-*-')
                                        ,COALESCE(NUM_SUBM_UNITS_INTEGER,'-*-')
                                        ,COALESCE(INITIAL_MON_DATE,'-*-')
                                        ,COALESCE(INITIAL_DMR_DUE_DATE,'-*-')
                                        ,COALESCE(LMT_SET_MOD_TYPE_CODE,'-*-')
                                        ,COALESCE(LMT_SET_MOD_EFFECTIVE_DATE,'-*-'))
                                 ,'-*-','')
                         );
   -- -----------------------
   -- UPDATE ICS_LMT_SET_STAT
   -- -----------------------
   SET v_marker = 'UPDATE ICS_LMT_SET_STAT 1';
   UPDATE ICS_LMT_SET_STAT
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(LMT_SET_STAT_IND,'-*-')
                                        ,COALESCE(LMT_SET_STAT_START_DATE,'-*-')
                                        ,COALESCE(LMT_SET_STAT_REASON_TXT,'-*-'))
                                 ,'-*-','')
                         );
   -- ---------------
   -- UPDATE ICS_LMTS
   -- ---------------
   SET v_marker = 'UPDATE ICS_LMTS 1';
   UPDATE ICS_LMTS
      SET KEY_HASH  = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(PRMT_FEATR_IDENT,'-*-')
                                        ,COALESCE(LMT_SET_DESIGNATOR,'-*-')
                                        ,COALESCE(PARAM_CODE,'-*-')
                                        ,COALESCE(MON_SITE_DESC_CODE,'-*-')
                                        ,COALESCE(LMT_SEASON_NUM,'-*-')
                                        ,COALESCE(LMT_START_DATE,'-*-')
                                        ,COALESCE(LMT_END_DATE,'-*-'))
                                 ,'-*-','')
                         )
         ,DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(PRMT_FEATR_IDENT,'-*-')
                                        ,COALESCE(LMT_SET_DESIGNATOR,'-*-')
                                        ,COALESCE(PARAM_CODE,'-*-')
                                        ,COALESCE(MON_SITE_DESC_CODE,'-*-')
                                        ,COALESCE(LMT_SEASON_NUM,'-*-')
                                        ,COALESCE(LMT_START_DATE,'-*-')
                                        ,COALESCE(LMT_END_DATE,'-*-')
                                        ,COALESCE(LMT_TYPE_CODE,'-*-')
                                        ,COALESCE(SMPL_TYPE_TXT,'-*-')
                                        ,COALESCE(FREQ_OF_ANALYSIS_CODE,'-*-')
                                        ,COALESCE(ELIGIBLE_FOR_BURDEN_REDUCTION,'-*-')
                                        ,COALESCE(LMT_STAY_TYPE_CODE,'-*-')
                                        ,COALESCE(STAY_START_DATE,'-*-')
                                        ,COALESCE(STAY_END_DATE,'-*-')
                                        ,COALESCE(STAY_REASON_TXT,'-*-')
                                        ,COALESCE(CALCULATE_VIOL_IND,'-*-')
                                        ,COALESCE(ENFRC_ACTN_IDENT,'-*-')
                                        ,COALESCE(FINAL_ORDER_IDENT,'-*-')
                                        ,COALESCE(BASIS_OF_LMT,'-*-')
                                        ,COALESCE(LMT_MOD_TYPE_CODE,'-*-')
                                        ,COALESCE(LMT_MOD_EFFECTIVE_DATE,'-*-')
                                        ,COALESCE(LMTS_USR_DFND_FLD_1,'-*-')
                                        ,COALESCE(LMTS_USR_DFND_FLD_2,'-*-')
                                        ,COALESCE(LMTS_USR_DFND_FLD_3,'-*-')
                                        ,COALESCE(CONCEN_NUM_COND_UNIT_MEAS_CODE,'-*-')
                                        ,COALESCE(QTY_NUM_COND_UNIT_MEAS_CODE,'-*-'))
                                 ,'-*-','')
                         );
   -- ---------------------
   -- UPDATE ICS_LNK_BS_REP
   -- ---------------------
   SET v_marker = 'UPDATE ICS_LNK_BS_REP 1';
   UPDATE ICS_LNK_BS_REP
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(REP_COVERAGE_END_DATE,'-*-'))
                                 ,'-*-','')
                         );
   -- -----------------------------
   -- UPDATE ICS_LNK_CAFO_ANNUL_REP
   -- -----------------------------
   SET v_marker = 'UPDATE ICS_LNK_CAFO_ANNUL_REP 1';
   UPDATE ICS_LNK_CAFO_ANNUL_REP
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(PRMT_AUTH_REP_RCVD_DATE,'-*-'))
                                 ,'-*-','')
                         );
   -- --------------------------
   -- UPDATE ICS_LNK_CSO_EVT_REP
   -- --------------------------
   SET v_marker = 'UPDATE ICS_LNK_CSO_EVT_REP 1';
   UPDATE ICS_LNK_CSO_EVT_REP
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(CSO_EVT_DATE,'-*-')
                                        ,COALESCE(CSO_EVT_ID,'-*-'))
                                 ,'-*-','')
                         );
   -- -------------------------
   -- UPDATE ICS_LNK_ENFRC_ACTN
   -- -------------------------
   SET v_marker = 'UPDATE ICS_LNK_ENFRC_ACTN 1';
   UPDATE ICS_LNK_ENFRC_ACTN
      SET DATA_HASH = MD5(ENFRC_ACTN_IDENT);
   -- ----------------------------
   -- UPDATE ICS_LNK_FEDR_CMPL_MON
   -- ----------------------------
   SET v_marker = 'UPDATE ICS_LNK_FEDR_CMPL_MON 1';
   UPDATE ICS_LNK_FEDR_CMPL_MON 
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(PROG_SYSTM_ACRONYM,'-*-')
                                        ,COALESCE(PROG_SYSTM_IDENT,'-*-')
                                        ,COALESCE(FEDR_STATUTE_CODE,'-*-')
                                        ,COALESCE(CMPL_MON_ACTY_TYPE_CODE,'-*-')
                                        ,COALESCE(CMPL_MON_CATG_CODE,'-*-')
                                        ,COALESCE(CMPL_MON_DATE,'-*-'))
                                 ,'-*-','')
                         );
   -- ---------------------------
   -- UPDATE ICS_LNK_LOC_LMTS_REP
   -- ---------------------------
   SET v_marker = 'UPDATE ICS_LNK_LOC_LMTS_REP 1';
   UPDATE ICS_LNK_LOC_LMTS_REP
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(PRMT_AUTH_REP_RCVD_DATE,'-*-'))
                                 ,'-*-','')
                         );
   -- -----------------------------
   -- UPDATE ICS_LNK_PRETR_PERF_REP
   -- -----------------------------
   SET v_marker = 'UPDATE ICS_LNK_PRETR_PERF_REP 1';
   UPDATE ICS_LNK_PRETR_PERF_REP
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(PRETR_PERF_SUMM_END_DATE,'-*-'))
                                 ,'-*-','')
                         );
   -- -----------------------
   -- UPDATE ICS_LNK_SNGL_EVT
   -- -----------------------
   SET v_marker = 'UPDATE ICS_LNK_SNGL_EVT 1';
   UPDATE ICS_LNK_SNGL_EVT
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(SNGL_EVT_VIOL_CODE,'-*-')
                                        ,COALESCE(SNGL_EVT_VIOL_DATE,'-*-'))
                                 ,'-*-','')
                         );
   -- ----------------------------
   -- UPDATE ICS_LNK_SSO_ANNUL_REP
   -- ----------------------------
   SET v_marker = 'UPDATE ICS_LNK_SSO_ANNUL_REP 1';
   UPDATE ICS_LNK_SSO_ANNUL_REP
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(SSO_ANNUL_REP_RCVD_DATE,'-*-'))
                                 ,'-*-','')
                         );
   -- --------------------------
   -- UPDATE ICS_LNK_SSO_EVT_REP
   -- --------------------------
   SET v_marker = 'UPDATE ICS_LNK_SSO_EVT_REP 1';
   UPDATE ICS_LNK_SSO_EVT_REP
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(SSO_EVT_DATE,'-*-')
                                        ,COALESCE(SSO_EVT_ID,'-*-'))
                                 ,'-*-','')
                         );
   -- ----------------------------------
   -- UPDATE ICS_LNK_SSO_MONTHLY_EVT_REP
   -- ----------------------------------
   SET v_marker = 'UPDATE ICS_LNK_SSO_MONTHLY_EVT_REP 1';
   UPDATE ICS_LNK_SSO_MONTHLY_EVT_REP
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(SSO_MONTHLY_REP_RCVD_DATE,'-*-'))
                                 ,'-*-','')
                         );
   -- --------------------------
   -- UPDATE ICS_LNK_ST_CMPL_MON
   -- --------------------------
   SET v_marker = 'UPDATE ICS_LNK_ST_CMPL_MON 1';
   UPDATE ICS_LNK_ST_CMPL_MON
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(CMPL_MON_CATG_CODE,'-*-')
                                        ,COALESCE(CMPL_MON_DATE,'-*-'))
                                 ,'-*-','')
                         );
   -- --------------------------
   -- UPDATE ICS_LNK_SW_EVT_REP
   -- --------------------------
   SET v_marker = 'UPDATE ICS_LNK_SW_EVT_REP 1';
   UPDATE ICS_LNK_SW_EVT_REP
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(DATE_STRM_EVT_SMPL,'-*-')
                                        ,COALESCE(SW_EVT_ID,'-*-'))
                                 ,'-*-','')
                         );
   -- --------------------------
   -- UPDATE ICS_LNK_SWMS_4_REP
   -- --------------------------
   SET v_marker = 'UPDATE ICS_LNK_SWMS_4_REP 1';
   UPDATE ICS_LNK_SWMS_4_REP
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(SW_MS_4_REP_RCVD_DATE,'-*-'))
                                 ,'-*-','')
                         );
   -- -------------------
   -- UPDATE ICS_LOC_LMTS
   -- -------------------
   SET v_marker = 'UPDATE ICS_LOC_LMTS 1';
   UPDATE ICS_LOC_LMTS
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(MOS_RC_DATE_TECH_EVAL_LOC_LMTS,'-*-')
                                        ,COALESCE(MOS_RC_DATE_AD_TC_BS_LOC_LMTS,'-*-'))
                                 ,'-*-','')
                         );
   -- -------------------------
   -- UPDATE ICS_LOC_LMTS_POLUT
   -- -------------------------
   SET v_marker = 'UPDATE ICS_LOC_LMTS_POLUT 1';
   UPDATE ICS_LOC_LMTS_POLUT
      SET DATA_HASH = MD5(LOC_LMTS_POLUT_CODE);
   -- ----------------------------
   -- UPDATE ICS_LOC_LMTS_PROG_REP
   -- ----------------------------
   SET v_marker = 'UPDATE ICS_LOC_LMTS_PROG_REP 1';
   UPDATE ICS_LOC_LMTS_PROG_REP
      SET KEY_HASH  = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(PRMT_AUTH_REP_RCVD_DATE,'-*-'))
                                 ,'-*-','')
                         )
         ,DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(PRMT_AUTH_REP_RCVD_DATE,'-*-'))
                                 ,'-*-','')
                         );
   -- ---------------------------
   -- UPDATE ICS_MASTER_GNRL_PRMT
   -- ---------------------------
   SET v_marker = 'UPDATE ICS_MASTER_GNRL_PRMT 1';
   UPDATE ICS_MASTER_GNRL_PRMT
      SET KEY_HASH  = MD5(PRMT_IDENT)
         ,DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(PRMT_TYPE_CODE,'-*-')
                                        ,COALESCE(AGNCY_TYPE_CODE,'-*-')
                                        ,COALESCE(PRMT_ISSUE_DATE,'-*-')
                                        ,COALESCE(PRMT_EFFECTIVE_DATE,'-*-')
                                        ,COALESCE(PRMT_EXPR_DATE,'-*-')
                                        ,COALESCE(REISSU_PRIO_PRMT_IND,'-*-')
                                        ,COALESCE(BACKLOG_REASON_TXT,'-*-')
                                        ,COALESCE(PRMT_ISSUING_ORG_TYPE_NAME,'-*-')
                                        ,COALESCE(PRMT_APPEALED_IND,'-*-')
                                        ,COALESCE(PRMT_USR_DFND_DAT_ELM_1_TXT,'-*-')
                                        ,COALESCE(PRMT_USR_DFND_DAT_ELM_2_TXT,'-*-')
                                        ,COALESCE(PRMT_USR_DFND_DAT_ELM_3_TXT,'-*-')
                                        ,COALESCE(PRMT_USR_DFND_DAT_ELM_4_TXT,'-*-')
                                        ,COALESCE(PRMT_USR_DFND_DAT_ELM_5_TXT,'-*-')
                                        ,COALESCE(PRMT_CMNTS_TXT,'-*-')
                                        ,COALESCE(GNRL_PRMT_INDST_CATG,'-*-')
                                        ,COALESCE(PRMT_NAME,'-*-'))
                                 ,'-*-','')
                         );
   -- -------------------------
   -- UPDATE ICS_MN_LMT_APPLIES
   -- -------------------------
   SET v_marker = 'UPDATE ICS_MN_LMT_APPLIES 1';
   UPDATE ICS_MN_LMT_APPLIES
      SET DATA_HASH = MD5(MN_LMT_APPLIES);
   -- ----------------------------------
   -- UPDATE ICS_MNUR_LTTR_PRCSS_WW_STOR
   -- ----------------------------------
   SET v_marker = 'UPDATE ICS_MNUR_LTTR_PRCSS_WW_STOR 1';
   UPDATE ICS_MNUR_LTTR_PRCSS_WW_STOR
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(MNUR_LTTR_PRCSS_WW_STOR_TYPE,'-*-')
                                        ,COALESCE(OTHR_STOR_TYPE_NAME,'-*-')
                                        ,COALESCE(STOR_TTL_CPCTY_MEAS,'-*-')
                                        ,COALESCE(DAYS_OF_STOR,'-*-'))
                                 ,'-*-','')
                         );
   -- ---------------------
   -- UPDATE ICS_NAICS_CODE
   -- ---------------------
   SET v_marker = 'UPDATE ICS_NAICS_CODE 1';
   UPDATE ICS_NAICS_CODE
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(NAICS_CODE,'-*-')
                                        ,COALESCE(NAICS_PRIMARY_IND_CODE,'-*-'))
                                 ,'-*-','')
                         );
   -- ---------------------
   -- UPDATE ICS_NAICS_CODE
   -- ---------------------
   SET v_marker = 'UPDATE ICS_NARR_COND_SCHD 1';
   UPDATE ICS_NARR_COND_SCHD
      SET KEY_HASH  = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(NARR_COND_NUM,'-*-'))
                                 ,'-*-','')
                         )
         ,DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(NARR_COND_NUM,'-*-')
                                        ,COALESCE(NARR_COND_CODE,'-*-')
                                        ,COALESCE(CMNTS,'-*-'))
                                 ,'-*-','')
                         );
   -- -------------------
   -- UPDATE ICS_NAT_PRIO
   -- -------------------
   SET v_marker = 'UPDATE ICS_NAT_PRIO 1';
   UPDATE ICS_NAT_PRIO
      SET DATA_HASH = MD5(NAT_PRIO_CODE);
   -- -------------------
   -- UPDATE ICS_NUM_COND
   -- -------------------
   SET v_marker = 'UPDATE ICS_NUM_COND 1';
   UPDATE ICS_NUM_COND
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(NUM_COND_TXT,'-*-')
                                        ,COALESCE(NUM_COND_QTY,'-*-')
                                        ,COALESCE(NUM_COND_STAT_BASE_CODE,'-*-')
                                        ,COALESCE(NUM_COND_QUALIFIER,'-*-')
                                        ,COALESCE(NUM_COND_OPT_MON_IND,'-*-')
                                        ,COALESCE(NUM_COND_STAY_VALUE,'-*-'))
                                 ,'-*-','')
                         );
   -- ------------------
   -- UPDATE ICS_NUM_REP
   -- ------------------
   SET v_marker = 'UPDATE ICS_NUM_REP 1';
   UPDATE ICS_NUM_REP
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(NUM_REP_CODE,'-*-')
                                        ,COALESCE(NUM_REP_RCVD_DATE,'-*-')
                                        ,COALESCE(NUM_REP_NO_DSCH_IND,'-*-')
                                        ,COALESCE(NUM_COND_QTY,'-*-')
                                        ,COALESCE(NUM_COND_ADJUSTED_QTY,'-*-')
                                        ,COALESCE(NUM_COND_QUALIFIER,'-*-'))
                                 ,'-*-','')
                         );
   -- ---------------------
   -- UPDATE ICS_ORIG_PROGS
   -- ---------------------
   SET v_marker = 'UPDATE ICS_ORIG_PROGS 1';
   UPDATE ICS_ORIG_PROGS
      SET DATA_HASH = MD5(ORIG_PROGS_CODE);
   -- ---------------------
   -- UPDATE ICS_OTHR_PRMTS
   -- ---------------------
   SET v_marker = 'UPDATE ICS_OTHR_PRMTS 1';
   UPDATE ICS_OTHR_PRMTS
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(OTHR_PRMT_IDENT,'-*-')
                                        ,COALESCE(OTHR_ORG_NAME,'-*-')
                                        ,COALESCE(OTHR_PRMT_IDENT_CNTXT_NAME,'-*-'))
                                 ,'-*-','')
                         );
   -- ---------------------
   -- UPDATE ICS_PARAM_LMTS
   -- ---------------------
   SET v_marker = 'UPDATE ICS_PARAM_LMTS 1';
   UPDATE ICS_PARAM_LMTS
      SET KEY_HASH  = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(PRMT_FEATR_IDENT,'-*-')
                                        ,COALESCE(LMT_SET_DESIGNATOR,'-*-')
                                        ,COALESCE(PARAM_CODE,'-*-')
                                        ,COALESCE(MON_SITE_DESC_CODE,'-*-')
                                        ,COALESCE(LMT_SEASON_NUM,'-*-'))
                                 ,'-*-','')
                         )
         ,DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(PRMT_FEATR_IDENT,'-*-')
                                        ,COALESCE(LMT_SET_DESIGNATOR,'-*-')
                                        ,COALESCE(PARAM_CODE,'-*-')
                                        ,COALESCE(MON_SITE_DESC_CODE,'-*-')
                                        ,COALESCE(LMT_SEASON_NUM,'-*-'))
                                 ,'-*-','')
                         );
   -- ---------------
   -- UPDATE ICS_PLCY
   -- ---------------
   SET v_marker = 'UPDATE ICS_PLCY 1';
   UPDATE ICS_PLCY
      SET DATA_HASH = MD5(PLCY_CODE);
   -- --------------------
   -- UPDATE ICS_POTW_PRMT
   -- --------------------
   SET v_marker = 'UPDATE ICS_POTW_PRMT 1';
   UPDATE ICS_POTW_PRMT
      SET KEY_HASH  = MD5(PRMT_IDENT)
         ,DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(SSCS_POPL_SERVED_NUM,'-*-')
                                        ,COALESCE(COMBINED_SSCS_SYSTM_LENGTH,'-*-'))
                                 ,'-*-','')
                         );
   -- ---------------------
   -- UPDATE ICS_PRETR_INSP
   -- ---------------------
   SET v_marker = 'UPDATE ICS_PRETR_INSP 1';
   UPDATE ICS_PRETR_INSP
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(SUO_REF,'-*-')
                                        ,COALESCE(SUO_DATE,'-*-')
                                        ,COALESCE(ACCEPTANCE_HAZ_WASTE,'-*-')
                                        ,COALESCE(ACCEPTANCE_NON_HAZ_INDST_WASTE,'-*-')
                                        ,COALESCE(ACCEPTANCE_HULED_DOMSTIC_WSTES,'-*-')
                                        ,COALESCE(ANNUL_PRETR_BUDGET,'-*-')
                                        ,COALESCE(INADEQUACY_SMPL_INSP_IND,'-*-')
                                        ,COALESCE(ADEQUACY_PRETR_RESOURCES,'-*-')
                                        ,COALESCE(DFCNC_IDNTFD_DRNG_IU_FILE_RVIW,'-*-')
                                        ,COALESCE(CONTROL_MECH_DFCNC,'-*-')
                                        ,COALESCE(LEGAL_AUTH_DFCNC,'-*-')
                                        ,COALESCE(DFCNC_INTRPRT_APPL_PRETR_STNDR,'-*-')
                                        ,COALESCE(DFCNC_DAT_MGMT_PBLC_PRTICIPTON,'-*-')
                                        ,COALESCE(VIOL_IU_SCHD_RMD_MSR,'-*-')
                                        ,COALESCE(FRML_RSPN_VIOL_IU_SCHD_RMD_MSR,'-*-')
                                        ,COALESCE(ANNUL_FREQ_INFLUNT_TOXCNT_SMPL,'-*-')
                                        ,COALESCE(ANNUL_FREQ_EFFLU_TOXCNT_SMPL,'-*-')
                                        ,COALESCE(ANNUL_FREQ_SLDG_TOXCNT_SMPL,'-*-')
                                        ,COALESCE(NUM_SI_US,'-*-')
                                        ,COALESCE(SI_US_WITHOUT_CONTROL_MECH,'-*-')
                                        ,COALESCE(SI_US_NOT_INSPECTED,'-*-')
                                        ,COALESCE(SI_US_NOT_SMPL,'-*-')
                                        ,COALESCE(SI_US_ON_SCHD,'-*-')
                                        ,COALESCE(SI_US_SNC_WITH_PRETR_STNDR,'-*-')
                                        ,COALESCE(SI_US_SNC_WITH_REP_REQS,'-*-')
                                        ,COALESCE(SI_US_SNC_WITH_PRETR_SCHD,'-*-')
                                        ,COALESCE(SI_US_SNC_PUBL_NEWSPAPER,'-*-')
                                        ,COALESCE(VIOL_NOTICES_ISSUED_SI_US,'-*-')
                                        ,COALESCE(ADMIN_ORDERS_ISSUED_SI_US,'-*-')
                                        ,COALESCE(CIVIL_SUTS_FILD_AGINST_SI_US,'-*-')
                                        ,COALESCE(CRIMINL_SUTS_FILD_AGINST_SI_US,'-*-')
                                        ,COALESCE(DOLLAR_AMT_PNLTY_COLL,'-*-')
                                        ,COALESCE(I_US_WHC_PNLTY_HAV_BEE_COLL,'-*-')
                                        ,COALESCE(NUM_CI_US,'-*-')
                                        ,COALESCE(CI_US_IN_SNC,'-*-')
                                        ,COALESCE(PASS_THROUGH_INTERFERENCE_IND,'-*-'))
                                 ,'-*-','')
                         );
   -- --------------------------
   -- UPDATE ICS_PRETR_PERF_SUMM
   -- --------------------------
   SET v_marker = 'UPDATE ICS_PRETR_PERF_SUMM 1';
   UPDATE ICS_PRETR_PERF_SUMM
      SET KEY_HASH  = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(PRETR_PERF_SUMM_END_DATE,'-*-'))
                                 ,'-*-','')
                         )
         ,DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(PRETR_PERF_SUMM_END_DATE,'-*-')
                                        ,COALESCE(PRETR_PERF_SUMM_START_DATE,'-*-')
                                        ,COALESCE(SUO_REF,'-*-')
                                        ,COALESCE(SUO_DATE,'-*-')
                                        ,COALESCE(ACCEPTANCE_HAZ_WASTE,'-*-')
                                        ,COALESCE(ACCEPTANCE_NON_HAZ_INDST_WASTE,'-*-')
                                        ,COALESCE(ACCEPTANCE_HULED_DOMSTIC_WSTES,'-*-')
                                        ,COALESCE(ANNUL_PRETR_BUDGET_PP,'-*-')
                                        ,COALESCE(INADEQUACY_SMPL_INSP_IND,'-*-')
                                        ,COALESCE(ADEQUACY_PRETR_RESOURCES,'-*-')
                                        ,COALESCE(DFCNC_IDNTFD_DRNG_IU_FILE_RVIW,'-*-')
                                        ,COALESCE(CONTROL_MECH_DFCNC,'-*-')
                                        ,COALESCE(LEGAL_AUTH_DFCNC,'-*-')
                                        ,COALESCE(DFCNC_INTRPRT_APPL_PRETR_STNDR,'-*-')
                                        ,COALESCE(DFCNC_DAT_MGMT_PBLC_PRTICIPTON,'-*-')
                                        ,COALESCE(VIOL_IU_SCHD_RMD_MSR,'-*-')
                                        ,COALESCE(FRML_RSPN_VIOL_IU_SCHD_RMD_MSR,'-*-')
                                        ,COALESCE(ANNUL_FREQ_INFLUNT_TOXCNT_SMPL,'-*-')
                                        ,COALESCE(ANNUL_FREQ_EFFLU_TOXCNT_SMPL,'-*-')
                                        ,COALESCE(ANNUL_FREQ_SLDG_TOXCNT_SMPL,'-*-')
                                        ,COALESCE(NUM_SI_US,'-*-')
                                        ,COALESCE(SI_US_WITHOUT_CONTROL_MECH,'-*-')
                                        ,COALESCE(SI_US_NOT_INSPECTED,'-*-')
                                        ,COALESCE(SI_US_NOT_SMPL,'-*-')
                                        ,COALESCE(SI_US_ON_SCHD,'-*-')
                                        ,COALESCE(SI_US_SNC_WITH_PRETR_STNDR,'-*-')
                                        ,COALESCE(SI_US_SNC_WITH_REP_REQS,'-*-')
                                        ,COALESCE(SI_US_SNC_WITH_PRETR_SCHD,'-*-')
                                        ,COALESCE(SI_US_SNC_PUBL_NEWSPAPER,'-*-')
                                        ,COALESCE(VIOL_NOTICES_ISSUED_SI_US,'-*-')
                                        ,COALESCE(ADMIN_ORDERS_ISSUED_SI_US,'-*-')
                                        ,COALESCE(CIVIL_SUTS_FILD_AGINST_SI_US,'-*-')
                                        ,COALESCE(CRIMINL_SUTS_FILD_AGINST_SI_US,'-*-')
                                        ,COALESCE(DOLLAR_AMT_PNLTY_COLL_PP,'-*-')
                                        ,COALESCE(I_US_WHC_PNLTY_HAV_BEE_COLL_PP,'-*-')
                                        ,COALESCE(NUM_CI_US,'-*-')
                                        ,COALESCE(CI_US_IN_SNC,'-*-')
                                        ,COALESCE(PASS_THROUGH_INTERFERENCE_IND,'-*-'))
                                 ,'-*-','')
                         );
   -- ---------------------
   -- UPDATE ICS_PRETR_PRMT
   -- ---------------------
   SET v_marker = 'UPDATE ICS_PRETR_PRMT 1';
   UPDATE ICS_PRETR_PRMT
      SET KEY_HASH  = MD5(PRMT_IDENT)
         ,DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(PRETR_PROG_REQD_IND_CODE,'-*-')
                                        ,COALESCE(CONTROL_AUTH_ST_AGNCY_CODE,'-*-')
                                        ,COALESCE(CONTROL_AUTH_RGNL_AGNCY_CODE,'-*-')
                                        ,COALESCE(CONTROL_AUTH_NPDES_IDENT,'-*-')
                                        ,COALESCE(PRETR_PROG_APRVD_DATE,'-*-'))
                                 ,'-*-','')
                         );
   -- -------------------------
   -- UPDATE ICS_PRMT_COMP_TYPE
   -- -------------------------
   SET v_marker = 'UPDATE ICS_PRMT_COMP_TYPE 1';
   UPDATE ICS_PRMT_COMP_TYPE
      SET DATA_HASH = MD5(PRMT_COMP_TYPE_CODE);
   -- ---------------------
   -- UPDATE ICS_PRMT_FEATR
   -- ---------------------
   SET v_marker = 'UPDATE ICS_PRMT_FEATR 1';
   UPDATE ICS_PRMT_FEATR
      SET KEY_HASH  = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT ,'-*-')
                                        ,COALESCE(PRMT_FEATR_IDENT,'-*-'))
                                 ,'-*-','')
                         )
         ,DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(PRMT_FEATR_IDENT,'-*-')
                                        ,COALESCE(PRMT_FEATR_TYPE_CODE,'-*-')
                                        ,COALESCE(PRMT_FEATR_DESC,'-*-')
                                        ,COALESCE(PRMT_FEATR_DSGN_FLOW_NUM,'-*-')
                                        ,COALESCE(PRMT_FEATR_ACTUL_AVER_FLOW_NUM,'-*-')
                                        ,COALESCE(PRMT_FEATR_ST_WTR_BODY_CODE,'-*-')
                                        ,COALESCE(PRMT_FEATR_ST_WTR_BODY_NAME,'-*-')
                                        ,COALESCE(PRMT_FEATR_USR_DFND_DAT_ELM_1,'-*-')
                                        ,COALESCE(PRMT_FEATR_USR_DFND_DAT_ELM_2,'-*-')
                                        ,COALESCE(FLD_SIZE,'-*-')
                                        ,COALESCE(IS_SITE_OWN_BY_FAC,'-*-')
                                        ,COALESCE(IS_SYSTM_LINED_WITH_LEACHATE,'-*-')
                                        ,COALESCE(DOES_UNIT_HAV_DAILY_COVER,'-*-')
                                        ,COALESCE(PROP_BOUNDARY_DISTANCE,'-*-')
                                        ,COALESCE(IS_REQD_NITRATE_GROUND_WTR,'-*-')
                                        ,COALESCE(WELL_NUM,'-*-')
                                        ,COALESCE(SRC_PRMT_FEATR_DETAIL_TXT,'-*-'))
                                 ,'-*-','')
                         );
   -- --------------------------
   -- UPDATE ICS_PRMT_FEATR_CHAR
   -- --------------------------
   SET v_marker = 'UPDATE ICS_PRMT_FEATR_CHAR 1';
   UPDATE ICS_PRMT_FEATR_CHAR
      SET DATA_HASH = MD5(PRMT_FEATR_CHAR);
   -- ---------------------------------
   -- UPDATE ICS_PRMT_FEATR_TRTMNT_TYPE
   -- ---------------------------------
   SET v_marker = 'UPDATE ICS_PRMT_FEATR_TRTMNT_TYPE 1';
   UPDATE ICS_PRMT_FEATR_TRTMNT_TYPE
      SET DATA_HASH = MD5(PRMT_FEATR_TRTMNT_TYPE_CODE);
   -- ---------------------
   -- UPDATE ICS_PRMT_IDENT
   -- ---------------------
   SET v_marker = 'UPDATE ICS_PRMT_IDENT 1';
  UPDATE ICS_PRMT_IDENT
     SET DATA_HASH = MD5(PRMT_IDENT);
   -- ----------------------
   -- UPDATE ICS_PRMT_REISSU
   -- ----------------------
   SET v_marker = 'UPDATE ICS_PRMT_REISSU 1';
   UPDATE ICS_PRMT_REISSU
      SET KEY_HASH  = MD5(PRMT_IDENT)
         ,DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(PRMT_ISSUE_DATE,'-*-')
                                        ,COALESCE(PRMT_EFFECTIVE_DATE,'-*-')
                                        ,COALESCE(PRMT_EXPR_DATE,'-*-'))
                                 ,'-*-','')
                         );
   -- ------------------------
   -- UPDATE ICS_PRMT_SCHD_EVT
   -- ------------------------
   SET v_marker = 'UPDATE ICS_PRMT_SCHD_EVT 1';
   UPDATE ICS_PRMT_SCHD_EVT
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(SCHD_EVT_CODE,'-*-')
                                        ,COALESCE(SCHD_DATE,'-*-')
                                        ,COALESCE(SCHD_REP_RCVD_DATE,'-*-')
                                        ,COALESCE(SCHD_ACTUL_DATE,'-*-')
                                        ,COALESCE(SCHD_PROJ_DATE,'-*-')
                                        ,COALESCE(SCHD_USR_DFND_DAT_ELM_1,'-*-')
                                        ,COALESCE(SCHD_USR_DFND_DAT_ELM_2,'-*-')
                                        ,COALESCE(SCHD_EVT_CMNTS,'-*-'))
                                 ,'-*-','')
                         );
   -- ----------------------------------
   -- UPDATE ICS_PRMT_SCHD_EVT_VIOL_ELEM
   -- ----------------------------------
   SET v_marker = 'UPDATE ICS_PRMT_SCHD_EVT_VIOL_ELEM 1';
   UPDATE ICS_PRMT_SCHD_EVT_VIOL_ELEM
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(NARR_COND_NUM,'-*-')
                                        ,COALESCE(SCHD_EVT_CODE,'-*-')
                                        ,COALESCE(SCHD_DATE,'-*-')
                                        ,COALESCE(SCHD_VIOL_CODE,'-*-'))
                                 ,'-*-','')
                         );
   -- -------------------------
   -- UPDATE ICS_PRMT_SCHD_VIOL
   -- -------------------------
   SET v_marker = 'UPDATE ICS_PRMT_SCHD_VIOL 1';
   UPDATE ICS_PRMT_SCHD_VIOL
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(NARR_COND_NUM,'-*-')
                                        ,COALESCE(SCHD_EVT_CODE,'-*-')
                                        ,COALESCE(SCHD_DATE,'-*-'))
                                 ,'-*-','')
                         );
   -- --------------------
   -- UPDATE ICS_PRMT_TERM
   -- --------------------
   SET v_marker = 'UPDATE ICS_PRMT_TERM 1';
   UPDATE ICS_PRMT_TERM
      SET KEY_HASH  = MD5(PRMT_IDENT)
         ,DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(PRMT_TERM_DATE,'-*-'))
                                 ,'-*-','')
                         );
   -- -------------------------
   -- UPDATE ICS_PRMT_TRACK_EVT
   -- -------------------------
   SET v_marker = 'UPDATE ICS_PRMT_TRACK_EVT 1';
   UPDATE ICS_PRMT_TRACK_EVT
      SET KEY_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                       ,COALESCE(PRMT_TRACK_EVT_CODE,'-*-')
                                       ,COALESCE(PRMT_TRACK_EVT_DATE,'-*-'))
                                 ,'-*-','')
                         )
         ,DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(PRMT_TRACK_EVT_CODE,'-*-')
                                        ,COALESCE(PRMT_TRACK_EVT_DATE,'-*-')
                                        ,COALESCE(PRMT_TRACK_CMNTS_TXT,'-*-'))
                                 ,'-*-','')
                         );
   -- ---------------
   -- UPDATE ICS_PROG
   -- ---------------
   SET v_marker = 'UPDATE ICS_PROG 1';
   UPDATE ICS_PROG
      SET DATA_HASH = MD5(PROG_CODE);
   -- ---------------------
   -- UPDATE ICS_PROGS_VIOL
   -- ---------------------
   SET v_marker = 'UPDATE ICS_PROGS_VIOL 1';
   UPDATE ICS_PROGS_VIOL
      SET DATA_HASH = MD5(PROGS_VIOL_CODE);
   -- -------------------------
   -- UPDATE ICS_PROJ_SRCS_FUND
   -- -------------------------
   SET v_marker = 'UPDATE ICS_PROJ_SRCS_FUND 1';
   UPDATE ICS_PROJ_SRCS_FUND
      SET DATA_HASH = MD5(PROJ_SRCS_FUND_CODE);
   -- --------------------
   -- UPDATE ICS_PROJ_TYPE
   -- --------------------
   SET v_marker = 'UPDATE ICS_PROJ_TYPE 1';
   UPDATE ICS_PROJ_TYPE
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(PROJ_TYPE_CODE,'-*-')
                                        ,COALESCE(PROJ_TYPE_CODE_OTHR_DESC,'-*-'))
                                 ,'-*-','')
                         );
   -- ------------------------
   -- UPDATE ICS_REP_ANML_TYPE
   -- ------------------------
   SET v_marker = 'UPDATE ICS_REP_ANML_TYPE 1';
   UPDATE ICS_REP_ANML_TYPE
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(ANML_TYPE_CODE,'-*-')
                                        ,COALESCE(OTHR_ANML_TYPE_NAME,'-*-')
                                        ,COALESCE(TTL_NUM_EACH_LVSTCK,'-*-'))
                                 ,'-*-','')
                         );
   -- --------------------
   -- UPDATE ICS_REP_PARAM
   -- --------------------
   SET v_marker = 'UPDATE ICS_REP_PARAM 1';
   UPDATE ICS_REP_PARAM
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(PARAM_CODE,'-*-')
                                        ,COALESCE(MON_SITE_DESC_CODE,'-*-')
                                        ,COALESCE(LMT_SEASON_NUM,'-*-')
                                        ,COALESCE(REP_SMPL_TYPE_TXT,'-*-')
                                        ,COALESCE(REP_FREQ_CODE,'-*-')
                                        ,COALESCE(REP_NUM_OF_EXCURSIONS,'-*-')
                                        ,COALESCE(CONCEN_NUM_REP_UNIT_MEAS_CODE,'-*-')
                                        ,COALESCE(QTY_NUM_REP_UNIT_MEAS_CODE,'-*-'))
                                 ,'-*-','')
                         );
   -- ---------------------
   -- UPDATE ICS_RMVL_CRDTS
   -- ---------------------
   SET v_marker = 'UPDATE ICS_RMVL_CRDTS 1';
   UPDATE ICS_RMVL_CRDTS
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(MOS_RC_DATE_RMVL_CRDTS_APRVL,'-*-')
                                        ,COALESCE(RMVL_CRDTS_APPL_STAT_CODE,'-*-'))
                                 ,'-*-','')
                         );
   -- ---------------------------
   -- UPDATE ICS_RMVL_CRDTS_POLUT
   -- ---------------------------
   SET v_marker = 'UPDATE ICS_RMVL_CRDTS_POLUT 1';
   UPDATE ICS_RMVL_CRDTS_POLUT
      SET DATA_HASH = MD5(RMVL_CRDTS_POLUT_CODE);
   -- --------------------------
   -- UPDATE ICS_SATL_COLL_SYSTM
   -- --------------------------
   SET v_marker = 'UPDATE ICS_SATL_COLL_SYSTM 1';
   UPDATE ICS_SATL_COLL_SYSTM
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(SATL_COLL_SYSTM_IDENT,'-*-')
                                        ,COALESCE(SATL_COLL_SYSTM_NAME,'-*-'))
                                 ,'-*-','')
                         );
   -- ------------------------
   -- UPDATE ICS_SCHD_EVT_VIOL
   -- ------------------------
   SET v_marker = 'UPDATE ICS_SCHD_EVT_VIOL 1';
   -- ROOT TABLE HAS CONDITIONAL KEY, SKIPPING KEY_HASH CREATION
   UPDATE ICS_SCHD_EVT_VIOL
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(REP_NON_CMPL_RESL_CODE,'-*-')
                                        ,COALESCE(REP_NON_CMPL_RESL_DATE,'-*-'))
                                 ,'-*-','')
                         );
   -- -------------------
   -- UPDATE ICS_SIC_CODE
   -- -------------------
   SET v_marker = 'UPDATE ICS_SIC_CODE 1';
   UPDATE ICS_SIC_CODE
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(SIC_CODE,'-*-')
                                        ,COALESCE(SIC_PRIMARY_IND_CODE,'-*-'))
                                 ,'-*-','')
                         );
   -- ------------------------
   -- UPDATE ICS_SNGL_EVT_VIOL
   -- ------------------------
   SET v_marker = 'UPDATE ICS_SNGL_EVT_VIOL 1';
   UPDATE ICS_SNGL_EVT_VIOL
      SET KEY_HASH  = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(SNGL_EVT_VIOL_CODE,'-*-')
                                        ,COALESCE(SNGL_EVT_VIOL_DATE,'-*-'))
                                 ,'-*-','')
                         )
         ,DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(SNGL_EVT_VIOL_CODE,'-*-')
                                        ,COALESCE(SNGL_EVT_VIOL_DATE,'-*-')
                                        ,COALESCE(SNGL_EVT_VIOL_START_DATE,'-*-')
                                        ,COALESCE(SNGL_EVT_VIOL_END_DATE,'-*-')
                                        ,COALESCE(REP_NON_CMPL_DETECT_CODE,'-*-')
                                        ,COALESCE(REP_NON_CMPL_DETECT_DATE,'-*-')
                                        ,COALESCE(REP_NON_CMPL_RESL_CODE,'-*-')
                                        ,COALESCE(REP_NON_CMPL_RESL_DATE,'-*-')
                                        ,COALESCE(SNGL_EVT_USR_DFND_FLD_1,'-*-')
                                        ,COALESCE(SNGL_EVT_USR_DFND_FLD_2,'-*-')
                                        ,COALESCE(SNGL_EVT_USR_DFND_FLD_3,'-*-')
                                        ,COALESCE(SNGL_EVT_USR_DFND_FLD_4,'-*-')
                                        ,COALESCE(SNGL_EVT_USR_DFND_FLD_5,'-*-')
                                        ,COALESCE(SNGL_EVT_CMNT_TXT,'-*-'))
                                 ,'-*-','')
                         );
   -- -------------------------
   -- UPDATE ICS_SNGL_EVTS_VIOL
   -- -------------------------
   SET v_marker = 'UPDATE ICS_SNGL_EVTS_VIOL 1';
   UPDATE ICS_SNGL_EVTS_VIOL
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(SNGL_EVT_VIOL_CODE,'-*-')
                                        ,COALESCE(SNGL_EVT_VIOL_DATE,'-*-'))
                                 ,'-*-','')
                         );
   -- ------------------------
   -- UPDATE ICS_SSO_ANNUL_REP
   -- ------------------------
   SET v_marker = 'UPDATE ICS_SSO_ANNUL_REP 1';
   UPDATE ICS_SSO_ANNUL_REP
      SET KEY_HASH  = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(SSO_ANNUL_REP_RCVD_DATE,'-*-'))
                                 ,'-*-','')
                         )
         ,DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(SSO_ANNUL_REP_RCVD_DATE,'-*-')
                                        ,COALESCE(SSO_ANNUL_REP_YEAR,'-*-')
                                        ,COALESCE(NUM_SSO_EVTS_PER_YEAR,'-*-')
                                        ,COALESCE(VOL_SSO_EVTS_PER_YEAR,'-*-'))
                                 ,'-*-','')
                         );
   -- ----------------------
   -- UPDATE ICS_SSO_EVT_REP
   -- ----------------------
   SET v_marker = 'UPDATE ICS_SSO_EVT_REP 1';
   UPDATE ICS_SSO_EVT_REP
      SET KEY_HASH  = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(SSO_EVT_DATE,'-*-')
                                        ,COALESCE(SSO_EVT_ID,'-*-'))
                                 ,'-*-','')
                         )
         ,DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(CAUSE_SSO_OVRFLW_EVT,'-*-')
                                        ,COALESCE(LAT_MEAS,'-*-')
                                        ,COALESCE(LONG_MEAS,'-*-')
                                        ,COALESCE(SSO_OVRFLW_LOC_STREET,'-*-')
                                        ,COALESCE(DURATION_SSO_OVRFLW_EVT,'-*-')
                                        ,COALESCE(SSO_VOL,'-*-')
                                        ,COALESCE(NAME_RCVG_WTR,'-*-')
                                        ,COALESCE(DESC_STPS_TAKEN,'-*-'))
                                 ,'-*-','')
                         );
   -- -------------------
   -- UPDATE ICS_SSO_INSP
   -- -------------------
   SET v_marker = 'UPDATE ICS_SSO_INSP 1';
   UPDATE ICS_SSO_INSP
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(SSO_EVT_DATE,'-*-')
                                        ,COALESCE(CAUSE_SSO_OVRFLW_EVT,'-*-')
                                        ,COALESCE(LAT_MEAS,'-*-')
                                        ,COALESCE(LONG_MEAS,'-*-')
                                        ,COALESCE(SSO_OVRFLW_LOC_STREET,'-*-')
                                        ,COALESCE(DURATION_SSO_OVRFLW_EVT,'-*-')
                                        ,COALESCE(SSO_VOL,'-*-')
                                        ,COALESCE(NAME_RCVG_WTR,'-*-')
                                        ,COALESCE(DESC_STPS_TAKEN,'-*-'))
                                 ,'-*-','')
                         );
   -- ------------------------------
   -- UPDATE ICS_SSO_MONTHLY_EVT_REP
   -- ------------------------------
   SET v_marker = 'UPDATE ICS_SSO_MONTHLY_EVT_REP 1';
   UPDATE ICS_SSO_MONTHLY_EVT_REP
      SET KEY_HASH  = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(SSO_MONTHLY_REP_RCVD_DATE,'-*-'))
                                 ,'-*-','')
                         )
         ,DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(SSO_MONTHLY_REP_RCVD_DATE,'-*-')
                                        ,COALESCE(SSO_MONTHLY_EVT_MN,'-*-')
                                        ,COALESCE(SSO_MONTHLY_EVT_YEAR,'-*-')
                                        ,COALESCE(NUM_SSO_EVTS_REC_US_WTR_PER_MN,'-*-')
                                        ,COALESCE(VOL_SSO_EVTS_REC_US_WTR_PER_MN,'-*-'))
                                 ,'-*-','')
                         );
   -- -------------------
   -- UPDATE ICS_SSO_STPS
   -- -------------------
   SET v_marker = 'UPDATE ICS_SSO_STPS 1';
   UPDATE ICS_SSO_STPS
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(STPS_RDUCE_PREVNT_MITIGTE,'-*-')
                                        ,COALESCE(OTHR_STPS_RDUCE_PREVNT_MITIGTE,'-*-'))
                                 ,'-*-','')
                         );
   -- -------------------------
   -- UPDATE ICS_SSO_SYSTM_COMP
   -- -------------------------
   SET v_marker = 'UPDATE ICS_SSO_SYSTM_COMP 1';
   UPDATE ICS_SSO_SYSTM_COMP
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(SYSTM_COMP,'-*-')
                                        ,COALESCE(OTHR_SYSTM_COMP,'-*-'))
                                 ,'-*-','')
                         );
   -- -------------------------
   -- UPDATE ICS_SURF_DSPL_SITE
   -- -------------------------
   SET v_marker = 'UPDATE ICS_SURF_DSPL_SITE 1';
   UPDATE ICS_SURF_DSPL_SITE
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(PATHOGEN_REDUCTION_IND,'-*-')
                                        ,COALESCE(VECTOR_REDUCTION_IND,'-*-')
                                        ,COALESCE(MGMT_PRACTICES_IND,'-*-')
                                        ,COALESCE(CERT_STATEMENT_IND,'-*-')
                                        ,COALESCE(CERT_FIRST_NAME,'-*-')
                                        ,COALESCE(CERT_LAST_NAME,'-*-')
                                        ,COALESCE(CLASS_A_ALT_USED,'-*-')
                                        ,COALESCE(CLASS_A_ALTS_TXT,'-*-')
                                        ,COALESCE(CLASS_B_ALT_USED,'-*-')
                                        ,COALESCE(CLASS_B_ALTS_TXT,'-*-')
                                        ,COALESCE(VAR_ALT_USED,'-*-')
                                        ,COALESCE(VAR_ALTS_TXT,'-*-'))
                                 ,'-*-','')
                         );
   -- -----------------------------
   -- UPDATE ICS_SW_CNST_INDST_INSP
   -- -----------------------------
   SET v_marker = 'UPDATE ICS_SW_CNST_INDST_INSP 1';
   UPDATE ICS_SW_CNST_INDST_INSP
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(SWPPP_EVAL_BASIS_CODE,'-*-')
                                        ,COALESCE(SWPPP_EVAL_DATE,'-*-')
                                        ,COALESCE(SWPPP_EVAL_DESC_TXT,'-*-')
                                        ,COALESCE(NO_EXPOSURE_AUTH_DATE,'-*-'))
                                 ,'-*-','')
                         );
   -- -----------------------
   -- UPDATE ICS_SW_CNST_INSP
   -- -----------------------
   SET v_marker = 'UPDATE ICS_SW_CNST_INSP 1';
   UPDATE ICS_SW_CNST_INSP
      SET DATA_HASH = MD5(0);
   -- --------------------------------
   -- UPDATE ICS_SW_CNST_NON_CNST_INSP
   -- --------------------------------
   SET v_marker = 'UPDATE ICS_SW_CNST_NON_CNST_INSP 1';
   UPDATE ICS_SW_CNST_NON_CNST_INSP
     SET DATA_HASH = MD5(0);
   -- -----------------------
   -- UPDATE ICS_SW_CNST_PRMT
   -- -----------------------
   SET v_marker = 'UPDATE ICS_SW_CNST_PRMT 1';
   UPDATE ICS_SW_CNST_PRMT
      SET KEY_HASH  = MD5(PRMT_IDENT)
         ,DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(ST_WTR_BODY_NAME,'-*-')
                                        ,COALESCE(RCVG_MS_4_NAME,'-*-')
                                        ,COALESCE(IMPAIRED_WTR_IND,'-*-')
                                        ,COALESCE(HIST_PROP_IND,'-*-')
                                        ,COALESCE(HIST_PROP_CRIT_MET_CODE,'-*-')
                                        ,COALESCE(SPECIES_CRIT_HABITAT_IND,'-*-')
                                        ,COALESCE(SPECIES_CRIT_MET_CODE,'-*-')
                                        ,COALESCE(PROJ_TYPE_CODE,'-*-')
                                        ,COALESCE(EST_START_DATE,'-*-')
                                        ,COALESCE(EST_COMPLETE_DATE,'-*-')
                                        ,COALESCE(EST_AREA_DISTURBED_ACRES_NUM,'-*-')
                                        ,COALESCE(PROJ_PLAN_SIZE_CODE,'-*-'))
                                 ,'-*-','')
                         );
   -- ---------------------
   -- UPDATE ICS_SW_EVT_REP
   -- ---------------------
   SET v_marker = 'UPDATE ICS_SW_EVT_REP 1';
   UPDATE ICS_SW_EVT_REP
      SET KEY_HASH  = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(DATE_STRM_EVT_SMPL,'-*-')
                                        ,COALESCE(SW_EVT_ID,'-*-'))
                                 ,'-*-','')
                         )
         ,DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_FEATR_IDENT,'-*-')
                                        ,COALESCE(RAINFALL_STRM_EVT_SMPL_NUM,'-*-')
                                        ,COALESCE(DURATION_STRM_EVT_SMPL,'-*-')
                                        ,COALESCE(VOL_DSCH_SMPL,'-*-')
                                        ,COALESCE(DURATION_SINCE_LAST_STRM_EVT,'-*-')
                                        ,COALESCE(SMPL_BASIS_IND,'-*-')
                                        ,COALESCE(PRECIP_FORM,'-*-')
                                        ,COALESCE(SMPL_TAKEN_WITHIN_TIMEFRME_IND,'-*-')
                                        ,COALESCE(TIME_EXCEEDANCE_RATIONALE_CODE,'-*-')
                                        ,COALESCE(ESSEN_IDENTICAL_OUTFALL_NOTIF,'-*-')
                                        ,COALESCE(MON_EXEMPTION_RATIONALE_IND,'-*-')
                                        ,COALESCE(POLUT_MON_BASIS_CODE,'-*-'))
                                 ,'-*-','')
                         );
   -- ------------------------
   -- UPDATE ICS_SW_INDST_PRMT
   -- ------------------------
   SET v_marker = 'UPDATE ICS_SW_INDST_PRMT 1';
   UPDATE ICS_SW_INDST_PRMT
      SET KEY_HASH  = MD5(PRMT_IDENT)
         ,DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(ST_WTR_BODY_NAME,'-*-')
                                        ,COALESCE(RCVG_MS_4_NAME,'-*-')
                                        ,COALESCE(IMPAIRED_WTR_IND,'-*-')
                                        ,COALESCE(HIST_PROP_IND,'-*-')
                                        ,COALESCE(HIST_PROP_CRIT_MET_CODE,'-*-')
                                        ,COALESCE(SPECIES_CRIT_HABITAT_IND,'-*-')
                                        ,COALESCE(SPECIES_CRIT_MET_CODE,'-*-'))
                                 ,'-*-','')
                         );
   -- -----------------------
   -- UPDATE ICS_SW_MS_4_INSP
   -- -----------------------
   SET v_marker = 'UPDATE ICS_SW_MS_4_INSP 1';
   UPDATE ICS_SW_MS_4_INSP 
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(MS_4_ANNUL_EXPEN_DOLLARS,'-*-')
                                        ,COALESCE(MS_4_ANNUL_EXPEN_YEAR,'-*-')
                                        ,COALESCE(MS_4_BUDGET_DOLLARS,'-*-')
                                        ,COALESCE(MS_4_BUDGET_YEAR,'-*-')
                                        ,COALESCE(MAJOR_OUTFALL_EST_MEAS_IND,'-*-')
                                        ,COALESCE(MAJOR_OUTFALL_NUM,'-*-')
                                        ,COALESCE(MINOR_OUTFALL_EST_MEAS_IND,'-*-')
                                        ,COALESCE(MINOR_OUTFALL_NUM,'-*-'))
                                 ,'-*-','')
                         );
   -- ---------------------------
   -- UPDATE ICS_SW_NON_CNST_INSP
   -- ---------------------------
   SET v_marker = 'UPDATE ICS_SW_NON_CNST_INSP 1';
   UPDATE ICS_SW_NON_CNST_INSP
      SET DATA_HASH = MD5(0);
   -- ------------------------------
   -- UPDATE ICS_SW_UNPRMT_CNST_INSP
   -- ------------------------------
   SET v_marker = 'UPDATE ICS_SW_UNPRMT_CNST_INSP 1';
   UPDATE ICS_SW_UNPRMT_CNST_INSP
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(EST_START_DATE,'-*-')
                                        ,COALESCE(EST_COMPLETE_DATE,'-*-')
                                        ,COALESCE(EST_AREA_DISTURBED_ACRES_NUM,'-*-')
                                        ,COALESCE(PROJ_PLAN_SIZE_CODE,'-*-'))
                                 ,'-*-','')
                         );
   -- ----------------------------
   -- UPDATE ICS_SWMS_4_LARGE_PRMT
   -- ----------------------------
   SET v_marker = 'UPDATE ICS_SWMS_4_LARGE_PRMT 1';
   UPDATE ICS_SWMS_4_LARGE_PRMT
      SET KEY_HASH  = MD5(PRMT_IDENT)
         ,DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(ST_WTR_BODY_NAME,'-*-')
                                        ,COALESCE(RCVG_MS_4_NAME,'-*-')
                                        ,COALESCE(IMPAIRED_WTR_IND,'-*-')
                                        ,COALESCE(HIST_PROP_IND,'-*-')
                                        ,COALESCE(HIST_PROP_CRIT_MET_CODE,'-*-')
                                        ,COALESCE(SPECIES_CRIT_HABITAT_IND,'-*-')
                                        ,COALESCE(SPECIES_CRIT_MET_CODE,'-*-')
                                        ,COALESCE(LEGAL_ENTITY_TYPE_CODE,'-*-')
                                        ,COALESCE(MS_4_PRMT_CLASS_CODE,'-*-')
                                        ,COALESCE(MS_4_TYPE_CODE,'-*-')
                                        ,COALESCE(MS_4_ACREAGE_COVERED_NUM,'-*-')
                                        ,COALESCE(MS_4_POPL_SERVED_NUM,'-*-')
                                        ,COALESCE(URBANIZED_AREA_INCRP_PLCE_NAME,'-*-')
                                        ,COALESCE(MS_4_ANNUL_EXPEN_DOLLARS,'-*-')
                                        ,COALESCE(MS_4_ANNUL_EXPEN_YEAR,'-*-')
                                        ,COALESCE(MS_4_BUDGET_DOLLARS,'-*-')
                                        ,COALESCE(MS_4_BUDGET_YEAR,'-*-')
                                        ,COALESCE(PROJ_SRCS_OF_FUND_CODE,'-*-')
                                        ,COALESCE(MAJOR_OUTFALL_EST_MEAS_IND,'-*-')
                                        ,COALESCE(MAJOR_OUTFALL_NUM,'-*-')
                                        ,COALESCE(MINOR_OUTFALL_EST_MEAS_IND,'-*-')
                                        ,COALESCE(MINOR_OUTFALL_NUM,'-*-'))
                                 ,'-*-','')
                         );
   -- --------------------------
   -- UPDATE ICS_SWMS_4_PROG_REP
   -- --------------------------
   SET v_marker = 'UPDATE ICS_SWMS_4_PROG_REP 1';
   UPDATE ICS_SWMS_4_PROG_REP
      SET KEY_HASH  = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(SW_MS_4_REP_RCVD_DATE,'-*-'))
                                 ,'-*-','')
                         )
         ,DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(SW_MS_4_REP_RCVD_DATE,'-*-')
                                        ,COALESCE(MS_4_ANNUL_EXPEN_DOLLARS,'-*-')
                                        ,COALESCE(MS_4_ANNUL_EXPEN_YEAR,'-*-')
                                        ,COALESCE(MS_4_BUDGET_DOLLARS,'-*-')
                                        ,COALESCE(MS_4_BUDGET_YEAR,'-*-')
                                        ,COALESCE(MAJOR_OUTFALL_EST_MEAS_IND,'-*-')
                                        ,COALESCE(MAJOR_OUTFALL_NUM,'-*-')
                                        ,COALESCE(MINOR_OUTFALL_EST_MEAS_IND,'-*-')
                                        ,COALESCE(MINOR_OUTFALL_NUM,'-*-'))
                                 ,'-*-','')
                         );
   -- ----------------------------
   -- UPDATE ICS_SWMS_4_SMALL_PRMT
   -- ----------------------------
   SET v_marker = 'UPDATE ICS_SWMS_4_SMALL_PRMT 1';
   UPDATE ICS_SWMS_4_SMALL_PRMT
      SET KEY_HASH  = MD5(PRMT_IDENT)
         ,DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(ST_WTR_BODY_NAME,'-*-')
                                        ,COALESCE(RCVG_MS_4_NAME,'-*-')
                                        ,COALESCE(IMPAIRED_WTR_IND,'-*-')
                                        ,COALESCE(HIST_PROP_IND,'-*-')
                                        ,COALESCE(HIST_PROP_CRIT_MET_CODE,'-*-')
                                        ,COALESCE(SPECIES_CRIT_HABITAT_IND,'-*-')
                                        ,COALESCE(SPECIES_CRIT_MET_CODE,'-*-')
                                        ,COALESCE(LEGAL_ENTITY_TYPE_CODE,'-*-')
                                        ,COALESCE(MS_4_PRMT_CLASS_CODE,'-*-')
                                        ,COALESCE(MS_4_TYPE_CODE,'-*-')
                                        ,COALESCE(MS_4_ACREAGE_COVERED_NUM,'-*-')
                                        ,COALESCE(MS_4_POPL_SERVED_NUM,'-*-')
                                        ,COALESCE(URBANIZED_AREA_INCRP_PLCE_NAME,'-*-')
                                        ,COALESCE(MS_4_ANNUL_EXPEN_DOLLARS,'-*-')
                                        ,COALESCE(MS_4_ANNUL_EXPEN_YEAR,'-*-')
                                        ,COALESCE(MS_4_BUDGET_DOLLARS,'-*-')
                                        ,COALESCE(MS_4_BUDGET_YEAR,'-*-')
                                        ,COALESCE(PROJ_SRCS_OF_FUND_CODE,'-*-')
                                        ,COALESCE(MAJOR_OUTFALL_EST_MEAS_IND,'-*-')
                                        ,COALESCE(MAJOR_OUTFALL_NUM,'-*-')
                                        ,COALESCE(MINOR_OUTFALL_EST_MEAS_IND,'-*-')
                                        ,COALESCE(MINOR_OUTFALL_NUM,'-*-')
                                        ,COALESCE(QUAL_LOC_PROG_IND,'-*-')
                                        ,COALESCE(QUAL_LOC_PROG_DESC_TXT,'-*-')
                                        ,COALESCE(SHARED_RESP_IND,'-*-')
                                        ,COALESCE(SHARED_RESP_DESC_TXT,'-*-'))
                                 ,'-*-','')
                         );
   -- -----------------
   -- UPDATE ICS_TELEPH
   -- -----------------
   SET v_marker = 'UPDATE ICS_TELEPH 1';
   UPDATE ICS_TELEPH
      SET DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(TELEPH_NUM_TYPE_CODE,'-*-')
                                        ,COALESCE(TELEPH_NUM,'-*-')
                                        ,COALESCE(TELEPH_EXT_NUM,'-*-'))
                                 ,'-*-','')
                         );
   -- ---------------------
   -- UPDATE ICS_UNPRMT_FAC
   -- ---------------------
   SET v_marker = 'UPDATE ICS_UNPRMT_FAC 1';
   UPDATE ICS_UNPRMT_FAC
      SET KEY_HASH  = MD5(PRMT_IDENT)
         ,DATA_HASH = MD5(REPLACE(CONCAT(COALESCE(PRMT_IDENT,'-*-')
                                        ,COALESCE(FAC_SITE_NAME,'-*-')
                                        ,COALESCE(LOC_ADDR_TXT,'-*-')
                                        ,COALESCE(SUPPL_LOC_TXT,'-*-')
                                        ,COALESCE(LOCALITY_NAME,'-*-')
                                        ,COALESCE(LOC_ST_CODE,'-*-')
                                        ,COALESCE(LOC_ZIP_CODE,'-*-')
                                        ,COALESCE(LOC_COUNTRY_CODE,'-*-')
                                        ,COALESCE(ORG_DUNS_NUM,'-*-')
                                        ,COALESCE(ST_FAC_IDENT,'-*-')
                                        ,COALESCE(ST_RGN_CODE,'-*-')
                                        ,COALESCE(FAC_CONGR_DISTRICT_NUM,'-*-')
                                        ,COALESCE(FAC_TYPE_OF_OWNERSHIP_CODE,'-*-')
                                        ,COALESCE(FEDR_FAC_IDENT_NUM,'-*-')
                                        ,COALESCE(FEDR_AGNCY_CODE,'-*-')
                                        ,COALESCE(TRIBAL_LAND_CODE,'-*-')
                                        ,COALESCE(CNST_PROJ_NAME,'-*-')
                                        ,COALESCE(CNST_PROJ_LAT_MEAS,'-*-')
                                        ,COALESCE(CNST_PROJ_LONG_MEAS,'-*-')
                                        ,COALESCE(SECTION_TOWNSHIP_RNG,'-*-')
                                        ,COALESCE(FAC_CMNTS,'-*-')
                                        ,COALESCE(FAC_USR_DFND_FLD_1,'-*-')
                                        ,COALESCE(FAC_USR_DFND_FLD_2,'-*-')
                                        ,COALESCE(FAC_USR_DFND_FLD_3,'-*-')
                                        ,COALESCE(FAC_USR_DFND_FLD_4,'-*-')
                                        ,COALESCE(FAC_USR_DFND_FLD_5,'-*-')
                                        ,COALESCE(PRMT_CMNTS_TXT,'-*-'))
                                 ,'-*-','')
                         );
   -- ===================================================================
   -- Create KEY_HASH for modules with conditional keys (5 data families)
   -- ===================================================================
   -- -----------------------
   -- UPDATE ICS_CMPL_MON_LNK
   -- -----------------------
   SET v_marker = 'UPDATE ics_cmpl_mon_lnk 2';
   UPDATE ICS_CMPL_MON_LNK icml
     LEFT JOIN ICS_LNK_BS_REP  ilbs
       ON ilbs.ICS_CMPL_MON_LNK_ID = icml.ICS_CMPL_MON_LNK_ID
     LEFT JOIN ICS_LNK_CAFO_ANNUL_REP ilcar
       ON ilcar.ICS_CMPL_MON_LNK_ID = icml.ICS_CMPL_MON_LNK_ID
     LEFT JOIN ICS_LNK_CSO_EVT_REP ilcer
       ON ilcer.ICS_CMPL_MON_LNK_ID = icml.ICS_CMPL_MON_LNK_ID
     LEFT JOIN ICS_LNK_ENFRC_ACTN ilea
       ON ilea.ICS_CMPL_MON_LNK_ID = icml.ICS_CMPL_MON_LNK_ID
     LEFT JOIN ICS_LNK_LOC_LMTS_REP illlr
       ON illlr.ICS_CMPL_MON_LNK_ID = icml.ICS_CMPL_MON_LNK_ID
     LEFT JOIN ICS_LNK_PRETR_PERF_REP ilppr
       ON ilppr.ICS_CMPL_MON_LNK_ID = icml.ICS_CMPL_MON_LNK_ID
     LEFT JOIN ICS_LNK_SNGL_EVT ilse
       ON ilse.ICS_CMPL_MON_LNK_ID = icml.ICS_CMPL_MON_LNK_ID
     LEFT JOIN ICS_LNK_SSO_ANNUL_REP ilsar
       ON ilsar.ICS_CMPL_MON_LNK_ID = icml.ICS_CMPL_MON_LNK_ID
     LEFT JOIN ICS_LNK_SSO_EVT_REP ilser
       ON ilser.ICS_CMPL_MON_LNK_ID = icml.ICS_CMPL_MON_LNK_ID
     LEFT JOIN ICS_LNK_SSO_MONTHLY_EVT_REP ilsmer
       ON ilsmer.ICS_CMPL_MON_LNK_ID = icml.ICS_CMPL_MON_LNK_ID
     LEFT JOIN ICS_LNK_ST_CMPL_MON ilscm
       ON ilscm.ICS_CMPL_MON_LNK_ID = icml.ICS_CMPL_MON_LNK_ID
     LEFT JOIN ICS_LNK_SW_EVT_REP ilserp
       ON ilserp.ICS_CMPL_MON_LNK_ID = icml.ICS_CMPL_MON_LNK_ID
     LEFT JOIN ICS_LNK_SWMS_4_REP ils4r
       ON ils4r.ICS_CMPL_MON_LNK_ID = icml.ICS_CMPL_MON_LNK_ID
      SET icml.KEY_HASH = COALESCE( MD5(REPLACE(CONCAT(COALESCE(icml.PRMT_IDENT,'-*-')
                                                      ,COALESCE(icml.CMPL_MON_CATG_CODE,'-*-')
                                                      ,COALESCE(icml.CMPL_MON_DATE,'-*-')
                                                      ,COALESCE(ilbs.PRMT_IDENT,'-*-')
                                                      ,COALESCE(ilbs.REP_COVERAGE_END_DATE,'-*-')
                                                      ,COALESCE(ilcar.PRMT_IDENT,'-*-')
                                                      ,COALESCE(ilcar.PRMT_AUTH_REP_RCVD_DATE,'-*-')
                                                      ,COALESCE(ilcer.PRMT_IDENT,'-*-')
                                                      ,COALESCE(ilcer.CSO_EVT_DATE,'-*-')
                                                      ,COALESCE(ilcer.CSO_EVT_ID,'-*-')
                                                      ,COALESCE(ilea.ENFRC_ACTN_IDENT,'-*-')
                                                      ,COALESCE(illlr.PRMT_IDENT,'-*-')
                                                      ,COALESCE(illlr.PRMT_AUTH_REP_RCVD_DATE,'-*-')
                                                      ,COALESCE(ilppr.PRMT_IDENT,'-*-')
                                                      ,COALESCE(ilppr.PRETR_PERF_SUMM_END_DATE,'-*-')
                                                      ,COALESCE(ilse.PRMT_IDENT,'-*-')
                                                      ,COALESCE(ilse.SNGL_EVT_VIOL_CODE,'-*-')
                                                      ,COALESCE(ilse.SNGL_EVT_VIOL_DATE,'-*-')
                                                      ,COALESCE(ilsar.PRMT_IDENT,'-*-')
                                                      ,COALESCE(ilsar.SSO_ANNUL_REP_RCVD_DATE,'-*-')
                                                      ,COALESCE(ilser.PRMT_IDENT,'-*-')
                                                      ,COALESCE(ilser.SSO_EVT_DATE,'-*-')
                                                      ,COALESCE(ilser.SSO_EVT_ID,'-*-')
                                                      ,COALESCE(ilsmer.PRMT_IDENT,'-*-')
                                                      ,COALESCE(ilsmer.SSO_MONTHLY_REP_RCVD_DATE,'-*-')
                                                      ,COALESCE(ilscm.PRMT_IDENT,'-*-')
                                                      ,COALESCE(ilscm.CMPL_MON_CATG_CODE,'-*-')
                                                      ,COALESCE(ilscm.CMPL_MON_DATE,'-*-')
                                                      ,COALESCE(ilserp.PRMT_IDENT,'-*-')
                                                      ,COALESCE(ilserp.DATE_STRM_EVT_SMPL,'-*-')
                                                      ,COALESCE(ilserp.SW_EVT_ID,'-*-')
                                                      ,COALESCE(ils4r.PRMT_IDENT,'-*-')
                                                      ,COALESCE(ils4r.SW_MS_4_REP_RCVD_DATE,'-*-'))
                                      ,'-*-','')
                                  )
                                  ,icml.KEY_HASH);
   -- ------------------------
   -- UPDATE ICS_SCHD_EVT_VIOL
   -- ------------------------
   SET v_marker = 'UPDATE ics_schd_evt_viol 2';
   UPDATE ICS_SCHD_EVT_VIOL isev
     LEFT JOIN ICS_PRMT_SCHD_EVT_VIOL_ELEM  ipseve
       ON ipseve.ICS_SCHD_EVT_VIOL_ID = isev.ICS_SCHD_EVT_VIOL_ID
     LEFT JOIN ICS_CMPL_SCHD_EVT_VIOL_ELEM icseve
       ON icseve.ICS_SCHD_EVT_VIOL_ID = isev.ICS_SCHD_EVT_VIOL_ID
      SET isev.KEY_HASH = COALESCE(MD5(REPLACE(CONCAT(COALESCE(ipseve.PRMT_IDENT,'-*-')
                                                     ,COALESCE(ipseve.NARR_COND_NUM,'-*-')
                                                     ,COALESCE(ipseve.SCHD_EVT_CODE,'-*-')
                                                     ,COALESCE(ipseve.SCHD_DATE,'-*-')
                                                     ,COALESCE(ipseve.SCHD_VIOL_CODE,'-*-')
                                                     ,COALESCE(icseve.ENFRC_ACTN_IDENT,'-*-')
                                                     ,COALESCE(icseve.FINAL_ORDER_IDENT,'-*-')
                                                     ,COALESCE(icseve.PRMT_IDENT,'-*-')
                                                     ,COALESCE(icseve.CMPL_SCHD_NUM,'-*-')
                                                     ,COALESCE(icseve.SCHD_EVT_CODE,'-*-')
                                                     ,COALESCE(icseve.SCHD_DATE,'-*-')
                                                     ,COALESCE(icseve.SCHD_VIOL_CODE,'-*-'))
                                 ,'-*-','')
                         )
                                  ,isev.KEY_HASH);
   -- ---------------------------
   -- UPDATE ICS_DMR_PROG_REP_LNK
   -- ---------------------------
   SET v_marker = 'UPDATE ics_dmr_prog_rep_lnk 2';
   UPDATE ICS_DMR_PROG_REP_LNK idprl
     LEFT JOIN ICS_LNK_BS_REP ilbs
       ON ilbs.ICS_DMR_PROG_REP_LNK_ID = idprl.ICS_DMR_PROG_REP_LNK_ID
     LEFT JOIN ICS_LNK_SW_EVT_REP ilser
       ON ilser.ICS_DMR_PROG_REP_LNK_ID = idprl.ICS_DMR_PROG_REP_LNK_ID
      SET idprl.KEY_HASH = COALESCE(MD5(REPLACE(CONCAT(COALESCE(idprl.PRMT_IDENT,'-*-')
                                                      ,COALESCE(idprl.PRMT_FEATR_IDENT,'-*-')
                                                      ,COALESCE(idprl.LMT_SET_DESIGNATOR,'-*-')
                                                      ,COALESCE(idprl.MON_PERIOD_END_DATE,'-*-')
                                                      ,COALESCE(ilbs.PRMT_IDENT,'-*-')
                                                      ,COALESCE(ilbs.REP_COVERAGE_END_DATE,'-*-')
                                                      ,COALESCE(ilser.PRMT_IDENT,'-*-')
                                                      ,COALESCE(ilser.DATE_STRM_EVT_SMPL,'-*-')
                                                      ,COALESCE(ilser.SW_EVT_ID,'-*-'))
                                 ,'-*-','')
                         )
                                   ,idprl.KEY_HASH);
   -- ------------------------------
   -- UPDATE ICS_ENFRC_ACTN_VIOL_LNK
   -- ------------------------------
   SET v_marker = 'UPDATE ics_enfrc_actn_viol_lnk 2';
   UPDATE ICS_ENFRC_ACTN_VIOL_LNK ieavl
     LEFT JOIN ICS_PRMT_SCHD_VIOL ipsv
       ON ipsv.ICS_ENFRC_ACTN_VIOL_LNK_ID = ieavl.ICS_ENFRC_ACTN_VIOL_LNK_ID
     LEFT JOIN ICS_CMPL_SCHD_VIOL icsv
       ON icsv.ICS_ENFRC_ACTN_VIOL_LNK_ID = ieavl.ICS_ENFRC_ACTN_VIOL_LNK_ID
     LEFT JOIN ICS_DSCH_MON_REP_VIOL idmrv
       ON idmrv.ICS_ENFRC_ACTN_VIOL_LNK_ID = ieavl.ICS_ENFRC_ACTN_VIOL_LNK_ID
     LEFT JOIN ICS_DSCH_MON_REP_PARAM_VIOL idmrpv
       ON idmrpv.ICS_ENFRC_ACTN_VIOL_LNK_ID = ieavl.ICS_ENFRC_ACTN_VIOL_LNK_ID
     LEFT JOIN ICS_SNGL_EVTS_VIOL isev
       ON isev.ICS_ENFRC_ACTN_VIOL_LNK_ID = ieavl.ICS_ENFRC_ACTN_VIOL_LNK_ID
      SET ieavl.KEY_HASH = COALESCE(MD5(REPLACE(CONCAT(COALESCE(ieavl.ENFRC_ACTN_IDENT,'-*-')
                                                      ,COALESCE(ipsv.PRMT_IDENT,'-*-')
                                                      ,COALESCE(ipsv.NARR_COND_NUM,'-*-')
                                                      ,COALESCE(ipsv.SCHD_EVT_CODE,'-*-')
                                                      ,COALESCE(ipsv.SCHD_DATE,'-*-')
                                                      ,COALESCE(icsv.ENFRC_ACTN_IDENT,'-*-')
                                                      ,COALESCE(icsv.FINAL_ORDER_IDENT,'-*-')
                                                      ,COALESCE(icsv.PRMT_IDENT ,'-*-')
                                                      ,COALESCE(icsv.CMPL_SCHD_NUM,'-*-')
                                                      ,COALESCE(icsv.SCHD_EVT_CODE,'-*-')
                                                      ,COALESCE(icsv.SCHD_DATE,'-*-')
                                                      ,COALESCE(idmrv.PRMT_IDENT,'-*-')
                                                      ,COALESCE(idmrv.PRMT_FEATR_IDENT,'-*-')
                                                      ,COALESCE(idmrv.LMT_SET_DESIGNATOR,'-*-')
                                                      ,COALESCE(idmrv.MON_PERIOD_END_DATE,'-*-')
                                                      ,COALESCE(idmrpv.PRMT_IDENT,'-*-')
                                                      ,COALESCE(idmrpv.PRMT_FEATR_IDENT,'-*-')
                                                      ,COALESCE(idmrpv.LMT_SET_DESIGNATOR,'-*-')
                                                      ,COALESCE(idmrpv.MON_PERIOD_END_DATE,'-*-')
                                                      ,COALESCE(idmrpv.PARAM_CODE,'-*-')
                                                      ,COALESCE(idmrpv.MON_SITE_DESC_CODE,'-*-')
                                                      ,COALESCE(idmrpv.LMT_SEASON_NUM,'-*-')
                                                      ,COALESCE(isev.PRMT_IDENT,'-*-')
                                                      ,COALESCE(isev.SNGL_EVT_VIOL_CODE,'-*-')
                                                      ,COALESCE(isev.SNGL_EVT_VIOL_DATE,'-*-'))
                                 ,'-*-','')
                         )
                                   ,ieavl.KEY_HASH);
   -- -------------------------------
   -- UPDATE ICS_FINAL_ORDER_VIOL_LNK
   -- -------------------------------
   SET v_marker = 'UPDATE ics_final_order_viol_lnk 2';
   UPDATE ICS_FINAL_ORDER_VIOL_LNK ifovl
     LEFT JOIN ICS_PRMT_SCHD_VIOL ipsv
       ON ipsv.ICS_FINAL_ORDER_VIOL_LNK_ID = ifovl.ICS_FINAL_ORDER_VIOL_LNK_ID
     LEFT JOIN ICS_CMPL_SCHD_VIOL icsv
       ON icsv.ICS_FINAL_ORDER_VIOL_LNK_ID = ifovl.ICS_FINAL_ORDER_VIOL_LNK_ID
     LEFT JOIN ICS_DSCH_MON_REP_VIOL idmrv
       ON idmrv.ICS_FINAL_ORDER_VIOL_LNK_ID = ifovl.ICS_FINAL_ORDER_VIOL_LNK_ID
     LEFT JOIN ICS_DSCH_MON_REP_PARAM_VIOL idmrpv
       ON idmrpv.ICS_FINAL_ORDER_VIOL_LNK_ID = ifovl.ICS_FINAL_ORDER_VIOL_LNK_ID
     LEFT JOIN ICS_SNGL_EVTS_VIOL isev
       ON isev.ICS_FINAL_ORDER_VIOL_LNK_ID = ifovl.ICS_FINAL_ORDER_VIOL_LNK_ID
      SET ifovl.KEY_HASH = COALESCE(MD5(REPLACE(CONCAT(COALESCE(ifovl.ENFRC_ACTN_IDENT,'-*-')
                                                      ,COALESCE(ifovl.FINAL_ORDER_IDENT,'-*-')
                                                      ,COALESCE(ipsv.PRMT_IDENT,'-*-')
                                                      ,COALESCE(ipsv.NARR_COND_NUM,'-*-')
                                                      ,COALESCE(ipsv.SCHD_EVT_CODE,'-*-')
                                                      ,COALESCE(ipsv.SCHD_DATE,'-*-')
                                                      ,COALESCE(icsv.ENFRC_ACTN_IDENT,'-*-')
                                                      ,COALESCE(icsv.FINAL_ORDER_IDENT,'-*-')
                                                      ,COALESCE(icsv.PRMT_IDENT ,'-*-')
                                                      ,COALESCE(icsv.CMPL_SCHD_NUM,'-*-')
                                                      ,COALESCE(icsv.SCHD_EVT_CODE,'-*-')
                                                      ,COALESCE(icsv.SCHD_DATE,'-*-')
                                                      ,COALESCE(idmrv.PRMT_IDENT,'-*-')
                                                      ,COALESCE(idmrv.PRMT_FEATR_IDENT,'-*-')
                                                      ,COALESCE(idmrv.LMT_SET_DESIGNATOR,'-*-')
                                                      ,COALESCE(idmrv.MON_PERIOD_END_DATE,'-*-')
                                                      ,COALESCE(idmrpv.PRMT_IDENT,'-*-')
                                                      ,COALESCE(idmrpv.PRMT_FEATR_IDENT,'-*-')
                                                      ,COALESCE(idmrpv.LMT_SET_DESIGNATOR,'-*-')
                                                      ,COALESCE(idmrpv.MON_PERIOD_END_DATE,'-*-')
                                                      ,COALESCE(idmrpv.PARAM_CODE,'-*-')
                                                      ,COALESCE(idmrpv.MON_SITE_DESC_CODE,'-*-')
                                                      ,COALESCE(idmrpv.LMT_SEASON_NUM,'-*-')
                                                      ,COALESCE(isev.PRMT_IDENT,'-*-')
                                                      ,COALESCE(isev.SNGL_EVT_VIOL_CODE,'-*-')
                                                      ,COALESCE(isev.SNGL_EVT_VIOL_DATE,'-*-'))
                                 ,'-*-','')
                         )
                                   ,ifovl.KEY_HASH);
   -- -------------- --
   --  END PROCEDURE --
   -- -------------- --
   SET v_marker = 'CALL ics_etl_log_sp END';
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_sp_name     -- pi_marker
      ,NULL          -- pi_tgt_tbl
      ,NULL          -- pi_src_tbl 
      ,v_startdtm    -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'COMPLETED'   -- pi_process
      ,0);           -- pi_value
   --
   SET po_status = 1;
   SET po_errm   = 'COMPLETED';
END