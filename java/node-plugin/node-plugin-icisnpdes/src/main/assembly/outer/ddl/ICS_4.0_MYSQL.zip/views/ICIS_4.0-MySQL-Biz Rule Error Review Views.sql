DROP VIEW IF EXISTS ICS_V_BP_BASIC_PRMT_ERRORS;
CREATE VIEW ICS_V_BP_BASIC_PRMT_ERRORS AS
/*************************************************************************************************
** ObjectName: ICS_V_BP_BASIC_PRMT_ERRORS
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  Returns the Basic Permit records that return ICIS business rule violations
**
** Revision History:
** ------------------------------------------------------------------------------------------------
** Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 10/23/2012   Windsor      Created 
** 11/06/2012   Jen Go       Converted from Oracle to MySQL
***************************************************************************************************/
SELECT ICS_BASIC_PRMT.TRANSACTION_TYPE
     , ICS_BASIC_PRMT.PRMT_IDENT
     , ICS_BASIC_PRMT.PRMT_ISSUE_DATE
     , ICS_BASIC_PRMT.PRMT_EFFECTIVE_DATE
     , ICS_BASIC_PRMT.PRMT_EXPR_DATE
     , ICS_SUBM_RESULTS.RESULT_CODE
     , ICS_SUBM_RESULTS.RESULT_DESC
FROM ICS_BASIC_PRMT 
  JOIN ICS_SUBM_RESULTS
    ON ICS_BASIC_PRMT.PRMT_IDENT = ICS_SUBM_RESULTS.PRMT_IDENT 
WHERE RESULT_TYPE_CODE = 'Error'
  AND SUBM_TYPE_NAME = 'BasicPermitSubmission';

  
DROP VIEW IF EXISTS ICS_V_CM_CMPL_MON_ERRORS;
CREATE VIEW ICS_V_CM_CMPL_MON_ERRORS AS
/*************************************************************************************************
** ObjectName: ICS_V_CM_CMPL_MON_ERRORS
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  Returns the Compliance Monitoring records that return ICIS business rule violations
**
** Revision History:
** ------------------------------------------------------------------------------------------------
** Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 10/23/2012   Windsor     Created 
** 11/06/2012   Jen Go       Converted from Oracle to MySQL
***************************************************************************************************/
SELECT ICS_CMPL_MON.PRMT_IDENT
     , ICS_CMPL_MON.CMPL_MON_CATG_CODE
     , ICS_CMPL_MON.CMPL_MON_DATE
     , RESULT_CODE
     , RESULT_DESC
  FROM ICS_CMPL_MON 
  JOIN ICS_SUBM_RESULTS 
    ON ICS_SUBM_RESULTS.PRMT_IDENT = ICS_CMPL_MON.PRMT_IDENT
   AND ICS_SUBM_RESULTS.CMPL_MON_CATG_CODE = ICS_CMPL_MON.CMPL_MON_CATG_CODE
   AND ICS_SUBM_RESULTS.CMPL_MON_DATE = ICS_CMPL_MON.CMPL_MON_DATE
 WHERE ICS_SUBM_RESULTS.SUBM_TYPE_NAME = 'ComplianceMonitoringSubmission';
 
 
DROP VIEW IF EXISTS ICS_V_CS_CMPL_SCHD_ERRORS;
CREATE VIEW ICS_V_CS_CMPL_SCHD_ERRORS AS
/*************************************************************************************************
** ObjectName: ICS_V_CS_CMPL_SCHD_ERRORS
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  Returns the Compliance Schedule records that have ICIS business rule violations
**
** Revision History:
** ------------------------------------------------------------------------------------------------
** Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 10/23/2012   Windsor      Created 
** 11/06/2012   Jen Go       Converted from Oracle to MySQL
***************************************************************************************************/
SELECT ICS_CMPL_SCHD.TRANSACTION_TYPE
     , ICS_CMPL_SCHD.PRMT_IDENT
     , ICS_CMPL_SCHD.ENFRC_ACTN_IDENT
     , ICS_CMPL_SCHD.FINAL_ORDER_IDENT
     , ICS_CMPL_SCHD.CMPL_SCHD_NUM
     , ICS_CMPL_SCHD.SCHD_DESC_CODE
     , ICS_SUBM_RESULTS.RESULT_CODE
     , ICS_SUBM_RESULTS.RESULT_DESC
FROM ICS_CMPL_SCHD
  JOIN ICS_SUBM_RESULTS
    ON ICS_CMPL_SCHD.PRMT_IDENT = ICS_SUBM_RESULTS.PRMT_IDENT 
   AND ICS_CMPL_SCHD.ENFRC_ACTN_IDENT = ICS_SUBM_RESULTS.ENFRC_ACTN_IDENT
   AND ICS_CMPL_SCHD.FINAL_ORDER_IDENT = ICS_SUBM_RESULTS.FINAL_ORDER_IDENT
   AND ICS_CMPL_SCHD.CMPL_SCHD_NUM = ICS_SUBM_RESULTS.CMPL_SCHD_NUM
   AND ICS_CMPL_SCHD.ENFRC_ACTN_IDENT = ICS_SUBM_RESULTS.ENFRC_ACTN_IDENT
WHERE RESULT_TYPE_CODE IN ('Error','Warning')
  AND SUBM_TYPE_NAME = 'ComplianceScheduleSubmission';
  
  
DROP VIEW IF EXISTS ICS_V_DM_DMR_ERRORS;
CREATE VIEW ICS_V_DM_DMR_ERRORS AS
/*************************************************************************************************
** ObjectName: ICS_V_DM_DMR_ERRORS
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  Returns the DMR records that return ICIS business rule violations
**
** Revision History:
** ------------------------------------------------------------------------------------------------
** Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 10/18/2012   Windsor      Created 
** 11/06/2012   Jen Go       Converted from Oracle to MySQL
***************************************************************************************************/
SELECT ICS_SUBM_RESULTS.RESULT_CODE
     , ICS_SUBM_RESULTS.PRMT_IDENT
     , CONCAT(ICS_SUBM_RESULTS.PRMT_FEATR_IDENT
             ,ICS_SUBM_RESULTS.LMT_SET_DESIGNATOR) LIMIT_SET
     , ICS_REP_PARAM.PARAM_CODE 
     , ICS_REP_PARAM.MON_SITE_DESC_CODE MON_LOC
     , ICS_REP_PARAM.LMT_SEASON_NUM SEASON
     , ICS_SUBM_RESULTS.MON_PERIOD_END_DATE
     , ICS_DSCH_MON_REP.DMR_NO_DSCH_IND AS NODI
     , (SELECT CONCAT(NUM_REP_NO_DSCH_IND,NUM_COND_QTY)
          FROM ICS_NUM_REP 
         WHERE NUM_REP_CODE = 'Q1' 
           AND ICS_REP_PARAM_ID = ICS_REP_PARAM.ICS_REP_PARAM_ID 
         LIMIT 1) Q1
     , (SELECT CONCAT(NUM_REP_NO_DSCH_IND,NUM_COND_QTY)
          FROM ICS_NUM_REP 
         WHERE NUM_REP_CODE = 'Q2' 
           AND ICS_REP_PARAM_ID = ICS_REP_PARAM.ICS_REP_PARAM_ID
         LIMIT 1) Q2
     , QTY_NUM_REP_UNIT_MEAS_CODE QTY_UNIT
     , (SELECT CONCAT(NUM_REP_NO_DSCH_IND,NUM_COND_QTY)
          FROM ICS_NUM_REP 
         WHERE NUM_REP_CODE = 'C1' 
           AND ICS_REP_PARAM_ID = ICS_REP_PARAM.ICS_REP_PARAM_ID 
         LIMIT 1) C1
     , (SELECT CONCAT(NUM_REP_NO_DSCH_IND,NUM_COND_QTY)
          FROM ICS_NUM_REP
         WHERE NUM_REP_CODE = 'C2' 
           AND ICS_REP_PARAM_ID = ICS_REP_PARAM.ICS_REP_PARAM_ID 
         LIMIT 1) C2
     , (SELECT CONCAT(NUM_REP_NO_DSCH_IND,NUM_COND_QTY)
          FROM ICS_NUM_REP 
         WHERE NUM_REP_CODE = 'C3' 
           AND ICS_REP_PARAM_ID = ICS_REP_PARAM.ICS_REP_PARAM_ID
         LIMIT 1) C3
     , CONCEN_NUM_REP_UNIT_MEAS_CODE CNC_UNIT
     , RESULT_DESC
  FROM ICS_DSCH_MON_REP
  LEFT JOIN ICS_REP_PARAM
    ON ICS_REP_PARAM.ICS_DSCH_MON_REP_ID = ICS_DSCH_MON_REP.ICS_DSCH_MON_REP_ID
  JOIN ICS_SUBM_RESULTS 
    ON ICS_SUBM_RESULTS.PRMT_IDENT = ICS_DSCH_MON_REP.PRMT_IDENT
   AND ICS_SUBM_RESULTS.PRMT_FEATR_IDENT = ICS_DSCH_MON_REP.PRMT_FEATR_IDENT
   AND ICS_SUBM_RESULTS.LMT_SET_DESIGNATOR = ICS_DSCH_MON_REP.LMT_SET_DESIGNATOR
   AND ICS_SUBM_RESULTS.MON_PERIOD_END_DATE = ICS_DSCH_MON_REP.MON_PERIOD_END_DATE
   AND ICS_SUBM_RESULTS.PARAM_CODE = ICS_REP_PARAM.PARAM_CODE
   AND ICS_SUBM_RESULTS.MON_SITE_DESC_CODE = ICS_REP_PARAM.MON_SITE_DESC_CODE
   AND ICS_SUBM_RESULTS.LMT_SEASON_NUM = ICS_REP_PARAM.LMT_SEASON_NUM
 WHERE ICS_SUBM_RESULTS.RESULT_CODE LIKE 'DMR%'
 LIMIT 500;
   
   
DROP VIEW IF EXISTS ICS_V_ERRORS_BY_ERROR_TYPE;
CREATE VIEW ICS_V_ERRORS_BY_ERROR_TYPE AS
/*************************************************************************************************
** ObjectName: ICS_V_ERRORS_BY_ERROR_TYPE
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view provides a count of errors by error type as returned by ICIS in processing reports
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 05/14/2012   Windsor      Created 
** 08/22/2012   Windsor      Added result_type_code to subquery in select list.
** 10/30/2012   Brensmith    Added command line support for script
** 11/06/2012   Jen Go       Converted from Oracle to MySQL
***************************************************************************************************/
SELECT SUBM_TYPE_NAME
      , COUNT(1) AS ERROR_COUNT
      , RESULT_TYPE_CODE
      , RESULT_CODE
      , (SELECT RESULT_DESC
           FROM ICS_SUBM_RESULTS
          WHERE RESULT_CODE = RSLT.RESULT_CODE
            AND RESULT_TYPE_CODE = RSLT.RESULT_TYPE_CODE
            AND SUBM_TYPE_NAME = RSLT.SUBM_TYPE_NAME
          LIMIT 1
        ) AS FIRST_RESULT_DESC
  FROM ICS_SUBM_RESULTS RSLT
  GROUP BY SUBM_TYPE_NAME
          ,RESULT_TYPE_CODE
          ,RESULT_CODE
ORDER BY SUBM_TYPE_NAME,
    COUNT(1) DESC;

	
DROP VIEW IF EXISTS ICS_V_FA_FRML_ENFRC_ACTN_ERR;
CREATE VIEW ICS_V_FA_FRML_ENFRC_ACTN_ERR AS
/*************************************************************************************************
** ObjectName: ICS_V_FA_FRML_ENFRC_ACTN_ERR
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  Returns the Formal Enforcement Action records that have ICIS business rule violations
**
** Revision History:
** ------------------------------------------------------------------------------------------------
** Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 10/23/2012   Windsor      Created 
** 11/06/2012   Jen Go       Converted from Oracle to MySQL
***************************************************************************************************/
SELECT ICS_FRML_ENFRC_ACTN.TRANSACTION_TYPE
     , ICS_FRML_ENFRC_ACTN.ENFRC_ACTN_IDENT
     , ICS_FRML_ENFRC_ACTN.FORUM
     , ICS_FINAL_ORDER.FINAL_ORDER_IDENT
     , ICS_FINAL_ORDER.FINAL_ORDER_TYPE_CODE
     , ICS_SUBM_RESULTS.RESULT_CODE
     , ICS_SUBM_RESULTS.RESULT_DESC
FROM ICS_FRML_ENFRC_ACTN
  JOIN ICS_SUBM_RESULTS 
    ON ICS_FRML_ENFRC_ACTN.ENFRC_ACTN_IDENT = ICS_SUBM_RESULTS.ENFRC_ACTN_IDENT
  LEFT JOIN ICS_FINAL_ORDER
         ON ICS_FINAL_ORDER.ICS_FRML_ENFRC_ACTN_ID = ICS_FRML_ENFRC_ACTN.ICS_FRML_ENFRC_ACTN_ID
WHERE RESULT_TYPE_CODE IN ('Error','Warning')
  AND SUBM_TYPE_NAME = 'FormalEnforcementActionSubmission';
  
  
  
DROP VIEW IF EXISTS ICS_V_GP_GNRL_PRMT_ERRORS;
CREATE VIEW ICS_V_GP_GNRL_PRMT_ERRORS AS
/*************************************************************************************************
** ObjectName: ICS_V_GP_GNRL_PRMT_ERRORS
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  Returns the General Permit records that have ICIS business rule violations
**
** Revision History:
** ------------------------------------------------------------------------------------------------
** Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 10/23/2012   Windsor      Created 
** 11/06/2012   Jen Go       Converted from Oracle to MySQL
***************************************************************************************************/
SELECT ICS_GNRL_PRMT.TRANSACTION_TYPE
     , ICS_GNRL_PRMT.PRMT_IDENT
     , ICS_GNRL_PRMT.PRMT_ISSUE_DATE
     , ICS_GNRL_PRMT.PRMT_EFFECTIVE_DATE
     , ICS_GNRL_PRMT.PRMT_EXPR_DATE
     , ICS_SUBM_RESULTS.RESULT_CODE
     , ICS_SUBM_RESULTS.RESULT_DESC
FROM ICS_GNRL_PRMT 
  JOIN ICS_SUBM_RESULTS
    ON ICS_GNRL_PRMT.PRMT_IDENT = ICS_SUBM_RESULTS.PRMT_IDENT 
WHERE RESULT_TYPE_CODE = 'Error'
  AND SUBM_TYPE_NAME = 'GeneralPermitSubmission';
  
  
DROP VIEW IF EXISTS ICS_V_IA_INF_ENFRC_ACTN;
CREATE VIEW ICS_V_IA_INF_ENFRC_ACTN AS
/*************************************************************************************************
** ObjectName: ICS_V_IA_INF_ENFRC_ACTN
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  Returns the Informal Enforcement Action records that return ICIS business rule violations
**
** Revision History:
** ------------------------------------------------------------------------------------------------
** Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 10/23/2012   Windsor      Created 
**
***************************************************************************************************/
SELECT ICS_INFRML_ENFRC_ACTN.TRANSACTION_TYPE
     , ICS_INFRML_ENFRC_ACTN.ENFRC_ACTN_IDENT
     , ICS_INFRML_ENFRC_ACTN.ENFRC_ACTN_TYPE_CODE
     , ICS_SUBM_RESULTS.RESULT_CODE
     , ICS_SUBM_RESULTS.RESULT_DESC
FROM ICS_INFRML_ENFRC_ACTN  
  JOIN ICS_SUBM_RESULTS 
    ON ICS_INFRML_ENFRC_ACTN.ENFRC_ACTN_IDENT = ICS_SUBM_RESULTS.ENFRC_ACTN_IDENT
WHERE RESULT_TYPE_CODE IN ('Error','Warning')
  AND SUBM_TYPE_NAME = 'InformalEnforcementActionSubmission';
  
  
DROP VIEW IF EXISTS ICS_V_LS_LIMIT_SET_ERRORS;
CREATE VIEW ICS_V_LS_LIMIT_SET_ERRORS AS
/*************************************************************************************************
** ObjectName: ICS_V_LS_LIMIT_SET_ERRORS
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  Returns the Limit Set records that return ICIS business rule violations
**
** Revision History:
** ------------------------------------------------------------------------------------------------
** Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 10/23/2012   Windsor     Created 
** 11/06/2012   Jen Go       Converted from Oracle to MySQL
***************************************************************************************************/
SELECT ICS_LMT_SET.PRMT_IDENT
     , ICS_LMT_SET.PRMT_FEATR_IDENT
     , ICS_LMT_SET.LMT_SET_DESIGNATOR
     , ICS_LMT_SET_SCHD.INITIAL_MON_DATE
     , ICS_LMT_SET_SCHD.INITIAL_DMR_DUE_DATE
     , ICS_LMT_SET_STAT.LMT_SET_STAT_IND
     , ICS_LMT_SET_STAT.LMT_SET_STAT_START_DATE
     , RESULT_CODE
     , RESULT_DESC
  FROM ICS_LMT_SET
    JOIN ICS_SUBM_RESULTS
      ON ICS_SUBM_RESULTS.PRMT_IDENT = ICS_LMT_SET.PRMT_IDENT
     AND ICS_SUBM_RESULTS.PRMT_FEATR_IDENT = ICS_LMT_SET.PRMT_FEATR_IDENT
     AND ICS_SUBM_RESULTS.LMT_SET_DESIGNATOR = ICS_LMT_SET.LMT_SET_DESIGNATOR
  LEFT JOIN ICS_LMT_SET_SCHD
         ON ICS_LMT_SET_SCHD.ICS_LMT_SET_ID = ICS_LMT_SET.ICS_LMT_SET_ID
  LEFT JOIN ICS_LMT_SET_STAT
         ON ICS_LMT_SET_STAT.ICS_LMT_SET_ID = ICS_LMT_SET.ICS_LMT_SET_ID
 WHERE RESULT_TYPE_CODE IN ('Error','Warning')
   AND ICS_SUBM_RESULTS.SUBM_TYPE_NAME = 'LimitSetSubmission';
 
 
DROP VIEW IF EXISTS ICS_V_MGP_MSTR_GNRL_PRMT_ERR;
CREATE VIEW ICS_V_MGP_MSTR_GNRL_PRMT_ERR AS
/*************************************************************************************************
** ObjectName: ICS_V_MGP_MSTR_GNRL_PRMT_ERR
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  Returns the Master General Permit records that have ICIS business rule violations
**
** Revision History:
** ------------------------------------------------------------------------------------------------
** Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 10/23/2012   Windsor      Created 
** 11/06/2012   Jen Go       Converted from Oracle to MySQL
***************************************************************************************************/
SELECT ICS_GNRL_PRMT.TRANSACTION_TYPE
     , ICS_GNRL_PRMT.PRMT_IDENT
     , ICS_GNRL_PRMT.PRMT_ISSUE_DATE
     , ICS_GNRL_PRMT.PRMT_EFFECTIVE_DATE
     , ICS_GNRL_PRMT.PRMT_EXPR_DATE
     , ICS_SUBM_RESULTS.RESULT_CODE
     , ICS_SUBM_RESULTS.RESULT_DESC
FROM ICS_GNRL_PRMT 
  JOIN ICS_SUBM_RESULTS
    ON ICS_GNRL_PRMT.PRMT_IDENT = ICS_SUBM_RESULTS.PRMT_IDENT 
WHERE RESULT_TYPE_CODE = 'Error'
  AND SUBM_TYPE_NAME = 'MasterGeneralPermitSubmission';
  
 
DROP VIEW IF EXISTS ICS_V_PF_PRMT_FEATR_ERRORS;
CREATE VIEW ICS_V_NC_NARR_COND_SCHD_ERRORS AS
/*************************************************************************************************
** ObjectName: ICS_V_NC_NARR_COND_SCHD_ERRORS
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  Returns the Narrative Condition Schedule records that return ICIS business rule violations
**
** Revision History:
** ------------------------------------------------------------------------------------------------
** Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 10/23/2012   Windsor     Created 
** 11/06/2012   Jen Go       Converted from Oracle to MySQL
***************************************************************************************************/
SELECT ICS_NARR_COND_SCHD.PRMT_IDENT
     , ICS_NARR_COND_SCHD.NARR_COND_NUM
     , ICS_NARR_COND_SCHD.NARR_COND_CODE
     , RESULT_CODE
     , RESULT_DESC
  FROM ICS_NARR_COND_SCHD
  JOIN ICS_SUBM_RESULTS 
    ON ICS_SUBM_RESULTS.PRMT_IDENT = ICS_NARR_COND_SCHD.PRMT_IDENT
   AND ICS_SUBM_RESULTS.NARR_COND_NUM = ICS_NARR_COND_SCHD.NARR_COND_NUM
 WHERE ICS_SUBM_RESULTS.SUBM_TYPE_NAME = 'NarrativeConditionScheduleSubmission';
 

DROP VIEW IF EXISTS ICS_V_PF_PRMT_FEATR_ERRORS;
CREATE VIEW ICS_V_PF_PRMT_FEATR_ERRORS AS
/*************************************************************************************************
** ObjectName: ICS_V_PF_PRMT_FEATR_ERRORS
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  Returns the Permitted Feature records that return ICIS business rule violations
**
** Revision History:
** ------------------------------------------------------------------------------------------------
** Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 10/23/2012   Windsor      Created 
** 11/06/2012   Jen Go       Converted from Oracle to MySQL
***************************************************************************************************/
SELECT ICS_PRMT_FEATR.TRANSACTION_TYPE
     , ICS_PRMT_FEATR.PRMT_IDENT
     , ICS_PRMT_FEATR.PRMT_FEATR_IDENT
     , ICS_PRMT_FEATR.PRMT_FEATR_TYPE_CODE
     , ICS_SUBM_RESULTS.RESULT_CODE
     , ICS_SUBM_RESULTS.RESULT_DESC
FROM ICS_PRMT_FEATR
  JOIN ICS_SUBM_RESULTS
    ON ICS_PRMT_FEATR.PRMT_IDENT = ICS_SUBM_RESULTS.PRMT_IDENT 
   AND ICS_PRMT_FEATR.PRMT_FEATR_IDENT = ICS_SUBM_RESULTS.PRMT_FEATR_IDENT
WHERE RESULT_TYPE_CODE = 'Error'
  AND SUBM_TYPE_NAME = 'PermittedFeatureSubmission';
  
  
DROP VIEW IF EXISTS ICS_V_PL_PARAM_LMT_ACCEPTED;
CREATE VIEW ICS_V_PL_PARAM_LMT_ACCEPTED AS
/*************************************************************************************************
** ObjectName: ICS_V_PL_PARAM_LMT_ACCEPTED
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  Returns Parameter Limits that exist in ICIS
**
** Revision History:
** ------------------------------------------------------------------------------------------------
** Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 10/29/2012   Windsor      Created 
** 11/06/2012   Jen Go       Converted from Oracle to MySQL
***************************************************************************************************/
SELECT ICS_PARAM_LMTS.PRMT_IDENT
     , CONCAT(ICS_PARAM_LMTS.PRMT_FEATR_IDENT
             ,ICS_PARAM_LMTS.LMT_SET_DESIGNATOR)  LIMIT_SET
     , ICS_PARAM_LMTS.PARAM_CODE
     , ICS_PARAM_LMTS.MON_SITE_DESC_CODE MON_LOC
     , ICS_PARAM_LMTS.LMT_SEASON_NUM SEASON
     , ICS_LMT.LMT_START_DATE
     , ICS_LMT.LMT_END_DATE
     , COALESCE((SELECT CONCAT(NUM_COND_QUALIFIER
                              ,NUM_COND_QTY
                              ,' '
                              ,NUM_COND_STAT_BASE_CODE)
                   FROM ga_ics_flow_icis.ICS_NUM_COND 
                  WHERE NUM_COND_TXT = 'Q1' 
                    AND ICS_LMT_ID = ICS_LMT.ICS_LMT_ID),'*****') Q1
     , COALESCE((SELECT CONCAT(NUM_COND_QUALIFIER
                              ,NUM_COND_QTY
                              ,' ' 
                              ,NUM_COND_STAT_BASE_CODE)
                   FROM ga_ics_flow_icis.ICS_NUM_COND 
                  WHERE NUM_COND_TXT = 'Q2' 
                    AND ICS_LMT_ID = ICS_LMT.ICS_LMT_ID),'*****') Q2
     , QTY_NUM_COND_UNIT_MEAS_CODE QTY_UNIT
     , COALESCE((SELECT CONCAT(NUM_COND_QUALIFIER
                              ,NUM_COND_QTY
                              ,' '
                              ,NUM_COND_STAT_BASE_CODE)
                   FROM ga_ics_flow_icis.ICS_NUM_COND 
                  WHERE NUM_COND_TXT = 'C1' 
                    AND ICS_LMT_ID = ICS_LMT.ICS_LMT_ID),'*****') C1
     , COALESCE((SELECT CONCAT(NUM_COND_QUALIFIER
                              ,NUM_COND_QTY
                              ,' '
                              ,NUM_COND_STAT_BASE_CODE)
                   FROM ga_ics_flow_icis.ICS_NUM_COND 
                  WHERE NUM_COND_TXT = 'C2' 
                    AND ICS_LMT_ID = ICS_LMT.ICS_LMT_ID),'*****') C2
     , COALESCE((SELECT CONCAT(NUM_COND_QUALIFIER
                              ,NUM_COND_QTY
                              ,' '
                              ,NUM_COND_STAT_BASE_CODE)
                   FROM ga_ics_flow_icis.ICS_NUM_COND 
                  WHERE NUM_COND_TXT = 'C3' 
                    AND ICS_LMT_ID = ICS_LMT.ICS_LMT_ID),'*****') C3
     , CONCEN_NUM_COND_UNIT_MEAS_CODE CNC_UNIT
  FROM ga_ics_flow_icis.ICS_PARAM_LMTS ICS_PARAM_LMTS
  JOIN ga_ics_flow_icis.ICS_LMT ICS_LMT
    ON ICS_LMT.ICS_PARAM_LMTS_ID = ICS_PARAM_LMTS.ICS_PARAM_LMTS_ID;

DROP VIEW IF EXISTS ICS_V_PL_PARAM_LMT_ERRORS;
CREATE VIEW ICS_V_PL_PARAM_LMT_ERRORS AS
/*************************************************************************************************
** ObjectName: ICS_V_PL_PARAM_LMT_ERRORS
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  Returns the Parameter Limit records that return ICIS business rule violations
**
** Revision History:
** ------------------------------------------------------------------------------------------------
** Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 10/18/2012   Windsor      Created 
** 11/01/2012   Windsor      Fix typo in subm_type_name
** 11/06/2012   Jen Go       Converted from Oracle to MySQL
***************************************************************************************************/
SELECT ICS_SUBM_RESULTS.RESULT_CODE
     , ICS_SUBM_RESULTS.PRMT_IDENT
     , CONCAT(ICS_SUBM_RESULTS.PRMT_FEATR_IDENT
             ,ICS_SUBM_RESULTS.LMT_SET_DESIGNATOR) LIMIT_SET
     , ICS_SUBM_RESULTS.PARAM_CODE
     , ICS_SUBM_RESULTS.MON_SITE_DESC_CODE MON_LOC
     , ICS_SUBM_RESULTS.LMT_SEASON_NUM SEASON
     , ICS_LMT.LMT_START_DATE
     , ICS_LMT.LMT_END_DATE
     , COALESCE((SELECT CONCAT(NUM_COND_QUALIFIER
                              ,NUM_COND_QTY
                              ,' '
                              ,NUM_COND_STAT_BASE_CODE)
                   FROM ICS_NUM_COND 
                  WHERE NUM_COND_TXT = 'Q1' 
                    AND ICS_LMT_ID = ICS_LMT.ICS_LMT_ID),'*****') Q1
     , COALESCE((SELECT CONCAT(NUM_COND_QUALIFIER
                              ,NUM_COND_QTY
                              ,' '
                              ,NUM_COND_STAT_BASE_CODE)
                   FROM ICS_NUM_COND 
                  WHERE NUM_COND_TXT = 'Q2' 
                    AND ICS_LMT_ID = ICS_LMT.ICS_LMT_ID),'*****') Q2
     , QTY_NUM_COND_UNIT_MEAS_CODE QTY_UNIT
     , COALESCE((SELECT CONCAT(NUM_COND_QUALIFIER
                              ,NUM_COND_QTY
                              ,' '
                              ,NUM_COND_STAT_BASE_CODE)
                   FROM ICS_NUM_COND 
                  WHERE NUM_COND_TXT = 'C1' 
                    AND ICS_LMT_ID = ICS_LMT.ICS_LMT_ID),'*****') C1
     , COALESCE((SELECT CONCAT(NUM_COND_QUALIFIER
                              ,NUM_COND_QTY
                              ,' '
                              ,NUM_COND_STAT_BASE_CODE)
                   FROM ICS_NUM_COND 
                  WHERE NUM_COND_TXT = 'C2' 
                    AND ICS_LMT_ID = ICS_LMT.ICS_LMT_ID),'*****') C2
     , COALESCE((SELECT CONCAT(NUM_COND_QUALIFIER
                              ,NUM_COND_QTY
                              ,' '
                              ,NUM_COND_STAT_BASE_CODE)
                   FROM ICS_NUM_COND 
                  WHERE NUM_COND_TXT = 'C3' 
                    AND ICS_LMT_ID = ICS_LMT.ICS_LMT_ID),'*****') C3
     , CONCEN_NUM_COND_UNIT_MEAS_CODE CNC_UNIT
     , RESULT_DESC
  FROM ICS_PARAM_LMTS
  JOIN ICS_SUBM_RESULTS 
    ON ICS_SUBM_RESULTS.PRMT_IDENT = ICS_PARAM_LMTS.PRMT_IDENT
   AND ICS_SUBM_RESULTS.PRMT_FEATR_IDENT = ICS_PARAM_LMTS.PRMT_FEATR_IDENT
   AND ICS_SUBM_RESULTS.LMT_SET_DESIGNATOR = ICS_PARAM_LMTS.LMT_SET_DESIGNATOR
   AND ICS_SUBM_RESULTS.PARAM_CODE = ICS_PARAM_LMTS.PARAM_CODE
   AND ICS_SUBM_RESULTS.MON_SITE_DESC_CODE = ICS_PARAM_LMTS.MON_SITE_DESC_CODE
   AND ICS_SUBM_RESULTS.LMT_SEASON_NUM = ICS_PARAM_LMTS.LMT_SEASON_NUM
  LEFT JOIN ICS_LMT
    ON ICS_LMT.ICS_PARAM_LMTS_ID = ICS_PARAM_LMTS.ICS_PARAM_LMTS_ID
 WHERE RESULT_TYPE_CODE IN ('Error','Warning')
  AND SUBM_TYPE_NAME = 'ParameterLimitsSubmission';
 

DROP VIEW IF EXISTS ICS_V_PT_PRMT_REISSU_ERRORS;
CREATE VIEW ICS_V_PT_PRMT_REISSU_ERRORS AS
/*************************************************************************************************
** ObjectName: ICS_V_PT_PRMT_REISSU_ERRORS
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  Returns the Permit Reissuance records that have ICIS business rule violations
**
** Revision History:
** ------------------------------------------------------------------------------------------------
** Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 10/18/2012   Windsor      Created 
** 11/06/2012   Jen Go       Converted from Oracle to MySQL
***************************************************************************************************/
SELECT ICS_PRMT_REISSU.PRMT_IDENT
     , ICS_PRMT_REISSU.PRMT_ISSUE_DATE
     , ICS_PRMT_REISSU.PRMT_EFFECTIVE_DATE
     , ICS_PRMT_REISSU.PRMT_EXPR_DATE
     , ICS_SUBM_RESULTS.RESULT_CODE
     , ICS_SUBM_RESULTS.RESULT_DESC
  FROM ICS_PRMT_REISSU
  JOIN ICS_SUBM_RESULTS 
    ON ICS_SUBM_RESULTS.PRMT_IDENT = ICS_PRMT_REISSU.PRMT_IDENT
 WHERE RESULT_TYPE_CODE IN ('Error','Warning')
  AND SUBM_TYPE_NAME = 'PermitReissuanceSubmission';


DROP VIEW IF EXISTS ICS_V_PT_PRMT_TERM_ERRORS;
CREATE VIEW ICS_V_PT_PRMT_TERM_ERRORS AS
/*************************************************************************************************
** ObjectName: ICS_V_PT_PRMT_TERM_ERRORS
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  Returns the Permit Termination records that have ICIS business rule violations
**
** Revision History:
** ------------------------------------------------------------------------------------------------
** Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 10/18/2012   Windsor      Created 
** 11/06/2012   Jen Go       Converted from Oracle to MySQL
***************************************************************************************************/
SELECT ICS_PRMT_TERM.PRMT_IDENT
     , ICS_PRMT_TERM.PRMT_TERM_DATE
     , ICS_SUBM_RESULTS.RESULT_CODE
     , ICS_SUBM_RESULTS.RESULT_DESC
  FROM ICS_PRMT_TERM
  JOIN ICS_SUBM_RESULTS 
    ON ICS_SUBM_RESULTS.PRMT_IDENT = ICS_PRMT_TERM.PRMT_IDENT
 WHERE RESULT_TYPE_CODE IN ('Error','Warning')
  AND SUBM_TYPE_NAME = 'PermitTerminationSubmission';
  
  
DROP VIEW IF EXISTS ICS_V_PT_PRMT_TRACK_EVT_ERRORS;
CREATE VIEW ICS_V_PT_PRMT_TRACK_EVT_ERRORS AS
/*************************************************************************************************
** ObjectName: ICS_V_PT_PRMT_TRACK_EVT_ERRORS
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  Returns the Permit Tracking Event records that have ICIS business rule violations
**
** Revision History:
** ------------------------------------------------------------------------------------------------
** Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 10/18/2012   Windsor     Created 
** 11/06/2012   Jen Go       Converted from Oracle to MySQL
***************************************************************************************************/
SELECT ICS_PRMT_TRACK_EVT.PRMT_IDENT
     , ICS_PRMT_TRACK_EVT.PRMT_TRACK_EVT_CODE
     , ICS_PRMT_TRACK_EVT.PRMT_TRACK_EVT_DATE
     , ICS_SUBM_RESULTS.RESULT_CODE
     , ICS_SUBM_RESULTS.RESULT_DESC
  FROM ICS_PRMT_TRACK_EVT
  JOIN ICS_SUBM_RESULTS 
    ON ICS_SUBM_RESULTS.PRMT_IDENT = ICS_PRMT_TRACK_EVT.PRMT_IDENT
   AND ICS_SUBM_RESULTS.PRMT_TRACK_EVT_CODE = ICS_PRMT_TRACK_EVT.PRMT_TRACK_EVT_CODE
   AND ICS_SUBM_RESULTS.PRMT_TRACK_EVT_DATE = ICS_PRMT_TRACK_EVT.PRMT_TRACK_EVT_DATE
 WHERE RESULT_TYPE_CODE IN ('Error','Warning')
  AND SUBM_TYPE_NAME = 'PermitTrackingEventSubmission';





