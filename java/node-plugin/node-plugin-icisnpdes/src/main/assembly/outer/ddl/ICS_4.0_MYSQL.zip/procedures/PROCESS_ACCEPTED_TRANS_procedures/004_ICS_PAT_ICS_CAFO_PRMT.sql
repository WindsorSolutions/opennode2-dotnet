USE ga_ics_flow_local;
DROP PROCEDURE IF EXISTS ics_pat_ics_cafo_prmt;
CREATE PROCEDURE ics_pat_ics_cafo_prmt
   (IN  pi_transaction_id  VARCHAR(40)
   ,OUT po_status INT
   ,OUT po_errm   VARCHAR(255))
BEGIN
/******************************************************************************
** Object Name: ics_pat_ics_cafo_prmt
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  1) Process ICS_CAFO_PRMT
**                  called by: ICS_PROCESS_ACCEPTED_TRANS
**
** Revision History:
** ----------------------------------------------------------------------------
**  Date         Name        Description
** ----------------------------------------------------------------------------
** 20121102      JenGo       Converted from Oracle to MySQL.
**                           Modularized SP, added logging and error-handling
**                           called by: ICS_PROCESS_ACCEPTED_TRANS
** 20121106      JenGo       Modified DELETE FROM ga_ics_flow_icis.ICS_BASIC_PRMT
**                           MySQL errors out when the table being deleted is 
**                           used in the subquery.  To get around this either
**                           create a temp table or enclose the subquery in an
**                           inline view. 
*******************************************************************************/
   DECLARE v_startdtm
          ,v_enddtm     DATETIME;
   DECLARE v_sp_name    VARCHAR(64)  DEFAULT 'ics_pat_ics_cafo_prmt';
   DECLARE v_errstat    INT DEFAULT 1;
   DECLARE v_errm       VARCHAR(255);
   DECLARE v_marker     VARCHAR(255);
   --
   DECLARE EXIT HANDLER FOR SQLEXCEPTION
      BEGIN  
         ROLLBACK;
         SET po_status = -1;
         SET po_errm   = v_marker;
         CALL ics_etl_log_sp    
            (v_sp_name          -- pi_sp_name
            ,v_marker           -- pi_marker
            ,NULL               -- pi_tgt_tbl
            ,NULL               -- pi_src_tbl
            ,v_startdtm         -- pi_startdtm
            ,NOW()              -- pi_enddtm
            ,'FAILED'           -- pi_process
            ,-1);               -- pi_value
         COMMIT;
      END;
   --
   SET v_startdtm = NOW();
-- Remove any old records for ICS_CAFO_PRMT
-- /ICS_CAFO_PRMT/ICS_ADDR/ICS_TELEPH
SET v_marker = 'DELETE FROM -- /ICS_CAFO_PRMT/ICS_ADDR/ICS_TELEPH'; 
DELETE
  FROM ga_ics_flow_icis.ICS_TELEPH
 WHERE ICS_TELEPH.ICS_ADDR_ID IN
          (SELECT ICS_ADDR.ICS_ADDR_ID
             FROM ga_ics_flow_icis.ICS_CAFO_PRMT
                 LEFT JOIN ICS_SUBM_RESULTS ON ICS_SUBM_RESULTS.KEY_HASH = ICS_CAFO_PRMT.KEY_HASH 
                  JOIN ga_ics_flow_icis.ICS_ADDR ON ICS_ADDR.ICS_CAFO_PRMT_ID = ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID
              WHERE (RESULT_TYPE_CODE IN ('Accepted','Warning') AND SUBM_TYPE_NAME = 'CAFOPermitSubmission')
                 OR ICS_CAFO_PRMT.PRMT_IDENT IN (SELECT PRMT_IDENT FROM ICS_SUBM_RESULTS WHERE SUBM_TYPE_NAME = 'PermitTerminationSubmission' AND RESULT_TYPE_CODE = 'Accepted')
);
-- /ICS_CAFO_PRMT/ICS_CONTACT/ICS_TELEPH
SET v_marker = 'DELETE FROM -- /ICS_CAFO_PRMT/ICS_CONTACT/ICS_TELEPH'; 
DELETE
  FROM ga_ics_flow_icis.ICS_TELEPH
 WHERE ICS_TELEPH.ICS_CONTACT_ID IN
          (SELECT ICS_CONTACT.ICS_CONTACT_ID
             FROM ga_ics_flow_icis.ICS_CAFO_PRMT
                 LEFT JOIN ICS_SUBM_RESULTS ON ICS_SUBM_RESULTS.KEY_HASH = ICS_CAFO_PRMT.KEY_HASH 
                  JOIN ga_ics_flow_icis.ICS_CONTACT ON ICS_CONTACT.ICS_CAFO_PRMT_ID = ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID
              WHERE (RESULT_TYPE_CODE IN ('Accepted','Warning') AND SUBM_TYPE_NAME = 'CAFOPermitSubmission')
                 OR ICS_CAFO_PRMT.PRMT_IDENT IN (SELECT PRMT_IDENT FROM ICS_SUBM_RESULTS WHERE SUBM_TYPE_NAME = 'PermitTerminationSubmission' AND RESULT_TYPE_CODE = 'Accepted')
);
-- /ICS_CAFO_PRMT/ICS_ADDR
SET v_marker = 'DELETE FROM -- /ICS_CAFO_PRMT/ICS_ADDR'; 
DELETE
  FROM ga_ics_flow_icis.ICS_ADDR
 WHERE ICS_ADDR.ICS_CAFO_PRMT_ID IN
          (SELECT ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID
             FROM ga_ics_flow_icis.ICS_CAFO_PRMT
                 LEFT JOIN ICS_SUBM_RESULTS ON ICS_SUBM_RESULTS.KEY_HASH = ICS_CAFO_PRMT.KEY_HASH 
              WHERE (RESULT_TYPE_CODE IN ('Accepted','Warning') AND SUBM_TYPE_NAME = 'CAFOPermitSubmission')
                 OR ICS_CAFO_PRMT.PRMT_IDENT IN (SELECT PRMT_IDENT FROM ICS_SUBM_RESULTS WHERE SUBM_TYPE_NAME = 'PermitTerminationSubmission' AND RESULT_TYPE_CODE = 'Accepted')
);
-- /ICS_CAFO_PRMT/ICS_ANML_TYPE
SET v_marker = 'DELETE FROM -- /ICS_CAFO_PRMT/ICS_ANML_TYPE'; 
DELETE
  FROM ga_ics_flow_icis.ICS_ANML_TYPE
 WHERE ICS_ANML_TYPE.ICS_CAFO_PRMT_ID IN
          (SELECT ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID
             FROM ga_ics_flow_icis.ICS_CAFO_PRMT
                 LEFT JOIN ICS_SUBM_RESULTS ON ICS_SUBM_RESULTS.KEY_HASH = ICS_CAFO_PRMT.KEY_HASH 
              WHERE (RESULT_TYPE_CODE IN ('Accepted','Warning') AND SUBM_TYPE_NAME = 'CAFOPermitSubmission')
                 OR ICS_CAFO_PRMT.PRMT_IDENT IN (SELECT PRMT_IDENT FROM ICS_SUBM_RESULTS WHERE SUBM_TYPE_NAME = 'PermitTerminationSubmission' AND RESULT_TYPE_CODE = 'Accepted')
);
-- /ICS_CAFO_PRMT/ICS_CONTACT
SET v_marker = 'DELETE FROM -- /ICS_CAFO_PRMT/ICS_CONTACT'; 
DELETE
  FROM ga_ics_flow_icis.ICS_CONTACT
 WHERE ICS_CONTACT.ICS_CAFO_PRMT_ID IN
          (SELECT ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID
             FROM ga_ics_flow_icis.ICS_CAFO_PRMT
                 LEFT JOIN ICS_SUBM_RESULTS ON ICS_SUBM_RESULTS.KEY_HASH = ICS_CAFO_PRMT.KEY_HASH 
              WHERE (RESULT_TYPE_CODE IN ('Accepted','Warning') AND SUBM_TYPE_NAME = 'CAFOPermitSubmission')
                 OR ICS_CAFO_PRMT.PRMT_IDENT IN (SELECT PRMT_IDENT FROM ICS_SUBM_RESULTS WHERE SUBM_TYPE_NAME = 'PermitTerminationSubmission' AND RESULT_TYPE_CODE = 'Accepted')
);
-- /ICS_CAFO_PRMT/ICS_CONTAINMENT
SET v_marker = 'DELETE FROM -- /ICS_CAFO_PRMT/ICS_CONTAINMENT'; 
DELETE
  FROM ga_ics_flow_icis.ICS_CONTAINMENT
 WHERE ICS_CONTAINMENT.ICS_CAFO_PRMT_ID IN
          (SELECT ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID
             FROM ga_ics_flow_icis.ICS_CAFO_PRMT
                 LEFT JOIN ICS_SUBM_RESULTS ON ICS_SUBM_RESULTS.KEY_HASH = ICS_CAFO_PRMT.KEY_HASH 
              WHERE (RESULT_TYPE_CODE IN ('Accepted','Warning') AND SUBM_TYPE_NAME = 'CAFOPermitSubmission')
                 OR ICS_CAFO_PRMT.PRMT_IDENT IN (SELECT PRMT_IDENT FROM ICS_SUBM_RESULTS WHERE SUBM_TYPE_NAME = 'PermitTerminationSubmission' AND RESULT_TYPE_CODE = 'Accepted')
);
-- /ICS_CAFO_PRMT/ICS_LAND_APPL_BMP
SET v_marker = 'DELETE FROM -- /ICS_CAFO_PRMT/ICS_LAND_APPL_BMP'; 
DELETE
  FROM ga_ics_flow_icis.ICS_LAND_APPL_BMP
 WHERE ICS_LAND_APPL_BMP.ICS_CAFO_PRMT_ID IN
          (SELECT ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID
             FROM ga_ics_flow_icis.ICS_CAFO_PRMT
                 LEFT JOIN ICS_SUBM_RESULTS ON ICS_SUBM_RESULTS.KEY_HASH = ICS_CAFO_PRMT.KEY_HASH 
              WHERE (RESULT_TYPE_CODE IN ('Accepted','Warning') AND SUBM_TYPE_NAME = 'CAFOPermitSubmission')
                 OR ICS_CAFO_PRMT.PRMT_IDENT IN (SELECT PRMT_IDENT FROM ICS_SUBM_RESULTS WHERE SUBM_TYPE_NAME = 'PermitTerminationSubmission' AND RESULT_TYPE_CODE = 'Accepted')
);
-- /ICS_CAFO_PRMT/ICS_MNUR_LTTR_PRCSS_WW_STOR
SET v_marker = 'DELETE FROM -- /ICS_CAFO_PRMT/ICS_MNUR_LTTR_PRCSS_WW_STOR'; 
DELETE
  FROM ga_ics_flow_icis.ICS_MNUR_LTTR_PRCSS_WW_STOR
 WHERE ICS_MNUR_LTTR_PRCSS_WW_STOR.ICS_CAFO_PRMT_ID IN
          (SELECT ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID
             FROM ga_ics_flow_icis.ICS_CAFO_PRMT
                 LEFT JOIN ICS_SUBM_RESULTS ON ICS_SUBM_RESULTS.KEY_HASH = ICS_CAFO_PRMT.KEY_HASH 
              WHERE (RESULT_TYPE_CODE IN ('Accepted','Warning') AND SUBM_TYPE_NAME = 'CAFOPermitSubmission')
                 OR ICS_CAFO_PRMT.PRMT_IDENT IN (SELECT PRMT_IDENT FROM ICS_SUBM_RESULTS WHERE SUBM_TYPE_NAME = 'PermitTerminationSubmission' AND RESULT_TYPE_CODE = 'Accepted')
);
-- 20121106 -
-- /ICS_CAFO_PRMT
SET v_marker = 'DELETE FROM -- /ICS_CAFO_PRMT'; 
DELETE FROM ga_ics_flow_icis.ICS_CAFO_PRMT
 WHERE ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID IN
          (SELECT ICS_CAFO_PRMT_ID
             FROM (SELECT ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID
                     FROM ga_ics_flow_icis.ICS_CAFO_PRMT
                     LEFT JOIN ICS_SUBM_RESULTS
                       ON ICS_SUBM_RESULTS.KEY_HASH = ICS_CAFO_PRMT.KEY_HASH 
                    WHERE (    RESULT_TYPE_CODE IN ('Accepted','Warning') 
                           AND SUBM_TYPE_NAME = 'CAFOPermitSubmission')
                       OR ICS_CAFO_PRMT.PRMT_IDENT IN (SELECT PRMT_IDENT 
                                                         FROM ICS_SUBM_RESULTS 
                                                        WHERE SUBM_TYPE_NAME = 'PermitTerminationSubmission' 
                                                          AND RESULT_TYPE_CODE = 'Accepted')
                  ) vw
);
-- 20121106 

-- Add accepted records for ICS_CAFO_PRMT
-- /ICS_CAFO_PRMT
SET v_marker = 'INSERT INTO -- /ICS_CAFO_PRMT'; 
INSERT INTO  ga_ics_flow_icis.ICS_CAFO_PRMT
     SELECT ICS_CAFO_PRMT.*
       FROM ICS_CAFO_PRMT
       WHERE ICS_CAFO_PRMT.TRANSACTION_TYPE NOT IN ('D','X')
        AND KEY_HASH IN 
              (SELECT KEY_HASH
                 FROM ICS_SUBM_RESULTS
                WHERE RESULT_TYPE_CODE IN ('Accepted','Warning')
                  AND SUBM_TYPE_NAME = 'CAFOPermitSubmission');

-- /ICS_CAFO_PRMT/ICS_ADDR
SET v_marker = 'INSERT INTO -- /ICS_CAFO_PRMT/ICS_ADDR'; 
INSERT INTO  ga_ics_flow_icis.ICS_ADDR
     SELECT ICS_ADDR.*
       FROM ICS_ADDR
          JOIN ICS_CAFO_PRMT
            ON ICS_ADDR.ICS_CAFO_PRMT_ID = ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID
       WHERE ICS_CAFO_PRMT.TRANSACTION_TYPE NOT IN ('D','X')
        AND KEY_HASH IN 
              (SELECT KEY_HASH
                 FROM ICS_SUBM_RESULTS
                WHERE RESULT_TYPE_CODE IN ('Accepted','Warning')
                  AND SUBM_TYPE_NAME = 'CAFOPermitSubmission');

-- /ICS_CAFO_PRMT/ICS_ADDR/ICS_TELEPH
SET v_marker = 'INSERT INTO -- /ICS_CAFO_PRMT/ICS_ADDR/ICS_TELEPH'; 
INSERT INTO  ga_ics_flow_icis.ICS_TELEPH
     SELECT ICS_TELEPH.*
       FROM ICS_TELEPH
          JOIN ICS_ADDR
            ON ICS_TELEPH.ICS_ADDR_ID = ICS_ADDR.ICS_ADDR_ID
          JOIN ICS_CAFO_PRMT
            ON ICS_ADDR.ICS_CAFO_PRMT_ID = ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID
       WHERE ICS_CAFO_PRMT.TRANSACTION_TYPE NOT IN ('D','X')
        AND KEY_HASH IN 
              (SELECT KEY_HASH
                 FROM ICS_SUBM_RESULTS
                WHERE RESULT_TYPE_CODE IN ('Accepted','Warning')
                  AND SUBM_TYPE_NAME = 'CAFOPermitSubmission');

-- /ICS_CAFO_PRMT/ICS_ANML_TYPE
SET v_marker = 'INSERT INTO -- /ICS_CAFO_PRMT/ICS_ANML_TYPE'; 
INSERT INTO  ga_ics_flow_icis.ICS_ANML_TYPE
     SELECT ICS_ANML_TYPE.*
       FROM ICS_ANML_TYPE
          JOIN ICS_CAFO_PRMT
            ON ICS_ANML_TYPE.ICS_CAFO_PRMT_ID = ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID
       WHERE ICS_CAFO_PRMT.TRANSACTION_TYPE NOT IN ('D','X')
        AND KEY_HASH IN 
              (SELECT KEY_HASH
                 FROM ICS_SUBM_RESULTS
                WHERE RESULT_TYPE_CODE IN ('Accepted','Warning')
                  AND SUBM_TYPE_NAME = 'CAFOPermitSubmission');

-- /ICS_CAFO_PRMT/ICS_CONTACT
SET v_marker = 'INSERT INTO -- /ICS_CAFO_PRMT/ICS_CONTACT'; 
INSERT INTO  ga_ics_flow_icis.ICS_CONTACT
     SELECT ICS_CONTACT.*
       FROM ICS_CONTACT
          JOIN ICS_CAFO_PRMT
            ON ICS_CONTACT.ICS_CAFO_PRMT_ID = ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID
       WHERE ICS_CAFO_PRMT.TRANSACTION_TYPE NOT IN ('D','X')
        AND KEY_HASH IN 
              (SELECT KEY_HASH
                 FROM ICS_SUBM_RESULTS
                WHERE RESULT_TYPE_CODE IN ('Accepted','Warning')
                  AND SUBM_TYPE_NAME = 'CAFOPermitSubmission');

-- /ICS_CAFO_PRMT/ICS_CONTACT/ICS_TELEPH
SET v_marker = 'INSERT INTO -- /ICS_CAFO_PRMT/ICS_CONTACT/ICS_TELEPH'; 
INSERT INTO  ga_ics_flow_icis.ICS_TELEPH
     SELECT ICS_TELEPH.*
       FROM ICS_TELEPH
          JOIN ICS_CONTACT
            ON ICS_TELEPH.ICS_CONTACT_ID = ICS_CONTACT.ICS_CONTACT_ID
          JOIN ICS_CAFO_PRMT
            ON ICS_CONTACT.ICS_CAFO_PRMT_ID = ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID
       WHERE ICS_CAFO_PRMT.TRANSACTION_TYPE NOT IN ('D','X')
        AND KEY_HASH IN 
              (SELECT KEY_HASH
                 FROM ICS_SUBM_RESULTS
                WHERE RESULT_TYPE_CODE IN ('Accepted','Warning')
                  AND SUBM_TYPE_NAME = 'CAFOPermitSubmission');

-- /ICS_CAFO_PRMT/ICS_CONTAINMENT
SET v_marker = 'INSERT INTO -- /ICS_CAFO_PRMT/ICS_CONTAINMENT'; 
INSERT INTO  ga_ics_flow_icis.ICS_CONTAINMENT
     SELECT ICS_CONTAINMENT.*
       FROM ICS_CONTAINMENT
          JOIN ICS_CAFO_PRMT
            ON ICS_CONTAINMENT.ICS_CAFO_PRMT_ID = ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID
       WHERE ICS_CAFO_PRMT.TRANSACTION_TYPE NOT IN ('D','X')
        AND KEY_HASH IN 
              (SELECT KEY_HASH
                 FROM ICS_SUBM_RESULTS
                WHERE RESULT_TYPE_CODE IN ('Accepted','Warning')
                  AND SUBM_TYPE_NAME = 'CAFOPermitSubmission');

-- /ICS_CAFO_PRMT/ICS_LAND_APPL_BMP
SET v_marker = 'INSERT INTO -- /ICS_CAFO_PRMT/ICS_LAND_APPL_BMP'; 
INSERT INTO  ga_ics_flow_icis.ICS_LAND_APPL_BMP
     SELECT ICS_LAND_APPL_BMP.*
       FROM ICS_LAND_APPL_BMP
          JOIN ICS_CAFO_PRMT
            ON ICS_LAND_APPL_BMP.ICS_CAFO_PRMT_ID = ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID
       WHERE ICS_CAFO_PRMT.TRANSACTION_TYPE NOT IN ('D','X')
        AND KEY_HASH IN 
              (SELECT KEY_HASH
                 FROM ICS_SUBM_RESULTS
                WHERE RESULT_TYPE_CODE IN ('Accepted','Warning')
                  AND SUBM_TYPE_NAME = 'CAFOPermitSubmission');

-- /ICS_CAFO_PRMT/ICS_MNUR_LTTR_PRCSS_WW_STOR
SET v_marker = 'INSERT INTO -- /ICS_CAFO_PRMT/ICS_MNUR_LTTR_PRCSS_WW_STOR'; 
INSERT INTO  ga_ics_flow_icis.ICS_MNUR_LTTR_PRCSS_WW_STOR
     SELECT ICS_MNUR_LTTR_PRCSS_WW_STOR.*
       FROM ICS_MNUR_LTTR_PRCSS_WW_STOR
          JOIN ICS_CAFO_PRMT
            ON ICS_MNUR_LTTR_PRCSS_WW_STOR.ICS_CAFO_PRMT_ID = ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID
       WHERE ICS_CAFO_PRMT.TRANSACTION_TYPE NOT IN ('D','X')
        AND KEY_HASH IN 
              (SELECT KEY_HASH
                 FROM ICS_SUBM_RESULTS
                WHERE RESULT_TYPE_CODE IN ('Accepted','Warning')
                  AND SUBM_TYPE_NAME = 'CAFOPermitSubmission');
   -- -------------- --
   --  END PROCEDURE --
   -- -------------- --
   SET v_marker = 'CALL ics_etl_log_sp END';
   CALL ics_etl_log_sp
      (v_sp_name     -- pi_sp_name
      ,v_sp_name     -- pi_marker
      ,NULL          -- pi_tgt_tbl
      ,NULL          -- pi_src_tbl 
      ,v_startdtm    -- pi_startdtm
      ,NOW()         -- pi_enddtm
      ,'COMPLETED'   -- pi_process
      ,0);           -- pi_value
   --
   SET po_status = 1;
   SET po_errm   = '';
   -- 
END 