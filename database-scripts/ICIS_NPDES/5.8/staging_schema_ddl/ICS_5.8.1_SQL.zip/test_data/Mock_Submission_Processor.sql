/*

-- Mostly from the query below.  Need to fill in linkages (LATER) also take out nulls

select 
'insert into ICS_SUBM_RESULTS
(
ICS_SUBM_RESULTS_ID,SUBM_TYPE_NAME,TRANSACTION_TYPE
,' + KEYLIST
+',RESULT_CODE,RESULT_TYPE_CODE,RESULT_DESC
,SUBM_TRANSACTION_ID,KEY_HASH,CREATED_DATE_TIME)
select 
newid(),'''
+ Operation
+ ''' ,''R''
,' + KEYLIST 
+',null,''Accepted'',null
,''TRANSID000'',KEY_HASH,CURRENT_TIMESTAMP
 from ' + BASE_TABLE_NAME + ';' + CHAR(10)

 FROM
 (
 SELECT 
BASE_TABLE_NAME,
Operation,
KEYLIST = STUFF((
SELECT ',' + BKEYS.ColumnName
FROM
(
SELECT 
     TableName = t.name,
    -- IndexName = ind.name,
    -- IndexId = ind.index_id,
    -- ColumnId = ic.index_column_id,
     ColumnName = col.name
    --, ind.*,
    -- ic.*,
    -- col.* 
FROM 
     sys.indexes ind 
INNER JOIN 
     sys.index_columns ic ON  ind.object_id = ic.object_id and ind.index_id = ic.index_id 
INNER JOIN 
     sys.columns col ON ic.object_id = col.object_id and ic.column_id = col.column_id 
INNER JOIN 
     sys.tables t ON ind.object_id = t.object_id 
WHERE 
     ind.is_primary_key = 0 
     AND ind.is_unique = 1 
     AND ind.is_unique_constraint = 0 
     AND t.is_ms_shipped = 0 
) BKEYS
WHERE BKEYS.TableName = P.BASE_TABLE_NAME
FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'), 1, 1, '')
FROM ICS_PAYLOAD P

) vw
;

*/


delete from ICS_SUBM_TRACK where SUBM_TRANSACTION_ID = 'TRANSID000';

INSERT INTO ICS_SUBM_TRACK
(
	ICS_SUBM_TRACK_ID
      ,ETL_CMPL_DATE_TIME
      ,DET_CHANGE_CMPL_DATE_TIME
      ,SUBM_DATE_TIME
      ,SUBM_TRANSACTION_ID
      ,SUBM_TRANSACTION_STAT
      ,SUBM_STAT_DATE_TIME
      ,RSPN_PARSE_DATE_TIME
      ,WORKFLOW_STAT
      ,WORKFLOW_STAT_MESSAGE
)
SELECT 
	   newid() AS ICS_SUBM_TRACK_ID
      ,GETDATE() AS ETL_CMPL_DATE_TIME
      ,GETDATE() AS DET_CHANGE_CMPL_DATE_TIME
      ,GETDATE() AS SUBM_DATE_TIME
      ,'TRANSID000' AS SUBM_TRANSACTION_ID
      ,'Pending' AS SUBM_TRANSACTION_STAT
      ,GETDATE() AS SUBM_STAT_DATE_TIME
      ,NULL AS RSPN_PARSE_DATE_TIME
      ,'Pending' AS WORKFLOW_STAT
      ,'TEST for Fake Submission processor' WORKFLOW_STAT_MESSAGE
      
;

insert into ICS_SUBM_RESULTS
(
ICS_SUBM_RESULTS_ID,SUBM_TYPE_NAME,TRANSACTION_TYPE
,PRMT_IDENT,RESULT_CODE,RESULT_TYPE_CODE,RESULT_DESC
,SUBM_TRANSACTION_ID,KEY_HASH,CREATED_DATE_TIME)
select 
newid(),'BasicPermitSubmission' ,'R'
,PRMT_IDENT,null,'Accepted',null
,'TRANSID000',KEY_HASH,CURRENT_TIMESTAMP
 from ICS_BASIC_PRMT;

insert into ICS_SUBM_RESULTS
(
ICS_SUBM_RESULTS_ID,SUBM_TYPE_NAME,TRANSACTION_TYPE
,PRMT_IDENT,BS_ANNUL_REP_RCVD_DATE,RESULT_CODE,RESULT_TYPE_CODE,RESULT_DESC
,SUBM_TRANSACTION_ID,KEY_HASH,CREATED_DATE_TIME)
select 
newid(),'BiosolidsAnnualProgramReportSubmission' ,'R'
,PRMT_IDENT,BS_ANNUL_REP_RCVD_DATE,null,'Accepted',null
,'TRANSID000',KEY_HASH,CURRENT_TIMESTAMP
 from ICS_BS_ANNUL_PROG_REP;

insert into ICS_SUBM_RESULTS
(
ICS_SUBM_RESULTS_ID,SUBM_TYPE_NAME,TRANSACTION_TYPE
,PRMT_IDENT,RESULT_CODE,RESULT_TYPE_CODE,RESULT_DESC
,SUBM_TRANSACTION_ID,KEY_HASH,CREATED_DATE_TIME)
select 
newid(),'BiosolidsPermitSubmission' ,'R'
,PRMT_IDENT,null,'Accepted',null
,'TRANSID000',KEY_HASH,CURRENT_TIMESTAMP
 from ICS_BS_PRMT;

insert into ICS_SUBM_RESULTS
(
ICS_SUBM_RESULTS_ID,SUBM_TYPE_NAME,TRANSACTION_TYPE
,PRMT_IDENT,REP_COVERAGE_END_DATE,RESULT_CODE,RESULT_TYPE_CODE,RESULT_DESC
,SUBM_TRANSACTION_ID,KEY_HASH,CREATED_DATE_TIME)
select 
newid(),'BiosolidsProgramReportSubmission' ,'R'
,PRMT_IDENT,REP_COVERAGE_END_DATE,null,'Accepted',null
,'TRANSID000',KEY_HASH,CURRENT_TIMESTAMP
 from ICS_BS_PROG_REP;

insert into ICS_SUBM_RESULTS
(
ICS_SUBM_RESULTS_ID,SUBM_TYPE_NAME,TRANSACTION_TYPE
,PRMT_IDENT,PRMT_AUTH_REP_RCVD_DATE,RESULT_CODE,RESULT_TYPE_CODE,RESULT_DESC
,SUBM_TRANSACTION_ID,KEY_HASH,CREATED_DATE_TIME)
select 
newid(),'CAFOAnnualReportSubmission' ,'R'
,PRMT_IDENT,PRMT_AUTH_REP_RCVD_DATE,null,'Accepted',null
,'TRANSID000',KEY_HASH,CURRENT_TIMESTAMP
 from ICS_CAFO_ANNUL_REP;

insert into ICS_SUBM_RESULTS
(
ICS_SUBM_RESULTS_ID,SUBM_TYPE_NAME,TRANSACTION_TYPE
,PRMT_IDENT,RESULT_CODE,RESULT_TYPE_CODE,RESULT_DESC
,SUBM_TRANSACTION_ID,KEY_HASH,CREATED_DATE_TIME)
select 
newid(),'CAFOPermitSubmission' ,'R'
,PRMT_IDENT,null,'Accepted',null
,'TRANSID000',KEY_HASH,CURRENT_TIMESTAMP
 from ICS_CAFO_PRMT;

insert into ICS_SUBM_RESULTS
(
ICS_SUBM_RESULTS_ID,SUBM_TYPE_NAME,TRANSACTION_TYPE
,CMPL_MON_IDENT,RESULT_CODE,RESULT_TYPE_CODE,RESULT_DESC
,SUBM_TRANSACTION_ID,KEY_HASH,CREATED_DATE_TIME)
select 
newid(),'ComplianceMonitoringSubmission' ,'R'
,CMPL_MON_IDENT,null,'Accepted',null
,'TRANSID000',KEY_HASH,CURRENT_TIMESTAMP
 from ICS_CMPL_MON;
 
insert into ICS_SUBM_RESULTS
(
ICS_SUBM_RESULTS_ID,SUBM_TYPE_NAME,TRANSACTION_TYPE
,RESULT_CODE,RESULT_TYPE_CODE,RESULT_DESC
,SUBM_TRANSACTION_ID,KEY_HASH,CREATED_DATE_TIME,
cmpl_mon_ident
,prmt_ident_2
,sngl_evt_viol_code
,sngl_evt_viol_date
,enfrc_actn_ident
,rep_coverage_end_date
,prmt_auth_rep_rcvd_date
,cso_evt_date
,pretr_perf_summ_end_date
,sso_annul_rep_rcvd_date
,sso_evt_date
,sso_monthly_rep_rcvd_date
,date_strm_evt_smpl
,sw_ms_4_rep_rcvd_date
,cmpl_mon_ident_2
,evt_id
)select 
newid(),'ComplianceMonitoringLinkageSubmission' ,'R'
,null,'Accepted',null
,'TRANSID000',ics_cmpl_mon_lnk.KEY_HASH,CURRENT_TIMESTAMP
 ,ics_cmpl_mon_lnk.cmpl_mon_ident
						 -- ics_cmpl_mon_lnk.prmt_ident
						 -- , ics_cmpl_mon_lnk.cmpl_mon_catg_code
       --                --  , CONVERT(varchar(50), ics_cmpl_mon_lnk.cmpl_mon_date)
                         , COALESCE(
                                   ics_lnk_bs_rep.prmt_ident
                                   ,ics_lnk_cafo_annul_rep.prmt_ident
                                   ,ics_lnk_cso_evt_rep.prmt_ident
                                   ,ics_lnk_loc_lmts_rep.prmt_ident
                                   ,ics_lnk_pretr_perf_rep.prmt_ident
                                   ,ics_lnk_sngl_evt.prmt_ident
                                   ,ics_lnk_sso_annul_rep.prmt_ident
                                   ,ics_lnk_sso_evt_rep.prmt_ident
                                   ,ics_lnk_sso_monthly_evt_rep.prmt_ident
                                   ,ics_lnk_sw_evt_rep.prmt_ident
                                   ,ics_lnk_swms_4_rep.prmt_ident
                                   ,''
                                    ) -- prmt_ident2

                         , ics_lnk_sngl_evt.sngl_evt_viol_code
                         , CONVERT(varchar(50), ics_lnk_sngl_evt.sngl_evt_viol_date)
                         , CONVERT(varchar(50),ics_lnk_enfrc_actn.enfrc_actn_ident)
                         , CONVERT(varchar(50), ics_lnk_bs_rep.rep_coverage_end_date)
                         , COALESCE(
                          CONVERT(varchar(50), ics_lnk_cafo_annul_rep.prmt_auth_rep_rcvd_date)
                          ,CONVERT(varchar(50), ics_lnk_loc_lmts_rep.prmt_auth_rep_rcvd_date)
                          )
                         
                         , CONVERT(varchar(50), ics_lnk_cso_evt_rep.cso_evt_date)
                         , CONVERT(varchar(50), ics_lnk_pretr_perf_rep.pretr_perf_summ_end_date)
                         , CONVERT(varchar(50), ics_lnk_sso_annul_rep.sso_annul_rep_rcvd_date)
                         , CONVERT(varchar(50), ics_lnk_sso_evt_rep.sso_evt_date)
                         , CONVERT(varchar(50), ics_lnk_sso_monthly_evt_rep.sso_monthly_rep_rcvd_date)
                         , CONVERT(varchar(50), ics_lnk_sw_evt_rep.date_strm_evt_smpl)
                         , CONVERT(varchar(50), ics_lnk_swms_4_rep.sw_ms_4_rep_rcvd_date)
                         , ics_lnk_st_cmpl_mon.cmpl_mon_ident
                         , COALESCE(
                                      CONVERT(varchar(50), ics_lnk_cso_evt_rep.cso_evt_id)
                                      ,CONVERT(varchar(50), ics_lnk_sso_evt_rep.sso_evt_id)
                                      ,CONVERT(varchar(50), ics_lnk_sw_evt_rep.sw_evt_id)
                                      
                                    )
                         
	FROM dbo.ics_cmpl_mon_lnk ics_cmpl_mon_lnk
		LEFT JOIN dbo.ics_lnk_bs_rep ics_lnk_bs_rep on ics_lnk_bs_rep.ics_cmpl_mon_lnk_id = ics_cmpl_mon_lnk.ics_cmpl_mon_lnk_id
		LEFT JOIN dbo.ics_lnk_cafo_annul_rep ics_lnk_cafo_annul_rep on ics_lnk_cafo_annul_rep.ics_cmpl_mon_lnk_id = ics_cmpl_mon_lnk.ics_cmpl_mon_lnk_id
		LEFT JOIN dbo.ics_lnk_cso_evt_rep ics_lnk_cso_evt_rep on ics_lnk_cso_evt_rep.ics_cmpl_mon_lnk_id = ics_cmpl_mon_lnk.ics_cmpl_mon_lnk_id
		LEFT JOIN dbo.ics_lnk_enfrc_actn ics_lnk_enfrc_actn on ics_lnk_enfrc_actn.ics_cmpl_mon_lnk_id = ics_cmpl_mon_lnk.ics_cmpl_mon_lnk_id
		LEFT JOIN dbo.ics_lnk_loc_lmts_rep ics_lnk_loc_lmts_rep on ics_lnk_loc_lmts_rep.ics_cmpl_mon_lnk_id = ics_cmpl_mon_lnk.ics_cmpl_mon_lnk_id
		LEFT JOIN dbo.ics_lnk_pretr_perf_rep ics_lnk_pretr_perf_rep on ics_lnk_pretr_perf_rep.ics_cmpl_mon_lnk_id = ics_cmpl_mon_lnk.ics_cmpl_mon_lnk_id
		LEFT JOIN dbo.ics_lnk_sngl_evt ics_lnk_sngl_evt on ics_lnk_sngl_evt.ics_cmpl_mon_lnk_id = ics_cmpl_mon_lnk.ics_cmpl_mon_lnk_id
		LEFT JOIN dbo.ics_lnk_sso_annul_rep ics_lnk_sso_annul_rep on ics_lnk_sso_annul_rep.ics_cmpl_mon_lnk_id = ics_cmpl_mon_lnk.ics_cmpl_mon_lnk_id
		LEFT JOIN dbo.ics_lnk_sso_evt_rep ics_lnk_sso_evt_rep on ics_lnk_sso_evt_rep.ics_cmpl_mon_lnk_id = ics_cmpl_mon_lnk.ics_cmpl_mon_lnk_id
		LEFT JOIN dbo.ics_lnk_sso_monthly_evt_rep ics_lnk_sso_monthly_evt_rep on ics_lnk_sso_monthly_evt_rep.ics_cmpl_mon_lnk_id = ics_cmpl_mon_lnk.ics_cmpl_mon_lnk_id
		LEFT JOIN dbo.ics_lnk_st_cmpl_mon ics_lnk_st_cmpl_mon on ics_lnk_st_cmpl_mon.ics_cmpl_mon_lnk_id = ics_cmpl_mon_lnk.ics_cmpl_mon_lnk_id
		LEFT JOIN dbo.ics_lnk_sw_evt_rep ics_lnk_sw_evt_rep on ics_lnk_sw_evt_rep.ics_cmpl_mon_lnk_id = ics_cmpl_mon_lnk.ics_cmpl_mon_lnk_id
		LEFT JOIN dbo.ics_lnk_swms_4_rep ics_lnk_swms_4_rep on ics_lnk_swms_4_rep.ics_cmpl_mon_lnk_id = ics_cmpl_mon_lnk.ics_cmpl_mon_lnk_id;
	

insert into ICS_SUBM_RESULTS
(
ICS_SUBM_RESULTS_ID,SUBM_TYPE_NAME,TRANSACTION_TYPE
,ENFRC_ACTN_IDENT,FINAL_ORDER_IDENT,PRMT_IDENT,CMPL_SCHD_NUM,RESULT_CODE,RESULT_TYPE_CODE,RESULT_DESC
,SUBM_TRANSACTION_ID,KEY_HASH,CREATED_DATE_TIME)
select 
newid(),'ComplianceScheduleSubmission' ,'R'
,ENFRC_ACTN_IDENT,FINAL_ORDER_IDENT,PRMT_IDENT,CMPL_SCHD_NUM,null,'Accepted',null
,'TRANSID000',KEY_HASH,CURRENT_TIMESTAMP
 from ICS_CMPL_SCHD;

insert into ICS_SUBM_RESULTS
(
ICS_SUBM_RESULTS_ID,SUBM_TYPE_NAME,TRANSACTION_TYPE
,PRMT_IDENT,CSO_EVT_DATE,RESULT_CODE,RESULT_TYPE_CODE,RESULT_DESC
,SUBM_TRANSACTION_ID,KEY_HASH,CREATED_DATE_TIME)
select 
newid(),'CSOEventReportSubmission' ,'R'
,PRMT_IDENT,CSO_EVT_DATE,null,'Accepted',null
,'TRANSID000',KEY_HASH,CURRENT_TIMESTAMP
 from ICS_CSO_EVT_REP;

insert into ICS_SUBM_RESULTS
(
ICS_SUBM_RESULTS_ID,SUBM_TYPE_NAME,TRANSACTION_TYPE
,PRMT_IDENT,RESULT_CODE,RESULT_TYPE_CODE,RESULT_DESC
,SUBM_TRANSACTION_ID,KEY_HASH,CREATED_DATE_TIME)
select 
newid(),'CSOPermitSubmission' ,'R'
,PRMT_IDENT,null,'Accepted',null
,'TRANSID000',KEY_HASH,CURRENT_TIMESTAMP
 from ICS_CSO_PRMT;

insert into ICS_SUBM_RESULTS
(
ICS_SUBM_RESULTS_ID,SUBM_TYPE_NAME,TRANSACTION_TYPE
,PRMT_IDENT,PRMT_FEATR_IDENT,LMT_SET_DESIGNATOR,MON_PERIOD_END_DATE,RESULT_CODE,RESULT_TYPE_CODE,RESULT_DESC
,SUBM_TRANSACTION_ID,KEY_HASH,CREATED_DATE_TIME)
select 
newid(),'DischargeMonitoringReportSubmission' ,'R'
,PRMT_IDENT,PRMT_FEATR_IDENT,LMT_SET_DESIGNATOR,MON_PERIOD_END_DATE,null,'Accepted',null
,'TRANSID000',KEY_HASH,CURRENT_TIMESTAMP
 from ICS_DSCH_MON_REP;

insert into ICS_SUBM_RESULTS
(
ICS_SUBM_RESULTS_ID,SUBM_TYPE_NAME,TRANSACTION_TYPE
,PRMT_IDENT,PRMT_FEATR_IDENT,LMT_SET_DESIGNATOR,MON_PERIOD_END_DATE,RESULT_CODE,RESULT_TYPE_CODE,RESULT_DESC
,SUBM_TRANSACTION_ID,KEY_HASH,CREATED_DATE_TIME)
select 
newid(),'DMRProgramReportLinkageSubmission' ,'R'
,PRMT_IDENT,PRMT_FEATR_IDENT,LMT_SET_DESIGNATOR,MON_PERIOD_END_DATE,null,'Accepted',null
,'TRANSID000',KEY_HASH,CURRENT_TIMESTAMP
 from ICS_DMR_PROG_REP_LNK;

insert into ICS_SUBM_RESULTS
(
ICS_SUBM_RESULTS_ID,SUBM_TYPE_NAME,TRANSACTION_TYPE
,PRMT_IDENT,PRMT_FEATR_IDENT,LMT_SET_DESIGNATOR,MON_PERIOD_END_DATE,PARAM_CODE,MON_SITE_DESC_CODE,LMT_SEASON_NUM,NUM_REP_CODE,NUM_REP_VIOL_CODE,RESULT_CODE,RESULT_TYPE_CODE,RESULT_DESC
,SUBM_TRANSACTION_ID,KEY_HASH,CREATED_DATE_TIME)
select 
newid(),'DMRViolationSubmission' ,'R'
,PRMT_IDENT,PRMT_FEATR_IDENT,LMT_SET_DESIGNATOR,MON_PERIOD_END_DATE,PARAM_CODE,MON_SITE_DESC_CODE,LMT_SEASON_NUM,NUM_REP_CODE,NUM_REP_VIOL_CODE,null,'Accepted',null
,'TRANSID000',KEY_HASH,CURRENT_TIMESTAMP
 from ICS_DMR_VIOL;

insert into ICS_SUBM_RESULTS
(
ICS_SUBM_RESULTS_ID,SUBM_TYPE_NAME,TRANSACTION_TYPE
,PRMT_IDENT,PRMT_FEATR_IDENT,LMT_SET_DESIGNATOR,PARAM_CODE,MON_SITE_DESC_CODE,LMT_SEASON_NUM,LMT_START_DATE,LMT_END_DATE,LMT_MOD_EFFECTIVE_DATE,TRADE_ID,RESULT_CODE,RESULT_TYPE_CODE,RESULT_DESC
,SUBM_TRANSACTION_ID,KEY_HASH,CREATED_DATE_TIME)
select 
newid(),'EffluentTradePartnerSubmission' ,'R'
,PRMT_IDENT,PRMT_FEATR_IDENT,LMT_SET_DESIGNATOR,PARAM_CODE,MON_SITE_DESC_CODE,LMT_SEASON_NUM,LMT_START_DATE,LMT_END_DATE,LMT_MOD_EFFECTIVE_DATE,TRADE_ID,null,'Accepted',null
,'TRANSID000',KEY_HASH,CURRENT_TIMESTAMP
 from ICS_EFFLU_TRADE_PRTNER;

insert into ICS_SUBM_RESULTS
(
ICS_SUBM_RESULTS_ID,SUBM_TYPE_NAME,TRANSACTION_TYPE
,ENFRC_ACTN_IDENT,MILESTONE_TYPE_CODE,RESULT_CODE,RESULT_TYPE_CODE,RESULT_DESC
,SUBM_TRANSACTION_ID,KEY_HASH,CREATED_DATE_TIME)
select 
newid(),'EnforcementActionMilestoneSubmission' ,'R'
,ENFRC_ACTN_IDENT,MILESTONE_TYPE_CODE,null,'Accepted',null
,'TRANSID000',KEY_HASH,CURRENT_TIMESTAMP
 from ICS_ENFRC_ACTN_MILESTONE;


insert into ICS_SUBM_RESULTS
(
ICS_SUBM_RESULTS_ID,SUBM_TYPE_NAME,TRANSACTION_TYPE
,ENFRC_ACTN_IDENT,RESULT_CODE,RESULT_TYPE_CODE,RESULT_DESC
,SUBM_TRANSACTION_ID,KEY_HASH,CREATED_DATE_TIME)
select 
newid(),'FormalEnforcementActionSubmission' ,'R'
,ENFRC_ACTN_IDENT,null,'Accepted',null
,'TRANSID000',KEY_HASH,CURRENT_TIMESTAMP
 from ICS_FRML_ENFRC_ACTN;

insert into ICS_SUBM_RESULTS
(
ICS_SUBM_RESULTS_ID,SUBM_TYPE_NAME,TRANSACTION_TYPE
,PRMT_IDENT,RESULT_CODE,RESULT_TYPE_CODE,RESULT_DESC
,SUBM_TRANSACTION_ID,KEY_HASH,CREATED_DATE_TIME)
select 
newid(),'GeneralPermitSubmission' ,'R'
,PRMT_IDENT,null,'Accepted',null
,'TRANSID000',KEY_HASH,CURRENT_TIMESTAMP
 from ICS_GNRL_PRMT;

insert into ICS_SUBM_RESULTS
(
ICS_SUBM_RESULTS_ID,SUBM_TYPE_NAME,TRANSACTION_TYPE
,PRMT_IDENT,PRMT_EFFECTIVE_DATE,NARR_COND_NUM,SCHD_EVT_CODE,SCHD_DATE,RESULT_CODE,RESULT_TYPE_CODE,RESULT_DESC
,SUBM_TRANSACTION_ID,KEY_HASH,CREATED_DATE_TIME)
select 
newid(),'HistoricalPermitScheduleEventsSubmission' ,'R'
,PRMT_IDENT,PRMT_EFFECTIVE_DATE,NARR_COND_NUM,SCHD_EVT_CODE,SCHD_DATE,null,'Accepted',null
,'TRANSID000',KEY_HASH,CURRENT_TIMESTAMP
 from ICS_HIST_PRMT_SCHD_EVTS;

insert into ICS_SUBM_RESULTS
(
ICS_SUBM_RESULTS_ID,SUBM_TYPE_NAME,TRANSACTION_TYPE
,ENFRC_ACTN_IDENT,RESULT_CODE,RESULT_TYPE_CODE,RESULT_DESC
,SUBM_TRANSACTION_ID,KEY_HASH,CREATED_DATE_TIME)
select 
newid(),'InformalEnforcementActionSubmission' ,'R'
,ENFRC_ACTN_IDENT,null,'Accepted',null
,'TRANSID000',KEY_HASH,CURRENT_TIMESTAMP
 from ICS_INFRML_ENFRC_ACTN;

insert into ICS_SUBM_RESULTS
(
ICS_SUBM_RESULTS_ID,SUBM_TYPE_NAME,TRANSACTION_TYPE
,PRMT_IDENT,PRMT_FEATR_IDENT,LMT_SET_DESIGNATOR,PARAM_CODE,MON_SITE_DESC_CODE,LMT_SEASON_NUM,LMT_START_DATE,LMT_END_DATE,RESULT_CODE,RESULT_TYPE_CODE,RESULT_DESC
,SUBM_TRANSACTION_ID,KEY_HASH,CREATED_DATE_TIME)
select 
newid(),'LimitsSubmission' ,'R'
,PRMT_IDENT,PRMT_FEATR_IDENT,LMT_SET_DESIGNATOR,PARAM_CODE,MON_SITE_DESC_CODE,LMT_SEASON_NUM,LMT_START_DATE,LMT_END_DATE,null,'Accepted',null
,'TRANSID000',KEY_HASH,CURRENT_TIMESTAMP
 from ICS_LMTS;

insert into ICS_SUBM_RESULTS
(
ICS_SUBM_RESULTS_ID,SUBM_TYPE_NAME,TRANSACTION_TYPE
,PRMT_IDENT,PRMT_FEATR_IDENT,LMT_SET_DESIGNATOR,RESULT_CODE,RESULT_TYPE_CODE,RESULT_DESC
,SUBM_TRANSACTION_ID,KEY_HASH,CREATED_DATE_TIME)
select 
newid(),'LimitSetSubmission' ,'R'
,PRMT_IDENT,PRMT_FEATR_IDENT,LMT_SET_DESIGNATOR,null,'Accepted',null
,'TRANSID000',KEY_HASH,CURRENT_TIMESTAMP
 from ICS_LMT_SET;

insert into ICS_SUBM_RESULTS
(
ICS_SUBM_RESULTS_ID,SUBM_TYPE_NAME,TRANSACTION_TYPE
,PRMT_IDENT,PRMT_AUTH_REP_RCVD_DATE,RESULT_CODE,RESULT_TYPE_CODE,RESULT_DESC
,SUBM_TRANSACTION_ID,KEY_HASH,CREATED_DATE_TIME)
select 
newid(),'LocalLimitsProgramReportSubmission' ,'R'
,PRMT_IDENT,PRMT_AUTH_REP_RCVD_DATE,null,'Accepted',null
,'TRANSID000',KEY_HASH,CURRENT_TIMESTAMP
 from ICS_LOC_LMTS_PROG_REP;


insert into ICS_SUBM_RESULTS
(
ICS_SUBM_RESULTS_ID,SUBM_TYPE_NAME,TRANSACTION_TYPE
,PRMT_IDENT,NARR_COND_NUM,RESULT_CODE,RESULT_TYPE_CODE,RESULT_DESC
,SUBM_TRANSACTION_ID,KEY_HASH,CREATED_DATE_TIME)
select 
newid(),'NarrativeConditionScheduleSubmission' ,'R'
,PRMT_IDENT,NARR_COND_NUM,null,'Accepted',null
,'TRANSID000',KEY_HASH,CURRENT_TIMESTAMP
 from ICS_NARR_COND_SCHD;

insert into ICS_SUBM_RESULTS
(
ICS_SUBM_RESULTS_ID,SUBM_TYPE_NAME,TRANSACTION_TYPE
,PRMT_IDENT,PRMT_FEATR_IDENT,LMT_SET_DESIGNATOR,PARAM_CODE,MON_SITE_DESC_CODE,LMT_SEASON_NUM,RESULT_CODE,RESULT_TYPE_CODE,RESULT_DESC
,SUBM_TRANSACTION_ID,KEY_HASH,CREATED_DATE_TIME)
select 
newid(),'ParameterLimitsSubmission' ,'R'
,PRMT_IDENT,PRMT_FEATR_IDENT,LMT_SET_DESIGNATOR,PARAM_CODE,MON_SITE_DESC_CODE,LMT_SEASON_NUM,null,'Accepted',null
,'TRANSID000',KEY_HASH,CURRENT_TIMESTAMP
 from ICS_PARAM_LMTS;

insert into ICS_SUBM_RESULTS
(
ICS_SUBM_RESULTS_ID,SUBM_TYPE_NAME,TRANSACTION_TYPE
,PRMT_IDENT,PRMT_ISSUE_DATE,RESULT_CODE,RESULT_TYPE_CODE,RESULT_DESC
,SUBM_TRANSACTION_ID,KEY_HASH,CREATED_DATE_TIME)
select 
newid(),'PermitReissuanceSubmission' ,'R'
,PRMT_IDENT,PRMT_ISSUE_DATE,null,'Accepted',null
,'TRANSID000',KEY_HASH,CURRENT_TIMESTAMP
 from ICS_PRMT_REISSU;

insert into ICS_SUBM_RESULTS
(
ICS_SUBM_RESULTS_ID,SUBM_TYPE_NAME,TRANSACTION_TYPE
,PRMT_IDENT,PRMT_FEATR_IDENT,RESULT_CODE,RESULT_TYPE_CODE,RESULT_DESC
,SUBM_TRANSACTION_ID,KEY_HASH,CREATED_DATE_TIME)
select 
newid(),'PermittedFeatureSubmission' ,'R'
,PRMT_IDENT,PRMT_FEATR_IDENT,null,'Accepted',null
,'TRANSID000',KEY_HASH,CURRENT_TIMESTAMP
 from ICS_PRMT_FEATR;

insert into ICS_SUBM_RESULTS
(
ICS_SUBM_RESULTS_ID,SUBM_TYPE_NAME,TRANSACTION_TYPE
,PRMT_IDENT,RESULT_CODE,RESULT_TYPE_CODE,RESULT_DESC
,SUBM_TRANSACTION_ID,KEY_HASH,CREATED_DATE_TIME)
select 
newid(),'PermitTerminationSubmission' ,'R'
,PRMT_IDENT,null,'Accepted',null
,'TRANSID000',KEY_HASH,CURRENT_TIMESTAMP
 from ICS_PRMT_TERM;

insert into ICS_SUBM_RESULTS
(
ICS_SUBM_RESULTS_ID,SUBM_TYPE_NAME,TRANSACTION_TYPE
,PRMT_IDENT,PRMT_TRACK_EVT_CODE,PRMT_TRACK_EVT_DATE,RESULT_CODE,RESULT_TYPE_CODE,RESULT_DESC
,SUBM_TRANSACTION_ID,KEY_HASH,CREATED_DATE_TIME)
select 
newid(),'PermitTrackingEventSubmission' ,'R'
,PRMT_IDENT,PRMT_TRACK_EVT_CODE,PRMT_TRACK_EVT_DATE,null,'Accepted',null
,'TRANSID000',KEY_HASH,CURRENT_TIMESTAMP
 from ICS_PRMT_TRACK_EVT;

insert into ICS_SUBM_RESULTS
(
ICS_SUBM_RESULTS_ID,SUBM_TYPE_NAME,TRANSACTION_TYPE
,PRMT_IDENT,RESULT_CODE,RESULT_TYPE_CODE,RESULT_DESC
,SUBM_TRANSACTION_ID,KEY_HASH,CREATED_DATE_TIME)
select 
newid(),'POTWPermitSubmission' ,'R'
,PRMT_IDENT,null,'Accepted',null
,'TRANSID000',KEY_HASH,CURRENT_TIMESTAMP
 from ICS_POTW_PRMT;

insert into ICS_SUBM_RESULTS
(
ICS_SUBM_RESULTS_ID,SUBM_TYPE_NAME,TRANSACTION_TYPE
,PRMT_IDENT,PRETR_PERF_SUMM_END_DATE,RESULT_CODE,RESULT_TYPE_CODE,RESULT_DESC
,SUBM_TRANSACTION_ID,KEY_HASH,CREATED_DATE_TIME)
select 
newid(),'PretreatmentPerformanceSummarySubmission' ,'R'
,PRMT_IDENT,PRETR_PERF_SUMM_END_DATE,null,'Accepted',null
,'TRANSID000',KEY_HASH,CURRENT_TIMESTAMP
 from ICS_PRETR_PERF_SUMM;

insert into ICS_SUBM_RESULTS
(
ICS_SUBM_RESULTS_ID,SUBM_TYPE_NAME,TRANSACTION_TYPE
,PRMT_IDENT,RESULT_CODE,RESULT_TYPE_CODE,RESULT_DESC
,SUBM_TRANSACTION_ID,KEY_HASH,CREATED_DATE_TIME)
select 
newid(),'PretreatmentPermitSubmission' ,'R'
,PRMT_IDENT,null,'Accepted',null
,'TRANSID000',KEY_HASH,CURRENT_TIMESTAMP
 from ICS_PRETR_PRMT;


insert into ICS_SUBM_RESULTS
(
ICS_SUBM_RESULTS_ID,SUBM_TYPE_NAME,TRANSACTION_TYPE
,PRMT_IDENT,SNGL_EVT_VIOL_CODE,SNGL_EVT_VIOL_DATE,RESULT_CODE,RESULT_TYPE_CODE,RESULT_DESC
,SUBM_TRANSACTION_ID,KEY_HASH,CREATED_DATE_TIME)
select 
newid(),'SingleEventViolationSubmission' ,'R'
,PRMT_IDENT,SNGL_EVT_VIOL_CODE,SNGL_EVT_VIOL_DATE,null,'Accepted',null
,'TRANSID000',KEY_HASH,CURRENT_TIMESTAMP
 from ICS_SNGL_EVT_VIOL;

insert into ICS_SUBM_RESULTS
(
ICS_SUBM_RESULTS_ID,SUBM_TYPE_NAME,TRANSACTION_TYPE
,PRMT_IDENT,SSO_ANNUL_REP_RCVD_DATE,RESULT_CODE,RESULT_TYPE_CODE,RESULT_DESC
,SUBM_TRANSACTION_ID,KEY_HASH,CREATED_DATE_TIME)
select 
newid(),'SSOAnnualReportSubmission' ,'R'
,PRMT_IDENT,SSO_ANNUL_REP_RCVD_DATE,null,'Accepted',null
,'TRANSID000',KEY_HASH,CURRENT_TIMESTAMP
 from ICS_SSO_ANNUL_REP;

insert into ICS_SUBM_RESULTS
(
ICS_SUBM_RESULTS_ID,SUBM_TYPE_NAME,TRANSACTION_TYPE
,PRMT_IDENT,SSO_EVT_DATE,RESULT_CODE,RESULT_TYPE_CODE,RESULT_DESC
,SUBM_TRANSACTION_ID,KEY_HASH,CREATED_DATE_TIME)
select 
newid(),'SSOEventReportSubmission' ,'R'
,PRMT_IDENT,SSO_EVT_DATE,null,'Accepted',null
,'TRANSID000',KEY_HASH,CURRENT_TIMESTAMP
 from ICS_SSO_EVT_REP;

insert into ICS_SUBM_RESULTS
(
ICS_SUBM_RESULTS_ID,SUBM_TYPE_NAME,TRANSACTION_TYPE
,PRMT_IDENT,SSO_MONTHLY_REP_RCVD_DATE,RESULT_CODE,RESULT_TYPE_CODE,RESULT_DESC
,SUBM_TRANSACTION_ID,KEY_HASH,CREATED_DATE_TIME)
select 
newid(),'SSOMonthlyEventReportSubmission' ,'R'
,PRMT_IDENT,SSO_MONTHLY_REP_RCVD_DATE,null,'Accepted',null
,'TRANSID000',KEY_HASH,CURRENT_TIMESTAMP
 from ICS_SSO_MONTHLY_EVT_REP;

insert into ICS_SUBM_RESULTS
(
ICS_SUBM_RESULTS_ID,SUBM_TYPE_NAME,TRANSACTION_TYPE
,PRMT_IDENT,RESULT_CODE,RESULT_TYPE_CODE,RESULT_DESC
,SUBM_TRANSACTION_ID,KEY_HASH,CREATED_DATE_TIME)
select 
newid(),'SWConstructionPermitSubmission' ,'R'
,PRMT_IDENT,null,'Accepted',null
,'TRANSID000',KEY_HASH,CURRENT_TIMESTAMP
 from ICS_SW_CNST_PRMT;

insert into ICS_SUBM_RESULTS
(
ICS_SUBM_RESULTS_ID,SUBM_TYPE_NAME,TRANSACTION_TYPE
,PRMT_IDENT,DATE_STRM_EVT_SMPL,RESULT_CODE,RESULT_TYPE_CODE,RESULT_DESC
,SUBM_TRANSACTION_ID,KEY_HASH,CREATED_DATE_TIME)
select 
newid(),'SWEventReportSubmission' ,'R'
,PRMT_IDENT,DATE_STRM_EVT_SMPL,null,'Accepted',null
,'TRANSID000',KEY_HASH,CURRENT_TIMESTAMP
 from ICS_SW_EVT_REP;

insert into ICS_SUBM_RESULTS
(
ICS_SUBM_RESULTS_ID,SUBM_TYPE_NAME,TRANSACTION_TYPE
,PRMT_IDENT,INDST_SW_ANNUL_REP_RCVD_DATE,RESULT_CODE,RESULT_TYPE_CODE,RESULT_DESC
,SUBM_TRANSACTION_ID,KEY_HASH,CREATED_DATE_TIME)
select 
newid(),'SWIndustrialAnnualReportSubmission' ,'R'
,PRMT_IDENT,INDST_SW_ANNUL_REP_RCVD_DATE,null,'Accepted',null
,'TRANSID000',KEY_HASH,CURRENT_TIMESTAMP
 from ICS_SW_INDST_ANNUL_REP;

insert into ICS_SUBM_RESULTS
(
ICS_SUBM_RESULTS_ID,SUBM_TYPE_NAME,TRANSACTION_TYPE
,PRMT_IDENT,RESULT_CODE,RESULT_TYPE_CODE,RESULT_DESC
,SUBM_TRANSACTION_ID,KEY_HASH,CREATED_DATE_TIME)
select 
newid(),'SWIndustrialPermitSubmission' ,'R'
,PRMT_IDENT,null,'Accepted',null
,'TRANSID000',KEY_HASH,CURRENT_TIMESTAMP
 from ICS_SW_INDST_PRMT;

insert into ICS_SUBM_RESULTS
(
ICS_SUBM_RESULTS_ID,SUBM_TYPE_NAME,TRANSACTION_TYPE
,PRMT_IDENT,RESULT_CODE,RESULT_TYPE_CODE,RESULT_DESC
,SUBM_TRANSACTION_ID,KEY_HASH,CREATED_DATE_TIME)
select 
newid(),'SWMS4LargePermitSubmission' ,'R'
,PRMT_IDENT,null,'Accepted',null
,'TRANSID000',KEY_HASH,CURRENT_TIMESTAMP
 from ICS_SWMS_4_LARGE_PRMT;

insert into ICS_SUBM_RESULTS
(
ICS_SUBM_RESULTS_ID,SUBM_TYPE_NAME,TRANSACTION_TYPE
,PRMT_IDENT,SW_MS_4_REP_RCVD_DATE,RESULT_CODE,RESULT_TYPE_CODE,RESULT_DESC
,SUBM_TRANSACTION_ID,KEY_HASH,CREATED_DATE_TIME)
select 
newid(),'SWMS4ProgramReportSubmission' ,'R'
,PRMT_IDENT,SW_MS_4_REP_RCVD_DATE,null,'Accepted',null
,'TRANSID000',KEY_HASH,CURRENT_TIMESTAMP
 from ICS_SWMS_4_PROG_REP;

insert into ICS_SUBM_RESULTS
(
ICS_SUBM_RESULTS_ID,SUBM_TYPE_NAME,TRANSACTION_TYPE
,PRMT_IDENT,RESULT_CODE,RESULT_TYPE_CODE,RESULT_DESC
,SUBM_TRANSACTION_ID,KEY_HASH,CREATED_DATE_TIME)
select 
newid(),'SWMS4SmallPermitSubmission' ,'R'
,PRMT_IDENT,null,'Accepted',null
,'TRANSID000',KEY_HASH,CURRENT_TIMESTAMP
 from ICS_SWMS_4_SMALL_PRMT;

insert into ICS_SUBM_RESULTS
(
ICS_SUBM_RESULTS_ID,SUBM_TYPE_NAME,TRANSACTION_TYPE
,PRMT_IDENT,RESULT_CODE,RESULT_TYPE_CODE,RESULT_DESC
,SUBM_TRANSACTION_ID,KEY_HASH,CREATED_DATE_TIME)
select 
newid(),'UnpermittedFacilitySubmission' ,'R'
,PRMT_IDENT,null,'Accepted',null
,'TRANSID000',KEY_HASH,CURRENT_TIMESTAMP
 from ICS_UNPRMT_FAC;
 
 
-- 5.8.1
insert INTO ICS_SUBM_RESULTS
(
ICS_SUBM_RESULTS_ID,SUBM_TYPE_NAME,TRANSACTION_TYPE
,PRMT_IDENT,PRMT_FEATR_IDENT,LMT_SET_DESIGNATOR,
RESULT_CODE,RESULT_TYPE_CODE,RESULT_DESC
,SUBM_TRANSACTION_ID,KEY_HASH,CREATED_DATE_TIME)
select 
newid(),'CopyMGPLimitSetSubmission' ,'R'
,TRGT_GNRL_PRMT_IDENT,TRGT_GNRL_PRMT_FEATR_IDENT,TRGT_GNRL_LMT_SET_DESIGNATOR
,null,'Accepted',null
,'TRANSID000',KEY_HASH,CURRENT_TIMESTAMP
FROM ICS_COPY_MGP_LMT_SET;

 
