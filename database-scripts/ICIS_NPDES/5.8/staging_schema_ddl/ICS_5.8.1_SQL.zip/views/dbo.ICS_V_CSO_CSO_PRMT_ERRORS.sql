IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.ICS_V_CSO_CSO_PRMT_ERRORS') AND type = N'V')
DROP VIEW dbo.ICS_V_CSO_CSO_PRMT_ERRORS
GO

CREATE VIEW dbo.ICS_V_CSO_CSO_PRMT_ERRORS
AS
/*************************************************************************************************
** ObjectName: ICS_V_CSO_CSO_PRMT_ERRORS
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  Returns the CSO Permit records that return ICIS business rule violations
**
** Revision History:
** ------------------------------------------------------------------------------------------------
** Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 07/03/2018   Windsor      Created 
**
***************************************************************************************************/
SELECT ics_cso_prmt.transaction_type
     , ics_cso_prmt.prmt_ident
     , ics_cso_prmt.css_popl_served_num
     , ics_cso_prmt.combined_sewer_systm_length
     , ics_cso_prmt.coll_systm_combined_percent
     , ics_subm_results.result_code
     , ics_subm_results.result_desc
FROM dbo.ics_cso_prmt as ics_cso_prmt
  JOIN dbo.ics_subm_results as ics_subm_results
  on ics_cso_prmt.prmt_ident = ics_subm_results.prmt_ident 
WHERE ics_subm_results.result_type_code = 'Error'
  AND ics_subm_results.subm_type_name = 'CSOPermitSubmission';
GO