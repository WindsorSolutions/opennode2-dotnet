IF NOT EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND OBJECT_ID = OBJECT_ID('dbo.ICS_CLEAR_TRANSACT_FLAGS'))
  EXEC('CREATE PROCEDURE [dbo].[ICS_CLEAR_TRANSACT_FLAGS] AS BEGIN SET NOCOUNT ON; END')
GO

/*
Copyright (c) 2012, The Environmental Council of the States (ECOS)
All rights reserved.
 
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
 
 * Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
 * Neither the name of the ECOS nor the names of its contributors may
   be used to endorse or promote products derived from this software
   without specific prior written permission.
 
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/


/*************************************************************************************************
** ObjectName: ics_clear_transact_flags
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure clears the transaction flag from permit payloads where the permit
**               has an effective date that is greater than the permit expiration date, preventing
**               these from being sent to ICIS.
**
**               The following tables will have their transaction flags cleared by this procedure:
**
**               Basic Permit
**               CAFO Permit
**               Effluent Trade Partner
**               General Permit
**               Limit Set
**               Limits
**               Narrative Condition Schedule
**               Parameter Limits
**               Permit Reissuance
**               Permit Tracking Event
**               Permitted Feature
**               POTW Permit
**               Pretreatment Permit
**               SW Construction Permit
**               SW Industrial Permit
**               SW MS4 Large Permit
**               SW MS4 Small Permit
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 07/09/2018    TK Conrad   Created.
** 06/11/2019    KJames      Modified schema from ICIS on the create statement to match the dbo
**                           schema referenced in the alter statement below.
***************************************************************************************************/
ALTER PROCEDURE dbo.ICS_CLEAR_TRANSACT_FLAGS AS
BEGIN

   SET NOCOUNT ON;

   DECLARE @v_marker         VARCHAR(255)
          ,@v_sp_name        VARCHAR(128)
          ,@v_tgt_tbl        VARCHAR(128)
          ,@v_sp_startdtm    DATETIME
          ,@v_sp_enddtm      DATETIME
          ,@v_insrtd_rows    INT
          ,@localTran        BIT;

    SET XACT_ABORT,
        QUOTED_IDENTIFIER,
        ANSI_NULLS,
        ANSI_PADDING,
        ANSI_WARNINGS,
        ARITHABORT,
        CONCAT_NULL_YIELDS_NULL ON;
    SET NUMERIC_ROUNDABORT OFF;
	
	
    SET @v_sp_startdtm = GETDATE();
    SET @v_sp_name     = 'dbo.ics_clear_transact_flags';

    BEGIN TRY

  --  Save all permits where eff date > expiration date

  SELECT prmt_ident INTO #prmt_mod_after_exp_date
  FROM ics_prmt_reissu
  WHERE DATEDIFF(DD, prmt_expr_date, prmt_effective_date) > 0;
  
  /******************************
   ICS_PRMT_REISSU
   ******************************/
  
  --  Run-time Logging  --
  SET @v_tgt_tbl     = 'dbo.ICS_PRMT_REISSU - Clear invalid reissuances';
  
  UPDATE ics_prmt_reissu SET transaction_type = NULL
   WHERE 1=1
     AND transaction_type IS NOT NULL
	 AND prmt_ident IN
	 (
	 SELECT prmt_ident FROM #prmt_mod_after_exp_date
	 );

  --  ETL Logging
  SET @v_insrtd_rows = @@ROWCOUNT;
  SET @v_marker      = @v_tgt_tbl + ' Total rows inserted = ' + CAST(@v_insrtd_rows AS VARCHAR);
  SET @v_sp_enddtm   = GETDATE();
  -- EXEC ICIS.ICS_ETL_LOG_SP @v_sp_name,@v_tgt_tbl,@v_marker,@v_sp_startdtm,@v_sp_enddtm,NULL,NULL,NULL;

  /******************************
   ICS_BASIC_PRMT
   ******************************/
  
  --  Run-time Logging  --
  SET @v_tgt_tbl     = 'dbo.ICS_BASIC_PRMT - Clear invalid reissuances';
  
  UPDATE ics_basic_prmt SET transaction_type = NULL
   WHERE 1=1
     AND transaction_type IS NOT NULL
	 AND prmt_ident IN
	 (
	 SELECT prmt_ident FROM #prmt_mod_after_exp_date
	 );

  --  ETL Logging
  SET @v_insrtd_rows = @@ROWCOUNT;
  SET @v_marker      = @v_tgt_tbl + ' Total rows inserted = ' + CAST(@v_insrtd_rows AS VARCHAR);
  SET @v_sp_enddtm   = GETDATE();
  -- EXEC ICIS.ICS_ETL_LOG_SP @v_sp_name,@v_tgt_tbl,@v_marker,@v_sp_startdtm,@v_sp_enddtm,NULL,NULL,NULL;

  /******************************
   ICS_GNRL_PRMT
   ******************************/
  
  --  Run-time Logging  --
  SET @v_tgt_tbl     = 'dbo.ICS_GNRL_PRMT - Clear invalid reissuances';
  
  UPDATE ics_gnrl_prmt SET transaction_type = NULL
   WHERE 1=1
     AND transaction_type IS NOT NULL
	 AND prmt_ident IN
	 (
	 SELECT prmt_ident FROM #prmt_mod_after_exp_date
	 );

  --  ETL Logging
  SET @v_insrtd_rows = @@ROWCOUNT;
  SET @v_marker      = @v_tgt_tbl + ' Total rows inserted = ' + CAST(@v_insrtd_rows AS VARCHAR);
  SET @v_sp_enddtm   = GETDATE();
  -- EXEC ICIS.ICS_ETL_LOG_SP @v_sp_name,@v_tgt_tbl,@v_marker,@v_sp_startdtm,@v_sp_enddtm,NULL,NULL,NULL;

  /******************************
   ICS_PRMT_FEATR
   ******************************/
  
  --  Run-time Logging  --
  SET @v_tgt_tbl     = 'dbo.ICS_PRMT_FEATR - Clear invalid reissuances';
  
  UPDATE ics_prmt_featr SET transaction_type = NULL
   WHERE 1=1
     AND transaction_type IS NOT NULL
	 AND prmt_ident IN
	 (
	 SELECT prmt_ident FROM #prmt_mod_after_exp_date
	 );

  --  ETL Logging
  SET @v_insrtd_rows = @@ROWCOUNT;
  SET @v_marker      = @v_tgt_tbl + ' Total rows inserted = ' + CAST(@v_insrtd_rows AS VARCHAR);
  SET @v_sp_enddtm   = GETDATE();
  -- EXEC ICIS.ICS_ETL_LOG_SP @v_sp_name,@v_tgt_tbl,@v_marker,@v_sp_startdtm,@v_sp_enddtm,NULL,NULL,NULL;

  /******************************
   ICS_LMT_SET
   ******************************/
  
  --  Run-time Logging  --
  SET @v_tgt_tbl     = 'dbo.ICS_LMT_SET - Clear invalid reissuances';
  
  UPDATE ics_lmt_set SET transaction_type = NULL
   WHERE 1=1
     AND transaction_type IS NOT NULL
	 AND prmt_ident IN
	 (
	 SELECT prmt_ident FROM #prmt_mod_after_exp_date
	 );

  --  ETL Logging
  SET @v_insrtd_rows = @@ROWCOUNT;
  SET @v_marker      = @v_tgt_tbl + ' Total rows inserted = ' + CAST(@v_insrtd_rows AS VARCHAR);
  SET @v_sp_enddtm   = GETDATE();
  -- EXEC ICIS.ICS_ETL_LOG_SP @v_sp_name,@v_tgt_tbl,@v_marker,@v_sp_startdtm,@v_sp_enddtm,NULL,NULL,NULL;

  /******************************
   ICS_PARAM_LMTS
   ******************************/
  
  --  Run-time Logging  --
  SET @v_tgt_tbl     = 'dbo.ICS_PARAM_LMTS - Clear invalid reissuances';
  
  UPDATE ics_param_lmts SET transaction_type = NULL
   WHERE 1=1
     AND transaction_type IS NOT NULL
	 AND prmt_ident IN
	 (
	 SELECT prmt_ident FROM #prmt_mod_after_exp_date
	 );

  --  ETL Logging
  SET @v_insrtd_rows = @@ROWCOUNT;
  SET @v_marker      = @v_tgt_tbl + ' Total rows inserted = ' + CAST(@v_insrtd_rows AS VARCHAR);
  SET @v_sp_enddtm   = GETDATE();
  -- EXEC ICIS.ICS_ETL_LOG_SP @v_sp_name,@v_tgt_tbl,@v_marker,@v_sp_startdtm,@v_sp_enddtm,NULL,NULL,NULL;

  /******************************
   ICS_LMTS
   ******************************/
  
  --  Run-time Logging  --
  SET @v_tgt_tbl     = 'dbo.ICS_LMTS - Clear invalid reissuances';
  
  UPDATE ics_lmts SET transaction_type = NULL
   WHERE 1=1
     AND transaction_type IS NOT NULL
	 AND prmt_ident IN
	 (
	 SELECT prmt_ident FROM #prmt_mod_after_exp_date
	 );

  --  ETL Logging
  SET @v_insrtd_rows = @@ROWCOUNT;
  SET @v_marker      = @v_tgt_tbl + ' Total rows inserted = ' + CAST(@v_insrtd_rows AS VARCHAR);
  SET @v_sp_enddtm   = GETDATE();
  -- EXEC ICIS.ICS_ETL_LOG_SP @v_sp_name,@v_tgt_tbl,@v_marker,@v_sp_startdtm,@v_sp_enddtm,NULL,NULL,NULL;

  /******************************
   ICS_EFFLU_TRADE_PRTNER
   ******************************/
  
  --  Run-time Logging  --
  SET @v_tgt_tbl     = 'dbo.ICS_EFFLU_TRADE_PRTNER - Clear invalid reissuances';
  
  UPDATE ics_efflu_trade_prtner SET transaction_type = NULL
   WHERE 1=1
     AND transaction_type IS NOT NULL
	 AND prmt_ident IN
	 (
	 SELECT prmt_ident FROM #prmt_mod_after_exp_date
	 );

  /******************************
   ICS_NARR_COND_SCHD
   ******************************/
  
  --  Run-time Logging  --
  SET @v_tgt_tbl     = 'dbo.ICS_NARR_COND_SCHD - Clear invalid reissuances';
  
  UPDATE ics_narr_cond_schd SET transaction_type = NULL
   WHERE 1=1
     AND transaction_type IS NOT NULL
	 AND prmt_ident IN
	 (
	 SELECT prmt_ident FROM #prmt_mod_after_exp_date
	 );

  --  ETL Logging
  SET @v_insrtd_rows = @@ROWCOUNT;
  SET @v_marker      = @v_tgt_tbl + ' Total rows inserted = ' + CAST(@v_insrtd_rows AS VARCHAR);
  SET @v_sp_enddtm   = GETDATE();
  -- EXEC ICIS.ICS_ETL_LOG_SP @v_sp_name,@v_tgt_tbl,@v_marker,@v_sp_startdtm,@v_sp_enddtm,NULL,NULL,NULL;

  /******************************
   ICS_PRMT_TRACK_EVT
   ******************************/
  
  --  Run-time Logging  --
  SET @v_tgt_tbl     = 'dbo.ICS_PRMT_TRACK_EVT - Clear invalid reissuances';
  
  UPDATE ics_prmt_track_evt SET transaction_type = NULL
   WHERE 1=1
     AND transaction_type IS NOT NULL
	 AND prmt_ident IN
	 (
	 SELECT prmt_ident FROM #prmt_mod_after_exp_date
	 );

  --  ETL Logging
  SET @v_insrtd_rows = @@ROWCOUNT;
  SET @v_marker      = @v_tgt_tbl + ' Total rows inserted = ' + CAST(@v_insrtd_rows AS VARCHAR);
  SET @v_sp_enddtm   = GETDATE();
  -- EXEC ICIS.ICS_ETL_LOG_SP @v_sp_name,@v_tgt_tbl,@v_marker,@v_sp_startdtm,@v_sp_enddtm,NULL,NULL,NULL;

  /******************************
   ICS_SW_CNST_PRMT
   ******************************/
  
  --  Run-time Logging  --
  SET @v_tgt_tbl     = 'dbo.ICS_SW_CNST_PRMT - Clear invalid reissuances';
  
  UPDATE ics_sw_cnst_prmt SET transaction_type = NULL
   WHERE 1=1
     AND transaction_type IS NOT NULL
	 AND prmt_ident IN
	 (
	 SELECT prmt_ident FROM #prmt_mod_after_exp_date
	 );

  --  ETL Logging
  SET @v_insrtd_rows = @@ROWCOUNT;
  SET @v_marker      = @v_tgt_tbl + ' Total rows inserted = ' + CAST(@v_insrtd_rows AS VARCHAR);
  SET @v_sp_enddtm   = GETDATE();
  -- EXEC ICIS.ICS_ETL_LOG_SP @v_sp_name,@v_tgt_tbl,@v_marker,@v_sp_startdtm,@v_sp_enddtm,NULL,NULL,NULL;

  /******************************
   ICS_SW_INDST_PRMT
   ******************************/
  
  --  Run-time Logging  --
  SET @v_tgt_tbl     = 'dbo.ICS_SW_INDST_PRMT - Clear invalid reissuances';
  
  UPDATE ics_sw_indst_prmt SET transaction_type = NULL
   WHERE 1=1
     AND transaction_type IS NOT NULL
	 AND prmt_ident IN
	 (
	 SELECT prmt_ident FROM #prmt_mod_after_exp_date
	 );

  --  ETL Logging
  SET @v_insrtd_rows = @@ROWCOUNT;
  SET @v_marker      = @v_tgt_tbl + ' Total rows inserted = ' + CAST(@v_insrtd_rows AS VARCHAR);
  SET @v_sp_enddtm   = GETDATE();
  -- EXEC ICIS.ICS_ETL_LOG_SP @v_sp_name,@v_tgt_tbl,@v_marker,@v_sp_startdtm,@v_sp_enddtm,NULL,NULL,NULL;

  /******************************
   ICS_SWMS_4_LARGE_PRMT
   ******************************/
  
  --  Run-time Logging  --
  SET @v_tgt_tbl     = 'dbo.ICS_SWMS_4_LARGE_PRMT - Clear invalid reissuances';
  
  UPDATE ics_swms_4_large_prmt SET transaction_type = NULL
   WHERE 1=1
     AND transaction_type IS NOT NULL
	 AND prmt_ident IN
	 (
	 SELECT prmt_ident FROM #prmt_mod_after_exp_date
	 );

  --  ETL Logging
  SET @v_insrtd_rows = @@ROWCOUNT;
  SET @v_marker      = @v_tgt_tbl + ' Total rows inserted = ' + CAST(@v_insrtd_rows AS VARCHAR);
  SET @v_sp_enddtm   = GETDATE();
  -- EXEC ICIS.ICS_ETL_LOG_SP @v_sp_name,@v_tgt_tbl,@v_marker,@v_sp_startdtm,@v_sp_enddtm,NULL,NULL,NULL;

  /******************************
   ICS_SWMS_4_SMALL_PRMT
   ******************************/
  
  --  Run-time Logging  --
  SET @v_tgt_tbl     = 'dbo.ICS_SWMS_4_SMALL_PRMT - Clear invalid reissuances';
  
  UPDATE ics_swms_4_small_prmt SET transaction_type = NULL
   WHERE 1=1
     AND transaction_type IS NOT NULL
	 AND prmt_ident IN
	 (
	 SELECT prmt_ident FROM #prmt_mod_after_exp_date
	 );

  --  ETL Logging
  SET @v_insrtd_rows = @@ROWCOUNT;
  SET @v_marker      = @v_tgt_tbl + ' Total rows inserted = ' + CAST(@v_insrtd_rows AS VARCHAR);
  SET @v_sp_enddtm   = GETDATE();
  -- EXEC ICIS.ICS_ETL_LOG_SP @v_sp_name,@v_tgt_tbl,@v_marker,@v_sp_startdtm,@v_sp_enddtm,NULL,NULL,NULL;

  /******************************
   ICS_POTW_PRMT
   ******************************/
  
  --  Run-time Logging  --
  SET @v_tgt_tbl     = 'dbo.ICS_POTW_PRMT - Clear invalid reissuances';
  
  UPDATE ics_potw_prmt SET transaction_type = NULL
   WHERE 1=1
     AND transaction_type IS NOT NULL
	 AND prmt_ident IN
	 (
	 SELECT prmt_ident FROM #prmt_mod_after_exp_date
	 );

  --  ETL Logging
  SET @v_insrtd_rows = @@ROWCOUNT;
  SET @v_marker      = @v_tgt_tbl + ' Total rows inserted = ' + CAST(@v_insrtd_rows AS VARCHAR);
  SET @v_sp_enddtm   = GETDATE();
  -- EXEC ICIS.ICS_ETL_LOG_SP @v_sp_name,@v_tgt_tbl,@v_marker,@v_sp_startdtm,@v_sp_enddtm,NULL,NULL,NULL;

  /******************************
   ICS_PRETR_PRMT
   ******************************/
  
  --  Run-time Logging  --
  SET @v_tgt_tbl     = 'dbo.ICS_PRETR_PRMT - Clear invalid reissuances';
  
  UPDATE ics_pretr_prmt SET transaction_type = NULL
   WHERE 1=1
     AND transaction_type IS NOT NULL
	 AND prmt_ident IN
	 (
	 SELECT prmt_ident FROM #prmt_mod_after_exp_date
	 );

  --  ETL Logging
  SET @v_insrtd_rows = @@ROWCOUNT;
  SET @v_marker      = @v_tgt_tbl + ' Total rows inserted = ' + CAST(@v_insrtd_rows AS VARCHAR);
  SET @v_sp_enddtm   = GETDATE();
  -- EXEC ICIS.ICS_ETL_LOG_SP @v_sp_name,@v_tgt_tbl,@v_marker,@v_sp_startdtm,@v_sp_enddtm,NULL,NULL,NULL;

  /******************************
   ICS_CAFO_PRMT
   ******************************/
  
  --  Run-time Logging  --
  SET @v_tgt_tbl     = 'dbo.ICS_CAFO_PRMT - Clear invalid reissuances';
  
  UPDATE ics_cafo_prmt SET transaction_type = NULL
   WHERE 1=1
     AND transaction_type IS NOT NULL
	 AND prmt_ident IN
	 (
	 SELECT prmt_ident FROM #prmt_mod_after_exp_date
	 );

  --  ETL Logging
  SET @v_insrtd_rows = @@ROWCOUNT;
  SET @v_marker      = @v_tgt_tbl + ' Total rows inserted = ' + CAST(@v_insrtd_rows AS VARCHAR);
  SET @v_sp_enddtm   = GETDATE();
  -- EXEC ICIS.ICS_ETL_LOG_SP @v_sp_name,@v_tgt_tbl,@v_marker,@v_sp_startdtm,@v_sp_enddtm,NULL,NULL,NULL;

  DROP TABLE #prmt_mod_after_exp_date;

  END TRY
  BEGIN CATCH
 
      DECLARE @ErrorMessage NVARCHAR(4000)
      DECLARE @ErrorSeverity INT
      DECLARE @ErrorState INT
 
      SELECT  @ErrorMessage = ERROR_MESSAGE(),
              @ErrorSeverity = ERROR_SEVERITY(),
              @ErrorState = ERROR_STATE()

      SET @v_marker = 'Error '      + CONVERT(VARCHAR(200), ERROR_MESSAGE()) 
                    + ', Severity ' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) 
                    + ', State '    + CONVERT(VARCHAR(5), ERROR_STATE()) 
                    + ', Line '     + CONVERT(VARCHAR(5), ERROR_LINE());
      SET @v_sp_enddtm   = GETDATE();

      -- EXEC ICIS.ICS_ETL_LOG_SP @v_sp_name,@v_tgt_tbl,@v_marker,@v_sp_startdtm,@v_sp_enddtm,NULL,NULL,NULL;

      RAISERROR ( @ErrorMessage, @ErrorSeverity, @ErrorState);

  END CATCH
 
END;
GO


