  /*
Copyright (c) 2012, The Environmental Council of the States (ECOS)
All rights reserved.
 
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
 
 * Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
 * Neither the name of the ECOS nor the names of its contributors may
   be used to endorse or promote products derived from this software
   without specific prior written permission.
 
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/
/* ************************************************************************************************
** ObjectName: ICIS_ORA-5.8-to-5.8.1.sql
**
** Author: Windsor Solutions, Inc.
**
** Company Name: Windsor Solutions, Inc.
**
** Description:  This script will update an existing ICIS 5.8 database to support the ICIS 5.8.1
**               XML schema.  This script can be run multiple times without issue.
**
** Revision History:
** ------------------------------------------------------------------------------------------------
** Date          Name        Description
** ------------------------------------------------------------------------------------------------
** 06/27/2017    CTyler      Created
** 08/16/2017    CTyler      Add supporting views for JAVA node for 5.8 
** 09/11/2017    CTyler      Removed db schema on views defn
** 04/13/2018    KJames      CREATE FOREIGN KEY on ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID, with associated 
**                           index IX_NPD_DAT_GRP_NUM_IC_GN_PR_ID
** 04/16/2018    KJames      Fixed insert statement for payload BiosolidsAnnualProgramReport.
** 08/13/2019    CTyler      Add 5.8.1 fields ICS_COPY_MGP_LMT_SET table and FK on ICS_GEO_COORD
**                           ICS_LMt_SET_SCHD and ICS_LMT_SET_STAT
**
************************************************************************************************ */



/******************************************************************************************************** 

    Create new table ICS_COPY_MGP_LMT_SET 

*********************************************************************************************************/
DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN

  /*  Check to see if table ICS_COPY_MGP_LMT_SET exists  */
   SELECT 1
     INTO v_object_ind
     FROM user_tables
    WHERE user_tables.table_name = 'ICS_COPY_MGP_LMT_SET';
   
   /* The column already exists in schema, bypass creation */
    DBMS_OUTPUT.PUT_LINE( 'The table ICS_COPY_MGP_LMT_SET already exists, schema alteration bypassed!');

EXCEPTION    
  WHEN NO_DATA_FOUND THEN  
  
  BEGIN    
  --  Create table
      v_sql_statement := '
    CREATE TABLE ICS_COPY_MGP_LMT_SET
    (
        ICS_COPY_MGP_LMT_SET_ID VARCHAR2(36) NOT NULL,
        ICS_PAYLOAD_ID VARCHAR(36) NOT NULL,
        SRC_SYSTM_IDENT VARCHAR(50) NULL,
        TRANSACTION_TYPE CHAR(1) NULL,
        TRANSACTION_TIMESTAMP DATE NULL,
        PRMT_IDENT CHAR(9) NOT NULL,
        PRMT_FEATR_IDENT VARCHAR(4) NOT NULL,
        LMT_SET_DESIGNATOR VARCHAR(2) NOT NULL,
        TRGT_GNRL_PRMT_IDENT CHAR(9) NULL,
        TRGT_GNRL_PRMT_FEATR_IDENT VARCHAR(4) NULL,
        TRGT_GNRL_LMT_SET_DESIGNATOR VARCHAR(2) NULL,
        PRMT_FEATR_TYPE_CODE VARCHAR(3) NULL,
        PRMT_FEATR_DESC VARCHAR(100) NULL,
        PRMT_FEATR_ST_WTR_BODY_NAME VARCHAR(50) NULL,
        IMPAIRED_WTR_IND CHAR(1) NULL,
        TMDL_COMPLETED_IND CHAR(1) NULL,
        PRMT_FEATR_USR_DFND_DAT_ELM_1 VARCHAR(30) NULL,
        PRMT_FEATR_USR_DFND_DAT_ELM_2 VARCHAR(30) NULL,
        LMT_SET_NAME_TXT VARCHAR(100) NULL,
        DMR_PRE_PRINT_CMNTS_TXT VARCHAR(315) NULL,
        DATA_HASH VARCHAR(100) NULL,
        KEY_HASH VARCHAR(100) NULL
    )';

      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The table ICS_COPY_MGP_LMT_SET was added to the schema!');    
      
      v_sql_statement := 'ALTER TABLE "ICS_COPY_MGP_LMT_SET" 
       ADD ( CONSTRAINT "PK_COPY_MGP_LMT_SET" 
       PRIMARY KEY("ICS_COPY_MGP_LMT_SET_ID") 
       NOT DEFERRABLE INITIALLY IMMEDIATE)';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The prmary key for ICS_COPY_MGP_LMT_SET  was added.');      
      
      v_sql_statement := 'CREATE INDEX "IX_COPY_MGP_LMT_SET_ICS_PYL_ID" 
   ON "ICS_COPY_MGP_LMT_SET"("ICS_PAYLOAD_ID")';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The index IX_COPY_MGP_LMT_SET_ICS_PYL_ID was added.');      
      
      
     END;
     
 END;
 /



   
/******************************************************************************************************** 

    Add column ICS_COPY_MGP_LMT_SET_ID to table ICS_GEO_COORD .
*********************************************************************************************************/

DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  /*  Check to see if ICS_COPY_MGP_LMT_SET_ID column exists on the database table ICS_GEO_COORD   */
   SELECT 1
     INTO v_object_ind
     FROM user_tables
     JOIN user_tab_cols
       ON user_tab_cols.table_name = user_tables.table_name
    WHERE user_tables.table_name = 'ICS_GEO_COORD'
      AND user_tab_cols.column_name = 'ICS_COPY_MGP_LMT_SET_ID';
   
   /* The column already exists in schema, bypass creation */
    DBMS_OUTPUT.PUT_LINE( 'The column ICS_COPY_MGP_LMT_SET_ID already existed on ICS_GEO_COORD , schema alteration bypassed!');

EXCEPTION

  WHEN NO_DATA_FOUND THEN  
  
    BEGIN
       
      --  Add new column 
      v_sql_statement := 'ALTER TABLE ICS_GEO_COORD  ADD ICS_COPY_MGP_LMT_SET_ID VARCHAR(36) NULL';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The column ICS_COPY_MGP_LMT_SET_ID was added to the table ICS_GEO_COORD !');
 
      v_sql_statement := 'CREATE INDEX "IX_GEO_COR_ICS_COP_MG_LM_SE_ID" 
   ON "ICS_GEO_COORD"("ICS_COPY_MGP_LMT_SET_ID")';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The index IX_GEO_COR_ICS_COP_MG_LM_SE_ID  was added.');

      v_sql_statement := 'ALTER TABLE "ICS_GEO_COORD"
 ADD ( CONSTRAINT "FK_GEO_COORD_COPY_MGP"
 FOREIGN KEY("ICS_COPY_MGP_LMT_SET_ID")
 REFERENCES ICS_COPY_MGP_LMT_SET("ICS_COPY_MGP_LMT_SET_ID")
ON DELETE CASCADE NOT DEFERRABLE INITIALLY IMMEDIATE VALIDATE )';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The FK FK_GEO_COORD_COPY_MGP  was added.'); 
 
      
     END;  

END;
/ 
 

   
/******************************************************************************************************** 

    Add column ICS_COPY_MGP_LMT_SET_ID to table ICS_LMT_SET_SCHD .
*********************************************************************************************************/

DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  /*  Check to see if ICS_COPY_MGP_LMT_SET_ID column exists on the database table ICS_LMT_SET_SCHD   */
   SELECT 1
     INTO v_object_ind
     FROM user_tables
     JOIN user_tab_cols
       ON user_tab_cols.table_name = user_tables.table_name
    WHERE user_tables.table_name = 'ICS_LMT_SET_SCHD'
      AND user_tab_cols.column_name = 'ICS_COPY_MGP_LMT_SET_ID';
   
   /* The column already exists in schema, bypass creation */
    DBMS_OUTPUT.PUT_LINE( 'The column ICS_COPY_MGP_LMT_SET_ID already existed on ICS_LMT_SET_SCHD , schema alteration bypassed!');

EXCEPTION

  WHEN NO_DATA_FOUND THEN  
  
    BEGIN
       
      --  Add new column 
      v_sql_statement := 'ALTER TABLE ICS_LMT_SET_SCHD  ADD ICS_COPY_MGP_LMT_SET_ID VARCHAR(36) NULL';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The column ICS_COPY_MGP_LMT_SET_ID was added to the table ICS_LMT_SET_SCHD !');
 
      v_sql_statement := 'CREATE INDEX "IX_LMT_SE_SC_IC_CO_MG_LM_SE_ID" 
   ON "ICS_LMT_SET_SCHD"("ICS_COPY_MGP_LMT_SET_ID")';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The index IX_LMT_SE_SC_IC_CO_MG_LM_SE_ID  was added.');

      v_sql_statement := 'ALTER TABLE "ICS_LMT_SET_SCHD"
 ADD ( CONSTRAINT "FK_LMT_SET_SCHD_COPY_MGP"
 FOREIGN KEY("ICS_COPY_MGP_LMT_SET_ID")
 REFERENCES ICS_COPY_MGP_LMT_SET("ICS_COPY_MGP_LMT_SET_ID")
ON DELETE CASCADE NOT DEFERRABLE INITIALLY IMMEDIATE VALIDATE )';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The FK FK_LMT_SET_SCHD_COPY_MGP  was added.'); 
      
     END;  

END;
/ 
 

   
/******************************************************************************************************** 

    Add column ICS_COPY_MGP_LMT_SET_ID to table ICS_LMT_SET_STAT .
*********************************************************************************************************/

DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  /*  Check to see if ICS_COPY_MGP_LMT_SET_ID column exists on the database table ICS_LMT_SET_STAT   */
   SELECT 1
     INTO v_object_ind
     FROM user_tables
     JOIN user_tab_cols
       ON user_tab_cols.table_name = user_tables.table_name
    WHERE user_tables.table_name = 'ICS_LMT_SET_STAT'
      AND user_tab_cols.column_name = 'ICS_COPY_MGP_LMT_SET_ID';
   
   /* The column already exists in schema, bypass creation */
    DBMS_OUTPUT.PUT_LINE( 'The column ICS_COPY_MGP_LMT_SET_ID already existed on ICS_LMT_SET_STAT , schema alteration bypassed!');

EXCEPTION

  WHEN NO_DATA_FOUND THEN  
  
    BEGIN
       
      --  Add new column 
      v_sql_statement := 'ALTER TABLE ICS_LMT_SET_STAT  ADD ICS_COPY_MGP_LMT_SET_ID VARCHAR(36) NULL';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The column ICS_COPY_MGP_LMT_SET_ID was added to the table ICS_LMT_SET_STAT !');
 
      v_sql_statement := 'CREATE INDEX "IX_LMT_SE_ST_IC_CO_MG_LM_SE_ID" 
   ON "ICS_LMT_SET_STAT"("ICS_COPY_MGP_LMT_SET_ID")';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The index IX_LMT_SE_ST_IC_CO_MG_LM_SE_ID  was added.');

      v_sql_statement := 'ALTER TABLE "ICS_LMT_SET_STAT"
 ADD ( CONSTRAINT "FK_LMT_SET_STAT_COPY_MGP"
 FOREIGN KEY("ICS_COPY_MGP_LMT_SET_ID")
 REFERENCES ICS_COPY_MGP_LMT_SET("ICS_COPY_MGP_LMT_SET_ID")
ON DELETE CASCADE NOT DEFERRABLE INITIALLY IMMEDIATE VALIDATE )';
      EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'The FK FK_LMT_SET_SCHD_COPY_MGP  was added.');
      
     END;  

END;
/ 
 


  
/******************************************************************************************************** 

    Alter table ICS_LMT_SET_SCHD.ICS_LMT_SET_ID made nulllable (will assume it already exists)
*********************************************************************************************************/

DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  /* Check to see if ICS_LMT_SET_STAT.ICS_LMT_SET_ID is nulllable on the database table ICS_LMT_SET_SCHD   */
   SELECT 1
    INTO v_object_ind
     FROM user_tables
     JOIN user_tab_cols
       ON user_tab_cols.table_name = user_tables.table_name
    WHERE user_tables.table_name = 'ICS_LMT_SET_SCHD'
      AND user_tab_cols.column_name = 'ICS_LMT_SET_ID'
      AND NULLABLE = 'Y';
   
   /* The column already nullable, bypass modify */
    DBMS_OUTPUT.PUT_LINE( 'The column ICS_LMT_SET_ID already nullable , schema alteration bypassed!');

EXCEPTION

  WHEN NO_DATA_FOUND THEN  
    BEGIN
      v_sql_statement := 'ALTER TABLE ICS_LMT_SET_SCHD MODIFY ICS_LMT_SET_ID VARCHAR2(36) NULL';
       EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'ICS_LMT_SET_SCHD.ICS_LMT_SET_ID made nulllable');
      
   END;
END;
/



  
/******************************************************************************************************** 

    Alter table ICS_LMT_SET_STAT.ICS_LMT_SET_ID made nulllable (will assume it already exists)
*********************************************************************************************************/

DECLARE

  v_object_ind NUMBER(01) := 0;
  v_sql_statement VARCHAR2(4000);

BEGIN 

  /*  Check to see if ICS_LMT_SET_STAT.ICS_LMT_SET_ID is nulllable on the database table ICS_LMT_SET_STAT   */
   SELECT 1
    INTO v_object_ind
     FROM user_tables
     JOIN user_tab_cols
       ON user_tab_cols.table_name = user_tables.table_name
    WHERE user_tables.table_name = 'ICS_LMT_SET_STAT'
      AND user_tab_cols.column_name = 'ICS_LMT_SET_ID'
      AND NULLABLE = 'Y';
   
   /* The column already nullable, bypass modify */
    DBMS_OUTPUT.PUT_LINE( 'The column ICS_LMT_SET_ID already nullable , schema alteration bypassed!');

EXCEPTION

  WHEN NO_DATA_FOUND THEN  
    BEGIN
      v_sql_statement := 'ALTER TABLE ICS_LMT_SET_STAT MODIFY ICS_LMT_SET_ID VARCHAR2(36) NULL';
       EXECUTE IMMEDIATE v_sql_statement;   
      DBMS_OUTPUT.PUT_LINE( 'ICS_LMT_SET_STAT.ICS_LMT_SET_ID made nulllable');
      
   END;
END;
/
      

-- 5.8.1
INSERT INTO "ICS_PAYLOAD" ("ICS_PAYLOAD_ID", "OPERATION", "ENABLED", "AUTO_GEN_DELETES", "BASE_TABLE_NAME", "ETL_PROCEDURE") 
SELECT 'CopyMGPLimitSet', 'CopyMGPLimitSetSubmission', 'Y', 'N', 'ICS_COPY_MGP_LMT_SET', NULL from dual where not exists (SELECT 1 from ICS_PAYLOAD where ICS_PAYLOAD_ID = 'CopyMGPLimitSet');

DELETE FROM ICS_ABOUT_DB;
INSERT INTO ICS_ABOUT_DB(ICS_ABOUT_DB_ID,DATA_KEY,DATA_VALUE) VALUES(SYS_GUID(),'ICIS_NPDES_VERSION','5.8.1');
INSERT INTO ICS_ABOUT_DB(ICS_ABOUT_DB_ID,DATA_KEY,DATA_VALUE) VALUES(SYS_GUID(),'DEPLOY_DATE',SYSDATE);
INSERT INTO ICS_ABOUT_DB(ICS_ABOUT_DB_ID,DATA_KEY,DATA_VALUE) VALUES(SYS_GUID(),'DEPLOY_ANALYST','Windsor');



commit;




