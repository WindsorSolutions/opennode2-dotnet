
IF NOT EXISTS (SELECT name FROM sys.schemas WHERE name = N'ICS_FLOW_LOCAL')
BEGIN
	exec('create schema ICS_FLOW_LOCAL');
END
GO

IF NOT EXISTS (SELECT name FROM sys.schemas WHERE name = N'ICS_FLOW_ICIS')
BEGIN
	exec('create schema ICS_FLOW_ICIS');
END
GO

