IF NOT EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND OBJECT_ID = OBJECT_ID('ICS_FLOW_LOCAL.ICS_PROCESS_ACCEPTED_TRANS'))
  EXEC('CREATE PROCEDURE [ICS_FLOW_LOCAL].[ICS_PROCESS_ACCEPTED_TRANS] AS BEGIN SET NOCOUNT ON; END')
GO

/*
Copyright (c) 2012, The Environmental Council of the States (ECOS)
All rights reserved.
 
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
 
 * Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
 * Neither the name of the ECOS nor the names of its contributors may
   be used to endorse or promote products derived from this software
   without specific prior written permission.
 
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/

/*************************************************************************************************
** Object Name: ics_process_accepted_trans
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure uses the data in ICS_SUBM_RESULTS table to copy the data for accepted
**               transactions from the LOCAL to ICIS schema/database. It should only be executed by
**               the OpenNode2 plugin as part of the GetICISStatusAndProcessReports service execution
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 06/08/2016    Windsor     Baselined from v5.6 procedure. 
** 07/31/2017    EPerson     Removed deletion of ICS_FLOW_ICIS records for non-DMR payloads.
** 10/04/2017    TConrad     Delete all Warning transactions prior to reload from local (in addition
**                           to Accepted transactions).
** 11/14/2017    TConrad     Comment out removal of DMRs when permit is terminated.
** 11/14/2017    TConrad     Remove DMRs where permit was reissued and reissuance eff date is less
**                           than the DMR monitoring period end date (these are cleared by ICIS).
** 01/25/2018    EPerson     Treat DMR300 and BGP010 as Accepted records (they are accepted by ICIS)
** 07/09/2018    KJames      Casted all PRMT_IDENT_2 columns as VARCHAR(09) to prevent unintnetional
**                           spaces in the key hash when defined as CHAR(09) and empty.
** 07/10/2018    TConrad     Delete from ICS_NPDES_DAT_GRP_NUM before deleting from ICS_GNRL_PRMT
**                           (JIRA: ICISNUPG-44).
** 07/10/2018    TConrad     Fix deletion from ICS_NPDES_DAT_GRP_NUM before ICS_BASIC_PRMT
**                           (JIRA: ICISNUPG-44).
** 07/18/2018    TConrad     Comment out deletions of terminations.
** 04/05/2019    TConrad     Filter out inserts for records when permits are terminated:
**                                 prmt_ident NOT IN
**                                 (SELECT prmt_ident
**                                    FROM ICS_FLOW_LOCAL.ics_subm_results
**                                   WHERE subm_type_name = 'PermitTerminationSubmission'
**                                     AND result_type_code = 'Accepted');
** 06/28/2019    TConrad     Added inserts into ICS_NPDES_DAT_GRP_NUM for accepted General Permits.
** 06/28/2019    TConrad     Commented out the EXEC ICS_FLOW_LOCAL.ICS_PROCESS_ACCEPTED_TRANS statement at end.
** 06/28/2019    TConrad     Un-comment deletions of terminations. This allows the procedure to run
**                           multiple times without error.
** 08/18/2019    CTyler      added ICS_COPY_MGP_LMT_SET payload processing
** 09/06/2019    CTyler      Added ICS_COPY_MGP_LMT_SET 
** 09/13/2019    CTyler      changed to CopyMGPLimitSetDataSubmission in hash calc
** 04/01/2025    CTyler      Changes for ICIS-NPDES 5.14 
** 2025-05-20    CTyler      Added OECA Assume all data section
***************************************************************************************************/
ALTER PROCEDURE ICS_FLOW_LOCAL.ICS_PROCESS_ACCEPTED_TRANS

   @p_transaction_id varchar(50)

AS

-- Stored procedure to move accepted transactions from ICS_FLOW_LOCAL to ICS_FLOW_ICIS.
-- Target Database: SQL Server

--Step 0.5: Create acceptance records for all OECA data store payloads (ICIS-NPDES 5.14)  UNTIL THEY FIX RESPONSE
--Step 1: Remove processing results from previous submissions
--Step 2: Update key_hash with hashed business key data
--Step 3: Move accepted transactions from LOCAL to ICIS database
--Step 4: Copy business keys where ICIS returnes error that key is already present in ICIS
--Step 5: Record counts INTO ICS_FLOW_LOCAL.ics_subm_hist

--Quit procedure if no records are returned relating to the current transaction. ICIS will return an empty processing report
  --if there is a severe error in the ICIS submission processor at EPA
IF (SELECT COUNT(1) FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_transaction_id = @p_transaction_id) = 0
   RETURN;



-- Step 0.5: Create acceptance records for all OECA data store payloads (ICIS-NPDES 5.14) 
--           There may be a result report in a future release, but for now we accept everything and 
--           handle with existing logic

-- ==============================================================
-- OECA Assume All Data Accepted 
--
-- This logic assumes that all data sent was accepted for OECA.
-- This may change in the future if results are returned
-- ==============================================================
insert into ICS_FLOW_LOCAL.ICS_SUBM_RESULTS (ICS_SUBM_RESULTS_ID,TRANSACTION_TYPE,SUBM_TRANSACTION_ID,CREATED_DATE_TIME,RESULT_TYPE_CODE,SUBM_TYPE_NAME,PRMT_IDENT,PROG_REP_FORM_SET_ID,PROG_REP_FORM_ID) select newid() as ICS_SUBM_RESULTS_ID,'R' as TRANSACTION_TYPE,@p_transaction_id as SUBM_TRANSACTION_ID,getdate() as CREATE_DATE_TIME,'Accepted' as RESULT_TYPE_CODE,'BiosolidsAnnualProgramReportSubmission',PRMT_IDENT,PROG_REP_FORM_SET_ID,PROG_REP_FORM_ID from ICS_FLOW_LOCAL.ICS_BS_ANNUL_PROG_REP WHERE TRANSACTION_TYPE is not null;
insert into ICS_FLOW_LOCAL.ICS_SUBM_RESULTS (ICS_SUBM_RESULTS_ID,TRANSACTION_TYPE,SUBM_TRANSACTION_ID,CREATED_DATE_TIME,RESULT_TYPE_CODE,SUBM_TYPE_NAME,PRMT_IDENT,PROG_REP_FORM_SET_ID,PROG_REP_FORM_ID) select newid() as ICS_SUBM_RESULTS_ID,'R' as TRANSACTION_TYPE,@p_transaction_id as SUBM_TRANSACTION_ID,getdate() as CREATE_DATE_TIME,'Accepted' as RESULT_TYPE_CODE,'CAFOAnnualProgramReportSubmission',PRMT_IDENT,PROG_REP_FORM_SET_ID,PROG_REP_FORM_ID from ICS_FLOW_LOCAL.ICS_CAFO_ANNUL_PROG_REP WHERE TRANSACTION_TYPE is not null;
insert into ICS_FLOW_LOCAL.ICS_SUBM_RESULTS (ICS_SUBM_RESULTS_ID,TRANSACTION_TYPE,SUBM_TRANSACTION_ID,CREATED_DATE_TIME,RESULT_TYPE_CODE,SUBM_TYPE_NAME,PRMT_IDENT,COLL_SYSTM_IDENT) select newid() as ICS_SUBM_RESULTS_ID,'R' as TRANSACTION_TYPE,@p_transaction_id as SUBM_TRANSACTION_ID,getdate() as CREATE_DATE_TIME,'Accepted' as RESULT_TYPE_CODE,'CollectionSystemPermitSubmission',PRMT_IDENT,COLL_SYSTM_IDENT from ICS_FLOW_LOCAL.ICS_COLL_SYSTM_PRMT WHERE TRANSACTION_TYPE is not null;
insert into ICS_FLOW_LOCAL.ICS_SUBM_RESULTS (ICS_SUBM_RESULTS_ID,TRANSACTION_TYPE,SUBM_TRANSACTION_ID,CREATED_DATE_TIME,RESULT_TYPE_CODE,SUBM_TYPE_NAME,PRMT_IDENT) select newid() as ICS_SUBM_RESULTS_ID,'R' as TRANSACTION_TYPE,@p_transaction_id as SUBM_TRANSACTION_ID,getdate() as CREATE_DATE_TIME,'Accepted' as RESULT_TYPE_CODE,'CopyMGPMS4RequirementSubmission',PRMT_IDENT from ICS_FLOW_LOCAL.ICS_COPY_MGPMS_4_REQ WHERE TRANSACTION_TYPE is not null;
insert into ICS_FLOW_LOCAL.ICS_SUBM_RESULTS (ICS_SUBM_RESULTS_ID,TRANSACTION_TYPE,SUBM_TRANSACTION_ID,CREATED_DATE_TIME,RESULT_TYPE_CODE,SUBM_TYPE_NAME,PRMT_IDENT) select newid() as ICS_SUBM_RESULTS_ID,'R' as TRANSACTION_TYPE,@p_transaction_id as SUBM_TRANSACTION_ID,getdate() as CREATE_DATE_TIME,'Accepted' as RESULT_TYPE_CODE,'CSOLongTermControlPlanSubmission',PRMT_IDENT from ICS_FLOW_LOCAL.ICS_CSO_LONG_TERM_CONTROL_PLAN WHERE TRANSACTION_TYPE is not null;
insert into ICS_FLOW_LOCAL.ICS_SUBM_RESULTS (ICS_SUBM_RESULTS_ID,TRANSACTION_TYPE,SUBM_TRANSACTION_ID,CREATED_DATE_TIME,RESULT_TYPE_CODE,SUBM_TYPE_NAME,PRMT_IDENT,PROG_REP_FORM_SET_ID,PROG_REP_FORM_ID) select newid() as ICS_SUBM_RESULTS_ID,'R' as TRANSACTION_TYPE,@p_transaction_id as SUBM_TRANSACTION_ID,getdate() as CREATE_DATE_TIME,'Accepted' as RESULT_TYPE_CODE,'CWA316bProgramReportSubmission',PRMT_IDENT,PROG_REP_FORM_SET_ID,PROG_REP_FORM_ID from ICS_FLOW_LOCAL.ICS_CWA_316B_PROG_REP WHERE TRANSACTION_TYPE is not null;
insert into ICS_FLOW_LOCAL.ICS_SUBM_RESULTS (ICS_SUBM_RESULTS_ID,TRANSACTION_TYPE,SUBM_TRANSACTION_ID,CREATED_DATE_TIME,RESULT_TYPE_CODE,SUBM_TYPE_NAME,PRMT_IDENT,NPDES_VARIANCE_TYPE_CODE,NPDES_VARIANCE_SUBM_DATE) select newid() as ICS_SUBM_RESULTS_ID,'R' as TRANSACTION_TYPE,@p_transaction_id as SUBM_TRANSACTION_ID,getdate() as CREATE_DATE_TIME,'Accepted' as RESULT_TYPE_CODE,'NPDESVariancePermitSubmission',PRMT_IDENT,NPDES_VARIANCE_TYPE_CODE,NPDES_VARIANCE_SUBM_DATE from ICS_FLOW_LOCAL.ICS_NPDES_VARIANCE_PRMT WHERE TRANSACTION_TYPE is not null;
insert into ICS_FLOW_LOCAL.ICS_SUBM_RESULTS (ICS_SUBM_RESULTS_ID,TRANSACTION_TYPE,SUBM_TRANSACTION_ID,CREATED_DATE_TIME,RESULT_TYPE_CODE,SUBM_TYPE_NAME,PRMT_IDENT) select newid() as ICS_SUBM_RESULTS_ID,'R' as TRANSACTION_TYPE,@p_transaction_id as SUBM_TRANSACTION_ID,getdate() as CREATE_DATE_TIME,'Accepted' as RESULT_TYPE_CODE,'POTWTreatmentTechnologyPermitSubmission',PRMT_IDENT from ICS_FLOW_LOCAL.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT WHERE TRANSACTION_TYPE is not null;
insert into ICS_FLOW_LOCAL.ICS_SUBM_RESULTS (ICS_SUBM_RESULTS_ID,TRANSACTION_TYPE,SUBM_TRANSACTION_ID,CREATED_DATE_TIME,RESULT_TYPE_CODE,SUBM_TYPE_NAME,PRMT_IDENT,PROG_REP_FORM_SET_ID,PROG_REP_FORM_ID) select newid() as ICS_SUBM_RESULTS_ID,'R' as TRANSACTION_TYPE,@p_transaction_id as SUBM_TRANSACTION_ID,getdate() as CREATE_DATE_TIME,'Accepted' as RESULT_TYPE_CODE,'PretreatmentProgramReportSubmission',PRMT_IDENT,PROG_REP_FORM_SET_ID,PROG_REP_FORM_ID from ICS_FLOW_LOCAL.ICS_PRETR_PROG_REP WHERE TRANSACTION_TYPE is not null;
insert into ICS_FLOW_LOCAL.ICS_SUBM_RESULTS (ICS_SUBM_RESULTS_ID,TRANSACTION_TYPE,SUBM_TRANSACTION_ID,CREATED_DATE_TIME,RESULT_TYPE_CODE,SUBM_TYPE_NAME,PRMT_IDENT,PROG_REP_FORM_SET_ID,PROG_REP_FORM_ID) select newid() as ICS_SUBM_RESULTS_ID,'R' as TRANSACTION_TYPE,@p_transaction_id as SUBM_TRANSACTION_ID,getdate() as CREATE_DATE_TIME,'Accepted' as RESULT_TYPE_CODE,'SewerOverflowBypassEventReportSubmission',PRMT_IDENT,PROG_REP_FORM_SET_ID,PROG_REP_FORM_ID from ICS_FLOW_LOCAL.ICS_SEWER_OVRFLW_BYPASS_EVT_REP WHERE TRANSACTION_TYPE is not null;
insert into ICS_FLOW_LOCAL.ICS_SUBM_RESULTS (ICS_SUBM_RESULTS_ID,TRANSACTION_TYPE,SUBM_TRANSACTION_ID,CREATED_DATE_TIME,RESULT_TYPE_CODE,SUBM_TYPE_NAME,PRMT_IDENT,PROG_REP_FORM_SET_ID,PROG_REP_FORM_ID) select newid() as ICS_SUBM_RESULTS_ID,'R' as TRANSACTION_TYPE,@p_transaction_id as SUBM_TRANSACTION_ID,getdate() as CREATE_DATE_TIME,'Accepted' as RESULT_TYPE_CODE,'SWMS4AnnualProgramReportSubmission',PRMT_IDENT,PROG_REP_FORM_SET_ID,PROG_REP_FORM_ID from ICS_FLOW_LOCAL.ICS_SWMS_4_ANNUL_PROG_REP WHERE TRANSACTION_TYPE is not null;
insert into ICS_FLOW_LOCAL.ICS_SUBM_RESULTS (ICS_SUBM_RESULTS_ID,TRANSACTION_TYPE,SUBM_TRANSACTION_ID,CREATED_DATE_TIME,RESULT_TYPE_CODE,SUBM_TYPE_NAME,PRMT_IDENT) select newid() as ICS_SUBM_RESULTS_ID,'R' as TRANSACTION_TYPE,@p_transaction_id as SUBM_TRANSACTION_ID,getdate() as CREATE_DATE_TIME,'Accepted' as RESULT_TYPE_CODE,'SWMS4PermitSubmission',PRMT_IDENT from ICS_FLOW_LOCAL.ICS_SWMS_4_PRMT WHERE TRANSACTION_TYPE is not null;





--Step 1: Remove processing results from previous submissions

    --Remove all old Accepted records
    DELETE 
      FROM ICS_FLOW_LOCAL.ics_subm_results 
     WHERE (result_type_code = 'Accepted' OR result_code IN ('DMR300', 'BGP010'))
       AND subm_transaction_id <> @p_transaction_id;

    --Delete errors if there was at least one accepted transaction for the same submission type in the latest submission 
    DELETE 
      FROM ICS_FLOW_LOCAL.ics_subm_results 
     WHERE result_type_code IN ('Error','Warning')
	   AND subm_type_name   IN (SELECT subm_type_name
	                              FROM ICS_FLOW_LOCAL.ics_subm_results
								 WHERE subm_transaction_id = @p_transaction_id
								   AND subm_type_name <> 'DischargeMonitoringReportSubmission'
								   AND result_type_code = 'Accepted')
       AND subm_transaction_id <> @p_transaction_id;
 
    --Remove previous DMR error transactions where same business key values exist in the most recent submission
	--This will leave previous DMR errors in the results table that have not yet been corrected.
	DELETE
	  FROM ICS_FLOW_LOCAL.ics_subm_results
	 WHERE subm_type_name = 'DischargeMonitoringReportSubmission'
	   AND subm_transaction_id <> @p_transaction_id
	   AND result_type_code = 'Error'
	   AND EXISTS (SELECT 1
					 FROM ICS_FLOW_LOCAL.ics_subm_results r
					WHERE r.subm_type_name = 'DischargeMonitoringReportSubmission'
					  AND r.subm_transaction_id = @p_transaction_id
					  AND r.prmt_ident         = ics_subm_results.prmt_ident
					  AND r.prmt_featr_ident   = ics_subm_results.prmt_featr_ident
					  AND r.lmt_set_designator = ics_subm_results.lmt_set_designator
					  --COALESCE below removes previous errors for "DMR Does not exist for key data entered" when DMR params have now beem successfully sent
					  AND COALESCE(r.param_code, ics_subm_results.param_code)         = ics_subm_results.param_code
					  AND COALESCE(r.mon_site_desc_code, ics_subm_results.param_code) = ics_subm_results.mon_site_desc_code
					  AND COALESCE(r.lmt_season_num, ics_subm_results.param_code)     = ics_subm_results.lmt_season_num);

--Step 2: Update key_hash with hashed business key data
UPDATE ICS_FLOW_LOCAL.ics_subm_results
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', prmt_ident)
 WHERE subm_transaction_id = @p_transaction_id
   AND subm_type_name IN ('BasicPermitSubmission'
                         ,'BiosolidsPermitSubmission'
						 ,'CAFOPermitSubmission'
						 ,'CSOPermitSubmission'
						 ,'GeneralPermitSubmission'
						 ,'MasterGeneralPermitSubmission'
						 ,'PermitReissuanceSubmission'
						 ,'PermitTerminationSubmission'
						 ,'POTWPermitSubmission'
						 ,'PretreatmentPermitSubmission'
						 ,'SWConstructionPermitSubmission'
						 ,'SWIndustrialPermitSubmission'
						-- ,'SWMS4LargePermitSubmission'
						-- ,'SWMS4SmallPermitSubmission'
						 ,'UnpermittedFacilitySubmission'
						 -- 5.14
						 ,'CSOLongTermControlPlanSubmission'
						 ,'CopyMGPMS4RequirementSubmission'
						 ,'POTWTreatmentTechnologyPermitSubmission'
						 ,'SWMS4PermitSubmission'
						 );


 -- 5.14 Program Reports
 UPDATE ICS_FLOW_LOCAL.ics_subm_results
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', prmt_ident + PROG_REP_FORM_SET_ID + CONVERT(varchar(50), PROG_REP_FORM_ID) )
 WHERE subm_type_name in (
						'CAFOAnnualProgramReportSubmission'
						,'CWA316bProgramReportSubmission'
						,'PretreatmentProgramReportSubmission'
						,'SWMS4AnnualProgramReportSubmission'
						,'SewerOverflowBypassEventReportSubmission'
						,'BiosolidsAnnualProgramReportSubmission'
						)
   AND subm_transaction_id = @p_transaction_id;

UPDATE ICS_FLOW_LOCAL.ics_subm_results
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', prmt_ident + COLL_SYSTM_IDENT)
 WHERE subm_type_name = 'CollectionSystemPermitSubmission'
   AND subm_transaction_id = @p_transaction_id;

UPDATE ICS_FLOW_LOCAL.ics_subm_results
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', prmt_ident + NPDES_VARIANCE_TYPE_CODE + CONVERT(varchar(50), NPDES_VARIANCE_SUBM_DATE))
 WHERE subm_type_name = 'NPDESVariancePermitSubmission'
   AND subm_transaction_id = @p_transaction_id;



UPDATE ICS_FLOW_LOCAL.ics_subm_results
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', prmt_ident + prmt_track_evt_code + CONVERT(varchar(50), prmt_track_evt_date))
 WHERE subm_type_name = 'PermitTrackingEventSubmission'
   AND subm_transaction_id = @p_transaction_id;

UPDATE ICS_FLOW_LOCAL.ics_subm_results
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', prmt_ident + CONVERT(varchar(50), prmt_effective_date) + CONVERT(varchar(50), narr_cond_num) + schd_evt_code + CONVERT(varchar(50), schd_date) + CONVERT(varchar(50), narr_cond_num) + schd_evt_code + CONVERT(varchar(50), schd_date))
 WHERE subm_type_name = 'HistoricalPermitScheduleEventsSubmission'
   AND subm_transaction_id = @p_transaction_id;

UPDATE ICS_FLOW_LOCAL.ics_subm_results
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', prmt_ident + CONVERT(varchar(50), narr_cond_num))
 WHERE subm_type_name = 'NarrativeConditionScheduleSubmission'
   AND subm_transaction_id = @p_transaction_id;

UPDATE ICS_FLOW_LOCAL.ics_subm_results
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', prmt_ident + prmt_featr_ident)
 WHERE subm_type_name = 'PermittedFeatureSubmission'
   AND subm_transaction_id = @p_transaction_id;

UPDATE ICS_FLOW_LOCAL.ics_subm_results
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', prmt_ident + prmt_featr_ident + lmt_set_designator)
 WHERE subm_type_name = 'LimitSetSubmission'
   AND subm_transaction_id = @p_transaction_id;

UPDATE ICS_FLOW_LOCAL.ics_subm_results
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', prmt_ident + prmt_featr_ident + lmt_set_designator + param_code + mon_site_desc_code + CONVERT(varchar(50), lmt_season_num) + CONVERT(varchar(50), lmt_start_date) + CONVERT(varchar(50), lmt_end_date))
 WHERE subm_type_name = 'LimitsSubmission'
   AND subm_transaction_id = @p_transaction_id;

UPDATE ICS_FLOW_LOCAL.ics_subm_results
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', prmt_ident + prmt_featr_ident + lmt_set_designator + param_code + mon_site_desc_code + CONVERT(varchar(50), lmt_season_num))
 WHERE subm_type_name = 'ParameterLimitsSubmission'
   AND subm_transaction_id = @p_transaction_id;

UPDATE ICS_FLOW_LOCAL.ics_subm_results
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', prmt_ident + prmt_featr_ident + lmt_set_designator + CONVERT(varchar(50), mon_period_end_date))
 WHERE subm_type_name = 'DischargeMonitoringReportSubmission'
   AND subm_transaction_id = @p_transaction_id;

UPDATE ICS_FLOW_LOCAL.ics_subm_results
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', cmpl_mon_ident)
--   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', prmt_ident + cmpl_mon_catg_code + CONVERT(varchar(50), cmpl_mon_date))
 WHERE subm_type_name = 'ComplianceMonitoringSubmission'
   AND subm_transaction_id = @p_transaction_id;

UPDATE ICS_FLOW_LOCAL.ics_subm_results
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', prmt_ident + prmt_featr_ident + lmt_set_designator + param_code + mon_site_desc_code + CONVERT(varchar(50), lmt_season_num) + CONVERT(varchar(50), lmt_start_date) + CONVERT(varchar(50), lmt_end_date) + CONVERT(varchar(50), lmt_mod_effective_date) + trade_id)
 WHERE subm_type_name = 'EffluentTradePartnerSubmission'
   AND subm_transaction_id = @p_transaction_id;

UPDATE ICS_FLOW_LOCAL.ics_subm_results
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', enfrc_actn_ident)
 WHERE subm_type_name = 'FormalEnforcementActionSubmission'
   AND subm_transaction_id = @p_transaction_id;

UPDATE ICS_FLOW_LOCAL.ics_subm_results
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', enfrc_actn_ident)
 WHERE subm_type_name = 'InformalEnforcementActionSubmission'
   AND subm_transaction_id = @p_transaction_id;

UPDATE ICS_FLOW_LOCAL.ics_subm_results
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', enfrc_actn_ident + CONVERT(varchar(50), final_order_ident) + prmt_ident + CONVERT(varchar(50), cmpl_schd_num))
 WHERE subm_type_name = 'ComplianceScheduleSubmission'
   AND subm_transaction_id = @p_transaction_id;

UPDATE ICS_FLOW_LOCAL.ics_subm_results
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', enfrc_actn_ident + milestone_type_code)
 WHERE subm_type_name = 'EnforcementActionMilestoneSubmission'
   AND subm_transaction_id = @p_transaction_id;

UPDATE ICS_FLOW_LOCAL.ics_subm_results
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', prmt_ident + prmt_featr_ident + lmt_set_designator + CONVERT(varchar(50), mon_period_end_date) + param_code + mon_site_desc_code + CONVERT(varchar(50), lmt_season_num) + CONVERT(varchar(50), num_rep_code) + CONVERT(varchar(50), num_rep_viol_code))
 WHERE subm_type_name = 'DMRViolationSubmission'
   AND subm_transaction_id = @p_transaction_id;

UPDATE ICS_FLOW_LOCAL.ics_subm_results
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', prmt_ident + sngl_evt_viol_code + CONVERT(varchar(50), sngl_evt_viol_date))
 WHERE subm_type_name = 'SingleEventViolationSubmission'
   AND subm_transaction_id = @p_transaction_id;

--UPDATE ICS_FLOW_LOCAL.ics_subm_results
--   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', prmt_ident + CONVERT(varchar(50), cso_evt_date) + CONVERT(varchar(50), evt_id))
-- WHERE subm_type_name = 'CSOEventReportSubmission'
--   AND subm_transaction_id = @p_transaction_id;

UPDATE ICS_FLOW_LOCAL.ics_subm_results
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1',
      PRMT_IDENT
      + PRMT_FEATR_IDENT
      + LMT_SET_DESIGNATOR
   )
 WHERE subm_type_name = 'CopyMGPLimitSetSubmission'
   AND subm_transaction_id = @p_transaction_id;

--UPDATE ICS_FLOW_LOCAL.ics_subm_results
--   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', prmt_ident + CONVERT(varchar(50), date_strm_evt_smpl) + CONVERT(varchar(50), evt_id))
-- WHERE subm_type_name = 'SWEventReportSubmission'
--   AND subm_transaction_id = @p_transaction_id;

UPDATE ICS_FLOW_LOCAL.ics_subm_results
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', prmt_ident + CONVERT(varchar(50), prmt_auth_rep_rcvd_date))
 WHERE subm_type_name = 'CAFOAnnualReportSubmission'
   AND subm_transaction_id = @p_transaction_id;

UPDATE ICS_FLOW_LOCAL.ics_subm_results
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', prmt_ident + CONVERT(varchar(50), indst_sw_annul_rep_rcvd_date))
 WHERE subm_type_name = 'SWIndustrialAnnualReportSubmission'
   AND subm_transaction_id = @p_transaction_id;

--UPDATE ICS_FLOW_LOCAL.ics_subm_results
--   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', prmt_ident + CONVERT(varchar(50), prmt_auth_rep_rcvd_date))
-- WHERE subm_type_name = 'LocalLimitsProgramReportSubmission'
--   AND subm_transaction_id = @p_transaction_id;

--UPDATE ICS_FLOW_LOCAL.ics_subm_results
--   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', prmt_ident + CONVERT(varchar(50), pretr_perf_summ_end_date))
-- WHERE subm_type_name = 'PretreatmentPerformanceSummarySubmission'
--   AND subm_transaction_id = @p_transaction_id;

--UPDATE ICS_FLOW_LOCAL.ics_subm_results
--   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', prmt_ident + CONVERT(varchar(50), rep_coverage_end_date))
-- WHERE subm_type_name = 'BiosolidsProgramReportSubmission'
--   AND subm_transaction_id = @p_transaction_id;

   
--UPDATE ICS_FLOW_LOCAL.ics_subm_results
--   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', prmt_ident + CONVERT(varchar(50), sso_annul_rep_rcvd_date))
-- WHERE subm_type_name = 'SSOAnnualReportSubmission'
--   AND subm_transaction_id = @p_transaction_id;

--UPDATE ICS_FLOW_LOCAL.ics_subm_results
--   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', prmt_ident + CONVERT(varchar(50), sso_evt_date) + CONVERT(varchar(50), evt_id))
-- WHERE subm_type_name = 'SSOEventReportSubmission'
--   AND subm_transaction_id = @p_transaction_id;

--UPDATE ICS_FLOW_LOCAL.ics_subm_results
--   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', prmt_ident + CONVERT(varchar(50), sso_monthly_rep_rcvd_date))
-- WHERE subm_type_name = 'SSOMonthlyEventReportSubmission'
--   AND subm_transaction_id = @p_transaction_id;

--UPDATE ICS_FLOW_LOCAL.ics_subm_results
--   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', prmt_ident + CONVERT(varchar(50), sw_ms_4_rep_rcvd_date))
-- WHERE subm_type_name = 'SWMS4ProgramReportSubmission'
--   AND subm_transaction_id = @p_transaction_id;

  
UPDATE ICS_FLOW_LOCAL.ics_subm_results
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1',
						cmpl_mon_ident
                         + COALESCE(
                                   cmpl_mon_ident_2
								   ,enfrc_actn_ident
                                   ,CONCAT(
										prmt_ident
										,sngl_evt_viol_code
										,CONVERT(varchar(50), sngl_evt_viol_date)
                                    ) 
                         )
						)  
 WHERE subm_type_name = 'ComplianceMonitoringLinkageSubmission'
   AND subm_transaction_id = @p_transaction_id;  
   


-- UPDATE KEY HASH Choice (breakout method)
-- ---------------------
-- EnforcementActionViolationLinkageSubmission
-- DMR Value
update ICS_SUBM_RESULTS SET KEY_HASH = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1',CONCAT(
ENFRC_ACTN_IDENT
	,PRMT_IDENT
	,PRMT_FEATR_IDENT
	,LMT_SET_DESIGNATOR
	,MON_PERIOD_END_DATE
	,PARAM_CODE
	,MON_SITE_DESC_CODE
	,LMT_SEASON_NUM
)) from  ICS_SUBM_RESULTS ISR where SUBM_TYPE_NAME = 'EnforcementActionViolationLinkageSubmission' and PARAM_CODE is not null;

-- DMR (form)
update ICS_SUBM_RESULTS SET KEY_HASH = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1',CONCAT(
ENFRC_ACTN_IDENT
	,PRMT_IDENT
	,PRMT_FEATR_IDENT
	,LMT_SET_DESIGNATOR
	,MON_PERIOD_END_DATE
))
from ICS_SUBM_RESULTS ISR where SUBM_TYPE_NAME = 'EnforcementActionViolationLinkageSubmission' and MON_PERIOD_END_DATE is not null and PARAM_CODE is null
;
-- Permit Schedule Violation
update ICS_SUBM_RESULTS SET KEY_HASH = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1',CONCAT(
ENFRC_ACTN_IDENT
	,PRMT_IDENT
	,NARR_COND_NUM
	,SCHD_EVT_CODE
	,SCHD_DATE
))
from ICS_SUBM_RESULTS ISR where SUBM_TYPE_NAME = 'EnforcementActionViolationLinkageSubmission' and NARR_COND_NUM is not null
;
-- Single Event Violation 
update ICS_SUBM_RESULTS SET KEY_HASH = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1',CONCAT(
ENFRC_ACTN_IDENT
	,PRMT_IDENT
	,SNGL_EVT_VIOL_CODE
	,SNGL_EVT_VIOL_DATE
))
from ICS_SUBM_RESULTS ISR where SUBM_TYPE_NAME = 'EnforcementActionViolationLinkageSubmission' and SNGL_EVT_VIOL_CODE is not null
;
-- Compliance Schedule 
update ICS_SUBM_RESULTS SET KEY_HASH = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1',CONCAT(
ENFRC_ACTN_IDENT
	,FINAL_ORDER_IDENT
	,PRMT_IDENT
	,CMPL_SCHD_NUM
	,SCHD_EVT_CODE
	,SCHD_DATE
))
from ICS_SUBM_RESULTS ISR where SUBM_TYPE_NAME = 'EnforcementActionViolationLinkageSubmission' and CMPL_SCHD_NUM is not null
;



-- UPDATE KEY HASH Choice (breakout method)
-- ---------------------
-- FinalOrderViolationLinkageSubmission
-- DMR Value
update ICS_SUBM_RESULTS SET KEY_HASH = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1',CONCAT(
ENFRC_ACTN_IDENT
,FINAL_ORDER_IDENT
	,PRMT_IDENT
	,PRMT_FEATR_IDENT
	,LMT_SET_DESIGNATOR
	,MON_PERIOD_END_DATE
	,PARAM_CODE
	,MON_SITE_DESC_CODE
	,LMT_SEASON_NUM
)) from  ICS_SUBM_RESULTS ISR where SUBM_TYPE_NAME = 'FinalOrderViolationLinkageSubmission' and PARAM_CODE is not null;

-- DMR (form)
update ICS_SUBM_RESULTS SET KEY_HASH = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1',CONCAT(
ENFRC_ACTN_IDENT
,FINAL_ORDER_IDENT
	,PRMT_IDENT
	,PRMT_FEATR_IDENT
	,LMT_SET_DESIGNATOR
	,MON_PERIOD_END_DATE
))
from ICS_SUBM_RESULTS ISR where SUBM_TYPE_NAME = 'FinalOrderViolationLinkageSubmission' and MON_PERIOD_END_DATE is not null and PARAM_CODE is null
;
-- Permit Schedule Violation
update ICS_SUBM_RESULTS SET KEY_HASH = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1',CONCAT(
ENFRC_ACTN_IDENT
,FINAL_ORDER_IDENT
	,PRMT_IDENT
	,NARR_COND_NUM
	,SCHD_EVT_CODE
	,SCHD_DATE
))
from ICS_SUBM_RESULTS ISR where SUBM_TYPE_NAME = 'FinalOrderViolationLinkageSubmission' and NARR_COND_NUM is not null
;
-- Single Event Violation 
update ICS_SUBM_RESULTS SET KEY_HASH = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1',CONCAT(
ENFRC_ACTN_IDENT
,FINAL_ORDER_IDENT
	,PRMT_IDENT
	,SNGL_EVT_VIOL_CODE
	,SNGL_EVT_VIOL_DATE
))
from ICS_SUBM_RESULTS ISR where SUBM_TYPE_NAME = 'FinalOrderViolationLinkageSubmission' and SNGL_EVT_VIOL_CODE is not null
;
-- Compliance Schedule 
update ICS_SUBM_RESULTS SET KEY_HASH = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1',CONCAT(
ENFRC_ACTN_IDENT
,FINAL_ORDER_IDENT
	,FINAL_ORDER_IDENT_2
	,PRMT_IDENT
	,CMPL_SCHD_NUM
	,SCHD_EVT_CODE
	,SCHD_DATE
))
from ICS_SUBM_RESULTS ISR where SUBM_TYPE_NAME = 'FinalOrderViolationLinkageSubmission' and CMPL_SCHD_NUM is not null
;



UPDATE ICS_SUBM_RESULTS SET
KEY_HASH = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1',
	   concat(
	   ENFRC_ACTN_IDENT
	   ,FINAL_ORDER_IDENT
	   ,PRMT_IDENT
	   ,CMPL_SCHD_NUM
	   ,SCHD_EVT_CODE
	   ,SCHD_DATE
	   ))
where SUBM_TYPE_NAME  = 'ScheduleEventViolationSubmission' and ENFRC_ACTN_IDENT is not null
;
UPDATE ICS_SUBM_RESULTS SET
KEY_HASH = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1',
	   concat(
	   PRMT_IDENT
	   ,NARR_COND_NUM
	   ,SCHD_EVT_CODE
	   ,SCHD_DATE
	   ,SCHD_VIOL_CODE
	   ))
where SUBM_TYPE_NAME  = 'ScheduleEventViolationSubmission' and NARR_COND_NUM is not null
;


-- print 'Line 387'
-- OLD final Order Linkages (worked only for DV,PS and SEV)
/*
UPDATE ICS_FLOW_LOCAL.ics_subm_results
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', enfrc_actn_ident
                                 + CONVERT(varchar(50),final_order_ident)
                                 + ISNULL(prmt_ident,'')
                                 + ISNULL(CONVERT(varchar(50), narr_cond_num),'')
                                 + ISNULL(schd_evt_code,'')
                                 + ISNULL(CONVERT(varchar(50), schd_date),'')
                                 + ISNULL(enfrc_actn_ident_2,'')
                                 + ISNULL(CONVERT(varchar(50), final_order_ident_2),'')
                                 + ISNULL(CONVERT(varchar(50), cmpl_schd_num),'')
                                 + ISNULL(prmt_featr_ident,'')
                                 + ISNULL(lmt_set_designator,'')
                                 + ISNULL(CONVERT(varchar(50), mon_period_end_date),'')
                                 + ISNULL(param_code,'')
                                 + ISNULL(mon_site_desc_code,'')
                                 + ISNULL(CONVERT(varchar(50), lmt_season_num),'')
                                 + ISNULL(sngl_evt_viol_code,'')
                                 + ISNULL(CONVERT(varchar(50), sngl_evt_viol_date),'')
                                 )
 WHERE subm_type_name = 'FinalOrderViolationLinkageSubmission'
   AND subm_transaction_id = @p_transaction_id;

   */









--UPDATE ICS_FLOW_LOCAL.ics_subm_results
--   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1',
--          ISNULL(prmt_ident,'') 
--          + ISNULL(prmt_featr_ident,'') 
--          + ISNULL(lmt_set_designator,'') 
--          + ISNULL(CONVERT(varchar(50), mon_period_end_date),'') 
--          + ISNULL(CAST(prmt_ident_2 AS VARCHAR(09)),'') 
--          + ISNULL(CONVERT(varchar(50), rep_coverage_end_date),'') 
--          + ISNULL(CONVERT(varchar(50), date_strm_evt_smpl),'') 
--          + ISNULL(CONVERT(varchar(50), evt_id),'')
--          )
--   --SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', prmt_ident + prmt_featr_ident + lmt_set_designator + CONVERT(varchar(50), mon_period_end_date) + CAST(prmt_ident_2 AS VARCHAR(09)) + CONVERT(varchar(50), rep_coverage_end_date) + CONVERT(varchar(50), date_strm_evt_smpl) + CONVERT(varchar(50), evt_id))
-- WHERE subm_type_name = 'DMRProgramReportLinkageSubmission'
--   AND subm_transaction_id = @p_transaction_id;

--UPDATE ICS_FLOW_LOCAL.ics_subm_results
--   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', ISNULL(prmt_ident,'') + ISNULL(prmt_featr_ident,'') + ISNULL(lmt_set_designator,'') + ISNULL(CONVERT(varchar(50), mon_period_end_date),'') + ISNULL(CAST(prmt_ident_2 AS VARCHAR(09)),'') + ISNULL(CONVERT(varchar(50), rep_coverage_end_date),'') + ISNULL(CONVERT(varchar(50), date_strm_evt_smpl),'') + ISNULL(CONVERT(varchar(50), evt_id),''))
--   --SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', prmt_ident + prmt_featr_ident + lmt_set_designator + CONVERT(varchar(50), mon_period_end_date) + CAST(prmt_ident_2 AS VARCHAR(09)) + CONVERT(varchar(50), rep_coverage_end_date) + CONVERT(varchar(50), date_strm_evt_smpl) + CONVERT(varchar(50), evt_id))
-- WHERE subm_type_name = 'DMRProgramReportLinkageSubmission'
--   AND subm_transaction_id = @p_transaction_id;

--Delete errors from previous submissions where here is an error for the same key in the current submission
    DELETE 
      FROM ICS_FLOW_LOCAL.ics_subm_results 
     WHERE result_type_code IN ('Error','Warning')
       AND key_hash IN (SELECT key_hash 
                          FROM ICS_FLOW_LOCAL.ics_subm_results 
                         WHERE subm_transaction_id = @p_transaction_id
                           AND result_type_code IN ('Error','Warning'))
       AND subm_transaction_id <> @p_transaction_id;

 /*
  *  Step 3: Move accepted transactions from LOCAL to ICIS database
  *          FOR EACH PAYLOAD TYPE:
  *          1.  First prune data from the ICS_FLOW_ICIS schema to make room for new data coming across
  *              - Delete for basic permit, general permit, permitted feature, limit set, parameter limit, and limit data
  *                for permits that have been reissued.
  *              - Delete all data for permit that has been terminated 
  *          2.  Second copy accepted data from ICS_FLOW_LOCAL into ICS_FLOW_ICIS.
  */
 

-- ================================================================
-- ICS_BASIC_PRMT 
-- ================================================================
			
				-- DELETES for: ICS_BASIC_PRMT 
				
								
-- /ICS_BASIC_PRMT/ICS_NAICS_CODE
DELETE I25
 from ICS_FLOW_ICIS.[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_NAICS_CODE] [I25]
 ON [I25].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
				
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_BASIC_PRMT/ICS_CMPL_TRACK_STAT
DELETE I24
 from ICS_FLOW_ICIS.[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_CMPL_TRACK_STAT] [I24]
 ON [I24].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
				
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_BASIC_PRMT/ICS_ASSC_PRMT
DELETE I23
 from ICS_FLOW_ICIS.[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_ASSC_PRMT] [I23]
 ON [I23].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
				
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_BASIC_PRMT/ICS_ADDR/ICS_TELEPH
DELETE I22
 from ICS_FLOW_ICIS.[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_ADDR] [I21]
 ON [I21].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_TELEPH] [I22]
 ON [I22].[ICS_ADDR_ID] = [I21].[ICS_ADDR_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
				
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_BASIC_PRMT/ICS_ADDR
DELETE I21
 from ICS_FLOW_ICIS.[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_ADDR] [I21]
 ON [I21].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
				
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_BASIC_PRMT/ICS_SIU_DESGN_TYPE
DELETE I20
 from ICS_FLOW_ICIS.[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_SIU_DESGN_TYPE] [I20]
 ON [I20].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
				
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_BASIC_PRMT/ICS_SIC_CODE
DELETE I19
 from ICS_FLOW_ICIS.[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_SIC_CODE] [I19]
 ON [I19].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
				
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_BASIC_PRMT/ICS_RESIDUAL_DESGN_DTRMN
DELETE I18
 from ICS_FLOW_ICIS.[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_RESIDUAL_DESGN_DTRMN] [I18]
 ON [I18].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
				
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_BASIC_PRMT/ICS_REP_NON_CMPL_STAT
DELETE I17
 from ICS_FLOW_ICIS.[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_REP_NON_CMPL_STAT] [I17]
 ON [I17].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
				
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_BASIC_PRMT/ICS_FAC/ICS_NAICS_CODE
DELETE I16
 from ICS_FLOW_ICIS.[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_FAC] [I6]
 ON [I6].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_NAICS_CODE] [I16]
 ON [I16].[ICS_FAC_ID] = [I6].[ICS_FAC_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
				
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_BASIC_PRMT/ICS_FAC/ICS_ADDR/ICS_TELEPH
DELETE I15
 from ICS_FLOW_ICIS.[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_FAC] [I6]
 ON [I6].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_ADDR] [I14]
 ON [I14].[ICS_FAC_ID] = [I6].[ICS_FAC_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_TELEPH] [I15]
 ON [I15].[ICS_ADDR_ID] = [I14].[ICS_ADDR_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
				
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_BASIC_PRMT/ICS_FAC/ICS_ADDR
DELETE I14
 from ICS_FLOW_ICIS.[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_FAC] [I6]
 ON [I6].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_ADDR] [I14]
 ON [I14].[ICS_FAC_ID] = [I6].[ICS_FAC_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
				
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_BASIC_PRMT/ICS_FAC/ICS_SIC_CODE
DELETE I13
 from ICS_FLOW_ICIS.[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_FAC] [I6]
 ON [I6].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_SIC_CODE] [I13]
 ON [I13].[ICS_FAC_ID] = [I6].[ICS_FAC_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
				
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_BASIC_PRMT/ICS_FAC/ICS_GEO_COORD
DELETE I12
 from ICS_FLOW_ICIS.[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_FAC] [I6]
 ON [I6].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_GEO_COORD] [I12]
 ON [I12].[ICS_FAC_ID] = [I6].[ICS_FAC_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
				
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_BASIC_PRMT/ICS_FAC/ICS_FAC_CLASS
DELETE I11
 from ICS_FLOW_ICIS.[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_FAC] [I6]
 ON [I6].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_FAC_CLASS] [I11]
 ON [I11].[ICS_FAC_ID] = [I6].[ICS_FAC_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
				
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_BASIC_PRMT/ICS_FAC/ICS_PLCY
DELETE I10
 from ICS_FLOW_ICIS.[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_FAC] [I6]
 ON [I6].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_PLCY] [I10]
 ON [I10].[ICS_FAC_ID] = [I6].[ICS_FAC_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
				
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_BASIC_PRMT/ICS_FAC/ICS_ORIG_PROGS
DELETE I9
 from ICS_FLOW_ICIS.[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_FAC] [I6]
 ON [I6].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_ORIG_PROGS] [I9]
 ON [I9].[ICS_FAC_ID] = [I6].[ICS_FAC_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
				
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_BASIC_PRMT/ICS_FAC/ICS_CONTACT/ICS_TELEPH
DELETE I8
 from ICS_FLOW_ICIS.[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_FAC] [I6]
 ON [I6].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_CONTACT] [I7]
 ON [I7].[ICS_FAC_ID] = [I6].[ICS_FAC_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_TELEPH] [I8]
 ON [I8].[ICS_CONTACT_ID] = [I7].[ICS_CONTACT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
				
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_BASIC_PRMT/ICS_FAC/ICS_CONTACT
DELETE I7
 from ICS_FLOW_ICIS.[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_FAC] [I6]
 ON [I6].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_CONTACT] [I7]
 ON [I7].[ICS_FAC_ID] = [I6].[ICS_FAC_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
				
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_BASIC_PRMT/ICS_FAC
DELETE I6
 from ICS_FLOW_ICIS.[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_FAC] [I6]
 ON [I6].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
				
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_BASIC_PRMT/ICS_EFFLU_GUIDE
DELETE I5
 from ICS_FLOW_ICIS.[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_EFFLU_GUIDE] [I5]
 ON [I5].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
				
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_BASIC_PRMT/ICS_OTHR_PRMTS
DELETE I4
 from ICS_FLOW_ICIS.[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_OTHR_PRMTS] [I4]
 ON [I4].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
				
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_BASIC_PRMT/ICS_NPDES_DAT_GRP_NUM
DELETE I3
 from ICS_FLOW_ICIS.[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_NPDES_DAT_GRP_NUM] [I3]
 ON [I3].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
				
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_BASIC_PRMT/ICS_CONTACT/ICS_TELEPH
DELETE I2
 from ICS_FLOW_ICIS.[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_CONTACT] [I1]
 ON [I1].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_TELEPH] [I2]
 ON [I2].[ICS_CONTACT_ID] = [I1].[ICS_CONTACT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
				
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_BASIC_PRMT/ICS_CONTACT
DELETE I1
 from ICS_FLOW_ICIS.[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_CONTACT] [I1]
 ON [I1].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
				
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_BASIC_PRMT
DELETE ICS_BASIC_PRMT
 from ICS_FLOW_ICIS.[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
				
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
					

				-- INSERTS for: ICS_BASIC_PRMT
	
				
-- /ICS_BASIC_PRMT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_BASIC_PRMT]
     SELECT ICS_BASIC_PRMT.*
        from [ICS_FLOW_LOCAL].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 
       WHERE ICS_BASIC_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission')
								  
	    AND ICS_BASIC_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_BASIC_PRMT/ICS_CONTACT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_CONTACT]
     SELECT I1.*
        from [ICS_FLOW_LOCAL].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTACT] [I1]
 ON [I1].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 
       WHERE ICS_BASIC_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission')
								  
	    AND ICS_BASIC_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_BASIC_PRMT/ICS_CONTACT/ICS_TELEPH 
INSERT INTO [ICS_FLOW_ICIS].[ICS_TELEPH]
     SELECT I2.*
        from [ICS_FLOW_LOCAL].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTACT] [I1]
 ON [I1].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_TELEPH] [I2]
 ON [I2].[ICS_CONTACT_ID] = [I1].[ICS_CONTACT_ID] 
 
       WHERE ICS_BASIC_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission')
								  
	    AND ICS_BASIC_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_BASIC_PRMT/ICS_NPDES_DAT_GRP_NUM 
INSERT INTO [ICS_FLOW_ICIS].[ICS_NPDES_DAT_GRP_NUM]
     SELECT I3.*
        from [ICS_FLOW_LOCAL].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_NPDES_DAT_GRP_NUM] [I3]
 ON [I3].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 
       WHERE ICS_BASIC_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission')
								  
	    AND ICS_BASIC_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_BASIC_PRMT/ICS_OTHR_PRMTS 
INSERT INTO [ICS_FLOW_ICIS].[ICS_OTHR_PRMTS]
     SELECT I4.*
        from [ICS_FLOW_LOCAL].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_OTHR_PRMTS] [I4]
 ON [I4].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 
       WHERE ICS_BASIC_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission')
								  
	    AND ICS_BASIC_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_BASIC_PRMT/ICS_EFFLU_GUIDE 
INSERT INTO [ICS_FLOW_ICIS].[ICS_EFFLU_GUIDE]
     SELECT I5.*
        from [ICS_FLOW_LOCAL].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_EFFLU_GUIDE] [I5]
 ON [I5].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 
       WHERE ICS_BASIC_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission')
								  
	    AND ICS_BASIC_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_BASIC_PRMT/ICS_FAC 
INSERT INTO [ICS_FLOW_ICIS].[ICS_FAC]
     SELECT I6.*
        from [ICS_FLOW_LOCAL].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_FAC] [I6]
 ON [I6].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 
       WHERE ICS_BASIC_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission')
								  
	    AND ICS_BASIC_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_BASIC_PRMT/ICS_FAC/ICS_CONTACT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_CONTACT]
     SELECT I7.*
        from [ICS_FLOW_LOCAL].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_FAC] [I6]
 ON [I6].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTACT] [I7]
 ON [I7].[ICS_FAC_ID] = [I6].[ICS_FAC_ID] 
 
       WHERE ICS_BASIC_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission')
								  
	    AND ICS_BASIC_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_BASIC_PRMT/ICS_FAC/ICS_CONTACT/ICS_TELEPH 
INSERT INTO [ICS_FLOW_ICIS].[ICS_TELEPH]
     SELECT I8.*
        from [ICS_FLOW_LOCAL].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_FAC] [I6]
 ON [I6].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTACT] [I7]
 ON [I7].[ICS_FAC_ID] = [I6].[ICS_FAC_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_TELEPH] [I8]
 ON [I8].[ICS_CONTACT_ID] = [I7].[ICS_CONTACT_ID] 
 
       WHERE ICS_BASIC_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission')
								  
	    AND ICS_BASIC_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_BASIC_PRMT/ICS_FAC/ICS_ORIG_PROGS 
INSERT INTO [ICS_FLOW_ICIS].[ICS_ORIG_PROGS]
     SELECT I9.*
        from [ICS_FLOW_LOCAL].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_FAC] [I6]
 ON [I6].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ORIG_PROGS] [I9]
 ON [I9].[ICS_FAC_ID] = [I6].[ICS_FAC_ID] 
 
       WHERE ICS_BASIC_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission')
								  
	    AND ICS_BASIC_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_BASIC_PRMT/ICS_FAC/ICS_PLCY 
INSERT INTO [ICS_FLOW_ICIS].[ICS_PLCY]
     SELECT I10.*
        from [ICS_FLOW_LOCAL].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_FAC] [I6]
 ON [I6].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PLCY] [I10]
 ON [I10].[ICS_FAC_ID] = [I6].[ICS_FAC_ID] 
 
       WHERE ICS_BASIC_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission')
								  
	    AND ICS_BASIC_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_BASIC_PRMT/ICS_FAC/ICS_FAC_CLASS 
INSERT INTO [ICS_FLOW_ICIS].[ICS_FAC_CLASS]
     SELECT I11.*
        from [ICS_FLOW_LOCAL].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_FAC] [I6]
 ON [I6].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_FAC_CLASS] [I11]
 ON [I11].[ICS_FAC_ID] = [I6].[ICS_FAC_ID] 
 
       WHERE ICS_BASIC_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission')
								  
	    AND ICS_BASIC_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_BASIC_PRMT/ICS_FAC/ICS_GEO_COORD 
INSERT INTO [ICS_FLOW_ICIS].[ICS_GEO_COORD]
     SELECT I12.*
        from [ICS_FLOW_LOCAL].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_FAC] [I6]
 ON [I6].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_GEO_COORD] [I12]
 ON [I12].[ICS_FAC_ID] = [I6].[ICS_FAC_ID] 
 
       WHERE ICS_BASIC_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission')
								  
	    AND ICS_BASIC_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_BASIC_PRMT/ICS_FAC/ICS_SIC_CODE 
INSERT INTO [ICS_FLOW_ICIS].[ICS_SIC_CODE]
     SELECT I13.*
        from [ICS_FLOW_LOCAL].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_FAC] [I6]
 ON [I6].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SIC_CODE] [I13]
 ON [I13].[ICS_FAC_ID] = [I6].[ICS_FAC_ID] 
 
       WHERE ICS_BASIC_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission')
								  
	    AND ICS_BASIC_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_BASIC_PRMT/ICS_FAC/ICS_ADDR 
INSERT INTO [ICS_FLOW_ICIS].[ICS_ADDR]
     SELECT I14.*
        from [ICS_FLOW_LOCAL].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_FAC] [I6]
 ON [I6].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ADDR] [I14]
 ON [I14].[ICS_FAC_ID] = [I6].[ICS_FAC_ID] 
 
       WHERE ICS_BASIC_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission')
								  
	    AND ICS_BASIC_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_BASIC_PRMT/ICS_FAC/ICS_ADDR/ICS_TELEPH 
INSERT INTO [ICS_FLOW_ICIS].[ICS_TELEPH]
     SELECT I15.*
        from [ICS_FLOW_LOCAL].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_FAC] [I6]
 ON [I6].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ADDR] [I14]
 ON [I14].[ICS_FAC_ID] = [I6].[ICS_FAC_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_TELEPH] [I15]
 ON [I15].[ICS_ADDR_ID] = [I14].[ICS_ADDR_ID] 
 
       WHERE ICS_BASIC_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission')
								  
	    AND ICS_BASIC_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_BASIC_PRMT/ICS_FAC/ICS_NAICS_CODE 
INSERT INTO [ICS_FLOW_ICIS].[ICS_NAICS_CODE]
     SELECT I16.*
        from [ICS_FLOW_LOCAL].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_FAC] [I6]
 ON [I6].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_NAICS_CODE] [I16]
 ON [I16].[ICS_FAC_ID] = [I6].[ICS_FAC_ID] 
 
       WHERE ICS_BASIC_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission')
								  
	    AND ICS_BASIC_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_BASIC_PRMT/ICS_REP_NON_CMPL_STAT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_REP_NON_CMPL_STAT]
     SELECT I17.*
        from [ICS_FLOW_LOCAL].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_REP_NON_CMPL_STAT] [I17]
 ON [I17].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 
       WHERE ICS_BASIC_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission')
								  
	    AND ICS_BASIC_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_BASIC_PRMT/ICS_RESIDUAL_DESGN_DTRMN 
INSERT INTO [ICS_FLOW_ICIS].[ICS_RESIDUAL_DESGN_DTRMN]
     SELECT I18.*
        from [ICS_FLOW_LOCAL].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_RESIDUAL_DESGN_DTRMN] [I18]
 ON [I18].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 
       WHERE ICS_BASIC_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission')
								  
	    AND ICS_BASIC_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_BASIC_PRMT/ICS_SIC_CODE 
INSERT INTO [ICS_FLOW_ICIS].[ICS_SIC_CODE]
     SELECT I19.*
        from [ICS_FLOW_LOCAL].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SIC_CODE] [I19]
 ON [I19].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 
       WHERE ICS_BASIC_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission')
								  
	    AND ICS_BASIC_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_BASIC_PRMT/ICS_SIU_DESGN_TYPE 
INSERT INTO [ICS_FLOW_ICIS].[ICS_SIU_DESGN_TYPE]
     SELECT I20.*
        from [ICS_FLOW_LOCAL].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SIU_DESGN_TYPE] [I20]
 ON [I20].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 
       WHERE ICS_BASIC_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission')
								  
	    AND ICS_BASIC_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_BASIC_PRMT/ICS_ADDR 
INSERT INTO [ICS_FLOW_ICIS].[ICS_ADDR]
     SELECT I21.*
        from [ICS_FLOW_LOCAL].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ADDR] [I21]
 ON [I21].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 
       WHERE ICS_BASIC_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission')
								  
	    AND ICS_BASIC_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_BASIC_PRMT/ICS_ADDR/ICS_TELEPH 
INSERT INTO [ICS_FLOW_ICIS].[ICS_TELEPH]
     SELECT I22.*
        from [ICS_FLOW_LOCAL].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ADDR] [I21]
 ON [I21].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_TELEPH] [I22]
 ON [I22].[ICS_ADDR_ID] = [I21].[ICS_ADDR_ID] 
 
       WHERE ICS_BASIC_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission')
								  
	    AND ICS_BASIC_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_BASIC_PRMT/ICS_ASSC_PRMT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_ASSC_PRMT]
     SELECT I23.*
        from [ICS_FLOW_LOCAL].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ASSC_PRMT] [I23]
 ON [I23].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 
       WHERE ICS_BASIC_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission')
								  
	    AND ICS_BASIC_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_BASIC_PRMT/ICS_CMPL_TRACK_STAT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_CMPL_TRACK_STAT]
     SELECT I24.*
        from [ICS_FLOW_LOCAL].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CMPL_TRACK_STAT] [I24]
 ON [I24].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 
       WHERE ICS_BASIC_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission')
								  
	    AND ICS_BASIC_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_BASIC_PRMT/ICS_NAICS_CODE 
INSERT INTO [ICS_FLOW_ICIS].[ICS_NAICS_CODE]
     SELECT I25.*
        from [ICS_FLOW_LOCAL].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_NAICS_CODE] [I25]
 ON [I25].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 
       WHERE ICS_BASIC_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission')
								  
	    AND ICS_BASIC_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

					
				
	

-- ================================================================
-- ICS_BS_ANNUL_PROG_REP 
-- ================================================================
			
				-- DELETES for: ICS_BS_ANNUL_PROG_REP 
				
								
-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICE/ICS_CMPL_MON_EVT/ICS_BS_SEWAGE_SLDG_PARAM
DELETE I17
 from ICS_FLOW_ICIS.[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN ICS_FLOW_ICIS.[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_CMPL_MON_EVT] [I16]
 ON [I16].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_BS_SEWAGE_SLDG_PARAM] [I17]
 ON [I17].[ICS_CMPL_MON_EVT_ID] = [I16].[ICS_CMPL_MON_EVT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_ANNUL_PROG_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission')
				
                  OR ICS_BS_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_BS_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICE/ICS_CMPL_MON_EVT
DELETE I16
 from ICS_FLOW_ICIS.[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN ICS_FLOW_ICIS.[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_CMPL_MON_EVT] [I16]
 ON [I16].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_ANNUL_PROG_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission')
				
                  OR ICS_BS_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_BS_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICE/ICS_VECTOR_A_REDUCTION_TYPE
DELETE I15
 from ICS_FLOW_ICIS.[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN ICS_FLOW_ICIS.[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_VECTOR_A_REDUCTION_TYPE] [I15]
 ON [I15].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_ANNUL_PROG_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission')
				
                  OR ICS_BS_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_BS_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICE/ICS_BS_SEWAGE_SLDG_PARAM
DELETE I14
 from ICS_FLOW_ICIS.[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN ICS_FLOW_ICIS.[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_BS_SEWAGE_SLDG_PARAM] [I14]
 ON [I14].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_ANNUL_PROG_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission')
				
                  OR ICS_BS_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_BS_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICE/ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR/ICS_CONTACT/ICS_TELEPH
DELETE I13
 from ICS_FLOW_ICIS.[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN ICS_FLOW_ICIS.[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] [I9]
 ON [I9].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_CONTACT] [I12]
 ON [I12].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] = [I9].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_TELEPH] [I13]
 ON [I13].[ICS_CONTACT_ID] = [I12].[ICS_CONTACT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_ANNUL_PROG_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission')
				
                  OR ICS_BS_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_BS_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICE/ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR/ICS_CONTACT
DELETE I12
 from ICS_FLOW_ICIS.[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN ICS_FLOW_ICIS.[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] [I9]
 ON [I9].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_CONTACT] [I12]
 ON [I12].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] = [I9].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_ANNUL_PROG_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission')
				
                  OR ICS_BS_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_BS_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICE/ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR/ICS_ADDR/ICS_TELEPH
DELETE I11
 from ICS_FLOW_ICIS.[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN ICS_FLOW_ICIS.[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] [I9]
 ON [I9].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_ADDR] [I10]
 ON [I10].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] = [I9].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_TELEPH] [I11]
 ON [I11].[ICS_ADDR_ID] = [I10].[ICS_ADDR_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_ANNUL_PROG_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission')
				
                  OR ICS_BS_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_BS_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICE/ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR/ICS_ADDR
DELETE I10
 from ICS_FLOW_ICIS.[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN ICS_FLOW_ICIS.[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] [I9]
 ON [I9].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_ADDR] [I10]
 ON [I10].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] = [I9].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_ANNUL_PROG_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission')
				
                  OR ICS_BS_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_BS_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICE/ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR
DELETE I9
 from ICS_FLOW_ICIS.[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN ICS_FLOW_ICIS.[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] [I9]
 ON [I9].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_ANNUL_PROG_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission')
				
                  OR ICS_BS_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_BS_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICE/ICS_BS_INCINERATION/ICS_BS_SEWAGE_SLDG_PARAM
DELETE I8
 from ICS_FLOW_ICIS.[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN ICS_FLOW_ICIS.[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_BS_INCINERATION] [I6]
 ON [I6].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_BS_SEWAGE_SLDG_PARAM] [I8]
 ON [I8].[ICS_BS_INCINERATION_ID] = [I6].[ICS_BS_INCINERATION_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_ANNUL_PROG_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission')
				
                  OR ICS_BS_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_BS_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICE/ICS_BS_INCINERATION/ICS_BS_INCIN_EMISSIONS_CONTROL_TYPE
DELETE I7
 from ICS_FLOW_ICIS.[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN ICS_FLOW_ICIS.[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_BS_INCINERATION] [I6]
 ON [I6].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_BS_INCIN_EMISSIONS_CONTROL_TYPE] [I7]
 ON [I7].[ICS_BS_INCINERATION_ID] = [I6].[ICS_BS_INCINERATION_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_ANNUL_PROG_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission')
				
                  OR ICS_BS_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_BS_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICE/ICS_BS_INCINERATION
DELETE I6
 from ICS_FLOW_ICIS.[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN ICS_FLOW_ICIS.[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_BS_INCINERATION] [I6]
 ON [I6].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_ANNUL_PROG_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission')
				
                  OR ICS_BS_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_BS_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICE/ICS_PATHOGEN_REDUCTION_TYPE
DELETE I5
 from ICS_FLOW_ICIS.[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN ICS_FLOW_ICIS.[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_PATHOGEN_REDUCTION_TYPE] [I5]
 ON [I5].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_ANNUL_PROG_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission')
				
                  OR ICS_BS_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_BS_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICE
DELETE I4
 from ICS_FLOW_ICIS.[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN ICS_FLOW_ICIS.[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_ANNUL_PROG_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission')
				
                  OR ICS_BS_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_BS_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_FAC_TYPE
DELETE I3
 from ICS_FLOW_ICIS.[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN ICS_FLOW_ICIS.[ICS_BS_FAC_TYPE] [I3]
 ON [I3].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_ANNUL_PROG_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission')
				
                  OR ICS_BS_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_BS_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_FAC_TRTMNT
DELETE I2
 from ICS_FLOW_ICIS.[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN ICS_FLOW_ICIS.[ICS_BS_FAC_TRTMNT] [I2]
 ON [I2].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_ANNUL_PROG_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission')
				
                  OR ICS_BS_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_BS_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_BS_ANNUL_PROG_REP/ICS_ANLYTCL_METHOD
DELETE I1
 from ICS_FLOW_ICIS.[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN ICS_FLOW_ICIS.[ICS_ANLYTCL_METHOD] [I1]
 ON [I1].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_ANNUL_PROG_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission')
				
                  OR ICS_BS_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_BS_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_BS_ANNUL_PROG_REP
DELETE ICS_BS_ANNUL_PROG_REP
 from ICS_FLOW_ICIS.[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_ANNUL_PROG_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission')
				
                  OR ICS_BS_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_BS_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
					

				-- INSERTS for: ICS_BS_ANNUL_PROG_REP
	
				
-- /ICS_BS_ANNUL_PROG_REP 
INSERT INTO [ICS_FLOW_ICIS].[ICS_BS_ANNUL_PROG_REP]
     SELECT ICS_BS_ANNUL_PROG_REP.*
        from [ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 
       WHERE ICS_BS_ANNUL_PROG_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission')
								  
	    AND ICS_BS_ANNUL_PROG_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_BS_ANNUL_PROG_REP/ICS_ANLYTCL_METHOD 
INSERT INTO [ICS_FLOW_ICIS].[ICS_ANLYTCL_METHOD]
     SELECT I1.*
        from [ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ANLYTCL_METHOD] [I1]
 ON [I1].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 
       WHERE ICS_BS_ANNUL_PROG_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission')
								  
	    AND ICS_BS_ANNUL_PROG_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_FAC_TRTMNT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_BS_FAC_TRTMNT]
     SELECT I2.*
        from [ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_FAC_TRTMNT] [I2]
 ON [I2].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 
       WHERE ICS_BS_ANNUL_PROG_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission')
								  
	    AND ICS_BS_ANNUL_PROG_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_FAC_TYPE 
INSERT INTO [ICS_FLOW_ICIS].[ICS_BS_FAC_TYPE]
     SELECT I3.*
        from [ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_FAC_TYPE] [I3]
 ON [I3].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 
       WHERE ICS_BS_ANNUL_PROG_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission')
								  
	    AND ICS_BS_ANNUL_PROG_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICE 
INSERT INTO [ICS_FLOW_ICIS].[ICS_BS_MGMT_PRACTICE]
     SELECT I4.*
        from [ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 
       WHERE ICS_BS_ANNUL_PROG_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission')
								  
	    AND ICS_BS_ANNUL_PROG_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICE/ICS_PATHOGEN_REDUCTION_TYPE 
INSERT INTO [ICS_FLOW_ICIS].[ICS_PATHOGEN_REDUCTION_TYPE]
     SELECT I5.*
        from [ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PATHOGEN_REDUCTION_TYPE] [I5]
 ON [I5].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
 
       WHERE ICS_BS_ANNUL_PROG_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission')
								  
	    AND ICS_BS_ANNUL_PROG_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICE/ICS_BS_INCINERATION 
INSERT INTO [ICS_FLOW_ICIS].[ICS_BS_INCINERATION]
     SELECT I6.*
        from [ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_INCINERATION] [I6]
 ON [I6].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
 
       WHERE ICS_BS_ANNUL_PROG_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission')
								  
	    AND ICS_BS_ANNUL_PROG_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICE/ICS_BS_INCINERATION/ICS_BS_INCIN_EMISSIONS_CONTROL_TYPE 
INSERT INTO [ICS_FLOW_ICIS].[ICS_BS_INCIN_EMISSIONS_CONTROL_TYPE]
     SELECT I7.*
        from [ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_INCINERATION] [I6]
 ON [I6].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_INCIN_EMISSIONS_CONTROL_TYPE] [I7]
 ON [I7].[ICS_BS_INCINERATION_ID] = [I6].[ICS_BS_INCINERATION_ID] 
 
       WHERE ICS_BS_ANNUL_PROG_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission')
								  
	    AND ICS_BS_ANNUL_PROG_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICE/ICS_BS_INCINERATION/ICS_BS_SEWAGE_SLDG_PARAM 
INSERT INTO [ICS_FLOW_ICIS].[ICS_BS_SEWAGE_SLDG_PARAM]
     SELECT I8.*
        from [ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_INCINERATION] [I6]
 ON [I6].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_SEWAGE_SLDG_PARAM] [I8]
 ON [I8].[ICS_BS_INCINERATION_ID] = [I6].[ICS_BS_INCINERATION_ID] 
 
       WHERE ICS_BS_ANNUL_PROG_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission')
								  
	    AND ICS_BS_ANNUL_PROG_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICE/ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR 
INSERT INTO [ICS_FLOW_ICIS].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR]
     SELECT I9.*
        from [ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] [I9]
 ON [I9].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
 
       WHERE ICS_BS_ANNUL_PROG_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission')
								  
	    AND ICS_BS_ANNUL_PROG_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICE/ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR/ICS_ADDR 
INSERT INTO [ICS_FLOW_ICIS].[ICS_ADDR]
     SELECT I10.*
        from [ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] [I9]
 ON [I9].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ADDR] [I10]
 ON [I10].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] = [I9].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] 
 
       WHERE ICS_BS_ANNUL_PROG_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission')
								  
	    AND ICS_BS_ANNUL_PROG_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICE/ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR/ICS_ADDR/ICS_TELEPH 
INSERT INTO [ICS_FLOW_ICIS].[ICS_TELEPH]
     SELECT I11.*
        from [ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] [I9]
 ON [I9].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ADDR] [I10]
 ON [I10].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] = [I9].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_TELEPH] [I11]
 ON [I11].[ICS_ADDR_ID] = [I10].[ICS_ADDR_ID] 
 
       WHERE ICS_BS_ANNUL_PROG_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission')
								  
	    AND ICS_BS_ANNUL_PROG_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICE/ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR/ICS_CONTACT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_CONTACT]
     SELECT I12.*
        from [ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] [I9]
 ON [I9].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTACT] [I12]
 ON [I12].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] = [I9].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] 
 
       WHERE ICS_BS_ANNUL_PROG_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission')
								  
	    AND ICS_BS_ANNUL_PROG_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICE/ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR/ICS_CONTACT/ICS_TELEPH 
INSERT INTO [ICS_FLOW_ICIS].[ICS_TELEPH]
     SELECT I13.*
        from [ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] [I9]
 ON [I9].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTACT] [I12]
 ON [I12].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] = [I9].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_TELEPH] [I13]
 ON [I13].[ICS_CONTACT_ID] = [I12].[ICS_CONTACT_ID] 
 
       WHERE ICS_BS_ANNUL_PROG_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission')
								  
	    AND ICS_BS_ANNUL_PROG_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICE/ICS_BS_SEWAGE_SLDG_PARAM 
INSERT INTO [ICS_FLOW_ICIS].[ICS_BS_SEWAGE_SLDG_PARAM]
     SELECT I14.*
        from [ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_SEWAGE_SLDG_PARAM] [I14]
 ON [I14].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
 
       WHERE ICS_BS_ANNUL_PROG_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission')
								  
	    AND ICS_BS_ANNUL_PROG_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICE/ICS_VECTOR_A_REDUCTION_TYPE 
INSERT INTO [ICS_FLOW_ICIS].[ICS_VECTOR_A_REDUCTION_TYPE]
     SELECT I15.*
        from [ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_VECTOR_A_REDUCTION_TYPE] [I15]
 ON [I15].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
 
       WHERE ICS_BS_ANNUL_PROG_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission')
								  
	    AND ICS_BS_ANNUL_PROG_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICE/ICS_CMPL_MON_EVT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_CMPL_MON_EVT]
     SELECT I16.*
        from [ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CMPL_MON_EVT] [I16]
 ON [I16].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
 
       WHERE ICS_BS_ANNUL_PROG_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission')
								  
	    AND ICS_BS_ANNUL_PROG_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICE/ICS_CMPL_MON_EVT/ICS_BS_SEWAGE_SLDG_PARAM 
INSERT INTO [ICS_FLOW_ICIS].[ICS_BS_SEWAGE_SLDG_PARAM]
     SELECT I17.*
        from [ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CMPL_MON_EVT] [I16]
 ON [I16].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_SEWAGE_SLDG_PARAM] [I17]
 ON [I17].[ICS_CMPL_MON_EVT_ID] = [I16].[ICS_CMPL_MON_EVT_ID] 
 
       WHERE ICS_BS_ANNUL_PROG_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission')
								  
	    AND ICS_BS_ANNUL_PROG_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

					
				
	

-- ================================================================
-- ICS_BS_PRMT 
-- ================================================================
			
				-- DELETES for: ICS_BS_PRMT 
				
								
-- /ICS_BS_PRMT/ICS_BS_FAC_TYPE
DELETE I10
 from ICS_FLOW_ICIS.[ICS_BS_PRMT] [ICS_BS_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_BS_FAC_TYPE] [I10]
 ON [I10].[ICS_BS_PRMT_ID] = [ICS_BS_PRMT].[ICS_BS_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BiosolidsPermitSubmission')
				
                  OR ICS_BS_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_BS_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_BS_PRMT/ICS_BS_FAC_TRTMNT
DELETE I9
 from ICS_FLOW_ICIS.[ICS_BS_PRMT] [ICS_BS_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_BS_FAC_TRTMNT] [I9]
 ON [I9].[ICS_BS_PRMT_ID] = [ICS_BS_PRMT].[ICS_BS_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BiosolidsPermitSubmission')
				
                  OR ICS_BS_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_BS_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_BS_PRMT/ICS_PRMT_BS_MGMT_PRACTICE/ICS_VECTOR_A_REDUCTION_TYPE
DELETE I8
 from ICS_FLOW_ICIS.[ICS_BS_PRMT] [ICS_BS_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_PRMT_BS_MGMT_PRACTICE] [I1]
 ON [I1].[ICS_BS_PRMT_ID] = [ICS_BS_PRMT].[ICS_BS_PRMT_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_VECTOR_A_REDUCTION_TYPE] [I8]
 ON [I8].[ICS_PRMT_BS_MGMT_PRACTICE_ID] = [I1].[ICS_PRMT_BS_MGMT_PRACTICE_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BiosolidsPermitSubmission')
				
                  OR ICS_BS_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_BS_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_BS_PRMT/ICS_PRMT_BS_MGMT_PRACTICE/ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR/ICS_CONTACT/ICS_TELEPH
DELETE I7
 from ICS_FLOW_ICIS.[ICS_BS_PRMT] [ICS_BS_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_PRMT_BS_MGMT_PRACTICE] [I1]
 ON [I1].[ICS_BS_PRMT_ID] = [ICS_BS_PRMT].[ICS_BS_PRMT_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] [I3]
 ON [I3].[ICS_PRMT_BS_MGMT_PRACTICE_ID] = [I1].[ICS_PRMT_BS_MGMT_PRACTICE_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_CONTACT] [I6]
 ON [I6].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] = [I3].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_TELEPH] [I7]
 ON [I7].[ICS_CONTACT_ID] = [I6].[ICS_CONTACT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BiosolidsPermitSubmission')
				
                  OR ICS_BS_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_BS_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_BS_PRMT/ICS_PRMT_BS_MGMT_PRACTICE/ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR/ICS_CONTACT
DELETE I6
 from ICS_FLOW_ICIS.[ICS_BS_PRMT] [ICS_BS_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_PRMT_BS_MGMT_PRACTICE] [I1]
 ON [I1].[ICS_BS_PRMT_ID] = [ICS_BS_PRMT].[ICS_BS_PRMT_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] [I3]
 ON [I3].[ICS_PRMT_BS_MGMT_PRACTICE_ID] = [I1].[ICS_PRMT_BS_MGMT_PRACTICE_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_CONTACT] [I6]
 ON [I6].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] = [I3].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BiosolidsPermitSubmission')
				
                  OR ICS_BS_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_BS_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_BS_PRMT/ICS_PRMT_BS_MGMT_PRACTICE/ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR/ICS_ADDR/ICS_TELEPH
DELETE I5
 from ICS_FLOW_ICIS.[ICS_BS_PRMT] [ICS_BS_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_PRMT_BS_MGMT_PRACTICE] [I1]
 ON [I1].[ICS_BS_PRMT_ID] = [ICS_BS_PRMT].[ICS_BS_PRMT_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] [I3]
 ON [I3].[ICS_PRMT_BS_MGMT_PRACTICE_ID] = [I1].[ICS_PRMT_BS_MGMT_PRACTICE_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_ADDR] [I4]
 ON [I4].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] = [I3].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_TELEPH] [I5]
 ON [I5].[ICS_ADDR_ID] = [I4].[ICS_ADDR_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BiosolidsPermitSubmission')
				
                  OR ICS_BS_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_BS_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_BS_PRMT/ICS_PRMT_BS_MGMT_PRACTICE/ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR/ICS_ADDR
DELETE I4
 from ICS_FLOW_ICIS.[ICS_BS_PRMT] [ICS_BS_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_PRMT_BS_MGMT_PRACTICE] [I1]
 ON [I1].[ICS_BS_PRMT_ID] = [ICS_BS_PRMT].[ICS_BS_PRMT_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] [I3]
 ON [I3].[ICS_PRMT_BS_MGMT_PRACTICE_ID] = [I1].[ICS_PRMT_BS_MGMT_PRACTICE_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_ADDR] [I4]
 ON [I4].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] = [I3].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BiosolidsPermitSubmission')
				
                  OR ICS_BS_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_BS_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_BS_PRMT/ICS_PRMT_BS_MGMT_PRACTICE/ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR
DELETE I3
 from ICS_FLOW_ICIS.[ICS_BS_PRMT] [ICS_BS_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_PRMT_BS_MGMT_PRACTICE] [I1]
 ON [I1].[ICS_BS_PRMT_ID] = [ICS_BS_PRMT].[ICS_BS_PRMT_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] [I3]
 ON [I3].[ICS_PRMT_BS_MGMT_PRACTICE_ID] = [I1].[ICS_PRMT_BS_MGMT_PRACTICE_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BiosolidsPermitSubmission')
				
                  OR ICS_BS_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_BS_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_BS_PRMT/ICS_PRMT_BS_MGMT_PRACTICE/ICS_PATHOGEN_REDUCTION_TYPE
DELETE I2
 from ICS_FLOW_ICIS.[ICS_BS_PRMT] [ICS_BS_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_PRMT_BS_MGMT_PRACTICE] [I1]
 ON [I1].[ICS_BS_PRMT_ID] = [ICS_BS_PRMT].[ICS_BS_PRMT_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_PATHOGEN_REDUCTION_TYPE] [I2]
 ON [I2].[ICS_PRMT_BS_MGMT_PRACTICE_ID] = [I1].[ICS_PRMT_BS_MGMT_PRACTICE_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BiosolidsPermitSubmission')
				
                  OR ICS_BS_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_BS_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_BS_PRMT/ICS_PRMT_BS_MGMT_PRACTICE
DELETE I1
 from ICS_FLOW_ICIS.[ICS_BS_PRMT] [ICS_BS_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_PRMT_BS_MGMT_PRACTICE] [I1]
 ON [I1].[ICS_BS_PRMT_ID] = [ICS_BS_PRMT].[ICS_BS_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BiosolidsPermitSubmission')
				
                  OR ICS_BS_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_BS_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_BS_PRMT
DELETE ICS_BS_PRMT
 from ICS_FLOW_ICIS.[ICS_BS_PRMT] [ICS_BS_PRMT] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BiosolidsPermitSubmission')
				
                  OR ICS_BS_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_BS_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
					

				-- INSERTS for: ICS_BS_PRMT
	
				
-- /ICS_BS_PRMT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_BS_PRMT]
     SELECT ICS_BS_PRMT.*
        from [ICS_FLOW_LOCAL].[ICS_BS_PRMT] [ICS_BS_PRMT] 
 
       WHERE ICS_BS_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsPermitSubmission')
								  
	    AND ICS_BS_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_BS_PRMT/ICS_PRMT_BS_MGMT_PRACTICE 
INSERT INTO [ICS_FLOW_ICIS].[ICS_PRMT_BS_MGMT_PRACTICE]
     SELECT I1.*
        from [ICS_FLOW_LOCAL].[ICS_BS_PRMT] [ICS_BS_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PRMT_BS_MGMT_PRACTICE] [I1]
 ON [I1].[ICS_BS_PRMT_ID] = [ICS_BS_PRMT].[ICS_BS_PRMT_ID] 
 
       WHERE ICS_BS_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsPermitSubmission')
								  
	    AND ICS_BS_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_BS_PRMT/ICS_PRMT_BS_MGMT_PRACTICE/ICS_PATHOGEN_REDUCTION_TYPE 
INSERT INTO [ICS_FLOW_ICIS].[ICS_PATHOGEN_REDUCTION_TYPE]
     SELECT I2.*
        from [ICS_FLOW_LOCAL].[ICS_BS_PRMT] [ICS_BS_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PRMT_BS_MGMT_PRACTICE] [I1]
 ON [I1].[ICS_BS_PRMT_ID] = [ICS_BS_PRMT].[ICS_BS_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PATHOGEN_REDUCTION_TYPE] [I2]
 ON [I2].[ICS_PRMT_BS_MGMT_PRACTICE_ID] = [I1].[ICS_PRMT_BS_MGMT_PRACTICE_ID] 
 
       WHERE ICS_BS_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsPermitSubmission')
								  
	    AND ICS_BS_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_BS_PRMT/ICS_PRMT_BS_MGMT_PRACTICE/ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR 
INSERT INTO [ICS_FLOW_ICIS].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR]
     SELECT I3.*
        from [ICS_FLOW_LOCAL].[ICS_BS_PRMT] [ICS_BS_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PRMT_BS_MGMT_PRACTICE] [I1]
 ON [I1].[ICS_BS_PRMT_ID] = [ICS_BS_PRMT].[ICS_BS_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] [I3]
 ON [I3].[ICS_PRMT_BS_MGMT_PRACTICE_ID] = [I1].[ICS_PRMT_BS_MGMT_PRACTICE_ID] 
 
       WHERE ICS_BS_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsPermitSubmission')
								  
	    AND ICS_BS_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_BS_PRMT/ICS_PRMT_BS_MGMT_PRACTICE/ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR/ICS_ADDR 
INSERT INTO [ICS_FLOW_ICIS].[ICS_ADDR]
     SELECT I4.*
        from [ICS_FLOW_LOCAL].[ICS_BS_PRMT] [ICS_BS_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PRMT_BS_MGMT_PRACTICE] [I1]
 ON [I1].[ICS_BS_PRMT_ID] = [ICS_BS_PRMT].[ICS_BS_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] [I3]
 ON [I3].[ICS_PRMT_BS_MGMT_PRACTICE_ID] = [I1].[ICS_PRMT_BS_MGMT_PRACTICE_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ADDR] [I4]
 ON [I4].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] = [I3].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] 
 
       WHERE ICS_BS_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsPermitSubmission')
								  
	    AND ICS_BS_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_BS_PRMT/ICS_PRMT_BS_MGMT_PRACTICE/ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR/ICS_ADDR/ICS_TELEPH 
INSERT INTO [ICS_FLOW_ICIS].[ICS_TELEPH]
     SELECT I5.*
        from [ICS_FLOW_LOCAL].[ICS_BS_PRMT] [ICS_BS_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PRMT_BS_MGMT_PRACTICE] [I1]
 ON [I1].[ICS_BS_PRMT_ID] = [ICS_BS_PRMT].[ICS_BS_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] [I3]
 ON [I3].[ICS_PRMT_BS_MGMT_PRACTICE_ID] = [I1].[ICS_PRMT_BS_MGMT_PRACTICE_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ADDR] [I4]
 ON [I4].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] = [I3].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_TELEPH] [I5]
 ON [I5].[ICS_ADDR_ID] = [I4].[ICS_ADDR_ID] 
 
       WHERE ICS_BS_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsPermitSubmission')
								  
	    AND ICS_BS_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_BS_PRMT/ICS_PRMT_BS_MGMT_PRACTICE/ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR/ICS_CONTACT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_CONTACT]
     SELECT I6.*
        from [ICS_FLOW_LOCAL].[ICS_BS_PRMT] [ICS_BS_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PRMT_BS_MGMT_PRACTICE] [I1]
 ON [I1].[ICS_BS_PRMT_ID] = [ICS_BS_PRMT].[ICS_BS_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] [I3]
 ON [I3].[ICS_PRMT_BS_MGMT_PRACTICE_ID] = [I1].[ICS_PRMT_BS_MGMT_PRACTICE_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTACT] [I6]
 ON [I6].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] = [I3].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] 
 
       WHERE ICS_BS_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsPermitSubmission')
								  
	    AND ICS_BS_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_BS_PRMT/ICS_PRMT_BS_MGMT_PRACTICE/ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR/ICS_CONTACT/ICS_TELEPH 
INSERT INTO [ICS_FLOW_ICIS].[ICS_TELEPH]
     SELECT I7.*
        from [ICS_FLOW_LOCAL].[ICS_BS_PRMT] [ICS_BS_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PRMT_BS_MGMT_PRACTICE] [I1]
 ON [I1].[ICS_BS_PRMT_ID] = [ICS_BS_PRMT].[ICS_BS_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] [I3]
 ON [I3].[ICS_PRMT_BS_MGMT_PRACTICE_ID] = [I1].[ICS_PRMT_BS_MGMT_PRACTICE_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTACT] [I6]
 ON [I6].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] = [I3].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_TELEPH] [I7]
 ON [I7].[ICS_CONTACT_ID] = [I6].[ICS_CONTACT_ID] 
 
       WHERE ICS_BS_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsPermitSubmission')
								  
	    AND ICS_BS_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_BS_PRMT/ICS_PRMT_BS_MGMT_PRACTICE/ICS_VECTOR_A_REDUCTION_TYPE 
INSERT INTO [ICS_FLOW_ICIS].[ICS_VECTOR_A_REDUCTION_TYPE]
     SELECT I8.*
        from [ICS_FLOW_LOCAL].[ICS_BS_PRMT] [ICS_BS_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PRMT_BS_MGMT_PRACTICE] [I1]
 ON [I1].[ICS_BS_PRMT_ID] = [ICS_BS_PRMT].[ICS_BS_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_VECTOR_A_REDUCTION_TYPE] [I8]
 ON [I8].[ICS_PRMT_BS_MGMT_PRACTICE_ID] = [I1].[ICS_PRMT_BS_MGMT_PRACTICE_ID] 
 
       WHERE ICS_BS_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsPermitSubmission')
								  
	    AND ICS_BS_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_BS_PRMT/ICS_BS_FAC_TRTMNT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_BS_FAC_TRTMNT]
     SELECT I9.*
        from [ICS_FLOW_LOCAL].[ICS_BS_PRMT] [ICS_BS_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_FAC_TRTMNT] [I9]
 ON [I9].[ICS_BS_PRMT_ID] = [ICS_BS_PRMT].[ICS_BS_PRMT_ID] 
 
       WHERE ICS_BS_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsPermitSubmission')
								  
	    AND ICS_BS_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_BS_PRMT/ICS_BS_FAC_TYPE 
INSERT INTO [ICS_FLOW_ICIS].[ICS_BS_FAC_TYPE]
     SELECT I10.*
        from [ICS_FLOW_LOCAL].[ICS_BS_PRMT] [ICS_BS_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_FAC_TYPE] [I10]
 ON [I10].[ICS_BS_PRMT_ID] = [ICS_BS_PRMT].[ICS_BS_PRMT_ID] 
 
       WHERE ICS_BS_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsPermitSubmission')
								  
	    AND ICS_BS_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

					
				
	

-- ================================================================
-- ICS_CAFO_ANNUL_PROG_REP 
-- ================================================================
			
				-- DELETES for: ICS_CAFO_ANNUL_PROG_REP 
				
								
-- /ICS_CAFO_ANNUL_PROG_REP/ICS_CAFOMLPW_TTL_AMOUNTS
DELETE I6
 from ICS_FLOW_ICIS.[ICS_CAFO_ANNUL_PROG_REP] [ICS_CAFO_ANNUL_PROG_REP] 
 JOIN ICS_FLOW_ICIS.[ICS_CAFOMLPW_TTL_AMOUNTS] [I6]
 ON [I6].[ICS_CAFO_ANNUL_PROG_REP_ID] = [ICS_CAFO_ANNUL_PROG_REP].[ICS_CAFO_ANNUL_PROG_REP_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CAFO_ANNUL_PROG_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CAFOAnnualProgramReportSubmission')
				
                  OR ICS_CAFO_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_CAFO_ANNUL_PROG_REP/ICS_CAFOMLPW_NUTR_MON
DELETE I5
 from ICS_FLOW_ICIS.[ICS_CAFO_ANNUL_PROG_REP] [ICS_CAFO_ANNUL_PROG_REP] 
 JOIN ICS_FLOW_ICIS.[ICS_CAFOMLPW_NUTR_MON] [I5]
 ON [I5].[ICS_CAFO_ANNUL_PROG_REP_ID] = [ICS_CAFO_ANNUL_PROG_REP].[ICS_CAFO_ANNUL_PROG_REP_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CAFO_ANNUL_PROG_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CAFOAnnualProgramReportSubmission')
				
                  OR ICS_CAFO_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_CAFO_ANNUL_PROG_REP/ICS_CAFO_PROD_AREA_DSCH
DELETE I4
 from ICS_FLOW_ICIS.[ICS_CAFO_ANNUL_PROG_REP] [ICS_CAFO_ANNUL_PROG_REP] 
 JOIN ICS_FLOW_ICIS.[ICS_CAFO_PROD_AREA_DSCH] [I4]
 ON [I4].[ICS_CAFO_ANNUL_PROG_REP_ID] = [ICS_CAFO_ANNUL_PROG_REP].[ICS_CAFO_ANNUL_PROG_REP_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CAFO_ANNUL_PROG_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CAFOAnnualProgramReportSubmission')
				
                  OR ICS_CAFO_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_CAFO_ANNUL_PROG_REP/ICS_CAFO_LAND_APPL_FLD_INFO/ICS_CAFOMLPW_FLD_AMOUNTS
DELETE I3
 from ICS_FLOW_ICIS.[ICS_CAFO_ANNUL_PROG_REP] [ICS_CAFO_ANNUL_PROG_REP] 
 JOIN ICS_FLOW_ICIS.[ICS_CAFO_LAND_APPL_FLD_INFO] [I2]
 ON [I2].[ICS_CAFO_ANNUL_PROG_REP_ID] = [ICS_CAFO_ANNUL_PROG_REP].[ICS_CAFO_ANNUL_PROG_REP_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_CAFOMLPW_FLD_AMOUNTS] [I3]
 ON [I3].[ICS_CAFO_LAND_APPL_FLD_INFO_ID] = [I2].[ICS_CAFO_LAND_APPL_FLD_INFO_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CAFO_ANNUL_PROG_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CAFOAnnualProgramReportSubmission')
				
                  OR ICS_CAFO_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_CAFO_ANNUL_PROG_REP/ICS_CAFO_LAND_APPL_FLD_INFO
DELETE I2
 from ICS_FLOW_ICIS.[ICS_CAFO_ANNUL_PROG_REP] [ICS_CAFO_ANNUL_PROG_REP] 
 JOIN ICS_FLOW_ICIS.[ICS_CAFO_LAND_APPL_FLD_INFO] [I2]
 ON [I2].[ICS_CAFO_ANNUL_PROG_REP_ID] = [ICS_CAFO_ANNUL_PROG_REP].[ICS_CAFO_ANNUL_PROG_REP_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CAFO_ANNUL_PROG_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CAFOAnnualProgramReportSubmission')
				
                  OR ICS_CAFO_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_CAFO_ANNUL_PROG_REP/ICS_ANML_TYPE
DELETE I1
 from ICS_FLOW_ICIS.[ICS_CAFO_ANNUL_PROG_REP] [ICS_CAFO_ANNUL_PROG_REP] 
 JOIN ICS_FLOW_ICIS.[ICS_ANML_TYPE] [I1]
 ON [I1].[ICS_CAFO_ANNUL_PROG_REP_ID] = [ICS_CAFO_ANNUL_PROG_REP].[ICS_CAFO_ANNUL_PROG_REP_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CAFO_ANNUL_PROG_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CAFOAnnualProgramReportSubmission')
				
                  OR ICS_CAFO_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_CAFO_ANNUL_PROG_REP
DELETE ICS_CAFO_ANNUL_PROG_REP
 from ICS_FLOW_ICIS.[ICS_CAFO_ANNUL_PROG_REP] [ICS_CAFO_ANNUL_PROG_REP] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CAFO_ANNUL_PROG_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CAFOAnnualProgramReportSubmission')
				
                  OR ICS_CAFO_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
					

				-- INSERTS for: ICS_CAFO_ANNUL_PROG_REP
	
				
-- /ICS_CAFO_ANNUL_PROG_REP 
INSERT INTO [ICS_FLOW_ICIS].[ICS_CAFO_ANNUL_PROG_REP]
     SELECT ICS_CAFO_ANNUL_PROG_REP.*
        from [ICS_FLOW_LOCAL].[ICS_CAFO_ANNUL_PROG_REP] [ICS_CAFO_ANNUL_PROG_REP] 
 
       WHERE ICS_CAFO_ANNUL_PROG_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CAFOAnnualProgramReportSubmission')
								  
	    AND ICS_CAFO_ANNUL_PROG_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_CAFO_ANNUL_PROG_REP/ICS_ANML_TYPE 
INSERT INTO [ICS_FLOW_ICIS].[ICS_ANML_TYPE]
     SELECT I1.*
        from [ICS_FLOW_LOCAL].[ICS_CAFO_ANNUL_PROG_REP] [ICS_CAFO_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ANML_TYPE] [I1]
 ON [I1].[ICS_CAFO_ANNUL_PROG_REP_ID] = [ICS_CAFO_ANNUL_PROG_REP].[ICS_CAFO_ANNUL_PROG_REP_ID] 
 
       WHERE ICS_CAFO_ANNUL_PROG_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CAFOAnnualProgramReportSubmission')
								  
	    AND ICS_CAFO_ANNUL_PROG_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_CAFO_ANNUL_PROG_REP/ICS_CAFO_LAND_APPL_FLD_INFO 
INSERT INTO [ICS_FLOW_ICIS].[ICS_CAFO_LAND_APPL_FLD_INFO]
     SELECT I2.*
        from [ICS_FLOW_LOCAL].[ICS_CAFO_ANNUL_PROG_REP] [ICS_CAFO_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CAFO_LAND_APPL_FLD_INFO] [I2]
 ON [I2].[ICS_CAFO_ANNUL_PROG_REP_ID] = [ICS_CAFO_ANNUL_PROG_REP].[ICS_CAFO_ANNUL_PROG_REP_ID] 
 
       WHERE ICS_CAFO_ANNUL_PROG_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CAFOAnnualProgramReportSubmission')
								  
	    AND ICS_CAFO_ANNUL_PROG_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_CAFO_ANNUL_PROG_REP/ICS_CAFO_LAND_APPL_FLD_INFO/ICS_CAFOMLPW_FLD_AMOUNTS 
INSERT INTO [ICS_FLOW_ICIS].[ICS_CAFOMLPW_FLD_AMOUNTS]
     SELECT I3.*
        from [ICS_FLOW_LOCAL].[ICS_CAFO_ANNUL_PROG_REP] [ICS_CAFO_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CAFO_LAND_APPL_FLD_INFO] [I2]
 ON [I2].[ICS_CAFO_ANNUL_PROG_REP_ID] = [ICS_CAFO_ANNUL_PROG_REP].[ICS_CAFO_ANNUL_PROG_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CAFOMLPW_FLD_AMOUNTS] [I3]
 ON [I3].[ICS_CAFO_LAND_APPL_FLD_INFO_ID] = [I2].[ICS_CAFO_LAND_APPL_FLD_INFO_ID] 
 
       WHERE ICS_CAFO_ANNUL_PROG_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CAFOAnnualProgramReportSubmission')
								  
	    AND ICS_CAFO_ANNUL_PROG_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_CAFO_ANNUL_PROG_REP/ICS_CAFO_PROD_AREA_DSCH 
INSERT INTO [ICS_FLOW_ICIS].[ICS_CAFO_PROD_AREA_DSCH]
     SELECT I4.*
        from [ICS_FLOW_LOCAL].[ICS_CAFO_ANNUL_PROG_REP] [ICS_CAFO_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CAFO_PROD_AREA_DSCH] [I4]
 ON [I4].[ICS_CAFO_ANNUL_PROG_REP_ID] = [ICS_CAFO_ANNUL_PROG_REP].[ICS_CAFO_ANNUL_PROG_REP_ID] 
 
       WHERE ICS_CAFO_ANNUL_PROG_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CAFOAnnualProgramReportSubmission')
								  
	    AND ICS_CAFO_ANNUL_PROG_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_CAFO_ANNUL_PROG_REP/ICS_CAFOMLPW_NUTR_MON 
INSERT INTO [ICS_FLOW_ICIS].[ICS_CAFOMLPW_NUTR_MON]
     SELECT I5.*
        from [ICS_FLOW_LOCAL].[ICS_CAFO_ANNUL_PROG_REP] [ICS_CAFO_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CAFOMLPW_NUTR_MON] [I5]
 ON [I5].[ICS_CAFO_ANNUL_PROG_REP_ID] = [ICS_CAFO_ANNUL_PROG_REP].[ICS_CAFO_ANNUL_PROG_REP_ID] 
 
       WHERE ICS_CAFO_ANNUL_PROG_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CAFOAnnualProgramReportSubmission')
								  
	    AND ICS_CAFO_ANNUL_PROG_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_CAFO_ANNUL_PROG_REP/ICS_CAFOMLPW_TTL_AMOUNTS 
INSERT INTO [ICS_FLOW_ICIS].[ICS_CAFOMLPW_TTL_AMOUNTS]
     SELECT I6.*
        from [ICS_FLOW_LOCAL].[ICS_CAFO_ANNUL_PROG_REP] [ICS_CAFO_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CAFOMLPW_TTL_AMOUNTS] [I6]
 ON [I6].[ICS_CAFO_ANNUL_PROG_REP_ID] = [ICS_CAFO_ANNUL_PROG_REP].[ICS_CAFO_ANNUL_PROG_REP_ID] 
 
       WHERE ICS_CAFO_ANNUL_PROG_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CAFOAnnualProgramReportSubmission')
								  
	    AND ICS_CAFO_ANNUL_PROG_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

					
				
	

-- ================================================================
-- ICS_CAFO_PRMT 
-- ================================================================
			
				-- DELETES for: ICS_CAFO_PRMT 
				
								
-- /ICS_CAFO_PRMT/ICS_CAFOMLPW_TTL_AMOUNTS
DELETE I9
 from ICS_FLOW_ICIS.[ICS_CAFO_PRMT] [ICS_CAFO_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_CAFOMLPW_TTL_AMOUNTS] [I9]
 ON [I9].[ICS_CAFO_PRMT_ID] = [ICS_CAFO_PRMT].[ICS_CAFO_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CAFO_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CAFOPermitSubmission')
				
                  OR ICS_CAFO_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_CAFO_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_CAFO_PRMT/ICS_MNUR_LTTR_PRCSS_WW_STOR
DELETE I8
 from ICS_FLOW_ICIS.[ICS_CAFO_PRMT] [ICS_CAFO_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_MNUR_LTTR_PRCSS_WW_STOR] [I8]
 ON [I8].[ICS_CAFO_PRMT_ID] = [ICS_CAFO_PRMT].[ICS_CAFO_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CAFO_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CAFOPermitSubmission')
				
                  OR ICS_CAFO_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_CAFO_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_CAFO_PRMT/ICS_ANML_TYPE
DELETE I7
 from ICS_FLOW_ICIS.[ICS_CAFO_PRMT] [ICS_CAFO_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_ANML_TYPE] [I7]
 ON [I7].[ICS_CAFO_PRMT_ID] = [ICS_CAFO_PRMT].[ICS_CAFO_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CAFO_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CAFOPermitSubmission')
				
                  OR ICS_CAFO_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_CAFO_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_CAFO_PRMT/ICS_ADDR/ICS_TELEPH
DELETE I6
 from ICS_FLOW_ICIS.[ICS_CAFO_PRMT] [ICS_CAFO_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_ADDR] [I5]
 ON [I5].[ICS_CAFO_PRMT_ID] = [ICS_CAFO_PRMT].[ICS_CAFO_PRMT_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_TELEPH] [I6]
 ON [I6].[ICS_ADDR_ID] = [I5].[ICS_ADDR_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CAFO_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CAFOPermitSubmission')
				
                  OR ICS_CAFO_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_CAFO_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_CAFO_PRMT/ICS_ADDR
DELETE I5
 from ICS_FLOW_ICIS.[ICS_CAFO_PRMT] [ICS_CAFO_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_ADDR] [I5]
 ON [I5].[ICS_CAFO_PRMT_ID] = [ICS_CAFO_PRMT].[ICS_CAFO_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CAFO_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CAFOPermitSubmission')
				
                  OR ICS_CAFO_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_CAFO_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_CAFO_PRMT/ICS_LAND_APPL_BMP
DELETE I4
 from ICS_FLOW_ICIS.[ICS_CAFO_PRMT] [ICS_CAFO_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_LAND_APPL_BMP] [I4]
 ON [I4].[ICS_CAFO_PRMT_ID] = [ICS_CAFO_PRMT].[ICS_CAFO_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CAFO_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CAFOPermitSubmission')
				
                  OR ICS_CAFO_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_CAFO_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_CAFO_PRMT/ICS_CONTAINMENT
DELETE I3
 from ICS_FLOW_ICIS.[ICS_CAFO_PRMT] [ICS_CAFO_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_CONTAINMENT] [I3]
 ON [I3].[ICS_CAFO_PRMT_ID] = [ICS_CAFO_PRMT].[ICS_CAFO_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CAFO_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CAFOPermitSubmission')
				
                  OR ICS_CAFO_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_CAFO_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_CAFO_PRMT/ICS_CONTACT/ICS_TELEPH
DELETE I2
 from ICS_FLOW_ICIS.[ICS_CAFO_PRMT] [ICS_CAFO_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_CONTACT] [I1]
 ON [I1].[ICS_CAFO_PRMT_ID] = [ICS_CAFO_PRMT].[ICS_CAFO_PRMT_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_TELEPH] [I2]
 ON [I2].[ICS_CONTACT_ID] = [I1].[ICS_CONTACT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CAFO_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CAFOPermitSubmission')
				
                  OR ICS_CAFO_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_CAFO_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_CAFO_PRMT/ICS_CONTACT
DELETE I1
 from ICS_FLOW_ICIS.[ICS_CAFO_PRMT] [ICS_CAFO_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_CONTACT] [I1]
 ON [I1].[ICS_CAFO_PRMT_ID] = [ICS_CAFO_PRMT].[ICS_CAFO_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CAFO_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CAFOPermitSubmission')
				
                  OR ICS_CAFO_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_CAFO_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_CAFO_PRMT
DELETE ICS_CAFO_PRMT
 from ICS_FLOW_ICIS.[ICS_CAFO_PRMT] [ICS_CAFO_PRMT] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CAFO_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CAFOPermitSubmission')
				
                  OR ICS_CAFO_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_CAFO_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
					

				-- INSERTS for: ICS_CAFO_PRMT
	
				
-- /ICS_CAFO_PRMT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_CAFO_PRMT]
     SELECT ICS_CAFO_PRMT.*
        from [ICS_FLOW_LOCAL].[ICS_CAFO_PRMT] [ICS_CAFO_PRMT] 
 
       WHERE ICS_CAFO_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CAFOPermitSubmission')
								  
	    AND ICS_CAFO_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_CAFO_PRMT/ICS_CONTACT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_CONTACT]
     SELECT I1.*
        from [ICS_FLOW_LOCAL].[ICS_CAFO_PRMT] [ICS_CAFO_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTACT] [I1]
 ON [I1].[ICS_CAFO_PRMT_ID] = [ICS_CAFO_PRMT].[ICS_CAFO_PRMT_ID] 
 
       WHERE ICS_CAFO_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CAFOPermitSubmission')
								  
	    AND ICS_CAFO_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_CAFO_PRMT/ICS_CONTACT/ICS_TELEPH 
INSERT INTO [ICS_FLOW_ICIS].[ICS_TELEPH]
     SELECT I2.*
        from [ICS_FLOW_LOCAL].[ICS_CAFO_PRMT] [ICS_CAFO_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTACT] [I1]
 ON [I1].[ICS_CAFO_PRMT_ID] = [ICS_CAFO_PRMT].[ICS_CAFO_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_TELEPH] [I2]
 ON [I2].[ICS_CONTACT_ID] = [I1].[ICS_CONTACT_ID] 
 
       WHERE ICS_CAFO_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CAFOPermitSubmission')
								  
	    AND ICS_CAFO_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_CAFO_PRMT/ICS_CONTAINMENT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_CONTAINMENT]
     SELECT I3.*
        from [ICS_FLOW_LOCAL].[ICS_CAFO_PRMT] [ICS_CAFO_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTAINMENT] [I3]
 ON [I3].[ICS_CAFO_PRMT_ID] = [ICS_CAFO_PRMT].[ICS_CAFO_PRMT_ID] 
 
       WHERE ICS_CAFO_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CAFOPermitSubmission')
								  
	    AND ICS_CAFO_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_CAFO_PRMT/ICS_LAND_APPL_BMP 
INSERT INTO [ICS_FLOW_ICIS].[ICS_LAND_APPL_BMP]
     SELECT I4.*
        from [ICS_FLOW_LOCAL].[ICS_CAFO_PRMT] [ICS_CAFO_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_LAND_APPL_BMP] [I4]
 ON [I4].[ICS_CAFO_PRMT_ID] = [ICS_CAFO_PRMT].[ICS_CAFO_PRMT_ID] 
 
       WHERE ICS_CAFO_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CAFOPermitSubmission')
								  
	    AND ICS_CAFO_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_CAFO_PRMT/ICS_ADDR 
INSERT INTO [ICS_FLOW_ICIS].[ICS_ADDR]
     SELECT I5.*
        from [ICS_FLOW_LOCAL].[ICS_CAFO_PRMT] [ICS_CAFO_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ADDR] [I5]
 ON [I5].[ICS_CAFO_PRMT_ID] = [ICS_CAFO_PRMT].[ICS_CAFO_PRMT_ID] 
 
       WHERE ICS_CAFO_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CAFOPermitSubmission')
								  
	    AND ICS_CAFO_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_CAFO_PRMT/ICS_ADDR/ICS_TELEPH 
INSERT INTO [ICS_FLOW_ICIS].[ICS_TELEPH]
     SELECT I6.*
        from [ICS_FLOW_LOCAL].[ICS_CAFO_PRMT] [ICS_CAFO_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ADDR] [I5]
 ON [I5].[ICS_CAFO_PRMT_ID] = [ICS_CAFO_PRMT].[ICS_CAFO_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_TELEPH] [I6]
 ON [I6].[ICS_ADDR_ID] = [I5].[ICS_ADDR_ID] 
 
       WHERE ICS_CAFO_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CAFOPermitSubmission')
								  
	    AND ICS_CAFO_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_CAFO_PRMT/ICS_ANML_TYPE 
INSERT INTO [ICS_FLOW_ICIS].[ICS_ANML_TYPE]
     SELECT I7.*
        from [ICS_FLOW_LOCAL].[ICS_CAFO_PRMT] [ICS_CAFO_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ANML_TYPE] [I7]
 ON [I7].[ICS_CAFO_PRMT_ID] = [ICS_CAFO_PRMT].[ICS_CAFO_PRMT_ID] 
 
       WHERE ICS_CAFO_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CAFOPermitSubmission')
								  
	    AND ICS_CAFO_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_CAFO_PRMT/ICS_MNUR_LTTR_PRCSS_WW_STOR 
INSERT INTO [ICS_FLOW_ICIS].[ICS_MNUR_LTTR_PRCSS_WW_STOR]
     SELECT I8.*
        from [ICS_FLOW_LOCAL].[ICS_CAFO_PRMT] [ICS_CAFO_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MNUR_LTTR_PRCSS_WW_STOR] [I8]
 ON [I8].[ICS_CAFO_PRMT_ID] = [ICS_CAFO_PRMT].[ICS_CAFO_PRMT_ID] 
 
       WHERE ICS_CAFO_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CAFOPermitSubmission')
								  
	    AND ICS_CAFO_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_CAFO_PRMT/ICS_CAFOMLPW_TTL_AMOUNTS 
INSERT INTO [ICS_FLOW_ICIS].[ICS_CAFOMLPW_TTL_AMOUNTS]
     SELECT I9.*
        from [ICS_FLOW_LOCAL].[ICS_CAFO_PRMT] [ICS_CAFO_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CAFOMLPW_TTL_AMOUNTS] [I9]
 ON [I9].[ICS_CAFO_PRMT_ID] = [ICS_CAFO_PRMT].[ICS_CAFO_PRMT_ID] 
 
       WHERE ICS_CAFO_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CAFOPermitSubmission')
								  
	    AND ICS_CAFO_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

					
				
	

-- ================================================================
-- ICS_COLL_SYSTM_PRMT 
-- ================================================================
			
				-- DELETES for: ICS_COLL_SYSTM_PRMT 
				
								
-- /ICS_COLL_SYSTM_PRMT
DELETE ICS_COLL_SYSTM_PRMT
 from ICS_FLOW_ICIS.[ICS_COLL_SYSTM_PRMT] [ICS_COLL_SYSTM_PRMT] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_COLL_SYSTM_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CollectionSystemPermitSubmission')
				
                  OR ICS_COLL_SYSTM_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_COLL_SYSTM_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
					

				-- INSERTS for: ICS_COLL_SYSTM_PRMT
	
				
-- /ICS_COLL_SYSTM_PRMT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_COLL_SYSTM_PRMT]
     SELECT ICS_COLL_SYSTM_PRMT.*
        from [ICS_FLOW_LOCAL].[ICS_COLL_SYSTM_PRMT] [ICS_COLL_SYSTM_PRMT] 
 
       WHERE ICS_COLL_SYSTM_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CollectionSystemPermitSubmission')
								  
	    AND ICS_COLL_SYSTM_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

					
				
	

-- ================================================================
-- ICS_CMPL_MON 
-- ================================================================
			
				-- DELETES for: ICS_CMPL_MON 
				
								
-- /ICS_CMPL_MON/ICS_CMPL_MON_AGNCY_TYPE
DELETE I36
 from ICS_FLOW_ICIS.[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN ICS_FLOW_ICIS.[ICS_CMPL_MON_AGNCY_TYPE] [I36]
 ON [I36].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
				
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_CMPL_MON/ICS_CMPL_MON_ACTN_REASON
DELETE I35
 from ICS_FLOW_ICIS.[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN ICS_FLOW_ICIS.[ICS_CMPL_MON_ACTN_REASON] [I35]
 ON [I35].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
				
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_CMPL_MON/ICS_CMPL_INSP_TYPE
DELETE I34
 from ICS_FLOW_ICIS.[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN ICS_FLOW_ICIS.[ICS_CMPL_INSP_TYPE] [I34]
 ON [I34].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
				
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_CMPL_MON/ICS_CAFO_INSP/ICS_CAFO_INSP_VIOL_TYPE
DELETE I33
 from ICS_FLOW_ICIS.[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN ICS_FLOW_ICIS.[ICS_CAFO_INSP] [I28]
 ON [I28].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_CAFO_INSP_VIOL_TYPE] [I33]
 ON [I33].[ICS_CAFO_INSP_ID] = [I28].[ICS_CAFO_INSP_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
				
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_CMPL_MON/ICS_CAFO_INSP/ICS_MNUR_LTTR_PRCSS_WW_STOR
DELETE I32
 from ICS_FLOW_ICIS.[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN ICS_FLOW_ICIS.[ICS_CAFO_INSP] [I28]
 ON [I28].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_MNUR_LTTR_PRCSS_WW_STOR] [I32]
 ON [I32].[ICS_CAFO_INSP_ID] = [I28].[ICS_CAFO_INSP_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
				
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_CMPL_MON/ICS_CAFO_INSP/ICS_ANML_TYPE
DELETE I31
 from ICS_FLOW_ICIS.[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN ICS_FLOW_ICIS.[ICS_CAFO_INSP] [I28]
 ON [I28].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_ANML_TYPE] [I31]
 ON [I31].[ICS_CAFO_INSP_ID] = [I28].[ICS_CAFO_INSP_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
				
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_CMPL_MON/ICS_CAFO_INSP/ICS_LAND_APPL_BMP
DELETE I30
 from ICS_FLOW_ICIS.[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN ICS_FLOW_ICIS.[ICS_CAFO_INSP] [I28]
 ON [I28].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_LAND_APPL_BMP] [I30]
 ON [I30].[ICS_CAFO_INSP_ID] = [I28].[ICS_CAFO_INSP_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
				
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_CMPL_MON/ICS_CAFO_INSP/ICS_CONTAINMENT
DELETE I29
 from ICS_FLOW_ICIS.[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN ICS_FLOW_ICIS.[ICS_CAFO_INSP] [I28]
 ON [I28].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_CONTAINMENT] [I29]
 ON [I29].[ICS_CAFO_INSP_ID] = [I28].[ICS_CAFO_INSP_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
				
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_CMPL_MON/ICS_CAFO_INSP
DELETE I28
 from ICS_FLOW_ICIS.[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN ICS_FLOW_ICIS.[ICS_CAFO_INSP] [I28]
 ON [I28].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
				
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_CMPL_MON/ICS_SW_NON_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP/ICS_PROJ_TYPE
DELETE I27
 from ICS_FLOW_ICIS.[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN ICS_FLOW_ICIS.[ICS_SW_NON_CNST_INSP] [I24]
 ON [I24].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_SW_UNPRMT_CNST_INSP] [I26]
 ON [I26].[ICS_SW_NON_CNST_INSP_ID] = [I24].[ICS_SW_NON_CNST_INSP_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_PROJ_TYPE] [I27]
 ON [I27].[ICS_SW_UNPRMT_CNST_INSP_ID] = [I26].[ICS_SW_UNPRMT_CNST_INSP_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
				
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_CMPL_MON/ICS_SW_NON_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP
DELETE I26
 from ICS_FLOW_ICIS.[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN ICS_FLOW_ICIS.[ICS_SW_NON_CNST_INSP] [I24]
 ON [I24].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_SW_UNPRMT_CNST_INSP] [I26]
 ON [I26].[ICS_SW_NON_CNST_INSP_ID] = [I24].[ICS_SW_NON_CNST_INSP_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
				
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_CMPL_MON/ICS_SW_NON_CNST_INSP/ICS_SW_CNST_INDST_INSP
DELETE I25
 from ICS_FLOW_ICIS.[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN ICS_FLOW_ICIS.[ICS_SW_NON_CNST_INSP] [I24]
 ON [I24].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_SW_CNST_INDST_INSP] [I25]
 ON [I25].[ICS_SW_NON_CNST_INSP_ID] = [I24].[ICS_SW_NON_CNST_INSP_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
				
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_CMPL_MON/ICS_SW_NON_CNST_INSP
DELETE I24
 from ICS_FLOW_ICIS.[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN ICS_FLOW_ICIS.[ICS_SW_NON_CNST_INSP] [I24]
 ON [I24].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
				
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_CMPL_MON/ICS_SW_MS_4_INSP/ICS_PROJ_SRCS_FUND
DELETE I23
 from ICS_FLOW_ICIS.[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN ICS_FLOW_ICIS.[ICS_SW_MS_4_INSP] [I22]
 ON [I22].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_PROJ_SRCS_FUND] [I23]
 ON [I23].[ICS_SW_MS_4_INSP_ID] = [I22].[ICS_SW_MS_4_INSP_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
				
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_CMPL_MON/ICS_SW_MS_4_INSP
DELETE I22
 from ICS_FLOW_ICIS.[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN ICS_FLOW_ICIS.[ICS_SW_MS_4_INSP] [I22]
 ON [I22].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
				
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_CMPL_MON/ICS_SW_CNST_NON_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP/ICS_PROJ_TYPE
DELETE I21
 from ICS_FLOW_ICIS.[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN ICS_FLOW_ICIS.[ICS_SW_CNST_NON_CNST_INSP] [I18]
 ON [I18].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_SW_UNPRMT_CNST_INSP] [I20]
 ON [I20].[ICS_SW_CNST_NON_CNST_INSP_ID] = [I18].[ICS_SW_CNST_NON_CNST_INSP_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_PROJ_TYPE] [I21]
 ON [I21].[ICS_SW_UNPRMT_CNST_INSP_ID] = [I20].[ICS_SW_UNPRMT_CNST_INSP_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
				
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_CMPL_MON/ICS_SW_CNST_NON_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP
DELETE I20
 from ICS_FLOW_ICIS.[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN ICS_FLOW_ICIS.[ICS_SW_CNST_NON_CNST_INSP] [I18]
 ON [I18].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_SW_UNPRMT_CNST_INSP] [I20]
 ON [I20].[ICS_SW_CNST_NON_CNST_INSP_ID] = [I18].[ICS_SW_CNST_NON_CNST_INSP_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
				
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_CMPL_MON/ICS_SW_CNST_NON_CNST_INSP/ICS_SW_CNST_INDST_INSP
DELETE I19
 from ICS_FLOW_ICIS.[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN ICS_FLOW_ICIS.[ICS_SW_CNST_NON_CNST_INSP] [I18]
 ON [I18].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_SW_CNST_INDST_INSP] [I19]
 ON [I19].[ICS_SW_CNST_NON_CNST_INSP_ID] = [I18].[ICS_SW_CNST_NON_CNST_INSP_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
				
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_CMPL_MON/ICS_SW_CNST_NON_CNST_INSP
DELETE I18
 from ICS_FLOW_ICIS.[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN ICS_FLOW_ICIS.[ICS_SW_CNST_NON_CNST_INSP] [I18]
 ON [I18].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
				
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_CMPL_MON/ICS_SW_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP/ICS_PROJ_TYPE
DELETE I17
 from ICS_FLOW_ICIS.[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN ICS_FLOW_ICIS.[ICS_SW_CNST_INSP] [I14]
 ON [I14].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_SW_UNPRMT_CNST_INSP] [I16]
 ON [I16].[ICS_SW_CNST_INSP_ID] = [I14].[ICS_SW_CNST_INSP_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_PROJ_TYPE] [I17]
 ON [I17].[ICS_SW_UNPRMT_CNST_INSP_ID] = [I16].[ICS_SW_UNPRMT_CNST_INSP_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
				
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_CMPL_MON/ICS_SW_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP
DELETE I16
 from ICS_FLOW_ICIS.[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN ICS_FLOW_ICIS.[ICS_SW_CNST_INSP] [I14]
 ON [I14].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_SW_UNPRMT_CNST_INSP] [I16]
 ON [I16].[ICS_SW_CNST_INSP_ID] = [I14].[ICS_SW_CNST_INSP_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
				
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_CMPL_MON/ICS_SW_CNST_INSP/ICS_SW_CNST_INDST_INSP
DELETE I15
 from ICS_FLOW_ICIS.[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN ICS_FLOW_ICIS.[ICS_SW_CNST_INSP] [I14]
 ON [I14].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_SW_CNST_INDST_INSP] [I15]
 ON [I15].[ICS_SW_CNST_INSP_ID] = [I14].[ICS_SW_CNST_INSP_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
				
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_CMPL_MON/ICS_SW_CNST_INSP
DELETE I14
 from ICS_FLOW_ICIS.[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN ICS_FLOW_ICIS.[ICS_SW_CNST_INSP] [I14]
 ON [I14].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
				
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_CMPL_MON/ICS_SSO_INSP/ICS_SSO_SYSTM_COMP
DELETE I13
 from ICS_FLOW_ICIS.[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN ICS_FLOW_ICIS.[ICS_SSO_INSP] [I10]
 ON [I10].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_SSO_SYSTM_COMP] [I13]
 ON [I13].[ICS_SSO_INSP_ID] = [I10].[ICS_SSO_INSP_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
				
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_CMPL_MON/ICS_SSO_INSP/ICS_SSO_STPS
DELETE I12
 from ICS_FLOW_ICIS.[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN ICS_FLOW_ICIS.[ICS_SSO_INSP] [I10]
 ON [I10].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_SSO_STPS] [I12]
 ON [I12].[ICS_SSO_INSP_ID] = [I10].[ICS_SSO_INSP_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
				
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_CMPL_MON/ICS_SSO_INSP/ICS_IMPACT_SSO_EVT
DELETE I11
 from ICS_FLOW_ICIS.[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN ICS_FLOW_ICIS.[ICS_SSO_INSP] [I10]
 ON [I10].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_IMPACT_SSO_EVT] [I11]
 ON [I11].[ICS_SSO_INSP_ID] = [I10].[ICS_SSO_INSP_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
				
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_CMPL_MON/ICS_SSO_INSP
DELETE I10
 from ICS_FLOW_ICIS.[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN ICS_FLOW_ICIS.[ICS_SSO_INSP] [I10]
 ON [I10].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
				
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_CMPL_MON/ICS_INSP_GOV_CONTACT
DELETE I9
 from ICS_FLOW_ICIS.[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN ICS_FLOW_ICIS.[ICS_INSP_GOV_CONTACT] [I9]
 ON [I9].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
				
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_CMPL_MON/ICS_INSP_CMNT_TXT
DELETE I8
 from ICS_FLOW_ICIS.[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN ICS_FLOW_ICIS.[ICS_INSP_CMNT_TXT] [I8]
 ON [I8].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
				
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_CMPL_MON/ICS_PROG_DEFCY_TYPE
DELETE I7
 from ICS_FLOW_ICIS.[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN ICS_FLOW_ICIS.[ICS_PROG_DEFCY_TYPE] [I7]
 ON [I7].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
				
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_CMPL_MON/ICS_PROG
DELETE I6
 from ICS_FLOW_ICIS.[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN ICS_FLOW_ICIS.[ICS_PROG] [I6]
 ON [I6].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
				
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_CMPL_MON/ICS_PRETR_INSP
DELETE I5
 from ICS_FLOW_ICIS.[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN ICS_FLOW_ICIS.[ICS_PRETR_INSP] [I5]
 ON [I5].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
				
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_CMPL_MON/ICS_CSO_INSP
DELETE I4
 from ICS_FLOW_ICIS.[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN ICS_FLOW_ICIS.[ICS_CSO_INSP] [I4]
 ON [I4].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
				
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_CMPL_MON/ICS_NAT_PRIO
DELETE I3
 from ICS_FLOW_ICIS.[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN ICS_FLOW_ICIS.[ICS_NAT_PRIO] [I3]
 ON [I3].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
				
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_CMPL_MON/ICS_CONTACT/ICS_TELEPH
DELETE I2
 from ICS_FLOW_ICIS.[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN ICS_FLOW_ICIS.[ICS_CONTACT] [I1]
 ON [I1].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_TELEPH] [I2]
 ON [I2].[ICS_CONTACT_ID] = [I1].[ICS_CONTACT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
				
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_CMPL_MON/ICS_CONTACT
DELETE I1
 from ICS_FLOW_ICIS.[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN ICS_FLOW_ICIS.[ICS_CONTACT] [I1]
 ON [I1].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
				
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_CMPL_MON
DELETE ICS_CMPL_MON
 from ICS_FLOW_ICIS.[ICS_CMPL_MON] [ICS_CMPL_MON] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
				
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
					

				-- INSERTS for: ICS_CMPL_MON
	
				
-- /ICS_CMPL_MON 
INSERT INTO [ICS_FLOW_ICIS].[ICS_CMPL_MON]
     SELECT ICS_CMPL_MON.*
        from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission')
								  
	    AND ICS_CMPL_MON.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_CMPL_MON/ICS_CONTACT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_CONTACT]
     SELECT I1.*
        from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTACT] [I1]
 ON [I1].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission')
								  
	    AND ICS_CMPL_MON.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_CMPL_MON/ICS_CONTACT/ICS_TELEPH 
INSERT INTO [ICS_FLOW_ICIS].[ICS_TELEPH]
     SELECT I2.*
        from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTACT] [I1]
 ON [I1].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_TELEPH] [I2]
 ON [I2].[ICS_CONTACT_ID] = [I1].[ICS_CONTACT_ID] 
 
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission')
								  
	    AND ICS_CMPL_MON.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_CMPL_MON/ICS_NAT_PRIO 
INSERT INTO [ICS_FLOW_ICIS].[ICS_NAT_PRIO]
     SELECT I3.*
        from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_NAT_PRIO] [I3]
 ON [I3].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission')
								  
	    AND ICS_CMPL_MON.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_CMPL_MON/ICS_CSO_INSP 
INSERT INTO [ICS_FLOW_ICIS].[ICS_CSO_INSP]
     SELECT I4.*
        from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CSO_INSP] [I4]
 ON [I4].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission')
								  
	    AND ICS_CMPL_MON.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_CMPL_MON/ICS_PRETR_INSP 
INSERT INTO [ICS_FLOW_ICIS].[ICS_PRETR_INSP]
     SELECT I5.*
        from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PRETR_INSP] [I5]
 ON [I5].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission')
								  
	    AND ICS_CMPL_MON.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_CMPL_MON/ICS_PROG 
INSERT INTO [ICS_FLOW_ICIS].[ICS_PROG]
     SELECT I6.*
        from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PROG] [I6]
 ON [I6].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission')
								  
	    AND ICS_CMPL_MON.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_CMPL_MON/ICS_PROG_DEFCY_TYPE 
INSERT INTO [ICS_FLOW_ICIS].[ICS_PROG_DEFCY_TYPE]
     SELECT I7.*
        from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PROG_DEFCY_TYPE] [I7]
 ON [I7].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission')
								  
	    AND ICS_CMPL_MON.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_CMPL_MON/ICS_INSP_CMNT_TXT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_INSP_CMNT_TXT]
     SELECT I8.*
        from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_INSP_CMNT_TXT] [I8]
 ON [I8].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission')
								  
	    AND ICS_CMPL_MON.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_CMPL_MON/ICS_INSP_GOV_CONTACT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_INSP_GOV_CONTACT]
     SELECT I9.*
        from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_INSP_GOV_CONTACT] [I9]
 ON [I9].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission')
								  
	    AND ICS_CMPL_MON.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_CMPL_MON/ICS_SSO_INSP 
INSERT INTO [ICS_FLOW_ICIS].[ICS_SSO_INSP]
     SELECT I10.*
        from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SSO_INSP] [I10]
 ON [I10].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission')
								  
	    AND ICS_CMPL_MON.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_CMPL_MON/ICS_SSO_INSP/ICS_IMPACT_SSO_EVT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_IMPACT_SSO_EVT]
     SELECT I11.*
        from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SSO_INSP] [I10]
 ON [I10].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_IMPACT_SSO_EVT] [I11]
 ON [I11].[ICS_SSO_INSP_ID] = [I10].[ICS_SSO_INSP_ID] 
 
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission')
								  
	    AND ICS_CMPL_MON.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_CMPL_MON/ICS_SSO_INSP/ICS_SSO_STPS 
INSERT INTO [ICS_FLOW_ICIS].[ICS_SSO_STPS]
     SELECT I12.*
        from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SSO_INSP] [I10]
 ON [I10].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SSO_STPS] [I12]
 ON [I12].[ICS_SSO_INSP_ID] = [I10].[ICS_SSO_INSP_ID] 
 
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission')
								  
	    AND ICS_CMPL_MON.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_CMPL_MON/ICS_SSO_INSP/ICS_SSO_SYSTM_COMP 
INSERT INTO [ICS_FLOW_ICIS].[ICS_SSO_SYSTM_COMP]
     SELECT I13.*
        from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SSO_INSP] [I10]
 ON [I10].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SSO_SYSTM_COMP] [I13]
 ON [I13].[ICS_SSO_INSP_ID] = [I10].[ICS_SSO_INSP_ID] 
 
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission')
								  
	    AND ICS_CMPL_MON.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_CMPL_MON/ICS_SW_CNST_INSP 
INSERT INTO [ICS_FLOW_ICIS].[ICS_SW_CNST_INSP]
     SELECT I14.*
        from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SW_CNST_INSP] [I14]
 ON [I14].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission')
								  
	    AND ICS_CMPL_MON.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_CMPL_MON/ICS_SW_CNST_INSP/ICS_SW_CNST_INDST_INSP 
INSERT INTO [ICS_FLOW_ICIS].[ICS_SW_CNST_INDST_INSP]
     SELECT I15.*
        from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SW_CNST_INSP] [I14]
 ON [I14].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SW_CNST_INDST_INSP] [I15]
 ON [I15].[ICS_SW_CNST_INSP_ID] = [I14].[ICS_SW_CNST_INSP_ID] 
 
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission')
								  
	    AND ICS_CMPL_MON.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_CMPL_MON/ICS_SW_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP 
INSERT INTO [ICS_FLOW_ICIS].[ICS_SW_UNPRMT_CNST_INSP]
     SELECT I16.*
        from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SW_CNST_INSP] [I14]
 ON [I14].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SW_UNPRMT_CNST_INSP] [I16]
 ON [I16].[ICS_SW_CNST_INSP_ID] = [I14].[ICS_SW_CNST_INSP_ID] 
 
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission')
								  
	    AND ICS_CMPL_MON.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_CMPL_MON/ICS_SW_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP/ICS_PROJ_TYPE 
INSERT INTO [ICS_FLOW_ICIS].[ICS_PROJ_TYPE]
     SELECT I17.*
        from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SW_CNST_INSP] [I14]
 ON [I14].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SW_UNPRMT_CNST_INSP] [I16]
 ON [I16].[ICS_SW_CNST_INSP_ID] = [I14].[ICS_SW_CNST_INSP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PROJ_TYPE] [I17]
 ON [I17].[ICS_SW_UNPRMT_CNST_INSP_ID] = [I16].[ICS_SW_UNPRMT_CNST_INSP_ID] 
 
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission')
								  
	    AND ICS_CMPL_MON.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_CMPL_MON/ICS_SW_CNST_NON_CNST_INSP 
INSERT INTO [ICS_FLOW_ICIS].[ICS_SW_CNST_NON_CNST_INSP]
     SELECT I18.*
        from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SW_CNST_NON_CNST_INSP] [I18]
 ON [I18].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission')
								  
	    AND ICS_CMPL_MON.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_CMPL_MON/ICS_SW_CNST_NON_CNST_INSP/ICS_SW_CNST_INDST_INSP 
INSERT INTO [ICS_FLOW_ICIS].[ICS_SW_CNST_INDST_INSP]
     SELECT I19.*
        from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SW_CNST_NON_CNST_INSP] [I18]
 ON [I18].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SW_CNST_INDST_INSP] [I19]
 ON [I19].[ICS_SW_CNST_NON_CNST_INSP_ID] = [I18].[ICS_SW_CNST_NON_CNST_INSP_ID] 
 
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission')
								  
	    AND ICS_CMPL_MON.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_CMPL_MON/ICS_SW_CNST_NON_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP 
INSERT INTO [ICS_FLOW_ICIS].[ICS_SW_UNPRMT_CNST_INSP]
     SELECT I20.*
        from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SW_CNST_NON_CNST_INSP] [I18]
 ON [I18].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SW_UNPRMT_CNST_INSP] [I20]
 ON [I20].[ICS_SW_CNST_NON_CNST_INSP_ID] = [I18].[ICS_SW_CNST_NON_CNST_INSP_ID] 
 
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission')
								  
	    AND ICS_CMPL_MON.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_CMPL_MON/ICS_SW_CNST_NON_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP/ICS_PROJ_TYPE 
INSERT INTO [ICS_FLOW_ICIS].[ICS_PROJ_TYPE]
     SELECT I21.*
        from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SW_CNST_NON_CNST_INSP] [I18]
 ON [I18].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SW_UNPRMT_CNST_INSP] [I20]
 ON [I20].[ICS_SW_CNST_NON_CNST_INSP_ID] = [I18].[ICS_SW_CNST_NON_CNST_INSP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PROJ_TYPE] [I21]
 ON [I21].[ICS_SW_UNPRMT_CNST_INSP_ID] = [I20].[ICS_SW_UNPRMT_CNST_INSP_ID] 
 
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission')
								  
	    AND ICS_CMPL_MON.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_CMPL_MON/ICS_SW_MS_4_INSP 
INSERT INTO [ICS_FLOW_ICIS].[ICS_SW_MS_4_INSP]
     SELECT I22.*
        from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SW_MS_4_INSP] [I22]
 ON [I22].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission')
								  
	    AND ICS_CMPL_MON.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_CMPL_MON/ICS_SW_MS_4_INSP/ICS_PROJ_SRCS_FUND 
INSERT INTO [ICS_FLOW_ICIS].[ICS_PROJ_SRCS_FUND]
     SELECT I23.*
        from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SW_MS_4_INSP] [I22]
 ON [I22].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PROJ_SRCS_FUND] [I23]
 ON [I23].[ICS_SW_MS_4_INSP_ID] = [I22].[ICS_SW_MS_4_INSP_ID] 
 
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission')
								  
	    AND ICS_CMPL_MON.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_CMPL_MON/ICS_SW_NON_CNST_INSP 
INSERT INTO [ICS_FLOW_ICIS].[ICS_SW_NON_CNST_INSP]
     SELECT I24.*
        from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SW_NON_CNST_INSP] [I24]
 ON [I24].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission')
								  
	    AND ICS_CMPL_MON.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_CMPL_MON/ICS_SW_NON_CNST_INSP/ICS_SW_CNST_INDST_INSP 
INSERT INTO [ICS_FLOW_ICIS].[ICS_SW_CNST_INDST_INSP]
     SELECT I25.*
        from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SW_NON_CNST_INSP] [I24]
 ON [I24].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SW_CNST_INDST_INSP] [I25]
 ON [I25].[ICS_SW_NON_CNST_INSP_ID] = [I24].[ICS_SW_NON_CNST_INSP_ID] 
 
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission')
								  
	    AND ICS_CMPL_MON.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_CMPL_MON/ICS_SW_NON_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP 
INSERT INTO [ICS_FLOW_ICIS].[ICS_SW_UNPRMT_CNST_INSP]
     SELECT I26.*
        from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SW_NON_CNST_INSP] [I24]
 ON [I24].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SW_UNPRMT_CNST_INSP] [I26]
 ON [I26].[ICS_SW_NON_CNST_INSP_ID] = [I24].[ICS_SW_NON_CNST_INSP_ID] 
 
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission')
								  
	    AND ICS_CMPL_MON.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_CMPL_MON/ICS_SW_NON_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP/ICS_PROJ_TYPE 
INSERT INTO [ICS_FLOW_ICIS].[ICS_PROJ_TYPE]
     SELECT I27.*
        from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SW_NON_CNST_INSP] [I24]
 ON [I24].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SW_UNPRMT_CNST_INSP] [I26]
 ON [I26].[ICS_SW_NON_CNST_INSP_ID] = [I24].[ICS_SW_NON_CNST_INSP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PROJ_TYPE] [I27]
 ON [I27].[ICS_SW_UNPRMT_CNST_INSP_ID] = [I26].[ICS_SW_UNPRMT_CNST_INSP_ID] 
 
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission')
								  
	    AND ICS_CMPL_MON.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_CMPL_MON/ICS_CAFO_INSP 
INSERT INTO [ICS_FLOW_ICIS].[ICS_CAFO_INSP]
     SELECT I28.*
        from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CAFO_INSP] [I28]
 ON [I28].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission')
								  
	    AND ICS_CMPL_MON.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_CMPL_MON/ICS_CAFO_INSP/ICS_CONTAINMENT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_CONTAINMENT]
     SELECT I29.*
        from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CAFO_INSP] [I28]
 ON [I28].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTAINMENT] [I29]
 ON [I29].[ICS_CAFO_INSP_ID] = [I28].[ICS_CAFO_INSP_ID] 
 
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission')
								  
	    AND ICS_CMPL_MON.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_CMPL_MON/ICS_CAFO_INSP/ICS_LAND_APPL_BMP 
INSERT INTO [ICS_FLOW_ICIS].[ICS_LAND_APPL_BMP]
     SELECT I30.*
        from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CAFO_INSP] [I28]
 ON [I28].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_LAND_APPL_BMP] [I30]
 ON [I30].[ICS_CAFO_INSP_ID] = [I28].[ICS_CAFO_INSP_ID] 
 
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission')
								  
	    AND ICS_CMPL_MON.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_CMPL_MON/ICS_CAFO_INSP/ICS_ANML_TYPE 
INSERT INTO [ICS_FLOW_ICIS].[ICS_ANML_TYPE]
     SELECT I31.*
        from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CAFO_INSP] [I28]
 ON [I28].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ANML_TYPE] [I31]
 ON [I31].[ICS_CAFO_INSP_ID] = [I28].[ICS_CAFO_INSP_ID] 
 
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission')
								  
	    AND ICS_CMPL_MON.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_CMPL_MON/ICS_CAFO_INSP/ICS_MNUR_LTTR_PRCSS_WW_STOR 
INSERT INTO [ICS_FLOW_ICIS].[ICS_MNUR_LTTR_PRCSS_WW_STOR]
     SELECT I32.*
        from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CAFO_INSP] [I28]
 ON [I28].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MNUR_LTTR_PRCSS_WW_STOR] [I32]
 ON [I32].[ICS_CAFO_INSP_ID] = [I28].[ICS_CAFO_INSP_ID] 
 
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission')
								  
	    AND ICS_CMPL_MON.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_CMPL_MON/ICS_CAFO_INSP/ICS_CAFO_INSP_VIOL_TYPE 
INSERT INTO [ICS_FLOW_ICIS].[ICS_CAFO_INSP_VIOL_TYPE]
     SELECT I33.*
        from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CAFO_INSP] [I28]
 ON [I28].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CAFO_INSP_VIOL_TYPE] [I33]
 ON [I33].[ICS_CAFO_INSP_ID] = [I28].[ICS_CAFO_INSP_ID] 
 
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission')
								  
	    AND ICS_CMPL_MON.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_CMPL_MON/ICS_CMPL_INSP_TYPE 
INSERT INTO [ICS_FLOW_ICIS].[ICS_CMPL_INSP_TYPE]
     SELECT I34.*
        from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CMPL_INSP_TYPE] [I34]
 ON [I34].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission')
								  
	    AND ICS_CMPL_MON.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_CMPL_MON/ICS_CMPL_MON_ACTN_REASON 
INSERT INTO [ICS_FLOW_ICIS].[ICS_CMPL_MON_ACTN_REASON]
     SELECT I35.*
        from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CMPL_MON_ACTN_REASON] [I35]
 ON [I35].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission')
								  
	    AND ICS_CMPL_MON.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_CMPL_MON/ICS_CMPL_MON_AGNCY_TYPE 
INSERT INTO [ICS_FLOW_ICIS].[ICS_CMPL_MON_AGNCY_TYPE]
     SELECT I36.*
        from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CMPL_MON_AGNCY_TYPE] [I36]
 ON [I36].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission')
								  
	    AND ICS_CMPL_MON.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

					
				
	

-- ================================================================
-- ICS_CMPL_MON_LNK 
-- ================================================================
			
				-- DELETES for: ICS_CMPL_MON_LNK 
				
								
-- /ICS_CMPL_MON_LNK/ICS_LNK_SNGL_EVT
DELETE I3
 from ICS_FLOW_ICIS.[ICS_CMPL_MON_LNK] [ICS_CMPL_MON_LNK] 
 JOIN ICS_FLOW_ICIS.[ICS_LNK_SNGL_EVT] [I3]
 ON [I3].[ICS_CMPL_MON_LNK_ID] = [ICS_CMPL_MON_LNK].[ICS_CMPL_MON_LNK_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON_LNK.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringLinkageSubmission')
				  ;
          				
				
								
-- /ICS_CMPL_MON_LNK/ICS_LNK_ENFRC_ACTN
DELETE I2
 from ICS_FLOW_ICIS.[ICS_CMPL_MON_LNK] [ICS_CMPL_MON_LNK] 
 JOIN ICS_FLOW_ICIS.[ICS_LNK_ENFRC_ACTN] [I2]
 ON [I2].[ICS_CMPL_MON_LNK_ID] = [ICS_CMPL_MON_LNK].[ICS_CMPL_MON_LNK_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON_LNK.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringLinkageSubmission')
				  ;
          				
				
								
-- /ICS_CMPL_MON_LNK/ICS_LNK_CMPL_MON
DELETE I1
 from ICS_FLOW_ICIS.[ICS_CMPL_MON_LNK] [ICS_CMPL_MON_LNK] 
 JOIN ICS_FLOW_ICIS.[ICS_LNK_CMPL_MON] [I1]
 ON [I1].[ICS_CMPL_MON_LNK_ID] = [ICS_CMPL_MON_LNK].[ICS_CMPL_MON_LNK_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON_LNK.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringLinkageSubmission')
				  ;
          				
				
								
-- /ICS_CMPL_MON_LNK
DELETE ICS_CMPL_MON_LNK
 from ICS_FLOW_ICIS.[ICS_CMPL_MON_LNK] [ICS_CMPL_MON_LNK] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON_LNK.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringLinkageSubmission')
				  ;
          				
				
					

				-- INSERTS for: ICS_CMPL_MON_LNK
	
				
-- /ICS_CMPL_MON_LNK 
INSERT INTO [ICS_FLOW_ICIS].[ICS_CMPL_MON_LNK]
     SELECT ICS_CMPL_MON_LNK.*
        from [ICS_FLOW_LOCAL].[ICS_CMPL_MON_LNK] [ICS_CMPL_MON_LNK] 
 
       WHERE ICS_CMPL_MON_LNK.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringLinkageSubmission')
				 
				  ;			 

				
-- /ICS_CMPL_MON_LNK/ICS_LNK_CMPL_MON 
INSERT INTO [ICS_FLOW_ICIS].[ICS_LNK_CMPL_MON]
     SELECT I1.*
        from [ICS_FLOW_LOCAL].[ICS_CMPL_MON_LNK] [ICS_CMPL_MON_LNK] 
 JOIN [ICS_FLOW_LOCAL].[ICS_LNK_CMPL_MON] [I1]
 ON [I1].[ICS_CMPL_MON_LNK_ID] = [ICS_CMPL_MON_LNK].[ICS_CMPL_MON_LNK_ID] 
 
       WHERE ICS_CMPL_MON_LNK.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringLinkageSubmission')
				 
				  ;			 

				
-- /ICS_CMPL_MON_LNK/ICS_LNK_ENFRC_ACTN 
INSERT INTO [ICS_FLOW_ICIS].[ICS_LNK_ENFRC_ACTN]
     SELECT I2.*
        from [ICS_FLOW_LOCAL].[ICS_CMPL_MON_LNK] [ICS_CMPL_MON_LNK] 
 JOIN [ICS_FLOW_LOCAL].[ICS_LNK_ENFRC_ACTN] [I2]
 ON [I2].[ICS_CMPL_MON_LNK_ID] = [ICS_CMPL_MON_LNK].[ICS_CMPL_MON_LNK_ID] 
 
       WHERE ICS_CMPL_MON_LNK.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringLinkageSubmission')
				 
				  ;			 

				
-- /ICS_CMPL_MON_LNK/ICS_LNK_SNGL_EVT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_LNK_SNGL_EVT]
     SELECT I3.*
        from [ICS_FLOW_LOCAL].[ICS_CMPL_MON_LNK] [ICS_CMPL_MON_LNK] 
 JOIN [ICS_FLOW_LOCAL].[ICS_LNK_SNGL_EVT] [I3]
 ON [I3].[ICS_CMPL_MON_LNK_ID] = [ICS_CMPL_MON_LNK].[ICS_CMPL_MON_LNK_ID] 
 
       WHERE ICS_CMPL_MON_LNK.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringLinkageSubmission')
				 
				  ;			 

					
				
	

-- ================================================================
-- ICS_CMPL_SCHD 
-- ================================================================
			
				-- DELETES for: ICS_CMPL_SCHD 
				
								
-- /ICS_CMPL_SCHD/ICS_CMPL_SCHD_EVT
DELETE I1
 from ICS_FLOW_ICIS.[ICS_CMPL_SCHD] [ICS_CMPL_SCHD] 
 JOIN ICS_FLOW_ICIS.[ICS_CMPL_SCHD_EVT] [I1]
 ON [I1].[ICS_CMPL_SCHD_ID] = [ICS_CMPL_SCHD].[ICS_CMPL_SCHD_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_SCHD.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceScheduleSubmission')
				
                  OR ICS_CMPL_SCHD.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_CMPL_SCHD
DELETE ICS_CMPL_SCHD
 from ICS_FLOW_ICIS.[ICS_CMPL_SCHD] [ICS_CMPL_SCHD] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_SCHD.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceScheduleSubmission')
				
                  OR ICS_CMPL_SCHD.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
					

				-- INSERTS for: ICS_CMPL_SCHD
	
				
-- /ICS_CMPL_SCHD 
INSERT INTO [ICS_FLOW_ICIS].[ICS_CMPL_SCHD]
     SELECT ICS_CMPL_SCHD.*
        from [ICS_FLOW_LOCAL].[ICS_CMPL_SCHD] [ICS_CMPL_SCHD] 
 
       WHERE ICS_CMPL_SCHD.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceScheduleSubmission')
								  
	    AND ICS_CMPL_SCHD.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_CMPL_SCHD/ICS_CMPL_SCHD_EVT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_CMPL_SCHD_EVT]
     SELECT I1.*
        from [ICS_FLOW_LOCAL].[ICS_CMPL_SCHD] [ICS_CMPL_SCHD] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CMPL_SCHD_EVT] [I1]
 ON [I1].[ICS_CMPL_SCHD_ID] = [ICS_CMPL_SCHD].[ICS_CMPL_SCHD_ID] 
 
       WHERE ICS_CMPL_SCHD.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceScheduleSubmission')
								  
	    AND ICS_CMPL_SCHD.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

					
				
	

-- ================================================================
-- ICS_COPY_MGP_LMT_SET 
-- ================================================================
			
				-- DELETES for: ICS_COPY_MGP_LMT_SET 
				
								
-- /ICS_COPY_MGP_LMT_SET/ICS_LMT_SET_STAT
DELETE I3
 from ICS_FLOW_ICIS.[ICS_COPY_MGP_LMT_SET] [ICS_COPY_MGP_LMT_SET] 
 JOIN ICS_FLOW_ICIS.[ICS_LMT_SET_STAT] [I3]
 ON [I3].[ICS_COPY_MGP_LMT_SET_ID] = [ICS_COPY_MGP_LMT_SET].[ICS_COPY_MGP_LMT_SET_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_COPY_MGP_LMT_SET.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CopyMGPLimitSetSubmission')
				
                  OR ICS_COPY_MGP_LMT_SET.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_COPY_MGP_LMT_SET/ICS_LMT_SET_SCHD
DELETE I2
 from ICS_FLOW_ICIS.[ICS_COPY_MGP_LMT_SET] [ICS_COPY_MGP_LMT_SET] 
 JOIN ICS_FLOW_ICIS.[ICS_LMT_SET_SCHD] [I2]
 ON [I2].[ICS_COPY_MGP_LMT_SET_ID] = [ICS_COPY_MGP_LMT_SET].[ICS_COPY_MGP_LMT_SET_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_COPY_MGP_LMT_SET.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CopyMGPLimitSetSubmission')
				
                  OR ICS_COPY_MGP_LMT_SET.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_COPY_MGP_LMT_SET/ICS_GEO_COORD
DELETE I1
 from ICS_FLOW_ICIS.[ICS_COPY_MGP_LMT_SET] [ICS_COPY_MGP_LMT_SET] 
 JOIN ICS_FLOW_ICIS.[ICS_GEO_COORD] [I1]
 ON [I1].[ICS_COPY_MGP_LMT_SET_ID] = [ICS_COPY_MGP_LMT_SET].[ICS_COPY_MGP_LMT_SET_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_COPY_MGP_LMT_SET.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CopyMGPLimitSetSubmission')
				
                  OR ICS_COPY_MGP_LMT_SET.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_COPY_MGP_LMT_SET
DELETE ICS_COPY_MGP_LMT_SET
 from ICS_FLOW_ICIS.[ICS_COPY_MGP_LMT_SET] [ICS_COPY_MGP_LMT_SET] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_COPY_MGP_LMT_SET.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CopyMGPLimitSetSubmission')
				
                  OR ICS_COPY_MGP_LMT_SET.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
					

				-- INSERTS for: ICS_COPY_MGP_LMT_SET
	
				
-- /ICS_COPY_MGP_LMT_SET 
INSERT INTO [ICS_FLOW_ICIS].[ICS_COPY_MGP_LMT_SET]
     SELECT ICS_COPY_MGP_LMT_SET.*
        from [ICS_FLOW_LOCAL].[ICS_COPY_MGP_LMT_SET] [ICS_COPY_MGP_LMT_SET] 
 
       WHERE ICS_COPY_MGP_LMT_SET.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CopyMGPLimitSetSubmission')
								  
	    AND ICS_COPY_MGP_LMT_SET.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_COPY_MGP_LMT_SET/ICS_GEO_COORD 
INSERT INTO [ICS_FLOW_ICIS].[ICS_GEO_COORD]
     SELECT I1.*
        from [ICS_FLOW_LOCAL].[ICS_COPY_MGP_LMT_SET] [ICS_COPY_MGP_LMT_SET] 
 JOIN [ICS_FLOW_LOCAL].[ICS_GEO_COORD] [I1]
 ON [I1].[ICS_COPY_MGP_LMT_SET_ID] = [ICS_COPY_MGP_LMT_SET].[ICS_COPY_MGP_LMT_SET_ID] 
 
       WHERE ICS_COPY_MGP_LMT_SET.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CopyMGPLimitSetSubmission')
								  
	    AND ICS_COPY_MGP_LMT_SET.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_COPY_MGP_LMT_SET/ICS_LMT_SET_SCHD 
INSERT INTO [ICS_FLOW_ICIS].[ICS_LMT_SET_SCHD]
     SELECT I2.*
        from [ICS_FLOW_LOCAL].[ICS_COPY_MGP_LMT_SET] [ICS_COPY_MGP_LMT_SET] 
 JOIN [ICS_FLOW_LOCAL].[ICS_LMT_SET_SCHD] [I2]
 ON [I2].[ICS_COPY_MGP_LMT_SET_ID] = [ICS_COPY_MGP_LMT_SET].[ICS_COPY_MGP_LMT_SET_ID] 
 
       WHERE ICS_COPY_MGP_LMT_SET.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CopyMGPLimitSetSubmission')
								  
	    AND ICS_COPY_MGP_LMT_SET.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_COPY_MGP_LMT_SET/ICS_LMT_SET_STAT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_LMT_SET_STAT]
     SELECT I3.*
        from [ICS_FLOW_LOCAL].[ICS_COPY_MGP_LMT_SET] [ICS_COPY_MGP_LMT_SET] 
 JOIN [ICS_FLOW_LOCAL].[ICS_LMT_SET_STAT] [I3]
 ON [I3].[ICS_COPY_MGP_LMT_SET_ID] = [ICS_COPY_MGP_LMT_SET].[ICS_COPY_MGP_LMT_SET_ID] 
 
       WHERE ICS_COPY_MGP_LMT_SET.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CopyMGPLimitSetSubmission')
								  
	    AND ICS_COPY_MGP_LMT_SET.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

					
				
	

-- ================================================================
-- ICS_COPY_MGPMS_4_REQ 
-- ================================================================
			
				-- DELETES for: ICS_COPY_MGPMS_4_REQ 
				
								
-- /ICS_COPY_MGPMS_4_REQ/ICS_MS_4_ACTY_IDENT
DELETE I3
 from ICS_FLOW_ICIS.[ICS_COPY_MGPMS_4_REQ] [ICS_COPY_MGPMS_4_REQ] 
 JOIN ICS_FLOW_ICIS.[ICS_MS_4_ACTY_IDENT] [I3]
 ON [I3].[ICS_COPY_MGPMS_4_REQ_ID] = [ICS_COPY_MGPMS_4_REQ].[ICS_COPY_MGPMS_4_REQ_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_COPY_MGPMS_4_REQ.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CopyMGPMS4RequirementSubmission')
				  ;
          				
				
								
-- /ICS_COPY_MGPMS_4_REQ/ICS_GNRL_PRMT_COVERAGE_MS_4_REQ/ICS_MS_4_REGULATED_ENTITY_IDENT
DELETE I2
 from ICS_FLOW_ICIS.[ICS_COPY_MGPMS_4_REQ] [ICS_COPY_MGPMS_4_REQ] 
 JOIN ICS_FLOW_ICIS.[ICS_GNRL_PRMT_COVERAGE_MS_4_REQ] [I1]
 ON [I1].[ICS_COPY_MGPMS_4_REQ_ID] = [ICS_COPY_MGPMS_4_REQ].[ICS_COPY_MGPMS_4_REQ_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_MS_4_REGULATED_ENTITY_IDENT] [I2]
 ON [I2].[ICS_GNRL_PRMT_COVERAGE_MS_4_REQ_ID] = [I1].[ICS_GNRL_PRMT_COVERAGE_MS_4_REQ_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_COPY_MGPMS_4_REQ.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CopyMGPMS4RequirementSubmission')
				  ;
          				
				
								
-- /ICS_COPY_MGPMS_4_REQ/ICS_GNRL_PRMT_COVERAGE_MS_4_REQ
DELETE I1
 from ICS_FLOW_ICIS.[ICS_COPY_MGPMS_4_REQ] [ICS_COPY_MGPMS_4_REQ] 
 JOIN ICS_FLOW_ICIS.[ICS_GNRL_PRMT_COVERAGE_MS_4_REQ] [I1]
 ON [I1].[ICS_COPY_MGPMS_4_REQ_ID] = [ICS_COPY_MGPMS_4_REQ].[ICS_COPY_MGPMS_4_REQ_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_COPY_MGPMS_4_REQ.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CopyMGPMS4RequirementSubmission')
				  ;
          				
				
								
-- /ICS_COPY_MGPMS_4_REQ
DELETE ICS_COPY_MGPMS_4_REQ
 from ICS_FLOW_ICIS.[ICS_COPY_MGPMS_4_REQ] [ICS_COPY_MGPMS_4_REQ] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_COPY_MGPMS_4_REQ.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CopyMGPMS4RequirementSubmission')
				  ;
          				
				
					

				-- INSERTS for: ICS_COPY_MGPMS_4_REQ
	
				
-- /ICS_COPY_MGPMS_4_REQ 
INSERT INTO [ICS_FLOW_ICIS].[ICS_COPY_MGPMS_4_REQ]
     SELECT ICS_COPY_MGPMS_4_REQ.*
        from [ICS_FLOW_LOCAL].[ICS_COPY_MGPMS_4_REQ] [ICS_COPY_MGPMS_4_REQ] 
 
       WHERE ICS_COPY_MGPMS_4_REQ.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CopyMGPMS4RequirementSubmission')
				 
				  ;			 

				
-- /ICS_COPY_MGPMS_4_REQ/ICS_GNRL_PRMT_COVERAGE_MS_4_REQ 
INSERT INTO [ICS_FLOW_ICIS].[ICS_GNRL_PRMT_COVERAGE_MS_4_REQ]
     SELECT I1.*
        from [ICS_FLOW_LOCAL].[ICS_COPY_MGPMS_4_REQ] [ICS_COPY_MGPMS_4_REQ] 
 JOIN [ICS_FLOW_LOCAL].[ICS_GNRL_PRMT_COVERAGE_MS_4_REQ] [I1]
 ON [I1].[ICS_COPY_MGPMS_4_REQ_ID] = [ICS_COPY_MGPMS_4_REQ].[ICS_COPY_MGPMS_4_REQ_ID] 
 
       WHERE ICS_COPY_MGPMS_4_REQ.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CopyMGPMS4RequirementSubmission')
				 
				  ;			 

				
-- /ICS_COPY_MGPMS_4_REQ/ICS_GNRL_PRMT_COVERAGE_MS_4_REQ/ICS_MS_4_REGULATED_ENTITY_IDENT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_MS_4_REGULATED_ENTITY_IDENT]
     SELECT I2.*
        from [ICS_FLOW_LOCAL].[ICS_COPY_MGPMS_4_REQ] [ICS_COPY_MGPMS_4_REQ] 
 JOIN [ICS_FLOW_LOCAL].[ICS_GNRL_PRMT_COVERAGE_MS_4_REQ] [I1]
 ON [I1].[ICS_COPY_MGPMS_4_REQ_ID] = [ICS_COPY_MGPMS_4_REQ].[ICS_COPY_MGPMS_4_REQ_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_REGULATED_ENTITY_IDENT] [I2]
 ON [I2].[ICS_GNRL_PRMT_COVERAGE_MS_4_REQ_ID] = [I1].[ICS_GNRL_PRMT_COVERAGE_MS_4_REQ_ID] 
 
       WHERE ICS_COPY_MGPMS_4_REQ.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CopyMGPMS4RequirementSubmission')
				 
				  ;			 

				
-- /ICS_COPY_MGPMS_4_REQ/ICS_MS_4_ACTY_IDENT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_MS_4_ACTY_IDENT]
     SELECT I3.*
        from [ICS_FLOW_LOCAL].[ICS_COPY_MGPMS_4_REQ] [ICS_COPY_MGPMS_4_REQ] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_ACTY_IDENT] [I3]
 ON [I3].[ICS_COPY_MGPMS_4_REQ_ID] = [ICS_COPY_MGPMS_4_REQ].[ICS_COPY_MGPMS_4_REQ_ID] 
 
       WHERE ICS_COPY_MGPMS_4_REQ.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CopyMGPMS4RequirementSubmission')
				 
				  ;			 

					
				
	

-- ================================================================
-- ICS_CSO_LONG_TERM_CONTROL_PLAN 
-- ================================================================
			
				-- DELETES for: ICS_CSO_LONG_TERM_CONTROL_PLAN 
				
								
-- /ICS_CSO_LONG_TERM_CONTROL_PLAN/ICS_LTCP_SUMM
DELETE I4
 from ICS_FLOW_ICIS.[ICS_CSO_LONG_TERM_CONTROL_PLAN] [ICS_CSO_LONG_TERM_CONTROL_PLAN] 
 JOIN ICS_FLOW_ICIS.[ICS_LTCP_SUMM] [I4]
 ON [I4].[ICS_CSO_LONG_TERM_CONTROL_PLAN_ID] = [ICS_CSO_LONG_TERM_CONTROL_PLAN].[ICS_CSO_LONG_TERM_CONTROL_PLAN_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CSO_LONG_TERM_CONTROL_PLAN.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CSOLongTermControlPlanSubmission')
				
                  OR ICS_CSO_LONG_TERM_CONTROL_PLAN.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_CSO_LONG_TERM_CONTROL_PLAN/ICS_LTCP_MOST_RECENT_REVISION_DETAIL
DELETE I3
 from ICS_FLOW_ICIS.[ICS_CSO_LONG_TERM_CONTROL_PLAN] [ICS_CSO_LONG_TERM_CONTROL_PLAN] 
 JOIN ICS_FLOW_ICIS.[ICS_LTCP_MOST_RECENT_REVISION_DETAIL] [I3]
 ON [I3].[ICS_CSO_LONG_TERM_CONTROL_PLAN_ID] = [ICS_CSO_LONG_TERM_CONTROL_PLAN].[ICS_CSO_LONG_TERM_CONTROL_PLAN_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CSO_LONG_TERM_CONTROL_PLAN.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CSOLongTermControlPlanSubmission')
				
                  OR ICS_CSO_LONG_TERM_CONTROL_PLAN.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_CSO_LONG_TERM_CONTROL_PLAN/ICS_LTCP_ENFORCEABLE_MECH_DETAIL
DELETE I2
 from ICS_FLOW_ICIS.[ICS_CSO_LONG_TERM_CONTROL_PLAN] [ICS_CSO_LONG_TERM_CONTROL_PLAN] 
 JOIN ICS_FLOW_ICIS.[ICS_LTCP_ENFORCEABLE_MECH_DETAIL] [I2]
 ON [I2].[ICS_CSO_LONG_TERM_CONTROL_PLAN_ID] = [ICS_CSO_LONG_TERM_CONTROL_PLAN].[ICS_CSO_LONG_TERM_CONTROL_PLAN_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CSO_LONG_TERM_CONTROL_PLAN.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CSOLongTermControlPlanSubmission')
				
                  OR ICS_CSO_LONG_TERM_CONTROL_PLAN.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_CSO_LONG_TERM_CONTROL_PLAN/ICS_CSO_CONTROL_MEAS_DETAIL
DELETE I1
 from ICS_FLOW_ICIS.[ICS_CSO_LONG_TERM_CONTROL_PLAN] [ICS_CSO_LONG_TERM_CONTROL_PLAN] 
 JOIN ICS_FLOW_ICIS.[ICS_CSO_CONTROL_MEAS_DETAIL] [I1]
 ON [I1].[ICS_CSO_LONG_TERM_CONTROL_PLAN_ID] = [ICS_CSO_LONG_TERM_CONTROL_PLAN].[ICS_CSO_LONG_TERM_CONTROL_PLAN_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CSO_LONG_TERM_CONTROL_PLAN.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CSOLongTermControlPlanSubmission')
				
                  OR ICS_CSO_LONG_TERM_CONTROL_PLAN.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_CSO_LONG_TERM_CONTROL_PLAN
DELETE ICS_CSO_LONG_TERM_CONTROL_PLAN
 from ICS_FLOW_ICIS.[ICS_CSO_LONG_TERM_CONTROL_PLAN] [ICS_CSO_LONG_TERM_CONTROL_PLAN] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CSO_LONG_TERM_CONTROL_PLAN.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CSOLongTermControlPlanSubmission')
				
                  OR ICS_CSO_LONG_TERM_CONTROL_PLAN.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
					

				-- INSERTS for: ICS_CSO_LONG_TERM_CONTROL_PLAN
	
				
-- /ICS_CSO_LONG_TERM_CONTROL_PLAN 
INSERT INTO [ICS_FLOW_ICIS].[ICS_CSO_LONG_TERM_CONTROL_PLAN]
     SELECT ICS_CSO_LONG_TERM_CONTROL_PLAN.*
        from [ICS_FLOW_LOCAL].[ICS_CSO_LONG_TERM_CONTROL_PLAN] [ICS_CSO_LONG_TERM_CONTROL_PLAN] 
 
       WHERE ICS_CSO_LONG_TERM_CONTROL_PLAN.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CSOLongTermControlPlanSubmission')
								  
	    AND ICS_CSO_LONG_TERM_CONTROL_PLAN.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_CSO_LONG_TERM_CONTROL_PLAN/ICS_CSO_CONTROL_MEAS_DETAIL 
INSERT INTO [ICS_FLOW_ICIS].[ICS_CSO_CONTROL_MEAS_DETAIL]
     SELECT I1.*
        from [ICS_FLOW_LOCAL].[ICS_CSO_LONG_TERM_CONTROL_PLAN] [ICS_CSO_LONG_TERM_CONTROL_PLAN] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CSO_CONTROL_MEAS_DETAIL] [I1]
 ON [I1].[ICS_CSO_LONG_TERM_CONTROL_PLAN_ID] = [ICS_CSO_LONG_TERM_CONTROL_PLAN].[ICS_CSO_LONG_TERM_CONTROL_PLAN_ID] 
 
       WHERE ICS_CSO_LONG_TERM_CONTROL_PLAN.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CSOLongTermControlPlanSubmission')
								  
	    AND ICS_CSO_LONG_TERM_CONTROL_PLAN.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_CSO_LONG_TERM_CONTROL_PLAN/ICS_LTCP_ENFORCEABLE_MECH_DETAIL 
INSERT INTO [ICS_FLOW_ICIS].[ICS_LTCP_ENFORCEABLE_MECH_DETAIL]
     SELECT I2.*
        from [ICS_FLOW_LOCAL].[ICS_CSO_LONG_TERM_CONTROL_PLAN] [ICS_CSO_LONG_TERM_CONTROL_PLAN] 
 JOIN [ICS_FLOW_LOCAL].[ICS_LTCP_ENFORCEABLE_MECH_DETAIL] [I2]
 ON [I2].[ICS_CSO_LONG_TERM_CONTROL_PLAN_ID] = [ICS_CSO_LONG_TERM_CONTROL_PLAN].[ICS_CSO_LONG_TERM_CONTROL_PLAN_ID] 
 
       WHERE ICS_CSO_LONG_TERM_CONTROL_PLAN.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CSOLongTermControlPlanSubmission')
								  
	    AND ICS_CSO_LONG_TERM_CONTROL_PLAN.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_CSO_LONG_TERM_CONTROL_PLAN/ICS_LTCP_MOST_RECENT_REVISION_DETAIL 
INSERT INTO [ICS_FLOW_ICIS].[ICS_LTCP_MOST_RECENT_REVISION_DETAIL]
     SELECT I3.*
        from [ICS_FLOW_LOCAL].[ICS_CSO_LONG_TERM_CONTROL_PLAN] [ICS_CSO_LONG_TERM_CONTROL_PLAN] 
 JOIN [ICS_FLOW_LOCAL].[ICS_LTCP_MOST_RECENT_REVISION_DETAIL] [I3]
 ON [I3].[ICS_CSO_LONG_TERM_CONTROL_PLAN_ID] = [ICS_CSO_LONG_TERM_CONTROL_PLAN].[ICS_CSO_LONG_TERM_CONTROL_PLAN_ID] 
 
       WHERE ICS_CSO_LONG_TERM_CONTROL_PLAN.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CSOLongTermControlPlanSubmission')
								  
	    AND ICS_CSO_LONG_TERM_CONTROL_PLAN.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_CSO_LONG_TERM_CONTROL_PLAN/ICS_LTCP_SUMM 
INSERT INTO [ICS_FLOW_ICIS].[ICS_LTCP_SUMM]
     SELECT I4.*
        from [ICS_FLOW_LOCAL].[ICS_CSO_LONG_TERM_CONTROL_PLAN] [ICS_CSO_LONG_TERM_CONTROL_PLAN] 
 JOIN [ICS_FLOW_LOCAL].[ICS_LTCP_SUMM] [I4]
 ON [I4].[ICS_CSO_LONG_TERM_CONTROL_PLAN_ID] = [ICS_CSO_LONG_TERM_CONTROL_PLAN].[ICS_CSO_LONG_TERM_CONTROL_PLAN_ID] 
 
       WHERE ICS_CSO_LONG_TERM_CONTROL_PLAN.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CSOLongTermControlPlanSubmission')
								  
	    AND ICS_CSO_LONG_TERM_CONTROL_PLAN.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

					
				
	

-- ================================================================
-- ICS_CWA_316B_PROG_REP 
-- ================================================================
			
				-- DELETES for: ICS_CWA_316B_PROG_REP 
				
								
-- /ICS_CWA_316B_PROG_REP/ICS_CWA_316B_TAKE_INFO
DELETE I1
 from ICS_FLOW_ICIS.[ICS_CWA_316B_PROG_REP] [ICS_CWA_316B_PROG_REP] 
 JOIN ICS_FLOW_ICIS.[ICS_CWA_316B_TAKE_INFO] [I1]
 ON [I1].[ICS_CWA_316B_PROG_REP_ID] = [ICS_CWA_316B_PROG_REP].[ICS_CWA_316B_PROG_REP_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CWA_316B_PROG_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CWA316bProgramReportSubmission')
				
                  OR ICS_CWA_316B_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_CWA_316B_PROG_REP
DELETE ICS_CWA_316B_PROG_REP
 from ICS_FLOW_ICIS.[ICS_CWA_316B_PROG_REP] [ICS_CWA_316B_PROG_REP] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CWA_316B_PROG_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CWA316bProgramReportSubmission')
				
                  OR ICS_CWA_316B_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
					

				-- INSERTS for: ICS_CWA_316B_PROG_REP
	
				
-- /ICS_CWA_316B_PROG_REP 
INSERT INTO [ICS_FLOW_ICIS].[ICS_CWA_316B_PROG_REP]
     SELECT ICS_CWA_316B_PROG_REP.*
        from [ICS_FLOW_LOCAL].[ICS_CWA_316B_PROG_REP] [ICS_CWA_316B_PROG_REP] 
 
       WHERE ICS_CWA_316B_PROG_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CWA316bProgramReportSubmission')
								  
	    AND ICS_CWA_316B_PROG_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_CWA_316B_PROG_REP/ICS_CWA_316B_TAKE_INFO 
INSERT INTO [ICS_FLOW_ICIS].[ICS_CWA_316B_TAKE_INFO]
     SELECT I1.*
        from [ICS_FLOW_LOCAL].[ICS_CWA_316B_PROG_REP] [ICS_CWA_316B_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CWA_316B_TAKE_INFO] [I1]
 ON [I1].[ICS_CWA_316B_PROG_REP_ID] = [ICS_CWA_316B_PROG_REP].[ICS_CWA_316B_PROG_REP_ID] 
 
       WHERE ICS_CWA_316B_PROG_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CWA316bProgramReportSubmission')
								  
	    AND ICS_CWA_316B_PROG_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

					
				
	

-- ================================================================
-- ICS_DSCH_MON_REP 
-- ================================================================
			
				-- DELETES for: ICS_DSCH_MON_REP 
				
								
-- /ICS_DSCH_MON_REP/ICS_CO_DSPL_SITE
DELETE I8
 from ICS_FLOW_ICIS.[ICS_DSCH_MON_REP] [ICS_DSCH_MON_REP] 
 JOIN ICS_FLOW_ICIS.[ICS_CO_DSPL_SITE] [I8]
 ON [I8].[ICS_DSCH_MON_REP_ID] = [ICS_DSCH_MON_REP].[ICS_DSCH_MON_REP_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_DSCH_MON_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'DischargeMonitoringReportSubmission')
				
                  OR ICS_DSCH_MON_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_DSCH_MON_REP/ICS_SURF_DSPL_SITE
DELETE I7
 from ICS_FLOW_ICIS.[ICS_DSCH_MON_REP] [ICS_DSCH_MON_REP] 
 JOIN ICS_FLOW_ICIS.[ICS_SURF_DSPL_SITE] [I7]
 ON [I7].[ICS_DSCH_MON_REP_ID] = [ICS_DSCH_MON_REP].[ICS_DSCH_MON_REP_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_DSCH_MON_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'DischargeMonitoringReportSubmission')
				
                  OR ICS_DSCH_MON_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_DSCH_MON_REP/ICS_LAND_APPL_SITE/ICS_CROP_TYPES_PLANTED
DELETE I6
 from ICS_FLOW_ICIS.[ICS_DSCH_MON_REP] [ICS_DSCH_MON_REP] 
 JOIN ICS_FLOW_ICIS.[ICS_LAND_APPL_SITE] [I4]
 ON [I4].[ICS_DSCH_MON_REP_ID] = [ICS_DSCH_MON_REP].[ICS_DSCH_MON_REP_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_CROP_TYPES_PLANTED] [I6]
 ON [I6].[ICS_LAND_APPL_SITE_ID] = [I4].[ICS_LAND_APPL_SITE_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_DSCH_MON_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'DischargeMonitoringReportSubmission')
				
                  OR ICS_DSCH_MON_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_DSCH_MON_REP/ICS_LAND_APPL_SITE/ICS_CROP_TYPES_HARVESTED
DELETE I5
 from ICS_FLOW_ICIS.[ICS_DSCH_MON_REP] [ICS_DSCH_MON_REP] 
 JOIN ICS_FLOW_ICIS.[ICS_LAND_APPL_SITE] [I4]
 ON [I4].[ICS_DSCH_MON_REP_ID] = [ICS_DSCH_MON_REP].[ICS_DSCH_MON_REP_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_CROP_TYPES_HARVESTED] [I5]
 ON [I5].[ICS_LAND_APPL_SITE_ID] = [I4].[ICS_LAND_APPL_SITE_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_DSCH_MON_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'DischargeMonitoringReportSubmission')
				
                  OR ICS_DSCH_MON_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_DSCH_MON_REP/ICS_LAND_APPL_SITE
DELETE I4
 from ICS_FLOW_ICIS.[ICS_DSCH_MON_REP] [ICS_DSCH_MON_REP] 
 JOIN ICS_FLOW_ICIS.[ICS_LAND_APPL_SITE] [I4]
 ON [I4].[ICS_DSCH_MON_REP_ID] = [ICS_DSCH_MON_REP].[ICS_DSCH_MON_REP_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_DSCH_MON_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'DischargeMonitoringReportSubmission')
				
                  OR ICS_DSCH_MON_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_DSCH_MON_REP/ICS_INCIN
DELETE I3
 from ICS_FLOW_ICIS.[ICS_DSCH_MON_REP] [ICS_DSCH_MON_REP] 
 JOIN ICS_FLOW_ICIS.[ICS_INCIN] [I3]
 ON [I3].[ICS_DSCH_MON_REP_ID] = [ICS_DSCH_MON_REP].[ICS_DSCH_MON_REP_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_DSCH_MON_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'DischargeMonitoringReportSubmission')
				
                  OR ICS_DSCH_MON_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_DSCH_MON_REP/ICS_REP_PARAM/ICS_NUM_REP
DELETE I2
 from ICS_FLOW_ICIS.[ICS_DSCH_MON_REP] [ICS_DSCH_MON_REP] 
 JOIN ICS_FLOW_ICIS.[ICS_REP_PARAM] [I1]
 ON [I1].[ICS_DSCH_MON_REP_ID] = [ICS_DSCH_MON_REP].[ICS_DSCH_MON_REP_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_NUM_REP] [I2]
 ON [I2].[ICS_REP_PARAM_ID] = [I1].[ICS_REP_PARAM_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_DSCH_MON_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'DischargeMonitoringReportSubmission')
				
                  OR ICS_DSCH_MON_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_DSCH_MON_REP/ICS_REP_PARAM
DELETE I1
 from ICS_FLOW_ICIS.[ICS_DSCH_MON_REP] [ICS_DSCH_MON_REP] 
 JOIN ICS_FLOW_ICIS.[ICS_REP_PARAM] [I1]
 ON [I1].[ICS_DSCH_MON_REP_ID] = [ICS_DSCH_MON_REP].[ICS_DSCH_MON_REP_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_DSCH_MON_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'DischargeMonitoringReportSubmission')
				
                  OR ICS_DSCH_MON_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_DSCH_MON_REP
DELETE ICS_DSCH_MON_REP
 from ICS_FLOW_ICIS.[ICS_DSCH_MON_REP] [ICS_DSCH_MON_REP] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_DSCH_MON_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'DischargeMonitoringReportSubmission')
				
                  OR ICS_DSCH_MON_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
					

				-- INSERTS for: ICS_DSCH_MON_REP
	
				
-- /ICS_DSCH_MON_REP 
INSERT INTO [ICS_FLOW_ICIS].[ICS_DSCH_MON_REP]
     SELECT ICS_DSCH_MON_REP.*
        from [ICS_FLOW_LOCAL].[ICS_DSCH_MON_REP] [ICS_DSCH_MON_REP] 
 
       WHERE ICS_DSCH_MON_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'DischargeMonitoringReportSubmission')
								  
	    AND ICS_DSCH_MON_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_DSCH_MON_REP/ICS_REP_PARAM 
INSERT INTO [ICS_FLOW_ICIS].[ICS_REP_PARAM]
     SELECT I1.*
        from [ICS_FLOW_LOCAL].[ICS_DSCH_MON_REP] [ICS_DSCH_MON_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_REP_PARAM] [I1]
 ON [I1].[ICS_DSCH_MON_REP_ID] = [ICS_DSCH_MON_REP].[ICS_DSCH_MON_REP_ID] 
 
       WHERE ICS_DSCH_MON_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'DischargeMonitoringReportSubmission')
								  
	    AND ICS_DSCH_MON_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_DSCH_MON_REP/ICS_REP_PARAM/ICS_NUM_REP 
INSERT INTO [ICS_FLOW_ICIS].[ICS_NUM_REP]
     SELECT I2.*
        from [ICS_FLOW_LOCAL].[ICS_DSCH_MON_REP] [ICS_DSCH_MON_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_REP_PARAM] [I1]
 ON [I1].[ICS_DSCH_MON_REP_ID] = [ICS_DSCH_MON_REP].[ICS_DSCH_MON_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_NUM_REP] [I2]
 ON [I2].[ICS_REP_PARAM_ID] = [I1].[ICS_REP_PARAM_ID] 
 
       WHERE ICS_DSCH_MON_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'DischargeMonitoringReportSubmission')
								  
	    AND ICS_DSCH_MON_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_DSCH_MON_REP/ICS_INCIN 
INSERT INTO [ICS_FLOW_ICIS].[ICS_INCIN]
     SELECT I3.*
        from [ICS_FLOW_LOCAL].[ICS_DSCH_MON_REP] [ICS_DSCH_MON_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_INCIN] [I3]
 ON [I3].[ICS_DSCH_MON_REP_ID] = [ICS_DSCH_MON_REP].[ICS_DSCH_MON_REP_ID] 
 
       WHERE ICS_DSCH_MON_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'DischargeMonitoringReportSubmission')
								  
	    AND ICS_DSCH_MON_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_DSCH_MON_REP/ICS_LAND_APPL_SITE 
INSERT INTO [ICS_FLOW_ICIS].[ICS_LAND_APPL_SITE]
     SELECT I4.*
        from [ICS_FLOW_LOCAL].[ICS_DSCH_MON_REP] [ICS_DSCH_MON_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_LAND_APPL_SITE] [I4]
 ON [I4].[ICS_DSCH_MON_REP_ID] = [ICS_DSCH_MON_REP].[ICS_DSCH_MON_REP_ID] 
 
       WHERE ICS_DSCH_MON_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'DischargeMonitoringReportSubmission')
								  
	    AND ICS_DSCH_MON_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_DSCH_MON_REP/ICS_LAND_APPL_SITE/ICS_CROP_TYPES_HARVESTED 
INSERT INTO [ICS_FLOW_ICIS].[ICS_CROP_TYPES_HARVESTED]
     SELECT I5.*
        from [ICS_FLOW_LOCAL].[ICS_DSCH_MON_REP] [ICS_DSCH_MON_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_LAND_APPL_SITE] [I4]
 ON [I4].[ICS_DSCH_MON_REP_ID] = [ICS_DSCH_MON_REP].[ICS_DSCH_MON_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CROP_TYPES_HARVESTED] [I5]
 ON [I5].[ICS_LAND_APPL_SITE_ID] = [I4].[ICS_LAND_APPL_SITE_ID] 
 
       WHERE ICS_DSCH_MON_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'DischargeMonitoringReportSubmission')
								  
	    AND ICS_DSCH_MON_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_DSCH_MON_REP/ICS_LAND_APPL_SITE/ICS_CROP_TYPES_PLANTED 
INSERT INTO [ICS_FLOW_ICIS].[ICS_CROP_TYPES_PLANTED]
     SELECT I6.*
        from [ICS_FLOW_LOCAL].[ICS_DSCH_MON_REP] [ICS_DSCH_MON_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_LAND_APPL_SITE] [I4]
 ON [I4].[ICS_DSCH_MON_REP_ID] = [ICS_DSCH_MON_REP].[ICS_DSCH_MON_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CROP_TYPES_PLANTED] [I6]
 ON [I6].[ICS_LAND_APPL_SITE_ID] = [I4].[ICS_LAND_APPL_SITE_ID] 
 
       WHERE ICS_DSCH_MON_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'DischargeMonitoringReportSubmission')
								  
	    AND ICS_DSCH_MON_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_DSCH_MON_REP/ICS_SURF_DSPL_SITE 
INSERT INTO [ICS_FLOW_ICIS].[ICS_SURF_DSPL_SITE]
     SELECT I7.*
        from [ICS_FLOW_LOCAL].[ICS_DSCH_MON_REP] [ICS_DSCH_MON_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SURF_DSPL_SITE] [I7]
 ON [I7].[ICS_DSCH_MON_REP_ID] = [ICS_DSCH_MON_REP].[ICS_DSCH_MON_REP_ID] 
 
       WHERE ICS_DSCH_MON_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'DischargeMonitoringReportSubmission')
								  
	    AND ICS_DSCH_MON_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_DSCH_MON_REP/ICS_CO_DSPL_SITE 
INSERT INTO [ICS_FLOW_ICIS].[ICS_CO_DSPL_SITE]
     SELECT I8.*
        from [ICS_FLOW_LOCAL].[ICS_DSCH_MON_REP] [ICS_DSCH_MON_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CO_DSPL_SITE] [I8]
 ON [I8].[ICS_DSCH_MON_REP_ID] = [ICS_DSCH_MON_REP].[ICS_DSCH_MON_REP_ID] 
 
       WHERE ICS_DSCH_MON_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'DischargeMonitoringReportSubmission')
								  
	    AND ICS_DSCH_MON_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

					
				
	

-- ================================================================
-- ICS_DMR_VIOL 
-- ================================================================
			
				-- DELETES for: ICS_DMR_VIOL 
				
								
-- /ICS_DMR_VIOL
DELETE ICS_DMR_VIOL
 from ICS_FLOW_ICIS.[ICS_DMR_VIOL] [ICS_DMR_VIOL] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_DMR_VIOL.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'DMRViolationSubmission')
				
                  OR ICS_DMR_VIOL.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
					

				-- INSERTS for: ICS_DMR_VIOL
	
				
-- /ICS_DMR_VIOL 
INSERT INTO [ICS_FLOW_ICIS].[ICS_DMR_VIOL]
     SELECT ICS_DMR_VIOL.*
        from [ICS_FLOW_LOCAL].[ICS_DMR_VIOL] [ICS_DMR_VIOL] 
 
       WHERE ICS_DMR_VIOL.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'DMRViolationSubmission')
								  
	    AND ICS_DMR_VIOL.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

					
				
	

-- ================================================================
-- ICS_EFFLU_TRADE_PRTNER 
-- ================================================================
			
				-- DELETES for: ICS_EFFLU_TRADE_PRTNER 
				
								
-- /ICS_EFFLU_TRADE_PRTNER/ICS_EFFLU_TRADE_PRTNER_ADDR/ICS_TELEPH
DELETE I2
 from ICS_FLOW_ICIS.[ICS_EFFLU_TRADE_PRTNER] [ICS_EFFLU_TRADE_PRTNER] 
 JOIN ICS_FLOW_ICIS.[ICS_EFFLU_TRADE_PRTNER_ADDR] [I1]
 ON [I1].[ICS_EFFLU_TRADE_PRTNER_ID] = [ICS_EFFLU_TRADE_PRTNER].[ICS_EFFLU_TRADE_PRTNER_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_TELEPH] [I2]
 ON [I2].[ICS_EFFLU_TRADE_PRTNER_ADDR_ID] = [I1].[ICS_EFFLU_TRADE_PRTNER_ADDR_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_EFFLU_TRADE_PRTNER.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'EffluentTradePartnerSubmission')
				
                  OR ICS_EFFLU_TRADE_PRTNER.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_EFFLU_TRADE_PRTNER/ICS_EFFLU_TRADE_PRTNER_ADDR
DELETE I1
 from ICS_FLOW_ICIS.[ICS_EFFLU_TRADE_PRTNER] [ICS_EFFLU_TRADE_PRTNER] 
 JOIN ICS_FLOW_ICIS.[ICS_EFFLU_TRADE_PRTNER_ADDR] [I1]
 ON [I1].[ICS_EFFLU_TRADE_PRTNER_ID] = [ICS_EFFLU_TRADE_PRTNER].[ICS_EFFLU_TRADE_PRTNER_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_EFFLU_TRADE_PRTNER.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'EffluentTradePartnerSubmission')
				
                  OR ICS_EFFLU_TRADE_PRTNER.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_EFFLU_TRADE_PRTNER
DELETE ICS_EFFLU_TRADE_PRTNER
 from ICS_FLOW_ICIS.[ICS_EFFLU_TRADE_PRTNER] [ICS_EFFLU_TRADE_PRTNER] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_EFFLU_TRADE_PRTNER.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'EffluentTradePartnerSubmission')
				
                  OR ICS_EFFLU_TRADE_PRTNER.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
					

				-- INSERTS for: ICS_EFFLU_TRADE_PRTNER
	
				
-- /ICS_EFFLU_TRADE_PRTNER 
INSERT INTO [ICS_FLOW_ICIS].[ICS_EFFLU_TRADE_PRTNER]
     SELECT ICS_EFFLU_TRADE_PRTNER.*
        from [ICS_FLOW_LOCAL].[ICS_EFFLU_TRADE_PRTNER] [ICS_EFFLU_TRADE_PRTNER] 
 
       WHERE ICS_EFFLU_TRADE_PRTNER.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'EffluentTradePartnerSubmission')
								  
	    AND ICS_EFFLU_TRADE_PRTNER.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_EFFLU_TRADE_PRTNER/ICS_EFFLU_TRADE_PRTNER_ADDR 
INSERT INTO [ICS_FLOW_ICIS].[ICS_EFFLU_TRADE_PRTNER_ADDR]
     SELECT I1.*
        from [ICS_FLOW_LOCAL].[ICS_EFFLU_TRADE_PRTNER] [ICS_EFFLU_TRADE_PRTNER] 
 JOIN [ICS_FLOW_LOCAL].[ICS_EFFLU_TRADE_PRTNER_ADDR] [I1]
 ON [I1].[ICS_EFFLU_TRADE_PRTNER_ID] = [ICS_EFFLU_TRADE_PRTNER].[ICS_EFFLU_TRADE_PRTNER_ID] 
 
       WHERE ICS_EFFLU_TRADE_PRTNER.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'EffluentTradePartnerSubmission')
								  
	    AND ICS_EFFLU_TRADE_PRTNER.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_EFFLU_TRADE_PRTNER/ICS_EFFLU_TRADE_PRTNER_ADDR/ICS_TELEPH 
INSERT INTO [ICS_FLOW_ICIS].[ICS_TELEPH]
     SELECT I2.*
        from [ICS_FLOW_LOCAL].[ICS_EFFLU_TRADE_PRTNER] [ICS_EFFLU_TRADE_PRTNER] 
 JOIN [ICS_FLOW_LOCAL].[ICS_EFFLU_TRADE_PRTNER_ADDR] [I1]
 ON [I1].[ICS_EFFLU_TRADE_PRTNER_ID] = [ICS_EFFLU_TRADE_PRTNER].[ICS_EFFLU_TRADE_PRTNER_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_TELEPH] [I2]
 ON [I2].[ICS_EFFLU_TRADE_PRTNER_ADDR_ID] = [I1].[ICS_EFFLU_TRADE_PRTNER_ADDR_ID] 
 
       WHERE ICS_EFFLU_TRADE_PRTNER.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'EffluentTradePartnerSubmission')
								  
	    AND ICS_EFFLU_TRADE_PRTNER.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

					
				
	

-- ================================================================
-- ICS_ENFRC_ACTN_MILESTONE 
-- ================================================================
			
				-- DELETES for: ICS_ENFRC_ACTN_MILESTONE 
				
								
-- /ICS_ENFRC_ACTN_MILESTONE
DELETE ICS_ENFRC_ACTN_MILESTONE
 from ICS_FLOW_ICIS.[ICS_ENFRC_ACTN_MILESTONE] [ICS_ENFRC_ACTN_MILESTONE] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_ENFRC_ACTN_MILESTONE.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'EnforcementActionMilestoneSubmission')
				  ;
          				
				
					

				-- INSERTS for: ICS_ENFRC_ACTN_MILESTONE
	
				
-- /ICS_ENFRC_ACTN_MILESTONE 
INSERT INTO [ICS_FLOW_ICIS].[ICS_ENFRC_ACTN_MILESTONE]
     SELECT ICS_ENFRC_ACTN_MILESTONE.*
        from [ICS_FLOW_LOCAL].[ICS_ENFRC_ACTN_MILESTONE] [ICS_ENFRC_ACTN_MILESTONE] 
 
       WHERE ICS_ENFRC_ACTN_MILESTONE.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'EnforcementActionMilestoneSubmission')
				 
				  ;			 

					
				
	

-- ================================================================
-- ICS_ENFRC_ACTN_VIOL_LNK 
-- ================================================================
			
				-- DELETES for: ICS_ENFRC_ACTN_VIOL_LNK 
				
								
-- /ICS_ENFRC_ACTN_VIOL_LNK/ICS_CMPL_SCHD_VIOL
DELETE I5
 from ICS_FLOW_ICIS.[ICS_ENFRC_ACTN_VIOL_LNK] [ICS_ENFRC_ACTN_VIOL_LNK] 
 JOIN ICS_FLOW_ICIS.[ICS_CMPL_SCHD_VIOL] [I5]
 ON [I5].[ICS_ENFRC_ACTN_VIOL_LNK_ID] = [ICS_ENFRC_ACTN_VIOL_LNK].[ICS_ENFRC_ACTN_VIOL_LNK_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_ENFRC_ACTN_VIOL_LNK.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'EnforcementActionViolationLinkageSubmission')
				  ;
          				
				
								
-- /ICS_ENFRC_ACTN_VIOL_LNK/ICS_SNGL_EVTS_VIOL
DELETE I4
 from ICS_FLOW_ICIS.[ICS_ENFRC_ACTN_VIOL_LNK] [ICS_ENFRC_ACTN_VIOL_LNK] 
 JOIN ICS_FLOW_ICIS.[ICS_SNGL_EVTS_VIOL] [I4]
 ON [I4].[ICS_ENFRC_ACTN_VIOL_LNK_ID] = [ICS_ENFRC_ACTN_VIOL_LNK].[ICS_ENFRC_ACTN_VIOL_LNK_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_ENFRC_ACTN_VIOL_LNK.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'EnforcementActionViolationLinkageSubmission')
				  ;
          				
				
								
-- /ICS_ENFRC_ACTN_VIOL_LNK/ICS_PRMT_SCHD_VIOL
DELETE I3
 from ICS_FLOW_ICIS.[ICS_ENFRC_ACTN_VIOL_LNK] [ICS_ENFRC_ACTN_VIOL_LNK] 
 JOIN ICS_FLOW_ICIS.[ICS_PRMT_SCHD_VIOL] [I3]
 ON [I3].[ICS_ENFRC_ACTN_VIOL_LNK_ID] = [ICS_ENFRC_ACTN_VIOL_LNK].[ICS_ENFRC_ACTN_VIOL_LNK_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_ENFRC_ACTN_VIOL_LNK.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'EnforcementActionViolationLinkageSubmission')
				  ;
          				
				
								
-- /ICS_ENFRC_ACTN_VIOL_LNK/ICS_DSCH_MON_REP_VIOL
DELETE I2
 from ICS_FLOW_ICIS.[ICS_ENFRC_ACTN_VIOL_LNK] [ICS_ENFRC_ACTN_VIOL_LNK] 
 JOIN ICS_FLOW_ICIS.[ICS_DSCH_MON_REP_VIOL] [I2]
 ON [I2].[ICS_ENFRC_ACTN_VIOL_LNK_ID] = [ICS_ENFRC_ACTN_VIOL_LNK].[ICS_ENFRC_ACTN_VIOL_LNK_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_ENFRC_ACTN_VIOL_LNK.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'EnforcementActionViolationLinkageSubmission')
				  ;
          				
				
								
-- /ICS_ENFRC_ACTN_VIOL_LNK/ICS_DSCH_MON_REP_PARAM_VIOL
DELETE I1
 from ICS_FLOW_ICIS.[ICS_ENFRC_ACTN_VIOL_LNK] [ICS_ENFRC_ACTN_VIOL_LNK] 
 JOIN ICS_FLOW_ICIS.[ICS_DSCH_MON_REP_PARAM_VIOL] [I1]
 ON [I1].[ICS_ENFRC_ACTN_VIOL_LNK_ID] = [ICS_ENFRC_ACTN_VIOL_LNK].[ICS_ENFRC_ACTN_VIOL_LNK_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_ENFRC_ACTN_VIOL_LNK.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'EnforcementActionViolationLinkageSubmission')
				  ;
          				
				
								
-- /ICS_ENFRC_ACTN_VIOL_LNK
DELETE ICS_ENFRC_ACTN_VIOL_LNK
 from ICS_FLOW_ICIS.[ICS_ENFRC_ACTN_VIOL_LNK] [ICS_ENFRC_ACTN_VIOL_LNK] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_ENFRC_ACTN_VIOL_LNK.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'EnforcementActionViolationLinkageSubmission')
				  ;
          				
				
					

				-- INSERTS for: ICS_ENFRC_ACTN_VIOL_LNK
	
				
-- /ICS_ENFRC_ACTN_VIOL_LNK 
INSERT INTO [ICS_FLOW_ICIS].[ICS_ENFRC_ACTN_VIOL_LNK]
     SELECT ICS_ENFRC_ACTN_VIOL_LNK.*
        from [ICS_FLOW_LOCAL].[ICS_ENFRC_ACTN_VIOL_LNK] [ICS_ENFRC_ACTN_VIOL_LNK] 
 
       WHERE ICS_ENFRC_ACTN_VIOL_LNK.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'EnforcementActionViolationLinkageSubmission')
				 
				  ;			 

				
-- /ICS_ENFRC_ACTN_VIOL_LNK/ICS_DSCH_MON_REP_PARAM_VIOL 
INSERT INTO [ICS_FLOW_ICIS].[ICS_DSCH_MON_REP_PARAM_VIOL]
     SELECT I1.*
        from [ICS_FLOW_LOCAL].[ICS_ENFRC_ACTN_VIOL_LNK] [ICS_ENFRC_ACTN_VIOL_LNK] 
 JOIN [ICS_FLOW_LOCAL].[ICS_DSCH_MON_REP_PARAM_VIOL] [I1]
 ON [I1].[ICS_ENFRC_ACTN_VIOL_LNK_ID] = [ICS_ENFRC_ACTN_VIOL_LNK].[ICS_ENFRC_ACTN_VIOL_LNK_ID] 
 
       WHERE ICS_ENFRC_ACTN_VIOL_LNK.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'EnforcementActionViolationLinkageSubmission')
				 
				  ;			 

				
-- /ICS_ENFRC_ACTN_VIOL_LNK/ICS_DSCH_MON_REP_VIOL 
INSERT INTO [ICS_FLOW_ICIS].[ICS_DSCH_MON_REP_VIOL]
     SELECT I2.*
        from [ICS_FLOW_LOCAL].[ICS_ENFRC_ACTN_VIOL_LNK] [ICS_ENFRC_ACTN_VIOL_LNK] 
 JOIN [ICS_FLOW_LOCAL].[ICS_DSCH_MON_REP_VIOL] [I2]
 ON [I2].[ICS_ENFRC_ACTN_VIOL_LNK_ID] = [ICS_ENFRC_ACTN_VIOL_LNK].[ICS_ENFRC_ACTN_VIOL_LNK_ID] 
 
       WHERE ICS_ENFRC_ACTN_VIOL_LNK.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'EnforcementActionViolationLinkageSubmission')
				 
				  ;			 

				
-- /ICS_ENFRC_ACTN_VIOL_LNK/ICS_PRMT_SCHD_VIOL 
INSERT INTO [ICS_FLOW_ICIS].[ICS_PRMT_SCHD_VIOL]
     SELECT I3.*
        from [ICS_FLOW_LOCAL].[ICS_ENFRC_ACTN_VIOL_LNK] [ICS_ENFRC_ACTN_VIOL_LNK] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PRMT_SCHD_VIOL] [I3]
 ON [I3].[ICS_ENFRC_ACTN_VIOL_LNK_ID] = [ICS_ENFRC_ACTN_VIOL_LNK].[ICS_ENFRC_ACTN_VIOL_LNK_ID] 
 
       WHERE ICS_ENFRC_ACTN_VIOL_LNK.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'EnforcementActionViolationLinkageSubmission')
				 
				  ;			 

				
-- /ICS_ENFRC_ACTN_VIOL_LNK/ICS_SNGL_EVTS_VIOL 
INSERT INTO [ICS_FLOW_ICIS].[ICS_SNGL_EVTS_VIOL]
     SELECT I4.*
        from [ICS_FLOW_LOCAL].[ICS_ENFRC_ACTN_VIOL_LNK] [ICS_ENFRC_ACTN_VIOL_LNK] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SNGL_EVTS_VIOL] [I4]
 ON [I4].[ICS_ENFRC_ACTN_VIOL_LNK_ID] = [ICS_ENFRC_ACTN_VIOL_LNK].[ICS_ENFRC_ACTN_VIOL_LNK_ID] 
 
       WHERE ICS_ENFRC_ACTN_VIOL_LNK.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'EnforcementActionViolationLinkageSubmission')
				 
				  ;			 

				
-- /ICS_ENFRC_ACTN_VIOL_LNK/ICS_CMPL_SCHD_VIOL 
INSERT INTO [ICS_FLOW_ICIS].[ICS_CMPL_SCHD_VIOL]
     SELECT I5.*
        from [ICS_FLOW_LOCAL].[ICS_ENFRC_ACTN_VIOL_LNK] [ICS_ENFRC_ACTN_VIOL_LNK] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CMPL_SCHD_VIOL] [I5]
 ON [I5].[ICS_ENFRC_ACTN_VIOL_LNK_ID] = [ICS_ENFRC_ACTN_VIOL_LNK].[ICS_ENFRC_ACTN_VIOL_LNK_ID] 
 
       WHERE ICS_ENFRC_ACTN_VIOL_LNK.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'EnforcementActionViolationLinkageSubmission')
				 
				  ;			 

					
				
	

-- ================================================================
-- ICS_FINAL_ORDER_VIOL_LNK 
-- ================================================================
			
				-- DELETES for: ICS_FINAL_ORDER_VIOL_LNK 
				
								
-- /ICS_FINAL_ORDER_VIOL_LNK/ICS_CMPL_SCHD_VIOL
DELETE I5
 from ICS_FLOW_ICIS.[ICS_FINAL_ORDER_VIOL_LNK] [ICS_FINAL_ORDER_VIOL_LNK] 
 JOIN ICS_FLOW_ICIS.[ICS_CMPL_SCHD_VIOL] [I5]
 ON [I5].[ICS_FINAL_ORDER_VIOL_LNK_ID] = [ICS_FINAL_ORDER_VIOL_LNK].[ICS_FINAL_ORDER_VIOL_LNK_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_FINAL_ORDER_VIOL_LNK.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'FinalOrderViolationLinkageSubmission')
				  ;
          				
				
								
-- /ICS_FINAL_ORDER_VIOL_LNK/ICS_SNGL_EVTS_VIOL
DELETE I4
 from ICS_FLOW_ICIS.[ICS_FINAL_ORDER_VIOL_LNK] [ICS_FINAL_ORDER_VIOL_LNK] 
 JOIN ICS_FLOW_ICIS.[ICS_SNGL_EVTS_VIOL] [I4]
 ON [I4].[ICS_FINAL_ORDER_VIOL_LNK_ID] = [ICS_FINAL_ORDER_VIOL_LNK].[ICS_FINAL_ORDER_VIOL_LNK_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_FINAL_ORDER_VIOL_LNK.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'FinalOrderViolationLinkageSubmission')
				  ;
          				
				
								
-- /ICS_FINAL_ORDER_VIOL_LNK/ICS_PRMT_SCHD_VIOL
DELETE I3
 from ICS_FLOW_ICIS.[ICS_FINAL_ORDER_VIOL_LNK] [ICS_FINAL_ORDER_VIOL_LNK] 
 JOIN ICS_FLOW_ICIS.[ICS_PRMT_SCHD_VIOL] [I3]
 ON [I3].[ICS_FINAL_ORDER_VIOL_LNK_ID] = [ICS_FINAL_ORDER_VIOL_LNK].[ICS_FINAL_ORDER_VIOL_LNK_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_FINAL_ORDER_VIOL_LNK.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'FinalOrderViolationLinkageSubmission')
				  ;
          				
				
								
-- /ICS_FINAL_ORDER_VIOL_LNK/ICS_DSCH_MON_REP_VIOL
DELETE I2
 from ICS_FLOW_ICIS.[ICS_FINAL_ORDER_VIOL_LNK] [ICS_FINAL_ORDER_VIOL_LNK] 
 JOIN ICS_FLOW_ICIS.[ICS_DSCH_MON_REP_VIOL] [I2]
 ON [I2].[ICS_FINAL_ORDER_VIOL_LNK_ID] = [ICS_FINAL_ORDER_VIOL_LNK].[ICS_FINAL_ORDER_VIOL_LNK_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_FINAL_ORDER_VIOL_LNK.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'FinalOrderViolationLinkageSubmission')
				  ;
          				
				
								
-- /ICS_FINAL_ORDER_VIOL_LNK/ICS_DSCH_MON_REP_PARAM_VIOL
DELETE I1
 from ICS_FLOW_ICIS.[ICS_FINAL_ORDER_VIOL_LNK] [ICS_FINAL_ORDER_VIOL_LNK] 
 JOIN ICS_FLOW_ICIS.[ICS_DSCH_MON_REP_PARAM_VIOL] [I1]
 ON [I1].[ICS_FINAL_ORDER_VIOL_LNK_ID] = [ICS_FINAL_ORDER_VIOL_LNK].[ICS_FINAL_ORDER_VIOL_LNK_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_FINAL_ORDER_VIOL_LNK.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'FinalOrderViolationLinkageSubmission')
				  ;
          				
				
								
-- /ICS_FINAL_ORDER_VIOL_LNK
DELETE ICS_FINAL_ORDER_VIOL_LNK
 from ICS_FLOW_ICIS.[ICS_FINAL_ORDER_VIOL_LNK] [ICS_FINAL_ORDER_VIOL_LNK] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_FINAL_ORDER_VIOL_LNK.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'FinalOrderViolationLinkageSubmission')
				  ;
          				
				
					

				-- INSERTS for: ICS_FINAL_ORDER_VIOL_LNK
	
				
-- /ICS_FINAL_ORDER_VIOL_LNK 
INSERT INTO [ICS_FLOW_ICIS].[ICS_FINAL_ORDER_VIOL_LNK]
     SELECT ICS_FINAL_ORDER_VIOL_LNK.*
        from [ICS_FLOW_LOCAL].[ICS_FINAL_ORDER_VIOL_LNK] [ICS_FINAL_ORDER_VIOL_LNK] 
 
       WHERE ICS_FINAL_ORDER_VIOL_LNK.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'FinalOrderViolationLinkageSubmission')
				 
				  ;			 

				
-- /ICS_FINAL_ORDER_VIOL_LNK/ICS_DSCH_MON_REP_PARAM_VIOL 
INSERT INTO [ICS_FLOW_ICIS].[ICS_DSCH_MON_REP_PARAM_VIOL]
     SELECT I1.*
        from [ICS_FLOW_LOCAL].[ICS_FINAL_ORDER_VIOL_LNK] [ICS_FINAL_ORDER_VIOL_LNK] 
 JOIN [ICS_FLOW_LOCAL].[ICS_DSCH_MON_REP_PARAM_VIOL] [I1]
 ON [I1].[ICS_FINAL_ORDER_VIOL_LNK_ID] = [ICS_FINAL_ORDER_VIOL_LNK].[ICS_FINAL_ORDER_VIOL_LNK_ID] 
 
       WHERE ICS_FINAL_ORDER_VIOL_LNK.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'FinalOrderViolationLinkageSubmission')
				 
				  ;			 

				
-- /ICS_FINAL_ORDER_VIOL_LNK/ICS_DSCH_MON_REP_VIOL 
INSERT INTO [ICS_FLOW_ICIS].[ICS_DSCH_MON_REP_VIOL]
     SELECT I2.*
        from [ICS_FLOW_LOCAL].[ICS_FINAL_ORDER_VIOL_LNK] [ICS_FINAL_ORDER_VIOL_LNK] 
 JOIN [ICS_FLOW_LOCAL].[ICS_DSCH_MON_REP_VIOL] [I2]
 ON [I2].[ICS_FINAL_ORDER_VIOL_LNK_ID] = [ICS_FINAL_ORDER_VIOL_LNK].[ICS_FINAL_ORDER_VIOL_LNK_ID] 
 
       WHERE ICS_FINAL_ORDER_VIOL_LNK.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'FinalOrderViolationLinkageSubmission')
				 
				  ;			 

				
-- /ICS_FINAL_ORDER_VIOL_LNK/ICS_PRMT_SCHD_VIOL 
INSERT INTO [ICS_FLOW_ICIS].[ICS_PRMT_SCHD_VIOL]
     SELECT I3.*
        from [ICS_FLOW_LOCAL].[ICS_FINAL_ORDER_VIOL_LNK] [ICS_FINAL_ORDER_VIOL_LNK] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PRMT_SCHD_VIOL] [I3]
 ON [I3].[ICS_FINAL_ORDER_VIOL_LNK_ID] = [ICS_FINAL_ORDER_VIOL_LNK].[ICS_FINAL_ORDER_VIOL_LNK_ID] 
 
       WHERE ICS_FINAL_ORDER_VIOL_LNK.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'FinalOrderViolationLinkageSubmission')
				 
				  ;			 

				
-- /ICS_FINAL_ORDER_VIOL_LNK/ICS_SNGL_EVTS_VIOL 
INSERT INTO [ICS_FLOW_ICIS].[ICS_SNGL_EVTS_VIOL]
     SELECT I4.*
        from [ICS_FLOW_LOCAL].[ICS_FINAL_ORDER_VIOL_LNK] [ICS_FINAL_ORDER_VIOL_LNK] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SNGL_EVTS_VIOL] [I4]
 ON [I4].[ICS_FINAL_ORDER_VIOL_LNK_ID] = [ICS_FINAL_ORDER_VIOL_LNK].[ICS_FINAL_ORDER_VIOL_LNK_ID] 
 
       WHERE ICS_FINAL_ORDER_VIOL_LNK.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'FinalOrderViolationLinkageSubmission')
				 
				  ;			 

				
-- /ICS_FINAL_ORDER_VIOL_LNK/ICS_CMPL_SCHD_VIOL 
INSERT INTO [ICS_FLOW_ICIS].[ICS_CMPL_SCHD_VIOL]
     SELECT I5.*
        from [ICS_FLOW_LOCAL].[ICS_FINAL_ORDER_VIOL_LNK] [ICS_FINAL_ORDER_VIOL_LNK] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CMPL_SCHD_VIOL] [I5]
 ON [I5].[ICS_FINAL_ORDER_VIOL_LNK_ID] = [ICS_FINAL_ORDER_VIOL_LNK].[ICS_FINAL_ORDER_VIOL_LNK_ID] 
 
       WHERE ICS_FINAL_ORDER_VIOL_LNK.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'FinalOrderViolationLinkageSubmission')
				 
				  ;			 

					
				
	

-- ================================================================
-- ICS_FRML_ENFRC_ACTN 
-- ================================================================
			
				-- DELETES for: ICS_FRML_ENFRC_ACTN 
				
								
-- /ICS_FRML_ENFRC_ACTN/ICS_FINAL_ORDER/ICS_SEP
DELETE I8
 from ICS_FLOW_ICIS.[ICS_FRML_ENFRC_ACTN] [ICS_FRML_ENFRC_ACTN] 
 JOIN ICS_FLOW_ICIS.[ICS_FINAL_ORDER] [I6]
 ON [I6].[ICS_FRML_ENFRC_ACTN_ID] = [ICS_FRML_ENFRC_ACTN].[ICS_FRML_ENFRC_ACTN_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_SEP] [I8]
 ON [I8].[ICS_FINAL_ORDER_ID] = [I6].[ICS_FINAL_ORDER_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_FRML_ENFRC_ACTN.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'FormalEnforcementActionSubmission')
				  ;
          				
				
								
-- /ICS_FRML_ENFRC_ACTN/ICS_FINAL_ORDER/ICS_FINAL_ORDER_PRMT_IDENT
DELETE I7
 from ICS_FLOW_ICIS.[ICS_FRML_ENFRC_ACTN] [ICS_FRML_ENFRC_ACTN] 
 JOIN ICS_FLOW_ICIS.[ICS_FINAL_ORDER] [I6]
 ON [I6].[ICS_FRML_ENFRC_ACTN_ID] = [ICS_FRML_ENFRC_ACTN].[ICS_FRML_ENFRC_ACTN_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_FINAL_ORDER_PRMT_IDENT] [I7]
 ON [I7].[ICS_FINAL_ORDER_ID] = [I6].[ICS_FINAL_ORDER_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_FRML_ENFRC_ACTN.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'FormalEnforcementActionSubmission')
				  ;
          				
				
								
-- /ICS_FRML_ENFRC_ACTN/ICS_FINAL_ORDER
DELETE I6
 from ICS_FLOW_ICIS.[ICS_FRML_ENFRC_ACTN] [ICS_FRML_ENFRC_ACTN] 
 JOIN ICS_FLOW_ICIS.[ICS_FINAL_ORDER] [I6]
 ON [I6].[ICS_FRML_ENFRC_ACTN_ID] = [ICS_FRML_ENFRC_ACTN].[ICS_FRML_ENFRC_ACTN_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_FRML_ENFRC_ACTN.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'FormalEnforcementActionSubmission')
				  ;
          				
				
								
-- /ICS_FRML_ENFRC_ACTN/ICS_PROGS_VIOL
DELETE I5
 from ICS_FLOW_ICIS.[ICS_FRML_ENFRC_ACTN] [ICS_FRML_ENFRC_ACTN] 
 JOIN ICS_FLOW_ICIS.[ICS_PROGS_VIOL] [I5]
 ON [I5].[ICS_FRML_ENFRC_ACTN_ID] = [ICS_FRML_ENFRC_ACTN].[ICS_FRML_ENFRC_ACTN_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_FRML_ENFRC_ACTN.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'FormalEnforcementActionSubmission')
				  ;
          				
				
								
-- /ICS_FRML_ENFRC_ACTN/ICS_ENFRC_AGNCY
DELETE I4
 from ICS_FLOW_ICIS.[ICS_FRML_ENFRC_ACTN] [ICS_FRML_ENFRC_ACTN] 
 JOIN ICS_FLOW_ICIS.[ICS_ENFRC_AGNCY] [I4]
 ON [I4].[ICS_FRML_ENFRC_ACTN_ID] = [ICS_FRML_ENFRC_ACTN].[ICS_FRML_ENFRC_ACTN_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_FRML_ENFRC_ACTN.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'FormalEnforcementActionSubmission')
				  ;
          				
				
								
-- /ICS_FRML_ENFRC_ACTN/ICS_ENFRC_ACTN_TYPE
DELETE I3
 from ICS_FLOW_ICIS.[ICS_FRML_ENFRC_ACTN] [ICS_FRML_ENFRC_ACTN] 
 JOIN ICS_FLOW_ICIS.[ICS_ENFRC_ACTN_TYPE] [I3]
 ON [I3].[ICS_FRML_ENFRC_ACTN_ID] = [ICS_FRML_ENFRC_ACTN].[ICS_FRML_ENFRC_ACTN_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_FRML_ENFRC_ACTN.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'FormalEnforcementActionSubmission')
				  ;
          				
				
								
-- /ICS_FRML_ENFRC_ACTN/ICS_ENFRC_ACTN_GOV_CONTACT
DELETE I2
 from ICS_FLOW_ICIS.[ICS_FRML_ENFRC_ACTN] [ICS_FRML_ENFRC_ACTN] 
 JOIN ICS_FLOW_ICIS.[ICS_ENFRC_ACTN_GOV_CONTACT] [I2]
 ON [I2].[ICS_FRML_ENFRC_ACTN_ID] = [ICS_FRML_ENFRC_ACTN].[ICS_FRML_ENFRC_ACTN_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_FRML_ENFRC_ACTN.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'FormalEnforcementActionSubmission')
				  ;
          				
				
								
-- /ICS_FRML_ENFRC_ACTN/ICS_PRMT_IDENT
DELETE I1
 from ICS_FLOW_ICIS.[ICS_FRML_ENFRC_ACTN] [ICS_FRML_ENFRC_ACTN] 
 JOIN ICS_FLOW_ICIS.[ICS_PRMT_IDENT] [I1]
 ON [I1].[ICS_FRML_ENFRC_ACTN_ID] = [ICS_FRML_ENFRC_ACTN].[ICS_FRML_ENFRC_ACTN_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_FRML_ENFRC_ACTN.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'FormalEnforcementActionSubmission')
				  ;
          				
				
								
-- /ICS_FRML_ENFRC_ACTN
DELETE ICS_FRML_ENFRC_ACTN
 from ICS_FLOW_ICIS.[ICS_FRML_ENFRC_ACTN] [ICS_FRML_ENFRC_ACTN] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_FRML_ENFRC_ACTN.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'FormalEnforcementActionSubmission')
				  ;
          				
				
					

				-- INSERTS for: ICS_FRML_ENFRC_ACTN
	
				
-- /ICS_FRML_ENFRC_ACTN 
INSERT INTO [ICS_FLOW_ICIS].[ICS_FRML_ENFRC_ACTN]
     SELECT ICS_FRML_ENFRC_ACTN.*
        from [ICS_FLOW_LOCAL].[ICS_FRML_ENFRC_ACTN] [ICS_FRML_ENFRC_ACTN] 
 
       WHERE ICS_FRML_ENFRC_ACTN.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'FormalEnforcementActionSubmission')
				 
				  ;			 

				
-- /ICS_FRML_ENFRC_ACTN/ICS_PRMT_IDENT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_PRMT_IDENT]
     SELECT I1.*
        from [ICS_FLOW_LOCAL].[ICS_FRML_ENFRC_ACTN] [ICS_FRML_ENFRC_ACTN] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PRMT_IDENT] [I1]
 ON [I1].[ICS_FRML_ENFRC_ACTN_ID] = [ICS_FRML_ENFRC_ACTN].[ICS_FRML_ENFRC_ACTN_ID] 
 
       WHERE ICS_FRML_ENFRC_ACTN.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'FormalEnforcementActionSubmission')
				 
				  ;			 

				
-- /ICS_FRML_ENFRC_ACTN/ICS_ENFRC_ACTN_GOV_CONTACT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_ENFRC_ACTN_GOV_CONTACT]
     SELECT I2.*
        from [ICS_FLOW_LOCAL].[ICS_FRML_ENFRC_ACTN] [ICS_FRML_ENFRC_ACTN] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ENFRC_ACTN_GOV_CONTACT] [I2]
 ON [I2].[ICS_FRML_ENFRC_ACTN_ID] = [ICS_FRML_ENFRC_ACTN].[ICS_FRML_ENFRC_ACTN_ID] 
 
       WHERE ICS_FRML_ENFRC_ACTN.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'FormalEnforcementActionSubmission')
				 
				  ;			 

				
-- /ICS_FRML_ENFRC_ACTN/ICS_ENFRC_ACTN_TYPE 
INSERT INTO [ICS_FLOW_ICIS].[ICS_ENFRC_ACTN_TYPE]
     SELECT I3.*
        from [ICS_FLOW_LOCAL].[ICS_FRML_ENFRC_ACTN] [ICS_FRML_ENFRC_ACTN] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ENFRC_ACTN_TYPE] [I3]
 ON [I3].[ICS_FRML_ENFRC_ACTN_ID] = [ICS_FRML_ENFRC_ACTN].[ICS_FRML_ENFRC_ACTN_ID] 
 
       WHERE ICS_FRML_ENFRC_ACTN.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'FormalEnforcementActionSubmission')
				 
				  ;			 

				
-- /ICS_FRML_ENFRC_ACTN/ICS_ENFRC_AGNCY 
INSERT INTO [ICS_FLOW_ICIS].[ICS_ENFRC_AGNCY]
     SELECT I4.*
        from [ICS_FLOW_LOCAL].[ICS_FRML_ENFRC_ACTN] [ICS_FRML_ENFRC_ACTN] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ENFRC_AGNCY] [I4]
 ON [I4].[ICS_FRML_ENFRC_ACTN_ID] = [ICS_FRML_ENFRC_ACTN].[ICS_FRML_ENFRC_ACTN_ID] 
 
       WHERE ICS_FRML_ENFRC_ACTN.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'FormalEnforcementActionSubmission')
				 
				  ;			 

				
-- /ICS_FRML_ENFRC_ACTN/ICS_PROGS_VIOL 
INSERT INTO [ICS_FLOW_ICIS].[ICS_PROGS_VIOL]
     SELECT I5.*
        from [ICS_FLOW_LOCAL].[ICS_FRML_ENFRC_ACTN] [ICS_FRML_ENFRC_ACTN] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PROGS_VIOL] [I5]
 ON [I5].[ICS_FRML_ENFRC_ACTN_ID] = [ICS_FRML_ENFRC_ACTN].[ICS_FRML_ENFRC_ACTN_ID] 
 
       WHERE ICS_FRML_ENFRC_ACTN.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'FormalEnforcementActionSubmission')
				 
				  ;			 

				
-- /ICS_FRML_ENFRC_ACTN/ICS_FINAL_ORDER 
INSERT INTO [ICS_FLOW_ICIS].[ICS_FINAL_ORDER]
     SELECT I6.*
        from [ICS_FLOW_LOCAL].[ICS_FRML_ENFRC_ACTN] [ICS_FRML_ENFRC_ACTN] 
 JOIN [ICS_FLOW_LOCAL].[ICS_FINAL_ORDER] [I6]
 ON [I6].[ICS_FRML_ENFRC_ACTN_ID] = [ICS_FRML_ENFRC_ACTN].[ICS_FRML_ENFRC_ACTN_ID] 
 
       WHERE ICS_FRML_ENFRC_ACTN.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'FormalEnforcementActionSubmission')
				 
				  ;			 

				
-- /ICS_FRML_ENFRC_ACTN/ICS_FINAL_ORDER/ICS_FINAL_ORDER_PRMT_IDENT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_FINAL_ORDER_PRMT_IDENT]
     SELECT I7.*
        from [ICS_FLOW_LOCAL].[ICS_FRML_ENFRC_ACTN] [ICS_FRML_ENFRC_ACTN] 
 JOIN [ICS_FLOW_LOCAL].[ICS_FINAL_ORDER] [I6]
 ON [I6].[ICS_FRML_ENFRC_ACTN_ID] = [ICS_FRML_ENFRC_ACTN].[ICS_FRML_ENFRC_ACTN_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_FINAL_ORDER_PRMT_IDENT] [I7]
 ON [I7].[ICS_FINAL_ORDER_ID] = [I6].[ICS_FINAL_ORDER_ID] 
 
       WHERE ICS_FRML_ENFRC_ACTN.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'FormalEnforcementActionSubmission')
				 
				  ;			 

				
-- /ICS_FRML_ENFRC_ACTN/ICS_FINAL_ORDER/ICS_SEP 
INSERT INTO [ICS_FLOW_ICIS].[ICS_SEP]
     SELECT I8.*
        from [ICS_FLOW_LOCAL].[ICS_FRML_ENFRC_ACTN] [ICS_FRML_ENFRC_ACTN] 
 JOIN [ICS_FLOW_LOCAL].[ICS_FINAL_ORDER] [I6]
 ON [I6].[ICS_FRML_ENFRC_ACTN_ID] = [ICS_FRML_ENFRC_ACTN].[ICS_FRML_ENFRC_ACTN_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SEP] [I8]
 ON [I8].[ICS_FINAL_ORDER_ID] = [I6].[ICS_FINAL_ORDER_ID] 
 
       WHERE ICS_FRML_ENFRC_ACTN.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'FormalEnforcementActionSubmission')
				 
				  ;			 

					
				
	

-- ================================================================
-- ICS_GNRL_PRMT 
-- ================================================================
			
				-- DELETES for: ICS_GNRL_PRMT 
				
								
-- /ICS_GNRL_PRMT/ICS_CMPL_TRACK_STAT
DELETE I24
 from ICS_FLOW_ICIS.[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_CMPL_TRACK_STAT] [I24]
 ON [I24].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'GeneralPermitSubmission')
				
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_GNRL_PRMT/ICS_ASSC_PRMT
DELETE I23
 from ICS_FLOW_ICIS.[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_ASSC_PRMT] [I23]
 ON [I23].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'GeneralPermitSubmission')
				
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_GNRL_PRMT/ICS_ADDR/ICS_TELEPH
DELETE I22
 from ICS_FLOW_ICIS.[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_ADDR] [I21]
 ON [I21].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_TELEPH] [I22]
 ON [I22].[ICS_ADDR_ID] = [I21].[ICS_ADDR_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'GeneralPermitSubmission')
				
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_GNRL_PRMT/ICS_ADDR
DELETE I21
 from ICS_FLOW_ICIS.[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_ADDR] [I21]
 ON [I21].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'GeneralPermitSubmission')
				
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_GNRL_PRMT/ICS_SIC_CODE
DELETE I20
 from ICS_FLOW_ICIS.[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_SIC_CODE] [I20]
 ON [I20].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'GeneralPermitSubmission')
				
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_GNRL_PRMT/ICS_RESIDUAL_DESGN_DTRMN
DELETE I19
 from ICS_FLOW_ICIS.[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_RESIDUAL_DESGN_DTRMN] [I19]
 ON [I19].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'GeneralPermitSubmission')
				
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_GNRL_PRMT/ICS_REP_NON_CMPL_STAT
DELETE I18
 from ICS_FLOW_ICIS.[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_REP_NON_CMPL_STAT] [I18]
 ON [I18].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'GeneralPermitSubmission')
				
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_GNRL_PRMT/ICS_FAC/ICS_NAICS_CODE
DELETE I17
 from ICS_FLOW_ICIS.[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_FAC] [I7]
 ON [I7].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_NAICS_CODE] [I17]
 ON [I17].[ICS_FAC_ID] = [I7].[ICS_FAC_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'GeneralPermitSubmission')
				
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_GNRL_PRMT/ICS_FAC/ICS_ADDR/ICS_TELEPH
DELETE I16
 from ICS_FLOW_ICIS.[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_FAC] [I7]
 ON [I7].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_ADDR] [I15]
 ON [I15].[ICS_FAC_ID] = [I7].[ICS_FAC_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_TELEPH] [I16]
 ON [I16].[ICS_ADDR_ID] = [I15].[ICS_ADDR_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'GeneralPermitSubmission')
				
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_GNRL_PRMT/ICS_FAC/ICS_ADDR
DELETE I15
 from ICS_FLOW_ICIS.[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_FAC] [I7]
 ON [I7].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_ADDR] [I15]
 ON [I15].[ICS_FAC_ID] = [I7].[ICS_FAC_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'GeneralPermitSubmission')
				
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_GNRL_PRMT/ICS_FAC/ICS_SIC_CODE
DELETE I14
 from ICS_FLOW_ICIS.[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_FAC] [I7]
 ON [I7].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_SIC_CODE] [I14]
 ON [I14].[ICS_FAC_ID] = [I7].[ICS_FAC_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'GeneralPermitSubmission')
				
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_GNRL_PRMT/ICS_FAC/ICS_GEO_COORD
DELETE I13
 from ICS_FLOW_ICIS.[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_FAC] [I7]
 ON [I7].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_GEO_COORD] [I13]
 ON [I13].[ICS_FAC_ID] = [I7].[ICS_FAC_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'GeneralPermitSubmission')
				
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_GNRL_PRMT/ICS_FAC/ICS_FAC_CLASS
DELETE I12
 from ICS_FLOW_ICIS.[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_FAC] [I7]
 ON [I7].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_FAC_CLASS] [I12]
 ON [I12].[ICS_FAC_ID] = [I7].[ICS_FAC_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'GeneralPermitSubmission')
				
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_GNRL_PRMT/ICS_FAC/ICS_PLCY
DELETE I11
 from ICS_FLOW_ICIS.[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_FAC] [I7]
 ON [I7].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_PLCY] [I11]
 ON [I11].[ICS_FAC_ID] = [I7].[ICS_FAC_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'GeneralPermitSubmission')
				
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_GNRL_PRMT/ICS_FAC/ICS_ORIG_PROGS
DELETE I10
 from ICS_FLOW_ICIS.[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_FAC] [I7]
 ON [I7].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_ORIG_PROGS] [I10]
 ON [I10].[ICS_FAC_ID] = [I7].[ICS_FAC_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'GeneralPermitSubmission')
				
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_GNRL_PRMT/ICS_FAC/ICS_CONTACT/ICS_TELEPH
DELETE I9
 from ICS_FLOW_ICIS.[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_FAC] [I7]
 ON [I7].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_CONTACT] [I8]
 ON [I8].[ICS_FAC_ID] = [I7].[ICS_FAC_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_TELEPH] [I9]
 ON [I9].[ICS_CONTACT_ID] = [I8].[ICS_CONTACT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'GeneralPermitSubmission')
				
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_GNRL_PRMT/ICS_FAC/ICS_CONTACT
DELETE I8
 from ICS_FLOW_ICIS.[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_FAC] [I7]
 ON [I7].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_CONTACT] [I8]
 ON [I8].[ICS_FAC_ID] = [I7].[ICS_FAC_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'GeneralPermitSubmission')
				
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_GNRL_PRMT/ICS_FAC
DELETE I7
 from ICS_FLOW_ICIS.[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_FAC] [I7]
 ON [I7].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'GeneralPermitSubmission')
				
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_GNRL_PRMT/ICS_EFFLU_GUIDE
DELETE I6
 from ICS_FLOW_ICIS.[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_EFFLU_GUIDE] [I6]
 ON [I6].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'GeneralPermitSubmission')
				
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_GNRL_PRMT/ICS_OTHR_PRMTS
DELETE I5
 from ICS_FLOW_ICIS.[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_OTHR_PRMTS] [I5]
 ON [I5].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'GeneralPermitSubmission')
				
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_GNRL_PRMT/ICS_NPDES_DAT_GRP_NUM
DELETE I4
 from ICS_FLOW_ICIS.[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_NPDES_DAT_GRP_NUM] [I4]
 ON [I4].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'GeneralPermitSubmission')
				
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_GNRL_PRMT/ICS_CONTACT/ICS_TELEPH
DELETE I3
 from ICS_FLOW_ICIS.[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_CONTACT] [I2]
 ON [I2].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_TELEPH] [I3]
 ON [I3].[ICS_CONTACT_ID] = [I2].[ICS_CONTACT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'GeneralPermitSubmission')
				
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_GNRL_PRMT/ICS_CONTACT
DELETE I2
 from ICS_FLOW_ICIS.[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_CONTACT] [I2]
 ON [I2].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'GeneralPermitSubmission')
				
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_GNRL_PRMT/ICS_NAICS_CODE
DELETE I1
 from ICS_FLOW_ICIS.[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_NAICS_CODE] [I1]
 ON [I1].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'GeneralPermitSubmission')
				
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_GNRL_PRMT
DELETE ICS_GNRL_PRMT
 from ICS_FLOW_ICIS.[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'GeneralPermitSubmission')
				
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
					

				-- INSERTS for: ICS_GNRL_PRMT
	
				
-- /ICS_GNRL_PRMT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_GNRL_PRMT]
     SELECT ICS_GNRL_PRMT.*
        from [ICS_FLOW_LOCAL].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 
       WHERE ICS_GNRL_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission')
								  
	    AND ICS_GNRL_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_GNRL_PRMT/ICS_NAICS_CODE 
INSERT INTO [ICS_FLOW_ICIS].[ICS_NAICS_CODE]
     SELECT I1.*
        from [ICS_FLOW_LOCAL].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_NAICS_CODE] [I1]
 ON [I1].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 
       WHERE ICS_GNRL_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission')
								  
	    AND ICS_GNRL_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_GNRL_PRMT/ICS_CONTACT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_CONTACT]
     SELECT I2.*
        from [ICS_FLOW_LOCAL].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTACT] [I2]
 ON [I2].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 
       WHERE ICS_GNRL_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission')
								  
	    AND ICS_GNRL_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_GNRL_PRMT/ICS_CONTACT/ICS_TELEPH 
INSERT INTO [ICS_FLOW_ICIS].[ICS_TELEPH]
     SELECT I3.*
        from [ICS_FLOW_LOCAL].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTACT] [I2]
 ON [I2].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_TELEPH] [I3]
 ON [I3].[ICS_CONTACT_ID] = [I2].[ICS_CONTACT_ID] 
 
       WHERE ICS_GNRL_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission')
								  
	    AND ICS_GNRL_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_GNRL_PRMT/ICS_NPDES_DAT_GRP_NUM 
INSERT INTO [ICS_FLOW_ICIS].[ICS_NPDES_DAT_GRP_NUM]
     SELECT I4.*
        from [ICS_FLOW_LOCAL].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_NPDES_DAT_GRP_NUM] [I4]
 ON [I4].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 
       WHERE ICS_GNRL_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission')
								  
	    AND ICS_GNRL_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_GNRL_PRMT/ICS_OTHR_PRMTS 
INSERT INTO [ICS_FLOW_ICIS].[ICS_OTHR_PRMTS]
     SELECT I5.*
        from [ICS_FLOW_LOCAL].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_OTHR_PRMTS] [I5]
 ON [I5].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 
       WHERE ICS_GNRL_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission')
								  
	    AND ICS_GNRL_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_GNRL_PRMT/ICS_EFFLU_GUIDE 
INSERT INTO [ICS_FLOW_ICIS].[ICS_EFFLU_GUIDE]
     SELECT I6.*
        from [ICS_FLOW_LOCAL].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_EFFLU_GUIDE] [I6]
 ON [I6].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 
       WHERE ICS_GNRL_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission')
								  
	    AND ICS_GNRL_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_GNRL_PRMT/ICS_FAC 
INSERT INTO [ICS_FLOW_ICIS].[ICS_FAC]
     SELECT I7.*
        from [ICS_FLOW_LOCAL].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_FAC] [I7]
 ON [I7].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 
       WHERE ICS_GNRL_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission')
								  
	    AND ICS_GNRL_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_GNRL_PRMT/ICS_FAC/ICS_CONTACT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_CONTACT]
     SELECT I8.*
        from [ICS_FLOW_LOCAL].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_FAC] [I7]
 ON [I7].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTACT] [I8]
 ON [I8].[ICS_FAC_ID] = [I7].[ICS_FAC_ID] 
 
       WHERE ICS_GNRL_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission')
								  
	    AND ICS_GNRL_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_GNRL_PRMT/ICS_FAC/ICS_CONTACT/ICS_TELEPH 
INSERT INTO [ICS_FLOW_ICIS].[ICS_TELEPH]
     SELECT I9.*
        from [ICS_FLOW_LOCAL].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_FAC] [I7]
 ON [I7].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTACT] [I8]
 ON [I8].[ICS_FAC_ID] = [I7].[ICS_FAC_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_TELEPH] [I9]
 ON [I9].[ICS_CONTACT_ID] = [I8].[ICS_CONTACT_ID] 
 
       WHERE ICS_GNRL_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission')
								  
	    AND ICS_GNRL_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_GNRL_PRMT/ICS_FAC/ICS_ORIG_PROGS 
INSERT INTO [ICS_FLOW_ICIS].[ICS_ORIG_PROGS]
     SELECT I10.*
        from [ICS_FLOW_LOCAL].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_FAC] [I7]
 ON [I7].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ORIG_PROGS] [I10]
 ON [I10].[ICS_FAC_ID] = [I7].[ICS_FAC_ID] 
 
       WHERE ICS_GNRL_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission')
								  
	    AND ICS_GNRL_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_GNRL_PRMT/ICS_FAC/ICS_PLCY 
INSERT INTO [ICS_FLOW_ICIS].[ICS_PLCY]
     SELECT I11.*
        from [ICS_FLOW_LOCAL].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_FAC] [I7]
 ON [I7].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PLCY] [I11]
 ON [I11].[ICS_FAC_ID] = [I7].[ICS_FAC_ID] 
 
       WHERE ICS_GNRL_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission')
								  
	    AND ICS_GNRL_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_GNRL_PRMT/ICS_FAC/ICS_FAC_CLASS 
INSERT INTO [ICS_FLOW_ICIS].[ICS_FAC_CLASS]
     SELECT I12.*
        from [ICS_FLOW_LOCAL].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_FAC] [I7]
 ON [I7].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_FAC_CLASS] [I12]
 ON [I12].[ICS_FAC_ID] = [I7].[ICS_FAC_ID] 
 
       WHERE ICS_GNRL_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission')
								  
	    AND ICS_GNRL_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_GNRL_PRMT/ICS_FAC/ICS_GEO_COORD 
INSERT INTO [ICS_FLOW_ICIS].[ICS_GEO_COORD]
     SELECT I13.*
        from [ICS_FLOW_LOCAL].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_FAC] [I7]
 ON [I7].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_GEO_COORD] [I13]
 ON [I13].[ICS_FAC_ID] = [I7].[ICS_FAC_ID] 
 
       WHERE ICS_GNRL_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission')
								  
	    AND ICS_GNRL_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_GNRL_PRMT/ICS_FAC/ICS_SIC_CODE 
INSERT INTO [ICS_FLOW_ICIS].[ICS_SIC_CODE]
     SELECT I14.*
        from [ICS_FLOW_LOCAL].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_FAC] [I7]
 ON [I7].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SIC_CODE] [I14]
 ON [I14].[ICS_FAC_ID] = [I7].[ICS_FAC_ID] 
 
       WHERE ICS_GNRL_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission')
								  
	    AND ICS_GNRL_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_GNRL_PRMT/ICS_FAC/ICS_ADDR 
INSERT INTO [ICS_FLOW_ICIS].[ICS_ADDR]
     SELECT I15.*
        from [ICS_FLOW_LOCAL].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_FAC] [I7]
 ON [I7].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ADDR] [I15]
 ON [I15].[ICS_FAC_ID] = [I7].[ICS_FAC_ID] 
 
       WHERE ICS_GNRL_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission')
								  
	    AND ICS_GNRL_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_GNRL_PRMT/ICS_FAC/ICS_ADDR/ICS_TELEPH 
INSERT INTO [ICS_FLOW_ICIS].[ICS_TELEPH]
     SELECT I16.*
        from [ICS_FLOW_LOCAL].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_FAC] [I7]
 ON [I7].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ADDR] [I15]
 ON [I15].[ICS_FAC_ID] = [I7].[ICS_FAC_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_TELEPH] [I16]
 ON [I16].[ICS_ADDR_ID] = [I15].[ICS_ADDR_ID] 
 
       WHERE ICS_GNRL_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission')
								  
	    AND ICS_GNRL_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_GNRL_PRMT/ICS_FAC/ICS_NAICS_CODE 
INSERT INTO [ICS_FLOW_ICIS].[ICS_NAICS_CODE]
     SELECT I17.*
        from [ICS_FLOW_LOCAL].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_FAC] [I7]
 ON [I7].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_NAICS_CODE] [I17]
 ON [I17].[ICS_FAC_ID] = [I7].[ICS_FAC_ID] 
 
       WHERE ICS_GNRL_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission')
								  
	    AND ICS_GNRL_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_GNRL_PRMT/ICS_REP_NON_CMPL_STAT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_REP_NON_CMPL_STAT]
     SELECT I18.*
        from [ICS_FLOW_LOCAL].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_REP_NON_CMPL_STAT] [I18]
 ON [I18].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 
       WHERE ICS_GNRL_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission')
								  
	    AND ICS_GNRL_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_GNRL_PRMT/ICS_RESIDUAL_DESGN_DTRMN 
INSERT INTO [ICS_FLOW_ICIS].[ICS_RESIDUAL_DESGN_DTRMN]
     SELECT I19.*
        from [ICS_FLOW_LOCAL].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_RESIDUAL_DESGN_DTRMN] [I19]
 ON [I19].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 
       WHERE ICS_GNRL_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission')
								  
	    AND ICS_GNRL_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_GNRL_PRMT/ICS_SIC_CODE 
INSERT INTO [ICS_FLOW_ICIS].[ICS_SIC_CODE]
     SELECT I20.*
        from [ICS_FLOW_LOCAL].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SIC_CODE] [I20]
 ON [I20].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 
       WHERE ICS_GNRL_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission')
								  
	    AND ICS_GNRL_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_GNRL_PRMT/ICS_ADDR 
INSERT INTO [ICS_FLOW_ICIS].[ICS_ADDR]
     SELECT I21.*
        from [ICS_FLOW_LOCAL].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ADDR] [I21]
 ON [I21].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 
       WHERE ICS_GNRL_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission')
								  
	    AND ICS_GNRL_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_GNRL_PRMT/ICS_ADDR/ICS_TELEPH 
INSERT INTO [ICS_FLOW_ICIS].[ICS_TELEPH]
     SELECT I22.*
        from [ICS_FLOW_LOCAL].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ADDR] [I21]
 ON [I21].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_TELEPH] [I22]
 ON [I22].[ICS_ADDR_ID] = [I21].[ICS_ADDR_ID] 
 
       WHERE ICS_GNRL_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission')
								  
	    AND ICS_GNRL_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_GNRL_PRMT/ICS_ASSC_PRMT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_ASSC_PRMT]
     SELECT I23.*
        from [ICS_FLOW_LOCAL].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ASSC_PRMT] [I23]
 ON [I23].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 
       WHERE ICS_GNRL_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission')
								  
	    AND ICS_GNRL_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_GNRL_PRMT/ICS_CMPL_TRACK_STAT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_CMPL_TRACK_STAT]
     SELECT I24.*
        from [ICS_FLOW_LOCAL].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CMPL_TRACK_STAT] [I24]
 ON [I24].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 
       WHERE ICS_GNRL_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission')
								  
	    AND ICS_GNRL_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

					
				
	

-- ================================================================
-- ICS_HIST_PRMT_SCHD_EVTS 
-- ================================================================
			
				-- DELETES for: ICS_HIST_PRMT_SCHD_EVTS 
				
								
-- /ICS_HIST_PRMT_SCHD_EVTS
DELETE ICS_HIST_PRMT_SCHD_EVTS
 from ICS_FLOW_ICIS.[ICS_HIST_PRMT_SCHD_EVTS] [ICS_HIST_PRMT_SCHD_EVTS] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_HIST_PRMT_SCHD_EVTS.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'HistoricalPermitScheduleEventsSubmission')
				  ;
          				
				
					

				-- INSERTS for: ICS_HIST_PRMT_SCHD_EVTS
	
				
-- /ICS_HIST_PRMT_SCHD_EVTS 
INSERT INTO [ICS_FLOW_ICIS].[ICS_HIST_PRMT_SCHD_EVTS]
     SELECT ICS_HIST_PRMT_SCHD_EVTS.*
        from [ICS_FLOW_LOCAL].[ICS_HIST_PRMT_SCHD_EVTS] [ICS_HIST_PRMT_SCHD_EVTS] 
 
       WHERE ICS_HIST_PRMT_SCHD_EVTS.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'HistoricalPermitScheduleEventsSubmission')
				 
				  ;			 

					
				
	

-- ================================================================
-- ICS_INFRML_ENFRC_ACTN 
-- ================================================================
			
				-- DELETES for: ICS_INFRML_ENFRC_ACTN 
				
								
-- /ICS_INFRML_ENFRC_ACTN/ICS_PROGS_VIOL
DELETE I4
 from ICS_FLOW_ICIS.[ICS_INFRML_ENFRC_ACTN] [ICS_INFRML_ENFRC_ACTN] 
 JOIN ICS_FLOW_ICIS.[ICS_PROGS_VIOL] [I4]
 ON [I4].[ICS_INFRML_ENFRC_ACTN_ID] = [ICS_INFRML_ENFRC_ACTN].[ICS_INFRML_ENFRC_ACTN_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_INFRML_ENFRC_ACTN.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'InformalEnforcementActionSubmission')
				  ;
          				
				
								
-- /ICS_INFRML_ENFRC_ACTN/ICS_ENFRC_AGNCY
DELETE I3
 from ICS_FLOW_ICIS.[ICS_INFRML_ENFRC_ACTN] [ICS_INFRML_ENFRC_ACTN] 
 JOIN ICS_FLOW_ICIS.[ICS_ENFRC_AGNCY] [I3]
 ON [I3].[ICS_INFRML_ENFRC_ACTN_ID] = [ICS_INFRML_ENFRC_ACTN].[ICS_INFRML_ENFRC_ACTN_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_INFRML_ENFRC_ACTN.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'InformalEnforcementActionSubmission')
				  ;
          				
				
								
-- /ICS_INFRML_ENFRC_ACTN/ICS_ENFRC_ACTN_GOV_CONTACT
DELETE I2
 from ICS_FLOW_ICIS.[ICS_INFRML_ENFRC_ACTN] [ICS_INFRML_ENFRC_ACTN] 
 JOIN ICS_FLOW_ICIS.[ICS_ENFRC_ACTN_GOV_CONTACT] [I2]
 ON [I2].[ICS_INFRML_ENFRC_ACTN_ID] = [ICS_INFRML_ENFRC_ACTN].[ICS_INFRML_ENFRC_ACTN_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_INFRML_ENFRC_ACTN.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'InformalEnforcementActionSubmission')
				  ;
          				
				
								
-- /ICS_INFRML_ENFRC_ACTN/ICS_PRMT_IDENT
DELETE I1
 from ICS_FLOW_ICIS.[ICS_INFRML_ENFRC_ACTN] [ICS_INFRML_ENFRC_ACTN] 
 JOIN ICS_FLOW_ICIS.[ICS_PRMT_IDENT] [I1]
 ON [I1].[ICS_INFRML_ENFRC_ACTN_ID] = [ICS_INFRML_ENFRC_ACTN].[ICS_INFRML_ENFRC_ACTN_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_INFRML_ENFRC_ACTN.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'InformalEnforcementActionSubmission')
				  ;
          				
				
								
-- /ICS_INFRML_ENFRC_ACTN
DELETE ICS_INFRML_ENFRC_ACTN
 from ICS_FLOW_ICIS.[ICS_INFRML_ENFRC_ACTN] [ICS_INFRML_ENFRC_ACTN] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_INFRML_ENFRC_ACTN.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'InformalEnforcementActionSubmission')
				  ;
          				
				
					

				-- INSERTS for: ICS_INFRML_ENFRC_ACTN
	
				
-- /ICS_INFRML_ENFRC_ACTN 
INSERT INTO [ICS_FLOW_ICIS].[ICS_INFRML_ENFRC_ACTN]
     SELECT ICS_INFRML_ENFRC_ACTN.*
        from [ICS_FLOW_LOCAL].[ICS_INFRML_ENFRC_ACTN] [ICS_INFRML_ENFRC_ACTN] 
 
       WHERE ICS_INFRML_ENFRC_ACTN.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'InformalEnforcementActionSubmission')
				 
				  ;			 

				
-- /ICS_INFRML_ENFRC_ACTN/ICS_PRMT_IDENT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_PRMT_IDENT]
     SELECT I1.*
        from [ICS_FLOW_LOCAL].[ICS_INFRML_ENFRC_ACTN] [ICS_INFRML_ENFRC_ACTN] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PRMT_IDENT] [I1]
 ON [I1].[ICS_INFRML_ENFRC_ACTN_ID] = [ICS_INFRML_ENFRC_ACTN].[ICS_INFRML_ENFRC_ACTN_ID] 
 
       WHERE ICS_INFRML_ENFRC_ACTN.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'InformalEnforcementActionSubmission')
				 
				  ;			 

				
-- /ICS_INFRML_ENFRC_ACTN/ICS_ENFRC_ACTN_GOV_CONTACT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_ENFRC_ACTN_GOV_CONTACT]
     SELECT I2.*
        from [ICS_FLOW_LOCAL].[ICS_INFRML_ENFRC_ACTN] [ICS_INFRML_ENFRC_ACTN] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ENFRC_ACTN_GOV_CONTACT] [I2]
 ON [I2].[ICS_INFRML_ENFRC_ACTN_ID] = [ICS_INFRML_ENFRC_ACTN].[ICS_INFRML_ENFRC_ACTN_ID] 
 
       WHERE ICS_INFRML_ENFRC_ACTN.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'InformalEnforcementActionSubmission')
				 
				  ;			 

				
-- /ICS_INFRML_ENFRC_ACTN/ICS_ENFRC_AGNCY 
INSERT INTO [ICS_FLOW_ICIS].[ICS_ENFRC_AGNCY]
     SELECT I3.*
        from [ICS_FLOW_LOCAL].[ICS_INFRML_ENFRC_ACTN] [ICS_INFRML_ENFRC_ACTN] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ENFRC_AGNCY] [I3]
 ON [I3].[ICS_INFRML_ENFRC_ACTN_ID] = [ICS_INFRML_ENFRC_ACTN].[ICS_INFRML_ENFRC_ACTN_ID] 
 
       WHERE ICS_INFRML_ENFRC_ACTN.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'InformalEnforcementActionSubmission')
				 
				  ;			 

				
-- /ICS_INFRML_ENFRC_ACTN/ICS_PROGS_VIOL 
INSERT INTO [ICS_FLOW_ICIS].[ICS_PROGS_VIOL]
     SELECT I4.*
        from [ICS_FLOW_LOCAL].[ICS_INFRML_ENFRC_ACTN] [ICS_INFRML_ENFRC_ACTN] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PROGS_VIOL] [I4]
 ON [I4].[ICS_INFRML_ENFRC_ACTN_ID] = [ICS_INFRML_ENFRC_ACTN].[ICS_INFRML_ENFRC_ACTN_ID] 
 
       WHERE ICS_INFRML_ENFRC_ACTN.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'InformalEnforcementActionSubmission')
				 
				  ;			 

					
				
	

-- ================================================================
-- ICS_LMTS 
-- ================================================================
			
				-- DELETES for: ICS_LMTS 
				
								
-- /ICS_LMTS/ICS_MN_LMT_APPLIES
DELETE I2
 from ICS_FLOW_ICIS.[ICS_LMTS] [ICS_LMTS] 
 JOIN ICS_FLOW_ICIS.[ICS_MN_LMT_APPLIES] [I2]
 ON [I2].[ICS_LMTS_ID] = [ICS_LMTS].[ICS_LMTS_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_LMTS.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'LimitsSubmission')
				
                  OR ICS_LMTS.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_LMTS.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_LMTS/ICS_NUM_COND
DELETE I1
 from ICS_FLOW_ICIS.[ICS_LMTS] [ICS_LMTS] 
 JOIN ICS_FLOW_ICIS.[ICS_NUM_COND] [I1]
 ON [I1].[ICS_LMTS_ID] = [ICS_LMTS].[ICS_LMTS_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_LMTS.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'LimitsSubmission')
				
                  OR ICS_LMTS.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_LMTS.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_LMTS
DELETE ICS_LMTS
 from ICS_FLOW_ICIS.[ICS_LMTS] [ICS_LMTS] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_LMTS.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'LimitsSubmission')
				
                  OR ICS_LMTS.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_LMTS.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
					

				-- INSERTS for: ICS_LMTS
	
				
-- /ICS_LMTS 
INSERT INTO [ICS_FLOW_ICIS].[ICS_LMTS]
     SELECT ICS_LMTS.*
        from [ICS_FLOW_LOCAL].[ICS_LMTS] [ICS_LMTS] 
 
       WHERE ICS_LMTS.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'LimitsSubmission')
								  
	    AND ICS_LMTS.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_LMTS/ICS_NUM_COND 
INSERT INTO [ICS_FLOW_ICIS].[ICS_NUM_COND]
     SELECT I1.*
        from [ICS_FLOW_LOCAL].[ICS_LMTS] [ICS_LMTS] 
 JOIN [ICS_FLOW_LOCAL].[ICS_NUM_COND] [I1]
 ON [I1].[ICS_LMTS_ID] = [ICS_LMTS].[ICS_LMTS_ID] 
 
       WHERE ICS_LMTS.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'LimitsSubmission')
								  
	    AND ICS_LMTS.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_LMTS/ICS_MN_LMT_APPLIES 
INSERT INTO [ICS_FLOW_ICIS].[ICS_MN_LMT_APPLIES]
     SELECT I2.*
        from [ICS_FLOW_LOCAL].[ICS_LMTS] [ICS_LMTS] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MN_LMT_APPLIES] [I2]
 ON [I2].[ICS_LMTS_ID] = [ICS_LMTS].[ICS_LMTS_ID] 
 
       WHERE ICS_LMTS.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'LimitsSubmission')
								  
	    AND ICS_LMTS.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

					
				
	

-- ================================================================
-- ICS_LMT_SET 
-- ================================================================
			
				-- DELETES for: ICS_LMT_SET 
				
								
-- /ICS_LMT_SET/ICS_LMT_SET_STAT
DELETE I3
 from ICS_FLOW_ICIS.[ICS_LMT_SET] [ICS_LMT_SET] 
 JOIN ICS_FLOW_ICIS.[ICS_LMT_SET_STAT] [I3]
 ON [I3].[ICS_LMT_SET_ID] = [ICS_LMT_SET].[ICS_LMT_SET_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_LMT_SET.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'LimitSetSubmission')
				
                  OR ICS_LMT_SET.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_LMT_SET.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_LMT_SET/ICS_LMT_SET_SCHD
DELETE I2
 from ICS_FLOW_ICIS.[ICS_LMT_SET] [ICS_LMT_SET] 
 JOIN ICS_FLOW_ICIS.[ICS_LMT_SET_SCHD] [I2]
 ON [I2].[ICS_LMT_SET_ID] = [ICS_LMT_SET].[ICS_LMT_SET_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_LMT_SET.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'LimitSetSubmission')
				
                  OR ICS_LMT_SET.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_LMT_SET.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_LMT_SET/ICS_LMT_SET_MONTHS_APPL
DELETE I1
 from ICS_FLOW_ICIS.[ICS_LMT_SET] [ICS_LMT_SET] 
 JOIN ICS_FLOW_ICIS.[ICS_LMT_SET_MONTHS_APPL] [I1]
 ON [I1].[ICS_LMT_SET_ID] = [ICS_LMT_SET].[ICS_LMT_SET_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_LMT_SET.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'LimitSetSubmission')
				
                  OR ICS_LMT_SET.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_LMT_SET.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_LMT_SET
DELETE ICS_LMT_SET
 from ICS_FLOW_ICIS.[ICS_LMT_SET] [ICS_LMT_SET] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_LMT_SET.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'LimitSetSubmission')
				
                  OR ICS_LMT_SET.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_LMT_SET.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
					

				-- INSERTS for: ICS_LMT_SET
	
				
-- /ICS_LMT_SET 
INSERT INTO [ICS_FLOW_ICIS].[ICS_LMT_SET]
     SELECT ICS_LMT_SET.*
        from [ICS_FLOW_LOCAL].[ICS_LMT_SET] [ICS_LMT_SET] 
 
       WHERE ICS_LMT_SET.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'LimitSetSubmission')
								  
	    AND ICS_LMT_SET.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_LMT_SET/ICS_LMT_SET_MONTHS_APPL 
INSERT INTO [ICS_FLOW_ICIS].[ICS_LMT_SET_MONTHS_APPL]
     SELECT I1.*
        from [ICS_FLOW_LOCAL].[ICS_LMT_SET] [ICS_LMT_SET] 
 JOIN [ICS_FLOW_LOCAL].[ICS_LMT_SET_MONTHS_APPL] [I1]
 ON [I1].[ICS_LMT_SET_ID] = [ICS_LMT_SET].[ICS_LMT_SET_ID] 
 
       WHERE ICS_LMT_SET.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'LimitSetSubmission')
								  
	    AND ICS_LMT_SET.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_LMT_SET/ICS_LMT_SET_SCHD 
INSERT INTO [ICS_FLOW_ICIS].[ICS_LMT_SET_SCHD]
     SELECT I2.*
        from [ICS_FLOW_LOCAL].[ICS_LMT_SET] [ICS_LMT_SET] 
 JOIN [ICS_FLOW_LOCAL].[ICS_LMT_SET_SCHD] [I2]
 ON [I2].[ICS_LMT_SET_ID] = [ICS_LMT_SET].[ICS_LMT_SET_ID] 
 
       WHERE ICS_LMT_SET.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'LimitSetSubmission')
								  
	    AND ICS_LMT_SET.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_LMT_SET/ICS_LMT_SET_STAT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_LMT_SET_STAT]
     SELECT I3.*
        from [ICS_FLOW_LOCAL].[ICS_LMT_SET] [ICS_LMT_SET] 
 JOIN [ICS_FLOW_LOCAL].[ICS_LMT_SET_STAT] [I3]
 ON [I3].[ICS_LMT_SET_ID] = [ICS_LMT_SET].[ICS_LMT_SET_ID] 
 
       WHERE ICS_LMT_SET.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'LimitSetSubmission')
								  
	    AND ICS_LMT_SET.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

					
				
	

-- ================================================================
-- ICS_MASTER_GNRL_PRMT 
-- ================================================================
			
				-- DELETES for: ICS_MASTER_GNRL_PRMT 
				
								
-- /ICS_MASTER_GNRL_PRMT/ICS_ASSC_PRMT
DELETE I8
 from ICS_FLOW_ICIS.[ICS_MASTER_GNRL_PRMT] [ICS_MASTER_GNRL_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_ASSC_PRMT] [I8]
 ON [I8].[ICS_MASTER_GNRL_PRMT_ID] = [ICS_MASTER_GNRL_PRMT].[ICS_MASTER_GNRL_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_MASTER_GNRL_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'MasterGeneralPermitSubmission')
				
                  OR ICS_MASTER_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_MASTER_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_MASTER_GNRL_PRMT/ICS_SIC_CODE
DELETE I7
 from ICS_FLOW_ICIS.[ICS_MASTER_GNRL_PRMT] [ICS_MASTER_GNRL_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_SIC_CODE] [I7]
 ON [I7].[ICS_MASTER_GNRL_PRMT_ID] = [ICS_MASTER_GNRL_PRMT].[ICS_MASTER_GNRL_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_MASTER_GNRL_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'MasterGeneralPermitSubmission')
				
                  OR ICS_MASTER_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_MASTER_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_MASTER_GNRL_PRMT/ICS_RESIDUAL_DESGN_DTRMN
DELETE I6
 from ICS_FLOW_ICIS.[ICS_MASTER_GNRL_PRMT] [ICS_MASTER_GNRL_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_RESIDUAL_DESGN_DTRMN] [I6]
 ON [I6].[ICS_MASTER_GNRL_PRMT_ID] = [ICS_MASTER_GNRL_PRMT].[ICS_MASTER_GNRL_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_MASTER_GNRL_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'MasterGeneralPermitSubmission')
				
                  OR ICS_MASTER_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_MASTER_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_MASTER_GNRL_PRMT/ICS_PRMT_COMP_TYPE
DELETE I5
 from ICS_FLOW_ICIS.[ICS_MASTER_GNRL_PRMT] [ICS_MASTER_GNRL_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_PRMT_COMP_TYPE] [I5]
 ON [I5].[ICS_MASTER_GNRL_PRMT_ID] = [ICS_MASTER_GNRL_PRMT].[ICS_MASTER_GNRL_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_MASTER_GNRL_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'MasterGeneralPermitSubmission')
				
                  OR ICS_MASTER_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_MASTER_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_MASTER_GNRL_PRMT/ICS_OTHR_PRMTS
DELETE I4
 from ICS_FLOW_ICIS.[ICS_MASTER_GNRL_PRMT] [ICS_MASTER_GNRL_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_OTHR_PRMTS] [I4]
 ON [I4].[ICS_MASTER_GNRL_PRMT_ID] = [ICS_MASTER_GNRL_PRMT].[ICS_MASTER_GNRL_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_MASTER_GNRL_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'MasterGeneralPermitSubmission')
				
                  OR ICS_MASTER_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_MASTER_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_MASTER_GNRL_PRMT/ICS_CONTACT/ICS_TELEPH
DELETE I3
 from ICS_FLOW_ICIS.[ICS_MASTER_GNRL_PRMT] [ICS_MASTER_GNRL_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_CONTACT] [I2]
 ON [I2].[ICS_MASTER_GNRL_PRMT_ID] = [ICS_MASTER_GNRL_PRMT].[ICS_MASTER_GNRL_PRMT_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_TELEPH] [I3]
 ON [I3].[ICS_CONTACT_ID] = [I2].[ICS_CONTACT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_MASTER_GNRL_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'MasterGeneralPermitSubmission')
				
                  OR ICS_MASTER_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_MASTER_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_MASTER_GNRL_PRMT/ICS_CONTACT
DELETE I2
 from ICS_FLOW_ICIS.[ICS_MASTER_GNRL_PRMT] [ICS_MASTER_GNRL_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_CONTACT] [I2]
 ON [I2].[ICS_MASTER_GNRL_PRMT_ID] = [ICS_MASTER_GNRL_PRMT].[ICS_MASTER_GNRL_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_MASTER_GNRL_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'MasterGeneralPermitSubmission')
				
                  OR ICS_MASTER_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_MASTER_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_MASTER_GNRL_PRMT/ICS_NAICS_CODE
DELETE I1
 from ICS_FLOW_ICIS.[ICS_MASTER_GNRL_PRMT] [ICS_MASTER_GNRL_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_NAICS_CODE] [I1]
 ON [I1].[ICS_MASTER_GNRL_PRMT_ID] = [ICS_MASTER_GNRL_PRMT].[ICS_MASTER_GNRL_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_MASTER_GNRL_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'MasterGeneralPermitSubmission')
				
                  OR ICS_MASTER_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_MASTER_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_MASTER_GNRL_PRMT
DELETE ICS_MASTER_GNRL_PRMT
 from ICS_FLOW_ICIS.[ICS_MASTER_GNRL_PRMT] [ICS_MASTER_GNRL_PRMT] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_MASTER_GNRL_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'MasterGeneralPermitSubmission')
				
                  OR ICS_MASTER_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_MASTER_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
					

				-- INSERTS for: ICS_MASTER_GNRL_PRMT
	
				
-- /ICS_MASTER_GNRL_PRMT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_MASTER_GNRL_PRMT]
     SELECT ICS_MASTER_GNRL_PRMT.*
        from [ICS_FLOW_LOCAL].[ICS_MASTER_GNRL_PRMT] [ICS_MASTER_GNRL_PRMT] 
 
       WHERE ICS_MASTER_GNRL_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'MasterGeneralPermitSubmission')
								  
	    AND ICS_MASTER_GNRL_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_MASTER_GNRL_PRMT/ICS_NAICS_CODE 
INSERT INTO [ICS_FLOW_ICIS].[ICS_NAICS_CODE]
     SELECT I1.*
        from [ICS_FLOW_LOCAL].[ICS_MASTER_GNRL_PRMT] [ICS_MASTER_GNRL_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_NAICS_CODE] [I1]
 ON [I1].[ICS_MASTER_GNRL_PRMT_ID] = [ICS_MASTER_GNRL_PRMT].[ICS_MASTER_GNRL_PRMT_ID] 
 
       WHERE ICS_MASTER_GNRL_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'MasterGeneralPermitSubmission')
								  
	    AND ICS_MASTER_GNRL_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_MASTER_GNRL_PRMT/ICS_CONTACT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_CONTACT]
     SELECT I2.*
        from [ICS_FLOW_LOCAL].[ICS_MASTER_GNRL_PRMT] [ICS_MASTER_GNRL_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTACT] [I2]
 ON [I2].[ICS_MASTER_GNRL_PRMT_ID] = [ICS_MASTER_GNRL_PRMT].[ICS_MASTER_GNRL_PRMT_ID] 
 
       WHERE ICS_MASTER_GNRL_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'MasterGeneralPermitSubmission')
								  
	    AND ICS_MASTER_GNRL_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_MASTER_GNRL_PRMT/ICS_CONTACT/ICS_TELEPH 
INSERT INTO [ICS_FLOW_ICIS].[ICS_TELEPH]
     SELECT I3.*
        from [ICS_FLOW_LOCAL].[ICS_MASTER_GNRL_PRMT] [ICS_MASTER_GNRL_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTACT] [I2]
 ON [I2].[ICS_MASTER_GNRL_PRMT_ID] = [ICS_MASTER_GNRL_PRMT].[ICS_MASTER_GNRL_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_TELEPH] [I3]
 ON [I3].[ICS_CONTACT_ID] = [I2].[ICS_CONTACT_ID] 
 
       WHERE ICS_MASTER_GNRL_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'MasterGeneralPermitSubmission')
								  
	    AND ICS_MASTER_GNRL_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_MASTER_GNRL_PRMT/ICS_OTHR_PRMTS 
INSERT INTO [ICS_FLOW_ICIS].[ICS_OTHR_PRMTS]
     SELECT I4.*
        from [ICS_FLOW_LOCAL].[ICS_MASTER_GNRL_PRMT] [ICS_MASTER_GNRL_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_OTHR_PRMTS] [I4]
 ON [I4].[ICS_MASTER_GNRL_PRMT_ID] = [ICS_MASTER_GNRL_PRMT].[ICS_MASTER_GNRL_PRMT_ID] 
 
       WHERE ICS_MASTER_GNRL_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'MasterGeneralPermitSubmission')
								  
	    AND ICS_MASTER_GNRL_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_MASTER_GNRL_PRMT/ICS_PRMT_COMP_TYPE 
INSERT INTO [ICS_FLOW_ICIS].[ICS_PRMT_COMP_TYPE]
     SELECT I5.*
        from [ICS_FLOW_LOCAL].[ICS_MASTER_GNRL_PRMT] [ICS_MASTER_GNRL_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PRMT_COMP_TYPE] [I5]
 ON [I5].[ICS_MASTER_GNRL_PRMT_ID] = [ICS_MASTER_GNRL_PRMT].[ICS_MASTER_GNRL_PRMT_ID] 
 
       WHERE ICS_MASTER_GNRL_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'MasterGeneralPermitSubmission')
								  
	    AND ICS_MASTER_GNRL_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_MASTER_GNRL_PRMT/ICS_RESIDUAL_DESGN_DTRMN 
INSERT INTO [ICS_FLOW_ICIS].[ICS_RESIDUAL_DESGN_DTRMN]
     SELECT I6.*
        from [ICS_FLOW_LOCAL].[ICS_MASTER_GNRL_PRMT] [ICS_MASTER_GNRL_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_RESIDUAL_DESGN_DTRMN] [I6]
 ON [I6].[ICS_MASTER_GNRL_PRMT_ID] = [ICS_MASTER_GNRL_PRMT].[ICS_MASTER_GNRL_PRMT_ID] 
 
       WHERE ICS_MASTER_GNRL_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'MasterGeneralPermitSubmission')
								  
	    AND ICS_MASTER_GNRL_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_MASTER_GNRL_PRMT/ICS_SIC_CODE 
INSERT INTO [ICS_FLOW_ICIS].[ICS_SIC_CODE]
     SELECT I7.*
        from [ICS_FLOW_LOCAL].[ICS_MASTER_GNRL_PRMT] [ICS_MASTER_GNRL_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SIC_CODE] [I7]
 ON [I7].[ICS_MASTER_GNRL_PRMT_ID] = [ICS_MASTER_GNRL_PRMT].[ICS_MASTER_GNRL_PRMT_ID] 
 
       WHERE ICS_MASTER_GNRL_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'MasterGeneralPermitSubmission')
								  
	    AND ICS_MASTER_GNRL_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_MASTER_GNRL_PRMT/ICS_ASSC_PRMT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_ASSC_PRMT]
     SELECT I8.*
        from [ICS_FLOW_LOCAL].[ICS_MASTER_GNRL_PRMT] [ICS_MASTER_GNRL_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ASSC_PRMT] [I8]
 ON [I8].[ICS_MASTER_GNRL_PRMT_ID] = [ICS_MASTER_GNRL_PRMT].[ICS_MASTER_GNRL_PRMT_ID] 
 
       WHERE ICS_MASTER_GNRL_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'MasterGeneralPermitSubmission')
								  
	    AND ICS_MASTER_GNRL_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

					
				
	

-- ================================================================
-- ICS_NARR_COND_SCHD 
-- ================================================================
			
				-- DELETES for: ICS_NARR_COND_SCHD 
				
								
-- /ICS_NARR_COND_SCHD/ICS_PRMT_SCHD_EVT
DELETE I1
 from ICS_FLOW_ICIS.[ICS_NARR_COND_SCHD] [ICS_NARR_COND_SCHD] 
 JOIN ICS_FLOW_ICIS.[ICS_PRMT_SCHD_EVT] [I1]
 ON [I1].[ICS_NARR_COND_SCHD_ID] = [ICS_NARR_COND_SCHD].[ICS_NARR_COND_SCHD_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_NARR_COND_SCHD.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'NarrativeConditionScheduleSubmission')
				
                  OR ICS_NARR_COND_SCHD.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_NARR_COND_SCHD.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_NARR_COND_SCHD
DELETE ICS_NARR_COND_SCHD
 from ICS_FLOW_ICIS.[ICS_NARR_COND_SCHD] [ICS_NARR_COND_SCHD] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_NARR_COND_SCHD.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'NarrativeConditionScheduleSubmission')
				
                  OR ICS_NARR_COND_SCHD.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_NARR_COND_SCHD.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
					

				-- INSERTS for: ICS_NARR_COND_SCHD
	
				
-- /ICS_NARR_COND_SCHD 
INSERT INTO [ICS_FLOW_ICIS].[ICS_NARR_COND_SCHD]
     SELECT ICS_NARR_COND_SCHD.*
        from [ICS_FLOW_LOCAL].[ICS_NARR_COND_SCHD] [ICS_NARR_COND_SCHD] 
 
       WHERE ICS_NARR_COND_SCHD.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'NarrativeConditionScheduleSubmission')
								  
	    AND ICS_NARR_COND_SCHD.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_NARR_COND_SCHD/ICS_PRMT_SCHD_EVT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_PRMT_SCHD_EVT]
     SELECT I1.*
        from [ICS_FLOW_LOCAL].[ICS_NARR_COND_SCHD] [ICS_NARR_COND_SCHD] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PRMT_SCHD_EVT] [I1]
 ON [I1].[ICS_NARR_COND_SCHD_ID] = [ICS_NARR_COND_SCHD].[ICS_NARR_COND_SCHD_ID] 
 
       WHERE ICS_NARR_COND_SCHD.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'NarrativeConditionScheduleSubmission')
								  
	    AND ICS_NARR_COND_SCHD.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

					
				
	

-- ================================================================
-- ICS_NPDES_VARIANCE_PRMT 
-- ================================================================
			
				-- DELETES for: ICS_NPDES_VARIANCE_PRMT 
				
								
-- /ICS_NPDES_VARIANCE_PRMT
DELETE ICS_NPDES_VARIANCE_PRMT
 from ICS_FLOW_ICIS.[ICS_NPDES_VARIANCE_PRMT] [ICS_NPDES_VARIANCE_PRMT] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_NPDES_VARIANCE_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'NPDESVariancePermitSubmission')
				
                  OR ICS_NPDES_VARIANCE_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_NPDES_VARIANCE_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
					

				-- INSERTS for: ICS_NPDES_VARIANCE_PRMT
	
				
-- /ICS_NPDES_VARIANCE_PRMT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_NPDES_VARIANCE_PRMT]
     SELECT ICS_NPDES_VARIANCE_PRMT.*
        from [ICS_FLOW_LOCAL].[ICS_NPDES_VARIANCE_PRMT] [ICS_NPDES_VARIANCE_PRMT] 
 
       WHERE ICS_NPDES_VARIANCE_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'NPDESVariancePermitSubmission')
								  
	    AND ICS_NPDES_VARIANCE_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

					
				
	

-- ================================================================
-- ICS_PARAM_LMTS 
-- ================================================================
			
				-- DELETES for: ICS_PARAM_LMTS 
				
								
-- /ICS_PARAM_LMTS/ICS_LMT/ICS_MN_LMT_APPLIES
DELETE I3
 from ICS_FLOW_ICIS.[ICS_PARAM_LMTS] [ICS_PARAM_LMTS] 
 JOIN ICS_FLOW_ICIS.[ICS_LMT] [I1]
 ON [I1].[ICS_PARAM_LMTS_ID] = [ICS_PARAM_LMTS].[ICS_PARAM_LMTS_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_MN_LMT_APPLIES] [I3]
 ON [I3].[ICS_LMT_ID] = [I1].[ICS_LMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PARAM_LMTS.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ParameterLimitsSubmission')
				
                  OR ICS_PARAM_LMTS.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_PARAM_LMTS.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_PARAM_LMTS/ICS_LMT/ICS_NUM_COND
DELETE I2
 from ICS_FLOW_ICIS.[ICS_PARAM_LMTS] [ICS_PARAM_LMTS] 
 JOIN ICS_FLOW_ICIS.[ICS_LMT] [I1]
 ON [I1].[ICS_PARAM_LMTS_ID] = [ICS_PARAM_LMTS].[ICS_PARAM_LMTS_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_NUM_COND] [I2]
 ON [I2].[ICS_LMT_ID] = [I1].[ICS_LMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PARAM_LMTS.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ParameterLimitsSubmission')
				
                  OR ICS_PARAM_LMTS.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_PARAM_LMTS.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_PARAM_LMTS/ICS_LMT
DELETE I1
 from ICS_FLOW_ICIS.[ICS_PARAM_LMTS] [ICS_PARAM_LMTS] 
 JOIN ICS_FLOW_ICIS.[ICS_LMT] [I1]
 ON [I1].[ICS_PARAM_LMTS_ID] = [ICS_PARAM_LMTS].[ICS_PARAM_LMTS_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PARAM_LMTS.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ParameterLimitsSubmission')
				
                  OR ICS_PARAM_LMTS.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_PARAM_LMTS.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_PARAM_LMTS
DELETE ICS_PARAM_LMTS
 from ICS_FLOW_ICIS.[ICS_PARAM_LMTS] [ICS_PARAM_LMTS] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PARAM_LMTS.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ParameterLimitsSubmission')
				
                  OR ICS_PARAM_LMTS.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_PARAM_LMTS.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
					

				-- INSERTS for: ICS_PARAM_LMTS
	
				
-- /ICS_PARAM_LMTS 
INSERT INTO [ICS_FLOW_ICIS].[ICS_PARAM_LMTS]
     SELECT ICS_PARAM_LMTS.*
        from [ICS_FLOW_LOCAL].[ICS_PARAM_LMTS] [ICS_PARAM_LMTS] 
 
       WHERE ICS_PARAM_LMTS.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ParameterLimitsSubmission')
								  
	    AND ICS_PARAM_LMTS.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_PARAM_LMTS/ICS_LMT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_LMT]
     SELECT I1.*
        from [ICS_FLOW_LOCAL].[ICS_PARAM_LMTS] [ICS_PARAM_LMTS] 
 JOIN [ICS_FLOW_LOCAL].[ICS_LMT] [I1]
 ON [I1].[ICS_PARAM_LMTS_ID] = [ICS_PARAM_LMTS].[ICS_PARAM_LMTS_ID] 
 
       WHERE ICS_PARAM_LMTS.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ParameterLimitsSubmission')
								  
	    AND ICS_PARAM_LMTS.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_PARAM_LMTS/ICS_LMT/ICS_NUM_COND 
INSERT INTO [ICS_FLOW_ICIS].[ICS_NUM_COND]
     SELECT I2.*
        from [ICS_FLOW_LOCAL].[ICS_PARAM_LMTS] [ICS_PARAM_LMTS] 
 JOIN [ICS_FLOW_LOCAL].[ICS_LMT] [I1]
 ON [I1].[ICS_PARAM_LMTS_ID] = [ICS_PARAM_LMTS].[ICS_PARAM_LMTS_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_NUM_COND] [I2]
 ON [I2].[ICS_LMT_ID] = [I1].[ICS_LMT_ID] 
 
       WHERE ICS_PARAM_LMTS.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ParameterLimitsSubmission')
								  
	    AND ICS_PARAM_LMTS.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_PARAM_LMTS/ICS_LMT/ICS_MN_LMT_APPLIES 
INSERT INTO [ICS_FLOW_ICIS].[ICS_MN_LMT_APPLIES]
     SELECT I3.*
        from [ICS_FLOW_LOCAL].[ICS_PARAM_LMTS] [ICS_PARAM_LMTS] 
 JOIN [ICS_FLOW_LOCAL].[ICS_LMT] [I1]
 ON [I1].[ICS_PARAM_LMTS_ID] = [ICS_PARAM_LMTS].[ICS_PARAM_LMTS_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MN_LMT_APPLIES] [I3]
 ON [I3].[ICS_LMT_ID] = [I1].[ICS_LMT_ID] 
 
       WHERE ICS_PARAM_LMTS.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ParameterLimitsSubmission')
								  
	    AND ICS_PARAM_LMTS.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

					
				
	

-- ================================================================
-- ICS_PRMT_REISSU 
-- ================================================================
			
				-- DELETES for: ICS_PRMT_REISSU 
				
								
-- /ICS_PRMT_REISSU
DELETE ICS_PRMT_REISSU
 from ICS_FLOW_ICIS.[ICS_PRMT_REISSU] [ICS_PRMT_REISSU] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRMT_REISSU.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PermitReissuanceSubmission')
				
                  OR ICS_PRMT_REISSU.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
					

				-- INSERTS for: ICS_PRMT_REISSU
	
				
-- /ICS_PRMT_REISSU 
INSERT INTO [ICS_FLOW_ICIS].[ICS_PRMT_REISSU]
     SELECT ICS_PRMT_REISSU.*
        from [ICS_FLOW_LOCAL].[ICS_PRMT_REISSU] [ICS_PRMT_REISSU] 
 
       WHERE ICS_PRMT_REISSU.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PermitReissuanceSubmission')
								  
	    AND ICS_PRMT_REISSU.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

--Remove DMRs for permits that have been reissued after reissue effective date (NCORE-5088)					
SELECT DMR.ICS_DSCH_MON_REP_ID
INTO #DMR_DEL_ON_REISSUE
FROM ICS_FLOW_ICIS.ICS_DSCH_MON_REP DMR
JOIN ICS_FLOW_LOCAL.ICS_PRMT_REISSU IPR ON IPR.PRMT_IDENT = DMR.PRMT_IDENT
JOIN ICS_FLOW_LOCAL.ics_subm_results ISU ON ISU.KEY_HASH = IPR.KEY_HASH 
    AND ISU.RESULT_TYPE_CODE = 'Accepted' 
    AND ISU.SUBM_TYPE_NAME = 'PermitReissuanceSubmission'
WHERE DMR.MON_PERIOD_END_DATE > IPR.PRMT_EFFECTIVE_DATE

DELETE 
FROM ICS_FLOW_ICIS.ICS_DSCH_MON_REP
WHERE ICS_DSCH_MON_REP_ID IN (SELECT ICS_DSCH_MON_REP_ID FROM #DMR_DEL_ON_REISSUE DDOR)
			
	

-- ================================================================
-- ICS_PRMT_FEATR 
-- ================================================================
			
				-- DELETES for: ICS_PRMT_FEATR 
				
								
-- /ICS_PRMT_FEATR/ICS_ADDR/ICS_TELEPH
DELETE I13
 from ICS_FLOW_ICIS.[ICS_PRMT_FEATR] [ICS_PRMT_FEATR] 
 JOIN ICS_FLOW_ICIS.[ICS_ADDR] [I12]
 ON [I12].[ICS_PRMT_FEATR_ID] = [ICS_PRMT_FEATR].[ICS_PRMT_FEATR_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_TELEPH] [I13]
 ON [I13].[ICS_ADDR_ID] = [I12].[ICS_ADDR_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRMT_FEATR.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PermittedFeatureSubmission')
				
                  OR ICS_PRMT_FEATR.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_PRMT_FEATR.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_PRMT_FEATR/ICS_ADDR
DELETE I12
 from ICS_FLOW_ICIS.[ICS_PRMT_FEATR] [ICS_PRMT_FEATR] 
 JOIN ICS_FLOW_ICIS.[ICS_ADDR] [I12]
 ON [I12].[ICS_PRMT_FEATR_ID] = [ICS_PRMT_FEATR].[ICS_PRMT_FEATR_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRMT_FEATR.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PermittedFeatureSubmission')
				
                  OR ICS_PRMT_FEATR.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_PRMT_FEATR.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_PRMT_FEATR/ICS_GEO_COORD
DELETE I11
 from ICS_FLOW_ICIS.[ICS_PRMT_FEATR] [ICS_PRMT_FEATR] 
 JOIN ICS_FLOW_ICIS.[ICS_GEO_COORD] [I11]
 ON [I11].[ICS_PRMT_FEATR_ID] = [ICS_PRMT_FEATR].[ICS_PRMT_FEATR_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRMT_FEATR.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PermittedFeatureSubmission')
				
                  OR ICS_PRMT_FEATR.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_PRMT_FEATR.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_PRMT_FEATR/ICS_PRMT_FEATR_TRTMNT_TYPE
DELETE I10
 from ICS_FLOW_ICIS.[ICS_PRMT_FEATR] [ICS_PRMT_FEATR] 
 JOIN ICS_FLOW_ICIS.[ICS_PRMT_FEATR_TRTMNT_TYPE] [I10]
 ON [I10].[ICS_PRMT_FEATR_ID] = [ICS_PRMT_FEATR].[ICS_PRMT_FEATR_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRMT_FEATR.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PermittedFeatureSubmission')
				
                  OR ICS_PRMT_FEATR.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_PRMT_FEATR.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_PRMT_FEATR/ICS_PRMT_FEATR_CHAR
DELETE I9
 from ICS_FLOW_ICIS.[ICS_PRMT_FEATR] [ICS_PRMT_FEATR] 
 JOIN ICS_FLOW_ICIS.[ICS_PRMT_FEATR_CHAR] [I9]
 ON [I9].[ICS_PRMT_FEATR_ID] = [ICS_PRMT_FEATR].[ICS_PRMT_FEATR_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRMT_FEATR.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PermittedFeatureSubmission')
				
                  OR ICS_PRMT_FEATR.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_PRMT_FEATR.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_PRMT_FEATR/ICS_POLUT_LIST/ICS_TMDL_POLLUTANTS/ICS_TMDL_POLUT
DELETE I8
 from ICS_FLOW_ICIS.[ICS_PRMT_FEATR] [ICS_PRMT_FEATR] 
 JOIN ICS_FLOW_ICIS.[ICS_POLUT_LIST] [I5]
 ON [I5].[ICS_PRMT_FEATR_ID] = [ICS_PRMT_FEATR].[ICS_PRMT_FEATR_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_TMDL_POLLUTANTS] [I7]
 ON [I7].[ICS_POLUT_LIST_ID] = [I5].[ICS_POLUT_LIST_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_TMDL_POLUT] [I8]
 ON [I8].[ICS_TMDL_POLLUTANTS_ID] = [I7].[ICS_TMDL_POLLUTANTS_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRMT_FEATR.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PermittedFeatureSubmission')
				
                  OR ICS_PRMT_FEATR.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_PRMT_FEATR.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_PRMT_FEATR/ICS_POLUT_LIST/ICS_TMDL_POLLUTANTS
DELETE I7
 from ICS_FLOW_ICIS.[ICS_PRMT_FEATR] [ICS_PRMT_FEATR] 
 JOIN ICS_FLOW_ICIS.[ICS_POLUT_LIST] [I5]
 ON [I5].[ICS_PRMT_FEATR_ID] = [ICS_PRMT_FEATR].[ICS_PRMT_FEATR_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_TMDL_POLLUTANTS] [I7]
 ON [I7].[ICS_POLUT_LIST_ID] = [I5].[ICS_POLUT_LIST_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRMT_FEATR.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PermittedFeatureSubmission')
				
                  OR ICS_PRMT_FEATR.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_PRMT_FEATR.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_PRMT_FEATR/ICS_POLUT_LIST/ICS_IMPAIRED_WTR_POLLUTANTS
DELETE I6
 from ICS_FLOW_ICIS.[ICS_PRMT_FEATR] [ICS_PRMT_FEATR] 
 JOIN ICS_FLOW_ICIS.[ICS_POLUT_LIST] [I5]
 ON [I5].[ICS_PRMT_FEATR_ID] = [ICS_PRMT_FEATR].[ICS_PRMT_FEATR_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_IMPAIRED_WTR_POLLUTANTS] [I6]
 ON [I6].[ICS_POLUT_LIST_ID] = [I5].[ICS_POLUT_LIST_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRMT_FEATR.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PermittedFeatureSubmission')
				
                  OR ICS_PRMT_FEATR.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_PRMT_FEATR.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_PRMT_FEATR/ICS_POLUT_LIST
DELETE I5
 from ICS_FLOW_ICIS.[ICS_PRMT_FEATR] [ICS_PRMT_FEATR] 
 JOIN ICS_FLOW_ICIS.[ICS_POLUT_LIST] [I5]
 ON [I5].[ICS_PRMT_FEATR_ID] = [ICS_PRMT_FEATR].[ICS_PRMT_FEATR_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRMT_FEATR.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PermittedFeatureSubmission')
				
                  OR ICS_PRMT_FEATR.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_PRMT_FEATR.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_PRMT_FEATR/ICS_COOLING_WTR_INTAKE_STRCT_INFO/ICS_COOLING_WTR_INTAKE_STRCT_CMPL_METHOD
DELETE I4
 from ICS_FLOW_ICIS.[ICS_PRMT_FEATR] [ICS_PRMT_FEATR] 
 JOIN ICS_FLOW_ICIS.[ICS_COOLING_WTR_INTAKE_STRCT_INFO] [I3]
 ON [I3].[ICS_PRMT_FEATR_ID] = [ICS_PRMT_FEATR].[ICS_PRMT_FEATR_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_COOLING_WTR_INTAKE_STRCT_CMPL_METHOD] [I4]
 ON [I4].[ICS_COOLING_WTR_INTAKE_STRCT_INFO_ID] = [I3].[ICS_COOLING_WTR_INTAKE_STRCT_INFO_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRMT_FEATR.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PermittedFeatureSubmission')
				
                  OR ICS_PRMT_FEATR.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_PRMT_FEATR.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_PRMT_FEATR/ICS_COOLING_WTR_INTAKE_STRCT_INFO
DELETE I3
 from ICS_FLOW_ICIS.[ICS_PRMT_FEATR] [ICS_PRMT_FEATR] 
 JOIN ICS_FLOW_ICIS.[ICS_COOLING_WTR_INTAKE_STRCT_INFO] [I3]
 ON [I3].[ICS_PRMT_FEATR_ID] = [ICS_PRMT_FEATR].[ICS_PRMT_FEATR_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRMT_FEATR.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PermittedFeatureSubmission')
				
                  OR ICS_PRMT_FEATR.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_PRMT_FEATR.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_PRMT_FEATR/ICS_CONTACT/ICS_TELEPH
DELETE I2
 from ICS_FLOW_ICIS.[ICS_PRMT_FEATR] [ICS_PRMT_FEATR] 
 JOIN ICS_FLOW_ICIS.[ICS_CONTACT] [I1]
 ON [I1].[ICS_PRMT_FEATR_ID] = [ICS_PRMT_FEATR].[ICS_PRMT_FEATR_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_TELEPH] [I2]
 ON [I2].[ICS_CONTACT_ID] = [I1].[ICS_CONTACT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRMT_FEATR.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PermittedFeatureSubmission')
				
                  OR ICS_PRMT_FEATR.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_PRMT_FEATR.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_PRMT_FEATR/ICS_CONTACT
DELETE I1
 from ICS_FLOW_ICIS.[ICS_PRMT_FEATR] [ICS_PRMT_FEATR] 
 JOIN ICS_FLOW_ICIS.[ICS_CONTACT] [I1]
 ON [I1].[ICS_PRMT_FEATR_ID] = [ICS_PRMT_FEATR].[ICS_PRMT_FEATR_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRMT_FEATR.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PermittedFeatureSubmission')
				
                  OR ICS_PRMT_FEATR.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_PRMT_FEATR.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_PRMT_FEATR
DELETE ICS_PRMT_FEATR
 from ICS_FLOW_ICIS.[ICS_PRMT_FEATR] [ICS_PRMT_FEATR] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRMT_FEATR.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PermittedFeatureSubmission')
				
                  OR ICS_PRMT_FEATR.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_PRMT_FEATR.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
					

				-- INSERTS for: ICS_PRMT_FEATR
	
				
-- /ICS_PRMT_FEATR 
INSERT INTO [ICS_FLOW_ICIS].[ICS_PRMT_FEATR]
     SELECT ICS_PRMT_FEATR.*
        from [ICS_FLOW_LOCAL].[ICS_PRMT_FEATR] [ICS_PRMT_FEATR] 
 
       WHERE ICS_PRMT_FEATR.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PermittedFeatureSubmission')
								  
	    AND ICS_PRMT_FEATR.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_PRMT_FEATR/ICS_CONTACT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_CONTACT]
     SELECT I1.*
        from [ICS_FLOW_LOCAL].[ICS_PRMT_FEATR] [ICS_PRMT_FEATR] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTACT] [I1]
 ON [I1].[ICS_PRMT_FEATR_ID] = [ICS_PRMT_FEATR].[ICS_PRMT_FEATR_ID] 
 
       WHERE ICS_PRMT_FEATR.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PermittedFeatureSubmission')
								  
	    AND ICS_PRMT_FEATR.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_PRMT_FEATR/ICS_CONTACT/ICS_TELEPH 
INSERT INTO [ICS_FLOW_ICIS].[ICS_TELEPH]
     SELECT I2.*
        from [ICS_FLOW_LOCAL].[ICS_PRMT_FEATR] [ICS_PRMT_FEATR] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTACT] [I1]
 ON [I1].[ICS_PRMT_FEATR_ID] = [ICS_PRMT_FEATR].[ICS_PRMT_FEATR_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_TELEPH] [I2]
 ON [I2].[ICS_CONTACT_ID] = [I1].[ICS_CONTACT_ID] 
 
       WHERE ICS_PRMT_FEATR.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PermittedFeatureSubmission')
								  
	    AND ICS_PRMT_FEATR.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_PRMT_FEATR/ICS_COOLING_WTR_INTAKE_STRCT_INFO 
INSERT INTO [ICS_FLOW_ICIS].[ICS_COOLING_WTR_INTAKE_STRCT_INFO]
     SELECT I3.*
        from [ICS_FLOW_LOCAL].[ICS_PRMT_FEATR] [ICS_PRMT_FEATR] 
 JOIN [ICS_FLOW_LOCAL].[ICS_COOLING_WTR_INTAKE_STRCT_INFO] [I3]
 ON [I3].[ICS_PRMT_FEATR_ID] = [ICS_PRMT_FEATR].[ICS_PRMT_FEATR_ID] 
 
       WHERE ICS_PRMT_FEATR.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PermittedFeatureSubmission')
								  
	    AND ICS_PRMT_FEATR.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_PRMT_FEATR/ICS_COOLING_WTR_INTAKE_STRCT_INFO/ICS_COOLING_WTR_INTAKE_STRCT_CMPL_METHOD 
INSERT INTO [ICS_FLOW_ICIS].[ICS_COOLING_WTR_INTAKE_STRCT_CMPL_METHOD]
     SELECT I4.*
        from [ICS_FLOW_LOCAL].[ICS_PRMT_FEATR] [ICS_PRMT_FEATR] 
 JOIN [ICS_FLOW_LOCAL].[ICS_COOLING_WTR_INTAKE_STRCT_INFO] [I3]
 ON [I3].[ICS_PRMT_FEATR_ID] = [ICS_PRMT_FEATR].[ICS_PRMT_FEATR_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_COOLING_WTR_INTAKE_STRCT_CMPL_METHOD] [I4]
 ON [I4].[ICS_COOLING_WTR_INTAKE_STRCT_INFO_ID] = [I3].[ICS_COOLING_WTR_INTAKE_STRCT_INFO_ID] 
 
       WHERE ICS_PRMT_FEATR.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PermittedFeatureSubmission')
								  
	    AND ICS_PRMT_FEATR.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_PRMT_FEATR/ICS_POLUT_LIST 
INSERT INTO [ICS_FLOW_ICIS].[ICS_POLUT_LIST]
     SELECT I5.*
        from [ICS_FLOW_LOCAL].[ICS_PRMT_FEATR] [ICS_PRMT_FEATR] 
 JOIN [ICS_FLOW_LOCAL].[ICS_POLUT_LIST] [I5]
 ON [I5].[ICS_PRMT_FEATR_ID] = [ICS_PRMT_FEATR].[ICS_PRMT_FEATR_ID] 
 
       WHERE ICS_PRMT_FEATR.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PermittedFeatureSubmission')
								  
	    AND ICS_PRMT_FEATR.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_PRMT_FEATR/ICS_POLUT_LIST/ICS_IMPAIRED_WTR_POLLUTANTS 
INSERT INTO [ICS_FLOW_ICIS].[ICS_IMPAIRED_WTR_POLLUTANTS]
     SELECT I6.*
        from [ICS_FLOW_LOCAL].[ICS_PRMT_FEATR] [ICS_PRMT_FEATR] 
 JOIN [ICS_FLOW_LOCAL].[ICS_POLUT_LIST] [I5]
 ON [I5].[ICS_PRMT_FEATR_ID] = [ICS_PRMT_FEATR].[ICS_PRMT_FEATR_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_IMPAIRED_WTR_POLLUTANTS] [I6]
 ON [I6].[ICS_POLUT_LIST_ID] = [I5].[ICS_POLUT_LIST_ID] 
 
       WHERE ICS_PRMT_FEATR.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PermittedFeatureSubmission')
								  
	    AND ICS_PRMT_FEATR.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_PRMT_FEATR/ICS_POLUT_LIST/ICS_TMDL_POLLUTANTS 
INSERT INTO [ICS_FLOW_ICIS].[ICS_TMDL_POLLUTANTS]
     SELECT I7.*
        from [ICS_FLOW_LOCAL].[ICS_PRMT_FEATR] [ICS_PRMT_FEATR] 
 JOIN [ICS_FLOW_LOCAL].[ICS_POLUT_LIST] [I5]
 ON [I5].[ICS_PRMT_FEATR_ID] = [ICS_PRMT_FEATR].[ICS_PRMT_FEATR_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_TMDL_POLLUTANTS] [I7]
 ON [I7].[ICS_POLUT_LIST_ID] = [I5].[ICS_POLUT_LIST_ID] 
 
       WHERE ICS_PRMT_FEATR.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PermittedFeatureSubmission')
								  
	    AND ICS_PRMT_FEATR.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_PRMT_FEATR/ICS_POLUT_LIST/ICS_TMDL_POLLUTANTS/ICS_TMDL_POLUT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_TMDL_POLUT]
     SELECT I8.*
        from [ICS_FLOW_LOCAL].[ICS_PRMT_FEATR] [ICS_PRMT_FEATR] 
 JOIN [ICS_FLOW_LOCAL].[ICS_POLUT_LIST] [I5]
 ON [I5].[ICS_PRMT_FEATR_ID] = [ICS_PRMT_FEATR].[ICS_PRMT_FEATR_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_TMDL_POLLUTANTS] [I7]
 ON [I7].[ICS_POLUT_LIST_ID] = [I5].[ICS_POLUT_LIST_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_TMDL_POLUT] [I8]
 ON [I8].[ICS_TMDL_POLLUTANTS_ID] = [I7].[ICS_TMDL_POLLUTANTS_ID] 
 
       WHERE ICS_PRMT_FEATR.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PermittedFeatureSubmission')
								  
	    AND ICS_PRMT_FEATR.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_PRMT_FEATR/ICS_PRMT_FEATR_CHAR 
INSERT INTO [ICS_FLOW_ICIS].[ICS_PRMT_FEATR_CHAR]
     SELECT I9.*
        from [ICS_FLOW_LOCAL].[ICS_PRMT_FEATR] [ICS_PRMT_FEATR] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PRMT_FEATR_CHAR] [I9]
 ON [I9].[ICS_PRMT_FEATR_ID] = [ICS_PRMT_FEATR].[ICS_PRMT_FEATR_ID] 
 
       WHERE ICS_PRMT_FEATR.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PermittedFeatureSubmission')
								  
	    AND ICS_PRMT_FEATR.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_PRMT_FEATR/ICS_PRMT_FEATR_TRTMNT_TYPE 
INSERT INTO [ICS_FLOW_ICIS].[ICS_PRMT_FEATR_TRTMNT_TYPE]
     SELECT I10.*
        from [ICS_FLOW_LOCAL].[ICS_PRMT_FEATR] [ICS_PRMT_FEATR] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PRMT_FEATR_TRTMNT_TYPE] [I10]
 ON [I10].[ICS_PRMT_FEATR_ID] = [ICS_PRMT_FEATR].[ICS_PRMT_FEATR_ID] 
 
       WHERE ICS_PRMT_FEATR.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PermittedFeatureSubmission')
								  
	    AND ICS_PRMT_FEATR.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_PRMT_FEATR/ICS_GEO_COORD 
INSERT INTO [ICS_FLOW_ICIS].[ICS_GEO_COORD]
     SELECT I11.*
        from [ICS_FLOW_LOCAL].[ICS_PRMT_FEATR] [ICS_PRMT_FEATR] 
 JOIN [ICS_FLOW_LOCAL].[ICS_GEO_COORD] [I11]
 ON [I11].[ICS_PRMT_FEATR_ID] = [ICS_PRMT_FEATR].[ICS_PRMT_FEATR_ID] 
 
       WHERE ICS_PRMT_FEATR.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PermittedFeatureSubmission')
								  
	    AND ICS_PRMT_FEATR.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_PRMT_FEATR/ICS_ADDR 
INSERT INTO [ICS_FLOW_ICIS].[ICS_ADDR]
     SELECT I12.*
        from [ICS_FLOW_LOCAL].[ICS_PRMT_FEATR] [ICS_PRMT_FEATR] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ADDR] [I12]
 ON [I12].[ICS_PRMT_FEATR_ID] = [ICS_PRMT_FEATR].[ICS_PRMT_FEATR_ID] 
 
       WHERE ICS_PRMT_FEATR.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PermittedFeatureSubmission')
								  
	    AND ICS_PRMT_FEATR.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_PRMT_FEATR/ICS_ADDR/ICS_TELEPH 
INSERT INTO [ICS_FLOW_ICIS].[ICS_TELEPH]
     SELECT I13.*
        from [ICS_FLOW_LOCAL].[ICS_PRMT_FEATR] [ICS_PRMT_FEATR] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ADDR] [I12]
 ON [I12].[ICS_PRMT_FEATR_ID] = [ICS_PRMT_FEATR].[ICS_PRMT_FEATR_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_TELEPH] [I13]
 ON [I13].[ICS_ADDR_ID] = [I12].[ICS_ADDR_ID] 
 
       WHERE ICS_PRMT_FEATR.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PermittedFeatureSubmission')
								  
	    AND ICS_PRMT_FEATR.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

					
				
	

-- ================================================================
-- ICS_PRMT_TERM 
-- ================================================================
			
				-- DELETES for: ICS_PRMT_TERM 
				
								
-- /ICS_PRMT_TERM
DELETE ICS_PRMT_TERM
 from ICS_FLOW_ICIS.[ICS_PRMT_TERM] [ICS_PRMT_TERM] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRMT_TERM.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PermitTerminationSubmission')
				  ;
          				
				
					

				-- INSERTS for: ICS_PRMT_TERM
	
				
-- /ICS_PRMT_TERM 
INSERT INTO [ICS_FLOW_ICIS].[ICS_PRMT_TERM]
     SELECT ICS_PRMT_TERM.*
        from [ICS_FLOW_LOCAL].[ICS_PRMT_TERM] [ICS_PRMT_TERM] 
 
       WHERE ICS_PRMT_TERM.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PermitTerminationSubmission')
				 
				  ;			 

					
				
	

-- ================================================================
-- ICS_PRMT_TRACK_EVT 
-- ================================================================
			
				-- DELETES for: ICS_PRMT_TRACK_EVT 
				
								
-- /ICS_PRMT_TRACK_EVT
DELETE ICS_PRMT_TRACK_EVT
 from ICS_FLOW_ICIS.[ICS_PRMT_TRACK_EVT] [ICS_PRMT_TRACK_EVT] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRMT_TRACK_EVT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PermitTrackingEventSubmission')
				
                  OR ICS_PRMT_TRACK_EVT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
					

				-- INSERTS for: ICS_PRMT_TRACK_EVT
	
				
-- /ICS_PRMT_TRACK_EVT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_PRMT_TRACK_EVT]
     SELECT ICS_PRMT_TRACK_EVT.*
        from [ICS_FLOW_LOCAL].[ICS_PRMT_TRACK_EVT] [ICS_PRMT_TRACK_EVT] 
 
       WHERE ICS_PRMT_TRACK_EVT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PermitTrackingEventSubmission')
								  
	    AND ICS_PRMT_TRACK_EVT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

					
				
	

-- ================================================================
-- ICS_POTW_PRMT 
-- ================================================================
			
				-- DELETES for: ICS_POTW_PRMT 
				
								
-- /ICS_POTW_PRMT/ICS_SATL_COLL_SYSTM
DELETE I1
 from ICS_FLOW_ICIS.[ICS_POTW_PRMT] [ICS_POTW_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_SATL_COLL_SYSTM] [I1]
 ON [I1].[ICS_POTW_PRMT_ID] = [ICS_POTW_PRMT].[ICS_POTW_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_POTW_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'POTWPermitSubmission')
				
                  OR ICS_POTW_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_POTW_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_POTW_PRMT
DELETE ICS_POTW_PRMT
 from ICS_FLOW_ICIS.[ICS_POTW_PRMT] [ICS_POTW_PRMT] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_POTW_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'POTWPermitSubmission')
				
                  OR ICS_POTW_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_POTW_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
					

				-- INSERTS for: ICS_POTW_PRMT
	
				
-- /ICS_POTW_PRMT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_POTW_PRMT]
     SELECT ICS_POTW_PRMT.*
        from [ICS_FLOW_LOCAL].[ICS_POTW_PRMT] [ICS_POTW_PRMT] 
 
       WHERE ICS_POTW_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'POTWPermitSubmission')
								  
	    AND ICS_POTW_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_POTW_PRMT/ICS_SATL_COLL_SYSTM 
INSERT INTO [ICS_FLOW_ICIS].[ICS_SATL_COLL_SYSTM]
     SELECT I1.*
        from [ICS_FLOW_LOCAL].[ICS_POTW_PRMT] [ICS_POTW_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SATL_COLL_SYSTM] [I1]
 ON [I1].[ICS_POTW_PRMT_ID] = [ICS_POTW_PRMT].[ICS_POTW_PRMT_ID] 
 
       WHERE ICS_POTW_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'POTWPermitSubmission')
								  
	    AND ICS_POTW_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

					
				
	

-- ================================================================
-- ICS_POTW_TRTMNT_TECHNOLOGY_PRMT 
-- ================================================================
			
				-- DELETES for: ICS_POTW_TRTMNT_TECHNOLOGY_PRMT 
				
								
-- /ICS_POTW_TRTMNT_TECHNOLOGY_PRMT
DELETE ICS_POTW_TRTMNT_TECHNOLOGY_PRMT
 from ICS_FLOW_ICIS.[ICS_POTW_TRTMNT_TECHNOLOGY_PRMT] [ICS_POTW_TRTMNT_TECHNOLOGY_PRMT] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_POTW_TRTMNT_TECHNOLOGY_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'POTWTreatmentTechnologyPermitSubmission')
				
                  OR ICS_POTW_TRTMNT_TECHNOLOGY_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_POTW_TRTMNT_TECHNOLOGY_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
					

				-- INSERTS for: ICS_POTW_TRTMNT_TECHNOLOGY_PRMT
	
				
-- /ICS_POTW_TRTMNT_TECHNOLOGY_PRMT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_POTW_TRTMNT_TECHNOLOGY_PRMT]
     SELECT ICS_POTW_TRTMNT_TECHNOLOGY_PRMT.*
        from [ICS_FLOW_LOCAL].[ICS_POTW_TRTMNT_TECHNOLOGY_PRMT] [ICS_POTW_TRTMNT_TECHNOLOGY_PRMT] 
 
       WHERE ICS_POTW_TRTMNT_TECHNOLOGY_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'POTWTreatmentTechnologyPermitSubmission')
								  
	    AND ICS_POTW_TRTMNT_TECHNOLOGY_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

					
				
	

-- ================================================================
-- ICS_PRETR_PRMT 
-- ================================================================
			
				-- DELETES for: ICS_PRETR_PRMT 
				
								
-- /ICS_PRETR_PRMT/ICS_PRETR_PROG_MOD
DELETE I3
 from ICS_FLOW_ICIS.[ICS_PRETR_PRMT] [ICS_PRETR_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_PRETR_PROG_MOD] [I3]
 ON [I3].[ICS_PRETR_PRMT_ID] = [ICS_PRETR_PRMT].[ICS_PRETR_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRETR_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PretreatmentPermitSubmission')
				
                  OR ICS_PRETR_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_PRETR_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_PRETR_PRMT/ICS_CONTACT/ICS_TELEPH
DELETE I2
 from ICS_FLOW_ICIS.[ICS_PRETR_PRMT] [ICS_PRETR_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_CONTACT] [I1]
 ON [I1].[ICS_PRETR_PRMT_ID] = [ICS_PRETR_PRMT].[ICS_PRETR_PRMT_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_TELEPH] [I2]
 ON [I2].[ICS_CONTACT_ID] = [I1].[ICS_CONTACT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRETR_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PretreatmentPermitSubmission')
				
                  OR ICS_PRETR_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_PRETR_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_PRETR_PRMT/ICS_CONTACT
DELETE I1
 from ICS_FLOW_ICIS.[ICS_PRETR_PRMT] [ICS_PRETR_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_CONTACT] [I1]
 ON [I1].[ICS_PRETR_PRMT_ID] = [ICS_PRETR_PRMT].[ICS_PRETR_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRETR_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PretreatmentPermitSubmission')
				
                  OR ICS_PRETR_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_PRETR_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_PRETR_PRMT
DELETE ICS_PRETR_PRMT
 from ICS_FLOW_ICIS.[ICS_PRETR_PRMT] [ICS_PRETR_PRMT] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRETR_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PretreatmentPermitSubmission')
				
                  OR ICS_PRETR_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_PRETR_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
					

				-- INSERTS for: ICS_PRETR_PRMT
	
				
-- /ICS_PRETR_PRMT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_PRETR_PRMT]
     SELECT ICS_PRETR_PRMT.*
        from [ICS_FLOW_LOCAL].[ICS_PRETR_PRMT] [ICS_PRETR_PRMT] 
 
       WHERE ICS_PRETR_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PretreatmentPermitSubmission')
								  
	    AND ICS_PRETR_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_PRETR_PRMT/ICS_CONTACT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_CONTACT]
     SELECT I1.*
        from [ICS_FLOW_LOCAL].[ICS_PRETR_PRMT] [ICS_PRETR_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTACT] [I1]
 ON [I1].[ICS_PRETR_PRMT_ID] = [ICS_PRETR_PRMT].[ICS_PRETR_PRMT_ID] 
 
       WHERE ICS_PRETR_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PretreatmentPermitSubmission')
								  
	    AND ICS_PRETR_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_PRETR_PRMT/ICS_CONTACT/ICS_TELEPH 
INSERT INTO [ICS_FLOW_ICIS].[ICS_TELEPH]
     SELECT I2.*
        from [ICS_FLOW_LOCAL].[ICS_PRETR_PRMT] [ICS_PRETR_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTACT] [I1]
 ON [I1].[ICS_PRETR_PRMT_ID] = [ICS_PRETR_PRMT].[ICS_PRETR_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_TELEPH] [I2]
 ON [I2].[ICS_CONTACT_ID] = [I1].[ICS_CONTACT_ID] 
 
       WHERE ICS_PRETR_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PretreatmentPermitSubmission')
								  
	    AND ICS_PRETR_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_PRETR_PRMT/ICS_PRETR_PROG_MOD 
INSERT INTO [ICS_FLOW_ICIS].[ICS_PRETR_PROG_MOD]
     SELECT I3.*
        from [ICS_FLOW_LOCAL].[ICS_PRETR_PRMT] [ICS_PRETR_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PRETR_PROG_MOD] [I3]
 ON [I3].[ICS_PRETR_PRMT_ID] = [ICS_PRETR_PRMT].[ICS_PRETR_PRMT_ID] 
 
       WHERE ICS_PRETR_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PretreatmentPermitSubmission')
								  
	    AND ICS_PRETR_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

					
				
	

-- ================================================================
-- ICS_PRETR_PROG_REP 
-- ================================================================
			
				-- DELETES for: ICS_PRETR_PROG_REP 
				
								
-- /ICS_PRETR_PROG_REP/ICS_INDST_USR_INVENTORY/ICS_INDST_USR_INFO/ICS_IU_VIOL_INFO/ICS_SNC_PRETR_STND_LMTS_PARAMETERS
DELETE I9
 from ICS_FLOW_ICIS.[ICS_PRETR_PROG_REP] [ICS_PRETR_PROG_REP] 
 JOIN ICS_FLOW_ICIS.[ICS_INDST_USR_INVENTORY] [I3]
 ON [I3].[ICS_PRETR_PROG_REP_ID] = [ICS_PRETR_PROG_REP].[ICS_PRETR_PROG_REP_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_INDST_USR_INFO] [I4]
 ON [I4].[ICS_INDST_USR_INVENTORY_ID] = [I3].[ICS_INDST_USR_INVENTORY_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_IU_VIOL_INFO] [I7]
 ON [I7].[ICS_INDST_USR_INFO_ID] = [I4].[ICS_INDST_USR_INFO_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_SNC_PRETR_STND_LMTS_PARAMETERS] [I9]
 ON [I9].[ICS_IU_VIOL_INFO_ID] = [I7].[ICS_IU_VIOL_INFO_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRETR_PROG_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PretreatmentProgramReportSubmission')
				
                  OR ICS_PRETR_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_PRETR_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_PRETR_PROG_REP/ICS_INDST_USR_INVENTORY/ICS_INDST_USR_INFO/ICS_IU_VIOL_INFO/ICS_SNC_LISTING_MONTHS
DELETE I8
 from ICS_FLOW_ICIS.[ICS_PRETR_PROG_REP] [ICS_PRETR_PROG_REP] 
 JOIN ICS_FLOW_ICIS.[ICS_INDST_USR_INVENTORY] [I3]
 ON [I3].[ICS_PRETR_PROG_REP_ID] = [ICS_PRETR_PROG_REP].[ICS_PRETR_PROG_REP_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_INDST_USR_INFO] [I4]
 ON [I4].[ICS_INDST_USR_INVENTORY_ID] = [I3].[ICS_INDST_USR_INVENTORY_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_IU_VIOL_INFO] [I7]
 ON [I7].[ICS_INDST_USR_INFO_ID] = [I4].[ICS_INDST_USR_INFO_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_SNC_LISTING_MONTHS] [I8]
 ON [I8].[ICS_IU_VIOL_INFO_ID] = [I7].[ICS_IU_VIOL_INFO_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRETR_PROG_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PretreatmentProgramReportSubmission')
				
                  OR ICS_PRETR_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_PRETR_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_PRETR_PROG_REP/ICS_INDST_USR_INVENTORY/ICS_INDST_USR_INFO/ICS_IU_VIOL_INFO
DELETE I7
 from ICS_FLOW_ICIS.[ICS_PRETR_PROG_REP] [ICS_PRETR_PROG_REP] 
 JOIN ICS_FLOW_ICIS.[ICS_INDST_USR_INVENTORY] [I3]
 ON [I3].[ICS_PRETR_PROG_REP_ID] = [ICS_PRETR_PROG_REP].[ICS_PRETR_PROG_REP_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_INDST_USR_INFO] [I4]
 ON [I4].[ICS_INDST_USR_INVENTORY_ID] = [I3].[ICS_INDST_USR_INVENTORY_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_IU_VIOL_INFO] [I7]
 ON [I7].[ICS_INDST_USR_INFO_ID] = [I4].[ICS_INDST_USR_INFO_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRETR_PROG_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PretreatmentProgramReportSubmission')
				
                  OR ICS_PRETR_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_PRETR_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_PRETR_PROG_REP/ICS_INDST_USR_INVENTORY/ICS_INDST_USR_INFO/ICS_IU_ENFRC_ACTN_INFO/ICS_IU_ENF_ACTN_TYPES
DELETE I6
 from ICS_FLOW_ICIS.[ICS_PRETR_PROG_REP] [ICS_PRETR_PROG_REP] 
 JOIN ICS_FLOW_ICIS.[ICS_INDST_USR_INVENTORY] [I3]
 ON [I3].[ICS_PRETR_PROG_REP_ID] = [ICS_PRETR_PROG_REP].[ICS_PRETR_PROG_REP_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_INDST_USR_INFO] [I4]
 ON [I4].[ICS_INDST_USR_INVENTORY_ID] = [I3].[ICS_INDST_USR_INVENTORY_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_IU_ENFRC_ACTN_INFO] [I5]
 ON [I5].[ICS_INDST_USR_INFO_ID] = [I4].[ICS_INDST_USR_INFO_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_IU_ENF_ACTN_TYPES] [I6]
 ON [I6].[ICS_IU_ENFRC_ACTN_INFO_ID] = [I5].[ICS_IU_ENFRC_ACTN_INFO_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRETR_PROG_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PretreatmentProgramReportSubmission')
				
                  OR ICS_PRETR_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_PRETR_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_PRETR_PROG_REP/ICS_INDST_USR_INVENTORY/ICS_INDST_USR_INFO/ICS_IU_ENFRC_ACTN_INFO
DELETE I5
 from ICS_FLOW_ICIS.[ICS_PRETR_PROG_REP] [ICS_PRETR_PROG_REP] 
 JOIN ICS_FLOW_ICIS.[ICS_INDST_USR_INVENTORY] [I3]
 ON [I3].[ICS_PRETR_PROG_REP_ID] = [ICS_PRETR_PROG_REP].[ICS_PRETR_PROG_REP_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_INDST_USR_INFO] [I4]
 ON [I4].[ICS_INDST_USR_INVENTORY_ID] = [I3].[ICS_INDST_USR_INVENTORY_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_IU_ENFRC_ACTN_INFO] [I5]
 ON [I5].[ICS_INDST_USR_INFO_ID] = [I4].[ICS_INDST_USR_INFO_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRETR_PROG_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PretreatmentProgramReportSubmission')
				
                  OR ICS_PRETR_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_PRETR_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_PRETR_PROG_REP/ICS_INDST_USR_INVENTORY/ICS_INDST_USR_INFO
DELETE I4
 from ICS_FLOW_ICIS.[ICS_PRETR_PROG_REP] [ICS_PRETR_PROG_REP] 
 JOIN ICS_FLOW_ICIS.[ICS_INDST_USR_INVENTORY] [I3]
 ON [I3].[ICS_PRETR_PROG_REP_ID] = [ICS_PRETR_PROG_REP].[ICS_PRETR_PROG_REP_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_INDST_USR_INFO] [I4]
 ON [I4].[ICS_INDST_USR_INVENTORY_ID] = [I3].[ICS_INDST_USR_INVENTORY_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRETR_PROG_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PretreatmentProgramReportSubmission')
				
                  OR ICS_PRETR_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_PRETR_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_PRETR_PROG_REP/ICS_INDST_USR_INVENTORY
DELETE I3
 from ICS_FLOW_ICIS.[ICS_PRETR_PROG_REP] [ICS_PRETR_PROG_REP] 
 JOIN ICS_FLOW_ICIS.[ICS_INDST_USR_INVENTORY] [I3]
 ON [I3].[ICS_PRETR_PROG_REP_ID] = [ICS_PRETR_PROG_REP].[ICS_PRETR_PROG_REP_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRETR_PROG_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PretreatmentProgramReportSubmission')
				
                  OR ICS_PRETR_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_PRETR_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_PRETR_PROG_REP/ICS_CONTROL_AUTH_PROG_INFO/ICS_LOC_LMTS_PARAMETERS
DELETE I2
 from ICS_FLOW_ICIS.[ICS_PRETR_PROG_REP] [ICS_PRETR_PROG_REP] 
 JOIN ICS_FLOW_ICIS.[ICS_CONTROL_AUTH_PROG_INFO] [I1]
 ON [I1].[ICS_PRETR_PROG_REP_ID] = [ICS_PRETR_PROG_REP].[ICS_PRETR_PROG_REP_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_LOC_LMTS_PARAMETERS] [I2]
 ON [I2].[ICS_CONTROL_AUTH_PROG_INFO_ID] = [I1].[ICS_CONTROL_AUTH_PROG_INFO_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRETR_PROG_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PretreatmentProgramReportSubmission')
				
                  OR ICS_PRETR_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_PRETR_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_PRETR_PROG_REP/ICS_CONTROL_AUTH_PROG_INFO
DELETE I1
 from ICS_FLOW_ICIS.[ICS_PRETR_PROG_REP] [ICS_PRETR_PROG_REP] 
 JOIN ICS_FLOW_ICIS.[ICS_CONTROL_AUTH_PROG_INFO] [I1]
 ON [I1].[ICS_PRETR_PROG_REP_ID] = [ICS_PRETR_PROG_REP].[ICS_PRETR_PROG_REP_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRETR_PROG_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PretreatmentProgramReportSubmission')
				
                  OR ICS_PRETR_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_PRETR_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_PRETR_PROG_REP
DELETE ICS_PRETR_PROG_REP
 from ICS_FLOW_ICIS.[ICS_PRETR_PROG_REP] [ICS_PRETR_PROG_REP] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRETR_PROG_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PretreatmentProgramReportSubmission')
				
                  OR ICS_PRETR_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_PRETR_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
					

				-- INSERTS for: ICS_PRETR_PROG_REP
	
				
-- /ICS_PRETR_PROG_REP 
INSERT INTO [ICS_FLOW_ICIS].[ICS_PRETR_PROG_REP]
     SELECT ICS_PRETR_PROG_REP.*
        from [ICS_FLOW_LOCAL].[ICS_PRETR_PROG_REP] [ICS_PRETR_PROG_REP] 
 
       WHERE ICS_PRETR_PROG_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PretreatmentProgramReportSubmission')
								  
	    AND ICS_PRETR_PROG_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_PRETR_PROG_REP/ICS_CONTROL_AUTH_PROG_INFO 
INSERT INTO [ICS_FLOW_ICIS].[ICS_CONTROL_AUTH_PROG_INFO]
     SELECT I1.*
        from [ICS_FLOW_LOCAL].[ICS_PRETR_PROG_REP] [ICS_PRETR_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTROL_AUTH_PROG_INFO] [I1]
 ON [I1].[ICS_PRETR_PROG_REP_ID] = [ICS_PRETR_PROG_REP].[ICS_PRETR_PROG_REP_ID] 
 
       WHERE ICS_PRETR_PROG_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PretreatmentProgramReportSubmission')
								  
	    AND ICS_PRETR_PROG_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_PRETR_PROG_REP/ICS_CONTROL_AUTH_PROG_INFO/ICS_LOC_LMTS_PARAMETERS 
INSERT INTO [ICS_FLOW_ICIS].[ICS_LOC_LMTS_PARAMETERS]
     SELECT I2.*
        from [ICS_FLOW_LOCAL].[ICS_PRETR_PROG_REP] [ICS_PRETR_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTROL_AUTH_PROG_INFO] [I1]
 ON [I1].[ICS_PRETR_PROG_REP_ID] = [ICS_PRETR_PROG_REP].[ICS_PRETR_PROG_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_LOC_LMTS_PARAMETERS] [I2]
 ON [I2].[ICS_CONTROL_AUTH_PROG_INFO_ID] = [I1].[ICS_CONTROL_AUTH_PROG_INFO_ID] 
 
       WHERE ICS_PRETR_PROG_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PretreatmentProgramReportSubmission')
								  
	    AND ICS_PRETR_PROG_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_PRETR_PROG_REP/ICS_INDST_USR_INVENTORY 
INSERT INTO [ICS_FLOW_ICIS].[ICS_INDST_USR_INVENTORY]
     SELECT I3.*
        from [ICS_FLOW_LOCAL].[ICS_PRETR_PROG_REP] [ICS_PRETR_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_INDST_USR_INVENTORY] [I3]
 ON [I3].[ICS_PRETR_PROG_REP_ID] = [ICS_PRETR_PROG_REP].[ICS_PRETR_PROG_REP_ID] 
 
       WHERE ICS_PRETR_PROG_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PretreatmentProgramReportSubmission')
								  
	    AND ICS_PRETR_PROG_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_PRETR_PROG_REP/ICS_INDST_USR_INVENTORY/ICS_INDST_USR_INFO 
INSERT INTO [ICS_FLOW_ICIS].[ICS_INDST_USR_INFO]
     SELECT I4.*
        from [ICS_FLOW_LOCAL].[ICS_PRETR_PROG_REP] [ICS_PRETR_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_INDST_USR_INVENTORY] [I3]
 ON [I3].[ICS_PRETR_PROG_REP_ID] = [ICS_PRETR_PROG_REP].[ICS_PRETR_PROG_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_INDST_USR_INFO] [I4]
 ON [I4].[ICS_INDST_USR_INVENTORY_ID] = [I3].[ICS_INDST_USR_INVENTORY_ID] 
 
       WHERE ICS_PRETR_PROG_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PretreatmentProgramReportSubmission')
								  
	    AND ICS_PRETR_PROG_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_PRETR_PROG_REP/ICS_INDST_USR_INVENTORY/ICS_INDST_USR_INFO/ICS_IU_ENFRC_ACTN_INFO 
INSERT INTO [ICS_FLOW_ICIS].[ICS_IU_ENFRC_ACTN_INFO]
     SELECT I5.*
        from [ICS_FLOW_LOCAL].[ICS_PRETR_PROG_REP] [ICS_PRETR_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_INDST_USR_INVENTORY] [I3]
 ON [I3].[ICS_PRETR_PROG_REP_ID] = [ICS_PRETR_PROG_REP].[ICS_PRETR_PROG_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_INDST_USR_INFO] [I4]
 ON [I4].[ICS_INDST_USR_INVENTORY_ID] = [I3].[ICS_INDST_USR_INVENTORY_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_IU_ENFRC_ACTN_INFO] [I5]
 ON [I5].[ICS_INDST_USR_INFO_ID] = [I4].[ICS_INDST_USR_INFO_ID] 
 
       WHERE ICS_PRETR_PROG_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PretreatmentProgramReportSubmission')
								  
	    AND ICS_PRETR_PROG_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_PRETR_PROG_REP/ICS_INDST_USR_INVENTORY/ICS_INDST_USR_INFO/ICS_IU_ENFRC_ACTN_INFO/ICS_IU_ENF_ACTN_TYPES 
INSERT INTO [ICS_FLOW_ICIS].[ICS_IU_ENF_ACTN_TYPES]
     SELECT I6.*
        from [ICS_FLOW_LOCAL].[ICS_PRETR_PROG_REP] [ICS_PRETR_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_INDST_USR_INVENTORY] [I3]
 ON [I3].[ICS_PRETR_PROG_REP_ID] = [ICS_PRETR_PROG_REP].[ICS_PRETR_PROG_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_INDST_USR_INFO] [I4]
 ON [I4].[ICS_INDST_USR_INVENTORY_ID] = [I3].[ICS_INDST_USR_INVENTORY_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_IU_ENFRC_ACTN_INFO] [I5]
 ON [I5].[ICS_INDST_USR_INFO_ID] = [I4].[ICS_INDST_USR_INFO_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_IU_ENF_ACTN_TYPES] [I6]
 ON [I6].[ICS_IU_ENFRC_ACTN_INFO_ID] = [I5].[ICS_IU_ENFRC_ACTN_INFO_ID] 
 
       WHERE ICS_PRETR_PROG_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PretreatmentProgramReportSubmission')
								  
	    AND ICS_PRETR_PROG_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_PRETR_PROG_REP/ICS_INDST_USR_INVENTORY/ICS_INDST_USR_INFO/ICS_IU_VIOL_INFO 
INSERT INTO [ICS_FLOW_ICIS].[ICS_IU_VIOL_INFO]
     SELECT I7.*
        from [ICS_FLOW_LOCAL].[ICS_PRETR_PROG_REP] [ICS_PRETR_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_INDST_USR_INVENTORY] [I3]
 ON [I3].[ICS_PRETR_PROG_REP_ID] = [ICS_PRETR_PROG_REP].[ICS_PRETR_PROG_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_INDST_USR_INFO] [I4]
 ON [I4].[ICS_INDST_USR_INVENTORY_ID] = [I3].[ICS_INDST_USR_INVENTORY_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_IU_VIOL_INFO] [I7]
 ON [I7].[ICS_INDST_USR_INFO_ID] = [I4].[ICS_INDST_USR_INFO_ID] 
 
       WHERE ICS_PRETR_PROG_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PretreatmentProgramReportSubmission')
								  
	    AND ICS_PRETR_PROG_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_PRETR_PROG_REP/ICS_INDST_USR_INVENTORY/ICS_INDST_USR_INFO/ICS_IU_VIOL_INFO/ICS_SNC_LISTING_MONTHS 
INSERT INTO [ICS_FLOW_ICIS].[ICS_SNC_LISTING_MONTHS]
     SELECT I8.*
        from [ICS_FLOW_LOCAL].[ICS_PRETR_PROG_REP] [ICS_PRETR_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_INDST_USR_INVENTORY] [I3]
 ON [I3].[ICS_PRETR_PROG_REP_ID] = [ICS_PRETR_PROG_REP].[ICS_PRETR_PROG_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_INDST_USR_INFO] [I4]
 ON [I4].[ICS_INDST_USR_INVENTORY_ID] = [I3].[ICS_INDST_USR_INVENTORY_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_IU_VIOL_INFO] [I7]
 ON [I7].[ICS_INDST_USR_INFO_ID] = [I4].[ICS_INDST_USR_INFO_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SNC_LISTING_MONTHS] [I8]
 ON [I8].[ICS_IU_VIOL_INFO_ID] = [I7].[ICS_IU_VIOL_INFO_ID] 
 
       WHERE ICS_PRETR_PROG_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PretreatmentProgramReportSubmission')
								  
	    AND ICS_PRETR_PROG_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_PRETR_PROG_REP/ICS_INDST_USR_INVENTORY/ICS_INDST_USR_INFO/ICS_IU_VIOL_INFO/ICS_SNC_PRETR_STND_LMTS_PARAMETERS 
INSERT INTO [ICS_FLOW_ICIS].[ICS_SNC_PRETR_STND_LMTS_PARAMETERS]
     SELECT I9.*
        from [ICS_FLOW_LOCAL].[ICS_PRETR_PROG_REP] [ICS_PRETR_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_INDST_USR_INVENTORY] [I3]
 ON [I3].[ICS_PRETR_PROG_REP_ID] = [ICS_PRETR_PROG_REP].[ICS_PRETR_PROG_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_INDST_USR_INFO] [I4]
 ON [I4].[ICS_INDST_USR_INVENTORY_ID] = [I3].[ICS_INDST_USR_INVENTORY_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_IU_VIOL_INFO] [I7]
 ON [I7].[ICS_INDST_USR_INFO_ID] = [I4].[ICS_INDST_USR_INFO_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SNC_PRETR_STND_LMTS_PARAMETERS] [I9]
 ON [I9].[ICS_IU_VIOL_INFO_ID] = [I7].[ICS_IU_VIOL_INFO_ID] 
 
       WHERE ICS_PRETR_PROG_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PretreatmentProgramReportSubmission')
								  
	    AND ICS_PRETR_PROG_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

					
				
	

-- ================================================================
-- ICS_SCHD_EVT_VIOL 
-- ================================================================
			
				-- DELETES for: ICS_SCHD_EVT_VIOL 
				
								
-- /ICS_SCHD_EVT_VIOL/ICS_CMPL_SCHD_EVT_VIOL_ELEM
DELETE I2
 from ICS_FLOW_ICIS.[ICS_SCHD_EVT_VIOL] [ICS_SCHD_EVT_VIOL] 
 JOIN ICS_FLOW_ICIS.[ICS_CMPL_SCHD_EVT_VIOL_ELEM] [I2]
 ON [I2].[ICS_SCHD_EVT_VIOL_ID] = [ICS_SCHD_EVT_VIOL].[ICS_SCHD_EVT_VIOL_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SCHD_EVT_VIOL.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ScheduleEventViolationSubmission')
				  ;
          				
				
								
-- /ICS_SCHD_EVT_VIOL/ICS_PRMT_SCHD_EVT_VIOL_ELEM
DELETE I1
 from ICS_FLOW_ICIS.[ICS_SCHD_EVT_VIOL] [ICS_SCHD_EVT_VIOL] 
 JOIN ICS_FLOW_ICIS.[ICS_PRMT_SCHD_EVT_VIOL_ELEM] [I1]
 ON [I1].[ICS_SCHD_EVT_VIOL_ID] = [ICS_SCHD_EVT_VIOL].[ICS_SCHD_EVT_VIOL_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SCHD_EVT_VIOL.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ScheduleEventViolationSubmission')
				  ;
          				
				
								
-- /ICS_SCHD_EVT_VIOL
DELETE ICS_SCHD_EVT_VIOL
 from ICS_FLOW_ICIS.[ICS_SCHD_EVT_VIOL] [ICS_SCHD_EVT_VIOL] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SCHD_EVT_VIOL.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ScheduleEventViolationSubmission')
				  ;
          				
				
					

				-- INSERTS for: ICS_SCHD_EVT_VIOL
	
				
-- /ICS_SCHD_EVT_VIOL 
INSERT INTO [ICS_FLOW_ICIS].[ICS_SCHD_EVT_VIOL]
     SELECT ICS_SCHD_EVT_VIOL.*
        from [ICS_FLOW_LOCAL].[ICS_SCHD_EVT_VIOL] [ICS_SCHD_EVT_VIOL] 
 
       WHERE ICS_SCHD_EVT_VIOL.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ScheduleEventViolationSubmission')
				 
				  ;			 

				
-- /ICS_SCHD_EVT_VIOL/ICS_PRMT_SCHD_EVT_VIOL_ELEM 
INSERT INTO [ICS_FLOW_ICIS].[ICS_PRMT_SCHD_EVT_VIOL_ELEM]
     SELECT I1.*
        from [ICS_FLOW_LOCAL].[ICS_SCHD_EVT_VIOL] [ICS_SCHD_EVT_VIOL] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PRMT_SCHD_EVT_VIOL_ELEM] [I1]
 ON [I1].[ICS_SCHD_EVT_VIOL_ID] = [ICS_SCHD_EVT_VIOL].[ICS_SCHD_EVT_VIOL_ID] 
 
       WHERE ICS_SCHD_EVT_VIOL.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ScheduleEventViolationSubmission')
				 
				  ;			 

				
-- /ICS_SCHD_EVT_VIOL/ICS_CMPL_SCHD_EVT_VIOL_ELEM 
INSERT INTO [ICS_FLOW_ICIS].[ICS_CMPL_SCHD_EVT_VIOL_ELEM]
     SELECT I2.*
        from [ICS_FLOW_LOCAL].[ICS_SCHD_EVT_VIOL] [ICS_SCHD_EVT_VIOL] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CMPL_SCHD_EVT_VIOL_ELEM] [I2]
 ON [I2].[ICS_SCHD_EVT_VIOL_ID] = [ICS_SCHD_EVT_VIOL].[ICS_SCHD_EVT_VIOL_ID] 
 
       WHERE ICS_SCHD_EVT_VIOL.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ScheduleEventViolationSubmission')
				 
				  ;			 

					
				
	

-- ================================================================
-- ICS_SEWER_OVRFLW_BYPASS_EVT_REP 
-- ================================================================
			
				-- DELETES for: ICS_SEWER_OVRFLW_BYPASS_EVT_REP 
				
								
-- /ICS_SEWER_OVRFLW_BYPASS_EVT_REP/ICS_SEWER_OVRFLW_BYPASS_REP_EVT/ICS_BYPASS_TRTMNT_PLANT_EQUIPMENT
DELETE I8
 from ICS_FLOW_ICIS.[ICS_SEWER_OVRFLW_BYPASS_EVT_REP] [ICS_SEWER_OVRFLW_BYPASS_EVT_REP] 
 JOIN ICS_FLOW_ICIS.[ICS_SEWER_OVRFLW_BYPASS_REP_EVT] [I1]
 ON [I1].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] = [ICS_SEWER_OVRFLW_BYPASS_EVT_REP].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_BYPASS_TRTMNT_PLANT_EQUIPMENT] [I8]
 ON [I8].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] = [I1].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SEWER_OVRFLW_BYPASS_EVT_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SewerOverflowBypassEventReportSubmission')
				
                  OR ICS_SEWER_OVRFLW_BYPASS_EVT_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_SEWER_OVRFLW_BYPASS_EVT_REP/ICS_SEWER_OVRFLW_BYPASS_REP_EVT/ICS_SEWER_OVRFLW_TRTMNT
DELETE I7
 from ICS_FLOW_ICIS.[ICS_SEWER_OVRFLW_BYPASS_EVT_REP] [ICS_SEWER_OVRFLW_BYPASS_EVT_REP] 
 JOIN ICS_FLOW_ICIS.[ICS_SEWER_OVRFLW_BYPASS_REP_EVT] [I1]
 ON [I1].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] = [ICS_SEWER_OVRFLW_BYPASS_EVT_REP].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_SEWER_OVRFLW_TRTMNT] [I7]
 ON [I7].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] = [I1].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SEWER_OVRFLW_BYPASS_EVT_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SewerOverflowBypassEventReportSubmission')
				
                  OR ICS_SEWER_OVRFLW_BYPASS_EVT_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_SEWER_OVRFLW_BYPASS_EVT_REP/ICS_SEWER_OVRFLW_BYPASS_REP_EVT/ICS_SEWER_OVRFLW_BYPASS_TYPE
DELETE I6
 from ICS_FLOW_ICIS.[ICS_SEWER_OVRFLW_BYPASS_EVT_REP] [ICS_SEWER_OVRFLW_BYPASS_EVT_REP] 
 JOIN ICS_FLOW_ICIS.[ICS_SEWER_OVRFLW_BYPASS_REP_EVT] [I1]
 ON [I1].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] = [ICS_SEWER_OVRFLW_BYPASS_EVT_REP].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_SEWER_OVRFLW_BYPASS_TYPE] [I6]
 ON [I6].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] = [I1].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SEWER_OVRFLW_BYPASS_EVT_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SewerOverflowBypassEventReportSubmission')
				
                  OR ICS_SEWER_OVRFLW_BYPASS_EVT_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_SEWER_OVRFLW_BYPASS_EVT_REP/ICS_SEWER_OVRFLW_BYPASS_REP_EVT/ICS_SEWER_OVRFLW_BYPASS_RCVG_WTR
DELETE I5
 from ICS_FLOW_ICIS.[ICS_SEWER_OVRFLW_BYPASS_EVT_REP] [ICS_SEWER_OVRFLW_BYPASS_EVT_REP] 
 JOIN ICS_FLOW_ICIS.[ICS_SEWER_OVRFLW_BYPASS_REP_EVT] [I1]
 ON [I1].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] = [ICS_SEWER_OVRFLW_BYPASS_EVT_REP].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_SEWER_OVRFLW_BYPASS_RCVG_WTR] [I5]
 ON [I5].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] = [I1].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SEWER_OVRFLW_BYPASS_EVT_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SewerOverflowBypassEventReportSubmission')
				
                  OR ICS_SEWER_OVRFLW_BYPASS_EVT_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_SEWER_OVRFLW_BYPASS_EVT_REP/ICS_SEWER_OVRFLW_BYPASS_REP_EVT/ICS_SEWER_OVRFLW_BYPASS_IMPACT
DELETE I4
 from ICS_FLOW_ICIS.[ICS_SEWER_OVRFLW_BYPASS_EVT_REP] [ICS_SEWER_OVRFLW_BYPASS_EVT_REP] 
 JOIN ICS_FLOW_ICIS.[ICS_SEWER_OVRFLW_BYPASS_REP_EVT] [I1]
 ON [I1].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] = [ICS_SEWER_OVRFLW_BYPASS_EVT_REP].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_SEWER_OVRFLW_BYPASS_IMPACT] [I4]
 ON [I4].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] = [I1].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SEWER_OVRFLW_BYPASS_EVT_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SewerOverflowBypassEventReportSubmission')
				
                  OR ICS_SEWER_OVRFLW_BYPASS_EVT_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_SEWER_OVRFLW_BYPASS_EVT_REP/ICS_SEWER_OVRFLW_BYPASS_REP_EVT/ICS_SEWER_OVRFLW_BYPASS_CORR_ACTN
DELETE I3
 from ICS_FLOW_ICIS.[ICS_SEWER_OVRFLW_BYPASS_EVT_REP] [ICS_SEWER_OVRFLW_BYPASS_EVT_REP] 
 JOIN ICS_FLOW_ICIS.[ICS_SEWER_OVRFLW_BYPASS_REP_EVT] [I1]
 ON [I1].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] = [ICS_SEWER_OVRFLW_BYPASS_EVT_REP].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_SEWER_OVRFLW_BYPASS_CORR_ACTN] [I3]
 ON [I3].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] = [I1].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SEWER_OVRFLW_BYPASS_EVT_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SewerOverflowBypassEventReportSubmission')
				
                  OR ICS_SEWER_OVRFLW_BYPASS_EVT_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_SEWER_OVRFLW_BYPASS_EVT_REP/ICS_SEWER_OVRFLW_BYPASS_REP_EVT/ICS_SEWER_OVRFLW_BYPASS_CAUSE
DELETE I2
 from ICS_FLOW_ICIS.[ICS_SEWER_OVRFLW_BYPASS_EVT_REP] [ICS_SEWER_OVRFLW_BYPASS_EVT_REP] 
 JOIN ICS_FLOW_ICIS.[ICS_SEWER_OVRFLW_BYPASS_REP_EVT] [I1]
 ON [I1].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] = [ICS_SEWER_OVRFLW_BYPASS_EVT_REP].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_SEWER_OVRFLW_BYPASS_CAUSE] [I2]
 ON [I2].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] = [I1].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SEWER_OVRFLW_BYPASS_EVT_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SewerOverflowBypassEventReportSubmission')
				
                  OR ICS_SEWER_OVRFLW_BYPASS_EVT_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_SEWER_OVRFLW_BYPASS_EVT_REP/ICS_SEWER_OVRFLW_BYPASS_REP_EVT
DELETE I1
 from ICS_FLOW_ICIS.[ICS_SEWER_OVRFLW_BYPASS_EVT_REP] [ICS_SEWER_OVRFLW_BYPASS_EVT_REP] 
 JOIN ICS_FLOW_ICIS.[ICS_SEWER_OVRFLW_BYPASS_REP_EVT] [I1]
 ON [I1].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] = [ICS_SEWER_OVRFLW_BYPASS_EVT_REP].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SEWER_OVRFLW_BYPASS_EVT_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SewerOverflowBypassEventReportSubmission')
				
                  OR ICS_SEWER_OVRFLW_BYPASS_EVT_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_SEWER_OVRFLW_BYPASS_EVT_REP
DELETE ICS_SEWER_OVRFLW_BYPASS_EVT_REP
 from ICS_FLOW_ICIS.[ICS_SEWER_OVRFLW_BYPASS_EVT_REP] [ICS_SEWER_OVRFLW_BYPASS_EVT_REP] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SEWER_OVRFLW_BYPASS_EVT_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SewerOverflowBypassEventReportSubmission')
				
                  OR ICS_SEWER_OVRFLW_BYPASS_EVT_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
					

				-- INSERTS for: ICS_SEWER_OVRFLW_BYPASS_EVT_REP
	
				
-- /ICS_SEWER_OVRFLW_BYPASS_EVT_REP 
INSERT INTO [ICS_FLOW_ICIS].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP]
     SELECT ICS_SEWER_OVRFLW_BYPASS_EVT_REP.*
        from [ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP] [ICS_SEWER_OVRFLW_BYPASS_EVT_REP] 
 
       WHERE ICS_SEWER_OVRFLW_BYPASS_EVT_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SewerOverflowBypassEventReportSubmission')
								  
	    AND ICS_SEWER_OVRFLW_BYPASS_EVT_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_SEWER_OVRFLW_BYPASS_EVT_REP/ICS_SEWER_OVRFLW_BYPASS_REP_EVT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT]
     SELECT I1.*
        from [ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP] [ICS_SEWER_OVRFLW_BYPASS_EVT_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT] [I1]
 ON [I1].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] = [ICS_SEWER_OVRFLW_BYPASS_EVT_REP].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] 
 
       WHERE ICS_SEWER_OVRFLW_BYPASS_EVT_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SewerOverflowBypassEventReportSubmission')
								  
	    AND ICS_SEWER_OVRFLW_BYPASS_EVT_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_SEWER_OVRFLW_BYPASS_EVT_REP/ICS_SEWER_OVRFLW_BYPASS_REP_EVT/ICS_SEWER_OVRFLW_BYPASS_CAUSE 
INSERT INTO [ICS_FLOW_ICIS].[ICS_SEWER_OVRFLW_BYPASS_CAUSE]
     SELECT I2.*
        from [ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP] [ICS_SEWER_OVRFLW_BYPASS_EVT_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT] [I1]
 ON [I1].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] = [ICS_SEWER_OVRFLW_BYPASS_EVT_REP].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_CAUSE] [I2]
 ON [I2].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] = [I1].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] 
 
       WHERE ICS_SEWER_OVRFLW_BYPASS_EVT_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SewerOverflowBypassEventReportSubmission')
								  
	    AND ICS_SEWER_OVRFLW_BYPASS_EVT_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_SEWER_OVRFLW_BYPASS_EVT_REP/ICS_SEWER_OVRFLW_BYPASS_REP_EVT/ICS_SEWER_OVRFLW_BYPASS_CORR_ACTN 
INSERT INTO [ICS_FLOW_ICIS].[ICS_SEWER_OVRFLW_BYPASS_CORR_ACTN]
     SELECT I3.*
        from [ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP] [ICS_SEWER_OVRFLW_BYPASS_EVT_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT] [I1]
 ON [I1].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] = [ICS_SEWER_OVRFLW_BYPASS_EVT_REP].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_CORR_ACTN] [I3]
 ON [I3].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] = [I1].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] 
 
       WHERE ICS_SEWER_OVRFLW_BYPASS_EVT_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SewerOverflowBypassEventReportSubmission')
								  
	    AND ICS_SEWER_OVRFLW_BYPASS_EVT_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_SEWER_OVRFLW_BYPASS_EVT_REP/ICS_SEWER_OVRFLW_BYPASS_REP_EVT/ICS_SEWER_OVRFLW_BYPASS_IMPACT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_SEWER_OVRFLW_BYPASS_IMPACT]
     SELECT I4.*
        from [ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP] [ICS_SEWER_OVRFLW_BYPASS_EVT_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT] [I1]
 ON [I1].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] = [ICS_SEWER_OVRFLW_BYPASS_EVT_REP].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_IMPACT] [I4]
 ON [I4].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] = [I1].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] 
 
       WHERE ICS_SEWER_OVRFLW_BYPASS_EVT_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SewerOverflowBypassEventReportSubmission')
								  
	    AND ICS_SEWER_OVRFLW_BYPASS_EVT_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_SEWER_OVRFLW_BYPASS_EVT_REP/ICS_SEWER_OVRFLW_BYPASS_REP_EVT/ICS_SEWER_OVRFLW_BYPASS_RCVG_WTR 
INSERT INTO [ICS_FLOW_ICIS].[ICS_SEWER_OVRFLW_BYPASS_RCVG_WTR]
     SELECT I5.*
        from [ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP] [ICS_SEWER_OVRFLW_BYPASS_EVT_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT] [I1]
 ON [I1].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] = [ICS_SEWER_OVRFLW_BYPASS_EVT_REP].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_RCVG_WTR] [I5]
 ON [I5].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] = [I1].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] 
 
       WHERE ICS_SEWER_OVRFLW_BYPASS_EVT_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SewerOverflowBypassEventReportSubmission')
								  
	    AND ICS_SEWER_OVRFLW_BYPASS_EVT_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_SEWER_OVRFLW_BYPASS_EVT_REP/ICS_SEWER_OVRFLW_BYPASS_REP_EVT/ICS_SEWER_OVRFLW_BYPASS_TYPE 
INSERT INTO [ICS_FLOW_ICIS].[ICS_SEWER_OVRFLW_BYPASS_TYPE]
     SELECT I6.*
        from [ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP] [ICS_SEWER_OVRFLW_BYPASS_EVT_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT] [I1]
 ON [I1].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] = [ICS_SEWER_OVRFLW_BYPASS_EVT_REP].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_TYPE] [I6]
 ON [I6].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] = [I1].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] 
 
       WHERE ICS_SEWER_OVRFLW_BYPASS_EVT_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SewerOverflowBypassEventReportSubmission')
								  
	    AND ICS_SEWER_OVRFLW_BYPASS_EVT_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_SEWER_OVRFLW_BYPASS_EVT_REP/ICS_SEWER_OVRFLW_BYPASS_REP_EVT/ICS_SEWER_OVRFLW_TRTMNT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_SEWER_OVRFLW_TRTMNT]
     SELECT I7.*
        from [ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP] [ICS_SEWER_OVRFLW_BYPASS_EVT_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT] [I1]
 ON [I1].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] = [ICS_SEWER_OVRFLW_BYPASS_EVT_REP].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_TRTMNT] [I7]
 ON [I7].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] = [I1].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] 
 
       WHERE ICS_SEWER_OVRFLW_BYPASS_EVT_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SewerOverflowBypassEventReportSubmission')
								  
	    AND ICS_SEWER_OVRFLW_BYPASS_EVT_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_SEWER_OVRFLW_BYPASS_EVT_REP/ICS_SEWER_OVRFLW_BYPASS_REP_EVT/ICS_BYPASS_TRTMNT_PLANT_EQUIPMENT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_BYPASS_TRTMNT_PLANT_EQUIPMENT]
     SELECT I8.*
        from [ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP] [ICS_SEWER_OVRFLW_BYPASS_EVT_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT] [I1]
 ON [I1].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] = [ICS_SEWER_OVRFLW_BYPASS_EVT_REP].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BYPASS_TRTMNT_PLANT_EQUIPMENT] [I8]
 ON [I8].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] = [I1].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] 
 
       WHERE ICS_SEWER_OVRFLW_BYPASS_EVT_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SewerOverflowBypassEventReportSubmission')
								  
	    AND ICS_SEWER_OVRFLW_BYPASS_EVT_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

					
				
	

-- ================================================================
-- ICS_SNGL_EVT_VIOL 
-- ================================================================
			
				-- DELETES for: ICS_SNGL_EVT_VIOL 
				
								
-- /ICS_SNGL_EVT_VIOL
DELETE ICS_SNGL_EVT_VIOL
 from ICS_FLOW_ICIS.[ICS_SNGL_EVT_VIOL] [ICS_SNGL_EVT_VIOL] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SNGL_EVT_VIOL.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SingleEventViolationSubmission')
				
                  OR ICS_SNGL_EVT_VIOL.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
					

				-- INSERTS for: ICS_SNGL_EVT_VIOL
	
				
-- /ICS_SNGL_EVT_VIOL 
INSERT INTO [ICS_FLOW_ICIS].[ICS_SNGL_EVT_VIOL]
     SELECT ICS_SNGL_EVT_VIOL.*
        from [ICS_FLOW_LOCAL].[ICS_SNGL_EVT_VIOL] [ICS_SNGL_EVT_VIOL] 
 
       WHERE ICS_SNGL_EVT_VIOL.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SingleEventViolationSubmission')
								  
	    AND ICS_SNGL_EVT_VIOL.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

					
				
	

-- ================================================================
-- ICS_SW_CNST_PRMT 
-- ================================================================
			
				-- DELETES for: ICS_SW_CNST_PRMT 
				
								
-- /ICS_SW_CNST_PRMT/ICS_CNST_SITE_LIST/ICS_CNST_SITE
DELETE I11
 from ICS_FLOW_ICIS.[ICS_SW_CNST_PRMT] [ICS_SW_CNST_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_CNST_SITE_LIST] [I10]
 ON [I10].[ICS_SW_CNST_PRMT_ID] = [ICS_SW_CNST_PRMT].[ICS_SW_CNST_PRMT_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_CNST_SITE] [I11]
 ON [I11].[ICS_CNST_SITE_LIST_ID] = [I10].[ICS_CNST_SITE_LIST_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_CNST_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWConstructionPermitSubmission')
				
                  OR ICS_SW_CNST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_SW_CNST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_SW_CNST_PRMT/ICS_CNST_SITE_LIST
DELETE I10
 from ICS_FLOW_ICIS.[ICS_SW_CNST_PRMT] [ICS_SW_CNST_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_CNST_SITE_LIST] [I10]
 ON [I10].[ICS_SW_CNST_PRMT_ID] = [ICS_SW_CNST_PRMT].[ICS_SW_CNST_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_CNST_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWConstructionPermitSubmission')
				
                  OR ICS_SW_CNST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_SW_CNST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_SW_CNST_PRMT/ICS_TRTMNT_CHEMS_LIST
DELETE I9
 from ICS_FLOW_ICIS.[ICS_SW_CNST_PRMT] [ICS_SW_CNST_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_TRTMNT_CHEMS_LIST] [I9]
 ON [I9].[ICS_SW_CNST_PRMT_ID] = [ICS_SW_CNST_PRMT].[ICS_SW_CNST_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_CNST_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWConstructionPermitSubmission')
				
                  OR ICS_SW_CNST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_SW_CNST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_SW_CNST_PRMT/ICS_ADDR/ICS_TELEPH
DELETE I8
 from ICS_FLOW_ICIS.[ICS_SW_CNST_PRMT] [ICS_SW_CNST_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_ADDR] [I7]
 ON [I7].[ICS_SW_CNST_PRMT_ID] = [ICS_SW_CNST_PRMT].[ICS_SW_CNST_PRMT_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_TELEPH] [I8]
 ON [I8].[ICS_ADDR_ID] = [I7].[ICS_ADDR_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_CNST_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWConstructionPermitSubmission')
				
                  OR ICS_SW_CNST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_SW_CNST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_SW_CNST_PRMT/ICS_ADDR
DELETE I7
 from ICS_FLOW_ICIS.[ICS_SW_CNST_PRMT] [ICS_SW_CNST_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_ADDR] [I7]
 ON [I7].[ICS_SW_CNST_PRMT_ID] = [ICS_SW_CNST_PRMT].[ICS_SW_CNST_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_CNST_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWConstructionPermitSubmission')
				
                  OR ICS_SW_CNST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_SW_CNST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_SW_CNST_PRMT/ICS_GPCF_NOTICE_OF_INTENT/ICS_SUBSECTOR_CODE_PLUS_DESC
DELETE I6
 from ICS_FLOW_ICIS.[ICS_SW_CNST_PRMT] [ICS_SW_CNST_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_GPCF_NOTICE_OF_INTENT] [I5]
 ON [I5].[ICS_SW_CNST_PRMT_ID] = [ICS_SW_CNST_PRMT].[ICS_SW_CNST_PRMT_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_SUBSECTOR_CODE_PLUS_DESC] [I6]
 ON [I6].[ICS_GPCF_NOTICE_OF_INTENT_ID] = [I5].[ICS_GPCF_NOTICE_OF_INTENT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_CNST_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWConstructionPermitSubmission')
				
                  OR ICS_SW_CNST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_SW_CNST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_SW_CNST_PRMT/ICS_GPCF_NOTICE_OF_INTENT
DELETE I5
 from ICS_FLOW_ICIS.[ICS_SW_CNST_PRMT] [ICS_SW_CNST_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_GPCF_NOTICE_OF_INTENT] [I5]
 ON [I5].[ICS_SW_CNST_PRMT_ID] = [ICS_SW_CNST_PRMT].[ICS_SW_CNST_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_CNST_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWConstructionPermitSubmission')
				
                  OR ICS_SW_CNST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_SW_CNST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_SW_CNST_PRMT/ICS_PROPOSED_POST_CNST_SW_BM_PS
DELETE I4
 from ICS_FLOW_ICIS.[ICS_SW_CNST_PRMT] [ICS_SW_CNST_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_PROPOSED_POST_CNST_SW_BM_PS] [I4]
 ON [I4].[ICS_SW_CNST_PRMT_ID] = [ICS_SW_CNST_PRMT].[ICS_SW_CNST_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_CNST_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWConstructionPermitSubmission')
				
                  OR ICS_SW_CNST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_SW_CNST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_SW_CNST_PRMT/ICS_PROPOSED_CNST_SW_BM_PS
DELETE I3
 from ICS_FLOW_ICIS.[ICS_SW_CNST_PRMT] [ICS_SW_CNST_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_PROPOSED_CNST_SW_BM_PS] [I3]
 ON [I3].[ICS_SW_CNST_PRMT_ID] = [ICS_SW_CNST_PRMT].[ICS_SW_CNST_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_CNST_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWConstructionPermitSubmission')
				
                  OR ICS_SW_CNST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_SW_CNST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_SW_CNST_PRMT/ICS_CONTACT/ICS_TELEPH
DELETE I2
 from ICS_FLOW_ICIS.[ICS_SW_CNST_PRMT] [ICS_SW_CNST_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_CONTACT] [I1]
 ON [I1].[ICS_SW_CNST_PRMT_ID] = [ICS_SW_CNST_PRMT].[ICS_SW_CNST_PRMT_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_TELEPH] [I2]
 ON [I2].[ICS_CONTACT_ID] = [I1].[ICS_CONTACT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_CNST_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWConstructionPermitSubmission')
				
                  OR ICS_SW_CNST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_SW_CNST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_SW_CNST_PRMT/ICS_CONTACT
DELETE I1
 from ICS_FLOW_ICIS.[ICS_SW_CNST_PRMT] [ICS_SW_CNST_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_CONTACT] [I1]
 ON [I1].[ICS_SW_CNST_PRMT_ID] = [ICS_SW_CNST_PRMT].[ICS_SW_CNST_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_CNST_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWConstructionPermitSubmission')
				
                  OR ICS_SW_CNST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_SW_CNST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_SW_CNST_PRMT
DELETE ICS_SW_CNST_PRMT
 from ICS_FLOW_ICIS.[ICS_SW_CNST_PRMT] [ICS_SW_CNST_PRMT] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_CNST_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWConstructionPermitSubmission')
				
                  OR ICS_SW_CNST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_SW_CNST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
					

				-- INSERTS for: ICS_SW_CNST_PRMT
	
				
-- /ICS_SW_CNST_PRMT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_SW_CNST_PRMT]
     SELECT ICS_SW_CNST_PRMT.*
        from [ICS_FLOW_LOCAL].[ICS_SW_CNST_PRMT] [ICS_SW_CNST_PRMT] 
 
       WHERE ICS_SW_CNST_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWConstructionPermitSubmission')
								  
	    AND ICS_SW_CNST_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_SW_CNST_PRMT/ICS_CONTACT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_CONTACT]
     SELECT I1.*
        from [ICS_FLOW_LOCAL].[ICS_SW_CNST_PRMT] [ICS_SW_CNST_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTACT] [I1]
 ON [I1].[ICS_SW_CNST_PRMT_ID] = [ICS_SW_CNST_PRMT].[ICS_SW_CNST_PRMT_ID] 
 
       WHERE ICS_SW_CNST_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWConstructionPermitSubmission')
								  
	    AND ICS_SW_CNST_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_SW_CNST_PRMT/ICS_CONTACT/ICS_TELEPH 
INSERT INTO [ICS_FLOW_ICIS].[ICS_TELEPH]
     SELECT I2.*
        from [ICS_FLOW_LOCAL].[ICS_SW_CNST_PRMT] [ICS_SW_CNST_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTACT] [I1]
 ON [I1].[ICS_SW_CNST_PRMT_ID] = [ICS_SW_CNST_PRMT].[ICS_SW_CNST_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_TELEPH] [I2]
 ON [I2].[ICS_CONTACT_ID] = [I1].[ICS_CONTACT_ID] 
 
       WHERE ICS_SW_CNST_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWConstructionPermitSubmission')
								  
	    AND ICS_SW_CNST_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_SW_CNST_PRMT/ICS_PROPOSED_CNST_SW_BM_PS 
INSERT INTO [ICS_FLOW_ICIS].[ICS_PROPOSED_CNST_SW_BM_PS]
     SELECT I3.*
        from [ICS_FLOW_LOCAL].[ICS_SW_CNST_PRMT] [ICS_SW_CNST_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PROPOSED_CNST_SW_BM_PS] [I3]
 ON [I3].[ICS_SW_CNST_PRMT_ID] = [ICS_SW_CNST_PRMT].[ICS_SW_CNST_PRMT_ID] 
 
       WHERE ICS_SW_CNST_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWConstructionPermitSubmission')
								  
	    AND ICS_SW_CNST_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_SW_CNST_PRMT/ICS_PROPOSED_POST_CNST_SW_BM_PS 
INSERT INTO [ICS_FLOW_ICIS].[ICS_PROPOSED_POST_CNST_SW_BM_PS]
     SELECT I4.*
        from [ICS_FLOW_LOCAL].[ICS_SW_CNST_PRMT] [ICS_SW_CNST_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PROPOSED_POST_CNST_SW_BM_PS] [I4]
 ON [I4].[ICS_SW_CNST_PRMT_ID] = [ICS_SW_CNST_PRMT].[ICS_SW_CNST_PRMT_ID] 
 
       WHERE ICS_SW_CNST_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWConstructionPermitSubmission')
								  
	    AND ICS_SW_CNST_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_SW_CNST_PRMT/ICS_GPCF_NOTICE_OF_INTENT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_GPCF_NOTICE_OF_INTENT]
     SELECT I5.*
        from [ICS_FLOW_LOCAL].[ICS_SW_CNST_PRMT] [ICS_SW_CNST_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_GPCF_NOTICE_OF_INTENT] [I5]
 ON [I5].[ICS_SW_CNST_PRMT_ID] = [ICS_SW_CNST_PRMT].[ICS_SW_CNST_PRMT_ID] 
 
       WHERE ICS_SW_CNST_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWConstructionPermitSubmission')
								  
	    AND ICS_SW_CNST_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_SW_CNST_PRMT/ICS_GPCF_NOTICE_OF_INTENT/ICS_SUBSECTOR_CODE_PLUS_DESC 
INSERT INTO [ICS_FLOW_ICIS].[ICS_SUBSECTOR_CODE_PLUS_DESC]
     SELECT I6.*
        from [ICS_FLOW_LOCAL].[ICS_SW_CNST_PRMT] [ICS_SW_CNST_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_GPCF_NOTICE_OF_INTENT] [I5]
 ON [I5].[ICS_SW_CNST_PRMT_ID] = [ICS_SW_CNST_PRMT].[ICS_SW_CNST_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SUBSECTOR_CODE_PLUS_DESC] [I6]
 ON [I6].[ICS_GPCF_NOTICE_OF_INTENT_ID] = [I5].[ICS_GPCF_NOTICE_OF_INTENT_ID] 
 
       WHERE ICS_SW_CNST_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWConstructionPermitSubmission')
								  
	    AND ICS_SW_CNST_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_SW_CNST_PRMT/ICS_ADDR 
INSERT INTO [ICS_FLOW_ICIS].[ICS_ADDR]
     SELECT I7.*
        from [ICS_FLOW_LOCAL].[ICS_SW_CNST_PRMT] [ICS_SW_CNST_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ADDR] [I7]
 ON [I7].[ICS_SW_CNST_PRMT_ID] = [ICS_SW_CNST_PRMT].[ICS_SW_CNST_PRMT_ID] 
 
       WHERE ICS_SW_CNST_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWConstructionPermitSubmission')
								  
	    AND ICS_SW_CNST_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_SW_CNST_PRMT/ICS_ADDR/ICS_TELEPH 
INSERT INTO [ICS_FLOW_ICIS].[ICS_TELEPH]
     SELECT I8.*
        from [ICS_FLOW_LOCAL].[ICS_SW_CNST_PRMT] [ICS_SW_CNST_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ADDR] [I7]
 ON [I7].[ICS_SW_CNST_PRMT_ID] = [ICS_SW_CNST_PRMT].[ICS_SW_CNST_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_TELEPH] [I8]
 ON [I8].[ICS_ADDR_ID] = [I7].[ICS_ADDR_ID] 
 
       WHERE ICS_SW_CNST_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWConstructionPermitSubmission')
								  
	    AND ICS_SW_CNST_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_SW_CNST_PRMT/ICS_TRTMNT_CHEMS_LIST 
INSERT INTO [ICS_FLOW_ICIS].[ICS_TRTMNT_CHEMS_LIST]
     SELECT I9.*
        from [ICS_FLOW_LOCAL].[ICS_SW_CNST_PRMT] [ICS_SW_CNST_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_TRTMNT_CHEMS_LIST] [I9]
 ON [I9].[ICS_SW_CNST_PRMT_ID] = [ICS_SW_CNST_PRMT].[ICS_SW_CNST_PRMT_ID] 
 
       WHERE ICS_SW_CNST_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWConstructionPermitSubmission')
								  
	    AND ICS_SW_CNST_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_SW_CNST_PRMT/ICS_CNST_SITE_LIST 
INSERT INTO [ICS_FLOW_ICIS].[ICS_CNST_SITE_LIST]
     SELECT I10.*
        from [ICS_FLOW_LOCAL].[ICS_SW_CNST_PRMT] [ICS_SW_CNST_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CNST_SITE_LIST] [I10]
 ON [I10].[ICS_SW_CNST_PRMT_ID] = [ICS_SW_CNST_PRMT].[ICS_SW_CNST_PRMT_ID] 
 
       WHERE ICS_SW_CNST_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWConstructionPermitSubmission')
								  
	    AND ICS_SW_CNST_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_SW_CNST_PRMT/ICS_CNST_SITE_LIST/ICS_CNST_SITE 
INSERT INTO [ICS_FLOW_ICIS].[ICS_CNST_SITE]
     SELECT I11.*
        from [ICS_FLOW_LOCAL].[ICS_SW_CNST_PRMT] [ICS_SW_CNST_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CNST_SITE_LIST] [I10]
 ON [I10].[ICS_SW_CNST_PRMT_ID] = [ICS_SW_CNST_PRMT].[ICS_SW_CNST_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CNST_SITE] [I11]
 ON [I11].[ICS_CNST_SITE_LIST_ID] = [I10].[ICS_CNST_SITE_LIST_ID] 
 
       WHERE ICS_SW_CNST_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWConstructionPermitSubmission')
								  
	    AND ICS_SW_CNST_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

					
				
	

-- ================================================================
-- ICS_SW_INDST_ANNUL_REP 
-- ================================================================
			
				-- DELETES for: ICS_SW_INDST_ANNUL_REP 
				
								
-- /ICS_SW_INDST_ANNUL_REP
DELETE ICS_SW_INDST_ANNUL_REP
 from ICS_FLOW_ICIS.[ICS_SW_INDST_ANNUL_REP] [ICS_SW_INDST_ANNUL_REP] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_INDST_ANNUL_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWIndustrialAnnualReportSubmission')
				
                  OR ICS_SW_INDST_ANNUL_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
					

				-- INSERTS for: ICS_SW_INDST_ANNUL_REP
	
				
-- /ICS_SW_INDST_ANNUL_REP 
INSERT INTO [ICS_FLOW_ICIS].[ICS_SW_INDST_ANNUL_REP]
     SELECT ICS_SW_INDST_ANNUL_REP.*
        from [ICS_FLOW_LOCAL].[ICS_SW_INDST_ANNUL_REP] [ICS_SW_INDST_ANNUL_REP] 
 
       WHERE ICS_SW_INDST_ANNUL_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWIndustrialAnnualReportSubmission')
								  
	    AND ICS_SW_INDST_ANNUL_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

					
				
	

-- ================================================================
-- ICS_SW_INDST_PRMT 
-- ================================================================
			
				-- DELETES for: ICS_SW_INDST_PRMT 
				
								
-- /ICS_SW_INDST_PRMT/ICS_ADDR/ICS_TELEPH
DELETE I9
 from ICS_FLOW_ICIS.[ICS_SW_INDST_PRMT] [ICS_SW_INDST_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_ADDR] [I8]
 ON [I8].[ICS_SW_INDST_PRMT_ID] = [ICS_SW_INDST_PRMT].[ICS_SW_INDST_PRMT_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_TELEPH] [I9]
 ON [I9].[ICS_ADDR_ID] = [I8].[ICS_ADDR_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_INDST_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWIndustrialPermitSubmission')
				
                  OR ICS_SW_INDST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_SW_INDST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_SW_INDST_PRMT/ICS_ADDR
DELETE I8
 from ICS_FLOW_ICIS.[ICS_SW_INDST_PRMT] [ICS_SW_INDST_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_ADDR] [I8]
 ON [I8].[ICS_SW_INDST_PRMT_ID] = [ICS_SW_INDST_PRMT].[ICS_SW_INDST_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_INDST_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWIndustrialPermitSubmission')
				
                  OR ICS_SW_INDST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_SW_INDST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_SW_INDST_PRMT/ICS_GPCF_NOTICE_OF_TERM
DELETE I7
 from ICS_FLOW_ICIS.[ICS_SW_INDST_PRMT] [ICS_SW_INDST_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_GPCF_NOTICE_OF_TERM] [I7]
 ON [I7].[ICS_SW_INDST_PRMT_ID] = [ICS_SW_INDST_PRMT].[ICS_SW_INDST_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_INDST_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWIndustrialPermitSubmission')
				
                  OR ICS_SW_INDST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_SW_INDST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_SW_INDST_PRMT/ICS_GPCF_NOTICE_OF_INTENT/ICS_SUBSECTOR_CODE_PLUS_DESC
DELETE I6
 from ICS_FLOW_ICIS.[ICS_SW_INDST_PRMT] [ICS_SW_INDST_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_GPCF_NOTICE_OF_INTENT] [I5]
 ON [I5].[ICS_SW_INDST_PRMT_ID] = [ICS_SW_INDST_PRMT].[ICS_SW_INDST_PRMT_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_SUBSECTOR_CODE_PLUS_DESC] [I6]
 ON [I6].[ICS_GPCF_NOTICE_OF_INTENT_ID] = [I5].[ICS_GPCF_NOTICE_OF_INTENT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_INDST_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWIndustrialPermitSubmission')
				
                  OR ICS_SW_INDST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_SW_INDST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_SW_INDST_PRMT/ICS_GPCF_NOTICE_OF_INTENT
DELETE I5
 from ICS_FLOW_ICIS.[ICS_SW_INDST_PRMT] [ICS_SW_INDST_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_GPCF_NOTICE_OF_INTENT] [I5]
 ON [I5].[ICS_SW_INDST_PRMT_ID] = [ICS_SW_INDST_PRMT].[ICS_SW_INDST_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_INDST_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWIndustrialPermitSubmission')
				
                  OR ICS_SW_INDST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_SW_INDST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_SW_INDST_PRMT/ICS_GPCF_NO_EXPOSURE
DELETE I4
 from ICS_FLOW_ICIS.[ICS_SW_INDST_PRMT] [ICS_SW_INDST_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_GPCF_NO_EXPOSURE] [I4]
 ON [I4].[ICS_SW_INDST_PRMT_ID] = [ICS_SW_INDST_PRMT].[ICS_SW_INDST_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_INDST_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWIndustrialPermitSubmission')
				
                  OR ICS_SW_INDST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_SW_INDST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_SW_INDST_PRMT/ICS_PROPOSED_INDST_SW_BM_PS
DELETE I3
 from ICS_FLOW_ICIS.[ICS_SW_INDST_PRMT] [ICS_SW_INDST_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_PROPOSED_INDST_SW_BM_PS] [I3]
 ON [I3].[ICS_SW_INDST_PRMT_ID] = [ICS_SW_INDST_PRMT].[ICS_SW_INDST_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_INDST_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWIndustrialPermitSubmission')
				
                  OR ICS_SW_INDST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_SW_INDST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_SW_INDST_PRMT/ICS_CONTACT/ICS_TELEPH
DELETE I2
 from ICS_FLOW_ICIS.[ICS_SW_INDST_PRMT] [ICS_SW_INDST_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_CONTACT] [I1]
 ON [I1].[ICS_SW_INDST_PRMT_ID] = [ICS_SW_INDST_PRMT].[ICS_SW_INDST_PRMT_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_TELEPH] [I2]
 ON [I2].[ICS_CONTACT_ID] = [I1].[ICS_CONTACT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_INDST_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWIndustrialPermitSubmission')
				
                  OR ICS_SW_INDST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_SW_INDST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_SW_INDST_PRMT/ICS_CONTACT
DELETE I1
 from ICS_FLOW_ICIS.[ICS_SW_INDST_PRMT] [ICS_SW_INDST_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_CONTACT] [I1]
 ON [I1].[ICS_SW_INDST_PRMT_ID] = [ICS_SW_INDST_PRMT].[ICS_SW_INDST_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_INDST_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWIndustrialPermitSubmission')
				
                  OR ICS_SW_INDST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_SW_INDST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_SW_INDST_PRMT
DELETE ICS_SW_INDST_PRMT
 from ICS_FLOW_ICIS.[ICS_SW_INDST_PRMT] [ICS_SW_INDST_PRMT] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_INDST_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWIndustrialPermitSubmission')
				
                  OR ICS_SW_INDST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_SW_INDST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
					

				-- INSERTS for: ICS_SW_INDST_PRMT
	
				
-- /ICS_SW_INDST_PRMT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_SW_INDST_PRMT]
     SELECT ICS_SW_INDST_PRMT.*
        from [ICS_FLOW_LOCAL].[ICS_SW_INDST_PRMT] [ICS_SW_INDST_PRMT] 
 
       WHERE ICS_SW_INDST_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWIndustrialPermitSubmission')
								  
	    AND ICS_SW_INDST_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_SW_INDST_PRMT/ICS_CONTACT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_CONTACT]
     SELECT I1.*
        from [ICS_FLOW_LOCAL].[ICS_SW_INDST_PRMT] [ICS_SW_INDST_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTACT] [I1]
 ON [I1].[ICS_SW_INDST_PRMT_ID] = [ICS_SW_INDST_PRMT].[ICS_SW_INDST_PRMT_ID] 
 
       WHERE ICS_SW_INDST_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWIndustrialPermitSubmission')
								  
	    AND ICS_SW_INDST_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_SW_INDST_PRMT/ICS_CONTACT/ICS_TELEPH 
INSERT INTO [ICS_FLOW_ICIS].[ICS_TELEPH]
     SELECT I2.*
        from [ICS_FLOW_LOCAL].[ICS_SW_INDST_PRMT] [ICS_SW_INDST_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTACT] [I1]
 ON [I1].[ICS_SW_INDST_PRMT_ID] = [ICS_SW_INDST_PRMT].[ICS_SW_INDST_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_TELEPH] [I2]
 ON [I2].[ICS_CONTACT_ID] = [I1].[ICS_CONTACT_ID] 
 
       WHERE ICS_SW_INDST_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWIndustrialPermitSubmission')
								  
	    AND ICS_SW_INDST_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_SW_INDST_PRMT/ICS_PROPOSED_INDST_SW_BM_PS 
INSERT INTO [ICS_FLOW_ICIS].[ICS_PROPOSED_INDST_SW_BM_PS]
     SELECT I3.*
        from [ICS_FLOW_LOCAL].[ICS_SW_INDST_PRMT] [ICS_SW_INDST_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PROPOSED_INDST_SW_BM_PS] [I3]
 ON [I3].[ICS_SW_INDST_PRMT_ID] = [ICS_SW_INDST_PRMT].[ICS_SW_INDST_PRMT_ID] 
 
       WHERE ICS_SW_INDST_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWIndustrialPermitSubmission')
								  
	    AND ICS_SW_INDST_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_SW_INDST_PRMT/ICS_GPCF_NO_EXPOSURE 
INSERT INTO [ICS_FLOW_ICIS].[ICS_GPCF_NO_EXPOSURE]
     SELECT I4.*
        from [ICS_FLOW_LOCAL].[ICS_SW_INDST_PRMT] [ICS_SW_INDST_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_GPCF_NO_EXPOSURE] [I4]
 ON [I4].[ICS_SW_INDST_PRMT_ID] = [ICS_SW_INDST_PRMT].[ICS_SW_INDST_PRMT_ID] 
 
       WHERE ICS_SW_INDST_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWIndustrialPermitSubmission')
								  
	    AND ICS_SW_INDST_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_SW_INDST_PRMT/ICS_GPCF_NOTICE_OF_INTENT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_GPCF_NOTICE_OF_INTENT]
     SELECT I5.*
        from [ICS_FLOW_LOCAL].[ICS_SW_INDST_PRMT] [ICS_SW_INDST_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_GPCF_NOTICE_OF_INTENT] [I5]
 ON [I5].[ICS_SW_INDST_PRMT_ID] = [ICS_SW_INDST_PRMT].[ICS_SW_INDST_PRMT_ID] 
 
       WHERE ICS_SW_INDST_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWIndustrialPermitSubmission')
								  
	    AND ICS_SW_INDST_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_SW_INDST_PRMT/ICS_GPCF_NOTICE_OF_INTENT/ICS_SUBSECTOR_CODE_PLUS_DESC 
INSERT INTO [ICS_FLOW_ICIS].[ICS_SUBSECTOR_CODE_PLUS_DESC]
     SELECT I6.*
        from [ICS_FLOW_LOCAL].[ICS_SW_INDST_PRMT] [ICS_SW_INDST_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_GPCF_NOTICE_OF_INTENT] [I5]
 ON [I5].[ICS_SW_INDST_PRMT_ID] = [ICS_SW_INDST_PRMT].[ICS_SW_INDST_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SUBSECTOR_CODE_PLUS_DESC] [I6]
 ON [I6].[ICS_GPCF_NOTICE_OF_INTENT_ID] = [I5].[ICS_GPCF_NOTICE_OF_INTENT_ID] 
 
       WHERE ICS_SW_INDST_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWIndustrialPermitSubmission')
								  
	    AND ICS_SW_INDST_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_SW_INDST_PRMT/ICS_GPCF_NOTICE_OF_TERM 
INSERT INTO [ICS_FLOW_ICIS].[ICS_GPCF_NOTICE_OF_TERM]
     SELECT I7.*
        from [ICS_FLOW_LOCAL].[ICS_SW_INDST_PRMT] [ICS_SW_INDST_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_GPCF_NOTICE_OF_TERM] [I7]
 ON [I7].[ICS_SW_INDST_PRMT_ID] = [ICS_SW_INDST_PRMT].[ICS_SW_INDST_PRMT_ID] 
 
       WHERE ICS_SW_INDST_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWIndustrialPermitSubmission')
								  
	    AND ICS_SW_INDST_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_SW_INDST_PRMT/ICS_ADDR 
INSERT INTO [ICS_FLOW_ICIS].[ICS_ADDR]
     SELECT I8.*
        from [ICS_FLOW_LOCAL].[ICS_SW_INDST_PRMT] [ICS_SW_INDST_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ADDR] [I8]
 ON [I8].[ICS_SW_INDST_PRMT_ID] = [ICS_SW_INDST_PRMT].[ICS_SW_INDST_PRMT_ID] 
 
       WHERE ICS_SW_INDST_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWIndustrialPermitSubmission')
								  
	    AND ICS_SW_INDST_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_SW_INDST_PRMT/ICS_ADDR/ICS_TELEPH 
INSERT INTO [ICS_FLOW_ICIS].[ICS_TELEPH]
     SELECT I9.*
        from [ICS_FLOW_LOCAL].[ICS_SW_INDST_PRMT] [ICS_SW_INDST_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ADDR] [I8]
 ON [I8].[ICS_SW_INDST_PRMT_ID] = [ICS_SW_INDST_PRMT].[ICS_SW_INDST_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_TELEPH] [I9]
 ON [I9].[ICS_ADDR_ID] = [I8].[ICS_ADDR_ID] 
 
       WHERE ICS_SW_INDST_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWIndustrialPermitSubmission')
								  
	    AND ICS_SW_INDST_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

					
				
	

-- ================================================================
-- ICS_SWMS_4_ANNUL_PROG_REP 
-- ================================================================
			
				-- DELETES for: ICS_SWMS_4_ANNUL_PROG_REP 
				
								
-- /ICS_SWMS_4_ANNUL_PROG_REP/ICS_MS_4_SWMP_CHANGES
DELETE I8
 from ICS_FLOW_ICIS.[ICS_SWMS_4_ANNUL_PROG_REP] [ICS_SWMS_4_ANNUL_PROG_REP] 
 JOIN ICS_FLOW_ICIS.[ICS_MS_4_SWMP_CHANGES] [I8]
 ON [I8].[ICS_SWMS_4_ANNUL_PROG_REP_ID] = [ICS_SWMS_4_ANNUL_PROG_REP].[ICS_SWMS_4_ANNUL_PROG_REP_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_ANNUL_PROG_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4AnnualProgramReportSubmission')
				
                  OR ICS_SWMS_4_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_SWMS_4_ANNUL_PROG_REP/ICS_MS_4_REGULATED_ENTITY_ENFRC/ICS_MS_4_REGULATED_ENTITY_ENFRC_ACTIONS
DELETE I7
 from ICS_FLOW_ICIS.[ICS_SWMS_4_ANNUL_PROG_REP] [ICS_SWMS_4_ANNUL_PROG_REP] 
 JOIN ICS_FLOW_ICIS.[ICS_MS_4_REGULATED_ENTITY_ENFRC] [I6]
 ON [I6].[ICS_SWMS_4_ANNUL_PROG_REP_ID] = [ICS_SWMS_4_ANNUL_PROG_REP].[ICS_SWMS_4_ANNUL_PROG_REP_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_MS_4_REGULATED_ENTITY_ENFRC_ACTIONS] [I7]
 ON [I7].[ICS_MS_4_REGULATED_ENTITY_ENFRC_ID] = [I6].[ICS_MS_4_REGULATED_ENTITY_ENFRC_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_ANNUL_PROG_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4AnnualProgramReportSubmission')
				
                  OR ICS_SWMS_4_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_SWMS_4_ANNUL_PROG_REP/ICS_MS_4_REGULATED_ENTITY_ENFRC
DELETE I6
 from ICS_FLOW_ICIS.[ICS_SWMS_4_ANNUL_PROG_REP] [ICS_SWMS_4_ANNUL_PROG_REP] 
 JOIN ICS_FLOW_ICIS.[ICS_MS_4_REGULATED_ENTITY_ENFRC] [I6]
 ON [I6].[ICS_SWMS_4_ANNUL_PROG_REP_ID] = [ICS_SWMS_4_ANNUL_PROG_REP].[ICS_SWMS_4_ANNUL_PROG_REP_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_ANNUL_PROG_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4AnnualProgramReportSubmission')
				
                  OR ICS_SWMS_4_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_SWMS_4_ANNUL_PROG_REP/ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY/ICS_MS_4_REGULATED_ENTITY_IDENT
DELETE I5
 from ICS_FLOW_ICIS.[ICS_SWMS_4_ANNUL_PROG_REP] [ICS_SWMS_4_ANNUL_PROG_REP] 
 JOIN ICS_FLOW_ICIS.[ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY] [I4]
 ON [I4].[ICS_SWMS_4_ANNUL_PROG_REP_ID] = [ICS_SWMS_4_ANNUL_PROG_REP].[ICS_SWMS_4_ANNUL_PROG_REP_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_MS_4_REGULATED_ENTITY_IDENT] [I5]
 ON [I5].[ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY_ID] = [I4].[ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_ANNUL_PROG_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4AnnualProgramReportSubmission')
				
                  OR ICS_SWMS_4_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_SWMS_4_ANNUL_PROG_REP/ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY
DELETE I4
 from ICS_FLOW_ICIS.[ICS_SWMS_4_ANNUL_PROG_REP] [ICS_SWMS_4_ANNUL_PROG_REP] 
 JOIN ICS_FLOW_ICIS.[ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY] [I4]
 ON [I4].[ICS_SWMS_4_ANNUL_PROG_REP_ID] = [ICS_SWMS_4_ANNUL_PROG_REP].[ICS_SWMS_4_ANNUL_PROG_REP_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_ANNUL_PROG_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4AnnualProgramReportSubmission')
				
                  OR ICS_SWMS_4_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_SWMS_4_ANNUL_PROG_REP/ICS_MS_4_PROG_REP_ANALYSIS/ICS_MS_4_REGULATED_ENTITY_IDENT
DELETE I3
 from ICS_FLOW_ICIS.[ICS_SWMS_4_ANNUL_PROG_REP] [ICS_SWMS_4_ANNUL_PROG_REP] 
 JOIN ICS_FLOW_ICIS.[ICS_MS_4_PROG_REP_ANALYSIS] [I2]
 ON [I2].[ICS_SWMS_4_ANNUL_PROG_REP_ID] = [ICS_SWMS_4_ANNUL_PROG_REP].[ICS_SWMS_4_ANNUL_PROG_REP_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_MS_4_REGULATED_ENTITY_IDENT] [I3]
 ON [I3].[ICS_MS_4_PROG_REP_ANALYSIS_ID] = [I2].[ICS_MS_4_PROG_REP_ANALYSIS_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_ANNUL_PROG_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4AnnualProgramReportSubmission')
				
                  OR ICS_SWMS_4_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_SWMS_4_ANNUL_PROG_REP/ICS_MS_4_PROG_REP_ANALYSIS
DELETE I2
 from ICS_FLOW_ICIS.[ICS_SWMS_4_ANNUL_PROG_REP] [ICS_SWMS_4_ANNUL_PROG_REP] 
 JOIN ICS_FLOW_ICIS.[ICS_MS_4_PROG_REP_ANALYSIS] [I2]
 ON [I2].[ICS_SWMS_4_ANNUL_PROG_REP_ID] = [ICS_SWMS_4_ANNUL_PROG_REP].[ICS_SWMS_4_ANNUL_PROG_REP_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_ANNUL_PROG_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4AnnualProgramReportSubmission')
				
                  OR ICS_SWMS_4_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_SWMS_4_ANNUL_PROG_REP/ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO_PROG_REP
DELETE I1
 from ICS_FLOW_ICIS.[ICS_SWMS_4_ANNUL_PROG_REP] [ICS_SWMS_4_ANNUL_PROG_REP] 
 JOIN ICS_FLOW_ICIS.[ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO_PROG_REP] [I1]
 ON [I1].[ICS_SWMS_4_ANNUL_PROG_REP_ID] = [ICS_SWMS_4_ANNUL_PROG_REP].[ICS_SWMS_4_ANNUL_PROG_REP_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_ANNUL_PROG_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4AnnualProgramReportSubmission')
				
                  OR ICS_SWMS_4_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
								
-- /ICS_SWMS_4_ANNUL_PROG_REP
DELETE ICS_SWMS_4_ANNUL_PROG_REP
 from ICS_FLOW_ICIS.[ICS_SWMS_4_ANNUL_PROG_REP] [ICS_SWMS_4_ANNUL_PROG_REP] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_ANNUL_PROG_REP.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4AnnualProgramReportSubmission')
				
                  OR ICS_SWMS_4_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				    ;
          				
				
					

				-- INSERTS for: ICS_SWMS_4_ANNUL_PROG_REP
	
				
-- /ICS_SWMS_4_ANNUL_PROG_REP 
INSERT INTO [ICS_FLOW_ICIS].[ICS_SWMS_4_ANNUL_PROG_REP]
     SELECT ICS_SWMS_4_ANNUL_PROG_REP.*
        from [ICS_FLOW_LOCAL].[ICS_SWMS_4_ANNUL_PROG_REP] [ICS_SWMS_4_ANNUL_PROG_REP] 
 
       WHERE ICS_SWMS_4_ANNUL_PROG_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4AnnualProgramReportSubmission')
								  
	    AND ICS_SWMS_4_ANNUL_PROG_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_SWMS_4_ANNUL_PROG_REP/ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO_PROG_REP 
INSERT INTO [ICS_FLOW_ICIS].[ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO_PROG_REP]
     SELECT I1.*
        from [ICS_FLOW_LOCAL].[ICS_SWMS_4_ANNUL_PROG_REP] [ICS_SWMS_4_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO_PROG_REP] [I1]
 ON [I1].[ICS_SWMS_4_ANNUL_PROG_REP_ID] = [ICS_SWMS_4_ANNUL_PROG_REP].[ICS_SWMS_4_ANNUL_PROG_REP_ID] 
 
       WHERE ICS_SWMS_4_ANNUL_PROG_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4AnnualProgramReportSubmission')
								  
	    AND ICS_SWMS_4_ANNUL_PROG_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_SWMS_4_ANNUL_PROG_REP/ICS_MS_4_PROG_REP_ANALYSIS 
INSERT INTO [ICS_FLOW_ICIS].[ICS_MS_4_PROG_REP_ANALYSIS]
     SELECT I2.*
        from [ICS_FLOW_LOCAL].[ICS_SWMS_4_ANNUL_PROG_REP] [ICS_SWMS_4_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_PROG_REP_ANALYSIS] [I2]
 ON [I2].[ICS_SWMS_4_ANNUL_PROG_REP_ID] = [ICS_SWMS_4_ANNUL_PROG_REP].[ICS_SWMS_4_ANNUL_PROG_REP_ID] 
 
       WHERE ICS_SWMS_4_ANNUL_PROG_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4AnnualProgramReportSubmission')
								  
	    AND ICS_SWMS_4_ANNUL_PROG_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_SWMS_4_ANNUL_PROG_REP/ICS_MS_4_PROG_REP_ANALYSIS/ICS_MS_4_REGULATED_ENTITY_IDENT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_MS_4_REGULATED_ENTITY_IDENT]
     SELECT I3.*
        from [ICS_FLOW_LOCAL].[ICS_SWMS_4_ANNUL_PROG_REP] [ICS_SWMS_4_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_PROG_REP_ANALYSIS] [I2]
 ON [I2].[ICS_SWMS_4_ANNUL_PROG_REP_ID] = [ICS_SWMS_4_ANNUL_PROG_REP].[ICS_SWMS_4_ANNUL_PROG_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_REGULATED_ENTITY_IDENT] [I3]
 ON [I3].[ICS_MS_4_PROG_REP_ANALYSIS_ID] = [I2].[ICS_MS_4_PROG_REP_ANALYSIS_ID] 
 
       WHERE ICS_SWMS_4_ANNUL_PROG_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4AnnualProgramReportSubmission')
								  
	    AND ICS_SWMS_4_ANNUL_PROG_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_SWMS_4_ANNUL_PROG_REP/ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY 
INSERT INTO [ICS_FLOW_ICIS].[ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY]
     SELECT I4.*
        from [ICS_FLOW_LOCAL].[ICS_SWMS_4_ANNUL_PROG_REP] [ICS_SWMS_4_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY] [I4]
 ON [I4].[ICS_SWMS_4_ANNUL_PROG_REP_ID] = [ICS_SWMS_4_ANNUL_PROG_REP].[ICS_SWMS_4_ANNUL_PROG_REP_ID] 
 
       WHERE ICS_SWMS_4_ANNUL_PROG_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4AnnualProgramReportSubmission')
								  
	    AND ICS_SWMS_4_ANNUL_PROG_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_SWMS_4_ANNUL_PROG_REP/ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY/ICS_MS_4_REGULATED_ENTITY_IDENT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_MS_4_REGULATED_ENTITY_IDENT]
     SELECT I5.*
        from [ICS_FLOW_LOCAL].[ICS_SWMS_4_ANNUL_PROG_REP] [ICS_SWMS_4_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY] [I4]
 ON [I4].[ICS_SWMS_4_ANNUL_PROG_REP_ID] = [ICS_SWMS_4_ANNUL_PROG_REP].[ICS_SWMS_4_ANNUL_PROG_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_REGULATED_ENTITY_IDENT] [I5]
 ON [I5].[ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY_ID] = [I4].[ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY_ID] 
 
       WHERE ICS_SWMS_4_ANNUL_PROG_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4AnnualProgramReportSubmission')
								  
	    AND ICS_SWMS_4_ANNUL_PROG_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_SWMS_4_ANNUL_PROG_REP/ICS_MS_4_REGULATED_ENTITY_ENFRC 
INSERT INTO [ICS_FLOW_ICIS].[ICS_MS_4_REGULATED_ENTITY_ENFRC]
     SELECT I6.*
        from [ICS_FLOW_LOCAL].[ICS_SWMS_4_ANNUL_PROG_REP] [ICS_SWMS_4_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_REGULATED_ENTITY_ENFRC] [I6]
 ON [I6].[ICS_SWMS_4_ANNUL_PROG_REP_ID] = [ICS_SWMS_4_ANNUL_PROG_REP].[ICS_SWMS_4_ANNUL_PROG_REP_ID] 
 
       WHERE ICS_SWMS_4_ANNUL_PROG_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4AnnualProgramReportSubmission')
								  
	    AND ICS_SWMS_4_ANNUL_PROG_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_SWMS_4_ANNUL_PROG_REP/ICS_MS_4_REGULATED_ENTITY_ENFRC/ICS_MS_4_REGULATED_ENTITY_ENFRC_ACTIONS 
INSERT INTO [ICS_FLOW_ICIS].[ICS_MS_4_REGULATED_ENTITY_ENFRC_ACTIONS]
     SELECT I7.*
        from [ICS_FLOW_LOCAL].[ICS_SWMS_4_ANNUL_PROG_REP] [ICS_SWMS_4_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_REGULATED_ENTITY_ENFRC] [I6]
 ON [I6].[ICS_SWMS_4_ANNUL_PROG_REP_ID] = [ICS_SWMS_4_ANNUL_PROG_REP].[ICS_SWMS_4_ANNUL_PROG_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_REGULATED_ENTITY_ENFRC_ACTIONS] [I7]
 ON [I7].[ICS_MS_4_REGULATED_ENTITY_ENFRC_ID] = [I6].[ICS_MS_4_REGULATED_ENTITY_ENFRC_ID] 
 
       WHERE ICS_SWMS_4_ANNUL_PROG_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4AnnualProgramReportSubmission')
								  
	    AND ICS_SWMS_4_ANNUL_PROG_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_SWMS_4_ANNUL_PROG_REP/ICS_MS_4_SWMP_CHANGES 
INSERT INTO [ICS_FLOW_ICIS].[ICS_MS_4_SWMP_CHANGES]
     SELECT I8.*
        from [ICS_FLOW_LOCAL].[ICS_SWMS_4_ANNUL_PROG_REP] [ICS_SWMS_4_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_SWMP_CHANGES] [I8]
 ON [I8].[ICS_SWMS_4_ANNUL_PROG_REP_ID] = [ICS_SWMS_4_ANNUL_PROG_REP].[ICS_SWMS_4_ANNUL_PROG_REP_ID] 
 
       WHERE ICS_SWMS_4_ANNUL_PROG_REP.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4AnnualProgramReportSubmission')
								  
	    AND ICS_SWMS_4_ANNUL_PROG_REP.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

					
				
	

-- ================================================================
-- ICS_SWMS_4_PRMT 
-- ================================================================
			
				-- DELETES for: ICS_SWMS_4_PRMT 
				
								
-- /ICS_SWMS_4_PRMT/ICS_MS_4_REGULATED_ENTITY_AREA/ICS_MS_4_REGULATED_ENTITY_AREA_COORD
DELETE I27
 from ICS_FLOW_ICIS.[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_MS_4_REGULATED_ENTITY_AREA] [I26]
 ON [I26].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_MS_4_REGULATED_ENTITY_AREA_COORD] [I27]
 ON [I27].[ICS_MS_4_REGULATED_ENTITY_AREA_ID] = [I26].[ICS_MS_4_REGULATED_ENTITY_AREA_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4PermitSubmission')
				
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_SWMS_4_PRMT/ICS_MS_4_REGULATED_ENTITY_AREA
DELETE I26
 from ICS_FLOW_ICIS.[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_MS_4_REGULATED_ENTITY_AREA] [I26]
 ON [I26].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4PermitSubmission')
				
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_SWMS_4_PRMT/ICS_MS_4_REGULATED_ENTITY
DELETE I25
 from ICS_FLOW_ICIS.[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_MS_4_REGULATED_ENTITY] [I25]
 ON [I25].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4PermitSubmission')
				
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_SWMS_4_PRMT/ICS_MS_4_POST_CNST_SW_REQS/ICS_MS_4_POST_CNST_SW_REGULATED_ENTITY_INFO
DELETE I24
 from ICS_FLOW_ICIS.[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_MS_4_POST_CNST_SW_REQS] [I21]
 ON [I21].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_MS_4_POST_CNST_SW_REGULATED_ENTITY_INFO] [I24]
 ON [I24].[ICS_MS_4_POST_CNST_SW_REQS_ID] = [I21].[ICS_MS_4_POST_CNST_SW_REQS_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4PermitSubmission')
				
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_SWMS_4_PRMT/ICS_MS_4_POST_CNST_SW_REQS/ICS_MS_4_POST_CNST_SW_PROCEDURES/ICS_MS_4_REGULATED_ENTITY_IDENT
DELETE I23
 from ICS_FLOW_ICIS.[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_MS_4_POST_CNST_SW_REQS] [I21]
 ON [I21].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_MS_4_POST_CNST_SW_PROCEDURES] [I22]
 ON [I22].[ICS_MS_4_POST_CNST_SW_REQS_ID] = [I21].[ICS_MS_4_POST_CNST_SW_REQS_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_MS_4_REGULATED_ENTITY_IDENT] [I23]
 ON [I23].[ICS_MS_4_POST_CNST_SW_PROCEDURES_ID] = [I22].[ICS_MS_4_POST_CNST_SW_PROCEDURES_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4PermitSubmission')
				
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_SWMS_4_PRMT/ICS_MS_4_POST_CNST_SW_REQS/ICS_MS_4_POST_CNST_SW_PROCEDURES
DELETE I22
 from ICS_FLOW_ICIS.[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_MS_4_POST_CNST_SW_REQS] [I21]
 ON [I21].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_MS_4_POST_CNST_SW_PROCEDURES] [I22]
 ON [I22].[ICS_MS_4_POST_CNST_SW_REQS_ID] = [I21].[ICS_MS_4_POST_CNST_SW_REQS_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4PermitSubmission')
				
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_SWMS_4_PRMT/ICS_MS_4_POST_CNST_SW_REQS
DELETE I21
 from ICS_FLOW_ICIS.[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_MS_4_POST_CNST_SW_REQS] [I21]
 ON [I21].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4PermitSubmission')
				
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_SWMS_4_PRMT/ICS_MS_4_POLLUTION_PREVENTION_REQS/ICS_MS_4_REGULATED_ENTITY_IDENT
DELETE I20
 from ICS_FLOW_ICIS.[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_MS_4_POLLUTION_PREVENTION_REQS] [I19]
 ON [I19].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_MS_4_REGULATED_ENTITY_IDENT] [I20]
 ON [I20].[ICS_MS_4_POLLUTION_PREVENTION_REQS_ID] = [I19].[ICS_MS_4_POLLUTION_PREVENTION_REQS_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4PermitSubmission')
				
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_SWMS_4_PRMT/ICS_MS_4_POLLUTION_PREVENTION_REQS
DELETE I19
 from ICS_FLOW_ICIS.[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_MS_4_POLLUTION_PREVENTION_REQS] [I19]
 ON [I19].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4PermitSubmission')
				
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_SWMS_4_PRMT/ICS_MS_4_PBLC_INVOLVEMENT_REQS/ICS_MS_4_REGULATED_ENTITY_IDENT
DELETE I18
 from ICS_FLOW_ICIS.[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_MS_4_PBLC_INVOLVEMENT_REQS] [I17]
 ON [I17].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_MS_4_REGULATED_ENTITY_IDENT] [I18]
 ON [I18].[ICS_MS_4_PBLC_INVOLVEMENT_REQS_ID] = [I17].[ICS_MS_4_PBLC_INVOLVEMENT_REQS_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4PermitSubmission')
				
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_SWMS_4_PRMT/ICS_MS_4_PBLC_INVOLVEMENT_REQS
DELETE I17
 from ICS_FLOW_ICIS.[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_MS_4_PBLC_INVOLVEMENT_REQS] [I17]
 ON [I17].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4PermitSubmission')
				
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;

								
-- /ICS_SWMS_4_PRMT/ICS_MS_4_PBLC_EDUCATION_REQS/ICS_MS_4_REGULATED_ENTITY_IDENT
DELETE I16
 from ICS_FLOW_ICIS.[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_MS_4_PBLC_EDUCATION_REQS] [I15]
 ON [I15].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_MS_4_REGULATED_ENTITY_IDENT] [I16]
 ON [I16].[ICS_MS_4_PBLC_EDUCATION_REQS_ID] = [I15].[ICS_MS_4_PBLC_EDUCATION_REQS_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4PermitSubmission')
				
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
 
								
-- /ICS_SWMS_4_PRMT/ICS_MS_4_INDST_SW_REQS/ICS_MS_4_INDST_SW_PROCEDURES/ICS_MS_4_REGULATED_ENTITY_IDENT
DELETE I11
 from ICS_FLOW_ICIS.[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_MS_4_INDST_SW_REQS] [I9]
 ON [I9].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_MS_4_INDST_SW_PROCEDURES] [I10]
 ON [I10].[ICS_MS_4_INDST_SW_REQS_ID] = [I9].[ICS_MS_4_INDST_SW_REQS_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_MS_4_REGULATED_ENTITY_IDENT] [I11]
 ON [I11].[ICS_MS_4_INDST_SW_PROCEDURES_ID] = [I10].[ICS_MS_4_INDST_SW_PROCEDURES_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4PermitSubmission')
				
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				 
				
print 	'delete: /ICS_SWMS_4_PRMT/ICS_MS_4_INDST_SW_REQS/ICS_MS_4_INDST_SW_PROCEDURES'							
-- /ICS_SWMS_4_PRMT/ICS_MS_4_INDST_SW_REQS/ICS_MS_4_INDST_SW_PROCEDURES
DELETE I10
 from ICS_FLOW_ICIS.[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_MS_4_INDST_SW_REQS] [I9]
 ON [I9].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_MS_4_INDST_SW_PROCEDURES] [I10]
 ON [I10].[ICS_MS_4_INDST_SW_REQS_ID] = [I9].[ICS_MS_4_INDST_SW_REQS_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4PermitSubmission')
				
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
print 'delete: 	/ICS_SWMS_4_PRMT/ICS_MS_4_PBLC_EDUCATION_REQS'							
-- /ICS_SWMS_4_PRMT/ICS_MS_4_PBLC_EDUCATION_REQS
DELETE I15
 from ICS_FLOW_ICIS.[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_MS_4_PBLC_EDUCATION_REQS] [I15]
 ON [I15].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4PermitSubmission')
				
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_SWMS_4_PRMT/ICS_MS_4_OTHR_APPL_REQS/ICS_MS_4_REGULATED_ENTITY_IDENT
DELETE I14
 from ICS_FLOW_ICIS.[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_MS_4_OTHR_APPL_REQS] [I13]
 ON [I13].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_MS_4_REGULATED_ENTITY_IDENT] [I14]
 ON [I14].[ICS_MS_4_OTHR_APPL_REQS_ID] = [I13].[ICS_MS_4_OTHR_APPL_REQS_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4PermitSubmission')
				
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_SWMS_4_PRMT/ICS_MS_4_OTHR_APPL_REQS
DELETE I13
 from ICS_FLOW_ICIS.[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_MS_4_OTHR_APPL_REQS] [I13]
 ON [I13].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4PermitSubmission')
				
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_SWMS_4_PRMT/ICS_MS_4_INDST_SW_REQS/ICS_MS_4_INDST_SW_REGULATED_ENTITY_INFO
DELETE I12
 from ICS_FLOW_ICIS.[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_MS_4_INDST_SW_REQS] [I9]
 ON [I9].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_MS_4_INDST_SW_REGULATED_ENTITY_INFO] [I12]
 ON [I12].[ICS_MS_4_INDST_SW_REQS_ID] = [I9].[ICS_MS_4_INDST_SW_REQS_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4PermitSubmission')
				
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				

				
								
-- /ICS_SWMS_4_PRMT/ICS_MS_4_INDST_SW_REQS
DELETE I9
 from ICS_FLOW_ICIS.[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_MS_4_INDST_SW_REQS] [I9]
 ON [I9].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4PermitSubmission')
				
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_SWMS_4_PRMT/ICS_MS_4_ILLICIT_DETECT_REQS/ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO
DELETE I8
 from ICS_FLOW_ICIS.[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_MS_4_ILLICIT_DETECT_REQS] [I5]
 ON [I5].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO] [I8]
 ON [I8].[ICS_MS_4_ILLICIT_DETECT_REQS_ID] = [I5].[ICS_MS_4_ILLICIT_DETECT_REQS_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4PermitSubmission')
				
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_SWMS_4_PRMT/ICS_MS_4_ILLICIT_DETECT_REQS/ICS_MS_4_ILLICIT_DETECT_PROCEDURES/ICS_MS_4_REGULATED_ENTITY_IDENT
DELETE I7
 from ICS_FLOW_ICIS.[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_MS_4_ILLICIT_DETECT_REQS] [I5]
 ON [I5].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_MS_4_ILLICIT_DETECT_PROCEDURES] [I6]
 ON [I6].[ICS_MS_4_ILLICIT_DETECT_REQS_ID] = [I5].[ICS_MS_4_ILLICIT_DETECT_REQS_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_MS_4_REGULATED_ENTITY_IDENT] [I7]
 ON [I7].[ICS_MS_4_ILLICIT_DETECT_PROCEDURES_ID] = [I6].[ICS_MS_4_ILLICIT_DETECT_PROCEDURES_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4PermitSubmission')
				
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_SWMS_4_PRMT/ICS_MS_4_ILLICIT_DETECT_REQS/ICS_MS_4_ILLICIT_DETECT_PROCEDURES
DELETE I6
 from ICS_FLOW_ICIS.[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_MS_4_ILLICIT_DETECT_REQS] [I5]
 ON [I5].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_MS_4_ILLICIT_DETECT_PROCEDURES] [I6]
 ON [I6].[ICS_MS_4_ILLICIT_DETECT_REQS_ID] = [I5].[ICS_MS_4_ILLICIT_DETECT_REQS_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4PermitSubmission')
				
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_SWMS_4_PRMT/ICS_MS_4_ILLICIT_DETECT_REQS
DELETE I5
 from ICS_FLOW_ICIS.[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_MS_4_ILLICIT_DETECT_REQS] [I5]
 ON [I5].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4PermitSubmission')
				
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_SWMS_4_PRMT/ICS_MS_4_CNST_SW_REQS/ICS_MS_4_CNST_SW_REGULATED_ENTITY_INFO
DELETE I4
 from ICS_FLOW_ICIS.[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_MS_4_CNST_SW_REQS] [I1]
 ON [I1].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_MS_4_CNST_SW_REGULATED_ENTITY_INFO] [I4]
 ON [I4].[ICS_MS_4_CNST_SW_REQS_ID] = [I1].[ICS_MS_4_CNST_SW_REQS_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4PermitSubmission')
				
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_SWMS_4_PRMT/ICS_MS_4_CNST_SW_REQS/ICS_MS_4_CNST_SW_PROCEDURES/ICS_MS_4_REGULATED_ENTITY_IDENT
DELETE I3
 from ICS_FLOW_ICIS.[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_MS_4_CNST_SW_REQS] [I1]
 ON [I1].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_MS_4_CNST_SW_PROCEDURES] [I2]
 ON [I2].[ICS_MS_4_CNST_SW_REQS_ID] = [I1].[ICS_MS_4_CNST_SW_REQS_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_MS_4_REGULATED_ENTITY_IDENT] [I3]
 ON [I3].[ICS_MS_4_CNST_SW_PROCEDURES_ID] = [I2].[ICS_MS_4_CNST_SW_PROCEDURES_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4PermitSubmission')
				
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_SWMS_4_PRMT/ICS_MS_4_CNST_SW_REQS/ICS_MS_4_CNST_SW_PROCEDURES
DELETE I2
 from ICS_FLOW_ICIS.[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_MS_4_CNST_SW_REQS] [I1]
 ON [I1].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_MS_4_CNST_SW_PROCEDURES] [I2]
 ON [I2].[ICS_MS_4_CNST_SW_REQS_ID] = [I1].[ICS_MS_4_CNST_SW_REQS_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4PermitSubmission')
				
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_SWMS_4_PRMT/ICS_MS_4_CNST_SW_REQS
DELETE I1
 from ICS_FLOW_ICIS.[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN ICS_FLOW_ICIS.[ICS_MS_4_CNST_SW_REQS] [I1]
 ON [I1].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4PermitSubmission')
				
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_SWMS_4_PRMT
DELETE ICS_SWMS_4_PRMT
 from ICS_FLOW_ICIS.[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4PermitSubmission')
				
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
					

				-- INSERTS for: ICS_SWMS_4_PRMT
	
				
-- /ICS_SWMS_4_PRMT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_SWMS_4_PRMT]
     SELECT ICS_SWMS_4_PRMT.*
        from [ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 
       WHERE ICS_SWMS_4_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4PermitSubmission')
								  
	    AND ICS_SWMS_4_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_SWMS_4_PRMT/ICS_MS_4_CNST_SW_REQS 
INSERT INTO [ICS_FLOW_ICIS].[ICS_MS_4_CNST_SW_REQS]
     SELECT I1.*
        from [ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_CNST_SW_REQS] [I1]
 ON [I1].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 
       WHERE ICS_SWMS_4_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4PermitSubmission')
								  
	    AND ICS_SWMS_4_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_SWMS_4_PRMT/ICS_MS_4_CNST_SW_REQS/ICS_MS_4_CNST_SW_PROCEDURES 
INSERT INTO [ICS_FLOW_ICIS].[ICS_MS_4_CNST_SW_PROCEDURES]
     SELECT I2.*
        from [ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_CNST_SW_REQS] [I1]
 ON [I1].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_CNST_SW_PROCEDURES] [I2]
 ON [I2].[ICS_MS_4_CNST_SW_REQS_ID] = [I1].[ICS_MS_4_CNST_SW_REQS_ID] 
 
       WHERE ICS_SWMS_4_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4PermitSubmission')
								  
	    AND ICS_SWMS_4_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_SWMS_4_PRMT/ICS_MS_4_CNST_SW_REQS/ICS_MS_4_CNST_SW_PROCEDURES/ICS_MS_4_REGULATED_ENTITY_IDENT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_MS_4_REGULATED_ENTITY_IDENT]
     SELECT I3.*
        from [ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_CNST_SW_REQS] [I1]
 ON [I1].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_CNST_SW_PROCEDURES] [I2]
 ON [I2].[ICS_MS_4_CNST_SW_REQS_ID] = [I1].[ICS_MS_4_CNST_SW_REQS_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_REGULATED_ENTITY_IDENT] [I3]
 ON [I3].[ICS_MS_4_CNST_SW_PROCEDURES_ID] = [I2].[ICS_MS_4_CNST_SW_PROCEDURES_ID] 
 
       WHERE ICS_SWMS_4_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4PermitSubmission')
								  
	    AND ICS_SWMS_4_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_SWMS_4_PRMT/ICS_MS_4_CNST_SW_REQS/ICS_MS_4_CNST_SW_REGULATED_ENTITY_INFO 
INSERT INTO [ICS_FLOW_ICIS].[ICS_MS_4_CNST_SW_REGULATED_ENTITY_INFO]
     SELECT I4.*
        from [ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_CNST_SW_REQS] [I1]
 ON [I1].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_CNST_SW_REGULATED_ENTITY_INFO] [I4]
 ON [I4].[ICS_MS_4_CNST_SW_REQS_ID] = [I1].[ICS_MS_4_CNST_SW_REQS_ID] 
 
       WHERE ICS_SWMS_4_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4PermitSubmission')
								  
	    AND ICS_SWMS_4_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_SWMS_4_PRMT/ICS_MS_4_ILLICIT_DETECT_REQS 
INSERT INTO [ICS_FLOW_ICIS].[ICS_MS_4_ILLICIT_DETECT_REQS]
     SELECT I5.*
        from [ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_ILLICIT_DETECT_REQS] [I5]
 ON [I5].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 
       WHERE ICS_SWMS_4_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4PermitSubmission')
								  
	    AND ICS_SWMS_4_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_SWMS_4_PRMT/ICS_MS_4_ILLICIT_DETECT_REQS/ICS_MS_4_ILLICIT_DETECT_PROCEDURES 
INSERT INTO [ICS_FLOW_ICIS].[ICS_MS_4_ILLICIT_DETECT_PROCEDURES]
     SELECT I6.*
        from [ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_ILLICIT_DETECT_REQS] [I5]
 ON [I5].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_ILLICIT_DETECT_PROCEDURES] [I6]
 ON [I6].[ICS_MS_4_ILLICIT_DETECT_REQS_ID] = [I5].[ICS_MS_4_ILLICIT_DETECT_REQS_ID] 
 
       WHERE ICS_SWMS_4_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4PermitSubmission')
								  
	    AND ICS_SWMS_4_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_SWMS_4_PRMT/ICS_MS_4_ILLICIT_DETECT_REQS/ICS_MS_4_ILLICIT_DETECT_PROCEDURES/ICS_MS_4_REGULATED_ENTITY_IDENT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_MS_4_REGULATED_ENTITY_IDENT]
     SELECT I7.*
        from [ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_ILLICIT_DETECT_REQS] [I5]
 ON [I5].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_ILLICIT_DETECT_PROCEDURES] [I6]
 ON [I6].[ICS_MS_4_ILLICIT_DETECT_REQS_ID] = [I5].[ICS_MS_4_ILLICIT_DETECT_REQS_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_REGULATED_ENTITY_IDENT] [I7]
 ON [I7].[ICS_MS_4_ILLICIT_DETECT_PROCEDURES_ID] = [I6].[ICS_MS_4_ILLICIT_DETECT_PROCEDURES_ID] 
 
       WHERE ICS_SWMS_4_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4PermitSubmission')
								  
	    AND ICS_SWMS_4_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_SWMS_4_PRMT/ICS_MS_4_ILLICIT_DETECT_REQS/ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO 
INSERT INTO [ICS_FLOW_ICIS].[ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO]
     SELECT I8.*
        from [ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_ILLICIT_DETECT_REQS] [I5]
 ON [I5].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO] [I8]
 ON [I8].[ICS_MS_4_ILLICIT_DETECT_REQS_ID] = [I5].[ICS_MS_4_ILLICIT_DETECT_REQS_ID] 
 
       WHERE ICS_SWMS_4_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4PermitSubmission')
								  
	    AND ICS_SWMS_4_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 
print 'insert: /ICS_SWMS_4_PRMT/ICS_MS_4_INDST_SW_REQS '
				
-- /ICS_SWMS_4_PRMT/ICS_MS_4_INDST_SW_REQS 
INSERT INTO [ICS_FLOW_ICIS].[ICS_MS_4_INDST_SW_REQS]
     SELECT I9.*
        from [ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_INDST_SW_REQS] [I9]
 ON [I9].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 
       WHERE ICS_SWMS_4_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4PermitSubmission')
								  
	    AND ICS_SWMS_4_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 
				
-- /ICS_SWMS_4_PRMT/ICS_MS_4_INDST_SW_REQS/ICS_MS_4_INDST_SW_PROCEDURES 
INSERT INTO [ICS_FLOW_ICIS].[ICS_MS_4_INDST_SW_PROCEDURES]
     SELECT I10.*
        from [ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_INDST_SW_REQS] [I9]
 ON [I9].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_INDST_SW_PROCEDURES] [I10]
 ON [I10].[ICS_MS_4_INDST_SW_REQS_ID] = [I9].[ICS_MS_4_INDST_SW_REQS_ID] 
 
       WHERE ICS_SWMS_4_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4PermitSubmission')
								  
	    AND ICS_SWMS_4_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;		

print 'Insert:  /ICS_SWMS_4_PRMT/ICS_MS_4_INDST_SW_REQS/ICS_MS_4_INDST_SW_PROCEDURES/ICS_MS_4_REGULATED_ENTITY_IDENT'

-- /ICS_SWMS_4_PRMT/ICS_MS_4_INDST_SW_REQS/ICS_MS_4_INDST_SW_PROCEDURES/ICS_MS_4_REGULATED_ENTITY_IDENT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_MS_4_REGULATED_ENTITY_IDENT]
     SELECT I11.*
        from [ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_INDST_SW_REQS] [I9]
 ON [I9].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_INDST_SW_PROCEDURES] [I10]
 ON [I10].[ICS_MS_4_INDST_SW_REQS_ID] = [I9].[ICS_MS_4_INDST_SW_REQS_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_REGULATED_ENTITY_IDENT] [I11]
 ON [I11].[ICS_MS_4_INDST_SW_PROCEDURES_ID] = [I10].[ICS_MS_4_INDST_SW_PROCEDURES_ID] 
 
       WHERE ICS_SWMS_4_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4PermitSubmission')
								  
	    AND ICS_SWMS_4_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_SWMS_4_PRMT/ICS_MS_4_INDST_SW_REQS/ICS_MS_4_INDST_SW_REGULATED_ENTITY_INFO 
INSERT INTO [ICS_FLOW_ICIS].[ICS_MS_4_INDST_SW_REGULATED_ENTITY_INFO]
     SELECT I12.*
        from [ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_INDST_SW_REQS] [I9]
 ON [I9].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_INDST_SW_REGULATED_ENTITY_INFO] [I12]
 ON [I12].[ICS_MS_4_INDST_SW_REQS_ID] = [I9].[ICS_MS_4_INDST_SW_REQS_ID] 
 
       WHERE ICS_SWMS_4_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4PermitSubmission')
								  
	    AND ICS_SWMS_4_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_SWMS_4_PRMT/ICS_MS_4_OTHR_APPL_REQS 
INSERT INTO [ICS_FLOW_ICIS].[ICS_MS_4_OTHR_APPL_REQS]
     SELECT I13.*
        from [ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_OTHR_APPL_REQS] [I13]
 ON [I13].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 
       WHERE ICS_SWMS_4_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4PermitSubmission')
								  
	    AND ICS_SWMS_4_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_SWMS_4_PRMT/ICS_MS_4_OTHR_APPL_REQS/ICS_MS_4_REGULATED_ENTITY_IDENT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_MS_4_REGULATED_ENTITY_IDENT]
     SELECT I14.*
        from [ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_OTHR_APPL_REQS] [I13]
 ON [I13].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_REGULATED_ENTITY_IDENT] [I14]
 ON [I14].[ICS_MS_4_OTHR_APPL_REQS_ID] = [I13].[ICS_MS_4_OTHR_APPL_REQS_ID] 
 
       WHERE ICS_SWMS_4_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4PermitSubmission')
								  
	    AND ICS_SWMS_4_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_SWMS_4_PRMT/ICS_MS_4_PBLC_EDUCATION_REQS 
INSERT INTO [ICS_FLOW_ICIS].[ICS_MS_4_PBLC_EDUCATION_REQS]
     SELECT I15.*
        from [ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_PBLC_EDUCATION_REQS] [I15]
 ON [I15].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 
       WHERE ICS_SWMS_4_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4PermitSubmission')
								  
	    AND ICS_SWMS_4_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

	 

				
-- /ICS_SWMS_4_PRMT/ICS_MS_4_PBLC_EDUCATION_REQS/ICS_MS_4_REGULATED_ENTITY_IDENT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_MS_4_REGULATED_ENTITY_IDENT]
     SELECT I16.*
        from [ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_PBLC_EDUCATION_REQS] [I15]
 ON [I15].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_REGULATED_ENTITY_IDENT] [I16]
 ON [I16].[ICS_MS_4_PBLC_EDUCATION_REQS_ID] = [I15].[ICS_MS_4_PBLC_EDUCATION_REQS_ID] 
 
       WHERE ICS_SWMS_4_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4PermitSubmission')
								  
	    AND ICS_SWMS_4_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_SWMS_4_PRMT/ICS_MS_4_PBLC_INVOLVEMENT_REQS 
INSERT INTO [ICS_FLOW_ICIS].[ICS_MS_4_PBLC_INVOLVEMENT_REQS]
     SELECT I17.*
        from [ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_PBLC_INVOLVEMENT_REQS] [I17]
 ON [I17].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 
       WHERE ICS_SWMS_4_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4PermitSubmission')
								  
	    AND ICS_SWMS_4_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_SWMS_4_PRMT/ICS_MS_4_PBLC_INVOLVEMENT_REQS/ICS_MS_4_REGULATED_ENTITY_IDENT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_MS_4_REGULATED_ENTITY_IDENT]
     SELECT I18.*
        from [ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_PBLC_INVOLVEMENT_REQS] [I17]
 ON [I17].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_REGULATED_ENTITY_IDENT] [I18]
 ON [I18].[ICS_MS_4_PBLC_INVOLVEMENT_REQS_ID] = [I17].[ICS_MS_4_PBLC_INVOLVEMENT_REQS_ID] 
 
       WHERE ICS_SWMS_4_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4PermitSubmission')
								  
	    AND ICS_SWMS_4_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_SWMS_4_PRMT/ICS_MS_4_POLLUTION_PREVENTION_REQS 
INSERT INTO [ICS_FLOW_ICIS].[ICS_MS_4_POLLUTION_PREVENTION_REQS]
     SELECT I19.*
        from [ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_POLLUTION_PREVENTION_REQS] [I19]
 ON [I19].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 
       WHERE ICS_SWMS_4_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4PermitSubmission')
								  
	    AND ICS_SWMS_4_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_SWMS_4_PRMT/ICS_MS_4_POLLUTION_PREVENTION_REQS/ICS_MS_4_REGULATED_ENTITY_IDENT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_MS_4_REGULATED_ENTITY_IDENT]
     SELECT I20.*
        from [ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_POLLUTION_PREVENTION_REQS] [I19]
 ON [I19].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_REGULATED_ENTITY_IDENT] [I20]
 ON [I20].[ICS_MS_4_POLLUTION_PREVENTION_REQS_ID] = [I19].[ICS_MS_4_POLLUTION_PREVENTION_REQS_ID] 
 
       WHERE ICS_SWMS_4_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4PermitSubmission')
								  
	    AND ICS_SWMS_4_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_SWMS_4_PRMT/ICS_MS_4_POST_CNST_SW_REQS 
INSERT INTO [ICS_FLOW_ICIS].[ICS_MS_4_POST_CNST_SW_REQS]
     SELECT I21.*
        from [ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_POST_CNST_SW_REQS] [I21]
 ON [I21].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 
       WHERE ICS_SWMS_4_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4PermitSubmission')
								  
	    AND ICS_SWMS_4_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_SWMS_4_PRMT/ICS_MS_4_POST_CNST_SW_REQS/ICS_MS_4_POST_CNST_SW_PROCEDURES 
INSERT INTO [ICS_FLOW_ICIS].[ICS_MS_4_POST_CNST_SW_PROCEDURES]
     SELECT I22.*
        from [ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_POST_CNST_SW_REQS] [I21]
 ON [I21].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_POST_CNST_SW_PROCEDURES] [I22]
 ON [I22].[ICS_MS_4_POST_CNST_SW_REQS_ID] = [I21].[ICS_MS_4_POST_CNST_SW_REQS_ID] 
 
       WHERE ICS_SWMS_4_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4PermitSubmission')
								  
	    AND ICS_SWMS_4_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_SWMS_4_PRMT/ICS_MS_4_POST_CNST_SW_REQS/ICS_MS_4_POST_CNST_SW_PROCEDURES/ICS_MS_4_REGULATED_ENTITY_IDENT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_MS_4_REGULATED_ENTITY_IDENT]
     SELECT I23.*
        from [ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_POST_CNST_SW_REQS] [I21]
 ON [I21].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_POST_CNST_SW_PROCEDURES] [I22]
 ON [I22].[ICS_MS_4_POST_CNST_SW_REQS_ID] = [I21].[ICS_MS_4_POST_CNST_SW_REQS_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_REGULATED_ENTITY_IDENT] [I23]
 ON [I23].[ICS_MS_4_POST_CNST_SW_PROCEDURES_ID] = [I22].[ICS_MS_4_POST_CNST_SW_PROCEDURES_ID] 
 
       WHERE ICS_SWMS_4_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4PermitSubmission')
								  
	    AND ICS_SWMS_4_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_SWMS_4_PRMT/ICS_MS_4_POST_CNST_SW_REQS/ICS_MS_4_POST_CNST_SW_REGULATED_ENTITY_INFO 
INSERT INTO [ICS_FLOW_ICIS].[ICS_MS_4_POST_CNST_SW_REGULATED_ENTITY_INFO]
     SELECT I24.*
        from [ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_POST_CNST_SW_REQS] [I21]
 ON [I21].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_POST_CNST_SW_REGULATED_ENTITY_INFO] [I24]
 ON [I24].[ICS_MS_4_POST_CNST_SW_REQS_ID] = [I21].[ICS_MS_4_POST_CNST_SW_REQS_ID] 
 
       WHERE ICS_SWMS_4_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4PermitSubmission')
								  
	    AND ICS_SWMS_4_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_SWMS_4_PRMT/ICS_MS_4_REGULATED_ENTITY 
INSERT INTO [ICS_FLOW_ICIS].[ICS_MS_4_REGULATED_ENTITY]
     SELECT I25.*
        from [ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_REGULATED_ENTITY] [I25]
 ON [I25].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 
       WHERE ICS_SWMS_4_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4PermitSubmission')
								  
	    AND ICS_SWMS_4_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_SWMS_4_PRMT/ICS_MS_4_REGULATED_ENTITY_AREA 
INSERT INTO [ICS_FLOW_ICIS].[ICS_MS_4_REGULATED_ENTITY_AREA]
     SELECT I26.*
        from [ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_REGULATED_ENTITY_AREA] [I26]
 ON [I26].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 
       WHERE ICS_SWMS_4_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4PermitSubmission')
								  
	    AND ICS_SWMS_4_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_SWMS_4_PRMT/ICS_MS_4_REGULATED_ENTITY_AREA/ICS_MS_4_REGULATED_ENTITY_AREA_COORD 
INSERT INTO [ICS_FLOW_ICIS].[ICS_MS_4_REGULATED_ENTITY_AREA_COORD]
     SELECT I27.*
        from [ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_REGULATED_ENTITY_AREA] [I26]
 ON [I26].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_REGULATED_ENTITY_AREA_COORD] [I27]
 ON [I27].[ICS_MS_4_REGULATED_ENTITY_AREA_ID] = [I26].[ICS_MS_4_REGULATED_ENTITY_AREA_ID] 
 
       WHERE ICS_SWMS_4_PRMT.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4PermitSubmission')
								  
	    AND ICS_SWMS_4_PRMT.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

					
				
	

-- ================================================================
-- ICS_UNPRMT_FAC 
-- ================================================================
			
				-- DELETES for: ICS_UNPRMT_FAC 
				
								
-- /ICS_UNPRMT_FAC/ICS_ADDR/ICS_TELEPH
DELETE I11
 from ICS_FLOW_ICIS.[ICS_UNPRMT_FAC] [ICS_UNPRMT_FAC] 
 JOIN ICS_FLOW_ICIS.[ICS_ADDR] [I10]
 ON [I10].[ICS_UNPRMT_FAC_ID] = [ICS_UNPRMT_FAC].[ICS_UNPRMT_FAC_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_TELEPH] [I11]
 ON [I11].[ICS_ADDR_ID] = [I10].[ICS_ADDR_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_UNPRMT_FAC.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'UnpermittedFacilitySubmission')
				
                  OR ICS_UNPRMT_FAC.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_UNPRMT_FAC.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_UNPRMT_FAC/ICS_ADDR
DELETE I10
 from ICS_FLOW_ICIS.[ICS_UNPRMT_FAC] [ICS_UNPRMT_FAC] 
 JOIN ICS_FLOW_ICIS.[ICS_ADDR] [I10]
 ON [I10].[ICS_UNPRMT_FAC_ID] = [ICS_UNPRMT_FAC].[ICS_UNPRMT_FAC_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_UNPRMT_FAC.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'UnpermittedFacilitySubmission')
				
                  OR ICS_UNPRMT_FAC.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_UNPRMT_FAC.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_UNPRMT_FAC/ICS_SIC_CODE
DELETE I9
 from ICS_FLOW_ICIS.[ICS_UNPRMT_FAC] [ICS_UNPRMT_FAC] 
 JOIN ICS_FLOW_ICIS.[ICS_SIC_CODE] [I9]
 ON [I9].[ICS_UNPRMT_FAC_ID] = [ICS_UNPRMT_FAC].[ICS_UNPRMT_FAC_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_UNPRMT_FAC.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'UnpermittedFacilitySubmission')
				
                  OR ICS_UNPRMT_FAC.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_UNPRMT_FAC.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_UNPRMT_FAC/ICS_GEO_COORD
DELETE I8
 from ICS_FLOW_ICIS.[ICS_UNPRMT_FAC] [ICS_UNPRMT_FAC] 
 JOIN ICS_FLOW_ICIS.[ICS_GEO_COORD] [I8]
 ON [I8].[ICS_UNPRMT_FAC_ID] = [ICS_UNPRMT_FAC].[ICS_UNPRMT_FAC_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_UNPRMT_FAC.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'UnpermittedFacilitySubmission')
				
                  OR ICS_UNPRMT_FAC.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_UNPRMT_FAC.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_UNPRMT_FAC/ICS_FAC_CLASS
DELETE I7
 from ICS_FLOW_ICIS.[ICS_UNPRMT_FAC] [ICS_UNPRMT_FAC] 
 JOIN ICS_FLOW_ICIS.[ICS_FAC_CLASS] [I7]
 ON [I7].[ICS_UNPRMT_FAC_ID] = [ICS_UNPRMT_FAC].[ICS_UNPRMT_FAC_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_UNPRMT_FAC.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'UnpermittedFacilitySubmission')
				
                  OR ICS_UNPRMT_FAC.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_UNPRMT_FAC.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_UNPRMT_FAC/ICS_PRMT_COMP_TYPE
DELETE I6
 from ICS_FLOW_ICIS.[ICS_UNPRMT_FAC] [ICS_UNPRMT_FAC] 
 JOIN ICS_FLOW_ICIS.[ICS_PRMT_COMP_TYPE] [I6]
 ON [I6].[ICS_UNPRMT_FAC_ID] = [ICS_UNPRMT_FAC].[ICS_UNPRMT_FAC_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_UNPRMT_FAC.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'UnpermittedFacilitySubmission')
				
                  OR ICS_UNPRMT_FAC.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_UNPRMT_FAC.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_UNPRMT_FAC/ICS_PLCY
DELETE I5
 from ICS_FLOW_ICIS.[ICS_UNPRMT_FAC] [ICS_UNPRMT_FAC] 
 JOIN ICS_FLOW_ICIS.[ICS_PLCY] [I5]
 ON [I5].[ICS_UNPRMT_FAC_ID] = [ICS_UNPRMT_FAC].[ICS_UNPRMT_FAC_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_UNPRMT_FAC.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'UnpermittedFacilitySubmission')
				
                  OR ICS_UNPRMT_FAC.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_UNPRMT_FAC.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_UNPRMT_FAC/ICS_ORIG_PROGS
DELETE I4
 from ICS_FLOW_ICIS.[ICS_UNPRMT_FAC] [ICS_UNPRMT_FAC] 
 JOIN ICS_FLOW_ICIS.[ICS_ORIG_PROGS] [I4]
 ON [I4].[ICS_UNPRMT_FAC_ID] = [ICS_UNPRMT_FAC].[ICS_UNPRMT_FAC_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_UNPRMT_FAC.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'UnpermittedFacilitySubmission')
				
                  OR ICS_UNPRMT_FAC.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_UNPRMT_FAC.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_UNPRMT_FAC/ICS_CONTACT/ICS_TELEPH
DELETE I3
 from ICS_FLOW_ICIS.[ICS_UNPRMT_FAC] [ICS_UNPRMT_FAC] 
 JOIN ICS_FLOW_ICIS.[ICS_CONTACT] [I2]
 ON [I2].[ICS_UNPRMT_FAC_ID] = [ICS_UNPRMT_FAC].[ICS_UNPRMT_FAC_ID] 
 JOIN ICS_FLOW_ICIS.[ICS_TELEPH] [I3]
 ON [I3].[ICS_CONTACT_ID] = [I2].[ICS_CONTACT_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_UNPRMT_FAC.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'UnpermittedFacilitySubmission')
				
                  OR ICS_UNPRMT_FAC.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_UNPRMT_FAC.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_UNPRMT_FAC/ICS_CONTACT
DELETE I2
 from ICS_FLOW_ICIS.[ICS_UNPRMT_FAC] [ICS_UNPRMT_FAC] 
 JOIN ICS_FLOW_ICIS.[ICS_CONTACT] [I2]
 ON [I2].[ICS_UNPRMT_FAC_ID] = [ICS_UNPRMT_FAC].[ICS_UNPRMT_FAC_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_UNPRMT_FAC.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'UnpermittedFacilitySubmission')
				
                  OR ICS_UNPRMT_FAC.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_UNPRMT_FAC.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_UNPRMT_FAC/ICS_NAICS_CODE
DELETE I1
 from ICS_FLOW_ICIS.[ICS_UNPRMT_FAC] [ICS_UNPRMT_FAC] 
 JOIN ICS_FLOW_ICIS.[ICS_NAICS_CODE] [I1]
 ON [I1].[ICS_UNPRMT_FAC_ID] = [ICS_UNPRMT_FAC].[ICS_UNPRMT_FAC_ID] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_UNPRMT_FAC.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'UnpermittedFacilitySubmission')
				
                  OR ICS_UNPRMT_FAC.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_UNPRMT_FAC.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
								
-- /ICS_UNPRMT_FAC
DELETE ICS_UNPRMT_FAC
 from ICS_FLOW_ICIS.[ICS_UNPRMT_FAC] [ICS_UNPRMT_FAC] 
 
 join ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_UNPRMT_FAC.KEY_HASH
                WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'UnpermittedFacilitySubmission')
				
                  OR ICS_UNPRMT_FAC.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted') 
				   
                  OR ICS_UNPRMT_FAC.prmt_ident IN (SELECT prmt_ident FROM ICS_FLOW_LOCAL.ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
				   ;
          				
				
					

				-- INSERTS for: ICS_UNPRMT_FAC
	
				
-- /ICS_UNPRMT_FAC 
INSERT INTO [ICS_FLOW_ICIS].[ICS_UNPRMT_FAC]
     SELECT ICS_UNPRMT_FAC.*
        from [ICS_FLOW_LOCAL].[ICS_UNPRMT_FAC] [ICS_UNPRMT_FAC] 
 
       WHERE ICS_UNPRMT_FAC.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'UnpermittedFacilitySubmission')
								  
	    AND ICS_UNPRMT_FAC.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_UNPRMT_FAC/ICS_NAICS_CODE 
INSERT INTO [ICS_FLOW_ICIS].[ICS_NAICS_CODE]
     SELECT I1.*
        from [ICS_FLOW_LOCAL].[ICS_UNPRMT_FAC] [ICS_UNPRMT_FAC] 
 JOIN [ICS_FLOW_LOCAL].[ICS_NAICS_CODE] [I1]
 ON [I1].[ICS_UNPRMT_FAC_ID] = [ICS_UNPRMT_FAC].[ICS_UNPRMT_FAC_ID] 
 
       WHERE ICS_UNPRMT_FAC.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'UnpermittedFacilitySubmission')
								  
	    AND ICS_UNPRMT_FAC.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_UNPRMT_FAC/ICS_CONTACT 
INSERT INTO [ICS_FLOW_ICIS].[ICS_CONTACT]
     SELECT I2.*
        from [ICS_FLOW_LOCAL].[ICS_UNPRMT_FAC] [ICS_UNPRMT_FAC] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTACT] [I2]
 ON [I2].[ICS_UNPRMT_FAC_ID] = [ICS_UNPRMT_FAC].[ICS_UNPRMT_FAC_ID] 
 
       WHERE ICS_UNPRMT_FAC.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'UnpermittedFacilitySubmission')
								  
	    AND ICS_UNPRMT_FAC.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_UNPRMT_FAC/ICS_CONTACT/ICS_TELEPH 
INSERT INTO [ICS_FLOW_ICIS].[ICS_TELEPH]
     SELECT I3.*
        from [ICS_FLOW_LOCAL].[ICS_UNPRMT_FAC] [ICS_UNPRMT_FAC] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTACT] [I2]
 ON [I2].[ICS_UNPRMT_FAC_ID] = [ICS_UNPRMT_FAC].[ICS_UNPRMT_FAC_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_TELEPH] [I3]
 ON [I3].[ICS_CONTACT_ID] = [I2].[ICS_CONTACT_ID] 
 
       WHERE ICS_UNPRMT_FAC.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'UnpermittedFacilitySubmission')
								  
	    AND ICS_UNPRMT_FAC.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_UNPRMT_FAC/ICS_ORIG_PROGS 
INSERT INTO [ICS_FLOW_ICIS].[ICS_ORIG_PROGS]
     SELECT I4.*
        from [ICS_FLOW_LOCAL].[ICS_UNPRMT_FAC] [ICS_UNPRMT_FAC] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ORIG_PROGS] [I4]
 ON [I4].[ICS_UNPRMT_FAC_ID] = [ICS_UNPRMT_FAC].[ICS_UNPRMT_FAC_ID] 
 
       WHERE ICS_UNPRMT_FAC.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'UnpermittedFacilitySubmission')
								  
	    AND ICS_UNPRMT_FAC.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_UNPRMT_FAC/ICS_PLCY 
INSERT INTO [ICS_FLOW_ICIS].[ICS_PLCY]
     SELECT I5.*
        from [ICS_FLOW_LOCAL].[ICS_UNPRMT_FAC] [ICS_UNPRMT_FAC] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PLCY] [I5]
 ON [I5].[ICS_UNPRMT_FAC_ID] = [ICS_UNPRMT_FAC].[ICS_UNPRMT_FAC_ID] 
 
       WHERE ICS_UNPRMT_FAC.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'UnpermittedFacilitySubmission')
								  
	    AND ICS_UNPRMT_FAC.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_UNPRMT_FAC/ICS_PRMT_COMP_TYPE 
INSERT INTO [ICS_FLOW_ICIS].[ICS_PRMT_COMP_TYPE]
     SELECT I6.*
        from [ICS_FLOW_LOCAL].[ICS_UNPRMT_FAC] [ICS_UNPRMT_FAC] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PRMT_COMP_TYPE] [I6]
 ON [I6].[ICS_UNPRMT_FAC_ID] = [ICS_UNPRMT_FAC].[ICS_UNPRMT_FAC_ID] 
 
       WHERE ICS_UNPRMT_FAC.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'UnpermittedFacilitySubmission')
								  
	    AND ICS_UNPRMT_FAC.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_UNPRMT_FAC/ICS_FAC_CLASS 
INSERT INTO [ICS_FLOW_ICIS].[ICS_FAC_CLASS]
     SELECT I7.*
        from [ICS_FLOW_LOCAL].[ICS_UNPRMT_FAC] [ICS_UNPRMT_FAC] 
 JOIN [ICS_FLOW_LOCAL].[ICS_FAC_CLASS] [I7]
 ON [I7].[ICS_UNPRMT_FAC_ID] = [ICS_UNPRMT_FAC].[ICS_UNPRMT_FAC_ID] 
 
       WHERE ICS_UNPRMT_FAC.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'UnpermittedFacilitySubmission')
								  
	    AND ICS_UNPRMT_FAC.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_UNPRMT_FAC/ICS_GEO_COORD 
INSERT INTO [ICS_FLOW_ICIS].[ICS_GEO_COORD]
     SELECT I8.*
        from [ICS_FLOW_LOCAL].[ICS_UNPRMT_FAC] [ICS_UNPRMT_FAC] 
 JOIN [ICS_FLOW_LOCAL].[ICS_GEO_COORD] [I8]
 ON [I8].[ICS_UNPRMT_FAC_ID] = [ICS_UNPRMT_FAC].[ICS_UNPRMT_FAC_ID] 
 
       WHERE ICS_UNPRMT_FAC.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'UnpermittedFacilitySubmission')
								  
	    AND ICS_UNPRMT_FAC.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_UNPRMT_FAC/ICS_SIC_CODE 
INSERT INTO [ICS_FLOW_ICIS].[ICS_SIC_CODE]
     SELECT I9.*
        from [ICS_FLOW_LOCAL].[ICS_UNPRMT_FAC] [ICS_UNPRMT_FAC] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SIC_CODE] [I9]
 ON [I9].[ICS_UNPRMT_FAC_ID] = [ICS_UNPRMT_FAC].[ICS_UNPRMT_FAC_ID] 
 
       WHERE ICS_UNPRMT_FAC.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'UnpermittedFacilitySubmission')
								  
	    AND ICS_UNPRMT_FAC.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_UNPRMT_FAC/ICS_ADDR 
INSERT INTO [ICS_FLOW_ICIS].[ICS_ADDR]
     SELECT I10.*
        from [ICS_FLOW_LOCAL].[ICS_UNPRMT_FAC] [ICS_UNPRMT_FAC] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ADDR] [I10]
 ON [I10].[ICS_UNPRMT_FAC_ID] = [ICS_UNPRMT_FAC].[ICS_UNPRMT_FAC_ID] 
 
       WHERE ICS_UNPRMT_FAC.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'UnpermittedFacilitySubmission')
								  
	    AND ICS_UNPRMT_FAC.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

				
-- /ICS_UNPRMT_FAC/ICS_ADDR/ICS_TELEPH 
INSERT INTO [ICS_FLOW_ICIS].[ICS_TELEPH]
     SELECT I11.*
        from [ICS_FLOW_LOCAL].[ICS_UNPRMT_FAC] [ICS_UNPRMT_FAC] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ADDR] [I10]
 ON [I10].[ICS_UNPRMT_FAC_ID] = [ICS_UNPRMT_FAC].[ICS_UNPRMT_FAC_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_TELEPH] [I11]
 ON [I11].[ICS_ADDR_ID] = [I10].[ICS_ADDR_ID] 
 
       WHERE ICS_UNPRMT_FAC.transaction_type not in ('D','X')
        AND key_hash IN 
              (SELECT key_hash
                 FROM ICS_FLOW_LOCAL.ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'UnpermittedFacilitySubmission')
								  
	    AND ICS_UNPRMT_FAC.prmt_ident NOT IN
              (SELECT prmt_ident
			     FROM ICS_FLOW_LOCAL.ics_subm_results
				WHERE subm_type_name = 'PermitTerminationSubmission'
				  AND result_type_code = 'Accepted')   
				  ;			 

					
				


--Step 4: Copy business keys where ICIS returnes error that key is already present in ICIS

  -- Add keys that already exist in ICIS for module ics_basic_prmt
  INSERT INTO ICS_FLOW_ICIS.ics_basic_prmt (ics_payload_id, ics_basic_prmt_id, prmt_ident, key_hash, data_hash)
       SELECT (SELECT ics_payload_id FROM ICS_FLOW_LOCAL.ics_payload WHERE operation='BasicPermitSubmission') as payload_id, NEWID(), prmt_ident, key_hash, '0' as data_hash
         FROM ICS_FLOW_LOCAL.ics_subm_results
        WHERE result_code = 'BP060'
          AND subm_type_name = 'BasicPermitSubmission'
          AND subm_transaction_id = @p_transaction_id
          AND key_hash NOT IN (SELECT key_hash FROM ICS_FLOW_ICIS.ics_basic_prmt WHERE KEY_HASH IS NOT NULL)
     GROUP BY prmt_ident, key_hash;

  -- Add keys that already exist in ICIS for module ics_bs_prmt
  INSERT INTO ICS_FLOW_ICIS.ics_bs_prmt (ics_payload_id, ics_bs_prmt_id, prmt_ident, key_hash, data_hash)
       SELECT (SELECT ics_payload_id FROM ICS_FLOW_LOCAL.ics_payload WHERE operation='BiosolidsPermitSubmission') as payload_id, NEWID(), prmt_ident, key_hash, '0' as data_hash
         FROM ICS_FLOW_LOCAL.ics_subm_results
        WHERE result_code = 'PC040'
          AND subm_type_name = 'BiosolidsPermitSubmission'
          AND subm_transaction_id = @p_transaction_id
          AND key_hash NOT IN (SELECT key_hash FROM ICS_FLOW_ICIS.ics_bs_prmt WHERE KEY_HASH IS NOT NULL)
     GROUP BY prmt_ident, key_hash;

  -- Add keys that already exist in ICIS for module ics_cafo_prmt
  INSERT INTO ICS_FLOW_ICIS.ics_cafo_prmt (ics_payload_id, ics_cafo_prmt_id, prmt_ident, key_hash, data_hash)
       SELECT (SELECT ics_payload_id FROM ICS_FLOW_LOCAL.ics_payload WHERE operation='CAFOPermitSubmission') as payload_id, NEWID(), prmt_ident, key_hash, '0' as data_hash
         FROM ICS_FLOW_LOCAL.ics_subm_results
        WHERE result_code = 'PC040'
          AND subm_type_name = 'CAFOPermitSubmission'
          AND subm_transaction_id = @p_transaction_id
          AND key_hash NOT IN (SELECT key_hash FROM ICS_FLOW_ICIS.ics_cafo_prmt WHERE KEY_HASH IS NOT NULL)
     GROUP BY prmt_ident, key_hash;

  -- Add keys that already exist in ICIS for module ics_cso_prmt
  --INSERT INTO ICS_FLOW_ICIS.ics_cso_prmt (ics_payload_id, ics_cso_prmt_id, prmt_ident, key_hash, data_hash)
  --     SELECT (SELECT ics_payload_id FROM ICS_FLOW_LOCAL.ics_payload WHERE operation='CSOPermitSubmission') as payload_id, NEWID(), prmt_ident, key_hash, '0' as data_hash
  --       FROM ICS_FLOW_LOCAL.ics_subm_results
  --      WHERE result_code = 'PC040'
  --        AND subm_type_name = 'CSOPermitSubmission'
  --        AND subm_transaction_id = @p_transaction_id
  --        AND key_hash NOT IN (SELECT key_hash FROM ICS_FLOW_ICIS.ics_cso_prmt)
  --   GROUP BY prmt_ident, key_hash;

  -- Add keys that already exist in ICIS for module ics_gnrl_prmt
  INSERT INTO ICS_FLOW_ICIS.ics_gnrl_prmt (ics_payload_id, ics_gnrl_prmt_id, prmt_ident, key_hash, data_hash)
       SELECT (SELECT ics_payload_id FROM ICS_FLOW_LOCAL.ics_payload WHERE operation='GeneralPermitSubmission') as payload_id, NEWID(), prmt_ident, key_hash, '0' as data_hash
         FROM ICS_FLOW_LOCAL.ics_subm_results
        WHERE result_code = 'BP060'
          AND subm_type_name = 'GeneralPermitSubmission'
          AND subm_transaction_id = @p_transaction_id
          AND key_hash NOT IN (SELECT key_hash FROM ICS_FLOW_ICIS.ics_gnrl_prmt WHERE KEY_HASH IS NOT NULL)
     GROUP BY prmt_ident, key_hash;
     
  -- Add keys that already exist in ICIS for module ics_master_gnrl_prmt
  INSERT INTO ICS_FLOW_ICIS.ics_master_gnrl_prmt (ics_payload_id, ics_master_gnrl_prmt_id, prmt_ident, key_hash, data_hash)
       SELECT (SELECT ics_payload_id FROM ICS_FLOW_LOCAL.ics_payload WHERE operation='MasterGeneralPermitSubmission') as payload_id, NEWID(), prmt_ident, key_hash, '0' as data_hash
         FROM ICS_FLOW_LOCAL.ics_subm_results
        WHERE result_code = 'MGP040'
          AND subm_type_name = 'MasterGeneralPermitSubmission'
          AND subm_transaction_id = @p_transaction_id
          AND key_hash NOT IN (SELECT key_hash FROM ICS_FLOW_ICIS.ics_master_gnrl_prmt WHERE KEY_HASH IS NOT NULL)
     GROUP BY prmt_ident, key_hash;

  -- Add keys that already exist in ICIS for module ics_prmt_track_evt
  INSERT INTO ICS_FLOW_ICIS.ics_prmt_track_evt (ics_payload_id, ics_prmt_track_evt_id, prmt_ident,  prmt_track_evt_code,  prmt_track_evt_date, key_hash, data_hash)
       SELECT (SELECT ics_payload_id FROM ICS_FLOW_LOCAL.ics_payload WHERE operation='PermitTrackingEventSubmission') as payload_id, NEWID(), prmt_ident,  prmt_track_evt_code,  prmt_track_evt_date, key_hash, '0' as data_hash
         FROM ICS_FLOW_LOCAL.ics_subm_results
        WHERE result_code = 'PTE030'
          AND subm_type_name = 'PermitTrackingEventSubmission'
          AND subm_transaction_id = @p_transaction_id
          AND key_hash NOT IN (SELECT key_hash FROM ICS_FLOW_ICIS.ics_prmt_track_evt WHERE KEY_HASH IS NOT NULL)
     GROUP BY prmt_ident,  prmt_track_evt_code,  prmt_track_evt_date, key_hash;

  -- Add keys that already exist in ICIS for module ics_potw_prmt
  INSERT INTO ICS_FLOW_ICIS.ics_potw_prmt (ics_payload_id, ics_potw_prmt_id, prmt_ident, key_hash, data_hash)
       SELECT (SELECT ics_payload_id FROM ICS_FLOW_LOCAL.ics_payload WHERE operation='POTWPermitSubmission') as payload_id, NEWID(), prmt_ident, key_hash, '0' as data_hash
         FROM ICS_FLOW_LOCAL.ics_subm_results
        WHERE result_code = 'PC040'
          AND subm_type_name = 'POTWPermitSubmission'
          AND subm_transaction_id = @p_transaction_id
          AND key_hash NOT IN (SELECT key_hash FROM ICS_FLOW_ICIS.ics_potw_prmt WHERE KEY_HASH IS NOT NULL)
     GROUP BY prmt_ident, key_hash;

  -- Add keys that already exist in ICIS for module ics_pretr_prmt
  INSERT INTO ICS_FLOW_ICIS.ics_pretr_prmt (ics_payload_id, ics_pretr_prmt_id, prmt_ident, key_hash, data_hash)
       SELECT (SELECT ics_payload_id FROM ICS_FLOW_LOCAL.ics_payload WHERE operation='PretreatmentPermitSubmission') as payload_id, NEWID(), prmt_ident, key_hash, '0' as data_hash
         FROM ICS_FLOW_LOCAL.ics_subm_results
        WHERE result_code = 'PC040'
          AND subm_type_name = 'PretreatmentPermitSubmission'
          AND subm_transaction_id = @p_transaction_id
          AND key_hash NOT IN (SELECT key_hash FROM ICS_FLOW_ICIS.ics_pretr_prmt WHERE KEY_HASH IS NOT NULL)
     GROUP BY prmt_ident, key_hash;

  -- Add keys that already exist in ICIS for module ics_sw_cnst_prmt
  INSERT INTO ICS_FLOW_ICIS.ics_sw_cnst_prmt (ics_payload_id, ics_sw_cnst_prmt_id, prmt_ident, key_hash, data_hash)
       SELECT (SELECT ics_payload_id FROM ICS_FLOW_LOCAL.ics_payload WHERE operation='SWConstructionPermitSubmission') as payload_id, NEWID(), prmt_ident, key_hash, '0' as data_hash
         FROM ICS_FLOW_LOCAL.ics_subm_results
        WHERE result_code = 'PC040'
          AND subm_type_name = 'SWConstructionPermitSubmission'
          AND subm_transaction_id = @p_transaction_id
          AND key_hash NOT IN (SELECT key_hash FROM ICS_FLOW_ICIS.ics_sw_cnst_prmt WHERE KEY_HASH IS NOT NULL)
     GROUP BY prmt_ident, key_hash;

  -- Add keys that already exist in ICIS for module ics_sw_indst_prmt
  INSERT INTO ICS_FLOW_ICIS.ics_sw_indst_prmt (ics_payload_id, ics_sw_indst_prmt_id, prmt_ident, key_hash, data_hash)
       SELECT (SELECT ics_payload_id FROM ICS_FLOW_LOCAL.ics_payload WHERE operation='SWIndustrialPermitSubmission') as payload_id, NEWID(), prmt_ident, key_hash, '0' as data_hash
         FROM ICS_FLOW_LOCAL.ics_subm_results
        WHERE result_code = 'PC040'
          AND subm_type_name = 'SWIndustrialPermitSubmission'
          AND subm_transaction_id = @p_transaction_id
          AND key_hash NOT IN (SELECT key_hash FROM ICS_FLOW_ICIS.ics_sw_indst_prmt WHERE KEY_HASH IS NOT NULL)
     GROUP BY prmt_ident, key_hash;

  ---- Add keys that already exist in ICIS for module ics_swms_4_large_prmt
  --INSERT INTO ICS_FLOW_ICIS.ics_swms_4_large_prmt (ics_payload_id, ics_swms_4_large_prmt_id, prmt_ident, key_hash, data_hash)
  --     SELECT (SELECT ics_payload_id FROM ICS_FLOW_LOCAL.ics_payload WHERE operation='SWMS4LargePermitSubmission') as payload_id, NEWID(), prmt_ident, key_hash, '0' as data_hash
  --       FROM ICS_FLOW_LOCAL.ics_subm_results
  --      WHERE result_code = 'PC040'
  --        AND subm_type_name = 'SWMS4LargePermitSubmission'
  --        AND subm_transaction_id = @p_transaction_id
  --        AND key_hash NOT IN (SELECT key_hash FROM ICS_FLOW_ICIS.ics_swms_4_large_prmt)
  --   GROUP BY prmt_ident, key_hash;

  ---- Add keys that already exist in ICIS for module ics_swms_4_small_prmt
  --INSERT INTO ICS_FLOW_ICIS.ics_swms_4_small_prmt (ics_payload_id, ics_swms_4_small_prmt_id, prmt_ident, key_hash, data_hash)
  --     SELECT (SELECT ics_payload_id FROM ICS_FLOW_LOCAL.ics_payload WHERE operation='SWMS4SmallPermitSubmission') as payload_id, NEWID(), prmt_ident, key_hash, '0' as data_hash
  --       FROM ICS_FLOW_LOCAL.ics_subm_results
  --      WHERE result_code = 'PC040'
  --        AND subm_type_name = 'SWMS4SmallPermitSubmission'
  --        AND subm_transaction_id = @p_transaction_id
  --        AND key_hash NOT IN (SELECT key_hash FROM ICS_FLOW_ICIS.ics_swms_4_small_prmt)
  --   GROUP BY prmt_ident, key_hash;

  -- Add keys that already exist in ICIS for module ics_unprmt_fac
  INSERT INTO ICS_FLOW_ICIS.ics_unprmt_fac (ics_payload_id, ics_unprmt_fac_id, prmt_ident, key_hash, data_hash)
       SELECT (SELECT ics_payload_id FROM ICS_FLOW_LOCAL.ics_payload WHERE operation='UnpermittedFacilitySubmission') as payload_id, NEWID(), prmt_ident, key_hash, '0' as data_hash
         FROM ICS_FLOW_LOCAL.ics_subm_results
        WHERE result_code = 'UPF060'
          AND subm_type_name = 'UnpermittedFacilitySubmission'
          AND subm_transaction_id = @p_transaction_id
          AND key_hash NOT IN (SELECT key_hash FROM ICS_FLOW_ICIS.ics_unprmt_fac WHERE KEY_HASH IS NOT NULL)
     GROUP BY prmt_ident, key_hash;

  -- Add keys that already exist in ICIS for module ics_prmt_featr
  INSERT INTO ICS_FLOW_ICIS.ics_prmt_featr (ics_payload_id, ics_prmt_featr_id, prmt_ident,  prmt_featr_ident, key_hash, data_hash)
       SELECT (SELECT ics_payload_id FROM ICS_FLOW_LOCAL.ics_payload WHERE operation='PermittedFeatureSubmission') as payload_id, NEWID(), prmt_ident,  prmt_featr_ident, key_hash, '0' as data_hash
         FROM ICS_FLOW_LOCAL.ics_subm_results
        WHERE result_code = 'PF030'
          AND subm_type_name = 'PermittedFeatureSubmission'
          AND subm_transaction_id = @p_transaction_id
          AND key_hash NOT IN (SELECT key_hash FROM ICS_FLOW_ICIS.ics_prmt_featr WHERE KEY_HASH IS NOT NULL)
     GROUP BY prmt_ident,  prmt_featr_ident, key_hash;

  -- Add keys that already exist in ICIS for module ics_lmt_set
  INSERT INTO ICS_FLOW_ICIS.ics_lmt_set (ics_payload_id, ics_lmt_set_id, prmt_ident,  prmt_featr_ident,  lmt_set_designator, LMT_SET_TYPE, key_hash, data_hash)
       SELECT (SELECT ics_payload_id FROM ICS_FLOW_LOCAL.ics_payload WHERE operation='LimitSetSubmission') as payload_id, NEWID(), prmt_ident,  prmt_featr_ident,  lmt_set_designator, 'S', key_hash, '0' as data_hash
         FROM ICS_FLOW_LOCAL.ics_subm_results
        WHERE result_code = 'LS060'
          AND subm_type_name = 'LimitSetSubmission'
          AND subm_transaction_id = @p_transaction_id
          AND key_hash NOT IN (SELECT key_hash FROM ICS_FLOW_ICIS.ics_lmt_set WHERE KEY_HASH IS NOT NULL)
     GROUP BY prmt_ident,  prmt_featr_ident,  lmt_set_designator, key_hash;

  -- Add keys that already exist in ICIS for module ics_lmts
  INSERT INTO ICS_FLOW_ICIS.ics_lmts (ics_payload_id, ics_lmts_id, prmt_ident,  prmt_featr_ident,  lmt_set_designator,  param_code,  mon_site_desc_code,  lmt_season_num,  lmt_start_date,  lmt_end_date, key_hash, data_hash)
       SELECT (SELECT ics_payload_id FROM ICS_FLOW_LOCAL.ics_payload WHERE operation='LimitsSubmission') as payload_id, NEWID(), prmt_ident,  prmt_featr_ident,  lmt_set_designator,  param_code,  mon_site_desc_code,  lmt_season_num,  lmt_start_date,  lmt_end_date, key_hash, '0' as data_hash
         FROM ICS_FLOW_LOCAL.ics_subm_results
        WHERE result_code = 'LTS050'
          AND subm_type_name = 'LimitsSubmission'
          AND subm_transaction_id = @p_transaction_id
          AND key_hash NOT IN (SELECT key_hash FROM ICS_FLOW_ICIS.ics_lmts WHERE KEY_HASH IS NOT NULL)
     GROUP BY prmt_ident,  prmt_featr_ident,  lmt_set_designator,  param_code,  mon_site_desc_code,  lmt_season_num,  lmt_start_date,  lmt_end_date, key_hash;

  -- Add keys that already exist in ICIS for module ics_cmpl_mon
  INSERT INTO ICS_FLOW_ICIS.ics_cmpl_mon (ics_payload_id, ics_cmpl_mon_id, cmpl_mon_ident, prmt_ident,  cmpl_mon_catg_code,  cmpl_mon_date, key_hash, data_hash)
       SELECT (SELECT ics_payload_id FROM ICS_FLOW_LOCAL.ics_payload WHERE operation='ComplianceMonitoringSubmission') as payload_id, NEWID(), cmpl_mon_ident, prmt_ident,  cmpl_mon_catg_code,  cmpl_mon_date, key_hash, '0' as data_hash
         FROM ICS_FLOW_LOCAL.ics_subm_results
        WHERE result_code = 'CM432'
          AND subm_type_name = 'ComplianceMonitoringSubmission'
          AND subm_transaction_id = @p_transaction_id
          AND key_hash NOT IN (SELECT key_hash FROM ICS_FLOW_ICIS.ics_cmpl_mon WHERE KEY_HASH IS NOT NULL)
     GROUP BY cmpl_mon_ident, prmt_ident, cmpl_mon_catg_code, cmpl_mon_date, key_hash;

  -- Add keys that already exist in ICIS for module ics_efflu_trade_prtner
  INSERT INTO ICS_FLOW_ICIS.ics_efflu_trade_prtner (ics_payload_id, ics_efflu_trade_prtner_id, prmt_ident,  prmt_featr_ident,  lmt_set_designator,  param_code,  mon_site_desc_code,  lmt_season_num,  lmt_start_date,  lmt_end_date,  lmt_mod_effective_date,  trade_id, key_hash, data_hash)
       SELECT (SELECT ics_payload_id FROM ICS_FLOW_LOCAL.ics_payload WHERE operation='EffluentTradePartnerSubmission') as payload_id, NEWID(), prmt_ident,  prmt_featr_ident,  lmt_set_designator,  param_code,  mon_site_desc_code,  lmt_season_num,  lmt_start_date,  lmt_end_date,  lmt_mod_effective_date,  trade_id, key_hash, '0' as data_hash
         FROM ICS_FLOW_LOCAL.ics_subm_results
        WHERE result_code = 'ETP030'
          AND subm_type_name = 'EffluentTradePartnerSubmission'
          AND subm_transaction_id = @p_transaction_id
          AND key_hash NOT IN (SELECT key_hash FROM ICS_FLOW_ICIS.ics_efflu_trade_prtner WHERE KEY_HASH IS NOT NULL)
     GROUP BY prmt_ident,  prmt_featr_ident,  lmt_set_designator,  param_code,  mon_site_desc_code,  lmt_season_num,  lmt_start_date,  lmt_end_date,  lmt_mod_effective_date,  trade_id, key_hash;

  -- Add keys that already exist in ICIS for module ics_frml_enfrc_actn
  INSERT INTO ICS_FLOW_ICIS.ics_frml_enfrc_actn (ics_payload_id, ics_frml_enfrc_actn_id, enfrc_actn_ident, key_hash, data_hash)
       SELECT (SELECT ics_payload_id FROM ICS_FLOW_LOCAL.ics_payload WHERE operation='FormalEnforcementActionSubmission') as payload_id, NEWID(), enfrc_actn_ident, key_hash, '0' as data_hash
         FROM ICS_FLOW_LOCAL.ics_subm_results
        WHERE result_code = 'FEA030'
          AND subm_type_name = 'FormalEnforcementActionSubmission'
          AND subm_transaction_id = @p_transaction_id
          AND key_hash NOT IN (SELECT key_hash FROM ICS_FLOW_ICIS.ics_frml_enfrc_actn WHERE KEY_HASH IS NOT NULL)
     GROUP BY enfrc_actn_ident, key_hash;

  -- Add keys that already exist in ICIS for module ics_infrml_enfrc_actn
  INSERT INTO ICS_FLOW_ICIS.ics_infrml_enfrc_actn (ics_payload_id, ics_infrml_enfrc_actn_id, enfrc_actn_ident, key_hash, data_hash)
       SELECT (SELECT ics_payload_id FROM ICS_FLOW_LOCAL.ics_payload WHERE operation='InformalEnforcementActionSubmission') as payload_id, NEWID(), enfrc_actn_ident, key_hash, '0' as data_hash
         FROM ICS_FLOW_LOCAL.ics_subm_results
        WHERE result_code IN ('IEA030','FEA030') --added FEA030 because ICIS returns wrong error code in this case 12/27/2012 BRensmith
          AND subm_type_name = 'InformalEnforcementActionSubmission'
          AND subm_transaction_id = @p_transaction_id
          AND key_hash NOT IN (SELECT key_hash FROM ICS_FLOW_ICIS.ics_infrml_enfrc_actn WHERE KEY_HASH IS NOT NULL)
     GROUP BY enfrc_actn_ident, key_hash;

  -- Add keys that already exist in ICIS for module ics_sngl_evt_viol
  INSERT INTO ICS_FLOW_ICIS.ics_sngl_evt_viol (ics_payload_id, ics_sngl_evt_viol_id, prmt_ident,  sngl_evt_viol_code,  sngl_evt_viol_date, key_hash, data_hash)
       SELECT (SELECT ics_payload_id FROM ICS_FLOW_LOCAL.ics_payload WHERE operation='SingleEventViolationSubmission') as payload_id, NEWID(), prmt_ident,  sngl_evt_viol_code,  sngl_evt_viol_date, key_hash, '0' as data_hash
         FROM ICS_FLOW_LOCAL.ics_subm_results
        WHERE result_code = 'SEV030'
          AND subm_type_name = 'SingleEventViolationSubmission'
          AND subm_transaction_id = @p_transaction_id
          AND key_hash NOT IN (SELECT key_hash FROM ICS_FLOW_ICIS.ics_sngl_evt_viol WHERE KEY_HASH IS NOT NULL)
     GROUP BY prmt_ident,  sngl_evt_viol_code,  sngl_evt_viol_date, key_hash;

--Step 5: Record counts INTO ICS_FLOW_LOCAL.ics_subm_hist

INSERT INTO ICS_FLOW_LOCAL.ics_subm_hist (
       ics_subm_hist_id
     , subm_date_time
     , subm_transaction_id
     , subm_type_name
     , trans_count_new
     , trans_count_chng_repl
     , trans_count_del_mass_del
     , error_count
     , warning_count
     , accepted_count
     , accepted_count_total
     , created_date_time)
SELECT NEWID() AS ics_subm_hist_id
     , (SELECT subm_date_time FROM ICS_FLOW_LOCAL.ics_subm_track WHERE subm_transaction_id = @p_transaction_id) as subm_date_time
     , @p_transaction_id 
     , operation
     , ISNULL(trans_count_new, 0)
     , ISNULL(trans_count_chng_repl, 0)
     , ISNULL(trans_count_del_mass_del, 0)
     , error_count
     , warning_count
     , accepted_count
     , ISNULL(accepted_count_total, 0)
     , GETDATE() AS created_date_time
  FROM ICS_FLOW_LOCAL.ics_v_module_count
    WHERE (ISNULL(trans_count_new, 0) +
      ISNULL(trans_count_chng_repl, 0) +
      ISNULL(trans_count_del_mass_del, 0) +
      ISNULL(error_count, 0) +
      ISNULL(warning_count, 0) +
      ISNULL(accepted_count, 0)) > 0;

GO



-- EXEC ICS_FLOW_LOCAL.ICS_PROCESS_ACCEPTED_TRANS @p_transaction_id = '1' -- varchar(50)
