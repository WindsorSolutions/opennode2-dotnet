﻿
/*************************************************************************************************
** ObjectName: ics_etl_PermitReissuance
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the PermitReissuanceSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/18/2025   Windsor      Created 
**
***************************************************************************************************/
CREATE OR ALTER PROCEDURE ics_flow_local.ics_etl_PermitReissuance

AS

BEGIN
---------------------------- 
-- ICS_PRMT_REISSU
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- /ICS_PRMT_REISSU
DELETE
  FROM ics_flow_local.ICS_PRMT_REISSU;


-- /ICS_PRMT_REISSU
INSERT INTO ics_flow_local.ICS_PRMT_REISSU (
     [ICS_PRMT_REISSU_ID]
   , [ICS_PAYLOAD_ID]
   , [SRC_SYSTM_IDENT]
   , [TRANSACTION_TYPE]
   , [TRANSACTION_TIMESTAMP]
   , [PRMT_IDENT]
   , [PRMT_ISSUE_DATE]
   , [PRMT_EFFECTIVE_DATE]
   , [PRMT_EXPR_DATE]
   , [KEY_HASH]
   , [DATA_HASH])
SELECT 
     null  --ICS_PRMT_REISSU_ID, 
   , null  --ICS_PAYLOAD_ID, 
   , null  --SRC_SYSTM_IDENT, SourceSystemIdentifier
   , null  --TRANSACTION_TYPE, TransactionType
   , null  --TRANSACTION_TIMESTAMP, TransactionTimestamp
   , null  --PRMT_IDENT, PermitIdentifier
   , null  --PRMT_ISSUE_DATE, PermitIssueDate
   , null  --PRMT_EFFECTIVE_DATE, PermitEffectiveDate
   , null  --PRMT_EXPR_DATE, PermitExpirationDate
   , null  --KEY_HASH, 
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

END;
