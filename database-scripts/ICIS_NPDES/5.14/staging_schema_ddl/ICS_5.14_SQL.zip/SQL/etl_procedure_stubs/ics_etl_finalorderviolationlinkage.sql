﻿
/*************************************************************************************************
** ObjectName: ics_etl_FinalOrderViolationLinkageSubmission
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the FinalOrderViolationLinkageSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/18/2025   Windsor      Created 
**
***************************************************************************************************/
CREATE OR ALTER PROCEDURE dbo.ics_etl_FinalOrderViolationLinkageSubmission

AS

BEGIN
---------------------------- 
-- ICS_FINAL_ORDER_VIOL_LNK
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- /ICS_FINAL_ORDER_VIOL_LNK/ICS_CMPL_SCHD_VIOL
DELETE
  FROM dbo.ICS_CMPL_SCHD_VIOL
 WHERE ICS_FINAL_ORDER_VIOL_LNK_ID IN
          (SELECT ICS_FINAL_ORDER_VIOL_LNK.ICS_FINAL_ORDER_VIOL_LNK_ID
             FROM dbo.ICS_FINAL_ORDER_VIOL_LNK
          );

-- /ICS_FINAL_ORDER_VIOL_LNK/ICS_DSCH_MON_REP_PARAM_VIOL
DELETE
  FROM dbo.ICS_DSCH_MON_REP_PARAM_VIOL
 WHERE ICS_FINAL_ORDER_VIOL_LNK_ID IN
          (SELECT ICS_FINAL_ORDER_VIOL_LNK.ICS_FINAL_ORDER_VIOL_LNK_ID
             FROM dbo.ICS_FINAL_ORDER_VIOL_LNK
          );

-- /ICS_FINAL_ORDER_VIOL_LNK/ICS_DSCH_MON_REP_VIOL
DELETE
  FROM dbo.ICS_DSCH_MON_REP_VIOL
 WHERE ICS_FINAL_ORDER_VIOL_LNK_ID IN
          (SELECT ICS_FINAL_ORDER_VIOL_LNK.ICS_FINAL_ORDER_VIOL_LNK_ID
             FROM dbo.ICS_FINAL_ORDER_VIOL_LNK
          );

-- /ICS_FINAL_ORDER_VIOL_LNK/ICS_PRMT_SCHD_VIOL
DELETE
  FROM dbo.ICS_PRMT_SCHD_VIOL
 WHERE ICS_FINAL_ORDER_VIOL_LNK_ID IN
          (SELECT ICS_FINAL_ORDER_VIOL_LNK.ICS_FINAL_ORDER_VIOL_LNK_ID
             FROM dbo.ICS_FINAL_ORDER_VIOL_LNK
          );

-- /ICS_FINAL_ORDER_VIOL_LNK/ICS_SNGL_EVTS_VIOL
DELETE
  FROM dbo.ICS_SNGL_EVTS_VIOL
 WHERE ICS_FINAL_ORDER_VIOL_LNK_ID IN
          (SELECT ICS_FINAL_ORDER_VIOL_LNK.ICS_FINAL_ORDER_VIOL_LNK_ID
             FROM dbo.ICS_FINAL_ORDER_VIOL_LNK
          );

-- /ICS_FINAL_ORDER_VIOL_LNK
DELETE
  FROM dbo.ICS_FINAL_ORDER_VIOL_LNK;


-- /ICS_FINAL_ORDER_VIOL_LNK
INSERT INTO dbo.ICS_FINAL_ORDER_VIOL_LNK (
     [ICS_FINAL_ORDER_VIOL_LNK_ID]
   , [ICS_PAYLOAD_ID]
   , [SRC_SYSTM_IDENT]
   , [TRANSACTION_TYPE]
   , [TRANSACTION_TIMESTAMP]
   , [ENFRC_ACTN_IDENT]
   , [FINAL_ORDER_IDENT]
   , [KEY_HASH]
   , [DATA_HASH])
SELECT 
     null  --ICS_FINAL_ORDER_VIOL_LNK_ID, 
   , null  --ICS_PAYLOAD_ID, 
   , null  --SRC_SYSTM_IDENT, SourceSystemIdentifier
   , null  --TRANSACTION_TYPE, TransactionType
   , null  --TRANSACTION_TIMESTAMP, TransactionTimestamp
   , null  --ENFRC_ACTN_IDENT, EnforcementActionIdentifier
   , null  --FINAL_ORDER_IDENT, FinalOrderIdentifier
   , null  --KEY_HASH, 
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_FINAL_ORDER_VIOL_LNK/ICS_CMPL_SCHD_VIOL
INSERT INTO dbo.ICS_CMPL_SCHD_VIOL (
     [ICS_CMPL_SCHD_VIOL_ID]
   , [ICS_ENFRC_ACTN_VIOL_LNK_ID]
   , [ICS_FINAL_ORDER_VIOL_LNK_ID]
   , [ENFRC_ACTN_IDENT]
   , [FINAL_ORDER_IDENT]
   , [PRMT_IDENT]
   , [CMPL_SCHD_NUM]
   , [SCHD_EVT_CODE]
   , [SCHD_DATE]
   , [DATA_HASH])
SELECT 
     null  --ICS_CMPL_SCHD_VIOL_ID, 
   , null  --ICS_ENFRC_ACTN_VIOL_LNK_ID, 
   , null  --ICS_FINAL_ORDER_VIOL_LNK_ID, 
   , null  --ENFRC_ACTN_IDENT, EnforcementActionIdentifier
   , null  --FINAL_ORDER_IDENT, FinalOrderIdentifier
   , null  --PRMT_IDENT, PermitIdentifier
   , null  --CMPL_SCHD_NUM, ComplianceScheduleNumber
   , null  --SCHD_EVT_CODE, ScheduleEventCode
   , null  --SCHD_DATE, ScheduleDate
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_FINAL_ORDER_VIOL_LNK/ICS_DSCH_MON_REP_PARAM_VIOL
INSERT INTO dbo.ICS_DSCH_MON_REP_PARAM_VIOL (
     [ICS_DSCH_MON_REP_PARAM_VIOL_ID]
   , [ICS_ENFRC_ACTN_VIOL_LNK_ID]
   , [ICS_FINAL_ORDER_VIOL_LNK_ID]
   , [PRMT_IDENT]
   , [PRMT_FEATR_IDENT]
   , [LMT_SET_DESIGNATOR]
   , [MON_PERIOD_END_DATE]
   , [PARAM_CODE]
   , [MON_SITE_DESC_CODE]
   , [LMT_SEASON_NUM]
   , [DATA_HASH])
SELECT 
     null  --ICS_DSCH_MON_REP_PARAM_VIOL_ID, 
   , null  --ICS_ENFRC_ACTN_VIOL_LNK_ID, 
   , null  --ICS_FINAL_ORDER_VIOL_LNK_ID, 
   , null  --PRMT_IDENT, PermitIdentifier
   , null  --PRMT_FEATR_IDENT, PermittedFeatureIdentifier
   , null  --LMT_SET_DESIGNATOR, LimitSetDesignator
   , null  --MON_PERIOD_END_DATE, MonitoringPeriodEndDate
   , null  --PARAM_CODE, ParameterCode
   , null  --MON_SITE_DESC_CODE, MonitoringSiteDescriptionCode
   , null  --LMT_SEASON_NUM, LimitSeasonNumber
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_FINAL_ORDER_VIOL_LNK/ICS_DSCH_MON_REP_VIOL
INSERT INTO dbo.ICS_DSCH_MON_REP_VIOL (
     [ICS_DSCH_MON_REP_VIOL_ID]
   , [ICS_ENFRC_ACTN_VIOL_LNK_ID]
   , [ICS_FINAL_ORDER_VIOL_LNK_ID]
   , [PRMT_IDENT]
   , [PRMT_FEATR_IDENT]
   , [LMT_SET_DESIGNATOR]
   , [MON_PERIOD_END_DATE]
   , [DATA_HASH])
SELECT 
     null  --ICS_DSCH_MON_REP_VIOL_ID, 
   , null  --ICS_ENFRC_ACTN_VIOL_LNK_ID, 
   , null  --ICS_FINAL_ORDER_VIOL_LNK_ID, 
   , null  --PRMT_IDENT, PermitIdentifier
   , null  --PRMT_FEATR_IDENT, PermittedFeatureIdentifier
   , null  --LMT_SET_DESIGNATOR, LimitSetDesignator
   , null  --MON_PERIOD_END_DATE, MonitoringPeriodEndDate
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_FINAL_ORDER_VIOL_LNK/ICS_PRMT_SCHD_VIOL
INSERT INTO dbo.ICS_PRMT_SCHD_VIOL (
     [ICS_PRMT_SCHD_VIOL_ID]
   , [ICS_ENFRC_ACTN_VIOL_LNK_ID]
   , [ICS_FINAL_ORDER_VIOL_LNK_ID]
   , [PRMT_IDENT]
   , [NARR_COND_NUM]
   , [SCHD_EVT_CODE]
   , [SCHD_DATE]
   , [DATA_HASH])
SELECT 
     null  --ICS_PRMT_SCHD_VIOL_ID, 
   , null  --ICS_ENFRC_ACTN_VIOL_LNK_ID, 
   , null  --ICS_FINAL_ORDER_VIOL_LNK_ID, 
   , null  --PRMT_IDENT, PermitIdentifier
   , null  --NARR_COND_NUM, NarrativeConditionNumber
   , null  --SCHD_EVT_CODE, ScheduleEventCode
   , null  --SCHD_DATE, ScheduleDate
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_FINAL_ORDER_VIOL_LNK/ICS_SNGL_EVTS_VIOL
INSERT INTO dbo.ICS_SNGL_EVTS_VIOL (
     [ICS_SNGL_EVTS_VIOL_ID]
   , [ICS_ENFRC_ACTN_VIOL_LNK_ID]
   , [ICS_FINAL_ORDER_VIOL_LNK_ID]
   , [PRMT_IDENT]
   , [SNGL_EVT_VIOL_CODE]
   , [SNGL_EVT_VIOL_DATE]
   , [DATA_HASH])
SELECT 
     null  --ICS_SNGL_EVTS_VIOL_ID, 
   , null  --ICS_ENFRC_ACTN_VIOL_LNK_ID, 
   , null  --ICS_FINAL_ORDER_VIOL_LNK_ID, 
   , null  --PRMT_IDENT, PermitIdentifier
   , null  --SNGL_EVT_VIOL_CODE, SingleEventViolationCode
   , null  --SNGL_EVT_VIOL_DATE, SingleEventViolationDate
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

END;
