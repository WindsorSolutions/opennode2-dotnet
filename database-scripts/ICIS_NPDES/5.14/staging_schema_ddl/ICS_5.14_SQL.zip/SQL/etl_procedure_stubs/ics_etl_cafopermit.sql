﻿
/*************************************************************************************************
** ObjectName: ics_etl_CAFOPermit
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the CAFOPermitSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/18/2025   Windsor      Created 
**
***************************************************************************************************/
CREATE OR ALTER PROCEDURE dbo.ics_etl_CAFOPermit

AS

BEGIN
---------------------------- 
-- ICS_CAFO_PRMT
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- /ICS_CAFO_PRMT/ICS_ADDR/ICS_TELEPH
DELETE
  FROM dbo.ICS_TELEPH
 WHERE ICS_ADDR_ID IN
          (SELECT ICS_ADDR.ICS_ADDR_ID
             FROM dbo.ICS_CAFO_PRMT
                  JOIN dbo.ICS_ADDR ON ICS_ADDR.ICS_CAFO_PRMT_id = ICS_CAFO_PRMT.ICS_CAFO_PRMT_id
          );

-- /ICS_CAFO_PRMT/ICS_CONTACT/ICS_TELEPH
DELETE
  FROM dbo.ICS_TELEPH
 WHERE ICS_CONTACT_ID IN
          (SELECT ICS_CONTACT.ICS_CONTACT_ID
             FROM dbo.ICS_CAFO_PRMT
                  JOIN dbo.ICS_CONTACT ON ICS_CONTACT.ICS_CAFO_PRMT_id = ICS_CAFO_PRMT.ICS_CAFO_PRMT_id
          );

-- /ICS_CAFO_PRMT/ICS_ADDR
DELETE
  FROM dbo.ICS_ADDR
 WHERE ICS_CAFO_PRMT_ID IN
          (SELECT ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID
             FROM dbo.ICS_CAFO_PRMT
          );

-- /ICS_CAFO_PRMT/ICS_ANML_TYPE
DELETE
  FROM dbo.ICS_ANML_TYPE
 WHERE ICS_CAFO_PRMT_ID IN
          (SELECT ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID
             FROM dbo.ICS_CAFO_PRMT
          );

-- /ICS_CAFO_PRMT/ICS_CAFOMLPW_TTL_AMOUNTS
DELETE
  FROM dbo.ICS_CAFOMLPW_TTL_AMOUNTS
 WHERE ICS_CAFO_PRMT_ID IN
          (SELECT ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID
             FROM dbo.ICS_CAFO_PRMT
          );

-- /ICS_CAFO_PRMT/ICS_CONTACT
DELETE
  FROM dbo.ICS_CONTACT
 WHERE ICS_CAFO_PRMT_ID IN
          (SELECT ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID
             FROM dbo.ICS_CAFO_PRMT
          );

-- /ICS_CAFO_PRMT/ICS_CONTAINMENT
DELETE
  FROM dbo.ICS_CONTAINMENT
 WHERE ICS_CAFO_PRMT_ID IN
          (SELECT ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID
             FROM dbo.ICS_CAFO_PRMT
          );

-- /ICS_CAFO_PRMT/ICS_LAND_APPL_BMP
DELETE
  FROM dbo.ICS_LAND_APPL_BMP
 WHERE ICS_CAFO_PRMT_ID IN
          (SELECT ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID
             FROM dbo.ICS_CAFO_PRMT
          );

-- /ICS_CAFO_PRMT/ICS_MNUR_LTTR_PRCSS_WW_STOR
DELETE
  FROM dbo.ICS_MNUR_LTTR_PRCSS_WW_STOR
 WHERE ICS_CAFO_PRMT_ID IN
          (SELECT ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID
             FROM dbo.ICS_CAFO_PRMT
          );

-- /ICS_CAFO_PRMT
DELETE
  FROM dbo.ICS_CAFO_PRMT;


-- /ICS_CAFO_PRMT
INSERT INTO dbo.ICS_CAFO_PRMT (
     [ICS_CAFO_PRMT_ID]
   , [ICS_PAYLOAD_ID]
   , [SRC_SYSTM_IDENT]
   , [TRANSACTION_TYPE]
   , [TRANSACTION_TIMESTAMP]
   , [PRMT_IDENT]
   , [CAFO_CLASS_CODE]
   , [IS_ANML_FAC_TYPE_CAFO_IND]
   , [CAFO_DESGN_DATE]
   , [CAFO_DESGN_REASON_TXT]
   , [NUM_ACRES_CONTRB_DRAIN]
   , [APPL_MEAS_AVAIL_LAND_NUM]
   , [SOLID_MNUR_LTTR_GNRTD_AMT]
   , [LIQUID_MNUR_WW_GNRTD_AMT]
   , [SOLID_MNUR_LTTR_TRANS_AMT]
   , [LIQUID_MNUR_WW_TRANS_AMT]
   , [NMP_DVLPD_CERT_PLNR_APRVD_IND]
   , [NMP_DVLPD_DATE]
   , [NMP_LAST_UPDATED_DATE]
   , [ENVR_MGMT_SYSTM_IND]
   , [EMS_DVLPD_DATE]
   , [EMS_LAST_UPDATED_DATE]
   , [LVSTCK_MAX_CPCTY_NUM]
   , [LVSTCK_CPCTY_DTRMN_BS_UPON_NUM]
   , [AUTH_LVSTCK_CPCTY_NUM]
   , [LEGAL_DESC_TXT]
   , [KEY_HASH]
   , [DATA_HASH])
SELECT 
     null  --ICS_CAFO_PRMT_ID, 
   , null  --ICS_PAYLOAD_ID, 
   , null  --SRC_SYSTM_IDENT, SourceSystemIdentifier
   , null  --TRANSACTION_TYPE, TransactionType
   , null  --TRANSACTION_TIMESTAMP, TransactionTimestamp
   , null  --PRMT_IDENT, PermitIdentifier
   , null  --CAFO_CLASS_CODE, CAFOClassificationCode
   , null  --IS_ANML_FAC_TYPE_CAFO_IND, IsAnimalFacilityTypeCAFOIndicator
   , null  --CAFO_DESGN_DATE, CAFODesignationDate
   , null  --CAFO_DESGN_REASON_TXT, CAFODesignationReasonText
   , null  --NUM_ACRES_CONTRB_DRAIN, NumberAcresContributingDrainage
   , null  --APPL_MEAS_AVAIL_LAND_NUM, ApplicationMeasureAvailableLandNumber
   , null  --SOLID_MNUR_LTTR_GNRTD_AMT, SolidManureLitterGeneratedAmount
   , null  --LIQUID_MNUR_WW_GNRTD_AMT, LiquidManureWastewaterGeneratedAmount
   , null  --SOLID_MNUR_LTTR_TRANS_AMT, SolidManureLitterTransferAmount
   , null  --LIQUID_MNUR_WW_TRANS_AMT, LiquidManureWastewaterTransferAmount
   , null  --NMP_DVLPD_CERT_PLNR_APRVD_IND, NMPDevelopedCertifiedPlannerApprovedIndicator
   , null  --NMP_DVLPD_DATE, NMPDevelopedDate
   , null  --NMP_LAST_UPDATED_DATE, NMPLastUpdatedDate
   , null  --ENVR_MGMT_SYSTM_IND, EnvironmentalManagementSystemIndicator
   , null  --EMS_DVLPD_DATE, EMSDevelopedDate
   , null  --EMS_LAST_UPDATED_DATE, EMSLastUpdatedDate
   , null  --LVSTCK_MAX_CPCTY_NUM, LivestockMaximumCapacityNumber
   , null  --LVSTCK_CPCTY_DTRMN_BS_UPON_NUM, LivestockCapacityDeterminationBasedUponNumber
   , null  --AUTH_LVSTCK_CPCTY_NUM, AuthorizedLivestockCapacityNumber
   , null  --LEGAL_DESC_TXT, LegalDescriptionText
   , null  --KEY_HASH, 
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CAFO_PRMT/ICS_ADDR
INSERT INTO dbo.ICS_ADDR (
     [ICS_ADDR_ID]
   , [ICS_FAC_ID]
   , [ICS_BASIC_PRMT_ID]
   , [ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID]
   , [ICS_CAFO_PRMT_ID]
   , [ICS_GNRL_PRMT_ID]
   , [ICS_PRMT_FEATR_ID]
   , [ICS_SW_CNST_PRMT_ID]
   , [ICS_SW_INDST_PRMT_ID]
   , [ICS_UNPRMT_FAC_ID]
   , [AFFIL_TYPE_TXT]
   , [ORG_FRML_NAME]
   , [ORG_DUNS_NUM]
   , [MAILING_ADDR_TXT]
   , [SUPPL_ADDR_TXT]
   , [MAILING_ADDR_CITY_NAME]
   , [MAILING_ADDR_ST_CODE]
   , [MAILING_ADDR_ZIP_CODE]
   , [COUNTY_NAME]
   , [MAILING_ADDR_COUNTRY_CODE]
   , [DIVISION_NAME]
   , [LOC_PROVINCE]
   , [ELEC_ADDR_TXT]
   , [START_DATE_OF_ADDR_ASSC]
   , [END_DATE_OF_ADDR_ASSC]
   , [DATA_HASH])
SELECT 
     null  --ICS_ADDR_ID, 
   , null  --ICS_FAC_ID, 
   , null  --ICS_BASIC_PRMT_ID, 
   , null  --ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID, 
   , null  --ICS_CAFO_PRMT_ID, 
   , null  --ICS_GNRL_PRMT_ID, 
   , null  --ICS_PRMT_FEATR_ID, 
   , null  --ICS_SW_CNST_PRMT_ID, 
   , null  --ICS_SW_INDST_PRMT_ID, 
   , null  --ICS_UNPRMT_FAC_ID, 
   , null  --AFFIL_TYPE_TXT, AffiliationTypeText
   , null  --ORG_FRML_NAME, OrganizationFormalName
   , null  --ORG_DUNS_NUM, OrganizationDUNSNumber
   , null  --MAILING_ADDR_TXT, MailingAddressText
   , null  --SUPPL_ADDR_TXT, SupplementalAddressText
   , null  --MAILING_ADDR_CITY_NAME, MailingAddressCityName
   , null  --MAILING_ADDR_ST_CODE, MailingAddressStateCode
   , null  --MAILING_ADDR_ZIP_CODE, MailingAddressZipCode
   , null  --COUNTY_NAME, CountyName
   , null  --MAILING_ADDR_COUNTRY_CODE, MailingAddressCountryCode
   , null  --DIVISION_NAME, DivisionName
   , null  --LOC_PROVINCE, LocationProvince
   , null  --ELEC_ADDR_TXT, ElectronicAddressText
   , null  --START_DATE_OF_ADDR_ASSC, StartDateOfAddressAssociation
   , null  --END_DATE_OF_ADDR_ASSC, EndDateOfAddressAssociation
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CAFO_PRMT/ICS_ADDR/ICS_TELEPH
INSERT INTO dbo.ICS_TELEPH (
     [ICS_TELEPH_ID]
   , [ICS_CONTACT_ID]
   , [ICS_ADDR_ID]
   , [ICS_EFFLU_TRADE_PRTNER_ADDR_ID]
   , [TELEPH_NUM_TYPE_CODE]
   , [TELEPH_NUM]
   , [TELEPH_EXT_NUM]
   , [DATA_HASH])
SELECT 
     null  --ICS_TELEPH_ID, 
   , null  --ICS_CONTACT_ID, 
   , null  --ICS_ADDR_ID, 
   , null  --ICS_EFFLU_TRADE_PRTNER_ADDR_ID, 
   , null  --TELEPH_NUM_TYPE_CODE, TelephoneNumberTypeCode
   , null  --TELEPH_NUM, TelephoneNumber
   , null  --TELEPH_EXT_NUM, TelephoneExtensionNumber
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CAFO_PRMT/ICS_ANML_TYPE
INSERT INTO dbo.ICS_ANML_TYPE (
     [ICS_ANML_TYPE_ID]
   , [ICS_CAFO_ANNUL_PROG_REP_ID]
   , [ICS_CAFO_PRMT_ID]
   , [ICS_CAFO_INSP_ID]
   , [ANML_TYPE_CODE]
   , [OTHR_ANML_TYPE_NAME]
   , [TTL_NUM_EACH_LVSTCK]
   , [OPEN_CONFINEMNT_CNT]
   , [HOUSD_UNDR_ROOF_CONFINEMNT_CNT]
   , [LIQUID_MNUR_HANDLING_SYSTM]
   , [DATA_HASH])
SELECT 
     null  --ICS_ANML_TYPE_ID, 
   , null  --ICS_CAFO_ANNUL_PROG_REP_ID, 
   , null  --ICS_CAFO_PRMT_ID, 
   , null  --ICS_CAFO_INSP_ID, 
   , null  --ANML_TYPE_CODE, AnimalTypeCode
   , null  --OTHR_ANML_TYPE_NAME, OtherAnimalTypeName
   , null  --TTL_NUM_EACH_LVSTCK, TotalNumbersEachLivestock
   , null  --OPEN_CONFINEMNT_CNT, OpenConfinementCount
   , null  --HOUSD_UNDR_ROOF_CONFINEMNT_CNT, HousedUnderRoofConfinementCount
   , null  --LIQUID_MNUR_HANDLING_SYSTM, LiquidManureHandlingSystem
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CAFO_PRMT/ICS_CAFOMLPW_TTL_AMOUNTS
INSERT INTO dbo.ICS_CAFOMLPW_TTL_AMOUNTS (
     [ICS_CAFOMLPW_TTL_AMOUNTS_ID]
   , [ICS_CAFO_ANNUL_PROG_REP_ID]
   , [ICS_CAFO_PRMT_ID]
   , [CAFOMLPW_CODE]
   , [CAFOMLPW_AMT_GNRTD]
   , [CAFOMLPW_AMT_TRANSFERRED]
   , [CAFOMLPW_UNIT]
   , [DATA_HASH])
SELECT 
     null  --ICS_CAFOMLPW_TTL_AMOUNTS_ID, 
   , null  --ICS_CAFO_ANNUL_PROG_REP_ID, 
   , null  --ICS_CAFO_PRMT_ID, 
   , null  --CAFOMLPW_CODE, CAFOMLPWCode
   , null  --CAFOMLPW_AMT_GNRTD, CAFOMLPWAmountGenerated
   , null  --CAFOMLPW_AMT_TRANSFERRED, CAFOMLPWAmountTransferred
   , null  --CAFOMLPW_UNIT, CAFOMLPWUnit
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CAFO_PRMT/ICS_CONTACT
INSERT INTO dbo.ICS_CONTACT (
     [ICS_CONTACT_ID]
   , [ICS_FAC_ID]
   , [ICS_BASIC_PRMT_ID]
   , [ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID]
   , [ICS_CAFO_PRMT_ID]
   , [ICS_CMPL_MON_ID]
   , [ICS_GNRL_PRMT_ID]
   , [ICS_MASTER_GNRL_PRMT_ID]
   , [ICS_PRMT_FEATR_ID]
   , [ICS_PRETR_PRMT_ID]
   , [ICS_SW_CNST_PRMT_ID]
   , [ICS_SW_INDST_PRMT_ID]
   , [ICS_UNPRMT_FAC_ID]
   , [AFFIL_TYPE_TXT]
   , [FIRST_NAME]
   , [MIDDLE_NAME]
   , [LAST_NAME]
   , [INDVL_TITLE_TXT]
   , [ORG_FRML_NAME]
   , [ST_CODE]
   , [RGN_CODE]
   , [ELEC_ADDR_TXT]
   , [START_DATE_OF_CONTACT_ASSC]
   , [END_DATE_OF_CONTACT_ASSC]
   , [DATA_HASH])
SELECT 
     null  --ICS_CONTACT_ID, 
   , null  --ICS_FAC_ID, 
   , null  --ICS_BASIC_PRMT_ID, 
   , null  --ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID, 
   , null  --ICS_CAFO_PRMT_ID, 
   , null  --ICS_CMPL_MON_ID, 
   , null  --ICS_GNRL_PRMT_ID, 
   , null  --ICS_MASTER_GNRL_PRMT_ID, 
   , null  --ICS_PRMT_FEATR_ID, 
   , null  --ICS_PRETR_PRMT_ID, 
   , null  --ICS_SW_CNST_PRMT_ID, 
   , null  --ICS_SW_INDST_PRMT_ID, 
   , null  --ICS_UNPRMT_FAC_ID, 
   , null  --AFFIL_TYPE_TXT, AffiliationTypeText
   , null  --FIRST_NAME, FirstName
   , null  --MIDDLE_NAME, MiddleName
   , null  --LAST_NAME, LastName
   , null  --INDVL_TITLE_TXT, IndividualTitleText
   , null  --ORG_FRML_NAME, OrganizationFormalName
   , null  --ST_CODE, StateCode
   , null  --RGN_CODE, RegionCode
   , null  --ELEC_ADDR_TXT, ElectronicAddressText
   , null  --START_DATE_OF_CONTACT_ASSC, StartDateOfContactAssociation
   , null  --END_DATE_OF_CONTACT_ASSC, EndDateOfContactAssociation
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CAFO_PRMT/ICS_CONTACT/ICS_TELEPH
INSERT INTO dbo.ICS_TELEPH (
     [ICS_TELEPH_ID]
   , [ICS_CONTACT_ID]
   , [ICS_ADDR_ID]
   , [ICS_EFFLU_TRADE_PRTNER_ADDR_ID]
   , [TELEPH_NUM_TYPE_CODE]
   , [TELEPH_NUM]
   , [TELEPH_EXT_NUM]
   , [DATA_HASH])
SELECT 
     null  --ICS_TELEPH_ID, 
   , null  --ICS_CONTACT_ID, 
   , null  --ICS_ADDR_ID, 
   , null  --ICS_EFFLU_TRADE_PRTNER_ADDR_ID, 
   , null  --TELEPH_NUM_TYPE_CODE, TelephoneNumberTypeCode
   , null  --TELEPH_NUM, TelephoneNumber
   , null  --TELEPH_EXT_NUM, TelephoneExtensionNumber
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CAFO_PRMT/ICS_CONTAINMENT
INSERT INTO dbo.ICS_CONTAINMENT (
     [ICS_CONTAINMENT_ID]
   , [ICS_CAFO_PRMT_ID]
   , [ICS_CAFO_INSP_ID]
   , [CONTAINMENT_TYPE_CODE]
   , [OTHR_CONTAINMENT_TYPE_NAME]
   , [CONTAINMENT_CPCTY_NUM]
   , [DATA_HASH])
SELECT 
     null  --ICS_CONTAINMENT_ID, 
   , null  --ICS_CAFO_PRMT_ID, 
   , null  --ICS_CAFO_INSP_ID, 
   , null  --CONTAINMENT_TYPE_CODE, ContainmentTypeCode
   , null  --OTHR_CONTAINMENT_TYPE_NAME, OtherContainmentTypeName
   , null  --CONTAINMENT_CPCTY_NUM, ContainmentCapacityNumber
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CAFO_PRMT/ICS_LAND_APPL_BMP
INSERT INTO dbo.ICS_LAND_APPL_BMP (
     [ICS_LAND_APPL_BMP_ID]
   , [ICS_CAFO_PRMT_ID]
   , [ICS_CAFO_INSP_ID]
   , [LAND_APPL_BMP_TYPE_CODE]
   , [OTHR_LAND_APPL_BMP_TYPE_NAME]
   , [DATA_HASH])
SELECT 
     null  --ICS_LAND_APPL_BMP_ID, 
   , null  --ICS_CAFO_PRMT_ID, 
   , null  --ICS_CAFO_INSP_ID, 
   , null  --LAND_APPL_BMP_TYPE_CODE, LandApplicationBMPTypeCode
   , null  --OTHR_LAND_APPL_BMP_TYPE_NAME, OtherLandApplicationBMPTypeName
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CAFO_PRMT/ICS_MNUR_LTTR_PRCSS_WW_STOR
INSERT INTO dbo.ICS_MNUR_LTTR_PRCSS_WW_STOR (
     [ICS_MNUR_LTTR_PRCSS_WW_STOR_ID]
   , [ICS_CAFO_PRMT_ID]
   , [ICS_CAFO_INSP_ID]
   , [MNUR_LTTR_PRCSS_WW_STOR_TYPE]
   , [OTHR_STOR_TYPE_NAME]
   , [STOR_TTL_CPCTY_MEAS]
   , [DAYS_OF_STOR]
   , [CAFOMLPW_UNIT]
   , [CAFOMLPW_STOR_WITHIN_DSGN_CPCTY]
   , [CAFOMLPW_STOR_WITHIN_DSGN_CPCTY_TXT]
   , [DATA_HASH])
SELECT 
     null  --ICS_MNUR_LTTR_PRCSS_WW_STOR_ID, 
   , null  --ICS_CAFO_PRMT_ID, 
   , null  --ICS_CAFO_INSP_ID, 
   , null  --MNUR_LTTR_PRCSS_WW_STOR_TYPE, ManureLitterProcessedWastewaterStorageType
   , null  --OTHR_STOR_TYPE_NAME, OtherStorageTypeName
   , null  --STOR_TTL_CPCTY_MEAS, StorageTotalCapacityMeasure
   , null  --DAYS_OF_STOR, DaysOfStorage
   , null  --CAFOMLPW_UNIT, CAFOMLPWUnit
   , null  --CAFOMLPW_STOR_WITHIN_DSGN_CPCTY, CAFOMLPWStorageWithinDesignCapacity
   , null  --CAFOMLPW_STOR_WITHIN_DSGN_CPCTY_TXT, CAFOMLPWStorageWithinDesignCapacityText
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

END;
