﻿
/*************************************************************************************************
** ObjectName: ics_etl_POTWPermitSubmission
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the POTWPermitSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/18/2025   Windsor      Created 
**
***************************************************************************************************/
CREATE OR ALTER PROCEDURE dbo.ics_etl_POTWPermitSubmission

AS

BEGIN
---------------------------- 
-- ICS_POTW_PRMT
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- /ICS_POTW_PRMT/ICS_SATL_COLL_SYSTM
DELETE
  FROM dbo.ICS_SATL_COLL_SYSTM
 WHERE ICS_POTW_PRMT_ID IN
          (SELECT ICS_POTW_PRMT.ICS_POTW_PRMT_ID
             FROM dbo.ICS_POTW_PRMT
          );

-- /ICS_POTW_PRMT
DELETE
  FROM dbo.ICS_POTW_PRMT;


-- /ICS_POTW_PRMT
INSERT INTO dbo.ICS_POTW_PRMT (
     [ICS_POTW_PRMT_ID]
   , [ICS_PAYLOAD_ID]
   , [SRC_SYSTM_IDENT]
   , [TRANSACTION_TYPE]
   , [TRANSACTION_TIMESTAMP]
   , [PRMT_IDENT]
   , [SSCS_POPL_SERVED_NUM]
   , [COMBINED_SSCS_SYSTM_LENGTH]
   , [KEY_HASH]
   , [DATA_HASH])
SELECT 
     null  --ICS_POTW_PRMT_ID, 
   , null  --ICS_PAYLOAD_ID, 
   , null  --SRC_SYSTM_IDENT, SourceSystemIdentifier
   , null  --TRANSACTION_TYPE, TransactionType
   , null  --TRANSACTION_TIMESTAMP, TransactionTimestamp
   , null  --PRMT_IDENT, PermitIdentifier
   , null  --SSCS_POPL_SERVED_NUM, SSCSPopulationServedNumber
   , null  --COMBINED_SSCS_SYSTM_LENGTH, CombinedSSCSSystemLength
   , null  --KEY_HASH, 
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_POTW_PRMT/ICS_SATL_COLL_SYSTM
INSERT INTO dbo.ICS_SATL_COLL_SYSTM (
     [ICS_SATL_COLL_SYSTM_ID]
   , [ICS_POTW_PRMT_ID]
   , [SATL_COLL_SYSTM_IDENT]
   , [SATL_COLL_SYSTM_NAME]
   , [DATA_HASH])
SELECT 
     null  --ICS_SATL_COLL_SYSTM_ID, 
   , null  --ICS_POTW_PRMT_ID, 
   , null  --SATL_COLL_SYSTM_IDENT, SatelliteCollectionSystemIdentifier
   , null  --SATL_COLL_SYSTM_NAME, SatelliteCollectionSystemName
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

END;
