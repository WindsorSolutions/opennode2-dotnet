﻿
/*************************************************************************************************
** ObjectName: ics_etl_CopyMGPMS4Requirement
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the CopyMGPMS4RequirementSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/18/2025   Windsor      Created 
**
***************************************************************************************************/
CREATE OR ALTER PROCEDURE dbo.ics_etl_CopyMGPMS4Requirement

AS

BEGIN
---------------------------- 
-- ICS_COPY_MGPMS_4_REQ
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- /ICS_COPY_MGPMS_4_REQ/ICS_GNRL_PRMT_COVERAGE_MS_4_REQ/ICS_MS_4_REGULATED_ENTITY_IDENT
DELETE
  FROM dbo.ICS_MS_4_REGULATED_ENTITY_IDENT
 WHERE ICS_GNRL_PRMT_COVERAGE_MS_4_REQ_ID IN
          (SELECT ICS_GNRL_PRMT_COVERAGE_MS_4_REQ.ICS_GNRL_PRMT_COVERAGE_MS_4_REQ_ID
             FROM dbo.ICS_COPY_MGPMS_4_REQ
                  JOIN dbo.ICS_GNRL_PRMT_COVERAGE_MS_4_REQ ON ICS_GNRL_PRMT_COVERAGE_MS_4_REQ.ICS_COPY_MGPMS_4_REQ_id = ICS_COPY_MGPMS_4_REQ.ICS_COPY_MGPMS_4_REQ_id
          );

-- /ICS_COPY_MGPMS_4_REQ/ICS_GNRL_PRMT_COVERAGE_MS_4_REQ
DELETE
  FROM dbo.ICS_GNRL_PRMT_COVERAGE_MS_4_REQ
 WHERE ICS_COPY_MGPMS_4_REQ_ID IN
          (SELECT ICS_COPY_MGPMS_4_REQ.ICS_COPY_MGPMS_4_REQ_ID
             FROM dbo.ICS_COPY_MGPMS_4_REQ
          );

-- /ICS_COPY_MGPMS_4_REQ/ICS_MS_4_ACTY_IDENT
DELETE
  FROM dbo.ICS_MS_4_ACTY_IDENT
 WHERE ICS_COPY_MGPMS_4_REQ_ID IN
          (SELECT ICS_COPY_MGPMS_4_REQ.ICS_COPY_MGPMS_4_REQ_ID
             FROM dbo.ICS_COPY_MGPMS_4_REQ
          );

-- /ICS_COPY_MGPMS_4_REQ
DELETE
  FROM dbo.ICS_COPY_MGPMS_4_REQ;


-- /ICS_COPY_MGPMS_4_REQ
INSERT INTO dbo.ICS_COPY_MGPMS_4_REQ (
     [ICS_COPY_MGPMS_4_REQ_ID]
   , [ICS_PAYLOAD_ID]
   , [SRC_SYSTM_IDENT]
   , [PRMT_IDENT]
   , [TRANSACTION_TYPE]
   , [TRANSACTION_TIMESTAMP]
   , [KEY_HASH]
   , [DATA_HASH])
SELECT 
     null  --ICS_COPY_MGPMS_4_REQ_ID, 
   , null  --ICS_PAYLOAD_ID, 
   , null  --SRC_SYSTM_IDENT, SourceSystemIdentifier
   , null  --PRMT_IDENT, PermitIdentifier
   , null  --TRANSACTION_TYPE, TransactionType
   , null  --TRANSACTION_TIMESTAMP, TransactionTimestamp
   , null  --KEY_HASH, 
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_COPY_MGPMS_4_REQ/ICS_GNRL_PRMT_COVERAGE_MS_4_REQ
INSERT INTO dbo.ICS_GNRL_PRMT_COVERAGE_MS_4_REQ (
     [ICS_GNRL_PRMT_COVERAGE_MS_4_REQ_ID]
   , [ICS_COPY_MGPMS_4_REQ_ID]
   , [PRMT_IDENT]
   , [DATA_HASH])
SELECT 
     null  --ICS_GNRL_PRMT_COVERAGE_MS_4_REQ_ID, 
   , null  --ICS_COPY_MGPMS_4_REQ_ID, 
   , null  --PRMT_IDENT, PermitIdentifier
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_COPY_MGPMS_4_REQ/ICS_GNRL_PRMT_COVERAGE_MS_4_REQ/ICS_MS_4_REGULATED_ENTITY_IDENT
INSERT INTO dbo.ICS_MS_4_REGULATED_ENTITY_IDENT (
     [ICS_MS_4_REGULATED_ENTITY_IDENT_ID]
   , [ICS_GNRL_PRMT_COVERAGE_MS_4_REQ_ID]
   , [ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY_ID]
   , [ICS_MS_4_PROG_REP_ANALYSIS_ID]
   , [ICS_MS_4_PBLC_EDUCATION_REQS_ID]
   , [ICS_MS_4_PBLC_INVOLVEMENT_REQS_ID]
   , [ICS_MS_4_ILLICIT_DETECT_PROCEDURES_ID]
   , [ICS_MS_4_CNST_SW_PROCEDURES_ID]
   , [ICS_MS_4_POST_CNST_SW_PROCEDURES_ID]
   , [ICS_MS_4_POLLUTION_PREVENTION_REQS_ID]
   , [ICS_MS_4_INDST_SW_PROCEDURES_ID]
   , [ICS_MS_4_OTHR_APPL_REQS_ID]
   , [MS_4_REGULATED_ENTITY_IDENT]
   , [DATA_HASH])
SELECT 
     null  --ICS_MS_4_REGULATED_ENTITY_IDENT_ID, 
   , null  --ICS_GNRL_PRMT_COVERAGE_MS_4_REQ_ID, 
   , null  --ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY_ID, 
   , null  --ICS_MS_4_PROG_REP_ANALYSIS_ID, 
   , null  --ICS_MS_4_PBLC_EDUCATION_REQS_ID, 
   , null  --ICS_MS_4_PBLC_INVOLVEMENT_REQS_ID, 
   , null  --ICS_MS_4_ILLICIT_DETECT_PROCEDURES_ID, 
   , null  --ICS_MS_4_CNST_SW_PROCEDURES_ID, 
   , null  --ICS_MS_4_POST_CNST_SW_PROCEDURES_ID, 
   , null  --ICS_MS_4_POLLUTION_PREVENTION_REQS_ID, 
   , null  --ICS_MS_4_INDST_SW_PROCEDURES_ID, 
   , null  --ICS_MS_4_OTHR_APPL_REQS_ID, 
   , null  --MS_4_REGULATED_ENTITY_IDENT, MS4RegulatedEntityIdentifier
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_COPY_MGPMS_4_REQ/ICS_MS_4_ACTY_IDENT
INSERT INTO dbo.ICS_MS_4_ACTY_IDENT (
     [ICS_MS_4_ACTY_IDENT_ID]
   , [ICS_COPY_MGPMS_4_REQ_ID]
   , [MS_4_ACTY_IDENT]
   , [DATA_HASH])
SELECT 
     null  --ICS_MS_4_ACTY_IDENT_ID, 
   , null  --ICS_COPY_MGPMS_4_REQ_ID, 
   , null  --MS_4_ACTY_IDENT, MS4ActivityIdentifier
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

END;
