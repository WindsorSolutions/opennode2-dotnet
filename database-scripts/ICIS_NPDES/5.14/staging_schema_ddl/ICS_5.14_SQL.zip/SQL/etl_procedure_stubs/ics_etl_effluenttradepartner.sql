﻿
/*************************************************************************************************
** ObjectName: ics_etl_EffluentTradePartnerSubmission
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the EffluentTradePartnerSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/18/2025   Windsor      Created 
**
***************************************************************************************************/
CREATE OR ALTER PROCEDURE dbo.ics_etl_EffluentTradePartnerSubmission

AS

BEGIN
---------------------------- 
-- ICS_EFFLU_TRADE_PRTNER
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- /ICS_EFFLU_TRADE_PRTNER/ICS_EFFLU_TRADE_PRTNER_ADDR/ICS_TELEPH
DELETE
  FROM dbo.ICS_TELEPH
 WHERE ICS_EFFLU_TRADE_PRTNER_ADDR_ID IN
          (SELECT ICS_EFFLU_TRADE_PRTNER_ADDR.ICS_EFFLU_TRADE_PRTNER_ADDR_ID
             FROM dbo.ICS_EFFLU_TRADE_PRTNER
                  JOIN dbo.ICS_EFFLU_TRADE_PRTNER_ADDR ON ICS_EFFLU_TRADE_PRTNER_ADDR.ICS_EFFLU_TRADE_PRTNER_id = ICS_EFFLU_TRADE_PRTNER.ICS_EFFLU_TRADE_PRTNER_id
          );

-- /ICS_EFFLU_TRADE_PRTNER/ICS_EFFLU_TRADE_PRTNER_ADDR
DELETE
  FROM dbo.ICS_EFFLU_TRADE_PRTNER_ADDR
 WHERE ICS_EFFLU_TRADE_PRTNER_ID IN
          (SELECT ICS_EFFLU_TRADE_PRTNER.ICS_EFFLU_TRADE_PRTNER_ID
             FROM dbo.ICS_EFFLU_TRADE_PRTNER
          );

-- /ICS_EFFLU_TRADE_PRTNER
DELETE
  FROM dbo.ICS_EFFLU_TRADE_PRTNER;


-- /ICS_EFFLU_TRADE_PRTNER
INSERT INTO dbo.ICS_EFFLU_TRADE_PRTNER (
     [ICS_EFFLU_TRADE_PRTNER_ID]
   , [ICS_PAYLOAD_ID]
   , [SRC_SYSTM_IDENT]
   , [TRANSACTION_TYPE]
   , [TRANSACTION_TIMESTAMP]
   , [PRMT_IDENT]
   , [PRMT_FEATR_IDENT]
   , [LMT_SET_DESIGNATOR]
   , [PARAM_CODE]
   , [MON_SITE_DESC_CODE]
   , [LMT_SEASON_NUM]
   , [LMT_START_DATE]
   , [LMT_END_DATE]
   , [LMT_MOD_EFFECTIVE_DATE]
   , [TRADE_ID]
   , [TRADE_PRTNER_NPDESID]
   , [TRADE_PRTNER_OTHR_ID]
   , [TRADE_PRTNER_TYPE]
   , [TRADE_PRTNER_START_DATE]
   , [TRADE_PRTNER_END_DATE]
   , [KEY_HASH]
   , [DATA_HASH])
SELECT 
     null  --ICS_EFFLU_TRADE_PRTNER_ID, 
   , null  --ICS_PAYLOAD_ID, 
   , null  --SRC_SYSTM_IDENT, SourceSystemIdentifier
   , null  --TRANSACTION_TYPE, TransactionType
   , null  --TRANSACTION_TIMESTAMP, TransactionTimestamp
   , null  --PRMT_IDENT, PermitIdentifier
   , null  --PRMT_FEATR_IDENT, PermittedFeatureIdentifier
   , null  --LMT_SET_DESIGNATOR, LimitSetDesignator
   , null  --PARAM_CODE, ParameterCode
   , null  --MON_SITE_DESC_CODE, MonitoringSiteDescriptionCode
   , null  --LMT_SEASON_NUM, LimitSeasonNumber
   , null  --LMT_START_DATE, LimitStartDate
   , null  --LMT_END_DATE, LimitEndDate
   , null  --LMT_MOD_EFFECTIVE_DATE, LimitModificationEffectiveDate
   , null  --TRADE_ID, TradeID
   , null  --TRADE_PRTNER_NPDESID, TradePartnerNPDESID
   , null  --TRADE_PRTNER_OTHR_ID, TradePartnerOtherID
   , null  --TRADE_PRTNER_TYPE, TradePartnerType
   , null  --TRADE_PRTNER_START_DATE, TradePartnerStartDate
   , null  --TRADE_PRTNER_END_DATE, TradePartnerEndDate
   , null  --KEY_HASH, 
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_EFFLU_TRADE_PRTNER/ICS_EFFLU_TRADE_PRTNER_ADDR
INSERT INTO dbo.ICS_EFFLU_TRADE_PRTNER_ADDR (
     [ICS_EFFLU_TRADE_PRTNER_ADDR_ID]
   , [ICS_EFFLU_TRADE_PRTNER_ID]
   , [ORG_FRML_NAME]
   , [ORG_DUNS_NUM]
   , [LOC_NAME]
   , [MAILING_ADDR_TXT]
   , [SUPPL_ADDR_TXT]
   , [MAILING_ADDR_CITY_NAME]
   , [MAILING_ADDR_COUNTRY_CODE]
   , [LOC_PROVINCE]
   , [MAILING_ADDR_ST_CODE]
   , [MAILING_ADDR_ZIP_CODE]
   , [COUNTY_NAME]
   , [DIVISION_NAME]
   , [ELEC_ADDR_TXT]
   , [DATA_HASH])
SELECT 
     null  --ICS_EFFLU_TRADE_PRTNER_ADDR_ID, 
   , null  --ICS_EFFLU_TRADE_PRTNER_ID, 
   , null  --ORG_FRML_NAME, OrganizationFormalName
   , null  --ORG_DUNS_NUM, OrganizationDUNSNumber
   , null  --LOC_NAME, LocationName
   , null  --MAILING_ADDR_TXT, MailingAddressText
   , null  --SUPPL_ADDR_TXT, SupplementalAddressText
   , null  --MAILING_ADDR_CITY_NAME, MailingAddressCityName
   , null  --MAILING_ADDR_COUNTRY_CODE, MailingAddressCountryCode
   , null  --LOC_PROVINCE, LocationProvince
   , null  --MAILING_ADDR_ST_CODE, MailingAddressStateCode
   , null  --MAILING_ADDR_ZIP_CODE, MailingAddressZipCode
   , null  --COUNTY_NAME, CountyName
   , null  --DIVISION_NAME, DivisionName
   , null  --ELEC_ADDR_TXT, ElectronicAddressText
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_EFFLU_TRADE_PRTNER/ICS_EFFLU_TRADE_PRTNER_ADDR/ICS_TELEPH
INSERT INTO dbo.ICS_TELEPH (
     [ICS_TELEPH_ID]
   , [ICS_CONTACT_ID]
   , [ICS_ADDR_ID]
   , [ICS_EFFLU_TRADE_PRTNER_ADDR_ID]
   , [TELEPH_NUM_TYPE_CODE]
   , [TELEPH_NUM]
   , [TELEPH_EXT_NUM]
   , [DATA_HASH])
SELECT 
     null  --ICS_TELEPH_ID, 
   , null  --ICS_CONTACT_ID, 
   , null  --ICS_ADDR_ID, 
   , null  --ICS_EFFLU_TRADE_PRTNER_ADDR_ID, 
   , null  --TELEPH_NUM_TYPE_CODE, TelephoneNumberTypeCode
   , null  --TELEPH_NUM, TelephoneNumber
   , null  --TELEPH_EXT_NUM, TelephoneExtensionNumber
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

END;
