﻿
/*************************************************************************************************
** ObjectName: ics_etl_UnpermittedFacilitySubmission
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the UnpermittedFacilitySubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/18/2025   Windsor      Created 
**
***************************************************************************************************/
CREATE OR ALTER PROCEDURE dbo.ics_etl_UnpermittedFacilitySubmission

AS

BEGIN
---------------------------- 
-- ICS_UNPRMT_FAC
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- /ICS_UNPRMT_FAC/ICS_ADDR/ICS_TELEPH
DELETE
  FROM dbo.ICS_TELEPH
 WHERE ICS_ADDR_ID IN
          (SELECT ICS_ADDR.ICS_ADDR_ID
             FROM dbo.ICS_UNPRMT_FAC
                  JOIN dbo.ICS_ADDR ON ICS_ADDR.ICS_UNPRMT_FAC_id = ICS_UNPRMT_FAC.ICS_UNPRMT_FAC_id
          );

-- /ICS_UNPRMT_FAC/ICS_CONTACT/ICS_TELEPH
DELETE
  FROM dbo.ICS_TELEPH
 WHERE ICS_CONTACT_ID IN
          (SELECT ICS_CONTACT.ICS_CONTACT_ID
             FROM dbo.ICS_UNPRMT_FAC
                  JOIN dbo.ICS_CONTACT ON ICS_CONTACT.ICS_UNPRMT_FAC_id = ICS_UNPRMT_FAC.ICS_UNPRMT_FAC_id
          );

-- /ICS_UNPRMT_FAC/ICS_ADDR
DELETE
  FROM dbo.ICS_ADDR
 WHERE ICS_UNPRMT_FAC_ID IN
          (SELECT ICS_UNPRMT_FAC.ICS_UNPRMT_FAC_ID
             FROM dbo.ICS_UNPRMT_FAC
          );

-- /ICS_UNPRMT_FAC/ICS_CONTACT
DELETE
  FROM dbo.ICS_CONTACT
 WHERE ICS_UNPRMT_FAC_ID IN
          (SELECT ICS_UNPRMT_FAC.ICS_UNPRMT_FAC_ID
             FROM dbo.ICS_UNPRMT_FAC
          );

-- /ICS_UNPRMT_FAC/ICS_FAC_CLASS
DELETE
  FROM dbo.ICS_FAC_CLASS
 WHERE ICS_UNPRMT_FAC_ID IN
          (SELECT ICS_UNPRMT_FAC.ICS_UNPRMT_FAC_ID
             FROM dbo.ICS_UNPRMT_FAC
          );

-- /ICS_UNPRMT_FAC/ICS_GEO_COORD
DELETE
  FROM dbo.ICS_GEO_COORD
 WHERE ICS_UNPRMT_FAC_ID IN
          (SELECT ICS_UNPRMT_FAC.ICS_UNPRMT_FAC_ID
             FROM dbo.ICS_UNPRMT_FAC
          );

-- /ICS_UNPRMT_FAC/ICS_NAICS_CODE
DELETE
  FROM dbo.ICS_NAICS_CODE
 WHERE ICS_UNPRMT_FAC_ID IN
          (SELECT ICS_UNPRMT_FAC.ICS_UNPRMT_FAC_ID
             FROM dbo.ICS_UNPRMT_FAC
          );

-- /ICS_UNPRMT_FAC/ICS_ORIG_PROGS
DELETE
  FROM dbo.ICS_ORIG_PROGS
 WHERE ICS_UNPRMT_FAC_ID IN
          (SELECT ICS_UNPRMT_FAC.ICS_UNPRMT_FAC_ID
             FROM dbo.ICS_UNPRMT_FAC
          );

-- /ICS_UNPRMT_FAC/ICS_PLCY
DELETE
  FROM dbo.ICS_PLCY
 WHERE ICS_UNPRMT_FAC_ID IN
          (SELECT ICS_UNPRMT_FAC.ICS_UNPRMT_FAC_ID
             FROM dbo.ICS_UNPRMT_FAC
          );

-- /ICS_UNPRMT_FAC/ICS_PRMT_COMP_TYPE
DELETE
  FROM dbo.ICS_PRMT_COMP_TYPE
 WHERE ICS_UNPRMT_FAC_ID IN
          (SELECT ICS_UNPRMT_FAC.ICS_UNPRMT_FAC_ID
             FROM dbo.ICS_UNPRMT_FAC
          );

-- /ICS_UNPRMT_FAC/ICS_SIC_CODE
DELETE
  FROM dbo.ICS_SIC_CODE
 WHERE ICS_UNPRMT_FAC_ID IN
          (SELECT ICS_UNPRMT_FAC.ICS_UNPRMT_FAC_ID
             FROM dbo.ICS_UNPRMT_FAC
          );

-- /ICS_UNPRMT_FAC
DELETE
  FROM dbo.ICS_UNPRMT_FAC;


-- /ICS_UNPRMT_FAC
INSERT INTO dbo.ICS_UNPRMT_FAC (
     [ICS_UNPRMT_FAC_ID]
   , [ICS_PAYLOAD_ID]
   , [SRC_SYSTM_IDENT]
   , [TRANSACTION_TYPE]
   , [TRANSACTION_TIMESTAMP]
   , [PRMT_IDENT]
   , [LOCALITY_NAME]
   , [LOC_ADDR_CITY_CODE]
   , [LOC_ADDR_COUNTY_CODE]
   , [FAC_SITE_NAME]
   , [LOC_ADDR_TXT]
   , [SUPPL_LOC_TXT]
   , [LOC_ST_CODE]
   , [LOC_ZIP_CODE]
   , [LOC_COUNTRY_CODE]
   , [ORG_DUNS_NUM]
   , [ST_FAC_IDENT]
   , [ST_RGN_CODE]
   , [FAC_CONGR_DISTRICT_NUM]
   , [FAC_TYPE_OF_OWNERSHIP_CODE]
   , [FEDR_FAC_IDENT_NUM]
   , [FEDR_AGNCY_CODE]
   , [TRIBAL_LAND_CODE]
   , [CNST_PROJ_NAME]
   , [CNST_PROJ_LAT_MEAS]
   , [CNST_PROJ_LONG_MEAS]
   , [SECTION_TOWNSHIP_RNG]
   , [FAC_CMNTS]
   , [FAC_USR_DFND_FLD_1]
   , [FAC_USR_DFND_FLD_2]
   , [FAC_USR_DFND_FLD_3]
   , [FAC_USR_DFND_FLD_4]
   , [FAC_USR_DFND_FLD_5]
   , [PRMT_CMNTS_TXT]
   , [KEY_HASH]
   , [DATA_HASH])
SELECT 
     null  --ICS_UNPRMT_FAC_ID, 
   , null  --ICS_PAYLOAD_ID, 
   , null  --SRC_SYSTM_IDENT, SourceSystemIdentifier
   , null  --TRANSACTION_TYPE, TransactionType
   , null  --TRANSACTION_TIMESTAMP, TransactionTimestamp
   , null  --PRMT_IDENT, PermitIdentifier
   , null  --LOCALITY_NAME, LocalityName
   , null  --LOC_ADDR_CITY_CODE, LocationAddressCityCode
   , null  --LOC_ADDR_COUNTY_CODE, LocationAddressCountyCode
   , null  --FAC_SITE_NAME, FacilitySiteName
   , null  --LOC_ADDR_TXT, LocationAddressText
   , null  --SUPPL_LOC_TXT, SupplementalLocationText
   , null  --LOC_ST_CODE, LocationStateCode
   , null  --LOC_ZIP_CODE, LocationZipCode
   , null  --LOC_COUNTRY_CODE, LocationCountryCode
   , null  --ORG_DUNS_NUM, OrganizationDUNSNumber
   , null  --ST_FAC_IDENT, StateFacilityIdentifier
   , null  --ST_RGN_CODE, StateRegionCode
   , null  --FAC_CONGR_DISTRICT_NUM, FacilityCongressionalDistrictNumber
   , null  --FAC_TYPE_OF_OWNERSHIP_CODE, FacilityTypeOfOwnershipCode
   , null  --FEDR_FAC_IDENT_NUM, FederalFacilityIdentificationNumber
   , null  --FEDR_AGNCY_CODE, FederalAgencyCode
   , null  --TRIBAL_LAND_CODE, TribalLandCode
   , null  --CNST_PROJ_NAME, ConstructionProjectName
   , null  --CNST_PROJ_LAT_MEAS, ConstructionProjectLatitudeMeasure
   , null  --CNST_PROJ_LONG_MEAS, ConstructionProjectLongitudeMeasure
   , null  --SECTION_TOWNSHIP_RNG, SectionTownshipRange
   , null  --FAC_CMNTS, FacilityComments
   , null  --FAC_USR_DFND_FLD_1, FacilityUserDefinedField1
   , null  --FAC_USR_DFND_FLD_2, FacilityUserDefinedField2
   , null  --FAC_USR_DFND_FLD_3, FacilityUserDefinedField3
   , null  --FAC_USR_DFND_FLD_4, FacilityUserDefinedField4
   , null  --FAC_USR_DFND_FLD_5, FacilityUserDefinedField5
   , null  --PRMT_CMNTS_TXT, PermitCommentsText
   , null  --KEY_HASH, 
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_UNPRMT_FAC/ICS_ADDR
INSERT INTO dbo.ICS_ADDR (
     [ICS_ADDR_ID]
   , [ICS_FAC_ID]
   , [ICS_BASIC_PRMT_ID]
   , [ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID]
   , [ICS_CAFO_PRMT_ID]
   , [ICS_GNRL_PRMT_ID]
   , [ICS_PRMT_FEATR_ID]
   , [ICS_SW_CNST_PRMT_ID]
   , [ICS_SW_INDST_PRMT_ID]
   , [ICS_UNPRMT_FAC_ID]
   , [AFFIL_TYPE_TXT]
   , [ORG_FRML_NAME]
   , [ORG_DUNS_NUM]
   , [MAILING_ADDR_TXT]
   , [SUPPL_ADDR_TXT]
   , [MAILING_ADDR_CITY_NAME]
   , [MAILING_ADDR_ST_CODE]
   , [MAILING_ADDR_ZIP_CODE]
   , [COUNTY_NAME]
   , [MAILING_ADDR_COUNTRY_CODE]
   , [DIVISION_NAME]
   , [LOC_PROVINCE]
   , [ELEC_ADDR_TXT]
   , [START_DATE_OF_ADDR_ASSC]
   , [END_DATE_OF_ADDR_ASSC]
   , [DATA_HASH])
SELECT 
     null  --ICS_ADDR_ID, 
   , null  --ICS_FAC_ID, 
   , null  --ICS_BASIC_PRMT_ID, 
   , null  --ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID, 
   , null  --ICS_CAFO_PRMT_ID, 
   , null  --ICS_GNRL_PRMT_ID, 
   , null  --ICS_PRMT_FEATR_ID, 
   , null  --ICS_SW_CNST_PRMT_ID, 
   , null  --ICS_SW_INDST_PRMT_ID, 
   , null  --ICS_UNPRMT_FAC_ID, 
   , null  --AFFIL_TYPE_TXT, AffiliationTypeText
   , null  --ORG_FRML_NAME, OrganizationFormalName
   , null  --ORG_DUNS_NUM, OrganizationDUNSNumber
   , null  --MAILING_ADDR_TXT, MailingAddressText
   , null  --SUPPL_ADDR_TXT, SupplementalAddressText
   , null  --MAILING_ADDR_CITY_NAME, MailingAddressCityName
   , null  --MAILING_ADDR_ST_CODE, MailingAddressStateCode
   , null  --MAILING_ADDR_ZIP_CODE, MailingAddressZipCode
   , null  --COUNTY_NAME, CountyName
   , null  --MAILING_ADDR_COUNTRY_CODE, MailingAddressCountryCode
   , null  --DIVISION_NAME, DivisionName
   , null  --LOC_PROVINCE, LocationProvince
   , null  --ELEC_ADDR_TXT, ElectronicAddressText
   , null  --START_DATE_OF_ADDR_ASSC, StartDateOfAddressAssociation
   , null  --END_DATE_OF_ADDR_ASSC, EndDateOfAddressAssociation
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_UNPRMT_FAC/ICS_ADDR/ICS_TELEPH
INSERT INTO dbo.ICS_TELEPH (
     [ICS_TELEPH_ID]
   , [ICS_CONTACT_ID]
   , [ICS_ADDR_ID]
   , [ICS_EFFLU_TRADE_PRTNER_ADDR_ID]
   , [TELEPH_NUM_TYPE_CODE]
   , [TELEPH_NUM]
   , [TELEPH_EXT_NUM]
   , [DATA_HASH])
SELECT 
     null  --ICS_TELEPH_ID, 
   , null  --ICS_CONTACT_ID, 
   , null  --ICS_ADDR_ID, 
   , null  --ICS_EFFLU_TRADE_PRTNER_ADDR_ID, 
   , null  --TELEPH_NUM_TYPE_CODE, TelephoneNumberTypeCode
   , null  --TELEPH_NUM, TelephoneNumber
   , null  --TELEPH_EXT_NUM, TelephoneExtensionNumber
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_UNPRMT_FAC/ICS_CONTACT
INSERT INTO dbo.ICS_CONTACT (
     [ICS_CONTACT_ID]
   , [ICS_FAC_ID]
   , [ICS_BASIC_PRMT_ID]
   , [ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID]
   , [ICS_CAFO_PRMT_ID]
   , [ICS_CMPL_MON_ID]
   , [ICS_GNRL_PRMT_ID]
   , [ICS_MASTER_GNRL_PRMT_ID]
   , [ICS_PRMT_FEATR_ID]
   , [ICS_PRETR_PRMT_ID]
   , [ICS_SW_CNST_PRMT_ID]
   , [ICS_SW_INDST_PRMT_ID]
   , [ICS_UNPRMT_FAC_ID]
   , [AFFIL_TYPE_TXT]
   , [FIRST_NAME]
   , [MIDDLE_NAME]
   , [LAST_NAME]
   , [INDVL_TITLE_TXT]
   , [ORG_FRML_NAME]
   , [ST_CODE]
   , [RGN_CODE]
   , [ELEC_ADDR_TXT]
   , [START_DATE_OF_CONTACT_ASSC]
   , [END_DATE_OF_CONTACT_ASSC]
   , [DATA_HASH])
SELECT 
     null  --ICS_CONTACT_ID, 
   , null  --ICS_FAC_ID, 
   , null  --ICS_BASIC_PRMT_ID, 
   , null  --ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID, 
   , null  --ICS_CAFO_PRMT_ID, 
   , null  --ICS_CMPL_MON_ID, 
   , null  --ICS_GNRL_PRMT_ID, 
   , null  --ICS_MASTER_GNRL_PRMT_ID, 
   , null  --ICS_PRMT_FEATR_ID, 
   , null  --ICS_PRETR_PRMT_ID, 
   , null  --ICS_SW_CNST_PRMT_ID, 
   , null  --ICS_SW_INDST_PRMT_ID, 
   , null  --ICS_UNPRMT_FAC_ID, 
   , null  --AFFIL_TYPE_TXT, AffiliationTypeText
   , null  --FIRST_NAME, FirstName
   , null  --MIDDLE_NAME, MiddleName
   , null  --LAST_NAME, LastName
   , null  --INDVL_TITLE_TXT, IndividualTitleText
   , null  --ORG_FRML_NAME, OrganizationFormalName
   , null  --ST_CODE, StateCode
   , null  --RGN_CODE, RegionCode
   , null  --ELEC_ADDR_TXT, ElectronicAddressText
   , null  --START_DATE_OF_CONTACT_ASSC, StartDateOfContactAssociation
   , null  --END_DATE_OF_CONTACT_ASSC, EndDateOfContactAssociation
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_UNPRMT_FAC/ICS_CONTACT/ICS_TELEPH
INSERT INTO dbo.ICS_TELEPH (
     [ICS_TELEPH_ID]
   , [ICS_CONTACT_ID]
   , [ICS_ADDR_ID]
   , [ICS_EFFLU_TRADE_PRTNER_ADDR_ID]
   , [TELEPH_NUM_TYPE_CODE]
   , [TELEPH_NUM]
   , [TELEPH_EXT_NUM]
   , [DATA_HASH])
SELECT 
     null  --ICS_TELEPH_ID, 
   , null  --ICS_CONTACT_ID, 
   , null  --ICS_ADDR_ID, 
   , null  --ICS_EFFLU_TRADE_PRTNER_ADDR_ID, 
   , null  --TELEPH_NUM_TYPE_CODE, TelephoneNumberTypeCode
   , null  --TELEPH_NUM, TelephoneNumber
   , null  --TELEPH_EXT_NUM, TelephoneExtensionNumber
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_UNPRMT_FAC/ICS_FAC_CLASS
INSERT INTO dbo.ICS_FAC_CLASS (
     [ICS_FAC_CLASS_ID]
   , [ICS_FAC_ID]
   , [ICS_UNPRMT_FAC_ID]
   , [FAC_CLASS]
   , [DATA_HASH])
SELECT 
     null  --ICS_FAC_CLASS_ID, 
   , null  --ICS_FAC_ID, 
   , null  --ICS_UNPRMT_FAC_ID, 
   , null  --FAC_CLASS, FacilityClassification
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_UNPRMT_FAC/ICS_GEO_COORD
INSERT INTO dbo.ICS_GEO_COORD (
     [ICS_GEO_COORD_ID]
   , [ICS_FAC_ID]
   , [ICS_COPY_MGP_LMT_SET_ID]
   , [ICS_PRMT_FEATR_ID]
   , [ICS_UNPRMT_FAC_ID]
   , [LAT_MEAS]
   , [LONG_MEAS]
   , [HORZ_ACCURACY_MEAS]
   , [GEOMETRIC_TYPE_CODE]
   , [HORZ_COLL_METHOD_CODE]
   , [HORZ_REF_DATUM_CODE]
   , [REF_POINT_CODE]
   , [SRC_MAP_SCALE_NUM]
   , [DATA_HASH])
SELECT 
     null  --ICS_GEO_COORD_ID, 
   , null  --ICS_FAC_ID, 
   , null  --ICS_COPY_MGP_LMT_SET_ID, 
   , null  --ICS_PRMT_FEATR_ID, 
   , null  --ICS_UNPRMT_FAC_ID, 
   , null  --LAT_MEAS, LatitudeMeasure
   , null  --LONG_MEAS, LongitudeMeasure
   , null  --HORZ_ACCURACY_MEAS, HorizontalAccuracyMeasure
   , null  --GEOMETRIC_TYPE_CODE, GeometricTypeCode
   , null  --HORZ_COLL_METHOD_CODE, HorizontalCollectionMethodCode
   , null  --HORZ_REF_DATUM_CODE, HorizontalReferenceDatumCode
   , null  --REF_POINT_CODE, ReferencePointCode
   , null  --SRC_MAP_SCALE_NUM, SourceMapScaleNumber
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_UNPRMT_FAC/ICS_NAICS_CODE
INSERT INTO dbo.ICS_NAICS_CODE (
     [ICS_NAICS_CODE_ID]
   , [ICS_BASIC_PRMT_ID]
   , [ICS_FAC_ID]
   , [ICS_GNRL_PRMT_ID]
   , [ICS_MASTER_GNRL_PRMT_ID]
   , [ICS_UNPRMT_FAC_ID]
   , [NAICS_CODE]
   , [NAICS_PRIMARY_IND_CODE]
   , [DATA_HASH])
SELECT 
     null  --ICS_NAICS_CODE_ID, 
   , null  --ICS_BASIC_PRMT_ID, 
   , null  --ICS_FAC_ID, 
   , null  --ICS_GNRL_PRMT_ID, 
   , null  --ICS_MASTER_GNRL_PRMT_ID, 
   , null  --ICS_UNPRMT_FAC_ID, 
   , null  --NAICS_CODE, NAICSCode
   , null  --NAICS_PRIMARY_IND_CODE, NAICSPrimaryIndicatorCode
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_UNPRMT_FAC/ICS_ORIG_PROGS
INSERT INTO dbo.ICS_ORIG_PROGS (
     [ICS_ORIG_PROGS_ID]
   , [ICS_FAC_ID]
   , [ICS_UNPRMT_FAC_ID]
   , [ORIG_PROGS_CODE]
   , [DATA_HASH])
SELECT 
     null  --ICS_ORIG_PROGS_ID, 
   , null  --ICS_FAC_ID, 
   , null  --ICS_UNPRMT_FAC_ID, 
   , null  --ORIG_PROGS_CODE, OriginatingProgramsCode
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_UNPRMT_FAC/ICS_PLCY
INSERT INTO dbo.ICS_PLCY (
     [ICS_PLCY_ID]
   , [ICS_FAC_ID]
   , [ICS_UNPRMT_FAC_ID]
   , [PLCY_CODE]
   , [DATA_HASH])
SELECT 
     null  --ICS_PLCY_ID, 
   , null  --ICS_FAC_ID, 
   , null  --ICS_UNPRMT_FAC_ID, 
   , null  --PLCY_CODE, PolicyCode
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_UNPRMT_FAC/ICS_PRMT_COMP_TYPE
INSERT INTO dbo.ICS_PRMT_COMP_TYPE (
     [ICS_PRMT_COMP_TYPE_ID]
   , [ICS_MASTER_GNRL_PRMT_ID]
   , [ICS_UNPRMT_FAC_ID]
   , [PRMT_COMP_TYPE_CODE]
   , [DATA_HASH])
SELECT 
     null  --ICS_PRMT_COMP_TYPE_ID, 
   , null  --ICS_MASTER_GNRL_PRMT_ID, 
   , null  --ICS_UNPRMT_FAC_ID, 
   , null  --PRMT_COMP_TYPE_CODE, PermitComponentTypeCode
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_UNPRMT_FAC/ICS_SIC_CODE
INSERT INTO dbo.ICS_SIC_CODE (
     [ICS_SIC_CODE_ID]
   , [ICS_BASIC_PRMT_ID]
   , [ICS_FAC_ID]
   , [ICS_GNRL_PRMT_ID]
   , [ICS_MASTER_GNRL_PRMT_ID]
   , [ICS_UNPRMT_FAC_ID]
   , [SIC_CODE]
   , [SIC_PRIMARY_IND_CODE]
   , [DATA_HASH])
SELECT 
     null  --ICS_SIC_CODE_ID, 
   , null  --ICS_BASIC_PRMT_ID, 
   , null  --ICS_FAC_ID, 
   , null  --ICS_GNRL_PRMT_ID, 
   , null  --ICS_MASTER_GNRL_PRMT_ID, 
   , null  --ICS_UNPRMT_FAC_ID, 
   , null  --SIC_CODE, SICCode
   , null  --SIC_PRIMARY_IND_CODE, SICPrimaryIndicatorCode
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

END;
