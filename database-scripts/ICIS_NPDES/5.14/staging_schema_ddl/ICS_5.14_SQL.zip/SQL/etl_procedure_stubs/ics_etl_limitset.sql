﻿
/*************************************************************************************************
** ObjectName: ics_etl_LimitSet
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the LimitSetSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/18/2025   Windsor      Created 
**
***************************************************************************************************/
CREATE OR ALTER PROCEDURE dbo.ics_etl_LimitSet

AS

BEGIN
---------------------------- 
-- ICS_LMT_SET
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- /ICS_LMT_SET/ICS_LMT_SET_MONTHS_APPL
DELETE
  FROM dbo.ICS_LMT_SET_MONTHS_APPL
 WHERE ICS_LMT_SET_ID IN
          (SELECT ICS_LMT_SET.ICS_LMT_SET_ID
             FROM dbo.ICS_LMT_SET
          );

-- /ICS_LMT_SET/ICS_LMT_SET_SCHD
DELETE
  FROM dbo.ICS_LMT_SET_SCHD
 WHERE ICS_LMT_SET_ID IN
          (SELECT ICS_LMT_SET.ICS_LMT_SET_ID
             FROM dbo.ICS_LMT_SET
          );

-- /ICS_LMT_SET/ICS_LMT_SET_STAT
DELETE
  FROM dbo.ICS_LMT_SET_STAT
 WHERE ICS_LMT_SET_ID IN
          (SELECT ICS_LMT_SET.ICS_LMT_SET_ID
             FROM dbo.ICS_LMT_SET
          );

-- /ICS_LMT_SET
DELETE
  FROM dbo.ICS_LMT_SET;


-- /ICS_LMT_SET
INSERT INTO dbo.ICS_LMT_SET (
     [ICS_LMT_SET_ID]
   , [ICS_PAYLOAD_ID]
   , [SRC_SYSTM_IDENT]
   , [TRANSACTION_TYPE]
   , [TRANSACTION_TIMESTAMP]
   , [PRMT_IDENT]
   , [PRMT_FEATR_IDENT]
   , [LMT_SET_DESIGNATOR]
   , [LMT_SET_TYPE]
   , [LMT_SET_NAME_TXT]
   , [DMR_PRE_PRINT_CMNTS_TXT]
   , [AGNCY_REVIEWER]
   , [LMT_SET_USR_DFND_DAT_ELM_1_TXT]
   , [LMT_SET_USR_DFND_DAT_ELM_2_TXT]
   , [KEY_HASH]
   , [DATA_HASH])
SELECT 
     null  --ICS_LMT_SET_ID, 
   , null  --ICS_PAYLOAD_ID, 
   , null  --SRC_SYSTM_IDENT, SourceSystemIdentifier
   , null  --TRANSACTION_TYPE, TransactionType
   , null  --TRANSACTION_TIMESTAMP, TransactionTimestamp
   , null  --PRMT_IDENT, PermitIdentifier
   , null  --PRMT_FEATR_IDENT, PermittedFeatureIdentifier
   , null  --LMT_SET_DESIGNATOR, LimitSetDesignator
   , null  --LMT_SET_TYPE, LimitSetType
   , null  --LMT_SET_NAME_TXT, LimitSetNameText
   , null  --DMR_PRE_PRINT_CMNTS_TXT, DMRPrePrintCommentsText
   , null  --AGNCY_REVIEWER, AgencyReviewer
   , null  --LMT_SET_USR_DFND_DAT_ELM_1_TXT, LimitSetUserDefinedDataElement1Text
   , null  --LMT_SET_USR_DFND_DAT_ELM_2_TXT, LimitSetUserDefinedDataElement2Text
   , null  --KEY_HASH, 
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_LMT_SET/ICS_LMT_SET_MONTHS_APPL
INSERT INTO dbo.ICS_LMT_SET_MONTHS_APPL (
     [ICS_LMT_SET_MONTHS_APPL_ID]
   , [ICS_LMT_SET_ID]
   , [LMT_SET_MONTHS_APPL]
   , [DATA_HASH])
SELECT 
     null  --ICS_LMT_SET_MONTHS_APPL_ID, 
   , null  --ICS_LMT_SET_ID, 
   , null  --LMT_SET_MONTHS_APPL, LimitSetMonthsApplicable
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_LMT_SET/ICS_LMT_SET_SCHD
INSERT INTO dbo.ICS_LMT_SET_SCHD (
     [ICS_LMT_SET_SCHD_ID]
   , [ICS_COPY_MGP_LMT_SET_ID]
   , [ICS_LMT_SET_ID]
   , [NUM_UNITS_REP_PERIOD_INTEGER]
   , [NUM_SUBM_UNITS_INTEGER]
   , [INITIAL_MON_DATE]
   , [INITIAL_DMR_DUE_DATE]
   , [LMT_SET_MOD_TYPE_CODE]
   , [LMT_SET_MOD_EFFECTIVE_DATE]
   , [DATA_HASH])
SELECT 
     null  --ICS_LMT_SET_SCHD_ID, 
   , null  --ICS_COPY_MGP_LMT_SET_ID, 
   , null  --ICS_LMT_SET_ID, 
   , null  --NUM_UNITS_REP_PERIOD_INTEGER, NumberUnitsReportPeriodInteger
   , null  --NUM_SUBM_UNITS_INTEGER, NumberSubmissionUnitsInteger
   , null  --INITIAL_MON_DATE, InitialMonitoringDate
   , null  --INITIAL_DMR_DUE_DATE, InitialDMRDueDate
   , null  --LMT_SET_MOD_TYPE_CODE, LimitSetModificationTypeCode
   , null  --LMT_SET_MOD_EFFECTIVE_DATE, LimitSetModificationEffectiveDate
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_LMT_SET/ICS_LMT_SET_STAT
INSERT INTO dbo.ICS_LMT_SET_STAT (
     [ICS_LMT_SET_STAT_ID]
   , [ICS_COPY_MGP_LMT_SET_ID]
   , [ICS_LMT_SET_ID]
   , [LMT_SET_STAT_IND]
   , [LMT_SET_STAT_START_DATE]
   , [LMT_SET_STAT_REASON_TXT]
   , [DATA_HASH])
SELECT 
     null  --ICS_LMT_SET_STAT_ID, 
   , null  --ICS_COPY_MGP_LMT_SET_ID, 
   , null  --ICS_LMT_SET_ID, 
   , null  --LMT_SET_STAT_IND, LimitSetStatusIndicator
   , null  --LMT_SET_STAT_START_DATE, LimitSetStatusStartDate
   , null  --LMT_SET_STAT_REASON_TXT, LimitSetStatusReasonText
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

END;
