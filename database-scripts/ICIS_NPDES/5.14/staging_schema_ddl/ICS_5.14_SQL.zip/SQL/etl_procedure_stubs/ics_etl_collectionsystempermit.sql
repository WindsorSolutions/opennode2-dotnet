﻿
/*************************************************************************************************
** ObjectName: ics_etl_CollectionSystemPermitSubmission
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the CollectionSystemPermitSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/18/2025   Windsor      Created 
**
***************************************************************************************************/
CREATE OR ALTER PROCEDURE dbo.ics_etl_CollectionSystemPermitSubmission

AS

BEGIN
---------------------------- 
-- ICS_COLL_SYSTM_PRMT
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- /ICS_COLL_SYSTM_PRMT
DELETE
  FROM dbo.ICS_COLL_SYSTM_PRMT;


-- /ICS_COLL_SYSTM_PRMT
INSERT INTO dbo.ICS_COLL_SYSTM_PRMT (
     [ICS_COLL_SYSTM_PRMT_ID]
   , [ICS_PAYLOAD_ID]
   , [SRC_SYSTM_IDENT]
   , [TRANSACTION_TYPE]
   , [TRANSACTION_TIMESTAMP]
   , [PRMT_IDENT]
   , [COLL_SYSTM_IDENT]
   , [COLL_SYSTM_NAME]
   , [COLL_SYSTM_OWNER_TYPE_CODE]
   , [COLL_SYSTM_POPL]
   , [PERCENT_COLL_SYSTM_CSS]
   , [KEY_HASH]
   , [DATA_HASH])
SELECT 
     null  --ICS_COLL_SYSTM_PRMT_ID, 
   , null  --ICS_PAYLOAD_ID, 
   , null  --SRC_SYSTM_IDENT, SourceSystemIdentifier
   , null  --TRANSACTION_TYPE, TransactionType
   , null  --TRANSACTION_TIMESTAMP, TransactionTimestamp
   , null  --PRMT_IDENT, PermitIdentifier
   , null  --COLL_SYSTM_IDENT, CollectionSystemIdentifier
   , null  --COLL_SYSTM_NAME, CollectionSystemName
   , null  --COLL_SYSTM_OWNER_TYPE_CODE, CollectionSystemOwnerTypeCode
   , null  --COLL_SYSTM_POPL, CollectionSystemPopulation
   , null  --PERCENT_COLL_SYSTM_CSS, PercentCollectionSystemCSS
   , null  --KEY_HASH, 
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

END;
