﻿
/*************************************************************************************************
** ObjectName: ics_etl_SingleEventViolationSubmission
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the SingleEventViolationSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/18/2025   Windsor      Created 
**
***************************************************************************************************/
CREATE OR ALTER PROCEDURE dbo.ics_etl_SingleEventViolationSubmission

AS

BEGIN
---------------------------- 
-- ICS_SNGL_EVT_VIOL
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- /ICS_SNGL_EVT_VIOL
DELETE
  FROM dbo.ICS_SNGL_EVT_VIOL;


-- /ICS_SNGL_EVT_VIOL
INSERT INTO dbo.ICS_SNGL_EVT_VIOL (
     [ICS_SNGL_EVT_VIOL_ID]
   , [ICS_PAYLOAD_ID]
   , [SRC_SYSTM_IDENT]
   , [TRANSACTION_TYPE]
   , [TRANSACTION_TIMESTAMP]
   , [PRMT_IDENT]
   , [SNGL_EVT_VIOL_CODE]
   , [SNGL_EVT_VIOL_DATE]
   , [SNGL_EVT_VIOL_END_DATE]
   , [REP_NON_CMPL_DETECT_CODE]
   , [REP_NON_CMPL_DETECT_DATE]
   , [REP_NON_CMPL_RESL_CODE]
   , [REP_NON_CMPL_RESL_DATE]
   , [SNGL_EVT_USR_DFND_FLD_1]
   , [SNGL_EVT_USR_DFND_FLD_2]
   , [SNGL_EVT_USR_DFND_FLD_3]
   , [SNGL_EVT_USR_DFND_FLD_4]
   , [SNGL_EVT_USR_DFND_FLD_5]
   , [SNGL_EVT_CMNT_TXT]
   , [KEY_HASH]
   , [DATA_HASH])
SELECT 
     null  --ICS_SNGL_EVT_VIOL_ID, 
   , null  --ICS_PAYLOAD_ID, 
   , null  --SRC_SYSTM_IDENT, SourceSystemIdentifier
   , null  --TRANSACTION_TYPE, TransactionType
   , null  --TRANSACTION_TIMESTAMP, TransactionTimestamp
   , null  --PRMT_IDENT, PermitIdentifier
   , null  --SNGL_EVT_VIOL_CODE, SingleEventViolationCode
   , null  --SNGL_EVT_VIOL_DATE, SingleEventViolationDate
   , null  --SNGL_EVT_VIOL_END_DATE, SingleEventViolationEndDate
   , null  --REP_NON_CMPL_DETECT_CODE, ReportableNonComplianceDetectionCode
   , null  --REP_NON_CMPL_DETECT_DATE, ReportableNonComplianceDetectionDate
   , null  --REP_NON_CMPL_RESL_CODE, ReportableNonComplianceResolutionCode
   , null  --REP_NON_CMPL_RESL_DATE, ReportableNonComplianceResolutionDate
   , null  --SNGL_EVT_USR_DFND_FLD_1, SingleEventUserDefinedField1
   , null  --SNGL_EVT_USR_DFND_FLD_2, SingleEventUserDefinedField2
   , null  --SNGL_EVT_USR_DFND_FLD_3, SingleEventUserDefinedField3
   , null  --SNGL_EVT_USR_DFND_FLD_4, SingleEventUserDefinedField4
   , null  --SNGL_EVT_USR_DFND_FLD_5, SingleEventUserDefinedField5
   , null  --SNGL_EVT_CMNT_TXT, SingleEventCommentText
   , null  --KEY_HASH, 
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

END;
