﻿
/*************************************************************************************************
** ObjectName: ics_etl_ComplianceMonitoring
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the ComplianceMonitoringSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/18/2025   Windsor      Created 
**
***************************************************************************************************/
CREATE OR ALTER PROCEDURE dbo.ics_etl_ComplianceMonitoring

AS

BEGIN
---------------------------- 
-- ICS_CMPL_MON
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- /ICS_CMPL_MON/ICS_SW_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP/ICS_PROJ_TYPE
DELETE
  FROM dbo.ICS_PROJ_TYPE
 WHERE ICS_SW_UNPRMT_CNST_INSP_ID IN
          (SELECT ICS_SW_UNPRMT_CNST_INSP.ICS_SW_UNPRMT_CNST_INSP_ID
             FROM dbo.ICS_CMPL_MON
                  JOIN dbo.ICS_SW_CNST_INSP ON ICS_SW_CNST_INSP.ICS_CMPL_MON_id = ICS_CMPL_MON.ICS_CMPL_MON_id
                  JOIN dbo.ICS_SW_UNPRMT_CNST_INSP ON ICS_SW_UNPRMT_CNST_INSP.ICS_SW_CNST_INSP_id = ICS_SW_CNST_INSP.ICS_SW_CNST_INSP_id
          );

-- /ICS_CMPL_MON/ICS_SW_CNST_NON_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP/ICS_PROJ_TYPE
DELETE
  FROM dbo.ICS_PROJ_TYPE
 WHERE ICS_SW_UNPRMT_CNST_INSP_ID IN
          (SELECT ICS_SW_UNPRMT_CNST_INSP.ICS_SW_UNPRMT_CNST_INSP_ID
             FROM dbo.ICS_CMPL_MON
                  JOIN dbo.ICS_SW_CNST_NON_CNST_INSP ON ICS_SW_CNST_NON_CNST_INSP.ICS_CMPL_MON_id = ICS_CMPL_MON.ICS_CMPL_MON_id
                  JOIN dbo.ICS_SW_UNPRMT_CNST_INSP ON ICS_SW_UNPRMT_CNST_INSP.ICS_SW_CNST_NON_CNST_INSP_id = ICS_SW_CNST_NON_CNST_INSP.ICS_SW_CNST_NON_CNST_INSP_id
          );

-- /ICS_CMPL_MON/ICS_SW_NON_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP/ICS_PROJ_TYPE
DELETE
  FROM dbo.ICS_PROJ_TYPE
 WHERE ICS_SW_UNPRMT_CNST_INSP_ID IN
          (SELECT ICS_SW_UNPRMT_CNST_INSP.ICS_SW_UNPRMT_CNST_INSP_ID
             FROM dbo.ICS_CMPL_MON
                  JOIN dbo.ICS_SW_NON_CNST_INSP ON ICS_SW_NON_CNST_INSP.ICS_CMPL_MON_id = ICS_CMPL_MON.ICS_CMPL_MON_id
                  JOIN dbo.ICS_SW_UNPRMT_CNST_INSP ON ICS_SW_UNPRMT_CNST_INSP.ICS_SW_NON_CNST_INSP_id = ICS_SW_NON_CNST_INSP.ICS_SW_NON_CNST_INSP_id
          );

-- /ICS_CMPL_MON/ICS_CAFO_INSP/ICS_ANML_TYPE
DELETE
  FROM dbo.ICS_ANML_TYPE
 WHERE ICS_CAFO_INSP_ID IN
          (SELECT ICS_CAFO_INSP.ICS_CAFO_INSP_ID
             FROM dbo.ICS_CMPL_MON
                  JOIN dbo.ICS_CAFO_INSP ON ICS_CAFO_INSP.ICS_CMPL_MON_id = ICS_CMPL_MON.ICS_CMPL_MON_id
          );

-- /ICS_CMPL_MON/ICS_CAFO_INSP/ICS_CAFO_INSP_VIOL_TYPE
DELETE
  FROM dbo.ICS_CAFO_INSP_VIOL_TYPE
 WHERE ICS_CAFO_INSP_ID IN
          (SELECT ICS_CAFO_INSP.ICS_CAFO_INSP_ID
             FROM dbo.ICS_CMPL_MON
                  JOIN dbo.ICS_CAFO_INSP ON ICS_CAFO_INSP.ICS_CMPL_MON_id = ICS_CMPL_MON.ICS_CMPL_MON_id
          );

-- /ICS_CMPL_MON/ICS_CAFO_INSP/ICS_CONTAINMENT
DELETE
  FROM dbo.ICS_CONTAINMENT
 WHERE ICS_CAFO_INSP_ID IN
          (SELECT ICS_CAFO_INSP.ICS_CAFO_INSP_ID
             FROM dbo.ICS_CMPL_MON
                  JOIN dbo.ICS_CAFO_INSP ON ICS_CAFO_INSP.ICS_CMPL_MON_id = ICS_CMPL_MON.ICS_CMPL_MON_id
          );

-- /ICS_CMPL_MON/ICS_CAFO_INSP/ICS_LAND_APPL_BMP
DELETE
  FROM dbo.ICS_LAND_APPL_BMP
 WHERE ICS_CAFO_INSP_ID IN
          (SELECT ICS_CAFO_INSP.ICS_CAFO_INSP_ID
             FROM dbo.ICS_CMPL_MON
                  JOIN dbo.ICS_CAFO_INSP ON ICS_CAFO_INSP.ICS_CMPL_MON_id = ICS_CMPL_MON.ICS_CMPL_MON_id
          );

-- /ICS_CMPL_MON/ICS_CAFO_INSP/ICS_MNUR_LTTR_PRCSS_WW_STOR
DELETE
  FROM dbo.ICS_MNUR_LTTR_PRCSS_WW_STOR
 WHERE ICS_CAFO_INSP_ID IN
          (SELECT ICS_CAFO_INSP.ICS_CAFO_INSP_ID
             FROM dbo.ICS_CMPL_MON
                  JOIN dbo.ICS_CAFO_INSP ON ICS_CAFO_INSP.ICS_CMPL_MON_id = ICS_CMPL_MON.ICS_CMPL_MON_id
          );

-- /ICS_CMPL_MON/ICS_CONTACT/ICS_TELEPH
DELETE
  FROM dbo.ICS_TELEPH
 WHERE ICS_CONTACT_ID IN
          (SELECT ICS_CONTACT.ICS_CONTACT_ID
             FROM dbo.ICS_CMPL_MON
                  JOIN dbo.ICS_CONTACT ON ICS_CONTACT.ICS_CMPL_MON_id = ICS_CMPL_MON.ICS_CMPL_MON_id
          );

-- /ICS_CMPL_MON/ICS_SSO_INSP/ICS_IMPACT_SSO_EVT
DELETE
  FROM dbo.ICS_IMPACT_SSO_EVT
 WHERE ICS_SSO_INSP_ID IN
          (SELECT ICS_SSO_INSP.ICS_SSO_INSP_ID
             FROM dbo.ICS_CMPL_MON
                  JOIN dbo.ICS_SSO_INSP ON ICS_SSO_INSP.ICS_CMPL_MON_id = ICS_CMPL_MON.ICS_CMPL_MON_id
          );

-- /ICS_CMPL_MON/ICS_SSO_INSP/ICS_SSO_STPS
DELETE
  FROM dbo.ICS_SSO_STPS
 WHERE ICS_SSO_INSP_ID IN
          (SELECT ICS_SSO_INSP.ICS_SSO_INSP_ID
             FROM dbo.ICS_CMPL_MON
                  JOIN dbo.ICS_SSO_INSP ON ICS_SSO_INSP.ICS_CMPL_MON_id = ICS_CMPL_MON.ICS_CMPL_MON_id
          );

-- /ICS_CMPL_MON/ICS_SSO_INSP/ICS_SSO_SYSTM_COMP
DELETE
  FROM dbo.ICS_SSO_SYSTM_COMP
 WHERE ICS_SSO_INSP_ID IN
          (SELECT ICS_SSO_INSP.ICS_SSO_INSP_ID
             FROM dbo.ICS_CMPL_MON
                  JOIN dbo.ICS_SSO_INSP ON ICS_SSO_INSP.ICS_CMPL_MON_id = ICS_CMPL_MON.ICS_CMPL_MON_id
          );

-- /ICS_CMPL_MON/ICS_SW_CNST_INSP/ICS_SW_CNST_INDST_INSP
DELETE
  FROM dbo.ICS_SW_CNST_INDST_INSP
 WHERE ICS_SW_CNST_INSP_ID IN
          (SELECT ICS_SW_CNST_INSP.ICS_SW_CNST_INSP_ID
             FROM dbo.ICS_CMPL_MON
                  JOIN dbo.ICS_SW_CNST_INSP ON ICS_SW_CNST_INSP.ICS_CMPL_MON_id = ICS_CMPL_MON.ICS_CMPL_MON_id
          );

-- /ICS_CMPL_MON/ICS_SW_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP
DELETE
  FROM dbo.ICS_SW_UNPRMT_CNST_INSP
 WHERE ICS_SW_CNST_INSP_ID IN
          (SELECT ICS_SW_CNST_INSP.ICS_SW_CNST_INSP_ID
             FROM dbo.ICS_CMPL_MON
                  JOIN dbo.ICS_SW_CNST_INSP ON ICS_SW_CNST_INSP.ICS_CMPL_MON_id = ICS_CMPL_MON.ICS_CMPL_MON_id
          );

-- /ICS_CMPL_MON/ICS_SW_CNST_NON_CNST_INSP/ICS_SW_CNST_INDST_INSP
DELETE
  FROM dbo.ICS_SW_CNST_INDST_INSP
 WHERE ICS_SW_CNST_NON_CNST_INSP_ID IN
          (SELECT ICS_SW_CNST_NON_CNST_INSP.ICS_SW_CNST_NON_CNST_INSP_ID
             FROM dbo.ICS_CMPL_MON
                  JOIN dbo.ICS_SW_CNST_NON_CNST_INSP ON ICS_SW_CNST_NON_CNST_INSP.ICS_CMPL_MON_id = ICS_CMPL_MON.ICS_CMPL_MON_id
          );

-- /ICS_CMPL_MON/ICS_SW_CNST_NON_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP
DELETE
  FROM dbo.ICS_SW_UNPRMT_CNST_INSP
 WHERE ICS_SW_CNST_NON_CNST_INSP_ID IN
          (SELECT ICS_SW_CNST_NON_CNST_INSP.ICS_SW_CNST_NON_CNST_INSP_ID
             FROM dbo.ICS_CMPL_MON
                  JOIN dbo.ICS_SW_CNST_NON_CNST_INSP ON ICS_SW_CNST_NON_CNST_INSP.ICS_CMPL_MON_id = ICS_CMPL_MON.ICS_CMPL_MON_id
          );

-- /ICS_CMPL_MON/ICS_SW_MS_4_INSP/ICS_PROJ_SRCS_FUND
DELETE
  FROM dbo.ICS_PROJ_SRCS_FUND
 WHERE ICS_SW_MS_4_INSP_ID IN
          (SELECT ICS_SW_MS_4_INSP.ICS_SW_MS_4_INSP_ID
             FROM dbo.ICS_CMPL_MON
                  JOIN dbo.ICS_SW_MS_4_INSP ON ICS_SW_MS_4_INSP.ICS_CMPL_MON_id = ICS_CMPL_MON.ICS_CMPL_MON_id
          );

-- /ICS_CMPL_MON/ICS_SW_NON_CNST_INSP/ICS_SW_CNST_INDST_INSP
DELETE
  FROM dbo.ICS_SW_CNST_INDST_INSP
 WHERE ICS_SW_NON_CNST_INSP_ID IN
          (SELECT ICS_SW_NON_CNST_INSP.ICS_SW_NON_CNST_INSP_ID
             FROM dbo.ICS_CMPL_MON
                  JOIN dbo.ICS_SW_NON_CNST_INSP ON ICS_SW_NON_CNST_INSP.ICS_CMPL_MON_id = ICS_CMPL_MON.ICS_CMPL_MON_id
          );

-- /ICS_CMPL_MON/ICS_SW_NON_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP
DELETE
  FROM dbo.ICS_SW_UNPRMT_CNST_INSP
 WHERE ICS_SW_NON_CNST_INSP_ID IN
          (SELECT ICS_SW_NON_CNST_INSP.ICS_SW_NON_CNST_INSP_ID
             FROM dbo.ICS_CMPL_MON
                  JOIN dbo.ICS_SW_NON_CNST_INSP ON ICS_SW_NON_CNST_INSP.ICS_CMPL_MON_id = ICS_CMPL_MON.ICS_CMPL_MON_id
          );

-- /ICS_CMPL_MON/ICS_CAFO_INSP
DELETE
  FROM dbo.ICS_CAFO_INSP
 WHERE ICS_CMPL_MON_ID IN
          (SELECT ICS_CMPL_MON.ICS_CMPL_MON_ID
             FROM dbo.ICS_CMPL_MON
          );

-- /ICS_CMPL_MON/ICS_CMPL_INSP_TYPE
DELETE
  FROM dbo.ICS_CMPL_INSP_TYPE
 WHERE ICS_CMPL_MON_ID IN
          (SELECT ICS_CMPL_MON.ICS_CMPL_MON_ID
             FROM dbo.ICS_CMPL_MON
          );

-- /ICS_CMPL_MON/ICS_CMPL_MON_ACTN_REASON
DELETE
  FROM dbo.ICS_CMPL_MON_ACTN_REASON
 WHERE ICS_CMPL_MON_ID IN
          (SELECT ICS_CMPL_MON.ICS_CMPL_MON_ID
             FROM dbo.ICS_CMPL_MON
          );

-- /ICS_CMPL_MON/ICS_CMPL_MON_AGNCY_TYPE
DELETE
  FROM dbo.ICS_CMPL_MON_AGNCY_TYPE
 WHERE ICS_CMPL_MON_ID IN
          (SELECT ICS_CMPL_MON.ICS_CMPL_MON_ID
             FROM dbo.ICS_CMPL_MON
          );

-- /ICS_CMPL_MON/ICS_CONTACT
DELETE
  FROM dbo.ICS_CONTACT
 WHERE ICS_CMPL_MON_ID IN
          (SELECT ICS_CMPL_MON.ICS_CMPL_MON_ID
             FROM dbo.ICS_CMPL_MON
          );

-- /ICS_CMPL_MON/ICS_CSO_INSP
DELETE
  FROM dbo.ICS_CSO_INSP
 WHERE ICS_CMPL_MON_ID IN
          (SELECT ICS_CMPL_MON.ICS_CMPL_MON_ID
             FROM dbo.ICS_CMPL_MON
          );

-- /ICS_CMPL_MON/ICS_INSP_CMNT_TXT
DELETE
  FROM dbo.ICS_INSP_CMNT_TXT
 WHERE ICS_CMPL_MON_ID IN
          (SELECT ICS_CMPL_MON.ICS_CMPL_MON_ID
             FROM dbo.ICS_CMPL_MON
          );

-- /ICS_CMPL_MON/ICS_INSP_GOV_CONTACT
DELETE
  FROM dbo.ICS_INSP_GOV_CONTACT
 WHERE ICS_CMPL_MON_ID IN
          (SELECT ICS_CMPL_MON.ICS_CMPL_MON_ID
             FROM dbo.ICS_CMPL_MON
          );

-- /ICS_CMPL_MON/ICS_NAT_PRIO
DELETE
  FROM dbo.ICS_NAT_PRIO
 WHERE ICS_CMPL_MON_ID IN
          (SELECT ICS_CMPL_MON.ICS_CMPL_MON_ID
             FROM dbo.ICS_CMPL_MON
          );

-- /ICS_CMPL_MON/ICS_PRETR_INSP
DELETE
  FROM dbo.ICS_PRETR_INSP
 WHERE ICS_CMPL_MON_ID IN
          (SELECT ICS_CMPL_MON.ICS_CMPL_MON_ID
             FROM dbo.ICS_CMPL_MON
          );

-- /ICS_CMPL_MON/ICS_PROG
DELETE
  FROM dbo.ICS_PROG
 WHERE ICS_CMPL_MON_ID IN
          (SELECT ICS_CMPL_MON.ICS_CMPL_MON_ID
             FROM dbo.ICS_CMPL_MON
          );

-- /ICS_CMPL_MON/ICS_PROG_DEFCY_TYPE
DELETE
  FROM dbo.ICS_PROG_DEFCY_TYPE
 WHERE ICS_CMPL_MON_ID IN
          (SELECT ICS_CMPL_MON.ICS_CMPL_MON_ID
             FROM dbo.ICS_CMPL_MON
          );

-- /ICS_CMPL_MON/ICS_SSO_INSP
DELETE
  FROM dbo.ICS_SSO_INSP
 WHERE ICS_CMPL_MON_ID IN
          (SELECT ICS_CMPL_MON.ICS_CMPL_MON_ID
             FROM dbo.ICS_CMPL_MON
          );

-- /ICS_CMPL_MON/ICS_SW_CNST_INSP
DELETE
  FROM dbo.ICS_SW_CNST_INSP
 WHERE ICS_CMPL_MON_ID IN
          (SELECT ICS_CMPL_MON.ICS_CMPL_MON_ID
             FROM dbo.ICS_CMPL_MON
          );

-- /ICS_CMPL_MON/ICS_SW_CNST_NON_CNST_INSP
DELETE
  FROM dbo.ICS_SW_CNST_NON_CNST_INSP
 WHERE ICS_CMPL_MON_ID IN
          (SELECT ICS_CMPL_MON.ICS_CMPL_MON_ID
             FROM dbo.ICS_CMPL_MON
          );

-- /ICS_CMPL_MON/ICS_SW_MS_4_INSP
DELETE
  FROM dbo.ICS_SW_MS_4_INSP
 WHERE ICS_CMPL_MON_ID IN
          (SELECT ICS_CMPL_MON.ICS_CMPL_MON_ID
             FROM dbo.ICS_CMPL_MON
          );

-- /ICS_CMPL_MON/ICS_SW_NON_CNST_INSP
DELETE
  FROM dbo.ICS_SW_NON_CNST_INSP
 WHERE ICS_CMPL_MON_ID IN
          (SELECT ICS_CMPL_MON.ICS_CMPL_MON_ID
             FROM dbo.ICS_CMPL_MON
          );

-- /ICS_CMPL_MON
DELETE
  FROM dbo.ICS_CMPL_MON;


-- /ICS_CMPL_MON
INSERT INTO dbo.ICS_CMPL_MON (
     [ICS_CMPL_MON_ID]
   , [ICS_PAYLOAD_ID]
   , [SRC_SYSTM_IDENT]
   , [TRANSACTION_TYPE]
   , [TRANSACTION_TIMESTAMP]
   , [CMPL_MON_IDENT]
   , [PRMT_IDENT]
   , [CMPL_MON_ACTY_TYPE_CODE]
   , [CMPL_MON_CATG_CODE]
   , [CMPL_MON_DATE]
   , [CMPL_MON_START_DATE]
   , [CMPL_MON_ACTY_NAME]
   , [BIOMON_INSP_METHOD]
   , [CMPL_MON_AGNCY_CODE]
   , [ST_STATUTE_VIOL_NAME]
   , [EPA_ASSIST_IND]
   , [ST_FEDR_JOINT_IND]
   , [JOINT_INSP_REASON_CODE]
   , [LEAD_PARTY]
   , [NUM_DAYS_PHYS_COND_ACTY]
   , [NUM_HOURS_PHYS_COND_ACTY]
   , [CMPL_MON_ACTN_OUTCOME_CODE]
   , [INSP_RATING_CODE]
   , [MULTIMEDIA_IND]
   , [FEDR_FAC_IND]
   , [FEDR_FAC_IND_CMNT]
   , [INSP_USR_DFND_FLD_1]
   , [INSP_USR_DFND_FLD_2]
   , [INSP_USR_DFND_FLD_3]
   , [INSP_USR_DFND_FLD_4]
   , [INSP_USR_DFND_FLD_5]
   , [INSP_USR_DFND_FLD_6]
   , [CMPL_MON_PLANNED_START_DATE]
   , [CMPL_MON_PLANNED_END_DATE]
   , [KEY_HASH]
   , [DATA_HASH])
SELECT 
     null  --ICS_CMPL_MON_ID, 
   , null  --ICS_PAYLOAD_ID, 
   , null  --SRC_SYSTM_IDENT, SourceSystemIdentifier
   , null  --TRANSACTION_TYPE, TransactionType
   , null  --TRANSACTION_TIMESTAMP, TransactionTimestamp
   , null  --CMPL_MON_IDENT, ComplianceMonitoringIdentifier
   , null  --PRMT_IDENT, PermitIdentifier
   , null  --CMPL_MON_ACTY_TYPE_CODE, ComplianceMonitoringActivityTypeCode
   , null  --CMPL_MON_CATG_CODE, ComplianceMonitoringCategoryCode
   , null  --CMPL_MON_DATE, ComplianceMonitoringDate
   , null  --CMPL_MON_START_DATE, ComplianceMonitoringStartDate
   , null  --CMPL_MON_ACTY_NAME, ComplianceMonitoringActivityName
   , null  --BIOMON_INSP_METHOD, BiomonitoringInspectionMethod
   , null  --CMPL_MON_AGNCY_CODE, ComplianceMonitoringAgencyCode
   , null  --ST_STATUTE_VIOL_NAME, StateStatuteViolatedName
   , null  --EPA_ASSIST_IND, EPAAssistanceIndicator
   , null  --ST_FEDR_JOINT_IND, StateFederalJointIndicator
   , null  --JOINT_INSP_REASON_CODE, JointInspectionReasonCode
   , null  --LEAD_PARTY, LeadParty
   , null  --NUM_DAYS_PHYS_COND_ACTY, NumberDaysPhysicallyConductingActivity
   , null  --NUM_HOURS_PHYS_COND_ACTY, NumberHoursPhysicallyConductingActivity
   , null  --CMPL_MON_ACTN_OUTCOME_CODE, ComplianceMonitoringActionOutcomeCode
   , null  --INSP_RATING_CODE, InspectionRatingCode
   , null  --MULTIMEDIA_IND, MultimediaIndicator
   , null  --FEDR_FAC_IND, FederalFacilityIndicator
   , null  --FEDR_FAC_IND_CMNT, FederalFacilityIndicatorComment
   , null  --INSP_USR_DFND_FLD_1, InspectionUserDefinedField1
   , null  --INSP_USR_DFND_FLD_2, InspectionUserDefinedField2
   , null  --INSP_USR_DFND_FLD_3, InspectionUserDefinedField3
   , null  --INSP_USR_DFND_FLD_4, InspectionUserDefinedField4
   , null  --INSP_USR_DFND_FLD_5, InspectionUserDefinedField5
   , null  --INSP_USR_DFND_FLD_6, InspectionUserDefinedField6
   , null  --CMPL_MON_PLANNED_START_DATE, ComplianceMonitoringPlannedStartDate
   , null  --CMPL_MON_PLANNED_END_DATE, ComplianceMonitoringPlannedEndDate
   , null  --KEY_HASH, 
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_CAFO_INSP
INSERT INTO dbo.ICS_CAFO_INSP (
     [ICS_CAFO_INSP_ID]
   , [ICS_CMPL_MON_ID]
   , [CAFO_CLASS_CODE]
   , [IS_ANML_FAC_TYPE_CAFO_IND]
   , [CAFO_DESGN_DATE]
   , [CAFO_DESGN_REASON_TXT]
   , [DSCH_DRNG_YEAR_PROD_AREA_IND]
   , [DSCH_DRNG_YEAR_LAND_APPL_AREA_IND]
   , [CAFO_DSCH_DRNG_YEAR_TXT]
   , [NUM_ACRES_CONTRB_DRAIN]
   , [APPL_MEAS_AVAIL_LAND_NUM]
   , [SOLID_MNUR_LTTR_GNRTD_AMT]
   , [LIQUID_MNUR_WW_GNRTD_AMT]
   , [SOLID_MNUR_LTTR_TRANS_AMT]
   , [LIQUID_MNUR_WW_TRANS_AMT]
   , [NMP_DVLPD_CERT_PLNR_APRVD_IND]
   , [NMP_DVLPD_DATE]
   , [NMP_LAST_UPDATED_DATE]
   , [ENVR_MGMT_SYSTM_IND]
   , [EMS_DVLPD_DATE]
   , [EMS_LAST_UPDATED_DATE]
   , [LVSTCK_MAX_CPCTY_NUM]
   , [LVSTCK_CPCTY_DTRMN_BS_UPON_NUM]
   , [AUTH_LVSTCK_CPCTY_NUM]
   , [DATA_HASH])
SELECT 
     null  --ICS_CAFO_INSP_ID, 
   , null  --ICS_CMPL_MON_ID, 
   , null  --CAFO_CLASS_CODE, CAFOClassificationCode
   , null  --IS_ANML_FAC_TYPE_CAFO_IND, IsAnimalFacilityTypeCAFOIndicator
   , null  --CAFO_DESGN_DATE, CAFODesignationDate
   , null  --CAFO_DESGN_REASON_TXT, CAFODesignationReasonText
   , null  --DSCH_DRNG_YEAR_PROD_AREA_IND, DischargesDuringYearProductionAreaIndicator
   , null  --DSCH_DRNG_YEAR_LAND_APPL_AREA_IND, DischargesDuringYearLandApplicationAreaIndicator
   , null  --CAFO_DSCH_DRNG_YEAR_TXT, CAFODischargesDuringYearText
   , null  --NUM_ACRES_CONTRB_DRAIN, NumberAcresContributingDrainage
   , null  --APPL_MEAS_AVAIL_LAND_NUM, ApplicationMeasureAvailableLandNumber
   , null  --SOLID_MNUR_LTTR_GNRTD_AMT, SolidManureLitterGeneratedAmount
   , null  --LIQUID_MNUR_WW_GNRTD_AMT, LiquidManureWastewaterGeneratedAmount
   , null  --SOLID_MNUR_LTTR_TRANS_AMT, SolidManureLitterTransferAmount
   , null  --LIQUID_MNUR_WW_TRANS_AMT, LiquidManureWastewaterTransferAmount
   , null  --NMP_DVLPD_CERT_PLNR_APRVD_IND, NMPDevelopedCertifiedPlannerApprovedIndicator
   , null  --NMP_DVLPD_DATE, NMPDevelopedDate
   , null  --NMP_LAST_UPDATED_DATE, NMPLastUpdatedDate
   , null  --ENVR_MGMT_SYSTM_IND, EnvironmentalManagementSystemIndicator
   , null  --EMS_DVLPD_DATE, EMSDevelopedDate
   , null  --EMS_LAST_UPDATED_DATE, EMSLastUpdatedDate
   , null  --LVSTCK_MAX_CPCTY_NUM, LivestockMaximumCapacityNumber
   , null  --LVSTCK_CPCTY_DTRMN_BS_UPON_NUM, LivestockCapacityDeterminationBasedUponNumber
   , null  --AUTH_LVSTCK_CPCTY_NUM, AuthorizedLivestockCapacityNumber
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_CAFO_INSP/ICS_ANML_TYPE
INSERT INTO dbo.ICS_ANML_TYPE (
     [ICS_ANML_TYPE_ID]
   , [ICS_CAFO_ANNUL_PROG_REP_ID]
   , [ICS_CAFO_PRMT_ID]
   , [ICS_CAFO_INSP_ID]
   , [ANML_TYPE_CODE]
   , [OTHR_ANML_TYPE_NAME]
   , [TTL_NUM_EACH_LVSTCK]
   , [OPEN_CONFINEMNT_CNT]
   , [HOUSD_UNDR_ROOF_CONFINEMNT_CNT]
   , [LIQUID_MNUR_HANDLING_SYSTM]
   , [DATA_HASH])
SELECT 
     null  --ICS_ANML_TYPE_ID, 
   , null  --ICS_CAFO_ANNUL_PROG_REP_ID, 
   , null  --ICS_CAFO_PRMT_ID, 
   , null  --ICS_CAFO_INSP_ID, 
   , null  --ANML_TYPE_CODE, AnimalTypeCode
   , null  --OTHR_ANML_TYPE_NAME, OtherAnimalTypeName
   , null  --TTL_NUM_EACH_LVSTCK, TotalNumbersEachLivestock
   , null  --OPEN_CONFINEMNT_CNT, OpenConfinementCount
   , null  --HOUSD_UNDR_ROOF_CONFINEMNT_CNT, HousedUnderRoofConfinementCount
   , null  --LIQUID_MNUR_HANDLING_SYSTM, LiquidManureHandlingSystem
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_CAFO_INSP/ICS_CAFO_INSP_VIOL_TYPE
INSERT INTO dbo.ICS_CAFO_INSP_VIOL_TYPE (
     [ICS_CAFO_INSP_VIOL_TYPE_ID]
   , [ICS_CAFO_INSP_ID]
   , [CAFO_INSP_VIOL_TYPE_CODE]
   , [DATA_HASH])
SELECT 
     null  --ICS_CAFO_INSP_VIOL_TYPE_ID, 
   , null  --ICS_CAFO_INSP_ID, 
   , null  --CAFO_INSP_VIOL_TYPE_CODE, CAFOInspectionViolationTypeCode
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_CAFO_INSP/ICS_CONTAINMENT
INSERT INTO dbo.ICS_CONTAINMENT (
     [ICS_CONTAINMENT_ID]
   , [ICS_CAFO_PRMT_ID]
   , [ICS_CAFO_INSP_ID]
   , [CONTAINMENT_TYPE_CODE]
   , [OTHR_CONTAINMENT_TYPE_NAME]
   , [CONTAINMENT_CPCTY_NUM]
   , [DATA_HASH])
SELECT 
     null  --ICS_CONTAINMENT_ID, 
   , null  --ICS_CAFO_PRMT_ID, 
   , null  --ICS_CAFO_INSP_ID, 
   , null  --CONTAINMENT_TYPE_CODE, ContainmentTypeCode
   , null  --OTHR_CONTAINMENT_TYPE_NAME, OtherContainmentTypeName
   , null  --CONTAINMENT_CPCTY_NUM, ContainmentCapacityNumber
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_CAFO_INSP/ICS_LAND_APPL_BMP
INSERT INTO dbo.ICS_LAND_APPL_BMP (
     [ICS_LAND_APPL_BMP_ID]
   , [ICS_CAFO_PRMT_ID]
   , [ICS_CAFO_INSP_ID]
   , [LAND_APPL_BMP_TYPE_CODE]
   , [OTHR_LAND_APPL_BMP_TYPE_NAME]
   , [DATA_HASH])
SELECT 
     null  --ICS_LAND_APPL_BMP_ID, 
   , null  --ICS_CAFO_PRMT_ID, 
   , null  --ICS_CAFO_INSP_ID, 
   , null  --LAND_APPL_BMP_TYPE_CODE, LandApplicationBMPTypeCode
   , null  --OTHR_LAND_APPL_BMP_TYPE_NAME, OtherLandApplicationBMPTypeName
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_CAFO_INSP/ICS_MNUR_LTTR_PRCSS_WW_STOR
INSERT INTO dbo.ICS_MNUR_LTTR_PRCSS_WW_STOR (
     [ICS_MNUR_LTTR_PRCSS_WW_STOR_ID]
   , [ICS_CAFO_PRMT_ID]
   , [ICS_CAFO_INSP_ID]
   , [MNUR_LTTR_PRCSS_WW_STOR_TYPE]
   , [OTHR_STOR_TYPE_NAME]
   , [STOR_TTL_CPCTY_MEAS]
   , [DAYS_OF_STOR]
   , [CAFOMLPW_UNIT]
   , [CAFOMLPW_STOR_WITHIN_DSGN_CPCTY]
   , [CAFOMLPW_STOR_WITHIN_DSGN_CPCTY_TXT]
   , [DATA_HASH])
SELECT 
     null  --ICS_MNUR_LTTR_PRCSS_WW_STOR_ID, 
   , null  --ICS_CAFO_PRMT_ID, 
   , null  --ICS_CAFO_INSP_ID, 
   , null  --MNUR_LTTR_PRCSS_WW_STOR_TYPE, ManureLitterProcessedWastewaterStorageType
   , null  --OTHR_STOR_TYPE_NAME, OtherStorageTypeName
   , null  --STOR_TTL_CPCTY_MEAS, StorageTotalCapacityMeasure
   , null  --DAYS_OF_STOR, DaysOfStorage
   , null  --CAFOMLPW_UNIT, CAFOMLPWUnit
   , null  --CAFOMLPW_STOR_WITHIN_DSGN_CPCTY, CAFOMLPWStorageWithinDesignCapacity
   , null  --CAFOMLPW_STOR_WITHIN_DSGN_CPCTY_TXT, CAFOMLPWStorageWithinDesignCapacityText
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_CMPL_INSP_TYPE
INSERT INTO dbo.ICS_CMPL_INSP_TYPE (
     [ICS_CMPL_INSP_TYPE_ID]
   , [ICS_CMPL_MON_ID]
   , [CMPL_INSP_TYPE_CODE]
   , [DATA_HASH])
SELECT 
     null  --ICS_CMPL_INSP_TYPE_ID, 
   , null  --ICS_CMPL_MON_ID, 
   , null  --CMPL_INSP_TYPE_CODE, ComplianceInspectionTypeCode
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_CMPL_MON_ACTN_REASON
INSERT INTO dbo.ICS_CMPL_MON_ACTN_REASON (
     [ICS_CMPL_MON_ACTN_REASON_ID]
   , [ICS_CMPL_MON_ID]
   , [CMPL_MON_ACTN_REASON_CODE]
   , [DATA_HASH])
SELECT 
     null  --ICS_CMPL_MON_ACTN_REASON_ID, 
   , null  --ICS_CMPL_MON_ID, 
   , null  --CMPL_MON_ACTN_REASON_CODE, ComplianceMonitoringActionReasonCode
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_CMPL_MON_AGNCY_TYPE
INSERT INTO dbo.ICS_CMPL_MON_AGNCY_TYPE (
     [ICS_CMPL_MON_AGNCY_TYPE_ID]
   , [ICS_CMPL_MON_ID]
   , [CMPL_MON_AGNCY_TYPE_CODE]
   , [DATA_HASH])
SELECT 
     null  --ICS_CMPL_MON_AGNCY_TYPE_ID, 
   , null  --ICS_CMPL_MON_ID, 
   , null  --CMPL_MON_AGNCY_TYPE_CODE, ComplianceMonitoringAgencyTypeCode
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_CONTACT
INSERT INTO dbo.ICS_CONTACT (
     [ICS_CONTACT_ID]
   , [ICS_FAC_ID]
   , [ICS_BASIC_PRMT_ID]
   , [ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID]
   , [ICS_CAFO_PRMT_ID]
   , [ICS_CMPL_MON_ID]
   , [ICS_GNRL_PRMT_ID]
   , [ICS_MASTER_GNRL_PRMT_ID]
   , [ICS_PRMT_FEATR_ID]
   , [ICS_PRETR_PRMT_ID]
   , [ICS_SW_CNST_PRMT_ID]
   , [ICS_SW_INDST_PRMT_ID]
   , [ICS_UNPRMT_FAC_ID]
   , [AFFIL_TYPE_TXT]
   , [FIRST_NAME]
   , [MIDDLE_NAME]
   , [LAST_NAME]
   , [INDVL_TITLE_TXT]
   , [ORG_FRML_NAME]
   , [ST_CODE]
   , [RGN_CODE]
   , [ELEC_ADDR_TXT]
   , [START_DATE_OF_CONTACT_ASSC]
   , [END_DATE_OF_CONTACT_ASSC]
   , [DATA_HASH])
SELECT 
     null  --ICS_CONTACT_ID, 
   , null  --ICS_FAC_ID, 
   , null  --ICS_BASIC_PRMT_ID, 
   , null  --ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID, 
   , null  --ICS_CAFO_PRMT_ID, 
   , null  --ICS_CMPL_MON_ID, 
   , null  --ICS_GNRL_PRMT_ID, 
   , null  --ICS_MASTER_GNRL_PRMT_ID, 
   , null  --ICS_PRMT_FEATR_ID, 
   , null  --ICS_PRETR_PRMT_ID, 
   , null  --ICS_SW_CNST_PRMT_ID, 
   , null  --ICS_SW_INDST_PRMT_ID, 
   , null  --ICS_UNPRMT_FAC_ID, 
   , null  --AFFIL_TYPE_TXT, AffiliationTypeText
   , null  --FIRST_NAME, FirstName
   , null  --MIDDLE_NAME, MiddleName
   , null  --LAST_NAME, LastName
   , null  --INDVL_TITLE_TXT, IndividualTitleText
   , null  --ORG_FRML_NAME, OrganizationFormalName
   , null  --ST_CODE, StateCode
   , null  --RGN_CODE, RegionCode
   , null  --ELEC_ADDR_TXT, ElectronicAddressText
   , null  --START_DATE_OF_CONTACT_ASSC, StartDateOfContactAssociation
   , null  --END_DATE_OF_CONTACT_ASSC, EndDateOfContactAssociation
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_CONTACT/ICS_TELEPH
INSERT INTO dbo.ICS_TELEPH (
     [ICS_TELEPH_ID]
   , [ICS_CONTACT_ID]
   , [ICS_ADDR_ID]
   , [ICS_EFFLU_TRADE_PRTNER_ADDR_ID]
   , [TELEPH_NUM_TYPE_CODE]
   , [TELEPH_NUM]
   , [TELEPH_EXT_NUM]
   , [DATA_HASH])
SELECT 
     null  --ICS_TELEPH_ID, 
   , null  --ICS_CONTACT_ID, 
   , null  --ICS_ADDR_ID, 
   , null  --ICS_EFFLU_TRADE_PRTNER_ADDR_ID, 
   , null  --TELEPH_NUM_TYPE_CODE, TelephoneNumberTypeCode
   , null  --TELEPH_NUM, TelephoneNumber
   , null  --TELEPH_EXT_NUM, TelephoneExtensionNumber
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_CSO_INSP
INSERT INTO dbo.ICS_CSO_INSP (
     [ICS_CSO_INSP_ID]
   , [ICS_CMPL_MON_ID]
   , [CSO_EVT_DATE]
   , [DRY_OR_WET_WEATHER_IND]
   , [PRMT_FEATR_IDENT]
   , [LAT_MEAS]
   , [LONG_MEAS]
   , [CSO_OVRFLW_LOC_STREET]
   , [DURATION_CSO_OVRFLW_EVT]
   , [DSCH_VOL_TREATED]
   , [DSCH_VOL_UNTREATED]
   , [CORR_ACTN_TAKEN_DESC_TXT]
   , [INCHES_PRECIP]
   , [DATA_HASH])
SELECT 
     null  --ICS_CSO_INSP_ID, 
   , null  --ICS_CMPL_MON_ID, 
   , null  --CSO_EVT_DATE, CSOEventDate
   , null  --DRY_OR_WET_WEATHER_IND, DryOrWetWeatherIndicator
   , null  --PRMT_FEATR_IDENT, PermittedFeatureIdentifier
   , null  --LAT_MEAS, LatitudeMeasure
   , null  --LONG_MEAS, LongitudeMeasure
   , null  --CSO_OVRFLW_LOC_STREET, CSOOverflowLocationStreet
   , null  --DURATION_CSO_OVRFLW_EVT, DurationCSOOverflowEvent
   , null  --DSCH_VOL_TREATED, DischargeVolumeTreated
   , null  --DSCH_VOL_UNTREATED, DischargeVolumeUntreated
   , null  --CORR_ACTN_TAKEN_DESC_TXT, CorrectiveActionTakenDescriptionText
   , null  --INCHES_PRECIP, InchesPrecipitation
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_INSP_CMNT_TXT
INSERT INTO dbo.ICS_INSP_CMNT_TXT (
     [ICS_INSP_CMNT_TXT_ID]
   , [ICS_CMPL_MON_ID]
   , [INSP_CMNT_TXT]
   , [DATA_HASH])
SELECT 
     null  --ICS_INSP_CMNT_TXT_ID, 
   , null  --ICS_CMPL_MON_ID, 
   , null  --INSP_CMNT_TXT, InspectionCommentText
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_INSP_GOV_CONTACT
INSERT INTO dbo.ICS_INSP_GOV_CONTACT (
     [ICS_INSP_GOV_CONTACT_ID]
   , [ICS_CMPL_MON_ID]
   , [AFFIL_TYPE_TXT]
   , [ELEC_ADDR_TXT]
   , [DATA_HASH])
SELECT 
     null  --ICS_INSP_GOV_CONTACT_ID, 
   , null  --ICS_CMPL_MON_ID, 
   , null  --AFFIL_TYPE_TXT, AffiliationTypeText
   , null  --ELEC_ADDR_TXT, ElectronicAddressText
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_NAT_PRIO
INSERT INTO dbo.ICS_NAT_PRIO (
     [ICS_NAT_PRIO_ID]
   , [ICS_CMPL_MON_ID]
   , [NAT_PRIO_CODE]
   , [DATA_HASH])
SELECT 
     null  --ICS_NAT_PRIO_ID, 
   , null  --ICS_CMPL_MON_ID, 
   , null  --NAT_PRIO_CODE, NationalPrioritiesCode
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_PRETR_INSP
INSERT INTO dbo.ICS_PRETR_INSP (
     [ICS_PRETR_INSP_ID]
   , [ICS_CMPL_MON_ID]
   , [SUO_REF]
   , [SUO_DATE]
   , [ACCEPTANCE_HAZ_WASTE]
   , [ACCEPTANCE_NON_HAZ_INDST_WASTE]
   , [ACCEPTANCE_HULED_DOMSTIC_WSTES]
   , [ANNUL_PRETR_BUDGET]
   , [INADEQUACY_SMPL_INSP_IND]
   , [ADEQUACY_PRETR_RESOURCES]
   , [DFCNC_IDNTFD_DRNG_IU_FILE_RVIW]
   , [CONTROL_MECH_DFCNC]
   , [LEGAL_AUTH_DFCNC]
   , [DFCNC_INTRPRT_APPL_PRETR_STNDR]
   , [DFCNC_DAT_MGMT_PBLC_PRTICIPTON]
   , [VIOL_IU_SCHD_RMD_MSR]
   , [FRML_RSPN_VIOL_IU_SCHD_RMD_MSR]
   , [ANNUL_FREQ_INFLUNT_TOXCNT_SMPL]
   , [ANNUL_FREQ_EFFLU_TOXCNT_SMPL]
   , [ANNUL_FREQ_SLDG_TOXCNT_SMPL]
   , [NUM_SI_US]
   , [SI_US_WITHOUT_CONTROL_MECH]
   , [SI_US_NOT_INSPECTED]
   , [SI_US_NOT_SMPL]
   , [SI_US_ON_SCHD]
   , [SI_US_SNC_WITH_PRETR_STNDR]
   , [SI_US_SNC_WITH_REP_REQS]
   , [SI_US_SNC_WITH_PRETR_SCHD]
   , [SI_US_SNC_PUBL_NEWSPAPER]
   , [VIOL_NOTICES_ISSUED_SI_US]
   , [ADMIN_ORDERS_ISSUED_SI_US]
   , [CIVIL_SUTS_FILD_AGINST_SI_US]
   , [CRIMINL_SUTS_FILD_AGINST_SI_US]
   , [DOLLAR_AMT_PNLTY_COLL]
   , [I_US_WHC_PNLTY_HAV_BEE_COLL]
   , [NUM_CI_US]
   , [CI_US_IN_SNC]
   , [PASS_THROUGH_INTERFERENCE_IND]
   , [DATA_HASH])
SELECT 
     null  --ICS_PRETR_INSP_ID, 
   , null  --ICS_CMPL_MON_ID, 
   , null  --SUO_REF, SUOReference
   , null  --SUO_DATE, SUODate
   , null  --ACCEPTANCE_HAZ_WASTE, AcceptanceHazardousWaste
   , null  --ACCEPTANCE_NON_HAZ_INDST_WASTE, AcceptanceNonHazardousIndustrialWaste
   , null  --ACCEPTANCE_HULED_DOMSTIC_WSTES, AcceptanceHauledDomesticWastes
   , null  --ANNUL_PRETR_BUDGET, AnnualPretreatmentBudget
   , null  --INADEQUACY_SMPL_INSP_IND, InadequacySamplingInspectionIndicator
   , null  --ADEQUACY_PRETR_RESOURCES, AdequacyPretreatmentResources
   , null  --DFCNC_IDNTFD_DRNG_IU_FILE_RVIW, DeficienciesIdentifiedDuringIUFileReview
   , null  --CONTROL_MECH_DFCNC, ControlMechanismDeficiencies
   , null  --LEGAL_AUTH_DFCNC, LegalAuthorityDeficiencies
   , null  --DFCNC_INTRPRT_APPL_PRETR_STNDR, DeficienciesInterpretationApplicationPretreatmentStandards
   , null  --DFCNC_DAT_MGMT_PBLC_PRTICIPTON, DeficienciesDataManagementPublicParticipation
   , null  --VIOL_IU_SCHD_RMD_MSR, ViolationIUScheduleRemedialMeasures
   , null  --FRML_RSPN_VIOL_IU_SCHD_RMD_MSR, FormalResponseViolationIUScheduleRemedialMeasures
   , null  --ANNUL_FREQ_INFLUNT_TOXCNT_SMPL, AnnualFrequencyInfluentToxicantSampling
   , null  --ANNUL_FREQ_EFFLU_TOXCNT_SMPL, AnnualFrequencyEffluentToxicantSampling
   , null  --ANNUL_FREQ_SLDG_TOXCNT_SMPL, AnnualFrequencySludgeToxicantSampling
   , null  --NUM_SI_US, NumberSIUs
   , null  --SI_US_WITHOUT_CONTROL_MECH, SIUsWithoutControlMechanism
   , null  --SI_US_NOT_INSPECTED, SIUsNotInspected
   , null  --SI_US_NOT_SMPL, SIUsNotSampled
   , null  --SI_US_ON_SCHD, SIUsOnSchedule
   , null  --SI_US_SNC_WITH_PRETR_STNDR, SIUsSNCWithPretreatmentStandards
   , null  --SI_US_SNC_WITH_REP_REQS, SIUsSNCWithReportingRequirements
   , null  --SI_US_SNC_WITH_PRETR_SCHD, SIUsSNCWithPretreatmentSchedule
   , null  --SI_US_SNC_PUBL_NEWSPAPER, SIUsSNCPublishedNewspaper
   , null  --VIOL_NOTICES_ISSUED_SI_US, ViolationNoticesIssuedSIUs
   , null  --ADMIN_ORDERS_ISSUED_SI_US, AdministrativeOrdersIssuedSIUs
   , null  --CIVIL_SUTS_FILD_AGINST_SI_US, CivilSuitsFiledAgainstSIUs
   , null  --CRIMINL_SUTS_FILD_AGINST_SI_US, CriminalSuitsFiledAgainstSIUs
   , null  --DOLLAR_AMT_PNLTY_COLL, DollarAmountPenaltiesCollected
   , null  --I_US_WHC_PNLTY_HAV_BEE_COLL, IUsWhichPenaltiesHaveBeenCollected
   , null  --NUM_CI_US, NumberCIUs
   , null  --CI_US_IN_SNC, CIUsInSNC
   , null  --PASS_THROUGH_INTERFERENCE_IND, PassThroughInterferenceIndicator
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_PROG
INSERT INTO dbo.ICS_PROG (
     [ICS_PROG_ID]
   , [ICS_CMPL_MON_ID]
   , [PROG_CODE]
   , [DATA_HASH])
SELECT 
     null  --ICS_PROG_ID, 
   , null  --ICS_CMPL_MON_ID, 
   , null  --PROG_CODE, ProgramCode
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_PROG_DEFCY_TYPE
INSERT INTO dbo.ICS_PROG_DEFCY_TYPE (
     [ICS_PROG_DEFCY_TYPE_ID]
   , [ICS_CMPL_MON_ID]
   , [PROG_DEFCY_TYPE_CODE]
   , [DATA_HASH])
SELECT 
     null  --ICS_PROG_DEFCY_TYPE_ID, 
   , null  --ICS_CMPL_MON_ID, 
   , null  --PROG_DEFCY_TYPE_CODE, ProgramDeficiencyTypeCode
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_SSO_INSP
INSERT INTO dbo.ICS_SSO_INSP (
     [ICS_SSO_INSP_ID]
   , [ICS_CMPL_MON_ID]
   , [SSO_EVT_DATE]
   , [CAUSE_SSO_OVRFLW_EVT]
   , [LAT_MEAS]
   , [LONG_MEAS]
   , [SSO_OVRFLW_LOC_STREET]
   , [DURATION_SSO_OVRFLW_EVT]
   , [SSO_VOL]
   , [NAME_RCVG_WTR]
   , [DESC_STPS_TAKEN]
   , [DATA_HASH])
SELECT 
     null  --ICS_SSO_INSP_ID, 
   , null  --ICS_CMPL_MON_ID, 
   , null  --SSO_EVT_DATE, SSOEventDate
   , null  --CAUSE_SSO_OVRFLW_EVT, CauseSSOOverflowEvent
   , null  --LAT_MEAS, LatitudeMeasure
   , null  --LONG_MEAS, LongitudeMeasure
   , null  --SSO_OVRFLW_LOC_STREET, SSOOverflowLocationStreet
   , null  --DURATION_SSO_OVRFLW_EVT, DurationSSOOverflowEvent
   , null  --SSO_VOL, SSOVolume
   , null  --NAME_RCVG_WTR, NameReceivingWater
   , null  --DESC_STPS_TAKEN, DescriptionStepsTaken
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_SSO_INSP/ICS_IMPACT_SSO_EVT
INSERT INTO dbo.ICS_IMPACT_SSO_EVT (
     [ICS_IMPACT_SSO_EVT_ID]
   , [ICS_SSO_INSP_ID]
   , [IMPACT_SSO_EVT]
   , [DATA_HASH])
SELECT 
     null  --ICS_IMPACT_SSO_EVT_ID, 
   , null  --ICS_SSO_INSP_ID, 
   , null  --IMPACT_SSO_EVT, ImpactSSOEvent
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_SSO_INSP/ICS_SSO_STPS
INSERT INTO dbo.ICS_SSO_STPS (
     [ICS_SSO_STPS_ID]
   , [ICS_SSO_INSP_ID]
   , [STPS_RDUCE_PREVNT_MITIGTE]
   , [OTHR_STPS_RDUCE_PREVNT_MITIGTE]
   , [DATA_HASH])
SELECT 
     null  --ICS_SSO_STPS_ID, 
   , null  --ICS_SSO_INSP_ID, 
   , null  --STPS_RDUCE_PREVNT_MITIGTE, StepsReducePreventMitigate
   , null  --OTHR_STPS_RDUCE_PREVNT_MITIGTE, OtherStepsReducePreventMitigate
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_SSO_INSP/ICS_SSO_SYSTM_COMP
INSERT INTO dbo.ICS_SSO_SYSTM_COMP (
     [ICS_SSO_SYSTM_COMP_ID]
   , [ICS_SSO_INSP_ID]
   , [SYSTM_COMP]
   , [OTHR_SYSTM_COMP]
   , [DATA_HASH])
SELECT 
     null  --ICS_SSO_SYSTM_COMP_ID, 
   , null  --ICS_SSO_INSP_ID, 
   , null  --SYSTM_COMP, SystemComponent
   , null  --OTHR_SYSTM_COMP, OtherSystemComponent
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_SW_CNST_INSP
INSERT INTO dbo.ICS_SW_CNST_INSP (
     [ICS_SW_CNST_INSP_ID]
   , [ICS_CMPL_MON_ID]
   , [DATA_HASH])
SELECT 
     null  --ICS_SW_CNST_INSP_ID, 
   , null  --ICS_CMPL_MON_ID, 
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_SW_CNST_INSP/ICS_SW_CNST_INDST_INSP
INSERT INTO dbo.ICS_SW_CNST_INDST_INSP (
     [ICS_SW_CNST_INDST_INSP_ID]
   , [ICS_SW_CNST_INSP_ID]
   , [ICS_SW_CNST_NON_CNST_INSP_ID]
   , [ICS_SW_NON_CNST_INSP_ID]
   , [SWPPP_EVAL_BASIS_CODE]
   , [SWPPP_EVAL_DATE]
   , [SWPPP_EVAL_DESC_TXT]
   , [NO_EXPOSURE_AUTH_DATE]
   , [DATA_HASH])
SELECT 
     null  --ICS_SW_CNST_INDST_INSP_ID, 
   , null  --ICS_SW_CNST_INSP_ID, 
   , null  --ICS_SW_CNST_NON_CNST_INSP_ID, 
   , null  --ICS_SW_NON_CNST_INSP_ID, 
   , null  --SWPPP_EVAL_BASIS_CODE, SWPPPEvaluationBasisCode
   , null  --SWPPP_EVAL_DATE, SWPPPEvaluationDate
   , null  --SWPPP_EVAL_DESC_TXT, SWPPPEvaluationDescriptionText
   , null  --NO_EXPOSURE_AUTH_DATE, NoExposureAuthorizationDate
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_SW_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP
INSERT INTO dbo.ICS_SW_UNPRMT_CNST_INSP (
     [ICS_SW_UNPRMT_CNST_INSP_ID]
   , [ICS_SW_CNST_INSP_ID]
   , [ICS_SW_CNST_NON_CNST_INSP_ID]
   , [ICS_SW_NON_CNST_INSP_ID]
   , [EST_START_DATE]
   , [EST_COMPLETE_DATE]
   , [EST_AREA_DISTURBED_ACRES_NUM]
   , [PROJ_PLAN_SIZE_CODE]
   , [DATA_HASH])
SELECT 
     null  --ICS_SW_UNPRMT_CNST_INSP_ID, 
   , null  --ICS_SW_CNST_INSP_ID, 
   , null  --ICS_SW_CNST_NON_CNST_INSP_ID, 
   , null  --ICS_SW_NON_CNST_INSP_ID, 
   , null  --EST_START_DATE, EstimatedStartDate
   , null  --EST_COMPLETE_DATE, EstimatedCompleteDate
   , null  --EST_AREA_DISTURBED_ACRES_NUM, EstimatedAreaDisturbedAcresNumber
   , null  --PROJ_PLAN_SIZE_CODE, ProjectPlanSizeCode
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_SW_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP/ICS_PROJ_TYPE
INSERT INTO dbo.ICS_PROJ_TYPE (
     [ICS_PROJ_TYPE_ID]
   , [ICS_SW_UNPRMT_CNST_INSP_ID]
   , [PROJ_TYPE_CODE]
   , [PROJ_TYPE_CODE_OTHR_DESC]
   , [DATA_HASH])
SELECT 
     null  --ICS_PROJ_TYPE_ID, 
   , null  --ICS_SW_UNPRMT_CNST_INSP_ID, 
   , null  --PROJ_TYPE_CODE, ProjectTypeCode
   , null  --PROJ_TYPE_CODE_OTHR_DESC, ProjectTypeCodeOtherDescription
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_SW_CNST_NON_CNST_INSP
INSERT INTO dbo.ICS_SW_CNST_NON_CNST_INSP (
     [ICS_SW_CNST_NON_CNST_INSP_ID]
   , [ICS_CMPL_MON_ID]
   , [DATA_HASH])
SELECT 
     null  --ICS_SW_CNST_NON_CNST_INSP_ID, 
   , null  --ICS_CMPL_MON_ID, 
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_SW_CNST_NON_CNST_INSP/ICS_SW_CNST_INDST_INSP
INSERT INTO dbo.ICS_SW_CNST_INDST_INSP (
     [ICS_SW_CNST_INDST_INSP_ID]
   , [ICS_SW_CNST_INSP_ID]
   , [ICS_SW_CNST_NON_CNST_INSP_ID]
   , [ICS_SW_NON_CNST_INSP_ID]
   , [SWPPP_EVAL_BASIS_CODE]
   , [SWPPP_EVAL_DATE]
   , [SWPPP_EVAL_DESC_TXT]
   , [NO_EXPOSURE_AUTH_DATE]
   , [DATA_HASH])
SELECT 
     null  --ICS_SW_CNST_INDST_INSP_ID, 
   , null  --ICS_SW_CNST_INSP_ID, 
   , null  --ICS_SW_CNST_NON_CNST_INSP_ID, 
   , null  --ICS_SW_NON_CNST_INSP_ID, 
   , null  --SWPPP_EVAL_BASIS_CODE, SWPPPEvaluationBasisCode
   , null  --SWPPP_EVAL_DATE, SWPPPEvaluationDate
   , null  --SWPPP_EVAL_DESC_TXT, SWPPPEvaluationDescriptionText
   , null  --NO_EXPOSURE_AUTH_DATE, NoExposureAuthorizationDate
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_SW_CNST_NON_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP
INSERT INTO dbo.ICS_SW_UNPRMT_CNST_INSP (
     [ICS_SW_UNPRMT_CNST_INSP_ID]
   , [ICS_SW_CNST_INSP_ID]
   , [ICS_SW_CNST_NON_CNST_INSP_ID]
   , [ICS_SW_NON_CNST_INSP_ID]
   , [EST_START_DATE]
   , [EST_COMPLETE_DATE]
   , [EST_AREA_DISTURBED_ACRES_NUM]
   , [PROJ_PLAN_SIZE_CODE]
   , [DATA_HASH])
SELECT 
     null  --ICS_SW_UNPRMT_CNST_INSP_ID, 
   , null  --ICS_SW_CNST_INSP_ID, 
   , null  --ICS_SW_CNST_NON_CNST_INSP_ID, 
   , null  --ICS_SW_NON_CNST_INSP_ID, 
   , null  --EST_START_DATE, EstimatedStartDate
   , null  --EST_COMPLETE_DATE, EstimatedCompleteDate
   , null  --EST_AREA_DISTURBED_ACRES_NUM, EstimatedAreaDisturbedAcresNumber
   , null  --PROJ_PLAN_SIZE_CODE, ProjectPlanSizeCode
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_SW_CNST_NON_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP/ICS_PROJ_TYPE
INSERT INTO dbo.ICS_PROJ_TYPE (
     [ICS_PROJ_TYPE_ID]
   , [ICS_SW_UNPRMT_CNST_INSP_ID]
   , [PROJ_TYPE_CODE]
   , [PROJ_TYPE_CODE_OTHR_DESC]
   , [DATA_HASH])
SELECT 
     null  --ICS_PROJ_TYPE_ID, 
   , null  --ICS_SW_UNPRMT_CNST_INSP_ID, 
   , null  --PROJ_TYPE_CODE, ProjectTypeCode
   , null  --PROJ_TYPE_CODE_OTHR_DESC, ProjectTypeCodeOtherDescription
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_SW_MS_4_INSP
INSERT INTO dbo.ICS_SW_MS_4_INSP (
     [ICS_SW_MS_4_INSP_ID]
   , [ICS_CMPL_MON_ID]
   , [MS_4_ANNUL_EXPEN_DOLLARS]
   , [MS_4_ANNUL_EXPEN_YEAR]
   , [MS_4_BUDGET_DOLLARS]
   , [MS_4_BUDGET_YEAR]
   , [MAJOR_OUTFALL_EST_MEAS_IND]
   , [MAJOR_OUTFALL_NUM]
   , [MINOR_OUTFALL_EST_MEAS_IND]
   , [MINOR_OUTFALL_NUM]
   , [DATA_HASH])
SELECT 
     null  --ICS_SW_MS_4_INSP_ID, 
   , null  --ICS_CMPL_MON_ID, 
   , null  --MS_4_ANNUL_EXPEN_DOLLARS, MS4AnnualExpenditureDollars
   , null  --MS_4_ANNUL_EXPEN_YEAR, MS4AnnualExpenditureYear
   , null  --MS_4_BUDGET_DOLLARS, MS4BudgetDollars
   , null  --MS_4_BUDGET_YEAR, MS4BudgetYear
   , null  --MAJOR_OUTFALL_EST_MEAS_IND, MajorOutfallEstimatedMeasureIndicator
   , null  --MAJOR_OUTFALL_NUM, MajorOutfallNumber
   , null  --MINOR_OUTFALL_EST_MEAS_IND, MinorOutfallEstimatedMeasureIndicator
   , null  --MINOR_OUTFALL_NUM, MinorOutfallNumber
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_SW_MS_4_INSP/ICS_PROJ_SRCS_FUND
INSERT INTO dbo.ICS_PROJ_SRCS_FUND (
     [ICS_PROJ_SRCS_FUND_ID]
   , [ICS_SW_MS_4_INSP_ID]
   , [PROJ_SRCS_FUND_CODE]
   , [DATA_HASH])
SELECT 
     null  --ICS_PROJ_SRCS_FUND_ID, 
   , null  --ICS_SW_MS_4_INSP_ID, 
   , null  --PROJ_SRCS_FUND_CODE, ProjectedSourcesFundingCode
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_SW_NON_CNST_INSP
INSERT INTO dbo.ICS_SW_NON_CNST_INSP (
     [ICS_SW_NON_CNST_INSP_ID]
   , [ICS_CMPL_MON_ID]
   , [DATA_HASH])
SELECT 
     null  --ICS_SW_NON_CNST_INSP_ID, 
   , null  --ICS_CMPL_MON_ID, 
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_SW_NON_CNST_INSP/ICS_SW_CNST_INDST_INSP
INSERT INTO dbo.ICS_SW_CNST_INDST_INSP (
     [ICS_SW_CNST_INDST_INSP_ID]
   , [ICS_SW_CNST_INSP_ID]
   , [ICS_SW_CNST_NON_CNST_INSP_ID]
   , [ICS_SW_NON_CNST_INSP_ID]
   , [SWPPP_EVAL_BASIS_CODE]
   , [SWPPP_EVAL_DATE]
   , [SWPPP_EVAL_DESC_TXT]
   , [NO_EXPOSURE_AUTH_DATE]
   , [DATA_HASH])
SELECT 
     null  --ICS_SW_CNST_INDST_INSP_ID, 
   , null  --ICS_SW_CNST_INSP_ID, 
   , null  --ICS_SW_CNST_NON_CNST_INSP_ID, 
   , null  --ICS_SW_NON_CNST_INSP_ID, 
   , null  --SWPPP_EVAL_BASIS_CODE, SWPPPEvaluationBasisCode
   , null  --SWPPP_EVAL_DATE, SWPPPEvaluationDate
   , null  --SWPPP_EVAL_DESC_TXT, SWPPPEvaluationDescriptionText
   , null  --NO_EXPOSURE_AUTH_DATE, NoExposureAuthorizationDate
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_SW_NON_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP
INSERT INTO dbo.ICS_SW_UNPRMT_CNST_INSP (
     [ICS_SW_UNPRMT_CNST_INSP_ID]
   , [ICS_SW_CNST_INSP_ID]
   , [ICS_SW_CNST_NON_CNST_INSP_ID]
   , [ICS_SW_NON_CNST_INSP_ID]
   , [EST_START_DATE]
   , [EST_COMPLETE_DATE]
   , [EST_AREA_DISTURBED_ACRES_NUM]
   , [PROJ_PLAN_SIZE_CODE]
   , [DATA_HASH])
SELECT 
     null  --ICS_SW_UNPRMT_CNST_INSP_ID, 
   , null  --ICS_SW_CNST_INSP_ID, 
   , null  --ICS_SW_CNST_NON_CNST_INSP_ID, 
   , null  --ICS_SW_NON_CNST_INSP_ID, 
   , null  --EST_START_DATE, EstimatedStartDate
   , null  --EST_COMPLETE_DATE, EstimatedCompleteDate
   , null  --EST_AREA_DISTURBED_ACRES_NUM, EstimatedAreaDisturbedAcresNumber
   , null  --PROJ_PLAN_SIZE_CODE, ProjectPlanSizeCode
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON/ICS_SW_NON_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP/ICS_PROJ_TYPE
INSERT INTO dbo.ICS_PROJ_TYPE (
     [ICS_PROJ_TYPE_ID]
   , [ICS_SW_UNPRMT_CNST_INSP_ID]
   , [PROJ_TYPE_CODE]
   , [PROJ_TYPE_CODE_OTHR_DESC]
   , [DATA_HASH])
SELECT 
     null  --ICS_PROJ_TYPE_ID, 
   , null  --ICS_SW_UNPRMT_CNST_INSP_ID, 
   , null  --PROJ_TYPE_CODE, ProjectTypeCode
   , null  --PROJ_TYPE_CODE_OTHR_DESC, ProjectTypeCodeOtherDescription
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

END;
