﻿
/*************************************************************************************************
** ObjectName: ics_etl_PermitTermination
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the PermitTerminationSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/18/2025   Windsor      Created 
**
***************************************************************************************************/
CREATE OR ALTER PROCEDURE dbo.ics_etl_PermitTermination

AS

BEGIN
---------------------------- 
-- ICS_PRMT_TERM
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- /ICS_PRMT_TERM
DELETE
  FROM dbo.ICS_PRMT_TERM;


-- /ICS_PRMT_TERM
INSERT INTO dbo.ICS_PRMT_TERM (
     [ICS_PRMT_TERM_ID]
   , [ICS_PAYLOAD_ID]
   , [SRC_SYSTM_IDENT]
   , [TRANSACTION_TYPE]
   , [TRANSACTION_TIMESTAMP]
   , [PRMT_IDENT]
   , [PRMT_TERM_DATE]
   , [KEY_HASH]
   , [DATA_HASH])
SELECT 
     null  --ICS_PRMT_TERM_ID, 
   , null  --ICS_PAYLOAD_ID, 
   , null  --SRC_SYSTM_IDENT, SourceSystemIdentifier
   , null  --TRANSACTION_TYPE, TransactionType
   , null  --TRANSACTION_TIMESTAMP, TransactionTimestamp
   , null  --PRMT_IDENT, PermitIdentifier
   , null  --PRMT_TERM_DATE, PermitTerminationDate
   , null  --KEY_HASH, 
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

END;
