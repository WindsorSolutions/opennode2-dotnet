The SQL Server staging setup has two possible configurations.
 - Explicit Database: This is the original configuration using two databases that must be named ICS_FLOW_LOCAL and ICS_FLOW_ICIS respectively.  Files include the 'SQL' prefix.
 - Explicit Schema: This is the new configuration where the database can have any name, but two schemas named ICS_FLOW_LOCAL and ICS_FLOW_ICIS are used. This also requires that the node login for the db have a default schema of ICS_FLOW_LOCAL.
