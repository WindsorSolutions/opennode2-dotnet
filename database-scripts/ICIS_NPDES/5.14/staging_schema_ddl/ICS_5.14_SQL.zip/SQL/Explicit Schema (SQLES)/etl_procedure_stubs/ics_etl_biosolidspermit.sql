﻿
/*************************************************************************************************
** ObjectName: ics_etl_BiosolidsPermit
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the BiosolidsPermitSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/18/2025   Windsor      Created 
**
***************************************************************************************************/
CREATE OR ALTER PROCEDURE ics_flow_local.ics_etl_BiosolidsPermit

AS

BEGIN
---------------------------- 
-- ICS_BS_PRMT
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- /ICS_BS_PRMT/ICS_PRMT_BS_MGMT_PRACTICE/ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR/ICS_ADDR/ICS_TELEPH
DELETE
  FROM ics_flow_local.ICS_TELEPH
 WHERE ICS_ADDR_ID IN
          (SELECT ICS_ADDR.ICS_ADDR_ID
             FROM ics_flow_local.ICS_BS_PRMT
                  JOIN ics_flow_local.ICS_PRMT_BS_MGMT_PRACTICE ON ICS_PRMT_BS_MGMT_PRACTICE.ICS_BS_PRMT_id = ICS_BS_PRMT.ICS_BS_PRMT_id
                  JOIN ics_flow_local.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR ON ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR.ICS_PRMT_BS_MGMT_PRACTICE_id = ICS_PRMT_BS_MGMT_PRACTICE.ICS_PRMT_BS_MGMT_PRACTICE_id
                  JOIN ics_flow_local.ICS_ADDR ON ICS_ADDR.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_id = ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_id
          );

-- /ICS_BS_PRMT/ICS_PRMT_BS_MGMT_PRACTICE/ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR/ICS_CONTACT/ICS_TELEPH
DELETE
  FROM ics_flow_local.ICS_TELEPH
 WHERE ICS_CONTACT_ID IN
          (SELECT ICS_CONTACT.ICS_CONTACT_ID
             FROM ics_flow_local.ICS_BS_PRMT
                  JOIN ics_flow_local.ICS_PRMT_BS_MGMT_PRACTICE ON ICS_PRMT_BS_MGMT_PRACTICE.ICS_BS_PRMT_id = ICS_BS_PRMT.ICS_BS_PRMT_id
                  JOIN ics_flow_local.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR ON ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR.ICS_PRMT_BS_MGMT_PRACTICE_id = ICS_PRMT_BS_MGMT_PRACTICE.ICS_PRMT_BS_MGMT_PRACTICE_id
                  JOIN ics_flow_local.ICS_CONTACT ON ICS_CONTACT.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_id = ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_id
          );

-- /ICS_BS_PRMT/ICS_PRMT_BS_MGMT_PRACTICE/ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR/ICS_ADDR
DELETE
  FROM ics_flow_local.ICS_ADDR
 WHERE ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID IN
          (SELECT ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID
             FROM ics_flow_local.ICS_BS_PRMT
                  JOIN ics_flow_local.ICS_PRMT_BS_MGMT_PRACTICE ON ICS_PRMT_BS_MGMT_PRACTICE.ICS_BS_PRMT_id = ICS_BS_PRMT.ICS_BS_PRMT_id
                  JOIN ics_flow_local.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR ON ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR.ICS_PRMT_BS_MGMT_PRACTICE_id = ICS_PRMT_BS_MGMT_PRACTICE.ICS_PRMT_BS_MGMT_PRACTICE_id
          );

-- /ICS_BS_PRMT/ICS_PRMT_BS_MGMT_PRACTICE/ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR/ICS_CONTACT
DELETE
  FROM ics_flow_local.ICS_CONTACT
 WHERE ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID IN
          (SELECT ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID
             FROM ics_flow_local.ICS_BS_PRMT
                  JOIN ics_flow_local.ICS_PRMT_BS_MGMT_PRACTICE ON ICS_PRMT_BS_MGMT_PRACTICE.ICS_BS_PRMT_id = ICS_BS_PRMT.ICS_BS_PRMT_id
                  JOIN ics_flow_local.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR ON ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR.ICS_PRMT_BS_MGMT_PRACTICE_id = ICS_PRMT_BS_MGMT_PRACTICE.ICS_PRMT_BS_MGMT_PRACTICE_id
          );

-- /ICS_BS_PRMT/ICS_PRMT_BS_MGMT_PRACTICE/ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR
DELETE
  FROM ics_flow_local.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR
 WHERE ICS_PRMT_BS_MGMT_PRACTICE_ID IN
          (SELECT ICS_PRMT_BS_MGMT_PRACTICE.ICS_PRMT_BS_MGMT_PRACTICE_ID
             FROM ics_flow_local.ICS_BS_PRMT
                  JOIN ics_flow_local.ICS_PRMT_BS_MGMT_PRACTICE ON ICS_PRMT_BS_MGMT_PRACTICE.ICS_BS_PRMT_id = ICS_BS_PRMT.ICS_BS_PRMT_id
          );

-- /ICS_BS_PRMT/ICS_PRMT_BS_MGMT_PRACTICE/ICS_PATHOGEN_REDUCTION_TYPE
DELETE
  FROM ics_flow_local.ICS_PATHOGEN_REDUCTION_TYPE
 WHERE ICS_PRMT_BS_MGMT_PRACTICE_ID IN
          (SELECT ICS_PRMT_BS_MGMT_PRACTICE.ICS_PRMT_BS_MGMT_PRACTICE_ID
             FROM ics_flow_local.ICS_BS_PRMT
                  JOIN ics_flow_local.ICS_PRMT_BS_MGMT_PRACTICE ON ICS_PRMT_BS_MGMT_PRACTICE.ICS_BS_PRMT_id = ICS_BS_PRMT.ICS_BS_PRMT_id
          );

-- /ICS_BS_PRMT/ICS_PRMT_BS_MGMT_PRACTICE/ICS_VECTOR_A_REDUCTION_TYPE
DELETE
  FROM ics_flow_local.ICS_VECTOR_A_REDUCTION_TYPE
 WHERE ICS_PRMT_BS_MGMT_PRACTICE_ID IN
          (SELECT ICS_PRMT_BS_MGMT_PRACTICE.ICS_PRMT_BS_MGMT_PRACTICE_ID
             FROM ics_flow_local.ICS_BS_PRMT
                  JOIN ics_flow_local.ICS_PRMT_BS_MGMT_PRACTICE ON ICS_PRMT_BS_MGMT_PRACTICE.ICS_BS_PRMT_id = ICS_BS_PRMT.ICS_BS_PRMT_id
          );

-- /ICS_BS_PRMT/ICS_BS_FAC_TRTMNT
DELETE
  FROM ics_flow_local.ICS_BS_FAC_TRTMNT
 WHERE ICS_BS_PRMT_ID IN
          (SELECT ICS_BS_PRMT.ICS_BS_PRMT_ID
             FROM ics_flow_local.ICS_BS_PRMT
          );

-- /ICS_BS_PRMT/ICS_BS_FAC_TYPE
DELETE
  FROM ics_flow_local.ICS_BS_FAC_TYPE
 WHERE ICS_BS_PRMT_ID IN
          (SELECT ICS_BS_PRMT.ICS_BS_PRMT_ID
             FROM ics_flow_local.ICS_BS_PRMT
          );

-- /ICS_BS_PRMT/ICS_PRMT_BS_MGMT_PRACTICE
DELETE
  FROM ics_flow_local.ICS_PRMT_BS_MGMT_PRACTICE
 WHERE ICS_BS_PRMT_ID IN
          (SELECT ICS_BS_PRMT.ICS_BS_PRMT_ID
             FROM ics_flow_local.ICS_BS_PRMT
          );

-- /ICS_BS_PRMT
DELETE
  FROM ics_flow_local.ICS_BS_PRMT;


-- /ICS_BS_PRMT
INSERT INTO ics_flow_local.ICS_BS_PRMT (
     [ICS_BS_PRMT_ID]
   , [ICS_PAYLOAD_ID]
   , [SRC_SYSTM_IDENT]
   , [TRANSACTION_TYPE]
   , [TRANSACTION_TIMESTAMP]
   , [PRMT_IDENT]
   , [BS_FAC_TYPE_OTHR_TXT]
   , [BS_FAC_TTL_VOL_AMT]
   , [BS_FAC_TRTMNT_OTHR_TXT]
   , [KEY_HASH]
   , [DATA_HASH])
SELECT 
     null  --ICS_BS_PRMT_ID, 
   , null  --ICS_PAYLOAD_ID, 
   , null  --SRC_SYSTM_IDENT, SourceSystemIdentifier
   , null  --TRANSACTION_TYPE, TransactionType
   , null  --TRANSACTION_TIMESTAMP, TransactionTimestamp
   , null  --PRMT_IDENT, PermitIdentifier
   , null  --BS_FAC_TYPE_OTHR_TXT, BiosolidsFacilityTypeOtherText
   , null  --BS_FAC_TTL_VOL_AMT, BiosolidsFacilityTotalVolumeAmount
   , null  --BS_FAC_TRTMNT_OTHR_TXT, BiosolidsFacilityTreatmentOtherText
   , null  --KEY_HASH, 
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_BS_PRMT/ICS_BS_FAC_TRTMNT
INSERT INTO ics_flow_local.ICS_BS_FAC_TRTMNT (
     [ICS_BS_FAC_TRTMNT_ID]
   , [ICS_BS_ANNUL_PROG_REP_ID]
   , [ICS_BS_PRMT_ID]
   , [BS_FAC_TRTMNT_CODE]
   , [DATA_HASH])
SELECT 
     null  --ICS_BS_FAC_TRTMNT_ID, 
   , null  --ICS_BS_ANNUL_PROG_REP_ID, 
   , null  --ICS_BS_PRMT_ID, 
   , null  --BS_FAC_TRTMNT_CODE, BiosolidsFacilityTreatmentCode
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_BS_PRMT/ICS_BS_FAC_TYPE
INSERT INTO ics_flow_local.ICS_BS_FAC_TYPE (
     [ICS_BS_FAC_TYPE_ID]
   , [ICS_BS_ANNUL_PROG_REP_ID]
   , [ICS_BS_PRMT_ID]
   , [BS_FAC_TYPE_CODE]
   , [DATA_HASH])
SELECT 
     null  --ICS_BS_FAC_TYPE_ID, 
   , null  --ICS_BS_ANNUL_PROG_REP_ID, 
   , null  --ICS_BS_PRMT_ID, 
   , null  --BS_FAC_TYPE_CODE, BiosolidsFacilityTypeCode
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_BS_PRMT/ICS_PRMT_BS_MGMT_PRACTICE
INSERT INTO ics_flow_local.ICS_PRMT_BS_MGMT_PRACTICE (
     [ICS_PRMT_BS_MGMT_PRACTICE_ID]
   , [ICS_BS_PRMT_ID]
   , [SSU_IDENT]
   , [BS_MGMT_PRACTICE_CODE]
   , [BS_MGMT_PRACTICE_SUB_CATG_CODE]
   , [BS_MGMT_PRACTICE_SUB_CATG_TXT]
   , [BS_OPERATOR_TYPE_CODE]
   , [BS_CNTNR_TYPE_CODE]
   , [SSUID_VOL_AMT]
   , [PATHOGEN_CLASS_TYPE_CODE]
   , [POLUT_LOADING_RATES_EXCEEDANCE_IND]
   , [SURF_DSPL_WITHOUT_LINER_IND]
   , [SURF_DSPL_SITE_SPEC_LMT_IND]
   , [SURF_DSPL_MIN_BOUNDARY_DISTANCE_CODE]
   , [BS_OFF_SITE_FAC_PRMT_IDENT]
   , [DATA_HASH])
SELECT 
     null  --ICS_PRMT_BS_MGMT_PRACTICE_ID, 
   , null  --ICS_BS_PRMT_ID, 
   , null  --SSU_IDENT, SSUIdentifier
   , null  --BS_MGMT_PRACTICE_CODE, BiosolidsManagementPracticeCode
   , null  --BS_MGMT_PRACTICE_SUB_CATG_CODE, BiosolidsManagementPracticeSubCategoryCode
   , null  --BS_MGMT_PRACTICE_SUB_CATG_TXT, BiosolidsManagementPracticeSubCategoryText
   , null  --BS_OPERATOR_TYPE_CODE, BiosolidsOperatorTypeCode
   , null  --BS_CNTNR_TYPE_CODE, BiosolidsContainerTypeCode
   , null  --SSUID_VOL_AMT, SSUIDVolumeAmount
   , null  --PATHOGEN_CLASS_TYPE_CODE, PathogenClassTypeCode
   , null  --POLUT_LOADING_RATES_EXCEEDANCE_IND, PollutantLoadingRatesExceedanceIndicator
   , null  --SURF_DSPL_WITHOUT_LINER_IND, SurfaceDisposalWithoutLinerIndicator
   , null  --SURF_DSPL_SITE_SPEC_LMT_IND, SurfaceDisposalSiteSpecificLimitIndicator
   , null  --SURF_DSPL_MIN_BOUNDARY_DISTANCE_CODE, SurfaceDisposalMinimumBoundaryDistanceCode
   , null  --BS_OFF_SITE_FAC_PRMT_IDENT, BiosolidsOffSiteFacilityPermitIdentifier
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_BS_PRMT/ICS_PRMT_BS_MGMT_PRACTICE/ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR
INSERT INTO ics_flow_local.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR (
     [ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID]
   , [ICS_BS_MGMT_PRACTICE_ID]
   , [ICS_PRMT_BS_MGMT_PRACTICE_ID]
   , [BS_OFF_SITE_HNDLR_APPLIER_VOL_AMT]
   , [DATA_HASH])
SELECT 
     null  --ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID, 
   , null  --ICS_BS_MGMT_PRACTICE_ID, 
   , null  --ICS_PRMT_BS_MGMT_PRACTICE_ID, 
   , null  --BS_OFF_SITE_HNDLR_APPLIER_VOL_AMT, BiosolidsOffSiteHandlerApplierVolumeAmount
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_BS_PRMT/ICS_PRMT_BS_MGMT_PRACTICE/ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR/ICS_ADDR
INSERT INTO ics_flow_local.ICS_ADDR (
     [ICS_ADDR_ID]
   , [ICS_FAC_ID]
   , [ICS_BASIC_PRMT_ID]
   , [ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID]
   , [ICS_CAFO_PRMT_ID]
   , [ICS_GNRL_PRMT_ID]
   , [ICS_PRMT_FEATR_ID]
   , [ICS_SW_CNST_PRMT_ID]
   , [ICS_SW_INDST_PRMT_ID]
   , [ICS_UNPRMT_FAC_ID]
   , [AFFIL_TYPE_TXT]
   , [ORG_FRML_NAME]
   , [ORG_DUNS_NUM]
   , [MAILING_ADDR_TXT]
   , [SUPPL_ADDR_TXT]
   , [MAILING_ADDR_CITY_NAME]
   , [MAILING_ADDR_ST_CODE]
   , [MAILING_ADDR_ZIP_CODE]
   , [COUNTY_NAME]
   , [MAILING_ADDR_COUNTRY_CODE]
   , [DIVISION_NAME]
   , [LOC_PROVINCE]
   , [ELEC_ADDR_TXT]
   , [START_DATE_OF_ADDR_ASSC]
   , [END_DATE_OF_ADDR_ASSC]
   , [DATA_HASH])
SELECT 
     null  --ICS_ADDR_ID, 
   , null  --ICS_FAC_ID, 
   , null  --ICS_BASIC_PRMT_ID, 
   , null  --ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID, 
   , null  --ICS_CAFO_PRMT_ID, 
   , null  --ICS_GNRL_PRMT_ID, 
   , null  --ICS_PRMT_FEATR_ID, 
   , null  --ICS_SW_CNST_PRMT_ID, 
   , null  --ICS_SW_INDST_PRMT_ID, 
   , null  --ICS_UNPRMT_FAC_ID, 
   , null  --AFFIL_TYPE_TXT, AffiliationTypeText
   , null  --ORG_FRML_NAME, OrganizationFormalName
   , null  --ORG_DUNS_NUM, OrganizationDUNSNumber
   , null  --MAILING_ADDR_TXT, MailingAddressText
   , null  --SUPPL_ADDR_TXT, SupplementalAddressText
   , null  --MAILING_ADDR_CITY_NAME, MailingAddressCityName
   , null  --MAILING_ADDR_ST_CODE, MailingAddressStateCode
   , null  --MAILING_ADDR_ZIP_CODE, MailingAddressZipCode
   , null  --COUNTY_NAME, CountyName
   , null  --MAILING_ADDR_COUNTRY_CODE, MailingAddressCountryCode
   , null  --DIVISION_NAME, DivisionName
   , null  --LOC_PROVINCE, LocationProvince
   , null  --ELEC_ADDR_TXT, ElectronicAddressText
   , null  --START_DATE_OF_ADDR_ASSC, StartDateOfAddressAssociation
   , null  --END_DATE_OF_ADDR_ASSC, EndDateOfAddressAssociation
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_BS_PRMT/ICS_PRMT_BS_MGMT_PRACTICE/ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR/ICS_ADDR/ICS_TELEPH
INSERT INTO ics_flow_local.ICS_TELEPH (
     [ICS_TELEPH_ID]
   , [ICS_CONTACT_ID]
   , [ICS_ADDR_ID]
   , [ICS_EFFLU_TRADE_PRTNER_ADDR_ID]
   , [TELEPH_NUM_TYPE_CODE]
   , [TELEPH_NUM]
   , [TELEPH_EXT_NUM]
   , [DATA_HASH])
SELECT 
     null  --ICS_TELEPH_ID, 
   , null  --ICS_CONTACT_ID, 
   , null  --ICS_ADDR_ID, 
   , null  --ICS_EFFLU_TRADE_PRTNER_ADDR_ID, 
   , null  --TELEPH_NUM_TYPE_CODE, TelephoneNumberTypeCode
   , null  --TELEPH_NUM, TelephoneNumber
   , null  --TELEPH_EXT_NUM, TelephoneExtensionNumber
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_BS_PRMT/ICS_PRMT_BS_MGMT_PRACTICE/ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR/ICS_CONTACT
INSERT INTO ics_flow_local.ICS_CONTACT (
     [ICS_CONTACT_ID]
   , [ICS_FAC_ID]
   , [ICS_BASIC_PRMT_ID]
   , [ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID]
   , [ICS_CAFO_PRMT_ID]
   , [ICS_CMPL_MON_ID]
   , [ICS_GNRL_PRMT_ID]
   , [ICS_MASTER_GNRL_PRMT_ID]
   , [ICS_PRMT_FEATR_ID]
   , [ICS_PRETR_PRMT_ID]
   , [ICS_SW_CNST_PRMT_ID]
   , [ICS_SW_INDST_PRMT_ID]
   , [ICS_UNPRMT_FAC_ID]
   , [AFFIL_TYPE_TXT]
   , [FIRST_NAME]
   , [MIDDLE_NAME]
   , [LAST_NAME]
   , [INDVL_TITLE_TXT]
   , [ORG_FRML_NAME]
   , [ST_CODE]
   , [RGN_CODE]
   , [ELEC_ADDR_TXT]
   , [START_DATE_OF_CONTACT_ASSC]
   , [END_DATE_OF_CONTACT_ASSC]
   , [DATA_HASH])
SELECT 
     null  --ICS_CONTACT_ID, 
   , null  --ICS_FAC_ID, 
   , null  --ICS_BASIC_PRMT_ID, 
   , null  --ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID, 
   , null  --ICS_CAFO_PRMT_ID, 
   , null  --ICS_CMPL_MON_ID, 
   , null  --ICS_GNRL_PRMT_ID, 
   , null  --ICS_MASTER_GNRL_PRMT_ID, 
   , null  --ICS_PRMT_FEATR_ID, 
   , null  --ICS_PRETR_PRMT_ID, 
   , null  --ICS_SW_CNST_PRMT_ID, 
   , null  --ICS_SW_INDST_PRMT_ID, 
   , null  --ICS_UNPRMT_FAC_ID, 
   , null  --AFFIL_TYPE_TXT, AffiliationTypeText
   , null  --FIRST_NAME, FirstName
   , null  --MIDDLE_NAME, MiddleName
   , null  --LAST_NAME, LastName
   , null  --INDVL_TITLE_TXT, IndividualTitleText
   , null  --ORG_FRML_NAME, OrganizationFormalName
   , null  --ST_CODE, StateCode
   , null  --RGN_CODE, RegionCode
   , null  --ELEC_ADDR_TXT, ElectronicAddressText
   , null  --START_DATE_OF_CONTACT_ASSC, StartDateOfContactAssociation
   , null  --END_DATE_OF_CONTACT_ASSC, EndDateOfContactAssociation
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_BS_PRMT/ICS_PRMT_BS_MGMT_PRACTICE/ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR/ICS_CONTACT/ICS_TELEPH
INSERT INTO ics_flow_local.ICS_TELEPH (
     [ICS_TELEPH_ID]
   , [ICS_CONTACT_ID]
   , [ICS_ADDR_ID]
   , [ICS_EFFLU_TRADE_PRTNER_ADDR_ID]
   , [TELEPH_NUM_TYPE_CODE]
   , [TELEPH_NUM]
   , [TELEPH_EXT_NUM]
   , [DATA_HASH])
SELECT 
     null  --ICS_TELEPH_ID, 
   , null  --ICS_CONTACT_ID, 
   , null  --ICS_ADDR_ID, 
   , null  --ICS_EFFLU_TRADE_PRTNER_ADDR_ID, 
   , null  --TELEPH_NUM_TYPE_CODE, TelephoneNumberTypeCode
   , null  --TELEPH_NUM, TelephoneNumber
   , null  --TELEPH_EXT_NUM, TelephoneExtensionNumber
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_BS_PRMT/ICS_PRMT_BS_MGMT_PRACTICE/ICS_PATHOGEN_REDUCTION_TYPE
INSERT INTO ics_flow_local.ICS_PATHOGEN_REDUCTION_TYPE (
     [ICS_PATHOGEN_REDUCTION_TYPE_ID]
   , [ICS_BS_MGMT_PRACTICE_ID]
   , [ICS_PRMT_BS_MGMT_PRACTICE_ID]
   , [PATHOGEN_REDUCTION_TYPE_CODE]
   , [DATA_HASH])
SELECT 
     null  --ICS_PATHOGEN_REDUCTION_TYPE_ID, 
   , null  --ICS_BS_MGMT_PRACTICE_ID, 
   , null  --ICS_PRMT_BS_MGMT_PRACTICE_ID, 
   , null  --PATHOGEN_REDUCTION_TYPE_CODE, PathogenReductionTypeCode
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_BS_PRMT/ICS_PRMT_BS_MGMT_PRACTICE/ICS_VECTOR_A_REDUCTION_TYPE
INSERT INTO ics_flow_local.ICS_VECTOR_A_REDUCTION_TYPE (
     [ICS_VECTOR_A_REDUCTION_TYPE_ID]
   , [ICS_BS_MGMT_PRACTICE_ID]
   , [ICS_PRMT_BS_MGMT_PRACTICE_ID]
   , [VECTOR_A_REDUCTION_TYPE_CODE]
   , [DATA_HASH])
SELECT 
     null  --ICS_VECTOR_A_REDUCTION_TYPE_ID, 
   , null  --ICS_BS_MGMT_PRACTICE_ID, 
   , null  --ICS_PRMT_BS_MGMT_PRACTICE_ID, 
   , null  --VECTOR_A_REDUCTION_TYPE_CODE, VectorAttractionReductionTypeCode
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

END;
