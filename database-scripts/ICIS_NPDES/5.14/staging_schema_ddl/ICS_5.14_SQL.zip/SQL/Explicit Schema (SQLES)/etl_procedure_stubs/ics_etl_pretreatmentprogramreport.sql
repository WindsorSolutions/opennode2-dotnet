﻿
/*************************************************************************************************
** ObjectName: ics_etl_PretreatmentProgramReport
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the PretreatmentProgramReportSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/18/2025   Windsor      Created 
**
***************************************************************************************************/
CREATE OR ALTER PROCEDURE ics_flow_local.ics_etl_PretreatmentProgramReport

AS

BEGIN
---------------------------- 
-- ICS_PRETR_PROG_REP
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- /ICS_PRETR_PROG_REP/ICS_INDST_USR_INVENTORY/ICS_INDST_USR_INFO/ICS_IU_ENFRC_ACTN_INFO/ICS_IU_ENF_ACTN_TYPES
DELETE
  FROM ics_flow_local.ICS_IU_ENF_ACTN_TYPES
 WHERE ICS_IU_ENFRC_ACTN_INFO_ID IN
          (SELECT ICS_IU_ENFRC_ACTN_INFO.ICS_IU_ENFRC_ACTN_INFO_ID
             FROM ics_flow_local.ICS_PRETR_PROG_REP
                  JOIN ics_flow_local.ICS_INDST_USR_INVENTORY ON ICS_INDST_USR_INVENTORY.ICS_PRETR_PROG_REP_id = ICS_PRETR_PROG_REP.ICS_PRETR_PROG_REP_id
                  JOIN ics_flow_local.ICS_INDST_USR_INFO ON ICS_INDST_USR_INFO.ICS_INDST_USR_INVENTORY_id = ICS_INDST_USR_INVENTORY.ICS_INDST_USR_INVENTORY_id
                  JOIN ics_flow_local.ICS_IU_ENFRC_ACTN_INFO ON ICS_IU_ENFRC_ACTN_INFO.ICS_INDST_USR_INFO_id = ICS_INDST_USR_INFO.ICS_INDST_USR_INFO_id
          );

-- /ICS_PRETR_PROG_REP/ICS_INDST_USR_INVENTORY/ICS_INDST_USR_INFO/ICS_IU_VIOL_INFO/ICS_SNC_LISTING_MONTHS
DELETE
  FROM ics_flow_local.ICS_SNC_LISTING_MONTHS
 WHERE ICS_IU_VIOL_INFO_ID IN
          (SELECT ICS_IU_VIOL_INFO.ICS_IU_VIOL_INFO_ID
             FROM ics_flow_local.ICS_PRETR_PROG_REP
                  JOIN ics_flow_local.ICS_INDST_USR_INVENTORY ON ICS_INDST_USR_INVENTORY.ICS_PRETR_PROG_REP_id = ICS_PRETR_PROG_REP.ICS_PRETR_PROG_REP_id
                  JOIN ics_flow_local.ICS_INDST_USR_INFO ON ICS_INDST_USR_INFO.ICS_INDST_USR_INVENTORY_id = ICS_INDST_USR_INVENTORY.ICS_INDST_USR_INVENTORY_id
                  JOIN ics_flow_local.ICS_IU_VIOL_INFO ON ICS_IU_VIOL_INFO.ICS_INDST_USR_INFO_id = ICS_INDST_USR_INFO.ICS_INDST_USR_INFO_id
          );

-- /ICS_PRETR_PROG_REP/ICS_INDST_USR_INVENTORY/ICS_INDST_USR_INFO/ICS_IU_VIOL_INFO/ICS_SNC_PRETR_STND_LMTS_PARAMETERS
DELETE
  FROM ics_flow_local.ICS_SNC_PRETR_STND_LMTS_PARAMETERS
 WHERE ICS_IU_VIOL_INFO_ID IN
          (SELECT ICS_IU_VIOL_INFO.ICS_IU_VIOL_INFO_ID
             FROM ics_flow_local.ICS_PRETR_PROG_REP
                  JOIN ics_flow_local.ICS_INDST_USR_INVENTORY ON ICS_INDST_USR_INVENTORY.ICS_PRETR_PROG_REP_id = ICS_PRETR_PROG_REP.ICS_PRETR_PROG_REP_id
                  JOIN ics_flow_local.ICS_INDST_USR_INFO ON ICS_INDST_USR_INFO.ICS_INDST_USR_INVENTORY_id = ICS_INDST_USR_INVENTORY.ICS_INDST_USR_INVENTORY_id
                  JOIN ics_flow_local.ICS_IU_VIOL_INFO ON ICS_IU_VIOL_INFO.ICS_INDST_USR_INFO_id = ICS_INDST_USR_INFO.ICS_INDST_USR_INFO_id
          );

-- /ICS_PRETR_PROG_REP/ICS_INDST_USR_INVENTORY/ICS_INDST_USR_INFO/ICS_IU_ENFRC_ACTN_INFO
DELETE
  FROM ics_flow_local.ICS_IU_ENFRC_ACTN_INFO
 WHERE ICS_INDST_USR_INFO_ID IN
          (SELECT ICS_INDST_USR_INFO.ICS_INDST_USR_INFO_ID
             FROM ics_flow_local.ICS_PRETR_PROG_REP
                  JOIN ics_flow_local.ICS_INDST_USR_INVENTORY ON ICS_INDST_USR_INVENTORY.ICS_PRETR_PROG_REP_id = ICS_PRETR_PROG_REP.ICS_PRETR_PROG_REP_id
                  JOIN ics_flow_local.ICS_INDST_USR_INFO ON ICS_INDST_USR_INFO.ICS_INDST_USR_INVENTORY_id = ICS_INDST_USR_INVENTORY.ICS_INDST_USR_INVENTORY_id
          );

-- /ICS_PRETR_PROG_REP/ICS_INDST_USR_INVENTORY/ICS_INDST_USR_INFO/ICS_IU_VIOL_INFO
DELETE
  FROM ics_flow_local.ICS_IU_VIOL_INFO
 WHERE ICS_INDST_USR_INFO_ID IN
          (SELECT ICS_INDST_USR_INFO.ICS_INDST_USR_INFO_ID
             FROM ics_flow_local.ICS_PRETR_PROG_REP
                  JOIN ics_flow_local.ICS_INDST_USR_INVENTORY ON ICS_INDST_USR_INVENTORY.ICS_PRETR_PROG_REP_id = ICS_PRETR_PROG_REP.ICS_PRETR_PROG_REP_id
                  JOIN ics_flow_local.ICS_INDST_USR_INFO ON ICS_INDST_USR_INFO.ICS_INDST_USR_INVENTORY_id = ICS_INDST_USR_INVENTORY.ICS_INDST_USR_INVENTORY_id
          );

-- /ICS_PRETR_PROG_REP/ICS_CONTROL_AUTH_PROG_INFO/ICS_LOC_LMTS_PARAMETERS
DELETE
  FROM ics_flow_local.ICS_LOC_LMTS_PARAMETERS
 WHERE ICS_CONTROL_AUTH_PROG_INFO_ID IN
          (SELECT ICS_CONTROL_AUTH_PROG_INFO.ICS_CONTROL_AUTH_PROG_INFO_ID
             FROM ics_flow_local.ICS_PRETR_PROG_REP
                  JOIN ics_flow_local.ICS_CONTROL_AUTH_PROG_INFO ON ICS_CONTROL_AUTH_PROG_INFO.ICS_PRETR_PROG_REP_id = ICS_PRETR_PROG_REP.ICS_PRETR_PROG_REP_id
          );

-- /ICS_PRETR_PROG_REP/ICS_INDST_USR_INVENTORY/ICS_INDST_USR_INFO
DELETE
  FROM ics_flow_local.ICS_INDST_USR_INFO
 WHERE ICS_INDST_USR_INVENTORY_ID IN
          (SELECT ICS_INDST_USR_INVENTORY.ICS_INDST_USR_INVENTORY_ID
             FROM ics_flow_local.ICS_PRETR_PROG_REP
                  JOIN ics_flow_local.ICS_INDST_USR_INVENTORY ON ICS_INDST_USR_INVENTORY.ICS_PRETR_PROG_REP_id = ICS_PRETR_PROG_REP.ICS_PRETR_PROG_REP_id
          );

-- /ICS_PRETR_PROG_REP/ICS_CONTROL_AUTH_PROG_INFO
DELETE
  FROM ics_flow_local.ICS_CONTROL_AUTH_PROG_INFO
 WHERE ICS_PRETR_PROG_REP_ID IN
          (SELECT ICS_PRETR_PROG_REP.ICS_PRETR_PROG_REP_ID
             FROM ics_flow_local.ICS_PRETR_PROG_REP
          );

-- /ICS_PRETR_PROG_REP/ICS_INDST_USR_INVENTORY
DELETE
  FROM ics_flow_local.ICS_INDST_USR_INVENTORY
 WHERE ICS_PRETR_PROG_REP_ID IN
          (SELECT ICS_PRETR_PROG_REP.ICS_PRETR_PROG_REP_ID
             FROM ics_flow_local.ICS_PRETR_PROG_REP
          );

-- /ICS_PRETR_PROG_REP
DELETE
  FROM ics_flow_local.ICS_PRETR_PROG_REP;


-- /ICS_PRETR_PROG_REP
INSERT INTO ics_flow_local.ICS_PRETR_PROG_REP (
     [ICS_PRETR_PROG_REP_ID]
   , [ICS_PAYLOAD_ID]
   , [SRC_SYSTM_IDENT]
   , [TRANSACTION_TYPE]
   , [TRANSACTION_TIMESTAMP]
   , [PRMT_IDENT]
   , [PROG_REP_FORM_SET_ID]
   , [PROG_REP_FORM_ID]
   , [PROG_REP_RCVD_DATE]
   , [PROG_REP_START_DATE]
   , [PROG_REP_END_DATE]
   , [ELEC_SUBM_TYPE_CODE]
   , [PROG_REP_NPDES_DAT_GRP_NUM_CODE]
   , [KEY_HASH]
   , [DATA_HASH])
SELECT 
     null  --ICS_PRETR_PROG_REP_ID, 
   , null  --ICS_PAYLOAD_ID, 
   , null  --SRC_SYSTM_IDENT, SourceSystemIdentifier
   , null  --TRANSACTION_TYPE, TransactionType
   , null  --TRANSACTION_TIMESTAMP, TransactionTimestamp
   , null  --PRMT_IDENT, PermitIdentifier
   , null  --PROG_REP_FORM_SET_ID, ProgramReportFormSetID
   , null  --PROG_REP_FORM_ID, ProgramReportFormID
   , null  --PROG_REP_RCVD_DATE, ProgramReportReceivedDate
   , null  --PROG_REP_START_DATE, ProgramReportStartDate
   , null  --PROG_REP_END_DATE, ProgramReportEndDate
   , null  --ELEC_SUBM_TYPE_CODE, ElectronicSubmissionTypeCode
   , null  --PROG_REP_NPDES_DAT_GRP_NUM_CODE, ProgramReportNPDESDataGroupNumberCode
   , null  --KEY_HASH, 
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_PRETR_PROG_REP/ICS_CONTROL_AUTH_PROG_INFO
INSERT INTO ics_flow_local.ICS_CONTROL_AUTH_PROG_INFO (
     [ICS_CONTROL_AUTH_PROG_INFO_ID]
   , [ICS_PRETR_PROG_REP_ID]
   , [LOC_LMTS_ADOPTION_DATE]
   , [LOC_LMTS_EVAL_DATE]
   , [POTW_DSCH_CONTAMINATION_IND]
   , [POTW_DSCH_CONTAMINATION_TXT]
   , [POTW_BS_CONTAMINATION_IND]
   , [POTW_BS_CONTAMINATION_TXT]
   , [DATA_HASH])
SELECT 
     null  --ICS_CONTROL_AUTH_PROG_INFO_ID, 
   , null  --ICS_PRETR_PROG_REP_ID, 
   , null  --LOC_LMTS_ADOPTION_DATE, LocalLimitsAdoptionDate
   , null  --LOC_LMTS_EVAL_DATE, LocalLimitsEvaluationDate
   , null  --POTW_DSCH_CONTAMINATION_IND, POTWDischargeContaminationIndicator
   , null  --POTW_DSCH_CONTAMINATION_TXT, POTWDischargeContaminationText
   , null  --POTW_BS_CONTAMINATION_IND, POTWBiosolidsContaminationIndicator
   , null  --POTW_BS_CONTAMINATION_TXT, POTWBiosolidsContaminationText
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_PRETR_PROG_REP/ICS_CONTROL_AUTH_PROG_INFO/ICS_LOC_LMTS_PARAMETERS
INSERT INTO ics_flow_local.ICS_LOC_LMTS_PARAMETERS (
     [ICS_LOC_LMTS_PARAMETERS_ID]
   , [ICS_CONTROL_AUTH_PROG_INFO_ID]
   , [LOC_LMTS_PARAMETERS]
   , [DATA_HASH])
SELECT 
     null  --ICS_LOC_LMTS_PARAMETERS_ID, 
   , null  --ICS_CONTROL_AUTH_PROG_INFO_ID, 
   , null  --LOC_LMTS_PARAMETERS, LocalLimitsParameters
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_PRETR_PROG_REP/ICS_INDST_USR_INVENTORY
INSERT INTO ics_flow_local.ICS_INDST_USR_INVENTORY (
     [ICS_INDST_USR_INVENTORY_ID]
   , [ICS_PRETR_PROG_REP_ID]
   , [INDST_USR_IND]
   , [DATA_HASH])
SELECT 
     null  --ICS_INDST_USR_INVENTORY_ID, 
   , null  --ICS_PRETR_PROG_REP_ID, 
   , null  --INDST_USR_IND, IndustrialUserIndicator
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_PRETR_PROG_REP/ICS_INDST_USR_INVENTORY/ICS_INDST_USR_INFO
INSERT INTO ics_flow_local.ICS_INDST_USR_INFO (
     [ICS_INDST_USR_INFO_ID]
   , [ICS_INDST_USR_INVENTORY_ID]
   , [PRMT_IDENT]
   , [IU_AVER_DAILY_WW_FLOW_RATE_GPD]
   , [IU_AVER_DAILY_PRCSS_WW_FLOW_RATE_GPD]
   , [IU_SUBJECT_LOC_LMTS_IND]
   , [IU_SUBJECT_LOC_LMTS_MORE_STRINGENT_CAT_STD_IND]
   , [MTCIU_SUBJECT_REDUCED_REP_IND]
   , [NUM_IU_INSP_BY_CA]
   , [NUM_IU_SMPL_EVTS_BY_CA]
   , [NUM_REQD_IU_SELF_MON_EVTS_MAX]
   , [IU_COMPLY_REQ_SELF_MON_RPTING_IND]
   , [IU_COMPLY_REQ_SELF_MON_RPTING_TXT]
   , [NSCIU_CERT_SUBM_TO_CA_IND]
   , [CHANGED_DISCH_SUBM_IND]
   , [DATA_HASH])
SELECT 
     null  --ICS_INDST_USR_INFO_ID, 
   , null  --ICS_INDST_USR_INVENTORY_ID, 
   , null  --PRMT_IDENT, PermitIdentifier
   , null  --IU_AVER_DAILY_WW_FLOW_RATE_GPD, IUAverageDailyWastewaterFlowRateGPD
   , null  --IU_AVER_DAILY_PRCSS_WW_FLOW_RATE_GPD, IUAverageDailyProcessWastewaterFlowRateGPD
   , null  --IU_SUBJECT_LOC_LMTS_IND, IUSubjectLocalLimitsIndicator
   , null  --IU_SUBJECT_LOC_LMTS_MORE_STRINGENT_CAT_STD_IND, IUSubjectLocalLimitsMoreStringentCatStdIndicator
   , null  --MTCIU_SUBJECT_REDUCED_REP_IND, MTCIUSubjectReducedReportingIndicator
   , null  --NUM_IU_INSP_BY_CA, NumberIUInspectionsByCA
   , null  --NUM_IU_SMPL_EVTS_BY_CA, NumberIUSamplingEventsByCA
   , null  --NUM_REQD_IU_SELF_MON_EVTS_MAX, NumberReqdIUSelfMonEventsMaximum
   , null  --IU_COMPLY_REQ_SELF_MON_RPTING_IND, IUComplyReqSelfMonRptingIndicator
   , null  --IU_COMPLY_REQ_SELF_MON_RPTING_TXT, IUComplyReqSelfMonRptingText
   , null  --NSCIU_CERT_SUBM_TO_CA_IND, NSCIUCertSubmToCAIndicator
   , null  --CHANGED_DISCH_SUBM_IND, ChangedDischSubmIndicator
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_PRETR_PROG_REP/ICS_INDST_USR_INVENTORY/ICS_INDST_USR_INFO/ICS_IU_ENFRC_ACTN_INFO
INSERT INTO ics_flow_local.ICS_IU_ENFRC_ACTN_INFO (
     [ICS_IU_ENFRC_ACTN_INFO_ID]
   , [ICS_INDST_USR_INFO_ID]
   , [SNC_PRETR_ENF_CMPL_SCHED_STAT_IND]
   , [IU_CASH_CIVIL_PNLTY_AMT_ASSESSED]
   , [IU_CASH_CIVIL_PNLTY_AMT_COLL]
   , [DATA_HASH])
SELECT 
     null  --ICS_IU_ENFRC_ACTN_INFO_ID, 
   , null  --ICS_INDST_USR_INFO_ID, 
   , null  --SNC_PRETR_ENF_CMPL_SCHED_STAT_IND, SNCPretrEnfCmplSchedStatusIndicator
   , null  --IU_CASH_CIVIL_PNLTY_AMT_ASSESSED, IUCashCivilPenaltyAmountAssessed
   , null  --IU_CASH_CIVIL_PNLTY_AMT_COLL, IUCashCivilPenaltyAmountCollected
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_PRETR_PROG_REP/ICS_INDST_USR_INVENTORY/ICS_INDST_USR_INFO/ICS_IU_ENFRC_ACTN_INFO/ICS_IU_ENF_ACTN_TYPES
INSERT INTO ics_flow_local.ICS_IU_ENF_ACTN_TYPES (
     [ICS_IU_ENF_ACTN_TYPES_ID]
   , [ICS_IU_ENFRC_ACTN_INFO_ID]
   , [IU_ENF_ACTN_TYPE_CODE]
   , [IU_ENF_ACTN_TYPE_OTHR_TXT]
   , [NUM_IU_ENF_ACTIONS]
   , [DATA_HASH])
SELECT 
     null  --ICS_IU_ENF_ACTN_TYPES_ID, 
   , null  --ICS_IU_ENFRC_ACTN_INFO_ID, 
   , null  --IU_ENF_ACTN_TYPE_CODE, IUEnfActionTypeCode
   , null  --IU_ENF_ACTN_TYPE_OTHR_TXT, IUEnfActionTypeOtherText
   , null  --NUM_IU_ENF_ACTIONS, NumIUEnfActions
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_PRETR_PROG_REP/ICS_INDST_USR_INVENTORY/ICS_INDST_USR_INFO/ICS_IU_VIOL_INFO
INSERT INTO ics_flow_local.ICS_IU_VIOL_INFO (
     [ICS_IU_VIOL_INFO_ID]
   , [ICS_INDST_USR_INFO_ID]
   , [SNC_PRETR_STND_LMTS_IND]
   , [SNC_RPT_RQMT_IND]
   , [SNC_OTH_CTRL_MECH_RQMT_IND]
   , [SNC_REL_POTW_DISCH_OPER_IND]
   , [SNC_REL_POTW_DISCH_OPER_TXT]
   , [SNC_REL_POTW_BIO_OPER_SEWG_SLUD_MGMT_IND]
   , [SNC_REL_POTW_BIO_OPER_SEWG_SLUD_MGMT_TXT]
   , [SNC_PUBL_IND]
   , [DATA_HASH])
SELECT 
     null  --ICS_IU_VIOL_INFO_ID, 
   , null  --ICS_INDST_USR_INFO_ID, 
   , null  --SNC_PRETR_STND_LMTS_IND, SNCPretrStndLimitsIndicator
   , null  --SNC_RPT_RQMT_IND, SNCRptRqmtIndicator
   , null  --SNC_OTH_CTRL_MECH_RQMT_IND, SNCOthCtrlMechRqmtIndicator
   , null  --SNC_REL_POTW_DISCH_OPER_IND, SNCRelPOTWDischOperIndicator
   , null  --SNC_REL_POTW_DISCH_OPER_TXT, SNCRelPOTWDischOperText
   , null  --SNC_REL_POTW_BIO_OPER_SEWG_SLUD_MGMT_IND, SNCRelPOTWBioOperSewgSludMgmtIndicator
   , null  --SNC_REL_POTW_BIO_OPER_SEWG_SLUD_MGMT_TXT, SNCRelPOTWBioOperSewgSludMgmtText
   , null  --SNC_PUBL_IND, SNCPublishedIndicator
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_PRETR_PROG_REP/ICS_INDST_USR_INVENTORY/ICS_INDST_USR_INFO/ICS_IU_VIOL_INFO/ICS_SNC_LISTING_MONTHS
INSERT INTO ics_flow_local.ICS_SNC_LISTING_MONTHS (
     [ICS_SNC_LISTING_MONTHS_ID]
   , [ICS_IU_VIOL_INFO_ID]
   , [SNC_LISTING_MONTHS]
   , [DATA_HASH])
SELECT 
     null  --ICS_SNC_LISTING_MONTHS_ID, 
   , null  --ICS_IU_VIOL_INFO_ID, 
   , null  --SNC_LISTING_MONTHS, SNCListingMonths
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_PRETR_PROG_REP/ICS_INDST_USR_INVENTORY/ICS_INDST_USR_INFO/ICS_IU_VIOL_INFO/ICS_SNC_PRETR_STND_LMTS_PARAMETERS
INSERT INTO ics_flow_local.ICS_SNC_PRETR_STND_LMTS_PARAMETERS (
     [ICS_SNC_PRETR_STND_LMTS_PARAMETERS_ID]
   , [ICS_IU_VIOL_INFO_ID]
   , [SNC_PRETR_STND_LMTS_PARAMETERS]
   , [DATA_HASH])
SELECT 
     null  --ICS_SNC_PRETR_STND_LMTS_PARAMETERS_ID, 
   , null  --ICS_IU_VIOL_INFO_ID, 
   , null  --SNC_PRETR_STND_LMTS_PARAMETERS, SNCPretrStndLimitsParameters
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

END;
