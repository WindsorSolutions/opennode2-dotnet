﻿
/*************************************************************************************************
** ObjectName: ics_etl_PretreatmentPermit
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the PretreatmentPermitSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/18/2025   Windsor      Created 
**
***************************************************************************************************/
CREATE OR ALTER PROCEDURE ics_flow_local.ics_etl_PretreatmentPermit

AS

BEGIN
---------------------------- 
-- ICS_PRETR_PRMT
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- /ICS_PRETR_PRMT/ICS_CONTACT/ICS_TELEPH
DELETE
  FROM ics_flow_local.ICS_TELEPH
 WHERE ICS_CONTACT_ID IN
          (SELECT ICS_CONTACT.ICS_CONTACT_ID
             FROM ics_flow_local.ICS_PRETR_PRMT
                  JOIN ics_flow_local.ICS_CONTACT ON ICS_CONTACT.ICS_PRETR_PRMT_id = ICS_PRETR_PRMT.ICS_PRETR_PRMT_id
          );

-- /ICS_PRETR_PRMT/ICS_CONTACT
DELETE
  FROM ics_flow_local.ICS_CONTACT
 WHERE ICS_PRETR_PRMT_ID IN
          (SELECT ICS_PRETR_PRMT.ICS_PRETR_PRMT_ID
             FROM ics_flow_local.ICS_PRETR_PRMT
          );

-- /ICS_PRETR_PRMT/ICS_PRETR_PROG_MOD
DELETE
  FROM ics_flow_local.ICS_PRETR_PROG_MOD
 WHERE ICS_PRETR_PRMT_ID IN
          (SELECT ICS_PRETR_PRMT.ICS_PRETR_PRMT_ID
             FROM ics_flow_local.ICS_PRETR_PRMT
          );

-- /ICS_PRETR_PRMT
DELETE
  FROM ics_flow_local.ICS_PRETR_PRMT;


-- /ICS_PRETR_PRMT
INSERT INTO ics_flow_local.ICS_PRETR_PRMT (
     [ICS_PRETR_PRMT_ID]
   , [ICS_PAYLOAD_ID]
   , [SRC_SYSTM_IDENT]
   , [TRANSACTION_TYPE]
   , [TRANSACTION_TIMESTAMP]
   , [PRMT_IDENT]
   , [PRETR_PROG_REQD_IND_CODE]
   , [CONTROL_AUTH_ST_AGNCY_CODE]
   , [CONTROL_AUTH_RGNL_AGNCY_CODE]
   , [CONTROL_AUTH_NPDES_IDENT]
   , [PRETR_PROG_APRVD_DATE]
   , [RCVG_RCRA_WASTE_IND]
   , [RCVG_REMEDIATION_WASTE_IND]
   , [KEY_HASH]
   , [DATA_HASH])
SELECT 
     null  --ICS_PRETR_PRMT_ID, 
   , null  --ICS_PAYLOAD_ID, 
   , null  --SRC_SYSTM_IDENT, SourceSystemIdentifier
   , null  --TRANSACTION_TYPE, TransactionType
   , null  --TRANSACTION_TIMESTAMP, TransactionTimestamp
   , null  --PRMT_IDENT, PermitIdentifier
   , null  --PRETR_PROG_REQD_IND_CODE, PretreatmentProgramRequiredIndicatorCode
   , null  --CONTROL_AUTH_ST_AGNCY_CODE, ControlAuthorityStateAgencyCode
   , null  --CONTROL_AUTH_RGNL_AGNCY_CODE, ControlAuthorityRegionalAgencyCode
   , null  --CONTROL_AUTH_NPDES_IDENT, ControlAuthorityNPDESIdentifier
   , null  --PRETR_PROG_APRVD_DATE, PretreatmentProgramApprovedDate
   , null  --RCVG_RCRA_WASTE_IND, ReceivingRCRAWasteIndicator
   , null  --RCVG_REMEDIATION_WASTE_IND, ReceivingRemediationWasteIndicator
   , null  --KEY_HASH, 
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_PRETR_PRMT/ICS_CONTACT
INSERT INTO ics_flow_local.ICS_CONTACT (
     [ICS_CONTACT_ID]
   , [ICS_FAC_ID]
   , [ICS_BASIC_PRMT_ID]
   , [ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID]
   , [ICS_CAFO_PRMT_ID]
   , [ICS_CMPL_MON_ID]
   , [ICS_GNRL_PRMT_ID]
   , [ICS_MASTER_GNRL_PRMT_ID]
   , [ICS_PRMT_FEATR_ID]
   , [ICS_PRETR_PRMT_ID]
   , [ICS_SW_CNST_PRMT_ID]
   , [ICS_SW_INDST_PRMT_ID]
   , [ICS_UNPRMT_FAC_ID]
   , [AFFIL_TYPE_TXT]
   , [FIRST_NAME]
   , [MIDDLE_NAME]
   , [LAST_NAME]
   , [INDVL_TITLE_TXT]
   , [ORG_FRML_NAME]
   , [ST_CODE]
   , [RGN_CODE]
   , [ELEC_ADDR_TXT]
   , [START_DATE_OF_CONTACT_ASSC]
   , [END_DATE_OF_CONTACT_ASSC]
   , [DATA_HASH])
SELECT 
     null  --ICS_CONTACT_ID, 
   , null  --ICS_FAC_ID, 
   , null  --ICS_BASIC_PRMT_ID, 
   , null  --ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID, 
   , null  --ICS_CAFO_PRMT_ID, 
   , null  --ICS_CMPL_MON_ID, 
   , null  --ICS_GNRL_PRMT_ID, 
   , null  --ICS_MASTER_GNRL_PRMT_ID, 
   , null  --ICS_PRMT_FEATR_ID, 
   , null  --ICS_PRETR_PRMT_ID, 
   , null  --ICS_SW_CNST_PRMT_ID, 
   , null  --ICS_SW_INDST_PRMT_ID, 
   , null  --ICS_UNPRMT_FAC_ID, 
   , null  --AFFIL_TYPE_TXT, AffiliationTypeText
   , null  --FIRST_NAME, FirstName
   , null  --MIDDLE_NAME, MiddleName
   , null  --LAST_NAME, LastName
   , null  --INDVL_TITLE_TXT, IndividualTitleText
   , null  --ORG_FRML_NAME, OrganizationFormalName
   , null  --ST_CODE, StateCode
   , null  --RGN_CODE, RegionCode
   , null  --ELEC_ADDR_TXT, ElectronicAddressText
   , null  --START_DATE_OF_CONTACT_ASSC, StartDateOfContactAssociation
   , null  --END_DATE_OF_CONTACT_ASSC, EndDateOfContactAssociation
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_PRETR_PRMT/ICS_CONTACT/ICS_TELEPH
INSERT INTO ics_flow_local.ICS_TELEPH (
     [ICS_TELEPH_ID]
   , [ICS_CONTACT_ID]
   , [ICS_ADDR_ID]
   , [ICS_EFFLU_TRADE_PRTNER_ADDR_ID]
   , [TELEPH_NUM_TYPE_CODE]
   , [TELEPH_NUM]
   , [TELEPH_EXT_NUM]
   , [DATA_HASH])
SELECT 
     null  --ICS_TELEPH_ID, 
   , null  --ICS_CONTACT_ID, 
   , null  --ICS_ADDR_ID, 
   , null  --ICS_EFFLU_TRADE_PRTNER_ADDR_ID, 
   , null  --TELEPH_NUM_TYPE_CODE, TelephoneNumberTypeCode
   , null  --TELEPH_NUM, TelephoneNumber
   , null  --TELEPH_EXT_NUM, TelephoneExtensionNumber
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_PRETR_PRMT/ICS_PRETR_PROG_MOD
INSERT INTO ics_flow_local.ICS_PRETR_PROG_MOD (
     [ICS_PRETR_PROG_MOD_ID]
   , [ICS_PRETR_PRMT_ID]
   , [PRETR_PROG_MOD_TYPE]
   , [PRETR_PROG_MOD_DATE]
   , [PRETR_PROG_MOD_TXT]
   , [DATA_HASH])
SELECT 
     null  --ICS_PRETR_PROG_MOD_ID, 
   , null  --ICS_PRETR_PRMT_ID, 
   , null  --PRETR_PROG_MOD_TYPE, PretreatmentProgramModificationType
   , null  --PRETR_PROG_MOD_DATE, PretreatmentProgramModificationDate
   , null  --PRETR_PROG_MOD_TXT, PretreatmentProgramModificationText
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

END;
