﻿
/*************************************************************************************************
** ObjectName: ics_etl_EnforcementActionMilestone
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the EnforcementActionMilestoneSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/18/2025   Windsor      Created 
**
***************************************************************************************************/
CREATE OR ALTER PROCEDURE ics_flow_local.ics_etl_EnforcementActionMilestone

AS

BEGIN
---------------------------- 
-- ICS_ENFRC_ACTN_MILESTONE
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- /ICS_ENFRC_ACTN_MILESTONE
DELETE
  FROM ics_flow_local.ICS_ENFRC_ACTN_MILESTONE;


-- /ICS_ENFRC_ACTN_MILESTONE
INSERT INTO ics_flow_local.ICS_ENFRC_ACTN_MILESTONE (
     [ICS_ENFRC_ACTN_MILESTONE_ID]
   , [ICS_PAYLOAD_ID]
   , [SRC_SYSTM_IDENT]
   , [TRANSACTION_TYPE]
   , [TRANSACTION_TIMESTAMP]
   , [ENFRC_ACTN_IDENT]
   , [MILESTONE_TYPE_CODE]
   , [MILESTONE_PLANNED_DATE]
   , [MILESTONE_ACTUL_DATE]
   , [KEY_HASH]
   , [DATA_HASH])
SELECT 
     null  --ICS_ENFRC_ACTN_MILESTONE_ID, 
   , null  --ICS_PAYLOAD_ID, 
   , null  --SRC_SYSTM_IDENT, SourceSystemIdentifier
   , null  --TRANSACTION_TYPE, TransactionType
   , null  --TRANSACTION_TIMESTAMP, TransactionTimestamp
   , null  --ENFRC_ACTN_IDENT, EnforcementActionIdentifier
   , null  --MILESTONE_TYPE_CODE, MilestoneTypeCode
   , null  --MILESTONE_PLANNED_DATE, MilestonePlannedDate
   , null  --MILESTONE_ACTUL_DATE, MilestoneActualDate
   , null  --KEY_HASH, 
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

END;
