﻿
/*************************************************************************************************
** ObjectName: ics_etl_DMRViolation
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the DMRViolationSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/18/2025   Windsor      Created 
**
***************************************************************************************************/
CREATE OR ALTER PROCEDURE ics_flow_local.ics_etl_DMRViolation

AS

BEGIN
---------------------------- 
-- ICS_DMR_VIOL
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- /ICS_DMR_VIOL
DELETE
  FROM ics_flow_local.ICS_DMR_VIOL;


-- /ICS_DMR_VIOL
INSERT INTO ics_flow_local.ICS_DMR_VIOL (
     [ICS_DMR_VIOL_ID]
   , [ICS_PAYLOAD_ID]
   , [SRC_SYSTM_IDENT]
   , [TRANSACTION_TYPE]
   , [TRANSACTION_TIMESTAMP]
   , [PRMT_IDENT]
   , [PRMT_FEATR_IDENT]
   , [LMT_SET_DESIGNATOR]
   , [MON_PERIOD_END_DATE]
   , [PARAM_CODE]
   , [MON_SITE_DESC_CODE]
   , [LMT_SEASON_NUM]
   , [NUM_REP_CODE]
   , [NUM_REP_VIOL_CODE]
   , [REP_NON_CMPL_DETECT_CODE]
   , [REP_NON_CMPL_DETECT_DATE]
   , [REP_NON_CMPL_RESL_CODE]
   , [REP_NON_CMPL_RESL_DATE]
   , [KEY_HASH]
   , [DATA_HASH])
SELECT 
     null  --ICS_DMR_VIOL_ID, 
   , null  --ICS_PAYLOAD_ID, 
   , null  --SRC_SYSTM_IDENT, SourceSystemIdentifier
   , null  --TRANSACTION_TYPE, TransactionType
   , null  --TRANSACTION_TIMESTAMP, TransactionTimestamp
   , null  --PRMT_IDENT, PermitIdentifier
   , null  --PRMT_FEATR_IDENT, PermittedFeatureIdentifier
   , null  --LMT_SET_DESIGNATOR, LimitSetDesignator
   , null  --MON_PERIOD_END_DATE, MonitoringPeriodEndDate
   , null  --PARAM_CODE, ParameterCode
   , null  --MON_SITE_DESC_CODE, MonitoringSiteDescriptionCode
   , null  --LMT_SEASON_NUM, LimitSeasonNumber
   , null  --NUM_REP_CODE, NumericReportCode
   , null  --NUM_REP_VIOL_CODE, NumericReportViolationCode
   , null  --REP_NON_CMPL_DETECT_CODE, ReportableNonComplianceDetectionCode
   , null  --REP_NON_CMPL_DETECT_DATE, ReportableNonComplianceDetectionDate
   , null  --REP_NON_CMPL_RESL_CODE, ReportableNonComplianceResolutionCode
   , null  --REP_NON_CMPL_RESL_DATE, ReportableNonComplianceResolutionDate
   , null  --KEY_HASH, 
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

END;
