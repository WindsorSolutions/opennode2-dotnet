﻿
/*************************************************************************************************
** ObjectName: ics_etl_ScheduleEventViolation
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the ScheduleEventViolationSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/18/2025   Windsor      Created 
**
***************************************************************************************************/
CREATE OR ALTER PROCEDURE ics_flow_local.ics_etl_ScheduleEventViolation

AS

BEGIN
---------------------------- 
-- ICS_SCHD_EVT_VIOL
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- /ICS_SCHD_EVT_VIOL/ICS_CMPL_SCHD_EVT_VIOL_ELEM
DELETE
  FROM ics_flow_local.ICS_CMPL_SCHD_EVT_VIOL_ELEM
 WHERE ICS_SCHD_EVT_VIOL_ID IN
          (SELECT ICS_SCHD_EVT_VIOL.ICS_SCHD_EVT_VIOL_ID
             FROM ics_flow_local.ICS_SCHD_EVT_VIOL
          );

-- /ICS_SCHD_EVT_VIOL/ICS_PRMT_SCHD_EVT_VIOL_ELEM
DELETE
  FROM ics_flow_local.ICS_PRMT_SCHD_EVT_VIOL_ELEM
 WHERE ICS_SCHD_EVT_VIOL_ID IN
          (SELECT ICS_SCHD_EVT_VIOL.ICS_SCHD_EVT_VIOL_ID
             FROM ics_flow_local.ICS_SCHD_EVT_VIOL
          );

-- /ICS_SCHD_EVT_VIOL
DELETE
  FROM ics_flow_local.ICS_SCHD_EVT_VIOL;


-- /ICS_SCHD_EVT_VIOL
INSERT INTO ics_flow_local.ICS_SCHD_EVT_VIOL (
     [ICS_SCHD_EVT_VIOL_ID]
   , [ICS_PAYLOAD_ID]
   , [SRC_SYSTM_IDENT]
   , [TRANSACTION_TYPE]
   , [TRANSACTION_TIMESTAMP]
   , [REP_NON_CMPL_RESL_CODE]
   , [REP_NON_CMPL_RESL_DATE]
   , [KEY_HASH]
   , [DATA_HASH])
SELECT 
     null  --ICS_SCHD_EVT_VIOL_ID, 
   , null  --ICS_PAYLOAD_ID, 
   , null  --SRC_SYSTM_IDENT, SourceSystemIdentifier
   , null  --TRANSACTION_TYPE, TransactionType
   , null  --TRANSACTION_TIMESTAMP, TransactionTimestamp
   , null  --REP_NON_CMPL_RESL_CODE, ReportableNonComplianceResolutionCode
   , null  --REP_NON_CMPL_RESL_DATE, ReportableNonComplianceResolutionDate
   , null  --KEY_HASH, 
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_SCHD_EVT_VIOL/ICS_CMPL_SCHD_EVT_VIOL_ELEM
INSERT INTO ics_flow_local.ICS_CMPL_SCHD_EVT_VIOL_ELEM (
     [ICS_CMPL_SCHD_EVT_VIOL_ELEM_ID]
   , [ICS_SCHD_EVT_VIOL_ID]
   , [ENFRC_ACTN_IDENT]
   , [FINAL_ORDER_IDENT]
   , [PRMT_IDENT]
   , [CMPL_SCHD_NUM]
   , [SCHD_EVT_CODE]
   , [SCHD_DATE]
   , [SCHD_VIOL_CODE]
   , [DATA_HASH])
SELECT 
     null  --ICS_CMPL_SCHD_EVT_VIOL_ELEM_ID, 
   , null  --ICS_SCHD_EVT_VIOL_ID, 
   , null  --ENFRC_ACTN_IDENT, EnforcementActionIdentifier
   , null  --FINAL_ORDER_IDENT, FinalOrderIdentifier
   , null  --PRMT_IDENT, PermitIdentifier
   , null  --CMPL_SCHD_NUM, ComplianceScheduleNumber
   , null  --SCHD_EVT_CODE, ScheduleEventCode
   , null  --SCHD_DATE, ScheduleDate
   , null  --SCHD_VIOL_CODE, ScheduleViolationCode
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_SCHD_EVT_VIOL/ICS_PRMT_SCHD_EVT_VIOL_ELEM
INSERT INTO ics_flow_local.ICS_PRMT_SCHD_EVT_VIOL_ELEM (
     [ICS_PRMT_SCHD_EVT_VIOL_ELEM_ID]
   , [ICS_SCHD_EVT_VIOL_ID]
   , [PRMT_IDENT]
   , [NARR_COND_NUM]
   , [SCHD_EVT_CODE]
   , [SCHD_DATE]
   , [SCHD_VIOL_CODE]
   , [DATA_HASH])
SELECT 
     null  --ICS_PRMT_SCHD_EVT_VIOL_ELEM_ID, 
   , null  --ICS_SCHD_EVT_VIOL_ID, 
   , null  --PRMT_IDENT, PermitIdentifier
   , null  --NARR_COND_NUM, NarrativeConditionNumber
   , null  --SCHD_EVT_CODE, ScheduleEventCode
   , null  --SCHD_DATE, ScheduleDate
   , null  --SCHD_VIOL_CODE, ScheduleViolationCode
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

END;
