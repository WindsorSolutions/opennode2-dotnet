/****** Object:  Table [ics_flow_local].[ICS_ABOUT_ELEMENTS]    Script Date: 5/29/2025 3:30:56 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
drop table if exists [ics_flow_local].[ICS_ABOUT_ELEMENTS];
GO

CREATE TABLE [ics_flow_local].[ICS_ABOUT_ELEMENTS](
	[SCHEMA_NAME] [sysname] NULL,
	[OBJECT_NAME] [sysname] NULL,
	[COLUMN_NAME] [sysname] NULL,
	[PROP_NAME] [sysname] NOT NULL,
	[PROP_VALUE] [sql_variant] NULL
) ON [PRIMARY]
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CSO_INSP', NULL, N'MS_Description', CAST(N'Schema element: CSOInspection' AS nvarchar(29)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CSO_INSP', N'CSO_EVT_DATE', N'MS_Description', CAST(N'CSOEventDate' AS nvarchar(12)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CSO_INSP', N'DRY_OR_WET_WEATHER_IND', N'MS_Description', CAST(N'DryOrWetWeatherIndicator' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CSO_INSP', N'PRMT_FEATR_IDENT', N'MS_Description', CAST(N'PermittedFeatureIdentifier' AS nvarchar(26)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CSO_INSP', N'LAT_MEAS', N'MS_Description', CAST(N'LatitudeMeasure' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CSO_INSP', N'LONG_MEAS', N'MS_Description', CAST(N'LongitudeMeasure' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CSO_INSP', N'CSO_OVRFLW_LOC_STREET', N'MS_Description', CAST(N'CSOOverflowLocationStreet' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CSO_INSP', N'DURATION_CSO_OVRFLW_EVT', N'MS_Description', CAST(N'DurationCSOOverflowEvent' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CSO_INSP', N'DSCH_VOL_TREATED', N'MS_Description', CAST(N'DischargeVolumeTreated' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CSO_INSP', N'DSCH_VOL_UNTREATED', N'MS_Description', CAST(N'DischargeVolumeUntreated' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CSO_INSP', N'CORR_ACTN_TAKEN_DESC_TXT', N'MS_Description', CAST(N'CorrectiveActionTakenDescriptionText' AS nvarchar(36)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CSO_INSP', N'INCHES_PRECIP', N'MS_Description', CAST(N'InchesPrecipitation' AS nvarchar(19)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SEWER_OVRFLW_BYPASS_IMPACT', NULL, N'MS_Description', CAST(N'Schema element: SewerOverflowBypassImpact' AS nvarchar(41)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SEWER_OVRFLW_BYPASS_IMPACT', N'SEWER_OVRFLW_BYPASS_IMPACT_CODE', N'MS_Description', CAST(N'SewerOverflowBypassImpactCode' AS nvarchar(29)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SEWER_OVRFLW_BYPASS_IMPACT', N'SEWER_OVRFLW_BYPASS_IMPACT_OTHR_TXT', N'MS_Description', CAST(N'SewerOverflowBypassImpactOtherText' AS nvarchar(34)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_INDST_SW_REGULATED_ENTITY_INFO', NULL, N'MS_Description', CAST(N'Schema element: MS4IndustrialStormwaterRegulatedEntityInformation' AS nvarchar(65)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_INDST_SW_REGULATED_ENTITY_INFO', N'MS_4_ACTY_IDENT', N'MS_Description', CAST(N'MS4ActivityIdentifier' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_INDST_SW_REGULATED_ENTITY_INFO', N'MS_4_REGULATED_ENTITY_IDENT', N'MS_Description', CAST(N'MS4RegulatedEntityIdentifier' AS nvarchar(28)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_INDST_SW_REGULATED_ENTITY_INFO', N'MS_4_INDST_SW_ORDINANCE_STAT', N'MS_Description', CAST(N'MS4IndustrialStormwaterOrdinanceStatus' AS nvarchar(38)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_INDST_SW_REGULATED_ENTITY_INFO', N'MS_4_INDST_SW_ORDINANCE_STAT_TXT', N'MS_Description', CAST(N'MS4IndustrialStormwaterOrdinanceStatusText' AS nvarchar(42)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_INDST_SW_REGULATED_ENTITY_INFO', N'MS_4_INDST_SW_INDST_INVENTORY_STAT', N'MS_Description', CAST(N'MS4IndustrialStormwaterIndustrialInventoryStatus' AS nvarchar(48)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_INDST_SW_REGULATED_ENTITY_INFO', N'MS_4_INDST_SW_INDST_INVENTORY_STAT_TXT', N'MS_Description', CAST(N'MS4IndustrialStormwaterIndustrialInventoryStatusText' AS nvarchar(52)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_INDST_SW_REGULATED_ENTITY_INFO', N'MS_4_INDST_SW_MON_STAT', N'MS_Description', CAST(N'MS4IndustrialStormwaterMonitoringStatus' AS nvarchar(39)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_INDST_SW_REGULATED_ENTITY_INFO', N'MS_4_INDST_SW_MON_STAT_TXT', N'MS_Description', CAST(N'MS4IndustrialStormwaterMonitoringStatusText' AS nvarchar(43)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CSO_LONG_TERM_CONTROL_PLAN', NULL, N'MS_Description', CAST(N'Schema element: CSOLongTermControlPlanData' AS nvarchar(42)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CSO_LONG_TERM_CONTROL_PLAN', N'SRC_SYSTM_IDENT', N'MS_Description', CAST(N'SourceSystemIdentifier' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CSO_LONG_TERM_CONTROL_PLAN', N'TRANSACTION_TYPE', N'MS_Description', CAST(N'TransactionType' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CSO_LONG_TERM_CONTROL_PLAN', N'TRANSACTION_TIMESTAMP', N'MS_Description', CAST(N'TransactionTimestamp' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CSO_LONG_TERM_CONTROL_PLAN', N'PRMT_IDENT', N'MS_Description', CAST(N'PermitIdentifier' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SEWER_OVRFLW_BYPASS_RCVG_WTR', NULL, N'MS_Description', CAST(N'Schema element: String' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SEWER_OVRFLW_BYPASS_RCVG_WTR', N'SEWER_OVRFLW_BYPASS_RCVG_WTR', N'MS_Description', CAST(N'SewerOverflowBypassReceivingWater' AS nvarchar(33)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_INDST_SW_REQS', NULL, N'MS_Description', CAST(N'Schema element: MS4IndustrialStormwaterRequirements' AS nvarchar(51)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CWA_316B_PROG_REP', NULL, N'MS_Description', CAST(N'Schema element: CWA316bProgramReportData' AS nvarchar(40)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CWA_316B_PROG_REP', N'SRC_SYSTM_IDENT', N'MS_Description', CAST(N'SourceSystemIdentifier' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CWA_316B_PROG_REP', N'TRANSACTION_TYPE', N'MS_Description', CAST(N'TransactionType' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CWA_316B_PROG_REP', N'TRANSACTION_TIMESTAMP', N'MS_Description', CAST(N'TransactionTimestamp' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CWA_316B_PROG_REP', N'PRMT_IDENT', N'MS_Description', CAST(N'PermitIdentifier' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CWA_316B_PROG_REP', N'PROG_REP_FORM_SET_ID', N'MS_Description', CAST(N'ProgramReportFormSetID' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CWA_316B_PROG_REP', N'PROG_REP_FORM_ID', N'MS_Description', CAST(N'ProgramReportFormID' AS nvarchar(19)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CWA_316B_PROG_REP', N'PROG_REP_RCVD_DATE', N'MS_Description', CAST(N'ProgramReportReceivedDate' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CWA_316B_PROG_REP', N'PROG_REP_START_DATE', N'MS_Description', CAST(N'ProgramReportStartDate' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CWA_316B_PROG_REP', N'PROG_REP_END_DATE', N'MS_Description', CAST(N'ProgramReportEndDate' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CWA_316B_PROG_REP', N'ELEC_SUBM_TYPE_CODE', N'MS_Description', CAST(N'ElectronicSubmissionTypeCode' AS nvarchar(28)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CWA_316B_PROG_REP', N'PROG_REP_NPDES_DAT_GRP_NUM_CODE', N'MS_Description', CAST(N'ProgramReportNPDESDataGroupNumberCode' AS nvarchar(37)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CWA_316B_PROG_REP', N'CWA_316B_CRIT_HABITAT_PROTECTION_MSR', N'MS_Description', CAST(N'CWA316bCriticalHabitatProtectionMeasures' AS nvarchar(40)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CWA_316B_PROG_REP', N'CWA_316B_OTHR_MON_INFO', N'MS_Description', CAST(N'CWA316bOtherMonitoringInformation' AS nvarchar(33)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SEWER_OVRFLW_BYPASS_REP_EVT', NULL, N'MS_Description', CAST(N'Schema element: SewerOverflowBypassReportEvent' AS nvarchar(46)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SEWER_OVRFLW_BYPASS_REP_EVT', N'LAT_MEAS', N'MS_Description', CAST(N'LatitudeMeasure' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SEWER_OVRFLW_BYPASS_REP_EVT', N'LONG_MEAS', N'MS_Description', CAST(N'LongitudeMeasure' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SEWER_OVRFLW_BYPASS_REP_EVT', N'PRMT_FEATR_IDENT', N'MS_Description', CAST(N'PermittedFeatureIdentifier' AS nvarchar(26)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SEWER_OVRFLW_BYPASS_REP_EVT', N'DSCH_QUANTIFICATION_METHOD_CODE', N'MS_Description', CAST(N'DischargeQuantificationMethodCode' AS nvarchar(33)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SEWER_OVRFLW_BYPASS_REP_EVT', N'SEWER_OVRFLW_BYPASS_DSCH_RATE_GPH', N'MS_Description', CAST(N'SewerOverflowBypassDischargeRateGPH' AS nvarchar(35)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SEWER_OVRFLW_BYPASS_REP_EVT', N'SEWER_OVRFLW_BYPASS_DSCH_VOL_GAL', N'MS_Description', CAST(N'SewerOverflowBypassDischargeVolumeGallons' AS nvarchar(41)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SEWER_OVRFLW_BYPASS_REP_EVT', N'SEWER_OVRFLW_BYPASS_EVT_ID', N'MS_Description', CAST(N'SewerOverflowBypassEventID' AS nvarchar(26)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SEWER_OVRFLW_BYPASS_REP_EVT', N'SEWER_OVRFLW_BYPASS_DESC_TXT', N'MS_Description', CAST(N'SewerOverflowBypassDescriptionText' AS nvarchar(34)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SEWER_OVRFLW_BYPASS_REP_EVT', N'SEWER_OVRFLW_BYPASS_REP_REQ_CODE', N'MS_Description', CAST(N'SewerOverflowBypassReportingRequirementCode' AS nvarchar(43)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SEWER_OVRFLW_BYPASS_REP_EVT', N'WET_WEATHER_OCCURANCE_IND', N'MS_Description', CAST(N'WetWeatherOccuranceIndicator' AS nvarchar(28)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SEWER_OVRFLW_BYPASS_REP_EVT', N'SEWER_OVRFLW_STRCT_TYPE_CODE', N'MS_Description', CAST(N'SewerOverflowStructureTypeCode' AS nvarchar(30)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SEWER_OVRFLW_BYPASS_REP_EVT', N'SEWER_OVRFLW_STRCT_TYPE_CODE_OTHR_TXT', N'MS_Description', CAST(N'SewerOverflowStructureTypeCodeOtherText' AS nvarchar(39)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SEWER_OVRFLW_BYPASS_REP_EVT', N'COLL_SYSTM_IDENT', N'MS_Description', CAST(N'CollectionSystemIdentifier' AS nvarchar(26)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SEWER_OVRFLW_BYPASS_REP_EVT', N'ANTICIPATED_BYPASS_TXT', N'MS_Description', CAST(N'AnticipatedBypassText' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SEWER_OVRFLW_BYPASS_REP_EVT', N'ANTICIPATED_BYPASS_EXPECT_LMT_VIOL', N'MS_Description', CAST(N'AnticipatedBypassExpectLimitViolation' AS nvarchar(37)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SEWER_OVRFLW_BYPASS_REP_EVT', N'ANTICIPATED_BYPASS_EXPECT_LMT_VIOL_TXT', N'MS_Description', CAST(N'AnticipatedBypassExpectLimitViolationText' AS nvarchar(41)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SEWER_OVRFLW_BYPASS_REP_EVT', N'SEWER_OVRFLW_BYPASS_DURATION_HOURS', N'MS_Description', CAST(N'SewerOverflowBypassDurationHours' AS nvarchar(32)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SEWER_OVRFLW_BYPASS_REP_EVT', N'SEWER_OVRFLW_BYPASS_START_DATE_TIME', N'MS_Description', CAST(N'SewerOverflowBypassStartDateTime' AS nvarchar(32)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SEWER_OVRFLW_BYPASS_REP_EVT', N'SEWER_OVRFLW_BYPASS_END_DATE_TIME', N'MS_Description', CAST(N'SewerOverflowBypassEndDateTime' AS nvarchar(30)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_OTHR_APPL_REQS', NULL, N'MS_Description', CAST(N'Schema element: MS4OtherApplicableRequirements' AS nvarchar(46)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_OTHR_APPL_REQS', N'MS_4_ACTY_IDENT', N'MS_Description', CAST(N'MS4ActivityIdentifier' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_OTHR_APPL_REQS', N'MS_4_OTHR_APPL_REQS_TXT', N'MS_Description', CAST(N'MS4OtherApplicableRequirementsText' AS nvarchar(34)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_OTHR_APPL_REQS', N'MS_4_OTHR_APPL_REQS_SCHD_TXT', N'MS_Description', CAST(N'MS4OtherApplicableRequirementsScheduleText' AS nvarchar(42)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CWA_316B_TAKE_INFO', NULL, N'MS_Description', CAST(N'Schema element: CWA316bTakeInformation' AS nvarchar(38)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CWA_316B_TAKE_INFO', N'CWA_316B_TAKE_IDENT', N'MS_Description', CAST(N'CWA316bTakeIdentifier' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CWA_316B_TAKE_INFO', N'CWA_316B_SPECIES_NAME', N'MS_Description', CAST(N'CWA316bSpeciesName' AS nvarchar(18)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CWA_316B_TAKE_INFO', N'CWA_316B_SPECIES_COMMON_NAME', N'MS_Description', CAST(N'CWA316bSpeciesCommonName' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CWA_316B_TAKE_INFO', N'CWA_316B_FEDR_STAT', N'MS_Description', CAST(N'CWA316bFederalStatus' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CWA_316B_TAKE_INFO', N'CWA_316B_LIFESTAGE_CODE', N'MS_Description', CAST(N'CWA316bLifestageCode' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CWA_316B_TAKE_INFO', N'CWA_316B_TAKE_METHOD_CODE', N'MS_Description', CAST(N'CWA316bTakeMethodCode' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CWA_316B_TAKE_INFO', N'CWA_316B_TAKE_METHOD_OTHR_TXT', N'MS_Description', CAST(N'CWA316bTakeMethodOtherText' AS nvarchar(26)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CWA_316B_TAKE_INFO', N'CWA_316B_TAKE_TYPE_CODE', N'MS_Description', CAST(N'CWA316bTakeTypeCode' AS nvarchar(19)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CWA_316B_TAKE_INFO', N'CWA_316B_TAKE_TYPE_OTHR_TXT', N'MS_Description', CAST(N'CWA316bTakeTypeOtherText' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CWA_316B_TAKE_INFO', N'CWA_316B_SPECIES_NUM', N'MS_Description', CAST(N'CWA316bSpeciesNumber' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CWA_316B_TAKE_INFO', N'CWA_316B_SPECIES_NUM_IMPINGED_ENTRAINED', N'MS_Description', CAST(N'CWA316bSpeciesNumberImpingedEntrained' AS nvarchar(37)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CWA_316B_TAKE_INFO', N'CWA_316B_SPECIES_NUM_IMPINGED_ENTRAINED_DATE', N'MS_Description', CAST(N'CWA316bSpeciesNumberImpingedEntrainedDate' AS nvarchar(41)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SEWER_OVRFLW_BYPASS_TYPE', NULL, N'MS_Description', CAST(N'Schema element: String' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SEWER_OVRFLW_BYPASS_TYPE', N'SEWER_OVRFLW_BYPASS_TYPE_CODE', N'MS_Description', CAST(N'SewerOverflowBypassTypeCode' AS nvarchar(27)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_PBLC_EDUCATION_REQS', NULL, N'MS_Description', CAST(N'Schema element: MS4PublicEducationRequirements' AS nvarchar(46)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_PBLC_EDUCATION_REQS', N'MS_4_ACTY_IDENT', N'MS_Description', CAST(N'MS4ActivityIdentifier' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_PBLC_EDUCATION_REQS', N'MS_4_PBLC_EDUCATION_REQS_TXT', N'MS_Description', CAST(N'MS4PublicEducationRequirementsText' AS nvarchar(34)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_PBLC_EDUCATION_REQS', N'MS_4_PBLC_EDUCATION_SCHD_TXT', N'MS_Description', CAST(N'MS4PublicEducationScheduleText' AS nvarchar(30)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_PBLC_EDUCATION_REQS', N'MS_4_PBLC_EDUCATION_DELIVERY_OPTION', N'MS_Description', CAST(N'MS4PublicEducationDeliveryOption' AS nvarchar(32)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_PBLC_EDUCATION_REQS', N'MS_4_PBLC_EDUCATION_DELIVERY_OPTION_OTHR_TXT', N'MS_Description', CAST(N'MS4PublicEducationDeliveryOptionOtherText' AS nvarchar(41)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_PBLC_EDUCATION_REQS', N'MS_4_PBLC_EDUCATION_SUBJECT_OPTION', N'MS_Description', CAST(N'MS4PublicEducationSubjectOption' AS nvarchar(31)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_PBLC_EDUCATION_REQS', N'MS_4_PBLC_EDUCATION_SUBJECT_OPTION_OTHR_TXT', N'MS_Description', CAST(N'MS4PublicEducationSubjectOptionOtherText' AS nvarchar(40)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_PBLC_EDUCATION_REQS', N'MS_4_PBLC_EDUCATION_AUDIENCE_OPTION', N'MS_Description', CAST(N'MS4PublicEducationAudienceOption' AS nvarchar(32)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_PBLC_EDUCATION_REQS', N'MS_4_PBLC_EDUCATION_AUDIENCE_OPTION_OTHR_TXT', N'MS_Description', CAST(N'MS4PublicEducationAudienceOptionOtherText' AS nvarchar(41)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_DMR_VIOL', NULL, N'MS_Description', CAST(N'Schema element: DMRViolationData' AS nvarchar(32)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_DMR_VIOL', N'SRC_SYSTM_IDENT', N'MS_Description', CAST(N'SourceSystemIdentifier' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_DMR_VIOL', N'TRANSACTION_TYPE', N'MS_Description', CAST(N'TransactionType' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_DMR_VIOL', N'TRANSACTION_TIMESTAMP', N'MS_Description', CAST(N'TransactionTimestamp' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_DMR_VIOL', N'PRMT_IDENT', N'MS_Description', CAST(N'PermitIdentifier' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_DMR_VIOL', N'PRMT_FEATR_IDENT', N'MS_Description', CAST(N'PermittedFeatureIdentifier' AS nvarchar(26)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_DMR_VIOL', N'LMT_SET_DESIGNATOR', N'MS_Description', CAST(N'LimitSetDesignator' AS nvarchar(18)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_DMR_VIOL', N'MON_PERIOD_END_DATE', N'MS_Description', CAST(N'MonitoringPeriodEndDate' AS nvarchar(23)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_DMR_VIOL', N'PARAM_CODE', N'MS_Description', CAST(N'ParameterCode' AS nvarchar(13)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_DMR_VIOL', N'MON_SITE_DESC_CODE', N'MS_Description', CAST(N'MonitoringSiteDescriptionCode' AS nvarchar(29)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_DMR_VIOL', N'LMT_SEASON_NUM', N'MS_Description', CAST(N'LimitSeasonNumber' AS nvarchar(17)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_DMR_VIOL', N'NUM_REP_CODE', N'MS_Description', CAST(N'NumericReportCode' AS nvarchar(17)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_DMR_VIOL', N'NUM_REP_VIOL_CODE', N'MS_Description', CAST(N'NumericReportViolationCode' AS nvarchar(26)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_DMR_VIOL', N'REP_NON_CMPL_DETECT_CODE', N'MS_Description', CAST(N'ReportableNonComplianceDetectionCode' AS nvarchar(36)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_DMR_VIOL', N'REP_NON_CMPL_DETECT_DATE', N'MS_Description', CAST(N'ReportableNonComplianceDetectionDate' AS nvarchar(36)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_DMR_VIOL', N'REP_NON_CMPL_RESL_CODE', N'MS_Description', CAST(N'ReportableNonComplianceResolutionCode' AS nvarchar(37)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_DMR_VIOL', N'REP_NON_CMPL_RESL_DATE', N'MS_Description', CAST(N'ReportableNonComplianceResolutionDate' AS nvarchar(37)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SEWER_OVRFLW_TRTMNT', NULL, N'MS_Description', CAST(N'Schema element: String' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SEWER_OVRFLW_TRTMNT', N'SEWER_OVRFLW_TRTMNT_CODE', N'MS_Description', CAST(N'SewerOverflowTreatmentCode' AS nvarchar(26)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_PBLC_INVOLVEMENT_REQS', NULL, N'MS_Description', CAST(N'Schema element: MS4PublicInvolvementRequirements' AS nvarchar(48)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_PBLC_INVOLVEMENT_REQS', N'MS_4_ACTY_IDENT', N'MS_Description', CAST(N'MS4ActivityIdentifier' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_PBLC_INVOLVEMENT_REQS', N'MS_4_PBLC_INVOLVEMENT_REQS_TXT', N'MS_Description', CAST(N'MS4PublicInvolvementRequirementsText' AS nvarchar(36)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_PBLC_INVOLVEMENT_REQS', N'MS_4_PBLC_INVOLVEMENT_SCHD_TXT', N'MS_Description', CAST(N'MS4PublicInvolvementScheduleText' AS nvarchar(32)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_PBLC_INVOLVEMENT_REQS', N'MS_4_PBLC_INVOLVEMENT_DELIVERY_OPTION', N'MS_Description', CAST(N'MS4PublicInvolvementDeliveryOption' AS nvarchar(34)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_PBLC_INVOLVEMENT_REQS', N'MS_4_PBLC_INVOLVEMENT_DELIVERY_OPTION_OTHR_TXT', N'MS_Description', CAST(N'MS4PublicInvolvementDeliveryOptionOtherText' AS nvarchar(43)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_PBLC_INVOLVEMENT_REQS', N'MS_4_PBLC_INVOLVEMENT_SUBJECT_OPTION', N'MS_Description', CAST(N'MS4PublicInvolvementSubjectOption' AS nvarchar(33)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_PBLC_INVOLVEMENT_REQS', N'MS_4_PBLC_INVOLVEMENT_SUBJECT_OPTION_OTHR_TXT', N'MS_Description', CAST(N'MS4PublicInvolvementSubjectOptionOtherText' AS nvarchar(42)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_PBLC_INVOLVEMENT_REQS', N'MS_4_PBLC_INVOLVEMENT_PARTICIPANT_OPTION', N'MS_Description', CAST(N'MS4PublicInvolvementParticipantOption' AS nvarchar(37)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_PBLC_INVOLVEMENT_REQS', N'MS_4_PBLC_INVOLVEMENT_PARTICIPANT_OPTION_OTHR_TXT', N'MS_Description', CAST(N'MS4PublicInvolvementParticipantOptionOtherText' AS nvarchar(46)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_DSCH_MON_REP', NULL, N'MS_Description', CAST(N'Schema element: DischargeMonitoringReportData' AS nvarchar(45)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_DSCH_MON_REP', N'SRC_SYSTM_IDENT', N'MS_Description', CAST(N'SourceSystemIdentifier' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_DSCH_MON_REP', N'TRANSACTION_TYPE', N'MS_Description', CAST(N'TransactionType' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_DSCH_MON_REP', N'TRANSACTION_TIMESTAMP', N'MS_Description', CAST(N'TransactionTimestamp' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_DSCH_MON_REP', N'PRMT_IDENT', N'MS_Description', CAST(N'PermitIdentifier' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_DSCH_MON_REP', N'PRMT_FEATR_IDENT', N'MS_Description', CAST(N'PermittedFeatureIdentifier' AS nvarchar(26)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_DSCH_MON_REP', N'LMT_SET_DESIGNATOR', N'MS_Description', CAST(N'LimitSetDesignator' AS nvarchar(18)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_DSCH_MON_REP', N'MON_PERIOD_END_DATE', N'MS_Description', CAST(N'MonitoringPeriodEndDate' AS nvarchar(23)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_DSCH_MON_REP', N'DMR_NO_DSCH_IND', N'MS_Description', CAST(N'DMRNoDischargeIndicator' AS nvarchar(23)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_DSCH_MON_REP', N'DMR_NO_DSCH_RCVD_DATE', N'MS_Description', CAST(N'DMRNoDischargeReceivedDate' AS nvarchar(26)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_DSCH_MON_REP', N'ELEC_SUBM_TYPE_CODE', N'MS_Description', CAST(N'ElectronicSubmissionTypeCode' AS nvarchar(28)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_DSCH_MON_REP', N'SIGN_DATE', N'MS_Description', CAST(N'SignatureDate' AS nvarchar(13)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_DSCH_MON_REP', N'PRNCPL_EXEC_OFFCR_FIRST_NAME', N'MS_Description', CAST(N'PrincipalExecutiveOfficerFirstName' AS nvarchar(34)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_DSCH_MON_REP', N'PRNCPL_EXEC_OFFCR_LAST_NAME', N'MS_Description', CAST(N'PrincipalExecutiveOfficerLastName' AS nvarchar(33)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_DSCH_MON_REP', N'PRNCPL_EXEC_OFFCR_TITLE', N'MS_Description', CAST(N'PrincipalExecutiveOfficerTitle' AS nvarchar(30)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_DSCH_MON_REP', N'PRNCPL_EXEC_OFFCR_TELEPH', N'MS_Description', CAST(N'PrincipalExecutiveOfficerTelephone' AS nvarchar(34)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_DSCH_MON_REP', N'SIGN_FIRST_NAME', N'MS_Description', CAST(N'SignatoryFirstName' AS nvarchar(18)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_DSCH_MON_REP', N'SIGN_LAST_NAME', N'MS_Description', CAST(N'SignatoryLastName' AS nvarchar(17)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_DSCH_MON_REP', N'SIGN_TELEPH', N'MS_Description', CAST(N'SignatoryTelephone' AS nvarchar(18)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_DSCH_MON_REP', N'REP_CMNT_TXT', N'MS_Description', CAST(N'ReportCommentText' AS nvarchar(17)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SIC_CODE', NULL, N'MS_Description', CAST(N'Schema element: SICCodeDetails' AS nvarchar(30)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SIC_CODE', N'SIC_CODE', N'MS_Description', CAST(N'SICCode' AS nvarchar(7)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SIC_CODE', N'SIC_PRIMARY_IND_CODE', N'MS_Description', CAST(N'SICPrimaryIndicatorCode' AS nvarchar(23)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_POLLUTION_PREVENTION_REQS', NULL, N'MS_Description', CAST(N'Schema element: MS4PollutionPreventionRequirements' AS nvarchar(50)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_POLLUTION_PREVENTION_REQS', N'MS_4_ACTY_IDENT', N'MS_Description', CAST(N'MS4ActivityIdentifier' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_POLLUTION_PREVENTION_REQS', N'MS_4_POLLUTION_PREVENTION_REQS_TXT', N'MS_Description', CAST(N'MS4PollutionPreventionRequirementsText' AS nvarchar(38)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_POLLUTION_PREVENTION_REQS', N'MS_4_POLLUTION_PREVENTION_SCHD_TXT', N'MS_Description', CAST(N'MS4PollutionPreventionScheduleText' AS nvarchar(34)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_DSCH_MON_REP_PARAM_VIOL', NULL, N'MS_Description', CAST(N'Schema element: DischargeMonitoringReportParameterViolation' AS nvarchar(59)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_DSCH_MON_REP_PARAM_VIOL', N'PRMT_IDENT', N'MS_Description', CAST(N'PermitIdentifier' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_DSCH_MON_REP_PARAM_VIOL', N'PRMT_FEATR_IDENT', N'MS_Description', CAST(N'PermittedFeatureIdentifier' AS nvarchar(26)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_DSCH_MON_REP_PARAM_VIOL', N'LMT_SET_DESIGNATOR', N'MS_Description', CAST(N'LimitSetDesignator' AS nvarchar(18)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_DSCH_MON_REP_PARAM_VIOL', N'MON_PERIOD_END_DATE', N'MS_Description', CAST(N'MonitoringPeriodEndDate' AS nvarchar(23)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_DSCH_MON_REP_PARAM_VIOL', N'PARAM_CODE', N'MS_Description', CAST(N'ParameterCode' AS nvarchar(13)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_DSCH_MON_REP_PARAM_VIOL', N'MON_SITE_DESC_CODE', N'MS_Description', CAST(N'MonitoringSiteDescriptionCode' AS nvarchar(29)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_DSCH_MON_REP_PARAM_VIOL', N'LMT_SEASON_NUM', N'MS_Description', CAST(N'LimitSeasonNumber' AS nvarchar(17)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SIU_DESGN_TYPE', NULL, N'MS_Description', CAST(N'Schema element: String' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SIU_DESGN_TYPE', N'SIU_DESGN_TYPE', N'MS_Description', CAST(N'SIUDesignationType' AS nvarchar(18)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_POST_CNST_SW_PROCEDURES', NULL, N'MS_Description', CAST(N'Schema element: MS4PostConstructionStormwaterProcedures' AS nvarchar(55)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_POST_CNST_SW_PROCEDURES', N'MS_4_ACTY_IDENT', N'MS_Description', CAST(N'MS4ActivityIdentifier' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_POST_CNST_SW_PROCEDURES', N'MS_4_POST_CNST_SW_PROCEDURE_TYPE', N'MS_Description', CAST(N'MS4PostConstructionStormwaterProcedureType' AS nvarchar(42)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_POST_CNST_SW_PROCEDURES', N'MS_4_POST_CNST_SW_PROCEDURE_TXT', N'MS_Description', CAST(N'MS4PostConstructionStormwaterProcedureText' AS nvarchar(42)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_POST_CNST_SW_PROCEDURES', N'MS_4_POST_CNST_SW_PROCEDURE_SCHD_TXT', N'MS_Description', CAST(N'MS4PostConstructionStormwaterProcedureScheduleText' AS nvarchar(50)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_DSCH_MON_REP_VIOL', NULL, N'MS_Description', CAST(N'Schema element: DischargeMonitoringReportViolation' AS nvarchar(50)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_DSCH_MON_REP_VIOL', N'PRMT_IDENT', N'MS_Description', CAST(N'PermitIdentifier' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_DSCH_MON_REP_VIOL', N'PRMT_FEATR_IDENT', N'MS_Description', CAST(N'PermittedFeatureIdentifier' AS nvarchar(26)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_DSCH_MON_REP_VIOL', N'LMT_SET_DESIGNATOR', N'MS_Description', CAST(N'LimitSetDesignator' AS nvarchar(18)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_DSCH_MON_REP_VIOL', N'MON_PERIOD_END_DATE', N'MS_Description', CAST(N'MonitoringPeriodEndDate' AS nvarchar(23)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SNC_LISTING_MONTHS', NULL, N'MS_Description', CAST(N'Schema element: String' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SNC_LISTING_MONTHS', N'SNC_LISTING_MONTHS', N'MS_Description', CAST(N'SNCListingMonths' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_POST_CNST_SW_REGULATED_ENTITY_INFO', NULL, N'MS_Description', CAST(N'Schema element: MS4PostConstructionStormwaterRegulatedEntityInformation' AS nvarchar(71)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_POST_CNST_SW_REGULATED_ENTITY_INFO', N'MS_4_ACTY_IDENT', N'MS_Description', CAST(N'MS4ActivityIdentifier' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_POST_CNST_SW_REGULATED_ENTITY_INFO', N'MS_4_REGULATED_ENTITY_IDENT', N'MS_Description', CAST(N'MS4RegulatedEntityIdentifier' AS nvarchar(28)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_POST_CNST_SW_REGULATED_ENTITY_INFO', N'MS_4_POST_CNST_SW_RUNOFF_ORDINANCE_STAT', N'MS_Description', CAST(N'MS4PostConstructionStormwaterRunoffOrdinanceStatus' AS nvarchar(50)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_POST_CNST_SW_REGULATED_ENTITY_INFO', N'MS_4_POST_CNST_SW_RUNOFF_ORDINANCE_STAT_TXT', N'MS_Description', CAST(N'MS4PostConstructionStormwaterRunoffOrdinanceStatusText' AS nvarchar(54)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_POST_CNST_SW_REGULATED_ENTITY_INFO', N'MS_4_POST_CNST_SW_RUNOFF_PROG_STAT', N'MS_Description', CAST(N'MS4PostConstructionStormwaterRunoffProgramStatus' AS nvarchar(48)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_POST_CNST_SW_REGULATED_ENTITY_INFO', N'MS_4_POST_CNST_SW_RUNOFF_PROG_STAT_TXT', N'MS_Description', CAST(N'MS4PostConstructionStormwaterRunoffProgramStatusText' AS nvarchar(52)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_POST_CNST_SW_REGULATED_ENTITY_INFO', N'MS_4_POST_CNST_SW_RUNOFF_BMP_STAT', N'MS_Description', CAST(N'MS4PostConstructionStormwaterRunoffBMPStatus' AS nvarchar(44)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_POST_CNST_SW_REGULATED_ENTITY_INFO', N'MS_4_POST_CNST_SW_RUNOFF_BMP_STAT_TXT', N'MS_Description', CAST(N'MS4PostConstructionStormwaterRunoffBMPStatusText' AS nvarchar(48)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_EFFLU_GUIDE', NULL, N'MS_Description', CAST(N'Schema element: String' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_EFFLU_GUIDE', N'EFFLU_GUIDE_CODE', N'MS_Description', CAST(N'EffluentGuidelineCode' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SNC_PRETR_STND_LMTS_PARAMETERS', NULL, N'MS_Description', CAST(N'Schema element: String' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SNC_PRETR_STND_LMTS_PARAMETERS', N'SNC_PRETR_STND_LMTS_PARAMETERS', N'MS_Description', CAST(N'SNCPretrStndLimitsParameters' AS nvarchar(28)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_POST_CNST_SW_REQS', NULL, N'MS_Description', CAST(N'Schema element: MS4PostConstructionStormwaterRequirements' AS nvarchar(57)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_EFFLU_TRADE_PRTNER', NULL, N'MS_Description', CAST(N'Schema element: EffluentTradePartnerData' AS nvarchar(40)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_EFFLU_TRADE_PRTNER', N'SRC_SYSTM_IDENT', N'MS_Description', CAST(N'SourceSystemIdentifier' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_EFFLU_TRADE_PRTNER', N'TRANSACTION_TYPE', N'MS_Description', CAST(N'TransactionType' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_EFFLU_TRADE_PRTNER', N'TRANSACTION_TIMESTAMP', N'MS_Description', CAST(N'TransactionTimestamp' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_EFFLU_TRADE_PRTNER', N'PRMT_IDENT', N'MS_Description', CAST(N'PermitIdentifier' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_EFFLU_TRADE_PRTNER', N'PRMT_FEATR_IDENT', N'MS_Description', CAST(N'PermittedFeatureIdentifier' AS nvarchar(26)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_EFFLU_TRADE_PRTNER', N'LMT_SET_DESIGNATOR', N'MS_Description', CAST(N'LimitSetDesignator' AS nvarchar(18)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_EFFLU_TRADE_PRTNER', N'PARAM_CODE', N'MS_Description', CAST(N'ParameterCode' AS nvarchar(13)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_EFFLU_TRADE_PRTNER', N'MON_SITE_DESC_CODE', N'MS_Description', CAST(N'MonitoringSiteDescriptionCode' AS nvarchar(29)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_EFFLU_TRADE_PRTNER', N'LMT_SEASON_NUM', N'MS_Description', CAST(N'LimitSeasonNumber' AS nvarchar(17)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_EFFLU_TRADE_PRTNER', N'LMT_START_DATE', N'MS_Description', CAST(N'LimitStartDate' AS nvarchar(14)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_EFFLU_TRADE_PRTNER', N'LMT_END_DATE', N'MS_Description', CAST(N'LimitEndDate' AS nvarchar(12)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_EFFLU_TRADE_PRTNER', N'LMT_MOD_EFFECTIVE_DATE', N'MS_Description', CAST(N'LimitModificationEffectiveDate' AS nvarchar(30)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_EFFLU_TRADE_PRTNER', N'TRADE_ID', N'MS_Description', CAST(N'TradeID' AS nvarchar(7)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_EFFLU_TRADE_PRTNER', N'TRADE_PRTNER_NPDESID', N'MS_Description', CAST(N'TradePartnerNPDESID' AS nvarchar(19)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_EFFLU_TRADE_PRTNER', N'TRADE_PRTNER_OTHR_ID', N'MS_Description', CAST(N'TradePartnerOtherID' AS nvarchar(19)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_EFFLU_TRADE_PRTNER', N'TRADE_PRTNER_TYPE', N'MS_Description', CAST(N'TradePartnerType' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_EFFLU_TRADE_PRTNER', N'TRADE_PRTNER_START_DATE', N'MS_Description', CAST(N'TradePartnerStartDate' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_EFFLU_TRADE_PRTNER', N'TRADE_PRTNER_END_DATE', N'MS_Description', CAST(N'TradePartnerEndDate' AS nvarchar(19)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SNGL_EVT_VIOL', NULL, N'MS_Description', CAST(N'Schema element: SingleEventViolationData' AS nvarchar(40)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SNGL_EVT_VIOL', N'SRC_SYSTM_IDENT', N'MS_Description', CAST(N'SourceSystemIdentifier' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SNGL_EVT_VIOL', N'TRANSACTION_TYPE', N'MS_Description', CAST(N'TransactionType' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SNGL_EVT_VIOL', N'TRANSACTION_TIMESTAMP', N'MS_Description', CAST(N'TransactionTimestamp' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SNGL_EVT_VIOL', N'PRMT_IDENT', N'MS_Description', CAST(N'PermitIdentifier' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SNGL_EVT_VIOL', N'SNGL_EVT_VIOL_CODE', N'MS_Description', CAST(N'SingleEventViolationCode' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SNGL_EVT_VIOL', N'SNGL_EVT_VIOL_DATE', N'MS_Description', CAST(N'SingleEventViolationDate' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SNGL_EVT_VIOL', N'SNGL_EVT_VIOL_END_DATE', N'MS_Description', CAST(N'SingleEventViolationEndDate' AS nvarchar(27)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SNGL_EVT_VIOL', N'REP_NON_CMPL_DETECT_CODE', N'MS_Description', CAST(N'ReportableNonComplianceDetectionCode' AS nvarchar(36)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SNGL_EVT_VIOL', N'REP_NON_CMPL_DETECT_DATE', N'MS_Description', CAST(N'ReportableNonComplianceDetectionDate' AS nvarchar(36)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SNGL_EVT_VIOL', N'REP_NON_CMPL_RESL_CODE', N'MS_Description', CAST(N'ReportableNonComplianceResolutionCode' AS nvarchar(37)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SNGL_EVT_VIOL', N'REP_NON_CMPL_RESL_DATE', N'MS_Description', CAST(N'ReportableNonComplianceResolutionDate' AS nvarchar(37)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SNGL_EVT_VIOL', N'SNGL_EVT_USR_DFND_FLD_1', N'MS_Description', CAST(N'SingleEventUserDefinedField1' AS nvarchar(28)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SNGL_EVT_VIOL', N'SNGL_EVT_USR_DFND_FLD_2', N'MS_Description', CAST(N'SingleEventUserDefinedField2' AS nvarchar(28)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SNGL_EVT_VIOL', N'SNGL_EVT_USR_DFND_FLD_3', N'MS_Description', CAST(N'SingleEventUserDefinedField3' AS nvarchar(28)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SNGL_EVT_VIOL', N'SNGL_EVT_USR_DFND_FLD_4', N'MS_Description', CAST(N'SingleEventUserDefinedField4' AS nvarchar(28)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SNGL_EVT_VIOL', N'SNGL_EVT_USR_DFND_FLD_5', N'MS_Description', CAST(N'SingleEventUserDefinedField5' AS nvarchar(28)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SNGL_EVT_VIOL', N'SNGL_EVT_CMNT_TXT', N'MS_Description', CAST(N'SingleEventCommentText' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_PROG_REP_ANALYSIS', NULL, N'MS_Description', CAST(N'Schema element: MS4ProgramReportAnalysis' AS nvarchar(40)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_PROG_REP_ANALYSIS', N'MS_4_PROG_REP_ANALYSIS_TXT', N'MS_Description', CAST(N'MS4ProgramReportAnalysisText' AS nvarchar(28)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_EFFLU_TRADE_PRTNER_ADDR', NULL, N'MS_Description', CAST(N'Schema element: EffluentTradePartnerAddress' AS nvarchar(43)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_EFFLU_TRADE_PRTNER_ADDR', N'ORG_FRML_NAME', N'MS_Description', CAST(N'OrganizationFormalName' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_EFFLU_TRADE_PRTNER_ADDR', N'ORG_DUNS_NUM', N'MS_Description', CAST(N'OrganizationDUNSNumber' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_EFFLU_TRADE_PRTNER_ADDR', N'LOC_NAME', N'MS_Description', CAST(N'LocationName' AS nvarchar(12)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_EFFLU_TRADE_PRTNER_ADDR', N'MAILING_ADDR_TXT', N'MS_Description', CAST(N'MailingAddressText' AS nvarchar(18)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_EFFLU_TRADE_PRTNER_ADDR', N'SUPPL_ADDR_TXT', N'MS_Description', CAST(N'SupplementalAddressText' AS nvarchar(23)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_EFFLU_TRADE_PRTNER_ADDR', N'MAILING_ADDR_CITY_NAME', N'MS_Description', CAST(N'MailingAddressCityName' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_EFFLU_TRADE_PRTNER_ADDR', N'MAILING_ADDR_COUNTRY_CODE', N'MS_Description', CAST(N'MailingAddressCountryCode' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_EFFLU_TRADE_PRTNER_ADDR', N'LOC_PROVINCE', N'MS_Description', CAST(N'LocationProvince' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_EFFLU_TRADE_PRTNER_ADDR', N'MAILING_ADDR_ST_CODE', N'MS_Description', CAST(N'MailingAddressStateCode' AS nvarchar(23)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_EFFLU_TRADE_PRTNER_ADDR', N'MAILING_ADDR_ZIP_CODE', N'MS_Description', CAST(N'MailingAddressZipCode' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_EFFLU_TRADE_PRTNER_ADDR', N'COUNTY_NAME', N'MS_Description', CAST(N'CountyName' AS nvarchar(10)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_EFFLU_TRADE_PRTNER_ADDR', N'DIVISION_NAME', N'MS_Description', CAST(N'DivisionName' AS nvarchar(12)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_EFFLU_TRADE_PRTNER_ADDR', N'ELEC_ADDR_TXT', N'MS_Description', CAST(N'ElectronicAddressText' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SNGL_EVTS_VIOL', NULL, N'MS_Description', CAST(N'Schema element: SingleEventsViolation' AS nvarchar(37)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SNGL_EVTS_VIOL', N'PRMT_IDENT', N'MS_Description', CAST(N'PermitIdentifier' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SNGL_EVTS_VIOL', N'SNGL_EVT_VIOL_CODE', N'MS_Description', CAST(N'SingleEventViolationCode' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SNGL_EVTS_VIOL', N'SNGL_EVT_VIOL_DATE', N'MS_Description', CAST(N'SingleEventViolationDate' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY', NULL, N'MS_Description', CAST(N'Schema element: MS4ProgramReportRequirementsRegulatedEntity' AS nvarchar(59)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY', N'MS_4_ACTY_IDENT', N'MS_Description', CAST(N'MS4ActivityIdentifier' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY', N'MS_4_REGULATED_ENTITY_CMPL_STAT', N'MS_Description', CAST(N'MS4RegulatedEntityComplianceStatus' AS nvarchar(34)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY', N'MS_4_REGULATED_ENTITY_CMPL_STAT_TXT', N'MS_Description', CAST(N'MS4RegulatedEntityComplianceStatusText' AS nvarchar(38)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY', N'MS_4_PROG_REP_REQS_ACTIVITIES', N'MS_Description', CAST(N'MS4ProgramReportRequirementsActivities' AS nvarchar(38)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_ENFRC_ACTN_GOV_CONTACT', NULL, N'MS_Description', CAST(N'Schema element: EnforcementActionGovernmentContact' AS nvarchar(50)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_ENFRC_ACTN_GOV_CONTACT', N'AFFIL_TYPE_TXT', N'MS_Description', CAST(N'AffiliationTypeText' AS nvarchar(19)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_ENFRC_ACTN_GOV_CONTACT', N'ELEC_ADDR_TXT', N'MS_Description', CAST(N'ElectronicAddressText' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_ENFRC_ACTN_GOV_CONTACT', N'START_DATE_OF_CONTACT_ASSC', N'MS_Description', CAST(N'StartDateOfContactAssociation' AS nvarchar(29)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_ENFRC_ACTN_GOV_CONTACT', N'END_DATE_OF_CONTACT_ASSC', N'MS_Description', CAST(N'EndDateOfContactAssociation' AS nvarchar(27)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SSO_INSP', NULL, N'MS_Description', CAST(N'Schema element: SSOInspection' AS nvarchar(29)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SSO_INSP', N'SSO_EVT_DATE', N'MS_Description', CAST(N'SSOEventDate' AS nvarchar(12)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SSO_INSP', N'CAUSE_SSO_OVRFLW_EVT', N'MS_Description', CAST(N'CauseSSOOverflowEvent' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SSO_INSP', N'LAT_MEAS', N'MS_Description', CAST(N'LatitudeMeasure' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SSO_INSP', N'LONG_MEAS', N'MS_Description', CAST(N'LongitudeMeasure' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SSO_INSP', N'SSO_OVRFLW_LOC_STREET', N'MS_Description', CAST(N'SSOOverflowLocationStreet' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SSO_INSP', N'DURATION_SSO_OVRFLW_EVT', N'MS_Description', CAST(N'DurationSSOOverflowEvent' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SSO_INSP', N'SSO_VOL', N'MS_Description', CAST(N'SSOVolume' AS nvarchar(9)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SSO_INSP', N'NAME_RCVG_WTR', N'MS_Description', CAST(N'NameReceivingWater' AS nvarchar(18)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SSO_INSP', N'DESC_STPS_TAKEN', N'MS_Description', CAST(N'DescriptionStepsTaken' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_REGULATED_ENTITY', NULL, N'MS_Description', CAST(N'Schema element: MS4RegulatedEntity' AS nvarchar(34)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_REGULATED_ENTITY', N'MS_4_REGULATED_ENTITY_IDENT', N'MS_Description', CAST(N'MS4RegulatedEntityIdentifier' AS nvarchar(28)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_REGULATED_ENTITY', N'MS_4_REGULATED_ENTITY_NAME', N'MS_Description', CAST(N'MS4RegulatedEntityName' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_REGULATED_ENTITY', N'MS_4_REGULATED_ENTITY_OWNERSHIP_LEVEL_CODE', N'MS_Description', CAST(N'MS4RegulatedEntityOwnershipLevelCode' AS nvarchar(36)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_REGULATED_ENTITY', N'MS_4_REGULATED_ENTITY_OWNERSHIP_LEVEL_OTHR_TXT', N'MS_Description', CAST(N'MS4RegulatedEntityOwnershipLevelOtherText' AS nvarchar(41)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_REGULATED_ENTITY', N'MS_4_REGULATED_ENTITY_CATG_CODE', N'MS_Description', CAST(N'MS4RegulatedEntityCategoryCode' AS nvarchar(30)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_REGULATED_ENTITY', N'MS_4_REGULATED_ENTITY_CATG_CODE_OTHR_TXT', N'MS_Description', CAST(N'MS4RegulatedEntityCategoryCodeOtherText' AS nvarchar(39)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_ENFRC_ACTN_MILESTONE', NULL, N'MS_Description', CAST(N'Schema element: EnforcementActionMilestoneData' AS nvarchar(46)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_ENFRC_ACTN_MILESTONE', N'SRC_SYSTM_IDENT', N'MS_Description', CAST(N'SourceSystemIdentifier' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_ENFRC_ACTN_MILESTONE', N'TRANSACTION_TYPE', N'MS_Description', CAST(N'TransactionType' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_ENFRC_ACTN_MILESTONE', N'TRANSACTION_TIMESTAMP', N'MS_Description', CAST(N'TransactionTimestamp' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_ENFRC_ACTN_MILESTONE', N'ENFRC_ACTN_IDENT', N'MS_Description', CAST(N'EnforcementActionIdentifier' AS nvarchar(27)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_ENFRC_ACTN_MILESTONE', N'MILESTONE_TYPE_CODE', N'MS_Description', CAST(N'MilestoneTypeCode' AS nvarchar(17)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_ENFRC_ACTN_MILESTONE', N'MILESTONE_PLANNED_DATE', N'MS_Description', CAST(N'MilestonePlannedDate' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_ENFRC_ACTN_MILESTONE', N'MILESTONE_ACTUL_DATE', N'MS_Description', CAST(N'MilestoneActualDate' AS nvarchar(19)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SSO_STPS', NULL, N'MS_Description', CAST(N'Schema element: SSOSteps' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SSO_STPS', N'STPS_RDUCE_PREVNT_MITIGTE', N'MS_Description', CAST(N'StepsReducePreventMitigate' AS nvarchar(26)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SSO_STPS', N'OTHR_STPS_RDUCE_PREVNT_MITIGTE', N'MS_Description', CAST(N'OtherStepsReducePreventMitigate' AS nvarchar(31)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_REGULATED_ENTITY_AREA', NULL, N'MS_Description', CAST(N'Schema element: MS4RegulatedEntityArea' AS nvarchar(38)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_REGULATED_ENTITY_AREA', N'MS_4_REGULATED_ENTITY_AREA_NUM', N'MS_Description', CAST(N'MS4RegulatedEntityAreaNumber' AS nvarchar(28)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_REGULATED_ENTITY_AREA', N'MS_4_REGULATED_ENTITY_IDENT', N'MS_Description', CAST(N'MS4RegulatedEntityIdentifier' AS nvarchar(28)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_REGULATED_ENTITY_AREA', N'MS_4_REGULATED_ENTITY_AREA_STAT_CODE', N'MS_Description', CAST(N'MS4RegulatedEntityAreaStatusCode' AS nvarchar(32)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_REGULATED_ENTITY_AREA', N'MS_4_REGULATED_ENTITY_AREA_TXT', N'MS_Description', CAST(N'MS4RegulatedEntityAreaText' AS nvarchar(26)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_ENFRC_ACTN_TYPE', NULL, N'MS_Description', CAST(N'Schema element: String' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_ENFRC_ACTN_TYPE', N'ENFRC_ACTN_TYPE_CODE', N'MS_Description', CAST(N'EnforcementActionTypeCode' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SSO_SYSTM_COMP', NULL, N'MS_Description', CAST(N'Schema element: SSOSystemComponent' AS nvarchar(34)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SSO_SYSTM_COMP', N'SYSTM_COMP', N'MS_Description', CAST(N'SystemComponent' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SSO_SYSTM_COMP', N'OTHR_SYSTM_COMP', N'MS_Description', CAST(N'OtherSystemComponent' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_REGULATED_ENTITY_AREA_COORD', NULL, N'MS_Description', CAST(N'Schema element: MS4RegulatedEntityAreaCoordinates' AS nvarchar(49)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_REGULATED_ENTITY_AREA_COORD', N'LAT_MEAS', N'MS_Description', CAST(N'LatitudeMeasure' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_REGULATED_ENTITY_AREA_COORD', N'LONG_MEAS', N'MS_Description', CAST(N'LongitudeMeasure' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_ENFRC_ACTN_VIOL_LNK', NULL, N'MS_Description', CAST(N'Schema element: EnforcementActionViolationLinkageData' AS nvarchar(53)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_ENFRC_ACTN_VIOL_LNK', N'SRC_SYSTM_IDENT', N'MS_Description', CAST(N'SourceSystemIdentifier' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_ENFRC_ACTN_VIOL_LNK', N'TRANSACTION_TYPE', N'MS_Description', CAST(N'TransactionType' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_ENFRC_ACTN_VIOL_LNK', N'TRANSACTION_TIMESTAMP', N'MS_Description', CAST(N'TransactionTimestamp' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_ENFRC_ACTN_VIOL_LNK', N'ENFRC_ACTN_IDENT', N'MS_Description', CAST(N'EnforcementActionIdentifier' AS nvarchar(27)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_HIST', N'ICS_SUBM_HIST_ID', N'MS_Description', CAST(N'PK For ICS_SUBM_HIST' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_HIST', N'SUBM_DATE_TIME', N'MS_Description', CAST(N'Date and Time when the submission occurred' AS nvarchar(42)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_HIST', N'SUBM_TRANSACTION_ID', N'MS_Description', CAST(N'EN Transaction ID for the submission' AS nvarchar(36)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_HIST', N'SUBM_TYPE_NAME', N'MS_Description', CAST(N'The ICIS-NPDES submission type' AS nvarchar(30)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_HIST', N'TRANS_COUNT_NEW', N'MS_Description', CAST(N'The count of records in the local staging tables marked as (N)ew Transactions' AS nvarchar(77)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_HIST', N'TRANS_COUNT_CHNG_REPL', N'MS_Description', CAST(N'The count of records in the local staging tables marked as (C)hange or (R)eplace Transactions' AS nvarchar(93)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_HIST', N'TRANS_COUNT_DEL_MASS_DEL', N'MS_Description', CAST(N'The count of records in the local staging tables marked as (D)elete or (X) Mass Delete Transactions' AS nvarchar(99)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_HIST', N'ERROR_COUNT', N'MS_Description', CAST(N'The number of Errors returned from ICIS in the Rejected Transactions Report' AS nvarchar(75)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_HIST', N'WARNING_COUNT', N'MS_Description', CAST(N'The number of Warnings returned from ICIS in the Accepted Transactions Report' AS nvarchar(77)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_HIST', N'ACCEPTED_COUNT', N'MS_Description', CAST(N'The number of records returned from ICIS in the Accepted Transactions Report indicating successful processing' AS nvarchar(109)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_HIST', N'ACCEPTED_COUNT_TOTAL', N'MS_Description', CAST(N'The total number of records successfully sent to ICIS' AS nvarchar(53)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_HIST', N'CREATED_DATE_TIME', N'MS_Description', CAST(N'The date and time when this record was created.' AS nvarchar(47)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_REGULATED_ENTITY_ENFRC', NULL, N'MS_Description', CAST(N'Schema element: MS4RegulatedEntityEnforcement' AS nvarchar(45)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_REGULATED_ENTITY_ENFRC', N'MS_4_REGULATED_ENTITY_IDENT', N'MS_Description', CAST(N'MS4RegulatedEntityIdentifier' AS nvarchar(28)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_ENFRC_AGNCY', NULL, N'MS_Description', CAST(N'Schema element: EnforcementAgency' AS nvarchar(33)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_ENFRC_AGNCY', N'ENFRC_AGNCY_TYPE_CODE', N'MS_Description', CAST(N'EnforcementAgencyTypeCode' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_ENFRC_AGNCY', N'AGNCY_LEAD_IND', N'MS_Description', CAST(N'AgencyLeadIndicator' AS nvarchar(19)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_RESULTS', NULL, N'MS_Description', CAST(N'Schema element: SubmissionResultsDataType' AS nvarchar(41)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_RESULTS', N'TRANSACTION_TYPE', N'MS_Description', CAST(N'The type of transaction that was sent in the submission. (SubmissionTransactionTypeCode)' AS nvarchar(88)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_RESULTS', N'PRMT_IDENT', N'MS_Description', CAST(N'PermitIdentifier' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_RESULTS', N'PRMT_IDENT_2', N'MS_Description', CAST(N'PermitIdentifier. Used by ComplianceMonitoringLinkage, DMRProgramReportLinkageSubmission, and EnforcementActionViolationLinkageSubmission since error key my contain two values' AS nvarchar(175)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_RESULTS', N'PRMT_FEATR_IDENT', N'MS_Description', CAST(N'PermittedFeatureIdentifier' AS nvarchar(26)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_RESULTS', N'LMT_SET_DESIGNATOR', N'MS_Description', CAST(N'LimitSetDesignator' AS nvarchar(18)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_RESULTS', N'MON_PERIOD_END_DATE', N'MS_Description', CAST(N'MonitoringPeriodEndDate' AS nvarchar(23)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_RESULTS', N'PARAM_CODE', N'MS_Description', CAST(N'ParameterCode' AS nvarchar(13)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_RESULTS', N'MON_SITE_DESC_CODE', N'MS_Description', CAST(N'MonitoringSiteDescriptionCode' AS nvarchar(29)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_RESULTS', N'LMT_SEASON_NUM', N'MS_Description', CAST(N'LimitSeasonNumber' AS nvarchar(17)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_RESULTS', N'LMT_START_DATE', N'MS_Description', CAST(N'LimitStartDate' AS nvarchar(14)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_RESULTS', N'LMT_END_DATE', N'MS_Description', CAST(N'LimitEndDate' AS nvarchar(12)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_RESULTS', N'LMT_MOD_EFFECTIVE_DATE', N'MS_Description', CAST(N'LimitModificationEffectiveDate' AS nvarchar(30)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_RESULTS', N'TRADE_ID', N'MS_Description', CAST(N'TradeID' AS nvarchar(7)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_RESULTS', N'CMPL_MON_CATG_CODE', N'MS_Description', CAST(N'ComplianceMonitoringCategoryCode' AS nvarchar(32)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_RESULTS', N'CMPL_MON_CATG_CODE_2', N'MS_Description', CAST(N'ComplianceMonitoringCategoryCode. Used by ComplianceMonitoringLinkage since error key may contain two values.' AS nvarchar(109)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_RESULTS', N'CMPL_MON_DATE', N'MS_Description', CAST(N'ComplianceMonitoringDate' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_RESULTS', N'CMPL_MON_DATE_2', N'MS_Description', CAST(N'ComplianceMonitoringDate. Used by ComplianceMonitoringLinkage since error key may contain two values.' AS nvarchar(101)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_RESULTS', N'CSO_EVT_DATE', N'MS_Description', CAST(N'CSOEventDate' AS nvarchar(12)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_RESULTS', N'DATE_STRM_EVT_SMPL', N'MS_Description', CAST(N'DateStormEventSampled' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_RESULTS', N'PRMT_EFFECTIVE_DATE', N'MS_Description', CAST(N'PermitEffectiveDate' AS nvarchar(19)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_RESULTS', N'PRMT_TRACK_EVT_CODE', N'MS_Description', CAST(N'PermitTrackingEventCode' AS nvarchar(23)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_RESULTS', N'PRMT_TRACK_EVT_DATE', N'MS_Description', CAST(N'PermitTrackingEventDate' AS nvarchar(23)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_RESULTS', N'NARR_COND_NUM', N'MS_Description', CAST(N'NarrativeConditionNumber' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_RESULTS', N'SCHD_EVT_CODE', N'MS_Description', CAST(N'ScheduleEventCode' AS nvarchar(17)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_RESULTS', N'SCHD_DATE', N'MS_Description', CAST(N'ScheduleDate' AS nvarchar(12)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_RESULTS', N'NUM_REP_CODE', N'MS_Description', CAST(N'NumericReportCode' AS nvarchar(17)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_RESULTS', N'NUM_REP_VIOL_CODE', N'MS_Description', CAST(N'NumericReportViolationCode' AS nvarchar(26)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_RESULTS', N'PRMT_AUTH_REP_RCVD_DATE', N'MS_Description', CAST(N'PermittingAuthorityReportReceivedDate' AS nvarchar(37)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_RESULTS', N'PRETR_PERF_SUMM_END_DATE', N'MS_Description', CAST(N'PretreatmentPerformanceSummaryEndDate' AS nvarchar(37)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_RESULTS', N'REP_COVERAGE_END_DATE', N'MS_Description', CAST(N'ReportCoverageEndDate' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_RESULTS', N'SNGL_EVT_VIOL_CODE', N'MS_Description', CAST(N'SingleEventViolationCode' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_RESULTS', N'SNGL_EVT_VIOL_DATE', N'MS_Description', CAST(N'SingleEventViolationDate' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_RESULTS', N'SSO_ANNUL_REP_RCVD_DATE', N'MS_Description', CAST(N'SSOAnnualReportReceivedDate' AS nvarchar(27)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_RESULTS', N'SSO_EVT_DATE', N'MS_Description', CAST(N'SSOEventDate' AS nvarchar(12)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_RESULTS', N'SSO_MONTHLY_REP_RCVD_DATE', N'MS_Description', CAST(N'SSOMonthlyReportReceivedDate' AS nvarchar(28)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_RESULTS', N'SW_MS_4_REP_RCVD_DATE', N'MS_Description', CAST(N'StormWaterMS4ReportReceivedDate' AS nvarchar(31)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_RESULTS', N'ENFRC_ACTN_IDENT', N'MS_Description', CAST(N'EnforcementActionIdentifier' AS nvarchar(27)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_RESULTS', N'ENFRC_ACTN_IDENT_2', N'MS_Description', CAST(N'EnforcementActionIdentifier. Used by FinalOrderViolationLinkageSubmission and EnforcementActionViolationLinkageSubmission data families since error key may contain two values' AS nvarchar(174)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_RESULTS', N'FINAL_ORDER_IDENT', N'MS_Description', CAST(N'FinalOrderIdentifier' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_RESULTS', N'FINAL_ORDER_IDENT_2', N'MS_Description', CAST(N'FinalOrderIdentifier. Used by FinalOrderViolationLinkageSubmission data family since error key may contain two values' AS nvarchar(117)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_RESULTS', N'CMPL_SCHD_NUM', N'MS_Description', CAST(N'ComplianceScheduleNumber' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_RESULTS', N'MILESTONE_TYPE_CODE', N'MS_Description', CAST(N'MilestoneTypeCode' AS nvarchar(17)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_RESULTS', N'SCHD_VIOL_CODE', N'MS_Description', CAST(N'ScheduleViolationCode' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_RESULTS', N'RESULT_CODE', N'MS_Description', CAST(N'An Service Provider (e.g., ICIS-NPDES) specific error code that uniquely identifies a type of error, information or warning. (ResultCode)' AS nvarchar(137)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_RESULTS', N'RESULT_TYPE_CODE', N'MS_Description', CAST(N'The type of error, information or warning that is being returned. (ResultTypeCode)' AS nvarchar(82)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_RESULTS', N'RESULT_DESC', N'MS_Description', CAST(N'A human readable description on an error, information or warning. (ResultDescription)' AS nvarchar(85)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_RESULTS', N'CREATED_DATE_TIME', N'MS_Description', CAST(N'The date and time when this row was created. (CreatedDateTime)' AS nvarchar(62)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_REGULATED_ENTITY_ENFRC_ACTIONS', NULL, N'MS_Description', CAST(N'Schema element: MS4RegulatedEntityEnforcementActions' AS nvarchar(52)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_REGULATED_ENTITY_ENFRC_ACTIONS', N'MS_4_REGULATED_ENTITY_ENFRC_ACTN_TYPE_CODE', N'MS_Description', CAST(N'MS4RegulatedEntityEnforcementActionTypeCode' AS nvarchar(43)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_REGULATED_ENTITY_ENFRC_ACTIONS', N'MS_4_REGULATED_ENTITY_ENFRC_ACTN_TYPE_CODE_OTHR_TXT', N'MS_Description', CAST(N'MS4RegulatedEntityEnforcementActionTypeCodeOtherText' AS nvarchar(52)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FAC', NULL, N'MS_Description', CAST(N'Schema element: Facility' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FAC', N'LOCALITY_NAME', N'MS_Description', CAST(N'LocalityName' AS nvarchar(12)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FAC', N'LOC_ADDR_CITY_CODE', N'MS_Description', CAST(N'LocationAddressCityCode' AS nvarchar(23)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FAC', N'LOC_ADDR_COUNTY_CODE', N'MS_Description', CAST(N'LocationAddressCountyCode' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FAC', N'FAC_SITE_NAME', N'MS_Description', CAST(N'FacilitySiteName' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FAC', N'LOC_ADDR_TXT', N'MS_Description', CAST(N'LocationAddressText' AS nvarchar(19)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FAC', N'SUPPL_LOC_TXT', N'MS_Description', CAST(N'SupplementalLocationText' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FAC', N'LOC_ST_CODE', N'MS_Description', CAST(N'LocationStateCode' AS nvarchar(17)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FAC', N'LOC_ZIP_CODE', N'MS_Description', CAST(N'LocationZipCode' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FAC', N'LOC_COUNTRY_CODE', N'MS_Description', CAST(N'LocationCountryCode' AS nvarchar(19)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FAC', N'ORG_DUNS_NUM', N'MS_Description', CAST(N'OrganizationDUNSNumber' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FAC', N'ST_FAC_IDENT', N'MS_Description', CAST(N'StateFacilityIdentifier' AS nvarchar(23)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FAC', N'ST_RGN_CODE', N'MS_Description', CAST(N'StateRegionCode' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FAC', N'FAC_CONGR_DISTRICT_NUM', N'MS_Description', CAST(N'FacilityCongressionalDistrictNumber' AS nvarchar(35)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FAC', N'FAC_TYPE_OF_OWNERSHIP_CODE', N'MS_Description', CAST(N'FacilityTypeOfOwnershipCode' AS nvarchar(27)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FAC', N'FEDR_FAC_IDENT_NUM', N'MS_Description', CAST(N'FederalFacilityIdentificationNumber' AS nvarchar(35)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FAC', N'FEDR_AGNCY_CODE', N'MS_Description', CAST(N'FederalAgencyCode' AS nvarchar(17)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FAC', N'TRIBAL_LAND_CODE', N'MS_Description', CAST(N'TribalLandCode' AS nvarchar(14)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FAC', N'CNST_PROJ_NAME', N'MS_Description', CAST(N'ConstructionProjectName' AS nvarchar(23)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FAC', N'CNST_PROJ_LAT_MEAS', N'MS_Description', CAST(N'ConstructionProjectLatitudeMeasure' AS nvarchar(34)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FAC', N'CNST_PROJ_LONG_MEAS', N'MS_Description', CAST(N'ConstructionProjectLongitudeMeasure' AS nvarchar(35)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FAC', N'SECTION_TOWNSHIP_RNG', N'MS_Description', CAST(N'SectionTownshipRange' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FAC', N'FAC_CMNTS', N'MS_Description', CAST(N'FacilityComments' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FAC', N'FAC_USR_DFND_FLD_1', N'MS_Description', CAST(N'FacilityUserDefinedField1' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FAC', N'FAC_USR_DFND_FLD_2', N'MS_Description', CAST(N'FacilityUserDefinedField2' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FAC', N'FAC_USR_DFND_FLD_3', N'MS_Description', CAST(N'FacilityUserDefinedField3' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FAC', N'FAC_USR_DFND_FLD_4', N'MS_Description', CAST(N'FacilityUserDefinedField4' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FAC', N'FAC_USR_DFND_FLD_5', N'MS_Description', CAST(N'FacilityUserDefinedField5' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_TRACK', NULL, N'MS_Description', CAST(N'Schema element: SubmissionTrackingDataType' AS nvarchar(42)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_TRACK', N'ETL_CMPL_DATE_TIME', N'MS_Description', CAST(N'ETLCompletionDateTime' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_TRACK', N'DET_CHANGE_CMPL_DATE_TIME', N'MS_Description', CAST(N'DETChangeCompletionDateTime' AS nvarchar(27)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_TRACK', N'SUBM_DATE_TIME', N'MS_Description', CAST(N'SubmissionDateTime' AS nvarchar(18)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_TRACK', N'SUBM_TRANSACTION_ID', N'MS_Description', CAST(N'SubmissionTransactionId' AS nvarchar(23)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_TRACK', N'SUBM_TRANSACTION_STAT', N'MS_Description', CAST(N'SubmissionTransactionStatus' AS nvarchar(27)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_TRACK', N'SUBM_STAT_DATE_TIME', N'MS_Description', CAST(N'SubmissionStatusDateTime' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_TRACK', N'RSPN_PARSE_DATE_TIME', N'MS_Description', CAST(N'ResponseParseDateTime' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_TRACK', N'WORKFLOW_STAT', N'MS_Description', CAST(N'WorkflowStatus' AS nvarchar(14)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBM_TRACK', N'WORKFLOW_STAT_MESSAGE', N'MS_Description', CAST(N'WorkflowStatusMessage' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_REGULATED_ENTITY_IDENT', NULL, N'MS_Description', CAST(N'Schema element: String' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_REGULATED_ENTITY_IDENT', N'MS_4_REGULATED_ENTITY_IDENT', N'MS_Description', CAST(N'MS4RegulatedEntityIdentifier' AS nvarchar(28)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FAC_CLASS', NULL, N'MS_Description', CAST(N'Schema element: String' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FAC_CLASS', N'FAC_CLASS', N'MS_Description', CAST(N'FacilityClassification' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBSECTOR_CODE_PLUS_DESC', NULL, N'MS_Description', CAST(N'Schema element: String' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SUBSECTOR_CODE_PLUS_DESC', N'SUBSECTOR_CODE_PLUS_DESC', N'MS_Description', CAST(N'SubsectorCodePlusDescription' AS nvarchar(28)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_SWMP_CHANGES', NULL, N'MS_Description', CAST(N'Schema element: MS4SWMPChanges' AS nvarchar(30)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_SWMP_CHANGES', N'MS_4_REGULATED_ENTITY_IDENT', N'MS_Description', CAST(N'MS4RegulatedEntityIdentifier' AS nvarchar(28)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_SWMP_CHANGES', N'MS_4_SWMP_CHANGE_IND', N'MS_Description', CAST(N'MS4SWMPChangeIndicator' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_SWMP_CHANGES', N'MS_4_SWMP_CHANGE_IND_TXT', N'MS_Description', CAST(N'MS4SWMPChangeIndicatorText' AS nvarchar(26)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_ADDR', NULL, N'MS_Description', CAST(N'Schema element: Address' AS nvarchar(23)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_ADDR', N'AFFIL_TYPE_TXT', N'MS_Description', CAST(N'AffiliationTypeText' AS nvarchar(19)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_ADDR', N'ORG_FRML_NAME', N'MS_Description', CAST(N'OrganizationFormalName' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_ADDR', N'ORG_DUNS_NUM', N'MS_Description', CAST(N'OrganizationDUNSNumber' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_ADDR', N'MAILING_ADDR_TXT', N'MS_Description', CAST(N'MailingAddressText' AS nvarchar(18)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_ADDR', N'SUPPL_ADDR_TXT', N'MS_Description', CAST(N'SupplementalAddressText' AS nvarchar(23)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_ADDR', N'MAILING_ADDR_CITY_NAME', N'MS_Description', CAST(N'MailingAddressCityName' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_ADDR', N'MAILING_ADDR_ST_CODE', N'MS_Description', CAST(N'MailingAddressStateCode' AS nvarchar(23)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_ADDR', N'MAILING_ADDR_ZIP_CODE', N'MS_Description', CAST(N'MailingAddressZipCode' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_ADDR', N'COUNTY_NAME', N'MS_Description', CAST(N'CountyName' AS nvarchar(10)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_ADDR', N'MAILING_ADDR_COUNTRY_CODE', N'MS_Description', CAST(N'MailingAddressCountryCode' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_ADDR', N'DIVISION_NAME', N'MS_Description', CAST(N'DivisionName' AS nvarchar(12)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_ADDR', N'LOC_PROVINCE', N'MS_Description', CAST(N'LocationProvince' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_ADDR', N'ELEC_ADDR_TXT', N'MS_Description', CAST(N'ElectronicAddressText' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_ADDR', N'START_DATE_OF_ADDR_ASSC', N'MS_Description', CAST(N'StartDateOfAddressAssociation' AS nvarchar(29)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_ADDR', N'END_DATE_OF_ADDR_ASSC', N'MS_Description', CAST(N'EndDateOfAddressAssociation' AS nvarchar(27)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FINAL_ORDER', NULL, N'MS_Description', CAST(N'Schema element: FinalOrder' AS nvarchar(26)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FINAL_ORDER', N'FINAL_ORDER_IDENT', N'MS_Description', CAST(N'FinalOrderIdentifier' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FINAL_ORDER', N'FINAL_ORDER_TYPE_CODE', N'MS_Description', CAST(N'FinalOrderTypeCode' AS nvarchar(18)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FINAL_ORDER', N'FINAL_ORDER_ISSUED_ENTERD_DATE', N'MS_Description', CAST(N'FinalOrderIssuedEnteredDate' AS nvarchar(27)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FINAL_ORDER', N'NPDES_CLOSED_DATE', N'MS_Description', CAST(N'NPDESClosedDate' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FINAL_ORDER', N'FINAL_ORDER_QNCR_CMNTS', N'MS_Description', CAST(N'FinalOrderQNCRComments' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FINAL_ORDER', N'CASH_CIVIL_PNLTY_REQD_AMT', N'MS_Description', CAST(N'CashCivilPenaltyRequiredAmount' AS nvarchar(30)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FINAL_ORDER', N'CASH_CIVIL_PNLTY_COLL_AMT', N'MS_Description', CAST(N'CashCivilPenaltyCollectedAmount' AS nvarchar(31)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FINAL_ORDER', N'OTHR_CMNTS', N'MS_Description', CAST(N'OtherComments' AS nvarchar(13)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SURF_DSPL_SITE', NULL, N'MS_Description', CAST(N'Schema element: SurfaceDisposalSite' AS nvarchar(35)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SURF_DSPL_SITE', N'PATHOGEN_REDUCTION_IND', N'MS_Description', CAST(N'PathogenReductionIndicator' AS nvarchar(26)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SURF_DSPL_SITE', N'VECTOR_REDUCTION_IND', N'MS_Description', CAST(N'VectorReductionIndicator' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SURF_DSPL_SITE', N'MGMT_PRACTICE_IND', N'MS_Description', CAST(N'ManagementPracticesIndicator' AS nvarchar(28)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SURF_DSPL_SITE', N'CERT_STATEMENT_IND', N'MS_Description', CAST(N'CertificationStatementIndicator' AS nvarchar(31)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SURF_DSPL_SITE', N'CERT_FIRST_NAME', N'MS_Description', CAST(N'CertifierFirstName' AS nvarchar(18)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SURF_DSPL_SITE', N'CERT_LAST_NAME', N'MS_Description', CAST(N'CertifierLastName' AS nvarchar(17)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SURF_DSPL_SITE', N'CLASS_A_ALT_USED', N'MS_Description', CAST(N'ClassAAlternativeUsed' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SURF_DSPL_SITE', N'CLASS_A_ALTS_TXT', N'MS_Description', CAST(N'ClassAAlternativesText' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SURF_DSPL_SITE', N'CLASS_B_ALT_USED', N'MS_Description', CAST(N'ClassBAlternativeUsed' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SURF_DSPL_SITE', N'CLASS_B_ALTS_TXT', N'MS_Description', CAST(N'ClassBAlternativesText' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SURF_DSPL_SITE', N'VAR_ALT_USED', N'MS_Description', CAST(N'VARAlternativeUsed' AS nvarchar(18)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SURF_DSPL_SITE', N'VAR_ALTS_TXT', N'MS_Description', CAST(N'VARAlternativesText' AS nvarchar(19)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_NAICS_CODE', NULL, N'MS_Description', CAST(N'Schema element: NAICSCodeDetails' AS nvarchar(32)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_NAICS_CODE', N'NAICS_CODE', N'MS_Description', CAST(N'NAICSCode' AS nvarchar(9)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_NAICS_CODE', N'NAICS_PRIMARY_IND_CODE', N'MS_Description', CAST(N'NAICSPrimaryIndicatorCode' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_ANLYTCL_METHOD', NULL, N'MS_Description', CAST(N'Schema element: AnalyticalMethodData' AS nvarchar(36)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_ANLYTCL_METHOD', N'ANLYTCL_METHOD_TYPE_CODE', N'MS_Description', CAST(N'AnalyticalMethodTypeCode' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_ANLYTCL_METHOD', N'ANLYTCL_METHOD_OTHR_TYPE_TXT', N'MS_Description', CAST(N'AnalyticalMethodOtherTypeText' AS nvarchar(29)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FINAL_ORDER_PRMT_IDENT', NULL, N'MS_Description', CAST(N'Schema element: String' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FINAL_ORDER_PRMT_IDENT', N'FINAL_ORDER_PRMT_IDENT', N'MS_Description', CAST(N'FinalOrderPermitIdentifier' AS nvarchar(26)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_CNST_INDST_INSP', NULL, N'MS_Description', CAST(N'Schema element: StormWaterConstructionIndustrialInspection' AS nvarchar(58)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_CNST_INDST_INSP', N'SWPPP_EVAL_BASIS_CODE', N'MS_Description', CAST(N'SWPPPEvaluationBasisCode' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_CNST_INDST_INSP', N'SWPPP_EVAL_DATE', N'MS_Description', CAST(N'SWPPPEvaluationDate' AS nvarchar(19)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_CNST_INDST_INSP', N'SWPPP_EVAL_DESC_TXT', N'MS_Description', CAST(N'SWPPPEvaluationDescriptionText' AS nvarchar(30)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_CNST_INDST_INSP', N'NO_EXPOSURE_AUTH_DATE', N'MS_Description', CAST(N'NoExposureAuthorizationDate' AS nvarchar(27)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_NARR_COND_SCHD', NULL, N'MS_Description', CAST(N'Schema element: NarrativeConditionScheduleData' AS nvarchar(46)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_NARR_COND_SCHD', N'SRC_SYSTM_IDENT', N'MS_Description', CAST(N'SourceSystemIdentifier' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_NARR_COND_SCHD', N'TRANSACTION_TYPE', N'MS_Description', CAST(N'TransactionType' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_NARR_COND_SCHD', N'TRANSACTION_TIMESTAMP', N'MS_Description', CAST(N'TransactionTimestamp' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_NARR_COND_SCHD', N'PRMT_IDENT', N'MS_Description', CAST(N'PermitIdentifier' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_NARR_COND_SCHD', N'NARR_COND_NUM', N'MS_Description', CAST(N'NarrativeConditionNumber' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_NARR_COND_SCHD', N'NARR_COND_CODE', N'MS_Description', CAST(N'NarrativeConditionCode' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_NARR_COND_SCHD', N'CMNTS', N'MS_Description', CAST(N'Comments' AS nvarchar(8)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_ANML_TYPE', NULL, N'MS_Description', CAST(N'Schema element: AnimalType' AS nvarchar(26)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_ANML_TYPE', N'ANML_TYPE_CODE', N'MS_Description', CAST(N'AnimalTypeCode' AS nvarchar(14)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_ANML_TYPE', N'OTHR_ANML_TYPE_NAME', N'MS_Description', CAST(N'OtherAnimalTypeName' AS nvarchar(19)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_ANML_TYPE', N'TTL_NUM_EACH_LVSTCK', N'MS_Description', CAST(N'TotalNumbersEachLivestock' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_ANML_TYPE', N'OPEN_CONFINEMNT_CNT', N'MS_Description', CAST(N'OpenConfinementCount' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_ANML_TYPE', N'HOUSD_UNDR_ROOF_CONFINEMNT_CNT', N'MS_Description', CAST(N'HousedUnderRoofConfinementCount' AS nvarchar(31)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_ANML_TYPE', N'LIQUID_MNUR_HANDLING_SYSTM', N'MS_Description', CAST(N'LiquidManureHandlingSystem' AS nvarchar(26)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FINAL_ORDER_VIOL_LNK', NULL, N'MS_Description', CAST(N'Schema element: FinalOrderViolationLinkageData' AS nvarchar(46)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FINAL_ORDER_VIOL_LNK', N'SRC_SYSTM_IDENT', N'MS_Description', CAST(N'SourceSystemIdentifier' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FINAL_ORDER_VIOL_LNK', N'TRANSACTION_TYPE', N'MS_Description', CAST(N'TransactionType' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FINAL_ORDER_VIOL_LNK', N'TRANSACTION_TIMESTAMP', N'MS_Description', CAST(N'TransactionTimestamp' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FINAL_ORDER_VIOL_LNK', N'ENFRC_ACTN_IDENT', N'MS_Description', CAST(N'EnforcementActionIdentifier' AS nvarchar(27)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FINAL_ORDER_VIOL_LNK', N'FINAL_ORDER_IDENT', N'MS_Description', CAST(N'FinalOrderIdentifier' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_CNST_INSP', NULL, N'MS_Description', CAST(N'Schema element: StormWaterConstructionInspection' AS nvarchar(48)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_NAT_PRIO', NULL, N'MS_Description', CAST(N'Schema element: CustomXmlStringFormatInt32' AS nvarchar(42)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_NAT_PRIO', N'NAT_PRIO_CODE', N'MS_Description', CAST(N'NationalPrioritiesCode' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_ASSC_PRMT', NULL, N'MS_Description', CAST(N'Schema element: AssociatedPermit' AS nvarchar(32)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_ASSC_PRMT', N'ASSC_PRMT_IDENT', N'MS_Description', CAST(N'AssociatedPermitIdentifier' AS nvarchar(26)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_ASSC_PRMT', N'ASSC_PRMT_REASON_CODE', N'MS_Description', CAST(N'AssociatedPermitReasonCode' AS nvarchar(26)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FRML_ENFRC_ACTN', NULL, N'MS_Description', CAST(N'Schema element: FormalEnforcementActionData' AS nvarchar(43)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FRML_ENFRC_ACTN', N'SRC_SYSTM_IDENT', N'MS_Description', CAST(N'SourceSystemIdentifier' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FRML_ENFRC_ACTN', N'TRANSACTION_TYPE', N'MS_Description', CAST(N'TransactionType' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FRML_ENFRC_ACTN', N'TRANSACTION_TIMESTAMP', N'MS_Description', CAST(N'TransactionTimestamp' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FRML_ENFRC_ACTN', N'ENFRC_ACTN_IDENT', N'MS_Description', CAST(N'EnforcementActionIdentifier' AS nvarchar(27)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FRML_ENFRC_ACTN', N'ENFRC_ACTN_NAME', N'MS_Description', CAST(N'EnforcementActionName' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FRML_ENFRC_ACTN', N'FORUM', N'MS_Description', CAST(N'Forum' AS nvarchar(5)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FRML_ENFRC_ACTN', N'RESL_TYPE_CODE', N'MS_Description', CAST(N'ResolutionTypeCode' AS nvarchar(18)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FRML_ENFRC_ACTN', N'COMBINED_OR_SUPERSEDED_BY_EAID', N'MS_Description', CAST(N'CombinedOrSupersededByEAID' AS nvarchar(26)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FRML_ENFRC_ACTN', N'REASON_DELETING_RECORD', N'MS_Description', CAST(N'ReasonDeletingRecord' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FRML_ENFRC_ACTN', N'FRML_EA_USR_DFND_FLD_1', N'MS_Description', CAST(N'FormalEAUserDefinedField1' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FRML_ENFRC_ACTN', N'FRML_EA_USR_DFND_FLD_2', N'MS_Description', CAST(N'FormalEAUserDefinedField2' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FRML_ENFRC_ACTN', N'FRML_EA_USR_DFND_FLD_3', N'MS_Description', CAST(N'FormalEAUserDefinedField3' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FRML_ENFRC_ACTN', N'FRML_EA_USR_DFND_FLD_4', N'MS_Description', CAST(N'FormalEAUserDefinedField4' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FRML_ENFRC_ACTN', N'FRML_EA_USR_DFND_FLD_5', N'MS_Description', CAST(N'FormalEAUserDefinedField5' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FRML_ENFRC_ACTN', N'FRML_EA_USR_DFND_FLD_6', N'MS_Description', CAST(N'FormalEAUserDefinedField6' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_FRML_ENFRC_ACTN', N'ENFRC_AGNCY_NAME', N'MS_Description', CAST(N'EnforcementAgencyName' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_CNST_NON_CNST_INSP', NULL, N'MS_Description', CAST(N'Schema element: StormWaterConstructionNonConstructionInspections' AS nvarchar(64)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_NPDES_DAT_GRP_NUM', NULL, N'MS_Description', CAST(N'Schema element: String' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_NPDES_DAT_GRP_NUM', N'NPDES_DAT_GRP_NUM_CODE', N'MS_Description', CAST(N'NPDESDataGroupNumberCode' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BASIC_PRMT', NULL, N'MS_Description', CAST(N'Schema element: BasicPermitData' AS nvarchar(31)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BASIC_PRMT', N'SRC_SYSTM_IDENT', N'MS_Description', CAST(N'SourceSystemIdentifier' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BASIC_PRMT', N'TRANSACTION_TYPE', N'MS_Description', CAST(N'TransactionType' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BASIC_PRMT', N'TRANSACTION_TIMESTAMP', N'MS_Description', CAST(N'TransactionTimestamp' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BASIC_PRMT', N'PRMT_IDENT', N'MS_Description', CAST(N'PermitIdentifier' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BASIC_PRMT', N'PRMT_TYPE_CODE', N'MS_Description', CAST(N'PermitTypeCode' AS nvarchar(14)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BASIC_PRMT', N'AGNCY_TYPE_CODE', N'MS_Description', CAST(N'AgencyTypeCode' AS nvarchar(14)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BASIC_PRMT', N'PRMT_STAT_CODE', N'MS_Description', CAST(N'PermitStatusCode' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BASIC_PRMT', N'PRMT_ISSUE_DATE', N'MS_Description', CAST(N'PermitIssueDate' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BASIC_PRMT', N'PRMT_EFFECTIVE_DATE', N'MS_Description', CAST(N'PermitEffectiveDate' AS nvarchar(19)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BASIC_PRMT', N'PRMT_EXPR_DATE', N'MS_Description', CAST(N'PermitExpirationDate' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BASIC_PRMT', N'REISSU_PRIO_PRMT_IND', N'MS_Description', CAST(N'ReissuancePriorityPermitIndicator' AS nvarchar(33)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BASIC_PRMT', N'BACKLOG_REASON_TXT', N'MS_Description', CAST(N'BacklogReasonText' AS nvarchar(17)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BASIC_PRMT', N'PRMT_ISSUING_ORG_TYPE_NAME', N'MS_Description', CAST(N'PermitIssuingOrganizationTypeName' AS nvarchar(33)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BASIC_PRMT', N'PRMT_APPEALED_IND', N'MS_Description', CAST(N'PermitAppealedIndicator' AS nvarchar(23)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BASIC_PRMT', N'PRMT_USR_DFND_DAT_ELM_1_TXT', N'MS_Description', CAST(N'PermitUserDefinedDataElement1Text' AS nvarchar(33)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BASIC_PRMT', N'PRMT_USR_DFND_DAT_ELM_2_TXT', N'MS_Description', CAST(N'PermitUserDefinedDataElement2Text' AS nvarchar(33)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BASIC_PRMT', N'PRMT_USR_DFND_DAT_ELM_3_TXT', N'MS_Description', CAST(N'PermitUserDefinedDataElement3Text' AS nvarchar(33)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BASIC_PRMT', N'PRMT_USR_DFND_DAT_ELM_4_TXT', N'MS_Description', CAST(N'PermitUserDefinedDataElement4Text' AS nvarchar(33)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BASIC_PRMT', N'PRMT_USR_DFND_DAT_ELM_5_TXT', N'MS_Description', CAST(N'PermitUserDefinedDataElement5Text' AS nvarchar(33)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BASIC_PRMT', N'PRMT_CMNTS_TXT', N'MS_Description', CAST(N'PermitCommentsText' AS nvarchar(18)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BASIC_PRMT', N'MAJOR_MINOR_RATING_CODE', N'MS_Description', CAST(N'MajorMinorRatingCode' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BASIC_PRMT', N'TTL_APPL_DSGN_FLOW_NUM', N'MS_Description', CAST(N'TotalApplicationDesignFlowNumber' AS nvarchar(32)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BASIC_PRMT', N'TTL_APPL_AVER_FLOW_NUM', N'MS_Description', CAST(N'TotalApplicationAverageFlowNumber' AS nvarchar(33)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BASIC_PRMT', N'APPL_RCVD_DATE', N'MS_Description', CAST(N'ApplicationReceivedDate' AS nvarchar(23)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BASIC_PRMT', N'PRMT_APPL_CMPL_DATE', N'MS_Description', CAST(N'PermitApplicationCompletionDate' AS nvarchar(31)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BASIC_PRMT', N'NEW_SRC_IND', N'MS_Description', CAST(N'NewSourceIndicator' AS nvarchar(18)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BASIC_PRMT', N'PRMT_ST_WTR_BODY_CODE', N'MS_Description', CAST(N'PermitStateWaterBodyCode' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BASIC_PRMT', N'PRMT_ST_WTR_BODY_NAME', N'MS_Description', CAST(N'PermitStateWaterBodyName' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BASIC_PRMT', N'FEDR_GRANT_IND', N'MS_Description', CAST(N'FederalGrantIndicator' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BASIC_PRMT', N'DMR_COGNZNT_OFCL', N'MS_Description', CAST(N'DMRCognizantOfficial' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BASIC_PRMT', N'DMR_COGNZNT_OFCL_TELEPH_NUM', N'MS_Description', CAST(N'DMRCognizantOfficialTelephoneNumber' AS nvarchar(35)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BASIC_PRMT', N'SIG_IU_IND', N'MS_Description', CAST(N'SignificantIUIndicator' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BASIC_PRMT', N'RCVG_PRMT_IDENT', N'MS_Description', CAST(N'ReceivingPermitIdentifier' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BASIC_PRMT', N'INDST_USR_TYPE_CODE', N'MS_Description', CAST(N'IndustrialUserTypeCode' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BASIC_PRMT', N'ELEC_REP_WAIVER_TYPE_CODE', N'MS_Description', CAST(N'ElectronicReportingWaiverTypeCode' AS nvarchar(33)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BASIC_PRMT', N'ELEC_REP_WAIVER_EFFECTIVE_DATE', N'MS_Description', CAST(N'ElectronicReportingWaiverEffectiveDate' AS nvarchar(38)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BASIC_PRMT', N'ELEC_REP_WAIVER_EXPR_DATE', N'MS_Description', CAST(N'ElectronicReportingWaiverExpirationDate' AS nvarchar(39)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BASIC_PRMT', N'MAJOR_MINOR_STAT_IND', N'MS_Description', CAST(N'MajorMinorStatusIndicator' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BASIC_PRMT', N'MAJOR_MINOR_STAT_START_DATE', N'MS_Description', CAST(N'MajorMinorStatusStartDate' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BASIC_PRMT', N'DMR_NON_RCPT_STAT_IND', N'MS_Description', CAST(N'DMRNonReceiptStatusIndicator' AS nvarchar(28)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BASIC_PRMT', N'DMR_NON_RCPT_STAT_START_DATE', N'MS_Description', CAST(N'DMRNonReceiptStatusStartDate' AS nvarchar(28)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GEO_COORD', NULL, N'MS_Description', CAST(N'Schema element: GeographicCoordinates' AS nvarchar(37)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GEO_COORD', N'LAT_MEAS', N'MS_Description', CAST(N'LatitudeMeasure' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GEO_COORD', N'LONG_MEAS', N'MS_Description', CAST(N'LongitudeMeasure' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GEO_COORD', N'HORZ_ACCURACY_MEAS', N'MS_Description', CAST(N'HorizontalAccuracyMeasure' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GEO_COORD', N'GEOMETRIC_TYPE_CODE', N'MS_Description', CAST(N'GeometricTypeCode' AS nvarchar(17)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GEO_COORD', N'HORZ_COLL_METHOD_CODE', N'MS_Description', CAST(N'HorizontalCollectionMethodCode' AS nvarchar(30)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GEO_COORD', N'HORZ_REF_DATUM_CODE', N'MS_Description', CAST(N'HorizontalReferenceDatumCode' AS nvarchar(28)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GEO_COORD', N'REF_POINT_CODE', N'MS_Description', CAST(N'ReferencePointCode' AS nvarchar(18)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GEO_COORD', N'SRC_MAP_SCALE_NUM', N'MS_Description', CAST(N'SourceMapScaleNumber' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_CNST_PRMT', NULL, N'MS_Description', CAST(N'Schema element: SWConstructionPermitData' AS nvarchar(40)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_CNST_PRMT', N'SRC_SYSTM_IDENT', N'MS_Description', CAST(N'SourceSystemIdentifier' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_CNST_PRMT', N'TRANSACTION_TYPE', N'MS_Description', CAST(N'TransactionType' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_CNST_PRMT', N'TRANSACTION_TIMESTAMP', N'MS_Description', CAST(N'TransactionTimestamp' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_CNST_PRMT', N'PRMT_IDENT', N'MS_Description', CAST(N'PermitIdentifier' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_CNST_PRMT', N'ST_WTR_BODY_NAME', N'MS_Description', CAST(N'StateWaterBodyName' AS nvarchar(18)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_CNST_PRMT', N'RCVG_MS_4_NAME', N'MS_Description', CAST(N'ReceivingMS4Name' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_CNST_PRMT', N'IMPAIRED_WTR_IND', N'MS_Description', CAST(N'ImpairedWaterIndicator' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_CNST_PRMT', N'HIST_PROP_IND', N'MS_Description', CAST(N'HistoricPropertyIndicator' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_CNST_PRMT', N'HIST_PROP_CRIT_MET_CODE', N'MS_Description', CAST(N'HistoricPropertyCriterionMetCode' AS nvarchar(32)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_CNST_PRMT', N'SPECIES_CRIT_HABITAT_IND', N'MS_Description', CAST(N'SpeciesCriticalHabitatIndicator' AS nvarchar(31)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_CNST_PRMT', N'SPECIES_CRIT_MET_CODE', N'MS_Description', CAST(N'SpeciesCriterionMetCode' AS nvarchar(23)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_CNST_PRMT', N'INDST_ACTY_SIZE', N'MS_Description', CAST(N'IndustrialActivitySize' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_CNST_PRMT', N'PROJ_TYPE_CODE', N'MS_Description', CAST(N'ProjectTypeCode' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_CNST_PRMT', N'EST_START_DATE', N'MS_Description', CAST(N'EstimatedStartDate' AS nvarchar(18)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_CNST_PRMT', N'EST_COMPLETE_DATE', N'MS_Description', CAST(N'EstimatedCompleteDate' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_CNST_PRMT', N'EST_AREA_DISTURBED_ACRES_NUM', N'MS_Description', CAST(N'EstimatedAreaDisturbedAcresNumber' AS nvarchar(33)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_CNST_PRMT', N'PROJ_PLAN_SIZE_CODE', N'MS_Description', CAST(N'ProjectPlanSizeCode' AS nvarchar(19)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_CNST_PRMT', N'STRCT_DEMOED_IND', N'MS_Description', CAST(N'StructureDemolishedIndicator' AS nvarchar(28)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_CNST_PRMT', N'STRCT_DEMOED_FLOOR_SPACE_IND', N'MS_Description', CAST(N'StructureDemolishedFloorSpaceIndicator' AS nvarchar(38)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_CNST_PRMT', N'PREDEV_LAND_USE_IND', N'MS_Description', CAST(N'PredevelopmentLandUseIndicator' AS nvarchar(30)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_CNST_PRMT', N'ERTH_DISTRB_ACTIVITIES_IND', N'MS_Description', CAST(N'EarthDisturbingActivitiesIndicator' AS nvarchar(34)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_CNST_PRMT', N'ERTH_DISTRB_EMRGCY_IND', N'MS_Description', CAST(N'EarthDisturbingEmergencyIndicator' AS nvarchar(33)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_CNST_PRMT', N'PREVIOUS_SW_DSCH_IND', N'MS_Description', CAST(N'PreviousStormwaterDischargesIndicator' AS nvarchar(37)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_CNST_PRMT', N'OTHR_PRMT_IDENT', N'MS_Description', CAST(N'OtherPermitIdentifier' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_CNST_PRMT', N'CGP_IND', N'MS_Description', CAST(N'CGPIndicator' AS nvarchar(12)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_CNST_PRMT', N'MS_4_DSCH_IND', N'MS_Description', CAST(N'MS4DischargeIndicator' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_CNST_PRMT', N'WTR_PROX_IND', N'MS_Description', CAST(N'WaterProximityIndicator' AS nvarchar(23)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_CNST_PRMT', N'ANTIDEG_IND', N'MS_Description', CAST(N'AntidegradationIndicator' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_CNST_PRMT', N'TRTMNT_CHEMS_IND', N'MS_Description', CAST(N'TreatmentChemicalsIndicator' AS nvarchar(27)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_CNST_PRMT', N'CATIONIC_CHEMS_IND', N'MS_Description', CAST(N'CationicChemicalsIndicator' AS nvarchar(26)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_CNST_PRMT', N'CATIONIC_CHEMS_AUTH_IND', N'MS_Description', CAST(N'CationicChemicalsAuthorizationIndicator' AS nvarchar(39)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_CNST_PRMT', N'SWPPP_PREP_IND', N'MS_Description', CAST(N'SWPPPPreparedIndicator' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_CNST_PRMT', N'CNST_SITE_TTL_AREA', N'MS_Description', CAST(N'ConstructionSiteTotalArea' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_CNST_PRMT', N'POST_CNST_TTL_IMPERVIOUS_AREA', N'MS_Description', CAST(N'PostConstructionTotalImperviousArea' AS nvarchar(35)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_CNST_PRMT', N'SOIL_FILL_MATERIAL_DESC_TXT', N'MS_Description', CAST(N'SoilFillMaterialDescriptionText' AS nvarchar(31)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_CNST_PRMT', N'RUNOFF_COEFFICIENT_POST_CNST', N'MS_Description', CAST(N'RunoffCoefficientPostConstruction' AS nvarchar(33)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_CNST_PRMT', N'SUBSURFACE_ERTH_DISTURBANCE_IND', N'MS_Description', CAST(N'SubsurfaceEarthDisturbanceIndicator' AS nvarchar(35)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_CNST_PRMT', N'PRIOR_SURVEYS_EVALS_IND', N'MS_Description', CAST(N'PriorSurveysEvaluationsIndicator' AS nvarchar(32)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_CNST_PRMT', N'SUBSURFACE_ERTH_DISTURBANCE_CONTROL_IND', N'MS_Description', CAST(N'SubsurfaceEarthDisturbanceControlIndicator' AS nvarchar(42)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_CNST_PRMT', N'NOT_TERM_DATE', N'MS_Description', CAST(N'NOTTerminationDate' AS nvarchar(18)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_CNST_PRMT', N'NOT_SIGN_DATE', N'MS_Description', CAST(N'NOTSignatureDate' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_CNST_PRMT', N'NOT_POSTMARK_DATE', N'MS_Description', CAST(N'NOTPostmarkDate' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_CNST_PRMT', N'NOT_RCVD_DATE', N'MS_Description', CAST(N'NOTReceivedDate' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_CNST_PRMT', N'LEW_AUTH_DATE', N'MS_Description', CAST(N'LEWAuthorizationDate' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_NPDES_VARIANCE_PRMT', NULL, N'MS_Description', CAST(N'Schema element: NPDESVariancePermitData' AS nvarchar(39)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_NPDES_VARIANCE_PRMT', N'SRC_SYSTM_IDENT', N'MS_Description', CAST(N'SourceSystemIdentifier' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_NPDES_VARIANCE_PRMT', N'TRANSACTION_TYPE', N'MS_Description', CAST(N'TransactionType' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_NPDES_VARIANCE_PRMT', N'TRANSACTION_TIMESTAMP', N'MS_Description', CAST(N'TransactionTimestamp' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_NPDES_VARIANCE_PRMT', N'PRMT_IDENT', N'MS_Description', CAST(N'PermitIdentifier' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_NPDES_VARIANCE_PRMT', N'NPDES_VARIANCE_TYPE_CODE', N'MS_Description', CAST(N'NPDESVarianceTypeCode' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_NPDES_VARIANCE_PRMT', N'NPDES_VARIANCE_SUBM_DATE', N'MS_Description', CAST(N'NPDESVarianceSubmissionDate' AS nvarchar(27)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_NPDES_VARIANCE_PRMT', N'NPDES_VARIANCE_VERSION_TYPE', N'MS_Description', CAST(N'NPDESVarianceVersionType' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_NPDES_VARIANCE_PRMT', N'NPDES_VARIANCE_STAT_CODE', N'MS_Description', CAST(N'NPDESVarianceStatusCode' AS nvarchar(23)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_NPDES_VARIANCE_PRMT', N'NPDES_VARIANCE_ACTN_DATE', N'MS_Description', CAST(N'NPDESVarianceActionDate' AS nvarchar(23)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_NPDES_VARIANCE_PRMT', N'THERMAL_VARIANCE_REQUEST_PBLC_NOTICE_IND', N'MS_Description', CAST(N'ThermalVarianceRequestPublicNoticeIndicator' AS nvarchar(43)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_NPDES_VARIANCE_PRMT', N'NPDES_VARIANCE_CMNT_TXT', N'MS_Description', CAST(N'NPDESVarianceCommentText' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_ANNUL_PROG_REP', NULL, N'MS_Description', CAST(N'Schema element: BiosolidsAnnualProgramReportData' AS nvarchar(48)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_ANNUL_PROG_REP', N'SRC_SYSTM_IDENT', N'MS_Description', CAST(N'SourceSystemIdentifier' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_ANNUL_PROG_REP', N'TRANSACTION_TYPE', N'MS_Description', CAST(N'TransactionType' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_ANNUL_PROG_REP', N'TRANSACTION_TIMESTAMP', N'MS_Description', CAST(N'TransactionTimestamp' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_ANNUL_PROG_REP', N'PRMT_IDENT', N'MS_Description', CAST(N'PermitIdentifier' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_ANNUL_PROG_REP', N'PROG_REP_FORM_SET_ID', N'MS_Description', CAST(N'ProgramReportFormSetID' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_ANNUL_PROG_REP', N'PROG_REP_FORM_ID', N'MS_Description', CAST(N'ProgramReportFormID' AS nvarchar(19)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_ANNUL_PROG_REP', N'PROG_REP_RCVD_DATE', N'MS_Description', CAST(N'ProgramReportReceivedDate' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_ANNUL_PROG_REP', N'PROG_REP_START_DATE', N'MS_Description', CAST(N'ProgramReportStartDate' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_ANNUL_PROG_REP', N'PROG_REP_END_DATE', N'MS_Description', CAST(N'ProgramReportEndDate' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_ANNUL_PROG_REP', N'ELEC_SUBM_TYPE_CODE', N'MS_Description', CAST(N'ElectronicSubmissionTypeCode' AS nvarchar(28)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_ANNUL_PROG_REP', N'PROG_REP_NPDES_DAT_GRP_NUM_CODE', N'MS_Description', CAST(N'ProgramReportNPDESDataGroupNumberCode' AS nvarchar(37)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_ANNUL_PROG_REP', N'BS_FAC_TYPE_OTHR_TXT', N'MS_Description', CAST(N'BiosolidsFacilityTypeOtherText' AS nvarchar(30)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_ANNUL_PROG_REP', N'BS_FAC_TTL_VOL_AMT', N'MS_Description', CAST(N'BiosolidsFacilityTotalVolumeAmount' AS nvarchar(34)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_ANNUL_PROG_REP', N'BS_FAC_TRTMNT_OTHR_TXT', N'MS_Description', CAST(N'BiosolidsFacilityTreatmentOtherText' AS nvarchar(35)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_ANNUL_PROG_REP', N'BS_ANNUL_PROG_REP_CMNT_TXT', N'MS_Description', CAST(N'BiosolidsAnnualProgramReportCommentText' AS nvarchar(39)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GNRL_PRMT', NULL, N'MS_Description', CAST(N'Schema element: GeneralPermitData' AS nvarchar(33)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GNRL_PRMT', N'SRC_SYSTM_IDENT', N'MS_Description', CAST(N'SourceSystemIdentifier' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GNRL_PRMT', N'TRANSACTION_TYPE', N'MS_Description', CAST(N'TransactionType' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GNRL_PRMT', N'TRANSACTION_TIMESTAMP', N'MS_Description', CAST(N'TransactionTimestamp' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GNRL_PRMT', N'PRMT_IDENT', N'MS_Description', CAST(N'PermitIdentifier' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GNRL_PRMT', N'ELEC_SUBM_TYPE_CODE', N'MS_Description', CAST(N'ElectronicSubmissionTypeCode' AS nvarchar(28)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GNRL_PRMT', N'ASSC_MASTER_GNRL_PRMT_IDENT', N'MS_Description', CAST(N'AssociatedMasterGeneralPermitIdentifier' AS nvarchar(39)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GNRL_PRMT', N'PRMT_TYPE_CODE', N'MS_Description', CAST(N'PermitTypeCode' AS nvarchar(14)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GNRL_PRMT', N'AGNCY_TYPE_CODE', N'MS_Description', CAST(N'AgencyTypeCode' AS nvarchar(14)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GNRL_PRMT', N'PRMT_STAT_CODE', N'MS_Description', CAST(N'PermitStatusCode' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GNRL_PRMT', N'PRMT_ISSUE_DATE', N'MS_Description', CAST(N'PermitIssueDate' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GNRL_PRMT', N'PRMT_EFFECTIVE_DATE', N'MS_Description', CAST(N'PermitEffectiveDate' AS nvarchar(19)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GNRL_PRMT', N'PRMT_EXPR_DATE', N'MS_Description', CAST(N'PermitExpirationDate' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GNRL_PRMT', N'REISSU_PRIO_PRMT_IND', N'MS_Description', CAST(N'ReissuancePriorityPermitIndicator' AS nvarchar(33)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GNRL_PRMT', N'BACKLOG_REASON_TXT', N'MS_Description', CAST(N'BacklogReasonText' AS nvarchar(17)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GNRL_PRMT', N'PRMT_ISSUING_ORG_TYPE_NAME', N'MS_Description', CAST(N'PermitIssuingOrganizationTypeName' AS nvarchar(33)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GNRL_PRMT', N'PRMT_APPEALED_IND', N'MS_Description', CAST(N'PermitAppealedIndicator' AS nvarchar(23)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GNRL_PRMT', N'PRMT_USR_DFND_DAT_ELM_1_TXT', N'MS_Description', CAST(N'PermitUserDefinedDataElement1Text' AS nvarchar(33)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GNRL_PRMT', N'PRMT_USR_DFND_DAT_ELM_2_TXT', N'MS_Description', CAST(N'PermitUserDefinedDataElement2Text' AS nvarchar(33)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GNRL_PRMT', N'PRMT_USR_DFND_DAT_ELM_3_TXT', N'MS_Description', CAST(N'PermitUserDefinedDataElement3Text' AS nvarchar(33)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GNRL_PRMT', N'PRMT_USR_DFND_DAT_ELM_4_TXT', N'MS_Description', CAST(N'PermitUserDefinedDataElement4Text' AS nvarchar(33)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GNRL_PRMT', N'PRMT_USR_DFND_DAT_ELM_5_TXT', N'MS_Description', CAST(N'PermitUserDefinedDataElement5Text' AS nvarchar(33)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GNRL_PRMT', N'PRMT_CMNTS_TXT', N'MS_Description', CAST(N'PermitCommentsText' AS nvarchar(18)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GNRL_PRMT', N'MAJOR_MINOR_RATING_CODE', N'MS_Description', CAST(N'MajorMinorRatingCode' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GNRL_PRMT', N'TTL_APPL_DSGN_FLOW_NUM', N'MS_Description', CAST(N'TotalApplicationDesignFlowNumber' AS nvarchar(32)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GNRL_PRMT', N'TTL_APPL_AVER_FLOW_NUM', N'MS_Description', CAST(N'TotalApplicationAverageFlowNumber' AS nvarchar(33)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GNRL_PRMT', N'APPL_RCVD_DATE', N'MS_Description', CAST(N'ApplicationReceivedDate' AS nvarchar(23)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GNRL_PRMT', N'PRMT_APPL_CMPL_DATE', N'MS_Description', CAST(N'PermitApplicationCompletionDate' AS nvarchar(31)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GNRL_PRMT', N'NEW_SRC_IND', N'MS_Description', CAST(N'NewSourceIndicator' AS nvarchar(18)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GNRL_PRMT', N'PRMT_ST_WTR_BODY_CODE', N'MS_Description', CAST(N'PermitStateWaterBodyCode' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GNRL_PRMT', N'PRMT_ST_WTR_BODY_NAME', N'MS_Description', CAST(N'PermitStateWaterBodyName' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GNRL_PRMT', N'FEDR_GRANT_IND', N'MS_Description', CAST(N'FederalGrantIndicator' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GNRL_PRMT', N'DMR_COGNZNT_OFCL', N'MS_Description', CAST(N'DMRCognizantOfficial' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GNRL_PRMT', N'DMR_COGNZNT_OFCL_TELEPH_NUM', N'MS_Description', CAST(N'DMRCognizantOfficialTelephoneNumber' AS nvarchar(35)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GNRL_PRMT', N'ELEC_REP_WAIVER_TYPE_CODE', N'MS_Description', CAST(N'ElectronicReportingWaiverTypeCode' AS nvarchar(33)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GNRL_PRMT', N'ELEC_REP_WAIVER_EFFECTIVE_DATE', N'MS_Description', CAST(N'ElectronicReportingWaiverEffectiveDate' AS nvarchar(38)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GNRL_PRMT', N'ELEC_REP_WAIVER_EXPR_DATE', N'MS_Description', CAST(N'ElectronicReportingWaiverExpirationDate' AS nvarchar(39)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GNRL_PRMT', N'MAJOR_MINOR_STAT_IND', N'MS_Description', CAST(N'MajorMinorStatusIndicator' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GNRL_PRMT', N'MAJOR_MINOR_STAT_START_DATE', N'MS_Description', CAST(N'MajorMinorStatusStartDate' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GNRL_PRMT', N'DMR_NON_RCPT_STAT_IND', N'MS_Description', CAST(N'DMRNonReceiptStatusIndicator' AS nvarchar(28)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GNRL_PRMT', N'DMR_NON_RCPT_STAT_START_DATE', N'MS_Description', CAST(N'DMRNonReceiptStatusStartDate' AS nvarchar(28)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_INDST_ANNUL_REP', NULL, N'MS_Description', CAST(N'Schema element: SWIndustrialAnnualReportData' AS nvarchar(44)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_INDST_ANNUL_REP', N'SRC_SYSTM_IDENT', N'MS_Description', CAST(N'SourceSystemIdentifier' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_INDST_ANNUL_REP', N'TRANSACTION_TYPE', N'MS_Description', CAST(N'TransactionType' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_INDST_ANNUL_REP', N'TRANSACTION_TIMESTAMP', N'MS_Description', CAST(N'TransactionTimestamp' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_INDST_ANNUL_REP', N'PRMT_IDENT', N'MS_Description', CAST(N'PermitIdentifier' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_INDST_ANNUL_REP', N'INDST_SW_ANNUL_REP_RCVD_DATE', N'MS_Description', CAST(N'IndustrialStormWaterAnnualReportReceivedDate' AS nvarchar(44)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_INDST_ANNUL_REP', N'FAC_INSP_SUMM_TXT', N'MS_Description', CAST(N'FacilityInspectionSummaryText' AS nvarchar(29)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_INDST_ANNUL_REP', N'VISUAL_ASSESSMENT_SUMM_TXT', N'MS_Description', CAST(N'VisualAssessmentSummaryText' AS nvarchar(27)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_INDST_ANNUL_REP', N'NO_FURTHER_REDUCTION_SUMM_TXT', N'MS_Description', CAST(N'NoFurtherReductionSummaryText' AS nvarchar(29)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_INDST_ANNUL_REP', N'CORR_ACTN_SUMM_TXT', N'MS_Description', CAST(N'CorrectiveActionSummaryText' AS nvarchar(27)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_NUM_COND', NULL, N'MS_Description', CAST(N'Schema element: NumericCondition' AS nvarchar(32)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_NUM_COND', N'NUM_COND_TXT', N'MS_Description', CAST(N'NumericConditionText' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_NUM_COND', N'NUM_COND_QTY', N'MS_Description', CAST(N'NumericConditionQuantity' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_NUM_COND', N'NUM_COND_STAT_BASE_CODE', N'MS_Description', CAST(N'NumericConditionStatisticalBaseCode' AS nvarchar(35)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_NUM_COND', N'NUM_COND_QUALIFIER', N'MS_Description', CAST(N'NumericConditionQualifier' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_NUM_COND', N'NUM_COND_OPT_MON_IND', N'MS_Description', CAST(N'NumericConditionOptionalMonitoringIndicator' AS nvarchar(43)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_NUM_COND', N'NUM_COND_STAY_VALUE', N'MS_Description', CAST(N'NumericConditionStayValue' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_FAC_TRTMNT', NULL, N'MS_Description', CAST(N'Schema element: String' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_FAC_TRTMNT', N'BS_FAC_TRTMNT_CODE', N'MS_Description', CAST(N'BiosolidsFacilityTreatmentCode' AS nvarchar(30)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GNRL_PRMT_COVERAGE_MS_4_REQ', NULL, N'MS_Description', CAST(N'Schema element: GeneralPermitCoverageMS4Requirement' AS nvarchar(51)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GNRL_PRMT_COVERAGE_MS_4_REQ', N'PRMT_IDENT', N'MS_Description', CAST(N'PermitIdentifier' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_INDST_PRMT', NULL, N'MS_Description', CAST(N'Schema element: SWIndustrialPermitData' AS nvarchar(38)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_INDST_PRMT', N'SRC_SYSTM_IDENT', N'MS_Description', CAST(N'SourceSystemIdentifier' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_INDST_PRMT', N'TRANSACTION_TYPE', N'MS_Description', CAST(N'TransactionType' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_INDST_PRMT', N'TRANSACTION_TIMESTAMP', N'MS_Description', CAST(N'TransactionTimestamp' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_INDST_PRMT', N'PRMT_IDENT', N'MS_Description', CAST(N'PermitIdentifier' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_INDST_PRMT', N'ST_WTR_BODY_NAME', N'MS_Description', CAST(N'StateWaterBodyName' AS nvarchar(18)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_INDST_PRMT', N'RCVG_MS_4_NAME', N'MS_Description', CAST(N'ReceivingMS4Name' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_INDST_PRMT', N'IMPAIRED_WTR_IND', N'MS_Description', CAST(N'ImpairedWaterIndicator' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_INDST_PRMT', N'HIST_PROP_IND', N'MS_Description', CAST(N'HistoricPropertyIndicator' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_INDST_PRMT', N'HIST_PROP_CRIT_MET_CODE', N'MS_Description', CAST(N'HistoricPropertyCriterionMetCode' AS nvarchar(32)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_INDST_PRMT', N'SPECIES_CRIT_HABITAT_IND', N'MS_Description', CAST(N'SpeciesCriticalHabitatIndicator' AS nvarchar(31)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_INDST_PRMT', N'SPECIES_CRIT_MET_CODE', N'MS_Description', CAST(N'SpeciesCriterionMetCode' AS nvarchar(23)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_INDST_PRMT', N'INDST_ACTY_SIZE', N'MS_Description', CAST(N'IndustrialActivitySize' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_INDST_PRMT', N'WEB_ADDR_URL', N'MS_Description', CAST(N'WebAddressURL' AS nvarchar(13)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_INDST_PRMT', N'ACTIVITIES_EXPOSED_SW_TXT', N'MS_Description', CAST(N'ActivitiesExposedSWText' AS nvarchar(23)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_INDST_PRMT', N'ASSC_POLLUTANTS_TXT', N'MS_Description', CAST(N'AssociatedPollutantsText' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_INDST_PRMT', N'CONTROL_MSR_TXT', N'MS_Description', CAST(N'ControlMeasuresText' AS nvarchar(19)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_INDST_PRMT', N'SCHD_CONTROL_MSR_TXT', N'MS_Description', CAST(N'ScheduleControlMeasuresText' AS nvarchar(27)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_INDST_PRMT', N'INDST_TTL_IMPERVIOUS_SURF_AREA', N'MS_Description', CAST(N'IndustrialTotalImperviousSurfaceArea' AS nvarchar(36)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_INDST_PRMT', N'TIER_TWO_IND', N'MS_Description', CAST(N'TierTwoIndicator' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_INDST_PRMT', N'TIER_THREE_IND', N'MS_Description', CAST(N'TierThreeIndicator' AS nvarchar(18)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_NUM_REP', NULL, N'MS_Description', CAST(N'Schema element: NumericReport' AS nvarchar(29)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_NUM_REP', N'NUM_REP_CODE', N'MS_Description', CAST(N'NumericReportCode' AS nvarchar(17)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_NUM_REP', N'NUM_REP_RCVD_DATE', N'MS_Description', CAST(N'NumericReportReceivedDate' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_NUM_REP', N'NUM_REP_NO_DSCH_IND', N'MS_Description', CAST(N'NumericReportNoDischargeIndicator' AS nvarchar(33)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_NUM_REP', N'NUM_COND_QTY', N'MS_Description', CAST(N'NumericConditionQuantity' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_NUM_REP', N'NUM_COND_ADJUSTED_QTY', N'MS_Description', CAST(N'NumericConditionAdjustedQuantity' AS nvarchar(32)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_NUM_REP', N'NUM_COND_QUALIFIER', N'MS_Description', CAST(N'NumericConditionQualifier' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_FAC_TYPE', NULL, N'MS_Description', CAST(N'Schema element: String' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_FAC_TYPE', N'BS_FAC_TYPE_CODE', N'MS_Description', CAST(N'BiosolidsFacilityTypeCode' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GPCF_NO_EXPOSURE', NULL, N'MS_Description', CAST(N'Schema element: GPCFNoExposure' AS nvarchar(30)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GPCF_NO_EXPOSURE', N'NO_EXPOSURE_AUTH_DATE', N'MS_Description', CAST(N'NoExposureAuthorizationDate' AS nvarchar(27)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GPCF_NO_EXPOSURE', N'NO_EXPOSURE_POSTMARK_DATE', N'MS_Description', CAST(N'NoExposurePostmarkDate' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GPCF_NO_EXPOSURE', N'NO_EXPOSURE_EVAL_DATE', N'MS_Description', CAST(N'NoExposureEvaluationDate' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GPCF_NO_EXPOSURE', N'NO_EXPOSURE_EVAL_BASIS_CODE', N'MS_Description', CAST(N'NoExposureEvaluationBasisCode' AS nvarchar(29)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GPCF_NO_EXPOSURE', N'NO_EXPOSURE_CRITERIA_MET_IND', N'MS_Description', CAST(N'NoExposureCriteriaMetIndicator' AS nvarchar(30)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GPCF_NO_EXPOSURE', N'PAVED_ROOF_SIZE', N'MS_Description', CAST(N'PavedRoofSize' AS nvarchar(13)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_MS_4_INSP', NULL, N'MS_Description', CAST(N'Schema element: StormWaterMS4Inspection' AS nvarchar(39)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_MS_4_INSP', N'MS_4_ANNUL_EXPEN_DOLLARS', N'MS_Description', CAST(N'MS4AnnualExpenditureDollars' AS nvarchar(27)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_MS_4_INSP', N'MS_4_ANNUL_EXPEN_YEAR', N'MS_Description', CAST(N'MS4AnnualExpenditureYear' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_MS_4_INSP', N'MS_4_BUDGET_DOLLARS', N'MS_Description', CAST(N'MS4BudgetDollars' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_MS_4_INSP', N'MS_4_BUDGET_YEAR', N'MS_Description', CAST(N'MS4BudgetYear' AS nvarchar(13)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_MS_4_INSP', N'MAJOR_OUTFALL_EST_MEAS_IND', N'MS_Description', CAST(N'MajorOutfallEstimatedMeasureIndicator' AS nvarchar(37)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_MS_4_INSP', N'MAJOR_OUTFALL_NUM', N'MS_Description', CAST(N'MajorOutfallNumber' AS nvarchar(18)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_MS_4_INSP', N'MINOR_OUTFALL_EST_MEAS_IND', N'MS_Description', CAST(N'MinorOutfallEstimatedMeasureIndicator' AS nvarchar(37)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_MS_4_INSP', N'MINOR_OUTFALL_NUM', N'MS_Description', CAST(N'MinorOutfallNumber' AS nvarchar(18)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_ORIG_PROGS', NULL, N'MS_Description', CAST(N'Schema element: String' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_ORIG_PROGS', N'ORIG_PROGS_CODE', N'MS_Description', CAST(N'OriginatingProgramsCode' AS nvarchar(23)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_INCIN_EMISSIONS_CONTROL_TYPE', NULL, N'MS_Description', CAST(N'Schema element: BiosolidsIncineratorEmissionsControlType' AS nvarchar(56)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_INCIN_EMISSIONS_CONTROL_TYPE', N'BS_EMISSIONS_CONTROL_CATG', N'MS_Description', CAST(N'BiosolidsEmissionsControlCategory' AS nvarchar(33)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_INCIN_EMISSIONS_CONTROL_TYPE', N'BS_EMISSIONS_CONTROL_TECHNOLOGY_CODE', N'MS_Description', CAST(N'BiosolidsEmissionsControlTechnologyCode' AS nvarchar(39)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_INCIN_EMISSIONS_CONTROL_TYPE', N'BS_EMISSIONS_CONTROL_OTHR_TXT', N'MS_Description', CAST(N'BiosolidsEmissionsControlOtherText' AS nvarchar(34)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GPCF_NOTICE_OF_INTENT', NULL, N'MS_Description', CAST(N'Schema element: GPCFNoticeOfIntent' AS nvarchar(34)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GPCF_NOTICE_OF_INTENT', N'NOI_SIGN_DATE', N'MS_Description', CAST(N'NOISignatureDate' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GPCF_NOTICE_OF_INTENT', N'NOI_POSTMARK_DATE', N'MS_Description', CAST(N'NOIPostmarkDate' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GPCF_NOTICE_OF_INTENT', N'NOI_RCVD_DATE', N'MS_Description', CAST(N'NOIReceivedDate' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GPCF_NOTICE_OF_INTENT', N'COMPLETE_NOI_RCVD_DATE', N'MS_Description', CAST(N'CompleteNOIReceivedDate' AS nvarchar(23)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GPCF_NOTICE_OF_INTENT', N'FEDR_CERCLA_DSCH_IND', N'MS_Description', CAST(N'FederalCERCLADischargeIndicator' AS nvarchar(31)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_NON_CNST_INSP', NULL, N'MS_Description', CAST(N'Schema element: StormWaterNonConstructionInspection' AS nvarchar(51)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_OTHR_PRMTS', NULL, N'MS_Description', CAST(N'Schema element: OtherPermits' AS nvarchar(28)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_OTHR_PRMTS', N'OTHR_PRMT_IDENT', N'MS_Description', CAST(N'OtherPermitIdentifier' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_OTHR_PRMTS', N'OTHR_ORG_NAME', N'MS_Description', CAST(N'OtherOrganizationName' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_OTHR_PRMTS', N'OTHR_PRMT_IDENT_CNTXT_NAME', N'MS_Description', CAST(N'OtherPermitIdentifierContextName' AS nvarchar(32)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_INCINERATION', NULL, N'MS_Description', CAST(N'Schema element: BiosolidsIncinerationData' AS nvarchar(41)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_INCINERATION', N'BS_INCIN_IDENT', N'MS_Description', CAST(N'BiosolidsIncineratorIdentifier' AS nvarchar(30)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_INCINERATION', N'BS_INCIN_TYPE_CODE', N'MS_Description', CAST(N'BiosolidsIncineratorTypeCode' AS nvarchar(28)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_INCINERATION', N'BS_INCIN_OTHR_TXT', N'MS_Description', CAST(N'BiosolidsIncineratorOtherText' AS nvarchar(29)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_INCINERATION', N'BS_INCIN_LAST_SIG_CHANGE_DATE', N'MS_Description', CAST(N'BiosolidsIncineratorLastSignificantChangeDate' AS nvarchar(45)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_INCINERATION', N'BS_INCIN_NEW_POLUT_LMTS_IND', N'MS_Description', CAST(N'BiosolidsIncineratorNewPollutantLimitsIndicator' AS nvarchar(47)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GPCF_NOTICE_OF_TERM', NULL, N'MS_Description', CAST(N'Schema element: GPCFNoticeOfTermination' AS nvarchar(39)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GPCF_NOTICE_OF_TERM', N'NOT_TERM_DATE', N'MS_Description', CAST(N'NOTTerminationDate' AS nvarchar(18)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GPCF_NOTICE_OF_TERM', N'NOT_SIGN_DATE', N'MS_Description', CAST(N'NOTSignatureDate' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GPCF_NOTICE_OF_TERM', N'NOT_POSTMARK_DATE', N'MS_Description', CAST(N'NOTPostmarkDate' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_GPCF_NOTICE_OF_TERM', N'NOT_RCVD_DATE', N'MS_Description', CAST(N'NOTReceivedDate' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_UNPRMT_CNST_INSP', NULL, N'MS_Description', CAST(N'Schema element: StormWaterUnpermittedConstructionInspection' AS nvarchar(59)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_UNPRMT_CNST_INSP', N'EST_START_DATE', N'MS_Description', CAST(N'EstimatedStartDate' AS nvarchar(18)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_UNPRMT_CNST_INSP', N'EST_COMPLETE_DATE', N'MS_Description', CAST(N'EstimatedCompleteDate' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_UNPRMT_CNST_INSP', N'EST_AREA_DISTURBED_ACRES_NUM', N'MS_Description', CAST(N'EstimatedAreaDisturbedAcresNumber' AS nvarchar(33)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SW_UNPRMT_CNST_INSP', N'PROJ_PLAN_SIZE_CODE', N'MS_Description', CAST(N'ProjectPlanSizeCode' AS nvarchar(19)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PARAM_LMTS', NULL, N'MS_Description', CAST(N'Schema element: ParameterLimitsData' AS nvarchar(35)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PARAM_LMTS', N'SRC_SYSTM_IDENT', N'MS_Description', CAST(N'SourceSystemIdentifier' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PARAM_LMTS', N'TRANSACTION_TYPE', N'MS_Description', CAST(N'TransactionType' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PARAM_LMTS', N'TRANSACTION_TIMESTAMP', N'MS_Description', CAST(N'TransactionTimestamp' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PARAM_LMTS', N'PRMT_IDENT', N'MS_Description', CAST(N'PermitIdentifier' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PARAM_LMTS', N'PRMT_FEATR_IDENT', N'MS_Description', CAST(N'PermittedFeatureIdentifier' AS nvarchar(26)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PARAM_LMTS', N'LMT_SET_DESIGNATOR', N'MS_Description', CAST(N'LimitSetDesignator' AS nvarchar(18)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PARAM_LMTS', N'PARAM_CODE', N'MS_Description', CAST(N'ParameterCode' AS nvarchar(13)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PARAM_LMTS', N'MON_SITE_DESC_CODE', N'MS_Description', CAST(N'MonitoringSiteDescriptionCode' AS nvarchar(29)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PARAM_LMTS', N'LMT_SEASON_NUM', N'MS_Description', CAST(N'LimitSeasonNumber' AS nvarchar(17)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_MGMT_PRACTICE', NULL, N'MS_Description', CAST(N'Schema element: BiosolidsManagementPracticeData' AS nvarchar(47)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_MGMT_PRACTICE', N'SSU_IDENT', N'MS_Description', CAST(N'SSUIdentifier' AS nvarchar(13)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_MGMT_PRACTICE', N'BS_MGMT_PRACTICE_CODE', N'MS_Description', CAST(N'BiosolidsManagementPracticeCode' AS nvarchar(31)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_MGMT_PRACTICE', N'BS_MGMT_PRACTICE_SUB_CATG_CODE', N'MS_Description', CAST(N'BiosolidsManagementPracticeSubCategoryCode' AS nvarchar(42)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_MGMT_PRACTICE', N'BS_MGMT_PRACTICE_SUB_CATG_TXT', N'MS_Description', CAST(N'BiosolidsManagementPracticeSubCategoryText' AS nvarchar(42)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_MGMT_PRACTICE', N'BS_OPERATOR_TYPE_CODE', N'MS_Description', CAST(N'BiosolidsOperatorTypeCode' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_MGMT_PRACTICE', N'BS_CNTNR_TYPE_CODE', N'MS_Description', CAST(N'BiosolidsContainerTypeCode' AS nvarchar(26)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_MGMT_PRACTICE', N'SSUID_VOL_AMT', N'MS_Description', CAST(N'SSUIDVolumeAmount' AS nvarchar(17)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_MGMT_PRACTICE', N'PATHOGEN_CLASS_TYPE_CODE', N'MS_Description', CAST(N'PathogenClassTypeCode' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_MGMT_PRACTICE', N'POLUT_LOADING_RATES_EXCEEDANCE_IND', N'MS_Description', CAST(N'PollutantLoadingRatesExceedanceIndicator' AS nvarchar(40)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_MGMT_PRACTICE', N'BS_MGMT_PRACTICE_VIOL_TYPE_CODE', N'MS_Description', CAST(N'BiosolidsManagementPracticeViolationTypeCode' AS nvarchar(44)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_MGMT_PRACTICE', N'BS_MGMT_PRACTICE_VIOL_TXT', N'MS_Description', CAST(N'BiosolidsManagementPracticeViolationText' AS nvarchar(40)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_MGMT_PRACTICE', N'BS_OFF_SITE_FAC_PRMT_IDENT', N'MS_Description', CAST(N'BiosolidsOffSiteFacilityPermitIdentifier' AS nvarchar(40)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_MGMT_PRACTICE', N'SURF_DSPL_WITHOUT_LINER_IND', N'MS_Description', CAST(N'SurfaceDisposalWithoutLinerIndicator' AS nvarchar(36)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_MGMT_PRACTICE', N'SURF_DSPL_SITE_SPEC_LMT_IND', N'MS_Description', CAST(N'SurfaceDisposalSiteSpecificLimitIndicator' AS nvarchar(41)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_MGMT_PRACTICE', N'SURF_DSPL_MIN_BOUNDARY_DISTANCE_CODE', N'MS_Description', CAST(N'SurfaceDisposalMinimumBoundaryDistanceCode' AS nvarchar(42)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_HIST_PRMT_SCHD_EVTS', NULL, N'MS_Description', CAST(N'Schema element: HistoricalPermitScheduleEventsData' AS nvarchar(50)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_HIST_PRMT_SCHD_EVTS', N'SRC_SYSTM_IDENT', N'MS_Description', CAST(N'SourceSystemIdentifier' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_HIST_PRMT_SCHD_EVTS', N'TRANSACTION_TYPE', N'MS_Description', CAST(N'TransactionType' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_HIST_PRMT_SCHD_EVTS', N'TRANSACTION_TIMESTAMP', N'MS_Description', CAST(N'TransactionTimestamp' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_HIST_PRMT_SCHD_EVTS', N'PRMT_IDENT', N'MS_Description', CAST(N'PermitIdentifier' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_HIST_PRMT_SCHD_EVTS', N'PRMT_EFFECTIVE_DATE', N'MS_Description', CAST(N'PermitEffectiveDate' AS nvarchar(19)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_HIST_PRMT_SCHD_EVTS', N'NARR_COND_NUM', N'MS_Description', CAST(N'NarrativeConditionNumber' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_HIST_PRMT_SCHD_EVTS', N'SCHD_EVT_CODE', N'MS_Description', CAST(N'ScheduleEventCode' AS nvarchar(17)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_HIST_PRMT_SCHD_EVTS', N'SCHD_DATE', N'MS_Description', CAST(N'ScheduleDate' AS nvarchar(12)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_HIST_PRMT_SCHD_EVTS', N'SCHD_REP_RCVD_DATE', N'MS_Description', CAST(N'ScheduleReportReceivedDate' AS nvarchar(26)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_HIST_PRMT_SCHD_EVTS', N'SCHD_ACTUL_DATE', N'MS_Description', CAST(N'ScheduleActualDate' AS nvarchar(18)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_HIST_PRMT_SCHD_EVTS', N'SCHD_PROJ_DATE', N'MS_Description', CAST(N'ScheduleProjectedDate' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_HIST_PRMT_SCHD_EVTS', N'SCHD_USR_DFND_DAT_ELM_1', N'MS_Description', CAST(N'ScheduleUserDefinedDataElement1' AS nvarchar(31)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_HIST_PRMT_SCHD_EVTS', N'SCHD_USR_DFND_DAT_ELM_2', N'MS_Description', CAST(N'ScheduleUserDefinedDataElement2' AS nvarchar(31)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_HIST_PRMT_SCHD_EVTS', N'SCHD_EVT_CMNTS', N'MS_Description', CAST(N'ScheduleEventComments' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SWMS_4_ANNUL_PROG_REP', NULL, N'MS_Description', CAST(N'Schema element: SWMS4AnnualProgramReportData' AS nvarchar(44)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SWMS_4_ANNUL_PROG_REP', N'SRC_SYSTM_IDENT', N'MS_Description', CAST(N'SourceSystemIdentifier' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SWMS_4_ANNUL_PROG_REP', N'TRANSACTION_TYPE', N'MS_Description', CAST(N'TransactionType' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SWMS_4_ANNUL_PROG_REP', N'TRANSACTION_TIMESTAMP', N'MS_Description', CAST(N'TransactionTimestamp' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SWMS_4_ANNUL_PROG_REP', N'PRMT_IDENT', N'MS_Description', CAST(N'PermitIdentifier' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SWMS_4_ANNUL_PROG_REP', N'PROG_REP_FORM_SET_ID', N'MS_Description', CAST(N'ProgramReportFormSetID' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SWMS_4_ANNUL_PROG_REP', N'PROG_REP_FORM_ID', N'MS_Description', CAST(N'ProgramReportFormID' AS nvarchar(19)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SWMS_4_ANNUL_PROG_REP', N'PROG_REP_RCVD_DATE', N'MS_Description', CAST(N'ProgramReportReceivedDate' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SWMS_4_ANNUL_PROG_REP', N'PROG_REP_START_DATE', N'MS_Description', CAST(N'ProgramReportStartDate' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SWMS_4_ANNUL_PROG_REP', N'PROG_REP_END_DATE', N'MS_Description', CAST(N'ProgramReportEndDate' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SWMS_4_ANNUL_PROG_REP', N'ELEC_SUBM_TYPE_CODE', N'MS_Description', CAST(N'ElectronicSubmissionTypeCode' AS nvarchar(28)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SWMS_4_ANNUL_PROG_REP', N'PROG_REP_NPDES_DAT_GRP_NUM_CODE', N'MS_Description', CAST(N'ProgramReportNPDESDataGroupNumberCode' AS nvarchar(37)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PATHOGEN_REDUCTION_TYPE', NULL, N'MS_Description', CAST(N'Schema element: String' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PATHOGEN_REDUCTION_TYPE', N'PATHOGEN_REDUCTION_TYPE_CODE', N'MS_Description', CAST(N'PathogenReductionTypeCode' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR', NULL, N'MS_Description', CAST(N'Schema element: BiosolidsOffSiteHandlerApplierPreparer' AS nvarchar(54)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR', N'BS_OFF_SITE_HNDLR_APPLIER_VOL_AMT', N'MS_Description', CAST(N'BiosolidsOffSiteHandlerApplierVolumeAmount' AS nvarchar(42)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_IMPACT_SSO_EVT', NULL, N'MS_Description', CAST(N'Schema element: String' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_IMPACT_SSO_EVT', N'IMPACT_SSO_EVT', N'MS_Description', CAST(N'ImpactSSOEvent' AS nvarchar(14)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SWMS_4_PRMT', NULL, N'MS_Description', CAST(N'Schema element: SWMS4PermitData' AS nvarchar(31)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SWMS_4_PRMT', N'SRC_SYSTM_IDENT', N'MS_Description', CAST(N'SourceSystemIdentifier' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SWMS_4_PRMT', N'TRANSACTION_TYPE', N'MS_Description', CAST(N'TransactionType' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SWMS_4_PRMT', N'TRANSACTION_TIMESTAMP', N'MS_Description', CAST(N'TransactionTimestamp' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SWMS_4_PRMT', N'PRMT_IDENT', N'MS_Description', CAST(N'PermitIdentifier' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SWMS_4_PRMT', N'MS_4_PRMT_PHASE_CODE', N'MS_Description', CAST(N'MS4PermitPhaseCode' AS nvarchar(18)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SWMS_4_PRMT', N'MS_4_PRMT_PHASE_TXT', N'MS_Description', CAST(N'MS4PermitPhaseText' AS nvarchar(18)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PAYLOAD', NULL, N'MS_Description', CAST(N'Schema element: PayloadData' AS nvarchar(27)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PAYLOAD', N'OPERATION', N'MS_Description', CAST(N'Operation' AS nvarchar(9)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_PRMT', NULL, N'MS_Description', CAST(N'Schema element: BiosolidsPermitData' AS nvarchar(35)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_PRMT', N'SRC_SYSTM_IDENT', N'MS_Description', CAST(N'SourceSystemIdentifier' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_PRMT', N'TRANSACTION_TYPE', N'MS_Description', CAST(N'TransactionType' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_PRMT', N'TRANSACTION_TIMESTAMP', N'MS_Description', CAST(N'TransactionTimestamp' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_PRMT', N'PRMT_IDENT', N'MS_Description', CAST(N'PermitIdentifier' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_PRMT', N'BS_FAC_TYPE_OTHR_TXT', N'MS_Description', CAST(N'BiosolidsFacilityTypeOtherText' AS nvarchar(30)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_PRMT', N'BS_FAC_TTL_VOL_AMT', N'MS_Description', CAST(N'BiosolidsFacilityTotalVolumeAmount' AS nvarchar(34)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_PRMT', N'BS_FAC_TRTMNT_OTHR_TXT', N'MS_Description', CAST(N'BiosolidsFacilityTreatmentOtherText' AS nvarchar(35)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_IMPAIRED_WTR_POLLUTANTS', NULL, N'MS_Description', CAST(N'Schema element: CustomXmlStringFormatInt32' AS nvarchar(42)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_IMPAIRED_WTR_POLLUTANTS', N'IMPAIRED_WTR_POLLUTANTS', N'MS_Description', CAST(N'ImpairedWaterPollutants' AS nvarchar(23)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_TELEPH', NULL, N'MS_Description', CAST(N'Schema element: Telephone' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_TELEPH', N'TELEPH_NUM_TYPE_CODE', N'MS_Description', CAST(N'TelephoneNumberTypeCode' AS nvarchar(23)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_TELEPH', N'TELEPH_NUM', N'MS_Description', CAST(N'TelephoneNumber' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_TELEPH', N'TELEPH_EXT_NUM', N'MS_Description', CAST(N'TelephoneExtensionNumber' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PLCY', NULL, N'MS_Description', CAST(N'Schema element: String' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PLCY', N'PLCY_CODE', N'MS_Description', CAST(N'PolicyCode' AS nvarchar(10)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_SEWAGE_SLDG_PARAM', NULL, N'MS_Description', CAST(N'Schema element: BiosolidsSewageSludgeParameter' AS nvarchar(46)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_SEWAGE_SLDG_PARAM', N'BS_SEWAGE_SLDG_PARAM_CODE', N'MS_Description', CAST(N'BiosolidsSewageSludgeParameterCode' AS nvarchar(34)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_SEWAGE_SLDG_PARAM', N'BS_SEWAGE_SLDG_PARAM_LMT', N'MS_Description', CAST(N'BiosolidsSewageSludgeParameterLimit' AS nvarchar(35)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_SEWAGE_SLDG_PARAM', N'PARAM_VALUE', N'MS_Description', CAST(N'ParameterValue' AS nvarchar(14)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_SEWAGE_SLDG_PARAM', N'VALUE_QUALIFIER', N'MS_Description', CAST(N'ValueQualifier' AS nvarchar(14)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_SEWAGE_SLDG_PARAM', N'NO_DAT_IND_CODE', N'MS_Description', CAST(N'NoDataIndicatorCode' AS nvarchar(19)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_SEWAGE_SLDG_PARAM', N'PASS_FAIL_IND_CODE', N'MS_Description', CAST(N'PassFailIndicatorCode' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_SEWAGE_SLDG_PARAM', N'PATHOGEN_REDUCTION_TYPE_CODE', N'MS_Description', CAST(N'PathogenReductionTypeCode' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_SEWAGE_SLDG_PARAM', N'BS_SMPL_START_DATE', N'MS_Description', CAST(N'BiosolidsSampleStartDate' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_SEWAGE_SLDG_PARAM', N'BS_SMPL_END_DATE', N'MS_Description', CAST(N'BiosolidsSampleEndDate' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BS_SEWAGE_SLDG_PARAM', N'BS_SMPL_MN', N'MS_Description', CAST(N'BiosolidsSampleMonth' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_INCIN', NULL, N'MS_Description', CAST(N'Schema element: Incinerator' AS nvarchar(27)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_INCIN', N'BERYLLIUM_CMPL_IND', N'MS_Description', CAST(N'BerylliumComplianceIndicator' AS nvarchar(28)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_INCIN', N'MERCURY_CMPL_IND', N'MS_Description', CAST(N'MercuryComplianceIndicator' AS nvarchar(26)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_TMDL_POLLUTANTS', NULL, N'MS_Description', CAST(N'Schema element: TMDLPollutants' AS nvarchar(30)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_TMDL_POLLUTANTS', N'TMDL_IDENT', N'MS_Description', CAST(N'TMDLIdentifier' AS nvarchar(14)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_TMDL_POLLUTANTS', N'TMDL_NAME', N'MS_Description', CAST(N'TMDLName' AS nvarchar(8)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_POLUT_LIST', NULL, N'MS_Description', CAST(N'Schema element: PollutantList' AS nvarchar(29)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BYPASS_TRTMNT_PLANT_EQUIPMENT', NULL, N'MS_Description', CAST(N'Schema element: String' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_BYPASS_TRTMNT_PLANT_EQUIPMENT', N'BYPASS_TRTMNT_PLANT_EQUIPMENT_CODE', N'MS_Description', CAST(N'BypassTreatmentPlantEquipmentCode' AS nvarchar(33)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_INDST_USR_INFO', NULL, N'MS_Description', CAST(N'Schema element: IndustrialUserInformation' AS nvarchar(41)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_INDST_USR_INFO', N'PRMT_IDENT', N'MS_Description', CAST(N'PermitIdentifier' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_INDST_USR_INFO', N'IU_AVER_DAILY_WW_FLOW_RATE_GPD', N'MS_Description', CAST(N'IUAverageDailyWastewaterFlowRateGPD' AS nvarchar(35)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_INDST_USR_INFO', N'IU_AVER_DAILY_PRCSS_WW_FLOW_RATE_GPD', N'MS_Description', CAST(N'IUAverageDailyProcessWastewaterFlowRateGPD' AS nvarchar(42)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_INDST_USR_INFO', N'IU_SUBJECT_LOC_LMTS_IND', N'MS_Description', CAST(N'IUSubjectLocalLimitsIndicator' AS nvarchar(29)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_INDST_USR_INFO', N'IU_SUBJECT_LOC_LMTS_MORE_STRINGENT_CAT_STD_IND', N'MS_Description', CAST(N'IUSubjectLocalLimitsMoreStringentCatStdIndicator' AS nvarchar(48)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_INDST_USR_INFO', N'MTCIU_SUBJECT_REDUCED_REP_IND', N'MS_Description', CAST(N'MTCIUSubjectReducedReportingIndicator' AS nvarchar(37)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_INDST_USR_INFO', N'NUM_IU_INSP_BY_CA', N'MS_Description', CAST(N'NumberIUInspectionsByCA' AS nvarchar(23)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_INDST_USR_INFO', N'NUM_IU_SMPL_EVTS_BY_CA', N'MS_Description', CAST(N'NumberIUSamplingEventsByCA' AS nvarchar(26)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_INDST_USR_INFO', N'NUM_REQD_IU_SELF_MON_EVTS_MAX', N'MS_Description', CAST(N'NumberReqdIUSelfMonEventsMaximum' AS nvarchar(32)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_INDST_USR_INFO', N'IU_COMPLY_REQ_SELF_MON_RPTING_IND', N'MS_Description', CAST(N'IUComplyReqSelfMonRptingIndicator' AS nvarchar(33)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_INDST_USR_INFO', N'IU_COMPLY_REQ_SELF_MON_RPTING_TXT', N'MS_Description', CAST(N'IUComplyReqSelfMonRptingText' AS nvarchar(28)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_INDST_USR_INFO', N'NSCIU_CERT_SUBM_TO_CA_IND', N'MS_Description', CAST(N'NSCIUCertSubmToCAIndicator' AS nvarchar(26)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_INDST_USR_INFO', N'CHANGED_DISCH_SUBM_IND', N'MS_Description', CAST(N'ChangedDischSubmIndicator' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_TMDL_POLUT', NULL, N'MS_Description', CAST(N'Schema element: CustomXmlStringFormatInt32' AS nvarchar(42)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_TMDL_POLUT', N'TMDL_POLUT_CODE', N'MS_Description', CAST(N'TMDLPollutantCode' AS nvarchar(17)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_POTW_PRMT', NULL, N'MS_Description', CAST(N'Schema element: POTWPermitData' AS nvarchar(30)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_POTW_PRMT', N'SRC_SYSTM_IDENT', N'MS_Description', CAST(N'SourceSystemIdentifier' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_POTW_PRMT', N'TRANSACTION_TYPE', N'MS_Description', CAST(N'TransactionType' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_POTW_PRMT', N'TRANSACTION_TIMESTAMP', N'MS_Description', CAST(N'TransactionTimestamp' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_POTW_PRMT', N'PRMT_IDENT', N'MS_Description', CAST(N'PermitIdentifier' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_POTW_PRMT', N'SSCS_POPL_SERVED_NUM', N'MS_Description', CAST(N'SSCSPopulationServedNumber' AS nvarchar(26)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_POTW_PRMT', N'COMBINED_SSCS_SYSTM_LENGTH', N'MS_Description', CAST(N'CombinedSSCSSystemLength' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_ANNUL_PROG_REP', NULL, N'MS_Description', CAST(N'Schema element: CAFOAnnualProgramReportData' AS nvarchar(43)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_ANNUL_PROG_REP', N'SRC_SYSTM_IDENT', N'MS_Description', CAST(N'SourceSystemIdentifier' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_ANNUL_PROG_REP', N'TRANSACTION_TYPE', N'MS_Description', CAST(N'TransactionType' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_ANNUL_PROG_REP', N'TRANSACTION_TIMESTAMP', N'MS_Description', CAST(N'TransactionTimestamp' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_ANNUL_PROG_REP', N'PRMT_IDENT', N'MS_Description', CAST(N'PermitIdentifier' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_ANNUL_PROG_REP', N'PROG_REP_FORM_SET_ID', N'MS_Description', CAST(N'ProgramReportFormSetID' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_ANNUL_PROG_REP', N'PROG_REP_FORM_ID', N'MS_Description', CAST(N'ProgramReportFormID' AS nvarchar(19)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_ANNUL_PROG_REP', N'PROG_REP_RCVD_DATE', N'MS_Description', CAST(N'ProgramReportReceivedDate' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_ANNUL_PROG_REP', N'PROG_REP_START_DATE', N'MS_Description', CAST(N'ProgramReportStartDate' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_ANNUL_PROG_REP', N'PROG_REP_END_DATE', N'MS_Description', CAST(N'ProgramReportEndDate' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_ANNUL_PROG_REP', N'ELEC_SUBM_TYPE_CODE', N'MS_Description', CAST(N'ElectronicSubmissionTypeCode' AS nvarchar(28)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_ANNUL_PROG_REP', N'PROG_REP_NPDES_DAT_GRP_NUM_CODE', N'MS_Description', CAST(N'ProgramReportNPDESDataGroupNumberCode' AS nvarchar(37)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_ANNUL_PROG_REP', N'NUTR_MGMT_PLAN_ACREAGE_NUM', N'MS_Description', CAST(N'NutrientManagementPlanAcreageNumber' AS nvarchar(35)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_ANNUL_PROG_REP', N'ACTUL_LAND_APPL_ACREAGE_NUM', N'MS_Description', CAST(N'ActualLandApplicationAcreageNumber' AS nvarchar(34)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_ANNUL_PROG_REP', N'NMP_CERT_PLNR_IND', N'MS_Description', CAST(N'NMPCertifiedPlannerIndicator' AS nvarchar(28)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_INDST_USR_INVENTORY', NULL, N'MS_Description', CAST(N'Schema element: IndustrialUserInventory' AS nvarchar(39)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_INDST_USR_INVENTORY', N'INDST_USR_IND', N'MS_Description', CAST(N'IndustrialUserIndicator' AS nvarchar(23)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_TRTMNT_CHEMS_LIST', NULL, N'MS_Description', CAST(N'Schema element: String' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_TRTMNT_CHEMS_LIST', N'TRTMNT_CHEMS_LIST', N'MS_Description', CAST(N'TreatmentChemicalsList' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_POTW_TRTMNT_TECHNOLOGY_PRMT', NULL, N'MS_Description', CAST(N'Schema element: POTWTreatmentTechnologyPermitData' AS nvarchar(49)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_POTW_TRTMNT_TECHNOLOGY_PRMT', N'SRC_SYSTM_IDENT', N'MS_Description', CAST(N'SourceSystemIdentifier' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_POTW_TRTMNT_TECHNOLOGY_PRMT', N'TRANSACTION_TYPE', N'MS_Description', CAST(N'TransactionType' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_POTW_TRTMNT_TECHNOLOGY_PRMT', N'TRANSACTION_TIMESTAMP', N'MS_Description', CAST(N'TransactionTimestamp' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_POTW_TRTMNT_TECHNOLOGY_PRMT', N'PRMT_IDENT', N'MS_Description', CAST(N'PermitIdentifier' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_POTW_TRTMNT_TECHNOLOGY_PRMT', N'POTW_TRTMNT_LEVEL_CODE', N'MS_Description', CAST(N'POTWTreatmentLevelCode' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_POTW_TRTMNT_TECHNOLOGY_PRMT', N'POTW_TRTMNT_LEVEL_OTHR_TXT', N'MS_Description', CAST(N'POTWTreatmentLevelOtherText' AS nvarchar(27)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_POTW_TRTMNT_TECHNOLOGY_PRMT', N'POTW_WW_DISINFECTION_TECHNOLOGY_CODE', N'MS_Description', CAST(N'POTWWastewaterDisinfectionTechnologyCode' AS nvarchar(40)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_POTW_TRTMNT_TECHNOLOGY_PRMT', N'POTW_WW_DISINFECTION_TECHNOLOGY_OTHR_TXT', N'MS_Description', CAST(N'POTWWastewaterDisinfectionTechnologyOtherText' AS nvarchar(45)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_POTW_TRTMNT_TECHNOLOGY_PRMT', N'POTW_WW_TRTMNT_TECHNOLOGY_UNIT_OPERATION_CODE', N'MS_Description', CAST(N'POTWWastewaterTreatmentTechnologyUnitOperationCode' AS nvarchar(50)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_POTW_TRTMNT_TECHNOLOGY_PRMT', N'POTW_WW_TRTMNT_TECHNOLOGY_UNIT_OPERATION_OTHR_TXT', N'MS_Description', CAST(N'POTWWastewaterTreatmentTechnologyUnitOperationOtherText' AS nvarchar(55)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_INSP', NULL, N'MS_Description', CAST(N'Schema element: CAFOInspection' AS nvarchar(30)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_INSP', N'CAFO_CLASS_CODE', N'MS_Description', CAST(N'CAFOClassificationCode' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_INSP', N'IS_ANML_FAC_TYPE_CAFO_IND', N'MS_Description', CAST(N'IsAnimalFacilityTypeCAFOIndicator' AS nvarchar(33)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_INSP', N'CAFO_DESGN_DATE', N'MS_Description', CAST(N'CAFODesignationDate' AS nvarchar(19)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_INSP', N'CAFO_DESGN_REASON_TXT', N'MS_Description', CAST(N'CAFODesignationReasonText' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_INSP', N'DSCH_DRNG_YEAR_PROD_AREA_IND', N'MS_Description', CAST(N'DischargesDuringYearProductionAreaIndicator' AS nvarchar(43)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_INSP', N'DSCH_DRNG_YEAR_LAND_APPL_AREA_IND', N'MS_Description', CAST(N'DischargesDuringYearLandApplicationAreaIndicator' AS nvarchar(48)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_INSP', N'CAFO_DSCH_DRNG_YEAR_TXT', N'MS_Description', CAST(N'CAFODischargesDuringYearText' AS nvarchar(28)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_INSP', N'NUM_ACRES_CONTRB_DRAIN', N'MS_Description', CAST(N'NumberAcresContributingDrainage' AS nvarchar(31)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_INSP', N'APPL_MEAS_AVAIL_LAND_NUM', N'MS_Description', CAST(N'ApplicationMeasureAvailableLandNumber' AS nvarchar(37)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_INSP', N'SOLID_MNUR_LTTR_GNRTD_AMT', N'MS_Description', CAST(N'SolidManureLitterGeneratedAmount' AS nvarchar(32)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_INSP', N'LIQUID_MNUR_WW_GNRTD_AMT', N'MS_Description', CAST(N'LiquidManureWastewaterGeneratedAmount' AS nvarchar(37)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_INSP', N'SOLID_MNUR_LTTR_TRANS_AMT', N'MS_Description', CAST(N'SolidManureLitterTransferAmount' AS nvarchar(31)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_INSP', N'LIQUID_MNUR_WW_TRANS_AMT', N'MS_Description', CAST(N'LiquidManureWastewaterTransferAmount' AS nvarchar(36)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_INSP', N'NMP_DVLPD_CERT_PLNR_APRVD_IND', N'MS_Description', CAST(N'NMPDevelopedCertifiedPlannerApprovedIndicator' AS nvarchar(45)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_INSP', N'NMP_DVLPD_DATE', N'MS_Description', CAST(N'NMPDevelopedDate' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_INSP', N'NMP_LAST_UPDATED_DATE', N'MS_Description', CAST(N'NMPLastUpdatedDate' AS nvarchar(18)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_INSP', N'ENVR_MGMT_SYSTM_IND', N'MS_Description', CAST(N'EnvironmentalManagementSystemIndicator' AS nvarchar(38)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_INSP', N'EMS_DVLPD_DATE', N'MS_Description', CAST(N'EMSDevelopedDate' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_INSP', N'EMS_LAST_UPDATED_DATE', N'MS_Description', CAST(N'EMSLastUpdatedDate' AS nvarchar(18)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_INSP', N'LVSTCK_MAX_CPCTY_NUM', N'MS_Description', CAST(N'LivestockMaximumCapacityNumber' AS nvarchar(30)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_INSP', N'LVSTCK_CPCTY_DTRMN_BS_UPON_NUM', N'MS_Description', CAST(N'LivestockCapacityDeterminationBasedUponNumber' AS nvarchar(45)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_INSP', N'AUTH_LVSTCK_CPCTY_NUM', N'MS_Description', CAST(N'AuthorizedLivestockCapacityNumber' AS nvarchar(33)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_INFRML_ENFRC_ACTN', NULL, N'MS_Description', CAST(N'Schema element: InformalEnforcementActionData' AS nvarchar(45)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_INFRML_ENFRC_ACTN', N'SRC_SYSTM_IDENT', N'MS_Description', CAST(N'SourceSystemIdentifier' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_INFRML_ENFRC_ACTN', N'TRANSACTION_TYPE', N'MS_Description', CAST(N'TransactionType' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_INFRML_ENFRC_ACTN', N'TRANSACTION_TIMESTAMP', N'MS_Description', CAST(N'TransactionTimestamp' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_INFRML_ENFRC_ACTN', N'ENFRC_ACTN_IDENT', N'MS_Description', CAST(N'EnforcementActionIdentifier' AS nvarchar(27)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_INFRML_ENFRC_ACTN', N'ENFRC_ACTN_TYPE_CODE', N'MS_Description', CAST(N'EnforcementActionTypeCode' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_INFRML_ENFRC_ACTN', N'ENFRC_ACTN_NAME', N'MS_Description', CAST(N'EnforcementActionName' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_INFRML_ENFRC_ACTN', N'ACHIEVED_DATE', N'MS_Description', CAST(N'AchievedDate' AS nvarchar(12)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_INFRML_ENFRC_ACTN', N'FILE_NUM', N'MS_Description', CAST(N'FileNumber' AS nvarchar(10)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_INFRML_ENFRC_ACTN', N'REASON_DELETING_RECORD', N'MS_Description', CAST(N'ReasonDeletingRecord' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_INFRML_ENFRC_ACTN', N'INFRML_EA_CMNT_TXT', N'MS_Description', CAST(N'InformalEACommentText' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_INFRML_ENFRC_ACTN', N'INFRML_EA_USR_DFND_FLD_1', N'MS_Description', CAST(N'InformalEAUserDefinedField1' AS nvarchar(27)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_INFRML_ENFRC_ACTN', N'INFRML_EA_USR_DFND_FLD_2', N'MS_Description', CAST(N'InformalEAUserDefinedField2' AS nvarchar(27)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_INFRML_ENFRC_ACTN', N'INFRML_EA_USR_DFND_FLD_3', N'MS_Description', CAST(N'InformalEAUserDefinedField3' AS nvarchar(27)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_INFRML_ENFRC_ACTN', N'INFRML_EA_USR_DFND_FLD_4', N'MS_Description', CAST(N'InformalEAUserDefinedField4' AS nvarchar(27)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_INFRML_ENFRC_ACTN', N'INFRML_EA_USR_DFND_FLD_5', N'MS_Description', CAST(N'InformalEAUserDefinedField5' AS nvarchar(27)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_INFRML_ENFRC_ACTN', N'INFRML_EA_USR_DFND_FLD_6', N'MS_Description', CAST(N'InformalEAUserDefinedField6' AS nvarchar(27)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_INFRML_ENFRC_ACTN', N'ENFRC_AGNCY_NAME', N'MS_Description', CAST(N'EnforcementAgencyName' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_UNPRMT_FAC', NULL, N'MS_Description', CAST(N'Schema element: UnpermittedFacilityData' AS nvarchar(39)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_UNPRMT_FAC', N'SRC_SYSTM_IDENT', N'MS_Description', CAST(N'SourceSystemIdentifier' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_UNPRMT_FAC', N'TRANSACTION_TYPE', N'MS_Description', CAST(N'TransactionType' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_UNPRMT_FAC', N'TRANSACTION_TIMESTAMP', N'MS_Description', CAST(N'TransactionTimestamp' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_UNPRMT_FAC', N'PRMT_IDENT', N'MS_Description', CAST(N'PermitIdentifier' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_UNPRMT_FAC', N'LOCALITY_NAME', N'MS_Description', CAST(N'LocalityName' AS nvarchar(12)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_UNPRMT_FAC', N'LOC_ADDR_CITY_CODE', N'MS_Description', CAST(N'LocationAddressCityCode' AS nvarchar(23)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_UNPRMT_FAC', N'LOC_ADDR_COUNTY_CODE', N'MS_Description', CAST(N'LocationAddressCountyCode' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_UNPRMT_FAC', N'FAC_SITE_NAME', N'MS_Description', CAST(N'FacilitySiteName' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_UNPRMT_FAC', N'LOC_ADDR_TXT', N'MS_Description', CAST(N'LocationAddressText' AS nvarchar(19)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_UNPRMT_FAC', N'SUPPL_LOC_TXT', N'MS_Description', CAST(N'SupplementalLocationText' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_UNPRMT_FAC', N'LOC_ST_CODE', N'MS_Description', CAST(N'LocationStateCode' AS nvarchar(17)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_UNPRMT_FAC', N'LOC_ZIP_CODE', N'MS_Description', CAST(N'LocationZipCode' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_UNPRMT_FAC', N'LOC_COUNTRY_CODE', N'MS_Description', CAST(N'LocationCountryCode' AS nvarchar(19)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_UNPRMT_FAC', N'ORG_DUNS_NUM', N'MS_Description', CAST(N'OrganizationDUNSNumber' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_UNPRMT_FAC', N'ST_FAC_IDENT', N'MS_Description', CAST(N'StateFacilityIdentifier' AS nvarchar(23)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_UNPRMT_FAC', N'ST_RGN_CODE', N'MS_Description', CAST(N'StateRegionCode' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_UNPRMT_FAC', N'FAC_CONGR_DISTRICT_NUM', N'MS_Description', CAST(N'FacilityCongressionalDistrictNumber' AS nvarchar(35)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_UNPRMT_FAC', N'FAC_TYPE_OF_OWNERSHIP_CODE', N'MS_Description', CAST(N'FacilityTypeOfOwnershipCode' AS nvarchar(27)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_UNPRMT_FAC', N'FEDR_FAC_IDENT_NUM', N'MS_Description', CAST(N'FederalFacilityIdentificationNumber' AS nvarchar(35)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_UNPRMT_FAC', N'FEDR_AGNCY_CODE', N'MS_Description', CAST(N'FederalAgencyCode' AS nvarchar(17)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_UNPRMT_FAC', N'TRIBAL_LAND_CODE', N'MS_Description', CAST(N'TribalLandCode' AS nvarchar(14)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_UNPRMT_FAC', N'CNST_PROJ_NAME', N'MS_Description', CAST(N'ConstructionProjectName' AS nvarchar(23)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_UNPRMT_FAC', N'CNST_PROJ_LAT_MEAS', N'MS_Description', CAST(N'ConstructionProjectLatitudeMeasure' AS nvarchar(34)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_UNPRMT_FAC', N'CNST_PROJ_LONG_MEAS', N'MS_Description', CAST(N'ConstructionProjectLongitudeMeasure' AS nvarchar(35)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_UNPRMT_FAC', N'SECTION_TOWNSHIP_RNG', N'MS_Description', CAST(N'SectionTownshipRange' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_UNPRMT_FAC', N'FAC_CMNTS', N'MS_Description', CAST(N'FacilityComments' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_UNPRMT_FAC', N'FAC_USR_DFND_FLD_1', N'MS_Description', CAST(N'FacilityUserDefinedField1' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_UNPRMT_FAC', N'FAC_USR_DFND_FLD_2', N'MS_Description', CAST(N'FacilityUserDefinedField2' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_UNPRMT_FAC', N'FAC_USR_DFND_FLD_3', N'MS_Description', CAST(N'FacilityUserDefinedField3' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_UNPRMT_FAC', N'FAC_USR_DFND_FLD_4', N'MS_Description', CAST(N'FacilityUserDefinedField4' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_UNPRMT_FAC', N'FAC_USR_DFND_FLD_5', N'MS_Description', CAST(N'FacilityUserDefinedField5' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_UNPRMT_FAC', N'PRMT_CMNTS_TXT', N'MS_Description', CAST(N'PermitCommentsText' AS nvarchar(18)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_INSP', NULL, N'MS_Description', CAST(N'Schema element: PretreatmentInspection' AS nvarchar(38)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_INSP', N'SUO_REF', N'MS_Description', CAST(N'SUOReference' AS nvarchar(12)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_INSP', N'SUO_DATE', N'MS_Description', CAST(N'SUODate' AS nvarchar(7)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_INSP', N'ACCEPTANCE_HAZ_WASTE', N'MS_Description', CAST(N'AcceptanceHazardousWaste' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_INSP', N'ACCEPTANCE_NON_HAZ_INDST_WASTE', N'MS_Description', CAST(N'AcceptanceNonHazardousIndustrialWaste' AS nvarchar(37)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_INSP', N'ACCEPTANCE_HULED_DOMSTIC_WSTES', N'MS_Description', CAST(N'AcceptanceHauledDomesticWastes' AS nvarchar(30)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_INSP', N'ANNUL_PRETR_BUDGET', N'MS_Description', CAST(N'AnnualPretreatmentBudget' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_INSP', N'INADEQUACY_SMPL_INSP_IND', N'MS_Description', CAST(N'InadequacySamplingInspectionIndicator' AS nvarchar(37)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_INSP', N'ADEQUACY_PRETR_RESOURCES', N'MS_Description', CAST(N'AdequacyPretreatmentResources' AS nvarchar(29)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_INSP', N'DFCNC_IDNTFD_DRNG_IU_FILE_RVIW', N'MS_Description', CAST(N'DeficienciesIdentifiedDuringIUFileReview' AS nvarchar(40)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_INSP', N'CONTROL_MECH_DFCNC', N'MS_Description', CAST(N'ControlMechanismDeficiencies' AS nvarchar(28)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_INSP', N'LEGAL_AUTH_DFCNC', N'MS_Description', CAST(N'LegalAuthorityDeficiencies' AS nvarchar(26)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_INSP', N'DFCNC_INTRPRT_APPL_PRETR_STNDR', N'MS_Description', CAST(N'DeficienciesInterpretationApplicationPretreatmentStandards' AS nvarchar(58)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_INSP', N'DFCNC_DAT_MGMT_PBLC_PRTICIPTON', N'MS_Description', CAST(N'DeficienciesDataManagementPublicParticipation' AS nvarchar(45)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_INSP', N'VIOL_IU_SCHD_RMD_MSR', N'MS_Description', CAST(N'ViolationIUScheduleRemedialMeasures' AS nvarchar(35)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_INSP', N'FRML_RSPN_VIOL_IU_SCHD_RMD_MSR', N'MS_Description', CAST(N'FormalResponseViolationIUScheduleRemedialMeasures' AS nvarchar(49)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_INSP', N'ANNUL_FREQ_INFLUNT_TOXCNT_SMPL', N'MS_Description', CAST(N'AnnualFrequencyInfluentToxicantSampling' AS nvarchar(39)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_INSP', N'ANNUL_FREQ_EFFLU_TOXCNT_SMPL', N'MS_Description', CAST(N'AnnualFrequencyEffluentToxicantSampling' AS nvarchar(39)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_INSP', N'ANNUL_FREQ_SLDG_TOXCNT_SMPL', N'MS_Description', CAST(N'AnnualFrequencySludgeToxicantSampling' AS nvarchar(37)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_INSP', N'NUM_SI_US', N'MS_Description', CAST(N'NumberSIUs' AS nvarchar(10)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_INSP', N'SI_US_WITHOUT_CONTROL_MECH', N'MS_Description', CAST(N'SIUsWithoutControlMechanism' AS nvarchar(27)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_INSP', N'SI_US_NOT_INSPECTED', N'MS_Description', CAST(N'SIUsNotInspected' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_INSP', N'SI_US_NOT_SMPL', N'MS_Description', CAST(N'SIUsNotSampled' AS nvarchar(14)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_INSP', N'SI_US_ON_SCHD', N'MS_Description', CAST(N'SIUsOnSchedule' AS nvarchar(14)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_INSP', N'SI_US_SNC_WITH_PRETR_STNDR', N'MS_Description', CAST(N'SIUsSNCWithPretreatmentStandards' AS nvarchar(32)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_INSP', N'SI_US_SNC_WITH_REP_REQS', N'MS_Description', CAST(N'SIUsSNCWithReportingRequirements' AS nvarchar(32)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_INSP', N'SI_US_SNC_WITH_PRETR_SCHD', N'MS_Description', CAST(N'SIUsSNCWithPretreatmentSchedule' AS nvarchar(31)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_INSP', N'SI_US_SNC_PUBL_NEWSPAPER', N'MS_Description', CAST(N'SIUsSNCPublishedNewspaper' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_INSP', N'VIOL_NOTICES_ISSUED_SI_US', N'MS_Description', CAST(N'ViolationNoticesIssuedSIUs' AS nvarchar(26)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_INSP', N'ADMIN_ORDERS_ISSUED_SI_US', N'MS_Description', CAST(N'AdministrativeOrdersIssuedSIUs' AS nvarchar(30)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_INSP', N'CIVIL_SUTS_FILD_AGINST_SI_US', N'MS_Description', CAST(N'CivilSuitsFiledAgainstSIUs' AS nvarchar(26)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_INSP', N'CRIMINL_SUTS_FILD_AGINST_SI_US', N'MS_Description', CAST(N'CriminalSuitsFiledAgainstSIUs' AS nvarchar(29)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_INSP', N'DOLLAR_AMT_PNLTY_COLL', N'MS_Description', CAST(N'DollarAmountPenaltiesCollected' AS nvarchar(30)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_INSP', N'I_US_WHC_PNLTY_HAV_BEE_COLL', N'MS_Description', CAST(N'IUsWhichPenaltiesHaveBeenCollected' AS nvarchar(34)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_INSP', N'NUM_CI_US', N'MS_Description', CAST(N'NumberCIUs' AS nvarchar(10)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_INSP', N'CI_US_IN_SNC', N'MS_Description', CAST(N'CIUsInSNC' AS nvarchar(9)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_INSP', N'PASS_THROUGH_INTERFERENCE_IND', N'MS_Description', CAST(N'PassThroughInterferenceIndicator' AS nvarchar(32)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_INSP_VIOL_TYPE', NULL, N'MS_Description', CAST(N'Schema element: String' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_INSP_VIOL_TYPE', N'CAFO_INSP_VIOL_TYPE_CODE', N'MS_Description', CAST(N'CAFOInspectionViolationTypeCode' AS nvarchar(31)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_INSP_CMNT_TXT', NULL, N'MS_Description', CAST(N'Schema element: String' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_INSP_CMNT_TXT', N'INSP_CMNT_TXT', N'MS_Description', CAST(N'InspectionCommentText' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_VECTOR_A_REDUCTION_TYPE', NULL, N'MS_Description', CAST(N'Schema element: String' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_VECTOR_A_REDUCTION_TYPE', N'VECTOR_A_REDUCTION_TYPE_CODE', N'MS_Description', CAST(N'VectorAttractionReductionTypeCode' AS nvarchar(33)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_PRMT', NULL, N'MS_Description', CAST(N'Schema element: PretreatmentPermitData' AS nvarchar(38)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_PRMT', N'SRC_SYSTM_IDENT', N'MS_Description', CAST(N'SourceSystemIdentifier' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_PRMT', N'TRANSACTION_TYPE', N'MS_Description', CAST(N'TransactionType' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_PRMT', N'TRANSACTION_TIMESTAMP', N'MS_Description', CAST(N'TransactionTimestamp' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_PRMT', N'PRMT_IDENT', N'MS_Description', CAST(N'PermitIdentifier' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_PRMT', N'PRETR_PROG_REQD_IND_CODE', N'MS_Description', CAST(N'PretreatmentProgramRequiredIndicatorCode' AS nvarchar(40)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_PRMT', N'CONTROL_AUTH_ST_AGNCY_CODE', N'MS_Description', CAST(N'ControlAuthorityStateAgencyCode' AS nvarchar(31)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_PRMT', N'CONTROL_AUTH_RGNL_AGNCY_CODE', N'MS_Description', CAST(N'ControlAuthorityRegionalAgencyCode' AS nvarchar(34)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_PRMT', N'CONTROL_AUTH_NPDES_IDENT', N'MS_Description', CAST(N'ControlAuthorityNPDESIdentifier' AS nvarchar(31)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_PRMT', N'PRETR_PROG_APRVD_DATE', N'MS_Description', CAST(N'PretreatmentProgramApprovedDate' AS nvarchar(31)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_PRMT', N'RCVG_RCRA_WASTE_IND', N'MS_Description', CAST(N'ReceivingRCRAWasteIndicator' AS nvarchar(27)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_PRMT', N'RCVG_REMEDIATION_WASTE_IND', N'MS_Description', CAST(N'ReceivingRemediationWasteIndicator' AS nvarchar(34)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_LAND_APPL_FLD_INFO', NULL, N'MS_Description', CAST(N'Schema element: CAFOLandApplicationFieldInformation' AS nvarchar(51)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_LAND_APPL_FLD_INFO', N'CAFO_LAND_APPL_FLD_IDENT', N'MS_Description', CAST(N'CAFOLandApplicationFieldIdentifier' AS nvarchar(34)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_LAND_APPL_FLD_INFO', N'CAFO_LAND_APPL_FLD_ACREAGE', N'MS_Description', CAST(N'CAFOLandApplicationFieldAcreage' AS nvarchar(31)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_LAND_APPL_FLD_INFO', N'CAFOMLPW_MAX_AMT_METHOD', N'MS_Description', CAST(N'CAFOMLPWMaximumAmountMethod' AS nvarchar(27)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_LAND_APPL_FLD_INFO', N'CAFO_LAND_APPL_FLD_CROP_IDENT', N'MS_Description', CAST(N'CAFOLandApplicationFieldCropIdentifier' AS nvarchar(38)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_LAND_APPL_FLD_INFO', N'CAFO_LAND_APPL_FLD_CROP_CODE', N'MS_Description', CAST(N'CAFOLandApplicationFieldCropCode' AS nvarchar(32)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_LAND_APPL_FLD_INFO', N'CAFO_LAND_APPL_FLD_CROP_YIELD', N'MS_Description', CAST(N'CAFOLandApplicationFieldCropYield' AS nvarchar(33)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_LAND_APPL_FLD_INFO', N'CAFO_LAND_APPL_FLD_CROP_YIELD_UNIT', N'MS_Description', CAST(N'CAFOLandApplicationFieldCropYieldUnit' AS nvarchar(37)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_LAND_APPL_FLD_INFO', N'CAFO_LAND_APPL_FLD_CROP_SEEDED', N'MS_Description', CAST(N'CAFOLandApplicationFieldCropSeeded' AS nvarchar(34)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_LAND_APPL_FLD_INFO', N'CAFO_SOIL_MON_MEAS_FORM', N'MS_Description', CAST(N'CAFOSoilMonitoringMeasurementForm' AS nvarchar(33)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_LAND_APPL_FLD_INFO', N'CAFO_SOIL_MON_MEAS_VALUE', N'MS_Description', CAST(N'CAFOSoilMonitoringMeasurementValue' AS nvarchar(34)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_LAND_APPL_FLD_INFO', N'CAFO_SOIL_MON_MEAS_VALUE_UNIT', N'MS_Description', CAST(N'CAFOSoilMonitoringMeasurementValueUnit' AS nvarchar(38)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_LAND_APPL_FLD_INFO', N'CAFO_SOIL_MON_ANLYTCL_METHOD', N'MS_Description', CAST(N'CAFOSoilMonitoringAnalyticalMethod' AS nvarchar(34)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_LAND_APPL_FLD_INFO', N'CAFO_SOIL_MON_SMPL_DEPTH_INCHES', N'MS_Description', CAST(N'CAFOSoilMonitoringSampleDepthInches' AS nvarchar(35)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_LAND_APPL_FLD_INFO', N'CAFO_SOIL_MON_SMPL_DATE', N'MS_Description', CAST(N'CAFOSoilMonitoringSampleDate' AS nvarchar(28)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_LAND_APPL_FLD_INFO', N'CAFO_SUPPL_FERTILIZER_MEAS_FORM', N'MS_Description', CAST(N'CAFOSupplementalFertilizerMeasurementForm' AS nvarchar(41)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_LAND_APPL_FLD_INFO', N'CAFO_SUPPL_FERTILIZER_MEAS_VALUE', N'MS_Description', CAST(N'CAFOSupplementalFertilizerMeasurementValue' AS nvarchar(42)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_LAND_APPL_FLD_INFO', N'CAFO_SUPPL_FERTILIZER_MEAS_VALUE_UNIT', N'MS_Description', CAST(N'CAFOSupplementalFertilizerMeasurementValueUnit' AS nvarchar(46)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_INSP_GOV_CONTACT', NULL, N'MS_Description', CAST(N'Schema element: InspectionGovernmentContact' AS nvarchar(43)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_INSP_GOV_CONTACT', N'AFFIL_TYPE_TXT', N'MS_Description', CAST(N'AffiliationTypeText' AS nvarchar(19)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_INSP_GOV_CONTACT', N'ELEC_ADDR_TXT', N'MS_Description', CAST(N'ElectronicAddressText' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_PROG_MOD', NULL, N'MS_Description', CAST(N'Schema element: PretreatmentProgramModification' AS nvarchar(47)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_PROG_MOD', N'PRETR_PROG_MOD_TYPE', N'MS_Description', CAST(N'PretreatmentProgramModificationType' AS nvarchar(35)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_PROG_MOD', N'PRETR_PROG_MOD_DATE', N'MS_Description', CAST(N'PretreatmentProgramModificationDate' AS nvarchar(35)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_PROG_MOD', N'PRETR_PROG_MOD_TXT', N'MS_Description', CAST(N'PretreatmentProgramModificationText' AS nvarchar(35)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_PRMT', NULL, N'MS_Description', CAST(N'Schema element: CAFOPermitData' AS nvarchar(30)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_PRMT', N'SRC_SYSTM_IDENT', N'MS_Description', CAST(N'SourceSystemIdentifier' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_PRMT', N'TRANSACTION_TYPE', N'MS_Description', CAST(N'TransactionType' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_PRMT', N'TRANSACTION_TIMESTAMP', N'MS_Description', CAST(N'TransactionTimestamp' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_PRMT', N'PRMT_IDENT', N'MS_Description', CAST(N'PermitIdentifier' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_PRMT', N'CAFO_CLASS_CODE', N'MS_Description', CAST(N'CAFOClassificationCode' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_PRMT', N'IS_ANML_FAC_TYPE_CAFO_IND', N'MS_Description', CAST(N'IsAnimalFacilityTypeCAFOIndicator' AS nvarchar(33)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_PRMT', N'CAFO_DESGN_DATE', N'MS_Description', CAST(N'CAFODesignationDate' AS nvarchar(19)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_PRMT', N'CAFO_DESGN_REASON_TXT', N'MS_Description', CAST(N'CAFODesignationReasonText' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_PRMT', N'NUM_ACRES_CONTRB_DRAIN', N'MS_Description', CAST(N'NumberAcresContributingDrainage' AS nvarchar(31)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_PRMT', N'APPL_MEAS_AVAIL_LAND_NUM', N'MS_Description', CAST(N'ApplicationMeasureAvailableLandNumber' AS nvarchar(37)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_PRMT', N'SOLID_MNUR_LTTR_GNRTD_AMT', N'MS_Description', CAST(N'SolidManureLitterGeneratedAmount' AS nvarchar(32)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_PRMT', N'LIQUID_MNUR_WW_GNRTD_AMT', N'MS_Description', CAST(N'LiquidManureWastewaterGeneratedAmount' AS nvarchar(37)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_PRMT', N'SOLID_MNUR_LTTR_TRANS_AMT', N'MS_Description', CAST(N'SolidManureLitterTransferAmount' AS nvarchar(31)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_PRMT', N'LIQUID_MNUR_WW_TRANS_AMT', N'MS_Description', CAST(N'LiquidManureWastewaterTransferAmount' AS nvarchar(36)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_PRMT', N'NMP_DVLPD_CERT_PLNR_APRVD_IND', N'MS_Description', CAST(N'NMPDevelopedCertifiedPlannerApprovedIndicator' AS nvarchar(45)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_PRMT', N'NMP_DVLPD_DATE', N'MS_Description', CAST(N'NMPDevelopedDate' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_PRMT', N'NMP_LAST_UPDATED_DATE', N'MS_Description', CAST(N'NMPLastUpdatedDate' AS nvarchar(18)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_PRMT', N'ENVR_MGMT_SYSTM_IND', N'MS_Description', CAST(N'EnvironmentalManagementSystemIndicator' AS nvarchar(38)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_PRMT', N'EMS_DVLPD_DATE', N'MS_Description', CAST(N'EMSDevelopedDate' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_PRMT', N'EMS_LAST_UPDATED_DATE', N'MS_Description', CAST(N'EMSLastUpdatedDate' AS nvarchar(18)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_PRMT', N'LVSTCK_MAX_CPCTY_NUM', N'MS_Description', CAST(N'LivestockMaximumCapacityNumber' AS nvarchar(30)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_PRMT', N'LVSTCK_CPCTY_DTRMN_BS_UPON_NUM', N'MS_Description', CAST(N'LivestockCapacityDeterminationBasedUponNumber' AS nvarchar(45)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_PRMT', N'AUTH_LVSTCK_CPCTY_NUM', N'MS_Description', CAST(N'AuthorizedLivestockCapacityNumber' AS nvarchar(33)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_PRMT', N'LEGAL_DESC_TXT', N'MS_Description', CAST(N'LegalDescriptionText' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_IU_ENF_ACTN_TYPES', NULL, N'MS_Description', CAST(N'Schema element: IUEnfActionTypes' AS nvarchar(32)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_IU_ENF_ACTN_TYPES', N'IU_ENF_ACTN_TYPE_CODE', N'MS_Description', CAST(N'IUEnfActionTypeCode' AS nvarchar(19)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_IU_ENF_ACTN_TYPES', N'IU_ENF_ACTN_TYPE_OTHR_TXT', N'MS_Description', CAST(N'IUEnfActionTypeOtherText' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_IU_ENF_ACTN_TYPES', N'NUM_IU_ENF_ACTIONS', N'MS_Description', CAST(N'NumIUEnfActions' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_PROG_REP', NULL, N'MS_Description', CAST(N'Schema element: PretreatmentProgramReportData' AS nvarchar(45)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_PROG_REP', N'SRC_SYSTM_IDENT', N'MS_Description', CAST(N'SourceSystemIdentifier' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_PROG_REP', N'TRANSACTION_TYPE', N'MS_Description', CAST(N'TransactionType' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_PROG_REP', N'TRANSACTION_TIMESTAMP', N'MS_Description', CAST(N'TransactionTimestamp' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_PROG_REP', N'PRMT_IDENT', N'MS_Description', CAST(N'PermitIdentifier' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_PROG_REP', N'PROG_REP_FORM_SET_ID', N'MS_Description', CAST(N'ProgramReportFormSetID' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_PROG_REP', N'PROG_REP_FORM_ID', N'MS_Description', CAST(N'ProgramReportFormID' AS nvarchar(19)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_PROG_REP', N'PROG_REP_RCVD_DATE', N'MS_Description', CAST(N'ProgramReportReceivedDate' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_PROG_REP', N'PROG_REP_START_DATE', N'MS_Description', CAST(N'ProgramReportStartDate' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_PROG_REP', N'PROG_REP_END_DATE', N'MS_Description', CAST(N'ProgramReportEndDate' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_PROG_REP', N'ELEC_SUBM_TYPE_CODE', N'MS_Description', CAST(N'ElectronicSubmissionTypeCode' AS nvarchar(28)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRETR_PROG_REP', N'PROG_REP_NPDES_DAT_GRP_NUM_CODE', N'MS_Description', CAST(N'ProgramReportNPDESDataGroupNumberCode' AS nvarchar(37)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_PROD_AREA_DSCH', NULL, N'MS_Description', CAST(N'Schema element: CAFOProductionAreaDischarge' AS nvarchar(43)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_PROD_AREA_DSCH', N'CAFO_PROD_AREA_DSCH_DISCOVERY_DATE', N'MS_Description', CAST(N'CAFOProductionAreaDischargeDiscoveryDate' AS nvarchar(40)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_PROD_AREA_DSCH', N'CAFO_PROD_AREA_DSCH_24HR_RAIN_EVT_IND', N'MS_Description', CAST(N'CAFOProductionAreaDischarge24hrRainEventIndicator' AS nvarchar(49)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_PROD_AREA_DSCH', N'CAFO_PROD_AREA_DSCH_DURATION_HOURS', N'MS_Description', CAST(N'CAFOProductionAreaDischargeDurationHours' AS nvarchar(40)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFO_PROD_AREA_DSCH', N'CAFO_PROD_AREA_DSCH_VOL_GAL', N'MS_Description', CAST(N'CAFOProductionAreaDischargeVolumeGallons' AS nvarchar(40)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_IU_ENFRC_ACTN_INFO', NULL, N'MS_Description', CAST(N'Schema element: IUEnforcementActionInformation' AS nvarchar(46)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_IU_ENFRC_ACTN_INFO', N'SNC_PRETR_ENF_CMPL_SCHED_STAT_IND', N'MS_Description', CAST(N'SNCPretrEnfCmplSchedStatusIndicator' AS nvarchar(35)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_IU_ENFRC_ACTN_INFO', N'IU_CASH_CIVIL_PNLTY_AMT_ASSESSED', N'MS_Description', CAST(N'IUCashCivilPenaltyAmountAssessed' AS nvarchar(32)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_IU_ENFRC_ACTN_INFO', N'IU_CASH_CIVIL_PNLTY_AMT_COLL', N'MS_Description', CAST(N'IUCashCivilPenaltyAmountCollected' AS nvarchar(33)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_BS_MGMT_PRACTICE', NULL, N'MS_Description', CAST(N'Schema element: PermitBiosolidsManagementPracticeData' AS nvarchar(53)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_BS_MGMT_PRACTICE', N'SSU_IDENT', N'MS_Description', CAST(N'SSUIdentifier' AS nvarchar(13)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_BS_MGMT_PRACTICE', N'BS_MGMT_PRACTICE_CODE', N'MS_Description', CAST(N'BiosolidsManagementPracticeCode' AS nvarchar(31)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_BS_MGMT_PRACTICE', N'BS_MGMT_PRACTICE_SUB_CATG_CODE', N'MS_Description', CAST(N'BiosolidsManagementPracticeSubCategoryCode' AS nvarchar(42)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_BS_MGMT_PRACTICE', N'BS_MGMT_PRACTICE_SUB_CATG_TXT', N'MS_Description', CAST(N'BiosolidsManagementPracticeSubCategoryText' AS nvarchar(42)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_BS_MGMT_PRACTICE', N'BS_OPERATOR_TYPE_CODE', N'MS_Description', CAST(N'BiosolidsOperatorTypeCode' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_BS_MGMT_PRACTICE', N'BS_CNTNR_TYPE_CODE', N'MS_Description', CAST(N'BiosolidsContainerTypeCode' AS nvarchar(26)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_BS_MGMT_PRACTICE', N'SSUID_VOL_AMT', N'MS_Description', CAST(N'SSUIDVolumeAmount' AS nvarchar(17)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_BS_MGMT_PRACTICE', N'PATHOGEN_CLASS_TYPE_CODE', N'MS_Description', CAST(N'PathogenClassTypeCode' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_BS_MGMT_PRACTICE', N'POLUT_LOADING_RATES_EXCEEDANCE_IND', N'MS_Description', CAST(N'PollutantLoadingRatesExceedanceIndicator' AS nvarchar(40)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_BS_MGMT_PRACTICE', N'SURF_DSPL_WITHOUT_LINER_IND', N'MS_Description', CAST(N'SurfaceDisposalWithoutLinerIndicator' AS nvarchar(36)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_BS_MGMT_PRACTICE', N'SURF_DSPL_SITE_SPEC_LMT_IND', N'MS_Description', CAST(N'SurfaceDisposalSiteSpecificLimitIndicator' AS nvarchar(41)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_BS_MGMT_PRACTICE', N'SURF_DSPL_MIN_BOUNDARY_DISTANCE_CODE', N'MS_Description', CAST(N'SurfaceDisposalMinimumBoundaryDistanceCode' AS nvarchar(42)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_BS_MGMT_PRACTICE', N'BS_OFF_SITE_FAC_PRMT_IDENT', N'MS_Description', CAST(N'BiosolidsOffSiteFacilityPermitIdentifier' AS nvarchar(40)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFOMLPW_FLD_AMOUNTS', NULL, N'MS_Description', CAST(N'Schema element: CAFOMLPWFieldAmounts' AS nvarchar(36)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFOMLPW_FLD_AMOUNTS', N'CAFOMLPW_CODE', N'MS_Description', CAST(N'CAFOMLPWCode' AS nvarchar(12)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFOMLPW_FLD_AMOUNTS', N'CAFOMLPW_FLD_MAX_ALLOWABLE_AMT', N'MS_Description', CAST(N'CAFOMLPWFieldMaxAllowableAmount' AS nvarchar(31)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFOMLPW_FLD_AMOUNTS', N'CAFOMLPW_FLD_ACTUL_AMT', N'MS_Description', CAST(N'CAFOMLPWFieldActualAmount' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFOMLPW_FLD_AMOUNTS', N'CAFOMLPW_LAND_APPL_UNIT', N'MS_Description', CAST(N'CAFOMLPWLandApplicationUnit' AS nvarchar(27)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_IU_VIOL_INFO', NULL, N'MS_Description', CAST(N'Schema element: IUViolationInformation' AS nvarchar(38)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_IU_VIOL_INFO', N'SNC_PRETR_STND_LMTS_IND', N'MS_Description', CAST(N'SNCPretrStndLimitsIndicator' AS nvarchar(27)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_IU_VIOL_INFO', N'SNC_RPT_RQMT_IND', N'MS_Description', CAST(N'SNCRptRqmtIndicator' AS nvarchar(19)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_IU_VIOL_INFO', N'SNC_OTH_CTRL_MECH_RQMT_IND', N'MS_Description', CAST(N'SNCOthCtrlMechRqmtIndicator' AS nvarchar(27)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_IU_VIOL_INFO', N'SNC_REL_POTW_DISCH_OPER_IND', N'MS_Description', CAST(N'SNCRelPOTWDischOperIndicator' AS nvarchar(28)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_IU_VIOL_INFO', N'SNC_REL_POTW_DISCH_OPER_TXT', N'MS_Description', CAST(N'SNCRelPOTWDischOperText' AS nvarchar(23)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_IU_VIOL_INFO', N'SNC_REL_POTW_BIO_OPER_SEWG_SLUD_MGMT_IND', N'MS_Description', CAST(N'SNCRelPOTWBioOperSewgSludMgmtIndicator' AS nvarchar(38)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_IU_VIOL_INFO', N'SNC_REL_POTW_BIO_OPER_SEWG_SLUD_MGMT_TXT', N'MS_Description', CAST(N'SNCRelPOTWBioOperSewgSludMgmtText' AS nvarchar(33)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_IU_VIOL_INFO', N'SNC_PUBL_IND', N'MS_Description', CAST(N'SNCPublishedIndicator' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_COMP_TYPE', NULL, N'MS_Description', CAST(N'Schema element: String' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_COMP_TYPE', N'PRMT_COMP_TYPE_CODE', N'MS_Description', CAST(N'PermitComponentTypeCode' AS nvarchar(23)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFOMLPW_NUTR_MON', NULL, N'MS_Description', CAST(N'Schema element: CAFOMLPWNutrientMonitoring' AS nvarchar(42)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFOMLPW_NUTR_MON', N'CAFOMLPW_CODE', N'MS_Description', CAST(N'CAFOMLPWCode' AS nvarchar(12)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFOMLPW_NUTR_MON', N'CAFOMLPW_NUTR_FORM', N'MS_Description', CAST(N'CAFOMLPWNutrientForm' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFOMLPW_NUTR_MON', N'CAFOMLPW_NUTR_VALUE', N'MS_Description', CAST(N'CAFOMLPWNutrientValue' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFOMLPW_NUTR_MON', N'CAFOMLPW_NUTR_VALUE_UNIT', N'MS_Description', CAST(N'CAFOMLPWNutrientValueUnit' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_FEATR', NULL, N'MS_Description', CAST(N'Schema element: PermittedFeatureData' AS nvarchar(36)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_FEATR', N'SRC_SYSTM_IDENT', N'MS_Description', CAST(N'SourceSystemIdentifier' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_FEATR', N'TRANSACTION_TYPE', N'MS_Description', CAST(N'TransactionType' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_FEATR', N'TRANSACTION_TIMESTAMP', N'MS_Description', CAST(N'TransactionTimestamp' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_FEATR', N'PRMT_IDENT', N'MS_Description', CAST(N'PermitIdentifier' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_FEATR', N'PRMT_FEATR_IDENT', N'MS_Description', CAST(N'PermittedFeatureIdentifier' AS nvarchar(26)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_FEATR', N'PRMT_FEATR_TYPE_CODE', N'MS_Description', CAST(N'PermittedFeatureTypeCode' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_FEATR', N'PRMT_FEATR_DESC', N'MS_Description', CAST(N'PermittedFeatureDescription' AS nvarchar(27)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_FEATR', N'PRMT_FEATR_DSGN_FLOW_NUM', N'MS_Description', CAST(N'PermittedFeatureDesignFlowNumber' AS nvarchar(32)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_FEATR', N'PRMT_FEATR_ACTUL_AVER_FLOW_NUM', N'MS_Description', CAST(N'PermittedFeatureActualAverageFlowNumber' AS nvarchar(39)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_FEATR', N'PRMT_FEATR_ST_WTR_BODY_CODE', N'MS_Description', CAST(N'PermittedFeatureStateWaterBodyCode' AS nvarchar(34)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_FEATR', N'PRMT_FEATR_ST_WTR_BODY_NAME', N'MS_Description', CAST(N'PermittedFeatureStateWaterBodyName' AS nvarchar(34)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_FEATR', N'TIER_LEVEL_NAME', N'MS_Description', CAST(N'TierLevelName' AS nvarchar(13)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_FEATR', N'IMPAIRED_WTR_IND', N'MS_Description', CAST(N'ImpairedWaterIndicator' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_FEATR', N'TMDL_COMPLETED_IND', N'MS_Description', CAST(N'TMDLCompletedIndicator' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_FEATR', N'PRMT_FEATR_USR_DFND_DAT_ELM_1', N'MS_Description', CAST(N'PermittedFeatureUserDefinedDataElement1' AS nvarchar(39)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_FEATR', N'PRMT_FEATR_USR_DFND_DAT_ELM_2', N'MS_Description', CAST(N'PermittedFeatureUserDefinedDataElement2' AS nvarchar(39)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_FEATR', N'FLD_SIZE', N'MS_Description', CAST(N'FieldSize' AS nvarchar(9)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_FEATR', N'IS_SITE_OWN_BY_FAC', N'MS_Description', CAST(N'IsSiteOwnByFacility' AS nvarchar(19)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_FEATR', N'IS_SYSTM_LINED_WITH_LEACHATE', N'MS_Description', CAST(N'IsSystemLinedWithLeachate' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_FEATR', N'DOES_UNIT_HAV_DAILY_COVER', N'MS_Description', CAST(N'DoesUnitHaveDailyCover' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_FEATR', N'PROP_BOUNDARY_DISTANCE', N'MS_Description', CAST(N'PropertyBoundaryDistance' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_FEATR', N'IS_REQD_NITRATE_GROUND_WTR', N'MS_Description', CAST(N'IsRequiredNitrateGroundWater' AS nvarchar(28)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_FEATR', N'WELL_NUM', N'MS_Description', CAST(N'WellNumber' AS nvarchar(10)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_FEATR', N'SRC_PRMT_FEATR_DETAIL_TXT', N'MS_Description', CAST(N'SourcePermittedFeatureDetailText' AS nvarchar(32)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LAND_APPL_BMP', NULL, N'MS_Description', CAST(N'Schema element: LandApplicationBMP' AS nvarchar(34)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LAND_APPL_BMP', N'LAND_APPL_BMP_TYPE_CODE', N'MS_Description', CAST(N'LandApplicationBMPTypeCode' AS nvarchar(26)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LAND_APPL_BMP', N'OTHR_LAND_APPL_BMP_TYPE_NAME', N'MS_Description', CAST(N'OtherLandApplicationBMPTypeName' AS nvarchar(31)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFOMLPW_TTL_AMOUNTS', NULL, N'MS_Description', CAST(N'Schema element: CAFOMLPWTotalAmounts' AS nvarchar(36)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFOMLPW_TTL_AMOUNTS', N'CAFOMLPW_CODE', N'MS_Description', CAST(N'CAFOMLPWCode' AS nvarchar(12)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFOMLPW_TTL_AMOUNTS', N'CAFOMLPW_AMT_GNRTD', N'MS_Description', CAST(N'CAFOMLPWAmountGenerated' AS nvarchar(23)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFOMLPW_TTL_AMOUNTS', N'CAFOMLPW_AMT_TRANSFERRED', N'MS_Description', CAST(N'CAFOMLPWAmountTransferred' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CAFOMLPW_TTL_AMOUNTS', N'CAFOMLPW_UNIT', N'MS_Description', CAST(N'CAFOMLPWUnit' AS nvarchar(12)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_FEATR_CHAR', NULL, N'MS_Description', CAST(N'Schema element: String' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_FEATR_CHAR', N'PRMT_FEATR_CHAR', N'MS_Description', CAST(N'PermittedFeatureCharacteristics' AS nvarchar(31)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LAND_APPL_SITE', NULL, N'MS_Description', CAST(N'Schema element: LandApplicationSite' AS nvarchar(35)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LAND_APPL_SITE', N'POLUT_MET_FOR_LAND_APPL', N'MS_Description', CAST(N'PollutantMetForLandApplication' AS nvarchar(30)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LAND_APPL_SITE', N'PATHOGEN_REDUCTION_IND', N'MS_Description', CAST(N'PathogenReductionIndicator' AS nvarchar(26)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LAND_APPL_SITE', N'VECTOR_REDUCTION_IND', N'MS_Description', CAST(N'VectorReductionIndicator' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LAND_APPL_SITE', N'AGRONOMIC_GAL_RATE_FOR_FLD', N'MS_Description', CAST(N'AgronomicGallonsRateForField' AS nvarchar(28)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LAND_APPL_SITE', N'AGRONOMIC_DMT_RATE_FOR_FLD', N'MS_Description', CAST(N'AgronomicDMTRateForField' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LAND_APPL_SITE', N'CLASS_A_ALT_USED', N'MS_Description', CAST(N'ClassAAlternativeUsed' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LAND_APPL_SITE', N'CLASS_A_ALTS_TXT', N'MS_Description', CAST(N'ClassAAlternativesText' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LAND_APPL_SITE', N'CLASS_B_ALT_USED', N'MS_Description', CAST(N'ClassBAlternativeUsed' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LAND_APPL_SITE', N'CLASS_B_ALTS_TXT', N'MS_Description', CAST(N'ClassBAlternativesText' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LAND_APPL_SITE', N'VAR_ALT_USED', N'MS_Description', CAST(N'VARAlternativeUsed' AS nvarchar(18)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LAND_APPL_SITE', N'VAR_ALTS_TXT', N'MS_Description', CAST(N'VARAlternativesText' AS nvarchar(19)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_INSP_TYPE', NULL, N'MS_Description', CAST(N'Schema element: String' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_INSP_TYPE', N'CMPL_INSP_TYPE_CODE', N'MS_Description', CAST(N'ComplianceInspectionTypeCode' AS nvarchar(28)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_FEATR_TRTMNT_TYPE', NULL, N'MS_Description', CAST(N'Schema element: String' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_FEATR_TRTMNT_TYPE', N'PRMT_FEATR_TRTMNT_TYPE_CODE', N'MS_Description', CAST(N'PermittedFeatureTreatmentTypeCode' AS nvarchar(33)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMT', NULL, N'MS_Description', CAST(N'Schema element: Limit' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMT', N'LMT_START_DATE', N'MS_Description', CAST(N'LimitStartDate' AS nvarchar(14)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMT', N'LMT_END_DATE', N'MS_Description', CAST(N'LimitEndDate' AS nvarchar(12)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMT', N'LMT_TYPE_CODE', N'MS_Description', CAST(N'LimitTypeCode' AS nvarchar(13)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMT', N'SMPL_TYPE_TXT', N'MS_Description', CAST(N'SampleTypeText' AS nvarchar(14)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMT', N'FREQ_OF_ANALYSIS_CODE', N'MS_Description', CAST(N'FrequencyOfAnalysisCode' AS nvarchar(23)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMT', N'ELIGIBLE_FOR_BURDEN_REDUCTION', N'MS_Description', CAST(N'EligibleForBurdenReduction' AS nvarchar(26)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMT', N'LMT_STAY_TYPE_CODE', N'MS_Description', CAST(N'LimitStayTypeCode' AS nvarchar(17)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMT', N'STAY_START_DATE', N'MS_Description', CAST(N'StayStartDate' AS nvarchar(13)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMT', N'STAY_END_DATE', N'MS_Description', CAST(N'StayEndDate' AS nvarchar(11)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMT', N'STAY_REASON_TXT', N'MS_Description', CAST(N'StayReasonText' AS nvarchar(14)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMT', N'CALCULATE_VIOL_IND', N'MS_Description', CAST(N'CalculateViolationsIndicator' AS nvarchar(28)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMT', N'ENFRC_ACTN_IDENT', N'MS_Description', CAST(N'EnforcementActionIdentifier' AS nvarchar(27)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMT', N'FINAL_ORDER_IDENT', N'MS_Description', CAST(N'FinalOrderIdentifier' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMT', N'BASIS_OF_LMT', N'MS_Description', CAST(N'BasisOfLimit' AS nvarchar(12)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMT', N'LMT_MOD_TYPE_CODE', N'MS_Description', CAST(N'LimitModificationTypeCode' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMT', N'LMT_MOD_EFFECTIVE_DATE', N'MS_Description', CAST(N'LimitModificationEffectiveDate' AS nvarchar(30)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMT', N'LMT_MOD_TYPE_STAY_REASON_TXT', N'MS_Description', CAST(N'LimitModificationTypeStayReasonText' AS nvarchar(35)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMT', N'LMTS_USR_DFND_FLD_1', N'MS_Description', CAST(N'LimitsUserDefinedField1' AS nvarchar(23)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMT', N'LMTS_USR_DFND_FLD_2', N'MS_Description', CAST(N'LimitsUserDefinedField2' AS nvarchar(23)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMT', N'LMTS_USR_DFND_FLD_3', N'MS_Description', CAST(N'LimitsUserDefinedField3' AS nvarchar(23)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMT', N'CONCEN_NUM_COND_UNIT_MEAS_CODE', N'MS_Description', CAST(N'ConcentrationNumericConditionUnitMeasureCode' AS nvarchar(44)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMT', N'QTY_NUM_COND_UNIT_MEAS_CODE', N'MS_Description', CAST(N'QuantityNumericConditionUnitMeasureCode' AS nvarchar(39)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_MON', NULL, N'MS_Description', CAST(N'Schema element: ComplianceMonitoringData' AS nvarchar(40)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_MON', N'SRC_SYSTM_IDENT', N'MS_Description', CAST(N'SourceSystemIdentifier' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_MON', N'TRANSACTION_TYPE', N'MS_Description', CAST(N'TransactionType' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_MON', N'TRANSACTION_TIMESTAMP', N'MS_Description', CAST(N'TransactionTimestamp' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_MON', N'CMPL_MON_IDENT', N'MS_Description', CAST(N'ComplianceMonitoringIdentifier' AS nvarchar(30)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_MON', N'PRMT_IDENT', N'MS_Description', CAST(N'PermitIdentifier' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_MON', N'CMPL_MON_ACTY_TYPE_CODE', N'MS_Description', CAST(N'ComplianceMonitoringActivityTypeCode' AS nvarchar(36)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_MON', N'CMPL_MON_CATG_CODE', N'MS_Description', CAST(N'ComplianceMonitoringCategoryCode' AS nvarchar(32)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_MON', N'CMPL_MON_DATE', N'MS_Description', CAST(N'ComplianceMonitoringDate' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_MON', N'CMPL_MON_START_DATE', N'MS_Description', CAST(N'ComplianceMonitoringStartDate' AS nvarchar(29)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_MON', N'CMPL_MON_ACTY_NAME', N'MS_Description', CAST(N'ComplianceMonitoringActivityName' AS nvarchar(32)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_MON', N'BIOMON_INSP_METHOD', N'MS_Description', CAST(N'BiomonitoringInspectionMethod' AS nvarchar(29)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_MON', N'CMPL_MON_AGNCY_CODE', N'MS_Description', CAST(N'ComplianceMonitoringAgencyCode' AS nvarchar(30)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_MON', N'ST_STATUTE_VIOL_NAME', N'MS_Description', CAST(N'StateStatuteViolatedName' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_MON', N'EPA_ASSIST_IND', N'MS_Description', CAST(N'EPAAssistanceIndicator' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_MON', N'ST_FEDR_JOINT_IND', N'MS_Description', CAST(N'StateFederalJointIndicator' AS nvarchar(26)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_MON', N'JOINT_INSP_REASON_CODE', N'MS_Description', CAST(N'JointInspectionReasonCode' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_MON', N'LEAD_PARTY', N'MS_Description', CAST(N'LeadParty' AS nvarchar(9)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_MON', N'NUM_DAYS_PHYS_COND_ACTY', N'MS_Description', CAST(N'NumberDaysPhysicallyConductingActivity' AS nvarchar(38)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_MON', N'NUM_HOURS_PHYS_COND_ACTY', N'MS_Description', CAST(N'NumberHoursPhysicallyConductingActivity' AS nvarchar(39)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_MON', N'CMPL_MON_ACTN_OUTCOME_CODE', N'MS_Description', CAST(N'ComplianceMonitoringActionOutcomeCode' AS nvarchar(37)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_MON', N'INSP_RATING_CODE', N'MS_Description', CAST(N'InspectionRatingCode' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_MON', N'MULTIMEDIA_IND', N'MS_Description', CAST(N'MultimediaIndicator' AS nvarchar(19)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_MON', N'FEDR_FAC_IND', N'MS_Description', CAST(N'FederalFacilityIndicator' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_MON', N'FEDR_FAC_IND_CMNT', N'MS_Description', CAST(N'FederalFacilityIndicatorComment' AS nvarchar(31)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_MON', N'INSP_USR_DFND_FLD_1', N'MS_Description', CAST(N'InspectionUserDefinedField1' AS nvarchar(27)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_MON', N'INSP_USR_DFND_FLD_2', N'MS_Description', CAST(N'InspectionUserDefinedField2' AS nvarchar(27)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_MON', N'INSP_USR_DFND_FLD_3', N'MS_Description', CAST(N'InspectionUserDefinedField3' AS nvarchar(27)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_MON', N'INSP_USR_DFND_FLD_4', N'MS_Description', CAST(N'InspectionUserDefinedField4' AS nvarchar(27)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_MON', N'INSP_USR_DFND_FLD_5', N'MS_Description', CAST(N'InspectionUserDefinedField5' AS nvarchar(27)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_MON', N'INSP_USR_DFND_FLD_6', N'MS_Description', CAST(N'InspectionUserDefinedField6' AS nvarchar(27)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_MON', N'CMPL_MON_PLANNED_START_DATE', N'MS_Description', CAST(N'ComplianceMonitoringPlannedStartDate' AS nvarchar(36)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_MON', N'CMPL_MON_PLANNED_END_DATE', N'MS_Description', CAST(N'ComplianceMonitoringPlannedEndDate' AS nvarchar(34)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_IDENT', NULL, N'MS_Description', CAST(N'Schema element: String' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_IDENT', N'PRMT_IDENT', N'MS_Description', CAST(N'PermitIdentifier' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMT_SET', NULL, N'MS_Description', CAST(N'Schema element: LimitSetData' AS nvarchar(28)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMT_SET', N'SRC_SYSTM_IDENT', N'MS_Description', CAST(N'SourceSystemIdentifier' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMT_SET', N'TRANSACTION_TYPE', N'MS_Description', CAST(N'TransactionType' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMT_SET', N'TRANSACTION_TIMESTAMP', N'MS_Description', CAST(N'TransactionTimestamp' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMT_SET', N'PRMT_IDENT', N'MS_Description', CAST(N'PermitIdentifier' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMT_SET', N'PRMT_FEATR_IDENT', N'MS_Description', CAST(N'PermittedFeatureIdentifier' AS nvarchar(26)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMT_SET', N'LMT_SET_DESIGNATOR', N'MS_Description', CAST(N'LimitSetDesignator' AS nvarchar(18)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMT_SET', N'LMT_SET_TYPE', N'MS_Description', CAST(N'LimitSetType' AS nvarchar(12)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMT_SET', N'LMT_SET_NAME_TXT', N'MS_Description', CAST(N'LimitSetNameText' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMT_SET', N'DMR_PRE_PRINT_CMNTS_TXT', N'MS_Description', CAST(N'DMRPrePrintCommentsText' AS nvarchar(23)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMT_SET', N'AGNCY_REVIEWER', N'MS_Description', CAST(N'AgencyReviewer' AS nvarchar(14)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMT_SET', N'LMT_SET_USR_DFND_DAT_ELM_1_TXT', N'MS_Description', CAST(N'LimitSetUserDefinedDataElement1Text' AS nvarchar(35)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMT_SET', N'LMT_SET_USR_DFND_DAT_ELM_2_TXT', N'MS_Description', CAST(N'LimitSetUserDefinedDataElement2Text' AS nvarchar(35)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_MON_ACTN_REASON', NULL, N'MS_Description', CAST(N'Schema element: String' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_MON_ACTN_REASON', N'CMPL_MON_ACTN_REASON_CODE', N'MS_Description', CAST(N'ComplianceMonitoringActionReasonCode' AS nvarchar(36)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_REISSU', NULL, N'MS_Description', CAST(N'Schema element: PermitReissuanceData' AS nvarchar(36)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_REISSU', N'SRC_SYSTM_IDENT', N'MS_Description', CAST(N'SourceSystemIdentifier' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_REISSU', N'TRANSACTION_TYPE', N'MS_Description', CAST(N'TransactionType' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_REISSU', N'TRANSACTION_TIMESTAMP', N'MS_Description', CAST(N'TransactionTimestamp' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_REISSU', N'PRMT_IDENT', N'MS_Description', CAST(N'PermitIdentifier' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_REISSU', N'PRMT_ISSUE_DATE', N'MS_Description', CAST(N'PermitIssueDate' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_REISSU', N'PRMT_EFFECTIVE_DATE', N'MS_Description', CAST(N'PermitEffectiveDate' AS nvarchar(19)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_REISSU', N'PRMT_EXPR_DATE', N'MS_Description', CAST(N'PermitExpirationDate' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMT_SET_MONTHS_APPL', NULL, N'MS_Description', CAST(N'Schema element: MonthTextType' AS nvarchar(29)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMT_SET_MONTHS_APPL', N'LMT_SET_MONTHS_APPL', N'MS_Description', CAST(N'LimitSetMonthsApplicable' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_MON_AGNCY_TYPE', NULL, N'MS_Description', CAST(N'Schema element: String' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_MON_AGNCY_TYPE', N'CMPL_MON_AGNCY_TYPE_CODE', N'MS_Description', CAST(N'ComplianceMonitoringAgencyTypeCode' AS nvarchar(34)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_SCHD_EVT', NULL, N'MS_Description', CAST(N'Schema element: PermitScheduleEvent' AS nvarchar(35)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_SCHD_EVT', N'SCHD_EVT_CODE', N'MS_Description', CAST(N'ScheduleEventCode' AS nvarchar(17)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_SCHD_EVT', N'SCHD_DATE', N'MS_Description', CAST(N'ScheduleDate' AS nvarchar(12)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_SCHD_EVT', N'SCHD_REP_RCVD_DATE', N'MS_Description', CAST(N'ScheduleReportReceivedDate' AS nvarchar(26)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_SCHD_EVT', N'SCHD_ACTUL_DATE', N'MS_Description', CAST(N'ScheduleActualDate' AS nvarchar(18)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_SCHD_EVT', N'SCHD_PROJ_DATE', N'MS_Description', CAST(N'ScheduleProjectedDate' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_SCHD_EVT', N'SCHD_USR_DFND_DAT_ELM_1', N'MS_Description', CAST(N'ScheduleUserDefinedDataElement1' AS nvarchar(31)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_SCHD_EVT', N'SCHD_USR_DFND_DAT_ELM_2', N'MS_Description', CAST(N'ScheduleUserDefinedDataElement2' AS nvarchar(31)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_SCHD_EVT', N'SCHD_EVT_CMNTS', N'MS_Description', CAST(N'ScheduleEventComments' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMT_SET_SCHD', NULL, N'MS_Description', CAST(N'Schema element: LimitSetSchedule' AS nvarchar(32)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMT_SET_SCHD', N'NUM_UNITS_REP_PERIOD_INTEGER', N'MS_Description', CAST(N'NumberUnitsReportPeriodInteger' AS nvarchar(30)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMT_SET_SCHD', N'NUM_SUBM_UNITS_INTEGER', N'MS_Description', CAST(N'NumberSubmissionUnitsInteger' AS nvarchar(28)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMT_SET_SCHD', N'INITIAL_MON_DATE', N'MS_Description', CAST(N'InitialMonitoringDate' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMT_SET_SCHD', N'INITIAL_DMR_DUE_DATE', N'MS_Description', CAST(N'InitialDMRDueDate' AS nvarchar(17)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMT_SET_SCHD', N'LMT_SET_MOD_TYPE_CODE', N'MS_Description', CAST(N'LimitSetModificationTypeCode' AS nvarchar(28)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMT_SET_SCHD', N'LMT_SET_MOD_EFFECTIVE_DATE', N'MS_Description', CAST(N'LimitSetModificationEffectiveDate' AS nvarchar(33)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_MON_EVT', NULL, N'MS_Description', CAST(N'Schema element: ComplianceMonitoringEventData' AS nvarchar(45)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_MON_EVT', N'CMPL_MON_EVT_IDENT', N'MS_Description', CAST(N'ComplianceMonitoringEventIdentifier' AS nvarchar(35)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_MON_EVT', N'CMPL_MON_EVT_START_DATE', N'MS_Description', CAST(N'ComplianceMonitoringEventStartDate' AS nvarchar(34)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_MON_EVT', N'CMPL_MON_EVT_END_DATE', N'MS_Description', CAST(N'ComplianceMonitoringEventEndDate' AS nvarchar(32)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_SCHD_EVT_VIOL_ELEM', NULL, N'MS_Description', CAST(N'Schema element: PermitScheduleEventViolationKeyElements' AS nvarchar(55)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_SCHD_EVT_VIOL_ELEM', N'PRMT_IDENT', N'MS_Description', CAST(N'PermitIdentifier' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_SCHD_EVT_VIOL_ELEM', N'NARR_COND_NUM', N'MS_Description', CAST(N'NarrativeConditionNumber' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_SCHD_EVT_VIOL_ELEM', N'SCHD_EVT_CODE', N'MS_Description', CAST(N'ScheduleEventCode' AS nvarchar(17)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_SCHD_EVT_VIOL_ELEM', N'SCHD_DATE', N'MS_Description', CAST(N'ScheduleDate' AS nvarchar(12)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_SCHD_EVT_VIOL_ELEM', N'SCHD_VIOL_CODE', N'MS_Description', CAST(N'ScheduleViolationCode' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMT_SET_STAT', NULL, N'MS_Description', CAST(N'Schema element: LimitSetStatus' AS nvarchar(30)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMT_SET_STAT', N'LMT_SET_STAT_IND', N'MS_Description', CAST(N'LimitSetStatusIndicator' AS nvarchar(23)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMT_SET_STAT', N'LMT_SET_STAT_START_DATE', N'MS_Description', CAST(N'LimitSetStatusStartDate' AS nvarchar(23)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMT_SET_STAT', N'LMT_SET_STAT_REASON_TXT', N'MS_Description', CAST(N'LimitSetStatusReasonText' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_MON_LNK', NULL, N'MS_Description', CAST(N'Schema element: ComplianceMonitoringLinkageData' AS nvarchar(47)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_MON_LNK', N'SRC_SYSTM_IDENT', N'MS_Description', CAST(N'SourceSystemIdentifier' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_MON_LNK', N'TRANSACTION_TYPE', N'MS_Description', CAST(N'TransactionType' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_MON_LNK', N'TRANSACTION_TIMESTAMP', N'MS_Description', CAST(N'TransactionTimestamp' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_MON_LNK', N'CMPL_MON_IDENT', N'MS_Description', CAST(N'ComplianceMonitoringIdentifier' AS nvarchar(30)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_SCHD_VIOL', NULL, N'MS_Description', CAST(N'Schema element: PermitScheduleViolation' AS nvarchar(39)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_SCHD_VIOL', N'PRMT_IDENT', N'MS_Description', CAST(N'PermitIdentifier' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_SCHD_VIOL', N'NARR_COND_NUM', N'MS_Description', CAST(N'NarrativeConditionNumber' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_SCHD_VIOL', N'SCHD_EVT_CODE', N'MS_Description', CAST(N'ScheduleEventCode' AS nvarchar(17)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_SCHD_VIOL', N'SCHD_DATE', N'MS_Description', CAST(N'ScheduleDate' AS nvarchar(12)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMTS', NULL, N'MS_Description', CAST(N'Schema element: LimitsData' AS nvarchar(26)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMTS', N'SRC_SYSTM_IDENT', N'MS_Description', CAST(N'SourceSystemIdentifier' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMTS', N'TRANSACTION_TYPE', N'MS_Description', CAST(N'TransactionType' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMTS', N'TRANSACTION_TIMESTAMP', N'MS_Description', CAST(N'TransactionTimestamp' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMTS', N'PRMT_IDENT', N'MS_Description', CAST(N'PermitIdentifier' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMTS', N'PRMT_FEATR_IDENT', N'MS_Description', CAST(N'PermittedFeatureIdentifier' AS nvarchar(26)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMTS', N'LMT_SET_DESIGNATOR', N'MS_Description', CAST(N'LimitSetDesignator' AS nvarchar(18)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMTS', N'PARAM_CODE', N'MS_Description', CAST(N'ParameterCode' AS nvarchar(13)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMTS', N'MON_SITE_DESC_CODE', N'MS_Description', CAST(N'MonitoringSiteDescriptionCode' AS nvarchar(29)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMTS', N'LMT_SEASON_NUM', N'MS_Description', CAST(N'LimitSeasonNumber' AS nvarchar(17)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMTS', N'LMT_START_DATE', N'MS_Description', CAST(N'LimitStartDate' AS nvarchar(14)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMTS', N'LMT_END_DATE', N'MS_Description', CAST(N'LimitEndDate' AS nvarchar(12)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMTS', N'LMT_TYPE_CODE', N'MS_Description', CAST(N'LimitTypeCode' AS nvarchar(13)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMTS', N'SMPL_TYPE_TXT', N'MS_Description', CAST(N'SampleTypeText' AS nvarchar(14)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMTS', N'FREQ_OF_ANALYSIS_CODE', N'MS_Description', CAST(N'FrequencyOfAnalysisCode' AS nvarchar(23)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMTS', N'ELIGIBLE_FOR_BURDEN_REDUCTION', N'MS_Description', CAST(N'EligibleForBurdenReduction' AS nvarchar(26)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMTS', N'LMT_STAY_TYPE_CODE', N'MS_Description', CAST(N'LimitStayTypeCode' AS nvarchar(17)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMTS', N'STAY_START_DATE', N'MS_Description', CAST(N'StayStartDate' AS nvarchar(13)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMTS', N'STAY_END_DATE', N'MS_Description', CAST(N'StayEndDate' AS nvarchar(11)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMTS', N'STAY_REASON_TXT', N'MS_Description', CAST(N'StayReasonText' AS nvarchar(14)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMTS', N'CALCULATE_VIOL_IND', N'MS_Description', CAST(N'CalculateViolationsIndicator' AS nvarchar(28)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMTS', N'ENFRC_ACTN_IDENT', N'MS_Description', CAST(N'EnforcementActionIdentifier' AS nvarchar(27)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMTS', N'FINAL_ORDER_IDENT', N'MS_Description', CAST(N'FinalOrderIdentifier' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMTS', N'BASIS_OF_LMT', N'MS_Description', CAST(N'BasisOfLimit' AS nvarchar(12)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMTS', N'LMT_MOD_TYPE_CODE', N'MS_Description', CAST(N'LimitModificationTypeCode' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMTS', N'LMT_MOD_EFFECTIVE_DATE', N'MS_Description', CAST(N'LimitModificationEffectiveDate' AS nvarchar(30)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMTS', N'LMT_MOD_TYPE_STAY_REASON_TXT', N'MS_Description', CAST(N'LimitModificationTypeStayReasonText' AS nvarchar(35)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMTS', N'LMTS_USR_DFND_FLD_1', N'MS_Description', CAST(N'LimitsUserDefinedField1' AS nvarchar(23)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMTS', N'LMTS_USR_DFND_FLD_2', N'MS_Description', CAST(N'LimitsUserDefinedField2' AS nvarchar(23)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMTS', N'LMTS_USR_DFND_FLD_3', N'MS_Description', CAST(N'LimitsUserDefinedField3' AS nvarchar(23)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMTS', N'CONCEN_NUM_COND_UNIT_MEAS_CODE', N'MS_Description', CAST(N'ConcentrationNumericConditionUnitMeasureCode' AS nvarchar(44)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LMTS', N'QTY_NUM_COND_UNIT_MEAS_CODE', N'MS_Description', CAST(N'QuantityNumericConditionUnitMeasureCode' AS nvarchar(39)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_SCHD', NULL, N'MS_Description', CAST(N'Schema element: ComplianceScheduleData' AS nvarchar(38)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_SCHD', N'SRC_SYSTM_IDENT', N'MS_Description', CAST(N'SourceSystemIdentifier' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_SCHD', N'TRANSACTION_TYPE', N'MS_Description', CAST(N'TransactionType' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_SCHD', N'TRANSACTION_TIMESTAMP', N'MS_Description', CAST(N'TransactionTimestamp' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_SCHD', N'ENFRC_ACTN_IDENT', N'MS_Description', CAST(N'EnforcementActionIdentifier' AS nvarchar(27)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_SCHD', N'FINAL_ORDER_IDENT', N'MS_Description', CAST(N'FinalOrderIdentifier' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_SCHD', N'PRMT_IDENT', N'MS_Description', CAST(N'PermitIdentifier' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_SCHD', N'CMPL_SCHD_NUM', N'MS_Description', CAST(N'ComplianceScheduleNumber' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_SCHD', N'CMPL_SCHD_CMNTS', N'MS_Description', CAST(N'ComplianceScheduleComments' AS nvarchar(26)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_SCHD', N'SCHD_DESC_CODE', N'MS_Description', CAST(N'ScheduleDescriptorCode' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_TERM', NULL, N'MS_Description', CAST(N'Schema element: PermitTerminationData' AS nvarchar(37)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_TERM', N'SRC_SYSTM_IDENT', N'MS_Description', CAST(N'SourceSystemIdentifier' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_TERM', N'TRANSACTION_TYPE', N'MS_Description', CAST(N'TransactionType' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_TERM', N'TRANSACTION_TIMESTAMP', N'MS_Description', CAST(N'TransactionTimestamp' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_TERM', N'PRMT_IDENT', N'MS_Description', CAST(N'PermitIdentifier' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_TERM', N'PRMT_TERM_DATE', N'MS_Description', CAST(N'PermitTerminationDate' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LNK_CMPL_MON', NULL, N'MS_Description', CAST(N'Schema element: LinkageComplianceMonitoring' AS nvarchar(43)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LNK_CMPL_MON', N'CMPL_MON_IDENT', N'MS_Description', CAST(N'ComplianceMonitoringIdentifier' AS nvarchar(30)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_SCHD_EVT', NULL, N'MS_Description', CAST(N'Schema element: ComplianceScheduleEvent' AS nvarchar(39)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_SCHD_EVT', N'SCHD_EVT_CODE', N'MS_Description', CAST(N'ScheduleEventCode' AS nvarchar(17)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_SCHD_EVT', N'SCHD_DATE', N'MS_Description', CAST(N'ScheduleDate' AS nvarchar(12)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_SCHD_EVT', N'SCHD_REP_RCVD_DATE', N'MS_Description', CAST(N'ScheduleReportReceivedDate' AS nvarchar(26)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_SCHD_EVT', N'SCHD_ACTUL_DATE', N'MS_Description', CAST(N'ScheduleActualDate' AS nvarchar(18)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_SCHD_EVT', N'SCHD_PROJ_DATE', N'MS_Description', CAST(N'ScheduleProjectedDate' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_SCHD_EVT', N'SCHD_USR_DFND_DAT_ELM_1', N'MS_Description', CAST(N'ScheduleUserDefinedDataElement1' AS nvarchar(31)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_SCHD_EVT', N'SCHD_USR_DFND_DAT_ELM_2', N'MS_Description', CAST(N'ScheduleUserDefinedDataElement2' AS nvarchar(31)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_SCHD_EVT', N'SCHD_EVT_CMNTS', N'MS_Description', CAST(N'ScheduleEventComments' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_SCHD_EVT', N'CMPL_SCHD_PNLTY_AMT', N'MS_Description', CAST(N'ComplianceSchedulePenaltyAmount' AS nvarchar(31)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_TRACK_EVT', NULL, N'MS_Description', CAST(N'Schema element: PermitTrackingEventData' AS nvarchar(39)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_TRACK_EVT', N'SRC_SYSTM_IDENT', N'MS_Description', CAST(N'SourceSystemIdentifier' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_TRACK_EVT', N'TRANSACTION_TYPE', N'MS_Description', CAST(N'TransactionType' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_TRACK_EVT', N'TRANSACTION_TIMESTAMP', N'MS_Description', CAST(N'TransactionTimestamp' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_TRACK_EVT', N'PRMT_IDENT', N'MS_Description', CAST(N'PermitIdentifier' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_TRACK_EVT', N'PRMT_TRACK_EVT_CODE', N'MS_Description', CAST(N'PermitTrackingEventCode' AS nvarchar(23)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_TRACK_EVT', N'PRMT_TRACK_EVT_DATE', N'MS_Description', CAST(N'PermitTrackingEventDate' AS nvarchar(23)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PRMT_TRACK_EVT', N'PRMT_TRACK_CMNTS_TXT', N'MS_Description', CAST(N'PermitTrackingCommentsText' AS nvarchar(26)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LNK_ENFRC_ACTN', NULL, N'MS_Description', CAST(N'Schema element: LinkageEnforcementAction' AS nvarchar(40)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LNK_ENFRC_ACTN', N'ENFRC_ACTN_IDENT', N'MS_Description', CAST(N'EnforcementActionIdentifier' AS nvarchar(27)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_SCHD_EVT_VIOL_ELEM', NULL, N'MS_Description', CAST(N'Schema element: ComplianceScheduleEventViolationKeyElements' AS nvarchar(59)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_SCHD_EVT_VIOL_ELEM', N'ENFRC_ACTN_IDENT', N'MS_Description', CAST(N'EnforcementActionIdentifier' AS nvarchar(27)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_SCHD_EVT_VIOL_ELEM', N'FINAL_ORDER_IDENT', N'MS_Description', CAST(N'FinalOrderIdentifier' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_SCHD_EVT_VIOL_ELEM', N'PRMT_IDENT', N'MS_Description', CAST(N'PermitIdentifier' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_SCHD_EVT_VIOL_ELEM', N'CMPL_SCHD_NUM', N'MS_Description', CAST(N'ComplianceScheduleNumber' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_SCHD_EVT_VIOL_ELEM', N'SCHD_EVT_CODE', N'MS_Description', CAST(N'ScheduleEventCode' AS nvarchar(17)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_SCHD_EVT_VIOL_ELEM', N'SCHD_DATE', N'MS_Description', CAST(N'ScheduleDate' AS nvarchar(12)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_SCHD_EVT_VIOL_ELEM', N'SCHD_VIOL_CODE', N'MS_Description', CAST(N'ScheduleViolationCode' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PROG', NULL, N'MS_Description', CAST(N'Schema element: String' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PROG', N'PROG_CODE', N'MS_Description', CAST(N'ProgramCode' AS nvarchar(11)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LNK_SNGL_EVT', NULL, N'MS_Description', CAST(N'Schema element: LinkageSingleEvent' AS nvarchar(34)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LNK_SNGL_EVT', N'PRMT_IDENT', N'MS_Description', CAST(N'PermitIdentifier' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LNK_SNGL_EVT', N'SNGL_EVT_VIOL_CODE', N'MS_Description', CAST(N'SingleEventViolationCode' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LNK_SNGL_EVT', N'SNGL_EVT_VIOL_DATE', N'MS_Description', CAST(N'SingleEventViolationDate' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_SCHD_VIOL', NULL, N'MS_Description', CAST(N'Schema element: ComplianceScheduleViolation' AS nvarchar(43)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_SCHD_VIOL', N'ENFRC_ACTN_IDENT', N'MS_Description', CAST(N'EnforcementActionIdentifier' AS nvarchar(27)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_SCHD_VIOL', N'FINAL_ORDER_IDENT', N'MS_Description', CAST(N'FinalOrderIdentifier' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_SCHD_VIOL', N'PRMT_IDENT', N'MS_Description', CAST(N'PermitIdentifier' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_SCHD_VIOL', N'CMPL_SCHD_NUM', N'MS_Description', CAST(N'ComplianceScheduleNumber' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_SCHD_VIOL', N'SCHD_EVT_CODE', N'MS_Description', CAST(N'ScheduleEventCode' AS nvarchar(17)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_SCHD_VIOL', N'SCHD_DATE', N'MS_Description', CAST(N'ScheduleDate' AS nvarchar(12)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PROG_DEFCY_TYPE', NULL, N'MS_Description', CAST(N'Schema element: String' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PROG_DEFCY_TYPE', N'PROG_DEFCY_TYPE_CODE', N'MS_Description', CAST(N'ProgramDeficiencyTypeCode' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LOC_LMTS_PARAMETERS', NULL, N'MS_Description', CAST(N'Schema element: String' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LOC_LMTS_PARAMETERS', N'LOC_LMTS_PARAMETERS', N'MS_Description', CAST(N'LocalLimitsParameters' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_TRACK_STAT', NULL, N'MS_Description', CAST(N'Schema element: ComplianceTrackingStatus' AS nvarchar(40)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_TRACK_STAT', N'STAT_CODE', N'MS_Description', CAST(N'StatusCode' AS nvarchar(10)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_TRACK_STAT', N'STAT_START_DATE', N'MS_Description', CAST(N'StatusStartDate' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CMPL_TRACK_STAT', N'STAT_REASON', N'MS_Description', CAST(N'StatusReason' AS nvarchar(12)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PROGS_VIOL', NULL, N'MS_Description', CAST(N'Schema element: String' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PROGS_VIOL', N'PROGS_VIOL_CODE', N'MS_Description', CAST(N'ProgramsViolatedCode' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LTCP_ENFORCEABLE_MECH_DETAIL', NULL, N'MS_Description', CAST(N'Schema element: LTCPEnforceableMechanismDetail' AS nvarchar(46)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LTCP_ENFORCEABLE_MECH_DETAIL', N'LTCP_ENFORCEABLE_MECH_CODE', N'MS_Description', CAST(N'LTCPEnforceableMechanismCode' AS nvarchar(28)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LTCP_ENFORCEABLE_MECH_DETAIL', N'LTCP_ENFORCEABLE_MECH_CODE_OTHR_TXT', N'MS_Description', CAST(N'LTCPEnforceableMechanismCodeOtherText' AS nvarchar(37)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CNST_SITE', NULL, N'MS_Description', CAST(N'Schema element: String' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CNST_SITE', N'CNST_SITE_CODE', N'MS_Description', CAST(N'ConstructionSiteCode' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PROJ_SRCS_FUND', NULL, N'MS_Description', CAST(N'Schema element: String' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PROJ_SRCS_FUND', N'PROJ_SRCS_FUND_CODE', N'MS_Description', CAST(N'ProjectedSourcesFundingCode' AS nvarchar(27)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LTCP_MOST_RECENT_REVISION_DETAIL', NULL, N'MS_Description', CAST(N'Schema element: LTCPMostRecentRevisionDetail' AS nvarchar(44)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LTCP_MOST_RECENT_REVISION_DETAIL', N'LTCP_MOST_RECENT_REVISION_DATE', N'MS_Description', CAST(N'LTCPMostRecentRevisionDate' AS nvarchar(26)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LTCP_MOST_RECENT_REVISION_DETAIL', N'LTCP_MOST_RECENT_REVISION_STAT', N'MS_Description', CAST(N'LTCPMostRecentRevisionStatus' AS nvarchar(28)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CNST_SITE_LIST', NULL, N'MS_Description', CAST(N'Schema element: ConstructionSiteList' AS nvarchar(36)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CNST_SITE_LIST', N'CNST_SITE_OTHR_TXT', N'MS_Description', CAST(N'ConstructionSiteOtherText' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PROJ_TYPE', NULL, N'MS_Description', CAST(N'Schema element: ProjectType' AS nvarchar(27)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PROJ_TYPE', N'PROJ_TYPE_CODE', N'MS_Description', CAST(N'ProjectTypeCode' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PROJ_TYPE', N'PROJ_TYPE_CODE_OTHR_DESC', N'MS_Description', CAST(N'ProjectTypeCodeOtherDescription' AS nvarchar(31)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LTCP_SUMM', NULL, N'MS_Description', CAST(N'Schema element: LTCPSummary' AS nvarchar(27)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LTCP_SUMM', N'LTCP_REQD_IND', N'MS_Description', CAST(N'LTCPRequiredIndicator' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LTCP_SUMM', N'LTCP_IN_CMPL_IND', N'MS_Description', CAST(N'LTCPInComplianceIndicator' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LTCP_SUMM', N'LTCP_APRVL_DATE', N'MS_Description', CAST(N'LTCPApprovalDate' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LTCP_SUMM', N'LTCP_AND_CSO_CONTROLS_COMPLETE_DATE', N'MS_Description', CAST(N'LTCPAndCSOControlsCompleteDate' AS nvarchar(30)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LTCP_SUMM', N'CSO_POST_CNST_CMPL_MON_PROG', N'MS_Description', CAST(N'CSOPostConstructionComplianceMonitoringProgram' AS nvarchar(46)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_LTCP_SUMM', N'CSO_CONTROLS_OTHR_THAN_LTCP', N'MS_Description', CAST(N'CSOControlsOtherThanLTCP' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CO_DSPL_SITE', NULL, N'MS_Description', CAST(N'Schema element: CoDisposalSite' AS nvarchar(30)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CO_DSPL_SITE', N'PART_258_CMPL_IND', N'MS_Description', CAST(N'Part258ComplianceIndicator' AS nvarchar(26)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CO_DSPL_SITE', N'PAINT_FILTER_TEST_RESULT', N'MS_Description', CAST(N'PaintFilterTestResult' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CO_DSPL_SITE', N'TCLP_TEST_RESULT', N'MS_Description', CAST(N'TCLPTestResult' AS nvarchar(14)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PROPOSED_CNST_SW_BM_PS', NULL, N'MS_Description', CAST(N'Schema element: ProposedConstructionStormwaterBMPs' AS nvarchar(50)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PROPOSED_CNST_SW_BM_PS', N'PROPOSED_CNST_SW_BMP_CODE', N'MS_Description', CAST(N'ProposedConstructionStormwaterBMPCode' AS nvarchar(37)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PROPOSED_CNST_SW_BM_PS', N'PROPOSED_CNST_SW_BMP_OTHR_TXT', N'MS_Description', CAST(N'ProposedConstructionStormwaterBMPOtherText' AS nvarchar(42)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MASTER_GNRL_PRMT', NULL, N'MS_Description', CAST(N'Schema element: MasterGeneralPermitData' AS nvarchar(39)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MASTER_GNRL_PRMT', N'SRC_SYSTM_IDENT', N'MS_Description', CAST(N'SourceSystemIdentifier' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MASTER_GNRL_PRMT', N'TRANSACTION_TYPE', N'MS_Description', CAST(N'TransactionType' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MASTER_GNRL_PRMT', N'TRANSACTION_TIMESTAMP', N'MS_Description', CAST(N'TransactionTimestamp' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MASTER_GNRL_PRMT', N'PRMT_IDENT', N'MS_Description', CAST(N'PermitIdentifier' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MASTER_GNRL_PRMT', N'PRMT_TYPE_CODE', N'MS_Description', CAST(N'PermitTypeCode' AS nvarchar(14)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MASTER_GNRL_PRMT', N'AGNCY_TYPE_CODE', N'MS_Description', CAST(N'AgencyTypeCode' AS nvarchar(14)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MASTER_GNRL_PRMT', N'PRMT_ISSUE_DATE', N'MS_Description', CAST(N'PermitIssueDate' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MASTER_GNRL_PRMT', N'PRMT_EFFECTIVE_DATE', N'MS_Description', CAST(N'PermitEffectiveDate' AS nvarchar(19)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MASTER_GNRL_PRMT', N'PRMT_EXPR_DATE', N'MS_Description', CAST(N'PermitExpirationDate' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MASTER_GNRL_PRMT', N'REISSU_PRIO_PRMT_IND', N'MS_Description', CAST(N'ReissuancePriorityPermitIndicator' AS nvarchar(33)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MASTER_GNRL_PRMT', N'BACKLOG_REASON_TXT', N'MS_Description', CAST(N'BacklogReasonText' AS nvarchar(17)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MASTER_GNRL_PRMT', N'PRMT_ISSUING_ORG_TYPE_NAME', N'MS_Description', CAST(N'PermitIssuingOrganizationTypeName' AS nvarchar(33)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MASTER_GNRL_PRMT', N'PRMT_APPEALED_IND', N'MS_Description', CAST(N'PermitAppealedIndicator' AS nvarchar(23)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MASTER_GNRL_PRMT', N'PRMT_USR_DFND_DAT_ELM_1_TXT', N'MS_Description', CAST(N'PermitUserDefinedDataElement1Text' AS nvarchar(33)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MASTER_GNRL_PRMT', N'PRMT_USR_DFND_DAT_ELM_2_TXT', N'MS_Description', CAST(N'PermitUserDefinedDataElement2Text' AS nvarchar(33)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MASTER_GNRL_PRMT', N'PRMT_USR_DFND_DAT_ELM_3_TXT', N'MS_Description', CAST(N'PermitUserDefinedDataElement3Text' AS nvarchar(33)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MASTER_GNRL_PRMT', N'PRMT_USR_DFND_DAT_ELM_4_TXT', N'MS_Description', CAST(N'PermitUserDefinedDataElement4Text' AS nvarchar(33)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MASTER_GNRL_PRMT', N'PRMT_USR_DFND_DAT_ELM_5_TXT', N'MS_Description', CAST(N'PermitUserDefinedDataElement5Text' AS nvarchar(33)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MASTER_GNRL_PRMT', N'PRMT_CMNTS_TXT', N'MS_Description', CAST(N'PermitCommentsText' AS nvarchar(18)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MASTER_GNRL_PRMT', N'GNRL_PRMT_INDST_CATG', N'MS_Description', CAST(N'GeneralPermitIndustrialCategory' AS nvarchar(31)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MASTER_GNRL_PRMT', N'PRMT_NAME', N'MS_Description', CAST(N'PermitName' AS nvarchar(10)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_COLL_SYSTM_PRMT', NULL, N'MS_Description', CAST(N'Schema element: CollectionSystemPermitData' AS nvarchar(42)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_COLL_SYSTM_PRMT', N'SRC_SYSTM_IDENT', N'MS_Description', CAST(N'SourceSystemIdentifier' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_COLL_SYSTM_PRMT', N'TRANSACTION_TYPE', N'MS_Description', CAST(N'TransactionType' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_COLL_SYSTM_PRMT', N'TRANSACTION_TIMESTAMP', N'MS_Description', CAST(N'TransactionTimestamp' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_COLL_SYSTM_PRMT', N'PRMT_IDENT', N'MS_Description', CAST(N'PermitIdentifier' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_COLL_SYSTM_PRMT', N'COLL_SYSTM_IDENT', N'MS_Description', CAST(N'CollectionSystemIdentifier' AS nvarchar(26)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_COLL_SYSTM_PRMT', N'COLL_SYSTM_NAME', N'MS_Description', CAST(N'CollectionSystemName' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_COLL_SYSTM_PRMT', N'COLL_SYSTM_OWNER_TYPE_CODE', N'MS_Description', CAST(N'CollectionSystemOwnerTypeCode' AS nvarchar(29)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_COLL_SYSTM_PRMT', N'COLL_SYSTM_POPL', N'MS_Description', CAST(N'CollectionSystemPopulation' AS nvarchar(26)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_COLL_SYSTM_PRMT', N'PERCENT_COLL_SYSTM_CSS', N'MS_Description', CAST(N'PercentCollectionSystemCSS' AS nvarchar(26)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PROPOSED_INDST_SW_BM_PS', NULL, N'MS_Description', CAST(N'Schema element: ProposedIndustrialStormwaterBMPs' AS nvarchar(48)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PROPOSED_INDST_SW_BM_PS', N'PROPOSED_INDST_SW_BMP_CODE', N'MS_Description', CAST(N'ProposedIndustrialStormwaterBMPCode' AS nvarchar(35)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PROPOSED_INDST_SW_BM_PS', N'PROPOSED_INDST_SW_BMP_OTHR_TXT', N'MS_Description', CAST(N'ProposedIndustrialStormwaterBMPOtherText' AS nvarchar(40)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MN_LMT_APPLIES', NULL, N'MS_Description', CAST(N'Schema element: MonthTextType' AS nvarchar(29)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MN_LMT_APPLIES', N'MN_LMT_APPLIES', N'MS_Description', CAST(N'MonthLimitApplies' AS nvarchar(17)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CONTACT', NULL, N'MS_Description', CAST(N'Schema element: Contact' AS nvarchar(23)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CONTACT', N'AFFIL_TYPE_TXT', N'MS_Description', CAST(N'AffiliationTypeText' AS nvarchar(19)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CONTACT', N'FIRST_NAME', N'MS_Description', CAST(N'FirstName' AS nvarchar(9)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CONTACT', N'MIDDLE_NAME', N'MS_Description', CAST(N'MiddleName' AS nvarchar(10)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CONTACT', N'LAST_NAME', N'MS_Description', CAST(N'LastName' AS nvarchar(8)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CONTACT', N'INDVL_TITLE_TXT', N'MS_Description', CAST(N'IndividualTitleText' AS nvarchar(19)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CONTACT', N'ORG_FRML_NAME', N'MS_Description', CAST(N'OrganizationFormalName' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CONTACT', N'ST_CODE', N'MS_Description', CAST(N'StateCode' AS nvarchar(9)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CONTACT', N'RGN_CODE', N'MS_Description', CAST(N'RegionCode' AS nvarchar(10)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CONTACT', N'ELEC_ADDR_TXT', N'MS_Description', CAST(N'ElectronicAddressText' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CONTACT', N'START_DATE_OF_CONTACT_ASSC', N'MS_Description', CAST(N'StartDateOfContactAssociation' AS nvarchar(29)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CONTACT', N'END_DATE_OF_CONTACT_ASSC', N'MS_Description', CAST(N'EndDateOfContactAssociation' AS nvarchar(27)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PROPOSED_POST_CNST_SW_BM_PS', NULL, N'MS_Description', CAST(N'Schema element: ProposedPostConstructionStormwaterBMPs' AS nvarchar(54)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PROPOSED_POST_CNST_SW_BM_PS', N'PROPOSED_POST_CNST_SW_BMP_CODE', N'MS_Description', CAST(N'ProposedPostConstructionStormwaterBMPCode' AS nvarchar(41)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_PROPOSED_POST_CNST_SW_BM_PS', N'PROPOSED_POST_CNST_SW_BMP_OTHR_TXT', N'MS_Description', CAST(N'ProposedPostConstructionStormwaterBMPOtherText' AS nvarchar(46)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MNUR_LTTR_PRCSS_WW_STOR', NULL, N'MS_Description', CAST(N'Schema element: ManureLitterProcessedWastewaterStorage' AS nvarchar(54)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MNUR_LTTR_PRCSS_WW_STOR', N'MNUR_LTTR_PRCSS_WW_STOR_TYPE', N'MS_Description', CAST(N'ManureLitterProcessedWastewaterStorageType' AS nvarchar(42)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MNUR_LTTR_PRCSS_WW_STOR', N'OTHR_STOR_TYPE_NAME', N'MS_Description', CAST(N'OtherStorageTypeName' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MNUR_LTTR_PRCSS_WW_STOR', N'STOR_TTL_CPCTY_MEAS', N'MS_Description', CAST(N'StorageTotalCapacityMeasure' AS nvarchar(27)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MNUR_LTTR_PRCSS_WW_STOR', N'DAYS_OF_STOR', N'MS_Description', CAST(N'DaysOfStorage' AS nvarchar(13)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MNUR_LTTR_PRCSS_WW_STOR', N'CAFOMLPW_UNIT', N'MS_Description', CAST(N'CAFOMLPWUnit' AS nvarchar(12)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MNUR_LTTR_PRCSS_WW_STOR', N'CAFOMLPW_STOR_WITHIN_DSGN_CPCTY', N'MS_Description', CAST(N'CAFOMLPWStorageWithinDesignCapacity' AS nvarchar(35)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MNUR_LTTR_PRCSS_WW_STOR', N'CAFOMLPW_STOR_WITHIN_DSGN_CPCTY_TXT', N'MS_Description', CAST(N'CAFOMLPWStorageWithinDesignCapacityText' AS nvarchar(39)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CONTAINMENT', NULL, N'MS_Description', CAST(N'Schema element: Containment' AS nvarchar(27)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CONTAINMENT', N'CONTAINMENT_TYPE_CODE', N'MS_Description', CAST(N'ContainmentTypeCode' AS nvarchar(19)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CONTAINMENT', N'OTHR_CONTAINMENT_TYPE_NAME', N'MS_Description', CAST(N'OtherContainmentTypeName' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CONTAINMENT', N'CONTAINMENT_CPCTY_NUM', N'MS_Description', CAST(N'ContainmentCapacityNumber' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_REP_NON_CMPL_STAT', NULL, N'MS_Description', CAST(N'Schema element: ReportableNonComplianceStatus' AS nvarchar(45)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_REP_NON_CMPL_STAT', N'REP_NON_CMPL_STAT_CODE_YEAR', N'MS_Description', CAST(N'ReportableNonComplianceStatusCodeYear' AS nvarchar(37)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_REP_NON_CMPL_STAT', N'REP_NON_CMPL_STAT_CODE_QUARTER', N'MS_Description', CAST(N'ReportableNonComplianceStatusCodeQuarter' AS nvarchar(40)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_REP_NON_CMPL_STAT', N'REP_NON_CMPL_MANUAL_STAT_CODE', N'MS_Description', CAST(N'ReportableNonComplianceManualStatusCode' AS nvarchar(39)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_ACTY_IDENT', NULL, N'MS_Description', CAST(N'Schema element: String' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_ACTY_IDENT', N'MS_4_ACTY_IDENT', N'MS_Description', CAST(N'MS4ActivityIdentifier' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CONTROL_AUTH_PROG_INFO', NULL, N'MS_Description', CAST(N'Schema element: ControlAuthorityProgramInformation' AS nvarchar(50)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CONTROL_AUTH_PROG_INFO', N'LOC_LMTS_ADOPTION_DATE', N'MS_Description', CAST(N'LocalLimitsAdoptionDate' AS nvarchar(23)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CONTROL_AUTH_PROG_INFO', N'LOC_LMTS_EVAL_DATE', N'MS_Description', CAST(N'LocalLimitsEvaluationDate' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CONTROL_AUTH_PROG_INFO', N'POTW_DSCH_CONTAMINATION_IND', N'MS_Description', CAST(N'POTWDischargeContaminationIndicator' AS nvarchar(35)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CONTROL_AUTH_PROG_INFO', N'POTW_DSCH_CONTAMINATION_TXT', N'MS_Description', CAST(N'POTWDischargeContaminationText' AS nvarchar(30)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CONTROL_AUTH_PROG_INFO', N'POTW_BS_CONTAMINATION_IND', N'MS_Description', CAST(N'POTWBiosolidsContaminationIndicator' AS nvarchar(35)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CONTROL_AUTH_PROG_INFO', N'POTW_BS_CONTAMINATION_TXT', N'MS_Description', CAST(N'POTWBiosolidsContaminationText' AS nvarchar(30)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_REP_PARAM', NULL, N'MS_Description', CAST(N'Schema element: ReportParameter' AS nvarchar(31)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_REP_PARAM', N'PARAM_CODE', N'MS_Description', CAST(N'ParameterCode' AS nvarchar(13)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_REP_PARAM', N'MON_SITE_DESC_CODE', N'MS_Description', CAST(N'MonitoringSiteDescriptionCode' AS nvarchar(29)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_REP_PARAM', N'LMT_SEASON_NUM', N'MS_Description', CAST(N'LimitSeasonNumber' AS nvarchar(17)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_REP_PARAM', N'REP_SMPL_TYPE_TXT', N'MS_Description', CAST(N'ReportSampleTypeText' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_REP_PARAM', N'REP_FREQ_CODE', N'MS_Description', CAST(N'ReportingFrequencyCode' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_REP_PARAM', N'REP_NUM_OF_EXCURSIONS', N'MS_Description', CAST(N'ReportNumberOfExcursions' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_REP_PARAM', N'CONCEN_NUM_REP_UNIT_MEAS_CODE', N'MS_Description', CAST(N'ConcentrationNumericReportUnitMeasureCode' AS nvarchar(41)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_REP_PARAM', N'QTY_NUM_REP_UNIT_MEAS_CODE', N'MS_Description', CAST(N'QuantityNumericReportUnitMeasureCode' AS nvarchar(36)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_CNST_SW_PROCEDURES', NULL, N'MS_Description', CAST(N'Schema element: MS4ConstructionStormwaterProcedures' AS nvarchar(51)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_CNST_SW_PROCEDURES', N'MS_4_ACTY_IDENT', N'MS_Description', CAST(N'MS4ActivityIdentifier' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_CNST_SW_PROCEDURES', N'MS_4_CNST_SW_PROCEDURE_TYPE', N'MS_Description', CAST(N'MS4ConstructionStormwaterProcedureType' AS nvarchar(38)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_CNST_SW_PROCEDURES', N'MS_4_CNST_SW_PROCEDURE_TXT', N'MS_Description', CAST(N'MS4ConstructionStormwaterProcedureText' AS nvarchar(38)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_CNST_SW_PROCEDURES', N'MS_4_CNST_SW_PROCEDURE_SCHD_TXT', N'MS_Description', CAST(N'MS4ConstructionStormwaterProcedureScheduleText' AS nvarchar(46)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_COOLING_WTR_INTAKE_STRCT_CMPL_METHOD', NULL, N'MS_Description', CAST(N'Schema element: CoolingWaterIntakeStructureComplianceMethod' AS nvarchar(59)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_COOLING_WTR_INTAKE_STRCT_CMPL_METHOD', N'COOLING_WTR_INTAKE_STRCT_CMPL_METHOD_CODE', N'MS_Description', CAST(N'CoolingWaterIntakeStructureComplianceMethodCode' AS nvarchar(47)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_COOLING_WTR_INTAKE_STRCT_CMPL_METHOD', N'COOLING_WTR_INTAKE_STRCT_CMPL_METHOD_TXT', N'MS_Description', CAST(N'CoolingWaterIntakeStructureComplianceMethodText' AS nvarchar(47)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_RESIDUAL_DESGN_DTRMN', NULL, N'MS_Description', CAST(N'Schema element: ResidualDesignationDetermination' AS nvarchar(48)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_RESIDUAL_DESGN_DTRMN', N'RESIDUAL_DESGN_DTRMN_CODE', N'MS_Description', CAST(N'ResidualDesignationDeterminationCode' AS nvarchar(36)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_RESIDUAL_DESGN_DTRMN', N'RESIDUAL_DESGN_DTRMN_OTHR_TXT', N'MS_Description', CAST(N'ResidualDesignationDeterminationOtherText' AS nvarchar(41)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_CNST_SW_REGULATED_ENTITY_INFO', NULL, N'MS_Description', CAST(N'Schema element: MS4ConstructionStormwaterRegulatedEntityInformation' AS nvarchar(67)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_CNST_SW_REGULATED_ENTITY_INFO', N'MS_4_ACTY_IDENT', N'MS_Description', CAST(N'MS4ActivityIdentifier' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_CNST_SW_REGULATED_ENTITY_INFO', N'MS_4_REGULATED_ENTITY_IDENT', N'MS_Description', CAST(N'MS4RegulatedEntityIdentifier' AS nvarchar(28)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_CNST_SW_REGULATED_ENTITY_INFO', N'MS_4_CNST_SW_EROSION_ORDINANCE_STAT', N'MS_Description', CAST(N'MS4ConstructionStormwaterErosionOrdinanceStatus' AS nvarchar(47)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_CNST_SW_REGULATED_ENTITY_INFO', N'MS_4_CNST_SW_EROSION_ORDINANCE_STAT_TXT', N'MS_Description', CAST(N'MS4ConstructionStormwaterErosionOrdinanceStatusText' AS nvarchar(51)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_CNST_SW_REGULATED_ENTITY_INFO', N'MS_4_CNST_SW_EROSION_PLAN_RVIW_STAT', N'MS_Description', CAST(N'MS4ConstructionStormwaterErosionPlanReviewStatus' AS nvarchar(48)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_CNST_SW_REGULATED_ENTITY_INFO', N'MS_4_CNST_SW_EROSION_PLAN_RVIW_STAT_TXT', N'MS_Description', CAST(N'MS4ConstructionStormwaterErosionPlanReviewStatusText' AS nvarchar(52)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_CNST_SW_REGULATED_ENTITY_INFO', N'MS_4_CNST_SW_SITE_INSP_STAT', N'MS_Description', CAST(N'MS4ConstructionStormwaterSiteInspectionStatus' AS nvarchar(45)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_CNST_SW_REGULATED_ENTITY_INFO', N'MS_4_CNST_SW_SITE_INSP_STAT_TXT', N'MS_Description', CAST(N'MS4ConstructionStormwaterSiteInspectionStatusText' AS nvarchar(49)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_COOLING_WTR_INTAKE_STRCT_INFO', NULL, N'MS_Description', CAST(N'Schema element: CoolingWaterIntakeStructureInformation' AS nvarchar(54)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_COOLING_WTR_INTAKE_STRCT_INFO', N'COOLING_WTR_INTAKE_STRCT_APPL_SUBPART', N'MS_Description', CAST(N'CoolingWaterIntakeStructureApplicableSubpart' AS nvarchar(44)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_COOLING_WTR_INTAKE_STRCT_INFO', N'COOLING_WTR_INTAKE_STRCT_DSGN_INTAKE_FLOW', N'MS_Description', CAST(N'CoolingWaterIntakeStructureDesignIntakeFlow' AS nvarchar(43)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_COOLING_WTR_INTAKE_STRCT_INFO', N'COOLING_WTR_INTAKE_STRCT_ACTUL_INTAKE_FLOW', N'MS_Description', CAST(N'CoolingWaterIntakeStructureActualIntakeFlow' AS nvarchar(43)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_COOLING_WTR_INTAKE_STRCT_INFO', N'COOLING_WTR_ACTUL_INTAKE_STRCT_VELOCITY', N'MS_Description', CAST(N'CoolingWaterActualIntakeStructureVelocity' AS nvarchar(41)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_COOLING_WTR_INTAKE_STRCT_INFO', N'SRC_WTR_BASELINE_BIOLOGICAL_CHARACTERIZATION', N'MS_Description', CAST(N'SourceWaterBaselineBiologicalCharacterization' AS nvarchar(45)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_COOLING_WTR_INTAKE_STRCT_INFO', N'COOLING_WTR_INTAKE_STRCT_LOC_CODE', N'MS_Description', CAST(N'CoolingWaterIntakeStructureLocationCode' AS nvarchar(39)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_COOLING_WTR_INTAKE_STRCT_INFO', N'COOLING_WTR_INTAKE_STRCT_LOC_TXT', N'MS_Description', CAST(N'CoolingWaterIntakeStructureLocationText' AS nvarchar(39)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_COOLING_WTR_INTAKE_STRCT_INFO', N'COOLING_WTR_INTAKE_STRCT_SRC_WTR_CODE', N'MS_Description', CAST(N'CoolingWaterIntakeStructureSourceWaterCode' AS nvarchar(42)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_COOLING_WTR_INTAKE_STRCT_INFO', N'COOLING_WTR_INTAKE_STRCT_SRC_WTR_TXT', N'MS_Description', CAST(N'CoolingWaterIntakeStructureSourceWaterText' AS nvarchar(42)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SATL_COLL_SYSTM', NULL, N'MS_Description', CAST(N'Schema element: SatelliteCollectionSystem' AS nvarchar(41)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SATL_COLL_SYSTM', N'SATL_COLL_SYSTM_IDENT', N'MS_Description', CAST(N'SatelliteCollectionSystemIdentifier' AS nvarchar(35)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SATL_COLL_SYSTM', N'SATL_COLL_SYSTM_NAME', N'MS_Description', CAST(N'SatelliteCollectionSystemName' AS nvarchar(29)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_CNST_SW_REQS', NULL, N'MS_Description', CAST(N'Schema element: MS4ConstructionStormwaterRequirements' AS nvarchar(53)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_COPY_MGP_LMT_SET', NULL, N'MS_Description', CAST(N'Schema element: CopyMGPLimitSetData' AS nvarchar(35)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_COPY_MGP_LMT_SET', N'SRC_SYSTM_IDENT', N'MS_Description', CAST(N'SourceSystemIdentifier' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_COPY_MGP_LMT_SET', N'TRANSACTION_TYPE', N'MS_Description', CAST(N'TransactionType' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_COPY_MGP_LMT_SET', N'TRANSACTION_TIMESTAMP', N'MS_Description', CAST(N'TransactionTimestamp' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_COPY_MGP_LMT_SET', N'PRMT_IDENT', N'MS_Description', CAST(N'PermitIdentifier' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_COPY_MGP_LMT_SET', N'PRMT_FEATR_IDENT', N'MS_Description', CAST(N'PermittedFeatureIdentifier' AS nvarchar(26)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_COPY_MGP_LMT_SET', N'LMT_SET_DESIGNATOR', N'MS_Description', CAST(N'LimitSetDesignator' AS nvarchar(18)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_COPY_MGP_LMT_SET', N'TRGT_GNRL_PRMT_IDENT', N'MS_Description', CAST(N'TargetGeneralPermitIdentifier' AS nvarchar(29)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_COPY_MGP_LMT_SET', N'TRGT_GNRL_PRMT_FEATR_IDENT', N'MS_Description', CAST(N'TargetGeneralPermittedFeatureIdentifier' AS nvarchar(39)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_COPY_MGP_LMT_SET', N'TRGT_GNRL_LMT_SET_DESIGNATOR', N'MS_Description', CAST(N'TargetGeneralLimitSetDesignator' AS nvarchar(31)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_COPY_MGP_LMT_SET', N'PRMT_FEATR_TYPE_CODE', N'MS_Description', CAST(N'PermittedFeatureTypeCode' AS nvarchar(24)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_COPY_MGP_LMT_SET', N'PRMT_FEATR_DESC', N'MS_Description', CAST(N'PermittedFeatureDescription' AS nvarchar(27)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_COPY_MGP_LMT_SET', N'PRMT_FEATR_ST_WTR_BODY_NAME', N'MS_Description', CAST(N'PermittedFeatureStateWaterBodyName' AS nvarchar(34)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_COPY_MGP_LMT_SET', N'IMPAIRED_WTR_IND', N'MS_Description', CAST(N'ImpairedWaterIndicator' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_COPY_MGP_LMT_SET', N'TMDL_COMPLETED_IND', N'MS_Description', CAST(N'TMDLCompletedIndicator' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_COPY_MGP_LMT_SET', N'PRMT_FEATR_USR_DFND_DAT_ELM_1', N'MS_Description', CAST(N'PermittedFeatureUserDefinedDataElement1' AS nvarchar(39)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_COPY_MGP_LMT_SET', N'PRMT_FEATR_USR_DFND_DAT_ELM_2', N'MS_Description', CAST(N'PermittedFeatureUserDefinedDataElement2' AS nvarchar(39)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_COPY_MGP_LMT_SET', N'LMT_SET_NAME_TXT', N'MS_Description', CAST(N'LimitSetNameText' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_COPY_MGP_LMT_SET', N'DMR_PRE_PRINT_CMNTS_TXT', N'MS_Description', CAST(N'DMRPrePrintCommentsText' AS nvarchar(23)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SCHD_EVT_VIOL', NULL, N'MS_Description', CAST(N'Schema element: ScheduleEventViolationData' AS nvarchar(42)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SCHD_EVT_VIOL', N'SRC_SYSTM_IDENT', N'MS_Description', CAST(N'SourceSystemIdentifier' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SCHD_EVT_VIOL', N'TRANSACTION_TYPE', N'MS_Description', CAST(N'TransactionType' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SCHD_EVT_VIOL', N'TRANSACTION_TIMESTAMP', N'MS_Description', CAST(N'TransactionTimestamp' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SCHD_EVT_VIOL', N'REP_NON_CMPL_RESL_CODE', N'MS_Description', CAST(N'ReportableNonComplianceResolutionCode' AS nvarchar(37)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SCHD_EVT_VIOL', N'REP_NON_CMPL_RESL_DATE', N'MS_Description', CAST(N'ReportableNonComplianceResolutionDate' AS nvarchar(37)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_ILLICIT_DETECT_PROCEDURES', NULL, N'MS_Description', CAST(N'Schema element: MS4IllicitDetectionProcedures' AS nvarchar(45)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_ILLICIT_DETECT_PROCEDURES', N'MS_4_ACTY_IDENT', N'MS_Description', CAST(N'MS4ActivityIdentifier' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_ILLICIT_DETECT_PROCEDURES', N'MS_4_ILLICIT_DETECT_PROCEDURE_TYPE', N'MS_Description', CAST(N'MS4IllicitDetectionProcedureType' AS nvarchar(32)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_ILLICIT_DETECT_PROCEDURES', N'MS_4_ILLICIT_DETECT_PROCEDURE_TXT', N'MS_Description', CAST(N'MS4IllicitDetectionProcedureText' AS nvarchar(32)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_ILLICIT_DETECT_PROCEDURES', N'MS_4_ILLICIT_DETECT_PROCEDURE_SCHD_TXT', N'MS_Description', CAST(N'MS4IllicitDetectionProcedureScheduleText' AS nvarchar(40)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_COPY_MGPMS_4_REQ', NULL, N'MS_Description', CAST(N'Schema element: CopyMGPMS4RequirementData' AS nvarchar(41)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_COPY_MGPMS_4_REQ', N'SRC_SYSTM_IDENT', N'MS_Description', CAST(N'SourceSystemIdentifier' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_COPY_MGPMS_4_REQ', N'PRMT_IDENT', N'MS_Description', CAST(N'PermitIdentifier' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_COPY_MGPMS_4_REQ', N'TRANSACTION_TYPE', N'MS_Description', CAST(N'TransactionType' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_COPY_MGPMS_4_REQ', N'TRANSACTION_TIMESTAMP', N'MS_Description', CAST(N'TransactionTimestamp' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SEP', NULL, N'MS_Description', CAST(N'Schema element: SupplementalEnvironmentalProject' AS nvarchar(48)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SEP', N'SEP_IDENT', N'MS_Description', CAST(N'SupplementalEnvironmentalProjectIdentifier' AS nvarchar(42)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SEP', N'SEP_DESC', N'MS_Description', CAST(N'SupplementalEnvironmentalProjectDescription' AS nvarchar(43)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SEP', N'SEP_PNLTY_ASSESSMENT_AMT', N'MS_Description', CAST(N'SupplementalEnvironmentalProjectPenaltyAssessmentAmount' AS nvarchar(55)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO', NULL, N'MS_Description', CAST(N'Schema element: MS4IllicitDetectionRegulatedEntityInformation' AS nvarchar(61)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO', N'MS_4_ACTY_IDENT', N'MS_Description', CAST(N'MS4ActivityIdentifier' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO', N'MS_4_REGULATED_ENTITY_IDENT', N'MS_Description', CAST(N'MS4RegulatedEntityIdentifier' AS nvarchar(28)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO', N'MS_4_PRMT_ILLICIT_DETECT_OUTFALL_MAPPING_DATE', N'MS_Description', CAST(N'MS4PermitIllicitDetectionOutfallMappingDate' AS nvarchar(43)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO', N'MS_4_ILLICIT_DETECT_OUTFALL_MAPPING_STAT', N'MS_Description', CAST(N'MS4IllicitDetectionOutfallMappingStatus' AS nvarchar(39)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO', N'MS_4_PRMT_ILLICIT_DETECT_OUTFALL_TTL_NUM', N'MS_Description', CAST(N'MS4PermitIllicitDetectionOutfallTotalNumber' AS nvarchar(43)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO', N'MS_4_PRMT_ILLICIT_DETECT_OUTFALL_MAPPED_NUM', N'MS_Description', CAST(N'MS4PermitIllicitDetectionOutfallMappedNumber' AS nvarchar(44)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO', N'MS_4_ILLICIT_DETECT_PROHIBITION_ORDINANCE_STAT', N'MS_Description', CAST(N'MS4IllicitDetectionProhibitionOrdinanceStatus' AS nvarchar(45)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO', N'MS_4_ILLICIT_DETECT_PROHIBITION_ORDINANCE_STAT_TXT', N'MS_Description', CAST(N'MS4IllicitDetectionProhibitionOrdinanceStatusText' AS nvarchar(49)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CROP_TYPES_HARVESTED', NULL, N'MS_Description', CAST(N'Schema element: String' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CROP_TYPES_HARVESTED', N'CROP_TYPES_HARVESTED', N'MS_Description', CAST(N'CropTypesHarvested' AS nvarchar(18)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SEWER_OVRFLW_BYPASS_CAUSE', NULL, N'MS_Description', CAST(N'Schema element: SewerOverflowBypassCause' AS nvarchar(40)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SEWER_OVRFLW_BYPASS_CAUSE', N'SEWER_OVRFLW_BYPASS_CAUSE_CODE', N'MS_Description', CAST(N'SewerOverflowBypassCauseCode' AS nvarchar(28)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SEWER_OVRFLW_BYPASS_CAUSE', N'SEWER_OVRFLW_BYPASS_CAUSE_OTHR_TXT', N'MS_Description', CAST(N'SewerOverflowBypassCauseOtherText' AS nvarchar(33)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO_PROG_REP', NULL, N'MS_Description', CAST(N'Schema element: MS4IllicitDetectionRegulatedEntityInformationProgramReport' AS nvarchar(74)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO_PROG_REP', N'MS_4_ACTY_IDENT', N'MS_Description', CAST(N'MS4ActivityIdentifier' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO_PROG_REP', N'MS_4_PROG_REP_ILLICIT_DETECT_OUTFALL_MAPPING_DATE', N'MS_Description', CAST(N'MS4ProgramReportIllicitDetectionOutfallMappingDate' AS nvarchar(50)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO_PROG_REP', N'MS_4_PROG_REP_ILLICIT_DETECT_OUTFALL_TTL_NUM', N'MS_Description', CAST(N'MS4ProgramReportIllicitDetectionOutfallTotalNumber' AS nvarchar(50)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO_PROG_REP', N'MS_4_PROG_REP_ILLICIT_DETECT_OUTFALL_MAPPED_NUM', N'MS_Description', CAST(N'MS4ProgramReportIllicitDetectionOutfallMappedNumber' AS nvarchar(51)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO_PROG_REP', N'MS_4_REGULATED_ENTITY_CMPL_STAT', N'MS_Description', CAST(N'MS4RegulatedEntityComplianceStatus' AS nvarchar(34)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO_PROG_REP', N'MS_4_REGULATED_ENTITY_CMPL_STAT_TXT', N'MS_Description', CAST(N'MS4RegulatedEntityComplianceStatusText' AS nvarchar(38)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO_PROG_REP', N'MS_4_PROG_REP_REQS_ACTIVITIES', N'MS_Description', CAST(N'MS4ProgramReportRequirementsActivities' AS nvarchar(38)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CROP_TYPES_PLANTED', NULL, N'MS_Description', CAST(N'Schema element: String' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CROP_TYPES_PLANTED', N'CROP_TYPES_PLANTED', N'MS_Description', CAST(N'CropTypesPlanted' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SEWER_OVRFLW_BYPASS_CORR_ACTN', NULL, N'MS_Description', CAST(N'Schema element: SewerOverflowBypassCorrectiveAction' AS nvarchar(51)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SEWER_OVRFLW_BYPASS_CORR_ACTN', N'SEWER_OVRFLW_BYPASS_CORR_ACTN_CODE', N'MS_Description', CAST(N'SewerOverflowBypassCorrectiveActionCode' AS nvarchar(39)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SEWER_OVRFLW_BYPASS_CORR_ACTN', N'SEWER_OVRFLW_BYPASS_CORR_ACTN_OTHR_TXT', N'MS_Description', CAST(N'SewerOverflowBypassCorrectiveActionOtherText' AS nvarchar(44)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_ILLICIT_DETECT_REQS', NULL, N'MS_Description', CAST(N'Schema element: MS4IllicitDetectionRequirements' AS nvarchar(47)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CSO_CONTROL_MEAS_DETAIL', NULL, N'MS_Description', CAST(N'Schema element: CSOControlMeasureDetail' AS nvarchar(39)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CSO_CONTROL_MEAS_DETAIL', N'CSO_CONTROL_MEAS_CODE', N'MS_Description', CAST(N'CSOControlMeasureCode' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CSO_CONTROL_MEAS_DETAIL', N'CSO_CONTROL_MEAS_CODE_OTHR_TXT', N'MS_Description', CAST(N'CSOControlMeasureCodeOtherText' AS nvarchar(30)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CSO_CONTROL_MEAS_DETAIL', N'CSO_CONTROL_MEAS_DEV_IMP_STAT', N'MS_Description', CAST(N'CSOControlMeasureDevImpStatus' AS nvarchar(29)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_CSO_CONTROL_MEAS_DETAIL', N'CSO_CONTROL_MEAS_CMPL_STAT', N'MS_Description', CAST(N'CSOControlMeasureComplianceStatus' AS nvarchar(33)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SEWER_OVRFLW_BYPASS_EVT_REP', NULL, N'MS_Description', CAST(N'Schema element: SewerOverflowBypassEventReportData' AS nvarchar(50)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SEWER_OVRFLW_BYPASS_EVT_REP', N'SRC_SYSTM_IDENT', N'MS_Description', CAST(N'SourceSystemIdentifier' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SEWER_OVRFLW_BYPASS_EVT_REP', N'TRANSACTION_TYPE', N'MS_Description', CAST(N'TransactionType' AS nvarchar(15)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SEWER_OVRFLW_BYPASS_EVT_REP', N'TRANSACTION_TIMESTAMP', N'MS_Description', CAST(N'TransactionTimestamp' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SEWER_OVRFLW_BYPASS_EVT_REP', N'PRMT_IDENT', N'MS_Description', CAST(N'PermitIdentifier' AS nvarchar(16)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SEWER_OVRFLW_BYPASS_EVT_REP', N'PROG_REP_FORM_SET_ID', N'MS_Description', CAST(N'ProgramReportFormSetID' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SEWER_OVRFLW_BYPASS_EVT_REP', N'PROG_REP_FORM_ID', N'MS_Description', CAST(N'ProgramReportFormID' AS nvarchar(19)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SEWER_OVRFLW_BYPASS_EVT_REP', N'PROG_REP_RCVD_DATE', N'MS_Description', CAST(N'ProgramReportReceivedDate' AS nvarchar(25)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SEWER_OVRFLW_BYPASS_EVT_REP', N'PROG_REP_START_DATE', N'MS_Description', CAST(N'ProgramReportStartDate' AS nvarchar(22)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SEWER_OVRFLW_BYPASS_EVT_REP', N'PROG_REP_END_DATE', N'MS_Description', CAST(N'ProgramReportEndDate' AS nvarchar(20)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SEWER_OVRFLW_BYPASS_EVT_REP', N'ELEC_SUBM_TYPE_CODE', N'MS_Description', CAST(N'ElectronicSubmissionTypeCode' AS nvarchar(28)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_SEWER_OVRFLW_BYPASS_EVT_REP', N'PROG_REP_NPDES_DAT_GRP_NUM_CODE', N'MS_Description', CAST(N'ProgramReportNPDESDataGroupNumberCode' AS nvarchar(37)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_INDST_SW_PROCEDURES', NULL, N'MS_Description', CAST(N'Schema element: MS4IndustrialStormwaterProcedures' AS nvarchar(49)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_INDST_SW_PROCEDURES', N'MS_4_ACTY_IDENT', N'MS_Description', CAST(N'MS4ActivityIdentifier' AS nvarchar(21)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_INDST_SW_PROCEDURES', N'MS_4_INDST_SW_PROCEDURE_TYPE', N'MS_Description', CAST(N'MS4IndustrialStormwaterProcedureType' AS nvarchar(36)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_INDST_SW_PROCEDURES', N'MS_4_INDST_SW_PROCEDURE_TXT', N'MS_Description', CAST(N'MS4IndustrialStormwaterProcedureText' AS nvarchar(36)))
GO
INSERT [ics_flow_local].[ICS_ABOUT_ELEMENTS] ([SCHEMA_NAME], [OBJECT_NAME], [COLUMN_NAME], [PROP_NAME], [PROP_VALUE]) VALUES (N'ics_flow_local', N'ICS_MS_4_INDST_SW_PROCEDURES', N'MS_4_INDST_SW_PROCEDURE_SCHD_TXT', N'MS_Description', CAST(N'MS4IndustrialStormwaterProcedureScheduleText' AS nvarchar(44)))
GO
