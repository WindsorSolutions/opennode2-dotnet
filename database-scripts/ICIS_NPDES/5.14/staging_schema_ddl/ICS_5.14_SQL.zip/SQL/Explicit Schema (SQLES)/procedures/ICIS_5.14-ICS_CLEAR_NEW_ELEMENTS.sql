
drop procedure if exists [ics_flow_local].[ICS_CLEAR_NEW_ELEMENTS];
GO
create procedure [ics_flow_local].[ICS_CLEAR_NEW_ELEMENTS]
as 
BEGIN

-- /[ics_flow_local].[ICS_BASIC_PRMT]/[ics_flow_local].[ICS_RESIDUAL_DESGN_DTRMN]
 delete I18 from [ics_flow_local].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT]    JOIN [ics_flow_local].[ICS_RESIDUAL_DESGN_DTRMN] [I18]   ON [I18].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID]   
-- /[ics_flow_local].[ICS_BASIC_PRMT]/[ics_flow_local].[ICS_SIU_DESGN_TYPE]
 delete I20 from [ics_flow_local].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT]    JOIN [ics_flow_local].[ICS_SIU_DESGN_TYPE] [I20]   ON [I20].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID]   
-- /[ics_flow_local].[ICS_BS_PRMT]/[ics_flow_local].[ICS_PRMT_BS_MGMT_PRACTICE]/[ics_flow_local].[ICS_PATHOGEN_REDUCTION_TYPE]
 delete I2 from [ics_flow_local].[ICS_BS_PRMT] [ICS_BS_PRMT]    JOIN [ics_flow_local].[ICS_PRMT_BS_MGMT_PRACTICE] [I1]   ON [I1].[ICS_BS_PRMT_ID] = [ICS_BS_PRMT].[ICS_BS_PRMT_ID]    JOIN [ics_flow_local].[ICS_PATHOGEN_REDUCTION_TYPE] [I2]   ON [I2].[ICS_PRMT_BS_MGMT_PRACTICE_ID] = [I1].[ICS_PRMT_BS_MGMT_PRACTICE_ID]   
-- /[ics_flow_local].[ICS_BS_PRMT]/[ics_flow_local].[ICS_PRMT_BS_MGMT_PRACTICE]/[ics_flow_local].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR]/[ics_flow_local].[ICS_ADDR]/[ics_flow_local].[ICS_TELEPH]
 delete I5 from [ics_flow_local].[ICS_BS_PRMT] [ICS_BS_PRMT]    JOIN [ics_flow_local].[ICS_PRMT_BS_MGMT_PRACTICE] [I1]   ON [I1].[ICS_BS_PRMT_ID] = [ICS_BS_PRMT].[ICS_BS_PRMT_ID]    JOIN [ics_flow_local].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] [I3]   ON [I3].[ICS_PRMT_BS_MGMT_PRACTICE_ID] = [I1].[ICS_PRMT_BS_MGMT_PRACTICE_ID]    JOIN [ics_flow_local].[ICS_ADDR] [I4]   ON [I4].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] = [I3].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID]    JOIN [ics_flow_local].[ICS_TELEPH] [I5]   ON [I5].[ICS_ADDR_ID] = [I4].[ICS_ADDR_ID]   
 -- /[ics_flow_local].[ICS_BS_PRMT]/[ics_flow_local].[ICS_PRMT_BS_MGMT_PRACTICE]/[ics_flow_local].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR]/[ics_flow_local].[ICS_ADDR]
 delete I4 from [ics_flow_local].[ICS_BS_PRMT] [ICS_BS_PRMT]    JOIN [ics_flow_local].[ICS_PRMT_BS_MGMT_PRACTICE] [I1]   ON [I1].[ICS_BS_PRMT_ID] = [ICS_BS_PRMT].[ICS_BS_PRMT_ID]    JOIN [ics_flow_local].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] [I3]   ON [I3].[ICS_PRMT_BS_MGMT_PRACTICE_ID] = [I1].[ICS_PRMT_BS_MGMT_PRACTICE_ID]    JOIN [ics_flow_local].[ICS_ADDR] [I4]   ON [I4].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] = [I3].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID]   


-- /[ics_flow_local].[ICS_BS_PRMT]/[ics_flow_local].[ICS_PRMT_BS_MGMT_PRACTICE]/[ics_flow_local].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR]/[ics_flow_local].[ICS_CONTACT]/[ics_flow_local].[ICS_TELEPH]
 delete I7 from [ics_flow_local].[ICS_BS_PRMT] [ICS_BS_PRMT]    JOIN [ics_flow_local].[ICS_PRMT_BS_MGMT_PRACTICE] [I1]   ON [I1].[ICS_BS_PRMT_ID] = [ICS_BS_PRMT].[ICS_BS_PRMT_ID]    JOIN [ics_flow_local].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] [I3]   ON [I3].[ICS_PRMT_BS_MGMT_PRACTICE_ID] = [I1].[ICS_PRMT_BS_MGMT_PRACTICE_ID]    JOIN [ics_flow_local].[ICS_CONTACT] [I6]   ON [I6].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] = [I3].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID]    JOIN [ics_flow_local].[ICS_TELEPH] [I7]   ON [I7].[ICS_CONTACT_ID] = [I6].[ICS_CONTACT_ID]   

 -- /[ics_flow_local].[ICS_BS_PRMT]/[ics_flow_local].[ICS_PRMT_BS_MGMT_PRACTICE]/[ics_flow_local].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR]/[ics_flow_local].[ICS_CONTACT]
 delete I6 from [ics_flow_local].[ICS_BS_PRMT] [ICS_BS_PRMT]    JOIN [ics_flow_local].[ICS_PRMT_BS_MGMT_PRACTICE] [I1]   ON [I1].[ICS_BS_PRMT_ID] = [ICS_BS_PRMT].[ICS_BS_PRMT_ID]    JOIN [ics_flow_local].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] [I3]   ON [I3].[ICS_PRMT_BS_MGMT_PRACTICE_ID] = [I1].[ICS_PRMT_BS_MGMT_PRACTICE_ID]    JOIN [ics_flow_local].[ICS_CONTACT] [I6]   ON [I6].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] = [I3].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID]   


-- /[ics_flow_local].[ICS_BS_PRMT]/[ics_flow_local].[ICS_PRMT_BS_MGMT_PRACTICE]/[ics_flow_local].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR]
 delete I3 from [ics_flow_local].[ICS_BS_PRMT] [ICS_BS_PRMT]    JOIN [ics_flow_local].[ICS_PRMT_BS_MGMT_PRACTICE] [I1]   ON [I1].[ICS_BS_PRMT_ID] = [ICS_BS_PRMT].[ICS_BS_PRMT_ID]    JOIN [ics_flow_local].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] [I3]   ON [I3].[ICS_PRMT_BS_MGMT_PRACTICE_ID] = [I1].[ICS_PRMT_BS_MGMT_PRACTICE_ID]   

-- /[ics_flow_local].[ICS_BS_PRMT]/[ics_flow_local].[ICS_PRMT_BS_MGMT_PRACTICE]/[ics_flow_local].[ICS_VECTOR_A_REDUCTION_TYPE]
 delete I8 from [ics_flow_local].[ICS_BS_PRMT] [ICS_BS_PRMT]    JOIN [ics_flow_local].[ICS_PRMT_BS_MGMT_PRACTICE] [I1]   ON [I1].[ICS_BS_PRMT_ID] = [ICS_BS_PRMT].[ICS_BS_PRMT_ID]    JOIN [ics_flow_local].[ICS_VECTOR_A_REDUCTION_TYPE] [I8]   ON [I8].[ICS_PRMT_BS_MGMT_PRACTICE_ID] = [I1].[ICS_PRMT_BS_MGMT_PRACTICE_ID]   
 -- /[ics_flow_local].[ICS_BS_PRMT]/[ics_flow_local].[ICS_PRMT_BS_MGMT_PRACTICE]
 delete I1 from [ics_flow_local].[ICS_BS_PRMT] [ICS_BS_PRMT]    JOIN [ics_flow_local].[ICS_PRMT_BS_MGMT_PRACTICE] [I1]   ON [I1].[ICS_BS_PRMT_ID] = [ICS_BS_PRMT].[ICS_BS_PRMT_ID]   



-- /[ics_flow_local].[ICS_BS_PRMT]/[ics_flow_local].[ICS_BS_FAC_TRTMNT]
 delete I9 from [ics_flow_local].[ICS_BS_PRMT] [ICS_BS_PRMT]    JOIN [ics_flow_local].[ICS_BS_FAC_TRTMNT] [I9]   ON [I9].[ICS_BS_PRMT_ID] = [ICS_BS_PRMT].[ICS_BS_PRMT_ID]   
-- /[ics_flow_local].[ICS_BS_PRMT]/[ics_flow_local].[ICS_BS_FAC_TYPE]
 delete I10 from [ics_flow_local].[ICS_BS_PRMT] [ICS_BS_PRMT]    JOIN [ics_flow_local].[ICS_BS_FAC_TYPE] [I10]   ON [I10].[ICS_BS_PRMT_ID] = [ICS_BS_PRMT].[ICS_BS_PRMT_ID]   
-- /[ics_flow_local].[ICS_CAFO_PRMT]/[ics_flow_local].[ICS_CAFOMLPW_TTL_AMOUNTS]
 delete I9 from [ics_flow_local].[ICS_CAFO_PRMT] [ICS_CAFO_PRMT]    JOIN [ics_flow_local].[ICS_CAFOMLPW_TTL_AMOUNTS] [I9]   ON [I9].[ICS_CAFO_PRMT_ID] = [ICS_CAFO_PRMT].[ICS_CAFO_PRMT_ID]   
-- /[ics_flow_local].[ICS_CMPL_MON]/[ics_flow_local].[ICS_INSP_CMNT_TXT]
 delete I8 from [ics_flow_local].[ICS_CMPL_MON] [ICS_CMPL_MON]    JOIN [ics_flow_local].[ICS_INSP_CMNT_TXT] [I8]   ON [I8].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID]   
-- /[ics_flow_local].[ICS_CMPL_MON]/[ics_flow_local].[ICS_INSP_GOV_CONTACT]
 delete I9 from [ics_flow_local].[ICS_CMPL_MON] [ICS_CMPL_MON]    JOIN [ics_flow_local].[ICS_INSP_GOV_CONTACT] [I9]   ON [I9].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID]   
-- /[ics_flow_local].[ICS_CMPL_MON_LNK]/[ics_flow_local].[ICS_LNK_CMPL_MON]
 delete I1 from [ics_flow_local].[ICS_CMPL_MON_LNK] [ICS_CMPL_MON_LNK]    JOIN [ics_flow_local].[ICS_LNK_CMPL_MON] [I1]   ON [I1].[ICS_CMPL_MON_LNK_ID] = [ICS_CMPL_MON_LNK].[ICS_CMPL_MON_LNK_ID]   
-- /[ics_flow_local].[ICS_GNRL_PRMT]/[ics_flow_local].[ICS_RESIDUAL_DESGN_DTRMN]
 delete I19 from [ics_flow_local].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT]    JOIN [ics_flow_local].[ICS_RESIDUAL_DESGN_DTRMN] [I19]   ON [I19].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID]   
-- /[ics_flow_local].[ICS_MASTER_GNRL_PRMT]/[ics_flow_local].[ICS_RESIDUAL_DESGN_DTRMN]
 delete I6 from [ics_flow_local].[ICS_MASTER_GNRL_PRMT] [ICS_MASTER_GNRL_PRMT]    JOIN [ics_flow_local].[ICS_RESIDUAL_DESGN_DTRMN] [I6]   ON [I6].[ICS_MASTER_GNRL_PRMT_ID] = [ICS_MASTER_GNRL_PRMT].[ICS_MASTER_GNRL_PRMT_ID]   
-- /[ics_flow_local].[ICS_PRMT_FEATR]/[ics_flow_local].[ICS_COOLING_WTR_INTAKE_STRCT_INFO]
 delete I3 from [ics_flow_local].[ICS_PRMT_FEATR] [ICS_PRMT_FEATR]    JOIN [ics_flow_local].[ICS_COOLING_WTR_INTAKE_STRCT_INFO] [I3]   ON [I3].[ICS_PRMT_FEATR_ID] = [ICS_PRMT_FEATR].[ICS_PRMT_FEATR_ID]   
-- /[ics_flow_local].[ICS_PRMT_FEATR]/[ics_flow_local].[ICS_COOLING_WTR_INTAKE_STRCT_INFO]/[ics_flow_local].[ICS_COOLING_WTR_INTAKE_STRCT_CMPL_METHOD]
 delete I4 from [ics_flow_local].[ICS_PRMT_FEATR] [ICS_PRMT_FEATR]    JOIN [ics_flow_local].[ICS_COOLING_WTR_INTAKE_STRCT_INFO] [I3]   ON [I3].[ICS_PRMT_FEATR_ID] = [ICS_PRMT_FEATR].[ICS_PRMT_FEATR_ID]    JOIN [ics_flow_local].[ICS_COOLING_WTR_INTAKE_STRCT_CMPL_METHOD] [I4]   ON [I4].[ICS_COOLING_WTR_INTAKE_STRCT_INFO_ID] = [I3].[ICS_COOLING_WTR_INTAKE_STRCT_INFO_ID]   
-- /[ics_flow_local].[ICS_PRMT_FEATR]/[ics_flow_local].[ICS_POLUT_LIST]
 delete I5 from [ics_flow_local].[ICS_PRMT_FEATR] [ICS_PRMT_FEATR]    JOIN [ics_flow_local].[ICS_POLUT_LIST] [I5]   ON [I5].[ICS_PRMT_FEATR_ID] = [ICS_PRMT_FEATR].[ICS_PRMT_FEATR_ID]   
-- /[ics_flow_local].[ICS_PRMT_FEATR]/[ics_flow_local].[ICS_POLUT_LIST]/[ics_flow_local].[ICS_IMPAIRED_WTR_POLLUTANTS]
 delete I6 from [ics_flow_local].[ICS_PRMT_FEATR] [ICS_PRMT_FEATR]    JOIN [ics_flow_local].[ICS_POLUT_LIST] [I5]   ON [I5].[ICS_PRMT_FEATR_ID] = [ICS_PRMT_FEATR].[ICS_PRMT_FEATR_ID]    JOIN [ics_flow_local].[ICS_IMPAIRED_WTR_POLLUTANTS] [I6]   ON [I6].[ICS_POLUT_LIST_ID] = [I5].[ICS_POLUT_LIST_ID]   
-- /[ics_flow_local].[ICS_PRMT_FEATR]/[ics_flow_local].[ICS_POLUT_LIST]/[ics_flow_local].[ICS_TMDL_POLLUTANTS]
 delete I7 from [ics_flow_local].[ICS_PRMT_FEATR] [ICS_PRMT_FEATR]    JOIN [ics_flow_local].[ICS_POLUT_LIST] [I5]   ON [I5].[ICS_PRMT_FEATR_ID] = [ICS_PRMT_FEATR].[ICS_PRMT_FEATR_ID]    JOIN [ics_flow_local].[ICS_TMDL_POLLUTANTS] [I7]   ON [I7].[ICS_POLUT_LIST_ID] = [I5].[ICS_POLUT_LIST_ID]   
-- /[ics_flow_local].[ICS_PRMT_FEATR]/[ics_flow_local].[ICS_POLUT_LIST]/[ics_flow_local].[ICS_TMDL_POLLUTANTS]/[ics_flow_local].[ICS_TMDL_POLUT]
 delete I8 from [ics_flow_local].[ICS_PRMT_FEATR] [ICS_PRMT_FEATR]    JOIN [ics_flow_local].[ICS_POLUT_LIST] [I5]   ON [I5].[ICS_PRMT_FEATR_ID] = [ICS_PRMT_FEATR].[ICS_PRMT_FEATR_ID]    JOIN [ics_flow_local].[ICS_TMDL_POLLUTANTS] [I7]   ON [I7].[ICS_POLUT_LIST_ID] = [I5].[ICS_POLUT_LIST_ID]    JOIN [ics_flow_local].[ICS_TMDL_POLUT] [I8]   ON [I8].[ICS_TMDL_POLLUTANTS_ID] = [I7].[ICS_TMDL_POLLUTANTS_ID]   
-- /[ics_flow_local].[ICS_PRETR_PRMT]/[ics_flow_local].[ICS_PRETR_PROG_MOD]
 delete I3 from [ics_flow_local].[ICS_PRETR_PRMT] [ICS_PRETR_PRMT]    JOIN [ics_flow_local].[ICS_PRETR_PROG_MOD] [I3]   ON [I3].[ICS_PRETR_PRMT_ID] = [ICS_PRETR_PRMT].[ICS_PRETR_PRMT_ID]   
-- /[ics_flow_local].[ICS_SW_CNST_PRMT]/[ics_flow_local].[ICS_PROPOSED_CNST_SW_BM_PS]
 delete I3 from [ics_flow_local].[ICS_SW_CNST_PRMT] [ICS_SW_CNST_PRMT]    JOIN [ics_flow_local].[ICS_PROPOSED_CNST_SW_BM_PS] [I3]   ON [I3].[ICS_SW_CNST_PRMT_ID] = [ICS_SW_CNST_PRMT].[ICS_SW_CNST_PRMT_ID]   
-- /[ics_flow_local].[ICS_SW_CNST_PRMT]/[ics_flow_local].[ICS_PROPOSED_POST_CNST_SW_BM_PS]
 delete I4 from [ics_flow_local].[ICS_SW_CNST_PRMT] [ICS_SW_CNST_PRMT]    JOIN [ics_flow_local].[ICS_PROPOSED_POST_CNST_SW_BM_PS] [I4]   ON [I4].[ICS_SW_CNST_PRMT_ID] = [ICS_SW_CNST_PRMT].[ICS_SW_CNST_PRMT_ID]   
-- /[ics_flow_local].[ICS_SW_CNST_PRMT]/[ics_flow_local].[ICS_GPCF_NOTICE_OF_INTENT]/[ics_flow_local].[ICS_SUBSECTOR_CODE_PLUS_DESC]
 delete I6 from [ics_flow_local].[ICS_SW_CNST_PRMT] [ICS_SW_CNST_PRMT]    JOIN [ics_flow_local].[ICS_GPCF_NOTICE_OF_INTENT] [I5]   ON [I5].[ICS_SW_CNST_PRMT_ID] = [ICS_SW_CNST_PRMT].[ICS_SW_CNST_PRMT_ID]    JOIN [ics_flow_local].[ICS_SUBSECTOR_CODE_PLUS_DESC] [I6]   ON [I6].[ICS_GPCF_NOTICE_OF_INTENT_ID] = [I5].[ICS_GPCF_NOTICE_OF_INTENT_ID]   
-- /[ics_flow_local].[ICS_SW_CNST_PRMT]/[ics_flow_local].[ICS_CNST_SITE_LIST]
 delete I10 from [ics_flow_local].[ICS_SW_CNST_PRMT] [ICS_SW_CNST_PRMT]    JOIN [ics_flow_local].[ICS_CNST_SITE_LIST] [I10]   ON [I10].[ICS_SW_CNST_PRMT_ID] = [ICS_SW_CNST_PRMT].[ICS_SW_CNST_PRMT_ID]   
-- /[ics_flow_local].[ICS_SW_CNST_PRMT]/[ics_flow_local].[ICS_CNST_SITE_LIST]/[ics_flow_local].[ICS_CNST_SITE]
 delete I11 from [ics_flow_local].[ICS_SW_CNST_PRMT] [ICS_SW_CNST_PRMT]    JOIN [ics_flow_local].[ICS_CNST_SITE_LIST] [I10]   ON [I10].[ICS_SW_CNST_PRMT_ID] = [ICS_SW_CNST_PRMT].[ICS_SW_CNST_PRMT_ID]    JOIN [ics_flow_local].[ICS_CNST_SITE] [I11]   ON [I11].[ICS_CNST_SITE_LIST_ID] = [I10].[ICS_CNST_SITE_LIST_ID]   
-- /[ics_flow_local].[ICS_SW_INDST_PRMT]/[ics_flow_local].[ICS_PROPOSED_INDST_SW_BM_PS]
 delete I3 from [ics_flow_local].[ICS_SW_INDST_PRMT] [ICS_SW_INDST_PRMT]    JOIN [ics_flow_local].[ICS_PROPOSED_INDST_SW_BM_PS] [I3]   ON [I3].[ICS_SW_INDST_PRMT_ID] = [ICS_SW_INDST_PRMT].[ICS_SW_INDST_PRMT_ID]   
-- /[ics_flow_local].[ICS_SW_INDST_PRMT]/[ics_flow_local].[ICS_GPCF_NOTICE_OF_INTENT]/[ics_flow_local].[ICS_SUBSECTOR_CODE_PLUS_DESC]
 delete I6 from [ics_flow_local].[ICS_SW_INDST_PRMT] [ICS_SW_INDST_PRMT]    JOIN [ics_flow_local].[ICS_GPCF_NOTICE_OF_INTENT] [I5]   ON [I5].[ICS_SW_INDST_PRMT_ID] = [ICS_SW_INDST_PRMT].[ICS_SW_INDST_PRMT_ID]    JOIN [ics_flow_local].[ICS_SUBSECTOR_CODE_PLUS_DESC] [I6]   ON [I6].[ICS_GPCF_NOTICE_OF_INTENT_ID] = [I5].[ICS_GPCF_NOTICE_OF_INTENT_ID]   
 

update ics_flow_local.ICS_ANML_TYPE SET LIQUID_MNUR_HANDLING_SYSTM = NULL ;
update ics_flow_local.ICS_BASIC_PRMT SET INDST_USR_TYPE_CODE = NULL ;
update ics_flow_local.ICS_BS_ANNUL_PROG_REP SET BS_ANNUL_PROG_REP_CMNT_TXT = NULL ;
update ics_flow_local.ICS_BS_ANNUL_PROG_REP SET BS_FAC_TRTMNT_OTHR_TXT = NULL ;
update ics_flow_local.ICS_BS_ANNUL_PROG_REP SET BS_FAC_TTL_VOL_AMT = NULL ;
update ics_flow_local.ICS_BS_ANNUL_PROG_REP SET BS_FAC_TYPE_OTHR_TXT = NULL ;
update ics_flow_local.ICS_BS_ANNUL_PROG_REP SET PROG_REP_END_DATE = NULL ;
update ics_flow_local.ICS_BS_ANNUL_PROG_REP SET PROG_REP_NPDES_DAT_GRP_NUM_CODE = NULL ;
update ics_flow_local.ICS_BS_ANNUL_PROG_REP SET PROG_REP_RCVD_DATE = NULL ;
update ics_flow_local.ICS_BS_ANNUL_PROG_REP SET PROG_REP_START_DATE = NULL ;
update ics_flow_local.ICS_BS_PRMT SET BS_FAC_TRTMNT_OTHR_TXT = NULL ;
update ics_flow_local.ICS_BS_PRMT SET BS_FAC_TTL_VOL_AMT = NULL ;
update ics_flow_local.ICS_BS_PRMT SET BS_FAC_TYPE_OTHR_TXT = NULL ;
update ics_flow_local.ICS_CAFO_INSP SET CAFO_DSCH_DRNG_YEAR_TXT = NULL ;
update ics_flow_local.ICS_CAFO_INSP SET DSCH_DRNG_YEAR_LAND_APPL_AREA_IND = NULL ;
update ics_flow_local.ICS_FINAL_ORDER SET CASH_CIVIL_PNLTY_COLL_AMT = NULL ;
update ics_flow_local.ICS_LMTS SET LMT_MOD_TYPE_STAY_REASON_TXT = NULL ;
update ics_flow_local.ICS_MNUR_LTTR_PRCSS_WW_STOR SET CAFOMLPW_STOR_WITHIN_DSGN_CPCTY = NULL ;
update ics_flow_local.ICS_MNUR_LTTR_PRCSS_WW_STOR SET CAFOMLPW_STOR_WITHIN_DSGN_CPCTY_TXT = NULL ;
update ics_flow_local.ICS_MNUR_LTTR_PRCSS_WW_STOR SET CAFOMLPW_UNIT = NULL ;
update ics_flow_local.ICS_PRETR_PRMT SET RCVG_RCRA_WASTE_IND = NULL ;
update ics_flow_local.ICS_PRETR_PRMT SET RCVG_REMEDIATION_WASTE_IND = NULL ;
update ics_flow_local.ICS_SURF_DSPL_SITE SET MGMT_PRACTICE_IND = NULL ;
update ics_flow_local.ICS_SW_CNST_PRMT SET CNST_SITE_TTL_AREA = NULL ;
update ics_flow_local.ICS_SW_CNST_PRMT SET LEW_AUTH_DATE = NULL ;
update ics_flow_local.ICS_SW_CNST_PRMT SET NOT_POSTMARK_DATE = NULL ;
update ics_flow_local.ICS_SW_CNST_PRMT SET NOT_RCVD_DATE = NULL ;
update ics_flow_local.ICS_SW_CNST_PRMT SET NOT_SIGN_DATE = NULL ;
update ics_flow_local.ICS_SW_CNST_PRMT SET NOT_TERM_DATE = NULL ;
update ics_flow_local.ICS_SW_CNST_PRMT SET POST_CNST_TTL_IMPERVIOUS_AREA = NULL ;
update ics_flow_local.ICS_SW_CNST_PRMT SET RUNOFF_COEFFICIENT_POST_CNST = NULL ;
update ics_flow_local.ICS_SW_CNST_PRMT SET SOIL_FILL_MATERIAL_DESC_TXT = NULL ;
update ics_flow_local.ICS_SW_CNST_PRMT SET SUBSURFACE_ERTH_DISTURBANCE_CONTROL_IND = NULL ;
update ics_flow_local.ICS_SW_CNST_PRMT SET SUBSURFACE_ERTH_DISTURBANCE_IND = NULL ;
update ics_flow_local.ICS_SW_INDST_PRMT SET INDST_TTL_IMPERVIOUS_SURF_AREA = NULL ;
 
 END
 GO
 
 