 IF NOT EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND OBJECT_ID = OBJECT_ID('ics_flow_local.ICS_SET_HASHES'))
  EXEC('CREATE PROCEDURE [ICS_FLOW_LOCAL].[ICS_SET_HASHES] AS BEGIN SET NOCOUNT ON; END')
GO

/*
Copyright (c) 2012, The Environmental Council of the States (ECOS)
All rights reserved.
 
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
 
 * Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
 * Neither the name of the ECOS nor the names of its contributors may
   be used to endorse or promote products derived from this software
   without specific prior written permission.
 
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/

/******************************************************************************************************************************
** ObjectName: ics_flow_local.ICS_SET_HASHES
**
** Author: Windsor Solutions, Inc.
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure will detect data changes made within the ICIS 5.8 schema and then sets the transaction type
**               flags so the data can be bundled and submitted to an exchange partner.
**
** Inputs:  -- NA --  
**
**
** Revision History:      
** ----------------------------------------------------------------------------------------------------------------------------
**  Date         Analyst     Description
** ----------------------------------------------------------------------------------------------------------------------------
** 06/12/2017    Windsor     Baselined from v5.6 procedure. 
** 08/05/2019    TConrad/CRT ENFLOW-9: Add the key_hash to the where clause of each sub-select to improve perf of roll-up data 
** 04/06/2025    CTyler      Update to v5.14
******************************************************************************************************************************/
ALTER PROCEDURE ics_flow_local.ICS_SET_HASHES AS

SET NOCOUNT ON;

DECLARE @v_sql_statement AS NVARCHAR(4000);
DECLARE @v_sql_param AS NVARCHAR(100);
DECLARE @p_payload_type AS NVARCHAR(50); 

/* Working Hash Variables */
--DECLARE @v_data_hash AS VARCHAR(100);
DECLARE @v_key_hash AS VARCHAR(100);
DECLARE @v_all_data_hashes AS VARCHAR(100);  
DECLARE @v_hashed_data_hashes AS VARCHAR(100); 
DECLARE @v_enabled AS CHAR(1);
DECLARE @v_working_data_hash AS VARCHAR(100);

DECLARE payload_type_process CURSOR 
    FOR SELECT DISTINCT child_table.name child_table_name 
          FROM sys.foreign_key_columns
          JOIN sys.objects child_table
            ON (child_table.object_id = sys.foreign_key_columns.parent_object_id)
          JOIN sys.objects parent_table
            ON (parent_table.object_id = sys.foreign_key_columns.referenced_object_id)
          JOIN sys.schemas
            ON (parent_table.schema_id = sys.schemas.schema_id)    
         WHERE sys.schemas.name = 'dbo'
           AND parent_table.name = 'ICS_PAYLOAD'
           /* The tables in this list will not have related child data, change processing can be skipped */
           AND child_table.name NOT IN ( 'ICS_BS_PROG_REP'
                                       , 'ICS_CSO_EVT_REP'
                                       , 'ICS_DMR_VIOL'
                                       , 'ICS_ENFRC_ACTN_MILESTONE'
                                       , 'ICS_HIST_PRMT_SCHD_EVTS'
                                       , 'ICS_PRMT_REISSU'
                                       , 'ICS_PRMT_TRACK_EVT'
                                       , 'ICS_PRMT_TERM'
                                       , 'ICS_SCHD_EVT_VIOL'
                                       , 'ICS_SNGL_EVT_VIOL'
                                       , 'ICS_SSO_ANNUL_REP'
                                       , 'ICS_SSO_MONTHLY_EVT_REP'
                                       , 'ICS_SW_INDST_ANNUL_REP')
         ORDER BY child_table.name; 
          
                        
DECLARE key_hash CURSOR 
    FOR SELECT key_hash 
          FROM ics_flow_local.ics_key_hash;
                        
BEGIN

 /*  Initialize working table ICS_KEY_HASH */
 DELETE FROM ics_flow_local.ics_key_hash;
 
-- -=-=-=-=-=-=- START COPY TO INDICATED SECTION IN ICS_SET_HASHES -=-=-=-=-=-=-=-=-=
 /*************************************************/  
  /* START - Set all KEY_HASH and DATA_HASH fields */
  /*************************************************/  

UPDATE ICS_FLOW_LOCAL.ics_addr
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  affil_type_txt
	+ org_frml_name
	+ ISNULL(org_duns_num,'')
	+ mailing_addr_txt
	+ ISNULL(suppl_addr_txt,'')
	+ mailing_addr_city_name
	+ mailing_addr_st_code
	+ mailing_addr_zip_code
	+ ISNULL(county_name,'')
	+ ISNULL(mailing_addr_country_code,'')
	+ ISNULL(division_name,'')
	+ ISNULL(loc_province,'')
	+ ISNULL(elec_addr_txt,'')
	+ ISNULL(CONVERT(varchar(50), start_date_of_addr_assc),'')
	+ ISNULL(CONVERT(varchar(50), end_date_of_addr_assc),'')
);
UPDATE ICS_FLOW_LOCAL.ics_anlytcl_method
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  anlytcl_method_type_code
	+ ISNULL(anlytcl_method_othr_type_txt,'')
);
UPDATE ICS_FLOW_LOCAL.ics_anml_type
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  anml_type_code
	+ ISNULL(othr_anml_type_name,'')
	+ ISNULL(CONVERT(varchar(50), ttl_num_each_lvstck),'')
	+ ISNULL(CONVERT(varchar(50), open_confinemnt_cnt),'')
	+ ISNULL(CONVERT(varchar(50), housd_undr_roof_confinemnt_cnt),'')
	+ ISNULL(liquid_mnur_handling_systm,'')
);
UPDATE ICS_FLOW_LOCAL.ics_assc_prmt
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(assc_prmt_ident,'')
	+ assc_prmt_reason_code
);
UPDATE ICS_FLOW_LOCAL.ics_basic_prmt
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', ICS_FLOW_LOCAL.ics_basic_prmt.prmt_ident),
      data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ ISNULL(prmt_type_code,'')
	+ ISNULL(agncy_type_code,'')
	+ ISNULL(prmt_stat_code,'')
	+ ISNULL(CONVERT(varchar(50), prmt_issue_date),'')
	+ ISNULL(CONVERT(varchar(50), prmt_effective_date),'')
	+ ISNULL(CONVERT(varchar(50), prmt_expr_date),'')
	+ ISNULL(reissu_prio_prmt_ind,'')
	+ ISNULL(backlog_reason_txt,'')
	+ ISNULL(prmt_issuing_org_type_name,'')
	+ ISNULL(prmt_appealed_ind,'')
	+ ISNULL(prmt_usr_dfnd_dat_elm_1_txt,'')
	+ ISNULL(prmt_usr_dfnd_dat_elm_2_txt,'')
	+ ISNULL(prmt_usr_dfnd_dat_elm_3_txt,'')
	+ ISNULL(prmt_usr_dfnd_dat_elm_4_txt,'')
	+ ISNULL(prmt_usr_dfnd_dat_elm_5_txt,'')
	+ ISNULL(prmt_cmnts_txt,'')
	+ ISNULL(CONVERT(varchar(50), major_minor_rating_code),'')
	+ ISNULL(CONVERT(varchar(50), ttl_appl_dsgn_flow_num),'')
	+ ISNULL(CONVERT(varchar(50), ttl_appl_aver_flow_num),'')
	+ ISNULL(CONVERT(varchar(50), appl_rcvd_date),'')
	+ ISNULL(CONVERT(varchar(50), prmt_appl_cmpl_date),'')
	+ ISNULL(new_src_ind,'')
	+ ISNULL(prmt_st_wtr_body_code,'')
	+ ISNULL(prmt_st_wtr_body_name,'')
	+ ISNULL(fedr_grant_ind,'')
	+ ISNULL(dmr_cognznt_ofcl,'')
	+ ISNULL(dmr_cognznt_ofcl_teleph_num,'')
	+ ISNULL(sig_iu_ind,'')
	+ ISNULL(rcvg_prmt_ident,'')
	+ ISNULL(indst_usr_type_code,'')
	+ ISNULL(elec_rep_waiver_type_code,'')
	+ ISNULL(CONVERT(varchar(50), elec_rep_waiver_effective_date),'')
	+ ISNULL(CONVERT(varchar(50), elec_rep_waiver_expr_date),'')
	+ ISNULL(major_minor_stat_ind,'')
	+ ISNULL(CONVERT(varchar(50), major_minor_stat_start_date),'')
	+ ISNULL(dmr_non_rcpt_stat_ind,'')
	+ ISNULL(CONVERT(varchar(50), dmr_non_rcpt_stat_start_date),'')
);
UPDATE ICS_FLOW_LOCAL.ics_bs_annul_prog_rep
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', prmt_ident + PROG_REP_FORM_SET_ID + CONVERT(varchar(50), PROG_REP_FORM_ID) ),
      data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	   ISNULL(prmt_ident,'')
	+ ISNULL(CONVERT(varchar(50), prog_rep_rcvd_date),'')
	+ ISNULL(CONVERT(varchar(50), prog_rep_start_date),'')
	+ ISNULL(CONVERT(varchar(50), prog_rep_end_date),'')
	+ ISNULL(elec_subm_type_code,'')
	+ ISNULL(prog_rep_npdes_dat_grp_num_code,'')
	+ ISNULL(bs_fac_type_othr_txt,'')
	+ ISNULL(CONVERT(varchar(50), bs_fac_ttl_vol_amt),'')
	+ ISNULL(bs_fac_trtmnt_othr_txt,'')
	+ ISNULL(bs_annul_prog_rep_cmnt_txt,'')
);
UPDATE ICS_FLOW_LOCAL.ics_bs_fac_trtmnt
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  bs_fac_trtmnt_code
);
UPDATE ICS_FLOW_LOCAL.ics_bs_fac_type
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  bs_fac_type_code
);
UPDATE ICS_FLOW_LOCAL.ics_bs_incin_emissions_control_type
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  bs_emissions_control_catg
	+ bs_emissions_control_technology_code
	+ ISNULL(bs_emissions_control_othr_txt,'')
);
UPDATE ICS_FLOW_LOCAL.ics_bs_incineration
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  bs_incin_ident
	+ ISNULL(bs_incin_type_code,'')
	+ ISNULL(bs_incin_othr_txt,'')
	+ ISNULL(CONVERT(varchar(50), bs_incin_last_sig_change_date),'')
	+ ISNULL(bs_incin_new_polut_lmts_ind,'')
);
UPDATE ICS_FLOW_LOCAL.ics_bs_mgmt_practice
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  ssu_ident
	+ ISNULL(bs_mgmt_practice_code,'')
	+ ISNULL(bs_mgmt_practice_sub_catg_code,'')
	+ ISNULL(bs_mgmt_practice_sub_catg_txt,'')
	+ ISNULL(bs_operator_type_code,'')
	+ ISNULL(bs_cntnr_type_code,'')
	+ ISNULL(CONVERT(varchar(50), ssuid_vol_amt),'')
	+ ISNULL(pathogen_class_type_code,'')
	+ ISNULL(polut_loading_rates_exceedance_ind,'')
	+ ISNULL(bs_mgmt_practice_viol_type_code,'')
	+ ISNULL(bs_mgmt_practice_viol_txt,'')
	+ ISNULL(bs_off_site_fac_prmt_ident,'')
	+ ISNULL(surf_dspl_without_liner_ind,'')
	+ ISNULL(surf_dspl_site_spec_lmt_ind,'')
	+ ISNULL(surf_dspl_min_boundary_distance_code,'')
);
UPDATE ICS_FLOW_LOCAL.ics_bs_off_site_hndlr_applier_prepr
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(CONVERT(varchar(50), bs_off_site_hndlr_applier_vol_amt),'')
);
UPDATE ICS_FLOW_LOCAL.ics_bs_prmt
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', ICS_FLOW_LOCAL.ics_bs_prmt.prmt_ident),
      data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ ISNULL(bs_fac_type_othr_txt,'')
	+ ISNULL(CONVERT(varchar(50), bs_fac_ttl_vol_amt),'')
	+ ISNULL(bs_fac_trtmnt_othr_txt,'')
);
UPDATE ICS_FLOW_LOCAL.ics_bs_sewage_sldg_param
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  CONVERT(varchar(50), bs_sewage_sldg_param_code)
	+ ISNULL(CONVERT(varchar(50), bs_sewage_sldg_param_lmt),'')
	+ ISNULL(param_value,'')
	+ ISNULL(value_qualifier,'')
	+ ISNULL(no_dat_ind_code,'')
	+ ISNULL(pass_fail_ind_code,'')
	+ ISNULL(pathogen_reduction_type_code,'')
	+ ISNULL(CONVERT(varchar(50), bs_smpl_start_date),'')
	+ ISNULL(CONVERT(varchar(50), bs_smpl_end_date),'')
	+ ISNULL(bs_smpl_mn,'')
);
UPDATE ICS_FLOW_LOCAL.ics_bypass_trtmnt_plant_equipment
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  bypass_trtmnt_plant_equipment_code
);
UPDATE ICS_FLOW_LOCAL.ics_cafo_annul_prog_rep
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', prmt_ident + PROG_REP_FORM_SET_ID + CONVERT(varchar(50), PROG_REP_FORM_ID) ),
      data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ ISNULL(CONVERT(varchar(50), prog_rep_rcvd_date),'')
	+ ISNULL(CONVERT(varchar(50), prog_rep_start_date),'')
	+ ISNULL(CONVERT(varchar(50), prog_rep_end_date),'')
	+ ISNULL(elec_subm_type_code,'')
	+ ISNULL(prog_rep_npdes_dat_grp_num_code,'')
	+ ISNULL(CONVERT(varchar(50), nutr_mgmt_plan_acreage_num),'')
	+ ISNULL(CONVERT(varchar(50), actul_land_appl_acreage_num),'')
	+ ISNULL(nmp_cert_plnr_ind,'')
);
UPDATE ICS_FLOW_LOCAL.ics_cafo_insp
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(cafo_class_code,'')
	+ ISNULL(is_anml_fac_type_cafo_ind,'')
	+ ISNULL(CONVERT(varchar(50), cafo_desgn_date),'')
	+ ISNULL(cafo_desgn_reason_txt,'')
	+ ISNULL(dsch_drng_year_prod_area_ind,'')
	+ ISNULL(dsch_drng_year_land_appl_area_ind,'')
	+ ISNULL(cafo_dsch_drng_year_txt,'')
	+ ISNULL(CONVERT(varchar(50), num_acres_contrb_drain),'')
	+ ISNULL(CONVERT(varchar(50), appl_meas_avail_land_num),'')
	+ ISNULL(CONVERT(varchar(50), solid_mnur_lttr_gnrtd_amt),'')
	+ ISNULL(CONVERT(varchar(50), liquid_mnur_ww_gnrtd_amt),'')
	+ ISNULL(CONVERT(varchar(50), solid_mnur_lttr_trans_amt),'')
	+ ISNULL(CONVERT(varchar(50), liquid_mnur_ww_trans_amt),'')
	+ ISNULL(nmp_dvlpd_cert_plnr_aprvd_ind,'')
	+ ISNULL(CONVERT(varchar(50), nmp_dvlpd_date),'')
	+ ISNULL(CONVERT(varchar(50), nmp_last_updated_date),'')
	+ ISNULL(envr_mgmt_systm_ind,'')
	+ ISNULL(CONVERT(varchar(50), ems_dvlpd_date),'')
	+ ISNULL(CONVERT(varchar(50), ems_last_updated_date),'')
	+ ISNULL(CONVERT(varchar(50), lvstck_max_cpcty_num),'')
	+ ISNULL(CONVERT(varchar(50), lvstck_cpcty_dtrmn_bs_upon_num),'')
	+ ISNULL(CONVERT(varchar(50), auth_lvstck_cpcty_num),'')
);
UPDATE ICS_FLOW_LOCAL.ics_cafo_insp_viol_type
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  cafo_insp_viol_type_code
);
UPDATE ICS_FLOW_LOCAL.ics_cafo_land_appl_fld_info
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  cafo_land_appl_fld_ident
	+ ISNULL(CONVERT(varchar(50), cafo_land_appl_fld_acreage),'')
	+ ISNULL(cafomlpw_max_amt_method,'')
	+ cafo_land_appl_fld_crop_ident
	+ ISNULL(cafo_land_appl_fld_crop_code,'')
	+ ISNULL(CONVERT(varchar(50), cafo_land_appl_fld_crop_yield),'')
	+ ISNULL(cafo_land_appl_fld_crop_yield_unit,'')
	+ ISNULL(cafo_land_appl_fld_crop_seeded,'')
	+ cafo_soil_mon_meas_form
	+ ISNULL(CONVERT(varchar(50), cafo_soil_mon_meas_value),'')
	+ ISNULL(cafo_soil_mon_meas_value_unit,'')
	+ ISNULL(cafo_soil_mon_anlytcl_method,'')
	+ ISNULL(CONVERT(varchar(50), cafo_soil_mon_smpl_depth_inches),'')
	+ ISNULL(CONVERT(varchar(50), cafo_soil_mon_smpl_date),'')
	+ cafo_suppl_fertilizer_meas_form
	+ ISNULL(CONVERT(varchar(50), cafo_suppl_fertilizer_meas_value),'')
	+ ISNULL(cafo_suppl_fertilizer_meas_value_unit,'')
);
UPDATE ICS_FLOW_LOCAL.ics_cafo_prmt
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', ICS_FLOW_LOCAL.ics_cafo_prmt.prmt_ident),
      data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ ISNULL(cafo_class_code,'')
	+ ISNULL(is_anml_fac_type_cafo_ind,'')
	+ ISNULL(CONVERT(varchar(50), cafo_desgn_date),'')
	+ ISNULL(cafo_desgn_reason_txt,'')
	+ ISNULL(CONVERT(varchar(50), num_acres_contrb_drain),'')
	+ ISNULL(CONVERT(varchar(50), appl_meas_avail_land_num),'')
	+ ISNULL(CONVERT(varchar(50), solid_mnur_lttr_gnrtd_amt),'')
	+ ISNULL(CONVERT(varchar(50), liquid_mnur_ww_gnrtd_amt),'')
	+ ISNULL(CONVERT(varchar(50), solid_mnur_lttr_trans_amt),'')
	+ ISNULL(CONVERT(varchar(50), liquid_mnur_ww_trans_amt),'')
	+ ISNULL(nmp_dvlpd_cert_plnr_aprvd_ind,'')
	+ ISNULL(CONVERT(varchar(50), nmp_dvlpd_date),'')
	+ ISNULL(CONVERT(varchar(50), nmp_last_updated_date),'')
	+ ISNULL(envr_mgmt_systm_ind,'')
	+ ISNULL(CONVERT(varchar(50), ems_dvlpd_date),'')
	+ ISNULL(CONVERT(varchar(50), ems_last_updated_date),'')
	+ ISNULL(CONVERT(varchar(50), lvstck_max_cpcty_num),'')
	+ ISNULL(CONVERT(varchar(50), lvstck_cpcty_dtrmn_bs_upon_num),'')
	+ ISNULL(CONVERT(varchar(50), auth_lvstck_cpcty_num),'')
	+ ISNULL(legal_desc_txt,'')
);
UPDATE ICS_FLOW_LOCAL.ics_cafo_prod_area_dsch
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  CONVERT(varchar(50), cafo_prod_area_dsch_discovery_date)
	+ ISNULL(cafo_prod_area_dsch_24hr_rain_evt_ind,'')
	+ ISNULL(CONVERT(varchar(50), cafo_prod_area_dsch_duration_hours),'')
	+ ISNULL(CONVERT(varchar(50), cafo_prod_area_dsch_vol_gal),'')
);
UPDATE ICS_FLOW_LOCAL.ics_cafomlpw_fld_amounts
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  cafomlpw_code
	+ ISNULL(CONVERT(varchar(50), cafomlpw_fld_max_allowable_amt),'')
	+ ISNULL(CONVERT(varchar(50), cafomlpw_fld_actul_amt),'')
	+ ISNULL(cafomlpw_land_appl_unit,'')
);
UPDATE ICS_FLOW_LOCAL.ics_cafomlpw_nutr_mon
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  cafomlpw_code
	+ ISNULL(cafomlpw_nutr_form,'')
	+ ISNULL(CONVERT(varchar(50), cafomlpw_nutr_value),'')
	+ ISNULL(cafomlpw_nutr_value_unit,'')
);
UPDATE ICS_FLOW_LOCAL.ics_cafomlpw_ttl_amounts
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  cafomlpw_code
	+ ISNULL(CONVERT(varchar(50), cafomlpw_amt_gnrtd),'')
	+ ISNULL(CONVERT(varchar(50), cafomlpw_amt_transferred),'')
	+ ISNULL(cafomlpw_unit,'')
);
UPDATE ICS_FLOW_LOCAL.ics_cmpl_insp_type
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  cmpl_insp_type_code
);
UPDATE ICS_FLOW_LOCAL.ics_cmpl_mon
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', cmpl_mon_ident),
      data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	   cmpl_mon_ident
	+ ISNULL(prmt_ident,'')
	+ ISNULL(cmpl_mon_acty_type_code,'')
	+ ISNULL(cmpl_mon_catg_code,'')
	+ ISNULL(CONVERT(varchar(50), cmpl_mon_date),'')
	+ ISNULL(CONVERT(varchar(50), cmpl_mon_start_date),'')
	+ ISNULL(cmpl_mon_acty_name,'')
	+ ISNULL(biomon_insp_method,'')
	+ ISNULL(CONVERT(varchar(50), cmpl_mon_agncy_code),'')
	+ ISNULL(st_statute_viol_name,'')
	+ ISNULL(epa_assist_ind,'')
	+ ISNULL(st_fedr_joint_ind,'')
	+ ISNULL(joint_insp_reason_code,'')
	+ ISNULL(lead_party,'')
	+ ISNULL(CONVERT(varchar(50), num_days_phys_cond_acty),'')
	+ ISNULL(CONVERT(varchar(50), num_hours_phys_cond_acty),'')
	+ ISNULL(CONVERT(varchar(50), cmpl_mon_actn_outcome_code),'')
	+ ISNULL(insp_rating_code,'')
	+ ISNULL(multimedia_ind,'')
	+ ISNULL(fedr_fac_ind,'')
	+ ISNULL(fedr_fac_ind_cmnt,'')
	+ ISNULL(insp_usr_dfnd_fld_1,'')
	+ ISNULL(insp_usr_dfnd_fld_2,'')
	+ ISNULL(insp_usr_dfnd_fld_3,'')
	+ ISNULL(CONVERT(varchar(50), insp_usr_dfnd_fld_4),'')
	+ ISNULL(CONVERT(varchar(50), insp_usr_dfnd_fld_5),'')
	+ ISNULL(insp_usr_dfnd_fld_6,'')
	+ ISNULL(CONVERT(varchar(50), cmpl_mon_planned_start_date),'')
	+ ISNULL(CONVERT(varchar(50), cmpl_mon_planned_end_date),'')
);
UPDATE ICS_FLOW_LOCAL.ics_cmpl_mon_actn_reason
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  cmpl_mon_actn_reason_code
);
UPDATE ICS_FLOW_LOCAL.ics_cmpl_mon_agncy_type
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  cmpl_mon_agncy_type_code
);
UPDATE ICS_FLOW_LOCAL.ics_cmpl_mon_evt
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  CONVERT(varchar(50), cmpl_mon_evt_ident)
	+ ISNULL(CONVERT(varchar(50), cmpl_mon_evt_start_date),'')
	+ ISNULL(CONVERT(varchar(50), cmpl_mon_evt_end_date),'')
);
UPDATE ICS_FLOW_LOCAL.ics_cmpl_mon_lnk
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	   cmpl_mon_ident
);
UPDATE ICS_FLOW_LOCAL.ics_cmpl_schd
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', CONVERT(varchar(50),ics_cmpl_schd.enfrc_actn_ident) + CONVERT(varchar(50),final_order_ident) + prmt_ident +CONVERT(varchar(50), cmpl_schd_num)),
      data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	   enfrc_actn_ident
	+ ISNULL(CONVERT(varchar(50), final_order_ident),'')
	+ prmt_ident
	+ CONVERT(varchar(50), cmpl_schd_num)
	+ ISNULL(cmpl_schd_cmnts,'')
	+ ISNULL(schd_desc_code,'')
);
UPDATE ICS_FLOW_LOCAL.ics_cmpl_schd_evt
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  schd_evt_code
	+ CONVERT(varchar(50), schd_date)
	+ ISNULL(CONVERT(varchar(50), schd_rep_rcvd_date),'')
	+ ISNULL(CONVERT(varchar(50), schd_actul_date),'')
	+ ISNULL(CONVERT(varchar(50), schd_proj_date),'')
	+ ISNULL(schd_usr_dfnd_dat_elm_1,'')
	+ ISNULL(schd_usr_dfnd_dat_elm_2,'')
	+ ISNULL(schd_evt_cmnts,'')
	+ ISNULL(CONVERT(varchar(50), cmpl_schd_pnlty_amt),'')
);
UPDATE ICS_FLOW_LOCAL.ics_cmpl_schd_evt_viol_elem
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  enfrc_actn_ident
	+ ISNULL(CONVERT(varchar(50), final_order_ident),'')
	+ prmt_ident
	+ CONVERT(varchar(50), cmpl_schd_num)
	+ schd_evt_code
	+ CONVERT(varchar(50), schd_date)
	+ schd_viol_code
);
UPDATE ICS_FLOW_LOCAL.ics_cmpl_schd_viol
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  enfrc_actn_ident
	+ ISNULL(CONVERT(varchar(50), final_order_ident),'')
	+ prmt_ident
	+ CONVERT(varchar(50), cmpl_schd_num)
	+ schd_evt_code
	+ CONVERT(varchar(50), schd_date)
);
UPDATE ICS_FLOW_LOCAL.ics_cmpl_track_stat
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(stat_code,'')
	+ ISNULL(CONVERT(varchar(50), stat_start_date),'')
	+ ISNULL(stat_reason,'')
);
UPDATE ICS_FLOW_LOCAL.ics_cnst_site
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  cnst_site_code
);
UPDATE ICS_FLOW_LOCAL.ics_cnst_site_list
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(cnst_site_othr_txt,'')
);
UPDATE ICS_FLOW_LOCAL.ics_co_dspl_site
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(part_258_cmpl_ind,'')
	+ ISNULL(paint_filter_test_result,'')
	+ ISNULL(tclp_test_result,'')
);
UPDATE ICS_FLOW_LOCAL.ics_coll_systm_prmt
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', prmt_ident + COLL_SYSTM_IDENT),
      data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ ISNULL(coll_systm_ident,'')
	+ ISNULL(coll_systm_name,'')
	+ ISNULL(coll_systm_owner_type_code,'')
	+ ISNULL(CONVERT(varchar(50), coll_systm_popl),'')
	+ ISNULL(CONVERT(varchar(50), percent_coll_systm_css),'')
);
UPDATE ICS_FLOW_LOCAL.ics_contact
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  affil_type_txt
	+ first_name
	+ ISNULL(middle_name,'')
	+ last_name
	+ indvl_title_txt
	+ ISNULL(org_frml_name,'')
	+ ISNULL(st_code,'')
	+ ISNULL(rgn_code,'')
	+ ISNULL(elec_addr_txt,'')
	+ ISNULL(CONVERT(varchar(50), start_date_of_contact_assc),'')
	+ ISNULL(CONVERT(varchar(50), end_date_of_contact_assc),'')
);
UPDATE ICS_FLOW_LOCAL.ics_containment
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  containment_type_code
	+ ISNULL(othr_containment_type_name,'')
	+ ISNULL(CONVERT(varchar(50), containment_cpcty_num),'')
);
UPDATE ICS_FLOW_LOCAL.ics_control_auth_prog_info
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(CONVERT(varchar(50), loc_lmts_adoption_date),'')
	+ ISNULL(CONVERT(varchar(50), loc_lmts_eval_date),'')
	+ potw_dsch_contamination_ind
	+ ISNULL(potw_dsch_contamination_txt,'')
	+ potw_bs_contamination_ind
	+ ISNULL(potw_bs_contamination_txt,'')
);
UPDATE ICS_FLOW_LOCAL.ics_cooling_wtr_intake_strct_cmpl_method
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  cooling_wtr_intake_strct_cmpl_method_code
	+ ISNULL(cooling_wtr_intake_strct_cmpl_method_txt,'')
);
UPDATE ICS_FLOW_LOCAL.ics_cooling_wtr_intake_strct_info
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(CONVERT(varchar(50), cooling_wtr_intake_strct_appl_subpart),'')
	+ ISNULL(CONVERT(varchar(50), cooling_wtr_intake_strct_dsgn_intake_flow),'')
	+ ISNULL(CONVERT(varchar(50), cooling_wtr_intake_strct_actul_intake_flow),'')
	+ ISNULL(CONVERT(varchar(50), cooling_wtr_actul_intake_strct_velocity),'')
	+ ISNULL(src_wtr_baseline_biological_characterization,'')
	+ cooling_wtr_intake_strct_loc_code
	+ ISNULL(cooling_wtr_intake_strct_loc_txt,'')
	+ cooling_wtr_intake_strct_src_wtr_code
	+ ISNULL(cooling_wtr_intake_strct_src_wtr_txt,'')
);
UPDATE ICS_FLOW_LOCAL.ics_copy_mgp_lmt_set
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', prmt_ident + prmt_featr_ident + lmt_set_designator),
   -- key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', prmt_ident + prmt_featr_ident + lmt_set_designator + trgt_gnrl_prmt_ident + trgt_gnrl_prmt_featr_ident + trgt_gnrl_lmt_set_designator),
       data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ prmt_featr_ident
	+ lmt_set_designator
	+ ISNULL(trgt_gnrl_prmt_ident,'')
	+ ISNULL(trgt_gnrl_prmt_featr_ident,'')
	+ ISNULL(trgt_gnrl_lmt_set_designator,'')
	+ ISNULL(prmt_featr_type_code,'')
	+ ISNULL(prmt_featr_desc,'')
	+ ISNULL(prmt_featr_st_wtr_body_name,'')
	+ ISNULL(impaired_wtr_ind,'')
	+ ISNULL(tmdl_completed_ind,'')
	+ ISNULL(prmt_featr_usr_dfnd_dat_elm_1,'')
	+ ISNULL(prmt_featr_usr_dfnd_dat_elm_2,'')
	+ ISNULL(lmt_set_name_txt,'')
	+ ISNULL(dmr_pre_print_cmnts_txt,'')
);
UPDATE ICS_FLOW_LOCAL.ics_copy_mgpms_4_req
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', ICS_FLOW_LOCAL.ics_copy_mgpms_4_req.prmt_ident),
      data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
);
UPDATE ICS_FLOW_LOCAL.ics_crop_types_harvested
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  crop_types_harvested
);
UPDATE ICS_FLOW_LOCAL.ics_crop_types_planted
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  crop_types_planted
);
UPDATE ICS_FLOW_LOCAL.ics_cso_control_meas_detail
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(cso_control_meas_code,'')
	+ ISNULL(cso_control_meas_code_othr_txt,'')
	+ ISNULL(cso_control_meas_dev_imp_stat,'')
	+ ISNULL(cso_control_meas_cmpl_stat,'')
);
UPDATE ICS_FLOW_LOCAL.ics_cso_insp
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(CONVERT(varchar(50), cso_evt_date),'')
	+ ISNULL(dry_or_wet_weather_ind,'')
	+ ISNULL(prmt_featr_ident,'')
	+ ISNULL(CONVERT(varchar(50), lat_meas),'')
	+ ISNULL(CONVERT(varchar(50), long_meas),'')
	+ ISNULL(cso_ovrflw_loc_street,'')
	+ ISNULL(CONVERT(varchar(50), duration_cso_ovrflw_evt),'')
	+ ISNULL(CONVERT(varchar(50), dsch_vol_treated),'')
	+ ISNULL(CONVERT(varchar(50), dsch_vol_untreated),'')
	+ ISNULL(corr_actn_taken_desc_txt,'')
	+ ISNULL(CONVERT(varchar(50), inches_precip),'')
);
UPDATE ICS_FLOW_LOCAL.ics_cso_long_term_control_plan
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', ICS_FLOW_LOCAL.ics_cso_long_term_control_plan.prmt_ident),
      data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
);
UPDATE ICS_FLOW_LOCAL.ics_cwa_316b_prog_rep
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', prmt_ident + PROG_REP_FORM_SET_ID + CONVERT(varchar(50), PROG_REP_FORM_ID) ),
      data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ ISNULL(CONVERT(varchar(50), prog_rep_rcvd_date),'')
	+ ISNULL(CONVERT(varchar(50), prog_rep_start_date),'')
	+ ISNULL(CONVERT(varchar(50), prog_rep_end_date),'')
	+ ISNULL(elec_subm_type_code,'')
	+ ISNULL(prog_rep_npdes_dat_grp_num_code,'')
	+ ISNULL(cwa_316b_crit_habitat_protection_msr,'')
	+ ISNULL(cwa_316b_othr_mon_info,'')
);
UPDATE ICS_FLOW_LOCAL.ics_cwa_316b_take_info
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  cwa_316b_take_ident
	+ ISNULL(cwa_316b_species_name,'')
	+ ISNULL(cwa_316b_species_common_name,'')
	+ ISNULL(cwa_316b_fedr_stat,'')
	+ ISNULL(cwa_316b_lifestage_code,'')
	+ ISNULL(cwa_316b_take_method_code,'')
	+ ISNULL(cwa_316b_take_method_othr_txt,'')
	+ ISNULL(cwa_316b_take_type_code,'')
	+ ISNULL(cwa_316b_take_type_othr_txt,'')
	+ ISNULL(CONVERT(varchar(50), cwa_316b_species_num),'')
	+ ISNULL(CONVERT(varchar(50), cwa_316b_species_num_impinged_entrained),'')
	+ ISNULL(CONVERT(varchar(50), cwa_316b_species_num_impinged_entrained_date),'')
);
UPDATE ICS_FLOW_LOCAL.ics_dmr_viol
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', ICS_FLOW_LOCAL.ics_dmr_viol.prmt_ident + prmt_featr_ident + lmt_set_designator +CONVERT(varchar(50), mon_period_end_date) + param_code + mon_site_desc_code +CONVERT(varchar(50), lmt_season_num) +CONVERT(varchar(50), num_rep_code) +CONVERT(varchar(50), num_rep_viol_code)),
      data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ prmt_featr_ident
	+ lmt_set_designator
	+ CONVERT(varchar(50), mon_period_end_date)
	+ param_code
	+ mon_site_desc_code
	+ CONVERT(varchar(50), lmt_season_num)
	+ num_rep_code
	+ num_rep_viol_code
	+ ISNULL(rep_non_cmpl_detect_code,'')
	+ ISNULL(CONVERT(varchar(50), rep_non_cmpl_detect_date),'')
	+ ISNULL(rep_non_cmpl_resl_code,'')
	+ ISNULL(CONVERT(varchar(50), rep_non_cmpl_resl_date),'')
);
UPDATE ICS_FLOW_LOCAL.ics_dsch_mon_rep
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', ICS_FLOW_LOCAL.ics_dsch_mon_rep.prmt_ident + prmt_featr_ident + lmt_set_designator +CONVERT(varchar(50), mon_period_end_date)),
      data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ prmt_featr_ident
	+ lmt_set_designator
	+ CONVERT(varchar(50), mon_period_end_date)
	+ ISNULL(dmr_no_dsch_ind,'')
	+ ISNULL(CONVERT(varchar(50), dmr_no_dsch_rcvd_date),'')
	+ ISNULL(elec_subm_type_code,'')
	+ ISNULL(CONVERT(varchar(50), sign_date),'')
	+ ISNULL(prncpl_exec_offcr_first_name,'')
	+ ISNULL(prncpl_exec_offcr_last_name,'')
	+ ISNULL(prncpl_exec_offcr_title,'')
	+ ISNULL(prncpl_exec_offcr_teleph,'')
	+ ISNULL(sign_first_name,'')
	+ ISNULL(sign_last_name,'')
	+ ISNULL(sign_teleph,'')
	+ ISNULL(rep_cmnt_txt,'')
);
UPDATE ICS_FLOW_LOCAL.ics_dsch_mon_rep_param_viol
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  prmt_ident
	+ prmt_featr_ident
	+ lmt_set_designator
	+ CONVERT(varchar(50), mon_period_end_date)
	+ param_code
	+ mon_site_desc_code
	+ CONVERT(varchar(50), lmt_season_num)
);
UPDATE ICS_FLOW_LOCAL.ics_dsch_mon_rep_viol
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  prmt_ident
	+ prmt_featr_ident
	+ lmt_set_designator
	+ CONVERT(varchar(50), mon_period_end_date)
);
UPDATE ICS_FLOW_LOCAL.ics_efflu_guide
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  efflu_guide_code
);
UPDATE ICS_FLOW_LOCAL.ics_efflu_trade_prtner
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', ICS_FLOW_LOCAL.ics_efflu_trade_prtner.prmt_ident + prmt_featr_ident + lmt_set_designator + param_code + mon_site_desc_code +CONVERT(varchar(50), lmt_season_num) +CONVERT(varchar(50), lmt_start_date) +CONVERT(varchar(50), lmt_end_date) +CONVERT(varchar(50), lmt_mod_effective_date) + trade_id),
      data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ prmt_featr_ident
	+ lmt_set_designator
	+ param_code
	+ mon_site_desc_code
	+ CONVERT(varchar(50), lmt_season_num)
	+ CONVERT(varchar(50), lmt_start_date)
	+ CONVERT(varchar(50), lmt_end_date)
	+ ISNULL(CONVERT(varchar(50), lmt_mod_effective_date),'')
	+ ISNULL(trade_prtner_npdesid,'')
	+ ISNULL(trade_prtner_type,'')
	+ ISNULL(CONVERT(varchar(50), trade_prtner_start_date),'')
	+ ISNULL(CONVERT(varchar(50), trade_prtner_end_date),'')
);
UPDATE ICS_FLOW_LOCAL.ics_efflu_trade_prtner_addr
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(org_frml_name,'')
	+ ISNULL(org_duns_num,'')
	+ ISNULL(loc_name,'')
	+ ISNULL(mailing_addr_txt,'')
	+ ISNULL(suppl_addr_txt,'')
	+ ISNULL(mailing_addr_city_name,'')
	+ ISNULL(mailing_addr_country_code,'')
	+ ISNULL(loc_province,'')
	+ ISNULL(mailing_addr_st_code,'')
	+ ISNULL(mailing_addr_zip_code,'')
	+ ISNULL(county_name,'')
	+ ISNULL(division_name,'')
	+ ISNULL(elec_addr_txt,'')
);
UPDATE ICS_FLOW_LOCAL.ics_enfrc_actn_gov_contact
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  affil_type_txt
	+ ISNULL(elec_addr_txt,'')
	+ ISNULL(CONVERT(varchar(50), start_date_of_contact_assc),'')
	+ ISNULL(CONVERT(varchar(50), end_date_of_contact_assc),'')
);
UPDATE ICS_FLOW_LOCAL.ics_enfrc_actn_milestone
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', ICS_FLOW_LOCAL.ics_enfrc_actn_milestone.enfrc_actn_ident + milestone_type_code),
      data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	   enfrc_actn_ident
	+ milestone_type_code
	+ ISNULL(CONVERT(varchar(50), milestone_planned_date),'')
	+ ISNULL(CONVERT(varchar(50), milestone_actul_date),'')
);
UPDATE ICS_FLOW_LOCAL.ics_enfrc_actn_type
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  enfrc_actn_type_code
);
UPDATE ICS_FLOW_LOCAL.ics_enfrc_actn_viol_lnk
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	   enfrc_actn_ident
);
UPDATE ICS_FLOW_LOCAL.ics_enfrc_agncy
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  enfrc_agncy_type_code
	+ agncy_lead_ind
);
UPDATE ICS_FLOW_LOCAL.ics_fac
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(locality_name,'')
	+ ISNULL(loc_addr_city_code,'')
	+ ISNULL(loc_addr_county_code,'')
	+ ISNULL(fac_site_name,'')
	+ ISNULL(loc_addr_txt,'')
	+ ISNULL(suppl_loc_txt,'')
	+ ISNULL(loc_st_code,'')
	+ ISNULL(loc_zip_code,'')
	+ ISNULL(loc_country_code,'')
	+ ISNULL(org_duns_num,'')
	+ ISNULL(st_fac_ident,'')
	+ ISNULL(st_rgn_code,'')
	+ ISNULL(CONVERT(varchar(50), fac_congr_district_num),'')
	+ ISNULL(fac_type_of_ownership_code,'')
	+ ISNULL(fedr_fac_ident_num,'')
	+ ISNULL(fedr_agncy_code,'')
	+ ISNULL(tribal_land_code,'')
	+ ISNULL(cnst_proj_name,'')
	+ ISNULL(CONVERT(varchar(50), cnst_proj_lat_meas),'')
	+ ISNULL(CONVERT(varchar(50), cnst_proj_long_meas),'')
	+ ISNULL(section_township_rng,'')
	+ ISNULL(fac_cmnts,'')
	+ ISNULL(fac_usr_dfnd_fld_1,'')
	+ ISNULL(fac_usr_dfnd_fld_2,'')
	+ ISNULL(fac_usr_dfnd_fld_3,'')
	+ ISNULL(fac_usr_dfnd_fld_4,'')
	+ ISNULL(fac_usr_dfnd_fld_5,'')
);
UPDATE ICS_FLOW_LOCAL.ics_fac_class
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  fac_class
);
UPDATE ICS_FLOW_LOCAL.ics_final_order
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  CONVERT(varchar(50), final_order_ident)
	+ ISNULL(final_order_type_code,'')
	+ ISNULL(CONVERT(varchar(50), final_order_issued_enterd_date),'')
	+ ISNULL(CONVERT(varchar(50), npdes_closed_date),'')
	+ ISNULL(final_order_qncr_cmnts,'')
	+ ISNULL(CONVERT(varchar(50), cash_civil_pnlty_reqd_amt),'')
	+ ISNULL(CONVERT(varchar(50), cash_civil_pnlty_coll_amt),'')
	+ ISNULL(othr_cmnts,'')
);
UPDATE ICS_FLOW_LOCAL.ics_final_order_prmt_ident
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  final_order_prmt_ident
);
UPDATE ICS_FLOW_LOCAL.ics_final_order_viol_lnk
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	   enfrc_actn_ident
	+ CONVERT(varchar(50), final_order_ident)
);
UPDATE ICS_FLOW_LOCAL.ics_frml_enfrc_actn
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', ICS_FLOW_LOCAL.ics_frml_enfrc_actn.enfrc_actn_ident),
      data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	   enfrc_actn_ident
	+ ISNULL(enfrc_actn_name,'')
	+ ISNULL(forum,'')
	+ ISNULL(resl_type_code,'')
	+ ISNULL(combined_or_superseded_by_eaid,'')
	+ ISNULL(reason_deleting_record,'')
	+ ISNULL(frml_ea_usr_dfnd_fld_1,'')
	+ ISNULL(frml_ea_usr_dfnd_fld_2,'')
	+ ISNULL(frml_ea_usr_dfnd_fld_3,'')
	+ ISNULL(CONVERT(varchar(50), frml_ea_usr_dfnd_fld_4),'')
	+ ISNULL(CONVERT(varchar(50), frml_ea_usr_dfnd_fld_5),'')
	+ ISNULL(frml_ea_usr_dfnd_fld_6,'')
	+ ISNULL(enfrc_agncy_name,'')
);
UPDATE ICS_FLOW_LOCAL.ics_geo_coord
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  CONVERT(varchar(50), lat_meas)
	+ CONVERT(varchar(50), long_meas)
	+ ISNULL(CONVERT(varchar(50), horz_accuracy_meas),'')
	+ ISNULL(geometric_type_code,'')
	+ ISNULL(horz_coll_method_code,'')
	+ ISNULL(horz_ref_datum_code,'')
	+ ISNULL(ref_point_code,'')
	+ ISNULL(CONVERT(varchar(50), src_map_scale_num),'')
);
UPDATE ICS_FLOW_LOCAL.ics_gnrl_prmt
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', ICS_FLOW_LOCAL.ics_gnrl_prmt.prmt_ident),
      data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ ISNULL(elec_subm_type_code,'')
	+ ISNULL(assc_master_gnrl_prmt_ident,'')
	+ ISNULL(prmt_type_code,'')
	+ ISNULL(agncy_type_code,'')
	+ ISNULL(prmt_stat_code,'')
	+ ISNULL(CONVERT(varchar(50), prmt_issue_date),'')
	+ ISNULL(CONVERT(varchar(50), prmt_effective_date),'')
	+ ISNULL(CONVERT(varchar(50), prmt_expr_date),'')
	+ ISNULL(reissu_prio_prmt_ind,'')
	+ ISNULL(backlog_reason_txt,'')
	+ ISNULL(prmt_issuing_org_type_name,'')
	+ ISNULL(prmt_appealed_ind,'')
	+ ISNULL(prmt_usr_dfnd_dat_elm_1_txt,'')
	+ ISNULL(prmt_usr_dfnd_dat_elm_2_txt,'')
	+ ISNULL(prmt_usr_dfnd_dat_elm_3_txt,'')
	+ ISNULL(prmt_usr_dfnd_dat_elm_4_txt,'')
	+ ISNULL(prmt_usr_dfnd_dat_elm_5_txt,'')
	+ ISNULL(prmt_cmnts_txt,'')
	+ ISNULL(CONVERT(varchar(50), major_minor_rating_code),'')
	+ ISNULL(CONVERT(varchar(50), ttl_appl_dsgn_flow_num),'')
	+ ISNULL(CONVERT(varchar(50), ttl_appl_aver_flow_num),'')
	+ ISNULL(CONVERT(varchar(50), appl_rcvd_date),'')
	+ ISNULL(CONVERT(varchar(50), prmt_appl_cmpl_date),'')
	+ ISNULL(new_src_ind,'')
	+ ISNULL(prmt_st_wtr_body_code,'')
	+ ISNULL(prmt_st_wtr_body_name,'')
	+ ISNULL(fedr_grant_ind,'')
	+ ISNULL(dmr_cognznt_ofcl,'')
	+ ISNULL(dmr_cognznt_ofcl_teleph_num,'')
	+ ISNULL(elec_rep_waiver_type_code,'')
	+ ISNULL(CONVERT(varchar(50), elec_rep_waiver_effective_date),'')
	+ ISNULL(CONVERT(varchar(50), elec_rep_waiver_expr_date),'')
	+ ISNULL(major_minor_stat_ind,'')
	+ ISNULL(CONVERT(varchar(50), major_minor_stat_start_date),'')
	+ ISNULL(dmr_non_rcpt_stat_ind,'')
	+ ISNULL(CONVERT(varchar(50), dmr_non_rcpt_stat_start_date),'')
);
UPDATE ICS_FLOW_LOCAL.ics_gnrl_prmt_coverage_ms_4_req
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  prmt_ident
);
UPDATE ICS_FLOW_LOCAL.ics_gpcf_no_exposure
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(CONVERT(varchar(50), no_exposure_auth_date),'')
	+ ISNULL(CONVERT(varchar(50), no_exposure_postmark_date),'')
	+ ISNULL(CONVERT(varchar(50), no_exposure_eval_date),'')
	+ ISNULL(no_exposure_eval_basis_code,'')
	+ ISNULL(no_exposure_criteria_met_ind,'')
	+ ISNULL(CONVERT(varchar(50), paved_roof_size),'')
);
UPDATE ICS_FLOW_LOCAL.ics_gpcf_notice_of_intent
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(CONVERT(varchar(50), noi_sign_date),'')
	+ ISNULL(CONVERT(varchar(50), noi_postmark_date),'')
	+ ISNULL(CONVERT(varchar(50), noi_rcvd_date),'')
	+ ISNULL(CONVERT(varchar(50), complete_noi_rcvd_date),'')
	+ ISNULL(fedr_cercla_dsch_ind,'')
);
UPDATE ICS_FLOW_LOCAL.ics_gpcf_notice_of_term
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(CONVERT(varchar(50), not_term_date),'')
	+ ISNULL(CONVERT(varchar(50), not_sign_date),'')
	+ ISNULL(CONVERT(varchar(50), not_postmark_date),'')
	+ ISNULL(CONVERT(varchar(50), not_rcvd_date),'')
);
UPDATE ICS_FLOW_LOCAL.ics_hist_prmt_schd_evts
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', ICS_FLOW_LOCAL.ics_hist_prmt_schd_evts.prmt_ident +CONVERT(varchar(50), prmt_effective_date) +CONVERT(varchar(50), narr_cond_num) + schd_evt_code +CONVERT(varchar(50), schd_date) +CONVERT(varchar(50), narr_cond_num) + schd_evt_code +CONVERT(varchar(50), schd_date)),
      data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ CONVERT(varchar(50), prmt_effective_date)
	+ ISNULL(CONVERT(varchar(50), narr_cond_num),'')
	+ schd_evt_code
	+ CONVERT(varchar(50), schd_date)
	+ ISNULL(CONVERT(varchar(50), schd_rep_rcvd_date),'')
	+ ISNULL(CONVERT(varchar(50), schd_actul_date),'')
	+ ISNULL(CONVERT(varchar(50), schd_proj_date),'')
	+ ISNULL(schd_usr_dfnd_dat_elm_1,'')
	+ ISNULL(schd_usr_dfnd_dat_elm_2,'')
	+ ISNULL(schd_evt_cmnts,'')
);
UPDATE ICS_FLOW_LOCAL.ics_impact_sso_evt
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  impact_sso_evt
);
UPDATE ICS_FLOW_LOCAL.ics_impaired_wtr_pollutants
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  CONVERT(varchar(50), impaired_wtr_pollutants)
);
UPDATE ICS_FLOW_LOCAL.ics_incin
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(beryllium_cmpl_ind,'')
	+ ISNULL(mercury_cmpl_ind,'')
);
UPDATE ICS_FLOW_LOCAL.ics_indst_usr_info
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  prmt_ident
	+ ISNULL(CONVERT(varchar(50), iu_aver_daily_ww_flow_rate_gpd),'')
	+ ISNULL(CONVERT(varchar(50), iu_aver_daily_prcss_ww_flow_rate_gpd),'')
	+ ISNULL(iu_subject_loc_lmts_ind,'')
	+ ISNULL(iu_subject_loc_lmts_more_stringent_cat_std_ind,'')
	+ ISNULL(mtciu_subject_reduced_rep_ind,'')
	+ ISNULL(CONVERT(varchar(50), num_iu_insp_by_ca),'')
	+ ISNULL(CONVERT(varchar(50), num_iu_smpl_evts_by_ca),'')
	+ ISNULL(CONVERT(varchar(50), num_reqd_iu_self_mon_evts_max),'')
	+ ISNULL(iu_comply_req_self_mon_rpting_ind,'')
	+ ISNULL(iu_comply_req_self_mon_rpting_txt,'')
	+ ISNULL(nsciu_cert_subm_to_ca_ind,'')
	+ ISNULL(changed_disch_subm_ind,'')
);
UPDATE ICS_FLOW_LOCAL.ics_indst_usr_inventory
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(indst_usr_ind,'')
);
UPDATE ICS_FLOW_LOCAL.ics_infrml_enfrc_actn
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', ICS_FLOW_LOCAL.ics_infrml_enfrc_actn.enfrc_actn_ident),
      data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	   enfrc_actn_ident
	+ ISNULL(enfrc_actn_type_code,'')
	+ ISNULL(enfrc_actn_name,'')
	+ ISNULL(CONVERT(varchar(50), achieved_date),'')
	+ ISNULL(file_num,'')
	+ ISNULL(reason_deleting_record,'')
	+ ISNULL(infrml_ea_cmnt_txt,'')
	+ ISNULL(infrml_ea_usr_dfnd_fld_1,'')
	+ ISNULL(infrml_ea_usr_dfnd_fld_2,'')
	+ ISNULL(infrml_ea_usr_dfnd_fld_3,'')
	+ ISNULL(CONVERT(varchar(50), infrml_ea_usr_dfnd_fld_4),'')
	+ ISNULL(CONVERT(varchar(50), infrml_ea_usr_dfnd_fld_5),'')
	+ ISNULL(infrml_ea_usr_dfnd_fld_6,'')
	+ ISNULL(enfrc_agncy_name,'')
);
UPDATE ICS_FLOW_LOCAL.ics_insp_cmnt_txt
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  insp_cmnt_txt
);
UPDATE ICS_FLOW_LOCAL.ics_insp_gov_contact
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  affil_type_txt
	+ ISNULL(elec_addr_txt,'')
);
UPDATE ICS_FLOW_LOCAL.ics_iu_enf_actn_types
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  iu_enf_actn_type_code
	+ ISNULL(iu_enf_actn_type_othr_txt,'')
	+ ISNULL(CONVERT(varchar(50), num_iu_enf_actions),'')
);
UPDATE ICS_FLOW_LOCAL.ics_iu_enfrc_actn_info
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(snc_pretr_enf_cmpl_sched_stat_ind,'')
	+ ISNULL(CONVERT(varchar(50), iu_cash_civil_pnlty_amt_assessed),'')
	+ ISNULL(CONVERT(varchar(50), iu_cash_civil_pnlty_amt_coll),'')
);
UPDATE ICS_FLOW_LOCAL.ics_iu_viol_info
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(snc_pretr_stnd_lmts_ind,'')
	+ ISNULL(snc_rpt_rqmt_ind,'')
	+ ISNULL(snc_oth_ctrl_mech_rqmt_ind,'')
	+ ISNULL(snc_rel_potw_disch_oper_ind,'')
	+ ISNULL(snc_rel_potw_disch_oper_txt,'')
	+ ISNULL(snc_rel_potw_bio_oper_sewg_slud_mgmt_ind,'')
	+ ISNULL(snc_rel_potw_bio_oper_sewg_slud_mgmt_txt,'')
	+ ISNULL(snc_publ_ind,'')
);
UPDATE ICS_FLOW_LOCAL.ics_land_appl_bmp
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  land_appl_bmp_type_code
	+ ISNULL(othr_land_appl_bmp_type_name,'')
);
UPDATE ICS_FLOW_LOCAL.ics_land_appl_site
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(CONVERT(varchar(50), polut_met_for_land_appl),'')
	+ ISNULL(pathogen_reduction_ind,'')
	+ ISNULL(vector_reduction_ind,'')
	+ ISNULL(CONVERT(varchar(50), agronomic_gal_rate_for_fld),'')
	+ ISNULL(CONVERT(varchar(50), agronomic_dmt_rate_for_fld),'')
	+ ISNULL(class_a_alt_used,'')
	+ ISNULL(class_a_alts_txt,'')
	+ ISNULL(class_b_alt_used,'')
	+ ISNULL(class_b_alts_txt,'')
	+ ISNULL(var_alt_used,'')
	+ ISNULL(var_alts_txt,'')
);
UPDATE ICS_FLOW_LOCAL.ics_lmt
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  CONVERT(varchar(50), lmt_start_date)
	+ CONVERT(varchar(50), lmt_end_date)
	+ ISNULL(lmt_type_code,'')
	+ ISNULL(smpl_type_txt,'')
	+ ISNULL(freq_of_analysis_code,'')
	+ ISNULL(eligible_for_burden_reduction,'')
	+ ISNULL(lmt_stay_type_code,'')
	+ ISNULL(CONVERT(varchar(50), stay_start_date),'')
	+ ISNULL(CONVERT(varchar(50), stay_end_date),'')
	+ ISNULL(stay_reason_txt,'')
	+ ISNULL(calculate_viol_ind,'')
	+ ISNULL(enfrc_actn_ident,'')
	+ ISNULL(CONVERT(varchar(50), final_order_ident),'')
	+ ISNULL(basis_of_lmt,'')
	+ ISNULL(lmt_mod_type_code,'')
	+ ISNULL(CONVERT(varchar(50), lmt_mod_effective_date),'')
	+ ISNULL(lmt_mod_type_stay_reason_txt,'')
	+ ISNULL(lmts_usr_dfnd_fld_1,'')
	+ ISNULL(lmts_usr_dfnd_fld_2,'')
	+ ISNULL(lmts_usr_dfnd_fld_3,'')
	+ ISNULL(concen_num_cond_unit_meas_code,'')
	+ ISNULL(qty_num_cond_unit_meas_code,'')
);
UPDATE ICS_FLOW_LOCAL.ics_lmt_set
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', ICS_FLOW_LOCAL.ics_lmt_set.prmt_ident + prmt_featr_ident + lmt_set_designator),
      data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ prmt_featr_ident
	+ lmt_set_designator
	+ ISNULL(lmt_set_type,'')
	+ ISNULL(lmt_set_name_txt,'')
	+ ISNULL(dmr_pre_print_cmnts_txt,'')
	+ ISNULL(agncy_reviewer,'')
	+ ISNULL(CONVERT(varchar(50), lmt_set_usr_dfnd_dat_elm_1_txt),'')
	+ ISNULL(lmt_set_usr_dfnd_dat_elm_2_txt,'')
);
UPDATE ICS_FLOW_LOCAL.ics_lmt_set_months_appl
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  lmt_set_months_appl
);
UPDATE ICS_FLOW_LOCAL.ics_lmt_set_schd
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  CONVERT(varchar(50), num_units_rep_period_integer)
	+ ISNULL(CONVERT(varchar(50), num_subm_units_integer),'')
	+ ISNULL(CONVERT(varchar(50), initial_mon_date),'')
	+ ISNULL(CONVERT(varchar(50), initial_dmr_due_date),'')
	+ ISNULL(lmt_set_mod_type_code,'')
	+ ISNULL(CONVERT(varchar(50), lmt_set_mod_effective_date),'')
);
UPDATE ICS_FLOW_LOCAL.ics_lmt_set_stat
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  lmt_set_stat_ind
	+ CONVERT(varchar(50), lmt_set_stat_start_date)
	+ ISNULL(lmt_set_stat_reason_txt,'')
);
UPDATE ICS_FLOW_LOCAL.ics_lmts
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', ICS_FLOW_LOCAL.ics_lmts.prmt_ident + prmt_featr_ident + lmt_set_designator + param_code + mon_site_desc_code +CONVERT(varchar(50), lmt_season_num) +CONVERT(varchar(50), lmt_start_date) +CONVERT(varchar(50), lmt_end_date)),
      data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ prmt_featr_ident
	+ lmt_set_designator
	+ param_code
	+ mon_site_desc_code
	+ CONVERT(varchar(50), lmt_season_num)
	+ CONVERT(varchar(50), lmt_start_date)
	+ CONVERT(varchar(50), lmt_end_date)
	+ ISNULL(lmt_type_code,'')
	+ ISNULL(smpl_type_txt,'')
	+ ISNULL(freq_of_analysis_code,'')
	+ ISNULL(eligible_for_burden_reduction,'')
	+ ISNULL(lmt_stay_type_code,'')
	+ ISNULL(CONVERT(varchar(50), stay_start_date),'')
	+ ISNULL(CONVERT(varchar(50), stay_end_date),'')
	+ ISNULL(stay_reason_txt,'')
	+ ISNULL(calculate_viol_ind,'')
	+ ISNULL(enfrc_actn_ident,'')
	+ ISNULL(CONVERT(varchar(50), final_order_ident),'')
	+ ISNULL(basis_of_lmt,'')
	+ ISNULL(lmt_mod_type_code,'')
	+ ISNULL(CONVERT(varchar(50), lmt_mod_effective_date),'')
	+ ISNULL(lmt_mod_type_stay_reason_txt,'')
	+ ISNULL(lmts_usr_dfnd_fld_1,'')
	+ ISNULL(lmts_usr_dfnd_fld_2,'')
	+ ISNULL(lmts_usr_dfnd_fld_3,'')
	+ ISNULL(concen_num_cond_unit_meas_code,'')
	+ ISNULL(qty_num_cond_unit_meas_code,'')
);
UPDATE ICS_FLOW_LOCAL.ics_lnk_cmpl_mon
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(cmpl_mon_ident,'')
);
UPDATE ICS_FLOW_LOCAL.ics_lnk_enfrc_actn
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  enfrc_actn_ident
);
UPDATE ICS_FLOW_LOCAL.ics_lnk_sngl_evt
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  prmt_ident
	+ sngl_evt_viol_code
	+ CONVERT(varchar(50), sngl_evt_viol_date)
);
UPDATE ICS_FLOW_LOCAL.ics_loc_lmts_parameters
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  loc_lmts_parameters
);
UPDATE ICS_FLOW_LOCAL.ics_ltcp_enforceable_mech_detail
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(ltcp_enforceable_mech_code,'')
	+ ISNULL(ltcp_enforceable_mech_code_othr_txt,'')
);
UPDATE ICS_FLOW_LOCAL.ics_ltcp_most_recent_revision_detail
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(CONVERT(varchar(50), ltcp_most_recent_revision_date),'')
	+ ISNULL(ltcp_most_recent_revision_stat,'')
);
UPDATE ICS_FLOW_LOCAL.ics_ltcp_summ
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(ltcp_reqd_ind,'')
	+ ISNULL(ltcp_in_cmpl_ind,'')
	+ ISNULL(CONVERT(varchar(50), ltcp_aprvl_date),'')
	+ ISNULL(CONVERT(varchar(50), ltcp_and_cso_controls_complete_date),'')
	+ ISNULL(cso_post_cnst_cmpl_mon_prog,'')
	+ ISNULL(cso_controls_othr_than_ltcp,'')
);
UPDATE ICS_FLOW_LOCAL.ics_master_gnrl_prmt
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', ICS_FLOW_LOCAL.ics_master_gnrl_prmt.prmt_ident),
      data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ ISNULL(prmt_type_code,'')
	+ ISNULL(agncy_type_code,'')
	+ ISNULL(CONVERT(varchar(50), prmt_issue_date),'')
	+ ISNULL(CONVERT(varchar(50), prmt_effective_date),'')
	+ ISNULL(CONVERT(varchar(50), prmt_expr_date),'')
	+ ISNULL(reissu_prio_prmt_ind,'')
	+ ISNULL(backlog_reason_txt,'')
	+ ISNULL(prmt_issuing_org_type_name,'')
	+ ISNULL(prmt_appealed_ind,'')
	+ ISNULL(prmt_usr_dfnd_dat_elm_1_txt,'')
	+ ISNULL(prmt_usr_dfnd_dat_elm_2_txt,'')
	+ ISNULL(prmt_usr_dfnd_dat_elm_3_txt,'')
	+ ISNULL(prmt_usr_dfnd_dat_elm_4_txt,'')
	+ ISNULL(prmt_usr_dfnd_dat_elm_5_txt,'')
	+ ISNULL(prmt_cmnts_txt,'')
	+ ISNULL(gnrl_prmt_indst_catg,'')
	+ ISNULL(prmt_name,'')
);
UPDATE ICS_FLOW_LOCAL.ics_mn_lmt_applies
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  mn_lmt_applies
);
UPDATE ICS_FLOW_LOCAL.ics_mnur_lttr_prcss_ww_stor
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  mnur_lttr_prcss_ww_stor_type
	+ ISNULL(othr_stor_type_name,'')
	+ ISNULL(CONVERT(varchar(50), stor_ttl_cpcty_meas),'')
	+ ISNULL(CONVERT(varchar(50), days_of_stor),'')
	+ ISNULL(cafomlpw_unit,'')
	+ ISNULL(cafomlpw_stor_within_dsgn_cpcty,'')
	+ ISNULL(cafomlpw_stor_within_dsgn_cpcty_txt,'')
);
UPDATE ICS_FLOW_LOCAL.ics_ms_4_acty_ident
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  ms_4_acty_ident
);
UPDATE ICS_FLOW_LOCAL.ics_ms_4_cnst_sw_procedures
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  ms_4_acty_ident
	+ ISNULL(ms_4_cnst_sw_procedure_type,'')
	+ ISNULL(ms_4_cnst_sw_procedure_txt,'')
	+ ISNULL(ms_4_cnst_sw_procedure_schd_txt,'')
);
UPDATE ICS_FLOW_LOCAL.ics_ms_4_cnst_sw_regulated_entity_info
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  ms_4_acty_ident
	+ ISNULL(ms_4_regulated_entity_ident,'')
	+ ISNULL(ms_4_cnst_sw_erosion_ordinance_stat,'')
	+ ISNULL(ms_4_cnst_sw_erosion_ordinance_stat_txt,'')
	+ ISNULL(ms_4_cnst_sw_erosion_plan_rviw_stat,'')
	+ ISNULL(ms_4_cnst_sw_erosion_plan_rviw_stat_txt,'')
	+ ISNULL(ms_4_cnst_sw_site_insp_stat,'')
	+ ISNULL(ms_4_cnst_sw_site_insp_stat_txt,'')
);
UPDATE ICS_FLOW_LOCAL.ics_ms_4_cnst_sw_reqs
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
null);
UPDATE ICS_FLOW_LOCAL.ics_ms_4_illicit_detect_procedures
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  ms_4_acty_ident
	+ ISNULL(ms_4_illicit_detect_procedure_type,'')
	+ ISNULL(ms_4_illicit_detect_procedure_txt,'')
	+ ISNULL(ms_4_illicit_detect_procedure_schd_txt,'')
);
UPDATE ICS_FLOW_LOCAL.ics_ms_4_illicit_detect_regulated_entity_info
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  ms_4_acty_ident
	+ ISNULL(ms_4_regulated_entity_ident,'')
	+ ISNULL(CONVERT(varchar(50), ms_4_prmt_illicit_detect_outfall_mapping_date),'')
	+ ISNULL(ms_4_illicit_detect_outfall_mapping_stat,'')
	+ ISNULL(CONVERT(varchar(50), ms_4_prmt_illicit_detect_outfall_ttl_num),'')
	+ ISNULL(CONVERT(varchar(50), ms_4_prmt_illicit_detect_outfall_mapped_num),'')
	+ ISNULL(ms_4_illicit_detect_prohibition_ordinance_stat,'')
	+ ISNULL(ms_4_illicit_detect_prohibition_ordinance_stat_txt,'')
);
UPDATE ICS_FLOW_LOCAL.ics_ms_4_illicit_detect_regulated_entity_info_prog_rep
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  ms_4_acty_ident
	+ ISNULL(CONVERT(varchar(50), ms_4_prog_rep_illicit_detect_outfall_mapping_date),'')
	+ ISNULL(CONVERT(varchar(50), ms_4_prog_rep_illicit_detect_outfall_ttl_num),'')
	+ ISNULL(CONVERT(varchar(50), ms_4_prog_rep_illicit_detect_outfall_mapped_num),'')
	+ ISNULL(ms_4_regulated_entity_cmpl_stat,'')
	+ ISNULL(ms_4_regulated_entity_cmpl_stat_txt,'')
	+ ISNULL(ms_4_prog_rep_reqs_activities,'')
);
UPDATE ICS_FLOW_LOCAL.ics_ms_4_illicit_detect_reqs
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
null);
UPDATE ICS_FLOW_LOCAL.ics_ms_4_indst_sw_procedures
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  ms_4_acty_ident
	+ ISNULL(ms_4_indst_sw_procedure_type,'')
	+ ISNULL(ms_4_indst_sw_procedure_txt,'')
	+ ISNULL(ms_4_indst_sw_procedure_schd_txt,'')
);
UPDATE ICS_FLOW_LOCAL.ics_ms_4_indst_sw_regulated_entity_info
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  ms_4_acty_ident
	+ ISNULL(ms_4_regulated_entity_ident,'')
	+ ISNULL(ms_4_indst_sw_ordinance_stat,'')
	+ ISNULL(ms_4_indst_sw_ordinance_stat_txt,'')
	+ ISNULL(ms_4_indst_sw_indst_inventory_stat,'')
	+ ISNULL(ms_4_indst_sw_indst_inventory_stat_txt,'')
	+ ISNULL(ms_4_indst_sw_mon_stat,'')
	+ ISNULL(ms_4_indst_sw_mon_stat_txt,'')
);
UPDATE ICS_FLOW_LOCAL.ics_ms_4_indst_sw_reqs
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
null);
UPDATE ICS_FLOW_LOCAL.ics_ms_4_othr_appl_reqs
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  ms_4_acty_ident
	+ ISNULL(ms_4_othr_appl_reqs_txt,'')
	+ ISNULL(ms_4_othr_appl_reqs_schd_txt,'')
);
UPDATE ICS_FLOW_LOCAL.ics_ms_4_pblc_education_reqs
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  ms_4_acty_ident
	+ ISNULL(ms_4_pblc_education_reqs_txt,'')
	+ ISNULL(ms_4_pblc_education_schd_txt,'')
	+ ISNULL(ms_4_pblc_education_delivery_option,'')
	+ ISNULL(ms_4_pblc_education_delivery_option_othr_txt,'')
	+ ISNULL(ms_4_pblc_education_subject_option,'')
	+ ISNULL(ms_4_pblc_education_subject_option_othr_txt,'')
	+ ISNULL(ms_4_pblc_education_audience_option,'')
	+ ISNULL(ms_4_pblc_education_audience_option_othr_txt,'')
);
UPDATE ICS_FLOW_LOCAL.ics_ms_4_pblc_involvement_reqs
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  ms_4_acty_ident
	+ ISNULL(ms_4_pblc_involvement_reqs_txt,'')
	+ ISNULL(ms_4_pblc_involvement_schd_txt,'')
	+ ISNULL(ms_4_pblc_involvement_delivery_option,'')
	+ ISNULL(ms_4_pblc_involvement_delivery_option_othr_txt,'')
	+ ISNULL(ms_4_pblc_involvement_subject_option,'')
	+ ISNULL(ms_4_pblc_involvement_subject_option_othr_txt,'')
	+ ISNULL(ms_4_pblc_involvement_participant_option,'')
	+ ISNULL(ms_4_pblc_involvement_participant_option_othr_txt,'')
);
UPDATE ICS_FLOW_LOCAL.ics_ms_4_pollution_prevention_reqs
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  ms_4_acty_ident
	+ ISNULL(ms_4_pollution_prevention_reqs_txt,'')
	+ ISNULL(ms_4_pollution_prevention_schd_txt,'')
);
UPDATE ICS_FLOW_LOCAL.ics_ms_4_post_cnst_sw_procedures
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  ms_4_acty_ident
	+ ISNULL(ms_4_post_cnst_sw_procedure_type,'')
	+ ISNULL(ms_4_post_cnst_sw_procedure_txt,'')
	+ ISNULL(ms_4_post_cnst_sw_procedure_schd_txt,'')
);
UPDATE ICS_FLOW_LOCAL.ics_ms_4_post_cnst_sw_regulated_entity_info
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  ms_4_acty_ident
	+ ISNULL(ms_4_regulated_entity_ident,'')
	+ ISNULL(ms_4_post_cnst_sw_runoff_ordinance_stat,'')
	+ ISNULL(ms_4_post_cnst_sw_runoff_ordinance_stat_txt,'')
	+ ISNULL(ms_4_post_cnst_sw_runoff_prog_stat,'')
	+ ISNULL(ms_4_post_cnst_sw_runoff_prog_stat_txt,'')
	+ ISNULL(ms_4_post_cnst_sw_runoff_bmp_stat,'')
	+ ISNULL(ms_4_post_cnst_sw_runoff_bmp_stat_txt,'')
);
UPDATE ICS_FLOW_LOCAL.ics_ms_4_post_cnst_sw_reqs
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
null);
UPDATE ICS_FLOW_LOCAL.ics_ms_4_prog_rep_analysis
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  ms_4_prog_rep_analysis_txt
);
UPDATE ICS_FLOW_LOCAL.ics_ms_4_prog_rep_reqs_regulated_entity
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  ms_4_acty_ident
	+ ISNULL(ms_4_regulated_entity_cmpl_stat,'')
	+ ISNULL(ms_4_regulated_entity_cmpl_stat_txt,'')
	+ ISNULL(ms_4_prog_rep_reqs_activities,'')
);
UPDATE ICS_FLOW_LOCAL.ics_ms_4_regulated_entity
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(ms_4_regulated_entity_ident,'')
	+ ISNULL(ms_4_regulated_entity_name,'')
	+ ISNULL(ms_4_regulated_entity_ownership_level_code,'')
	+ ISNULL(ms_4_regulated_entity_ownership_level_othr_txt,'')
	+ ISNULL(ms_4_regulated_entity_catg_code,'')
	+ ISNULL(ms_4_regulated_entity_catg_code_othr_txt,'')
);
UPDATE ICS_FLOW_LOCAL.ics_ms_4_regulated_entity_area
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  CONVERT(varchar(50), ms_4_regulated_entity_area_num)
	+ ISNULL(ms_4_regulated_entity_ident,'')
	+ ISNULL(ms_4_regulated_entity_area_stat_code,'')
	+ ISNULL(ms_4_regulated_entity_area_txt,'')
);
UPDATE ICS_FLOW_LOCAL.ics_ms_4_regulated_entity_area_coord
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(CONVERT(varchar(50), lat_meas),'')
	+ ISNULL(CONVERT(varchar(50), long_meas),'')
);
UPDATE ICS_FLOW_LOCAL.ics_ms_4_regulated_entity_enfrc
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(ms_4_regulated_entity_ident,'')
);
UPDATE ICS_FLOW_LOCAL.ics_ms_4_regulated_entity_enfrc_actions
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  ms_4_regulated_entity_enfrc_actn_type_code
	+ ms_4_regulated_entity_enfrc_actn_type_code_othr_txt
);
UPDATE ICS_FLOW_LOCAL.ics_ms_4_regulated_entity_ident
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  ms_4_regulated_entity_ident
);
UPDATE ICS_FLOW_LOCAL.ics_ms_4_swmp_changes
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(ms_4_regulated_entity_ident,'')
	+ ms_4_swmp_change_ind
	+ ISNULL(ms_4_swmp_change_ind_txt,'')
);
UPDATE ICS_FLOW_LOCAL.ics_naics_code
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  naics_code
	+ naics_primary_ind_code
);
UPDATE ICS_FLOW_LOCAL.ics_narr_cond_schd
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', ICS_FLOW_LOCAL.ics_narr_cond_schd.prmt_ident +CONVERT(varchar(50), narr_cond_num)),
      data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ CONVERT(varchar(50), narr_cond_num)
	+ ISNULL(narr_cond_code,'')
	+ ISNULL(cmnts,'')
);
UPDATE ICS_FLOW_LOCAL.ics_nat_prio
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  CONVERT(varchar(50), nat_prio_code)
);
UPDATE ICS_FLOW_LOCAL.ics_npdes_dat_grp_num
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  npdes_dat_grp_num_code
);
UPDATE ICS_FLOW_LOCAL.ics_npdes_variance_prmt
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', concat(prmt_ident,npdes_variance_type_code,CONVERT(varchar(50), NPDES_VARIANCE_SUBM_DATE))),
      data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ ISNULL(npdes_variance_type_code,'')
	+ ISNULL(CONVERT(varchar(50), npdes_variance_subm_date),'')
	+ ISNULL(npdes_variance_version_type,'')
	+ ISNULL(npdes_variance_stat_code,'')
	+ ISNULL(CONVERT(varchar(50), npdes_variance_actn_date),'')
	+ ISNULL(thermal_variance_request_pblc_notice_ind,'')
	+ ISNULL(npdes_variance_cmnt_txt,'')
);
UPDATE ICS_FLOW_LOCAL.ics_num_cond
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  num_cond_txt
	+ ISNULL(num_cond_qty,'')
	+ ISNULL(num_cond_stat_base_code,'')
	+ ISNULL(num_cond_qualifier,'')
	+ ISNULL(num_cond_opt_mon_ind,'')
	+ ISNULL(num_cond_stay_value,'')
);
UPDATE ICS_FLOW_LOCAL.ics_num_rep
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  num_rep_code
	+ ISNULL(CONVERT(varchar(50), num_rep_rcvd_date),'')
	+ ISNULL(num_rep_no_dsch_ind,'')
	+ ISNULL(num_cond_qty,'')
	+ ISNULL(num_cond_adjusted_qty,'')
	+ ISNULL(num_cond_qualifier,'')
);
UPDATE ICS_FLOW_LOCAL.ics_orig_progs
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  orig_progs_code
);
UPDATE ICS_FLOW_LOCAL.ics_othr_prmts
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  othr_prmt_ident
	+ ISNULL(othr_org_name,'')
	+ ISNULL(othr_prmt_ident_cntxt_name,'')
);
UPDATE ICS_FLOW_LOCAL.ics_param_lmts
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', ICS_FLOW_LOCAL.ics_param_lmts.prmt_ident + prmt_featr_ident + lmt_set_designator + param_code + mon_site_desc_code +CONVERT(varchar(50), lmt_season_num)),
      data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ prmt_featr_ident
	+ lmt_set_designator
	+ param_code
	+ mon_site_desc_code
	+ CONVERT(varchar(50), lmt_season_num)
);
UPDATE ICS_FLOW_LOCAL.ics_pathogen_reduction_type
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  pathogen_reduction_type_code
);
UPDATE ICS_FLOW_LOCAL.ics_plcy
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  plcy_code
);
UPDATE ICS_FLOW_LOCAL.ics_polut_list
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
null);
UPDATE ICS_FLOW_LOCAL.ics_potw_prmt
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', ICS_FLOW_LOCAL.ics_potw_prmt.prmt_ident),
      data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ ISNULL(CONVERT(varchar(50), sscs_popl_served_num),'')
	+ ISNULL(CONVERT(varchar(50), combined_sscs_systm_length),'')
);
UPDATE ICS_FLOW_LOCAL.ics_potw_trtmnt_technology_prmt
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', ICS_FLOW_LOCAL.ics_potw_trtmnt_technology_prmt.prmt_ident),
      data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ ISNULL(potw_trtmnt_level_code,'')
	+ ISNULL(potw_trtmnt_level_othr_txt,'')
	+ ISNULL(potw_ww_disinfection_technology_code,'')
	+ ISNULL(potw_ww_disinfection_technology_othr_txt,'')
	+ ISNULL(potw_ww_trtmnt_technology_unit_operation_code,'')
	+ ISNULL(potw_ww_trtmnt_technology_unit_operation_othr_txt,'')
);
UPDATE ICS_FLOW_LOCAL.ics_pretr_insp
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(suo_ref,'')
	+ ISNULL(CONVERT(varchar(50), suo_date),'')
	+ ISNULL(acceptance_haz_waste,'')
	+ ISNULL(acceptance_non_haz_indst_waste,'')
	+ ISNULL(acceptance_huled_domstic_wstes,'')
	+ ISNULL(annul_pretr_budget,'')
	+ ISNULL(inadequacy_smpl_insp_ind,'')
	+ ISNULL(adequacy_pretr_resources,'')
	+ ISNULL(dfcnc_idntfd_drng_iu_file_rviw,'')
	+ ISNULL(control_mech_dfcnc,'')
	+ ISNULL(legal_auth_dfcnc,'')
	+ ISNULL(dfcnc_intrprt_appl_pretr_stndr,'')
	+ ISNULL(dfcnc_dat_mgmt_pblc_prticipton,'')
	+ ISNULL(viol_iu_schd_rmd_msr,'')
	+ ISNULL(frml_rspn_viol_iu_schd_rmd_msr,'')
	+ ISNULL(CONVERT(varchar(50), annul_freq_influnt_toxcnt_smpl),'')
	+ ISNULL(CONVERT(varchar(50), annul_freq_efflu_toxcnt_smpl),'')
	+ ISNULL(CONVERT(varchar(50), annul_freq_sldg_toxcnt_smpl),'')
	+ ISNULL(CONVERT(varchar(50), num_si_us),'')
	+ ISNULL(CONVERT(varchar(50), si_us_without_control_mech),'')
	+ ISNULL(CONVERT(varchar(50), si_us_not_inspected),'')
	+ ISNULL(CONVERT(varchar(50), si_us_not_smpl),'')
	+ ISNULL(CONVERT(varchar(50), si_us_on_schd),'')
	+ ISNULL(CONVERT(varchar(50), si_us_snc_with_pretr_stndr),'')
	+ ISNULL(CONVERT(varchar(50), si_us_snc_with_rep_reqs),'')
	+ ISNULL(CONVERT(varchar(50), si_us_snc_with_pretr_schd),'')
	+ ISNULL(CONVERT(varchar(50), si_us_snc_publ_newspaper),'')
	+ ISNULL(CONVERT(varchar(50), viol_notices_issued_si_us),'')
	+ ISNULL(CONVERT(varchar(50), admin_orders_issued_si_us),'')
	+ ISNULL(CONVERT(varchar(50), civil_suts_fild_aginst_si_us),'')
	+ ISNULL(CONVERT(varchar(50), criminl_suts_fild_aginst_si_us),'')
	+ ISNULL(CONVERT(varchar(50), dollar_amt_pnlty_coll),'')
	+ ISNULL(i_us_whc_pnlty_hav_bee_coll,'')
	+ ISNULL(CONVERT(varchar(50), num_ci_us),'')
	+ ISNULL(CONVERT(varchar(50), ci_us_in_snc),'')
	+ ISNULL(pass_through_interference_ind,'')
);
UPDATE ICS_FLOW_LOCAL.ics_pretr_prmt
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', ICS_FLOW_LOCAL.ics_pretr_prmt.prmt_ident),
      data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ ISNULL(pretr_prog_reqd_ind_code,'')
	+ ISNULL(control_auth_st_agncy_code,'')
	+ ISNULL(control_auth_rgnl_agncy_code,'')
	+ ISNULL(control_auth_npdes_ident,'')
	+ ISNULL(CONVERT(varchar(50), pretr_prog_aprvd_date),'')
	+ ISNULL(rcvg_rcra_waste_ind,'')
	+ ISNULL(rcvg_remediation_waste_ind,'')
);
UPDATE ICS_FLOW_LOCAL.ics_pretr_prog_mod
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  pretr_prog_mod_type
	+ CONVERT(varchar(50), pretr_prog_mod_date)
	+ ISNULL(pretr_prog_mod_txt,'')
);
UPDATE ICS_FLOW_LOCAL.ics_pretr_prog_rep
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', prmt_ident + PROG_REP_FORM_SET_ID + CONVERT(varchar(50), PROG_REP_FORM_ID) ),
      data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ ISNULL(CONVERT(varchar(50), prog_rep_rcvd_date),'')
	+ ISNULL(CONVERT(varchar(50), prog_rep_start_date),'')
	+ ISNULL(CONVERT(varchar(50), prog_rep_end_date),'')
	+ ISNULL(elec_subm_type_code,'')
	+ ISNULL(prog_rep_npdes_dat_grp_num_code,'')
);
UPDATE ICS_FLOW_LOCAL.ics_prmt_bs_mgmt_practice
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  ssu_ident
	+ ISNULL(bs_mgmt_practice_code,'')
	+ ISNULL(bs_mgmt_practice_sub_catg_code,'')
	+ ISNULL(bs_mgmt_practice_sub_catg_txt,'')
	+ ISNULL(bs_operator_type_code,'')
	+ ISNULL(bs_cntnr_type_code,'')
	+ ISNULL(CONVERT(varchar(50), ssuid_vol_amt),'')
	+ ISNULL(pathogen_class_type_code,'')
	+ ISNULL(polut_loading_rates_exceedance_ind,'')
	+ ISNULL(surf_dspl_without_liner_ind,'')
	+ ISNULL(surf_dspl_site_spec_lmt_ind,'')
	+ ISNULL(surf_dspl_min_boundary_distance_code,'')
	+ ISNULL(bs_off_site_fac_prmt_ident,'')
);
UPDATE ICS_FLOW_LOCAL.ics_prmt_comp_type
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  prmt_comp_type_code
);
UPDATE ICS_FLOW_LOCAL.ics_prmt_featr
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', ICS_FLOW_LOCAL.ics_prmt_featr.prmt_ident + prmt_featr_ident),
      data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ prmt_featr_ident
	+ ISNULL(prmt_featr_type_code,'')
	+ ISNULL(prmt_featr_desc,'')
	+ ISNULL(CONVERT(varchar(50), prmt_featr_dsgn_flow_num),'')
	+ ISNULL(CONVERT(varchar(50), prmt_featr_actul_aver_flow_num),'')
	+ ISNULL(prmt_featr_st_wtr_body_code,'')
	+ ISNULL(prmt_featr_st_wtr_body_name,'')
	+ ISNULL(tier_level_name,'')
	+ ISNULL(impaired_wtr_ind,'')
	+ ISNULL(tmdl_completed_ind,'')
	+ ISNULL(prmt_featr_usr_dfnd_dat_elm_1,'')
	+ ISNULL(prmt_featr_usr_dfnd_dat_elm_2,'')
	+ ISNULL(CONVERT(varchar(50), fld_size),'')
	+ ISNULL(is_site_own_by_fac,'')
	+ ISNULL(is_systm_lined_with_leachate,'')
	+ ISNULL(does_unit_hav_daily_cover,'')
	+ ISNULL(CONVERT(varchar(50), prop_boundary_distance),'')
	+ ISNULL(is_reqd_nitrate_ground_wtr,'')
	+ ISNULL(CONVERT(varchar(50), well_num),'')
	+ ISNULL(src_prmt_featr_detail_txt,'')
);
UPDATE ICS_FLOW_LOCAL.ics_prmt_featr_char
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  prmt_featr_char
);
UPDATE ICS_FLOW_LOCAL.ics_prmt_featr_trtmnt_type
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  prmt_featr_trtmnt_type_code
);
UPDATE ICS_FLOW_LOCAL.ics_prmt_ident
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  prmt_ident
);
UPDATE ICS_FLOW_LOCAL.ics_prmt_reissu
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', ICS_FLOW_LOCAL.ics_prmt_reissu.prmt_ident),
      data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ CONVERT(varchar(50), prmt_issue_date)
	+ CONVERT(varchar(50), prmt_effective_date)
	+ CONVERT(varchar(50), prmt_expr_date)
);
UPDATE ICS_FLOW_LOCAL.ics_prmt_schd_evt
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  schd_evt_code
	+ CONVERT(varchar(50), schd_date)
	+ ISNULL(CONVERT(varchar(50), schd_rep_rcvd_date),'')
	+ ISNULL(CONVERT(varchar(50), schd_actul_date),'')
	+ ISNULL(CONVERT(varchar(50), schd_proj_date),'')
	+ ISNULL(schd_usr_dfnd_dat_elm_1,'')
	+ ISNULL(schd_usr_dfnd_dat_elm_2,'')
	+ ISNULL(schd_evt_cmnts,'')
);
UPDATE ICS_FLOW_LOCAL.ics_prmt_schd_evt_viol_elem
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  prmt_ident
	+ CONVERT(varchar(50), narr_cond_num)
	+ schd_evt_code
	+ CONVERT(varchar(50), schd_date)
	+ schd_viol_code
);
UPDATE ICS_FLOW_LOCAL.ics_prmt_schd_viol
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  prmt_ident
	+ CONVERT(varchar(50), narr_cond_num)
	+ schd_evt_code
	+ CONVERT(varchar(50), schd_date)
);
UPDATE ICS_FLOW_LOCAL.ics_prmt_term
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', ICS_FLOW_LOCAL.ics_prmt_term.prmt_ident),
      data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ CONVERT(varchar(50), prmt_term_date)
);
UPDATE ICS_FLOW_LOCAL.ics_prmt_track_evt
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', ICS_FLOW_LOCAL.ics_prmt_track_evt.prmt_ident + prmt_track_evt_code +CONVERT(varchar(50), prmt_track_evt_date)),
      data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ prmt_track_evt_code
	+ CONVERT(varchar(50), prmt_track_evt_date)
	+ ISNULL(prmt_track_cmnts_txt,'')
);
UPDATE ICS_FLOW_LOCAL.ics_prog
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  prog_code
);
UPDATE ICS_FLOW_LOCAL.ics_prog_defcy_type
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  prog_defcy_type_code
);
UPDATE ICS_FLOW_LOCAL.ics_progs_viol
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  progs_viol_code
);
UPDATE ICS_FLOW_LOCAL.ics_proj_srcs_fund
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  proj_srcs_fund_code
);
UPDATE ICS_FLOW_LOCAL.ics_proj_type
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  proj_type_code
	+ ISNULL(proj_type_code_othr_desc,'')
);
UPDATE ICS_FLOW_LOCAL.ics_proposed_cnst_sw_bm_ps
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  proposed_cnst_sw_bmp_code
	+ ISNULL(proposed_cnst_sw_bmp_othr_txt,'')
);
UPDATE ICS_FLOW_LOCAL.ics_proposed_indst_sw_bm_ps
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  proposed_indst_sw_bmp_code
	+ ISNULL(proposed_indst_sw_bmp_othr_txt,'')
);
UPDATE ICS_FLOW_LOCAL.ics_proposed_post_cnst_sw_bm_ps
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  proposed_post_cnst_sw_bmp_code
	+ ISNULL(proposed_post_cnst_sw_bmp_othr_txt,'')
);
UPDATE ICS_FLOW_LOCAL.ics_rep_non_cmpl_stat
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(CONVERT(varchar(50), rep_non_cmpl_stat_code_year),'')
	+ ISNULL(CONVERT(varchar(50), rep_non_cmpl_stat_code_quarter),'')
	+ ISNULL(rep_non_cmpl_manual_stat_code,'')
);
UPDATE ICS_FLOW_LOCAL.ics_rep_param
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  param_code
	+ mon_site_desc_code
	+ CONVERT(varchar(50), lmt_season_num)
	+ ISNULL(rep_smpl_type_txt,'')
	+ ISNULL(rep_freq_code,'')
	+ ISNULL(CONVERT(varchar(50), rep_num_of_excursions),'')
	+ ISNULL(concen_num_rep_unit_meas_code,'')
	+ ISNULL(qty_num_rep_unit_meas_code,'')
);
UPDATE ICS_FLOW_LOCAL.ics_residual_desgn_dtrmn
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  residual_desgn_dtrmn_code
	+ ISNULL(residual_desgn_dtrmn_othr_txt,'')
);
UPDATE ICS_FLOW_LOCAL.ics_satl_coll_systm
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  satl_coll_systm_ident
	+ satl_coll_systm_name
);
UPDATE ICS_FLOW_LOCAL.ics_schd_evt_viol
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	   ISNULL(rep_non_cmpl_resl_code,'')
	+ ISNULL(CONVERT(varchar(50), rep_non_cmpl_resl_date),'')
);
UPDATE ICS_FLOW_LOCAL.ics_sep
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  CONVERT(varchar(50), sep_ident)
	+ ISNULL(sep_desc,'')
	+ ISNULL(CONVERT(varchar(50), sep_pnlty_assessment_amt),'')
);
UPDATE ICS_FLOW_LOCAL.ics_sewer_ovrflw_bypass_cause
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  sewer_ovrflw_bypass_cause_code
	+ ISNULL(sewer_ovrflw_bypass_cause_othr_txt,'')
);
UPDATE ICS_FLOW_LOCAL.ics_sewer_ovrflw_bypass_corr_actn
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  sewer_ovrflw_bypass_corr_actn_code
	+ ISNULL(sewer_ovrflw_bypass_corr_actn_othr_txt,'')
);
UPDATE ICS_FLOW_LOCAL.ics_sewer_ovrflw_bypass_evt_rep
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', prmt_ident + PROG_REP_FORM_SET_ID + CONVERT(varchar(50), PROG_REP_FORM_ID) ),
      data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ ISNULL(CONVERT(varchar(50), prog_rep_rcvd_date),'')
	+ ISNULL(CONVERT(varchar(50), prog_rep_start_date),'')
	+ ISNULL(CONVERT(varchar(50), prog_rep_end_date),'')
	+ ISNULL(elec_subm_type_code,'')
	+ ISNULL(prog_rep_npdes_dat_grp_num_code,'')
);
UPDATE ICS_FLOW_LOCAL.ics_sewer_ovrflw_bypass_impact
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  sewer_ovrflw_bypass_impact_code
	+ ISNULL(sewer_ovrflw_bypass_impact_othr_txt,'')
);
UPDATE ICS_FLOW_LOCAL.ics_sewer_ovrflw_bypass_rcvg_wtr
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  sewer_ovrflw_bypass_rcvg_wtr
);
UPDATE ICS_FLOW_LOCAL.ics_sewer_ovrflw_bypass_rep_evt
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(CONVERT(varchar(50), lat_meas),'')
	+ ISNULL(CONVERT(varchar(50), long_meas),'')
	+ ISNULL(prmt_featr_ident,'')
	+ ISNULL(dsch_quantification_method_code,'')
	+ ISNULL(CONVERT(varchar(50), sewer_ovrflw_bypass_dsch_rate_gph),'')
	+ ISNULL(CONVERT(varchar(50), sewer_ovrflw_bypass_dsch_vol_gal),'')
	+ ISNULL(sewer_ovrflw_bypass_desc_txt,'')
	+ ISNULL(CONVERT(varchar(50), sewer_ovrflw_bypass_rep_req_code),'')
	+ ISNULL(wet_weather_occurance_ind,'')
	+ ISNULL(sewer_ovrflw_strct_type_code,'')
	+ ISNULL(sewer_ovrflw_strct_type_code_othr_txt,'')
	+ ISNULL(coll_systm_ident,'')
	+ ISNULL(anticipated_bypass_txt,'')
	+ ISNULL(anticipated_bypass_expect_lmt_viol,'')
	+ ISNULL(anticipated_bypass_expect_lmt_viol_txt,'')
	+ CONVERT(varchar(50), sewer_ovrflw_bypass_duration_hours)
	+ CONVERT(varchar(50), sewer_ovrflw_bypass_start_date_time)
	+ ISNULL(CONVERT(varchar(50), sewer_ovrflw_bypass_end_date_time),'')
);
UPDATE ICS_FLOW_LOCAL.ics_sewer_ovrflw_bypass_type
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  sewer_ovrflw_bypass_type_code
);
UPDATE ICS_FLOW_LOCAL.ics_sewer_ovrflw_trtmnt
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  sewer_ovrflw_trtmnt_code
);
UPDATE ICS_FLOW_LOCAL.ics_sic_code
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  sic_code
	+ sic_primary_ind_code
);
UPDATE ICS_FLOW_LOCAL.ics_siu_desgn_type
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  siu_desgn_type
);
UPDATE ICS_FLOW_LOCAL.ics_snc_listing_months
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  snc_listing_months
);
UPDATE ICS_FLOW_LOCAL.ics_snc_pretr_stnd_lmts_parameters
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  snc_pretr_stnd_lmts_parameters
);
UPDATE ICS_FLOW_LOCAL.ics_sngl_evt_viol
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', ICS_FLOW_LOCAL.ics_sngl_evt_viol.prmt_ident + sngl_evt_viol_code +CONVERT(varchar(50), sngl_evt_viol_date)),
      data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ sngl_evt_viol_code
	+ CONVERT(varchar(50), sngl_evt_viol_date)
	+ ISNULL(CONVERT(varchar(50), sngl_evt_viol_end_date),'')
	+ ISNULL(rep_non_cmpl_detect_code,'')
	+ ISNULL(CONVERT(varchar(50), rep_non_cmpl_detect_date),'')
	+ ISNULL(rep_non_cmpl_resl_code,'')
	+ ISNULL(CONVERT(varchar(50), rep_non_cmpl_resl_date),'')
	+ ISNULL(sngl_evt_usr_dfnd_fld_1,'')
	+ ISNULL(sngl_evt_usr_dfnd_fld_2,'')
	+ ISNULL(sngl_evt_usr_dfnd_fld_3,'')
	+ ISNULL(sngl_evt_usr_dfnd_fld_4,'')
	+ ISNULL(sngl_evt_usr_dfnd_fld_5,'')
	+ ISNULL(sngl_evt_cmnt_txt,'')
);
UPDATE ICS_FLOW_LOCAL.ics_sngl_evts_viol
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  prmt_ident
	+ sngl_evt_viol_code
	+ CONVERT(varchar(50), sngl_evt_viol_date)
);
UPDATE ICS_FLOW_LOCAL.ics_sso_insp
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(CONVERT(varchar(50), sso_evt_date),'')
	+ ISNULL(cause_sso_ovrflw_evt,'')
	+ ISNULL(CONVERT(varchar(50), lat_meas),'')
	+ ISNULL(CONVERT(varchar(50), long_meas),'')
	+ ISNULL(sso_ovrflw_loc_street,'')
	+ ISNULL(CONVERT(varchar(50), duration_sso_ovrflw_evt),'')
	+ ISNULL(CONVERT(varchar(50), sso_vol),'')
	+ ISNULL(name_rcvg_wtr,'')
	+ ISNULL(desc_stps_taken,'')
);
UPDATE ICS_FLOW_LOCAL.ics_sso_stps
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  stps_rduce_prevnt_mitigte
	+ ISNULL(othr_stps_rduce_prevnt_mitigte,'')
);
UPDATE ICS_FLOW_LOCAL.ics_sso_systm_comp
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  systm_comp
	+ ISNULL(othr_systm_comp,'')
);
UPDATE ICS_FLOW_LOCAL.ics_subsector_code_plus_desc
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  subsector_code_plus_desc
);
UPDATE ICS_FLOW_LOCAL.ics_surf_dspl_site
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(pathogen_reduction_ind,'')
	+ ISNULL(vector_reduction_ind,'')
	+ ISNULL(mgmt_practice_ind,'')
	+ ISNULL(cert_statement_ind,'')
	+ ISNULL(cert_first_name,'')
	+ ISNULL(cert_last_name,'')
	+ ISNULL(class_a_alt_used,'')
	+ ISNULL(class_a_alts_txt,'')
	+ ISNULL(class_b_alt_used,'')
	+ ISNULL(class_b_alts_txt,'')
	+ ISNULL(var_alt_used,'')
	+ ISNULL(var_alts_txt,'')
);
UPDATE ICS_FLOW_LOCAL.ics_sw_cnst_indst_insp
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(swppp_eval_basis_code,'')
	+ ISNULL(CONVERT(varchar(50), swppp_eval_date),'')
	+ ISNULL(swppp_eval_desc_txt,'')
	+ ISNULL(CONVERT(varchar(50), no_exposure_auth_date),'')
);
UPDATE ICS_FLOW_LOCAL.ics_sw_cnst_insp
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
null);
UPDATE ICS_FLOW_LOCAL.ics_sw_cnst_non_cnst_insp
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
null);
UPDATE ICS_FLOW_LOCAL.ics_sw_cnst_prmt
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', ICS_FLOW_LOCAL.ics_sw_cnst_prmt.prmt_ident),
      data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ ISNULL(st_wtr_body_name,'')
	+ ISNULL(rcvg_ms_4_name,'')
	+ ISNULL(impaired_wtr_ind,'')
	+ ISNULL(hist_prop_ind,'')
	+ ISNULL(hist_prop_crit_met_code,'')
	+ ISNULL(species_crit_habitat_ind,'')
	+ ISNULL(species_crit_met_code,'')
	+ ISNULL(CONVERT(varchar(50), indst_acty_size),'')
	+ ISNULL(proj_type_code,'')
	+ ISNULL(CONVERT(varchar(50), est_start_date),'')
	+ ISNULL(CONVERT(varchar(50), est_complete_date),'')
	+ ISNULL(CONVERT(varchar(50), est_area_disturbed_acres_num),'')
	+ ISNULL(proj_plan_size_code,'')
	+ ISNULL(strct_demoed_ind,'')
	+ ISNULL(strct_demoed_floor_space_ind,'')
	+ ISNULL(predev_land_use_ind,'')
	+ ISNULL(erth_distrb_activities_ind,'')
	+ ISNULL(erth_distrb_emrgcy_ind,'')
	+ ISNULL(previous_sw_dsch_ind,'')
	+ ISNULL(othr_prmt_ident,'')
	+ ISNULL(cgp_ind,'')
	+ ISNULL(ms_4_dsch_ind,'')
	+ ISNULL(wtr_prox_ind,'')
	+ ISNULL(antideg_ind,'')
	+ ISNULL(trtmnt_chems_ind,'')
	+ ISNULL(cationic_chems_ind,'')
	+ ISNULL(cationic_chems_auth_ind,'')
	+ ISNULL(swppp_prep_ind,'')
	+ ISNULL(CONVERT(varchar(50), cnst_site_ttl_area),'')
	+ ISNULL(CONVERT(varchar(50), post_cnst_ttl_impervious_area),'')
	+ ISNULL(soil_fill_material_desc_txt,'')
	+ ISNULL(CONVERT(varchar(50), runoff_coefficient_post_cnst),'')
	+ ISNULL(subsurface_erth_disturbance_ind,'')
	+ ISNULL(prior_surveys_evals_ind,'')
	+ ISNULL(subsurface_erth_disturbance_control_ind,'')
	+ ISNULL(CONVERT(varchar(50), not_term_date),'')
	+ ISNULL(CONVERT(varchar(50), not_sign_date),'')
	+ ISNULL(CONVERT(varchar(50), not_postmark_date),'')
	+ ISNULL(CONVERT(varchar(50), not_rcvd_date),'')
	+ ISNULL(CONVERT(varchar(50), lew_auth_date),'')
);
UPDATE ICS_FLOW_LOCAL.ics_sw_indst_annul_rep
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', ICS_FLOW_LOCAL.ics_sw_indst_annul_rep.prmt_ident +CONVERT(varchar(50), indst_sw_annul_rep_rcvd_date)),
      data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ CONVERT(varchar(50), indst_sw_annul_rep_rcvd_date)
	+ ISNULL(fac_insp_summ_txt,'')
	+ ISNULL(visual_assessment_summ_txt,'')
	+ ISNULL(no_further_reduction_summ_txt,'')
	+ ISNULL(corr_actn_summ_txt,'')
);
UPDATE ICS_FLOW_LOCAL.ics_sw_indst_prmt
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', ICS_FLOW_LOCAL.ics_sw_indst_prmt.prmt_ident),
      data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ ISNULL(st_wtr_body_name,'')
	+ ISNULL(rcvg_ms_4_name,'')
	+ ISNULL(impaired_wtr_ind,'')
	+ ISNULL(hist_prop_ind,'')
	+ ISNULL(hist_prop_crit_met_code,'')
	+ ISNULL(species_crit_habitat_ind,'')
	+ ISNULL(species_crit_met_code,'')
	+ ISNULL(CONVERT(varchar(50), indst_acty_size),'')
	+ ISNULL(web_addr_url,'')
	+ ISNULL(activities_exposed_sw_txt,'')
	+ ISNULL(assc_pollutants_txt,'')
	+ ISNULL(control_msr_txt,'')
	+ ISNULL(schd_control_msr_txt,'')
	+ ISNULL(CONVERT(varchar(50), indst_ttl_impervious_surf_area),'')
	+ ISNULL(tier_two_ind,'')
	+ ISNULL(tier_three_ind,'')
);
UPDATE ICS_FLOW_LOCAL.ics_sw_ms_4_insp
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(CONVERT(varchar(50), ms_4_annul_expen_dollars),'')
	+ ISNULL(CONVERT(varchar(50), ms_4_annul_expen_year),'')
	+ ISNULL(CONVERT(varchar(50), ms_4_budget_dollars),'')
	+ ISNULL(CONVERT(varchar(50), ms_4_budget_year),'')
	+ ISNULL(major_outfall_est_meas_ind,'')
	+ ISNULL(CONVERT(varchar(50), major_outfall_num),'')
	+ ISNULL(minor_outfall_est_meas_ind,'')
	+ ISNULL(CONVERT(varchar(50), minor_outfall_num),'')
);
UPDATE ICS_FLOW_LOCAL.ics_sw_non_cnst_insp
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
null);
UPDATE ICS_FLOW_LOCAL.ics_sw_unprmt_cnst_insp
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(CONVERT(varchar(50), est_start_date),'')
	+ ISNULL(CONVERT(varchar(50), est_complete_date),'')
	+ ISNULL(CONVERT(varchar(50), est_area_disturbed_acres_num),'')
	+ ISNULL(proj_plan_size_code,'')
);
UPDATE ICS_FLOW_LOCAL.ics_swms_4_annul_prog_rep
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', prmt_ident + PROG_REP_FORM_SET_ID + CONVERT(varchar(50), PROG_REP_FORM_ID) ),
      data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ ISNULL(CONVERT(varchar(50), prog_rep_rcvd_date),'')
	+ ISNULL(CONVERT(varchar(50), prog_rep_start_date),'')
	+ ISNULL(CONVERT(varchar(50), prog_rep_end_date),'')
	+ ISNULL(elec_subm_type_code,'')
	+ ISNULL(prog_rep_npdes_dat_grp_num_code,'')
);
UPDATE ICS_FLOW_LOCAL.ics_swms_4_prmt
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', ICS_FLOW_LOCAL.ics_swms_4_prmt.prmt_ident),
      data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ ISNULL(ms_4_prmt_phase_code,'')
	+ ISNULL(ms_4_prmt_phase_txt,'')
);
UPDATE ICS_FLOW_LOCAL.ics_teleph
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  teleph_num_type_code
	+ ISNULL(teleph_num,'')
	+ ISNULL(teleph_ext_num,'')
);
UPDATE ICS_FLOW_LOCAL.ics_tmdl_pollutants
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  tmdl_ident
	+ tmdl_name
);
UPDATE ICS_FLOW_LOCAL.ics_tmdl_polut
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  CONVERT(varchar(50), tmdl_polut_code)
);
UPDATE ICS_FLOW_LOCAL.ics_trtmnt_chems_list
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  trtmnt_chems_list
);
UPDATE ICS_FLOW_LOCAL.ics_unprmt_fac
   SET key_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', ICS_FLOW_LOCAL.ics_unprmt_fac.prmt_ident),
      data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ ISNULL(locality_name,'')
	+ ISNULL(loc_addr_city_code,'')
	+ ISNULL(loc_addr_county_code,'')
	+ ISNULL(fac_site_name,'')
	+ ISNULL(loc_addr_txt,'')
	+ ISNULL(suppl_loc_txt,'')
	+ ISNULL(loc_st_code,'')
	+ ISNULL(loc_zip_code,'')
	+ ISNULL(loc_country_code,'')
	+ ISNULL(org_duns_num,'')
	+ ISNULL(st_fac_ident,'')
	+ ISNULL(st_rgn_code,'')
	+ ISNULL(CONVERT(varchar(50), fac_congr_district_num),'')
	+ ISNULL(fac_type_of_ownership_code,'')
	+ ISNULL(fedr_fac_ident_num,'')
	+ ISNULL(fedr_agncy_code,'')
	+ ISNULL(tribal_land_code,'')
	+ ISNULL(cnst_proj_name,'')
	+ ISNULL(CONVERT(varchar(50), cnst_proj_lat_meas),'')
	+ ISNULL(CONVERT(varchar(50), cnst_proj_long_meas),'')
	+ ISNULL(section_township_rng,'')
	+ ISNULL(fac_cmnts,'')
	+ ISNULL(fac_usr_dfnd_fld_1,'')
	+ ISNULL(fac_usr_dfnd_fld_2,'')
	+ ISNULL(fac_usr_dfnd_fld_3,'')
	+ ISNULL(fac_usr_dfnd_fld_4,'')
	+ ISNULL(fac_usr_dfnd_fld_5,'')
	+ ISNULL(prmt_cmnts_txt,'')
);
UPDATE ICS_FLOW_LOCAL.ics_vector_a_reduction_type
    SET data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', 
	  vector_a_reduction_type_code
);

--Create KEY_HASH for modules with conditional keys (5 data families)

UPDATE ICS_FLOW_LOCAL.ics_cmpl_mon_lnk
   SET KEY_HASH = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1',
						ics_cmpl_mon_lnk.cmpl_mon_ident
                         + COALESCE(
                                   ics_lnk_cmpl_mon.cmpl_mon_ident
								   ,ics_lnk_enfrc_actn.enfrc_actn_ident
                                   ,CONCAT(
										ics_lnk_sngl_evt.prmt_ident
										,ics_lnk_sngl_evt.sngl_evt_viol_code
										,CONVERT(varchar(50), ics_lnk_sngl_evt.sngl_evt_viol_date)
                                    ) 
                         )
						)
	FROM ICS_FLOW_LOCAL.ics_cmpl_mon_lnk ics_cmpl_mon_lnk
		LEFT JOIN ICS_FLOW_LOCAL.ics_lnk_cmpl_mon ics_lnk_cmpl_mon on ics_lnk_cmpl_mon.ics_cmpl_mon_lnk_id = ics_cmpl_mon_lnk.ics_cmpl_mon_lnk_id
		LEFT JOIN ICS_FLOW_LOCAL.ics_lnk_enfrc_actn ics_lnk_enfrc_actn on ics_lnk_enfrc_actn.ics_cmpl_mon_lnk_id = ics_cmpl_mon_lnk.ics_cmpl_mon_lnk_id
		LEFT JOIN ICS_FLOW_LOCAL.ics_lnk_sngl_evt ics_lnk_sngl_evt on ics_lnk_sngl_evt.ics_cmpl_mon_lnk_id = ics_cmpl_mon_lnk.ics_cmpl_mon_lnk_id
;


-- 2025-04-13 CRT: try new method
-- ------------------------------
-- ICS_SCHD_EVT_VIOL

   update [ICS_SCHD_EVT_VIOL] 
  set KEY_HASH = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1',
	   concat(
	   PRMT_IDENT
	   ,NARR_COND_NUM
	   ,SCHD_EVT_CODE
	   ,SCHD_DATE
	   ,SCHD_VIOL_CODE
	   ))
 from [ICS_FLOW_LOCAL].[ICS_SCHD_EVT_VIOL] [ICS_SCHD_EVT_VIOL]    JOIN [ICS_FLOW_LOCAL].[ICS_PRMT_SCHD_EVT_VIOL_ELEM] [I1]   ON [I1].[ICS_SCHD_EVT_VIOL_ID] = [ICS_SCHD_EVT_VIOL].[ICS_SCHD_EVT_VIOL_ID]   
 ;

  update [ICS_SCHD_EVT_VIOL] 
  set KEY_HASH = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1',
	   concat(
	   ENFRC_ACTN_IDENT
	   ,FINAL_ORDER_IDENT
	   ,PRMT_IDENT
	   ,CMPL_SCHD_NUM
	   ,SCHD_EVT_CODE
	   ,SCHD_DATE
	   ))
  from [ICS_FLOW_LOCAL].[ICS_SCHD_EVT_VIOL] [ICS_SCHD_EVT_VIOL]    JOIN [ICS_FLOW_LOCAL].[ICS_CMPL_SCHD_EVT_VIOL_ELEM] [I2]   ON [I2].[ICS_SCHD_EVT_VIOL_ID] = [ICS_SCHD_EVT_VIOL].[ICS_SCHD_EVT_VIOL_ID]   
;

/*		
UPDATE ICS_FLOW_LOCAL.ics_schd_evt_viol
   SET KEY_HASH = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1',
                              COALESCE(ics_prmt_schd_evt_viol_elem.prmt_ident,ics_cmpl_schd_evt_viol_elem.prmt_ident,'')
                              + ISNULL(CONVERT(varchar(50), ics_prmt_schd_evt_viol_elem.narr_cond_num),'')
                              + COALESCE(ics_prmt_schd_evt_viol_elem.schd_evt_code,ics_cmpl_schd_evt_viol_elem.schd_evt_code,'')
                              + COALESCE(CONVERT(varchar(50), ics_prmt_schd_evt_viol_elem.schd_date),CONVERT(varchar(50), ics_cmpl_schd_evt_viol_elem.schd_date),'')
                              + COALESCE(ics_prmt_schd_evt_viol_elem.schd_viol_code,ics_cmpl_schd_evt_viol_elem.schd_viol_code,'')
                              + ISNULL(ics_cmpl_schd_evt_viol_elem.enfrc_actn_ident,'')
                              + ISNULL(CONVERT(varchar(50), ics_cmpl_schd_evt_viol_elem.final_order_ident),'')
                              -- + ISNULL(ics_cmpl_schd_evt_viol_elem.prmt_ident,'') -- Assuming this goes to prmt_ident not prmt_ident_2
                              + ISNULL(CONVERT(varchar(50), ics_cmpl_schd_evt_viol_elem.cmpl_schd_num),'')
                              -- + ISNULL(ics_cmpl_schd_evt_viol_elem.schd_evt_code,'')
                              -- + ISNULL(CONVERT(varchar(50), ics_cmpl_schd_evt_viol_elem.schd_date),'')
                              -- + ISNULL(ics_cmpl_schd_evt_viol_elem.schd_viol_code,'')
                              )
  FROM ICS_FLOW_LOCAL.ics_schd_evt_viol ics_schd_evt_viol
            LEFT JOIN ICS_FLOW_LOCAL.ics_prmt_schd_evt_viol_elem ics_prmt_schd_evt_viol_elem on ics_prmt_schd_evt_viol_elem.ics_schd_evt_viol_id = ics_schd_evt_viol.ics_schd_evt_viol_id
            LEFT JOIN ICS_FLOW_LOCAL.ics_cmpl_schd_evt_viol_elem ics_cmpl_schd_evt_viol_elem on ics_cmpl_schd_evt_viol_elem.ics_schd_evt_viol_id = ics_schd_evt_viol.ics_schd_evt_viol_id;
 */           


-- 2025-04-13 CRT: try new method
-- ------------------------------
-- ICS_ENFRC_ACTN_VIOL_LNK
update ICS_ENFRC_ACTN_VIOL_LNK set KEY_HASH = 
(select KEY_HASH from
(

	-- DMR (DMR Parameter)
	select 
	[ICS_ENFRC_ACTN_VIOL_LNK].[ICS_ENFRC_ACTN_VIOL_LNK_ID],
	   ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1',
	   concat(
	[ICS_ENFRC_ACTN_VIOL_LNK].ENFRC_ACTN_IDENT
	,PRMT_IDENT
	,PRMT_FEATR_IDENT
	,LMT_SET_DESIGNATOR
	,MON_PERIOD_END_DATE
	,PARAM_CODE
	,MON_SITE_DESC_CODE
	,LMT_SEASON_NUM
	)) as KEY_HASH
	from [ICS_FLOW_LOCAL].[ICS_ENFRC_ACTN_VIOL_LNK] [ICS_ENFRC_ACTN_VIOL_LNK]    JOIN [ICS_FLOW_LOCAL].[ICS_DSCH_MON_REP_PARAM_VIOL] [I1]   ON [I1].[ICS_ENFRC_ACTN_VIOL_LNK_ID] = [ICS_ENFRC_ACTN_VIOL_LNK].[ICS_ENFRC_ACTN_VIOL_LNK_ID]   

	union
	-- DV (DMR)
	select 
	[ICS_ENFRC_ACTN_VIOL_LNK].[ICS_ENFRC_ACTN_VIOL_LNK_ID],
	   ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1',
	   concat(
	[ICS_ENFRC_ACTN_VIOL_LNK].ENFRC_ACTN_IDENT
	,PRMT_IDENT
	,PRMT_FEATR_IDENT
	,LMT_SET_DESIGNATOR
	,MON_PERIOD_END_DATE
	))
	from [ICS_FLOW_LOCAL].[ICS_ENFRC_ACTN_VIOL_LNK] [ICS_ENFRC_ACTN_VIOL_LNK]    JOIN [ICS_FLOW_LOCAL].[ICS_DSCH_MON_REP_VIOL] [I2]   ON [I2].[ICS_ENFRC_ACTN_VIOL_LNK_ID] = [ICS_ENFRC_ACTN_VIOL_LNK].[ICS_ENFRC_ACTN_VIOL_LNK_ID]   

	union
	-- Permit ScheduleViolation 
	select
	[ICS_ENFRC_ACTN_VIOL_LNK].[ICS_ENFRC_ACTN_VIOL_LNK_ID],
	   ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1',
	   concat(
	[ICS_ENFRC_ACTN_VIOL_LNK].ENFRC_ACTN_IDENT
	,PRMT_IDENT
	,NARR_COND_NUM
	,SCHD_EVT_CODE
	,SCHD_DATE
	))
	from [ICS_FLOW_LOCAL].[ICS_ENFRC_ACTN_VIOL_LNK] [ICS_ENFRC_ACTN_VIOL_LNK]    JOIN [ICS_FLOW_LOCAL].[ICS_PRMT_SCHD_VIOL] [I3]   ON [I3].[ICS_ENFRC_ACTN_VIOL_LNK_ID] = [ICS_ENFRC_ACTN_VIOL_LNK].[ICS_ENFRC_ACTN_VIOL_LNK_ID]   

	union
	-- SEV
	select 
	[ICS_ENFRC_ACTN_VIOL_LNK].[ICS_ENFRC_ACTN_VIOL_LNK_ID],
	   ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1',
	   concat(
	[ICS_ENFRC_ACTN_VIOL_LNK].ENFRC_ACTN_IDENT
	,PRMT_IDENT
	,SNGL_EVT_VIOL_CODE
	,SNGL_EVT_VIOL_DATE
	))
	from [ICS_FLOW_LOCAL].[ICS_ENFRC_ACTN_VIOL_LNK] [ICS_ENFRC_ACTN_VIOL_LNK]    JOIN [ICS_FLOW_LOCAL].[ICS_SNGL_EVTS_VIOL] [I4]   ON [I4].[ICS_ENFRC_ACTN_VIOL_LNK_ID] = [ICS_ENFRC_ACTN_VIOL_LNK].[ICS_ENFRC_ACTN_VIOL_LNK_ID]   

	union
	-- CS  Compliance Schedule Violation
	select  
	[ICS_ENFRC_ACTN_VIOL_LNK].[ICS_ENFRC_ACTN_VIOL_LNK_ID],
	   ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1',
	   concat(
	[ICS_ENFRC_ACTN_VIOL_LNK].ENFRC_ACTN_IDENT
	,FINAL_ORDER_IDENT
	,PRMT_IDENT
	,CMPL_SCHD_NUM
	,SCHD_EVT_CODE
	,SCHD_DATE
	))
	from [ICS_FLOW_LOCAL].[ICS_ENFRC_ACTN_VIOL_LNK] [ICS_ENFRC_ACTN_VIOL_LNK]    JOIN [ICS_FLOW_LOCAL].[ICS_CMPL_SCHD_VIOL] [I5]   ON [I5].[ICS_ENFRC_ACTN_VIOL_LNK_ID] = [ICS_ENFRC_ACTN_VIOL_LNK].[ICS_ENFRC_ACTN_VIOL_LNK_ID]   

) vw
where
vw.ICS_ENFRC_ACTN_VIOL_LNK_ID = ICS_ENFRC_ACTN_VIOL_LNK.ICS_ENFRC_ACTN_VIOL_LNK_ID)
;


-- 2025-04-13 CRT: try new method
-- ------------------------------
-- ICS_FINAL_ORDER_VIOL_LNK
update ICS_FINAL_ORDER_VIOL_LNK set KEY_HASH = 
(select KEY_HASH from
(

	-- DMR (DMR Parameter)
	select 
	[ICS_FINAL_ORDER_VIOL_LNK].[ICS_FINAL_ORDER_VIOL_LNK_ID],
	   ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1',
	   concat(
	[ICS_FINAL_ORDER_VIOL_LNK].ENFRC_ACTN_IDENT
	,[ICS_FINAL_ORDER_VIOL_LNK].FINAL_ORDER_IDENT
	,PRMT_IDENT
	,PRMT_FEATR_IDENT
	,LMT_SET_DESIGNATOR
	,MON_PERIOD_END_DATE
	,PARAM_CODE
	,MON_SITE_DESC_CODE
	,LMT_SEASON_NUM
	)) as KEY_HASH
	from [ICS_FLOW_LOCAL].[ICS_FINAL_ORDER_VIOL_LNK] [ICS_FINAL_ORDER_VIOL_LNK]    JOIN [ICS_FLOW_LOCAL].[ICS_DSCH_MON_REP_PARAM_VIOL] [I1]   ON [I1].[ICS_FINAL_ORDER_VIOL_LNK_ID] = [ICS_FINAL_ORDER_VIOL_LNK].[ICS_FINAL_ORDER_VIOL_LNK_ID]   

	union
	-- DV (DMR)
	select 
	[ICS_FINAL_ORDER_VIOL_LNK].[ICS_FINAL_ORDER_VIOL_LNK_ID],
	   ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1',
	   concat(
	[ICS_FINAL_ORDER_VIOL_LNK].ENFRC_ACTN_IDENT
	,[ICS_FINAL_ORDER_VIOL_LNK].FINAL_ORDER_IDENT
	,PRMT_IDENT
	,PRMT_FEATR_IDENT
	,LMT_SET_DESIGNATOR
	,MON_PERIOD_END_DATE
	))
	from [ICS_FLOW_LOCAL].[ICS_FINAL_ORDER_VIOL_LNK] [ICS_FINAL_ORDER_VIOL_LNK]    JOIN [ICS_FLOW_LOCAL].[ICS_DSCH_MON_REP_VIOL] [I2]   ON [I2].[ICS_FINAL_ORDER_VIOL_LNK_ID] = [ICS_FINAL_ORDER_VIOL_LNK].[ICS_FINAL_ORDER_VIOL_LNK_ID]   

	union
	-- Permit ScheduleViolation 
	select
	[ICS_FINAL_ORDER_VIOL_LNK].[ICS_FINAL_ORDER_VIOL_LNK_ID],
	   ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1',
	   concat(
	[ICS_FINAL_ORDER_VIOL_LNK].ENFRC_ACTN_IDENT
	,[ICS_FINAL_ORDER_VIOL_LNK].FINAL_ORDER_IDENT
	,PRMT_IDENT
	,NARR_COND_NUM
	,SCHD_EVT_CODE
	,SCHD_DATE
	))
	from [ICS_FLOW_LOCAL].[ICS_FINAL_ORDER_VIOL_LNK] [ICS_FINAL_ORDER_VIOL_LNK]    JOIN [ICS_FLOW_LOCAL].[ICS_PRMT_SCHD_VIOL] [I3]   ON [I3].[ICS_FINAL_ORDER_VIOL_LNK_ID] = [ICS_FINAL_ORDER_VIOL_LNK].[ICS_FINAL_ORDER_VIOL_LNK_ID]   

	union
	-- SEV
	select 
	[ICS_FINAL_ORDER_VIOL_LNK].[ICS_FINAL_ORDER_VIOL_LNK_ID],
	   ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1',
	   concat(
	[ICS_FINAL_ORDER_VIOL_LNK].ENFRC_ACTN_IDENT
	,[ICS_FINAL_ORDER_VIOL_LNK].FINAL_ORDER_IDENT
	,PRMT_IDENT
	,SNGL_EVT_VIOL_CODE
	,SNGL_EVT_VIOL_DATE
	))
	from [ICS_FLOW_LOCAL].[ICS_FINAL_ORDER_VIOL_LNK] [ICS_FINAL_ORDER_VIOL_LNK]    JOIN [ICS_FLOW_LOCAL].[ICS_SNGL_EVTS_VIOL] [I4]   ON [I4].[ICS_FINAL_ORDER_VIOL_LNK_ID] = [ICS_FINAL_ORDER_VIOL_LNK].[ICS_FINAL_ORDER_VIOL_LNK_ID]   

	union
	-- CS  Compliance Schedule Violation
	select  
	[ICS_FINAL_ORDER_VIOL_LNK].[ICS_FINAL_ORDER_VIOL_LNK_ID],
	   ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1',
	   concat(
	[ICS_FINAL_ORDER_VIOL_LNK].ENFRC_ACTN_IDENT
	,[ICS_FINAL_ORDER_VIOL_LNK].FINAL_ORDER_IDENT
	,I5.FINAL_ORDER_IDENT
	,PRMT_IDENT
	,CMPL_SCHD_NUM
	,SCHD_EVT_CODE
	,SCHD_DATE
	))
	from [ICS_FLOW_LOCAL].[ICS_FINAL_ORDER_VIOL_LNK] [ICS_FINAL_ORDER_VIOL_LNK]    JOIN [ICS_FLOW_LOCAL].[ICS_CMPL_SCHD_VIOL] [I5]   ON [I5].[ICS_FINAL_ORDER_VIOL_LNK_ID] = [ICS_FINAL_ORDER_VIOL_LNK].[ICS_FINAL_ORDER_VIOL_LNK_ID]   

) vw
where
vw.ICS_FINAL_ORDER_VIOL_LNK_ID = ICS_FINAL_ORDER_VIOL_LNK.ICS_FINAL_ORDER_VIOL_LNK_ID)
;



/* OLD final Order Linkages (worked only for DV,PS and SEV)
UPDATE ICS_FLOW_LOCAL.ics_final_order_viol_lnk
   SET KEY_HASH = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', ics_final_order_viol_lnk.enfrc_actn_ident
                                 + CONVERT(varchar(50), ics_final_order_viol_lnk.final_order_ident)
                                 + COALESCE(
                                          ics_prmt_schd_viol.prmt_ident
                                          ,ics_cmpl_schd_viol.prmt_ident
                                          ,ics_dsch_mon_rep_viol.prmt_ident
                                          ,ics_dsch_mon_rep_param_viol.prmt_ident
                                          ,ics_sngl_evts_viol.prmt_ident
                                          ,'')
                                 + ISNULL(CONVERT(varchar(50), ics_prmt_schd_viol.narr_cond_num),'')
                                 + COALESCE(
                                             ics_prmt_schd_viol.schd_evt_code
                                             ,ics_cmpl_schd_viol.schd_evt_code
                                             ,'')
                                 + COALESCE(
                                           CONVERT(varchar(50), ics_prmt_schd_viol.schd_date)
                                          , CONVERT(varchar(50),ics_cmpl_schd_viol.schd_date),'')
                                -- + ISNULL(CONVERT(varchar(50), ics_prmt_schd_viol.schd_date),'')
                                 + ISNULL(ics_cmpl_schd_viol.enfrc_actn_ident,'') -- enfrc_actn_ident_2
                                 + ISNULL(CONVERT(varchar(50), ics_cmpl_schd_viol.final_order_ident),'') -- final_order_ident_2
                                -- + ISNULL(ics_cmpl_schd_viol.prmt_ident,'')
                                 + ISNULL(CONVERT(varchar(50), ics_cmpl_schd_viol.cmpl_schd_num),'')
                                 + ISNULL(ics_dsch_mon_rep_viol.prmt_featr_ident,'')
                                 + ISNULL(ics_dsch_mon_rep_viol.lmt_set_designator,'')
                                 + ISNULL(CONVERT(varchar(50), ics_dsch_mon_rep_viol.mon_period_end_date),'')
                                -- + ISNULL(ics_dsch_mon_rep_param_viol.prmt_ident,'')
                                -- + ISNULL(ics_dsch_mon_rep_param_viol.prmt_featr_ident,'')
                                -- + ISNULL(ics_dsch_mon_rep_param_viol.lmt_set_designator,'')
                                -- + ISNULL(CONVERT(varchar(50), ics_dsch_mon_rep_param_viol.mon_period_end_date),'')
                                 + ISNULL(ics_dsch_mon_rep_param_viol.param_code,'')
                                 + ISNULL(ics_dsch_mon_rep_param_viol.mon_site_desc_code,'')
                                 + ISNULL(CONVERT(varchar(50), ics_dsch_mon_rep_param_viol.lmt_season_num),'')
                                 + ISNULL(ics_sngl_evts_viol.sngl_evt_viol_code,'')
                                -- + ISNULL(ics_cmpl_schd_viol.schd_evt_code,'')
                                -- + ISNULL(CONVERT(varchar(50), ics_cmpl_schd_viol.schd_date),'')
                                -- + ISNULL(ics_dsch_mon_rep_viol.prmt_ident,'')
                                -- + ISNULL(ics_sngl_evts_viol.prmt_ident,'')
                                 + ISNULL(CONVERT(varchar(50), ics_sngl_evts_viol.sngl_evt_viol_date),''))
     FROM ICS_FLOW_LOCAL.ics_final_order_viol_lnk ics_final_order_viol_lnk
       LEFT JOIN ICS_FLOW_LOCAL.ics_prmt_schd_viol ics_prmt_schd_viol on ics_prmt_schd_viol.ics_final_order_viol_lnk_id = ics_final_order_viol_lnk.ics_final_order_viol_lnk_id
       LEFT JOIN ICS_FLOW_LOCAL.ics_cmpl_schd_viol ics_cmpl_schd_viol on ics_cmpl_schd_viol.ics_final_order_viol_lnk_id = ics_final_order_viol_lnk.ics_final_order_viol_lnk_id
       LEFT JOIN ICS_FLOW_LOCAL.ics_dsch_mon_rep_viol ics_dsch_mon_rep_viol on ics_dsch_mon_rep_viol.ics_final_order_viol_lnk_id = ics_final_order_viol_lnk.ics_final_order_viol_lnk_id
       LEFT JOIN ICS_FLOW_LOCAL.ics_dsch_mon_rep_param_viol ics_dsch_mon_rep_param_viol on ics_dsch_mon_rep_param_viol.ics_final_order_viol_lnk_id = ics_final_order_viol_lnk.ics_final_order_viol_lnk_id
       LEFT JOIN ICS_FLOW_LOCAL.ics_sngl_evts_viol ics_sngl_evts_viol on ics_sngl_evts_viol.ics_final_order_viol_lnk_id = ics_final_order_viol_lnk.ics_final_order_viol_lnk_id;
  */

  /************************************/  
  /* START - Process DATA_HASH values */
  /* START - Process DATA_HASH values */
  /* START - Process DATA_HASH values */
  /************************************/ 
 
  /* Loop through each payload type, for each loop roll child data_hash values up to the parent payload table */  
  OPEN payload_type_process;

  -- Get 1st payload type
  FETCH NEXT FROM payload_type_process INTO @p_payload_type;
  WHILE @@FETCH_STATUS = 0
    BEGIN

	    --PRINT 'Change Detection: Begin data_hash aggregation for table: ' + @p_payload_type + ' at ' + CONVERT(VARCHAR(24),GETDATE(),113)

      SET @v_sql_statement = 'SELECT TOP 1 @v_enabled_val = [ENABLED] FROM ICS_FLOW_LOCAL.ICS_PAYLOAD P JOIN ICS_FLOW_LOCAL.' + @p_payload_type +
        ' CHILD ON P.ICS_PAYLOAD_ID = CHILD.ICS_PAYLOAD_ID'
      SET @v_sql_param = '@v_enabled_val CHAR(1) OUTPUT';

      EXEC sp_executesql @v_sql_statement, @v_sql_param, @v_enabled_val=@v_enabled OUTPUT;
      
      SET @v_enabled = ISNULL(@v_enabled, 'N');
      
      /* Flush the prior payload type's key_hash values */
      DELETE FROM ICS_FLOW_LOCAL.ics_key_hash;
      
      IF (@v_enabled = 'Y')
      BEGIN
          /* Load next key_hash set for current payload type */ 
          SET @v_sql_statement = 'INSERT INTO ICS_FLOW_LOCAL.ics_key_hash SELECT key_hash FROM ICS_FLOW_LOCAL.' + @p_payload_type; 
          EXECUTE sp_executesql @v_sql_statement;
      END

     /* 
      *  Loop through each key in a payload type's key set.  For each key traverse the payload type's data heirarchy
      *  and load the child data_hash values into working table ICS_DATA_HASH for later processing at the end of 
      *  the loop.
      */
      OPEN key_hash;

      /*  Fetch 1st payload type */
      FETCH NEXT FROM key_hash INTO @v_key_hash;
      WHILE @@FETCH_STATUS = 0
        BEGIN    

          --  Reset the working data hash!
          SET @v_working_data_hash = NULL;




	  
		-- CollectionSystemPermitSubmission, not children
	  
		  
		-- BasicPermitSubmission

         IF @p_payload_type = 'ICS_BASIC_PRMT' and @v_enabled = 'Y'
             BEGIN

             WITH tmp (key_hash, data_hash) AS
             ( SELECT TOP 100 PERCENT here.key_hash, here.data_hash
             FROM (			

				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BASIC_PRMT] 
				
				SELECT KEY_HASH, ICS_BASIC_PRMT.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BASIC_PRMT]/[ICS_FLOW_LOCAL].[ICS_CONTACT] 
				 UNION 
				SELECT KEY_HASH, I1.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTACT] [I1]
 ON [I1].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BASIC_PRMT]/[ICS_FLOW_LOCAL].[ICS_CONTACT]/[ICS_FLOW_LOCAL].[ICS_TELEPH] 
				 UNION 
				SELECT KEY_HASH, I2.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTACT] [I1]
 ON [I1].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_TELEPH] [I2]
 ON [I2].[ICS_CONTACT_ID] = [I1].[ICS_CONTACT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BASIC_PRMT]/[ICS_FLOW_LOCAL].[ICS_NPDES_DAT_GRP_NUM] 
				 UNION 
				SELECT KEY_HASH, I3.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_NPDES_DAT_GRP_NUM] [I3]
 ON [I3].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BASIC_PRMT]/[ICS_FLOW_LOCAL].[ICS_OTHR_PRMTS] 
				 UNION 
				SELECT KEY_HASH, I4.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_OTHR_PRMTS] [I4]
 ON [I4].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BASIC_PRMT]/[ICS_FLOW_LOCAL].[ICS_EFFLU_GUIDE] 
				 UNION 
				SELECT KEY_HASH, I5.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_EFFLU_GUIDE] [I5]
 ON [I5].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BASIC_PRMT]/[ICS_FLOW_LOCAL].[ICS_FAC] 
				 UNION 
				SELECT KEY_HASH, I6.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_FAC] [I6]
 ON [I6].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BASIC_PRMT]/[ICS_FLOW_LOCAL].[ICS_FAC]/[ICS_FLOW_LOCAL].[ICS_CONTACT] 
				 UNION 
				SELECT KEY_HASH, I7.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_FAC] [I6]
 ON [I6].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTACT] [I7]
 ON [I7].[ICS_FAC_ID] = [I6].[ICS_FAC_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BASIC_PRMT]/[ICS_FLOW_LOCAL].[ICS_FAC]/[ICS_FLOW_LOCAL].[ICS_CONTACT]/[ICS_FLOW_LOCAL].[ICS_TELEPH] 
				 UNION 
				SELECT KEY_HASH, I8.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_FAC] [I6]
 ON [I6].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTACT] [I7]
 ON [I7].[ICS_FAC_ID] = [I6].[ICS_FAC_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_TELEPH] [I8]
 ON [I8].[ICS_CONTACT_ID] = [I7].[ICS_CONTACT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BASIC_PRMT]/[ICS_FLOW_LOCAL].[ICS_FAC]/[ICS_FLOW_LOCAL].[ICS_ORIG_PROGS] 
				 UNION 
				SELECT KEY_HASH, I9.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_FAC] [I6]
 ON [I6].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ORIG_PROGS] [I9]
 ON [I9].[ICS_FAC_ID] = [I6].[ICS_FAC_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BASIC_PRMT]/[ICS_FLOW_LOCAL].[ICS_FAC]/[ICS_FLOW_LOCAL].[ICS_PLCY] 
				 UNION 
				SELECT KEY_HASH, I10.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_FAC] [I6]
 ON [I6].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PLCY] [I10]
 ON [I10].[ICS_FAC_ID] = [I6].[ICS_FAC_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BASIC_PRMT]/[ICS_FLOW_LOCAL].[ICS_FAC]/[ICS_FLOW_LOCAL].[ICS_FAC_CLASS] 
				 UNION 
				SELECT KEY_HASH, I11.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_FAC] [I6]
 ON [I6].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_FAC_CLASS] [I11]
 ON [I11].[ICS_FAC_ID] = [I6].[ICS_FAC_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BASIC_PRMT]/[ICS_FLOW_LOCAL].[ICS_FAC]/[ICS_FLOW_LOCAL].[ICS_GEO_COORD] 
				 UNION 
				SELECT KEY_HASH, I12.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_FAC] [I6]
 ON [I6].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_GEO_COORD] [I12]
 ON [I12].[ICS_FAC_ID] = [I6].[ICS_FAC_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BASIC_PRMT]/[ICS_FLOW_LOCAL].[ICS_FAC]/[ICS_FLOW_LOCAL].[ICS_SIC_CODE] 
				 UNION 
				SELECT KEY_HASH, I13.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_FAC] [I6]
 ON [I6].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SIC_CODE] [I13]
 ON [I13].[ICS_FAC_ID] = [I6].[ICS_FAC_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BASIC_PRMT]/[ICS_FLOW_LOCAL].[ICS_FAC]/[ICS_FLOW_LOCAL].[ICS_ADDR] 
				 UNION 
				SELECT KEY_HASH, I14.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_FAC] [I6]
 ON [I6].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ADDR] [I14]
 ON [I14].[ICS_FAC_ID] = [I6].[ICS_FAC_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BASIC_PRMT]/[ICS_FLOW_LOCAL].[ICS_FAC]/[ICS_FLOW_LOCAL].[ICS_ADDR]/[ICS_FLOW_LOCAL].[ICS_TELEPH] 
				 UNION 
				SELECT KEY_HASH, I15.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_FAC] [I6]
 ON [I6].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ADDR] [I14]
 ON [I14].[ICS_FAC_ID] = [I6].[ICS_FAC_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_TELEPH] [I15]
 ON [I15].[ICS_ADDR_ID] = [I14].[ICS_ADDR_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BASIC_PRMT]/[ICS_FLOW_LOCAL].[ICS_FAC]/[ICS_FLOW_LOCAL].[ICS_NAICS_CODE] 
				 UNION 
				SELECT KEY_HASH, I16.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_FAC] [I6]
 ON [I6].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_NAICS_CODE] [I16]
 ON [I16].[ICS_FAC_ID] = [I6].[ICS_FAC_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BASIC_PRMT]/[ICS_FLOW_LOCAL].[ICS_REP_NON_CMPL_STAT] 
				 UNION 
				SELECT KEY_HASH, I17.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_REP_NON_CMPL_STAT] [I17]
 ON [I17].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BASIC_PRMT]/[ICS_FLOW_LOCAL].[ICS_RESIDUAL_DESGN_DTRMN] 
				 UNION 
				SELECT KEY_HASH, I18.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_RESIDUAL_DESGN_DTRMN] [I18]
 ON [I18].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BASIC_PRMT]/[ICS_FLOW_LOCAL].[ICS_SIC_CODE] 
				 UNION 
				SELECT KEY_HASH, I19.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SIC_CODE] [I19]
 ON [I19].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BASIC_PRMT]/[ICS_FLOW_LOCAL].[ICS_SIU_DESGN_TYPE] 
				 UNION 
				SELECT KEY_HASH, I20.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SIU_DESGN_TYPE] [I20]
 ON [I20].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BASIC_PRMT]/[ICS_FLOW_LOCAL].[ICS_ADDR] 
				 UNION 
				SELECT KEY_HASH, I21.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ADDR] [I21]
 ON [I21].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BASIC_PRMT]/[ICS_FLOW_LOCAL].[ICS_ADDR]/[ICS_FLOW_LOCAL].[ICS_TELEPH] 
				 UNION 
				SELECT KEY_HASH, I22.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ADDR] [I21]
 ON [I21].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_TELEPH] [I22]
 ON [I22].[ICS_ADDR_ID] = [I21].[ICS_ADDR_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BASIC_PRMT]/[ICS_FLOW_LOCAL].[ICS_ASSC_PRMT] 
				 UNION 
				SELECT KEY_HASH, I23.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ASSC_PRMT] [I23]
 ON [I23].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BASIC_PRMT]/[ICS_FLOW_LOCAL].[ICS_CMPL_TRACK_STAT] 
				 UNION 
				SELECT KEY_HASH, I24.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CMPL_TRACK_STAT] [I24]
 ON [I24].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BASIC_PRMT]/[ICS_FLOW_LOCAL].[ICS_NAICS_CODE] 
				 UNION 
				SELECT KEY_HASH, I25.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_NAICS_CODE] [I25]
 ON [I25].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
    
				WHERE key_hash = @v_key_hash
							  
             ) here
             WHERE here.key_hash = @v_key_hash
             ORDER BY here.data_hash)

              SELECT @v_working_data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', COALESCE(@v_working_data_hash,'#') + data_hash)
                FROM tmp
               WHERE tmp.key_hash = @v_key_hash
               ORDER BY data_hash

              UPDATE ICS_FLOW_LOCAL.ICS_BASIC_PRMT
                 SET data_hash = @v_working_data_hash
               WHERE key_hash = @v_key_hash
             END;
			 
			 

	  
		-- CollectionSystemPermitSubmission, not children
	  
		  
		-- BiosolidsAnnualProgramReportSubmission

         IF @p_payload_type = 'ICS_BS_ANNUL_PROG_REP' and @v_enabled = 'Y'
             BEGIN

             WITH tmp (key_hash, data_hash) AS
             ( SELECT TOP 100 PERCENT here.key_hash, here.data_hash
             FROM (			

				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP] 
				
				SELECT KEY_HASH, ICS_BS_ANNUL_PROG_REP.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP]/[ICS_FLOW_LOCAL].[ICS_ANLYTCL_METHOD] 
				 UNION 
				SELECT KEY_HASH, I1.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ANLYTCL_METHOD] [I1]
 ON [I1].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP]/[ICS_FLOW_LOCAL].[ICS_BS_FAC_TRTMNT] 
				 UNION 
				SELECT KEY_HASH, I2.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_FAC_TRTMNT] [I2]
 ON [I2].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP]/[ICS_FLOW_LOCAL].[ICS_BS_FAC_TYPE] 
				 UNION 
				SELECT KEY_HASH, I3.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_FAC_TYPE] [I3]
 ON [I3].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP]/[ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE] 
				 UNION 
				SELECT KEY_HASH, I4.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP]/[ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE]/[ICS_FLOW_LOCAL].[ICS_PATHOGEN_REDUCTION_TYPE] 
				 UNION 
				SELECT KEY_HASH, I5.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PATHOGEN_REDUCTION_TYPE] [I5]
 ON [I5].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP]/[ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE]/[ICS_FLOW_LOCAL].[ICS_BS_INCINERATION] 
				 UNION 
				SELECT KEY_HASH, I6.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_INCINERATION] [I6]
 ON [I6].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP]/[ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE]/[ICS_FLOW_LOCAL].[ICS_BS_INCINERATION]/[ICS_FLOW_LOCAL].[ICS_BS_INCIN_EMISSIONS_CONTROL_TYPE] 
				 UNION 
				SELECT KEY_HASH, I7.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_INCINERATION] [I6]
 ON [I6].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_INCIN_EMISSIONS_CONTROL_TYPE] [I7]
 ON [I7].[ICS_BS_INCINERATION_ID] = [I6].[ICS_BS_INCINERATION_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP]/[ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE]/[ICS_FLOW_LOCAL].[ICS_BS_INCINERATION]/[ICS_FLOW_LOCAL].[ICS_BS_SEWAGE_SLDG_PARAM] 
				 UNION 
				SELECT KEY_HASH, I8.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_INCINERATION] [I6]
 ON [I6].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_SEWAGE_SLDG_PARAM] [I8]
 ON [I8].[ICS_BS_INCINERATION_ID] = [I6].[ICS_BS_INCINERATION_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP]/[ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE]/[ICS_FLOW_LOCAL].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] 
				 UNION 
				SELECT KEY_HASH, I9.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] [I9]
 ON [I9].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP]/[ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE]/[ICS_FLOW_LOCAL].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR]/[ICS_FLOW_LOCAL].[ICS_ADDR] 
				 UNION 
				SELECT KEY_HASH, I10.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] [I9]
 ON [I9].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ADDR] [I10]
 ON [I10].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] = [I9].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP]/[ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE]/[ICS_FLOW_LOCAL].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR]/[ICS_FLOW_LOCAL].[ICS_ADDR]/[ICS_FLOW_LOCAL].[ICS_TELEPH] 
				 UNION 
				SELECT KEY_HASH, I11.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] [I9]
 ON [I9].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ADDR] [I10]
 ON [I10].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] = [I9].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_TELEPH] [I11]
 ON [I11].[ICS_ADDR_ID] = [I10].[ICS_ADDR_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP]/[ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE]/[ICS_FLOW_LOCAL].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR]/[ICS_FLOW_LOCAL].[ICS_CONTACT] 
				 UNION 
				SELECT KEY_HASH, I12.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] [I9]
 ON [I9].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTACT] [I12]
 ON [I12].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] = [I9].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP]/[ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE]/[ICS_FLOW_LOCAL].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR]/[ICS_FLOW_LOCAL].[ICS_CONTACT]/[ICS_FLOW_LOCAL].[ICS_TELEPH] 
				 UNION 
				SELECT KEY_HASH, I13.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] [I9]
 ON [I9].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTACT] [I12]
 ON [I12].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] = [I9].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_TELEPH] [I13]
 ON [I13].[ICS_CONTACT_ID] = [I12].[ICS_CONTACT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP]/[ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE]/[ICS_FLOW_LOCAL].[ICS_BS_SEWAGE_SLDG_PARAM] 
				 UNION 
				SELECT KEY_HASH, I14.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_SEWAGE_SLDG_PARAM] [I14]
 ON [I14].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP]/[ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE]/[ICS_FLOW_LOCAL].[ICS_VECTOR_A_REDUCTION_TYPE] 
				 UNION 
				SELECT KEY_HASH, I15.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_VECTOR_A_REDUCTION_TYPE] [I15]
 ON [I15].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP]/[ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE]/[ICS_FLOW_LOCAL].[ICS_CMPL_MON_EVT] 
				 UNION 
				SELECT KEY_HASH, I16.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CMPL_MON_EVT] [I16]
 ON [I16].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP]/[ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE]/[ICS_FLOW_LOCAL].[ICS_CMPL_MON_EVT]/[ICS_FLOW_LOCAL].[ICS_BS_SEWAGE_SLDG_PARAM] 
				 UNION 
				SELECT KEY_HASH, I17.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CMPL_MON_EVT] [I16]
 ON [I16].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_SEWAGE_SLDG_PARAM] [I17]
 ON [I17].[ICS_CMPL_MON_EVT_ID] = [I16].[ICS_CMPL_MON_EVT_ID] 
    
				WHERE key_hash = @v_key_hash
							  
             ) here
             WHERE here.key_hash = @v_key_hash
             ORDER BY here.data_hash)

              SELECT @v_working_data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', COALESCE(@v_working_data_hash,'#') + data_hash)
                FROM tmp
               WHERE tmp.key_hash = @v_key_hash
               ORDER BY data_hash

              UPDATE ICS_FLOW_LOCAL.ICS_BS_ANNUL_PROG_REP
                 SET data_hash = @v_working_data_hash
               WHERE key_hash = @v_key_hash
             END;
			 
			 

	  
		-- CollectionSystemPermitSubmission, not children
	  
		  
		-- BiosolidsAnnualProgramReportSubmission

         IF @p_payload_type = 'ICS_BS_ANNUL_PROG_REP' and @v_enabled = 'Y'
             BEGIN

             WITH tmp (key_hash, data_hash) AS
             ( SELECT TOP 100 PERCENT here.key_hash, here.data_hash
             FROM (			

				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP] 
				
				SELECT KEY_HASH, ICS_BS_ANNUL_PROG_REP.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP]/[ICS_FLOW_LOCAL].[ICS_ANLYTCL_METHOD] 
				 UNION 
				SELECT KEY_HASH, I1.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ANLYTCL_METHOD] [I1]
 ON [I1].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP]/[ICS_FLOW_LOCAL].[ICS_BS_FAC_TRTMNT] 
				 UNION 
				SELECT KEY_HASH, I2.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_FAC_TRTMNT] [I2]
 ON [I2].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP]/[ICS_FLOW_LOCAL].[ICS_BS_FAC_TYPE] 
				 UNION 
				SELECT KEY_HASH, I3.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_FAC_TYPE] [I3]
 ON [I3].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP]/[ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE] 
				 UNION 
				SELECT KEY_HASH, I4.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP]/[ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE]/[ICS_FLOW_LOCAL].[ICS_PATHOGEN_REDUCTION_TYPE] 
				 UNION 
				SELECT KEY_HASH, I5.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PATHOGEN_REDUCTION_TYPE] [I5]
 ON [I5].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP]/[ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE]/[ICS_FLOW_LOCAL].[ICS_BS_INCINERATION] 
				 UNION 
				SELECT KEY_HASH, I6.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_INCINERATION] [I6]
 ON [I6].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP]/[ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE]/[ICS_FLOW_LOCAL].[ICS_BS_INCINERATION]/[ICS_FLOW_LOCAL].[ICS_BS_INCIN_EMISSIONS_CONTROL_TYPE] 
				 UNION 
				SELECT KEY_HASH, I7.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_INCINERATION] [I6]
 ON [I6].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_INCIN_EMISSIONS_CONTROL_TYPE] [I7]
 ON [I7].[ICS_BS_INCINERATION_ID] = [I6].[ICS_BS_INCINERATION_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP]/[ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE]/[ICS_FLOW_LOCAL].[ICS_BS_INCINERATION]/[ICS_FLOW_LOCAL].[ICS_BS_SEWAGE_SLDG_PARAM] 
				 UNION 
				SELECT KEY_HASH, I8.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_INCINERATION] [I6]
 ON [I6].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_SEWAGE_SLDG_PARAM] [I8]
 ON [I8].[ICS_BS_INCINERATION_ID] = [I6].[ICS_BS_INCINERATION_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP]/[ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE]/[ICS_FLOW_LOCAL].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] 
				 UNION 
				SELECT KEY_HASH, I9.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] [I9]
 ON [I9].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP]/[ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE]/[ICS_FLOW_LOCAL].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR]/[ICS_FLOW_LOCAL].[ICS_ADDR] 
				 UNION 
				SELECT KEY_HASH, I10.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] [I9]
 ON [I9].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ADDR] [I10]
 ON [I10].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] = [I9].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP]/[ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE]/[ICS_FLOW_LOCAL].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR]/[ICS_FLOW_LOCAL].[ICS_ADDR]/[ICS_FLOW_LOCAL].[ICS_TELEPH] 
				 UNION 
				SELECT KEY_HASH, I11.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] [I9]
 ON [I9].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ADDR] [I10]
 ON [I10].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] = [I9].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_TELEPH] [I11]
 ON [I11].[ICS_ADDR_ID] = [I10].[ICS_ADDR_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP]/[ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE]/[ICS_FLOW_LOCAL].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR]/[ICS_FLOW_LOCAL].[ICS_CONTACT] 
				 UNION 
				SELECT KEY_HASH, I12.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] [I9]
 ON [I9].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTACT] [I12]
 ON [I12].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] = [I9].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP]/[ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE]/[ICS_FLOW_LOCAL].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR]/[ICS_FLOW_LOCAL].[ICS_CONTACT]/[ICS_FLOW_LOCAL].[ICS_TELEPH] 
				 UNION 
				SELECT KEY_HASH, I13.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] [I9]
 ON [I9].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTACT] [I12]
 ON [I12].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] = [I9].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_TELEPH] [I13]
 ON [I13].[ICS_CONTACT_ID] = [I12].[ICS_CONTACT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP]/[ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE]/[ICS_FLOW_LOCAL].[ICS_BS_SEWAGE_SLDG_PARAM] 
				 UNION 
				SELECT KEY_HASH, I14.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_SEWAGE_SLDG_PARAM] [I14]
 ON [I14].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP]/[ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE]/[ICS_FLOW_LOCAL].[ICS_VECTOR_A_REDUCTION_TYPE] 
				 UNION 
				SELECT KEY_HASH, I15.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_VECTOR_A_REDUCTION_TYPE] [I15]
 ON [I15].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP]/[ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE]/[ICS_FLOW_LOCAL].[ICS_CMPL_MON_EVT] 
				 UNION 
				SELECT KEY_HASH, I16.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CMPL_MON_EVT] [I16]
 ON [I16].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP]/[ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE]/[ICS_FLOW_LOCAL].[ICS_CMPL_MON_EVT]/[ICS_FLOW_LOCAL].[ICS_BS_SEWAGE_SLDG_PARAM] 
				 UNION 
				SELECT KEY_HASH, I17.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CMPL_MON_EVT] [I16]
 ON [I16].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_SEWAGE_SLDG_PARAM] [I17]
 ON [I17].[ICS_CMPL_MON_EVT_ID] = [I16].[ICS_CMPL_MON_EVT_ID] 
    
				WHERE key_hash = @v_key_hash
							  
             ) here
             WHERE here.key_hash = @v_key_hash
             ORDER BY here.data_hash)

              SELECT @v_working_data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', COALESCE(@v_working_data_hash,'#') + data_hash)
                FROM tmp
               WHERE tmp.key_hash = @v_key_hash
               ORDER BY data_hash

              UPDATE ICS_FLOW_LOCAL.ICS_BS_ANNUL_PROG_REP
                 SET data_hash = @v_working_data_hash
               WHERE key_hash = @v_key_hash
             END;
			 
			 

	  
		-- CollectionSystemPermitSubmission, not children
	  
		  
		-- BiosolidsPermitSubmission

         IF @p_payload_type = 'ICS_BS_PRMT' and @v_enabled = 'Y'
             BEGIN

             WITH tmp (key_hash, data_hash) AS
             ( SELECT TOP 100 PERCENT here.key_hash, here.data_hash
             FROM (			

				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BS_PRMT] 
				
				SELECT KEY_HASH, ICS_BS_PRMT.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BS_PRMT] [ICS_BS_PRMT] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BS_PRMT]/[ICS_FLOW_LOCAL].[ICS_PRMT_BS_MGMT_PRACTICE] 
				 UNION 
				SELECT KEY_HASH, I1.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BS_PRMT] [ICS_BS_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PRMT_BS_MGMT_PRACTICE] [I1]
 ON [I1].[ICS_BS_PRMT_ID] = [ICS_BS_PRMT].[ICS_BS_PRMT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BS_PRMT]/[ICS_FLOW_LOCAL].[ICS_PRMT_BS_MGMT_PRACTICE]/[ICS_FLOW_LOCAL].[ICS_PATHOGEN_REDUCTION_TYPE] 
				 UNION 
				SELECT KEY_HASH, I2.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BS_PRMT] [ICS_BS_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PRMT_BS_MGMT_PRACTICE] [I1]
 ON [I1].[ICS_BS_PRMT_ID] = [ICS_BS_PRMT].[ICS_BS_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PATHOGEN_REDUCTION_TYPE] [I2]
 ON [I2].[ICS_PRMT_BS_MGMT_PRACTICE_ID] = [I1].[ICS_PRMT_BS_MGMT_PRACTICE_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BS_PRMT]/[ICS_FLOW_LOCAL].[ICS_PRMT_BS_MGMT_PRACTICE]/[ICS_FLOW_LOCAL].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] 
				 UNION 
				SELECT KEY_HASH, I3.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BS_PRMT] [ICS_BS_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PRMT_BS_MGMT_PRACTICE] [I1]
 ON [I1].[ICS_BS_PRMT_ID] = [ICS_BS_PRMT].[ICS_BS_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] [I3]
 ON [I3].[ICS_PRMT_BS_MGMT_PRACTICE_ID] = [I1].[ICS_PRMT_BS_MGMT_PRACTICE_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BS_PRMT]/[ICS_FLOW_LOCAL].[ICS_PRMT_BS_MGMT_PRACTICE]/[ICS_FLOW_LOCAL].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR]/[ICS_FLOW_LOCAL].[ICS_ADDR] 
				 UNION 
				SELECT KEY_HASH, I4.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BS_PRMT] [ICS_BS_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PRMT_BS_MGMT_PRACTICE] [I1]
 ON [I1].[ICS_BS_PRMT_ID] = [ICS_BS_PRMT].[ICS_BS_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] [I3]
 ON [I3].[ICS_PRMT_BS_MGMT_PRACTICE_ID] = [I1].[ICS_PRMT_BS_MGMT_PRACTICE_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ADDR] [I4]
 ON [I4].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] = [I3].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BS_PRMT]/[ICS_FLOW_LOCAL].[ICS_PRMT_BS_MGMT_PRACTICE]/[ICS_FLOW_LOCAL].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR]/[ICS_FLOW_LOCAL].[ICS_ADDR]/[ICS_FLOW_LOCAL].[ICS_TELEPH] 
				 UNION 
				SELECT KEY_HASH, I5.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BS_PRMT] [ICS_BS_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PRMT_BS_MGMT_PRACTICE] [I1]
 ON [I1].[ICS_BS_PRMT_ID] = [ICS_BS_PRMT].[ICS_BS_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] [I3]
 ON [I3].[ICS_PRMT_BS_MGMT_PRACTICE_ID] = [I1].[ICS_PRMT_BS_MGMT_PRACTICE_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ADDR] [I4]
 ON [I4].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] = [I3].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_TELEPH] [I5]
 ON [I5].[ICS_ADDR_ID] = [I4].[ICS_ADDR_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BS_PRMT]/[ICS_FLOW_LOCAL].[ICS_PRMT_BS_MGMT_PRACTICE]/[ICS_FLOW_LOCAL].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR]/[ICS_FLOW_LOCAL].[ICS_CONTACT] 
				 UNION 
				SELECT KEY_HASH, I6.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BS_PRMT] [ICS_BS_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PRMT_BS_MGMT_PRACTICE] [I1]
 ON [I1].[ICS_BS_PRMT_ID] = [ICS_BS_PRMT].[ICS_BS_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] [I3]
 ON [I3].[ICS_PRMT_BS_MGMT_PRACTICE_ID] = [I1].[ICS_PRMT_BS_MGMT_PRACTICE_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTACT] [I6]
 ON [I6].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] = [I3].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BS_PRMT]/[ICS_FLOW_LOCAL].[ICS_PRMT_BS_MGMT_PRACTICE]/[ICS_FLOW_LOCAL].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR]/[ICS_FLOW_LOCAL].[ICS_CONTACT]/[ICS_FLOW_LOCAL].[ICS_TELEPH] 
				 UNION 
				SELECT KEY_HASH, I7.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BS_PRMT] [ICS_BS_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PRMT_BS_MGMT_PRACTICE] [I1]
 ON [I1].[ICS_BS_PRMT_ID] = [ICS_BS_PRMT].[ICS_BS_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] [I3]
 ON [I3].[ICS_PRMT_BS_MGMT_PRACTICE_ID] = [I1].[ICS_PRMT_BS_MGMT_PRACTICE_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTACT] [I6]
 ON [I6].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] = [I3].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_TELEPH] [I7]
 ON [I7].[ICS_CONTACT_ID] = [I6].[ICS_CONTACT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BS_PRMT]/[ICS_FLOW_LOCAL].[ICS_PRMT_BS_MGMT_PRACTICE]/[ICS_FLOW_LOCAL].[ICS_VECTOR_A_REDUCTION_TYPE] 
				 UNION 
				SELECT KEY_HASH, I8.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BS_PRMT] [ICS_BS_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PRMT_BS_MGMT_PRACTICE] [I1]
 ON [I1].[ICS_BS_PRMT_ID] = [ICS_BS_PRMT].[ICS_BS_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_VECTOR_A_REDUCTION_TYPE] [I8]
 ON [I8].[ICS_PRMT_BS_MGMT_PRACTICE_ID] = [I1].[ICS_PRMT_BS_MGMT_PRACTICE_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BS_PRMT]/[ICS_FLOW_LOCAL].[ICS_BS_FAC_TRTMNT] 
				 UNION 
				SELECT KEY_HASH, I9.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BS_PRMT] [ICS_BS_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_FAC_TRTMNT] [I9]
 ON [I9].[ICS_BS_PRMT_ID] = [ICS_BS_PRMT].[ICS_BS_PRMT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_BS_PRMT]/[ICS_FLOW_LOCAL].[ICS_BS_FAC_TYPE] 
				 UNION 
				SELECT KEY_HASH, I10.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_BS_PRMT] [ICS_BS_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BS_FAC_TYPE] [I10]
 ON [I10].[ICS_BS_PRMT_ID] = [ICS_BS_PRMT].[ICS_BS_PRMT_ID] 
    
				WHERE key_hash = @v_key_hash
							  
             ) here
             WHERE here.key_hash = @v_key_hash
             ORDER BY here.data_hash)

              SELECT @v_working_data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', COALESCE(@v_working_data_hash,'#') + data_hash)
                FROM tmp
               WHERE tmp.key_hash = @v_key_hash
               ORDER BY data_hash

              UPDATE ICS_FLOW_LOCAL.ICS_BS_PRMT
                 SET data_hash = @v_working_data_hash
               WHERE key_hash = @v_key_hash
             END;
			 
			 

	  
		-- CollectionSystemPermitSubmission, not children
	  
		  
		-- CAFOAnnualProgramReportSubmission

         IF @p_payload_type = 'ICS_CAFO_ANNUL_PROG_REP' and @v_enabled = 'Y'
             BEGIN

             WITH tmp (key_hash, data_hash) AS
             ( SELECT TOP 100 PERCENT here.key_hash, here.data_hash
             FROM (			

				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CAFO_ANNUL_PROG_REP] 
				
				SELECT KEY_HASH, ICS_CAFO_ANNUL_PROG_REP.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CAFO_ANNUL_PROG_REP] [ICS_CAFO_ANNUL_PROG_REP] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CAFO_ANNUL_PROG_REP]/[ICS_FLOW_LOCAL].[ICS_ANML_TYPE] 
				 UNION 
				SELECT KEY_HASH, I1.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CAFO_ANNUL_PROG_REP] [ICS_CAFO_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ANML_TYPE] [I1]
 ON [I1].[ICS_CAFO_ANNUL_PROG_REP_ID] = [ICS_CAFO_ANNUL_PROG_REP].[ICS_CAFO_ANNUL_PROG_REP_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CAFO_ANNUL_PROG_REP]/[ICS_FLOW_LOCAL].[ICS_CAFO_LAND_APPL_FLD_INFO] 
				 UNION 
				SELECT KEY_HASH, I2.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CAFO_ANNUL_PROG_REP] [ICS_CAFO_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CAFO_LAND_APPL_FLD_INFO] [I2]
 ON [I2].[ICS_CAFO_ANNUL_PROG_REP_ID] = [ICS_CAFO_ANNUL_PROG_REP].[ICS_CAFO_ANNUL_PROG_REP_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CAFO_ANNUL_PROG_REP]/[ICS_FLOW_LOCAL].[ICS_CAFO_LAND_APPL_FLD_INFO]/[ICS_FLOW_LOCAL].[ICS_CAFOMLPW_FLD_AMOUNTS] 
				 UNION 
				SELECT KEY_HASH, I3.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CAFO_ANNUL_PROG_REP] [ICS_CAFO_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CAFO_LAND_APPL_FLD_INFO] [I2]
 ON [I2].[ICS_CAFO_ANNUL_PROG_REP_ID] = [ICS_CAFO_ANNUL_PROG_REP].[ICS_CAFO_ANNUL_PROG_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CAFOMLPW_FLD_AMOUNTS] [I3]
 ON [I3].[ICS_CAFO_LAND_APPL_FLD_INFO_ID] = [I2].[ICS_CAFO_LAND_APPL_FLD_INFO_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CAFO_ANNUL_PROG_REP]/[ICS_FLOW_LOCAL].[ICS_CAFO_PROD_AREA_DSCH] 
				 UNION 
				SELECT KEY_HASH, I4.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CAFO_ANNUL_PROG_REP] [ICS_CAFO_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CAFO_PROD_AREA_DSCH] [I4]
 ON [I4].[ICS_CAFO_ANNUL_PROG_REP_ID] = [ICS_CAFO_ANNUL_PROG_REP].[ICS_CAFO_ANNUL_PROG_REP_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CAFO_ANNUL_PROG_REP]/[ICS_FLOW_LOCAL].[ICS_CAFOMLPW_NUTR_MON] 
				 UNION 
				SELECT KEY_HASH, I5.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CAFO_ANNUL_PROG_REP] [ICS_CAFO_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CAFOMLPW_NUTR_MON] [I5]
 ON [I5].[ICS_CAFO_ANNUL_PROG_REP_ID] = [ICS_CAFO_ANNUL_PROG_REP].[ICS_CAFO_ANNUL_PROG_REP_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CAFO_ANNUL_PROG_REP]/[ICS_FLOW_LOCAL].[ICS_CAFOMLPW_TTL_AMOUNTS] 
				 UNION 
				SELECT KEY_HASH, I6.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CAFO_ANNUL_PROG_REP] [ICS_CAFO_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CAFOMLPW_TTL_AMOUNTS] [I6]
 ON [I6].[ICS_CAFO_ANNUL_PROG_REP_ID] = [ICS_CAFO_ANNUL_PROG_REP].[ICS_CAFO_ANNUL_PROG_REP_ID] 
    
				WHERE key_hash = @v_key_hash
							  
             ) here
             WHERE here.key_hash = @v_key_hash
             ORDER BY here.data_hash)

              SELECT @v_working_data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', COALESCE(@v_working_data_hash,'#') + data_hash)
                FROM tmp
               WHERE tmp.key_hash = @v_key_hash
               ORDER BY data_hash

              UPDATE ICS_FLOW_LOCAL.ICS_CAFO_ANNUL_PROG_REP
                 SET data_hash = @v_working_data_hash
               WHERE key_hash = @v_key_hash
             END;
			 
			 

	  
		-- CollectionSystemPermitSubmission, not children
	  
		  
		-- CAFOPermitSubmission

         IF @p_payload_type = 'ICS_CAFO_PRMT' and @v_enabled = 'Y'
             BEGIN

             WITH tmp (key_hash, data_hash) AS
             ( SELECT TOP 100 PERCENT here.key_hash, here.data_hash
             FROM (			

				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CAFO_PRMT] 
				
				SELECT KEY_HASH, ICS_CAFO_PRMT.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CAFO_PRMT] [ICS_CAFO_PRMT] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CAFO_PRMT]/[ICS_FLOW_LOCAL].[ICS_CONTACT] 
				 UNION 
				SELECT KEY_HASH, I1.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CAFO_PRMT] [ICS_CAFO_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTACT] [I1]
 ON [I1].[ICS_CAFO_PRMT_ID] = [ICS_CAFO_PRMT].[ICS_CAFO_PRMT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CAFO_PRMT]/[ICS_FLOW_LOCAL].[ICS_CONTACT]/[ICS_FLOW_LOCAL].[ICS_TELEPH] 
				 UNION 
				SELECT KEY_HASH, I2.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CAFO_PRMT] [ICS_CAFO_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTACT] [I1]
 ON [I1].[ICS_CAFO_PRMT_ID] = [ICS_CAFO_PRMT].[ICS_CAFO_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_TELEPH] [I2]
 ON [I2].[ICS_CONTACT_ID] = [I1].[ICS_CONTACT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CAFO_PRMT]/[ICS_FLOW_LOCAL].[ICS_CONTAINMENT] 
				 UNION 
				SELECT KEY_HASH, I3.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CAFO_PRMT] [ICS_CAFO_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTAINMENT] [I3]
 ON [I3].[ICS_CAFO_PRMT_ID] = [ICS_CAFO_PRMT].[ICS_CAFO_PRMT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CAFO_PRMT]/[ICS_FLOW_LOCAL].[ICS_LAND_APPL_BMP] 
				 UNION 
				SELECT KEY_HASH, I4.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CAFO_PRMT] [ICS_CAFO_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_LAND_APPL_BMP] [I4]
 ON [I4].[ICS_CAFO_PRMT_ID] = [ICS_CAFO_PRMT].[ICS_CAFO_PRMT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CAFO_PRMT]/[ICS_FLOW_LOCAL].[ICS_ADDR] 
				 UNION 
				SELECT KEY_HASH, I5.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CAFO_PRMT] [ICS_CAFO_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ADDR] [I5]
 ON [I5].[ICS_CAFO_PRMT_ID] = [ICS_CAFO_PRMT].[ICS_CAFO_PRMT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CAFO_PRMT]/[ICS_FLOW_LOCAL].[ICS_ADDR]/[ICS_FLOW_LOCAL].[ICS_TELEPH] 
				 UNION 
				SELECT KEY_HASH, I6.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CAFO_PRMT] [ICS_CAFO_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ADDR] [I5]
 ON [I5].[ICS_CAFO_PRMT_ID] = [ICS_CAFO_PRMT].[ICS_CAFO_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_TELEPH] [I6]
 ON [I6].[ICS_ADDR_ID] = [I5].[ICS_ADDR_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CAFO_PRMT]/[ICS_FLOW_LOCAL].[ICS_ANML_TYPE] 
				 UNION 
				SELECT KEY_HASH, I7.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CAFO_PRMT] [ICS_CAFO_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ANML_TYPE] [I7]
 ON [I7].[ICS_CAFO_PRMT_ID] = [ICS_CAFO_PRMT].[ICS_CAFO_PRMT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CAFO_PRMT]/[ICS_FLOW_LOCAL].[ICS_MNUR_LTTR_PRCSS_WW_STOR] 
				 UNION 
				SELECT KEY_HASH, I8.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CAFO_PRMT] [ICS_CAFO_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MNUR_LTTR_PRCSS_WW_STOR] [I8]
 ON [I8].[ICS_CAFO_PRMT_ID] = [ICS_CAFO_PRMT].[ICS_CAFO_PRMT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CAFO_PRMT]/[ICS_FLOW_LOCAL].[ICS_CAFOMLPW_TTL_AMOUNTS] 
				 UNION 
				SELECT KEY_HASH, I9.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CAFO_PRMT] [ICS_CAFO_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CAFOMLPW_TTL_AMOUNTS] [I9]
 ON [I9].[ICS_CAFO_PRMT_ID] = [ICS_CAFO_PRMT].[ICS_CAFO_PRMT_ID] 
    
				WHERE key_hash = @v_key_hash
							  
             ) here
             WHERE here.key_hash = @v_key_hash
             ORDER BY here.data_hash)

              SELECT @v_working_data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', COALESCE(@v_working_data_hash,'#') + data_hash)
                FROM tmp
               WHERE tmp.key_hash = @v_key_hash
               ORDER BY data_hash

              UPDATE ICS_FLOW_LOCAL.ICS_CAFO_PRMT
                 SET data_hash = @v_working_data_hash
               WHERE key_hash = @v_key_hash
             END;
			 
			 

	  
		-- CollectionSystemPermitSubmission, not children
	  
		  
		-- CollectionSystemPermitSubmission

         IF @p_payload_type = 'ICS_COLL_SYSTM_PRMT' and @v_enabled = 'Y'
             BEGIN

             WITH tmp (key_hash, data_hash) AS
             ( SELECT TOP 100 PERCENT here.key_hash, here.data_hash
             FROM (			

				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_COLL_SYSTM_PRMT] 
				
				SELECT KEY_HASH, ICS_COLL_SYSTM_PRMT.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_COLL_SYSTM_PRMT] [ICS_COLL_SYSTM_PRMT] 
    
				WHERE key_hash = @v_key_hash
							  
             ) here
             WHERE here.key_hash = @v_key_hash
             ORDER BY here.data_hash)

              SELECT @v_working_data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', COALESCE(@v_working_data_hash,'#') + data_hash)
                FROM tmp
               WHERE tmp.key_hash = @v_key_hash
               ORDER BY data_hash

              UPDATE ICS_FLOW_LOCAL.ICS_COLL_SYSTM_PRMT
                 SET data_hash = @v_working_data_hash
               WHERE key_hash = @v_key_hash
             END;
			 
			 

	  
		-- CollectionSystemPermitSubmission, not children
	  
		  
		-- ComplianceMonitoringSubmission

         IF @p_payload_type = 'ICS_CMPL_MON' and @v_enabled = 'Y'
             BEGIN

             WITH tmp (key_hash, data_hash) AS
             ( SELECT TOP 100 PERCENT here.key_hash, here.data_hash
             FROM (			

				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CMPL_MON] 
				
				SELECT KEY_HASH, ICS_CMPL_MON.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CMPL_MON]/[ICS_FLOW_LOCAL].[ICS_CONTACT] 
				 UNION 
				SELECT KEY_HASH, I1.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTACT] [I1]
 ON [I1].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CMPL_MON]/[ICS_FLOW_LOCAL].[ICS_CONTACT]/[ICS_FLOW_LOCAL].[ICS_TELEPH] 
				 UNION 
				SELECT KEY_HASH, I2.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTACT] [I1]
 ON [I1].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_TELEPH] [I2]
 ON [I2].[ICS_CONTACT_ID] = [I1].[ICS_CONTACT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CMPL_MON]/[ICS_FLOW_LOCAL].[ICS_NAT_PRIO] 
				 UNION 
				SELECT KEY_HASH, I3.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_NAT_PRIO] [I3]
 ON [I3].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CMPL_MON]/[ICS_FLOW_LOCAL].[ICS_CSO_INSP] 
				 UNION 
				SELECT KEY_HASH, I4.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CSO_INSP] [I4]
 ON [I4].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CMPL_MON]/[ICS_FLOW_LOCAL].[ICS_PRETR_INSP] 
				 UNION 
				SELECT KEY_HASH, I5.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PRETR_INSP] [I5]
 ON [I5].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CMPL_MON]/[ICS_FLOW_LOCAL].[ICS_PROG] 
				 UNION 
				SELECT KEY_HASH, I6.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PROG] [I6]
 ON [I6].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CMPL_MON]/[ICS_FLOW_LOCAL].[ICS_PROG_DEFCY_TYPE] 
				 UNION 
				SELECT KEY_HASH, I7.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PROG_DEFCY_TYPE] [I7]
 ON [I7].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CMPL_MON]/[ICS_FLOW_LOCAL].[ICS_INSP_CMNT_TXT] 
				 UNION 
				SELECT KEY_HASH, I8.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_INSP_CMNT_TXT] [I8]
 ON [I8].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CMPL_MON]/[ICS_FLOW_LOCAL].[ICS_INSP_GOV_CONTACT] 
				 UNION 
				SELECT KEY_HASH, I9.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_INSP_GOV_CONTACT] [I9]
 ON [I9].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CMPL_MON]/[ICS_FLOW_LOCAL].[ICS_SSO_INSP] 
				 UNION 
				SELECT KEY_HASH, I10.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SSO_INSP] [I10]
 ON [I10].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CMPL_MON]/[ICS_FLOW_LOCAL].[ICS_SSO_INSP]/[ICS_FLOW_LOCAL].[ICS_IMPACT_SSO_EVT] 
				 UNION 
				SELECT KEY_HASH, I11.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SSO_INSP] [I10]
 ON [I10].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_IMPACT_SSO_EVT] [I11]
 ON [I11].[ICS_SSO_INSP_ID] = [I10].[ICS_SSO_INSP_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CMPL_MON]/[ICS_FLOW_LOCAL].[ICS_SSO_INSP]/[ICS_FLOW_LOCAL].[ICS_SSO_STPS] 
				 UNION 
				SELECT KEY_HASH, I12.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SSO_INSP] [I10]
 ON [I10].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SSO_STPS] [I12]
 ON [I12].[ICS_SSO_INSP_ID] = [I10].[ICS_SSO_INSP_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CMPL_MON]/[ICS_FLOW_LOCAL].[ICS_SSO_INSP]/[ICS_FLOW_LOCAL].[ICS_SSO_SYSTM_COMP] 
				 UNION 
				SELECT KEY_HASH, I13.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SSO_INSP] [I10]
 ON [I10].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SSO_SYSTM_COMP] [I13]
 ON [I13].[ICS_SSO_INSP_ID] = [I10].[ICS_SSO_INSP_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CMPL_MON]/[ICS_FLOW_LOCAL].[ICS_SW_CNST_INSP] 
				 UNION 
				SELECT KEY_HASH, I14.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SW_CNST_INSP] [I14]
 ON [I14].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CMPL_MON]/[ICS_FLOW_LOCAL].[ICS_SW_CNST_INSP]/[ICS_FLOW_LOCAL].[ICS_SW_CNST_INDST_INSP] 
				 UNION 
				SELECT KEY_HASH, I15.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SW_CNST_INSP] [I14]
 ON [I14].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SW_CNST_INDST_INSP] [I15]
 ON [I15].[ICS_SW_CNST_INSP_ID] = [I14].[ICS_SW_CNST_INSP_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CMPL_MON]/[ICS_FLOW_LOCAL].[ICS_SW_CNST_INSP]/[ICS_FLOW_LOCAL].[ICS_SW_UNPRMT_CNST_INSP] 
				 UNION 
				SELECT KEY_HASH, I16.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SW_CNST_INSP] [I14]
 ON [I14].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SW_UNPRMT_CNST_INSP] [I16]
 ON [I16].[ICS_SW_CNST_INSP_ID] = [I14].[ICS_SW_CNST_INSP_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CMPL_MON]/[ICS_FLOW_LOCAL].[ICS_SW_CNST_INSP]/[ICS_FLOW_LOCAL].[ICS_SW_UNPRMT_CNST_INSP]/[ICS_FLOW_LOCAL].[ICS_PROJ_TYPE] 
				 UNION 
				SELECT KEY_HASH, I17.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SW_CNST_INSP] [I14]
 ON [I14].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SW_UNPRMT_CNST_INSP] [I16]
 ON [I16].[ICS_SW_CNST_INSP_ID] = [I14].[ICS_SW_CNST_INSP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PROJ_TYPE] [I17]
 ON [I17].[ICS_SW_UNPRMT_CNST_INSP_ID] = [I16].[ICS_SW_UNPRMT_CNST_INSP_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CMPL_MON]/[ICS_FLOW_LOCAL].[ICS_SW_CNST_NON_CNST_INSP] 
				 UNION 
				SELECT KEY_HASH, I18.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SW_CNST_NON_CNST_INSP] [I18]
 ON [I18].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CMPL_MON]/[ICS_FLOW_LOCAL].[ICS_SW_CNST_NON_CNST_INSP]/[ICS_FLOW_LOCAL].[ICS_SW_CNST_INDST_INSP] 
				 UNION 
				SELECT KEY_HASH, I19.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SW_CNST_NON_CNST_INSP] [I18]
 ON [I18].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SW_CNST_INDST_INSP] [I19]
 ON [I19].[ICS_SW_CNST_NON_CNST_INSP_ID] = [I18].[ICS_SW_CNST_NON_CNST_INSP_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CMPL_MON]/[ICS_FLOW_LOCAL].[ICS_SW_CNST_NON_CNST_INSP]/[ICS_FLOW_LOCAL].[ICS_SW_UNPRMT_CNST_INSP] 
				 UNION 
				SELECT KEY_HASH, I20.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SW_CNST_NON_CNST_INSP] [I18]
 ON [I18].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SW_UNPRMT_CNST_INSP] [I20]
 ON [I20].[ICS_SW_CNST_NON_CNST_INSP_ID] = [I18].[ICS_SW_CNST_NON_CNST_INSP_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CMPL_MON]/[ICS_FLOW_LOCAL].[ICS_SW_CNST_NON_CNST_INSP]/[ICS_FLOW_LOCAL].[ICS_SW_UNPRMT_CNST_INSP]/[ICS_FLOW_LOCAL].[ICS_PROJ_TYPE] 
				 UNION 
				SELECT KEY_HASH, I21.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SW_CNST_NON_CNST_INSP] [I18]
 ON [I18].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SW_UNPRMT_CNST_INSP] [I20]
 ON [I20].[ICS_SW_CNST_NON_CNST_INSP_ID] = [I18].[ICS_SW_CNST_NON_CNST_INSP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PROJ_TYPE] [I21]
 ON [I21].[ICS_SW_UNPRMT_CNST_INSP_ID] = [I20].[ICS_SW_UNPRMT_CNST_INSP_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CMPL_MON]/[ICS_FLOW_LOCAL].[ICS_SW_MS_4_INSP] 
				 UNION 
				SELECT KEY_HASH, I22.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SW_MS_4_INSP] [I22]
 ON [I22].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CMPL_MON]/[ICS_FLOW_LOCAL].[ICS_SW_MS_4_INSP]/[ICS_FLOW_LOCAL].[ICS_PROJ_SRCS_FUND] 
				 UNION 
				SELECT KEY_HASH, I23.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SW_MS_4_INSP] [I22]
 ON [I22].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PROJ_SRCS_FUND] [I23]
 ON [I23].[ICS_SW_MS_4_INSP_ID] = [I22].[ICS_SW_MS_4_INSP_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CMPL_MON]/[ICS_FLOW_LOCAL].[ICS_SW_NON_CNST_INSP] 
				 UNION 
				SELECT KEY_HASH, I24.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SW_NON_CNST_INSP] [I24]
 ON [I24].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CMPL_MON]/[ICS_FLOW_LOCAL].[ICS_SW_NON_CNST_INSP]/[ICS_FLOW_LOCAL].[ICS_SW_CNST_INDST_INSP] 
				 UNION 
				SELECT KEY_HASH, I25.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SW_NON_CNST_INSP] [I24]
 ON [I24].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SW_CNST_INDST_INSP] [I25]
 ON [I25].[ICS_SW_NON_CNST_INSP_ID] = [I24].[ICS_SW_NON_CNST_INSP_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CMPL_MON]/[ICS_FLOW_LOCAL].[ICS_SW_NON_CNST_INSP]/[ICS_FLOW_LOCAL].[ICS_SW_UNPRMT_CNST_INSP] 
				 UNION 
				SELECT KEY_HASH, I26.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SW_NON_CNST_INSP] [I24]
 ON [I24].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SW_UNPRMT_CNST_INSP] [I26]
 ON [I26].[ICS_SW_NON_CNST_INSP_ID] = [I24].[ICS_SW_NON_CNST_INSP_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CMPL_MON]/[ICS_FLOW_LOCAL].[ICS_SW_NON_CNST_INSP]/[ICS_FLOW_LOCAL].[ICS_SW_UNPRMT_CNST_INSP]/[ICS_FLOW_LOCAL].[ICS_PROJ_TYPE] 
				 UNION 
				SELECT KEY_HASH, I27.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SW_NON_CNST_INSP] [I24]
 ON [I24].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SW_UNPRMT_CNST_INSP] [I26]
 ON [I26].[ICS_SW_NON_CNST_INSP_ID] = [I24].[ICS_SW_NON_CNST_INSP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PROJ_TYPE] [I27]
 ON [I27].[ICS_SW_UNPRMT_CNST_INSP_ID] = [I26].[ICS_SW_UNPRMT_CNST_INSP_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CMPL_MON]/[ICS_FLOW_LOCAL].[ICS_CAFO_INSP] 
				 UNION 
				SELECT KEY_HASH, I28.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CAFO_INSP] [I28]
 ON [I28].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CMPL_MON]/[ICS_FLOW_LOCAL].[ICS_CAFO_INSP]/[ICS_FLOW_LOCAL].[ICS_CONTAINMENT] 
				 UNION 
				SELECT KEY_HASH, I29.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CAFO_INSP] [I28]
 ON [I28].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTAINMENT] [I29]
 ON [I29].[ICS_CAFO_INSP_ID] = [I28].[ICS_CAFO_INSP_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CMPL_MON]/[ICS_FLOW_LOCAL].[ICS_CAFO_INSP]/[ICS_FLOW_LOCAL].[ICS_LAND_APPL_BMP] 
				 UNION 
				SELECT KEY_HASH, I30.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CAFO_INSP] [I28]
 ON [I28].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_LAND_APPL_BMP] [I30]
 ON [I30].[ICS_CAFO_INSP_ID] = [I28].[ICS_CAFO_INSP_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CMPL_MON]/[ICS_FLOW_LOCAL].[ICS_CAFO_INSP]/[ICS_FLOW_LOCAL].[ICS_ANML_TYPE] 
				 UNION 
				SELECT KEY_HASH, I31.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CAFO_INSP] [I28]
 ON [I28].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ANML_TYPE] [I31]
 ON [I31].[ICS_CAFO_INSP_ID] = [I28].[ICS_CAFO_INSP_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CMPL_MON]/[ICS_FLOW_LOCAL].[ICS_CAFO_INSP]/[ICS_FLOW_LOCAL].[ICS_MNUR_LTTR_PRCSS_WW_STOR] 
				 UNION 
				SELECT KEY_HASH, I32.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CAFO_INSP] [I28]
 ON [I28].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MNUR_LTTR_PRCSS_WW_STOR] [I32]
 ON [I32].[ICS_CAFO_INSP_ID] = [I28].[ICS_CAFO_INSP_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CMPL_MON]/[ICS_FLOW_LOCAL].[ICS_CAFO_INSP]/[ICS_FLOW_LOCAL].[ICS_CAFO_INSP_VIOL_TYPE] 
				 UNION 
				SELECT KEY_HASH, I33.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CAFO_INSP] [I28]
 ON [I28].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CAFO_INSP_VIOL_TYPE] [I33]
 ON [I33].[ICS_CAFO_INSP_ID] = [I28].[ICS_CAFO_INSP_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CMPL_MON]/[ICS_FLOW_LOCAL].[ICS_CMPL_INSP_TYPE] 
				 UNION 
				SELECT KEY_HASH, I34.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CMPL_INSP_TYPE] [I34]
 ON [I34].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CMPL_MON]/[ICS_FLOW_LOCAL].[ICS_CMPL_MON_ACTN_REASON] 
				 UNION 
				SELECT KEY_HASH, I35.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CMPL_MON_ACTN_REASON] [I35]
 ON [I35].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CMPL_MON]/[ICS_FLOW_LOCAL].[ICS_CMPL_MON_AGNCY_TYPE] 
				 UNION 
				SELECT KEY_HASH, I36.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CMPL_MON_AGNCY_TYPE] [I36]
 ON [I36].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
    
				WHERE key_hash = @v_key_hash
							  
             ) here
             WHERE here.key_hash = @v_key_hash
             ORDER BY here.data_hash)

              SELECT @v_working_data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', COALESCE(@v_working_data_hash,'#') + data_hash)
                FROM tmp
               WHERE tmp.key_hash = @v_key_hash
               ORDER BY data_hash

              UPDATE ICS_FLOW_LOCAL.ICS_CMPL_MON
                 SET data_hash = @v_working_data_hash
               WHERE key_hash = @v_key_hash
             END;
			 
			 

	  
		-- CollectionSystemPermitSubmission, not children
	  
		  
		-- ComplianceMonitoringLinkageSubmission

         IF @p_payload_type = 'ICS_CMPL_MON_LNK' and @v_enabled = 'Y'
             BEGIN

             WITH tmp (key_hash, data_hash) AS
             ( SELECT TOP 100 PERCENT here.key_hash, here.data_hash
             FROM (			
                     -- /ICS_CMPL_MON_LNK
                      SELECT key_hash
                           , child.data_hash
                        FROM ICS_FLOW_LOCAL.ics_cmpl_mon_lnk child
					   WHERE key_hash = @v_key_hash
        --              UNION ALL
        --              -- /ICS_CMPL_MON_LNK/ICS_LNK_BS_REP
        --              SELECT key_hash
        --                   , child.data_hash
        --                FROM ICS_FLOW_LOCAL.ics_cmpl_mon_lnk
        --                JOIN ICS_FLOW_LOCAL.ics_lnk_bs_rep child
        --                  ON child.ics_cmpl_mon_lnk_id = ics_cmpl_mon_lnk.ics_cmpl_mon_lnk_id
					   --WHERE key_hash = @v_key_hash
        --              UNION ALL
        --               -- /ICS_CMPL_MON_LNK/ICS_LNK_CAFO_ANNUL_REP
        --              SELECT key_hash
        --                   , child.data_hash
        --                FROM ICS_FLOW_LOCAL.ics_cmpl_mon_lnk
        --                JOIN ICS_FLOW_LOCAL.ics_lnk_cafo_annul_rep child
        --                  ON child.ics_cmpl_mon_lnk_id = ics_cmpl_mon_lnk.ics_cmpl_mon_lnk_id
					   --WHERE key_hash = @v_key_hash
                      UNION ALL
                      -- /ICS_CMPL_MON_LNK/ICS_LNK_CSO_EVT_REP
        --              SELECT key_hash
        --                   , child.data_hash
        --                FROM ICS_FLOW_LOCAL.ics_cmpl_mon_lnk
        --                JOIN ICS_FLOW_LOCAL.ics_lnk_cso_evt_rep child
        --                  ON child.ics_cmpl_mon_lnk_id = ics_cmpl_mon_lnk.ics_cmpl_mon_lnk_id
					   --WHERE key_hash = @v_key_hash
        --              UNION ALL
                      -- /ICS_CMPL_MON_LNK/ICS_LNK_ENFRC_ACTN
                      SELECT key_hash
                           , child.data_hash
                        FROM ICS_FLOW_LOCAL.ics_cmpl_mon_lnk
                        JOIN ICS_FLOW_LOCAL.ics_lnk_enfrc_actn child
                          ON child.ics_cmpl_mon_lnk_id = ics_cmpl_mon_lnk.ics_cmpl_mon_lnk_id
					   WHERE key_hash = @v_key_hash
                      UNION ALL
                      -- /ICS_CMPL_MON_LNK/ICS_LNK_FEDR_CMPL_MON
        --              SELECT key_hash
        --                   , child.data_hash
        --                FROM ICS_FLOW_LOCAL.ics_cmpl_mon_lnk
        --                JOIN ICS_FLOW_LOCAL.ics_lnk_fedr_cmpl_mon child
        --                  ON child.ics_cmpl_mon_lnk_id = ics_cmpl_mon_lnk.ics_cmpl_mon_lnk_id
					   --WHERE key_hash = @v_key_hash
        --              UNION ALL
        --              -- /ICS_CMPL_MON_LNK/ICS_LNK_LOC_LMTS_REP
        --              SELECT key_hash
        --                   , child.data_hash
        --                FROM ICS_FLOW_LOCAL.ics_cmpl_mon_lnk
        --                JOIN ICS_FLOW_LOCAL.ics_lnk_loc_lmts_rep child
        --                  ON child.ics_cmpl_mon_lnk_id = ics_cmpl_mon_lnk.ics_cmpl_mon_lnk_id
					   --WHERE key_hash = @v_key_hash
        --              UNION ALL
        --              -- /ICS_CMPL_MON_LNK/ICS_LNK_PRETR_PERF_REP
        --              SELECT key_hash
        --                   , child.data_hash
        --                FROM ICS_FLOW_LOCAL.ics_cmpl_mon_lnk
        --                JOIN ICS_FLOW_LOCAL.ics_lnk_pretr_perf_rep child
        --                  ON child.ics_cmpl_mon_lnk_id = ics_cmpl_mon_lnk.ics_cmpl_mon_lnk_id
					   --WHERE key_hash = @v_key_hash
        --              UNION ALL
                      -- /ICS_CMPL_MON_LNK/ICS_LNK_SNGL_EVT
                      SELECT key_hash
                           , child.data_hash
                        FROM ICS_FLOW_LOCAL.ics_cmpl_mon_lnk
                        JOIN ICS_FLOW_LOCAL.ics_lnk_sngl_evt child
                          ON child.ics_cmpl_mon_lnk_id = ics_cmpl_mon_lnk.ics_cmpl_mon_lnk_id
					   WHERE key_hash = @v_key_hash
                      UNION ALL
                      -- /ICS_CMPL_MON_LNK/ICS_LNK_SSO_ANNUL_REP
        --              SELECT key_hash
        --                   , child.data_hash
        --                FROM ICS_FLOW_LOCAL.ics_cmpl_mon_lnk
        --                JOIN ICS_FLOW_LOCAL.ics_lnk_sso_annul_rep child
        --                  ON child.ics_cmpl_mon_lnk_id = ics_cmpl_mon_lnk.ics_cmpl_mon_lnk_id
					   --WHERE key_hash = @v_key_hash
        --              UNION ALL
                      -- /ICS_CMPL_MON_LNK/ICS_LNK_SSO_EVT_REP
        --              SELECT key_hash
        --                   , child.data_hash
        --                FROM ICS_FLOW_LOCAL.ics_cmpl_mon_lnk
        --                JOIN ICS_FLOW_LOCAL.ics_lnk_sso_evt_rep child
        --                  ON child.ics_cmpl_mon_lnk_id = ics_cmpl_mon_lnk.ics_cmpl_mon_lnk_id
					   --WHERE key_hash = @v_key_hash
        --              UNION ALL
                      -- /ICS_CMPL_MON_LNK/ICS_LNK_SSO_MONTHLY_EVT_REP
        --              SELECT key_hash
        --                   , child.data_hash
        --                FROM ICS_FLOW_LOCAL.ics_cmpl_mon_lnk
        --                JOIN ICS_FLOW_LOCAL.ics_lnk_sso_monthly_evt_rep child
        --                  ON child.ics_cmpl_mon_lnk_id = ics_cmpl_mon_lnk.ics_cmpl_mon_lnk_id
					   --WHERE key_hash = @v_key_hash
        --              UNION ALL
                      -- /ICS_CMPL_MON_LNK/ics_lnk_cmpl_mon
                      SELECT key_hash
                           , child.data_hash
                        FROM ICS_FLOW_LOCAL.ics_cmpl_mon_lnk
                        JOIN ICS_FLOW_LOCAL.ics_lnk_cmpl_mon child
                          ON child.ics_cmpl_mon_lnk_id = ics_cmpl_mon_lnk.ics_cmpl_mon_lnk_id
					   WHERE key_hash = @v_key_hash
                      --UNION ALL
                      -- /ICS_CMPL_MON_LNK/ICS_LNK_SW_EVT_REP
        --              SELECT key_hash
        --                   , child.data_hash
        --                FROM ICS_FLOW_LOCAL.ics_cmpl_mon_lnk
        --                JOIN ICS_FLOW_LOCAL.ics_lnk_sw_evt_rep child
        --                  ON child.ics_cmpl_mon_lnk_id = ics_cmpl_mon_lnk.ics_cmpl_mon_lnk_id
					   --WHERE key_hash = @v_key_hash
        --              UNION ALL
                      -- /ICS_CMPL_MON_LNK/ICS_LNK_SWMS_4_REP
        --              SELECT key_hash
        --                   , child.data_hash
        --                FROM ICS_FLOW_LOCAL.ics_cmpl_mon_lnk
        --                JOIN ICS_FLOW_LOCAL.ics_lnk_swms_4_rep child
        --                  ON child.ics_cmpl_mon_lnk_id = ics_cmpl_mon_lnk.ics_cmpl_mon_lnk_id
					   --WHERE key_hash = @v_key_hash
							  
             ) here
             WHERE here.key_hash = @v_key_hash
             ORDER BY here.data_hash)

              SELECT @v_working_data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', COALESCE(@v_working_data_hash,'#') + data_hash)
                FROM tmp
               WHERE tmp.key_hash = @v_key_hash
               ORDER BY data_hash

              UPDATE ICS_FLOW_LOCAL.ICS_CMPL_MON_LNK
                 SET data_hash = @v_working_data_hash
               WHERE key_hash = @v_key_hash
             END;
			 
			 

	  
		-- CollectionSystemPermitSubmission, not children
	  
		  
		-- ComplianceScheduleSubmission

         IF @p_payload_type = 'ICS_CMPL_SCHD' and @v_enabled = 'Y'
             BEGIN

             WITH tmp (key_hash, data_hash) AS
             ( SELECT TOP 100 PERCENT here.key_hash, here.data_hash
             FROM (			

				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CMPL_SCHD] 
				
				SELECT KEY_HASH, ICS_CMPL_SCHD.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CMPL_SCHD] [ICS_CMPL_SCHD] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CMPL_SCHD]/[ICS_FLOW_LOCAL].[ICS_CMPL_SCHD_EVT] 
				 UNION 
				SELECT KEY_HASH, I1.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CMPL_SCHD] [ICS_CMPL_SCHD] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CMPL_SCHD_EVT] [I1]
 ON [I1].[ICS_CMPL_SCHD_ID] = [ICS_CMPL_SCHD].[ICS_CMPL_SCHD_ID] 
    
				WHERE key_hash = @v_key_hash
							  
             ) here
             WHERE here.key_hash = @v_key_hash
             ORDER BY here.data_hash)

              SELECT @v_working_data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', COALESCE(@v_working_data_hash,'#') + data_hash)
                FROM tmp
               WHERE tmp.key_hash = @v_key_hash
               ORDER BY data_hash

              UPDATE ICS_FLOW_LOCAL.ICS_CMPL_SCHD
                 SET data_hash = @v_working_data_hash
               WHERE key_hash = @v_key_hash
             END;
			 
			 

	  
		-- CollectionSystemPermitSubmission, not children
	  
		  
		-- CopyMGPLimitSetSubmission

         IF @p_payload_type = 'ICS_COPY_MGP_LMT_SET' and @v_enabled = 'Y'
             BEGIN

             WITH tmp (key_hash, data_hash) AS
             ( SELECT TOP 100 PERCENT here.key_hash, here.data_hash
             FROM (			
                      -- /ICS_COPY_MGP_LMT_SET
                      SELECT key_hash
                           , child.data_hash
                        FROM ICS_FLOW_LOCAL.ics_copy_mgp_lmt_set child
					   WHERE key_hash = @v_key_hash
                      UNION ALL
                      -- /ICS_COPY_MGP_LMT_SET/ICS_LMT_SET_SCHD
                      SELECT key_hash
                           , child.data_hash
                        FROM ICS_FLOW_LOCAL.ics_copy_mgp_lmt_set
                        JOIN ICS_FLOW_LOCAL.ics_lmt_set_schd child
                          ON child.ics_copy_mgp_lmt_set_id = ICS_COPY_MGP_LMT_SET.ics_copy_mgp_lmt_set_id
					   WHERE key_hash = @v_key_hash  
                      UNION ALL
                      -- /ICS_COPY_MGP_LMT_SET/ICS_LMT_SET_STAT
                      SELECT key_hash
                           , child.data_hash
                        FROM ICS_FLOW_LOCAL.ics_copy_mgp_lmt_set
                        JOIN ICS_FLOW_LOCAL.ics_lmt_set_stat child
                          ON child.ics_copy_mgp_lmt_set_id = ICS_COPY_MGP_LMT_SET.ics_copy_mgp_lmt_set_id
					   WHERE key_hash = @v_key_hash    
                      UNION ALL
                      -- /ICS_COPY_MGP_LMT_SET/ICS_GEO_COORD
                      SELECT key_hash
                           , child.data_hash
                        FROM ICS_FLOW_LOCAL.ics_copy_mgp_lmt_set
                        JOIN ICS_FLOW_LOCAL.ics_geo_coord child
                          ON child.ics_copy_mgp_lmt_set_id = ICS_COPY_MGP_LMT_SET.ics_copy_mgp_lmt_set_id
					   WHERE key_hash = @v_key_hash  
							  
             ) here
             WHERE here.key_hash = @v_key_hash
             ORDER BY here.data_hash)

              SELECT @v_working_data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', COALESCE(@v_working_data_hash,'#') + data_hash)
                FROM tmp
               WHERE tmp.key_hash = @v_key_hash
               ORDER BY data_hash

              UPDATE ICS_FLOW_LOCAL.ICS_COPY_MGP_LMT_SET
                 SET data_hash = @v_working_data_hash
               WHERE key_hash = @v_key_hash
             END;
			 
			 

	  
		-- CollectionSystemPermitSubmission, not children
	  
		  
		-- CopyMGPMS4RequirementSubmission

         IF @p_payload_type = 'ICS_COPY_MGPMS_4_REQ' and @v_enabled = 'Y'
             BEGIN

             WITH tmp (key_hash, data_hash) AS
             ( SELECT TOP 100 PERCENT here.key_hash, here.data_hash
             FROM (			

				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_COPY_MGPMS_4_REQ] 
				
				SELECT KEY_HASH, ICS_COPY_MGPMS_4_REQ.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_COPY_MGPMS_4_REQ] [ICS_COPY_MGPMS_4_REQ] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_COPY_MGPMS_4_REQ]/[ICS_FLOW_LOCAL].[ICS_GNRL_PRMT_COVERAGE_MS_4_REQ] 
				 UNION 
				SELECT KEY_HASH, I1.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_COPY_MGPMS_4_REQ] [ICS_COPY_MGPMS_4_REQ] 
 JOIN [ICS_FLOW_LOCAL].[ICS_GNRL_PRMT_COVERAGE_MS_4_REQ] [I1]
 ON [I1].[ICS_COPY_MGPMS_4_REQ_ID] = [ICS_COPY_MGPMS_4_REQ].[ICS_COPY_MGPMS_4_REQ_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_COPY_MGPMS_4_REQ]/[ICS_FLOW_LOCAL].[ICS_GNRL_PRMT_COVERAGE_MS_4_REQ]/[ICS_FLOW_LOCAL].[ICS_MS_4_REGULATED_ENTITY_IDENT] 
				 UNION 
				SELECT KEY_HASH, I2.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_COPY_MGPMS_4_REQ] [ICS_COPY_MGPMS_4_REQ] 
 JOIN [ICS_FLOW_LOCAL].[ICS_GNRL_PRMT_COVERAGE_MS_4_REQ] [I1]
 ON [I1].[ICS_COPY_MGPMS_4_REQ_ID] = [ICS_COPY_MGPMS_4_REQ].[ICS_COPY_MGPMS_4_REQ_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_REGULATED_ENTITY_IDENT] [I2]
 ON [I2].[ICS_GNRL_PRMT_COVERAGE_MS_4_REQ_ID] = [I1].[ICS_GNRL_PRMT_COVERAGE_MS_4_REQ_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_COPY_MGPMS_4_REQ]/[ICS_FLOW_LOCAL].[ICS_MS_4_ACTY_IDENT] 
				 UNION 
				SELECT KEY_HASH, I3.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_COPY_MGPMS_4_REQ] [ICS_COPY_MGPMS_4_REQ] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_ACTY_IDENT] [I3]
 ON [I3].[ICS_COPY_MGPMS_4_REQ_ID] = [ICS_COPY_MGPMS_4_REQ].[ICS_COPY_MGPMS_4_REQ_ID] 
    
				WHERE key_hash = @v_key_hash
							  
             ) here
             WHERE here.key_hash = @v_key_hash
             ORDER BY here.data_hash)

              SELECT @v_working_data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', COALESCE(@v_working_data_hash,'#') + data_hash)
                FROM tmp
               WHERE tmp.key_hash = @v_key_hash
               ORDER BY data_hash

              UPDATE ICS_FLOW_LOCAL.ICS_COPY_MGPMS_4_REQ
                 SET data_hash = @v_working_data_hash
               WHERE key_hash = @v_key_hash
             END;
			 
			 

	  
		-- CollectionSystemPermitSubmission, not children
	  
		  
		-- CSOLongTermControlPlanSubmission

         IF @p_payload_type = 'ICS_CSO_LONG_TERM_CONTROL_PLAN' and @v_enabled = 'Y'
             BEGIN

             WITH tmp (key_hash, data_hash) AS
             ( SELECT TOP 100 PERCENT here.key_hash, here.data_hash
             FROM (			

				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CSO_LONG_TERM_CONTROL_PLAN] 
				
				SELECT KEY_HASH, ICS_CSO_LONG_TERM_CONTROL_PLAN.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CSO_LONG_TERM_CONTROL_PLAN] [ICS_CSO_LONG_TERM_CONTROL_PLAN] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CSO_LONG_TERM_CONTROL_PLAN]/[ICS_FLOW_LOCAL].[ICS_CSO_CONTROL_MEAS_DETAIL] 
				 UNION 
				SELECT KEY_HASH, I1.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CSO_LONG_TERM_CONTROL_PLAN] [ICS_CSO_LONG_TERM_CONTROL_PLAN] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CSO_CONTROL_MEAS_DETAIL] [I1]
 ON [I1].[ICS_CSO_LONG_TERM_CONTROL_PLAN_ID] = [ICS_CSO_LONG_TERM_CONTROL_PLAN].[ICS_CSO_LONG_TERM_CONTROL_PLAN_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CSO_LONG_TERM_CONTROL_PLAN]/[ICS_FLOW_LOCAL].[ICS_LTCP_ENFORCEABLE_MECH_DETAIL] 
				 UNION 
				SELECT KEY_HASH, I2.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CSO_LONG_TERM_CONTROL_PLAN] [ICS_CSO_LONG_TERM_CONTROL_PLAN] 
 JOIN [ICS_FLOW_LOCAL].[ICS_LTCP_ENFORCEABLE_MECH_DETAIL] [I2]
 ON [I2].[ICS_CSO_LONG_TERM_CONTROL_PLAN_ID] = [ICS_CSO_LONG_TERM_CONTROL_PLAN].[ICS_CSO_LONG_TERM_CONTROL_PLAN_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CSO_LONG_TERM_CONTROL_PLAN]/[ICS_FLOW_LOCAL].[ICS_LTCP_MOST_RECENT_REVISION_DETAIL] 
				 UNION 
				SELECT KEY_HASH, I3.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CSO_LONG_TERM_CONTROL_PLAN] [ICS_CSO_LONG_TERM_CONTROL_PLAN] 
 JOIN [ICS_FLOW_LOCAL].[ICS_LTCP_MOST_RECENT_REVISION_DETAIL] [I3]
 ON [I3].[ICS_CSO_LONG_TERM_CONTROL_PLAN_ID] = [ICS_CSO_LONG_TERM_CONTROL_PLAN].[ICS_CSO_LONG_TERM_CONTROL_PLAN_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CSO_LONG_TERM_CONTROL_PLAN]/[ICS_FLOW_LOCAL].[ICS_LTCP_SUMM] 
				 UNION 
				SELECT KEY_HASH, I4.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CSO_LONG_TERM_CONTROL_PLAN] [ICS_CSO_LONG_TERM_CONTROL_PLAN] 
 JOIN [ICS_FLOW_LOCAL].[ICS_LTCP_SUMM] [I4]
 ON [I4].[ICS_CSO_LONG_TERM_CONTROL_PLAN_ID] = [ICS_CSO_LONG_TERM_CONTROL_PLAN].[ICS_CSO_LONG_TERM_CONTROL_PLAN_ID] 
    
				WHERE key_hash = @v_key_hash
							  
             ) here
             WHERE here.key_hash = @v_key_hash
             ORDER BY here.data_hash)

              SELECT @v_working_data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', COALESCE(@v_working_data_hash,'#') + data_hash)
                FROM tmp
               WHERE tmp.key_hash = @v_key_hash
               ORDER BY data_hash

              UPDATE ICS_FLOW_LOCAL.ICS_CSO_LONG_TERM_CONTROL_PLAN
                 SET data_hash = @v_working_data_hash
               WHERE key_hash = @v_key_hash
             END;
			 
			 

	  
		-- CollectionSystemPermitSubmission, not children
	  
		  
		-- CWA316bProgramReportSubmission

         IF @p_payload_type = 'ICS_CWA_316B_PROG_REP' and @v_enabled = 'Y'
             BEGIN

             WITH tmp (key_hash, data_hash) AS
             ( SELECT TOP 100 PERCENT here.key_hash, here.data_hash
             FROM (			

				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CWA_316B_PROG_REP] 
				
				SELECT KEY_HASH, ICS_CWA_316B_PROG_REP.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CWA_316B_PROG_REP] [ICS_CWA_316B_PROG_REP] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_CWA_316B_PROG_REP]/[ICS_FLOW_LOCAL].[ICS_CWA_316B_TAKE_INFO] 
				 UNION 
				SELECT KEY_HASH, I1.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_CWA_316B_PROG_REP] [ICS_CWA_316B_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CWA_316B_TAKE_INFO] [I1]
 ON [I1].[ICS_CWA_316B_PROG_REP_ID] = [ICS_CWA_316B_PROG_REP].[ICS_CWA_316B_PROG_REP_ID] 
    
				WHERE key_hash = @v_key_hash
							  
             ) here
             WHERE here.key_hash = @v_key_hash
             ORDER BY here.data_hash)

              SELECT @v_working_data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', COALESCE(@v_working_data_hash,'#') + data_hash)
                FROM tmp
               WHERE tmp.key_hash = @v_key_hash
               ORDER BY data_hash

              UPDATE ICS_FLOW_LOCAL.ICS_CWA_316B_PROG_REP
                 SET data_hash = @v_working_data_hash
               WHERE key_hash = @v_key_hash
             END;
			 
			 

	  
		-- CollectionSystemPermitSubmission, not children
	  
		  
		-- DischargeMonitoringReportSubmission

         IF @p_payload_type = 'ICS_DSCH_MON_REP' and @v_enabled = 'Y'
             BEGIN

             WITH tmp (key_hash, data_hash) AS
             ( SELECT TOP 100 PERCENT here.key_hash, here.data_hash
             FROM (			

				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_DSCH_MON_REP] 
				
				SELECT KEY_HASH, ICS_DSCH_MON_REP.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_DSCH_MON_REP] [ICS_DSCH_MON_REP] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_DSCH_MON_REP]/[ICS_FLOW_LOCAL].[ICS_REP_PARAM] 
				 UNION 
				SELECT KEY_HASH, I1.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_DSCH_MON_REP] [ICS_DSCH_MON_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_REP_PARAM] [I1]
 ON [I1].[ICS_DSCH_MON_REP_ID] = [ICS_DSCH_MON_REP].[ICS_DSCH_MON_REP_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_DSCH_MON_REP]/[ICS_FLOW_LOCAL].[ICS_REP_PARAM]/[ICS_FLOW_LOCAL].[ICS_NUM_REP] 
				 UNION 
				SELECT KEY_HASH, I2.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_DSCH_MON_REP] [ICS_DSCH_MON_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_REP_PARAM] [I1]
 ON [I1].[ICS_DSCH_MON_REP_ID] = [ICS_DSCH_MON_REP].[ICS_DSCH_MON_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_NUM_REP] [I2]
 ON [I2].[ICS_REP_PARAM_ID] = [I1].[ICS_REP_PARAM_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_DSCH_MON_REP]/[ICS_FLOW_LOCAL].[ICS_INCIN] 
				 UNION 
				SELECT KEY_HASH, I3.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_DSCH_MON_REP] [ICS_DSCH_MON_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_INCIN] [I3]
 ON [I3].[ICS_DSCH_MON_REP_ID] = [ICS_DSCH_MON_REP].[ICS_DSCH_MON_REP_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_DSCH_MON_REP]/[ICS_FLOW_LOCAL].[ICS_LAND_APPL_SITE] 
				 UNION 
				SELECT KEY_HASH, I4.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_DSCH_MON_REP] [ICS_DSCH_MON_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_LAND_APPL_SITE] [I4]
 ON [I4].[ICS_DSCH_MON_REP_ID] = [ICS_DSCH_MON_REP].[ICS_DSCH_MON_REP_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_DSCH_MON_REP]/[ICS_FLOW_LOCAL].[ICS_LAND_APPL_SITE]/[ICS_FLOW_LOCAL].[ICS_CROP_TYPES_HARVESTED] 
				 UNION 
				SELECT KEY_HASH, I5.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_DSCH_MON_REP] [ICS_DSCH_MON_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_LAND_APPL_SITE] [I4]
 ON [I4].[ICS_DSCH_MON_REP_ID] = [ICS_DSCH_MON_REP].[ICS_DSCH_MON_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CROP_TYPES_HARVESTED] [I5]
 ON [I5].[ICS_LAND_APPL_SITE_ID] = [I4].[ICS_LAND_APPL_SITE_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_DSCH_MON_REP]/[ICS_FLOW_LOCAL].[ICS_LAND_APPL_SITE]/[ICS_FLOW_LOCAL].[ICS_CROP_TYPES_PLANTED] 
				 UNION 
				SELECT KEY_HASH, I6.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_DSCH_MON_REP] [ICS_DSCH_MON_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_LAND_APPL_SITE] [I4]
 ON [I4].[ICS_DSCH_MON_REP_ID] = [ICS_DSCH_MON_REP].[ICS_DSCH_MON_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CROP_TYPES_PLANTED] [I6]
 ON [I6].[ICS_LAND_APPL_SITE_ID] = [I4].[ICS_LAND_APPL_SITE_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_DSCH_MON_REP]/[ICS_FLOW_LOCAL].[ICS_SURF_DSPL_SITE] 
				 UNION 
				SELECT KEY_HASH, I7.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_DSCH_MON_REP] [ICS_DSCH_MON_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SURF_DSPL_SITE] [I7]
 ON [I7].[ICS_DSCH_MON_REP_ID] = [ICS_DSCH_MON_REP].[ICS_DSCH_MON_REP_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_DSCH_MON_REP]/[ICS_FLOW_LOCAL].[ICS_CO_DSPL_SITE] 
				 UNION 
				SELECT KEY_HASH, I8.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_DSCH_MON_REP] [ICS_DSCH_MON_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CO_DSPL_SITE] [I8]
 ON [I8].[ICS_DSCH_MON_REP_ID] = [ICS_DSCH_MON_REP].[ICS_DSCH_MON_REP_ID] 
    
				WHERE key_hash = @v_key_hash
							  
             ) here
             WHERE here.key_hash = @v_key_hash
             ORDER BY here.data_hash)

              SELECT @v_working_data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', COALESCE(@v_working_data_hash,'#') + data_hash)
                FROM tmp
               WHERE tmp.key_hash = @v_key_hash
               ORDER BY data_hash

              UPDATE ICS_FLOW_LOCAL.ICS_DSCH_MON_REP
                 SET data_hash = @v_working_data_hash
               WHERE key_hash = @v_key_hash
             END;
			 
			 

	  
		-- CollectionSystemPermitSubmission, not children
	  
		  
		-- DMRViolationSubmission

         IF @p_payload_type = 'ICS_DMR_VIOL' and @v_enabled = 'Y'
             BEGIN

             WITH tmp (key_hash, data_hash) AS
             ( SELECT TOP 100 PERCENT here.key_hash, here.data_hash
             FROM (			

				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_DMR_VIOL] 
				
				SELECT KEY_HASH, ICS_DMR_VIOL.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_DMR_VIOL] [ICS_DMR_VIOL] 
    
				WHERE key_hash = @v_key_hash
							  
             ) here
             WHERE here.key_hash = @v_key_hash
             ORDER BY here.data_hash)

              SELECT @v_working_data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', COALESCE(@v_working_data_hash,'#') + data_hash)
                FROM tmp
               WHERE tmp.key_hash = @v_key_hash
               ORDER BY data_hash

              UPDATE ICS_FLOW_LOCAL.ICS_DMR_VIOL
                 SET data_hash = @v_working_data_hash
               WHERE key_hash = @v_key_hash
             END;
			 
			 

	  
		-- CollectionSystemPermitSubmission, not children
	  
		  
		-- EffluentTradePartnerSubmission

         IF @p_payload_type = 'ICS_EFFLU_TRADE_PRTNER' and @v_enabled = 'Y'
             BEGIN

             WITH tmp (key_hash, data_hash) AS
             ( SELECT TOP 100 PERCENT here.key_hash, here.data_hash
             FROM (			

				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_EFFLU_TRADE_PRTNER] 
				
				SELECT KEY_HASH, ICS_EFFLU_TRADE_PRTNER.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_EFFLU_TRADE_PRTNER] [ICS_EFFLU_TRADE_PRTNER] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_EFFLU_TRADE_PRTNER]/[ICS_FLOW_LOCAL].[ICS_EFFLU_TRADE_PRTNER_ADDR] 
				 UNION 
				SELECT KEY_HASH, I1.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_EFFLU_TRADE_PRTNER] [ICS_EFFLU_TRADE_PRTNER] 
 JOIN [ICS_FLOW_LOCAL].[ICS_EFFLU_TRADE_PRTNER_ADDR] [I1]
 ON [I1].[ICS_EFFLU_TRADE_PRTNER_ID] = [ICS_EFFLU_TRADE_PRTNER].[ICS_EFFLU_TRADE_PRTNER_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_EFFLU_TRADE_PRTNER]/[ICS_FLOW_LOCAL].[ICS_EFFLU_TRADE_PRTNER_ADDR]/[ICS_FLOW_LOCAL].[ICS_TELEPH] 
				 UNION 
				SELECT KEY_HASH, I2.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_EFFLU_TRADE_PRTNER] [ICS_EFFLU_TRADE_PRTNER] 
 JOIN [ICS_FLOW_LOCAL].[ICS_EFFLU_TRADE_PRTNER_ADDR] [I1]
 ON [I1].[ICS_EFFLU_TRADE_PRTNER_ID] = [ICS_EFFLU_TRADE_PRTNER].[ICS_EFFLU_TRADE_PRTNER_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_TELEPH] [I2]
 ON [I2].[ICS_EFFLU_TRADE_PRTNER_ADDR_ID] = [I1].[ICS_EFFLU_TRADE_PRTNER_ADDR_ID] 
    
				WHERE key_hash = @v_key_hash
							  
             ) here
             WHERE here.key_hash = @v_key_hash
             ORDER BY here.data_hash)

              SELECT @v_working_data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', COALESCE(@v_working_data_hash,'#') + data_hash)
                FROM tmp
               WHERE tmp.key_hash = @v_key_hash
               ORDER BY data_hash

              UPDATE ICS_FLOW_LOCAL.ICS_EFFLU_TRADE_PRTNER
                 SET data_hash = @v_working_data_hash
               WHERE key_hash = @v_key_hash
             END;
			 
			 

	  
		-- CollectionSystemPermitSubmission, not children
	  
		  
		-- EnforcementActionMilestoneSubmission

         IF @p_payload_type = 'ICS_ENFRC_ACTN_MILESTONE' and @v_enabled = 'Y'
             BEGIN

             WITH tmp (key_hash, data_hash) AS
             ( SELECT TOP 100 PERCENT here.key_hash, here.data_hash
             FROM (			

				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_ENFRC_ACTN_MILESTONE] 
				
				SELECT KEY_HASH, ICS_ENFRC_ACTN_MILESTONE.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_ENFRC_ACTN_MILESTONE] [ICS_ENFRC_ACTN_MILESTONE] 
    
				WHERE key_hash = @v_key_hash
							  
             ) here
             WHERE here.key_hash = @v_key_hash
             ORDER BY here.data_hash)

              SELECT @v_working_data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', COALESCE(@v_working_data_hash,'#') + data_hash)
                FROM tmp
               WHERE tmp.key_hash = @v_key_hash
               ORDER BY data_hash

              UPDATE ICS_FLOW_LOCAL.ICS_ENFRC_ACTN_MILESTONE
                 SET data_hash = @v_working_data_hash
               WHERE key_hash = @v_key_hash
             END;
			 
			 

	  
		-- CollectionSystemPermitSubmission, not children
	  
		  
		-- EnforcementActionViolationLinkageSubmission

         IF @p_payload_type = 'ICS_ENFRC_ACTN_VIOL_LNK' and @v_enabled = 'Y'
             BEGIN

             WITH tmp (key_hash, data_hash) AS
             ( SELECT TOP 100 PERCENT here.key_hash, here.data_hash
             FROM (			
                     -- /ICS_ENFRC_ACTN_VIOL_LNK
                      SELECT key_hash
                           , child.data_hash
                        FROM ICS_FLOW_LOCAL.ics_enfrc_actn_viol_lnk child
					   WHERE key_hash = @v_key_hash
                      UNION ALL
                      -- /ICS_ENFRC_ACTN_VIOL_LNK/ICS_CMPL_SCHD_VIOL
                      SELECT key_hash
                           , child.data_hash
                        FROM ICS_FLOW_LOCAL.ics_enfrc_actn_viol_lnk
                        JOIN ICS_FLOW_LOCAL.ics_cmpl_schd_viol child
                          ON child.ics_enfrc_actn_viol_lnk_id = ics_enfrc_actn_viol_lnk.ics_enfrc_actn_viol_lnk_id
					   WHERE key_hash = @v_key_hash
                      UNION ALL
                      -- /ICS_ENFRC_ACTN_VIOL_LNK/ICS_DSCH_MON_REP_PARAM_VIOL
                      SELECT key_hash
                           , child.data_hash
                        FROM ICS_FLOW_LOCAL.ics_enfrc_actn_viol_lnk
                        JOIN ICS_FLOW_LOCAL.ics_dsch_mon_rep_param_viol child
                          ON child.ics_enfrc_actn_viol_lnk_id = ics_enfrc_actn_viol_lnk.ics_enfrc_actn_viol_lnk_id
					   WHERE key_hash = @v_key_hash
                      UNION ALL
                      -- /ICS_ENFRC_ACTN_VIOL_LNK/ICS_DSCH_MON_REP_VIOL
                      SELECT key_hash
                           , child.data_hash
                        FROM ICS_FLOW_LOCAL.ics_enfrc_actn_viol_lnk
                        JOIN ICS_FLOW_LOCAL.ics_dsch_mon_rep_viol child
                          ON child.ics_enfrc_actn_viol_lnk_id = ics_enfrc_actn_viol_lnk.ics_enfrc_actn_viol_lnk_id
					   WHERE key_hash = @v_key_hash
                      UNION ALL
                      -- /ICS_ENFRC_ACTN_VIOL_LNK/ICS_PRMT_SCHD_VIOL
                      SELECT key_hash
                           , child.data_hash
                        FROM ICS_FLOW_LOCAL.ics_enfrc_actn_viol_lnk
                        JOIN ICS_FLOW_LOCAL.ics_prmt_schd_viol child
                          ON child.ics_enfrc_actn_viol_lnk_id = ics_enfrc_actn_viol_lnk.ics_enfrc_actn_viol_lnk_id
					   WHERE key_hash = @v_key_hash
                      UNION ALL
                      -- /ICS_ENFRC_ACTN_VIOL_LNK/ICS_SNGL_EVTS_VIOL
                      SELECT key_hash
                           , child.data_hash
                        FROM ICS_FLOW_LOCAL.ics_enfrc_actn_viol_lnk
                        JOIN ICS_FLOW_LOCAL.ics_sngl_evts_viol child
                          ON child.ics_enfrc_actn_viol_lnk_id = ics_enfrc_actn_viol_lnk.ics_enfrc_actn_viol_lnk_id
					   WHERE key_hash = @v_key_hash
							  
             ) here
             WHERE here.key_hash = @v_key_hash
             ORDER BY here.data_hash)

              SELECT @v_working_data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', COALESCE(@v_working_data_hash,'#') + data_hash)
                FROM tmp
               WHERE tmp.key_hash = @v_key_hash
               ORDER BY data_hash

              UPDATE ICS_FLOW_LOCAL.ICS_ENFRC_ACTN_VIOL_LNK
                 SET data_hash = @v_working_data_hash
               WHERE key_hash = @v_key_hash
             END;
			 
			 

	  
		-- CollectionSystemPermitSubmission, not children
	  
		  
		-- FinalOrderViolationLinkageSubmission

         IF @p_payload_type = 'ICS_FINAL_ORDER_VIOL_LNK' and @v_enabled = 'Y'
             BEGIN

             WITH tmp (key_hash, data_hash) AS
             ( SELECT TOP 100 PERCENT here.key_hash, here.data_hash
             FROM (			
                      -- /ICS_FINAL_ORDER_VIOL_LNK
                      SELECT key_hash
                           , child.data_hash
                        FROM ICS_FLOW_LOCAL.ics_final_order_viol_lnk child
					   WHERE key_hash = @v_key_hash
                      UNION ALL
                      -- /ICS_FINAL_ORDER_VIOL_LNK/ICS_CMPL_SCHD_VIOL
                      SELECT key_hash
                           , child.data_hash
                        FROM ICS_FLOW_LOCAL.ics_final_order_viol_lnk
                        JOIN ICS_FLOW_LOCAL.ics_cmpl_schd_viol child
                          ON child.ics_final_order_viol_lnk_id = ics_final_order_viol_lnk.ics_final_order_viol_lnk_id
					   WHERE key_hash = @v_key_hash
                      UNION ALL
                      -- /ICS_FINAL_ORDER_VIOL_LNK/ICS_DSCH_MON_REP_PARAM_VIOL
                      SELECT key_hash
                           , child.data_hash
                        FROM ICS_FLOW_LOCAL.ics_final_order_viol_lnk
                        JOIN ICS_FLOW_LOCAL.ics_dsch_mon_rep_param_viol child
                          ON child.ics_final_order_viol_lnk_id = ics_final_order_viol_lnk.ics_final_order_viol_lnk_id
					   WHERE key_hash = @v_key_hash
                      UNION ALL
                      -- /ICS_FINAL_ORDER_VIOL_LNK/ICS_DSCH_MON_REP_VIOL
                      SELECT key_hash
                           , child.data_hash
                        FROM ICS_FLOW_LOCAL.ics_final_order_viol_lnk
                        JOIN ICS_FLOW_LOCAL.ics_dsch_mon_rep_viol child
                          ON child.ics_final_order_viol_lnk_id = ics_final_order_viol_lnk.ics_final_order_viol_lnk_id
					   WHERE key_hash = @v_key_hash
                      UNION ALL
                      -- /ICS_FINAL_ORDER_VIOL_LNK/ICS_PRMT_SCHD_VIOL
                      SELECT key_hash
                           , child.data_hash
                        FROM ICS_FLOW_LOCAL.ics_final_order_viol_lnk
                        JOIN ICS_FLOW_LOCAL.ics_prmt_schd_viol child
                          ON child.ics_final_order_viol_lnk_id = ics_final_order_viol_lnk.ics_final_order_viol_lnk_id
					   WHERE key_hash = @v_key_hash
                      UNION ALL
                      -- /ICS_FINAL_ORDER_VIOL_LNK/ICS_SNGL_EVTS_VIOL
                      SELECT key_hash
                           , child.data_hash
                        FROM ICS_FLOW_LOCAL.ics_final_order_viol_lnk
                        JOIN ICS_FLOW_LOCAL.ics_sngl_evts_viol child
                          ON child.ics_final_order_viol_lnk_id = ics_final_order_viol_lnk.ics_final_order_viol_lnk_id
							  
             ) here
             WHERE here.key_hash = @v_key_hash
             ORDER BY here.data_hash)

              SELECT @v_working_data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', COALESCE(@v_working_data_hash,'#') + data_hash)
                FROM tmp
               WHERE tmp.key_hash = @v_key_hash
               ORDER BY data_hash

              UPDATE ICS_FLOW_LOCAL.ICS_FINAL_ORDER_VIOL_LNK
                 SET data_hash = @v_working_data_hash
               WHERE key_hash = @v_key_hash
             END;
			 
			 

	  
		-- CollectionSystemPermitSubmission, not children
	  
		  
		-- FormalEnforcementActionSubmission

         IF @p_payload_type = 'ICS_FRML_ENFRC_ACTN' and @v_enabled = 'Y'
             BEGIN

             WITH tmp (key_hash, data_hash) AS
             ( SELECT TOP 100 PERCENT here.key_hash, here.data_hash
             FROM (			

				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_FRML_ENFRC_ACTN] 
				
				SELECT KEY_HASH, ICS_FRML_ENFRC_ACTN.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_FRML_ENFRC_ACTN] [ICS_FRML_ENFRC_ACTN] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_FRML_ENFRC_ACTN]/[ICS_FLOW_LOCAL].[ICS_PRMT_IDENT] 
				 UNION 
				SELECT KEY_HASH, I1.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_FRML_ENFRC_ACTN] [ICS_FRML_ENFRC_ACTN] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PRMT_IDENT] [I1]
 ON [I1].[ICS_FRML_ENFRC_ACTN_ID] = [ICS_FRML_ENFRC_ACTN].[ICS_FRML_ENFRC_ACTN_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_FRML_ENFRC_ACTN]/[ICS_FLOW_LOCAL].[ICS_ENFRC_ACTN_GOV_CONTACT] 
				 UNION 
				SELECT KEY_HASH, I2.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_FRML_ENFRC_ACTN] [ICS_FRML_ENFRC_ACTN] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ENFRC_ACTN_GOV_CONTACT] [I2]
 ON [I2].[ICS_FRML_ENFRC_ACTN_ID] = [ICS_FRML_ENFRC_ACTN].[ICS_FRML_ENFRC_ACTN_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_FRML_ENFRC_ACTN]/[ICS_FLOW_LOCAL].[ICS_ENFRC_ACTN_TYPE] 
				 UNION 
				SELECT KEY_HASH, I3.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_FRML_ENFRC_ACTN] [ICS_FRML_ENFRC_ACTN] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ENFRC_ACTN_TYPE] [I3]
 ON [I3].[ICS_FRML_ENFRC_ACTN_ID] = [ICS_FRML_ENFRC_ACTN].[ICS_FRML_ENFRC_ACTN_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_FRML_ENFRC_ACTN]/[ICS_FLOW_LOCAL].[ICS_ENFRC_AGNCY] 
				 UNION 
				SELECT KEY_HASH, I4.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_FRML_ENFRC_ACTN] [ICS_FRML_ENFRC_ACTN] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ENFRC_AGNCY] [I4]
 ON [I4].[ICS_FRML_ENFRC_ACTN_ID] = [ICS_FRML_ENFRC_ACTN].[ICS_FRML_ENFRC_ACTN_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_FRML_ENFRC_ACTN]/[ICS_FLOW_LOCAL].[ICS_PROGS_VIOL] 
				 UNION 
				SELECT KEY_HASH, I5.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_FRML_ENFRC_ACTN] [ICS_FRML_ENFRC_ACTN] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PROGS_VIOL] [I5]
 ON [I5].[ICS_FRML_ENFRC_ACTN_ID] = [ICS_FRML_ENFRC_ACTN].[ICS_FRML_ENFRC_ACTN_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_FRML_ENFRC_ACTN]/[ICS_FLOW_LOCAL].[ICS_FINAL_ORDER] 
				 UNION 
				SELECT KEY_HASH, I6.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_FRML_ENFRC_ACTN] [ICS_FRML_ENFRC_ACTN] 
 JOIN [ICS_FLOW_LOCAL].[ICS_FINAL_ORDER] [I6]
 ON [I6].[ICS_FRML_ENFRC_ACTN_ID] = [ICS_FRML_ENFRC_ACTN].[ICS_FRML_ENFRC_ACTN_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_FRML_ENFRC_ACTN]/[ICS_FLOW_LOCAL].[ICS_FINAL_ORDER]/[ICS_FLOW_LOCAL].[ICS_FINAL_ORDER_PRMT_IDENT] 
				 UNION 
				SELECT KEY_HASH, I7.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_FRML_ENFRC_ACTN] [ICS_FRML_ENFRC_ACTN] 
 JOIN [ICS_FLOW_LOCAL].[ICS_FINAL_ORDER] [I6]
 ON [I6].[ICS_FRML_ENFRC_ACTN_ID] = [ICS_FRML_ENFRC_ACTN].[ICS_FRML_ENFRC_ACTN_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_FINAL_ORDER_PRMT_IDENT] [I7]
 ON [I7].[ICS_FINAL_ORDER_ID] = [I6].[ICS_FINAL_ORDER_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_FRML_ENFRC_ACTN]/[ICS_FLOW_LOCAL].[ICS_FINAL_ORDER]/[ICS_FLOW_LOCAL].[ICS_SEP] 
				 UNION 
				SELECT KEY_HASH, I8.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_FRML_ENFRC_ACTN] [ICS_FRML_ENFRC_ACTN] 
 JOIN [ICS_FLOW_LOCAL].[ICS_FINAL_ORDER] [I6]
 ON [I6].[ICS_FRML_ENFRC_ACTN_ID] = [ICS_FRML_ENFRC_ACTN].[ICS_FRML_ENFRC_ACTN_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SEP] [I8]
 ON [I8].[ICS_FINAL_ORDER_ID] = [I6].[ICS_FINAL_ORDER_ID] 
    
				WHERE key_hash = @v_key_hash
							  
             ) here
             WHERE here.key_hash = @v_key_hash
             ORDER BY here.data_hash)

              SELECT @v_working_data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', COALESCE(@v_working_data_hash,'#') + data_hash)
                FROM tmp
               WHERE tmp.key_hash = @v_key_hash
               ORDER BY data_hash

              UPDATE ICS_FLOW_LOCAL.ICS_FRML_ENFRC_ACTN
                 SET data_hash = @v_working_data_hash
               WHERE key_hash = @v_key_hash
             END;
			 
			 

	  
		-- CollectionSystemPermitSubmission, not children
	  
		  
		-- GeneralPermitSubmission

         IF @p_payload_type = 'ICS_GNRL_PRMT' and @v_enabled = 'Y'
             BEGIN

             WITH tmp (key_hash, data_hash) AS
             ( SELECT TOP 100 PERCENT here.key_hash, here.data_hash
             FROM (			

				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_GNRL_PRMT] 
				
				SELECT KEY_HASH, ICS_GNRL_PRMT.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_GNRL_PRMT]/[ICS_FLOW_LOCAL].[ICS_NAICS_CODE] 
				 UNION 
				SELECT KEY_HASH, I1.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_NAICS_CODE] [I1]
 ON [I1].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_GNRL_PRMT]/[ICS_FLOW_LOCAL].[ICS_CONTACT] 
				 UNION 
				SELECT KEY_HASH, I2.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTACT] [I2]
 ON [I2].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_GNRL_PRMT]/[ICS_FLOW_LOCAL].[ICS_CONTACT]/[ICS_FLOW_LOCAL].[ICS_TELEPH] 
				 UNION 
				SELECT KEY_HASH, I3.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTACT] [I2]
 ON [I2].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_TELEPH] [I3]
 ON [I3].[ICS_CONTACT_ID] = [I2].[ICS_CONTACT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_GNRL_PRMT]/[ICS_FLOW_LOCAL].[ICS_NPDES_DAT_GRP_NUM] 
				 UNION 
				SELECT KEY_HASH, I4.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_NPDES_DAT_GRP_NUM] [I4]
 ON [I4].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_GNRL_PRMT]/[ICS_FLOW_LOCAL].[ICS_OTHR_PRMTS] 
				 UNION 
				SELECT KEY_HASH, I5.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_OTHR_PRMTS] [I5]
 ON [I5].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_GNRL_PRMT]/[ICS_FLOW_LOCAL].[ICS_EFFLU_GUIDE] 
				 UNION 
				SELECT KEY_HASH, I6.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_EFFLU_GUIDE] [I6]
 ON [I6].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_GNRL_PRMT]/[ICS_FLOW_LOCAL].[ICS_FAC] 
				 UNION 
				SELECT KEY_HASH, I7.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_FAC] [I7]
 ON [I7].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_GNRL_PRMT]/[ICS_FLOW_LOCAL].[ICS_FAC]/[ICS_FLOW_LOCAL].[ICS_CONTACT] 
				 UNION 
				SELECT KEY_HASH, I8.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_FAC] [I7]
 ON [I7].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTACT] [I8]
 ON [I8].[ICS_FAC_ID] = [I7].[ICS_FAC_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_GNRL_PRMT]/[ICS_FLOW_LOCAL].[ICS_FAC]/[ICS_FLOW_LOCAL].[ICS_CONTACT]/[ICS_FLOW_LOCAL].[ICS_TELEPH] 
				 UNION 
				SELECT KEY_HASH, I9.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_FAC] [I7]
 ON [I7].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTACT] [I8]
 ON [I8].[ICS_FAC_ID] = [I7].[ICS_FAC_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_TELEPH] [I9]
 ON [I9].[ICS_CONTACT_ID] = [I8].[ICS_CONTACT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_GNRL_PRMT]/[ICS_FLOW_LOCAL].[ICS_FAC]/[ICS_FLOW_LOCAL].[ICS_ORIG_PROGS] 
				 UNION 
				SELECT KEY_HASH, I10.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_FAC] [I7]
 ON [I7].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ORIG_PROGS] [I10]
 ON [I10].[ICS_FAC_ID] = [I7].[ICS_FAC_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_GNRL_PRMT]/[ICS_FLOW_LOCAL].[ICS_FAC]/[ICS_FLOW_LOCAL].[ICS_PLCY] 
				 UNION 
				SELECT KEY_HASH, I11.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_FAC] [I7]
 ON [I7].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PLCY] [I11]
 ON [I11].[ICS_FAC_ID] = [I7].[ICS_FAC_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_GNRL_PRMT]/[ICS_FLOW_LOCAL].[ICS_FAC]/[ICS_FLOW_LOCAL].[ICS_FAC_CLASS] 
				 UNION 
				SELECT KEY_HASH, I12.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_FAC] [I7]
 ON [I7].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_FAC_CLASS] [I12]
 ON [I12].[ICS_FAC_ID] = [I7].[ICS_FAC_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_GNRL_PRMT]/[ICS_FLOW_LOCAL].[ICS_FAC]/[ICS_FLOW_LOCAL].[ICS_GEO_COORD] 
				 UNION 
				SELECT KEY_HASH, I13.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_FAC] [I7]
 ON [I7].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_GEO_COORD] [I13]
 ON [I13].[ICS_FAC_ID] = [I7].[ICS_FAC_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_GNRL_PRMT]/[ICS_FLOW_LOCAL].[ICS_FAC]/[ICS_FLOW_LOCAL].[ICS_SIC_CODE] 
				 UNION 
				SELECT KEY_HASH, I14.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_FAC] [I7]
 ON [I7].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SIC_CODE] [I14]
 ON [I14].[ICS_FAC_ID] = [I7].[ICS_FAC_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_GNRL_PRMT]/[ICS_FLOW_LOCAL].[ICS_FAC]/[ICS_FLOW_LOCAL].[ICS_ADDR] 
				 UNION 
				SELECT KEY_HASH, I15.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_FAC] [I7]
 ON [I7].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ADDR] [I15]
 ON [I15].[ICS_FAC_ID] = [I7].[ICS_FAC_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_GNRL_PRMT]/[ICS_FLOW_LOCAL].[ICS_FAC]/[ICS_FLOW_LOCAL].[ICS_ADDR]/[ICS_FLOW_LOCAL].[ICS_TELEPH] 
				 UNION 
				SELECT KEY_HASH, I16.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_FAC] [I7]
 ON [I7].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ADDR] [I15]
 ON [I15].[ICS_FAC_ID] = [I7].[ICS_FAC_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_TELEPH] [I16]
 ON [I16].[ICS_ADDR_ID] = [I15].[ICS_ADDR_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_GNRL_PRMT]/[ICS_FLOW_LOCAL].[ICS_FAC]/[ICS_FLOW_LOCAL].[ICS_NAICS_CODE] 
				 UNION 
				SELECT KEY_HASH, I17.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_FAC] [I7]
 ON [I7].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_NAICS_CODE] [I17]
 ON [I17].[ICS_FAC_ID] = [I7].[ICS_FAC_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_GNRL_PRMT]/[ICS_FLOW_LOCAL].[ICS_REP_NON_CMPL_STAT] 
				 UNION 
				SELECT KEY_HASH, I18.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_REP_NON_CMPL_STAT] [I18]
 ON [I18].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_GNRL_PRMT]/[ICS_FLOW_LOCAL].[ICS_RESIDUAL_DESGN_DTRMN] 
				 UNION 
				SELECT KEY_HASH, I19.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_RESIDUAL_DESGN_DTRMN] [I19]
 ON [I19].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_GNRL_PRMT]/[ICS_FLOW_LOCAL].[ICS_SIC_CODE] 
				 UNION 
				SELECT KEY_HASH, I20.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SIC_CODE] [I20]
 ON [I20].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_GNRL_PRMT]/[ICS_FLOW_LOCAL].[ICS_ADDR] 
				 UNION 
				SELECT KEY_HASH, I21.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ADDR] [I21]
 ON [I21].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_GNRL_PRMT]/[ICS_FLOW_LOCAL].[ICS_ADDR]/[ICS_FLOW_LOCAL].[ICS_TELEPH] 
				 UNION 
				SELECT KEY_HASH, I22.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ADDR] [I21]
 ON [I21].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_TELEPH] [I22]
 ON [I22].[ICS_ADDR_ID] = [I21].[ICS_ADDR_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_GNRL_PRMT]/[ICS_FLOW_LOCAL].[ICS_ASSC_PRMT] 
				 UNION 
				SELECT KEY_HASH, I23.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ASSC_PRMT] [I23]
 ON [I23].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_GNRL_PRMT]/[ICS_FLOW_LOCAL].[ICS_CMPL_TRACK_STAT] 
				 UNION 
				SELECT KEY_HASH, I24.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CMPL_TRACK_STAT] [I24]
 ON [I24].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
    
				WHERE key_hash = @v_key_hash
							  
             ) here
             WHERE here.key_hash = @v_key_hash
             ORDER BY here.data_hash)

              SELECT @v_working_data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', COALESCE(@v_working_data_hash,'#') + data_hash)
                FROM tmp
               WHERE tmp.key_hash = @v_key_hash
               ORDER BY data_hash

              UPDATE ICS_FLOW_LOCAL.ICS_GNRL_PRMT
                 SET data_hash = @v_working_data_hash
               WHERE key_hash = @v_key_hash
             END;
			 
			 

	  
		-- CollectionSystemPermitSubmission, not children
	  
		  
		-- HistoricalPermitScheduleEventsSubmission

         IF @p_payload_type = 'ICS_HIST_PRMT_SCHD_EVTS' and @v_enabled = 'Y'
             BEGIN

             WITH tmp (key_hash, data_hash) AS
             ( SELECT TOP 100 PERCENT here.key_hash, here.data_hash
             FROM (			

				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_HIST_PRMT_SCHD_EVTS] 
				
				SELECT KEY_HASH, ICS_HIST_PRMT_SCHD_EVTS.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_HIST_PRMT_SCHD_EVTS] [ICS_HIST_PRMT_SCHD_EVTS] 
    
				WHERE key_hash = @v_key_hash
							  
             ) here
             WHERE here.key_hash = @v_key_hash
             ORDER BY here.data_hash)

              SELECT @v_working_data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', COALESCE(@v_working_data_hash,'#') + data_hash)
                FROM tmp
               WHERE tmp.key_hash = @v_key_hash
               ORDER BY data_hash

              UPDATE ICS_FLOW_LOCAL.ICS_HIST_PRMT_SCHD_EVTS
                 SET data_hash = @v_working_data_hash
               WHERE key_hash = @v_key_hash
             END;
			 
			 

	  
		-- CollectionSystemPermitSubmission, not children
	  
		  
		-- InformalEnforcementActionSubmission

         IF @p_payload_type = 'ICS_INFRML_ENFRC_ACTN' and @v_enabled = 'Y'
             BEGIN

             WITH tmp (key_hash, data_hash) AS
             ( SELECT TOP 100 PERCENT here.key_hash, here.data_hash
             FROM (			

				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_INFRML_ENFRC_ACTN] 
				
				SELECT KEY_HASH, ICS_INFRML_ENFRC_ACTN.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_INFRML_ENFRC_ACTN] [ICS_INFRML_ENFRC_ACTN] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_INFRML_ENFRC_ACTN]/[ICS_FLOW_LOCAL].[ICS_PRMT_IDENT] 
				 UNION 
				SELECT KEY_HASH, I1.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_INFRML_ENFRC_ACTN] [ICS_INFRML_ENFRC_ACTN] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PRMT_IDENT] [I1]
 ON [I1].[ICS_INFRML_ENFRC_ACTN_ID] = [ICS_INFRML_ENFRC_ACTN].[ICS_INFRML_ENFRC_ACTN_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_INFRML_ENFRC_ACTN]/[ICS_FLOW_LOCAL].[ICS_ENFRC_ACTN_GOV_CONTACT] 
				 UNION 
				SELECT KEY_HASH, I2.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_INFRML_ENFRC_ACTN] [ICS_INFRML_ENFRC_ACTN] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ENFRC_ACTN_GOV_CONTACT] [I2]
 ON [I2].[ICS_INFRML_ENFRC_ACTN_ID] = [ICS_INFRML_ENFRC_ACTN].[ICS_INFRML_ENFRC_ACTN_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_INFRML_ENFRC_ACTN]/[ICS_FLOW_LOCAL].[ICS_ENFRC_AGNCY] 
				 UNION 
				SELECT KEY_HASH, I3.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_INFRML_ENFRC_ACTN] [ICS_INFRML_ENFRC_ACTN] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ENFRC_AGNCY] [I3]
 ON [I3].[ICS_INFRML_ENFRC_ACTN_ID] = [ICS_INFRML_ENFRC_ACTN].[ICS_INFRML_ENFRC_ACTN_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_INFRML_ENFRC_ACTN]/[ICS_FLOW_LOCAL].[ICS_PROGS_VIOL] 
				 UNION 
				SELECT KEY_HASH, I4.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_INFRML_ENFRC_ACTN] [ICS_INFRML_ENFRC_ACTN] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PROGS_VIOL] [I4]
 ON [I4].[ICS_INFRML_ENFRC_ACTN_ID] = [ICS_INFRML_ENFRC_ACTN].[ICS_INFRML_ENFRC_ACTN_ID] 
    
				WHERE key_hash = @v_key_hash
							  
             ) here
             WHERE here.key_hash = @v_key_hash
             ORDER BY here.data_hash)

              SELECT @v_working_data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', COALESCE(@v_working_data_hash,'#') + data_hash)
                FROM tmp
               WHERE tmp.key_hash = @v_key_hash
               ORDER BY data_hash

              UPDATE ICS_FLOW_LOCAL.ICS_INFRML_ENFRC_ACTN
                 SET data_hash = @v_working_data_hash
               WHERE key_hash = @v_key_hash
             END;
			 
			 

	  
		-- CollectionSystemPermitSubmission, not children
	  
		  
		-- LimitsSubmission

         IF @p_payload_type = 'ICS_LMTS' and @v_enabled = 'Y'
             BEGIN

             WITH tmp (key_hash, data_hash) AS
             ( SELECT TOP 100 PERCENT here.key_hash, here.data_hash
             FROM (			

				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_LMTS] 
				
				SELECT KEY_HASH, ICS_LMTS.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_LMTS] [ICS_LMTS] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_LMTS]/[ICS_FLOW_LOCAL].[ICS_NUM_COND] 
				 UNION 
				SELECT KEY_HASH, I1.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_LMTS] [ICS_LMTS] 
 JOIN [ICS_FLOW_LOCAL].[ICS_NUM_COND] [I1]
 ON [I1].[ICS_LMTS_ID] = [ICS_LMTS].[ICS_LMTS_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_LMTS]/[ICS_FLOW_LOCAL].[ICS_MN_LMT_APPLIES] 
				 UNION 
				SELECT KEY_HASH, I2.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_LMTS] [ICS_LMTS] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MN_LMT_APPLIES] [I2]
 ON [I2].[ICS_LMTS_ID] = [ICS_LMTS].[ICS_LMTS_ID] 
    
				WHERE key_hash = @v_key_hash
							  
             ) here
             WHERE here.key_hash = @v_key_hash
             ORDER BY here.data_hash)

              SELECT @v_working_data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', COALESCE(@v_working_data_hash,'#') + data_hash)
                FROM tmp
               WHERE tmp.key_hash = @v_key_hash
               ORDER BY data_hash

              UPDATE ICS_FLOW_LOCAL.ICS_LMTS
                 SET data_hash = @v_working_data_hash
               WHERE key_hash = @v_key_hash
             END;
			 
			 

	  
		-- CollectionSystemPermitSubmission, not children
	  
		  
		-- LimitSetSubmission

         IF @p_payload_type = 'ICS_LMT_SET' and @v_enabled = 'Y'
             BEGIN

             WITH tmp (key_hash, data_hash) AS
             ( SELECT TOP 100 PERCENT here.key_hash, here.data_hash
             FROM (			

				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_LMT_SET] 
				
				SELECT KEY_HASH, ICS_LMT_SET.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_LMT_SET] [ICS_LMT_SET] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_LMT_SET]/[ICS_FLOW_LOCAL].[ICS_LMT_SET_MONTHS_APPL] 
				 UNION 
				SELECT KEY_HASH, I1.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_LMT_SET] [ICS_LMT_SET] 
 JOIN [ICS_FLOW_LOCAL].[ICS_LMT_SET_MONTHS_APPL] [I1]
 ON [I1].[ICS_LMT_SET_ID] = [ICS_LMT_SET].[ICS_LMT_SET_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_LMT_SET]/[ICS_FLOW_LOCAL].[ICS_LMT_SET_SCHD] 
				 UNION 
				SELECT KEY_HASH, I2.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_LMT_SET] [ICS_LMT_SET] 
 JOIN [ICS_FLOW_LOCAL].[ICS_LMT_SET_SCHD] [I2]
 ON [I2].[ICS_LMT_SET_ID] = [ICS_LMT_SET].[ICS_LMT_SET_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_LMT_SET]/[ICS_FLOW_LOCAL].[ICS_LMT_SET_STAT] 
				 UNION 
				SELECT KEY_HASH, I3.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_LMT_SET] [ICS_LMT_SET] 
 JOIN [ICS_FLOW_LOCAL].[ICS_LMT_SET_STAT] [I3]
 ON [I3].[ICS_LMT_SET_ID] = [ICS_LMT_SET].[ICS_LMT_SET_ID] 
    
				WHERE key_hash = @v_key_hash
							  
             ) here
             WHERE here.key_hash = @v_key_hash
             ORDER BY here.data_hash)

              SELECT @v_working_data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', COALESCE(@v_working_data_hash,'#') + data_hash)
                FROM tmp
               WHERE tmp.key_hash = @v_key_hash
               ORDER BY data_hash

              UPDATE ICS_FLOW_LOCAL.ICS_LMT_SET
                 SET data_hash = @v_working_data_hash
               WHERE key_hash = @v_key_hash
             END;
			 
			 

	  
		-- CollectionSystemPermitSubmission, not children
	  
		  
		-- MasterGeneralPermitSubmission

         IF @p_payload_type = 'ICS_MASTER_GNRL_PRMT' and @v_enabled = 'Y'
             BEGIN

             WITH tmp (key_hash, data_hash) AS
             ( SELECT TOP 100 PERCENT here.key_hash, here.data_hash
             FROM (			
                     -- /ICS_MASTER_GNRL_PRMT
                      SELECT key_hash
                           , child.data_hash
                        FROM ICS_FLOW_LOCAL.ics_master_gnrl_prmt child
					   WHERE key_hash = @v_key_hash
                      UNION ALL
                      -- /ICS_MASTER_GNRL_PRMT/ICS_ASSC_PRMT
                      SELECT key_hash
                           , child.data_hash
                        FROM ICS_FLOW_LOCAL.ics_master_gnrl_prmt
                        JOIN ICS_FLOW_LOCAL.ics_assc_prmt child
                          ON child.ics_master_gnrl_prmt_id = ics_master_gnrl_prmt.ics_master_gnrl_prmt_id
					   WHERE key_hash = @v_key_hash
                      UNION ALL
                      -- /ICS_MASTER_GNRL_PRMT/ICS_CONTACT
                      SELECT key_hash
                           , child.data_hash
                        FROM ICS_FLOW_LOCAL.ics_master_gnrl_prmt
                        JOIN ICS_FLOW_LOCAL.ics_contact child
                          ON child.ics_master_gnrl_prmt_id = ics_master_gnrl_prmt.ics_master_gnrl_prmt_id
					   WHERE key_hash = @v_key_hash
                      UNION ALL
                      -- /ICS_MASTER_GNRL_PRMT/ICS_CONTACT/ICS_TELEPH
                      SELECT key_hash
                           , child.data_hash
                        FROM ICS_FLOW_LOCAL.ics_master_gnrl_prmt
                        JOIN ICS_FLOW_LOCAL.ics_contact
                          ON ics_contact.ics_master_gnrl_prmt_id = ics_master_gnrl_prmt.ics_master_gnrl_prmt_id
                        JOIN ICS_FLOW_LOCAL.ics_teleph child
                          ON child.ics_contact_id = ics_contact.ics_contact_id
					   WHERE key_hash = @v_key_hash
                      UNION ALL
                      -- /ICS_MASTER_GNRL_PRMT/ICS_NAICS_CODE
                      SELECT key_hash
                           , child.data_hash
                        FROM ICS_FLOW_LOCAL.ics_master_gnrl_prmt
                        JOIN ICS_FLOW_LOCAL.ics_naics_code child
                          ON child.ics_master_gnrl_prmt_id = ics_master_gnrl_prmt.ics_master_gnrl_prmt_id
					   WHERE key_hash = @v_key_hash
                      UNION ALL
                      -- /ICS_MASTER_GNRL_PRMT/ICS_OTHR_PRMTS
                      SELECT key_hash
                           , child.data_hash
                        FROM ICS_FLOW_LOCAL.ics_master_gnrl_prmt
                        JOIN ICS_FLOW_LOCAL.ics_othr_prmts child
                          ON child.ics_master_gnrl_prmt_id = ics_master_gnrl_prmt.ics_master_gnrl_prmt_id
					   WHERE key_hash = @v_key_hash
                      UNION ALL
                      -- /ICS_MASTER_GNRL_PRMT/ICS_PRMT_COMP_TYPE
                      SELECT key_hash
                           , child.data_hash
                        FROM ICS_FLOW_LOCAL.ics_master_gnrl_prmt
                        JOIN ICS_FLOW_LOCAL.ics_prmt_comp_type child
                          ON child.ics_master_gnrl_prmt_id = ics_master_gnrl_prmt.ics_master_gnrl_prmt_id
					   WHERE key_hash = @v_key_hash
                      UNION ALL
                      -- /ICS_MASTER_GNRL_PRMT/ICS_SIC_CODE
                      SELECT key_hash
                           , child.data_hash
                        FROM ICS_FLOW_LOCAL.ics_master_gnrl_prmt
                        JOIN ICS_FLOW_LOCAL.ics_sic_code child
                          ON child.ics_master_gnrl_prmt_id = ics_master_gnrl_prmt.ics_master_gnrl_prmt_id
					   WHERE key_hash = @v_key_hash
							  
             ) here
             WHERE here.key_hash = @v_key_hash
             ORDER BY here.data_hash)

              SELECT @v_working_data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', COALESCE(@v_working_data_hash,'#') + data_hash)
                FROM tmp
               WHERE tmp.key_hash = @v_key_hash
               ORDER BY data_hash

              UPDATE ICS_FLOW_LOCAL.ICS_MASTER_GNRL_PRMT
                 SET data_hash = @v_working_data_hash
               WHERE key_hash = @v_key_hash
             END;
			 
			 

	  
		-- CollectionSystemPermitSubmission, not children
	  
		  
		-- NarrativeConditionScheduleSubmission

         IF @p_payload_type = 'ICS_NARR_COND_SCHD' and @v_enabled = 'Y'
             BEGIN

             WITH tmp (key_hash, data_hash) AS
             ( SELECT TOP 100 PERCENT here.key_hash, here.data_hash
             FROM (			

				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_NARR_COND_SCHD] 
				
				SELECT KEY_HASH, ICS_NARR_COND_SCHD.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_NARR_COND_SCHD] [ICS_NARR_COND_SCHD] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_NARR_COND_SCHD]/[ICS_FLOW_LOCAL].[ICS_PRMT_SCHD_EVT] 
				 UNION 
				SELECT KEY_HASH, I1.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_NARR_COND_SCHD] [ICS_NARR_COND_SCHD] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PRMT_SCHD_EVT] [I1]
 ON [I1].[ICS_NARR_COND_SCHD_ID] = [ICS_NARR_COND_SCHD].[ICS_NARR_COND_SCHD_ID] 
    
				WHERE key_hash = @v_key_hash
							  
             ) here
             WHERE here.key_hash = @v_key_hash
             ORDER BY here.data_hash)

              SELECT @v_working_data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', COALESCE(@v_working_data_hash,'#') + data_hash)
                FROM tmp
               WHERE tmp.key_hash = @v_key_hash
               ORDER BY data_hash

              UPDATE ICS_FLOW_LOCAL.ICS_NARR_COND_SCHD
                 SET data_hash = @v_working_data_hash
               WHERE key_hash = @v_key_hash
             END;
			 
			 

	  
		-- CollectionSystemPermitSubmission, not children
	  
		  
		-- NPDESVariancePermitSubmission

         IF @p_payload_type = 'ICS_NPDES_VARIANCE_PRMT' and @v_enabled = 'Y'
             BEGIN

             WITH tmp (key_hash, data_hash) AS
             ( SELECT TOP 100 PERCENT here.key_hash, here.data_hash
             FROM (			

				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_NPDES_VARIANCE_PRMT] 
				
				SELECT KEY_HASH, ICS_NPDES_VARIANCE_PRMT.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_NPDES_VARIANCE_PRMT] [ICS_NPDES_VARIANCE_PRMT] 
    
				WHERE key_hash = @v_key_hash
							  
             ) here
             WHERE here.key_hash = @v_key_hash
             ORDER BY here.data_hash)

              SELECT @v_working_data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', COALESCE(@v_working_data_hash,'#') + data_hash)
                FROM tmp
               WHERE tmp.key_hash = @v_key_hash
               ORDER BY data_hash

              UPDATE ICS_FLOW_LOCAL.ICS_NPDES_VARIANCE_PRMT
                 SET data_hash = @v_working_data_hash
               WHERE key_hash = @v_key_hash
             END;
			 
			 

	  
		-- CollectionSystemPermitSubmission, not children
	  
		  
		-- ParameterLimitsSubmission

         IF @p_payload_type = 'ICS_PARAM_LMTS' and @v_enabled = 'Y'
             BEGIN

             WITH tmp (key_hash, data_hash) AS
             ( SELECT TOP 100 PERCENT here.key_hash, here.data_hash
             FROM (			

				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_PARAM_LMTS] 
				
				SELECT KEY_HASH, ICS_PARAM_LMTS.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_PARAM_LMTS] [ICS_PARAM_LMTS] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_PARAM_LMTS]/[ICS_FLOW_LOCAL].[ICS_LMT] 
				 UNION 
				SELECT KEY_HASH, I1.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_PARAM_LMTS] [ICS_PARAM_LMTS] 
 JOIN [ICS_FLOW_LOCAL].[ICS_LMT] [I1]
 ON [I1].[ICS_PARAM_LMTS_ID] = [ICS_PARAM_LMTS].[ICS_PARAM_LMTS_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_PARAM_LMTS]/[ICS_FLOW_LOCAL].[ICS_LMT]/[ICS_FLOW_LOCAL].[ICS_NUM_COND] 
				 UNION 
				SELECT KEY_HASH, I2.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_PARAM_LMTS] [ICS_PARAM_LMTS] 
 JOIN [ICS_FLOW_LOCAL].[ICS_LMT] [I1]
 ON [I1].[ICS_PARAM_LMTS_ID] = [ICS_PARAM_LMTS].[ICS_PARAM_LMTS_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_NUM_COND] [I2]
 ON [I2].[ICS_LMT_ID] = [I1].[ICS_LMT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_PARAM_LMTS]/[ICS_FLOW_LOCAL].[ICS_LMT]/[ICS_FLOW_LOCAL].[ICS_MN_LMT_APPLIES] 
				 UNION 
				SELECT KEY_HASH, I3.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_PARAM_LMTS] [ICS_PARAM_LMTS] 
 JOIN [ICS_FLOW_LOCAL].[ICS_LMT] [I1]
 ON [I1].[ICS_PARAM_LMTS_ID] = [ICS_PARAM_LMTS].[ICS_PARAM_LMTS_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MN_LMT_APPLIES] [I3]
 ON [I3].[ICS_LMT_ID] = [I1].[ICS_LMT_ID] 
    
				WHERE key_hash = @v_key_hash
							  
             ) here
             WHERE here.key_hash = @v_key_hash
             ORDER BY here.data_hash)

              SELECT @v_working_data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', COALESCE(@v_working_data_hash,'#') + data_hash)
                FROM tmp
               WHERE tmp.key_hash = @v_key_hash
               ORDER BY data_hash

              UPDATE ICS_FLOW_LOCAL.ICS_PARAM_LMTS
                 SET data_hash = @v_working_data_hash
               WHERE key_hash = @v_key_hash
             END;
			 
			 

	  
		-- CollectionSystemPermitSubmission, not children
	  
		  
		-- PermitReissuanceSubmission

         IF @p_payload_type = 'ICS_PRMT_REISSU' and @v_enabled = 'Y'
             BEGIN

             WITH tmp (key_hash, data_hash) AS
             ( SELECT TOP 100 PERCENT here.key_hash, here.data_hash
             FROM (			

				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_PRMT_REISSU] 
				
				SELECT KEY_HASH, ICS_PRMT_REISSU.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_PRMT_REISSU] [ICS_PRMT_REISSU] 
    
				WHERE key_hash = @v_key_hash
							  
             ) here
             WHERE here.key_hash = @v_key_hash
             ORDER BY here.data_hash)

              SELECT @v_working_data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', COALESCE(@v_working_data_hash,'#') + data_hash)
                FROM tmp
               WHERE tmp.key_hash = @v_key_hash
               ORDER BY data_hash

              UPDATE ICS_FLOW_LOCAL.ICS_PRMT_REISSU
                 SET data_hash = @v_working_data_hash
               WHERE key_hash = @v_key_hash
             END;
			 
			 

	  
		-- CollectionSystemPermitSubmission, not children
	  
		  
		-- PermittedFeatureSubmission

         IF @p_payload_type = 'ICS_PRMT_FEATR' and @v_enabled = 'Y'
             BEGIN

             WITH tmp (key_hash, data_hash) AS
             ( SELECT TOP 100 PERCENT here.key_hash, here.data_hash
             FROM (			

				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_PRMT_FEATR] 
				
				SELECT KEY_HASH, ICS_PRMT_FEATR.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_PRMT_FEATR] [ICS_PRMT_FEATR] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_PRMT_FEATR]/[ICS_FLOW_LOCAL].[ICS_CONTACT] 
				 UNION 
				SELECT KEY_HASH, I1.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_PRMT_FEATR] [ICS_PRMT_FEATR] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTACT] [I1]
 ON [I1].[ICS_PRMT_FEATR_ID] = [ICS_PRMT_FEATR].[ICS_PRMT_FEATR_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_PRMT_FEATR]/[ICS_FLOW_LOCAL].[ICS_CONTACT]/[ICS_FLOW_LOCAL].[ICS_TELEPH] 
				 UNION 
				SELECT KEY_HASH, I2.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_PRMT_FEATR] [ICS_PRMT_FEATR] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTACT] [I1]
 ON [I1].[ICS_PRMT_FEATR_ID] = [ICS_PRMT_FEATR].[ICS_PRMT_FEATR_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_TELEPH] [I2]
 ON [I2].[ICS_CONTACT_ID] = [I1].[ICS_CONTACT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_PRMT_FEATR]/[ICS_FLOW_LOCAL].[ICS_COOLING_WTR_INTAKE_STRCT_INFO] 
				 UNION 
				SELECT KEY_HASH, I3.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_PRMT_FEATR] [ICS_PRMT_FEATR] 
 JOIN [ICS_FLOW_LOCAL].[ICS_COOLING_WTR_INTAKE_STRCT_INFO] [I3]
 ON [I3].[ICS_PRMT_FEATR_ID] = [ICS_PRMT_FEATR].[ICS_PRMT_FEATR_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_PRMT_FEATR]/[ICS_FLOW_LOCAL].[ICS_COOLING_WTR_INTAKE_STRCT_INFO]/[ICS_FLOW_LOCAL].[ICS_COOLING_WTR_INTAKE_STRCT_CMPL_METHOD] 
				 UNION 
				SELECT KEY_HASH, I4.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_PRMT_FEATR] [ICS_PRMT_FEATR] 
 JOIN [ICS_FLOW_LOCAL].[ICS_COOLING_WTR_INTAKE_STRCT_INFO] [I3]
 ON [I3].[ICS_PRMT_FEATR_ID] = [ICS_PRMT_FEATR].[ICS_PRMT_FEATR_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_COOLING_WTR_INTAKE_STRCT_CMPL_METHOD] [I4]
 ON [I4].[ICS_COOLING_WTR_INTAKE_STRCT_INFO_ID] = [I3].[ICS_COOLING_WTR_INTAKE_STRCT_INFO_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_PRMT_FEATR]/[ICS_FLOW_LOCAL].[ICS_POLUT_LIST] 
				 UNION 
				SELECT KEY_HASH, I5.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_PRMT_FEATR] [ICS_PRMT_FEATR] 
 JOIN [ICS_FLOW_LOCAL].[ICS_POLUT_LIST] [I5]
 ON [I5].[ICS_PRMT_FEATR_ID] = [ICS_PRMT_FEATR].[ICS_PRMT_FEATR_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_PRMT_FEATR]/[ICS_FLOW_LOCAL].[ICS_POLUT_LIST]/[ICS_FLOW_LOCAL].[ICS_IMPAIRED_WTR_POLLUTANTS] 
				 UNION 
				SELECT KEY_HASH, I6.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_PRMT_FEATR] [ICS_PRMT_FEATR] 
 JOIN [ICS_FLOW_LOCAL].[ICS_POLUT_LIST] [I5]
 ON [I5].[ICS_PRMT_FEATR_ID] = [ICS_PRMT_FEATR].[ICS_PRMT_FEATR_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_IMPAIRED_WTR_POLLUTANTS] [I6]
 ON [I6].[ICS_POLUT_LIST_ID] = [I5].[ICS_POLUT_LIST_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_PRMT_FEATR]/[ICS_FLOW_LOCAL].[ICS_POLUT_LIST]/[ICS_FLOW_LOCAL].[ICS_TMDL_POLLUTANTS] 
				 UNION 
				SELECT KEY_HASH, I7.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_PRMT_FEATR] [ICS_PRMT_FEATR] 
 JOIN [ICS_FLOW_LOCAL].[ICS_POLUT_LIST] [I5]
 ON [I5].[ICS_PRMT_FEATR_ID] = [ICS_PRMT_FEATR].[ICS_PRMT_FEATR_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_TMDL_POLLUTANTS] [I7]
 ON [I7].[ICS_POLUT_LIST_ID] = [I5].[ICS_POLUT_LIST_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_PRMT_FEATR]/[ICS_FLOW_LOCAL].[ICS_POLUT_LIST]/[ICS_FLOW_LOCAL].[ICS_TMDL_POLLUTANTS]/[ICS_FLOW_LOCAL].[ICS_TMDL_POLUT] 
				 UNION 
				SELECT KEY_HASH, I8.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_PRMT_FEATR] [ICS_PRMT_FEATR] 
 JOIN [ICS_FLOW_LOCAL].[ICS_POLUT_LIST] [I5]
 ON [I5].[ICS_PRMT_FEATR_ID] = [ICS_PRMT_FEATR].[ICS_PRMT_FEATR_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_TMDL_POLLUTANTS] [I7]
 ON [I7].[ICS_POLUT_LIST_ID] = [I5].[ICS_POLUT_LIST_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_TMDL_POLUT] [I8]
 ON [I8].[ICS_TMDL_POLLUTANTS_ID] = [I7].[ICS_TMDL_POLLUTANTS_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_PRMT_FEATR]/[ICS_FLOW_LOCAL].[ICS_PRMT_FEATR_CHAR] 
				 UNION 
				SELECT KEY_HASH, I9.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_PRMT_FEATR] [ICS_PRMT_FEATR] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PRMT_FEATR_CHAR] [I9]
 ON [I9].[ICS_PRMT_FEATR_ID] = [ICS_PRMT_FEATR].[ICS_PRMT_FEATR_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_PRMT_FEATR]/[ICS_FLOW_LOCAL].[ICS_PRMT_FEATR_TRTMNT_TYPE] 
				 UNION 
				SELECT KEY_HASH, I10.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_PRMT_FEATR] [ICS_PRMT_FEATR] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PRMT_FEATR_TRTMNT_TYPE] [I10]
 ON [I10].[ICS_PRMT_FEATR_ID] = [ICS_PRMT_FEATR].[ICS_PRMT_FEATR_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_PRMT_FEATR]/[ICS_FLOW_LOCAL].[ICS_GEO_COORD] 
				 UNION 
				SELECT KEY_HASH, I11.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_PRMT_FEATR] [ICS_PRMT_FEATR] 
 JOIN [ICS_FLOW_LOCAL].[ICS_GEO_COORD] [I11]
 ON [I11].[ICS_PRMT_FEATR_ID] = [ICS_PRMT_FEATR].[ICS_PRMT_FEATR_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_PRMT_FEATR]/[ICS_FLOW_LOCAL].[ICS_ADDR] 
				 UNION 
				SELECT KEY_HASH, I12.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_PRMT_FEATR] [ICS_PRMT_FEATR] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ADDR] [I12]
 ON [I12].[ICS_PRMT_FEATR_ID] = [ICS_PRMT_FEATR].[ICS_PRMT_FEATR_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_PRMT_FEATR]/[ICS_FLOW_LOCAL].[ICS_ADDR]/[ICS_FLOW_LOCAL].[ICS_TELEPH] 
				 UNION 
				SELECT KEY_HASH, I13.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_PRMT_FEATR] [ICS_PRMT_FEATR] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ADDR] [I12]
 ON [I12].[ICS_PRMT_FEATR_ID] = [ICS_PRMT_FEATR].[ICS_PRMT_FEATR_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_TELEPH] [I13]
 ON [I13].[ICS_ADDR_ID] = [I12].[ICS_ADDR_ID] 
    
				WHERE key_hash = @v_key_hash
							  
             ) here
             WHERE here.key_hash = @v_key_hash
             ORDER BY here.data_hash)

              SELECT @v_working_data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', COALESCE(@v_working_data_hash,'#') + data_hash)
                FROM tmp
               WHERE tmp.key_hash = @v_key_hash
               ORDER BY data_hash

              UPDATE ICS_FLOW_LOCAL.ICS_PRMT_FEATR
                 SET data_hash = @v_working_data_hash
               WHERE key_hash = @v_key_hash
             END;
			 
			 

	  
		-- CollectionSystemPermitSubmission, not children
	  
		  
		-- PermitTerminationSubmission

         IF @p_payload_type = 'ICS_PRMT_TERM' and @v_enabled = 'Y'
             BEGIN

             WITH tmp (key_hash, data_hash) AS
             ( SELECT TOP 100 PERCENT here.key_hash, here.data_hash
             FROM (			

				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_PRMT_TERM] 
				
				SELECT KEY_HASH, ICS_PRMT_TERM.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_PRMT_TERM] [ICS_PRMT_TERM] 
    
				WHERE key_hash = @v_key_hash
							  
             ) here
             WHERE here.key_hash = @v_key_hash
             ORDER BY here.data_hash)

              SELECT @v_working_data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', COALESCE(@v_working_data_hash,'#') + data_hash)
                FROM tmp
               WHERE tmp.key_hash = @v_key_hash
               ORDER BY data_hash

              UPDATE ICS_FLOW_LOCAL.ICS_PRMT_TERM
                 SET data_hash = @v_working_data_hash
               WHERE key_hash = @v_key_hash
             END;
			 
			 

	  
		-- CollectionSystemPermitSubmission, not children
	  
		  
		-- PermitTrackingEventSubmission

         IF @p_payload_type = 'ICS_PRMT_TRACK_EVT' and @v_enabled = 'Y'
             BEGIN

             WITH tmp (key_hash, data_hash) AS
             ( SELECT TOP 100 PERCENT here.key_hash, here.data_hash
             FROM (			

				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_PRMT_TRACK_EVT] 
				
				SELECT KEY_HASH, ICS_PRMT_TRACK_EVT.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_PRMT_TRACK_EVT] [ICS_PRMT_TRACK_EVT] 
    
				WHERE key_hash = @v_key_hash
							  
             ) here
             WHERE here.key_hash = @v_key_hash
             ORDER BY here.data_hash)

              SELECT @v_working_data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', COALESCE(@v_working_data_hash,'#') + data_hash)
                FROM tmp
               WHERE tmp.key_hash = @v_key_hash
               ORDER BY data_hash

              UPDATE ICS_FLOW_LOCAL.ICS_PRMT_TRACK_EVT
                 SET data_hash = @v_working_data_hash
               WHERE key_hash = @v_key_hash
             END;
			 
			 

	  
		-- CollectionSystemPermitSubmission, not children
	  
		  
		-- POTWPermitSubmission

         IF @p_payload_type = 'ICS_POTW_PRMT' and @v_enabled = 'Y'
             BEGIN

             WITH tmp (key_hash, data_hash) AS
             ( SELECT TOP 100 PERCENT here.key_hash, here.data_hash
             FROM (			

				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_POTW_PRMT] 
				
				SELECT KEY_HASH, ICS_POTW_PRMT.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_POTW_PRMT] [ICS_POTW_PRMT] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_POTW_PRMT]/[ICS_FLOW_LOCAL].[ICS_SATL_COLL_SYSTM] 
				 UNION 
				SELECT KEY_HASH, I1.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_POTW_PRMT] [ICS_POTW_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SATL_COLL_SYSTM] [I1]
 ON [I1].[ICS_POTW_PRMT_ID] = [ICS_POTW_PRMT].[ICS_POTW_PRMT_ID] 
    
				WHERE key_hash = @v_key_hash
							  
             ) here
             WHERE here.key_hash = @v_key_hash
             ORDER BY here.data_hash)

              SELECT @v_working_data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', COALESCE(@v_working_data_hash,'#') + data_hash)
                FROM tmp
               WHERE tmp.key_hash = @v_key_hash
               ORDER BY data_hash

              UPDATE ICS_FLOW_LOCAL.ICS_POTW_PRMT
                 SET data_hash = @v_working_data_hash
               WHERE key_hash = @v_key_hash
             END;
			 
			 

	  
		-- CollectionSystemPermitSubmission, not children
	  
		  
		-- POTWTreatmentTechnologyPermitSubmission

         IF @p_payload_type = 'ICS_POTW_TRTMNT_TECHNOLOGY_PRMT' and @v_enabled = 'Y'
             BEGIN

             WITH tmp (key_hash, data_hash) AS
             ( SELECT TOP 100 PERCENT here.key_hash, here.data_hash
             FROM (			

				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_POTW_TRTMNT_TECHNOLOGY_PRMT] 
				
				SELECT KEY_HASH, ICS_POTW_TRTMNT_TECHNOLOGY_PRMT.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_POTW_TRTMNT_TECHNOLOGY_PRMT] [ICS_POTW_TRTMNT_TECHNOLOGY_PRMT] 
    
				WHERE key_hash = @v_key_hash
							  
             ) here
             WHERE here.key_hash = @v_key_hash
             ORDER BY here.data_hash)

              SELECT @v_working_data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', COALESCE(@v_working_data_hash,'#') + data_hash)
                FROM tmp
               WHERE tmp.key_hash = @v_key_hash
               ORDER BY data_hash

              UPDATE ICS_FLOW_LOCAL.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT
                 SET data_hash = @v_working_data_hash
               WHERE key_hash = @v_key_hash
             END;
			 
			 

	  
		-- CollectionSystemPermitSubmission, not children
	  
		  
		-- PretreatmentPermitSubmission

         IF @p_payload_type = 'ICS_PRETR_PRMT' and @v_enabled = 'Y'
             BEGIN

             WITH tmp (key_hash, data_hash) AS
             ( SELECT TOP 100 PERCENT here.key_hash, here.data_hash
             FROM (			

				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_PRETR_PRMT] 
				
				SELECT KEY_HASH, ICS_PRETR_PRMT.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_PRETR_PRMT] [ICS_PRETR_PRMT] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_PRETR_PRMT]/[ICS_FLOW_LOCAL].[ICS_CONTACT] 
				 UNION 
				SELECT KEY_HASH, I1.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_PRETR_PRMT] [ICS_PRETR_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTACT] [I1]
 ON [I1].[ICS_PRETR_PRMT_ID] = [ICS_PRETR_PRMT].[ICS_PRETR_PRMT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_PRETR_PRMT]/[ICS_FLOW_LOCAL].[ICS_CONTACT]/[ICS_FLOW_LOCAL].[ICS_TELEPH] 
				 UNION 
				SELECT KEY_HASH, I2.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_PRETR_PRMT] [ICS_PRETR_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTACT] [I1]
 ON [I1].[ICS_PRETR_PRMT_ID] = [ICS_PRETR_PRMT].[ICS_PRETR_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_TELEPH] [I2]
 ON [I2].[ICS_CONTACT_ID] = [I1].[ICS_CONTACT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_PRETR_PRMT]/[ICS_FLOW_LOCAL].[ICS_PRETR_PROG_MOD] 
				 UNION 
				SELECT KEY_HASH, I3.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_PRETR_PRMT] [ICS_PRETR_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PRETR_PROG_MOD] [I3]
 ON [I3].[ICS_PRETR_PRMT_ID] = [ICS_PRETR_PRMT].[ICS_PRETR_PRMT_ID] 
    
				WHERE key_hash = @v_key_hash
							  
             ) here
             WHERE here.key_hash = @v_key_hash
             ORDER BY here.data_hash)

              SELECT @v_working_data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', COALESCE(@v_working_data_hash,'#') + data_hash)
                FROM tmp
               WHERE tmp.key_hash = @v_key_hash
               ORDER BY data_hash

              UPDATE ICS_FLOW_LOCAL.ICS_PRETR_PRMT
                 SET data_hash = @v_working_data_hash
               WHERE key_hash = @v_key_hash
             END;
			 
			 

	  
		-- CollectionSystemPermitSubmission, not children
	  
		  
		-- PretreatmentProgramReportSubmission

         IF @p_payload_type = 'ICS_PRETR_PROG_REP' and @v_enabled = 'Y'
             BEGIN

             WITH tmp (key_hash, data_hash) AS
             ( SELECT TOP 100 PERCENT here.key_hash, here.data_hash
             FROM (			

				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_PRETR_PROG_REP] 
				
				SELECT KEY_HASH, ICS_PRETR_PROG_REP.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_PRETR_PROG_REP] [ICS_PRETR_PROG_REP] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_PRETR_PROG_REP]/[ICS_FLOW_LOCAL].[ICS_CONTROL_AUTH_PROG_INFO] 
				 UNION 
				SELECT KEY_HASH, I1.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_PRETR_PROG_REP] [ICS_PRETR_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTROL_AUTH_PROG_INFO] [I1]
 ON [I1].[ICS_PRETR_PROG_REP_ID] = [ICS_PRETR_PROG_REP].[ICS_PRETR_PROG_REP_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_PRETR_PROG_REP]/[ICS_FLOW_LOCAL].[ICS_CONTROL_AUTH_PROG_INFO]/[ICS_FLOW_LOCAL].[ICS_LOC_LMTS_PARAMETERS] 
				 UNION 
				SELECT KEY_HASH, I2.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_PRETR_PROG_REP] [ICS_PRETR_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTROL_AUTH_PROG_INFO] [I1]
 ON [I1].[ICS_PRETR_PROG_REP_ID] = [ICS_PRETR_PROG_REP].[ICS_PRETR_PROG_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_LOC_LMTS_PARAMETERS] [I2]
 ON [I2].[ICS_CONTROL_AUTH_PROG_INFO_ID] = [I1].[ICS_CONTROL_AUTH_PROG_INFO_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_PRETR_PROG_REP]/[ICS_FLOW_LOCAL].[ICS_INDST_USR_INVENTORY] 
				 UNION 
				SELECT KEY_HASH, I3.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_PRETR_PROG_REP] [ICS_PRETR_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_INDST_USR_INVENTORY] [I3]
 ON [I3].[ICS_PRETR_PROG_REP_ID] = [ICS_PRETR_PROG_REP].[ICS_PRETR_PROG_REP_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_PRETR_PROG_REP]/[ICS_FLOW_LOCAL].[ICS_INDST_USR_INVENTORY]/[ICS_FLOW_LOCAL].[ICS_INDST_USR_INFO] 
				 UNION 
				SELECT KEY_HASH, I4.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_PRETR_PROG_REP] [ICS_PRETR_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_INDST_USR_INVENTORY] [I3]
 ON [I3].[ICS_PRETR_PROG_REP_ID] = [ICS_PRETR_PROG_REP].[ICS_PRETR_PROG_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_INDST_USR_INFO] [I4]
 ON [I4].[ICS_INDST_USR_INVENTORY_ID] = [I3].[ICS_INDST_USR_INVENTORY_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_PRETR_PROG_REP]/[ICS_FLOW_LOCAL].[ICS_INDST_USR_INVENTORY]/[ICS_FLOW_LOCAL].[ICS_INDST_USR_INFO]/[ICS_FLOW_LOCAL].[ICS_IU_ENFRC_ACTN_INFO] 
				 UNION 
				SELECT KEY_HASH, I5.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_PRETR_PROG_REP] [ICS_PRETR_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_INDST_USR_INVENTORY] [I3]
 ON [I3].[ICS_PRETR_PROG_REP_ID] = [ICS_PRETR_PROG_REP].[ICS_PRETR_PROG_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_INDST_USR_INFO] [I4]
 ON [I4].[ICS_INDST_USR_INVENTORY_ID] = [I3].[ICS_INDST_USR_INVENTORY_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_IU_ENFRC_ACTN_INFO] [I5]
 ON [I5].[ICS_INDST_USR_INFO_ID] = [I4].[ICS_INDST_USR_INFO_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_PRETR_PROG_REP]/[ICS_FLOW_LOCAL].[ICS_INDST_USR_INVENTORY]/[ICS_FLOW_LOCAL].[ICS_INDST_USR_INFO]/[ICS_FLOW_LOCAL].[ICS_IU_ENFRC_ACTN_INFO]/[ICS_FLOW_LOCAL].[ICS_IU_ENF_ACTN_TYPES] 
				 UNION 
				SELECT KEY_HASH, I6.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_PRETR_PROG_REP] [ICS_PRETR_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_INDST_USR_INVENTORY] [I3]
 ON [I3].[ICS_PRETR_PROG_REP_ID] = [ICS_PRETR_PROG_REP].[ICS_PRETR_PROG_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_INDST_USR_INFO] [I4]
 ON [I4].[ICS_INDST_USR_INVENTORY_ID] = [I3].[ICS_INDST_USR_INVENTORY_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_IU_ENFRC_ACTN_INFO] [I5]
 ON [I5].[ICS_INDST_USR_INFO_ID] = [I4].[ICS_INDST_USR_INFO_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_IU_ENF_ACTN_TYPES] [I6]
 ON [I6].[ICS_IU_ENFRC_ACTN_INFO_ID] = [I5].[ICS_IU_ENFRC_ACTN_INFO_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_PRETR_PROG_REP]/[ICS_FLOW_LOCAL].[ICS_INDST_USR_INVENTORY]/[ICS_FLOW_LOCAL].[ICS_INDST_USR_INFO]/[ICS_FLOW_LOCAL].[ICS_IU_VIOL_INFO] 
				 UNION 
				SELECT KEY_HASH, I7.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_PRETR_PROG_REP] [ICS_PRETR_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_INDST_USR_INVENTORY] [I3]
 ON [I3].[ICS_PRETR_PROG_REP_ID] = [ICS_PRETR_PROG_REP].[ICS_PRETR_PROG_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_INDST_USR_INFO] [I4]
 ON [I4].[ICS_INDST_USR_INVENTORY_ID] = [I3].[ICS_INDST_USR_INVENTORY_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_IU_VIOL_INFO] [I7]
 ON [I7].[ICS_INDST_USR_INFO_ID] = [I4].[ICS_INDST_USR_INFO_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_PRETR_PROG_REP]/[ICS_FLOW_LOCAL].[ICS_INDST_USR_INVENTORY]/[ICS_FLOW_LOCAL].[ICS_INDST_USR_INFO]/[ICS_FLOW_LOCAL].[ICS_IU_VIOL_INFO]/[ICS_FLOW_LOCAL].[ICS_SNC_LISTING_MONTHS] 
				 UNION 
				SELECT KEY_HASH, I8.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_PRETR_PROG_REP] [ICS_PRETR_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_INDST_USR_INVENTORY] [I3]
 ON [I3].[ICS_PRETR_PROG_REP_ID] = [ICS_PRETR_PROG_REP].[ICS_PRETR_PROG_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_INDST_USR_INFO] [I4]
 ON [I4].[ICS_INDST_USR_INVENTORY_ID] = [I3].[ICS_INDST_USR_INVENTORY_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_IU_VIOL_INFO] [I7]
 ON [I7].[ICS_INDST_USR_INFO_ID] = [I4].[ICS_INDST_USR_INFO_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SNC_LISTING_MONTHS] [I8]
 ON [I8].[ICS_IU_VIOL_INFO_ID] = [I7].[ICS_IU_VIOL_INFO_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_PRETR_PROG_REP]/[ICS_FLOW_LOCAL].[ICS_INDST_USR_INVENTORY]/[ICS_FLOW_LOCAL].[ICS_INDST_USR_INFO]/[ICS_FLOW_LOCAL].[ICS_IU_VIOL_INFO]/[ICS_FLOW_LOCAL].[ICS_SNC_PRETR_STND_LMTS_PARAMETERS] 
				 UNION 
				SELECT KEY_HASH, I9.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_PRETR_PROG_REP] [ICS_PRETR_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_INDST_USR_INVENTORY] [I3]
 ON [I3].[ICS_PRETR_PROG_REP_ID] = [ICS_PRETR_PROG_REP].[ICS_PRETR_PROG_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_INDST_USR_INFO] [I4]
 ON [I4].[ICS_INDST_USR_INVENTORY_ID] = [I3].[ICS_INDST_USR_INVENTORY_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_IU_VIOL_INFO] [I7]
 ON [I7].[ICS_INDST_USR_INFO_ID] = [I4].[ICS_INDST_USR_INFO_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SNC_PRETR_STND_LMTS_PARAMETERS] [I9]
 ON [I9].[ICS_IU_VIOL_INFO_ID] = [I7].[ICS_IU_VIOL_INFO_ID] 
    
				WHERE key_hash = @v_key_hash
							  
             ) here
             WHERE here.key_hash = @v_key_hash
             ORDER BY here.data_hash)

              SELECT @v_working_data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', COALESCE(@v_working_data_hash,'#') + data_hash)
                FROM tmp
               WHERE tmp.key_hash = @v_key_hash
               ORDER BY data_hash

              UPDATE ICS_FLOW_LOCAL.ICS_PRETR_PROG_REP
                 SET data_hash = @v_working_data_hash
               WHERE key_hash = @v_key_hash
             END;
			 
			 

	  
		-- CollectionSystemPermitSubmission, not children
	  
		  
		-- ScheduleEventViolationSubmission

         IF @p_payload_type = 'ICS_SCHD_EVT_VIOL' and @v_enabled = 'Y'
             BEGIN

             WITH tmp (key_hash, data_hash) AS
             ( SELECT TOP 100 PERCENT here.key_hash, here.data_hash
             FROM (			
                      -- /ICS_SCHD_EVT_VIOL
                      SELECT key_hash
                           , child.data_hash
                        FROM ICS_FLOW_LOCAL.ics_schd_evt_viol child
					   WHERE key_hash = @v_key_hash
                      UNION ALL
                      -- /ICS_SCHD_EVT_VIOL/ICS_CMPL_SCHD_EVT_VIOL_ELEM
                      SELECT key_hash
                           , child.data_hash
                        FROM ICS_FLOW_LOCAL.ics_schd_evt_viol
                        JOIN ICS_FLOW_LOCAL.ics_cmpl_schd_evt_viol_elem child
                          ON child.ics_schd_evt_viol_id = ics_schd_evt_viol.ics_schd_evt_viol_id
					   WHERE key_hash = @v_key_hash
                      UNION ALL
                      -- /ICS_SCHD_EVT_VIOL/ICS_PRMT_SCHD_EVT_VIOL_ELEM
                      SELECT key_hash
                           , child.data_hash
                        FROM ICS_FLOW_LOCAL.ics_schd_evt_viol
                        JOIN ICS_FLOW_LOCAL.ics_prmt_schd_evt_viol_elem child
                          ON child.ics_schd_evt_viol_id = ics_schd_evt_viol.ics_schd_evt_viol_id
					   WHERE key_hash = @v_key_hash
							  
             ) here
             WHERE here.key_hash = @v_key_hash
             ORDER BY here.data_hash)

              SELECT @v_working_data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', COALESCE(@v_working_data_hash,'#') + data_hash)
                FROM tmp
               WHERE tmp.key_hash = @v_key_hash
               ORDER BY data_hash

              UPDATE ICS_FLOW_LOCAL.ICS_SCHD_EVT_VIOL
                 SET data_hash = @v_working_data_hash
               WHERE key_hash = @v_key_hash
             END;
			 
			 

	  
		-- CollectionSystemPermitSubmission, not children
	  
		  
		-- SewerOverflowBypassEventReportSubmission

         IF @p_payload_type = 'ICS_SEWER_OVRFLW_BYPASS_EVT_REP' and @v_enabled = 'Y'
             BEGIN

             WITH tmp (key_hash, data_hash) AS
             ( SELECT TOP 100 PERCENT here.key_hash, here.data_hash
             FROM (			

				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP] 
				
				SELECT KEY_HASH, ICS_SEWER_OVRFLW_BYPASS_EVT_REP.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP] [ICS_SEWER_OVRFLW_BYPASS_EVT_REP] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP]/[ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT] 
				 UNION 
				SELECT KEY_HASH, I1.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP] [ICS_SEWER_OVRFLW_BYPASS_EVT_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT] [I1]
 ON [I1].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] = [ICS_SEWER_OVRFLW_BYPASS_EVT_REP].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP]/[ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT]/[ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_CAUSE] 
				 UNION 
				SELECT KEY_HASH, I2.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP] [ICS_SEWER_OVRFLW_BYPASS_EVT_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT] [I1]
 ON [I1].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] = [ICS_SEWER_OVRFLW_BYPASS_EVT_REP].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_CAUSE] [I2]
 ON [I2].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] = [I1].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP]/[ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT]/[ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_CORR_ACTN] 
				 UNION 
				SELECT KEY_HASH, I3.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP] [ICS_SEWER_OVRFLW_BYPASS_EVT_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT] [I1]
 ON [I1].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] = [ICS_SEWER_OVRFLW_BYPASS_EVT_REP].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_CORR_ACTN] [I3]
 ON [I3].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] = [I1].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP]/[ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT]/[ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_IMPACT] 
				 UNION 
				SELECT KEY_HASH, I4.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP] [ICS_SEWER_OVRFLW_BYPASS_EVT_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT] [I1]
 ON [I1].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] = [ICS_SEWER_OVRFLW_BYPASS_EVT_REP].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_IMPACT] [I4]
 ON [I4].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] = [I1].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP]/[ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT]/[ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_RCVG_WTR] 
				 UNION 
				SELECT KEY_HASH, I5.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP] [ICS_SEWER_OVRFLW_BYPASS_EVT_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT] [I1]
 ON [I1].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] = [ICS_SEWER_OVRFLW_BYPASS_EVT_REP].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_RCVG_WTR] [I5]
 ON [I5].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] = [I1].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP]/[ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT]/[ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_TYPE] 
				 UNION 
				SELECT KEY_HASH, I6.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP] [ICS_SEWER_OVRFLW_BYPASS_EVT_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT] [I1]
 ON [I1].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] = [ICS_SEWER_OVRFLW_BYPASS_EVT_REP].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_TYPE] [I6]
 ON [I6].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] = [I1].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP]/[ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT]/[ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_TRTMNT] 
				 UNION 
				SELECT KEY_HASH, I7.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP] [ICS_SEWER_OVRFLW_BYPASS_EVT_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT] [I1]
 ON [I1].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] = [ICS_SEWER_OVRFLW_BYPASS_EVT_REP].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_TRTMNT] [I7]
 ON [I7].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] = [I1].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP]/[ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT]/[ICS_FLOW_LOCAL].[ICS_BYPASS_TRTMNT_PLANT_EQUIPMENT] 
				 UNION 
				SELECT KEY_HASH, I8.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP] [ICS_SEWER_OVRFLW_BYPASS_EVT_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT] [I1]
 ON [I1].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] = [ICS_SEWER_OVRFLW_BYPASS_EVT_REP].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_BYPASS_TRTMNT_PLANT_EQUIPMENT] [I8]
 ON [I8].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] = [I1].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] 
    
				WHERE key_hash = @v_key_hash
							  
             ) here
             WHERE here.key_hash = @v_key_hash
             ORDER BY here.data_hash)

              SELECT @v_working_data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', COALESCE(@v_working_data_hash,'#') + data_hash)
                FROM tmp
               WHERE tmp.key_hash = @v_key_hash
               ORDER BY data_hash

              UPDATE ICS_FLOW_LOCAL.ICS_SEWER_OVRFLW_BYPASS_EVT_REP
                 SET data_hash = @v_working_data_hash
               WHERE key_hash = @v_key_hash
             END;
			 
			 

	  
		-- CollectionSystemPermitSubmission, not children
	  
		  
		-- SingleEventViolationSubmission

         IF @p_payload_type = 'ICS_SNGL_EVT_VIOL' and @v_enabled = 'Y'
             BEGIN

             WITH tmp (key_hash, data_hash) AS
             ( SELECT TOP 100 PERCENT here.key_hash, here.data_hash
             FROM (			

				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SNGL_EVT_VIOL] 
				
				SELECT KEY_HASH, ICS_SNGL_EVT_VIOL.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SNGL_EVT_VIOL] [ICS_SNGL_EVT_VIOL] 
    
				WHERE key_hash = @v_key_hash
							  
             ) here
             WHERE here.key_hash = @v_key_hash
             ORDER BY here.data_hash)

              SELECT @v_working_data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', COALESCE(@v_working_data_hash,'#') + data_hash)
                FROM tmp
               WHERE tmp.key_hash = @v_key_hash
               ORDER BY data_hash

              UPDATE ICS_FLOW_LOCAL.ICS_SNGL_EVT_VIOL
                 SET data_hash = @v_working_data_hash
               WHERE key_hash = @v_key_hash
             END;
			 
			 

	  
		-- CollectionSystemPermitSubmission, not children
	  
		  
		-- SWConstructionPermitSubmission

         IF @p_payload_type = 'ICS_SW_CNST_PRMT' and @v_enabled = 'Y'
             BEGIN

             WITH tmp (key_hash, data_hash) AS
             ( SELECT TOP 100 PERCENT here.key_hash, here.data_hash
             FROM (			

				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SW_CNST_PRMT] 
				
				SELECT KEY_HASH, ICS_SW_CNST_PRMT.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SW_CNST_PRMT] [ICS_SW_CNST_PRMT] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SW_CNST_PRMT]/[ICS_FLOW_LOCAL].[ICS_CONTACT] 
				 UNION 
				SELECT KEY_HASH, I1.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SW_CNST_PRMT] [ICS_SW_CNST_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTACT] [I1]
 ON [I1].[ICS_SW_CNST_PRMT_ID] = [ICS_SW_CNST_PRMT].[ICS_SW_CNST_PRMT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SW_CNST_PRMT]/[ICS_FLOW_LOCAL].[ICS_CONTACT]/[ICS_FLOW_LOCAL].[ICS_TELEPH] 
				 UNION 
				SELECT KEY_HASH, I2.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SW_CNST_PRMT] [ICS_SW_CNST_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTACT] [I1]
 ON [I1].[ICS_SW_CNST_PRMT_ID] = [ICS_SW_CNST_PRMT].[ICS_SW_CNST_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_TELEPH] [I2]
 ON [I2].[ICS_CONTACT_ID] = [I1].[ICS_CONTACT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SW_CNST_PRMT]/[ICS_FLOW_LOCAL].[ICS_PROPOSED_CNST_SW_BM_PS] 
				 UNION 
				SELECT KEY_HASH, I3.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SW_CNST_PRMT] [ICS_SW_CNST_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PROPOSED_CNST_SW_BM_PS] [I3]
 ON [I3].[ICS_SW_CNST_PRMT_ID] = [ICS_SW_CNST_PRMT].[ICS_SW_CNST_PRMT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SW_CNST_PRMT]/[ICS_FLOW_LOCAL].[ICS_PROPOSED_POST_CNST_SW_BM_PS] 
				 UNION 
				SELECT KEY_HASH, I4.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SW_CNST_PRMT] [ICS_SW_CNST_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PROPOSED_POST_CNST_SW_BM_PS] [I4]
 ON [I4].[ICS_SW_CNST_PRMT_ID] = [ICS_SW_CNST_PRMT].[ICS_SW_CNST_PRMT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SW_CNST_PRMT]/[ICS_FLOW_LOCAL].[ICS_GPCF_NOTICE_OF_INTENT] 
				 UNION 
				SELECT KEY_HASH, I5.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SW_CNST_PRMT] [ICS_SW_CNST_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_GPCF_NOTICE_OF_INTENT] [I5]
 ON [I5].[ICS_SW_CNST_PRMT_ID] = [ICS_SW_CNST_PRMT].[ICS_SW_CNST_PRMT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SW_CNST_PRMT]/[ICS_FLOW_LOCAL].[ICS_GPCF_NOTICE_OF_INTENT]/[ICS_FLOW_LOCAL].[ICS_SUBSECTOR_CODE_PLUS_DESC] 
				 UNION 
				SELECT KEY_HASH, I6.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SW_CNST_PRMT] [ICS_SW_CNST_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_GPCF_NOTICE_OF_INTENT] [I5]
 ON [I5].[ICS_SW_CNST_PRMT_ID] = [ICS_SW_CNST_PRMT].[ICS_SW_CNST_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SUBSECTOR_CODE_PLUS_DESC] [I6]
 ON [I6].[ICS_GPCF_NOTICE_OF_INTENT_ID] = [I5].[ICS_GPCF_NOTICE_OF_INTENT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SW_CNST_PRMT]/[ICS_FLOW_LOCAL].[ICS_ADDR] 
				 UNION 
				SELECT KEY_HASH, I7.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SW_CNST_PRMT] [ICS_SW_CNST_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ADDR] [I7]
 ON [I7].[ICS_SW_CNST_PRMT_ID] = [ICS_SW_CNST_PRMT].[ICS_SW_CNST_PRMT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SW_CNST_PRMT]/[ICS_FLOW_LOCAL].[ICS_ADDR]/[ICS_FLOW_LOCAL].[ICS_TELEPH] 
				 UNION 
				SELECT KEY_HASH, I8.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SW_CNST_PRMT] [ICS_SW_CNST_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ADDR] [I7]
 ON [I7].[ICS_SW_CNST_PRMT_ID] = [ICS_SW_CNST_PRMT].[ICS_SW_CNST_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_TELEPH] [I8]
 ON [I8].[ICS_ADDR_ID] = [I7].[ICS_ADDR_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SW_CNST_PRMT]/[ICS_FLOW_LOCAL].[ICS_TRTMNT_CHEMS_LIST] 
				 UNION 
				SELECT KEY_HASH, I9.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SW_CNST_PRMT] [ICS_SW_CNST_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_TRTMNT_CHEMS_LIST] [I9]
 ON [I9].[ICS_SW_CNST_PRMT_ID] = [ICS_SW_CNST_PRMT].[ICS_SW_CNST_PRMT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SW_CNST_PRMT]/[ICS_FLOW_LOCAL].[ICS_CNST_SITE_LIST] 
				 UNION 
				SELECT KEY_HASH, I10.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SW_CNST_PRMT] [ICS_SW_CNST_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CNST_SITE_LIST] [I10]
 ON [I10].[ICS_SW_CNST_PRMT_ID] = [ICS_SW_CNST_PRMT].[ICS_SW_CNST_PRMT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SW_CNST_PRMT]/[ICS_FLOW_LOCAL].[ICS_CNST_SITE_LIST]/[ICS_FLOW_LOCAL].[ICS_CNST_SITE] 
				 UNION 
				SELECT KEY_HASH, I11.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SW_CNST_PRMT] [ICS_SW_CNST_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CNST_SITE_LIST] [I10]
 ON [I10].[ICS_SW_CNST_PRMT_ID] = [ICS_SW_CNST_PRMT].[ICS_SW_CNST_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CNST_SITE] [I11]
 ON [I11].[ICS_CNST_SITE_LIST_ID] = [I10].[ICS_CNST_SITE_LIST_ID] 
    
				WHERE key_hash = @v_key_hash
							  
             ) here
             WHERE here.key_hash = @v_key_hash
             ORDER BY here.data_hash)

              SELECT @v_working_data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', COALESCE(@v_working_data_hash,'#') + data_hash)
                FROM tmp
               WHERE tmp.key_hash = @v_key_hash
               ORDER BY data_hash

              UPDATE ICS_FLOW_LOCAL.ICS_SW_CNST_PRMT
                 SET data_hash = @v_working_data_hash
               WHERE key_hash = @v_key_hash
             END;
			 
			 

	  
		-- CollectionSystemPermitSubmission, not children
	  
		  
		-- SWIndustrialAnnualReportSubmission

         IF @p_payload_type = 'ICS_SW_INDST_ANNUL_REP' and @v_enabled = 'Y'
             BEGIN

             WITH tmp (key_hash, data_hash) AS
             ( SELECT TOP 100 PERCENT here.key_hash, here.data_hash
             FROM (			

				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SW_INDST_ANNUL_REP] 
				
				SELECT KEY_HASH, ICS_SW_INDST_ANNUL_REP.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SW_INDST_ANNUL_REP] [ICS_SW_INDST_ANNUL_REP] 
    
				WHERE key_hash = @v_key_hash
							  
             ) here
             WHERE here.key_hash = @v_key_hash
             ORDER BY here.data_hash)

              SELECT @v_working_data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', COALESCE(@v_working_data_hash,'#') + data_hash)
                FROM tmp
               WHERE tmp.key_hash = @v_key_hash
               ORDER BY data_hash

              UPDATE ICS_FLOW_LOCAL.ICS_SW_INDST_ANNUL_REP
                 SET data_hash = @v_working_data_hash
               WHERE key_hash = @v_key_hash
             END;
			 
			 

	  
		-- CollectionSystemPermitSubmission, not children
	  
		  
		-- SWIndustrialPermitSubmission

         IF @p_payload_type = 'ICS_SW_INDST_PRMT' and @v_enabled = 'Y'
             BEGIN

             WITH tmp (key_hash, data_hash) AS
             ( SELECT TOP 100 PERCENT here.key_hash, here.data_hash
             FROM (			

				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SW_INDST_PRMT] 
				
				SELECT KEY_HASH, ICS_SW_INDST_PRMT.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SW_INDST_PRMT] [ICS_SW_INDST_PRMT] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SW_INDST_PRMT]/[ICS_FLOW_LOCAL].[ICS_CONTACT] 
				 UNION 
				SELECT KEY_HASH, I1.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SW_INDST_PRMT] [ICS_SW_INDST_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTACT] [I1]
 ON [I1].[ICS_SW_INDST_PRMT_ID] = [ICS_SW_INDST_PRMT].[ICS_SW_INDST_PRMT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SW_INDST_PRMT]/[ICS_FLOW_LOCAL].[ICS_CONTACT]/[ICS_FLOW_LOCAL].[ICS_TELEPH] 
				 UNION 
				SELECT KEY_HASH, I2.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SW_INDST_PRMT] [ICS_SW_INDST_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTACT] [I1]
 ON [I1].[ICS_SW_INDST_PRMT_ID] = [ICS_SW_INDST_PRMT].[ICS_SW_INDST_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_TELEPH] [I2]
 ON [I2].[ICS_CONTACT_ID] = [I1].[ICS_CONTACT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SW_INDST_PRMT]/[ICS_FLOW_LOCAL].[ICS_PROPOSED_INDST_SW_BM_PS] 
				 UNION 
				SELECT KEY_HASH, I3.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SW_INDST_PRMT] [ICS_SW_INDST_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PROPOSED_INDST_SW_BM_PS] [I3]
 ON [I3].[ICS_SW_INDST_PRMT_ID] = [ICS_SW_INDST_PRMT].[ICS_SW_INDST_PRMT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SW_INDST_PRMT]/[ICS_FLOW_LOCAL].[ICS_GPCF_NO_EXPOSURE] 
				 UNION 
				SELECT KEY_HASH, I4.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SW_INDST_PRMT] [ICS_SW_INDST_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_GPCF_NO_EXPOSURE] [I4]
 ON [I4].[ICS_SW_INDST_PRMT_ID] = [ICS_SW_INDST_PRMT].[ICS_SW_INDST_PRMT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SW_INDST_PRMT]/[ICS_FLOW_LOCAL].[ICS_GPCF_NOTICE_OF_INTENT] 
				 UNION 
				SELECT KEY_HASH, I5.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SW_INDST_PRMT] [ICS_SW_INDST_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_GPCF_NOTICE_OF_INTENT] [I5]
 ON [I5].[ICS_SW_INDST_PRMT_ID] = [ICS_SW_INDST_PRMT].[ICS_SW_INDST_PRMT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SW_INDST_PRMT]/[ICS_FLOW_LOCAL].[ICS_GPCF_NOTICE_OF_INTENT]/[ICS_FLOW_LOCAL].[ICS_SUBSECTOR_CODE_PLUS_DESC] 
				 UNION 
				SELECT KEY_HASH, I6.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SW_INDST_PRMT] [ICS_SW_INDST_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_GPCF_NOTICE_OF_INTENT] [I5]
 ON [I5].[ICS_SW_INDST_PRMT_ID] = [ICS_SW_INDST_PRMT].[ICS_SW_INDST_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SUBSECTOR_CODE_PLUS_DESC] [I6]
 ON [I6].[ICS_GPCF_NOTICE_OF_INTENT_ID] = [I5].[ICS_GPCF_NOTICE_OF_INTENT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SW_INDST_PRMT]/[ICS_FLOW_LOCAL].[ICS_GPCF_NOTICE_OF_TERM] 
				 UNION 
				SELECT KEY_HASH, I7.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SW_INDST_PRMT] [ICS_SW_INDST_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_GPCF_NOTICE_OF_TERM] [I7]
 ON [I7].[ICS_SW_INDST_PRMT_ID] = [ICS_SW_INDST_PRMT].[ICS_SW_INDST_PRMT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SW_INDST_PRMT]/[ICS_FLOW_LOCAL].[ICS_ADDR] 
				 UNION 
				SELECT KEY_HASH, I8.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SW_INDST_PRMT] [ICS_SW_INDST_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ADDR] [I8]
 ON [I8].[ICS_SW_INDST_PRMT_ID] = [ICS_SW_INDST_PRMT].[ICS_SW_INDST_PRMT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SW_INDST_PRMT]/[ICS_FLOW_LOCAL].[ICS_ADDR]/[ICS_FLOW_LOCAL].[ICS_TELEPH] 
				 UNION 
				SELECT KEY_HASH, I9.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SW_INDST_PRMT] [ICS_SW_INDST_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ADDR] [I8]
 ON [I8].[ICS_SW_INDST_PRMT_ID] = [ICS_SW_INDST_PRMT].[ICS_SW_INDST_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_TELEPH] [I9]
 ON [I9].[ICS_ADDR_ID] = [I8].[ICS_ADDR_ID] 
    
				WHERE key_hash = @v_key_hash
							  
             ) here
             WHERE here.key_hash = @v_key_hash
             ORDER BY here.data_hash)

              SELECT @v_working_data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', COALESCE(@v_working_data_hash,'#') + data_hash)
                FROM tmp
               WHERE tmp.key_hash = @v_key_hash
               ORDER BY data_hash

              UPDATE ICS_FLOW_LOCAL.ICS_SW_INDST_PRMT
                 SET data_hash = @v_working_data_hash
               WHERE key_hash = @v_key_hash
             END;
			 
			 

	  
		-- CollectionSystemPermitSubmission, not children
	  
		  
		-- SWMS4AnnualProgramReportSubmission

         IF @p_payload_type = 'ICS_SWMS_4_ANNUL_PROG_REP' and @v_enabled = 'Y'
             BEGIN

             WITH tmp (key_hash, data_hash) AS
             ( SELECT TOP 100 PERCENT here.key_hash, here.data_hash
             FROM (			

				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SWMS_4_ANNUL_PROG_REP] 
				
				SELECT KEY_HASH, ICS_SWMS_4_ANNUL_PROG_REP.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SWMS_4_ANNUL_PROG_REP] [ICS_SWMS_4_ANNUL_PROG_REP] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SWMS_4_ANNUL_PROG_REP]/[ICS_FLOW_LOCAL].[ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO_PROG_REP] 
				 UNION 
				SELECT KEY_HASH, I1.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SWMS_4_ANNUL_PROG_REP] [ICS_SWMS_4_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO_PROG_REP] [I1]
 ON [I1].[ICS_SWMS_4_ANNUL_PROG_REP_ID] = [ICS_SWMS_4_ANNUL_PROG_REP].[ICS_SWMS_4_ANNUL_PROG_REP_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SWMS_4_ANNUL_PROG_REP]/[ICS_FLOW_LOCAL].[ICS_MS_4_PROG_REP_ANALYSIS] 
				 UNION 
				SELECT KEY_HASH, I2.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SWMS_4_ANNUL_PROG_REP] [ICS_SWMS_4_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_PROG_REP_ANALYSIS] [I2]
 ON [I2].[ICS_SWMS_4_ANNUL_PROG_REP_ID] = [ICS_SWMS_4_ANNUL_PROG_REP].[ICS_SWMS_4_ANNUL_PROG_REP_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SWMS_4_ANNUL_PROG_REP]/[ICS_FLOW_LOCAL].[ICS_MS_4_PROG_REP_ANALYSIS]/[ICS_FLOW_LOCAL].[ICS_MS_4_REGULATED_ENTITY_IDENT] 
				 UNION 
				SELECT KEY_HASH, I3.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SWMS_4_ANNUL_PROG_REP] [ICS_SWMS_4_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_PROG_REP_ANALYSIS] [I2]
 ON [I2].[ICS_SWMS_4_ANNUL_PROG_REP_ID] = [ICS_SWMS_4_ANNUL_PROG_REP].[ICS_SWMS_4_ANNUL_PROG_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_REGULATED_ENTITY_IDENT] [I3]
 ON [I3].[ICS_MS_4_PROG_REP_ANALYSIS_ID] = [I2].[ICS_MS_4_PROG_REP_ANALYSIS_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SWMS_4_ANNUL_PROG_REP]/[ICS_FLOW_LOCAL].[ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY] 
				 UNION 
				SELECT KEY_HASH, I4.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SWMS_4_ANNUL_PROG_REP] [ICS_SWMS_4_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY] [I4]
 ON [I4].[ICS_SWMS_4_ANNUL_PROG_REP_ID] = [ICS_SWMS_4_ANNUL_PROG_REP].[ICS_SWMS_4_ANNUL_PROG_REP_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SWMS_4_ANNUL_PROG_REP]/[ICS_FLOW_LOCAL].[ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY]/[ICS_FLOW_LOCAL].[ICS_MS_4_REGULATED_ENTITY_IDENT] 
				 UNION 
				SELECT KEY_HASH, I5.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SWMS_4_ANNUL_PROG_REP] [ICS_SWMS_4_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY] [I4]
 ON [I4].[ICS_SWMS_4_ANNUL_PROG_REP_ID] = [ICS_SWMS_4_ANNUL_PROG_REP].[ICS_SWMS_4_ANNUL_PROG_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_REGULATED_ENTITY_IDENT] [I5]
 ON [I5].[ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY_ID] = [I4].[ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SWMS_4_ANNUL_PROG_REP]/[ICS_FLOW_LOCAL].[ICS_MS_4_REGULATED_ENTITY_ENFRC] 
				 UNION 
				SELECT KEY_HASH, I6.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SWMS_4_ANNUL_PROG_REP] [ICS_SWMS_4_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_REGULATED_ENTITY_ENFRC] [I6]
 ON [I6].[ICS_SWMS_4_ANNUL_PROG_REP_ID] = [ICS_SWMS_4_ANNUL_PROG_REP].[ICS_SWMS_4_ANNUL_PROG_REP_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SWMS_4_ANNUL_PROG_REP]/[ICS_FLOW_LOCAL].[ICS_MS_4_REGULATED_ENTITY_ENFRC]/[ICS_FLOW_LOCAL].[ICS_MS_4_REGULATED_ENTITY_ENFRC_ACTIONS] 
				 UNION 
				SELECT KEY_HASH, I7.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SWMS_4_ANNUL_PROG_REP] [ICS_SWMS_4_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_REGULATED_ENTITY_ENFRC] [I6]
 ON [I6].[ICS_SWMS_4_ANNUL_PROG_REP_ID] = [ICS_SWMS_4_ANNUL_PROG_REP].[ICS_SWMS_4_ANNUL_PROG_REP_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_REGULATED_ENTITY_ENFRC_ACTIONS] [I7]
 ON [I7].[ICS_MS_4_REGULATED_ENTITY_ENFRC_ID] = [I6].[ICS_MS_4_REGULATED_ENTITY_ENFRC_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SWMS_4_ANNUL_PROG_REP]/[ICS_FLOW_LOCAL].[ICS_MS_4_SWMP_CHANGES] 
				 UNION 
				SELECT KEY_HASH, I8.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SWMS_4_ANNUL_PROG_REP] [ICS_SWMS_4_ANNUL_PROG_REP] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_SWMP_CHANGES] [I8]
 ON [I8].[ICS_SWMS_4_ANNUL_PROG_REP_ID] = [ICS_SWMS_4_ANNUL_PROG_REP].[ICS_SWMS_4_ANNUL_PROG_REP_ID] 
    
				WHERE key_hash = @v_key_hash
							  
             ) here
             WHERE here.key_hash = @v_key_hash
             ORDER BY here.data_hash)

              SELECT @v_working_data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', COALESCE(@v_working_data_hash,'#') + data_hash)
                FROM tmp
               WHERE tmp.key_hash = @v_key_hash
               ORDER BY data_hash

              UPDATE ICS_FLOW_LOCAL.ICS_SWMS_4_ANNUL_PROG_REP
                 SET data_hash = @v_working_data_hash
               WHERE key_hash = @v_key_hash
             END;
			 
			 

	  
		-- CollectionSystemPermitSubmission, not children
	  
		  
		-- SWMS4PermitSubmission

         IF @p_payload_type = 'ICS_SWMS_4_PRMT' and @v_enabled = 'Y'
             BEGIN

             WITH tmp (key_hash, data_hash) AS
             ( SELECT TOP 100 PERCENT here.key_hash, here.data_hash
             FROM (			

				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT] 
				
				SELECT KEY_HASH, ICS_SWMS_4_PRMT.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT]/[ICS_FLOW_LOCAL].[ICS_MS_4_CNST_SW_REQS] 
				 UNION 
				SELECT KEY_HASH, I1.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_CNST_SW_REQS] [I1]
 ON [I1].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT]/[ICS_FLOW_LOCAL].[ICS_MS_4_CNST_SW_REQS]/[ICS_FLOW_LOCAL].[ICS_MS_4_CNST_SW_PROCEDURES] 
				 UNION 
				SELECT KEY_HASH, I2.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_CNST_SW_REQS] [I1]
 ON [I1].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_CNST_SW_PROCEDURES] [I2]
 ON [I2].[ICS_MS_4_CNST_SW_REQS_ID] = [I1].[ICS_MS_4_CNST_SW_REQS_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT]/[ICS_FLOW_LOCAL].[ICS_MS_4_CNST_SW_REQS]/[ICS_FLOW_LOCAL].[ICS_MS_4_CNST_SW_PROCEDURES]/[ICS_FLOW_LOCAL].[ICS_MS_4_REGULATED_ENTITY_IDENT] 
				 UNION 
				SELECT KEY_HASH, I3.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_CNST_SW_REQS] [I1]
 ON [I1].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_CNST_SW_PROCEDURES] [I2]
 ON [I2].[ICS_MS_4_CNST_SW_REQS_ID] = [I1].[ICS_MS_4_CNST_SW_REQS_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_REGULATED_ENTITY_IDENT] [I3]
 ON [I3].[ICS_MS_4_CNST_SW_PROCEDURES_ID] = [I2].[ICS_MS_4_CNST_SW_PROCEDURES_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT]/[ICS_FLOW_LOCAL].[ICS_MS_4_CNST_SW_REQS]/[ICS_FLOW_LOCAL].[ICS_MS_4_CNST_SW_REGULATED_ENTITY_INFO] 
				 UNION 
				SELECT KEY_HASH, I4.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_CNST_SW_REQS] [I1]
 ON [I1].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_CNST_SW_REGULATED_ENTITY_INFO] [I4]
 ON [I4].[ICS_MS_4_CNST_SW_REQS_ID] = [I1].[ICS_MS_4_CNST_SW_REQS_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT]/[ICS_FLOW_LOCAL].[ICS_MS_4_ILLICIT_DETECT_REQS] 
				 UNION 
				SELECT KEY_HASH, I5.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_ILLICIT_DETECT_REQS] [I5]
 ON [I5].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT]/[ICS_FLOW_LOCAL].[ICS_MS_4_ILLICIT_DETECT_REQS]/[ICS_FLOW_LOCAL].[ICS_MS_4_ILLICIT_DETECT_PROCEDURES] 
				 UNION 
				SELECT KEY_HASH, I6.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_ILLICIT_DETECT_REQS] [I5]
 ON [I5].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_ILLICIT_DETECT_PROCEDURES] [I6]
 ON [I6].[ICS_MS_4_ILLICIT_DETECT_REQS_ID] = [I5].[ICS_MS_4_ILLICIT_DETECT_REQS_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT]/[ICS_FLOW_LOCAL].[ICS_MS_4_ILLICIT_DETECT_REQS]/[ICS_FLOW_LOCAL].[ICS_MS_4_ILLICIT_DETECT_PROCEDURES]/[ICS_FLOW_LOCAL].[ICS_MS_4_REGULATED_ENTITY_IDENT] 
				 UNION 
				SELECT KEY_HASH, I7.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_ILLICIT_DETECT_REQS] [I5]
 ON [I5].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_ILLICIT_DETECT_PROCEDURES] [I6]
 ON [I6].[ICS_MS_4_ILLICIT_DETECT_REQS_ID] = [I5].[ICS_MS_4_ILLICIT_DETECT_REQS_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_REGULATED_ENTITY_IDENT] [I7]
 ON [I7].[ICS_MS_4_ILLICIT_DETECT_PROCEDURES_ID] = [I6].[ICS_MS_4_ILLICIT_DETECT_PROCEDURES_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT]/[ICS_FLOW_LOCAL].[ICS_MS_4_ILLICIT_DETECT_REQS]/[ICS_FLOW_LOCAL].[ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO] 
				 UNION 
				SELECT KEY_HASH, I8.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_ILLICIT_DETECT_REQS] [I5]
 ON [I5].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO] [I8]
 ON [I8].[ICS_MS_4_ILLICIT_DETECT_REQS_ID] = [I5].[ICS_MS_4_ILLICIT_DETECT_REQS_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT]/[ICS_FLOW_LOCAL].[ICS_MS_4_INDST_SW_REQS] 
				 UNION 
				SELECT KEY_HASH, I9.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_INDST_SW_REQS] [I9]
 ON [I9].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT]/[ICS_FLOW_LOCAL].[ICS_MS_4_INDST_SW_REQS]/[ICS_FLOW_LOCAL].[ICS_MS_4_INDST_SW_PROCEDURES] 
				 UNION 
				SELECT KEY_HASH, I10.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_INDST_SW_REQS] [I9]
 ON [I9].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_INDST_SW_PROCEDURES] [I10]
 ON [I10].[ICS_MS_4_INDST_SW_REQS_ID] = [I9].[ICS_MS_4_INDST_SW_REQS_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT]/[ICS_FLOW_LOCAL].[ICS_MS_4_INDST_SW_REQS]/[ICS_FLOW_LOCAL].[ICS_MS_4_INDST_SW_PROCEDURES]/[ICS_FLOW_LOCAL].[ICS_MS_4_REGULATED_ENTITY_IDENT] 
				 UNION 
				SELECT KEY_HASH, I11.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_INDST_SW_REQS] [I9]
 ON [I9].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_INDST_SW_PROCEDURES] [I10]
 ON [I10].[ICS_MS_4_INDST_SW_REQS_ID] = [I9].[ICS_MS_4_INDST_SW_REQS_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_REGULATED_ENTITY_IDENT] [I11]
 ON [I11].[ICS_MS_4_INDST_SW_PROCEDURES_ID] = [I10].[ICS_MS_4_INDST_SW_PROCEDURES_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT]/[ICS_FLOW_LOCAL].[ICS_MS_4_INDST_SW_REQS]/[ICS_FLOW_LOCAL].[ICS_MS_4_INDST_SW_REGULATED_ENTITY_INFO] 
				 UNION 
				SELECT KEY_HASH, I12.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_INDST_SW_REQS] [I9]
 ON [I9].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_INDST_SW_REGULATED_ENTITY_INFO] [I12]
 ON [I12].[ICS_MS_4_INDST_SW_REQS_ID] = [I9].[ICS_MS_4_INDST_SW_REQS_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT]/[ICS_FLOW_LOCAL].[ICS_MS_4_OTHR_APPL_REQS] 
				 UNION 
				SELECT KEY_HASH, I13.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_OTHR_APPL_REQS] [I13]
 ON [I13].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT]/[ICS_FLOW_LOCAL].[ICS_MS_4_OTHR_APPL_REQS]/[ICS_FLOW_LOCAL].[ICS_MS_4_REGULATED_ENTITY_IDENT] 
				 UNION 
				SELECT KEY_HASH, I14.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_OTHR_APPL_REQS] [I13]
 ON [I13].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_REGULATED_ENTITY_IDENT] [I14]
 ON [I14].[ICS_MS_4_OTHR_APPL_REQS_ID] = [I13].[ICS_MS_4_OTHR_APPL_REQS_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT]/[ICS_FLOW_LOCAL].[ICS_MS_4_PBLC_EDUCATION_REQS] 
				 UNION 
				SELECT KEY_HASH, I15.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_PBLC_EDUCATION_REQS] [I15]
 ON [I15].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT]/[ICS_FLOW_LOCAL].[ICS_MS_4_PBLC_EDUCATION_REQS]/[ICS_FLOW_LOCAL].[ICS_MS_4_REGULATED_ENTITY_IDENT] 
				 UNION 
				SELECT KEY_HASH, I16.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_PBLC_EDUCATION_REQS] [I15]
 ON [I15].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_REGULATED_ENTITY_IDENT] [I16]
 ON [I16].[ICS_MS_4_PBLC_EDUCATION_REQS_ID] = [I15].[ICS_MS_4_PBLC_EDUCATION_REQS_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT]/[ICS_FLOW_LOCAL].[ICS_MS_4_PBLC_INVOLVEMENT_REQS] 
				 UNION 
				SELECT KEY_HASH, I17.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_PBLC_INVOLVEMENT_REQS] [I17]
 ON [I17].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT]/[ICS_FLOW_LOCAL].[ICS_MS_4_PBLC_INVOLVEMENT_REQS]/[ICS_FLOW_LOCAL].[ICS_MS_4_REGULATED_ENTITY_IDENT] 
				 UNION 
				SELECT KEY_HASH, I18.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_PBLC_INVOLVEMENT_REQS] [I17]
 ON [I17].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_REGULATED_ENTITY_IDENT] [I18]
 ON [I18].[ICS_MS_4_PBLC_INVOLVEMENT_REQS_ID] = [I17].[ICS_MS_4_PBLC_INVOLVEMENT_REQS_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT]/[ICS_FLOW_LOCAL].[ICS_MS_4_POLLUTION_PREVENTION_REQS] 
				 UNION 
				SELECT KEY_HASH, I19.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_POLLUTION_PREVENTION_REQS] [I19]
 ON [I19].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT]/[ICS_FLOW_LOCAL].[ICS_MS_4_POLLUTION_PREVENTION_REQS]/[ICS_FLOW_LOCAL].[ICS_MS_4_REGULATED_ENTITY_IDENT] 
				 UNION 
				SELECT KEY_HASH, I20.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_POLLUTION_PREVENTION_REQS] [I19]
 ON [I19].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_REGULATED_ENTITY_IDENT] [I20]
 ON [I20].[ICS_MS_4_POLLUTION_PREVENTION_REQS_ID] = [I19].[ICS_MS_4_POLLUTION_PREVENTION_REQS_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT]/[ICS_FLOW_LOCAL].[ICS_MS_4_POST_CNST_SW_REQS] 
				 UNION 
				SELECT KEY_HASH, I21.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_POST_CNST_SW_REQS] [I21]
 ON [I21].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT]/[ICS_FLOW_LOCAL].[ICS_MS_4_POST_CNST_SW_REQS]/[ICS_FLOW_LOCAL].[ICS_MS_4_POST_CNST_SW_PROCEDURES] 
				 UNION 
				SELECT KEY_HASH, I22.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_POST_CNST_SW_REQS] [I21]
 ON [I21].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_POST_CNST_SW_PROCEDURES] [I22]
 ON [I22].[ICS_MS_4_POST_CNST_SW_REQS_ID] = [I21].[ICS_MS_4_POST_CNST_SW_REQS_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT]/[ICS_FLOW_LOCAL].[ICS_MS_4_POST_CNST_SW_REQS]/[ICS_FLOW_LOCAL].[ICS_MS_4_POST_CNST_SW_PROCEDURES]/[ICS_FLOW_LOCAL].[ICS_MS_4_REGULATED_ENTITY_IDENT] 
				 UNION 
				SELECT KEY_HASH, I23.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_POST_CNST_SW_REQS] [I21]
 ON [I21].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_POST_CNST_SW_PROCEDURES] [I22]
 ON [I22].[ICS_MS_4_POST_CNST_SW_REQS_ID] = [I21].[ICS_MS_4_POST_CNST_SW_REQS_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_REGULATED_ENTITY_IDENT] [I23]
 ON [I23].[ICS_MS_4_POST_CNST_SW_PROCEDURES_ID] = [I22].[ICS_MS_4_POST_CNST_SW_PROCEDURES_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT]/[ICS_FLOW_LOCAL].[ICS_MS_4_POST_CNST_SW_REQS]/[ICS_FLOW_LOCAL].[ICS_MS_4_POST_CNST_SW_REGULATED_ENTITY_INFO] 
				 UNION 
				SELECT KEY_HASH, I24.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_POST_CNST_SW_REQS] [I21]
 ON [I21].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_POST_CNST_SW_REGULATED_ENTITY_INFO] [I24]
 ON [I24].[ICS_MS_4_POST_CNST_SW_REQS_ID] = [I21].[ICS_MS_4_POST_CNST_SW_REQS_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT]/[ICS_FLOW_LOCAL].[ICS_MS_4_REGULATED_ENTITY] 
				 UNION 
				SELECT KEY_HASH, I25.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_REGULATED_ENTITY] [I25]
 ON [I25].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT]/[ICS_FLOW_LOCAL].[ICS_MS_4_REGULATED_ENTITY_AREA] 
				 UNION 
				SELECT KEY_HASH, I26.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_REGULATED_ENTITY_AREA] [I26]
 ON [I26].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT]/[ICS_FLOW_LOCAL].[ICS_MS_4_REGULATED_ENTITY_AREA]/[ICS_FLOW_LOCAL].[ICS_MS_4_REGULATED_ENTITY_AREA_COORD] 
				 UNION 
				SELECT KEY_HASH, I27.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_REGULATED_ENTITY_AREA] [I26]
 ON [I26].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_MS_4_REGULATED_ENTITY_AREA_COORD] [I27]
 ON [I27].[ICS_MS_4_REGULATED_ENTITY_AREA_ID] = [I26].[ICS_MS_4_REGULATED_ENTITY_AREA_ID] 
    
				WHERE key_hash = @v_key_hash
							  
             ) here
             WHERE here.key_hash = @v_key_hash
             ORDER BY here.data_hash)

              SELECT @v_working_data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', COALESCE(@v_working_data_hash,'#') + data_hash)
                FROM tmp
               WHERE tmp.key_hash = @v_key_hash
               ORDER BY data_hash

              UPDATE ICS_FLOW_LOCAL.ICS_SWMS_4_PRMT
                 SET data_hash = @v_working_data_hash
               WHERE key_hash = @v_key_hash
             END;
			 
			 

	  
		-- CollectionSystemPermitSubmission, not children
	  
		  
		-- UnpermittedFacilitySubmission

         IF @p_payload_type = 'ICS_UNPRMT_FAC' and @v_enabled = 'Y'
             BEGIN

             WITH tmp (key_hash, data_hash) AS
             ( SELECT TOP 100 PERCENT here.key_hash, here.data_hash
             FROM (			

				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_UNPRMT_FAC] 
				
				SELECT KEY_HASH, ICS_UNPRMT_FAC.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_UNPRMT_FAC] [ICS_UNPRMT_FAC] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_UNPRMT_FAC]/[ICS_FLOW_LOCAL].[ICS_NAICS_CODE] 
				 UNION 
				SELECT KEY_HASH, I1.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_UNPRMT_FAC] [ICS_UNPRMT_FAC] 
 JOIN [ICS_FLOW_LOCAL].[ICS_NAICS_CODE] [I1]
 ON [I1].[ICS_UNPRMT_FAC_ID] = [ICS_UNPRMT_FAC].[ICS_UNPRMT_FAC_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_UNPRMT_FAC]/[ICS_FLOW_LOCAL].[ICS_CONTACT] 
				 UNION 
				SELECT KEY_HASH, I2.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_UNPRMT_FAC] [ICS_UNPRMT_FAC] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTACT] [I2]
 ON [I2].[ICS_UNPRMT_FAC_ID] = [ICS_UNPRMT_FAC].[ICS_UNPRMT_FAC_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_UNPRMT_FAC]/[ICS_FLOW_LOCAL].[ICS_CONTACT]/[ICS_FLOW_LOCAL].[ICS_TELEPH] 
				 UNION 
				SELECT KEY_HASH, I3.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_UNPRMT_FAC] [ICS_UNPRMT_FAC] 
 JOIN [ICS_FLOW_LOCAL].[ICS_CONTACT] [I2]
 ON [I2].[ICS_UNPRMT_FAC_ID] = [ICS_UNPRMT_FAC].[ICS_UNPRMT_FAC_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_TELEPH] [I3]
 ON [I3].[ICS_CONTACT_ID] = [I2].[ICS_CONTACT_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_UNPRMT_FAC]/[ICS_FLOW_LOCAL].[ICS_ORIG_PROGS] 
				 UNION 
				SELECT KEY_HASH, I4.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_UNPRMT_FAC] [ICS_UNPRMT_FAC] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ORIG_PROGS] [I4]
 ON [I4].[ICS_UNPRMT_FAC_ID] = [ICS_UNPRMT_FAC].[ICS_UNPRMT_FAC_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_UNPRMT_FAC]/[ICS_FLOW_LOCAL].[ICS_PLCY] 
				 UNION 
				SELECT KEY_HASH, I5.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_UNPRMT_FAC] [ICS_UNPRMT_FAC] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PLCY] [I5]
 ON [I5].[ICS_UNPRMT_FAC_ID] = [ICS_UNPRMT_FAC].[ICS_UNPRMT_FAC_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_UNPRMT_FAC]/[ICS_FLOW_LOCAL].[ICS_PRMT_COMP_TYPE] 
				 UNION 
				SELECT KEY_HASH, I6.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_UNPRMT_FAC] [ICS_UNPRMT_FAC] 
 JOIN [ICS_FLOW_LOCAL].[ICS_PRMT_COMP_TYPE] [I6]
 ON [I6].[ICS_UNPRMT_FAC_ID] = [ICS_UNPRMT_FAC].[ICS_UNPRMT_FAC_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_UNPRMT_FAC]/[ICS_FLOW_LOCAL].[ICS_FAC_CLASS] 
				 UNION 
				SELECT KEY_HASH, I7.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_UNPRMT_FAC] [ICS_UNPRMT_FAC] 
 JOIN [ICS_FLOW_LOCAL].[ICS_FAC_CLASS] [I7]
 ON [I7].[ICS_UNPRMT_FAC_ID] = [ICS_UNPRMT_FAC].[ICS_UNPRMT_FAC_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_UNPRMT_FAC]/[ICS_FLOW_LOCAL].[ICS_GEO_COORD] 
				 UNION 
				SELECT KEY_HASH, I8.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_UNPRMT_FAC] [ICS_UNPRMT_FAC] 
 JOIN [ICS_FLOW_LOCAL].[ICS_GEO_COORD] [I8]
 ON [I8].[ICS_UNPRMT_FAC_ID] = [ICS_UNPRMT_FAC].[ICS_UNPRMT_FAC_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_UNPRMT_FAC]/[ICS_FLOW_LOCAL].[ICS_SIC_CODE] 
				 UNION 
				SELECT KEY_HASH, I9.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_UNPRMT_FAC] [ICS_UNPRMT_FAC] 
 JOIN [ICS_FLOW_LOCAL].[ICS_SIC_CODE] [I9]
 ON [I9].[ICS_UNPRMT_FAC_ID] = [ICS_UNPRMT_FAC].[ICS_UNPRMT_FAC_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_UNPRMT_FAC]/[ICS_FLOW_LOCAL].[ICS_ADDR] 
				 UNION 
				SELECT KEY_HASH, I10.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_UNPRMT_FAC] [ICS_UNPRMT_FAC] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ADDR] [I10]
 ON [I10].[ICS_UNPRMT_FAC_ID] = [ICS_UNPRMT_FAC].[ICS_UNPRMT_FAC_ID] 
    
				WHERE key_hash = @v_key_hash
				
			 
				-- /[ICS_FLOW_LOCAL].[ICS_UNPRMT_FAC]/[ICS_FLOW_LOCAL].[ICS_ADDR]/[ICS_FLOW_LOCAL].[ICS_TELEPH] 
				 UNION 
				SELECT KEY_HASH, I11.DATA_HASH 
				 from [ICS_FLOW_LOCAL].[ICS_UNPRMT_FAC] [ICS_UNPRMT_FAC] 
 JOIN [ICS_FLOW_LOCAL].[ICS_ADDR] [I10]
 ON [I10].[ICS_UNPRMT_FAC_ID] = [ICS_UNPRMT_FAC].[ICS_UNPRMT_FAC_ID] 
 JOIN [ICS_FLOW_LOCAL].[ICS_TELEPH] [I11]
 ON [I11].[ICS_ADDR_ID] = [I10].[ICS_ADDR_ID] 
    
				WHERE key_hash = @v_key_hash
							  
             ) here
             WHERE here.key_hash = @v_key_hash
             ORDER BY here.data_hash)

              SELECT @v_working_data_hash = ICS_FLOW_LOCAL.HASHBYTES_VARCHAR('SHA1', COALESCE(@v_working_data_hash,'#') + data_hash)
                FROM tmp
               WHERE tmp.key_hash = @v_key_hash
               ORDER BY data_hash

              UPDATE ICS_FLOW_LOCAL.ICS_UNPRMT_FAC
                 SET data_hash = @v_working_data_hash
               WHERE key_hash = @v_key_hash
             END;
			 
			 
			 


		  
          /* Get next key_hash value...  */
          FETCH NEXT FROM key_hash INTO @v_key_hash;
                  
        END; -- key_loop   
       
      /*  Close the key_hash cursor */
      CLOSE key_hash;

      /*  Get the next payload type. */
      FETCH NEXT FROM payload_type_process 
      INTO @p_payload_type;
      
    END; -- payload_t--END LOOP module_loop;

  /*  Close payload type cursor */
  CLOSE payload_type_process;
  
  /*  Destroy the payload type cursor */
 
  DEALLOCATE payload_type_process;  
  DEALLOCATE key_hash;  
  
/* -=-=-=-=-=-=- END COPY TO INDICATED SECTION IN ICS_SET_HASHES -=-=-=-=-=-=-=-=-= */   

  END

