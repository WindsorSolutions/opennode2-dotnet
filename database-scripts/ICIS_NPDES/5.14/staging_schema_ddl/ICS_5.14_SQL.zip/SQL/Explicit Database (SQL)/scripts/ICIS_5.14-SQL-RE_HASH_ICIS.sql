
/*
 Script to Re-calculate Hashes on ICIS Data: 
 This script will re-establish the hash values for ICS_FLOW_ICIS tables after an update to the hashing procedures so that change detection will be accurate after an update.
 
 Run this script after a node version update. 
 It should be run after all objects are updated in the database, before a submission.
 
 
 */

-- ------------------------------------------------------
-- Prepare ICS_FLOW_ICIS.ICS_PAYLOAD TABLE
-- Hash calculation for specifice payloades is determined by the ICS_PAYLOAD.ENABLED for the payload row.
-- Ensure ICS_FLOW_ICIS.ICS_PAYLOAD contains all payloads present in ICS_FLOW_LOCAL, and that ENABLED = 'Y'
--
-- ICS_FLOW_ICIS.ICS_PAYLOAD had no function before the ICS_FlOW_ICIS.ICS_SET_HASHES procedure, and may
-- not have been loaded on some older installations.  We must ensure all payloads are present and set. 
-- ------------------------------------------------------

-- Ensure all payloads from ics_Flow_local are present
insert into ICS_FLOW_ICIS.dbo.ICS_PAYLOAD 
select * from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD src
where not exists (select 1 from ICS_FLOW_ICIS.dbo.ICS_PAYLOAD where src.ICS_PAYLOAD_ID = ICS_PAYLOAD.ICS_PAYLOAD_ID);

-- Set enabled
update ICS_FLOW_ICIS.dbo.ICS_PAYLOAD set ENABLED = 'Y' where 1=1;

-- Set hashes on ICS_FLOW_ICIS Data
exec ICS_FLOW_ICIS.dbo.ICS_SET_HASHES;
