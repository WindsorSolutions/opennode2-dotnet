
-- This script attempts to find permits which were fake-mirrored... that is, the data_hash in ics_flow_icis
-- was set to the value in ics_flow_local so that they will not be detected to flow. 
--
--Since this operation does not truly mirror the data, but rather only sets the data_hash on the base tables,
-- we can detect any record that has none of the necessary child tables as being a fake-mirrored record (also sometimes referd to as 'seeded'



-- LIMIT_SET 
update LS
set  LS.DATA_HASH  = LCL.DATA_HASH , LS.TRANSACTION_TYPE = 'M'  -- select *
from ICS_FLOW_LOCAL.dbo.ICS_LMT_SET LCL
join ICS_FLOW_ICIS.dbo.ICS_LMT_SET LS on LS.KEY_HASH = LCL.KEY_HASH
where not exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_LMT_SET_SCHD LSS where LSS.ICS_LMT_SET_ID = LS.ICS_LMT_SET_ID)

-- Parameter Limits: 
update BASE
set  BASE.DATA_HASH = LCL.DATA_HASH , BASE.TRANSACTION_TYPE = 'M' -- select *
from ICS_FLOW_LOCAL.dbo.ICS_PARAM_LMTS LCL
join ICS_FLOW_ICIS.dbo.ICS_PARAM_LMTS BASE on LCL.KEY_HASH = BASE.KEY_HASH
where not exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_LMT CHILD where CHILD.ICS_PARAM_LMTS_ID = BASE.ICS_PARAM_LMTS_ID)

-- General PErmits
update BASE
set  BASE.DATA_HASH = LCL.DATA_HASH , BASE.TRANSACTION_TYPE = 'M' -- select *
from ICS_FLOW_LOCAL.dbo.ICS_GNRL_PRMT LCL
join ICS_FLOW_ICIS.dbo.ICS_GNRL_PRMT BASE on LCL.KEY_HASH = BASE.KEY_HASH
where not exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_FAC CHILD where CHILD.ICS_GNRL_PRMT_ID = BASE.ICS_GNRL_PRMT_ID)

-- Basic Permit
update BASE
set  BASE.DATA_HASH = LCL.DATA_HASH , BASE.TRANSACTION_TYPE = 'M'  -- select *
from ICS_FLOW_LOCAL.dbo.ICS_BASIC_PRMT LCL
join ICS_FLOW_ICIS.dbo.ICS_BASIC_PRMT BASE on LCL.KEY_HASH = BASE.KEY_HASH
where not exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_FAC CHILD where CHILD.ICS_BASIC_PRMT_ID = BASE.ICS_BASIC_PRMT_ID)

-- there are 28  DMRs that appear to be seeded. However, DMRs are sometimes 1 level
-- due to NODI codes.  So, I commented this one out.
--update LCL
--set BASE.DATA_HASH = LCL.DATA_HASH , TRANSACTION_TYPE = 'M' -- select *
--from ICS_FLOW_LOCAL.dbo.ICS_DSCH_MON_REP LCL
--join ICS_FLOW_ICIS.dbo.ICS_DSCH_MON_REP BASE on LCL.KEY_HASH = BASE.KEY_HASH
--where not exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_REP_PARAM CHILD where CHILD.ICS_DSCH_MON_REP_ID = BASE.ICS_DSCH_MON_REP_ID)
--AND BASE.DMR_NO_DSCH_IND is null