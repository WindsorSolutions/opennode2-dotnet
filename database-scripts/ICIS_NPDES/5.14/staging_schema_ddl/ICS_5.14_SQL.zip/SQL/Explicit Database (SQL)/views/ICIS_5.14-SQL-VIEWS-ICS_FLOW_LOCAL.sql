-- All CDV Views



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.CDV_BASIC_PRMT') AND type = N'V')
  DROP VIEW dbo.CDV_BASIC_PRMT
GO

/*************************************************************************************************
** ObjectName: dbo.CDV_BASIC_PRMT
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Autogen: using helper: node .\run_template.js "all_cdv_views.js"
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/13/2016    Windsor     Baselined from v5.0 procedure. 
** 03/29/2025    Windsor     Recreate this 
**
***************************************************************************************************/
CREATE VIEW dbo.CDV_BASIC_PRMT AS 
SELECT DISTINCT ics_module
, ICS_BASIC_PRMT.key_hash
     , CASE ICS_BASIC_PRMT.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.dbo.ICS_BASIC_PRMT tbl
                  WHERE tbl.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID)
           ELSE (SELECT key_hash 
                   FROM dbo.ICS_BASIC_PRMT tbl
                  WHERE tbl.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID)
       END AS module_ident
     , ICS_BASIC_PRMT.action_type
     , ICS_BASIC_PRMT.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID
			 , ICS_BASIC_PRMT.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_BASIC_PRMT' as ics_module
          FROM dbo.ICS_BASIC_PRMT
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.dbo.ICS_BASIC_PRMT tbl
                            WHERE tbl.key_hash = ICS_BASIC_PRMT.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_BASIC_PRMT_ID
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_BASIC_PRMT' as ics_module
          FROM dbo.ICS_BASIC_PRMT local
          JOIN ics_flow_icis.dbo.ICS_BASIC_PRMT icis
            ON (icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash) 
        UNION
        /*  3 - DELETE  */
        SELECT ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID
             , ICS_BASIC_PRMT.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_BASIC_PRMT' as ics_module
          FROM ics_flow_icis.dbo.ICS_BASIC_PRMT
         WHERE NOT EXISTS (SELECT 'x'
                             FROM dbo.ICS_BASIC_PRMT tbl
                            WHERE tbl.key_hash = ICS_BASIC_PRMT.key_hash)) ICS_BASIC_PRMT;
GO



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.CDV_BS_ANNUL_PROG_REP') AND type = N'V')
  DROP VIEW dbo.CDV_BS_ANNUL_PROG_REP
GO

/*************************************************************************************************
** ObjectName: dbo.CDV_BS_ANNUL_PROG_REP
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Autogen: using helper: node .\run_template.js "all_cdv_views.js"
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/13/2016    Windsor     Baselined from v5.0 procedure. 
** 03/29/2025    Windsor     Recreate this 
**
***************************************************************************************************/
CREATE VIEW dbo.CDV_BS_ANNUL_PROG_REP AS 
SELECT DISTINCT ics_module
, ICS_BS_ANNUL_PROG_REP.key_hash
     , CASE ICS_BS_ANNUL_PROG_REP.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.dbo.ICS_BS_ANNUL_PROG_REP tbl
                  WHERE tbl.ICS_BS_ANNUL_PROG_REP_ID = ICS_BS_ANNUL_PROG_REP.ICS_BS_ANNUL_PROG_REP_ID)
           ELSE (SELECT key_hash 
                   FROM dbo.ICS_BS_ANNUL_PROG_REP tbl
                  WHERE tbl.ICS_BS_ANNUL_PROG_REP_ID = ICS_BS_ANNUL_PROG_REP.ICS_BS_ANNUL_PROG_REP_ID)
       END AS module_ident
     , ICS_BS_ANNUL_PROG_REP.action_type
     , ICS_BS_ANNUL_PROG_REP.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_BS_ANNUL_PROG_REP.ICS_BS_ANNUL_PROG_REP_ID
			 , ICS_BS_ANNUL_PROG_REP.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_BS_ANNUL_PROG_REP' as ics_module
          FROM dbo.ICS_BS_ANNUL_PROG_REP
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.dbo.ICS_BS_ANNUL_PROG_REP tbl
                            WHERE tbl.key_hash = ICS_BS_ANNUL_PROG_REP.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_BS_ANNUL_PROG_REP_ID
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_BS_ANNUL_PROG_REP' as ics_module
          FROM dbo.ICS_BS_ANNUL_PROG_REP local
          JOIN ics_flow_icis.dbo.ICS_BS_ANNUL_PROG_REP icis
            ON (icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash) 
        UNION
        /*  3 - DELETE  */
        SELECT ICS_BS_ANNUL_PROG_REP.ICS_BS_ANNUL_PROG_REP_ID
             , ICS_BS_ANNUL_PROG_REP.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_BS_ANNUL_PROG_REP' as ics_module
          FROM ics_flow_icis.dbo.ICS_BS_ANNUL_PROG_REP
         WHERE NOT EXISTS (SELECT 'x'
                             FROM dbo.ICS_BS_ANNUL_PROG_REP tbl
                            WHERE tbl.key_hash = ICS_BS_ANNUL_PROG_REP.key_hash)) ICS_BS_ANNUL_PROG_REP;
GO



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.CDV_BS_ANNUL_PROG_REP') AND type = N'V')
  DROP VIEW dbo.CDV_BS_ANNUL_PROG_REP
GO

/*************************************************************************************************
** ObjectName: dbo.CDV_BS_ANNUL_PROG_REP
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Autogen: using helper: node .\run_template.js "all_cdv_views.js"
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/13/2016    Windsor     Baselined from v5.0 procedure. 
** 03/29/2025    Windsor     Recreate this 
**
***************************************************************************************************/
CREATE VIEW dbo.CDV_BS_ANNUL_PROG_REP AS 
SELECT DISTINCT ics_module
, ICS_BS_ANNUL_PROG_REP.key_hash
     , CASE ICS_BS_ANNUL_PROG_REP.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.dbo.ICS_BS_ANNUL_PROG_REP tbl
                  WHERE tbl.ICS_BS_ANNUL_PROG_REP_ID = ICS_BS_ANNUL_PROG_REP.ICS_BS_ANNUL_PROG_REP_ID)
           ELSE (SELECT key_hash 
                   FROM dbo.ICS_BS_ANNUL_PROG_REP tbl
                  WHERE tbl.ICS_BS_ANNUL_PROG_REP_ID = ICS_BS_ANNUL_PROG_REP.ICS_BS_ANNUL_PROG_REP_ID)
       END AS module_ident
     , ICS_BS_ANNUL_PROG_REP.action_type
     , ICS_BS_ANNUL_PROG_REP.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_BS_ANNUL_PROG_REP.ICS_BS_ANNUL_PROG_REP_ID
			 , ICS_BS_ANNUL_PROG_REP.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_BS_ANNUL_PROG_REP' as ics_module
          FROM dbo.ICS_BS_ANNUL_PROG_REP
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.dbo.ICS_BS_ANNUL_PROG_REP tbl
                            WHERE tbl.key_hash = ICS_BS_ANNUL_PROG_REP.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_BS_ANNUL_PROG_REP_ID
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_BS_ANNUL_PROG_REP' as ics_module
          FROM dbo.ICS_BS_ANNUL_PROG_REP local
          JOIN ics_flow_icis.dbo.ICS_BS_ANNUL_PROG_REP icis
            ON (icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash) 
        UNION
        /*  3 - DELETE  */
        SELECT ICS_BS_ANNUL_PROG_REP.ICS_BS_ANNUL_PROG_REP_ID
             , ICS_BS_ANNUL_PROG_REP.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_BS_ANNUL_PROG_REP' as ics_module
          FROM ics_flow_icis.dbo.ICS_BS_ANNUL_PROG_REP
         WHERE NOT EXISTS (SELECT 'x'
                             FROM dbo.ICS_BS_ANNUL_PROG_REP tbl
                            WHERE tbl.key_hash = ICS_BS_ANNUL_PROG_REP.key_hash)) ICS_BS_ANNUL_PROG_REP;
GO



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.CDV_BS_PRMT') AND type = N'V')
  DROP VIEW dbo.CDV_BS_PRMT
GO

/*************************************************************************************************
** ObjectName: dbo.CDV_BS_PRMT
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Autogen: using helper: node .\run_template.js "all_cdv_views.js"
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/13/2016    Windsor     Baselined from v5.0 procedure. 
** 03/29/2025    Windsor     Recreate this 
**
***************************************************************************************************/
CREATE VIEW dbo.CDV_BS_PRMT AS 
SELECT DISTINCT ics_module
, ICS_BS_PRMT.key_hash
     , CASE ICS_BS_PRMT.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.dbo.ICS_BS_PRMT tbl
                  WHERE tbl.ICS_BS_PRMT_ID = ICS_BS_PRMT.ICS_BS_PRMT_ID)
           ELSE (SELECT key_hash 
                   FROM dbo.ICS_BS_PRMT tbl
                  WHERE tbl.ICS_BS_PRMT_ID = ICS_BS_PRMT.ICS_BS_PRMT_ID)
       END AS module_ident
     , ICS_BS_PRMT.action_type
     , ICS_BS_PRMT.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_BS_PRMT.ICS_BS_PRMT_ID
			 , ICS_BS_PRMT.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_BS_PRMT' as ics_module
          FROM dbo.ICS_BS_PRMT
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.dbo.ICS_BS_PRMT tbl
                            WHERE tbl.key_hash = ICS_BS_PRMT.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_BS_PRMT_ID
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_BS_PRMT' as ics_module
          FROM dbo.ICS_BS_PRMT local
          JOIN ics_flow_icis.dbo.ICS_BS_PRMT icis
            ON (icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash) 
        UNION
        /*  3 - DELETE  */
        SELECT ICS_BS_PRMT.ICS_BS_PRMT_ID
             , ICS_BS_PRMT.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_BS_PRMT' as ics_module
          FROM ics_flow_icis.dbo.ICS_BS_PRMT
         WHERE NOT EXISTS (SELECT 'x'
                             FROM dbo.ICS_BS_PRMT tbl
                            WHERE tbl.key_hash = ICS_BS_PRMT.key_hash)) ICS_BS_PRMT;
GO



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.CDV_CAFO_ANNUL_PROG_REP') AND type = N'V')
  DROP VIEW dbo.CDV_CAFO_ANNUL_PROG_REP
GO

/*************************************************************************************************
** ObjectName: dbo.CDV_CAFO_ANNUL_PROG_REP
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Autogen: using helper: node .\run_template.js "all_cdv_views.js"
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/13/2016    Windsor     Baselined from v5.0 procedure. 
** 03/29/2025    Windsor     Recreate this 
**
***************************************************************************************************/
CREATE VIEW dbo.CDV_CAFO_ANNUL_PROG_REP AS 
SELECT DISTINCT ics_module
, ICS_CAFO_ANNUL_PROG_REP.key_hash
     , CASE ICS_CAFO_ANNUL_PROG_REP.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.dbo.ICS_CAFO_ANNUL_PROG_REP tbl
                  WHERE tbl.ICS_CAFO_ANNUL_PROG_REP_ID = ICS_CAFO_ANNUL_PROG_REP.ICS_CAFO_ANNUL_PROG_REP_ID)
           ELSE (SELECT key_hash 
                   FROM dbo.ICS_CAFO_ANNUL_PROG_REP tbl
                  WHERE tbl.ICS_CAFO_ANNUL_PROG_REP_ID = ICS_CAFO_ANNUL_PROG_REP.ICS_CAFO_ANNUL_PROG_REP_ID)
       END AS module_ident
     , ICS_CAFO_ANNUL_PROG_REP.action_type
     , ICS_CAFO_ANNUL_PROG_REP.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_CAFO_ANNUL_PROG_REP.ICS_CAFO_ANNUL_PROG_REP_ID
			 , ICS_CAFO_ANNUL_PROG_REP.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_CAFO_ANNUL_PROG_REP' as ics_module
          FROM dbo.ICS_CAFO_ANNUL_PROG_REP
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.dbo.ICS_CAFO_ANNUL_PROG_REP tbl
                            WHERE tbl.key_hash = ICS_CAFO_ANNUL_PROG_REP.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_CAFO_ANNUL_PROG_REP_ID
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_CAFO_ANNUL_PROG_REP' as ics_module
          FROM dbo.ICS_CAFO_ANNUL_PROG_REP local
          JOIN ics_flow_icis.dbo.ICS_CAFO_ANNUL_PROG_REP icis
            ON (icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash) 
        UNION
        /*  3 - DELETE  */
        SELECT ICS_CAFO_ANNUL_PROG_REP.ICS_CAFO_ANNUL_PROG_REP_ID
             , ICS_CAFO_ANNUL_PROG_REP.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_CAFO_ANNUL_PROG_REP' as ics_module
          FROM ics_flow_icis.dbo.ICS_CAFO_ANNUL_PROG_REP
         WHERE NOT EXISTS (SELECT 'x'
                             FROM dbo.ICS_CAFO_ANNUL_PROG_REP tbl
                            WHERE tbl.key_hash = ICS_CAFO_ANNUL_PROG_REP.key_hash)) ICS_CAFO_ANNUL_PROG_REP;
GO



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.CDV_CAFO_PRMT') AND type = N'V')
  DROP VIEW dbo.CDV_CAFO_PRMT
GO

/*************************************************************************************************
** ObjectName: dbo.CDV_CAFO_PRMT
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Autogen: using helper: node .\run_template.js "all_cdv_views.js"
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/13/2016    Windsor     Baselined from v5.0 procedure. 
** 03/29/2025    Windsor     Recreate this 
**
***************************************************************************************************/
CREATE VIEW dbo.CDV_CAFO_PRMT AS 
SELECT DISTINCT ics_module
, ICS_CAFO_PRMT.key_hash
     , CASE ICS_CAFO_PRMT.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.dbo.ICS_CAFO_PRMT tbl
                  WHERE tbl.ICS_CAFO_PRMT_ID = ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID)
           ELSE (SELECT key_hash 
                   FROM dbo.ICS_CAFO_PRMT tbl
                  WHERE tbl.ICS_CAFO_PRMT_ID = ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID)
       END AS module_ident
     , ICS_CAFO_PRMT.action_type
     , ICS_CAFO_PRMT.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID
			 , ICS_CAFO_PRMT.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_CAFO_PRMT' as ics_module
          FROM dbo.ICS_CAFO_PRMT
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.dbo.ICS_CAFO_PRMT tbl
                            WHERE tbl.key_hash = ICS_CAFO_PRMT.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_CAFO_PRMT_ID
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_CAFO_PRMT' as ics_module
          FROM dbo.ICS_CAFO_PRMT local
          JOIN ics_flow_icis.dbo.ICS_CAFO_PRMT icis
            ON (icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash) 
        UNION
        /*  3 - DELETE  */
        SELECT ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID
             , ICS_CAFO_PRMT.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_CAFO_PRMT' as ics_module
          FROM ics_flow_icis.dbo.ICS_CAFO_PRMT
         WHERE NOT EXISTS (SELECT 'x'
                             FROM dbo.ICS_CAFO_PRMT tbl
                            WHERE tbl.key_hash = ICS_CAFO_PRMT.key_hash)) ICS_CAFO_PRMT;
GO



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.CDV_COLL_SYSTM_PRMT') AND type = N'V')
  DROP VIEW dbo.CDV_COLL_SYSTM_PRMT
GO

/*************************************************************************************************
** ObjectName: dbo.CDV_COLL_SYSTM_PRMT
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Autogen: using helper: node .\run_template.js "all_cdv_views.js"
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/13/2016    Windsor     Baselined from v5.0 procedure. 
** 03/29/2025    Windsor     Recreate this 
**
***************************************************************************************************/
CREATE VIEW dbo.CDV_COLL_SYSTM_PRMT AS 
SELECT DISTINCT ics_module
, ICS_COLL_SYSTM_PRMT.key_hash
     , CASE ICS_COLL_SYSTM_PRMT.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.dbo.ICS_COLL_SYSTM_PRMT tbl
                  WHERE tbl.ICS_COLL_SYSTM_PRMT_ID = ICS_COLL_SYSTM_PRMT.ICS_COLL_SYSTM_PRMT_ID)
           ELSE (SELECT key_hash 
                   FROM dbo.ICS_COLL_SYSTM_PRMT tbl
                  WHERE tbl.ICS_COLL_SYSTM_PRMT_ID = ICS_COLL_SYSTM_PRMT.ICS_COLL_SYSTM_PRMT_ID)
       END AS module_ident
     , ICS_COLL_SYSTM_PRMT.action_type
     , ICS_COLL_SYSTM_PRMT.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_COLL_SYSTM_PRMT.ICS_COLL_SYSTM_PRMT_ID
			 , ICS_COLL_SYSTM_PRMT.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_COLL_SYSTM_PRMT' as ics_module
          FROM dbo.ICS_COLL_SYSTM_PRMT
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.dbo.ICS_COLL_SYSTM_PRMT tbl
                            WHERE tbl.key_hash = ICS_COLL_SYSTM_PRMT.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_COLL_SYSTM_PRMT_ID
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_COLL_SYSTM_PRMT' as ics_module
          FROM dbo.ICS_COLL_SYSTM_PRMT local
          JOIN ics_flow_icis.dbo.ICS_COLL_SYSTM_PRMT icis
            ON (icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash) 
        UNION
        /*  3 - DELETE  */
        SELECT ICS_COLL_SYSTM_PRMT.ICS_COLL_SYSTM_PRMT_ID
             , ICS_COLL_SYSTM_PRMT.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_COLL_SYSTM_PRMT' as ics_module
          FROM ics_flow_icis.dbo.ICS_COLL_SYSTM_PRMT
         WHERE NOT EXISTS (SELECT 'x'
                             FROM dbo.ICS_COLL_SYSTM_PRMT tbl
                            WHERE tbl.key_hash = ICS_COLL_SYSTM_PRMT.key_hash)) ICS_COLL_SYSTM_PRMT;
GO



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.CDV_CMPL_MON') AND type = N'V')
  DROP VIEW dbo.CDV_CMPL_MON
GO

/*************************************************************************************************
** ObjectName: dbo.CDV_CMPL_MON
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Autogen: using helper: node .\run_template.js "all_cdv_views.js"
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/13/2016    Windsor     Baselined from v5.0 procedure. 
** 03/29/2025    Windsor     Recreate this 
**
***************************************************************************************************/
CREATE VIEW dbo.CDV_CMPL_MON AS 
SELECT DISTINCT ics_module
, ICS_CMPL_MON.key_hash
     , CASE ICS_CMPL_MON.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.dbo.ICS_CMPL_MON tbl
                  WHERE tbl.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID)
           ELSE (SELECT key_hash 
                   FROM dbo.ICS_CMPL_MON tbl
                  WHERE tbl.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID)
       END AS module_ident
     , ICS_CMPL_MON.action_type
     , ICS_CMPL_MON.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_CMPL_MON.ICS_CMPL_MON_ID
			 , ICS_CMPL_MON.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_CMPL_MON' as ics_module
          FROM dbo.ICS_CMPL_MON
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.dbo.ICS_CMPL_MON tbl
                            WHERE tbl.key_hash = ICS_CMPL_MON.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_CMPL_MON_ID
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_CMPL_MON' as ics_module
          FROM dbo.ICS_CMPL_MON local
          JOIN ics_flow_icis.dbo.ICS_CMPL_MON icis
            ON (icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash) 
        UNION
        /*  3 - DELETE  */
        SELECT ICS_CMPL_MON.ICS_CMPL_MON_ID
             , ICS_CMPL_MON.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_CMPL_MON' as ics_module
          FROM ics_flow_icis.dbo.ICS_CMPL_MON
         WHERE NOT EXISTS (SELECT 'x'
                             FROM dbo.ICS_CMPL_MON tbl
                            WHERE tbl.key_hash = ICS_CMPL_MON.key_hash)) ICS_CMPL_MON;
GO



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.CDV_CMPL_MON_LNK') AND type = N'V')
  DROP VIEW dbo.CDV_CMPL_MON_LNK
GO

/*************************************************************************************************
** ObjectName: dbo.CDV_CMPL_MON_LNK
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Autogen: using helper: node .\run_template.js "all_cdv_views.js"
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/13/2016    Windsor     Baselined from v5.0 procedure. 
** 03/29/2025    Windsor     Recreate this 
**
***************************************************************************************************/
CREATE VIEW dbo.CDV_CMPL_MON_LNK AS 
SELECT DISTINCT ics_module
, ICS_CMPL_MON_LNK.key_hash
     , CASE ICS_CMPL_MON_LNK.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.dbo.ICS_CMPL_MON_LNK tbl
                  WHERE tbl.ICS_CMPL_MON_LNK_ID = ICS_CMPL_MON_LNK.ICS_CMPL_MON_LNK_ID)
           ELSE (SELECT key_hash 
                   FROM dbo.ICS_CMPL_MON_LNK tbl
                  WHERE tbl.ICS_CMPL_MON_LNK_ID = ICS_CMPL_MON_LNK.ICS_CMPL_MON_LNK_ID)
       END AS module_ident
     , ICS_CMPL_MON_LNK.action_type
     , ICS_CMPL_MON_LNK.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_CMPL_MON_LNK.ICS_CMPL_MON_LNK_ID
			 , ICS_CMPL_MON_LNK.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_CMPL_MON_LNK' as ics_module
          FROM dbo.ICS_CMPL_MON_LNK
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.dbo.ICS_CMPL_MON_LNK tbl
                            WHERE tbl.key_hash = ICS_CMPL_MON_LNK.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_CMPL_MON_LNK_ID
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_CMPL_MON_LNK' as ics_module
          FROM dbo.ICS_CMPL_MON_LNK local
          JOIN ics_flow_icis.dbo.ICS_CMPL_MON_LNK icis
            ON (icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash) 
        UNION
        /*  3 - DELETE  */
        SELECT ICS_CMPL_MON_LNK.ICS_CMPL_MON_LNK_ID
             , ICS_CMPL_MON_LNK.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_CMPL_MON_LNK' as ics_module
          FROM ics_flow_icis.dbo.ICS_CMPL_MON_LNK
         WHERE NOT EXISTS (SELECT 'x'
                             FROM dbo.ICS_CMPL_MON_LNK tbl
                            WHERE tbl.key_hash = ICS_CMPL_MON_LNK.key_hash)) ICS_CMPL_MON_LNK;
GO



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.CDV_CMPL_SCHD') AND type = N'V')
  DROP VIEW dbo.CDV_CMPL_SCHD
GO

/*************************************************************************************************
** ObjectName: dbo.CDV_CMPL_SCHD
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Autogen: using helper: node .\run_template.js "all_cdv_views.js"
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/13/2016    Windsor     Baselined from v5.0 procedure. 
** 03/29/2025    Windsor     Recreate this 
**
***************************************************************************************************/
CREATE VIEW dbo.CDV_CMPL_SCHD AS 
SELECT DISTINCT ics_module
, ICS_CMPL_SCHD.key_hash
     , CASE ICS_CMPL_SCHD.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.dbo.ICS_CMPL_SCHD tbl
                  WHERE tbl.ICS_CMPL_SCHD_ID = ICS_CMPL_SCHD.ICS_CMPL_SCHD_ID)
           ELSE (SELECT key_hash 
                   FROM dbo.ICS_CMPL_SCHD tbl
                  WHERE tbl.ICS_CMPL_SCHD_ID = ICS_CMPL_SCHD.ICS_CMPL_SCHD_ID)
       END AS module_ident
     , ICS_CMPL_SCHD.action_type
     , ICS_CMPL_SCHD.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_CMPL_SCHD.ICS_CMPL_SCHD_ID
			 , ICS_CMPL_SCHD.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_CMPL_SCHD' as ics_module
          FROM dbo.ICS_CMPL_SCHD
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.dbo.ICS_CMPL_SCHD tbl
                            WHERE tbl.key_hash = ICS_CMPL_SCHD.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_CMPL_SCHD_ID
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_CMPL_SCHD' as ics_module
          FROM dbo.ICS_CMPL_SCHD local
          JOIN ics_flow_icis.dbo.ICS_CMPL_SCHD icis
            ON (icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash) 
        UNION
        /*  3 - DELETE  */
        SELECT ICS_CMPL_SCHD.ICS_CMPL_SCHD_ID
             , ICS_CMPL_SCHD.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_CMPL_SCHD' as ics_module
          FROM ics_flow_icis.dbo.ICS_CMPL_SCHD
         WHERE NOT EXISTS (SELECT 'x'
                             FROM dbo.ICS_CMPL_SCHD tbl
                            WHERE tbl.key_hash = ICS_CMPL_SCHD.key_hash)) ICS_CMPL_SCHD;
GO



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.CDV_COPY_MGP_LMT_SET') AND type = N'V')
  DROP VIEW dbo.CDV_COPY_MGP_LMT_SET
GO

/*************************************************************************************************
** ObjectName: dbo.CDV_COPY_MGP_LMT_SET
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Autogen: using helper: node .\run_template.js "all_cdv_views.js"
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/13/2016    Windsor     Baselined from v5.0 procedure. 
** 03/29/2025    Windsor     Recreate this 
**
***************************************************************************************************/
CREATE VIEW dbo.CDV_COPY_MGP_LMT_SET AS 
SELECT DISTINCT ics_module
, ICS_COPY_MGP_LMT_SET.key_hash
     , CASE ICS_COPY_MGP_LMT_SET.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.dbo.ICS_COPY_MGP_LMT_SET tbl
                  WHERE tbl.ICS_COPY_MGP_LMT_SET_ID = ICS_COPY_MGP_LMT_SET.ICS_COPY_MGP_LMT_SET_ID)
           ELSE (SELECT key_hash 
                   FROM dbo.ICS_COPY_MGP_LMT_SET tbl
                  WHERE tbl.ICS_COPY_MGP_LMT_SET_ID = ICS_COPY_MGP_LMT_SET.ICS_COPY_MGP_LMT_SET_ID)
       END AS module_ident
     , ICS_COPY_MGP_LMT_SET.action_type
     , ICS_COPY_MGP_LMT_SET.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_COPY_MGP_LMT_SET.ICS_COPY_MGP_LMT_SET_ID
			 , ICS_COPY_MGP_LMT_SET.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_COPY_MGP_LMT_SET' as ics_module
          FROM dbo.ICS_COPY_MGP_LMT_SET
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.dbo.ICS_COPY_MGP_LMT_SET tbl
                            WHERE tbl.key_hash = ICS_COPY_MGP_LMT_SET.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_COPY_MGP_LMT_SET_ID
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_COPY_MGP_LMT_SET' as ics_module
          FROM dbo.ICS_COPY_MGP_LMT_SET local
          JOIN ics_flow_icis.dbo.ICS_COPY_MGP_LMT_SET icis
            ON (icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash) 
        UNION
        /*  3 - DELETE  */
        SELECT ICS_COPY_MGP_LMT_SET.ICS_COPY_MGP_LMT_SET_ID
             , ICS_COPY_MGP_LMT_SET.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_COPY_MGP_LMT_SET' as ics_module
          FROM ics_flow_icis.dbo.ICS_COPY_MGP_LMT_SET
         WHERE NOT EXISTS (SELECT 'x'
                             FROM dbo.ICS_COPY_MGP_LMT_SET tbl
                            WHERE tbl.key_hash = ICS_COPY_MGP_LMT_SET.key_hash)) ICS_COPY_MGP_LMT_SET;
GO



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.CDV_COPY_MGPMS_4_REQ') AND type = N'V')
  DROP VIEW dbo.CDV_COPY_MGPMS_4_REQ
GO

/*************************************************************************************************
** ObjectName: dbo.CDV_COPY_MGPMS_4_REQ
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Autogen: using helper: node .\run_template.js "all_cdv_views.js"
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/13/2016    Windsor     Baselined from v5.0 procedure. 
** 03/29/2025    Windsor     Recreate this 
**
***************************************************************************************************/
CREATE VIEW dbo.CDV_COPY_MGPMS_4_REQ AS 
SELECT DISTINCT ics_module
, ICS_COPY_MGPMS_4_REQ.key_hash
     , CASE ICS_COPY_MGPMS_4_REQ.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.dbo.ICS_COPY_MGPMS_4_REQ tbl
                  WHERE tbl.ICS_COPY_MGPMS_4_REQ_ID = ICS_COPY_MGPMS_4_REQ.ICS_COPY_MGPMS_4_REQ_ID)
           ELSE (SELECT key_hash 
                   FROM dbo.ICS_COPY_MGPMS_4_REQ tbl
                  WHERE tbl.ICS_COPY_MGPMS_4_REQ_ID = ICS_COPY_MGPMS_4_REQ.ICS_COPY_MGPMS_4_REQ_ID)
       END AS module_ident
     , ICS_COPY_MGPMS_4_REQ.action_type
     , ICS_COPY_MGPMS_4_REQ.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_COPY_MGPMS_4_REQ.ICS_COPY_MGPMS_4_REQ_ID
			 , ICS_COPY_MGPMS_4_REQ.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_COPY_MGPMS_4_REQ' as ics_module
          FROM dbo.ICS_COPY_MGPMS_4_REQ
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.dbo.ICS_COPY_MGPMS_4_REQ tbl
                            WHERE tbl.key_hash = ICS_COPY_MGPMS_4_REQ.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_COPY_MGPMS_4_REQ_ID
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_COPY_MGPMS_4_REQ' as ics_module
          FROM dbo.ICS_COPY_MGPMS_4_REQ local
          JOIN ics_flow_icis.dbo.ICS_COPY_MGPMS_4_REQ icis
            ON (icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash) 
        UNION
        /*  3 - DELETE  */
        SELECT ICS_COPY_MGPMS_4_REQ.ICS_COPY_MGPMS_4_REQ_ID
             , ICS_COPY_MGPMS_4_REQ.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_COPY_MGPMS_4_REQ' as ics_module
          FROM ics_flow_icis.dbo.ICS_COPY_MGPMS_4_REQ
         WHERE NOT EXISTS (SELECT 'x'
                             FROM dbo.ICS_COPY_MGPMS_4_REQ tbl
                            WHERE tbl.key_hash = ICS_COPY_MGPMS_4_REQ.key_hash)) ICS_COPY_MGPMS_4_REQ;
GO



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.CDV_CSO_LONG_TERM_CONTROL_PLAN') AND type = N'V')
  DROP VIEW dbo.CDV_CSO_LONG_TERM_CONTROL_PLAN
GO

/*************************************************************************************************
** ObjectName: dbo.CDV_CSO_LONG_TERM_CONTROL_PLAN
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Autogen: using helper: node .\run_template.js "all_cdv_views.js"
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/13/2016    Windsor     Baselined from v5.0 procedure. 
** 03/29/2025    Windsor     Recreate this 
**
***************************************************************************************************/
CREATE VIEW dbo.CDV_CSO_LONG_TERM_CONTROL_PLAN AS 
SELECT DISTINCT ics_module
, ICS_CSO_LONG_TERM_CONTROL_PLAN.key_hash
     , CASE ICS_CSO_LONG_TERM_CONTROL_PLAN.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.dbo.ICS_CSO_LONG_TERM_CONTROL_PLAN tbl
                  WHERE tbl.ICS_CSO_LONG_TERM_CONTROL_PLAN_ID = ICS_CSO_LONG_TERM_CONTROL_PLAN.ICS_CSO_LONG_TERM_CONTROL_PLAN_ID)
           ELSE (SELECT key_hash 
                   FROM dbo.ICS_CSO_LONG_TERM_CONTROL_PLAN tbl
                  WHERE tbl.ICS_CSO_LONG_TERM_CONTROL_PLAN_ID = ICS_CSO_LONG_TERM_CONTROL_PLAN.ICS_CSO_LONG_TERM_CONTROL_PLAN_ID)
       END AS module_ident
     , ICS_CSO_LONG_TERM_CONTROL_PLAN.action_type
     , ICS_CSO_LONG_TERM_CONTROL_PLAN.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_CSO_LONG_TERM_CONTROL_PLAN.ICS_CSO_LONG_TERM_CONTROL_PLAN_ID
			 , ICS_CSO_LONG_TERM_CONTROL_PLAN.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_CSO_LONG_TERM_CONTROL_PLAN' as ics_module
          FROM dbo.ICS_CSO_LONG_TERM_CONTROL_PLAN
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.dbo.ICS_CSO_LONG_TERM_CONTROL_PLAN tbl
                            WHERE tbl.key_hash = ICS_CSO_LONG_TERM_CONTROL_PLAN.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_CSO_LONG_TERM_CONTROL_PLAN_ID
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_CSO_LONG_TERM_CONTROL_PLAN' as ics_module
          FROM dbo.ICS_CSO_LONG_TERM_CONTROL_PLAN local
          JOIN ics_flow_icis.dbo.ICS_CSO_LONG_TERM_CONTROL_PLAN icis
            ON (icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash) 
        UNION
        /*  3 - DELETE  */
        SELECT ICS_CSO_LONG_TERM_CONTROL_PLAN.ICS_CSO_LONG_TERM_CONTROL_PLAN_ID
             , ICS_CSO_LONG_TERM_CONTROL_PLAN.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_CSO_LONG_TERM_CONTROL_PLAN' as ics_module
          FROM ics_flow_icis.dbo.ICS_CSO_LONG_TERM_CONTROL_PLAN
         WHERE NOT EXISTS (SELECT 'x'
                             FROM dbo.ICS_CSO_LONG_TERM_CONTROL_PLAN tbl
                            WHERE tbl.key_hash = ICS_CSO_LONG_TERM_CONTROL_PLAN.key_hash)) ICS_CSO_LONG_TERM_CONTROL_PLAN;
GO



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.CDV_CWA_316B_PROG_REP') AND type = N'V')
  DROP VIEW dbo.CDV_CWA_316B_PROG_REP
GO

/*************************************************************************************************
** ObjectName: dbo.CDV_CWA_316B_PROG_REP
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Autogen: using helper: node .\run_template.js "all_cdv_views.js"
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/13/2016    Windsor     Baselined from v5.0 procedure. 
** 03/29/2025    Windsor     Recreate this 
**
***************************************************************************************************/
CREATE VIEW dbo.CDV_CWA_316B_PROG_REP AS 
SELECT DISTINCT ics_module
, ICS_CWA_316B_PROG_REP.key_hash
     , CASE ICS_CWA_316B_PROG_REP.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.dbo.ICS_CWA_316B_PROG_REP tbl
                  WHERE tbl.ICS_CWA_316B_PROG_REP_ID = ICS_CWA_316B_PROG_REP.ICS_CWA_316B_PROG_REP_ID)
           ELSE (SELECT key_hash 
                   FROM dbo.ICS_CWA_316B_PROG_REP tbl
                  WHERE tbl.ICS_CWA_316B_PROG_REP_ID = ICS_CWA_316B_PROG_REP.ICS_CWA_316B_PROG_REP_ID)
       END AS module_ident
     , ICS_CWA_316B_PROG_REP.action_type
     , ICS_CWA_316B_PROG_REP.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_CWA_316B_PROG_REP.ICS_CWA_316B_PROG_REP_ID
			 , ICS_CWA_316B_PROG_REP.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_CWA_316B_PROG_REP' as ics_module
          FROM dbo.ICS_CWA_316B_PROG_REP
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.dbo.ICS_CWA_316B_PROG_REP tbl
                            WHERE tbl.key_hash = ICS_CWA_316B_PROG_REP.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_CWA_316B_PROG_REP_ID
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_CWA_316B_PROG_REP' as ics_module
          FROM dbo.ICS_CWA_316B_PROG_REP local
          JOIN ics_flow_icis.dbo.ICS_CWA_316B_PROG_REP icis
            ON (icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash) 
        UNION
        /*  3 - DELETE  */
        SELECT ICS_CWA_316B_PROG_REP.ICS_CWA_316B_PROG_REP_ID
             , ICS_CWA_316B_PROG_REP.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_CWA_316B_PROG_REP' as ics_module
          FROM ics_flow_icis.dbo.ICS_CWA_316B_PROG_REP
         WHERE NOT EXISTS (SELECT 'x'
                             FROM dbo.ICS_CWA_316B_PROG_REP tbl
                            WHERE tbl.key_hash = ICS_CWA_316B_PROG_REP.key_hash)) ICS_CWA_316B_PROG_REP;
GO



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.CDV_DSCH_MON_REP') AND type = N'V')
  DROP VIEW dbo.CDV_DSCH_MON_REP
GO

/*************************************************************************************************
** ObjectName: dbo.CDV_DSCH_MON_REP
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Autogen: using helper: node .\run_template.js "all_cdv_views.js"
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/13/2016    Windsor     Baselined from v5.0 procedure. 
** 03/29/2025    Windsor     Recreate this 
**
***************************************************************************************************/
CREATE VIEW dbo.CDV_DSCH_MON_REP AS 
SELECT DISTINCT ics_module
, ICS_DSCH_MON_REP.key_hash
     , CASE ICS_DSCH_MON_REP.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.dbo.ICS_DSCH_MON_REP tbl
                  WHERE tbl.ICS_DSCH_MON_REP_ID = ICS_DSCH_MON_REP.ICS_DSCH_MON_REP_ID)
           ELSE (SELECT key_hash 
                   FROM dbo.ICS_DSCH_MON_REP tbl
                  WHERE tbl.ICS_DSCH_MON_REP_ID = ICS_DSCH_MON_REP.ICS_DSCH_MON_REP_ID)
       END AS module_ident
     , ICS_DSCH_MON_REP.action_type
     , ICS_DSCH_MON_REP.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_DSCH_MON_REP.ICS_DSCH_MON_REP_ID
			 , ICS_DSCH_MON_REP.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_DSCH_MON_REP' as ics_module
          FROM dbo.ICS_DSCH_MON_REP
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.dbo.ICS_DSCH_MON_REP tbl
                            WHERE tbl.key_hash = ICS_DSCH_MON_REP.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_DSCH_MON_REP_ID
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_DSCH_MON_REP' as ics_module
          FROM dbo.ICS_DSCH_MON_REP local
          JOIN ics_flow_icis.dbo.ICS_DSCH_MON_REP icis
            ON (icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash) 
        UNION
        /*  3 - DELETE  */
        SELECT ICS_DSCH_MON_REP.ICS_DSCH_MON_REP_ID
             , ICS_DSCH_MON_REP.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_DSCH_MON_REP' as ics_module
          FROM ics_flow_icis.dbo.ICS_DSCH_MON_REP
         WHERE NOT EXISTS (SELECT 'x'
                             FROM dbo.ICS_DSCH_MON_REP tbl
                            WHERE tbl.key_hash = ICS_DSCH_MON_REP.key_hash)) ICS_DSCH_MON_REP;
GO



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.CDV_DMR_VIOL') AND type = N'V')
  DROP VIEW dbo.CDV_DMR_VIOL
GO

/*************************************************************************************************
** ObjectName: dbo.CDV_DMR_VIOL
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Autogen: using helper: node .\run_template.js "all_cdv_views.js"
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/13/2016    Windsor     Baselined from v5.0 procedure. 
** 03/29/2025    Windsor     Recreate this 
**
***************************************************************************************************/
CREATE VIEW dbo.CDV_DMR_VIOL AS 
SELECT DISTINCT ics_module
, ICS_DMR_VIOL.key_hash
     , CASE ICS_DMR_VIOL.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.dbo.ICS_DMR_VIOL tbl
                  WHERE tbl.ICS_DMR_VIOL_ID = ICS_DMR_VIOL.ICS_DMR_VIOL_ID)
           ELSE (SELECT key_hash 
                   FROM dbo.ICS_DMR_VIOL tbl
                  WHERE tbl.ICS_DMR_VIOL_ID = ICS_DMR_VIOL.ICS_DMR_VIOL_ID)
       END AS module_ident
     , ICS_DMR_VIOL.action_type
     , ICS_DMR_VIOL.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_DMR_VIOL.ICS_DMR_VIOL_ID
			 , ICS_DMR_VIOL.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_DMR_VIOL' as ics_module
          FROM dbo.ICS_DMR_VIOL
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.dbo.ICS_DMR_VIOL tbl
                            WHERE tbl.key_hash = ICS_DMR_VIOL.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_DMR_VIOL_ID
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_DMR_VIOL' as ics_module
          FROM dbo.ICS_DMR_VIOL local
          JOIN ics_flow_icis.dbo.ICS_DMR_VIOL icis
            ON (icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash) 
        UNION
        /*  3 - DELETE  */
        SELECT ICS_DMR_VIOL.ICS_DMR_VIOL_ID
             , ICS_DMR_VIOL.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_DMR_VIOL' as ics_module
          FROM ics_flow_icis.dbo.ICS_DMR_VIOL
         WHERE NOT EXISTS (SELECT 'x'
                             FROM dbo.ICS_DMR_VIOL tbl
                            WHERE tbl.key_hash = ICS_DMR_VIOL.key_hash)) ICS_DMR_VIOL;
GO



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.CDV_EFFLU_TRADE_PRTNER') AND type = N'V')
  DROP VIEW dbo.CDV_EFFLU_TRADE_PRTNER
GO

/*************************************************************************************************
** ObjectName: dbo.CDV_EFFLU_TRADE_PRTNER
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Autogen: using helper: node .\run_template.js "all_cdv_views.js"
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/13/2016    Windsor     Baselined from v5.0 procedure. 
** 03/29/2025    Windsor     Recreate this 
**
***************************************************************************************************/
CREATE VIEW dbo.CDV_EFFLU_TRADE_PRTNER AS 
SELECT DISTINCT ics_module
, ICS_EFFLU_TRADE_PRTNER.key_hash
     , CASE ICS_EFFLU_TRADE_PRTNER.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.dbo.ICS_EFFLU_TRADE_PRTNER tbl
                  WHERE tbl.ICS_EFFLU_TRADE_PRTNER_ID = ICS_EFFLU_TRADE_PRTNER.ICS_EFFLU_TRADE_PRTNER_ID)
           ELSE (SELECT key_hash 
                   FROM dbo.ICS_EFFLU_TRADE_PRTNER tbl
                  WHERE tbl.ICS_EFFLU_TRADE_PRTNER_ID = ICS_EFFLU_TRADE_PRTNER.ICS_EFFLU_TRADE_PRTNER_ID)
       END AS module_ident
     , ICS_EFFLU_TRADE_PRTNER.action_type
     , ICS_EFFLU_TRADE_PRTNER.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_EFFLU_TRADE_PRTNER.ICS_EFFLU_TRADE_PRTNER_ID
			 , ICS_EFFLU_TRADE_PRTNER.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_EFFLU_TRADE_PRTNER' as ics_module
          FROM dbo.ICS_EFFLU_TRADE_PRTNER
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.dbo.ICS_EFFLU_TRADE_PRTNER tbl
                            WHERE tbl.key_hash = ICS_EFFLU_TRADE_PRTNER.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_EFFLU_TRADE_PRTNER_ID
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_EFFLU_TRADE_PRTNER' as ics_module
          FROM dbo.ICS_EFFLU_TRADE_PRTNER local
          JOIN ics_flow_icis.dbo.ICS_EFFLU_TRADE_PRTNER icis
            ON (icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash) 
        UNION
        /*  3 - DELETE  */
        SELECT ICS_EFFLU_TRADE_PRTNER.ICS_EFFLU_TRADE_PRTNER_ID
             , ICS_EFFLU_TRADE_PRTNER.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_EFFLU_TRADE_PRTNER' as ics_module
          FROM ics_flow_icis.dbo.ICS_EFFLU_TRADE_PRTNER
         WHERE NOT EXISTS (SELECT 'x'
                             FROM dbo.ICS_EFFLU_TRADE_PRTNER tbl
                            WHERE tbl.key_hash = ICS_EFFLU_TRADE_PRTNER.key_hash)) ICS_EFFLU_TRADE_PRTNER;
GO



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.CDV_ENFRC_ACTN_MILESTONE') AND type = N'V')
  DROP VIEW dbo.CDV_ENFRC_ACTN_MILESTONE
GO

/*************************************************************************************************
** ObjectName: dbo.CDV_ENFRC_ACTN_MILESTONE
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Autogen: using helper: node .\run_template.js "all_cdv_views.js"
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/13/2016    Windsor     Baselined from v5.0 procedure. 
** 03/29/2025    Windsor     Recreate this 
**
***************************************************************************************************/
CREATE VIEW dbo.CDV_ENFRC_ACTN_MILESTONE AS 
SELECT DISTINCT ics_module
, ICS_ENFRC_ACTN_MILESTONE.key_hash
     , CASE ICS_ENFRC_ACTN_MILESTONE.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.dbo.ICS_ENFRC_ACTN_MILESTONE tbl
                  WHERE tbl.ICS_ENFRC_ACTN_MILESTONE_ID = ICS_ENFRC_ACTN_MILESTONE.ICS_ENFRC_ACTN_MILESTONE_ID)
           ELSE (SELECT key_hash 
                   FROM dbo.ICS_ENFRC_ACTN_MILESTONE tbl
                  WHERE tbl.ICS_ENFRC_ACTN_MILESTONE_ID = ICS_ENFRC_ACTN_MILESTONE.ICS_ENFRC_ACTN_MILESTONE_ID)
       END AS module_ident
     , ICS_ENFRC_ACTN_MILESTONE.action_type
     , ICS_ENFRC_ACTN_MILESTONE.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_ENFRC_ACTN_MILESTONE.ICS_ENFRC_ACTN_MILESTONE_ID
			 , ICS_ENFRC_ACTN_MILESTONE.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_ENFRC_ACTN_MILESTONE' as ics_module
          FROM dbo.ICS_ENFRC_ACTN_MILESTONE
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.dbo.ICS_ENFRC_ACTN_MILESTONE tbl
                            WHERE tbl.key_hash = ICS_ENFRC_ACTN_MILESTONE.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_ENFRC_ACTN_MILESTONE_ID
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_ENFRC_ACTN_MILESTONE' as ics_module
          FROM dbo.ICS_ENFRC_ACTN_MILESTONE local
          JOIN ics_flow_icis.dbo.ICS_ENFRC_ACTN_MILESTONE icis
            ON (icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash) 
        UNION
        /*  3 - DELETE  */
        SELECT ICS_ENFRC_ACTN_MILESTONE.ICS_ENFRC_ACTN_MILESTONE_ID
             , ICS_ENFRC_ACTN_MILESTONE.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_ENFRC_ACTN_MILESTONE' as ics_module
          FROM ics_flow_icis.dbo.ICS_ENFRC_ACTN_MILESTONE
         WHERE NOT EXISTS (SELECT 'x'
                             FROM dbo.ICS_ENFRC_ACTN_MILESTONE tbl
                            WHERE tbl.key_hash = ICS_ENFRC_ACTN_MILESTONE.key_hash)) ICS_ENFRC_ACTN_MILESTONE;
GO



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.CDV_ENFRC_ACTN_VIOL_LNK') AND type = N'V')
  DROP VIEW dbo.CDV_ENFRC_ACTN_VIOL_LNK
GO

/*************************************************************************************************
** ObjectName: dbo.CDV_ENFRC_ACTN_VIOL_LNK
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Autogen: using helper: node .\run_template.js "all_cdv_views.js"
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/13/2016    Windsor     Baselined from v5.0 procedure. 
** 03/29/2025    Windsor     Recreate this 
**
***************************************************************************************************/
CREATE VIEW dbo.CDV_ENFRC_ACTN_VIOL_LNK AS 
SELECT DISTINCT ics_module
, ICS_ENFRC_ACTN_VIOL_LNK.key_hash
     , CASE ICS_ENFRC_ACTN_VIOL_LNK.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.dbo.ICS_ENFRC_ACTN_VIOL_LNK tbl
                  WHERE tbl.ICS_ENFRC_ACTN_VIOL_LNK_ID = ICS_ENFRC_ACTN_VIOL_LNK.ICS_ENFRC_ACTN_VIOL_LNK_ID)
           ELSE (SELECT key_hash 
                   FROM dbo.ICS_ENFRC_ACTN_VIOL_LNK tbl
                  WHERE tbl.ICS_ENFRC_ACTN_VIOL_LNK_ID = ICS_ENFRC_ACTN_VIOL_LNK.ICS_ENFRC_ACTN_VIOL_LNK_ID)
       END AS module_ident
     , ICS_ENFRC_ACTN_VIOL_LNK.action_type
     , ICS_ENFRC_ACTN_VIOL_LNK.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_ENFRC_ACTN_VIOL_LNK.ICS_ENFRC_ACTN_VIOL_LNK_ID
			 , ICS_ENFRC_ACTN_VIOL_LNK.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_ENFRC_ACTN_VIOL_LNK' as ics_module
          FROM dbo.ICS_ENFRC_ACTN_VIOL_LNK
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.dbo.ICS_ENFRC_ACTN_VIOL_LNK tbl
                            WHERE tbl.key_hash = ICS_ENFRC_ACTN_VIOL_LNK.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_ENFRC_ACTN_VIOL_LNK_ID
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_ENFRC_ACTN_VIOL_LNK' as ics_module
          FROM dbo.ICS_ENFRC_ACTN_VIOL_LNK local
          JOIN ics_flow_icis.dbo.ICS_ENFRC_ACTN_VIOL_LNK icis
            ON (icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash) 
        UNION
        /*  3 - DELETE  */
        SELECT ICS_ENFRC_ACTN_VIOL_LNK.ICS_ENFRC_ACTN_VIOL_LNK_ID
             , ICS_ENFRC_ACTN_VIOL_LNK.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_ENFRC_ACTN_VIOL_LNK' as ics_module
          FROM ics_flow_icis.dbo.ICS_ENFRC_ACTN_VIOL_LNK
         WHERE NOT EXISTS (SELECT 'x'
                             FROM dbo.ICS_ENFRC_ACTN_VIOL_LNK tbl
                            WHERE tbl.key_hash = ICS_ENFRC_ACTN_VIOL_LNK.key_hash)) ICS_ENFRC_ACTN_VIOL_LNK;
GO



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.CDV_FINAL_ORDER_VIOL_LNK') AND type = N'V')
  DROP VIEW dbo.CDV_FINAL_ORDER_VIOL_LNK
GO

/*************************************************************************************************
** ObjectName: dbo.CDV_FINAL_ORDER_VIOL_LNK
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Autogen: using helper: node .\run_template.js "all_cdv_views.js"
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/13/2016    Windsor     Baselined from v5.0 procedure. 
** 03/29/2025    Windsor     Recreate this 
**
***************************************************************************************************/
CREATE VIEW dbo.CDV_FINAL_ORDER_VIOL_LNK AS 
SELECT DISTINCT ics_module
, ICS_FINAL_ORDER_VIOL_LNK.key_hash
     , CASE ICS_FINAL_ORDER_VIOL_LNK.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.dbo.ICS_FINAL_ORDER_VIOL_LNK tbl
                  WHERE tbl.ICS_FINAL_ORDER_VIOL_LNK_ID = ICS_FINAL_ORDER_VIOL_LNK.ICS_FINAL_ORDER_VIOL_LNK_ID)
           ELSE (SELECT key_hash 
                   FROM dbo.ICS_FINAL_ORDER_VIOL_LNK tbl
                  WHERE tbl.ICS_FINAL_ORDER_VIOL_LNK_ID = ICS_FINAL_ORDER_VIOL_LNK.ICS_FINAL_ORDER_VIOL_LNK_ID)
       END AS module_ident
     , ICS_FINAL_ORDER_VIOL_LNK.action_type
     , ICS_FINAL_ORDER_VIOL_LNK.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_FINAL_ORDER_VIOL_LNK.ICS_FINAL_ORDER_VIOL_LNK_ID
			 , ICS_FINAL_ORDER_VIOL_LNK.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_FINAL_ORDER_VIOL_LNK' as ics_module
          FROM dbo.ICS_FINAL_ORDER_VIOL_LNK
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.dbo.ICS_FINAL_ORDER_VIOL_LNK tbl
                            WHERE tbl.key_hash = ICS_FINAL_ORDER_VIOL_LNK.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_FINAL_ORDER_VIOL_LNK_ID
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_FINAL_ORDER_VIOL_LNK' as ics_module
          FROM dbo.ICS_FINAL_ORDER_VIOL_LNK local
          JOIN ics_flow_icis.dbo.ICS_FINAL_ORDER_VIOL_LNK icis
            ON (icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash) 
        UNION
        /*  3 - DELETE  */
        SELECT ICS_FINAL_ORDER_VIOL_LNK.ICS_FINAL_ORDER_VIOL_LNK_ID
             , ICS_FINAL_ORDER_VIOL_LNK.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_FINAL_ORDER_VIOL_LNK' as ics_module
          FROM ics_flow_icis.dbo.ICS_FINAL_ORDER_VIOL_LNK
         WHERE NOT EXISTS (SELECT 'x'
                             FROM dbo.ICS_FINAL_ORDER_VIOL_LNK tbl
                            WHERE tbl.key_hash = ICS_FINAL_ORDER_VIOL_LNK.key_hash)) ICS_FINAL_ORDER_VIOL_LNK;
GO



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.CDV_FRML_ENFRC_ACTN') AND type = N'V')
  DROP VIEW dbo.CDV_FRML_ENFRC_ACTN
GO

/*************************************************************************************************
** ObjectName: dbo.CDV_FRML_ENFRC_ACTN
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Autogen: using helper: node .\run_template.js "all_cdv_views.js"
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/13/2016    Windsor     Baselined from v5.0 procedure. 
** 03/29/2025    Windsor     Recreate this 
**
***************************************************************************************************/
CREATE VIEW dbo.CDV_FRML_ENFRC_ACTN AS 
SELECT DISTINCT ics_module
, ICS_FRML_ENFRC_ACTN.key_hash
     , CASE ICS_FRML_ENFRC_ACTN.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.dbo.ICS_FRML_ENFRC_ACTN tbl
                  WHERE tbl.ICS_FRML_ENFRC_ACTN_ID = ICS_FRML_ENFRC_ACTN.ICS_FRML_ENFRC_ACTN_ID)
           ELSE (SELECT key_hash 
                   FROM dbo.ICS_FRML_ENFRC_ACTN tbl
                  WHERE tbl.ICS_FRML_ENFRC_ACTN_ID = ICS_FRML_ENFRC_ACTN.ICS_FRML_ENFRC_ACTN_ID)
       END AS module_ident
     , ICS_FRML_ENFRC_ACTN.action_type
     , ICS_FRML_ENFRC_ACTN.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_FRML_ENFRC_ACTN.ICS_FRML_ENFRC_ACTN_ID
			 , ICS_FRML_ENFRC_ACTN.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_FRML_ENFRC_ACTN' as ics_module
          FROM dbo.ICS_FRML_ENFRC_ACTN
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.dbo.ICS_FRML_ENFRC_ACTN tbl
                            WHERE tbl.key_hash = ICS_FRML_ENFRC_ACTN.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_FRML_ENFRC_ACTN_ID
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_FRML_ENFRC_ACTN' as ics_module
          FROM dbo.ICS_FRML_ENFRC_ACTN local
          JOIN ics_flow_icis.dbo.ICS_FRML_ENFRC_ACTN icis
            ON (icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash) 
        UNION
        /*  3 - DELETE  */
        SELECT ICS_FRML_ENFRC_ACTN.ICS_FRML_ENFRC_ACTN_ID
             , ICS_FRML_ENFRC_ACTN.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_FRML_ENFRC_ACTN' as ics_module
          FROM ics_flow_icis.dbo.ICS_FRML_ENFRC_ACTN
         WHERE NOT EXISTS (SELECT 'x'
                             FROM dbo.ICS_FRML_ENFRC_ACTN tbl
                            WHERE tbl.key_hash = ICS_FRML_ENFRC_ACTN.key_hash)) ICS_FRML_ENFRC_ACTN;
GO



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.CDV_GNRL_PRMT') AND type = N'V')
  DROP VIEW dbo.CDV_GNRL_PRMT
GO

/*************************************************************************************************
** ObjectName: dbo.CDV_GNRL_PRMT
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Autogen: using helper: node .\run_template.js "all_cdv_views.js"
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/13/2016    Windsor     Baselined from v5.0 procedure. 
** 03/29/2025    Windsor     Recreate this 
**
***************************************************************************************************/
CREATE VIEW dbo.CDV_GNRL_PRMT AS 
SELECT DISTINCT ics_module
, ICS_GNRL_PRMT.key_hash
     , CASE ICS_GNRL_PRMT.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.dbo.ICS_GNRL_PRMT tbl
                  WHERE tbl.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID)
           ELSE (SELECT key_hash 
                   FROM dbo.ICS_GNRL_PRMT tbl
                  WHERE tbl.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID)
       END AS module_ident
     , ICS_GNRL_PRMT.action_type
     , ICS_GNRL_PRMT.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
			 , ICS_GNRL_PRMT.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_GNRL_PRMT' as ics_module
          FROM dbo.ICS_GNRL_PRMT
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.dbo.ICS_GNRL_PRMT tbl
                            WHERE tbl.key_hash = ICS_GNRL_PRMT.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_GNRL_PRMT_ID
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_GNRL_PRMT' as ics_module
          FROM dbo.ICS_GNRL_PRMT local
          JOIN ics_flow_icis.dbo.ICS_GNRL_PRMT icis
            ON (icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash) 
        UNION
        /*  3 - DELETE  */
        SELECT ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
             , ICS_GNRL_PRMT.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_GNRL_PRMT' as ics_module
          FROM ics_flow_icis.dbo.ICS_GNRL_PRMT
         WHERE NOT EXISTS (SELECT 'x'
                             FROM dbo.ICS_GNRL_PRMT tbl
                            WHERE tbl.key_hash = ICS_GNRL_PRMT.key_hash)) ICS_GNRL_PRMT;
GO



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.CDV_HIST_PRMT_SCHD_EVTS') AND type = N'V')
  DROP VIEW dbo.CDV_HIST_PRMT_SCHD_EVTS
GO

/*************************************************************************************************
** ObjectName: dbo.CDV_HIST_PRMT_SCHD_EVTS
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Autogen: using helper: node .\run_template.js "all_cdv_views.js"
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/13/2016    Windsor     Baselined from v5.0 procedure. 
** 03/29/2025    Windsor     Recreate this 
**
***************************************************************************************************/
CREATE VIEW dbo.CDV_HIST_PRMT_SCHD_EVTS AS 
SELECT DISTINCT ics_module
, ICS_HIST_PRMT_SCHD_EVTS.key_hash
     , CASE ICS_HIST_PRMT_SCHD_EVTS.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.dbo.ICS_HIST_PRMT_SCHD_EVTS tbl
                  WHERE tbl.ICS_HIST_PRMT_SCHD_EVTS_ID = ICS_HIST_PRMT_SCHD_EVTS.ICS_HIST_PRMT_SCHD_EVTS_ID)
           ELSE (SELECT key_hash 
                   FROM dbo.ICS_HIST_PRMT_SCHD_EVTS tbl
                  WHERE tbl.ICS_HIST_PRMT_SCHD_EVTS_ID = ICS_HIST_PRMT_SCHD_EVTS.ICS_HIST_PRMT_SCHD_EVTS_ID)
       END AS module_ident
     , ICS_HIST_PRMT_SCHD_EVTS.action_type
     , ICS_HIST_PRMT_SCHD_EVTS.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_HIST_PRMT_SCHD_EVTS.ICS_HIST_PRMT_SCHD_EVTS_ID
			 , ICS_HIST_PRMT_SCHD_EVTS.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_HIST_PRMT_SCHD_EVTS' as ics_module
          FROM dbo.ICS_HIST_PRMT_SCHD_EVTS
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.dbo.ICS_HIST_PRMT_SCHD_EVTS tbl
                            WHERE tbl.key_hash = ICS_HIST_PRMT_SCHD_EVTS.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_HIST_PRMT_SCHD_EVTS_ID
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_HIST_PRMT_SCHD_EVTS' as ics_module
          FROM dbo.ICS_HIST_PRMT_SCHD_EVTS local
          JOIN ics_flow_icis.dbo.ICS_HIST_PRMT_SCHD_EVTS icis
            ON (icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash) 
        UNION
        /*  3 - DELETE  */
        SELECT ICS_HIST_PRMT_SCHD_EVTS.ICS_HIST_PRMT_SCHD_EVTS_ID
             , ICS_HIST_PRMT_SCHD_EVTS.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_HIST_PRMT_SCHD_EVTS' as ics_module
          FROM ics_flow_icis.dbo.ICS_HIST_PRMT_SCHD_EVTS
         WHERE NOT EXISTS (SELECT 'x'
                             FROM dbo.ICS_HIST_PRMT_SCHD_EVTS tbl
                            WHERE tbl.key_hash = ICS_HIST_PRMT_SCHD_EVTS.key_hash)) ICS_HIST_PRMT_SCHD_EVTS;
GO



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.CDV_INFRML_ENFRC_ACTN') AND type = N'V')
  DROP VIEW dbo.CDV_INFRML_ENFRC_ACTN
GO

/*************************************************************************************************
** ObjectName: dbo.CDV_INFRML_ENFRC_ACTN
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Autogen: using helper: node .\run_template.js "all_cdv_views.js"
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/13/2016    Windsor     Baselined from v5.0 procedure. 
** 03/29/2025    Windsor     Recreate this 
**
***************************************************************************************************/
CREATE VIEW dbo.CDV_INFRML_ENFRC_ACTN AS 
SELECT DISTINCT ics_module
, ICS_INFRML_ENFRC_ACTN.key_hash
     , CASE ICS_INFRML_ENFRC_ACTN.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.dbo.ICS_INFRML_ENFRC_ACTN tbl
                  WHERE tbl.ICS_INFRML_ENFRC_ACTN_ID = ICS_INFRML_ENFRC_ACTN.ICS_INFRML_ENFRC_ACTN_ID)
           ELSE (SELECT key_hash 
                   FROM dbo.ICS_INFRML_ENFRC_ACTN tbl
                  WHERE tbl.ICS_INFRML_ENFRC_ACTN_ID = ICS_INFRML_ENFRC_ACTN.ICS_INFRML_ENFRC_ACTN_ID)
       END AS module_ident
     , ICS_INFRML_ENFRC_ACTN.action_type
     , ICS_INFRML_ENFRC_ACTN.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_INFRML_ENFRC_ACTN.ICS_INFRML_ENFRC_ACTN_ID
			 , ICS_INFRML_ENFRC_ACTN.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_INFRML_ENFRC_ACTN' as ics_module
          FROM dbo.ICS_INFRML_ENFRC_ACTN
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.dbo.ICS_INFRML_ENFRC_ACTN tbl
                            WHERE tbl.key_hash = ICS_INFRML_ENFRC_ACTN.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_INFRML_ENFRC_ACTN_ID
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_INFRML_ENFRC_ACTN' as ics_module
          FROM dbo.ICS_INFRML_ENFRC_ACTN local
          JOIN ics_flow_icis.dbo.ICS_INFRML_ENFRC_ACTN icis
            ON (icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash) 
        UNION
        /*  3 - DELETE  */
        SELECT ICS_INFRML_ENFRC_ACTN.ICS_INFRML_ENFRC_ACTN_ID
             , ICS_INFRML_ENFRC_ACTN.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_INFRML_ENFRC_ACTN' as ics_module
          FROM ics_flow_icis.dbo.ICS_INFRML_ENFRC_ACTN
         WHERE NOT EXISTS (SELECT 'x'
                             FROM dbo.ICS_INFRML_ENFRC_ACTN tbl
                            WHERE tbl.key_hash = ICS_INFRML_ENFRC_ACTN.key_hash)) ICS_INFRML_ENFRC_ACTN;
GO



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.CDV_LMTS') AND type = N'V')
  DROP VIEW dbo.CDV_LMTS
GO

/*************************************************************************************************
** ObjectName: dbo.CDV_LMTS
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Autogen: using helper: node .\run_template.js "all_cdv_views.js"
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/13/2016    Windsor     Baselined from v5.0 procedure. 
** 03/29/2025    Windsor     Recreate this 
**
***************************************************************************************************/
CREATE VIEW dbo.CDV_LMTS AS 
SELECT DISTINCT ics_module
, ICS_LMTS.key_hash
     , CASE ICS_LMTS.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.dbo.ICS_LMTS tbl
                  WHERE tbl.ICS_LMTS_ID = ICS_LMTS.ICS_LMTS_ID)
           ELSE (SELECT key_hash 
                   FROM dbo.ICS_LMTS tbl
                  WHERE tbl.ICS_LMTS_ID = ICS_LMTS.ICS_LMTS_ID)
       END AS module_ident
     , ICS_LMTS.action_type
     , ICS_LMTS.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_LMTS.ICS_LMTS_ID
			 , ICS_LMTS.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_LMTS' as ics_module
          FROM dbo.ICS_LMTS
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.dbo.ICS_LMTS tbl
                            WHERE tbl.key_hash = ICS_LMTS.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_LMTS_ID
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_LMTS' as ics_module
          FROM dbo.ICS_LMTS local
          JOIN ics_flow_icis.dbo.ICS_LMTS icis
            ON (icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash) 
        UNION
        /*  3 - DELETE  */
        SELECT ICS_LMTS.ICS_LMTS_ID
             , ICS_LMTS.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_LMTS' as ics_module
          FROM ics_flow_icis.dbo.ICS_LMTS
         WHERE NOT EXISTS (SELECT 'x'
                             FROM dbo.ICS_LMTS tbl
                            WHERE tbl.key_hash = ICS_LMTS.key_hash)) ICS_LMTS;
GO



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.CDV_LMT_SET') AND type = N'V')
  DROP VIEW dbo.CDV_LMT_SET
GO

/*************************************************************************************************
** ObjectName: dbo.CDV_LMT_SET
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Autogen: using helper: node .\run_template.js "all_cdv_views.js"
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/13/2016    Windsor     Baselined from v5.0 procedure. 
** 03/29/2025    Windsor     Recreate this 
**
***************************************************************************************************/
CREATE VIEW dbo.CDV_LMT_SET AS 
SELECT DISTINCT ics_module
, ICS_LMT_SET.key_hash
     , CASE ICS_LMT_SET.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.dbo.ICS_LMT_SET tbl
                  WHERE tbl.ICS_LMT_SET_ID = ICS_LMT_SET.ICS_LMT_SET_ID)
           ELSE (SELECT key_hash 
                   FROM dbo.ICS_LMT_SET tbl
                  WHERE tbl.ICS_LMT_SET_ID = ICS_LMT_SET.ICS_LMT_SET_ID)
       END AS module_ident
     , ICS_LMT_SET.action_type
     , ICS_LMT_SET.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_LMT_SET.ICS_LMT_SET_ID
			 , ICS_LMT_SET.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_LMT_SET' as ics_module
          FROM dbo.ICS_LMT_SET
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.dbo.ICS_LMT_SET tbl
                            WHERE tbl.key_hash = ICS_LMT_SET.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_LMT_SET_ID
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_LMT_SET' as ics_module
          FROM dbo.ICS_LMT_SET local
          JOIN ics_flow_icis.dbo.ICS_LMT_SET icis
            ON (icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash) 
        UNION
        /*  3 - DELETE  */
        SELECT ICS_LMT_SET.ICS_LMT_SET_ID
             , ICS_LMT_SET.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_LMT_SET' as ics_module
          FROM ics_flow_icis.dbo.ICS_LMT_SET
         WHERE NOT EXISTS (SELECT 'x'
                             FROM dbo.ICS_LMT_SET tbl
                            WHERE tbl.key_hash = ICS_LMT_SET.key_hash)) ICS_LMT_SET;
GO



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.CDV_MASTER_GNRL_PRMT') AND type = N'V')
  DROP VIEW dbo.CDV_MASTER_GNRL_PRMT
GO

/*************************************************************************************************
** ObjectName: dbo.CDV_MASTER_GNRL_PRMT
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Autogen: using helper: node .\run_template.js "all_cdv_views.js"
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/13/2016    Windsor     Baselined from v5.0 procedure. 
** 03/29/2025    Windsor     Recreate this 
**
***************************************************************************************************/
CREATE VIEW dbo.CDV_MASTER_GNRL_PRMT AS 
SELECT DISTINCT ics_module
, ICS_MASTER_GNRL_PRMT.key_hash
     , CASE ICS_MASTER_GNRL_PRMT.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.dbo.ICS_MASTER_GNRL_PRMT tbl
                  WHERE tbl.ICS_MASTER_GNRL_PRMT_ID = ICS_MASTER_GNRL_PRMT.ICS_MASTER_GNRL_PRMT_ID)
           ELSE (SELECT key_hash 
                   FROM dbo.ICS_MASTER_GNRL_PRMT tbl
                  WHERE tbl.ICS_MASTER_GNRL_PRMT_ID = ICS_MASTER_GNRL_PRMT.ICS_MASTER_GNRL_PRMT_ID)
       END AS module_ident
     , ICS_MASTER_GNRL_PRMT.action_type
     , ICS_MASTER_GNRL_PRMT.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_MASTER_GNRL_PRMT.ICS_MASTER_GNRL_PRMT_ID
			 , ICS_MASTER_GNRL_PRMT.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_MASTER_GNRL_PRMT' as ics_module
          FROM dbo.ICS_MASTER_GNRL_PRMT
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.dbo.ICS_MASTER_GNRL_PRMT tbl
                            WHERE tbl.key_hash = ICS_MASTER_GNRL_PRMT.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_MASTER_GNRL_PRMT_ID
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_MASTER_GNRL_PRMT' as ics_module
          FROM dbo.ICS_MASTER_GNRL_PRMT local
          JOIN ics_flow_icis.dbo.ICS_MASTER_GNRL_PRMT icis
            ON (icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash) 
        UNION
        /*  3 - DELETE  */
        SELECT ICS_MASTER_GNRL_PRMT.ICS_MASTER_GNRL_PRMT_ID
             , ICS_MASTER_GNRL_PRMT.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_MASTER_GNRL_PRMT' as ics_module
          FROM ics_flow_icis.dbo.ICS_MASTER_GNRL_PRMT
         WHERE NOT EXISTS (SELECT 'x'
                             FROM dbo.ICS_MASTER_GNRL_PRMT tbl
                            WHERE tbl.key_hash = ICS_MASTER_GNRL_PRMT.key_hash)) ICS_MASTER_GNRL_PRMT;
GO



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.CDV_NARR_COND_SCHD') AND type = N'V')
  DROP VIEW dbo.CDV_NARR_COND_SCHD
GO

/*************************************************************************************************
** ObjectName: dbo.CDV_NARR_COND_SCHD
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Autogen: using helper: node .\run_template.js "all_cdv_views.js"
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/13/2016    Windsor     Baselined from v5.0 procedure. 
** 03/29/2025    Windsor     Recreate this 
**
***************************************************************************************************/
CREATE VIEW dbo.CDV_NARR_COND_SCHD AS 
SELECT DISTINCT ics_module
, ICS_NARR_COND_SCHD.key_hash
     , CASE ICS_NARR_COND_SCHD.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.dbo.ICS_NARR_COND_SCHD tbl
                  WHERE tbl.ICS_NARR_COND_SCHD_ID = ICS_NARR_COND_SCHD.ICS_NARR_COND_SCHD_ID)
           ELSE (SELECT key_hash 
                   FROM dbo.ICS_NARR_COND_SCHD tbl
                  WHERE tbl.ICS_NARR_COND_SCHD_ID = ICS_NARR_COND_SCHD.ICS_NARR_COND_SCHD_ID)
       END AS module_ident
     , ICS_NARR_COND_SCHD.action_type
     , ICS_NARR_COND_SCHD.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_NARR_COND_SCHD.ICS_NARR_COND_SCHD_ID
			 , ICS_NARR_COND_SCHD.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_NARR_COND_SCHD' as ics_module
          FROM dbo.ICS_NARR_COND_SCHD
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.dbo.ICS_NARR_COND_SCHD tbl
                            WHERE tbl.key_hash = ICS_NARR_COND_SCHD.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_NARR_COND_SCHD_ID
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_NARR_COND_SCHD' as ics_module
          FROM dbo.ICS_NARR_COND_SCHD local
          JOIN ics_flow_icis.dbo.ICS_NARR_COND_SCHD icis
            ON (icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash) 
        UNION
        /*  3 - DELETE  */
        SELECT ICS_NARR_COND_SCHD.ICS_NARR_COND_SCHD_ID
             , ICS_NARR_COND_SCHD.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_NARR_COND_SCHD' as ics_module
          FROM ics_flow_icis.dbo.ICS_NARR_COND_SCHD
         WHERE NOT EXISTS (SELECT 'x'
                             FROM dbo.ICS_NARR_COND_SCHD tbl
                            WHERE tbl.key_hash = ICS_NARR_COND_SCHD.key_hash)) ICS_NARR_COND_SCHD;
GO



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.CDV_NPDES_VARIANCE_PRMT') AND type = N'V')
  DROP VIEW dbo.CDV_NPDES_VARIANCE_PRMT
GO

/*************************************************************************************************
** ObjectName: dbo.CDV_NPDES_VARIANCE_PRMT
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Autogen: using helper: node .\run_template.js "all_cdv_views.js"
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/13/2016    Windsor     Baselined from v5.0 procedure. 
** 03/29/2025    Windsor     Recreate this 
**
***************************************************************************************************/
CREATE VIEW dbo.CDV_NPDES_VARIANCE_PRMT AS 
SELECT DISTINCT ics_module
, ICS_NPDES_VARIANCE_PRMT.key_hash
     , CASE ICS_NPDES_VARIANCE_PRMT.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.dbo.ICS_NPDES_VARIANCE_PRMT tbl
                  WHERE tbl.ICS_NPDES_VARIANCE_PRMT_ID = ICS_NPDES_VARIANCE_PRMT.ICS_NPDES_VARIANCE_PRMT_ID)
           ELSE (SELECT key_hash 
                   FROM dbo.ICS_NPDES_VARIANCE_PRMT tbl
                  WHERE tbl.ICS_NPDES_VARIANCE_PRMT_ID = ICS_NPDES_VARIANCE_PRMT.ICS_NPDES_VARIANCE_PRMT_ID)
       END AS module_ident
     , ICS_NPDES_VARIANCE_PRMT.action_type
     , ICS_NPDES_VARIANCE_PRMT.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_NPDES_VARIANCE_PRMT.ICS_NPDES_VARIANCE_PRMT_ID
			 , ICS_NPDES_VARIANCE_PRMT.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_NPDES_VARIANCE_PRMT' as ics_module
          FROM dbo.ICS_NPDES_VARIANCE_PRMT
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.dbo.ICS_NPDES_VARIANCE_PRMT tbl
                            WHERE tbl.key_hash = ICS_NPDES_VARIANCE_PRMT.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_NPDES_VARIANCE_PRMT_ID
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_NPDES_VARIANCE_PRMT' as ics_module
          FROM dbo.ICS_NPDES_VARIANCE_PRMT local
          JOIN ics_flow_icis.dbo.ICS_NPDES_VARIANCE_PRMT icis
            ON (icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash) 
        UNION
        /*  3 - DELETE  */
        SELECT ICS_NPDES_VARIANCE_PRMT.ICS_NPDES_VARIANCE_PRMT_ID
             , ICS_NPDES_VARIANCE_PRMT.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_NPDES_VARIANCE_PRMT' as ics_module
          FROM ics_flow_icis.dbo.ICS_NPDES_VARIANCE_PRMT
         WHERE NOT EXISTS (SELECT 'x'
                             FROM dbo.ICS_NPDES_VARIANCE_PRMT tbl
                            WHERE tbl.key_hash = ICS_NPDES_VARIANCE_PRMT.key_hash)) ICS_NPDES_VARIANCE_PRMT;
GO



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.CDV_PARAM_LMTS') AND type = N'V')
  DROP VIEW dbo.CDV_PARAM_LMTS
GO

/*************************************************************************************************
** ObjectName: dbo.CDV_PARAM_LMTS
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Autogen: using helper: node .\run_template.js "all_cdv_views.js"
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/13/2016    Windsor     Baselined from v5.0 procedure. 
** 03/29/2025    Windsor     Recreate this 
**
***************************************************************************************************/
CREATE VIEW dbo.CDV_PARAM_LMTS AS 
SELECT DISTINCT ics_module
, ICS_PARAM_LMTS.key_hash
     , CASE ICS_PARAM_LMTS.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.dbo.ICS_PARAM_LMTS tbl
                  WHERE tbl.ICS_PARAM_LMTS_ID = ICS_PARAM_LMTS.ICS_PARAM_LMTS_ID)
           ELSE (SELECT key_hash 
                   FROM dbo.ICS_PARAM_LMTS tbl
                  WHERE tbl.ICS_PARAM_LMTS_ID = ICS_PARAM_LMTS.ICS_PARAM_LMTS_ID)
       END AS module_ident
     , ICS_PARAM_LMTS.action_type
     , ICS_PARAM_LMTS.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_PARAM_LMTS.ICS_PARAM_LMTS_ID
			 , ICS_PARAM_LMTS.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_PARAM_LMTS' as ics_module
          FROM dbo.ICS_PARAM_LMTS
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.dbo.ICS_PARAM_LMTS tbl
                            WHERE tbl.key_hash = ICS_PARAM_LMTS.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_PARAM_LMTS_ID
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_PARAM_LMTS' as ics_module
          FROM dbo.ICS_PARAM_LMTS local
          JOIN ics_flow_icis.dbo.ICS_PARAM_LMTS icis
            ON (icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash) 
        UNION
        /*  3 - DELETE  */
        SELECT ICS_PARAM_LMTS.ICS_PARAM_LMTS_ID
             , ICS_PARAM_LMTS.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_PARAM_LMTS' as ics_module
          FROM ics_flow_icis.dbo.ICS_PARAM_LMTS
         WHERE NOT EXISTS (SELECT 'x'
                             FROM dbo.ICS_PARAM_LMTS tbl
                            WHERE tbl.key_hash = ICS_PARAM_LMTS.key_hash)) ICS_PARAM_LMTS;
GO



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.CDV_PRMT_REISSU') AND type = N'V')
  DROP VIEW dbo.CDV_PRMT_REISSU
GO

/*************************************************************************************************
** ObjectName: dbo.CDV_PRMT_REISSU
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Autogen: using helper: node .\run_template.js "all_cdv_views.js"
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/13/2016    Windsor     Baselined from v5.0 procedure. 
** 03/29/2025    Windsor     Recreate this 
**
***************************************************************************************************/
CREATE VIEW dbo.CDV_PRMT_REISSU AS 
SELECT DISTINCT ics_module
, ICS_PRMT_REISSU.key_hash
     , CASE ICS_PRMT_REISSU.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.dbo.ICS_PRMT_REISSU tbl
                  WHERE tbl.ICS_PRMT_REISSU_ID = ICS_PRMT_REISSU.ICS_PRMT_REISSU_ID)
           ELSE (SELECT key_hash 
                   FROM dbo.ICS_PRMT_REISSU tbl
                  WHERE tbl.ICS_PRMT_REISSU_ID = ICS_PRMT_REISSU.ICS_PRMT_REISSU_ID)
       END AS module_ident
     , ICS_PRMT_REISSU.action_type
     , ICS_PRMT_REISSU.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_PRMT_REISSU.ICS_PRMT_REISSU_ID
			 , ICS_PRMT_REISSU.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_PRMT_REISSU' as ics_module
          FROM dbo.ICS_PRMT_REISSU
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.dbo.ICS_PRMT_REISSU tbl
                            WHERE tbl.key_hash = ICS_PRMT_REISSU.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_PRMT_REISSU_ID
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_PRMT_REISSU' as ics_module
          FROM dbo.ICS_PRMT_REISSU local
          JOIN ics_flow_icis.dbo.ICS_PRMT_REISSU icis
            ON (icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash) 
        UNION
        /*  3 - DELETE  */
        SELECT ICS_PRMT_REISSU.ICS_PRMT_REISSU_ID
             , ICS_PRMT_REISSU.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_PRMT_REISSU' as ics_module
          FROM ics_flow_icis.dbo.ICS_PRMT_REISSU
         WHERE NOT EXISTS (SELECT 'x'
                             FROM dbo.ICS_PRMT_REISSU tbl
                            WHERE tbl.key_hash = ICS_PRMT_REISSU.key_hash)) ICS_PRMT_REISSU;
GO



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.CDV_PRMT_FEATR') AND type = N'V')
  DROP VIEW dbo.CDV_PRMT_FEATR
GO

/*************************************************************************************************
** ObjectName: dbo.CDV_PRMT_FEATR
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Autogen: using helper: node .\run_template.js "all_cdv_views.js"
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/13/2016    Windsor     Baselined from v5.0 procedure. 
** 03/29/2025    Windsor     Recreate this 
**
***************************************************************************************************/
CREATE VIEW dbo.CDV_PRMT_FEATR AS 
SELECT DISTINCT ics_module
, ICS_PRMT_FEATR.key_hash
     , CASE ICS_PRMT_FEATR.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.dbo.ICS_PRMT_FEATR tbl
                  WHERE tbl.ICS_PRMT_FEATR_ID = ICS_PRMT_FEATR.ICS_PRMT_FEATR_ID)
           ELSE (SELECT key_hash 
                   FROM dbo.ICS_PRMT_FEATR tbl
                  WHERE tbl.ICS_PRMT_FEATR_ID = ICS_PRMT_FEATR.ICS_PRMT_FEATR_ID)
       END AS module_ident
     , ICS_PRMT_FEATR.action_type
     , ICS_PRMT_FEATR.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_PRMT_FEATR.ICS_PRMT_FEATR_ID
			 , ICS_PRMT_FEATR.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_PRMT_FEATR' as ics_module
          FROM dbo.ICS_PRMT_FEATR
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.dbo.ICS_PRMT_FEATR tbl
                            WHERE tbl.key_hash = ICS_PRMT_FEATR.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_PRMT_FEATR_ID
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_PRMT_FEATR' as ics_module
          FROM dbo.ICS_PRMT_FEATR local
          JOIN ics_flow_icis.dbo.ICS_PRMT_FEATR icis
            ON (icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash) 
        UNION
        /*  3 - DELETE  */
        SELECT ICS_PRMT_FEATR.ICS_PRMT_FEATR_ID
             , ICS_PRMT_FEATR.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_PRMT_FEATR' as ics_module
          FROM ics_flow_icis.dbo.ICS_PRMT_FEATR
         WHERE NOT EXISTS (SELECT 'x'
                             FROM dbo.ICS_PRMT_FEATR tbl
                            WHERE tbl.key_hash = ICS_PRMT_FEATR.key_hash)) ICS_PRMT_FEATR;
GO



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.CDV_PRMT_TERM') AND type = N'V')
  DROP VIEW dbo.CDV_PRMT_TERM
GO

/*************************************************************************************************
** ObjectName: dbo.CDV_PRMT_TERM
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Autogen: using helper: node .\run_template.js "all_cdv_views.js"
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/13/2016    Windsor     Baselined from v5.0 procedure. 
** 03/29/2025    Windsor     Recreate this 
**
***************************************************************************************************/
CREATE VIEW dbo.CDV_PRMT_TERM AS 
SELECT DISTINCT ics_module
, ICS_PRMT_TERM.key_hash
     , CASE ICS_PRMT_TERM.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.dbo.ICS_PRMT_TERM tbl
                  WHERE tbl.ICS_PRMT_TERM_ID = ICS_PRMT_TERM.ICS_PRMT_TERM_ID)
           ELSE (SELECT key_hash 
                   FROM dbo.ICS_PRMT_TERM tbl
                  WHERE tbl.ICS_PRMT_TERM_ID = ICS_PRMT_TERM.ICS_PRMT_TERM_ID)
       END AS module_ident
     , ICS_PRMT_TERM.action_type
     , ICS_PRMT_TERM.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_PRMT_TERM.ICS_PRMT_TERM_ID
			 , ICS_PRMT_TERM.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_PRMT_TERM' as ics_module
          FROM dbo.ICS_PRMT_TERM
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.dbo.ICS_PRMT_TERM tbl
                            WHERE tbl.key_hash = ICS_PRMT_TERM.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_PRMT_TERM_ID
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_PRMT_TERM' as ics_module
          FROM dbo.ICS_PRMT_TERM local
          JOIN ics_flow_icis.dbo.ICS_PRMT_TERM icis
            ON (icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash) 
        UNION
        /*  3 - DELETE  */
        SELECT ICS_PRMT_TERM.ICS_PRMT_TERM_ID
             , ICS_PRMT_TERM.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_PRMT_TERM' as ics_module
          FROM ics_flow_icis.dbo.ICS_PRMT_TERM
         WHERE NOT EXISTS (SELECT 'x'
                             FROM dbo.ICS_PRMT_TERM tbl
                            WHERE tbl.key_hash = ICS_PRMT_TERM.key_hash)) ICS_PRMT_TERM;
GO



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.CDV_PRMT_TRACK_EVT') AND type = N'V')
  DROP VIEW dbo.CDV_PRMT_TRACK_EVT
GO

/*************************************************************************************************
** ObjectName: dbo.CDV_PRMT_TRACK_EVT
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Autogen: using helper: node .\run_template.js "all_cdv_views.js"
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/13/2016    Windsor     Baselined from v5.0 procedure. 
** 03/29/2025    Windsor     Recreate this 
**
***************************************************************************************************/
CREATE VIEW dbo.CDV_PRMT_TRACK_EVT AS 
SELECT DISTINCT ics_module
, ICS_PRMT_TRACK_EVT.key_hash
     , CASE ICS_PRMT_TRACK_EVT.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.dbo.ICS_PRMT_TRACK_EVT tbl
                  WHERE tbl.ICS_PRMT_TRACK_EVT_ID = ICS_PRMT_TRACK_EVT.ICS_PRMT_TRACK_EVT_ID)
           ELSE (SELECT key_hash 
                   FROM dbo.ICS_PRMT_TRACK_EVT tbl
                  WHERE tbl.ICS_PRMT_TRACK_EVT_ID = ICS_PRMT_TRACK_EVT.ICS_PRMT_TRACK_EVT_ID)
       END AS module_ident
     , ICS_PRMT_TRACK_EVT.action_type
     , ICS_PRMT_TRACK_EVT.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_PRMT_TRACK_EVT.ICS_PRMT_TRACK_EVT_ID
			 , ICS_PRMT_TRACK_EVT.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_PRMT_TRACK_EVT' as ics_module
          FROM dbo.ICS_PRMT_TRACK_EVT
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.dbo.ICS_PRMT_TRACK_EVT tbl
                            WHERE tbl.key_hash = ICS_PRMT_TRACK_EVT.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_PRMT_TRACK_EVT_ID
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_PRMT_TRACK_EVT' as ics_module
          FROM dbo.ICS_PRMT_TRACK_EVT local
          JOIN ics_flow_icis.dbo.ICS_PRMT_TRACK_EVT icis
            ON (icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash) 
        UNION
        /*  3 - DELETE  */
        SELECT ICS_PRMT_TRACK_EVT.ICS_PRMT_TRACK_EVT_ID
             , ICS_PRMT_TRACK_EVT.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_PRMT_TRACK_EVT' as ics_module
          FROM ics_flow_icis.dbo.ICS_PRMT_TRACK_EVT
         WHERE NOT EXISTS (SELECT 'x'
                             FROM dbo.ICS_PRMT_TRACK_EVT tbl
                            WHERE tbl.key_hash = ICS_PRMT_TRACK_EVT.key_hash)) ICS_PRMT_TRACK_EVT;
GO



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.CDV_POTW_PRMT') AND type = N'V')
  DROP VIEW dbo.CDV_POTW_PRMT
GO

/*************************************************************************************************
** ObjectName: dbo.CDV_POTW_PRMT
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Autogen: using helper: node .\run_template.js "all_cdv_views.js"
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/13/2016    Windsor     Baselined from v5.0 procedure. 
** 03/29/2025    Windsor     Recreate this 
**
***************************************************************************************************/
CREATE VIEW dbo.CDV_POTW_PRMT AS 
SELECT DISTINCT ics_module
, ICS_POTW_PRMT.key_hash
     , CASE ICS_POTW_PRMT.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.dbo.ICS_POTW_PRMT tbl
                  WHERE tbl.ICS_POTW_PRMT_ID = ICS_POTW_PRMT.ICS_POTW_PRMT_ID)
           ELSE (SELECT key_hash 
                   FROM dbo.ICS_POTW_PRMT tbl
                  WHERE tbl.ICS_POTW_PRMT_ID = ICS_POTW_PRMT.ICS_POTW_PRMT_ID)
       END AS module_ident
     , ICS_POTW_PRMT.action_type
     , ICS_POTW_PRMT.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_POTW_PRMT.ICS_POTW_PRMT_ID
			 , ICS_POTW_PRMT.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_POTW_PRMT' as ics_module
          FROM dbo.ICS_POTW_PRMT
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.dbo.ICS_POTW_PRMT tbl
                            WHERE tbl.key_hash = ICS_POTW_PRMT.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_POTW_PRMT_ID
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_POTW_PRMT' as ics_module
          FROM dbo.ICS_POTW_PRMT local
          JOIN ics_flow_icis.dbo.ICS_POTW_PRMT icis
            ON (icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash) 
        UNION
        /*  3 - DELETE  */
        SELECT ICS_POTW_PRMT.ICS_POTW_PRMT_ID
             , ICS_POTW_PRMT.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_POTW_PRMT' as ics_module
          FROM ics_flow_icis.dbo.ICS_POTW_PRMT
         WHERE NOT EXISTS (SELECT 'x'
                             FROM dbo.ICS_POTW_PRMT tbl
                            WHERE tbl.key_hash = ICS_POTW_PRMT.key_hash)) ICS_POTW_PRMT;
GO



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.CDV_POTW_TRTMNT_TECHNOLOGY_PRMT') AND type = N'V')
  DROP VIEW dbo.CDV_POTW_TRTMNT_TECHNOLOGY_PRMT
GO

/*************************************************************************************************
** ObjectName: dbo.CDV_POTW_TRTMNT_TECHNOLOGY_PRMT
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Autogen: using helper: node .\run_template.js "all_cdv_views.js"
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/13/2016    Windsor     Baselined from v5.0 procedure. 
** 03/29/2025    Windsor     Recreate this 
**
***************************************************************************************************/
CREATE VIEW dbo.CDV_POTW_TRTMNT_TECHNOLOGY_PRMT AS 
SELECT DISTINCT ics_module
, ICS_POTW_TRTMNT_TECHNOLOGY_PRMT.key_hash
     , CASE ICS_POTW_TRTMNT_TECHNOLOGY_PRMT.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.dbo.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT tbl
                  WHERE tbl.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT_ID = ICS_POTW_TRTMNT_TECHNOLOGY_PRMT.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT_ID)
           ELSE (SELECT key_hash 
                   FROM dbo.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT tbl
                  WHERE tbl.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT_ID = ICS_POTW_TRTMNT_TECHNOLOGY_PRMT.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT_ID)
       END AS module_ident
     , ICS_POTW_TRTMNT_TECHNOLOGY_PRMT.action_type
     , ICS_POTW_TRTMNT_TECHNOLOGY_PRMT.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_POTW_TRTMNT_TECHNOLOGY_PRMT.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT_ID
			 , ICS_POTW_TRTMNT_TECHNOLOGY_PRMT.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_POTW_TRTMNT_TECHNOLOGY_PRMT' as ics_module
          FROM dbo.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.dbo.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT tbl
                            WHERE tbl.key_hash = ICS_POTW_TRTMNT_TECHNOLOGY_PRMT.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT_ID
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_POTW_TRTMNT_TECHNOLOGY_PRMT' as ics_module
          FROM dbo.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT local
          JOIN ics_flow_icis.dbo.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT icis
            ON (icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash) 
        UNION
        /*  3 - DELETE  */
        SELECT ICS_POTW_TRTMNT_TECHNOLOGY_PRMT.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT_ID
             , ICS_POTW_TRTMNT_TECHNOLOGY_PRMT.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_POTW_TRTMNT_TECHNOLOGY_PRMT' as ics_module
          FROM ics_flow_icis.dbo.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT
         WHERE NOT EXISTS (SELECT 'x'
                             FROM dbo.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT tbl
                            WHERE tbl.key_hash = ICS_POTW_TRTMNT_TECHNOLOGY_PRMT.key_hash)) ICS_POTW_TRTMNT_TECHNOLOGY_PRMT;
GO



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.CDV_PRETR_PRMT') AND type = N'V')
  DROP VIEW dbo.CDV_PRETR_PRMT
GO

/*************************************************************************************************
** ObjectName: dbo.CDV_PRETR_PRMT
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Autogen: using helper: node .\run_template.js "all_cdv_views.js"
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/13/2016    Windsor     Baselined from v5.0 procedure. 
** 03/29/2025    Windsor     Recreate this 
**
***************************************************************************************************/
CREATE VIEW dbo.CDV_PRETR_PRMT AS 
SELECT DISTINCT ics_module
, ICS_PRETR_PRMT.key_hash
     , CASE ICS_PRETR_PRMT.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.dbo.ICS_PRETR_PRMT tbl
                  WHERE tbl.ICS_PRETR_PRMT_ID = ICS_PRETR_PRMT.ICS_PRETR_PRMT_ID)
           ELSE (SELECT key_hash 
                   FROM dbo.ICS_PRETR_PRMT tbl
                  WHERE tbl.ICS_PRETR_PRMT_ID = ICS_PRETR_PRMT.ICS_PRETR_PRMT_ID)
       END AS module_ident
     , ICS_PRETR_PRMT.action_type
     , ICS_PRETR_PRMT.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_PRETR_PRMT.ICS_PRETR_PRMT_ID
			 , ICS_PRETR_PRMT.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_PRETR_PRMT' as ics_module
          FROM dbo.ICS_PRETR_PRMT
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.dbo.ICS_PRETR_PRMT tbl
                            WHERE tbl.key_hash = ICS_PRETR_PRMT.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_PRETR_PRMT_ID
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_PRETR_PRMT' as ics_module
          FROM dbo.ICS_PRETR_PRMT local
          JOIN ics_flow_icis.dbo.ICS_PRETR_PRMT icis
            ON (icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash) 
        UNION
        /*  3 - DELETE  */
        SELECT ICS_PRETR_PRMT.ICS_PRETR_PRMT_ID
             , ICS_PRETR_PRMT.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_PRETR_PRMT' as ics_module
          FROM ics_flow_icis.dbo.ICS_PRETR_PRMT
         WHERE NOT EXISTS (SELECT 'x'
                             FROM dbo.ICS_PRETR_PRMT tbl
                            WHERE tbl.key_hash = ICS_PRETR_PRMT.key_hash)) ICS_PRETR_PRMT;
GO



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.CDV_PRETR_PROG_REP') AND type = N'V')
  DROP VIEW dbo.CDV_PRETR_PROG_REP
GO

/*************************************************************************************************
** ObjectName: dbo.CDV_PRETR_PROG_REP
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Autogen: using helper: node .\run_template.js "all_cdv_views.js"
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/13/2016    Windsor     Baselined from v5.0 procedure. 
** 03/29/2025    Windsor     Recreate this 
**
***************************************************************************************************/
CREATE VIEW dbo.CDV_PRETR_PROG_REP AS 
SELECT DISTINCT ics_module
, ICS_PRETR_PROG_REP.key_hash
     , CASE ICS_PRETR_PROG_REP.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.dbo.ICS_PRETR_PROG_REP tbl
                  WHERE tbl.ICS_PRETR_PROG_REP_ID = ICS_PRETR_PROG_REP.ICS_PRETR_PROG_REP_ID)
           ELSE (SELECT key_hash 
                   FROM dbo.ICS_PRETR_PROG_REP tbl
                  WHERE tbl.ICS_PRETR_PROG_REP_ID = ICS_PRETR_PROG_REP.ICS_PRETR_PROG_REP_ID)
       END AS module_ident
     , ICS_PRETR_PROG_REP.action_type
     , ICS_PRETR_PROG_REP.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_PRETR_PROG_REP.ICS_PRETR_PROG_REP_ID
			 , ICS_PRETR_PROG_REP.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_PRETR_PROG_REP' as ics_module
          FROM dbo.ICS_PRETR_PROG_REP
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.dbo.ICS_PRETR_PROG_REP tbl
                            WHERE tbl.key_hash = ICS_PRETR_PROG_REP.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_PRETR_PROG_REP_ID
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_PRETR_PROG_REP' as ics_module
          FROM dbo.ICS_PRETR_PROG_REP local
          JOIN ics_flow_icis.dbo.ICS_PRETR_PROG_REP icis
            ON (icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash) 
        UNION
        /*  3 - DELETE  */
        SELECT ICS_PRETR_PROG_REP.ICS_PRETR_PROG_REP_ID
             , ICS_PRETR_PROG_REP.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_PRETR_PROG_REP' as ics_module
          FROM ics_flow_icis.dbo.ICS_PRETR_PROG_REP
         WHERE NOT EXISTS (SELECT 'x'
                             FROM dbo.ICS_PRETR_PROG_REP tbl
                            WHERE tbl.key_hash = ICS_PRETR_PROG_REP.key_hash)) ICS_PRETR_PROG_REP;
GO



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.CDV_SCHD_EVT_VIOL') AND type = N'V')
  DROP VIEW dbo.CDV_SCHD_EVT_VIOL
GO

/*************************************************************************************************
** ObjectName: dbo.CDV_SCHD_EVT_VIOL
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Autogen: using helper: node .\run_template.js "all_cdv_views.js"
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/13/2016    Windsor     Baselined from v5.0 procedure. 
** 03/29/2025    Windsor     Recreate this 
**
***************************************************************************************************/
CREATE VIEW dbo.CDV_SCHD_EVT_VIOL AS 
SELECT DISTINCT ics_module
, ICS_SCHD_EVT_VIOL.key_hash
     , CASE ICS_SCHD_EVT_VIOL.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.dbo.ICS_SCHD_EVT_VIOL tbl
                  WHERE tbl.ICS_SCHD_EVT_VIOL_ID = ICS_SCHD_EVT_VIOL.ICS_SCHD_EVT_VIOL_ID)
           ELSE (SELECT key_hash 
                   FROM dbo.ICS_SCHD_EVT_VIOL tbl
                  WHERE tbl.ICS_SCHD_EVT_VIOL_ID = ICS_SCHD_EVT_VIOL.ICS_SCHD_EVT_VIOL_ID)
       END AS module_ident
     , ICS_SCHD_EVT_VIOL.action_type
     , ICS_SCHD_EVT_VIOL.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_SCHD_EVT_VIOL.ICS_SCHD_EVT_VIOL_ID
			 , ICS_SCHD_EVT_VIOL.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_SCHD_EVT_VIOL' as ics_module
          FROM dbo.ICS_SCHD_EVT_VIOL
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.dbo.ICS_SCHD_EVT_VIOL tbl
                            WHERE tbl.key_hash = ICS_SCHD_EVT_VIOL.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_SCHD_EVT_VIOL_ID
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_SCHD_EVT_VIOL' as ics_module
          FROM dbo.ICS_SCHD_EVT_VIOL local
          JOIN ics_flow_icis.dbo.ICS_SCHD_EVT_VIOL icis
            ON (icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash) 
        UNION
        /*  3 - DELETE  */
        SELECT ICS_SCHD_EVT_VIOL.ICS_SCHD_EVT_VIOL_ID
             , ICS_SCHD_EVT_VIOL.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_SCHD_EVT_VIOL' as ics_module
          FROM ics_flow_icis.dbo.ICS_SCHD_EVT_VIOL
         WHERE NOT EXISTS (SELECT 'x'
                             FROM dbo.ICS_SCHD_EVT_VIOL tbl
                            WHERE tbl.key_hash = ICS_SCHD_EVT_VIOL.key_hash)) ICS_SCHD_EVT_VIOL;
GO



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.CDV_SEWER_OVRFLW_BYPASS_EVT_REP') AND type = N'V')
  DROP VIEW dbo.CDV_SEWER_OVRFLW_BYPASS_EVT_REP
GO

/*************************************************************************************************
** ObjectName: dbo.CDV_SEWER_OVRFLW_BYPASS_EVT_REP
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Autogen: using helper: node .\run_template.js "all_cdv_views.js"
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/13/2016    Windsor     Baselined from v5.0 procedure. 
** 03/29/2025    Windsor     Recreate this 
**
***************************************************************************************************/
CREATE VIEW dbo.CDV_SEWER_OVRFLW_BYPASS_EVT_REP AS 
SELECT DISTINCT ics_module
, ICS_SEWER_OVRFLW_BYPASS_EVT_REP.key_hash
     , CASE ICS_SEWER_OVRFLW_BYPASS_EVT_REP.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.dbo.ICS_SEWER_OVRFLW_BYPASS_EVT_REP tbl
                  WHERE tbl.ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID = ICS_SEWER_OVRFLW_BYPASS_EVT_REP.ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID)
           ELSE (SELECT key_hash 
                   FROM dbo.ICS_SEWER_OVRFLW_BYPASS_EVT_REP tbl
                  WHERE tbl.ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID = ICS_SEWER_OVRFLW_BYPASS_EVT_REP.ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID)
       END AS module_ident
     , ICS_SEWER_OVRFLW_BYPASS_EVT_REP.action_type
     , ICS_SEWER_OVRFLW_BYPASS_EVT_REP.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_SEWER_OVRFLW_BYPASS_EVT_REP.ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID
			 , ICS_SEWER_OVRFLW_BYPASS_EVT_REP.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_SEWER_OVRFLW_BYPASS_EVT_REP' as ics_module
          FROM dbo.ICS_SEWER_OVRFLW_BYPASS_EVT_REP
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.dbo.ICS_SEWER_OVRFLW_BYPASS_EVT_REP tbl
                            WHERE tbl.key_hash = ICS_SEWER_OVRFLW_BYPASS_EVT_REP.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_SEWER_OVRFLW_BYPASS_EVT_REP' as ics_module
          FROM dbo.ICS_SEWER_OVRFLW_BYPASS_EVT_REP local
          JOIN ics_flow_icis.dbo.ICS_SEWER_OVRFLW_BYPASS_EVT_REP icis
            ON (icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash) 
        UNION
        /*  3 - DELETE  */
        SELECT ICS_SEWER_OVRFLW_BYPASS_EVT_REP.ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID
             , ICS_SEWER_OVRFLW_BYPASS_EVT_REP.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_SEWER_OVRFLW_BYPASS_EVT_REP' as ics_module
          FROM ics_flow_icis.dbo.ICS_SEWER_OVRFLW_BYPASS_EVT_REP
         WHERE NOT EXISTS (SELECT 'x'
                             FROM dbo.ICS_SEWER_OVRFLW_BYPASS_EVT_REP tbl
                            WHERE tbl.key_hash = ICS_SEWER_OVRFLW_BYPASS_EVT_REP.key_hash)) ICS_SEWER_OVRFLW_BYPASS_EVT_REP;
GO



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.CDV_SNGL_EVT_VIOL') AND type = N'V')
  DROP VIEW dbo.CDV_SNGL_EVT_VIOL
GO

/*************************************************************************************************
** ObjectName: dbo.CDV_SNGL_EVT_VIOL
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Autogen: using helper: node .\run_template.js "all_cdv_views.js"
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/13/2016    Windsor     Baselined from v5.0 procedure. 
** 03/29/2025    Windsor     Recreate this 
**
***************************************************************************************************/
CREATE VIEW dbo.CDV_SNGL_EVT_VIOL AS 
SELECT DISTINCT ics_module
, ICS_SNGL_EVT_VIOL.key_hash
     , CASE ICS_SNGL_EVT_VIOL.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.dbo.ICS_SNGL_EVT_VIOL tbl
                  WHERE tbl.ICS_SNGL_EVT_VIOL_ID = ICS_SNGL_EVT_VIOL.ICS_SNGL_EVT_VIOL_ID)
           ELSE (SELECT key_hash 
                   FROM dbo.ICS_SNGL_EVT_VIOL tbl
                  WHERE tbl.ICS_SNGL_EVT_VIOL_ID = ICS_SNGL_EVT_VIOL.ICS_SNGL_EVT_VIOL_ID)
       END AS module_ident
     , ICS_SNGL_EVT_VIOL.action_type
     , ICS_SNGL_EVT_VIOL.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_SNGL_EVT_VIOL.ICS_SNGL_EVT_VIOL_ID
			 , ICS_SNGL_EVT_VIOL.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_SNGL_EVT_VIOL' as ics_module
          FROM dbo.ICS_SNGL_EVT_VIOL
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.dbo.ICS_SNGL_EVT_VIOL tbl
                            WHERE tbl.key_hash = ICS_SNGL_EVT_VIOL.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_SNGL_EVT_VIOL_ID
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_SNGL_EVT_VIOL' as ics_module
          FROM dbo.ICS_SNGL_EVT_VIOL local
          JOIN ics_flow_icis.dbo.ICS_SNGL_EVT_VIOL icis
            ON (icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash) 
        UNION
        /*  3 - DELETE  */
        SELECT ICS_SNGL_EVT_VIOL.ICS_SNGL_EVT_VIOL_ID
             , ICS_SNGL_EVT_VIOL.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_SNGL_EVT_VIOL' as ics_module
          FROM ics_flow_icis.dbo.ICS_SNGL_EVT_VIOL
         WHERE NOT EXISTS (SELECT 'x'
                             FROM dbo.ICS_SNGL_EVT_VIOL tbl
                            WHERE tbl.key_hash = ICS_SNGL_EVT_VIOL.key_hash)) ICS_SNGL_EVT_VIOL;
GO



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.CDV_SW_CNST_PRMT') AND type = N'V')
  DROP VIEW dbo.CDV_SW_CNST_PRMT
GO

/*************************************************************************************************
** ObjectName: dbo.CDV_SW_CNST_PRMT
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Autogen: using helper: node .\run_template.js "all_cdv_views.js"
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/13/2016    Windsor     Baselined from v5.0 procedure. 
** 03/29/2025    Windsor     Recreate this 
**
***************************************************************************************************/
CREATE VIEW dbo.CDV_SW_CNST_PRMT AS 
SELECT DISTINCT ics_module
, ICS_SW_CNST_PRMT.key_hash
     , CASE ICS_SW_CNST_PRMT.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.dbo.ICS_SW_CNST_PRMT tbl
                  WHERE tbl.ICS_SW_CNST_PRMT_ID = ICS_SW_CNST_PRMT.ICS_SW_CNST_PRMT_ID)
           ELSE (SELECT key_hash 
                   FROM dbo.ICS_SW_CNST_PRMT tbl
                  WHERE tbl.ICS_SW_CNST_PRMT_ID = ICS_SW_CNST_PRMT.ICS_SW_CNST_PRMT_ID)
       END AS module_ident
     , ICS_SW_CNST_PRMT.action_type
     , ICS_SW_CNST_PRMT.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_SW_CNST_PRMT.ICS_SW_CNST_PRMT_ID
			 , ICS_SW_CNST_PRMT.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_SW_CNST_PRMT' as ics_module
          FROM dbo.ICS_SW_CNST_PRMT
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.dbo.ICS_SW_CNST_PRMT tbl
                            WHERE tbl.key_hash = ICS_SW_CNST_PRMT.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_SW_CNST_PRMT_ID
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_SW_CNST_PRMT' as ics_module
          FROM dbo.ICS_SW_CNST_PRMT local
          JOIN ics_flow_icis.dbo.ICS_SW_CNST_PRMT icis
            ON (icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash) 
        UNION
        /*  3 - DELETE  */
        SELECT ICS_SW_CNST_PRMT.ICS_SW_CNST_PRMT_ID
             , ICS_SW_CNST_PRMT.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_SW_CNST_PRMT' as ics_module
          FROM ics_flow_icis.dbo.ICS_SW_CNST_PRMT
         WHERE NOT EXISTS (SELECT 'x'
                             FROM dbo.ICS_SW_CNST_PRMT tbl
                            WHERE tbl.key_hash = ICS_SW_CNST_PRMT.key_hash)) ICS_SW_CNST_PRMT;
GO



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.CDV_SW_INDST_ANNUL_REP') AND type = N'V')
  DROP VIEW dbo.CDV_SW_INDST_ANNUL_REP
GO

/*************************************************************************************************
** ObjectName: dbo.CDV_SW_INDST_ANNUL_REP
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Autogen: using helper: node .\run_template.js "all_cdv_views.js"
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/13/2016    Windsor     Baselined from v5.0 procedure. 
** 03/29/2025    Windsor     Recreate this 
**
***************************************************************************************************/
CREATE VIEW dbo.CDV_SW_INDST_ANNUL_REP AS 
SELECT DISTINCT ics_module
, ICS_SW_INDST_ANNUL_REP.key_hash
     , CASE ICS_SW_INDST_ANNUL_REP.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.dbo.ICS_SW_INDST_ANNUL_REP tbl
                  WHERE tbl.ICS_SW_INDST_ANNUL_REP_ID = ICS_SW_INDST_ANNUL_REP.ICS_SW_INDST_ANNUL_REP_ID)
           ELSE (SELECT key_hash 
                   FROM dbo.ICS_SW_INDST_ANNUL_REP tbl
                  WHERE tbl.ICS_SW_INDST_ANNUL_REP_ID = ICS_SW_INDST_ANNUL_REP.ICS_SW_INDST_ANNUL_REP_ID)
       END AS module_ident
     , ICS_SW_INDST_ANNUL_REP.action_type
     , ICS_SW_INDST_ANNUL_REP.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_SW_INDST_ANNUL_REP.ICS_SW_INDST_ANNUL_REP_ID
			 , ICS_SW_INDST_ANNUL_REP.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_SW_INDST_ANNUL_REP' as ics_module
          FROM dbo.ICS_SW_INDST_ANNUL_REP
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.dbo.ICS_SW_INDST_ANNUL_REP tbl
                            WHERE tbl.key_hash = ICS_SW_INDST_ANNUL_REP.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_SW_INDST_ANNUL_REP_ID
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_SW_INDST_ANNUL_REP' as ics_module
          FROM dbo.ICS_SW_INDST_ANNUL_REP local
          JOIN ics_flow_icis.dbo.ICS_SW_INDST_ANNUL_REP icis
            ON (icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash) 
        UNION
        /*  3 - DELETE  */
        SELECT ICS_SW_INDST_ANNUL_REP.ICS_SW_INDST_ANNUL_REP_ID
             , ICS_SW_INDST_ANNUL_REP.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_SW_INDST_ANNUL_REP' as ics_module
          FROM ics_flow_icis.dbo.ICS_SW_INDST_ANNUL_REP
         WHERE NOT EXISTS (SELECT 'x'
                             FROM dbo.ICS_SW_INDST_ANNUL_REP tbl
                            WHERE tbl.key_hash = ICS_SW_INDST_ANNUL_REP.key_hash)) ICS_SW_INDST_ANNUL_REP;
GO



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.CDV_SW_INDST_PRMT') AND type = N'V')
  DROP VIEW dbo.CDV_SW_INDST_PRMT
GO

/*************************************************************************************************
** ObjectName: dbo.CDV_SW_INDST_PRMT
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Autogen: using helper: node .\run_template.js "all_cdv_views.js"
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/13/2016    Windsor     Baselined from v5.0 procedure. 
** 03/29/2025    Windsor     Recreate this 
**
***************************************************************************************************/
CREATE VIEW dbo.CDV_SW_INDST_PRMT AS 
SELECT DISTINCT ics_module
, ICS_SW_INDST_PRMT.key_hash
     , CASE ICS_SW_INDST_PRMT.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.dbo.ICS_SW_INDST_PRMT tbl
                  WHERE tbl.ICS_SW_INDST_PRMT_ID = ICS_SW_INDST_PRMT.ICS_SW_INDST_PRMT_ID)
           ELSE (SELECT key_hash 
                   FROM dbo.ICS_SW_INDST_PRMT tbl
                  WHERE tbl.ICS_SW_INDST_PRMT_ID = ICS_SW_INDST_PRMT.ICS_SW_INDST_PRMT_ID)
       END AS module_ident
     , ICS_SW_INDST_PRMT.action_type
     , ICS_SW_INDST_PRMT.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_SW_INDST_PRMT.ICS_SW_INDST_PRMT_ID
			 , ICS_SW_INDST_PRMT.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_SW_INDST_PRMT' as ics_module
          FROM dbo.ICS_SW_INDST_PRMT
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.dbo.ICS_SW_INDST_PRMT tbl
                            WHERE tbl.key_hash = ICS_SW_INDST_PRMT.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_SW_INDST_PRMT_ID
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_SW_INDST_PRMT' as ics_module
          FROM dbo.ICS_SW_INDST_PRMT local
          JOIN ics_flow_icis.dbo.ICS_SW_INDST_PRMT icis
            ON (icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash) 
        UNION
        /*  3 - DELETE  */
        SELECT ICS_SW_INDST_PRMT.ICS_SW_INDST_PRMT_ID
             , ICS_SW_INDST_PRMT.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_SW_INDST_PRMT' as ics_module
          FROM ics_flow_icis.dbo.ICS_SW_INDST_PRMT
         WHERE NOT EXISTS (SELECT 'x'
                             FROM dbo.ICS_SW_INDST_PRMT tbl
                            WHERE tbl.key_hash = ICS_SW_INDST_PRMT.key_hash)) ICS_SW_INDST_PRMT;
GO



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.CDV_SWMS_4_ANNUL_PROG_REP') AND type = N'V')
  DROP VIEW dbo.CDV_SWMS_4_ANNUL_PROG_REP
GO

/*************************************************************************************************
** ObjectName: dbo.CDV_SWMS_4_ANNUL_PROG_REP
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Autogen: using helper: node .\run_template.js "all_cdv_views.js"
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/13/2016    Windsor     Baselined from v5.0 procedure. 
** 03/29/2025    Windsor     Recreate this 
**
***************************************************************************************************/
CREATE VIEW dbo.CDV_SWMS_4_ANNUL_PROG_REP AS 
SELECT DISTINCT ics_module
, ICS_SWMS_4_ANNUL_PROG_REP.key_hash
     , CASE ICS_SWMS_4_ANNUL_PROG_REP.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.dbo.ICS_SWMS_4_ANNUL_PROG_REP tbl
                  WHERE tbl.ICS_SWMS_4_ANNUL_PROG_REP_ID = ICS_SWMS_4_ANNUL_PROG_REP.ICS_SWMS_4_ANNUL_PROG_REP_ID)
           ELSE (SELECT key_hash 
                   FROM dbo.ICS_SWMS_4_ANNUL_PROG_REP tbl
                  WHERE tbl.ICS_SWMS_4_ANNUL_PROG_REP_ID = ICS_SWMS_4_ANNUL_PROG_REP.ICS_SWMS_4_ANNUL_PROG_REP_ID)
       END AS module_ident
     , ICS_SWMS_4_ANNUL_PROG_REP.action_type
     , ICS_SWMS_4_ANNUL_PROG_REP.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_SWMS_4_ANNUL_PROG_REP.ICS_SWMS_4_ANNUL_PROG_REP_ID
			 , ICS_SWMS_4_ANNUL_PROG_REP.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_SWMS_4_ANNUL_PROG_REP' as ics_module
          FROM dbo.ICS_SWMS_4_ANNUL_PROG_REP
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.dbo.ICS_SWMS_4_ANNUL_PROG_REP tbl
                            WHERE tbl.key_hash = ICS_SWMS_4_ANNUL_PROG_REP.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_SWMS_4_ANNUL_PROG_REP_ID
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_SWMS_4_ANNUL_PROG_REP' as ics_module
          FROM dbo.ICS_SWMS_4_ANNUL_PROG_REP local
          JOIN ics_flow_icis.dbo.ICS_SWMS_4_ANNUL_PROG_REP icis
            ON (icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash) 
        UNION
        /*  3 - DELETE  */
        SELECT ICS_SWMS_4_ANNUL_PROG_REP.ICS_SWMS_4_ANNUL_PROG_REP_ID
             , ICS_SWMS_4_ANNUL_PROG_REP.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_SWMS_4_ANNUL_PROG_REP' as ics_module
          FROM ics_flow_icis.dbo.ICS_SWMS_4_ANNUL_PROG_REP
         WHERE NOT EXISTS (SELECT 'x'
                             FROM dbo.ICS_SWMS_4_ANNUL_PROG_REP tbl
                            WHERE tbl.key_hash = ICS_SWMS_4_ANNUL_PROG_REP.key_hash)) ICS_SWMS_4_ANNUL_PROG_REP;
GO



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.CDV_SWMS_4_PRMT') AND type = N'V')
  DROP VIEW dbo.CDV_SWMS_4_PRMT
GO

/*************************************************************************************************
** ObjectName: dbo.CDV_SWMS_4_PRMT
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Autogen: using helper: node .\run_template.js "all_cdv_views.js"
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/13/2016    Windsor     Baselined from v5.0 procedure. 
** 03/29/2025    Windsor     Recreate this 
**
***************************************************************************************************/
CREATE VIEW dbo.CDV_SWMS_4_PRMT AS 
SELECT DISTINCT ics_module
, ICS_SWMS_4_PRMT.key_hash
     , CASE ICS_SWMS_4_PRMT.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.dbo.ICS_SWMS_4_PRMT tbl
                  WHERE tbl.ICS_SWMS_4_PRMT_ID = ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_ID)
           ELSE (SELECT key_hash 
                   FROM dbo.ICS_SWMS_4_PRMT tbl
                  WHERE tbl.ICS_SWMS_4_PRMT_ID = ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_ID)
       END AS module_ident
     , ICS_SWMS_4_PRMT.action_type
     , ICS_SWMS_4_PRMT.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_ID
			 , ICS_SWMS_4_PRMT.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_SWMS_4_PRMT' as ics_module
          FROM dbo.ICS_SWMS_4_PRMT
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.dbo.ICS_SWMS_4_PRMT tbl
                            WHERE tbl.key_hash = ICS_SWMS_4_PRMT.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_SWMS_4_PRMT_ID
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_SWMS_4_PRMT' as ics_module
          FROM dbo.ICS_SWMS_4_PRMT local
          JOIN ics_flow_icis.dbo.ICS_SWMS_4_PRMT icis
            ON (icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash) 
        UNION
        /*  3 - DELETE  */
        SELECT ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_ID
             , ICS_SWMS_4_PRMT.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_SWMS_4_PRMT' as ics_module
          FROM ics_flow_icis.dbo.ICS_SWMS_4_PRMT
         WHERE NOT EXISTS (SELECT 'x'
                             FROM dbo.ICS_SWMS_4_PRMT tbl
                            WHERE tbl.key_hash = ICS_SWMS_4_PRMT.key_hash)) ICS_SWMS_4_PRMT;
GO



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.CDV_UNPRMT_FAC') AND type = N'V')
  DROP VIEW dbo.CDV_UNPRMT_FAC
GO

/*************************************************************************************************
** ObjectName: dbo.CDV_UNPRMT_FAC
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Autogen: using helper: node .\run_template.js "all_cdv_views.js"
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/13/2016    Windsor     Baselined from v5.0 procedure. 
** 03/29/2025    Windsor     Recreate this 
**
***************************************************************************************************/
CREATE VIEW dbo.CDV_UNPRMT_FAC AS 
SELECT DISTINCT ics_module
, ICS_UNPRMT_FAC.key_hash
     , CASE ICS_UNPRMT_FAC.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.dbo.ICS_UNPRMT_FAC tbl
                  WHERE tbl.ICS_UNPRMT_FAC_ID = ICS_UNPRMT_FAC.ICS_UNPRMT_FAC_ID)
           ELSE (SELECT key_hash 
                   FROM dbo.ICS_UNPRMT_FAC tbl
                  WHERE tbl.ICS_UNPRMT_FAC_ID = ICS_UNPRMT_FAC.ICS_UNPRMT_FAC_ID)
       END AS module_ident
     , ICS_UNPRMT_FAC.action_type
     , ICS_UNPRMT_FAC.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_UNPRMT_FAC.ICS_UNPRMT_FAC_ID
			 , ICS_UNPRMT_FAC.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_UNPRMT_FAC' as ics_module
          FROM dbo.ICS_UNPRMT_FAC
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.dbo.ICS_UNPRMT_FAC tbl
                            WHERE tbl.key_hash = ICS_UNPRMT_FAC.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_UNPRMT_FAC_ID
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_UNPRMT_FAC' as ics_module
          FROM dbo.ICS_UNPRMT_FAC local
          JOIN ics_flow_icis.dbo.ICS_UNPRMT_FAC icis
            ON (icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash) 
        UNION
        /*  3 - DELETE  */
        SELECT ICS_UNPRMT_FAC.ICS_UNPRMT_FAC_ID
             , ICS_UNPRMT_FAC.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_UNPRMT_FAC' as ics_module
          FROM ics_flow_icis.dbo.ICS_UNPRMT_FAC
         WHERE NOT EXISTS (SELECT 'x'
                             FROM dbo.ICS_UNPRMT_FAC tbl
                            WHERE tbl.key_hash = ICS_UNPRMT_FAC.key_hash)) ICS_UNPRMT_FAC;
GO



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.ics_v_module_count'))
DROP VIEW dbo.ics_v_module_count
GO


/*************************************************************************************************
** ObjectName: ics_v_module_count
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view displays a count of accepted, rejected, and warning records for each module
**               Used in process_accepted_transactions procedure to insert into ics_subm_hist
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 4/5/2012      Windsor     Created 
** 5/15/2012     BRensmith   Added columns for count by transaction type
** 5/25/2012     BRensmith   Added column for accepted_count_total
** 12/10/2012    BRensmith   Rewrote view to eliminate possible duplicates, now driven off of ics_payload
** 6/13/2017     CTyler      Added BiosolidsAnnualProgramReportSubmission into query
** 4/6/2025      CTyler      Update to ICIS 5.14
**
***************************************************************************************************/
CREATE VIEW dbo.ics_v_module_count

AS

SELECT operation
    , [enabled]
    , CASE 
	
      WHEN ics_payload.operation = 'BasicPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_BASIC_PRMT)
 	
      WHEN ics_payload.operation = 'BiosolidsAnnualProgramReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_BS_ANNUL_PROG_REP)
 	
      WHEN ics_payload.operation = 'BiosolidsPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_BS_PRMT)
 	
      WHEN ics_payload.operation = 'CAFOAnnualProgramReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_CAFO_ANNUL_PROG_REP)
 	
      WHEN ics_payload.operation = 'CAFOPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_CAFO_PRMT)
 	
      WHEN ics_payload.operation = 'CollectionSystemPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_COLL_SYSTM_PRMT)
 	
      WHEN ics_payload.operation = 'ComplianceMonitoringSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_CMPL_MON)
 	
      WHEN ics_payload.operation = 'ComplianceMonitoringLinkageSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_CMPL_MON_LNK)
 	
      WHEN ics_payload.operation = 'ComplianceScheduleSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_CMPL_SCHD)
 	
      WHEN ics_payload.operation = 'CopyMGPLimitSetSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_COPY_MGP_LMT_SET)
 	
      WHEN ics_payload.operation = 'CopyMGPMS4RequirementSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_COPY_MGPMS_4_REQ)
 	
      WHEN ics_payload.operation = 'CSOLongTermControlPlanSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_CSO_LONG_TERM_CONTROL_PLAN)
 	
      WHEN ics_payload.operation = 'CWA316bProgramReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_CWA_316B_PROG_REP)
 	
      WHEN ics_payload.operation = 'DischargeMonitoringReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_DSCH_MON_REP)
 	
      WHEN ics_payload.operation = 'DMRViolationSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_DMR_VIOL)
 	
      WHEN ics_payload.operation = 'EffluentTradePartnerSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_EFFLU_TRADE_PRTNER)
 	
      WHEN ics_payload.operation = 'EnforcementActionMilestoneSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_ENFRC_ACTN_MILESTONE)
 	
      WHEN ics_payload.operation = 'EnforcementActionViolationLinkageSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_ENFRC_ACTN_VIOL_LNK)
 	
      WHEN ics_payload.operation = 'FinalOrderViolationLinkageSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_FINAL_ORDER_VIOL_LNK)
 	
      WHEN ics_payload.operation = 'FormalEnforcementActionSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_FRML_ENFRC_ACTN)
 	
      WHEN ics_payload.operation = 'GeneralPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_GNRL_PRMT)
 	
      WHEN ics_payload.operation = 'HistoricalPermitScheduleEventsSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_HIST_PRMT_SCHD_EVTS)
 	
      WHEN ics_payload.operation = 'InformalEnforcementActionSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_INFRML_ENFRC_ACTN)
 	
      WHEN ics_payload.operation = 'LimitsSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_LMTS)
 	
      WHEN ics_payload.operation = 'LimitSetSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_LMT_SET)
 	
      WHEN ics_payload.operation = 'MasterGeneralPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_MASTER_GNRL_PRMT)
 	
      WHEN ics_payload.operation = 'NarrativeConditionScheduleSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_NARR_COND_SCHD)
 	
      WHEN ics_payload.operation = 'NPDESVariancePermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_NPDES_VARIANCE_PRMT)
 	
      WHEN ics_payload.operation = 'ParameterLimitsSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_PARAM_LMTS)
 	
      WHEN ics_payload.operation = 'PermitReissuanceSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_PRMT_REISSU)
 	
      WHEN ics_payload.operation = 'PermittedFeatureSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_PRMT_FEATR)
 	
      WHEN ics_payload.operation = 'PermitTerminationSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_PRMT_TERM)
 	
      WHEN ics_payload.operation = 'PermitTrackingEventSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_PRMT_TRACK_EVT)
 	
      WHEN ics_payload.operation = 'POTWPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_POTW_PRMT)
 	
      WHEN ics_payload.operation = 'POTWTreatmentTechnologyPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT)
 	
      WHEN ics_payload.operation = 'PretreatmentPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_PRETR_PRMT)
 	
      WHEN ics_payload.operation = 'PretreatmentProgramReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_PRETR_PROG_REP)
 	
      WHEN ics_payload.operation = 'ScheduleEventViolationSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SCHD_EVT_VIOL)
 	
      WHEN ics_payload.operation = 'SewerOverflowBypassEventReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SEWER_OVRFLW_BYPASS_EVT_REP)
 	
      WHEN ics_payload.operation = 'SingleEventViolationSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SNGL_EVT_VIOL)
 	
      WHEN ics_payload.operation = 'SWConstructionPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SW_CNST_PRMT)
 	
      WHEN ics_payload.operation = 'SWIndustrialAnnualReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SW_INDST_ANNUL_REP)
 	
      WHEN ics_payload.operation = 'SWIndustrialPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SW_INDST_PRMT)
 	
      WHEN ics_payload.operation = 'SWMS4AnnualProgramReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SWMS_4_ANNUL_PROG_REP)
 	
      WHEN ics_payload.operation = 'SWMS4PermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SWMS_4_PRMT)
 	
      WHEN ics_payload.operation = 'UnpermittedFacilitySubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_UNPRMT_FAC)
 
    END as trans_count_staged
  , CASE 
	
      WHEN ics_payload.operation = 'BasicPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_BASIC_PRMT WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'BiosolidsAnnualProgramReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_BS_ANNUL_PROG_REP WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'BiosolidsPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_BS_PRMT WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'CAFOAnnualProgramReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_CAFO_ANNUL_PROG_REP WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'CAFOPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_CAFO_PRMT WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'CollectionSystemPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_COLL_SYSTM_PRMT WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'ComplianceMonitoringSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_CMPL_MON WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'ComplianceMonitoringLinkageSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_CMPL_MON_LNK WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'ComplianceScheduleSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_CMPL_SCHD WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'CopyMGPLimitSetSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_COPY_MGP_LMT_SET WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'CopyMGPMS4RequirementSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_COPY_MGPMS_4_REQ WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'CSOLongTermControlPlanSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_CSO_LONG_TERM_CONTROL_PLAN WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'CWA316bProgramReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_CWA_316B_PROG_REP WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'DischargeMonitoringReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_DSCH_MON_REP WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'DMRViolationSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_DMR_VIOL WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'EffluentTradePartnerSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_EFFLU_TRADE_PRTNER WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'EnforcementActionMilestoneSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_ENFRC_ACTN_MILESTONE WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'EnforcementActionViolationLinkageSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_ENFRC_ACTN_VIOL_LNK WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'FinalOrderViolationLinkageSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_FINAL_ORDER_VIOL_LNK WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'FormalEnforcementActionSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_FRML_ENFRC_ACTN WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'GeneralPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_GNRL_PRMT WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'HistoricalPermitScheduleEventsSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_HIST_PRMT_SCHD_EVTS WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'InformalEnforcementActionSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_INFRML_ENFRC_ACTN WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'LimitsSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_LMTS WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'LimitSetSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_LMT_SET WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'MasterGeneralPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_MASTER_GNRL_PRMT WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'NarrativeConditionScheduleSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_NARR_COND_SCHD WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'NPDESVariancePermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_NPDES_VARIANCE_PRMT WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'ParameterLimitsSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_PARAM_LMTS WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'PermitReissuanceSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_PRMT_REISSU WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'PermittedFeatureSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_PRMT_FEATR WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'PermitTerminationSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_PRMT_TERM WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'PermitTrackingEventSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_PRMT_TRACK_EVT WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'POTWPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_POTW_PRMT WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'POTWTreatmentTechnologyPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'PretreatmentPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_PRETR_PRMT WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'PretreatmentProgramReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_PRETR_PROG_REP WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'ScheduleEventViolationSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SCHD_EVT_VIOL WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'SewerOverflowBypassEventReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SEWER_OVRFLW_BYPASS_EVT_REP WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'SingleEventViolationSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SNGL_EVT_VIOL WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'SWConstructionPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SW_CNST_PRMT WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'SWIndustrialAnnualReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SW_INDST_ANNUL_REP WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'SWIndustrialPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SW_INDST_PRMT WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'SWMS4AnnualProgramReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SWMS_4_ANNUL_PROG_REP WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'SWMS4PermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SWMS_4_PRMT WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'UnpermittedFacilitySubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_UNPRMT_FAC WHERE transaction_type='N')
 
   END as trans_count_new
    , CASE 
	
      WHEN ics_payload.operation = 'BasicPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_BASIC_PRMT WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'BiosolidsAnnualProgramReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_BS_ANNUL_PROG_REP WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'BiosolidsPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_BS_PRMT WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'CAFOAnnualProgramReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_CAFO_ANNUL_PROG_REP WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'CAFOPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_CAFO_PRMT WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'CollectionSystemPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_COLL_SYSTM_PRMT WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'ComplianceMonitoringSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_CMPL_MON WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'ComplianceMonitoringLinkageSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_CMPL_MON_LNK WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'ComplianceScheduleSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_CMPL_SCHD WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'CopyMGPLimitSetSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_COPY_MGP_LMT_SET WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'CopyMGPMS4RequirementSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_COPY_MGPMS_4_REQ WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'CSOLongTermControlPlanSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_CSO_LONG_TERM_CONTROL_PLAN WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'CWA316bProgramReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_CWA_316B_PROG_REP WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'DischargeMonitoringReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_DSCH_MON_REP WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'DMRViolationSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_DMR_VIOL WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'EffluentTradePartnerSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_EFFLU_TRADE_PRTNER WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'EnforcementActionMilestoneSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_ENFRC_ACTN_MILESTONE WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'EnforcementActionViolationLinkageSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_ENFRC_ACTN_VIOL_LNK WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'FinalOrderViolationLinkageSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_FINAL_ORDER_VIOL_LNK WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'FormalEnforcementActionSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_FRML_ENFRC_ACTN WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'GeneralPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_GNRL_PRMT WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'HistoricalPermitScheduleEventsSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_HIST_PRMT_SCHD_EVTS WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'InformalEnforcementActionSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_INFRML_ENFRC_ACTN WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'LimitsSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_LMTS WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'LimitSetSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_LMT_SET WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'MasterGeneralPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_MASTER_GNRL_PRMT WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'NarrativeConditionScheduleSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_NARR_COND_SCHD WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'NPDESVariancePermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_NPDES_VARIANCE_PRMT WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'ParameterLimitsSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_PARAM_LMTS WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'PermitReissuanceSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_PRMT_REISSU WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'PermittedFeatureSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_PRMT_FEATR WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'PermitTerminationSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_PRMT_TERM WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'PermitTrackingEventSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_PRMT_TRACK_EVT WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'POTWPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_POTW_PRMT WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'POTWTreatmentTechnologyPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'PretreatmentPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_PRETR_PRMT WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'PretreatmentProgramReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_PRETR_PROG_REP WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'ScheduleEventViolationSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SCHD_EVT_VIOL WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'SewerOverflowBypassEventReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SEWER_OVRFLW_BYPASS_EVT_REP WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'SingleEventViolationSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SNGL_EVT_VIOL WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'SWConstructionPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SW_CNST_PRMT WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'SWIndustrialAnnualReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SW_INDST_ANNUL_REP WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'SWIndustrialPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SW_INDST_PRMT WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'SWMS4AnnualProgramReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SWMS_4_ANNUL_PROG_REP WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'SWMS4PermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SWMS_4_PRMT WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'UnpermittedFacilitySubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_UNPRMT_FAC WHERE transaction_type IN ('C','R'))
 	
    END as trans_count_chng_repl	
    , CASE 
	
      WHEN ics_payload.operation = 'BasicPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_BASIC_PRMT WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'BiosolidsAnnualProgramReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_BS_ANNUL_PROG_REP WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'BiosolidsPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_BS_PRMT WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'CAFOAnnualProgramReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_CAFO_ANNUL_PROG_REP WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'CAFOPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_CAFO_PRMT WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'CollectionSystemPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_COLL_SYSTM_PRMT WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'ComplianceMonitoringSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_CMPL_MON WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'ComplianceMonitoringLinkageSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_CMPL_MON_LNK WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'ComplianceScheduleSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_CMPL_SCHD WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'CopyMGPLimitSetSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_COPY_MGP_LMT_SET WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'CopyMGPMS4RequirementSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_COPY_MGPMS_4_REQ WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'CSOLongTermControlPlanSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_CSO_LONG_TERM_CONTROL_PLAN WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'CWA316bProgramReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_CWA_316B_PROG_REP WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'DischargeMonitoringReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_DSCH_MON_REP WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'DMRViolationSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_DMR_VIOL WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'EffluentTradePartnerSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_EFFLU_TRADE_PRTNER WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'EnforcementActionMilestoneSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_ENFRC_ACTN_MILESTONE WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'EnforcementActionViolationLinkageSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_ENFRC_ACTN_VIOL_LNK WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'FinalOrderViolationLinkageSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_FINAL_ORDER_VIOL_LNK WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'FormalEnforcementActionSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_FRML_ENFRC_ACTN WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'GeneralPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_GNRL_PRMT WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'HistoricalPermitScheduleEventsSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_HIST_PRMT_SCHD_EVTS WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'InformalEnforcementActionSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_INFRML_ENFRC_ACTN WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'LimitsSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_LMTS WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'LimitSetSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_LMT_SET WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'MasterGeneralPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_MASTER_GNRL_PRMT WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'NarrativeConditionScheduleSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_NARR_COND_SCHD WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'NPDESVariancePermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_NPDES_VARIANCE_PRMT WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'ParameterLimitsSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_PARAM_LMTS WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'PermitReissuanceSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_PRMT_REISSU WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'PermittedFeatureSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_PRMT_FEATR WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'PermitTerminationSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_PRMT_TERM WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'PermitTrackingEventSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_PRMT_TRACK_EVT WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'POTWPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_POTW_PRMT WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'POTWTreatmentTechnologyPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'PretreatmentPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_PRETR_PRMT WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'PretreatmentProgramReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_PRETR_PROG_REP WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'ScheduleEventViolationSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SCHD_EVT_VIOL WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'SewerOverflowBypassEventReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SEWER_OVRFLW_BYPASS_EVT_REP WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'SingleEventViolationSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SNGL_EVT_VIOL WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'SWConstructionPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SW_CNST_PRMT WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'SWIndustrialAnnualReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SW_INDST_ANNUL_REP WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'SWIndustrialPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SW_INDST_PRMT WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'SWMS4AnnualProgramReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SWMS_4_ANNUL_PROG_REP WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'SWMS4PermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SWMS_4_PRMT WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'UnpermittedFacilitySubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_UNPRMT_FAC WHERE transaction_type IN ('D','X'))
 	
    END as trans_count_del_mass_del
  , (  SELECT count(1) 
         FROM dbo.ics_subm_results
        WHERE subm_type_name = ics_payload.operation
          AND result_type_code = 'Error') as error_count
  , (  SELECT count(1) 
         FROM dbo.ics_subm_results
        WHERE subm_type_name = ics_payload.operation
          AND result_type_code = 'Warning') as warning_count
, (  SELECT count(1) 
         FROM dbo.ics_subm_results
        WHERE subm_type_name = ics_payload.operation
          AND result_type_code = 'Accepted') as accepted_count
  , CASE 
	  
      WHEN ics_payload.operation = 'BasicPermitSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_BASIC_PRMT)
 	  
      WHEN ics_payload.operation = 'BiosolidsAnnualProgramReportSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_BS_ANNUL_PROG_REP)
 	  
      WHEN ics_payload.operation = 'BiosolidsPermitSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_BS_PRMT)
 	  
      WHEN ics_payload.operation = 'CAFOAnnualProgramReportSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_CAFO_ANNUL_PROG_REP)
 	  
      WHEN ics_payload.operation = 'CAFOPermitSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_CAFO_PRMT)
 	  
      WHEN ics_payload.operation = 'CollectionSystemPermitSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_COLL_SYSTM_PRMT)
 	  
      WHEN ics_payload.operation = 'ComplianceMonitoringSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_CMPL_MON)
 	  
      WHEN ics_payload.operation = 'ComplianceMonitoringLinkageSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_CMPL_MON_LNK)
 	  
      WHEN ics_payload.operation = 'ComplianceScheduleSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_CMPL_SCHD)
 	  
      WHEN ics_payload.operation = 'CopyMGPLimitSetSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_COPY_MGP_LMT_SET)
 	  
      WHEN ics_payload.operation = 'CopyMGPMS4RequirementSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_COPY_MGPMS_4_REQ)
 	  
      WHEN ics_payload.operation = 'CSOLongTermControlPlanSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_CSO_LONG_TERM_CONTROL_PLAN)
 	  
      WHEN ics_payload.operation = 'CWA316bProgramReportSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_CWA_316B_PROG_REP)
 	  
      WHEN ics_payload.operation = 'DischargeMonitoringReportSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_DSCH_MON_REP)
 	  
      WHEN ics_payload.operation = 'DMRViolationSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_DMR_VIOL)
 	  
      WHEN ics_payload.operation = 'EffluentTradePartnerSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_EFFLU_TRADE_PRTNER)
 	  
      WHEN ics_payload.operation = 'EnforcementActionMilestoneSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_ENFRC_ACTN_MILESTONE)
 	  
      WHEN ics_payload.operation = 'EnforcementActionViolationLinkageSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_ENFRC_ACTN_VIOL_LNK)
 	  
      WHEN ics_payload.operation = 'FinalOrderViolationLinkageSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_FINAL_ORDER_VIOL_LNK)
 	  
      WHEN ics_payload.operation = 'FormalEnforcementActionSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_FRML_ENFRC_ACTN)
 	  
      WHEN ics_payload.operation = 'GeneralPermitSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_GNRL_PRMT)
 	  
      WHEN ics_payload.operation = 'HistoricalPermitScheduleEventsSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_HIST_PRMT_SCHD_EVTS)
 	  
      WHEN ics_payload.operation = 'InformalEnforcementActionSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_INFRML_ENFRC_ACTN)
 	  
      WHEN ics_payload.operation = 'LimitsSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_LMTS)
 	  
      WHEN ics_payload.operation = 'LimitSetSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_LMT_SET)
 	  
      WHEN ics_payload.operation = 'MasterGeneralPermitSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_MASTER_GNRL_PRMT)
 	  
      WHEN ics_payload.operation = 'NarrativeConditionScheduleSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_NARR_COND_SCHD)
 	  
      WHEN ics_payload.operation = 'NPDESVariancePermitSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_NPDES_VARIANCE_PRMT)
 	  
      WHEN ics_payload.operation = 'ParameterLimitsSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_PARAM_LMTS)
 	  
      WHEN ics_payload.operation = 'PermitReissuanceSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_PRMT_REISSU)
 	  
      WHEN ics_payload.operation = 'PermittedFeatureSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_PRMT_FEATR)
 	  
      WHEN ics_payload.operation = 'PermitTerminationSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_PRMT_TERM)
 	  
      WHEN ics_payload.operation = 'PermitTrackingEventSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_PRMT_TRACK_EVT)
 	  
      WHEN ics_payload.operation = 'POTWPermitSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_POTW_PRMT)
 	  
      WHEN ics_payload.operation = 'POTWTreatmentTechnologyPermitSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT)
 	  
      WHEN ics_payload.operation = 'PretreatmentPermitSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_PRETR_PRMT)
 	  
      WHEN ics_payload.operation = 'PretreatmentProgramReportSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_PRETR_PROG_REP)
 	  
      WHEN ics_payload.operation = 'ScheduleEventViolationSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_SCHD_EVT_VIOL)
 	  
      WHEN ics_payload.operation = 'SewerOverflowBypassEventReportSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_SEWER_OVRFLW_BYPASS_EVT_REP)
 	  
      WHEN ics_payload.operation = 'SingleEventViolationSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_SNGL_EVT_VIOL)
 	  
      WHEN ics_payload.operation = 'SWConstructionPermitSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_SW_CNST_PRMT)
 	  
      WHEN ics_payload.operation = 'SWIndustrialAnnualReportSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_SW_INDST_ANNUL_REP)
 	  
      WHEN ics_payload.operation = 'SWIndustrialPermitSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_SW_INDST_PRMT)
 	  
      WHEN ics_payload.operation = 'SWMS4AnnualProgramReportSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_SWMS_4_ANNUL_PROG_REP)
 	  
      WHEN ics_payload.operation = 'SWMS4PermitSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_SWMS_4_PRMT)
 	  
      WHEN ics_payload.operation = 'UnpermittedFacilitySubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_UNPRMT_FAC)
 	
    END as accepted_count_total
  FROM dbo.ics_payload

GO
