

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.ics_v_module_count'))
DROP VIEW dbo.ics_v_module_count
GO


/*************************************************************************************************
** ObjectName: ics_v_module_count
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view displays a count of accepted, rejected, and warning records for each module
**               Used in process_accepted_transactions procedure to insert into ics_subm_hist
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 4/5/2012      Windsor     Created 
** 5/15/2012     BRensmith   Added columns for count by transaction type
** 5/25/2012     BRensmith   Added column for accepted_count_total
** 12/10/2012    BRensmith   Rewrote view to eliminate possible duplicates, now driven off of ics_payload
** 6/13/2017     CTyler      Added BiosolidsAnnualProgramReportSubmission into query
** 4/6/2025      CTyler      Update to ICIS 5.14
**
***************************************************************************************************/
CREATE VIEW dbo.ics_v_module_count

AS

SELECT operation
    , [enabled]
    , CASE 
	
      WHEN ics_payload.operation = 'BasicPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_BASIC_PRMT)
 	
      WHEN ics_payload.operation = 'BiosolidsAnnualProgramReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_BS_ANNUL_PROG_REP)
 	
      WHEN ics_payload.operation = 'BiosolidsPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_BS_PRMT)
 	
      WHEN ics_payload.operation = 'CAFOAnnualProgramReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_CAFO_ANNUL_PROG_REP)
 	
      WHEN ics_payload.operation = 'CAFOPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_CAFO_PRMT)
 	
      WHEN ics_payload.operation = 'CollectionSystemPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_COLL_SYSTM_PRMT)
 	
      WHEN ics_payload.operation = 'ComplianceMonitoringSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_CMPL_MON)
 	
      WHEN ics_payload.operation = 'ComplianceMonitoringLinkageSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_CMPL_MON_LNK)
 	
      WHEN ics_payload.operation = 'ComplianceScheduleSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_CMPL_SCHD)
 	
      WHEN ics_payload.operation = 'CopyMGPLimitSetSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_COPY_MGP_LMT_SET)
 	
      WHEN ics_payload.operation = 'CopyMGPMS4RequirementSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_COPY_MGPMS_4_REQ)
 	
      WHEN ics_payload.operation = 'CSOLongTermControlPlanSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_CSO_LONG_TERM_CONTROL_PLAN)
 	
      WHEN ics_payload.operation = 'CWA316bProgramReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_CWA_316B_PROG_REP)
 	
      WHEN ics_payload.operation = 'DischargeMonitoringReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_DSCH_MON_REP)
 	
      WHEN ics_payload.operation = 'DMRViolationSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_DMR_VIOL)
 	
      WHEN ics_payload.operation = 'EffluentTradePartnerSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_EFFLU_TRADE_PRTNER)
 	
      WHEN ics_payload.operation = 'EnforcementActionMilestoneSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_ENFRC_ACTN_MILESTONE)
 	
      WHEN ics_payload.operation = 'EnforcementActionViolationLinkageSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_ENFRC_ACTN_VIOL_LNK)
 	
      WHEN ics_payload.operation = 'FinalOrderViolationLinkageSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_FINAL_ORDER_VIOL_LNK)
 	
      WHEN ics_payload.operation = 'FormalEnforcementActionSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_FRML_ENFRC_ACTN)
 	
      WHEN ics_payload.operation = 'GeneralPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_GNRL_PRMT)
 	
      WHEN ics_payload.operation = 'HistoricalPermitScheduleEventsSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_HIST_PRMT_SCHD_EVTS)
 	
      WHEN ics_payload.operation = 'InformalEnforcementActionSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_INFRML_ENFRC_ACTN)
 	
      WHEN ics_payload.operation = 'LimitsSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_LMTS)
 	
      WHEN ics_payload.operation = 'LimitSetSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_LMT_SET)
 	
      WHEN ics_payload.operation = 'MasterGeneralPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_MASTER_GNRL_PRMT)
 	
      WHEN ics_payload.operation = 'NarrativeConditionScheduleSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_NARR_COND_SCHD)
 	
      WHEN ics_payload.operation = 'NPDESVariancePermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_NPDES_VARIANCE_PRMT)
 	
      WHEN ics_payload.operation = 'ParameterLimitsSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_PARAM_LMTS)
 	
      WHEN ics_payload.operation = 'PermitReissuanceSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_PRMT_REISSU)
 	
      WHEN ics_payload.operation = 'PermittedFeatureSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_PRMT_FEATR)
 	
      WHEN ics_payload.operation = 'PermitTerminationSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_PRMT_TERM)
 	
      WHEN ics_payload.operation = 'PermitTrackingEventSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_PRMT_TRACK_EVT)
 	
      WHEN ics_payload.operation = 'POTWPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_POTW_PRMT)
 	
      WHEN ics_payload.operation = 'POTWTreatmentTechnologyPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT)
 	
      WHEN ics_payload.operation = 'PretreatmentPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_PRETR_PRMT)
 	
      WHEN ics_payload.operation = 'PretreatmentProgramReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_PRETR_PROG_REP)
 	
      WHEN ics_payload.operation = 'ScheduleEventViolationSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SCHD_EVT_VIOL)
 	
      WHEN ics_payload.operation = 'SewerOverflowBypassEventReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SEWER_OVRFLW_BYPASS_EVT_REP)
 	
      WHEN ics_payload.operation = 'SingleEventViolationSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SNGL_EVT_VIOL)
 	
      WHEN ics_payload.operation = 'SWConstructionPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SW_CNST_PRMT)
 	
      WHEN ics_payload.operation = 'SWIndustrialAnnualReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SW_INDST_ANNUL_REP)
 	
      WHEN ics_payload.operation = 'SWIndustrialPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SW_INDST_PRMT)
 	
      WHEN ics_payload.operation = 'SWMS4AnnualProgramReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SWMS_4_ANNUL_PROG_REP)
 	
      WHEN ics_payload.operation = 'SWMS4PermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SWMS_4_PRMT)
 	
      WHEN ics_payload.operation = 'UnpermittedFacilitySubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_UNPRMT_FAC)
 
    END as trans_count_staged
  , CASE 
	
      WHEN ics_payload.operation = 'BasicPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_BASIC_PRMT WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'BiosolidsAnnualProgramReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_BS_ANNUL_PROG_REP WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'BiosolidsPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_BS_PRMT WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'CAFOAnnualProgramReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_CAFO_ANNUL_PROG_REP WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'CAFOPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_CAFO_PRMT WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'CollectionSystemPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_COLL_SYSTM_PRMT WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'ComplianceMonitoringSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_CMPL_MON WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'ComplianceMonitoringLinkageSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_CMPL_MON_LNK WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'ComplianceScheduleSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_CMPL_SCHD WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'CopyMGPLimitSetSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_COPY_MGP_LMT_SET WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'CopyMGPMS4RequirementSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_COPY_MGPMS_4_REQ WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'CSOLongTermControlPlanSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_CSO_LONG_TERM_CONTROL_PLAN WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'CWA316bProgramReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_CWA_316B_PROG_REP WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'DischargeMonitoringReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_DSCH_MON_REP WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'DMRViolationSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_DMR_VIOL WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'EffluentTradePartnerSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_EFFLU_TRADE_PRTNER WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'EnforcementActionMilestoneSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_ENFRC_ACTN_MILESTONE WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'EnforcementActionViolationLinkageSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_ENFRC_ACTN_VIOL_LNK WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'FinalOrderViolationLinkageSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_FINAL_ORDER_VIOL_LNK WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'FormalEnforcementActionSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_FRML_ENFRC_ACTN WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'GeneralPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_GNRL_PRMT WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'HistoricalPermitScheduleEventsSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_HIST_PRMT_SCHD_EVTS WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'InformalEnforcementActionSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_INFRML_ENFRC_ACTN WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'LimitsSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_LMTS WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'LimitSetSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_LMT_SET WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'MasterGeneralPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_MASTER_GNRL_PRMT WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'NarrativeConditionScheduleSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_NARR_COND_SCHD WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'NPDESVariancePermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_NPDES_VARIANCE_PRMT WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'ParameterLimitsSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_PARAM_LMTS WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'PermitReissuanceSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_PRMT_REISSU WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'PermittedFeatureSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_PRMT_FEATR WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'PermitTerminationSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_PRMT_TERM WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'PermitTrackingEventSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_PRMT_TRACK_EVT WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'POTWPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_POTW_PRMT WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'POTWTreatmentTechnologyPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'PretreatmentPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_PRETR_PRMT WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'PretreatmentProgramReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_PRETR_PROG_REP WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'ScheduleEventViolationSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SCHD_EVT_VIOL WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'SewerOverflowBypassEventReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SEWER_OVRFLW_BYPASS_EVT_REP WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'SingleEventViolationSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SNGL_EVT_VIOL WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'SWConstructionPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SW_CNST_PRMT WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'SWIndustrialAnnualReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SW_INDST_ANNUL_REP WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'SWIndustrialPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SW_INDST_PRMT WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'SWMS4AnnualProgramReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SWMS_4_ANNUL_PROG_REP WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'SWMS4PermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SWMS_4_PRMT WHERE transaction_type='N')
 	
      WHEN ics_payload.operation = 'UnpermittedFacilitySubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_UNPRMT_FAC WHERE transaction_type='N')
 
   END as trans_count_new
    , CASE 
	
      WHEN ics_payload.operation = 'BasicPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_BASIC_PRMT WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'BiosolidsAnnualProgramReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_BS_ANNUL_PROG_REP WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'BiosolidsPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_BS_PRMT WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'CAFOAnnualProgramReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_CAFO_ANNUL_PROG_REP WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'CAFOPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_CAFO_PRMT WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'CollectionSystemPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_COLL_SYSTM_PRMT WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'ComplianceMonitoringSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_CMPL_MON WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'ComplianceMonitoringLinkageSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_CMPL_MON_LNK WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'ComplianceScheduleSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_CMPL_SCHD WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'CopyMGPLimitSetSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_COPY_MGP_LMT_SET WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'CopyMGPMS4RequirementSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_COPY_MGPMS_4_REQ WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'CSOLongTermControlPlanSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_CSO_LONG_TERM_CONTROL_PLAN WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'CWA316bProgramReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_CWA_316B_PROG_REP WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'DischargeMonitoringReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_DSCH_MON_REP WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'DMRViolationSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_DMR_VIOL WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'EffluentTradePartnerSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_EFFLU_TRADE_PRTNER WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'EnforcementActionMilestoneSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_ENFRC_ACTN_MILESTONE WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'EnforcementActionViolationLinkageSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_ENFRC_ACTN_VIOL_LNK WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'FinalOrderViolationLinkageSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_FINAL_ORDER_VIOL_LNK WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'FormalEnforcementActionSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_FRML_ENFRC_ACTN WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'GeneralPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_GNRL_PRMT WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'HistoricalPermitScheduleEventsSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_HIST_PRMT_SCHD_EVTS WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'InformalEnforcementActionSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_INFRML_ENFRC_ACTN WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'LimitsSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_LMTS WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'LimitSetSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_LMT_SET WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'MasterGeneralPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_MASTER_GNRL_PRMT WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'NarrativeConditionScheduleSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_NARR_COND_SCHD WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'NPDESVariancePermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_NPDES_VARIANCE_PRMT WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'ParameterLimitsSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_PARAM_LMTS WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'PermitReissuanceSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_PRMT_REISSU WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'PermittedFeatureSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_PRMT_FEATR WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'PermitTerminationSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_PRMT_TERM WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'PermitTrackingEventSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_PRMT_TRACK_EVT WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'POTWPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_POTW_PRMT WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'POTWTreatmentTechnologyPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'PretreatmentPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_PRETR_PRMT WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'PretreatmentProgramReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_PRETR_PROG_REP WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'ScheduleEventViolationSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SCHD_EVT_VIOL WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'SewerOverflowBypassEventReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SEWER_OVRFLW_BYPASS_EVT_REP WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'SingleEventViolationSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SNGL_EVT_VIOL WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'SWConstructionPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SW_CNST_PRMT WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'SWIndustrialAnnualReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SW_INDST_ANNUL_REP WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'SWIndustrialPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SW_INDST_PRMT WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'SWMS4AnnualProgramReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SWMS_4_ANNUL_PROG_REP WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'SWMS4PermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SWMS_4_PRMT WHERE transaction_type IN ('C','R'))
 	
      WHEN ics_payload.operation = 'UnpermittedFacilitySubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_UNPRMT_FAC WHERE transaction_type IN ('C','R'))
 	
    END as trans_count_chng_repl	
    , CASE 
	
      WHEN ics_payload.operation = 'BasicPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_BASIC_PRMT WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'BiosolidsAnnualProgramReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_BS_ANNUL_PROG_REP WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'BiosolidsPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_BS_PRMT WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'CAFOAnnualProgramReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_CAFO_ANNUL_PROG_REP WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'CAFOPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_CAFO_PRMT WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'CollectionSystemPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_COLL_SYSTM_PRMT WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'ComplianceMonitoringSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_CMPL_MON WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'ComplianceMonitoringLinkageSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_CMPL_MON_LNK WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'ComplianceScheduleSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_CMPL_SCHD WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'CopyMGPLimitSetSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_COPY_MGP_LMT_SET WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'CopyMGPMS4RequirementSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_COPY_MGPMS_4_REQ WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'CSOLongTermControlPlanSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_CSO_LONG_TERM_CONTROL_PLAN WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'CWA316bProgramReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_CWA_316B_PROG_REP WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'DischargeMonitoringReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_DSCH_MON_REP WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'DMRViolationSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_DMR_VIOL WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'EffluentTradePartnerSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_EFFLU_TRADE_PRTNER WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'EnforcementActionMilestoneSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_ENFRC_ACTN_MILESTONE WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'EnforcementActionViolationLinkageSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_ENFRC_ACTN_VIOL_LNK WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'FinalOrderViolationLinkageSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_FINAL_ORDER_VIOL_LNK WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'FormalEnforcementActionSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_FRML_ENFRC_ACTN WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'GeneralPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_GNRL_PRMT WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'HistoricalPermitScheduleEventsSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_HIST_PRMT_SCHD_EVTS WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'InformalEnforcementActionSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_INFRML_ENFRC_ACTN WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'LimitsSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_LMTS WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'LimitSetSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_LMT_SET WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'MasterGeneralPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_MASTER_GNRL_PRMT WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'NarrativeConditionScheduleSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_NARR_COND_SCHD WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'NPDESVariancePermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_NPDES_VARIANCE_PRMT WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'ParameterLimitsSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_PARAM_LMTS WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'PermitReissuanceSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_PRMT_REISSU WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'PermittedFeatureSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_PRMT_FEATR WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'PermitTerminationSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_PRMT_TERM WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'PermitTrackingEventSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_PRMT_TRACK_EVT WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'POTWPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_POTW_PRMT WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'POTWTreatmentTechnologyPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'PretreatmentPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_PRETR_PRMT WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'PretreatmentProgramReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_PRETR_PROG_REP WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'ScheduleEventViolationSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SCHD_EVT_VIOL WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'SewerOverflowBypassEventReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SEWER_OVRFLW_BYPASS_EVT_REP WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'SingleEventViolationSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SNGL_EVT_VIOL WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'SWConstructionPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SW_CNST_PRMT WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'SWIndustrialAnnualReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SW_INDST_ANNUL_REP WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'SWIndustrialPermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SW_INDST_PRMT WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'SWMS4AnnualProgramReportSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SWMS_4_ANNUL_PROG_REP WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'SWMS4PermitSubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_SWMS_4_PRMT WHERE transaction_type IN ('D','X'))
 	
      WHEN ics_payload.operation = 'UnpermittedFacilitySubmission' THEN (SELECT COUNT(1) FROM dbo.ICS_UNPRMT_FAC WHERE transaction_type IN ('D','X'))
 	
    END as trans_count_del_mass_del
  , (  SELECT count(1) 
         FROM dbo.ics_subm_results
        WHERE subm_type_name = ics_payload.operation
          AND result_type_code = 'Error') as error_count
  , (  SELECT count(1) 
         FROM dbo.ics_subm_results
        WHERE subm_type_name = ics_payload.operation
          AND result_type_code = 'Warning') as warning_count
, (  SELECT count(1) 
         FROM dbo.ics_subm_results
        WHERE subm_type_name = ics_payload.operation
          AND result_type_code = 'Accepted') as accepted_count
  , CASE 
	  
      WHEN ics_payload.operation = 'BasicPermitSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_BASIC_PRMT)
 	  
      WHEN ics_payload.operation = 'BiosolidsAnnualProgramReportSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_BS_ANNUL_PROG_REP)
 	  
      WHEN ics_payload.operation = 'BiosolidsPermitSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_BS_PRMT)
 	  
      WHEN ics_payload.operation = 'CAFOAnnualProgramReportSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_CAFO_ANNUL_PROG_REP)
 	  
      WHEN ics_payload.operation = 'CAFOPermitSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_CAFO_PRMT)
 	  
      WHEN ics_payload.operation = 'CollectionSystemPermitSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_COLL_SYSTM_PRMT)
 	  
      WHEN ics_payload.operation = 'ComplianceMonitoringSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_CMPL_MON)
 	  
      WHEN ics_payload.operation = 'ComplianceMonitoringLinkageSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_CMPL_MON_LNK)
 	  
      WHEN ics_payload.operation = 'ComplianceScheduleSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_CMPL_SCHD)
 	  
      WHEN ics_payload.operation = 'CopyMGPLimitSetSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_COPY_MGP_LMT_SET)
 	  
      WHEN ics_payload.operation = 'CopyMGPMS4RequirementSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_COPY_MGPMS_4_REQ)
 	  
      WHEN ics_payload.operation = 'CSOLongTermControlPlanSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_CSO_LONG_TERM_CONTROL_PLAN)
 	  
      WHEN ics_payload.operation = 'CWA316bProgramReportSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_CWA_316B_PROG_REP)
 	  
      WHEN ics_payload.operation = 'DischargeMonitoringReportSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_DSCH_MON_REP)
 	  
      WHEN ics_payload.operation = 'DMRViolationSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_DMR_VIOL)
 	  
      WHEN ics_payload.operation = 'EffluentTradePartnerSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_EFFLU_TRADE_PRTNER)
 	  
      WHEN ics_payload.operation = 'EnforcementActionMilestoneSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_ENFRC_ACTN_MILESTONE)
 	  
      WHEN ics_payload.operation = 'EnforcementActionViolationLinkageSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_ENFRC_ACTN_VIOL_LNK)
 	  
      WHEN ics_payload.operation = 'FinalOrderViolationLinkageSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_FINAL_ORDER_VIOL_LNK)
 	  
      WHEN ics_payload.operation = 'FormalEnforcementActionSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_FRML_ENFRC_ACTN)
 	  
      WHEN ics_payload.operation = 'GeneralPermitSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_GNRL_PRMT)
 	  
      WHEN ics_payload.operation = 'HistoricalPermitScheduleEventsSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_HIST_PRMT_SCHD_EVTS)
 	  
      WHEN ics_payload.operation = 'InformalEnforcementActionSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_INFRML_ENFRC_ACTN)
 	  
      WHEN ics_payload.operation = 'LimitsSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_LMTS)
 	  
      WHEN ics_payload.operation = 'LimitSetSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_LMT_SET)
 	  
      WHEN ics_payload.operation = 'MasterGeneralPermitSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_MASTER_GNRL_PRMT)
 	  
      WHEN ics_payload.operation = 'NarrativeConditionScheduleSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_NARR_COND_SCHD)
 	  
      WHEN ics_payload.operation = 'NPDESVariancePermitSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_NPDES_VARIANCE_PRMT)
 	  
      WHEN ics_payload.operation = 'ParameterLimitsSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_PARAM_LMTS)
 	  
      WHEN ics_payload.operation = 'PermitReissuanceSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_PRMT_REISSU)
 	  
      WHEN ics_payload.operation = 'PermittedFeatureSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_PRMT_FEATR)
 	  
      WHEN ics_payload.operation = 'PermitTerminationSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_PRMT_TERM)
 	  
      WHEN ics_payload.operation = 'PermitTrackingEventSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_PRMT_TRACK_EVT)
 	  
      WHEN ics_payload.operation = 'POTWPermitSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_POTW_PRMT)
 	  
      WHEN ics_payload.operation = 'POTWTreatmentTechnologyPermitSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT)
 	  
      WHEN ics_payload.operation = 'PretreatmentPermitSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_PRETR_PRMT)
 	  
      WHEN ics_payload.operation = 'PretreatmentProgramReportSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_PRETR_PROG_REP)
 	  
      WHEN ics_payload.operation = 'ScheduleEventViolationSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_SCHD_EVT_VIOL)
 	  
      WHEN ics_payload.operation = 'SewerOverflowBypassEventReportSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_SEWER_OVRFLW_BYPASS_EVT_REP)
 	  
      WHEN ics_payload.operation = 'SingleEventViolationSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_SNGL_EVT_VIOL)
 	  
      WHEN ics_payload.operation = 'SWConstructionPermitSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_SW_CNST_PRMT)
 	  
      WHEN ics_payload.operation = 'SWIndustrialAnnualReportSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_SW_INDST_ANNUL_REP)
 	  
      WHEN ics_payload.operation = 'SWIndustrialPermitSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_SW_INDST_PRMT)
 	  
      WHEN ics_payload.operation = 'SWMS4AnnualProgramReportSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_SWMS_4_ANNUL_PROG_REP)
 	  
      WHEN ics_payload.operation = 'SWMS4PermitSubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_SWMS_4_PRMT)
 	  
      WHEN ics_payload.operation = 'UnpermittedFacilitySubmission' THEN (SELECT COUNT(1) FROM ics_flow_icis.dbo.ICS_UNPRMT_FAC)
 	
    END as accepted_count_total
  FROM dbo.ics_payload

GO
