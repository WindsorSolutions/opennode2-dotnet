﻿BEGIN TRANSACTION

SET ANSI_NULLS, ANSI_PADDING, ANSI_WARNINGS, ARITHABORT, CONCAT_NULL_YIELDS_NULL, QUOTED_IDENTIFIER ON;
SET NUMERIC_ROUNDABORT OFF;
PRINT N'Dropping Extended Property [dbo].[ICS_BS_END_USE_DSPL_TYPE].[BS_END_USE_DSPL_TYPE_CODE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_END_USE_DSPL_TYPE', @level2type = N'COLUMN', @level2name = N'BS_END_USE_DSPL_TYPE_CODE';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_MGMT_PRACTICES].[SSU_IDENT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_MGMT_PRACTICES', @level2type = N'COLUMN', @level2name = N'SSU_IDENT';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_MGMT_PRACTICES].[BS_MGMT_PRC_TYPE_CODE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_MGMT_PRACTICES', @level2type = N'COLUMN', @level2name = N'BS_MGMT_PRC_TYPE_CODE';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_MGMT_PRACTICES].[HNDLR_PREPR_TYPE_CODE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_MGMT_PRACTICES', @level2type = N'COLUMN', @level2name = N'HNDLR_PREPR_TYPE_CODE';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_MGMT_PRACTICES].[LAND_APPL_SUB_CATG_CODE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_MGMT_PRACTICES', @level2type = N'COLUMN', @level2name = N'LAND_APPL_SUB_CATG_CODE';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_MGMT_PRACTICES].[OTHR_SUB_CATG_CODE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_MGMT_PRACTICES', @level2type = N'COLUMN', @level2name = N'OTHR_SUB_CATG_CODE';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_MGMT_PRACTICES].[SUB_CATG_OTHR_TXT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_MGMT_PRACTICES', @level2type = N'COLUMN', @level2name = N'SUB_CATG_OTHR_TXT';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_MGMT_PRACTICES].[BS_CNTNR_TYPE_CODE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_MGMT_PRACTICES', @level2type = N'COLUMN', @level2name = N'BS_CNTNR_TYPE_CODE';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_MGMT_PRACTICES].[VOL_AMT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_MGMT_PRACTICES', @level2type = N'COLUMN', @level2name = N'VOL_AMT';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_MGMT_PRACTICES].[PATHOGEN_CLASS_TYPE_CODE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_MGMT_PRACTICES', @level2type = N'COLUMN', @level2name = N'PATHOGEN_CLASS_TYPE_CODE';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_MGMT_PRACTICES].[POLUT_CONCEN_EXCEEDANCE_IND].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_MGMT_PRACTICES', @level2type = N'COLUMN', @level2name = N'POLUT_CONCEN_EXCEEDANCE_IND';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_MGMT_PRACTICES].[POLUT_LOADING_R_EXCEEDANCE_IND].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_MGMT_PRACTICES', @level2type = N'COLUMN', @level2name = N'POLUT_LOADING_R_EXCEEDANCE_IND';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_MGMT_PRACTICES].[ACTIVE_DSPL_SITE_IND].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_MGMT_PRACTICES', @level2type = N'COLUMN', @level2name = N'ACTIVE_DSPL_SITE_IND';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_MGMT_PRACTICES].[SITE_SPEC_LMT_IND].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_MGMT_PRACTICES', @level2type = N'COLUMN', @level2name = N'SITE_SPEC_LMT_IND';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_MGMT_PRACTICES].[MIN_BNDRY_DIST_IND].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_MGMT_PRACTICES', @level2type = N'COLUMN', @level2name = N'MIN_BNDRY_DIST_IND';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_MGMT_PRACTICES].[MIN_BNDRY_DIST_TYPE_CODE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_MGMT_PRACTICES', @level2type = N'COLUMN', @level2name = N'MIN_BNDRY_DIST_TYPE_CODE';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_MGMT_PRACTICES].[ASSC_PRMT_IDENT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_MGMT_PRACTICES', @level2type = N'COLUMN', @level2name = N'ASSC_PRMT_IDENT';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_MGMT_PRACTICES].[MGMT_PRC_CMNT_TXT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_MGMT_PRACTICES', @level2type = N'COLUMN', @level2name = N'MGMT_PRC_CMNT_TXT';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_PROG_REP].[SRC_SYSTM_IDENT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_PROG_REP', @level2type = N'COLUMN', @level2name = N'SRC_SYSTM_IDENT';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_PROG_REP].[TRANSACTION_TYPE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_PROG_REP', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TYPE';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_PROG_REP].[TRANSACTION_TIMESTAMP].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_PROG_REP', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TIMESTAMP';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_PROG_REP].[PRMT_IDENT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_PROG_REP', @level2type = N'COLUMN', @level2name = N'PRMT_IDENT';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_PROG_REP].[REP_COVERAGE_END_DATE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_PROG_REP', @level2type = N'COLUMN', @level2name = N'REP_COVERAGE_END_DATE';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_PROG_REP].[NUM_OF_REP_UNITS].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_PROG_REP', @level2type = N'COLUMN', @level2name = N'NUM_OF_REP_UNITS';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_PROG_REP].[EQ_PROD_DIST_MARKETED_AMT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_PROG_REP', @level2type = N'COLUMN', @level2name = N'EQ_PROD_DIST_MARKETED_AMT';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_PROG_REP].[LAND_APPLIED_AMT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_PROG_REP', @level2type = N'COLUMN', @level2name = N'LAND_APPLIED_AMT';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_PROG_REP].[INCINERATED_AMT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_PROG_REP', @level2type = N'COLUMN', @level2name = N'INCINERATED_AMT';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_PROG_REP].[CODISPOSED_IN_MSW_LANDFILL_AMT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_PROG_REP', @level2type = N'COLUMN', @level2name = N'CODISPOSED_IN_MSW_LANDFILL_AMT';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_PROG_REP].[SURF_DSPL_AMT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_PROG_REP', @level2type = N'COLUMN', @level2name = N'SURF_DSPL_AMT';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_PROG_REP].[MNGED_OTHR_MTHDS_AMT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_PROG_REP', @level2type = N'COLUMN', @level2name = N'MNGED_OTHR_MTHDS_AMT';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_PROG_REP].[RCVD_OFFSITE_SRCS_AMT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_PROG_REP', @level2type = N'COLUMN', @level2name = N'RCVD_OFFSITE_SRCS_AMT';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_PROG_REP].[TRANSFERRED_AMT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_PROG_REP', @level2type = N'COLUMN', @level2name = N'TRANSFERRED_AMT';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_PROG_REP].[DISPOSED_OUT_OF_ST_AMT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_PROG_REP', @level2type = N'COLUMN', @level2name = N'DISPOSED_OUT_OF_ST_AMT';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_PROG_REP].[BENEF_USED_OUT_OF_ST_AMT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_PROG_REP', @level2type = N'COLUMN', @level2name = N'BENEF_USED_OUT_OF_ST_AMT';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_PROG_REP].[MNGED_OTHR_MTHDS_OUT_OF_ST_AMT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_PROG_REP', @level2type = N'COLUMN', @level2name = N'MNGED_OTHR_MTHDS_OUT_OF_ST_AMT';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_PROG_REP].[TTL_REMOVED_AMT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_PROG_REP', @level2type = N'COLUMN', @level2name = N'TTL_REMOVED_AMT';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_PROG_REP].[ANNUL_DRY_SLDG_PROD_NUM].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_PROG_REP', @level2type = N'COLUMN', @level2name = N'ANNUL_DRY_SLDG_PROD_NUM';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_PROG_REP].[ANNUL_LOADING_PARAM_DATE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_PROG_REP', @level2type = N'COLUMN', @level2name = N'ANNUL_LOADING_PARAM_DATE';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_PROG_REP].[ANNUL_LOADING_BS_GAL].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_PROG_REP', @level2type = N'COLUMN', @level2name = N'ANNUL_LOADING_BS_GAL';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_PROG_REP].[ANNUL_LOADING_BS_DMT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_PROG_REP', @level2type = N'COLUMN', @level2name = N'ANNUL_LOADING_BS_DMT';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_PROG_REP].[ANNUL_LOADING_NUTR_NITROGEN].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_PROG_REP', @level2type = N'COLUMN', @level2name = N'ANNUL_LOADING_NUTR_NITROGEN';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_PROG_REP].[ANNUL_LOADING_NUTR_PHOSPH].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_PROG_REP', @level2type = N'COLUMN', @level2name = N'ANNUL_LOADING_NUTR_PHOSPH';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_PROG_REP].[TTL_NUM_LAND_APPL_VIOL].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_PROG_REP', @level2type = N'COLUMN', @level2name = N'TTL_NUM_LAND_APPL_VIOL';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_PROG_REP].[TTL_NUM_INCIN_VIOL].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_PROG_REP', @level2type = N'COLUMN', @level2name = N'TTL_NUM_INCIN_VIOL';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_PROG_REP].[TTL_NUM_DIST_MARKETING_VIOL].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_PROG_REP', @level2type = N'COLUMN', @level2name = N'TTL_NUM_DIST_MARKETING_VIOL';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_PROG_REP].[TTL_NUM_SLDG_RLT_MGMT_PRC_VIOL].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_PROG_REP', @level2type = N'COLUMN', @level2name = N'TTL_NUM_SLDG_RLT_MGMT_PRC_VIOL';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_PROG_REP].[TTL_NUM_SURF_DSPL_VIOL].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_PROG_REP', @level2type = N'COLUMN', @level2name = N'TTL_NUM_SURF_DSPL_VIOL';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_PROG_REP].[TTL_NUM_OTHR_SLDG_VIOL].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_PROG_REP', @level2type = N'COLUMN', @level2name = N'TTL_NUM_OTHR_SLDG_VIOL';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_PROG_REP].[TTL_NUM_CODISPOSAL_VIOL].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_PROG_REP', @level2type = N'COLUMN', @level2name = N'TTL_NUM_CODISPOSAL_VIOL';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_PROG_REP].[BS_REP_CMNTS].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_PROG_REP', @level2type = N'COLUMN', @level2name = N'BS_REP_CMNTS';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_TYPE].[BS_TYPE_CODE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_TYPE', @level2type = N'COLUMN', @level2name = N'BS_TYPE_CODE';

PRINT N'Dropping Extended Property [dbo].[ICS_CAFO_ANNUL_REP].[SRC_SYSTM_IDENT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_ANNUL_REP', @level2type = N'COLUMN', @level2name = N'SRC_SYSTM_IDENT';

PRINT N'Dropping Extended Property [dbo].[ICS_CAFO_ANNUL_REP].[TRANSACTION_TYPE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_ANNUL_REP', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TYPE';

PRINT N'Dropping Extended Property [dbo].[ICS_CAFO_ANNUL_REP].[TRANSACTION_TIMESTAMP].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_ANNUL_REP', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TIMESTAMP';

PRINT N'Dropping Extended Property [dbo].[ICS_CAFO_ANNUL_REP].[PRMT_IDENT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_ANNUL_REP', @level2type = N'COLUMN', @level2name = N'PRMT_IDENT';

PRINT N'Dropping Extended Property [dbo].[ICS_CAFO_ANNUL_REP].[PRMT_AUTH_REP_RCVD_DATE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_ANNUL_REP', @level2type = N'COLUMN', @level2name = N'PRMT_AUTH_REP_RCVD_DATE';

PRINT N'Dropping Extended Property [dbo].[ICS_CAFO_ANNUL_REP].[DSCH_DRNG_YEAR_PROD_AREA_IND].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_ANNUL_REP', @level2type = N'COLUMN', @level2name = N'DSCH_DRNG_YEAR_PROD_AREA_IND';

PRINT N'Dropping Extended Property [dbo].[ICS_CAFO_ANNUL_REP].[SOLID_MNUR_LTTR_GNRTD_AMT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_ANNUL_REP', @level2type = N'COLUMN', @level2name = N'SOLID_MNUR_LTTR_GNRTD_AMT';

PRINT N'Dropping Extended Property [dbo].[ICS_CAFO_ANNUL_REP].[LIQUID_MNUR_WW_GNRTD_AMT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_ANNUL_REP', @level2type = N'COLUMN', @level2name = N'LIQUID_MNUR_WW_GNRTD_AMT';

PRINT N'Dropping Extended Property [dbo].[ICS_CAFO_ANNUL_REP].[SOLID_MNUR_LTTR_TRANS_AMT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_ANNUL_REP', @level2type = N'COLUMN', @level2name = N'SOLID_MNUR_LTTR_TRANS_AMT';

PRINT N'Dropping Extended Property [dbo].[ICS_CAFO_ANNUL_REP].[LIQUID_MNUR_WW_TRANS_AMT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_ANNUL_REP', @level2type = N'COLUMN', @level2name = N'LIQUID_MNUR_WW_TRANS_AMT';

PRINT N'Dropping Extended Property [dbo].[ICS_CAFO_ANNUL_REP].[NMP_DVLPD_CERT_PLNR_APRVD_IND].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_ANNUL_REP', @level2type = N'COLUMN', @level2name = N'NMP_DVLPD_CERT_PLNR_APRVD_IND';

PRINT N'Dropping Extended Property [dbo].[ICS_CAFO_ANNUL_REP].[TTL_NUM_ACRES_NMP_IDNTFD].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_ANNUL_REP', @level2type = N'COLUMN', @level2name = N'TTL_NUM_ACRES_NMP_IDNTFD';

PRINT N'Dropping Extended Property [dbo].[ICS_CAFO_ANNUL_REP].[TTL_NUM_ACRES_USED_LAND_APPL].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_ANNUL_REP', @level2type = N'COLUMN', @level2name = N'TTL_NUM_ACRES_USED_LAND_APPL';

PRINT N'Dropping Extended Property [dbo].[ICS_CSO_EVT_REP].[SRC_SYSTM_IDENT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CSO_EVT_REP', @level2type = N'COLUMN', @level2name = N'SRC_SYSTM_IDENT';

PRINT N'Dropping Extended Property [dbo].[ICS_CSO_EVT_REP].[TRANSACTION_TYPE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CSO_EVT_REP', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TYPE';

PRINT N'Dropping Extended Property [dbo].[ICS_CSO_EVT_REP].[TRANSACTION_TIMESTAMP].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CSO_EVT_REP', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TIMESTAMP';

PRINT N'Dropping Extended Property [dbo].[ICS_CSO_EVT_REP].[PRMT_IDENT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CSO_EVT_REP', @level2type = N'COLUMN', @level2name = N'PRMT_IDENT';

PRINT N'Dropping Extended Property [dbo].[ICS_CSO_EVT_REP].[CSO_EVT_DATE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CSO_EVT_REP', @level2type = N'COLUMN', @level2name = N'CSO_EVT_DATE';

PRINT N'Dropping Extended Property [dbo].[ICS_CSO_EVT_REP].[CSO_EVT_ID].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CSO_EVT_REP', @level2type = N'COLUMN', @level2name = N'CSO_EVT_ID';

PRINT N'Dropping Extended Property [dbo].[ICS_CSO_EVT_REP].[DRY_OR_WET_WEATHER_IND].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CSO_EVT_REP', @level2type = N'COLUMN', @level2name = N'DRY_OR_WET_WEATHER_IND';

PRINT N'Dropping Extended Property [dbo].[ICS_CSO_EVT_REP].[PRMT_FEATR_IDENT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CSO_EVT_REP', @level2type = N'COLUMN', @level2name = N'PRMT_FEATR_IDENT';

PRINT N'Dropping Extended Property [dbo].[ICS_CSO_EVT_REP].[LAT_MEAS].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CSO_EVT_REP', @level2type = N'COLUMN', @level2name = N'LAT_MEAS';

PRINT N'Dropping Extended Property [dbo].[ICS_CSO_EVT_REP].[LONG_MEAS].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CSO_EVT_REP', @level2type = N'COLUMN', @level2name = N'LONG_MEAS';

PRINT N'Dropping Extended Property [dbo].[ICS_CSO_EVT_REP].[CSO_OVRFLW_LOC_STREET].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CSO_EVT_REP', @level2type = N'COLUMN', @level2name = N'CSO_OVRFLW_LOC_STREET';

PRINT N'Dropping Extended Property [dbo].[ICS_CSO_EVT_REP].[DURATION_CSO_OVRFLW_EVT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CSO_EVT_REP', @level2type = N'COLUMN', @level2name = N'DURATION_CSO_OVRFLW_EVT';

PRINT N'Dropping Extended Property [dbo].[ICS_CSO_EVT_REP].[DSCH_VOL_TREATED].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CSO_EVT_REP', @level2type = N'COLUMN', @level2name = N'DSCH_VOL_TREATED';

PRINT N'Dropping Extended Property [dbo].[ICS_CSO_EVT_REP].[DSCH_VOL_UNTREATED].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CSO_EVT_REP', @level2type = N'COLUMN', @level2name = N'DSCH_VOL_UNTREATED';

PRINT N'Dropping Extended Property [dbo].[ICS_CSO_EVT_REP].[CORR_ACTN_TAKEN_DESC_TXT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CSO_EVT_REP', @level2type = N'COLUMN', @level2name = N'CORR_ACTN_TAKEN_DESC_TXT';

PRINT N'Dropping Extended Property [dbo].[ICS_CSO_EVT_REP].[INCHES_PRECIP].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CSO_EVT_REP', @level2type = N'COLUMN', @level2name = N'INCHES_PRECIP';

PRINT N'Dropping Extended Property [dbo].[ICS_CSO_PRMT].[SRC_SYSTM_IDENT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CSO_PRMT', @level2type = N'COLUMN', @level2name = N'SRC_SYSTM_IDENT';

PRINT N'Dropping Extended Property [dbo].[ICS_CSO_PRMT].[TRANSACTION_TYPE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CSO_PRMT', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TYPE';

PRINT N'Dropping Extended Property [dbo].[ICS_CSO_PRMT].[TRANSACTION_TIMESTAMP].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CSO_PRMT', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TIMESTAMP';

PRINT N'Dropping Extended Property [dbo].[ICS_CSO_PRMT].[PRMT_IDENT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CSO_PRMT', @level2type = N'COLUMN', @level2name = N'PRMT_IDENT';

PRINT N'Dropping Extended Property [dbo].[ICS_CSO_PRMT].[CSS_POPL_SERVED_NUM].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CSO_PRMT', @level2type = N'COLUMN', @level2name = N'CSS_POPL_SERVED_NUM';

PRINT N'Dropping Extended Property [dbo].[ICS_CSO_PRMT].[COMBINED_SEWER_SYSTM_LENGTH].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CSO_PRMT', @level2type = N'COLUMN', @level2name = N'COMBINED_SEWER_SYSTM_LENGTH';

PRINT N'Dropping Extended Property [dbo].[ICS_CSO_PRMT].[COLL_SYSTM_COMBINED_PERCENT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CSO_PRMT', @level2type = N'COLUMN', @level2name = N'COLL_SYSTM_COMBINED_PERCENT';

PRINT N'Dropping Extended Property [dbo].[ICS_DMR_PROG_REP_LNK].[SRC_SYSTM_IDENT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_DMR_PROG_REP_LNK', @level2type = N'COLUMN', @level2name = N'SRC_SYSTM_IDENT';

PRINT N'Dropping Extended Property [dbo].[ICS_DMR_PROG_REP_LNK].[TRANSACTION_TYPE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_DMR_PROG_REP_LNK', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TYPE';

PRINT N'Dropping Extended Property [dbo].[ICS_DMR_PROG_REP_LNK].[TRANSACTION_TIMESTAMP].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_DMR_PROG_REP_LNK', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TIMESTAMP';

PRINT N'Dropping Extended Property [dbo].[ICS_DMR_PROG_REP_LNK].[PRMT_IDENT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_DMR_PROG_REP_LNK', @level2type = N'COLUMN', @level2name = N'PRMT_IDENT';

PRINT N'Dropping Extended Property [dbo].[ICS_DMR_PROG_REP_LNK].[PRMT_FEATR_IDENT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_DMR_PROG_REP_LNK', @level2type = N'COLUMN', @level2name = N'PRMT_FEATR_IDENT';

PRINT N'Dropping Extended Property [dbo].[ICS_DMR_PROG_REP_LNK].[LMT_SET_DESIGNATOR].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_DMR_PROG_REP_LNK', @level2type = N'COLUMN', @level2name = N'LMT_SET_DESIGNATOR';

PRINT N'Dropping Extended Property [dbo].[ICS_DMR_PROG_REP_LNK].[MON_PERIOD_END_DATE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_DMR_PROG_REP_LNK', @level2type = N'COLUMN', @level2name = N'MON_PERIOD_END_DATE';

PRINT N'Dropping Extended Property [dbo].[ICS_GPCF_CNST_WAIVER].[CNST_WAIVER_AUTH_DATE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_GPCF_CNST_WAIVER', @level2type = N'COLUMN', @level2name = N'CNST_WAIVER_AUTH_DATE';

PRINT N'Dropping Extended Property [dbo].[ICS_GPCF_CNST_WAIVER].[CNST_WAIVER_CRITERIA_MET_IND].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_GPCF_CNST_WAIVER', @level2type = N'COLUMN', @level2name = N'CNST_WAIVER_CRITERIA_MET_IND';

PRINT N'Dropping Extended Property [dbo].[ICS_GPCF_CNST_WAIVER].[CNST_WAIVER_EVAL_BASIS_CODE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_GPCF_CNST_WAIVER', @level2type = N'COLUMN', @level2name = N'CNST_WAIVER_EVAL_BASIS_CODE';

PRINT N'Dropping Extended Property [dbo].[ICS_GPCF_CNST_WAIVER].[CNST_WAIVER_EVAL_DATE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_GPCF_CNST_WAIVER', @level2type = N'COLUMN', @level2name = N'CNST_WAIVER_EVAL_DATE';

PRINT N'Dropping Extended Property [dbo].[ICS_GPCF_CNST_WAIVER].[CNST_WAIVER_POSTMARK_DATE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_GPCF_CNST_WAIVER', @level2type = N'COLUMN', @level2name = N'CNST_WAIVER_POSTMARK_DATE';

PRINT N'Dropping Extended Property [dbo].[ICS_GPCF_CNST_WAIVER].[PROJ_ISOERODENT_VALUE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_GPCF_CNST_WAIVER', @level2type = N'COLUMN', @level2name = N'PROJ_ISOERODENT_VALUE';

PRINT N'Dropping Extended Property [dbo].[ICS_GPCF_CNST_WAIVER].[PROJ_EST_START_DATE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_GPCF_CNST_WAIVER', @level2type = N'COLUMN', @level2name = N'PROJ_EST_START_DATE';

PRINT N'Dropping Extended Property [dbo].[ICS_GPCF_CNST_WAIVER].[PROJ_EST_COMPLETED_DATE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_GPCF_CNST_WAIVER', @level2type = N'COLUMN', @level2name = N'PROJ_EST_COMPLETED_DATE';

PRINT N'Dropping Extended Property [dbo].[ICS_LNK_BS_REP].[PRMT_IDENT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LNK_BS_REP', @level2type = N'COLUMN', @level2name = N'PRMT_IDENT';

PRINT N'Dropping Extended Property [dbo].[ICS_LNK_BS_REP].[REP_COVERAGE_END_DATE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LNK_BS_REP', @level2type = N'COLUMN', @level2name = N'REP_COVERAGE_END_DATE';

PRINT N'Dropping Extended Property [dbo].[ICS_LNK_CAFO_ANNUL_REP].[PRMT_IDENT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LNK_CAFO_ANNUL_REP', @level2type = N'COLUMN', @level2name = N'PRMT_IDENT';

PRINT N'Dropping Extended Property [dbo].[ICS_LNK_CAFO_ANNUL_REP].[PRMT_AUTH_REP_RCVD_DATE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LNK_CAFO_ANNUL_REP', @level2type = N'COLUMN', @level2name = N'PRMT_AUTH_REP_RCVD_DATE';

PRINT N'Dropping Extended Property [dbo].[ICS_LNK_CSO_EVT_REP].[PRMT_IDENT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LNK_CSO_EVT_REP', @level2type = N'COLUMN', @level2name = N'PRMT_IDENT';

PRINT N'Dropping Extended Property [dbo].[ICS_LNK_CSO_EVT_REP].[CSO_EVT_DATE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LNK_CSO_EVT_REP', @level2type = N'COLUMN', @level2name = N'CSO_EVT_DATE';

PRINT N'Dropping Extended Property [dbo].[ICS_LNK_CSO_EVT_REP].[CSO_EVT_ID].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LNK_CSO_EVT_REP', @level2type = N'COLUMN', @level2name = N'CSO_EVT_ID';

PRINT N'Dropping Extended Property [dbo].[ICS_LNK_FEDR_CMPL_MON].[PROG_SYSTM_ACRONYM].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LNK_FEDR_CMPL_MON', @level2type = N'COLUMN', @level2name = N'PROG_SYSTM_ACRONYM';

PRINT N'Dropping Extended Property [dbo].[ICS_LNK_FEDR_CMPL_MON].[PROG_SYSTM_IDENT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LNK_FEDR_CMPL_MON', @level2type = N'COLUMN', @level2name = N'PROG_SYSTM_IDENT';

PRINT N'Dropping Extended Property [dbo].[ICS_LNK_FEDR_CMPL_MON].[FEDR_STATUTE_CODE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LNK_FEDR_CMPL_MON', @level2type = N'COLUMN', @level2name = N'FEDR_STATUTE_CODE';

PRINT N'Dropping Extended Property [dbo].[ICS_LNK_FEDR_CMPL_MON].[CMPL_MON_ACTY_TYPE_CODE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LNK_FEDR_CMPL_MON', @level2type = N'COLUMN', @level2name = N'CMPL_MON_ACTY_TYPE_CODE';

PRINT N'Dropping Extended Property [dbo].[ICS_LNK_FEDR_CMPL_MON].[CMPL_MON_CATG_CODE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LNK_FEDR_CMPL_MON', @level2type = N'COLUMN', @level2name = N'CMPL_MON_CATG_CODE';

PRINT N'Dropping Extended Property [dbo].[ICS_LNK_FEDR_CMPL_MON].[CMPL_MON_DATE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LNK_FEDR_CMPL_MON', @level2type = N'COLUMN', @level2name = N'CMPL_MON_DATE';

PRINT N'Dropping Extended Property [dbo].[ICS_LNK_LOC_LMTS_REP].[PRMT_IDENT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LNK_LOC_LMTS_REP', @level2type = N'COLUMN', @level2name = N'PRMT_IDENT';

PRINT N'Dropping Extended Property [dbo].[ICS_LNK_LOC_LMTS_REP].[PRMT_AUTH_REP_RCVD_DATE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LNK_LOC_LMTS_REP', @level2type = N'COLUMN', @level2name = N'PRMT_AUTH_REP_RCVD_DATE';

PRINT N'Dropping Extended Property [dbo].[ICS_LNK_PRETR_PERF_REP].[PRMT_IDENT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LNK_PRETR_PERF_REP', @level2type = N'COLUMN', @level2name = N'PRMT_IDENT';

PRINT N'Dropping Extended Property [dbo].[ICS_LNK_PRETR_PERF_REP].[PRETR_PERF_SUMM_END_DATE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LNK_PRETR_PERF_REP', @level2type = N'COLUMN', @level2name = N'PRETR_PERF_SUMM_END_DATE';

PRINT N'Dropping Extended Property [dbo].[ICS_LNK_SSO_ANNUL_REP].[PRMT_IDENT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LNK_SSO_ANNUL_REP', @level2type = N'COLUMN', @level2name = N'PRMT_IDENT';

PRINT N'Dropping Extended Property [dbo].[ICS_LNK_SSO_ANNUL_REP].[SSO_ANNUL_REP_RCVD_DATE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LNK_SSO_ANNUL_REP', @level2type = N'COLUMN', @level2name = N'SSO_ANNUL_REP_RCVD_DATE';

PRINT N'Dropping Extended Property [dbo].[ICS_LNK_SSO_EVT_REP].[PRMT_IDENT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LNK_SSO_EVT_REP', @level2type = N'COLUMN', @level2name = N'PRMT_IDENT';

PRINT N'Dropping Extended Property [dbo].[ICS_LNK_SSO_EVT_REP].[SSO_EVT_DATE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LNK_SSO_EVT_REP', @level2type = N'COLUMN', @level2name = N'SSO_EVT_DATE';

PRINT N'Dropping Extended Property [dbo].[ICS_LNK_SSO_EVT_REP].[SSO_EVT_ID].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LNK_SSO_EVT_REP', @level2type = N'COLUMN', @level2name = N'SSO_EVT_ID';

PRINT N'Dropping Extended Property [dbo].[ICS_LNK_SSO_MONTHLY_EVT_REP].[PRMT_IDENT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LNK_SSO_MONTHLY_EVT_REP', @level2type = N'COLUMN', @level2name = N'PRMT_IDENT';

PRINT N'Dropping Extended Property [dbo].[ICS_LNK_SSO_MONTHLY_EVT_REP].[SSO_MONTHLY_REP_RCVD_DATE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LNK_SSO_MONTHLY_EVT_REP', @level2type = N'COLUMN', @level2name = N'SSO_MONTHLY_REP_RCVD_DATE';

PRINT N'Dropping Extended Property [dbo].[ICS_LNK_ST_CMPL_MON].[CMPL_MON_IDENT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LNK_ST_CMPL_MON', @level2type = N'COLUMN', @level2name = N'CMPL_MON_IDENT';

PRINT N'Dropping Extended Property [dbo].[ICS_LNK_SW_EVT_REP].[PRMT_IDENT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LNK_SW_EVT_REP', @level2type = N'COLUMN', @level2name = N'PRMT_IDENT';

PRINT N'Dropping Extended Property [dbo].[ICS_LNK_SW_EVT_REP].[DATE_STRM_EVT_SMPL].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LNK_SW_EVT_REP', @level2type = N'COLUMN', @level2name = N'DATE_STRM_EVT_SMPL';

PRINT N'Dropping Extended Property [dbo].[ICS_LNK_SW_EVT_REP].[SW_EVT_ID].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LNK_SW_EVT_REP', @level2type = N'COLUMN', @level2name = N'SW_EVT_ID';

PRINT N'Dropping Extended Property [dbo].[ICS_LNK_SWMS_4_REP].[PRMT_IDENT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LNK_SWMS_4_REP', @level2type = N'COLUMN', @level2name = N'PRMT_IDENT';

PRINT N'Dropping Extended Property [dbo].[ICS_LNK_SWMS_4_REP].[SW_MS_4_REP_RCVD_DATE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LNK_SWMS_4_REP', @level2type = N'COLUMN', @level2name = N'SW_MS_4_REP_RCVD_DATE';

PRINT N'Dropping Extended Property [dbo].[ICS_LOC_LMTS].[MOS_RC_DATE_TECH_EVAL_LOC_LMTS].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LOC_LMTS', @level2type = N'COLUMN', @level2name = N'MOS_RC_DATE_TECH_EVAL_LOC_LMTS';

PRINT N'Dropping Extended Property [dbo].[ICS_LOC_LMTS].[MOS_RC_DATE_AD_TC_BS_LOC_LMTS].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LOC_LMTS', @level2type = N'COLUMN', @level2name = N'MOS_RC_DATE_AD_TC_BS_LOC_LMTS';

PRINT N'Dropping Extended Property [dbo].[ICS_LOC_LMTS_POLUT].[LOC_LMTS_POLUT_CODE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LOC_LMTS_POLUT', @level2type = N'COLUMN', @level2name = N'LOC_LMTS_POLUT_CODE';

PRINT N'Dropping Extended Property [dbo].[ICS_LOC_LMTS_PROG_REP].[SRC_SYSTM_IDENT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LOC_LMTS_PROG_REP', @level2type = N'COLUMN', @level2name = N'SRC_SYSTM_IDENT';

PRINT N'Dropping Extended Property [dbo].[ICS_LOC_LMTS_PROG_REP].[TRANSACTION_TYPE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LOC_LMTS_PROG_REP', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TYPE';

PRINT N'Dropping Extended Property [dbo].[ICS_LOC_LMTS_PROG_REP].[TRANSACTION_TIMESTAMP].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LOC_LMTS_PROG_REP', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TIMESTAMP';

PRINT N'Dropping Extended Property [dbo].[ICS_LOC_LMTS_PROG_REP].[PRMT_IDENT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LOC_LMTS_PROG_REP', @level2type = N'COLUMN', @level2name = N'PRMT_IDENT';

PRINT N'Dropping Extended Property [dbo].[ICS_LOC_LMTS_PROG_REP].[PRMT_AUTH_REP_RCVD_DATE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LOC_LMTS_PROG_REP', @level2type = N'COLUMN', @level2name = N'PRMT_AUTH_REP_RCVD_DATE';

PRINT N'Dropping Extended Property [dbo].[ICS_MGMT_PRC_DEFCY_TYPE].[MGMT_PRC_DEFCY_TYPE_CODE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MGMT_PRC_DEFCY_TYPE', @level2type = N'COLUMN', @level2name = N'MGMT_PRC_DEFCY_TYPE_CODE';

PRINT N'Dropping Extended Property [dbo].[ICS_PRETR_PERF_SUMM].[SRC_SYSTM_IDENT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PERF_SUMM', @level2type = N'COLUMN', @level2name = N'SRC_SYSTM_IDENT';

PRINT N'Dropping Extended Property [dbo].[ICS_PRETR_PERF_SUMM].[TRANSACTION_TYPE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PERF_SUMM', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TYPE';

PRINT N'Dropping Extended Property [dbo].[ICS_PRETR_PERF_SUMM].[TRANSACTION_TIMESTAMP].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PERF_SUMM', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TIMESTAMP';

PRINT N'Dropping Extended Property [dbo].[ICS_PRETR_PERF_SUMM].[PRMT_IDENT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PERF_SUMM', @level2type = N'COLUMN', @level2name = N'PRMT_IDENT';

PRINT N'Dropping Extended Property [dbo].[ICS_PRETR_PERF_SUMM].[PRETR_PERF_SUMM_END_DATE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PERF_SUMM', @level2type = N'COLUMN', @level2name = N'PRETR_PERF_SUMM_END_DATE';

PRINT N'Dropping Extended Property [dbo].[ICS_PRETR_PERF_SUMM].[PRETR_PERF_SUMM_START_DATE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PERF_SUMM', @level2type = N'COLUMN', @level2name = N'PRETR_PERF_SUMM_START_DATE';

PRINT N'Dropping Extended Property [dbo].[ICS_PRETR_PERF_SUMM].[SUO_REF].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PERF_SUMM', @level2type = N'COLUMN', @level2name = N'SUO_REF';

PRINT N'Dropping Extended Property [dbo].[ICS_PRETR_PERF_SUMM].[SUO_DATE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PERF_SUMM', @level2type = N'COLUMN', @level2name = N'SUO_DATE';

PRINT N'Dropping Extended Property [dbo].[ICS_PRETR_PERF_SUMM].[ACCEPTANCE_HAZ_WASTE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PERF_SUMM', @level2type = N'COLUMN', @level2name = N'ACCEPTANCE_HAZ_WASTE';

PRINT N'Dropping Extended Property [dbo].[ICS_PRETR_PERF_SUMM].[ACCEPTANCE_NON_HAZ_INDST_WASTE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PERF_SUMM', @level2type = N'COLUMN', @level2name = N'ACCEPTANCE_NON_HAZ_INDST_WASTE';

PRINT N'Dropping Extended Property [dbo].[ICS_PRETR_PERF_SUMM].[ACCEPTANCE_HULED_DOMSTIC_WSTES].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PERF_SUMM', @level2type = N'COLUMN', @level2name = N'ACCEPTANCE_HULED_DOMSTIC_WSTES';

PRINT N'Dropping Extended Property [dbo].[ICS_PRETR_PERF_SUMM].[ANNUL_PRETR_BUDGET_PP].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PERF_SUMM', @level2type = N'COLUMN', @level2name = N'ANNUL_PRETR_BUDGET_PP';

PRINT N'Dropping Extended Property [dbo].[ICS_PRETR_PERF_SUMM].[INADEQUACY_SMPL_INSP_IND].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PERF_SUMM', @level2type = N'COLUMN', @level2name = N'INADEQUACY_SMPL_INSP_IND';

PRINT N'Dropping Extended Property [dbo].[ICS_PRETR_PERF_SUMM].[ADEQUACY_PRETR_RESOURCES].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PERF_SUMM', @level2type = N'COLUMN', @level2name = N'ADEQUACY_PRETR_RESOURCES';

PRINT N'Dropping Extended Property [dbo].[ICS_PRETR_PERF_SUMM].[DFCNC_IDNTFD_DRNG_IU_FILE_RVIW].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PERF_SUMM', @level2type = N'COLUMN', @level2name = N'DFCNC_IDNTFD_DRNG_IU_FILE_RVIW';

PRINT N'Dropping Extended Property [dbo].[ICS_PRETR_PERF_SUMM].[CONTROL_MECH_DFCNC].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PERF_SUMM', @level2type = N'COLUMN', @level2name = N'CONTROL_MECH_DFCNC';

PRINT N'Dropping Extended Property [dbo].[ICS_PRETR_PERF_SUMM].[LEGAL_AUTH_DFCNC].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PERF_SUMM', @level2type = N'COLUMN', @level2name = N'LEGAL_AUTH_DFCNC';

PRINT N'Dropping Extended Property [dbo].[ICS_PRETR_PERF_SUMM].[DFCNC_INTRPRT_APPL_PRETR_STNDR].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PERF_SUMM', @level2type = N'COLUMN', @level2name = N'DFCNC_INTRPRT_APPL_PRETR_STNDR';

PRINT N'Dropping Extended Property [dbo].[ICS_PRETR_PERF_SUMM].[DFCNC_DAT_MGMT_PBLC_PRTICIPTON].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PERF_SUMM', @level2type = N'COLUMN', @level2name = N'DFCNC_DAT_MGMT_PBLC_PRTICIPTON';

PRINT N'Dropping Extended Property [dbo].[ICS_PRETR_PERF_SUMM].[VIOL_IU_SCHD_RMD_MSR].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PERF_SUMM', @level2type = N'COLUMN', @level2name = N'VIOL_IU_SCHD_RMD_MSR';

PRINT N'Dropping Extended Property [dbo].[ICS_PRETR_PERF_SUMM].[FRML_RSPN_VIOL_IU_SCHD_RMD_MSR].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PERF_SUMM', @level2type = N'COLUMN', @level2name = N'FRML_RSPN_VIOL_IU_SCHD_RMD_MSR';

PRINT N'Dropping Extended Property [dbo].[ICS_PRETR_PERF_SUMM].[ANNUL_FREQ_INFLUNT_TOXCNT_SMPL].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PERF_SUMM', @level2type = N'COLUMN', @level2name = N'ANNUL_FREQ_INFLUNT_TOXCNT_SMPL';

PRINT N'Dropping Extended Property [dbo].[ICS_PRETR_PERF_SUMM].[ANNUL_FREQ_EFFLU_TOXCNT_SMPL].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PERF_SUMM', @level2type = N'COLUMN', @level2name = N'ANNUL_FREQ_EFFLU_TOXCNT_SMPL';

PRINT N'Dropping Extended Property [dbo].[ICS_PRETR_PERF_SUMM].[ANNUL_FREQ_SLDG_TOXCNT_SMPL].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PERF_SUMM', @level2type = N'COLUMN', @level2name = N'ANNUL_FREQ_SLDG_TOXCNT_SMPL';

PRINT N'Dropping Extended Property [dbo].[ICS_PRETR_PERF_SUMM].[NUM_SI_US].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PERF_SUMM', @level2type = N'COLUMN', @level2name = N'NUM_SI_US';

PRINT N'Dropping Extended Property [dbo].[ICS_PRETR_PERF_SUMM].[SI_US_WITHOUT_CONTROL_MECH].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PERF_SUMM', @level2type = N'COLUMN', @level2name = N'SI_US_WITHOUT_CONTROL_MECH';

PRINT N'Dropping Extended Property [dbo].[ICS_PRETR_PERF_SUMM].[SI_US_NOT_INSPECTED].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PERF_SUMM', @level2type = N'COLUMN', @level2name = N'SI_US_NOT_INSPECTED';

PRINT N'Dropping Extended Property [dbo].[ICS_PRETR_PERF_SUMM].[SI_US_NOT_SMPL].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PERF_SUMM', @level2type = N'COLUMN', @level2name = N'SI_US_NOT_SMPL';

PRINT N'Dropping Extended Property [dbo].[ICS_PRETR_PERF_SUMM].[SI_US_ON_SCHD].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PERF_SUMM', @level2type = N'COLUMN', @level2name = N'SI_US_ON_SCHD';

PRINT N'Dropping Extended Property [dbo].[ICS_PRETR_PERF_SUMM].[SI_US_SNC_WITH_PRETR_STNDR].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PERF_SUMM', @level2type = N'COLUMN', @level2name = N'SI_US_SNC_WITH_PRETR_STNDR';

PRINT N'Dropping Extended Property [dbo].[ICS_PRETR_PERF_SUMM].[SI_US_SNC_WITH_REP_REQS].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PERF_SUMM', @level2type = N'COLUMN', @level2name = N'SI_US_SNC_WITH_REP_REQS';

PRINT N'Dropping Extended Property [dbo].[ICS_PRETR_PERF_SUMM].[SI_US_SNC_WITH_PRETR_SCHD].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PERF_SUMM', @level2type = N'COLUMN', @level2name = N'SI_US_SNC_WITH_PRETR_SCHD';

PRINT N'Dropping Extended Property [dbo].[ICS_PRETR_PERF_SUMM].[SI_US_SNC_PUBL_NEWSPAPER].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PERF_SUMM', @level2type = N'COLUMN', @level2name = N'SI_US_SNC_PUBL_NEWSPAPER';

PRINT N'Dropping Extended Property [dbo].[ICS_PRETR_PERF_SUMM].[VIOL_NOTICES_ISSUED_SI_US].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PERF_SUMM', @level2type = N'COLUMN', @level2name = N'VIOL_NOTICES_ISSUED_SI_US';

PRINT N'Dropping Extended Property [dbo].[ICS_PRETR_PERF_SUMM].[ADMIN_ORDERS_ISSUED_SI_US].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PERF_SUMM', @level2type = N'COLUMN', @level2name = N'ADMIN_ORDERS_ISSUED_SI_US';

PRINT N'Dropping Extended Property [dbo].[ICS_PRETR_PERF_SUMM].[CIVIL_SUTS_FILD_AGINST_SI_US].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PERF_SUMM', @level2type = N'COLUMN', @level2name = N'CIVIL_SUTS_FILD_AGINST_SI_US';

PRINT N'Dropping Extended Property [dbo].[ICS_PRETR_PERF_SUMM].[CRIMINL_SUTS_FILD_AGINST_SI_US].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PERF_SUMM', @level2type = N'COLUMN', @level2name = N'CRIMINL_SUTS_FILD_AGINST_SI_US';

PRINT N'Dropping Extended Property [dbo].[ICS_PRETR_PERF_SUMM].[DOLLAR_AMT_PNLTY_COLL_PP].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PERF_SUMM', @level2type = N'COLUMN', @level2name = N'DOLLAR_AMT_PNLTY_COLL_PP';

PRINT N'Dropping Extended Property [dbo].[ICS_PRETR_PERF_SUMM].[I_US_WHC_PNLTY_HAV_BEE_COLL_PP].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PERF_SUMM', @level2type = N'COLUMN', @level2name = N'I_US_WHC_PNLTY_HAV_BEE_COLL_PP';

PRINT N'Dropping Extended Property [dbo].[ICS_PRETR_PERF_SUMM].[NUM_CI_US].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PERF_SUMM', @level2type = N'COLUMN', @level2name = N'NUM_CI_US';

PRINT N'Dropping Extended Property [dbo].[ICS_PRETR_PERF_SUMM].[CI_US_IN_SNC].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PERF_SUMM', @level2type = N'COLUMN', @level2name = N'CI_US_IN_SNC';

PRINT N'Dropping Extended Property [dbo].[ICS_PRETR_PERF_SUMM].[PASS_THROUGH_INTERFERENCE_IND].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PERF_SUMM', @level2type = N'COLUMN', @level2name = N'PASS_THROUGH_INTERFERENCE_IND';

PRINT N'Dropping Extended Property [dbo].[ICS_REP_ANML_TYPE].[ANML_TYPE_CODE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_REP_ANML_TYPE', @level2type = N'COLUMN', @level2name = N'ANML_TYPE_CODE';

PRINT N'Dropping Extended Property [dbo].[ICS_REP_ANML_TYPE].[OTHR_ANML_TYPE_NAME].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_REP_ANML_TYPE', @level2type = N'COLUMN', @level2name = N'OTHR_ANML_TYPE_NAME';

PRINT N'Dropping Extended Property [dbo].[ICS_REP_ANML_TYPE].[TTL_NUM_EACH_LVSTCK].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_REP_ANML_TYPE', @level2type = N'COLUMN', @level2name = N'TTL_NUM_EACH_LVSTCK';

PRINT N'Dropping Extended Property [dbo].[ICS_REP_OBLGTN_TYPE].[REP_OBLGTN_TYPE_CODE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_REP_OBLGTN_TYPE', @level2type = N'COLUMN', @level2name = N'REP_OBLGTN_TYPE_CODE';

PRINT N'Dropping Extended Property [dbo].[ICS_RMVL_CRDTS].[MOS_RC_DATE_RMVL_CRDTS_APRVL].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_RMVL_CRDTS', @level2type = N'COLUMN', @level2name = N'MOS_RC_DATE_RMVL_CRDTS_APRVL';

PRINT N'Dropping Extended Property [dbo].[ICS_RMVL_CRDTS].[RMVL_CRDTS_APPL_STAT_CODE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_RMVL_CRDTS', @level2type = N'COLUMN', @level2name = N'RMVL_CRDTS_APPL_STAT_CODE';

PRINT N'Dropping Extended Property [dbo].[ICS_RMVL_CRDTS_POLUT].[RMVL_CRDTS_POLUT_CODE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_RMVL_CRDTS_POLUT', @level2type = N'COLUMN', @level2name = N'RMVL_CRDTS_POLUT_CODE';

PRINT N'Dropping Extended Property [dbo].[ICS_SSO_ANNUL_REP].[SRC_SYSTM_IDENT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SSO_ANNUL_REP', @level2type = N'COLUMN', @level2name = N'SRC_SYSTM_IDENT';

PRINT N'Dropping Extended Property [dbo].[ICS_SSO_ANNUL_REP].[TRANSACTION_TYPE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SSO_ANNUL_REP', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TYPE';

PRINT N'Dropping Extended Property [dbo].[ICS_SSO_ANNUL_REP].[TRANSACTION_TIMESTAMP].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SSO_ANNUL_REP', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TIMESTAMP';

PRINT N'Dropping Extended Property [dbo].[ICS_SSO_ANNUL_REP].[PRMT_IDENT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SSO_ANNUL_REP', @level2type = N'COLUMN', @level2name = N'PRMT_IDENT';

PRINT N'Dropping Extended Property [dbo].[ICS_SSO_ANNUL_REP].[SSO_ANNUL_REP_RCVD_DATE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SSO_ANNUL_REP', @level2type = N'COLUMN', @level2name = N'SSO_ANNUL_REP_RCVD_DATE';

PRINT N'Dropping Extended Property [dbo].[ICS_SSO_ANNUL_REP].[SSO_ANNUL_REP_YEAR].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SSO_ANNUL_REP', @level2type = N'COLUMN', @level2name = N'SSO_ANNUL_REP_YEAR';

PRINT N'Dropping Extended Property [dbo].[ICS_SSO_ANNUL_REP].[NUM_SSO_EVTS_PER_YEAR].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SSO_ANNUL_REP', @level2type = N'COLUMN', @level2name = N'NUM_SSO_EVTS_PER_YEAR';

PRINT N'Dropping Extended Property [dbo].[ICS_SSO_ANNUL_REP].[VOL_SSO_EVTS_PER_YEAR].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SSO_ANNUL_REP', @level2type = N'COLUMN', @level2name = N'VOL_SSO_EVTS_PER_YEAR';

PRINT N'Dropping Extended Property [dbo].[ICS_SSO_EVT_REP].[SRC_SYSTM_IDENT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SSO_EVT_REP', @level2type = N'COLUMN', @level2name = N'SRC_SYSTM_IDENT';

PRINT N'Dropping Extended Property [dbo].[ICS_SSO_EVT_REP].[TRANSACTION_TYPE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SSO_EVT_REP', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TYPE';

PRINT N'Dropping Extended Property [dbo].[ICS_SSO_EVT_REP].[TRANSACTION_TIMESTAMP].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SSO_EVT_REP', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TIMESTAMP';

PRINT N'Dropping Extended Property [dbo].[ICS_SSO_EVT_REP].[PRMT_IDENT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SSO_EVT_REP', @level2type = N'COLUMN', @level2name = N'PRMT_IDENT';

PRINT N'Dropping Extended Property [dbo].[ICS_SSO_EVT_REP].[SSO_EVT_DATE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SSO_EVT_REP', @level2type = N'COLUMN', @level2name = N'SSO_EVT_DATE';

PRINT N'Dropping Extended Property [dbo].[ICS_SSO_EVT_REP].[SSO_EVT_ID].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SSO_EVT_REP', @level2type = N'COLUMN', @level2name = N'SSO_EVT_ID';

PRINT N'Dropping Extended Property [dbo].[ICS_SSO_EVT_REP].[CAUSE_SSO_OVRFLW_EVT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SSO_EVT_REP', @level2type = N'COLUMN', @level2name = N'CAUSE_SSO_OVRFLW_EVT';

PRINT N'Dropping Extended Property [dbo].[ICS_SSO_EVT_REP].[LAT_MEAS].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SSO_EVT_REP', @level2type = N'COLUMN', @level2name = N'LAT_MEAS';

PRINT N'Dropping Extended Property [dbo].[ICS_SSO_EVT_REP].[LONG_MEAS].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SSO_EVT_REP', @level2type = N'COLUMN', @level2name = N'LONG_MEAS';

PRINT N'Dropping Extended Property [dbo].[ICS_SSO_EVT_REP].[SSO_OVRFLW_LOC_STREET].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SSO_EVT_REP', @level2type = N'COLUMN', @level2name = N'SSO_OVRFLW_LOC_STREET';

PRINT N'Dropping Extended Property [dbo].[ICS_SSO_EVT_REP].[DURATION_SSO_OVRFLW_EVT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SSO_EVT_REP', @level2type = N'COLUMN', @level2name = N'DURATION_SSO_OVRFLW_EVT';

PRINT N'Dropping Extended Property [dbo].[ICS_SSO_EVT_REP].[SSO_VOL].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SSO_EVT_REP', @level2type = N'COLUMN', @level2name = N'SSO_VOL';

PRINT N'Dropping Extended Property [dbo].[ICS_SSO_EVT_REP].[NAME_RCVG_WTR].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SSO_EVT_REP', @level2type = N'COLUMN', @level2name = N'NAME_RCVG_WTR';

PRINT N'Dropping Extended Property [dbo].[ICS_SSO_EVT_REP].[DESC_STPS_TAKEN].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SSO_EVT_REP', @level2type = N'COLUMN', @level2name = N'DESC_STPS_TAKEN';

PRINT N'Dropping Extended Property [dbo].[ICS_SSO_MONTHLY_EVT_REP].[SRC_SYSTM_IDENT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SSO_MONTHLY_EVT_REP', @level2type = N'COLUMN', @level2name = N'SRC_SYSTM_IDENT';

PRINT N'Dropping Extended Property [dbo].[ICS_SSO_MONTHLY_EVT_REP].[TRANSACTION_TYPE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SSO_MONTHLY_EVT_REP', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TYPE';

PRINT N'Dropping Extended Property [dbo].[ICS_SSO_MONTHLY_EVT_REP].[TRANSACTION_TIMESTAMP].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SSO_MONTHLY_EVT_REP', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TIMESTAMP';

PRINT N'Dropping Extended Property [dbo].[ICS_SSO_MONTHLY_EVT_REP].[PRMT_IDENT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SSO_MONTHLY_EVT_REP', @level2type = N'COLUMN', @level2name = N'PRMT_IDENT';

PRINT N'Dropping Extended Property [dbo].[ICS_SSO_MONTHLY_EVT_REP].[SSO_MONTHLY_REP_RCVD_DATE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SSO_MONTHLY_EVT_REP', @level2type = N'COLUMN', @level2name = N'SSO_MONTHLY_REP_RCVD_DATE';

PRINT N'Dropping Extended Property [dbo].[ICS_SSO_MONTHLY_EVT_REP].[SSO_MONTHLY_EVT_MN].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SSO_MONTHLY_EVT_REP', @level2type = N'COLUMN', @level2name = N'SSO_MONTHLY_EVT_MN';

PRINT N'Dropping Extended Property [dbo].[ICS_SSO_MONTHLY_EVT_REP].[SSO_MONTHLY_EVT_YEAR].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SSO_MONTHLY_EVT_REP', @level2type = N'COLUMN', @level2name = N'SSO_MONTHLY_EVT_YEAR';

PRINT N'Dropping Extended Property [dbo].[ICS_SSO_MONTHLY_EVT_REP].[NUM_SSO_EVTS_REC_US_WTR_PER_MN].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SSO_MONTHLY_EVT_REP', @level2type = N'COLUMN', @level2name = N'NUM_SSO_EVTS_REC_US_WTR_PER_MN';

PRINT N'Dropping Extended Property [dbo].[ICS_SSO_MONTHLY_EVT_REP].[VOL_SSO_EVTS_REC_US_WTR_PER_MN].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SSO_MONTHLY_EVT_REP', @level2type = N'COLUMN', @level2name = N'VOL_SSO_EVTS_REC_US_WTR_PER_MN';

PRINT N'Dropping Extended Property [dbo].[ICS_SUBSCTOR_CODE_PLUS_DESC].[SUBSCTOR_CODE_PLUS_DESC].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SUBSCTOR_CODE_PLUS_DESC', @level2type = N'COLUMN', @level2name = N'SUBSCTOR_CODE_PLUS_DESC';

PRINT N'Dropping Extended Property [dbo].[ICS_SW_EVT_REP].[SRC_SYSTM_IDENT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_EVT_REP', @level2type = N'COLUMN', @level2name = N'SRC_SYSTM_IDENT';

PRINT N'Dropping Extended Property [dbo].[ICS_SW_EVT_REP].[TRANSACTION_TYPE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_EVT_REP', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TYPE';

PRINT N'Dropping Extended Property [dbo].[ICS_SW_EVT_REP].[TRANSACTION_TIMESTAMP].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_EVT_REP', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TIMESTAMP';

PRINT N'Dropping Extended Property [dbo].[ICS_SW_EVT_REP].[PRMT_IDENT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_EVT_REP', @level2type = N'COLUMN', @level2name = N'PRMT_IDENT';

PRINT N'Dropping Extended Property [dbo].[ICS_SW_EVT_REP].[DATE_STRM_EVT_SMPL].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_EVT_REP', @level2type = N'COLUMN', @level2name = N'DATE_STRM_EVT_SMPL';

PRINT N'Dropping Extended Property [dbo].[ICS_SW_EVT_REP].[SW_EVT_ID].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_EVT_REP', @level2type = N'COLUMN', @level2name = N'SW_EVT_ID';

PRINT N'Dropping Extended Property [dbo].[ICS_SW_EVT_REP].[PRMT_FEATR_IDENT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_EVT_REP', @level2type = N'COLUMN', @level2name = N'PRMT_FEATR_IDENT';

PRINT N'Dropping Extended Property [dbo].[ICS_SW_EVT_REP].[RAINFALL_STRM_EVT_SMPL_NUM].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_EVT_REP', @level2type = N'COLUMN', @level2name = N'RAINFALL_STRM_EVT_SMPL_NUM';

PRINT N'Dropping Extended Property [dbo].[ICS_SW_EVT_REP].[DURATION_STRM_EVT_SMPL].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_EVT_REP', @level2type = N'COLUMN', @level2name = N'DURATION_STRM_EVT_SMPL';

PRINT N'Dropping Extended Property [dbo].[ICS_SW_EVT_REP].[VOL_DSCH_SMPL].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_EVT_REP', @level2type = N'COLUMN', @level2name = N'VOL_DSCH_SMPL';

PRINT N'Dropping Extended Property [dbo].[ICS_SW_EVT_REP].[DURATION_SINCE_LAST_STRM_EVT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_EVT_REP', @level2type = N'COLUMN', @level2name = N'DURATION_SINCE_LAST_STRM_EVT';

PRINT N'Dropping Extended Property [dbo].[ICS_SW_EVT_REP].[SMPL_BASIS_IND].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_EVT_REP', @level2type = N'COLUMN', @level2name = N'SMPL_BASIS_IND';

PRINT N'Dropping Extended Property [dbo].[ICS_SW_EVT_REP].[PRECIP_FORM].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_EVT_REP', @level2type = N'COLUMN', @level2name = N'PRECIP_FORM';

PRINT N'Dropping Extended Property [dbo].[ICS_SW_EVT_REP].[SMPL_TAKEN_WITHIN_TIMEFRME_IND].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_EVT_REP', @level2type = N'COLUMN', @level2name = N'SMPL_TAKEN_WITHIN_TIMEFRME_IND';

PRINT N'Dropping Extended Property [dbo].[ICS_SW_EVT_REP].[TIME_EXCEEDANCE_RATIONALE_CODE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_EVT_REP', @level2type = N'COLUMN', @level2name = N'TIME_EXCEEDANCE_RATIONALE_CODE';

PRINT N'Dropping Extended Property [dbo].[ICS_SW_EVT_REP].[ESSEN_IDENTICAL_OUTFALL_NOTIF].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_EVT_REP', @level2type = N'COLUMN', @level2name = N'ESSEN_IDENTICAL_OUTFALL_NOTIF';

PRINT N'Dropping Extended Property [dbo].[ICS_SW_EVT_REP].[MON_EXEMPTION_RATIONALE_IND].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_EVT_REP', @level2type = N'COLUMN', @level2name = N'MON_EXEMPTION_RATIONALE_IND';

PRINT N'Dropping Extended Property [dbo].[ICS_SW_EVT_REP].[POLUT_MON_BASIS_CODE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_EVT_REP', @level2type = N'COLUMN', @level2name = N'POLUT_MON_BASIS_CODE';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_LARGE_PRMT].[SRC_SYSTM_IDENT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_LARGE_PRMT', @level2type = N'COLUMN', @level2name = N'SRC_SYSTM_IDENT';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_LARGE_PRMT].[TRANSACTION_TYPE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_LARGE_PRMT', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TYPE';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_LARGE_PRMT].[TRANSACTION_TIMESTAMP].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_LARGE_PRMT', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TIMESTAMP';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_LARGE_PRMT].[PRMT_IDENT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_LARGE_PRMT', @level2type = N'COLUMN', @level2name = N'PRMT_IDENT';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_LARGE_PRMT].[ST_WTR_BODY_NAME].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_LARGE_PRMT', @level2type = N'COLUMN', @level2name = N'ST_WTR_BODY_NAME';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_LARGE_PRMT].[RCVG_MS_4_NAME].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_LARGE_PRMT', @level2type = N'COLUMN', @level2name = N'RCVG_MS_4_NAME';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_LARGE_PRMT].[IMPAIRED_WTR_IND].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_LARGE_PRMT', @level2type = N'COLUMN', @level2name = N'IMPAIRED_WTR_IND';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_LARGE_PRMT].[HIST_PROP_IND].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_LARGE_PRMT', @level2type = N'COLUMN', @level2name = N'HIST_PROP_IND';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_LARGE_PRMT].[HIST_PROP_CRIT_MET_CODE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_LARGE_PRMT', @level2type = N'COLUMN', @level2name = N'HIST_PROP_CRIT_MET_CODE';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_LARGE_PRMT].[SPECIES_CRIT_HABITAT_IND].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_LARGE_PRMT', @level2type = N'COLUMN', @level2name = N'SPECIES_CRIT_HABITAT_IND';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_LARGE_PRMT].[SPECIES_CRIT_MET_CODE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_LARGE_PRMT', @level2type = N'COLUMN', @level2name = N'SPECIES_CRIT_MET_CODE';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_LARGE_PRMT].[INDST_ACTY_SIZE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_LARGE_PRMT', @level2type = N'COLUMN', @level2name = N'INDST_ACTY_SIZE';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_LARGE_PRMT].[LEGAL_ENTITY_TYPE_CODE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_LARGE_PRMT', @level2type = N'COLUMN', @level2name = N'LEGAL_ENTITY_TYPE_CODE';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_LARGE_PRMT].[MS_4_PRMT_CLASS_CODE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_LARGE_PRMT', @level2type = N'COLUMN', @level2name = N'MS_4_PRMT_CLASS_CODE';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_LARGE_PRMT].[MS_4_TYPE_CODE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_LARGE_PRMT', @level2type = N'COLUMN', @level2name = N'MS_4_TYPE_CODE';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_LARGE_PRMT].[MS_4_ACREAGE_COVERED_NUM].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_LARGE_PRMT', @level2type = N'COLUMN', @level2name = N'MS_4_ACREAGE_COVERED_NUM';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_LARGE_PRMT].[MS_4_POPL_SERVED_NUM].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_LARGE_PRMT', @level2type = N'COLUMN', @level2name = N'MS_4_POPL_SERVED_NUM';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_LARGE_PRMT].[URBANIZED_AREA_INCRP_PLCE_NAME].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_LARGE_PRMT', @level2type = N'COLUMN', @level2name = N'URBANIZED_AREA_INCRP_PLCE_NAME';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_LARGE_PRMT].[MS_4_ANNUL_EXPEN_DOLLARS].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_LARGE_PRMT', @level2type = N'COLUMN', @level2name = N'MS_4_ANNUL_EXPEN_DOLLARS';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_LARGE_PRMT].[MS_4_ANNUL_EXPEN_YEAR].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_LARGE_PRMT', @level2type = N'COLUMN', @level2name = N'MS_4_ANNUL_EXPEN_YEAR';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_LARGE_PRMT].[MS_4_BUDGET_DOLLARS].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_LARGE_PRMT', @level2type = N'COLUMN', @level2name = N'MS_4_BUDGET_DOLLARS';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_LARGE_PRMT].[MS_4_BUDGET_YEAR].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_LARGE_PRMT', @level2type = N'COLUMN', @level2name = N'MS_4_BUDGET_YEAR';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_LARGE_PRMT].[PROJ_SRCS_OF_FUND_CODE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_LARGE_PRMT', @level2type = N'COLUMN', @level2name = N'PROJ_SRCS_OF_FUND_CODE';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_LARGE_PRMT].[MAJOR_OUTFALL_EST_MEAS_IND].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_LARGE_PRMT', @level2type = N'COLUMN', @level2name = N'MAJOR_OUTFALL_EST_MEAS_IND';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_LARGE_PRMT].[MAJOR_OUTFALL_NUM].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_LARGE_PRMT', @level2type = N'COLUMN', @level2name = N'MAJOR_OUTFALL_NUM';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_LARGE_PRMT].[MINOR_OUTFALL_EST_MEAS_IND].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_LARGE_PRMT', @level2type = N'COLUMN', @level2name = N'MINOR_OUTFALL_EST_MEAS_IND';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_LARGE_PRMT].[MINOR_OUTFALL_NUM].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_LARGE_PRMT', @level2type = N'COLUMN', @level2name = N'MINOR_OUTFALL_NUM';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_PROG_REP].[SRC_SYSTM_IDENT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_PROG_REP', @level2type = N'COLUMN', @level2name = N'SRC_SYSTM_IDENT';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_PROG_REP].[TRANSACTION_TYPE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_PROG_REP', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TYPE';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_PROG_REP].[TRANSACTION_TIMESTAMP].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_PROG_REP', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TIMESTAMP';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_PROG_REP].[PRMT_IDENT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_PROG_REP', @level2type = N'COLUMN', @level2name = N'PRMT_IDENT';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_PROG_REP].[SW_MS_4_REP_RCVD_DATE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_PROG_REP', @level2type = N'COLUMN', @level2name = N'SW_MS_4_REP_RCVD_DATE';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_PROG_REP].[MS_4_ANNUL_EXPEN_DOLLARS].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_PROG_REP', @level2type = N'COLUMN', @level2name = N'MS_4_ANNUL_EXPEN_DOLLARS';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_PROG_REP].[MS_4_ANNUL_EXPEN_YEAR].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_PROG_REP', @level2type = N'COLUMN', @level2name = N'MS_4_ANNUL_EXPEN_YEAR';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_PROG_REP].[MS_4_BUDGET_DOLLARS].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_PROG_REP', @level2type = N'COLUMN', @level2name = N'MS_4_BUDGET_DOLLARS';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_PROG_REP].[MS_4_BUDGET_YEAR].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_PROG_REP', @level2type = N'COLUMN', @level2name = N'MS_4_BUDGET_YEAR';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_PROG_REP].[MAJOR_OUTFALL_EST_MEAS_IND].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_PROG_REP', @level2type = N'COLUMN', @level2name = N'MAJOR_OUTFALL_EST_MEAS_IND';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_PROG_REP].[MAJOR_OUTFALL_NUM].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_PROG_REP', @level2type = N'COLUMN', @level2name = N'MAJOR_OUTFALL_NUM';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_PROG_REP].[MINOR_OUTFALL_EST_MEAS_IND].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_PROG_REP', @level2type = N'COLUMN', @level2name = N'MINOR_OUTFALL_EST_MEAS_IND';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_PROG_REP].[MINOR_OUTFALL_NUM].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_PROG_REP', @level2type = N'COLUMN', @level2name = N'MINOR_OUTFALL_NUM';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_SMALL_PRMT].[SRC_SYSTM_IDENT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_SMALL_PRMT', @level2type = N'COLUMN', @level2name = N'SRC_SYSTM_IDENT';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_SMALL_PRMT].[TRANSACTION_TYPE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_SMALL_PRMT', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TYPE';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_SMALL_PRMT].[TRANSACTION_TIMESTAMP].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_SMALL_PRMT', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TIMESTAMP';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_SMALL_PRMT].[PRMT_IDENT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_SMALL_PRMT', @level2type = N'COLUMN', @level2name = N'PRMT_IDENT';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_SMALL_PRMT].[ST_WTR_BODY_NAME].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_SMALL_PRMT', @level2type = N'COLUMN', @level2name = N'ST_WTR_BODY_NAME';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_SMALL_PRMT].[RCVG_MS_4_NAME].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_SMALL_PRMT', @level2type = N'COLUMN', @level2name = N'RCVG_MS_4_NAME';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_SMALL_PRMT].[IMPAIRED_WTR_IND].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_SMALL_PRMT', @level2type = N'COLUMN', @level2name = N'IMPAIRED_WTR_IND';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_SMALL_PRMT].[HIST_PROP_IND].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_SMALL_PRMT', @level2type = N'COLUMN', @level2name = N'HIST_PROP_IND';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_SMALL_PRMT].[HIST_PROP_CRIT_MET_CODE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_SMALL_PRMT', @level2type = N'COLUMN', @level2name = N'HIST_PROP_CRIT_MET_CODE';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_SMALL_PRMT].[SPECIES_CRIT_HABITAT_IND].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_SMALL_PRMT', @level2type = N'COLUMN', @level2name = N'SPECIES_CRIT_HABITAT_IND';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_SMALL_PRMT].[SPECIES_CRIT_MET_CODE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_SMALL_PRMT', @level2type = N'COLUMN', @level2name = N'SPECIES_CRIT_MET_CODE';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_SMALL_PRMT].[INDST_ACTY_SIZE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_SMALL_PRMT', @level2type = N'COLUMN', @level2name = N'INDST_ACTY_SIZE';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_SMALL_PRMT].[LEGAL_ENTITY_TYPE_CODE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_SMALL_PRMT', @level2type = N'COLUMN', @level2name = N'LEGAL_ENTITY_TYPE_CODE';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_SMALL_PRMT].[MS_4_PRMT_CLASS_CODE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_SMALL_PRMT', @level2type = N'COLUMN', @level2name = N'MS_4_PRMT_CLASS_CODE';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_SMALL_PRMT].[MS_4_TYPE_CODE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_SMALL_PRMT', @level2type = N'COLUMN', @level2name = N'MS_4_TYPE_CODE';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_SMALL_PRMT].[MS_4_ACREAGE_COVERED_NUM].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_SMALL_PRMT', @level2type = N'COLUMN', @level2name = N'MS_4_ACREAGE_COVERED_NUM';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_SMALL_PRMT].[MS_4_POPL_SERVED_NUM].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_SMALL_PRMT', @level2type = N'COLUMN', @level2name = N'MS_4_POPL_SERVED_NUM';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_SMALL_PRMT].[URBANIZED_AREA_INCRP_PLCE_NAME].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_SMALL_PRMT', @level2type = N'COLUMN', @level2name = N'URBANIZED_AREA_INCRP_PLCE_NAME';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_SMALL_PRMT].[MS_4_ANNUL_EXPEN_DOLLARS].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_SMALL_PRMT', @level2type = N'COLUMN', @level2name = N'MS_4_ANNUL_EXPEN_DOLLARS';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_SMALL_PRMT].[MS_4_ANNUL_EXPEN_YEAR].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_SMALL_PRMT', @level2type = N'COLUMN', @level2name = N'MS_4_ANNUL_EXPEN_YEAR';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_SMALL_PRMT].[MS_4_BUDGET_DOLLARS].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_SMALL_PRMT', @level2type = N'COLUMN', @level2name = N'MS_4_BUDGET_DOLLARS';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_SMALL_PRMT].[MS_4_BUDGET_YEAR].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_SMALL_PRMT', @level2type = N'COLUMN', @level2name = N'MS_4_BUDGET_YEAR';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_SMALL_PRMT].[PROJ_SRCS_OF_FUND_CODE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_SMALL_PRMT', @level2type = N'COLUMN', @level2name = N'PROJ_SRCS_OF_FUND_CODE';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_SMALL_PRMT].[MAJOR_OUTFALL_EST_MEAS_IND].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_SMALL_PRMT', @level2type = N'COLUMN', @level2name = N'MAJOR_OUTFALL_EST_MEAS_IND';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_SMALL_PRMT].[MAJOR_OUTFALL_NUM].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_SMALL_PRMT', @level2type = N'COLUMN', @level2name = N'MAJOR_OUTFALL_NUM';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_SMALL_PRMT].[MINOR_OUTFALL_EST_MEAS_IND].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_SMALL_PRMT', @level2type = N'COLUMN', @level2name = N'MINOR_OUTFALL_EST_MEAS_IND';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_SMALL_PRMT].[MINOR_OUTFALL_NUM].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_SMALL_PRMT', @level2type = N'COLUMN', @level2name = N'MINOR_OUTFALL_NUM';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_SMALL_PRMT].[QUAL_LOC_PROG_IND].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_SMALL_PRMT', @level2type = N'COLUMN', @level2name = N'QUAL_LOC_PROG_IND';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_SMALL_PRMT].[QUAL_LOC_PROG_DESC_TXT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_SMALL_PRMT', @level2type = N'COLUMN', @level2name = N'QUAL_LOC_PROG_DESC_TXT';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_SMALL_PRMT].[SHARED_RESP_IND].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_SMALL_PRMT', @level2type = N'COLUMN', @level2name = N'SHARED_RESP_IND';

PRINT N'Dropping Extended Property [dbo].[ICS_SWMS_4_SMALL_PRMT].[SHARED_RESP_DESC_TXT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_SMALL_PRMT', @level2type = N'COLUMN', @level2name = N'SHARED_RESP_DESC_TXT';

PRINT N'Dropping Extended Property [dbo].[ICS_TRTMNT_PRCSS_TYPE].[TRTMNT_PRCSS_TYPE_CODE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_TRTMNT_PRCSS_TYPE', @level2type = N'COLUMN', @level2name = N'TRTMNT_PRCSS_TYPE_CODE';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_ANNUL_PROG_REP].[BS_ADDL_INFO_CMNT_TXT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_ANNUL_PROG_REP', @level2type = N'COLUMN', @level2name = N'BS_ADDL_INFO_CMNT_TXT';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_ANNUL_PROG_REP].[BS_ANNUL_REP_RCVD_DATE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_ANNUL_PROG_REP', @level2type = N'COLUMN', @level2name = N'BS_ANNUL_REP_RCVD_DATE';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_ANNUL_PROG_REP].[REP_PERIOD_END_DATE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_ANNUL_PROG_REP', @level2type = N'COLUMN', @level2name = N'REP_PERIOD_END_DATE';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_ANNUL_PROG_REP].[REP_PERIOD_START_DATE].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_ANNUL_PROG_REP', @level2type = N'COLUMN', @level2name = N'REP_PERIOD_START_DATE';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_ANNUL_PROG_REP].[TRTMNT_PRCSS_OTHR_TXT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_ANNUL_PROG_REP', @level2type = N'COLUMN', @level2name = N'TRTMNT_PRCSS_OTHR_TXT';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_ANNUL_PROG_REP].[TTL_VOL_AMT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_ANNUL_PROG_REP', @level2type = N'COLUMN', @level2name = N'TTL_VOL_AMT';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_PRMT].[ANNUL_DRY_SLDG_PROD_NUM].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_PRMT', @level2type = N'COLUMN', @level2name = N'ANNUL_DRY_SLDG_PROD_NUM';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_PRMT].[BENEF_USED_OUT_OF_ST_AMT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_PRMT', @level2type = N'COLUMN', @level2name = N'BENEF_USED_OUT_OF_ST_AMT';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_PRMT].[CODISPOSED_IN_MSW_LANDFILL_AMT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_PRMT', @level2type = N'COLUMN', @level2name = N'CODISPOSED_IN_MSW_LANDFILL_AMT';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_PRMT].[DISPOSED_OUT_OF_ST_AMT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_PRMT', @level2type = N'COLUMN', @level2name = N'DISPOSED_OUT_OF_ST_AMT';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_PRMT].[EQ_PROD_DIST_MARKETED_AMT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_PRMT', @level2type = N'COLUMN', @level2name = N'EQ_PROD_DIST_MARKETED_AMT';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_PRMT].[INCINERATED_AMT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_PRMT', @level2type = N'COLUMN', @level2name = N'INCINERATED_AMT';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_PRMT].[LAND_APPLIED_AMT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_PRMT', @level2type = N'COLUMN', @level2name = N'LAND_APPLIED_AMT';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_PRMT].[MNGED_OTHR_MTHDS_AMT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_PRMT', @level2type = N'COLUMN', @level2name = N'MNGED_OTHR_MTHDS_AMT';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_PRMT].[MNGED_OTHR_MTHDS_OUT_OF_ST_AMT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_PRMT', @level2type = N'COLUMN', @level2name = N'MNGED_OTHR_MTHDS_OUT_OF_ST_AMT';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_PRMT].[RCVD_OFFSITE_SRCS_AMT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_PRMT', @level2type = N'COLUMN', @level2name = N'RCVD_OFFSITE_SRCS_AMT';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_PRMT].[SURF_DSPL_AMT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_PRMT', @level2type = N'COLUMN', @level2name = N'SURF_DSPL_AMT';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_PRMT].[TRANSFERRED_AMT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_PRMT', @level2type = N'COLUMN', @level2name = N'TRANSFERRED_AMT';

PRINT N'Dropping Extended Property [dbo].[ICS_BS_PRMT].[TTL_REMOVED_AMT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_PRMT', @level2type = N'COLUMN', @level2name = N'TTL_REMOVED_AMT';

PRINT N'Dropping Extended Property [dbo].[ICS_CMPL_MON].[INSP_CMNT_TXT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CMPL_MON', @level2type = N'COLUMN', @level2name = N'INSP_CMNT_TXT';

PRINT N'Dropping Extended Property [dbo].[ICS_SURF_DSPL_SITE].[MGMT_PRACTICES_IND].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SURF_DSPL_SITE', @level2type = N'COLUMN', @level2name = N'MGMT_PRACTICES_IND';

PRINT N'Dropping Extended Property [dbo].[ICS_SW_CNST_PRMT].[CNST_SITE_OTHR_TXT].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_CNST_PRMT', @level2type = N'COLUMN', @level2name = N'CNST_SITE_OTHR_TXT';

PRINT N'Dropping Extended Property [dbo].[ICS_SW_CNST_PRMT].[SBSRFC_ERTH_DSTRBN_CONTROL_IND].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_CNST_PRMT', @level2type = N'COLUMN', @level2name = N'SBSRFC_ERTH_DSTRBN_CONTROL_IND';

PRINT N'Dropping Extended Property [dbo].[ICS_SW_CNST_PRMT].[SBSRFC_ERTH_DSTRBN_IND].[MS_Description]...';

EXECUTE sp_dropextendedproperty @name = N'MS_Description', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_CNST_PRMT', @level2type = N'COLUMN', @level2name = N'SBSRFC_ERTH_DSTRBN_IND';

PRINT N'Dropping Index [dbo].[ICS_ADDR].[IX_ADDR_ICS_BS_MGMT_PRCTICS_ID]...';

DROP INDEX [IX_ADDR_ICS_BS_MGMT_PRCTICS_ID]
    ON [dbo].[ICS_ADDR];

PRINT N'Dropping Index [dbo].[ICS_ADDR].[IX_ADDR_ICS_BS_PRMT_ID]...';

DROP INDEX [IX_ADDR_ICS_BS_PRMT_ID]
    ON [dbo].[ICS_ADDR];

PRINT N'Dropping Index [dbo].[ICS_ADDR].[IX_ADDR_ICS_SW_EVT_REP_ID]...';

DROP INDEX [IX_ADDR_ICS_SW_EVT_REP_ID]
    ON [dbo].[ICS_ADDR];

PRINT N'Dropping Index [dbo].[ICS_ADDR].[IX_ADDR_ICS_SWMS_4_LRGE_PRM_ID]...';

DROP INDEX [IX_ADDR_ICS_SWMS_4_LRGE_PRM_ID]
    ON [dbo].[ICS_ADDR];

PRINT N'Dropping Index [dbo].[ICS_ADDR].[IX_ADDR_ICS_SWMS_4_PROG_REP_ID]...';

DROP INDEX [IX_ADDR_ICS_SWMS_4_PROG_REP_ID]
    ON [dbo].[ICS_ADDR];

PRINT N'Dropping Index [dbo].[ICS_ADDR].[IX_ADDR_ICS_SWMS_4_SMLL_PRM_ID]...';

DROP INDEX [IX_ADDR_ICS_SWMS_4_SMLL_PRM_ID]
    ON [dbo].[ICS_ADDR];

PRINT N'Dropping Index [dbo].[ICS_BS_ANNUL_PROG_REP].[IX_BS_ANL_REP_PR_ID_RE_CV_DA]...';

DROP INDEX [IX_BS_ANL_REP_PR_ID_RE_CV_DA]
    ON [dbo].[ICS_BS_ANNUL_PROG_REP];

PRINT N'Dropping Index [dbo].[ICS_CNST_SITE].[IX_CNST_SITE_ICS_SW_CNS_PRM_ID]...';

DROP INDEX [IX_CNST_SITE_ICS_SW_CNS_PRM_ID]
    ON [dbo].[ICS_CNST_SITE];

PRINT N'Dropping Index [dbo].[ICS_CONTACT].[IX_CNTC_ICS_BS_ANNL_PRO_REP_ID]...';

DROP INDEX [IX_CNTC_ICS_BS_ANNL_PRO_REP_ID]
    ON [dbo].[ICS_CONTACT];

PRINT N'Dropping Index [dbo].[ICS_CONTACT].[IX_CNTC_ICS_SWMS_4_LRGE_PRM_ID]...';

DROP INDEX [IX_CNTC_ICS_SWMS_4_LRGE_PRM_ID]
    ON [dbo].[ICS_CONTACT];

PRINT N'Dropping Index [dbo].[ICS_CONTACT].[IX_CNTC_ICS_SWMS_4_PROG_REP_ID]...';

DROP INDEX [IX_CNTC_ICS_SWMS_4_PROG_REP_ID]
    ON [dbo].[ICS_CONTACT];

PRINT N'Dropping Index [dbo].[ICS_CONTACT].[IX_CNTC_ICS_SWMS_4_SMLL_PRM_ID]...';

DROP INDEX [IX_CNTC_ICS_SWMS_4_SMLL_PRM_ID]
    ON [dbo].[ICS_CONTACT];

PRINT N'Dropping Index [dbo].[ICS_CONTACT].[IX_CNTCT_ICS_BS_MGMT_PRCTCS_ID]...';

DROP INDEX [IX_CNTCT_ICS_BS_MGMT_PRCTCS_ID]
    ON [dbo].[ICS_CONTACT];

PRINT N'Dropping Index [dbo].[ICS_CONTACT].[IX_CONTACT_ICS_BS_PRMT_ID]...';

DROP INDEX [IX_CONTACT_ICS_BS_PRMT_ID]
    ON [dbo].[ICS_CONTACT];

PRINT N'Dropping Index [dbo].[ICS_CONTACT].[IX_CONTACT_ICS_SW_EVT_REP_ID]...';

DROP INDEX [IX_CONTACT_ICS_SW_EVT_REP_ID]
    ON [dbo].[ICS_CONTACT];

PRINT N'Dropping Index [dbo].[ICS_GPCF_NOTICE_OF_TERM].[IX_GPC_NT_OF_TE_IC_SW_CN_PR_ID]...';

DROP INDEX [IX_GPC_NT_OF_TE_IC_SW_CN_PR_ID]
    ON [dbo].[ICS_GPCF_NOTICE_OF_TERM];

PRINT N'Dropping Index [dbo].[ICS_IMPACT_SSO_EVT].[IX_IMP_SSO_EVT_ICS_SS_EV_RE_ID]...';

DROP INDEX [IX_IMP_SSO_EVT_ICS_SS_EV_RE_ID]
    ON [dbo].[ICS_IMPACT_SSO_EVT];

PRINT N'Dropping Index [dbo].[ICS_IMPAIRED_WTR_POLLUTANTS].[IX_IMPR_WTR_PLL_ICS_PRM_FET_ID]...';

DROP INDEX [IX_IMPR_WTR_PLL_ICS_PRM_FET_ID]
    ON [dbo].[ICS_IMPAIRED_WTR_POLLUTANTS];

PRINT N'Dropping Index [dbo].[ICS_PROJ_SRCS_FUND].[IX_PRO_SRC_FU_IC_SW_4_PR_RE_ID]...';

DROP INDEX [IX_PRO_SRC_FU_IC_SW_4_PR_RE_ID]
    ON [dbo].[ICS_PROJ_SRCS_FUND];

PRINT N'Dropping Index [dbo].[ICS_SATL_COLL_SYSTM].[IX_SATL_COL_SYS_ICS_CSO_PRM_ID]...';

DROP INDEX [IX_SATL_COL_SYS_ICS_CSO_PRM_ID]
    ON [dbo].[ICS_SATL_COLL_SYSTM];

PRINT N'Dropping Index [dbo].[ICS_SSO_STPS].[IX_SSO_STPS_ICS_SSO_EVT_REP_ID]...';

DROP INDEX [IX_SSO_STPS_ICS_SSO_EVT_REP_ID]
    ON [dbo].[ICS_SSO_STPS];

PRINT N'Dropping Index [dbo].[ICS_SSO_SYSTM_COMP].[IX_SSO_SYS_COM_ICS_SS_EV_RE_ID]...';

DROP INDEX [IX_SSO_SYS_COM_ICS_SS_EV_RE_ID]
    ON [dbo].[ICS_SSO_SYSTM_COMP];

PRINT N'Dropping Index [dbo].[ICS_TMDL_POLLUTANTS].[IX_TMDL_PLLTN_ICS_PRMT_FETR_ID]...';

DROP INDEX [IX_TMDL_PLLTN_ICS_PRMT_FETR_ID]
    ON [dbo].[ICS_TMDL_POLLUTANTS];

PRINT N'Dropping Foreign Key [dbo].[FK_ADDR_BASIC_PRMT]...';

ALTER TABLE [dbo].[ICS_ADDR] DROP CONSTRAINT [FK_ADDR_BASIC_PRMT];

PRINT N'Dropping Foreign Key [dbo].[FK_ADDR_BS_MGMT_PRACTICES]...';

ALTER TABLE [dbo].[ICS_ADDR] DROP CONSTRAINT [FK_ADDR_BS_MGMT_PRACTICES];

PRINT N'Dropping Foreign Key [dbo].[FK_ADDR_BS_PRMT]...';

ALTER TABLE [dbo].[ICS_ADDR] DROP CONSTRAINT [FK_ADDR_BS_PRMT];

PRINT N'Dropping Foreign Key [dbo].[FK_ADDR_CAFO_PRMT]...';

ALTER TABLE [dbo].[ICS_ADDR] DROP CONSTRAINT [FK_ADDR_CAFO_PRMT];

PRINT N'Dropping Foreign Key [dbo].[FK_ADDR_FAC]...';

ALTER TABLE [dbo].[ICS_ADDR] DROP CONSTRAINT [FK_ADDR_FAC];

PRINT N'Dropping Foreign Key [dbo].[FK_ADDR_GNRL_PRMT]...';

ALTER TABLE [dbo].[ICS_ADDR] DROP CONSTRAINT [FK_ADDR_GNRL_PRMT];

PRINT N'Dropping Foreign Key [dbo].[FK_ADDR_PRMT_FEATR]...';

ALTER TABLE [dbo].[ICS_ADDR] DROP CONSTRAINT [FK_ADDR_PRMT_FEATR];

PRINT N'Dropping Foreign Key [dbo].[FK_ADDR_SW_CNST_PRMT]...';

ALTER TABLE [dbo].[ICS_ADDR] DROP CONSTRAINT [FK_ADDR_SW_CNST_PRMT];

PRINT N'Dropping Foreign Key [dbo].[FK_ADDR_SW_EVT_REP]...';

ALTER TABLE [dbo].[ICS_ADDR] DROP CONSTRAINT [FK_ADDR_SW_EVT_REP];

PRINT N'Dropping Foreign Key [dbo].[FK_ADDR_SW_INDST_PRMT]...';

ALTER TABLE [dbo].[ICS_ADDR] DROP CONSTRAINT [FK_ADDR_SW_INDST_PRMT];

PRINT N'Dropping Foreign Key [dbo].[FK_ADDR_SWMS_4_LARGE_PRMT]...';

ALTER TABLE [dbo].[ICS_ADDR] DROP CONSTRAINT [FK_ADDR_SWMS_4_LARGE_PRMT];

PRINT N'Dropping Foreign Key [dbo].[FK_ADDR_SWMS_4_PROG_REP]...';

ALTER TABLE [dbo].[ICS_ADDR] DROP CONSTRAINT [FK_ADDR_SWMS_4_PROG_REP];

PRINT N'Dropping Foreign Key [dbo].[FK_ADDR_SWMS_4_SMALL_PRMT]...';

ALTER TABLE [dbo].[ICS_ADDR] DROP CONSTRAINT [FK_ADDR_SWMS_4_SMALL_PRMT];

PRINT N'Dropping Foreign Key [dbo].[FK_ADDR_UNPRMT_FAC]...';

ALTER TABLE [dbo].[ICS_ADDR] DROP CONSTRAINT [FK_ADDR_UNPRMT_FAC];

PRINT N'Dropping Foreign Key [dbo].[FK_TELEPH_ADDR]...';

ALTER TABLE [dbo].[ICS_TELEPH] DROP CONSTRAINT [FK_TELEPH_ADDR];

PRINT N'Dropping Foreign Key [dbo].[FK_ANML_TYPE_CAFO_INSP]...';

ALTER TABLE [dbo].[ICS_ANML_TYPE] DROP CONSTRAINT [FK_ANML_TYPE_CAFO_INSP];

PRINT N'Dropping Foreign Key [dbo].[FK_ANML_TYPE_CAFO_PRMT]...';

ALTER TABLE [dbo].[ICS_ANML_TYPE] DROP CONSTRAINT [FK_ANML_TYPE_CAFO_PRMT];

PRINT N'Dropping Foreign Key [dbo].[FK_EFFLU_GUIDE_BASIC_PRMT]...';

ALTER TABLE [dbo].[ICS_EFFLU_GUIDE] DROP CONSTRAINT [FK_EFFLU_GUIDE_BASIC_PRMT];

PRINT N'Dropping Foreign Key [dbo].[FK_FAC_BASIC_PRMT]...';

ALTER TABLE [dbo].[ICS_FAC] DROP CONSTRAINT [FK_FAC_BASIC_PRMT];

PRINT N'Dropping Foreign Key [dbo].[FK_REP_NON_CMPL_STAT_BSIC_PRMT]...';

ALTER TABLE [dbo].[ICS_REP_NON_CMPL_STAT] DROP CONSTRAINT [FK_REP_NON_CMPL_STAT_BSIC_PRMT];

PRINT N'Dropping Foreign Key [dbo].[FK_SIC_CODE_BASIC_PRMT]...';

ALTER TABLE [dbo].[ICS_SIC_CODE] DROP CONSTRAINT [FK_SIC_CODE_BASIC_PRMT];

PRINT N'Dropping Foreign Key [dbo].[FK_ASSC_PRMT_BASIC_PRMT]...';

ALTER TABLE [dbo].[ICS_ASSC_PRMT] DROP CONSTRAINT [FK_ASSC_PRMT_BASIC_PRMT];

PRINT N'Dropping Foreign Key [dbo].[FK_BASIC_PRMT_PAYLOAD]...';

ALTER TABLE [dbo].[ICS_BASIC_PRMT] DROP CONSTRAINT [FK_BASIC_PRMT_PAYLOAD];

PRINT N'Dropping Foreign Key [dbo].[FK_CMPL_TRACK_STAT_BASIC_PRMT]...';

ALTER TABLE [dbo].[ICS_CMPL_TRACK_STAT] DROP CONSTRAINT [FK_CMPL_TRACK_STAT_BASIC_PRMT];

PRINT N'Dropping Foreign Key [dbo].[FK_NAICS_CODE_BASIC_PRMT]...';

ALTER TABLE [dbo].[ICS_NAICS_CODE] DROP CONSTRAINT [FK_NAICS_CODE_BASIC_PRMT];

PRINT N'Dropping Foreign Key [dbo].[FK_CONTACT_BASIC_PRMT]...';

ALTER TABLE [dbo].[ICS_CONTACT] DROP CONSTRAINT [FK_CONTACT_BASIC_PRMT];

PRINT N'Dropping Foreign Key [dbo].[FK_NPDES_DAT_GRP_NUM_BSIC_PRMT]...';

ALTER TABLE [dbo].[ICS_NPDES_DAT_GRP_NUM] DROP CONSTRAINT [FK_NPDES_DAT_GRP_NUM_BSIC_PRMT];

PRINT N'Dropping Foreign Key [dbo].[FK_OTHR_PRMTS_BASIC_PRMT]...';

ALTER TABLE [dbo].[ICS_OTHR_PRMTS] DROP CONSTRAINT [FK_OTHR_PRMTS_BASIC_PRMT];

PRINT N'Dropping Foreign Key [dbo].[FK_REP_OBLG_TYP_BS_ANN_PRO_REP]...';

ALTER TABLE [dbo].[ICS_REP_OBLGTN_TYPE] DROP CONSTRAINT [FK_REP_OBLG_TYP_BS_ANN_PRO_REP];

PRINT N'Dropping Foreign Key [dbo].[FK_ANLYT_MTHD_BS_ANNL_PROG_REP]...';

ALTER TABLE [dbo].[ICS_ANLYTCL_METHOD] DROP CONSTRAINT [FK_ANLYT_MTHD_BS_ANNL_PROG_REP];

PRINT N'Dropping Foreign Key [dbo].[FK_BS_ANNUL_PROG_REP_PAYLOAD]...';

ALTER TABLE [dbo].[ICS_BS_ANNUL_PROG_REP] DROP CONSTRAINT [FK_BS_ANNUL_PROG_REP_PAYLOAD];

PRINT N'Dropping Foreign Key [dbo].[FK_BS_MGMT_PRCT_BS_ANN_PRO_REP]...';

ALTER TABLE [dbo].[ICS_BS_MGMT_PRACTICES] DROP CONSTRAINT [FK_BS_MGMT_PRCT_BS_ANN_PRO_REP];

PRINT N'Dropping Foreign Key [dbo].[FK_CONTACT_BS_ANNUL_PROG_REP]...';

ALTER TABLE [dbo].[ICS_CONTACT] DROP CONSTRAINT [FK_CONTACT_BS_ANNUL_PROG_REP];

PRINT N'Dropping Foreign Key [dbo].[FK_TRTM_PRC_TYP_BS_ANN_PRO_REP]...';

ALTER TABLE [dbo].[ICS_TRTMNT_PRCSS_TYPE] DROP CONSTRAINT [FK_TRTM_PRC_TYP_BS_ANN_PRO_REP];

PRINT N'Dropping Foreign Key [dbo].[FK_BS_END_USE_DSPL_TYPE_BS_PRM]...';

ALTER TABLE [dbo].[ICS_BS_END_USE_DSPL_TYPE] DROP CONSTRAINT [FK_BS_END_USE_DSPL_TYPE_BS_PRM];

PRINT N'Dropping Foreign Key [dbo].[FK_BS_PRMT_PAYLOAD]...';

ALTER TABLE [dbo].[ICS_BS_PRMT] DROP CONSTRAINT [FK_BS_PRMT_PAYLOAD];

PRINT N'Dropping Foreign Key [dbo].[FK_BS_TYPE_BS_PRMT]...';

ALTER TABLE [dbo].[ICS_BS_TYPE] DROP CONSTRAINT [FK_BS_TYPE_BS_PRMT];

PRINT N'Dropping Foreign Key [dbo].[FK_CONTACT_BS_PRMT]...';

ALTER TABLE [dbo].[ICS_CONTACT] DROP CONSTRAINT [FK_CONTACT_BS_PRMT];

PRINT N'Dropping Foreign Key [dbo].[FK_LAND_APPL_BMP_CAFO_INSP]...';

ALTER TABLE [dbo].[ICS_LAND_APPL_BMP] DROP CONSTRAINT [FK_LAND_APPL_BMP_CAFO_INSP];

PRINT N'Dropping Foreign Key [dbo].[FK_CAFO_INSP_CMPL_MON]...';

ALTER TABLE [dbo].[ICS_CAFO_INSP] DROP CONSTRAINT [FK_CAFO_INSP_CMPL_MON];

PRINT N'Dropping Foreign Key [dbo].[FK_CAFO_INSP_VIOL_TYPE_CAF_INS]...';

ALTER TABLE [dbo].[ICS_CAFO_INSP_VIOL_TYPE] DROP CONSTRAINT [FK_CAFO_INSP_VIOL_TYPE_CAF_INS];

PRINT N'Dropping Foreign Key [dbo].[FK_MNUR_LTT_PRC_WW_STO_CAF_INS]...';

ALTER TABLE [dbo].[ICS_MNUR_LTTR_PRCSS_WW_STOR] DROP CONSTRAINT [FK_MNUR_LTT_PRC_WW_STO_CAF_INS];

PRINT N'Dropping Foreign Key [dbo].[FK_CONTAINMENT_CAFO_INSP]...';

ALTER TABLE [dbo].[ICS_CONTAINMENT] DROP CONSTRAINT [FK_CONTAINMENT_CAFO_INSP];

PRINT N'Dropping Foreign Key [dbo].[FK_CNST_SITE_SW_CNST_PRMT]...';

ALTER TABLE [dbo].[ICS_CNST_SITE] DROP CONSTRAINT [FK_CNST_SITE_SW_CNST_PRMT];

PRINT N'Dropping Foreign Key [dbo].[FK_TELEPH_CONTACT]...';

ALTER TABLE [dbo].[ICS_TELEPH] DROP CONSTRAINT [FK_TELEPH_CONTACT];

PRINT N'Dropping Foreign Key [dbo].[FK_CONTACT_BS_MGMT_PRACTICES]...';

ALTER TABLE [dbo].[ICS_CONTACT] DROP CONSTRAINT [FK_CONTACT_BS_MGMT_PRACTICES];

PRINT N'Dropping Foreign Key [dbo].[FK_CONTACT_CAFO_PRMT]...';

ALTER TABLE [dbo].[ICS_CONTACT] DROP CONSTRAINT [FK_CONTACT_CAFO_PRMT];

PRINT N'Dropping Foreign Key [dbo].[FK_CONTACT_CMPL_MON]...';

ALTER TABLE [dbo].[ICS_CONTACT] DROP CONSTRAINT [FK_CONTACT_CMPL_MON];

PRINT N'Dropping Foreign Key [dbo].[FK_CONTACT_FAC]...';

ALTER TABLE [dbo].[ICS_CONTACT] DROP CONSTRAINT [FK_CONTACT_FAC];

PRINT N'Dropping Foreign Key [dbo].[FK_CONTACT_GNRL_PRMT]...';

ALTER TABLE [dbo].[ICS_CONTACT] DROP CONSTRAINT [FK_CONTACT_GNRL_PRMT];

PRINT N'Dropping Foreign Key [dbo].[FK_CONTACT_MASTER_GNRL_PRMT]...';

ALTER TABLE [dbo].[ICS_CONTACT] DROP CONSTRAINT [FK_CONTACT_MASTER_GNRL_PRMT];

PRINT N'Dropping Foreign Key [dbo].[FK_CONTACT_PRETR_PRMT]...';

ALTER TABLE [dbo].[ICS_CONTACT] DROP CONSTRAINT [FK_CONTACT_PRETR_PRMT];

PRINT N'Dropping Foreign Key [dbo].[FK_CONTACT_PRMT_FEATR]...';

ALTER TABLE [dbo].[ICS_CONTACT] DROP CONSTRAINT [FK_CONTACT_PRMT_FEATR];

PRINT N'Dropping Foreign Key [dbo].[FK_CONTACT_SW_CNST_PRMT]...';

ALTER TABLE [dbo].[ICS_CONTACT] DROP CONSTRAINT [FK_CONTACT_SW_CNST_PRMT];

PRINT N'Dropping Foreign Key [dbo].[FK_CONTACT_SW_EVT_REP]...';

ALTER TABLE [dbo].[ICS_CONTACT] DROP CONSTRAINT [FK_CONTACT_SW_EVT_REP];

PRINT N'Dropping Foreign Key [dbo].[FK_CONTACT_SW_INDST_PRMT]...';

ALTER TABLE [dbo].[ICS_CONTACT] DROP CONSTRAINT [FK_CONTACT_SW_INDST_PRMT];

PRINT N'Dropping Foreign Key [dbo].[FK_CONTACT_SWMS_4_LARGE_PRMT]...';

ALTER TABLE [dbo].[ICS_CONTACT] DROP CONSTRAINT [FK_CONTACT_SWMS_4_LARGE_PRMT];

PRINT N'Dropping Foreign Key [dbo].[FK_CONTACT_SWMS_4_PROG_REP]...';

ALTER TABLE [dbo].[ICS_CONTACT] DROP CONSTRAINT [FK_CONTACT_SWMS_4_PROG_REP];

PRINT N'Dropping Foreign Key [dbo].[FK_CONTACT_SWMS_4_SMALL_PRMT]...';

ALTER TABLE [dbo].[ICS_CONTACT] DROP CONSTRAINT [FK_CONTACT_SWMS_4_SMALL_PRMT];

PRINT N'Dropping Foreign Key [dbo].[FK_CONTACT_UNPRMT_FAC]...';

ALTER TABLE [dbo].[ICS_CONTACT] DROP CONSTRAINT [FK_CONTACT_UNPRMT_FAC];

PRINT N'Dropping Foreign Key [dbo].[FK_REP_PARAM_DSCH_MON_REP]...';

ALTER TABLE [dbo].[ICS_REP_PARAM] DROP CONSTRAINT [FK_REP_PARAM_DSCH_MON_REP];

PRINT N'Dropping Foreign Key [dbo].[FK_INCIN_DSCH_MON_REP]...';

ALTER TABLE [dbo].[ICS_INCIN] DROP CONSTRAINT [FK_INCIN_DSCH_MON_REP];

PRINT N'Dropping Foreign Key [dbo].[FK_LAND_APPL_SITE_DSCH_MON_REP]...';

ALTER TABLE [dbo].[ICS_LAND_APPL_SITE] DROP CONSTRAINT [FK_LAND_APPL_SITE_DSCH_MON_REP];

PRINT N'Dropping Foreign Key [dbo].[FK_SURF_DSPL_SITE_DSCH_MON_REP]...';

ALTER TABLE [dbo].[ICS_SURF_DSPL_SITE] DROP CONSTRAINT [FK_SURF_DSPL_SITE_DSCH_MON_REP];

PRINT N'Dropping Foreign Key [dbo].[FK_CO_DSPL_SITE_DSCH_MON_REP]...';

ALTER TABLE [dbo].[ICS_CO_DSPL_SITE] DROP CONSTRAINT [FK_CO_DSPL_SITE_DSCH_MON_REP];

PRINT N'Dropping Foreign Key [dbo].[FK_DSCH_MON_REP_PAYLOAD]...';

ALTER TABLE [dbo].[ICS_DSCH_MON_REP] DROP CONSTRAINT [FK_DSCH_MON_REP_PAYLOAD];

PRINT N'Dropping Foreign Key [dbo].[FK_FAC_GNRL_PRMT]...';

ALTER TABLE [dbo].[ICS_FAC] DROP CONSTRAINT [FK_FAC_GNRL_PRMT];

PRINT N'Dropping Foreign Key [dbo].[FK_FAC_CLASS_FAC]...';

ALTER TABLE [dbo].[ICS_FAC_CLASS] DROP CONSTRAINT [FK_FAC_CLASS_FAC];

PRINT N'Dropping Foreign Key [dbo].[FK_GEO_COORD_FAC]...';

ALTER TABLE [dbo].[ICS_GEO_COORD] DROP CONSTRAINT [FK_GEO_COORD_FAC];

PRINT N'Dropping Foreign Key [dbo].[FK_SIC_CODE_FAC]...';

ALTER TABLE [dbo].[ICS_SIC_CODE] DROP CONSTRAINT [FK_SIC_CODE_FAC];

PRINT N'Dropping Foreign Key [dbo].[FK_NAICS_CODE_FAC]...';

ALTER TABLE [dbo].[ICS_NAICS_CODE] DROP CONSTRAINT [FK_NAICS_CODE_FAC];

PRINT N'Dropping Foreign Key [dbo].[FK_ORIG_PROGS_FAC]...';

ALTER TABLE [dbo].[ICS_ORIG_PROGS] DROP CONSTRAINT [FK_ORIG_PROGS_FAC];

PRINT N'Dropping Foreign Key [dbo].[FK_PLCY_FAC]...';

ALTER TABLE [dbo].[ICS_PLCY] DROP CONSTRAINT [FK_PLCY_FAC];

PRINT N'Dropping Foreign Key [dbo].[FK_FINAL_ORDER_FRML_ENFRC_ACTN]...';

ALTER TABLE [dbo].[ICS_FINAL_ORDER] DROP CONSTRAINT [FK_FINAL_ORDER_FRML_ENFRC_ACTN];

PRINT N'Dropping Foreign Key [dbo].[FK_FINL_ORDR_PRMT_IDNT_FIN_ORD]...';

ALTER TABLE [dbo].[ICS_FINAL_ORDER_PRMT_IDENT] DROP CONSTRAINT [FK_FINL_ORDR_PRMT_IDNT_FIN_ORD];

PRINT N'Dropping Foreign Key [dbo].[FK_SEP_FINAL_ORDER]...';

ALTER TABLE [dbo].[ICS_SEP] DROP CONSTRAINT [FK_SEP_FINAL_ORDER];

PRINT N'Dropping Foreign Key [dbo].[FK_GEO_COORD_PRMT_FEATR]...';

ALTER TABLE [dbo].[ICS_GEO_COORD] DROP CONSTRAINT [FK_GEO_COORD_PRMT_FEATR];

PRINT N'Dropping Foreign Key [dbo].[FK_GEO_COORD_UNPRMT_FAC]...';

ALTER TABLE [dbo].[ICS_GEO_COORD] DROP CONSTRAINT [FK_GEO_COORD_UNPRMT_FAC];

PRINT N'Dropping Foreign Key [dbo].[FK_EFFLU_GUIDE_GNRL_PRMT]...';

ALTER TABLE [dbo].[ICS_EFFLU_GUIDE] DROP CONSTRAINT [FK_EFFLU_GUIDE_GNRL_PRMT];

PRINT N'Dropping Foreign Key [dbo].[FK_GNRL_PRMT_PAYLOAD]...';

ALTER TABLE [dbo].[ICS_GNRL_PRMT] DROP CONSTRAINT [FK_GNRL_PRMT_PAYLOAD];

PRINT N'Dropping Foreign Key [dbo].[FK_REP_NON_CMPL_STAT_GNRL_PRMT]...';

ALTER TABLE [dbo].[ICS_REP_NON_CMPL_STAT] DROP CONSTRAINT [FK_REP_NON_CMPL_STAT_GNRL_PRMT];

PRINT N'Dropping Foreign Key [dbo].[FK_SIC_CODE_GNRL_PRMT]...';

ALTER TABLE [dbo].[ICS_SIC_CODE] DROP CONSTRAINT [FK_SIC_CODE_GNRL_PRMT];

PRINT N'Dropping Foreign Key [dbo].[FK_ASSC_PRMT_GNRL_PRMT]...';

ALTER TABLE [dbo].[ICS_ASSC_PRMT] DROP CONSTRAINT [FK_ASSC_PRMT_GNRL_PRMT];

PRINT N'Dropping Foreign Key [dbo].[FK_CMPL_TRACK_STAT_GNRL_PRMT]...';

ALTER TABLE [dbo].[ICS_CMPL_TRACK_STAT] DROP CONSTRAINT [FK_CMPL_TRACK_STAT_GNRL_PRMT];

PRINT N'Dropping Foreign Key [dbo].[FK_NAICS_CODE_GNRL_PRMT]...';

ALTER TABLE [dbo].[ICS_NAICS_CODE] DROP CONSTRAINT [FK_NAICS_CODE_GNRL_PRMT];

PRINT N'Dropping Foreign Key [dbo].[FK_NPDES_DAT_GRP_NUM_GNRL_PRMT]...';

ALTER TABLE [dbo].[ICS_NPDES_DAT_GRP_NUM] DROP CONSTRAINT [FK_NPDES_DAT_GRP_NUM_GNRL_PRMT];

PRINT N'Dropping Foreign Key [dbo].[FK_OTHR_PRMTS_GNRL_PRMT]...';

ALTER TABLE [dbo].[ICS_OTHR_PRMTS] DROP CONSTRAINT [FK_OTHR_PRMTS_GNRL_PRMT];

PRINT N'Dropping Foreign Key [dbo].[FK_IMPRD_WTR_PLLTNTS_PRMT_FETR]...';

ALTER TABLE [dbo].[ICS_IMPAIRED_WTR_POLLUTANTS] DROP CONSTRAINT [FK_IMPRD_WTR_PLLTNTS_PRMT_FETR];

PRINT N'Dropping Foreign Key [dbo].[FK_LMT_SET_SCHD_LMT_SET]...';

ALTER TABLE [dbo].[ICS_LMT_SET_SCHD] DROP CONSTRAINT [FK_LMT_SET_SCHD_LMT_SET];

PRINT N'Dropping Foreign Key [dbo].[FK_LMT_SET_STAT_LMT_SET]...';

ALTER TABLE [dbo].[ICS_LMT_SET_STAT] DROP CONSTRAINT [FK_LMT_SET_STAT_LMT_SET];

PRINT N'Dropping Foreign Key [dbo].[FK_LMTS_PAYLOAD]...';

ALTER TABLE [dbo].[ICS_LMTS] DROP CONSTRAINT [FK_LMTS_PAYLOAD];

PRINT N'Dropping Foreign Key [dbo].[FK_MN_LMT_APPLIES_LMTS]...';

ALTER TABLE [dbo].[ICS_MN_LMT_APPLIES] DROP CONSTRAINT [FK_MN_LMT_APPLIES_LMTS];

PRINT N'Dropping Foreign Key [dbo].[FK_NUM_COND_LMTS]...';

ALTER TABLE [dbo].[ICS_NUM_COND] DROP CONSTRAINT [FK_NUM_COND_LMTS];

PRINT N'Dropping Foreign Key [dbo].[FK_MNUR_LTT_PRC_WW_STO_CAF_PRM]...';

ALTER TABLE [dbo].[ICS_MNUR_LTTR_PRCSS_WW_STOR] DROP CONSTRAINT [FK_MNUR_LTT_PRC_WW_STO_CAF_PRM];

PRINT N'Dropping Foreign Key [dbo].[FK_PTHG_RDCT_TYPE_BS_MGMT_PRCT]...';

ALTER TABLE [dbo].[ICS_PATHOGEN_REDUCTION_TYPE] DROP CONSTRAINT [FK_PTHG_RDCT_TYPE_BS_MGMT_PRCT];

PRINT N'Dropping Foreign Key [dbo].[FK_PRETR_PRMT_PAYLOAD]...';

ALTER TABLE [dbo].[ICS_PRETR_PRMT] DROP CONSTRAINT [FK_PRETR_PRMT_PAYLOAD];

PRINT N'Dropping Foreign Key [dbo].[FK_GPCF_NTCE_OF_INT_SW_CNS_PRM]...';

ALTER TABLE [dbo].[ICS_GPCF_NOTICE_OF_INTENT] DROP CONSTRAINT [FK_GPCF_NTCE_OF_INT_SW_CNS_PRM];

PRINT N'Dropping Foreign Key [dbo].[FK_GPCF_NTCE_OF_TER_SW_CNS_PRM]...';

ALTER TABLE [dbo].[ICS_GPCF_NOTICE_OF_TERM] DROP CONSTRAINT [FK_GPCF_NTCE_OF_TER_SW_CNS_PRM];

PRINT N'Dropping Foreign Key [dbo].[FK_SW_CNST_PRMT_PAYLOAD]...';

ALTER TABLE [dbo].[ICS_SW_CNST_PRMT] DROP CONSTRAINT [FK_SW_CNST_PRMT_PAYLOAD];

PRINT N'Dropping Foreign Key [dbo].[FK_TRTM_CHMS_LIST_SW_CNST_PRMT]...';

ALTER TABLE [dbo].[ICS_TRTMNT_CHEMS_LIST] DROP CONSTRAINT [FK_TRTM_CHMS_LIST_SW_CNST_PRMT];

PRINT N'Dropping Foreign Key [dbo].[FK_GPCF_NO_EXPSR_SW_INDST_PRMT]...';

ALTER TABLE [dbo].[ICS_GPCF_NO_EXPOSURE] DROP CONSTRAINT [FK_GPCF_NO_EXPSR_SW_INDST_PRMT];

PRINT N'Dropping Foreign Key [dbo].[FK_GPCF_NTCE_OF_INT_SW_IND_PRM]...';

ALTER TABLE [dbo].[ICS_GPCF_NOTICE_OF_INTENT] DROP CONSTRAINT [FK_GPCF_NTCE_OF_INT_SW_IND_PRM];

PRINT N'Dropping Foreign Key [dbo].[FK_GPCF_NTCE_OF_TER_SW_IND_PRM]...';

ALTER TABLE [dbo].[ICS_GPCF_NOTICE_OF_TERM] DROP CONSTRAINT [FK_GPCF_NTCE_OF_TER_SW_IND_PRM];

PRINT N'Dropping Foreign Key [dbo].[FK_SW_INDST_PRMT_PAYLOAD]...';

ALTER TABLE [dbo].[ICS_SW_INDST_PRMT] DROP CONSTRAINT [FK_SW_INDST_PRMT_PAYLOAD];

PRINT N'Dropping Foreign Key [dbo].[FK_TMDL_POLLUTANTS_PRMT_FEATR]...';

ALTER TABLE [dbo].[ICS_TMDL_POLLUTANTS] DROP CONSTRAINT [FK_TMDL_POLLUTANTS_PRMT_FEATR];

PRINT N'Dropping Foreign Key [dbo].[FK_TMDL_POLUT_TMDL_POLLUTANTS]...';

ALTER TABLE [dbo].[ICS_TMDL_POLUT] DROP CONSTRAINT [FK_TMDL_POLUT_TMDL_POLLUTANTS];

PRINT N'Dropping Foreign Key [dbo].[FK_PRMT_COMP_TYPE_UNPRMT_FAC]...';

ALTER TABLE [dbo].[ICS_PRMT_COMP_TYPE] DROP CONSTRAINT [FK_PRMT_COMP_TYPE_UNPRMT_FAC];

PRINT N'Dropping Foreign Key [dbo].[FK_FAC_CLASS_UNPRMT_FAC]...';

ALTER TABLE [dbo].[ICS_FAC_CLASS] DROP CONSTRAINT [FK_FAC_CLASS_UNPRMT_FAC];

PRINT N'Dropping Foreign Key [dbo].[FK_SIC_CODE_UNPRMT_FAC]...';

ALTER TABLE [dbo].[ICS_SIC_CODE] DROP CONSTRAINT [FK_SIC_CODE_UNPRMT_FAC];

PRINT N'Dropping Foreign Key [dbo].[FK_NAICS_CODE_UNPRMT_FAC]...';

ALTER TABLE [dbo].[ICS_NAICS_CODE] DROP CONSTRAINT [FK_NAICS_CODE_UNPRMT_FAC];

PRINT N'Dropping Foreign Key [dbo].[FK_UNPRMT_FAC_PAYLOAD]...';

ALTER TABLE [dbo].[ICS_UNPRMT_FAC] DROP CONSTRAINT [FK_UNPRMT_FAC_PAYLOAD];

PRINT N'Dropping Foreign Key [dbo].[FK_ORIG_PROGS_UNPRMT_FAC]...';

ALTER TABLE [dbo].[ICS_ORIG_PROGS] DROP CONSTRAINT [FK_ORIG_PROGS_UNPRMT_FAC];

PRINT N'Dropping Foreign Key [dbo].[FK_PLCY_UNPRMT_FAC]...';

ALTER TABLE [dbo].[ICS_PLCY] DROP CONSTRAINT [FK_PLCY_UNPRMT_FAC];

PRINT N'Dropping Foreign Key [dbo].[FK_VCTR_A_RDCT_TYPE_BS_MGM_PRC]...';

ALTER TABLE [dbo].[ICS_VECTOR_A_REDUCTION_TYPE] DROP CONSTRAINT [FK_VCTR_A_RDCT_TYPE_BS_MGM_PRC];

PRINT N'Dropping Foreign Key [dbo].[FK_IMPACT_SSO_EVT_SSO_INSP]...';

ALTER TABLE [dbo].[ICS_IMPACT_SSO_EVT] DROP CONSTRAINT [FK_IMPACT_SSO_EVT_SSO_INSP];

PRINT N'Dropping Foreign Key [dbo].[FK_PROJ_SRCS_FUND_SW_MS_4_INSP]...';

ALTER TABLE [dbo].[ICS_PROJ_SRCS_FUND] DROP CONSTRAINT [FK_PROJ_SRCS_FUND_SW_MS_4_INSP];

PRINT N'Dropping Foreign Key [dbo].[FK_SATL_COLL_SYSTM_POTW_PRMT]...';

ALTER TABLE [dbo].[ICS_SATL_COLL_SYSTM] DROP CONSTRAINT [FK_SATL_COLL_SYSTM_POTW_PRMT];

PRINT N'Dropping Foreign Key [dbo].[FK_SSO_STPS_SSO_INSP]...';

ALTER TABLE [dbo].[ICS_SSO_STPS] DROP CONSTRAINT [FK_SSO_STPS_SSO_INSP];

PRINT N'Dropping Foreign Key [dbo].[FK_SSO_SYSTM_COMP_SSO_INSP]...';

ALTER TABLE [dbo].[ICS_SSO_SYSTM_COMP] DROP CONSTRAINT [FK_SSO_SYSTM_COMP_SSO_INSP];

PRINT N'Dropping Foreign Key [dbo].[FK_MGMT_PRC_DFC_TYP_BS_MGM_PRC]...';

ALTER TABLE [dbo].[ICS_MGMT_PRC_DEFCY_TYPE] DROP CONSTRAINT [FK_MGMT_PRC_DFC_TYP_BS_MGM_PRC];

PRINT N'Dropping Foreign Key [dbo].[FK_REP_ANML_TYPE_CAFO_ANNL_REP]...';

ALTER TABLE [dbo].[ICS_REP_ANML_TYPE] DROP CONSTRAINT [FK_REP_ANML_TYPE_CAFO_ANNL_REP];

PRINT N'Dropping Foreign Key [dbo].[FK_SATL_COLL_SYSTM_CSO_PRMT]...';

ALTER TABLE [dbo].[ICS_SATL_COLL_SYSTM] DROP CONSTRAINT [FK_SATL_COLL_SYSTM_CSO_PRMT];

PRINT N'Dropping Foreign Key [dbo].[FK_LNK_BS_REP_DMR_PROG_REP_LNK]...';

ALTER TABLE [dbo].[ICS_LNK_BS_REP] DROP CONSTRAINT [FK_LNK_BS_REP_DMR_PROG_REP_LNK];

PRINT N'Dropping Foreign Key [dbo].[FK_LNK_SW_EVT_REP_DMR_PR_RE_LN]...';

ALTER TABLE [dbo].[ICS_LNK_SW_EVT_REP] DROP CONSTRAINT [FK_LNK_SW_EVT_REP_DMR_PR_RE_LN];

PRINT N'Dropping Foreign Key [dbo].[FK_LOC_LMTS_POLUT_LOC_LMTS]...';

ALTER TABLE [dbo].[ICS_LOC_LMTS_POLUT] DROP CONSTRAINT [FK_LOC_LMTS_POLUT_LOC_LMTS];

PRINT N'Dropping Foreign Key [dbo].[FK_RMVL_CRDT_LOC_LMTS_PROG_REP]...';

ALTER TABLE [dbo].[ICS_RMVL_CRDTS] DROP CONSTRAINT [FK_RMVL_CRDT_LOC_LMTS_PROG_REP];

PRINT N'Dropping Foreign Key [dbo].[FK_LOC_LMTS_LOC_LMTS_PROG_REP]...';

ALTER TABLE [dbo].[ICS_LOC_LMTS] DROP CONSTRAINT [FK_LOC_LMTS_LOC_LMTS_PROG_REP];

PRINT N'Dropping Foreign Key [dbo].[FK_RMVL_CRDTS_PRETR_PERF_SUMM]...';

ALTER TABLE [dbo].[ICS_RMVL_CRDTS] DROP CONSTRAINT [FK_RMVL_CRDTS_PRETR_PERF_SUMM];

PRINT N'Dropping Foreign Key [dbo].[FK_LOC_LMTS_PRETR_PERF_SUMM]...';

ALTER TABLE [dbo].[ICS_LOC_LMTS] DROP CONSTRAINT [FK_LOC_LMTS_PRETR_PERF_SUMM];

PRINT N'Dropping Foreign Key [dbo].[FK_RMVL_CRDTS_POLUT_RMVL_CRDTS]...';

ALTER TABLE [dbo].[ICS_RMVL_CRDTS_POLUT] DROP CONSTRAINT [FK_RMVL_CRDTS_POLUT_RMVL_CRDTS];

PRINT N'Dropping Foreign Key [dbo].[FK_IMPACT_SSO_EVT_SSO_EVT_REP]...';

ALTER TABLE [dbo].[ICS_IMPACT_SSO_EVT] DROP CONSTRAINT [FK_IMPACT_SSO_EVT_SSO_EVT_REP];

PRINT N'Dropping Foreign Key [dbo].[FK_SSO_STPS_SSO_EVT_REP]...';

ALTER TABLE [dbo].[ICS_SSO_STPS] DROP CONSTRAINT [FK_SSO_STPS_SSO_EVT_REP];

PRINT N'Dropping Foreign Key [dbo].[FK_SSO_SYSTM_COMP_SSO_EVT_REP]...';

ALTER TABLE [dbo].[ICS_SSO_SYSTM_COMP] DROP CONSTRAINT [FK_SSO_SYSTM_COMP_SSO_EVT_REP];

PRINT N'Dropping Foreign Key [dbo].[FK_PROJ_SRCS_FUN_SWM_4_PRO_REP]...';

ALTER TABLE [dbo].[ICS_PROJ_SRCS_FUND] DROP CONSTRAINT [FK_PROJ_SRCS_FUN_SWM_4_PRO_REP];

PRINT N'Dropping Foreign Key [dbo].[FK_GPCF_CNST_WIV_SWM_4_SML_PRM]...';

ALTER TABLE [dbo].[ICS_GPCF_CNST_WAIVER] DROP CONSTRAINT [FK_GPCF_CNST_WIV_SWM_4_SML_PRM];

PRINT N'Dropping Foreign Key [dbo].[FK_BS_PROG_REP_PAYLOAD]...';

ALTER TABLE [dbo].[ICS_BS_PROG_REP] DROP CONSTRAINT [FK_BS_PROG_REP_PAYLOAD];

PRINT N'Dropping Foreign Key [dbo].[FK_CAFO_ANNUL_REP_PAYLOAD]...';

ALTER TABLE [dbo].[ICS_CAFO_ANNUL_REP] DROP CONSTRAINT [FK_CAFO_ANNUL_REP_PAYLOAD];

PRINT N'Dropping Foreign Key [dbo].[FK_CSO_EVT_REP_PAYLOAD]...';

ALTER TABLE [dbo].[ICS_CSO_EVT_REP] DROP CONSTRAINT [FK_CSO_EVT_REP_PAYLOAD];

PRINT N'Dropping Foreign Key [dbo].[FK_CSO_PRMT_PAYLOAD]...';

ALTER TABLE [dbo].[ICS_CSO_PRMT] DROP CONSTRAINT [FK_CSO_PRMT_PAYLOAD];

PRINT N'Dropping Foreign Key [dbo].[FK_DMR_PROG_REP_LNK_PAYLOAD]...';

ALTER TABLE [dbo].[ICS_DMR_PROG_REP_LNK] DROP CONSTRAINT [FK_DMR_PROG_REP_LNK_PAYLOAD];

PRINT N'Dropping Foreign Key [dbo].[FK_LNK_BS_REP_CMPL_MON_LNK]...';

ALTER TABLE [dbo].[ICS_LNK_BS_REP] DROP CONSTRAINT [FK_LNK_BS_REP_CMPL_MON_LNK];

PRINT N'Dropping Foreign Key [dbo].[FK_LNK_CAF_ANN_REP_CMP_MON_LNK]...';

ALTER TABLE [dbo].[ICS_LNK_CAFO_ANNUL_REP] DROP CONSTRAINT [FK_LNK_CAF_ANN_REP_CMP_MON_LNK];

PRINT N'Dropping Foreign Key [dbo].[FK_LNK_CSO_EVT_REP_CMP_MON_LNK]...';

ALTER TABLE [dbo].[ICS_LNK_CSO_EVT_REP] DROP CONSTRAINT [FK_LNK_CSO_EVT_REP_CMP_MON_LNK];

PRINT N'Dropping Foreign Key [dbo].[FK_LNK_FED_CMP_MON_CMP_MON_LNK]...';

ALTER TABLE [dbo].[ICS_LNK_FEDR_CMPL_MON] DROP CONSTRAINT [FK_LNK_FED_CMP_MON_CMP_MON_LNK];

PRINT N'Dropping Foreign Key [dbo].[FK_LNK_LOC_LMT_REP_CMP_MON_LNK]...';

ALTER TABLE [dbo].[ICS_LNK_LOC_LMTS_REP] DROP CONSTRAINT [FK_LNK_LOC_LMT_REP_CMP_MON_LNK];

PRINT N'Dropping Foreign Key [dbo].[FK_LNK_PRT_PER_REP_CMP_MON_LNK]...';

ALTER TABLE [dbo].[ICS_LNK_PRETR_PERF_REP] DROP CONSTRAINT [FK_LNK_PRT_PER_REP_CMP_MON_LNK];

PRINT N'Dropping Foreign Key [dbo].[FK_LNK_SSO_ANN_REP_CMP_MON_LNK]...';

ALTER TABLE [dbo].[ICS_LNK_SSO_ANNUL_REP] DROP CONSTRAINT [FK_LNK_SSO_ANN_REP_CMP_MON_LNK];

PRINT N'Dropping Foreign Key [dbo].[FK_LNK_SSO_EVT_REP_CMP_MON_LNK]...';

ALTER TABLE [dbo].[ICS_LNK_SSO_EVT_REP] DROP CONSTRAINT [FK_LNK_SSO_EVT_REP_CMP_MON_LNK];

PRINT N'Dropping Foreign Key [dbo].[FK_LNK_SSO_MNT_EVT_RE_CM_MO_LN]...';

ALTER TABLE [dbo].[ICS_LNK_SSO_MONTHLY_EVT_REP] DROP CONSTRAINT [FK_LNK_SSO_MNT_EVT_RE_CM_MO_LN];

PRINT N'Dropping Foreign Key [dbo].[FK_LNK_ST_CMPL_MON_CMP_MON_LNK]...';

ALTER TABLE [dbo].[ICS_LNK_ST_CMPL_MON] DROP CONSTRAINT [FK_LNK_ST_CMPL_MON_CMP_MON_LNK];

PRINT N'Dropping Foreign Key [dbo].[FK_LNK_SW_EVT_REP_CMPL_MON_LNK]...';

ALTER TABLE [dbo].[ICS_LNK_SW_EVT_REP] DROP CONSTRAINT [FK_LNK_SW_EVT_REP_CMPL_MON_LNK];

PRINT N'Dropping Foreign Key [dbo].[FK_LNK_SWMS_4_REP_CMPL_MON_LNK]...';

ALTER TABLE [dbo].[ICS_LNK_SWMS_4_REP] DROP CONSTRAINT [FK_LNK_SWMS_4_REP_CMPL_MON_LNK];

PRINT N'Dropping Foreign Key [dbo].[FK_LOC_LMTS_PRETR_INSP]...';

ALTER TABLE [dbo].[ICS_LOC_LMTS] DROP CONSTRAINT [FK_LOC_LMTS_PRETR_INSP];

PRINT N'Dropping Foreign Key [dbo].[FK_LOC_LMTS_PROG_REP_PAYLOAD]...';

ALTER TABLE [dbo].[ICS_LOC_LMTS_PROG_REP] DROP CONSTRAINT [FK_LOC_LMTS_PROG_REP_PAYLOAD];

PRINT N'Dropping Foreign Key [dbo].[FK_PRETR_PERF_SUMM_PAYLOAD]...';

ALTER TABLE [dbo].[ICS_PRETR_PERF_SUMM] DROP CONSTRAINT [FK_PRETR_PERF_SUMM_PAYLOAD];

PRINT N'Dropping Foreign Key [dbo].[FK_RMVL_CRDTS_PRETR_INSP]...';

ALTER TABLE [dbo].[ICS_RMVL_CRDTS] DROP CONSTRAINT [FK_RMVL_CRDTS_PRETR_INSP];

PRINT N'Dropping Foreign Key [dbo].[FK_SSO_ANNUL_REP_PAYLOAD]...';

ALTER TABLE [dbo].[ICS_SSO_ANNUL_REP] DROP CONSTRAINT [FK_SSO_ANNUL_REP_PAYLOAD];

PRINT N'Dropping Foreign Key [dbo].[FK_SSO_EVT_REP_PAYLOAD]...';

ALTER TABLE [dbo].[ICS_SSO_EVT_REP] DROP CONSTRAINT [FK_SSO_EVT_REP_PAYLOAD];

PRINT N'Dropping Foreign Key [dbo].[FK_SSO_MONTHLY_EVT_REP_PAYLOAD]...';

ALTER TABLE [dbo].[ICS_SSO_MONTHLY_EVT_REP] DROP CONSTRAINT [FK_SSO_MONTHLY_EVT_REP_PAYLOAD];

PRINT N'Dropping Foreign Key [dbo].[FK_SBS_COD_PLU_DES_GP_NT_OF_IN]...';

ALTER TABLE [dbo].[ICS_SUBSCTOR_CODE_PLUS_DESC] DROP CONSTRAINT [FK_SBS_COD_PLU_DES_GP_NT_OF_IN];

PRINT N'Dropping Foreign Key [dbo].[FK_SW_EVT_REP_PAYLOAD]...';

ALTER TABLE [dbo].[ICS_SW_EVT_REP] DROP CONSTRAINT [FK_SW_EVT_REP_PAYLOAD];

PRINT N'Dropping Foreign Key [dbo].[FK_SWMS_4_LARGE_PRMT_PAYLOAD]...';

ALTER TABLE [dbo].[ICS_SWMS_4_LARGE_PRMT] DROP CONSTRAINT [FK_SWMS_4_LARGE_PRMT_PAYLOAD];

PRINT N'Dropping Foreign Key [dbo].[FK_SWMS_4_PROG_REP_PAYLOAD]...';

ALTER TABLE [dbo].[ICS_SWMS_4_PROG_REP] DROP CONSTRAINT [FK_SWMS_4_PROG_REP_PAYLOAD];

PRINT N'Dropping Foreign Key [dbo].[FK_SWMS_4_SMALL_PRMT_PAYLOAD]...';

ALTER TABLE [dbo].[ICS_SWMS_4_SMALL_PRMT] DROP CONSTRAINT [FK_SWMS_4_SMALL_PRMT_PAYLOAD];

PRINT N'Dropping Table [dbo].[ICS_ABOUT_DB]...';

DROP TABLE [dbo].[ICS_ABOUT_DB];

PRINT N'Dropping Table [dbo].[ICS_BS_END_USE_DSPL_TYPE]...';

DROP TABLE [dbo].[ICS_BS_END_USE_DSPL_TYPE];

PRINT N'Dropping Table [dbo].[ICS_BS_MGMT_PRACTICES]...';

DROP TABLE [dbo].[ICS_BS_MGMT_PRACTICES];

PRINT N'Dropping Table [dbo].[ICS_BS_PROG_REP]...';

DROP TABLE [dbo].[ICS_BS_PROG_REP];

PRINT N'Dropping Table [dbo].[ICS_BS_TYPE]...';

DROP TABLE [dbo].[ICS_BS_TYPE];

PRINT N'Dropping Table [dbo].[ICS_CAFO_ANNUL_REP]...';

DROP TABLE [dbo].[ICS_CAFO_ANNUL_REP];

PRINT N'Dropping Table [dbo].[ICS_CSO_EVT_REP]...';

DROP TABLE [dbo].[ICS_CSO_EVT_REP];

PRINT N'Dropping Table [dbo].[ICS_CSO_PRMT]...';

DROP TABLE [dbo].[ICS_CSO_PRMT];

PRINT N'Dropping Table [dbo].[ICS_DMR_PROG_REP_LNK]...';

DROP TABLE [dbo].[ICS_DMR_PROG_REP_LNK];

PRINT N'Dropping Table [dbo].[ICS_GPCF_CNST_WAIVER]...';

DROP TABLE [dbo].[ICS_GPCF_CNST_WAIVER];

PRINT N'Dropping Table [dbo].[ICS_LNK_BS_REP]...';

DROP TABLE [dbo].[ICS_LNK_BS_REP];

PRINT N'Dropping Table [dbo].[ICS_LNK_CAFO_ANNUL_REP]...';

DROP TABLE [dbo].[ICS_LNK_CAFO_ANNUL_REP];

PRINT N'Dropping Table [dbo].[ICS_LNK_CSO_EVT_REP]...';

DROP TABLE [dbo].[ICS_LNK_CSO_EVT_REP];

PRINT N'Dropping Table [dbo].[ICS_LNK_FEDR_CMPL_MON]...';

DROP TABLE [dbo].[ICS_LNK_FEDR_CMPL_MON];

PRINT N'Dropping Table [dbo].[ICS_LNK_LOC_LMTS_REP]...';

DROP TABLE [dbo].[ICS_LNK_LOC_LMTS_REP];

PRINT N'Dropping Table [dbo].[ICS_LNK_PRETR_PERF_REP]...';

DROP TABLE [dbo].[ICS_LNK_PRETR_PERF_REP];

PRINT N'Dropping Table [dbo].[ICS_LNK_SSO_ANNUL_REP]...';

DROP TABLE [dbo].[ICS_LNK_SSO_ANNUL_REP];

PRINT N'Dropping Table [dbo].[ICS_LNK_SSO_EVT_REP]...';

DROP TABLE [dbo].[ICS_LNK_SSO_EVT_REP];

PRINT N'Dropping Table [dbo].[ICS_LNK_SSO_MONTHLY_EVT_REP]...';

DROP TABLE [dbo].[ICS_LNK_SSO_MONTHLY_EVT_REP];

PRINT N'Dropping Table [dbo].[ICS_LNK_ST_CMPL_MON]...';

DROP TABLE [dbo].[ICS_LNK_ST_CMPL_MON];

PRINT N'Dropping Table [dbo].[ICS_LNK_SW_EVT_REP]...';

DROP TABLE [dbo].[ICS_LNK_SW_EVT_REP];

PRINT N'Dropping Table [dbo].[ICS_LNK_SWMS_4_REP]...';

DROP TABLE [dbo].[ICS_LNK_SWMS_4_REP];

PRINT N'Dropping Table [dbo].[ICS_LOC_LMTS]...';

DROP TABLE [dbo].[ICS_LOC_LMTS];

PRINT N'Dropping Table [dbo].[ICS_LOC_LMTS_POLUT]...';

DROP TABLE [dbo].[ICS_LOC_LMTS_POLUT];

PRINT N'Dropping Table [dbo].[ICS_LOC_LMTS_PROG_REP]...';

DROP TABLE [dbo].[ICS_LOC_LMTS_PROG_REP];

PRINT N'Dropping Table [dbo].[ICS_MGMT_PRC_DEFCY_TYPE]...';

DROP TABLE [dbo].[ICS_MGMT_PRC_DEFCY_TYPE];

PRINT N'Dropping Table [dbo].[ICS_PRETR_PERF_SUMM]...';

DROP TABLE [dbo].[ICS_PRETR_PERF_SUMM];

PRINT N'Dropping Table [dbo].[ICS_REP_ANML_TYPE]...';

DROP TABLE [dbo].[ICS_REP_ANML_TYPE];

PRINT N'Dropping Table [dbo].[ICS_REP_OBLGTN_TYPE]...';

DROP TABLE [dbo].[ICS_REP_OBLGTN_TYPE];

PRINT N'Dropping Table [dbo].[ICS_RMVL_CRDTS]...';

DROP TABLE [dbo].[ICS_RMVL_CRDTS];

PRINT N'Dropping Table [dbo].[ICS_RMVL_CRDTS_POLUT]...';

DROP TABLE [dbo].[ICS_RMVL_CRDTS_POLUT];

PRINT N'Dropping Table [dbo].[ICS_SSO_ANNUL_REP]...';

DROP TABLE [dbo].[ICS_SSO_ANNUL_REP];

PRINT N'Dropping Table [dbo].[ICS_SSO_EVT_REP]...';

DROP TABLE [dbo].[ICS_SSO_EVT_REP];

PRINT N'Dropping Table [dbo].[ICS_SSO_MONTHLY_EVT_REP]...';

DROP TABLE [dbo].[ICS_SSO_MONTHLY_EVT_REP];

PRINT N'Dropping Table [dbo].[ICS_SUBSCTOR_CODE_PLUS_DESC]...';

DROP TABLE [dbo].[ICS_SUBSCTOR_CODE_PLUS_DESC];

PRINT N'Dropping Table [dbo].[ICS_SW_EVT_REP]...';

DROP TABLE [dbo].[ICS_SW_EVT_REP];

PRINT N'Dropping Table [dbo].[ICS_SWMS_4_LARGE_PRMT]...';

DROP TABLE [dbo].[ICS_SWMS_4_LARGE_PRMT];

PRINT N'Dropping Table [dbo].[ICS_SWMS_4_PROG_REP]...';

DROP TABLE [dbo].[ICS_SWMS_4_PROG_REP];

PRINT N'Dropping Table [dbo].[ICS_SWMS_4_SMALL_PRMT]...';

DROP TABLE [dbo].[ICS_SWMS_4_SMALL_PRMT];

PRINT N'Dropping Table [dbo].[ICS_TRTMNT_PRCSS_TYPE]...';

DROP TABLE [dbo].[ICS_TRTMNT_PRCSS_TYPE];

PRINT N'Starting rebuilding table [dbo].[ICS_ADDR]...';

BEGIN TRANSACTION;
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;
SET XACT_ABORT ON;
CREATE TABLE [dbo].[tmp_ms_xx_ICS_ADDR] (
    [ICS_ADDR_ID]                            VARCHAR (36)  NOT NULL,
    [ICS_FAC_ID]                             VARCHAR (36)  NULL,
    [ICS_BASIC_PRMT_ID]                      VARCHAR (36)  NULL,
    [ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] VARCHAR (36)  NULL,
    [ICS_CAFO_PRMT_ID]                       VARCHAR (36)  NULL,
    [ICS_GNRL_PRMT_ID]                       VARCHAR (36)  NULL,
    [ICS_PRMT_FEATR_ID]                      VARCHAR (36)  NULL,
    [ICS_SW_CNST_PRMT_ID]                    VARCHAR (36)  NULL,
    [ICS_SW_INDST_PRMT_ID]                   VARCHAR (36)  NULL,
    [ICS_UNPRMT_FAC_ID]                      VARCHAR (36)  NULL,
    [AFFIL_TYPE_TXT]                         VARCHAR (3)   NOT NULL,
    [ORG_FRML_NAME]                          VARCHAR (80)  NOT NULL,
    [ORG_DUNS_NUM]                           CHAR (9)      NULL,
    [MAILING_ADDR_TXT]                       VARCHAR (50)  NOT NULL,
    [SUPPL_ADDR_TXT]                         VARCHAR (50)  NULL,
    [MAILING_ADDR_CITY_NAME]                 VARCHAR (30)  NOT NULL,
    [MAILING_ADDR_ST_CODE]                   CHAR (2)      NOT NULL,
    [MAILING_ADDR_ZIP_CODE]                  VARCHAR (14)  NOT NULL,
    [COUNTY_NAME]                            VARCHAR (35)  NULL,
    [MAILING_ADDR_COUNTRY_CODE]              VARCHAR (3)   NULL,
    [DIVISION_NAME]                          VARCHAR (50)  NULL,
    [LOC_PROVINCE]                           VARCHAR (35)  NULL,
    [ELEC_ADDR_TXT]                          VARCHAR (100) NULL,
    [START_DATE_OF_ADDR_ASSC]                DATETIME      NULL,
    [END_DATE_OF_ADDR_ASSC]                  DATETIME      NULL,
    [DATA_HASH]                              VARCHAR (100) NULL,
    CONSTRAINT [tmp_ms_xx_constraint_PK_ADDR1] PRIMARY KEY CLUSTERED ([ICS_ADDR_ID] ASC)
);
IF EXISTS (SELECT TOP 1 1 
           FROM   [dbo].[ICS_ADDR])
    BEGIN
        INSERT INTO [dbo].[tmp_ms_xx_ICS_ADDR] ([ICS_ADDR_ID], [ICS_FAC_ID], [ICS_BASIC_PRMT_ID], [ICS_PRMT_FEATR_ID], [ICS_CAFO_PRMT_ID], [ICS_GNRL_PRMT_ID], [ICS_SW_CNST_PRMT_ID], [ICS_SW_INDST_PRMT_ID], [ICS_UNPRMT_FAC_ID], [AFFIL_TYPE_TXT], [ORG_FRML_NAME], [ORG_DUNS_NUM], [MAILING_ADDR_TXT], [SUPPL_ADDR_TXT], [MAILING_ADDR_CITY_NAME], [MAILING_ADDR_ST_CODE], [MAILING_ADDR_ZIP_CODE], [COUNTY_NAME], [MAILING_ADDR_COUNTRY_CODE], [DIVISION_NAME], [LOC_PROVINCE], [ELEC_ADDR_TXT], [START_DATE_OF_ADDR_ASSC], [END_DATE_OF_ADDR_ASSC], [DATA_HASH])
        SELECT   [ICS_ADDR_ID],
                 [ICS_FAC_ID],
                 [ICS_BASIC_PRMT_ID],
                 [ICS_PRMT_FEATR_ID],
                 [ICS_CAFO_PRMT_ID],
                 [ICS_GNRL_PRMT_ID],
                 [ICS_SW_CNST_PRMT_ID],
                 [ICS_SW_INDST_PRMT_ID],
                 [ICS_UNPRMT_FAC_ID],
                 [AFFIL_TYPE_TXT],
                 [ORG_FRML_NAME],
                 [ORG_DUNS_NUM],
                 [MAILING_ADDR_TXT],
                 [SUPPL_ADDR_TXT],
                 [MAILING_ADDR_CITY_NAME],
                 [MAILING_ADDR_ST_CODE],
                 [MAILING_ADDR_ZIP_CODE],
                 [COUNTY_NAME],
                 [MAILING_ADDR_COUNTRY_CODE],
                 [DIVISION_NAME],
                 [LOC_PROVINCE],
                 [ELEC_ADDR_TXT],
                 [START_DATE_OF_ADDR_ASSC],
                 [END_DATE_OF_ADDR_ASSC],
                 [DATA_HASH]
        FROM     [dbo].[ICS_ADDR]
        ORDER BY [ICS_ADDR_ID] ASC;
    END
DROP TABLE [dbo].[ICS_ADDR];
EXECUTE sp_rename N'[dbo].[tmp_ms_xx_ICS_ADDR]', N'ICS_ADDR';
EXECUTE sp_rename N'[dbo].[tmp_ms_xx_constraint_PK_ADDR1]', N'PK_ADDR', N'OBJECT';
COMMIT TRANSACTION;
SET TRANSACTION ISOLATION LEVEL READ COMMITTED;

PRINT N'Creating Index [dbo].[ICS_ADDR].[IX_ADD_IC_BS_OF_SI_HN_AP_PR_ID]...';

CREATE NONCLUSTERED INDEX [IX_ADD_IC_BS_OF_SI_HN_AP_PR_ID]
    ON [dbo].[ICS_ADDR]([ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] ASC);

PRINT N'Creating Index [dbo].[ICS_ADDR].[IX_ADDR_ICS_BASIC_PRMT_ID]...';

CREATE NONCLUSTERED INDEX [IX_ADDR_ICS_BASIC_PRMT_ID]
    ON [dbo].[ICS_ADDR]([ICS_BASIC_PRMT_ID] ASC);

PRINT N'Creating Index [dbo].[ICS_ADDR].[IX_ADDR_ICS_CAFO_PRMT_ID]...';

CREATE NONCLUSTERED INDEX [IX_ADDR_ICS_CAFO_PRMT_ID]
    ON [dbo].[ICS_ADDR]([ICS_CAFO_PRMT_ID] ASC);

PRINT N'Creating Index [dbo].[ICS_ADDR].[IX_ADDR_ICS_FAC_ID]...';

CREATE NONCLUSTERED INDEX [IX_ADDR_ICS_FAC_ID]
    ON [dbo].[ICS_ADDR]([ICS_FAC_ID] ASC);

PRINT N'Creating Index [dbo].[ICS_ADDR].[IX_ADDR_ICS_GNRL_PRMT_ID]...';

CREATE NONCLUSTERED INDEX [IX_ADDR_ICS_GNRL_PRMT_ID]
    ON [dbo].[ICS_ADDR]([ICS_GNRL_PRMT_ID] ASC);

PRINT N'Creating Index [dbo].[ICS_ADDR].[IX_ADDR_ICS_PRMT_FEATR_ID]...';

CREATE NONCLUSTERED INDEX [IX_ADDR_ICS_PRMT_FEATR_ID]
    ON [dbo].[ICS_ADDR]([ICS_PRMT_FEATR_ID] ASC);

PRINT N'Creating Index [dbo].[ICS_ADDR].[IX_ADDR_ICS_SW_CNST_PRMT_ID]...';

CREATE NONCLUSTERED INDEX [IX_ADDR_ICS_SW_CNST_PRMT_ID]
    ON [dbo].[ICS_ADDR]([ICS_SW_CNST_PRMT_ID] ASC);

PRINT N'Creating Index [dbo].[ICS_ADDR].[IX_ADDR_ICS_SW_INDST_PRMT_ID]...';

CREATE NONCLUSTERED INDEX [IX_ADDR_ICS_SW_INDST_PRMT_ID]
    ON [dbo].[ICS_ADDR]([ICS_SW_INDST_PRMT_ID] ASC);

PRINT N'Creating Index [dbo].[ICS_ADDR].[IX_ADDR_ICS_UNPRMT_FAC_ID]...';

CREATE NONCLUSTERED INDEX [IX_ADDR_ICS_UNPRMT_FAC_ID]
    ON [dbo].[ICS_ADDR]([ICS_UNPRMT_FAC_ID] ASC);

PRINT N'Starting rebuilding table [dbo].[ICS_ANML_TYPE]...';

BEGIN TRANSACTION;
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;
SET XACT_ABORT ON;
CREATE TABLE [dbo].[tmp_ms_xx_ICS_ANML_TYPE] (
    [ICS_ANML_TYPE_ID]               VARCHAR (36)  NOT NULL,
    [ICS_CAFO_ANNUL_PROG_REP_ID]     VARCHAR (36)  NULL,
    [ICS_CAFO_PRMT_ID]               VARCHAR (36)  NULL,
    [ICS_CAFO_INSP_ID]               VARCHAR (36)  NULL,
    [ANML_TYPE_CODE]                 VARCHAR (3)   NOT NULL,
    [OTHR_ANML_TYPE_NAME]            VARCHAR (50)  NULL,
    [TTL_NUM_EACH_LVSTCK]            INT           NULL,
    [OPEN_CONFINEMNT_CNT]            INT           NULL,
    [HOUSD_UNDR_ROOF_CONFINEMNT_CNT] INT           NULL,
    [LIQUID_MNUR_HANDLING_SYSTM]     CHAR (1)      NULL,
    [DATA_HASH]                      VARCHAR (100) NULL,
    CONSTRAINT [tmp_ms_xx_constraint_PK_ANML_TYPE1] PRIMARY KEY CLUSTERED ([ICS_ANML_TYPE_ID] ASC)
);
IF EXISTS (SELECT TOP 1 1 
           FROM   [dbo].[ICS_ANML_TYPE])
    BEGIN
        INSERT INTO [dbo].[tmp_ms_xx_ICS_ANML_TYPE] ([ICS_ANML_TYPE_ID], [ICS_CAFO_PRMT_ID], [ICS_CAFO_INSP_ID], [ANML_TYPE_CODE], [OTHR_ANML_TYPE_NAME], [TTL_NUM_EACH_LVSTCK], [OPEN_CONFINEMNT_CNT], [HOUSD_UNDR_ROOF_CONFINEMNT_CNT], [DATA_HASH])
        SELECT   [ICS_ANML_TYPE_ID],
                 [ICS_CAFO_PRMT_ID],
                 [ICS_CAFO_INSP_ID],
                 [ANML_TYPE_CODE],
                 [OTHR_ANML_TYPE_NAME],
                 [TTL_NUM_EACH_LVSTCK],
                 [OPEN_CONFINEMNT_CNT],
                 [HOUSD_UNDR_ROOF_CONFINEMNT_CNT],
                 [DATA_HASH]
        FROM     [dbo].[ICS_ANML_TYPE]
        ORDER BY [ICS_ANML_TYPE_ID] ASC;
    END
DROP TABLE [dbo].[ICS_ANML_TYPE];
EXECUTE sp_rename N'[dbo].[tmp_ms_xx_ICS_ANML_TYPE]', N'ICS_ANML_TYPE';
EXECUTE sp_rename N'[dbo].[tmp_ms_xx_constraint_PK_ANML_TYPE1]', N'PK_ANML_TYPE', N'OBJECT';
COMMIT TRANSACTION;
SET TRANSACTION ISOLATION LEVEL READ COMMITTED;

PRINT N'Creating Index [dbo].[ICS_ANML_TYPE].[IX_ANM_TYP_ICS_CAF_AN_PR_RE_ID]...';

CREATE NONCLUSTERED INDEX [IX_ANM_TYP_ICS_CAF_AN_PR_RE_ID]
    ON [dbo].[ICS_ANML_TYPE]([ICS_CAFO_ANNUL_PROG_REP_ID] ASC);

PRINT N'Creating Index [dbo].[ICS_ANML_TYPE].[IX_ANML_TYPE_ICS_CAFO_INSP_ID]...';

CREATE NONCLUSTERED INDEX [IX_ANML_TYPE_ICS_CAFO_INSP_ID]
    ON [dbo].[ICS_ANML_TYPE]([ICS_CAFO_INSP_ID] ASC);

PRINT N'Creating Index [dbo].[ICS_ANML_TYPE].[IX_ANML_TYPE_ICS_CAFO_PRMT_ID]...';

CREATE NONCLUSTERED INDEX [IX_ANML_TYPE_ICS_CAFO_PRMT_ID]
    ON [dbo].[ICS_ANML_TYPE]([ICS_CAFO_PRMT_ID] ASC);

PRINT N'Starting rebuilding table [dbo].[ICS_BASIC_PRMT]...';

BEGIN TRANSACTION;
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;
SET XACT_ABORT ON;
CREATE TABLE [dbo].[tmp_ms_xx_ICS_BASIC_PRMT] (
    [ICS_BASIC_PRMT_ID]              VARCHAR (36)    NOT NULL,
    [ICS_PAYLOAD_ID]                 VARCHAR (36)    NOT NULL,
    [SRC_SYSTM_IDENT]                VARCHAR (50)    NULL,
    [TRANSACTION_TYPE]               CHAR (1)        NULL,
    [TRANSACTION_TIMESTAMP]          DATETIME        NULL,
    [PRMT_IDENT]                     CHAR (9)        NOT NULL,
    [PRMT_TYPE_CODE]                 VARCHAR (3)     NULL,
    [AGNCY_TYPE_CODE]                VARCHAR (3)     NULL,
    [PRMT_STAT_CODE]                 VARCHAR (3)     NULL,
    [PRMT_ISSUE_DATE]                DATETIME        NULL,
    [PRMT_EFFECTIVE_DATE]            DATETIME        NULL,
    [PRMT_EXPR_DATE]                 DATETIME        NULL,
    [REISSU_PRIO_PRMT_IND]           CHAR (1)        NULL,
    [BACKLOG_REASON_TXT]             VARCHAR (2000)  NULL,
    [PRMT_ISSUING_ORG_TYPE_NAME]     VARCHAR (100)   NULL,
    [PRMT_APPEALED_IND]              CHAR (1)        NULL,
    [PRMT_USR_DFND_DAT_ELM_1_TXT]    VARCHAR (30)    NULL,
    [PRMT_USR_DFND_DAT_ELM_2_TXT]    VARCHAR (30)    NULL,
    [PRMT_USR_DFND_DAT_ELM_3_TXT]    VARCHAR (30)    NULL,
    [PRMT_USR_DFND_DAT_ELM_4_TXT]    VARCHAR (30)    NULL,
    [PRMT_USR_DFND_DAT_ELM_5_TXT]    VARCHAR (30)    NULL,
    [PRMT_CMNTS_TXT]                 VARCHAR (4000)  NULL,
    [MAJOR_MINOR_RATING_CODE]        INT             NULL,
    [TTL_APPL_DSGN_FLOW_NUM]         DECIMAL (15, 7) NULL,
    [TTL_APPL_AVER_FLOW_NUM]         DECIMAL (15, 7) NULL,
    [APPL_RCVD_DATE]                 DATETIME        NULL,
    [PRMT_APPL_CMPL_DATE]            DATETIME        NULL,
    [NEW_SRC_IND]                    CHAR (1)        NULL,
    [PRMT_ST_WTR_BODY_CODE]          VARCHAR (12)    NULL,
    [PRMT_ST_WTR_BODY_NAME]          VARCHAR (50)    NULL,
    [FEDR_GRANT_IND]                 CHAR (1)        NULL,
    [DMR_COGNZNT_OFCL]               VARCHAR (30)    NULL,
    [DMR_COGNZNT_OFCL_TELEPH_NUM]    VARCHAR (15)    NULL,
    [SIG_IU_IND]                     CHAR (1)        NULL,
    [RCVG_PRMT_IDENT]                CHAR (9)        NULL,
    [INDST_USR_TYPE_CODE]            VARCHAR (3)     NULL,
    [ELEC_REP_WAIVER_TYPE_CODE]      VARCHAR (3)     NULL,
    [ELEC_REP_WAIVER_EFFECTIVE_DATE] DATETIME        NULL,
    [ELEC_REP_WAIVER_EXPR_DATE]      DATETIME        NULL,
    [MAJOR_MINOR_STAT_IND]           CHAR (1)        NULL,
    [MAJOR_MINOR_STAT_START_DATE]    DATETIME        NULL,
    [DMR_NON_RCPT_STAT_IND]          CHAR (1)        NULL,
    [DMR_NON_RCPT_STAT_START_DATE]   DATETIME        NULL,
    [KEY_HASH]                       VARCHAR (100)   NULL,
    [DATA_HASH]                      VARCHAR (100)   NULL,
    CONSTRAINT [tmp_ms_xx_constraint_PK_BASIC_PRMT1] PRIMARY KEY CLUSTERED ([ICS_BASIC_PRMT_ID] ASC)
);
IF EXISTS (SELECT TOP 1 1 
           FROM   [dbo].[ICS_BASIC_PRMT])
    BEGIN
        INSERT INTO [dbo].[tmp_ms_xx_ICS_BASIC_PRMT] ([ICS_BASIC_PRMT_ID], [ICS_PAYLOAD_ID], [SRC_SYSTM_IDENT], [TRANSACTION_TYPE], [TRANSACTION_TIMESTAMP], [PRMT_IDENT], [PRMT_TYPE_CODE], [AGNCY_TYPE_CODE], [PRMT_STAT_CODE], [PRMT_ISSUE_DATE], [PRMT_EFFECTIVE_DATE], [PRMT_EXPR_DATE], [REISSU_PRIO_PRMT_IND], [BACKLOG_REASON_TXT], [PRMT_ISSUING_ORG_TYPE_NAME], [PRMT_APPEALED_IND], [PRMT_USR_DFND_DAT_ELM_1_TXT], [PRMT_USR_DFND_DAT_ELM_2_TXT], [PRMT_USR_DFND_DAT_ELM_3_TXT], [PRMT_USR_DFND_DAT_ELM_4_TXT], [PRMT_USR_DFND_DAT_ELM_5_TXT], [PRMT_CMNTS_TXT], [MAJOR_MINOR_RATING_CODE], [MAJOR_MINOR_STAT_IND], [MAJOR_MINOR_STAT_START_DATE], [TTL_APPL_DSGN_FLOW_NUM], [TTL_APPL_AVER_FLOW_NUM], [APPL_RCVD_DATE], [PRMT_APPL_CMPL_DATE], [NEW_SRC_IND], [DMR_NON_RCPT_STAT_IND], [DMR_NON_RCPT_STAT_START_DATE], [PRMT_ST_WTR_BODY_CODE], [PRMT_ST_WTR_BODY_NAME], [FEDR_GRANT_IND], [DMR_COGNZNT_OFCL], [DMR_COGNZNT_OFCL_TELEPH_NUM], [SIG_IU_IND], [RCVG_PRMT_IDENT], [ELEC_REP_WAIVER_TYPE_CODE], [ELEC_REP_WAIVER_EFFECTIVE_DATE], [ELEC_REP_WAIVER_EXPR_DATE], [KEY_HASH], [DATA_HASH])
        SELECT   [ICS_BASIC_PRMT_ID],
                 [ICS_PAYLOAD_ID],
                 [SRC_SYSTM_IDENT],
                 [TRANSACTION_TYPE],
                 [TRANSACTION_TIMESTAMP],
                 [PRMT_IDENT],
                 [PRMT_TYPE_CODE],
                 [AGNCY_TYPE_CODE],
                 [PRMT_STAT_CODE],
                 [PRMT_ISSUE_DATE],
                 [PRMT_EFFECTIVE_DATE],
                 [PRMT_EXPR_DATE],
                 [REISSU_PRIO_PRMT_IND],
                 [BACKLOG_REASON_TXT],
                 [PRMT_ISSUING_ORG_TYPE_NAME],
                 [PRMT_APPEALED_IND],
                 [PRMT_USR_DFND_DAT_ELM_1_TXT],
                 [PRMT_USR_DFND_DAT_ELM_2_TXT],
                 [PRMT_USR_DFND_DAT_ELM_3_TXT],
                 [PRMT_USR_DFND_DAT_ELM_4_TXT],
                 [PRMT_USR_DFND_DAT_ELM_5_TXT],
                 [PRMT_CMNTS_TXT],
                 [MAJOR_MINOR_RATING_CODE],
                 [MAJOR_MINOR_STAT_IND],
                 [MAJOR_MINOR_STAT_START_DATE],
                 [TTL_APPL_DSGN_FLOW_NUM],
                 [TTL_APPL_AVER_FLOW_NUM],
                 [APPL_RCVD_DATE],
                 [PRMT_APPL_CMPL_DATE],
                 [NEW_SRC_IND],
                 [DMR_NON_RCPT_STAT_IND],
                 [DMR_NON_RCPT_STAT_START_DATE],
                 [PRMT_ST_WTR_BODY_CODE],
                 [PRMT_ST_WTR_BODY_NAME],
                 [FEDR_GRANT_IND],
                 [DMR_COGNZNT_OFCL],
                 [DMR_COGNZNT_OFCL_TELEPH_NUM],
                 [SIG_IU_IND],
                 [RCVG_PRMT_IDENT],
                 [ELEC_REP_WAIVER_TYPE_CODE],
                 [ELEC_REP_WAIVER_EFFECTIVE_DATE],
                 [ELEC_REP_WAIVER_EXPR_DATE],
                 [KEY_HASH],
                 [DATA_HASH]
        FROM     [dbo].[ICS_BASIC_PRMT]
        ORDER BY [ICS_BASIC_PRMT_ID] ASC;
    END
DROP TABLE [dbo].[ICS_BASIC_PRMT];
EXECUTE sp_rename N'[dbo].[tmp_ms_xx_ICS_BASIC_PRMT]', N'ICS_BASIC_PRMT';
EXECUTE sp_rename N'[dbo].[tmp_ms_xx_constraint_PK_BASIC_PRMT1]', N'PK_BASIC_PRMT', N'OBJECT';
COMMIT TRANSACTION;
SET TRANSACTION ISOLATION LEVEL READ COMMITTED;

PRINT N'Creating Index [dbo].[ICS_BASIC_PRMT].[IX_BASIC_PRMT_ICS_PAYLOAD_ID]...';

CREATE NONCLUSTERED INDEX [IX_BASIC_PRMT_ICS_PAYLOAD_ID]
    ON [dbo].[ICS_BASIC_PRMT]([ICS_PAYLOAD_ID] ASC);

PRINT N'Creating Index [dbo].[ICS_BASIC_PRMT].[IX_BASIC_PRMT_PRMT_IDENT]...';

CREATE UNIQUE NONCLUSTERED INDEX [IX_BASIC_PRMT_PRMT_IDENT]
    ON [dbo].[ICS_BASIC_PRMT]([PRMT_IDENT] ASC);

PRINT N'Starting rebuilding table [dbo].[ICS_BS_ANNUL_PROG_REP]...';

BEGIN TRANSACTION;
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;
SET XACT_ABORT ON;
CREATE TABLE [dbo].[tmp_ms_xx_ICS_BS_ANNUL_PROG_REP] (
    [ICS_BS_ANNUL_PROG_REP_ID]        VARCHAR (36)    NOT NULL,
    [ICS_PAYLOAD_ID]                  VARCHAR (36)    NOT NULL,
    [SRC_SYSTM_IDENT]                 VARCHAR (50)    NULL,
    [TRANSACTION_TYPE]                CHAR (1)        NULL,
    [TRANSACTION_TIMESTAMP]           DATETIME        NULL,
    [PRMT_IDENT]                      CHAR (9)        NULL,
    [PROG_REP_FORM_SET_ID]            VARCHAR (50)    NOT NULL,
    [PROG_REP_FORM_ID]                INT             NULL,
    [PROG_REP_RCVD_DATE]              DATETIME        NULL,
    [PROG_REP_START_DATE]             DATETIME        NULL,
    [PROG_REP_END_DATE]               DATETIME        NULL,
    [ELEC_SUBM_TYPE_CODE]             VARCHAR (3)     NULL,
    [PROG_REP_NPDES_DAT_GRP_NUM_CODE] VARCHAR (3)     NULL,
    [BS_FAC_TYPE_OTHR_TXT]            VARCHAR (250)   NULL,
    [BS_FAC_TTL_VOL_AMT]              DECIMAL (15, 7) NULL,
    [BS_FAC_TRTMNT_OTHR_TXT]          VARCHAR (100)   NULL,
    [BS_ANNUL_PROG_REP_CMNT_TXT]      VARCHAR (4000)  NULL,
    [KEY_HASH]                        VARCHAR (100)   NULL,
    [DATA_HASH]                       VARCHAR (100)   NULL,
    CONSTRAINT [tmp_ms_xx_constraint_PK_BS_ANNUL_PROG_REP1] PRIMARY KEY CLUSTERED ([ICS_BS_ANNUL_PROG_REP_ID] ASC)
);
IF EXISTS (SELECT TOP 1 1 
           FROM   [dbo].[ICS_BS_ANNUL_PROG_REP])
    BEGIN
        INSERT INTO [dbo].[tmp_ms_xx_ICS_BS_ANNUL_PROG_REP] ([ICS_BS_ANNUL_PROG_REP_ID], [ICS_PAYLOAD_ID], [SRC_SYSTM_IDENT], [TRANSACTION_TYPE], [TRANSACTION_TIMESTAMP], [PRMT_IDENT], [ELEC_SUBM_TYPE_CODE], [KEY_HASH], [DATA_HASH])
        SELECT   [ICS_BS_ANNUL_PROG_REP_ID],
                 [ICS_PAYLOAD_ID],
                 [SRC_SYSTM_IDENT],
                 [TRANSACTION_TYPE],
                 [TRANSACTION_TIMESTAMP],
                 [PRMT_IDENT],
                 [ELEC_SUBM_TYPE_CODE],
                 [KEY_HASH],
                 [DATA_HASH]
        FROM     [dbo].[ICS_BS_ANNUL_PROG_REP]
        ORDER BY [ICS_BS_ANNUL_PROG_REP_ID] ASC;
    END
DROP TABLE [dbo].[ICS_BS_ANNUL_PROG_REP];
EXECUTE sp_rename N'[dbo].[tmp_ms_xx_ICS_BS_ANNUL_PROG_REP]', N'ICS_BS_ANNUL_PROG_REP';
EXECUTE sp_rename N'[dbo].[tmp_ms_xx_constraint_PK_BS_ANNUL_PROG_REP1]', N'PK_BS_ANNUL_PROG_REP', N'OBJECT';
COMMIT TRANSACTION;
SET TRANSACTION ISOLATION LEVEL READ COMMITTED;

PRINT N'Creating Index [dbo].[ICS_BS_ANNUL_PROG_REP].[IX_BS_ANNL_PROG_REP_ICS_PYL_ID]...';

CREATE NONCLUSTERED INDEX [IX_BS_ANNL_PROG_REP_ICS_PYL_ID]
    ON [dbo].[ICS_BS_ANNUL_PROG_REP]([ICS_PAYLOAD_ID] ASC);

PRINT N'Starting rebuilding table [dbo].[ICS_BS_PRMT]...';

BEGIN TRANSACTION;
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;
SET XACT_ABORT ON;
CREATE TABLE [dbo].[tmp_ms_xx_ICS_BS_PRMT] (
    [ICS_BS_PRMT_ID]         VARCHAR (36)    NOT NULL,
    [ICS_PAYLOAD_ID]         VARCHAR (36)    NOT NULL,
    [SRC_SYSTM_IDENT]        VARCHAR (50)    NULL,
    [TRANSACTION_TYPE]       CHAR (1)        NULL,
    [TRANSACTION_TIMESTAMP]  DATETIME        NULL,
    [PRMT_IDENT]             CHAR (9)        NOT NULL,
    [BS_FAC_TYPE_OTHR_TXT]   VARCHAR (250)   NULL,
    [BS_FAC_TTL_VOL_AMT]     DECIMAL (15, 7) NULL,
    [BS_FAC_TRTMNT_OTHR_TXT] VARCHAR (100)   NULL,
    [KEY_HASH]               VARCHAR (100)   NULL,
    [DATA_HASH]              VARCHAR (100)   NULL,
    CONSTRAINT [tmp_ms_xx_constraint_PK_BS_PRMT1] PRIMARY KEY CLUSTERED ([ICS_BS_PRMT_ID] ASC)
);
IF EXISTS (SELECT TOP 1 1 
           FROM   [dbo].[ICS_BS_PRMT])
    BEGIN
        INSERT INTO [dbo].[tmp_ms_xx_ICS_BS_PRMT] ([ICS_BS_PRMT_ID], [ICS_PAYLOAD_ID], [SRC_SYSTM_IDENT], [TRANSACTION_TYPE], [TRANSACTION_TIMESTAMP], [PRMT_IDENT], [KEY_HASH], [DATA_HASH])
        SELECT   [ICS_BS_PRMT_ID],
                 [ICS_PAYLOAD_ID],
                 [SRC_SYSTM_IDENT],
                 [TRANSACTION_TYPE],
                 [TRANSACTION_TIMESTAMP],
                 [PRMT_IDENT],
                 [KEY_HASH],
                 [DATA_HASH]
        FROM     [dbo].[ICS_BS_PRMT]
        ORDER BY [ICS_BS_PRMT_ID] ASC;
    END
DROP TABLE [dbo].[ICS_BS_PRMT];
EXECUTE sp_rename N'[dbo].[tmp_ms_xx_ICS_BS_PRMT]', N'ICS_BS_PRMT';
EXECUTE sp_rename N'[dbo].[tmp_ms_xx_constraint_PK_BS_PRMT1]', N'PK_BS_PRMT', N'OBJECT';
COMMIT TRANSACTION;
SET TRANSACTION ISOLATION LEVEL READ COMMITTED;

PRINT N'Creating Index [dbo].[ICS_BS_PRMT].[IX_BS_PRMT_ICS_PAYLOAD_ID]...';

CREATE NONCLUSTERED INDEX [IX_BS_PRMT_ICS_PAYLOAD_ID]
    ON [dbo].[ICS_BS_PRMT]([ICS_PAYLOAD_ID] ASC);

PRINT N'Creating Index [dbo].[ICS_BS_PRMT].[IX_BS_PRMT_PRMT_IDENT]...';

CREATE UNIQUE NONCLUSTERED INDEX [IX_BS_PRMT_PRMT_IDENT]
    ON [dbo].[ICS_BS_PRMT]([PRMT_IDENT] ASC);

PRINT N'Starting rebuilding table [dbo].[ICS_CAFO_INSP]...';

BEGIN TRANSACTION;
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;
SET XACT_ABORT ON;
CREATE TABLE [dbo].[tmp_ms_xx_ICS_CAFO_INSP] (
    [ICS_CAFO_INSP_ID]                  VARCHAR (36)  NOT NULL,
    [ICS_CMPL_MON_ID]                   VARCHAR (36)  NOT NULL,
    [CAFO_CLASS_CODE]                   VARCHAR (3)   NULL,
    [IS_ANML_FAC_TYPE_CAFO_IND]         CHAR (1)      NULL,
    [CAFO_DESGN_DATE]                   DATETIME      NULL,
    [CAFO_DESGN_REASON_TXT]             VARCHAR (500) NULL,
    [DSCH_DRNG_YEAR_PROD_AREA_IND]      VARCHAR (3)   NULL,
    [DSCH_DRNG_YEAR_LAND_APPL_AREA_IND] VARCHAR (3)   NULL,
    [CAFO_DSCH_DRNG_YEAR_TXT]           VARCHAR (500) NULL,
    [NUM_ACRES_CONTRB_DRAIN]            INT           NULL,
    [APPL_MEAS_AVAIL_LAND_NUM]          INT           NULL,
    [SOLID_MNUR_LTTR_GNRTD_AMT]         INT           NULL,
    [LIQUID_MNUR_WW_GNRTD_AMT]          INT           NULL,
    [SOLID_MNUR_LTTR_TRANS_AMT]         INT           NULL,
    [LIQUID_MNUR_WW_TRANS_AMT]          INT           NULL,
    [NMP_DVLPD_CERT_PLNR_APRVD_IND]     CHAR (1)      NULL,
    [NMP_DVLPD_DATE]                    DATETIME      NULL,
    [NMP_LAST_UPDATED_DATE]             DATETIME      NULL,
    [ENVR_MGMT_SYSTM_IND]               CHAR (1)      NULL,
    [EMS_DVLPD_DATE]                    DATETIME      NULL,
    [EMS_LAST_UPDATED_DATE]             DATETIME      NULL,
    [LVSTCK_MAX_CPCTY_NUM]              INT           NULL,
    [LVSTCK_CPCTY_DTRMN_BS_UPON_NUM]    INT           NULL,
    [AUTH_LVSTCK_CPCTY_NUM]             INT           NULL,
    [DATA_HASH]                         VARCHAR (100) NULL,
    CONSTRAINT [tmp_ms_xx_constraint_PK_CAFO_INSP1] PRIMARY KEY CLUSTERED ([ICS_CAFO_INSP_ID] ASC)
);
IF EXISTS (SELECT TOP 1 1 
           FROM   [dbo].[ICS_CAFO_INSP])
    BEGIN
        INSERT INTO [dbo].[tmp_ms_xx_ICS_CAFO_INSP] ([ICS_CAFO_INSP_ID], [ICS_CMPL_MON_ID], [CAFO_CLASS_CODE], [IS_ANML_FAC_TYPE_CAFO_IND], [CAFO_DESGN_DATE], [CAFO_DESGN_REASON_TXT], [DSCH_DRNG_YEAR_PROD_AREA_IND], [NUM_ACRES_CONTRB_DRAIN], [APPL_MEAS_AVAIL_LAND_NUM], [SOLID_MNUR_LTTR_GNRTD_AMT], [LIQUID_MNUR_WW_GNRTD_AMT], [SOLID_MNUR_LTTR_TRANS_AMT], [LIQUID_MNUR_WW_TRANS_AMT], [NMP_DVLPD_CERT_PLNR_APRVD_IND], [NMP_DVLPD_DATE], [NMP_LAST_UPDATED_DATE], [ENVR_MGMT_SYSTM_IND], [EMS_DVLPD_DATE], [EMS_LAST_UPDATED_DATE], [LVSTCK_MAX_CPCTY_NUM], [LVSTCK_CPCTY_DTRMN_BS_UPON_NUM], [AUTH_LVSTCK_CPCTY_NUM], [DATA_HASH])
        SELECT   [ICS_CAFO_INSP_ID],
                 [ICS_CMPL_MON_ID],
                 [CAFO_CLASS_CODE],
                 [IS_ANML_FAC_TYPE_CAFO_IND],
                 [CAFO_DESGN_DATE],
                 [CAFO_DESGN_REASON_TXT],
                 [DSCH_DRNG_YEAR_PROD_AREA_IND],
                 [NUM_ACRES_CONTRB_DRAIN],
                 [APPL_MEAS_AVAIL_LAND_NUM],
                 [SOLID_MNUR_LTTR_GNRTD_AMT],
                 [LIQUID_MNUR_WW_GNRTD_AMT],
                 [SOLID_MNUR_LTTR_TRANS_AMT],
                 [LIQUID_MNUR_WW_TRANS_AMT],
                 [NMP_DVLPD_CERT_PLNR_APRVD_IND],
                 [NMP_DVLPD_DATE],
                 [NMP_LAST_UPDATED_DATE],
                 [ENVR_MGMT_SYSTM_IND],
                 [EMS_DVLPD_DATE],
                 [EMS_LAST_UPDATED_DATE],
                 [LVSTCK_MAX_CPCTY_NUM],
                 [LVSTCK_CPCTY_DTRMN_BS_UPON_NUM],
                 [AUTH_LVSTCK_CPCTY_NUM],
                 [DATA_HASH]
        FROM     [dbo].[ICS_CAFO_INSP]
        ORDER BY [ICS_CAFO_INSP_ID] ASC;
    END
DROP TABLE [dbo].[ICS_CAFO_INSP];
EXECUTE sp_rename N'[dbo].[tmp_ms_xx_ICS_CAFO_INSP]', N'ICS_CAFO_INSP';
EXECUTE sp_rename N'[dbo].[tmp_ms_xx_constraint_PK_CAFO_INSP1]', N'PK_CAFO_INSP', N'OBJECT';
COMMIT TRANSACTION;
SET TRANSACTION ISOLATION LEVEL READ COMMITTED;

PRINT N'Creating Index [dbo].[ICS_CAFO_INSP].[IX_CAFO_INSP_ICS_CMPL_MON_ID]...';

CREATE NONCLUSTERED INDEX [IX_CAFO_INSP_ICS_CMPL_MON_ID]
    ON [dbo].[ICS_CAFO_INSP]([ICS_CMPL_MON_ID] ASC);

PRINT N'Altering Table [dbo].[ICS_CMPL_MON]...';

ALTER TABLE [dbo].[ICS_CMPL_MON] DROP COLUMN [INSP_CMNT_TXT];

PRINT N'Altering Table [dbo].[ICS_CMPL_SCHD_EVT]...';

ALTER TABLE [dbo].[ICS_CMPL_SCHD_EVT] ALTER COLUMN [CMPL_SCHD_PNLTY_AMT] DECIMAL (14, 2) NULL;

PRINT N'Starting rebuilding table [dbo].[ICS_CNST_SITE]...';

BEGIN TRANSACTION;
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;
SET XACT_ABORT ON;
CREATE TABLE [dbo].[tmp_ms_xx_ICS_CNST_SITE] (
    [ICS_CNST_SITE_ID]      VARCHAR (36)  NOT NULL,
    [ICS_CNST_SITE_LIST_ID] VARCHAR (36)  NOT NULL,
    [CNST_SITE_CODE]        VARCHAR (3)   NOT NULL,
    [DATA_HASH]             VARCHAR (100) NULL,
    CONSTRAINT [tmp_ms_xx_constraint_PK_CNST_SITE1] PRIMARY KEY CLUSTERED ([ICS_CNST_SITE_ID] ASC)
);
IF EXISTS (SELECT TOP 1 1 
           FROM   [dbo].[ICS_CNST_SITE])
    BEGIN
        INSERT INTO [dbo].[tmp_ms_xx_ICS_CNST_SITE] ([ICS_CNST_SITE_ID], [CNST_SITE_CODE], [DATA_HASH])
        SELECT   [ICS_CNST_SITE_ID],
                 [CNST_SITE_CODE],
                 [DATA_HASH]
        FROM     [dbo].[ICS_CNST_SITE]
        ORDER BY [ICS_CNST_SITE_ID] ASC;
    END
DROP TABLE [dbo].[ICS_CNST_SITE];
EXECUTE sp_rename N'[dbo].[tmp_ms_xx_ICS_CNST_SITE]', N'ICS_CNST_SITE';
EXECUTE sp_rename N'[dbo].[tmp_ms_xx_constraint_PK_CNST_SITE1]', N'PK_CNST_SITE', N'OBJECT';
COMMIT TRANSACTION;
SET TRANSACTION ISOLATION LEVEL READ COMMITTED;

PRINT N'Creating Index [dbo].[ICS_CNST_SITE].[IX_CNST_SIT_ICS_CNS_SIT_LIS_ID]...';

CREATE NONCLUSTERED INDEX [IX_CNST_SIT_ICS_CNS_SIT_LIS_ID]
    ON [dbo].[ICS_CNST_SITE]([ICS_CNST_SITE_LIST_ID] ASC);

PRINT N'Starting rebuilding table [dbo].[ICS_CONTACT]...';

BEGIN TRANSACTION;
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;
SET XACT_ABORT ON;
CREATE TABLE [dbo].[tmp_ms_xx_ICS_CONTACT] (
    [ICS_CONTACT_ID]                         VARCHAR (36)  NOT NULL,
    [ICS_FAC_ID]                             VARCHAR (36)  NULL,
    [ICS_BASIC_PRMT_ID]                      VARCHAR (36)  NULL,
    [ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] VARCHAR (36)  NULL,
    [ICS_CAFO_PRMT_ID]                       VARCHAR (36)  NULL,
    [ICS_CMPL_MON_ID]                        VARCHAR (36)  NULL,
    [ICS_GNRL_PRMT_ID]                       VARCHAR (36)  NULL,
    [ICS_MASTER_GNRL_PRMT_ID]                VARCHAR (36)  NULL,
    [ICS_PRMT_FEATR_ID]                      VARCHAR (36)  NULL,
    [ICS_PRETR_PRMT_ID]                      VARCHAR (36)  NULL,
    [ICS_SW_CNST_PRMT_ID]                    VARCHAR (36)  NULL,
    [ICS_SW_INDST_PRMT_ID]                   VARCHAR (36)  NULL,
    [ICS_UNPRMT_FAC_ID]                      VARCHAR (36)  NULL,
    [AFFIL_TYPE_TXT]                         VARCHAR (3)   NOT NULL,
    [FIRST_NAME]                             VARCHAR (30)  NOT NULL,
    [MIDDLE_NAME]                            VARCHAR (10)  NULL,
    [LAST_NAME]                              VARCHAR (30)  NOT NULL,
    [INDVL_TITLE_TXT]                        VARCHAR (40)  NOT NULL,
    [ORG_FRML_NAME]                          VARCHAR (80)  NULL,
    [ST_CODE]                                CHAR (2)      NULL,
    [RGN_CODE]                               CHAR (2)      NULL,
    [ELEC_ADDR_TXT]                          VARCHAR (100) NULL,
    [START_DATE_OF_CONTACT_ASSC]             DATETIME      NULL,
    [END_DATE_OF_CONTACT_ASSC]               DATETIME      NULL,
    [DATA_HASH]                              VARCHAR (100) NULL,
    CONSTRAINT [tmp_ms_xx_constraint_PK_CONTACT1] PRIMARY KEY CLUSTERED ([ICS_CONTACT_ID] ASC)
);
IF EXISTS (SELECT TOP 1 1 
           FROM   [dbo].[ICS_CONTACT])
    BEGIN
        INSERT INTO [dbo].[tmp_ms_xx_ICS_CONTACT] ([ICS_CONTACT_ID], [ICS_FAC_ID], [ICS_BASIC_PRMT_ID], [ICS_PRMT_FEATR_ID], [ICS_CAFO_PRMT_ID], [ICS_CMPL_MON_ID], [ICS_GNRL_PRMT_ID], [ICS_MASTER_GNRL_PRMT_ID], [ICS_PRETR_PRMT_ID], [ICS_SW_CNST_PRMT_ID], [ICS_SW_INDST_PRMT_ID], [ICS_UNPRMT_FAC_ID], [AFFIL_TYPE_TXT], [FIRST_NAME], [MIDDLE_NAME], [LAST_NAME], [INDVL_TITLE_TXT], [ORG_FRML_NAME], [ST_CODE], [RGN_CODE], [ELEC_ADDR_TXT], [START_DATE_OF_CONTACT_ASSC], [END_DATE_OF_CONTACT_ASSC], [DATA_HASH])
        SELECT   [ICS_CONTACT_ID],
                 [ICS_FAC_ID],
                 [ICS_BASIC_PRMT_ID],
                 [ICS_PRMT_FEATR_ID],
                 [ICS_CAFO_PRMT_ID],
                 [ICS_CMPL_MON_ID],
                 [ICS_GNRL_PRMT_ID],
                 [ICS_MASTER_GNRL_PRMT_ID],
                 [ICS_PRETR_PRMT_ID],
                 [ICS_SW_CNST_PRMT_ID],
                 [ICS_SW_INDST_PRMT_ID],
                 [ICS_UNPRMT_FAC_ID],
                 [AFFIL_TYPE_TXT],
                 [FIRST_NAME],
                 [MIDDLE_NAME],
                 [LAST_NAME],
                 [INDVL_TITLE_TXT],
                 [ORG_FRML_NAME],
                 [ST_CODE],
                 [RGN_CODE],
                 [ELEC_ADDR_TXT],
                 [START_DATE_OF_CONTACT_ASSC],
                 [END_DATE_OF_CONTACT_ASSC],
                 [DATA_HASH]
        FROM     [dbo].[ICS_CONTACT]
        ORDER BY [ICS_CONTACT_ID] ASC;
    END
DROP TABLE [dbo].[ICS_CONTACT];
EXECUTE sp_rename N'[dbo].[tmp_ms_xx_ICS_CONTACT]', N'ICS_CONTACT';
EXECUTE sp_rename N'[dbo].[tmp_ms_xx_constraint_PK_CONTACT1]', N'PK_CONTACT', N'OBJECT';
COMMIT TRANSACTION;
SET TRANSACTION ISOLATION LEVEL READ COMMITTED;

PRINT N'Creating Index [dbo].[ICS_CONTACT].[IX_CNT_IC_BS_OF_SI_HN_AP_PR_ID]...';

CREATE NONCLUSTERED INDEX [IX_CNT_IC_BS_OF_SI_HN_AP_PR_ID]
    ON [dbo].[ICS_CONTACT]([ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] ASC);

PRINT N'Creating Index [dbo].[ICS_CONTACT].[IX_CNTCT_ICS_MSTR_GNRL_PRMT_ID]...';

CREATE NONCLUSTERED INDEX [IX_CNTCT_ICS_MSTR_GNRL_PRMT_ID]
    ON [dbo].[ICS_CONTACT]([ICS_MASTER_GNRL_PRMT_ID] ASC);

PRINT N'Creating Index [dbo].[ICS_CONTACT].[IX_CONTACT_ICS_BASIC_PRMT_ID]...';

CREATE NONCLUSTERED INDEX [IX_CONTACT_ICS_BASIC_PRMT_ID]
    ON [dbo].[ICS_CONTACT]([ICS_BASIC_PRMT_ID] ASC);

PRINT N'Creating Index [dbo].[ICS_CONTACT].[IX_CONTACT_ICS_CAFO_PRMT_ID]...';

CREATE NONCLUSTERED INDEX [IX_CONTACT_ICS_CAFO_PRMT_ID]
    ON [dbo].[ICS_CONTACT]([ICS_CAFO_PRMT_ID] ASC);

PRINT N'Creating Index [dbo].[ICS_CONTACT].[IX_CONTACT_ICS_CMPL_MON_ID]...';

CREATE NONCLUSTERED INDEX [IX_CONTACT_ICS_CMPL_MON_ID]
    ON [dbo].[ICS_CONTACT]([ICS_CMPL_MON_ID] ASC);

PRINT N'Creating Index [dbo].[ICS_CONTACT].[IX_CONTACT_ICS_FAC_ID]...';

CREATE NONCLUSTERED INDEX [IX_CONTACT_ICS_FAC_ID]
    ON [dbo].[ICS_CONTACT]([ICS_FAC_ID] ASC);

PRINT N'Creating Index [dbo].[ICS_CONTACT].[IX_CONTACT_ICS_GNRL_PRMT_ID]...';

CREATE NONCLUSTERED INDEX [IX_CONTACT_ICS_GNRL_PRMT_ID]
    ON [dbo].[ICS_CONTACT]([ICS_GNRL_PRMT_ID] ASC);

PRINT N'Creating Index [dbo].[ICS_CONTACT].[IX_CONTACT_ICS_PRETR_PRMT_ID]...';

CREATE NONCLUSTERED INDEX [IX_CONTACT_ICS_PRETR_PRMT_ID]
    ON [dbo].[ICS_CONTACT]([ICS_PRETR_PRMT_ID] ASC);

PRINT N'Creating Index [dbo].[ICS_CONTACT].[IX_CONTACT_ICS_PRMT_FEATR_ID]...';

CREATE NONCLUSTERED INDEX [IX_CONTACT_ICS_PRMT_FEATR_ID]
    ON [dbo].[ICS_CONTACT]([ICS_PRMT_FEATR_ID] ASC);

PRINT N'Creating Index [dbo].[ICS_CONTACT].[IX_CONTACT_ICS_SW_CNST_PRMT_ID]...';

CREATE NONCLUSTERED INDEX [IX_CONTACT_ICS_SW_CNST_PRMT_ID]
    ON [dbo].[ICS_CONTACT]([ICS_SW_CNST_PRMT_ID] ASC);

PRINT N'Creating Index [dbo].[ICS_CONTACT].[IX_CONTACT_ICS_UNPRMT_FAC_ID]...';

CREATE NONCLUSTERED INDEX [IX_CONTACT_ICS_UNPRMT_FAC_ID]
    ON [dbo].[ICS_CONTACT]([ICS_UNPRMT_FAC_ID] ASC);

PRINT N'Creating Index [dbo].[ICS_CONTACT].[IX_CONTCT_ICS_SW_INDST_PRMT_ID]...';

CREATE NONCLUSTERED INDEX [IX_CONTCT_ICS_SW_INDST_PRMT_ID]
    ON [dbo].[ICS_CONTACT]([ICS_SW_INDST_PRMT_ID] ASC);

PRINT N'Starting rebuilding table [dbo].[ICS_COPY_MGP_LMT_SET]...';

BEGIN TRANSACTION;
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;
SET XACT_ABORT ON;
CREATE TABLE [dbo].[tmp_ms_xx_ICS_COPY_MGP_LMT_SET] (
    [ICS_COPY_MGP_LMT_SET_ID]       VARCHAR (36)  NOT NULL,
    [ICS_PAYLOAD_ID]                VARCHAR (36)  NOT NULL,
    [SRC_SYSTM_IDENT]               VARCHAR (50)  NULL,
    [TRANSACTION_TYPE]              CHAR (1)      NULL,
    [TRANSACTION_TIMESTAMP]         DATETIME      NULL,
    [PRMT_IDENT]                    CHAR (9)      NOT NULL,
    [PRMT_FEATR_IDENT]              VARCHAR (4)   NOT NULL,
    [LMT_SET_DESIGNATOR]            VARCHAR (2)   NOT NULL,
    [TRGT_GNRL_PRMT_IDENT]          CHAR (9)      NULL,
    [TRGT_GNRL_PRMT_FEATR_IDENT]    VARCHAR (4)   NULL,
    [TRGT_GNRL_LMT_SET_DESIGNATOR]  VARCHAR (2)   NULL,
    [PRMT_FEATR_TYPE_CODE]          VARCHAR (3)   NULL,
    [PRMT_FEATR_DESC]               VARCHAR (100) NULL,
    [PRMT_FEATR_ST_WTR_BODY_NAME]   VARCHAR (50)  NULL,
    [IMPAIRED_WTR_IND]              CHAR (1)      NULL,
    [TMDL_COMPLETED_IND]            CHAR (1)      NULL,
    [PRMT_FEATR_USR_DFND_DAT_ELM_1] VARCHAR (30)  NULL,
    [PRMT_FEATR_USR_DFND_DAT_ELM_2] VARCHAR (30)  NULL,
    [LMT_SET_NAME_TXT]              VARCHAR (100) NULL,
    [DMR_PRE_PRINT_CMNTS_TXT]       VARCHAR (315) NULL,
    [KEY_HASH]                      VARCHAR (100) NULL,
    [DATA_HASH]                     VARCHAR (100) NULL,
    CONSTRAINT [tmp_ms_xx_constraint_PK_COPY_MGP_LMT_SET1] PRIMARY KEY CLUSTERED ([ICS_COPY_MGP_LMT_SET_ID] ASC)
);
IF EXISTS (SELECT TOP 1 1 
           FROM   [dbo].[ICS_COPY_MGP_LMT_SET])
    BEGIN
        INSERT INTO [dbo].[tmp_ms_xx_ICS_COPY_MGP_LMT_SET] ([ICS_COPY_MGP_LMT_SET_ID], [ICS_PAYLOAD_ID], [SRC_SYSTM_IDENT], [TRANSACTION_TYPE], [TRANSACTION_TIMESTAMP], [PRMT_IDENT], [PRMT_FEATR_IDENT], [LMT_SET_DESIGNATOR], [TRGT_GNRL_PRMT_IDENT], [TRGT_GNRL_PRMT_FEATR_IDENT], [TRGT_GNRL_LMT_SET_DESIGNATOR], [PRMT_FEATR_TYPE_CODE], [PRMT_FEATR_DESC], [PRMT_FEATR_ST_WTR_BODY_NAME], [IMPAIRED_WTR_IND], [TMDL_COMPLETED_IND], [PRMT_FEATR_USR_DFND_DAT_ELM_1], [PRMT_FEATR_USR_DFND_DAT_ELM_2], [LMT_SET_NAME_TXT], [DMR_PRE_PRINT_CMNTS_TXT], [DATA_HASH], [KEY_HASH])
        SELECT   [ICS_COPY_MGP_LMT_SET_ID],
                 [ICS_PAYLOAD_ID],
                 [SRC_SYSTM_IDENT],
                 [TRANSACTION_TYPE],
                 [TRANSACTION_TIMESTAMP],
                 [PRMT_IDENT],
                 [PRMT_FEATR_IDENT],
                 [LMT_SET_DESIGNATOR],
                 [TRGT_GNRL_PRMT_IDENT],
                 [TRGT_GNRL_PRMT_FEATR_IDENT],
                 [TRGT_GNRL_LMT_SET_DESIGNATOR],
                 [PRMT_FEATR_TYPE_CODE],
                 [PRMT_FEATR_DESC],
                 [PRMT_FEATR_ST_WTR_BODY_NAME],
                 [IMPAIRED_WTR_IND],
                 [TMDL_COMPLETED_IND],
                 [PRMT_FEATR_USR_DFND_DAT_ELM_1],
                 [PRMT_FEATR_USR_DFND_DAT_ELM_2],
                 [LMT_SET_NAME_TXT],
                 [DMR_PRE_PRINT_CMNTS_TXT],
                 [DATA_HASH],
                 [KEY_HASH]
        FROM     [dbo].[ICS_COPY_MGP_LMT_SET]
        ORDER BY [ICS_COPY_MGP_LMT_SET_ID] ASC;
    END
DROP TABLE [dbo].[ICS_COPY_MGP_LMT_SET];
EXECUTE sp_rename N'[dbo].[tmp_ms_xx_ICS_COPY_MGP_LMT_SET]', N'ICS_COPY_MGP_LMT_SET';
EXECUTE sp_rename N'[dbo].[tmp_ms_xx_constraint_PK_COPY_MGP_LMT_SET1]', N'PK_COPY_MGP_LMT_SET', N'OBJECT';
COMMIT TRANSACTION;
SET TRANSACTION ISOLATION LEVEL READ COMMITTED;

PRINT N'Creating Index [dbo].[ICS_COPY_MGP_LMT_SET].[IX_COPY_MGP_LMT_SET_ICS_PYL_ID]...';

CREATE NONCLUSTERED INDEX [IX_COPY_MGP_LMT_SET_ICS_PYL_ID]
    ON [dbo].[ICS_COPY_MGP_LMT_SET]([ICS_PAYLOAD_ID] ASC);

PRINT N'Altering Table [dbo].[ICS_CSO_INSP]...';

ALTER TABLE [dbo].[ICS_CSO_INSP] ALTER COLUMN [DURATION_CSO_OVRFLW_EVT] DECIMAL (6, 2) NULL;
ALTER TABLE [dbo].[ICS_CSO_INSP] ALTER COLUMN [INCHES_PRECIP] DECIMAL (5, 2) NULL;

PRINT N'Starting rebuilding table [dbo].[ICS_DSCH_MON_REP]...';

BEGIN TRANSACTION;
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;
SET XACT_ABORT ON;
CREATE TABLE [dbo].[tmp_ms_xx_ICS_DSCH_MON_REP] (
    [ICS_DSCH_MON_REP_ID]          VARCHAR (36)   NOT NULL,
    [ICS_PAYLOAD_ID]               VARCHAR (36)   NOT NULL,
    [SRC_SYSTM_IDENT]              VARCHAR (50)   NULL,
    [TRANSACTION_TYPE]             CHAR (1)       NULL,
    [TRANSACTION_TIMESTAMP]        DATETIME       NULL,
    [PRMT_IDENT]                   CHAR (9)       NOT NULL,
    [PRMT_FEATR_IDENT]             VARCHAR (4)    NOT NULL,
    [LMT_SET_DESIGNATOR]           VARCHAR (2)    NOT NULL,
    [MON_PERIOD_END_DATE]          DATETIME       NOT NULL,
    [DMR_NO_DSCH_IND]              VARCHAR (3)    NULL,
    [DMR_NO_DSCH_RCVD_DATE]        DATETIME       NULL,
    [ELEC_SUBM_TYPE_CODE]          VARCHAR (3)    NULL,
    [SIGN_DATE]                    DATETIME       NULL,
    [PRNCPL_EXEC_OFFCR_FIRST_NAME] VARCHAR (30)   NULL,
    [PRNCPL_EXEC_OFFCR_LAST_NAME]  VARCHAR (30)   NULL,
    [PRNCPL_EXEC_OFFCR_TITLE]      VARCHAR (40)   NULL,
    [PRNCPL_EXEC_OFFCR_TELEPH]     VARCHAR (10)   NULL,
    [SIGN_FIRST_NAME]              VARCHAR (30)   NULL,
    [SIGN_LAST_NAME]               VARCHAR (30)   NULL,
    [SIGN_TELEPH]                  VARCHAR (10)   NULL,
    [REP_CMNT_TXT]                 VARCHAR (4000) NULL,
    [KEY_HASH]                     VARCHAR (100)  NULL,
    [DATA_HASH]                    VARCHAR (100)  NULL,
    CONSTRAINT [tmp_ms_xx_constraint_PK_DSCH_MON_REP1] PRIMARY KEY CLUSTERED ([ICS_DSCH_MON_REP_ID] ASC)
);
IF EXISTS (SELECT TOP 1 1 
           FROM   [dbo].[ICS_DSCH_MON_REP])
    BEGIN
        INSERT INTO [dbo].[tmp_ms_xx_ICS_DSCH_MON_REP] ([ICS_DSCH_MON_REP_ID], [ICS_PAYLOAD_ID], [SRC_SYSTM_IDENT], [TRANSACTION_TYPE], [TRANSACTION_TIMESTAMP], [PRMT_IDENT], [PRMT_FEATR_IDENT], [LMT_SET_DESIGNATOR], [MON_PERIOD_END_DATE], [ELEC_SUBM_TYPE_CODE], [SIGN_DATE], [PRNCPL_EXEC_OFFCR_FIRST_NAME], [PRNCPL_EXEC_OFFCR_LAST_NAME], [PRNCPL_EXEC_OFFCR_TITLE], [PRNCPL_EXEC_OFFCR_TELEPH], [SIGN_FIRST_NAME], [SIGN_LAST_NAME], [SIGN_TELEPH], [REP_CMNT_TXT], [DMR_NO_DSCH_IND], [DMR_NO_DSCH_RCVD_DATE], [KEY_HASH], [DATA_HASH])
        SELECT   [ICS_DSCH_MON_REP_ID],
                 [ICS_PAYLOAD_ID],
                 [SRC_SYSTM_IDENT],
                 [TRANSACTION_TYPE],
                 [TRANSACTION_TIMESTAMP],
                 [PRMT_IDENT],
                 [PRMT_FEATR_IDENT],
                 [LMT_SET_DESIGNATOR],
                 [MON_PERIOD_END_DATE],
                 [ELEC_SUBM_TYPE_CODE],
                 [SIGN_DATE],
                 [PRNCPL_EXEC_OFFCR_FIRST_NAME],
                 [PRNCPL_EXEC_OFFCR_LAST_NAME],
                 [PRNCPL_EXEC_OFFCR_TITLE],
                 [PRNCPL_EXEC_OFFCR_TELEPH],
                 [SIGN_FIRST_NAME],
                 [SIGN_LAST_NAME],
                 [SIGN_TELEPH],
                 [REP_CMNT_TXT],
                 [DMR_NO_DSCH_IND],
                 [DMR_NO_DSCH_RCVD_DATE],
                 [KEY_HASH],
                 [DATA_HASH]
        FROM     [dbo].[ICS_DSCH_MON_REP]
        ORDER BY [ICS_DSCH_MON_REP_ID] ASC;
    END
DROP TABLE [dbo].[ICS_DSCH_MON_REP];
EXECUTE sp_rename N'[dbo].[tmp_ms_xx_ICS_DSCH_MON_REP]', N'ICS_DSCH_MON_REP';
EXECUTE sp_rename N'[dbo].[tmp_ms_xx_constraint_PK_DSCH_MON_REP1]', N'PK_DSCH_MON_REP', N'OBJECT';
COMMIT TRANSACTION;
SET TRANSACTION ISOLATION LEVEL READ COMMITTED;

PRINT N'Creating Index [dbo].[ICS_DSCH_MON_REP].[IX_DSCH_MON_REP_ICS_PAYLOAD_ID]...';

CREATE NONCLUSTERED INDEX [IX_DSCH_MON_REP_ICS_PAYLOAD_ID]
    ON [dbo].[ICS_DSCH_MON_REP]([ICS_PAYLOAD_ID] ASC);

PRINT N'Creating Index [dbo].[ICS_DSCH_MON_REP].[IX_DS_MO_RE_PR_ID_PR_FE_ID_LM]...';

CREATE UNIQUE NONCLUSTERED INDEX [IX_DS_MO_RE_PR_ID_PR_FE_ID_LM]
    ON [dbo].[ICS_DSCH_MON_REP]([PRMT_IDENT] ASC, [PRMT_FEATR_IDENT] ASC, [LMT_SET_DESIGNATOR] ASC, [MON_PERIOD_END_DATE] ASC);

PRINT N'Starting rebuilding table [dbo].[ICS_FAC]...';

BEGIN TRANSACTION;
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;
SET XACT_ABORT ON;
CREATE TABLE [dbo].[tmp_ms_xx_ICS_FAC] (
    [ICS_FAC_ID]                 VARCHAR (36)    NOT NULL,
    [ICS_BASIC_PRMT_ID]          VARCHAR (36)    NULL,
    [ICS_GNRL_PRMT_ID]           VARCHAR (36)    NULL,
    [LOCALITY_NAME]              VARCHAR (60)    NULL,
    [LOC_ADDR_CITY_CODE]         VARCHAR (12)    NULL,
    [LOC_ADDR_COUNTY_CODE]       CHAR (5)        NULL,
    [FAC_SITE_NAME]              VARCHAR (80)    NULL,
    [LOC_ADDR_TXT]               VARCHAR (50)    NULL,
    [SUPPL_LOC_TXT]              VARCHAR (50)    NULL,
    [LOC_ST_CODE]                CHAR (2)        NULL,
    [LOC_ZIP_CODE]               VARCHAR (14)    NULL,
    [LOC_COUNTRY_CODE]           VARCHAR (3)     NULL,
    [ORG_DUNS_NUM]               CHAR (9)        NULL,
    [ST_FAC_IDENT]               VARCHAR (12)    NULL,
    [ST_RGN_CODE]                VARCHAR (5)     NULL,
    [FAC_CONGR_DISTRICT_NUM]     INT             NULL,
    [FAC_TYPE_OF_OWNERSHIP_CODE] VARCHAR (3)     NULL,
    [FEDR_FAC_IDENT_NUM]         VARCHAR (12)    NULL,
    [FEDR_AGNCY_CODE]            VARCHAR (5)     NULL,
    [TRIBAL_LAND_CODE]           VARCHAR (9)     NULL,
    [CNST_PROJ_NAME]             VARCHAR (50)    NULL,
    [CNST_PROJ_LAT_MEAS]         DECIMAL (9, 7)  NULL,
    [CNST_PROJ_LONG_MEAS]        DECIMAL (10, 6) NULL,
    [SECTION_TOWNSHIP_RNG]       VARCHAR (50)    NULL,
    [FAC_CMNTS]                  VARCHAR (4000)  NULL,
    [FAC_USR_DFND_FLD_1]         VARCHAR (30)    NULL,
    [FAC_USR_DFND_FLD_2]         VARCHAR (30)    NULL,
    [FAC_USR_DFND_FLD_3]         VARCHAR (30)    NULL,
    [FAC_USR_DFND_FLD_4]         VARCHAR (30)    NULL,
    [FAC_USR_DFND_FLD_5]         VARCHAR (30)    NULL,
    [DATA_HASH]                  VARCHAR (100)   NULL,
    CONSTRAINT [tmp_ms_xx_constraint_PK_FAC1] PRIMARY KEY CLUSTERED ([ICS_FAC_ID] ASC)
);
IF EXISTS (SELECT TOP 1 1 
           FROM   [dbo].[ICS_FAC])
    BEGIN
        INSERT INTO [dbo].[tmp_ms_xx_ICS_FAC] ([ICS_FAC_ID], [ICS_BASIC_PRMT_ID], [ICS_GNRL_PRMT_ID], [FAC_SITE_NAME], [LOC_ADDR_TXT], [SUPPL_LOC_TXT], [LOCALITY_NAME], [LOC_ADDR_COUNTY_CODE], [LOC_ADDR_CITY_CODE], [LOC_ST_CODE], [LOC_ZIP_CODE], [LOC_COUNTRY_CODE], [ORG_DUNS_NUM], [ST_FAC_IDENT], [ST_RGN_CODE], [FAC_CONGR_DISTRICT_NUM], [FAC_TYPE_OF_OWNERSHIP_CODE], [FEDR_FAC_IDENT_NUM], [FEDR_AGNCY_CODE], [TRIBAL_LAND_CODE], [CNST_PROJ_NAME], [CNST_PROJ_LAT_MEAS], [CNST_PROJ_LONG_MEAS], [SECTION_TOWNSHIP_RNG], [FAC_CMNTS], [FAC_USR_DFND_FLD_1], [FAC_USR_DFND_FLD_2], [FAC_USR_DFND_FLD_3], [FAC_USR_DFND_FLD_4], [FAC_USR_DFND_FLD_5], [DATA_HASH])
        SELECT   [ICS_FAC_ID],
                 [ICS_BASIC_PRMT_ID],
                 [ICS_GNRL_PRMT_ID],
                 [FAC_SITE_NAME],
                 [LOC_ADDR_TXT],
                 [SUPPL_LOC_TXT],
                 [LOCALITY_NAME],
                 [LOC_ADDR_COUNTY_CODE],
                 [LOC_ADDR_CITY_CODE],
                 [LOC_ST_CODE],
                 [LOC_ZIP_CODE],
                 [LOC_COUNTRY_CODE],
                 [ORG_DUNS_NUM],
                 [ST_FAC_IDENT],
                 [ST_RGN_CODE],
                 [FAC_CONGR_DISTRICT_NUM],
                 [FAC_TYPE_OF_OWNERSHIP_CODE],
                 [FEDR_FAC_IDENT_NUM],
                 [FEDR_AGNCY_CODE],
                 [TRIBAL_LAND_CODE],
                 [CNST_PROJ_NAME],
                 [CNST_PROJ_LAT_MEAS],
                 [CNST_PROJ_LONG_MEAS],
                 [SECTION_TOWNSHIP_RNG],
                 [FAC_CMNTS],
                 [FAC_USR_DFND_FLD_1],
                 [FAC_USR_DFND_FLD_2],
                 [FAC_USR_DFND_FLD_3],
                 [FAC_USR_DFND_FLD_4],
                 [FAC_USR_DFND_FLD_5],
                 [DATA_HASH]
        FROM     [dbo].[ICS_FAC]
        ORDER BY [ICS_FAC_ID] ASC;
    END
DROP TABLE [dbo].[ICS_FAC];
EXECUTE sp_rename N'[dbo].[tmp_ms_xx_ICS_FAC]', N'ICS_FAC';
EXECUTE sp_rename N'[dbo].[tmp_ms_xx_constraint_PK_FAC1]', N'PK_FAC', N'OBJECT';
COMMIT TRANSACTION;
SET TRANSACTION ISOLATION LEVEL READ COMMITTED;

PRINT N'Creating Index [dbo].[ICS_FAC].[IX_FAC_ICS_BASIC_PRMT_ID]...';

CREATE NONCLUSTERED INDEX [IX_FAC_ICS_BASIC_PRMT_ID]
    ON [dbo].[ICS_FAC]([ICS_BASIC_PRMT_ID] ASC);

PRINT N'Creating Index [dbo].[ICS_FAC].[IX_FAC_ICS_GNRL_PRMT_ID]...';

CREATE NONCLUSTERED INDEX [IX_FAC_ICS_GNRL_PRMT_ID]
    ON [dbo].[ICS_FAC]([ICS_GNRL_PRMT_ID] ASC);

PRINT N'Starting rebuilding table [dbo].[ICS_FINAL_ORDER]...';

BEGIN TRANSACTION;
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;
SET XACT_ABORT ON;
CREATE TABLE [dbo].[tmp_ms_xx_ICS_FINAL_ORDER] (
    [ICS_FINAL_ORDER_ID]             VARCHAR (36)    NOT NULL,
    [ICS_FRML_ENFRC_ACTN_ID]         VARCHAR (36)    NOT NULL,
    [FINAL_ORDER_IDENT]              INT             NOT NULL,
    [FINAL_ORDER_TYPE_CODE]          VARCHAR (3)     NULL,
    [FINAL_ORDER_ISSUED_ENTERD_DATE] DATETIME        NULL,
    [NPDES_CLOSED_DATE]              DATETIME        NULL,
    [FINAL_ORDER_QNCR_CMNTS]         VARCHAR (2000)  NULL,
    [CASH_CIVIL_PNLTY_REQD_AMT]      DECIMAL (14, 2) NULL,
    [CASH_CIVIL_PNLTY_COLL_AMT]      DECIMAL (14, 2) NULL,
    [OTHR_CMNTS]                     VARCHAR (4000)  NULL,
    [DATA_HASH]                      VARCHAR (100)   NULL,
    CONSTRAINT [tmp_ms_xx_constraint_PK_FINAL_ORDER1] PRIMARY KEY CLUSTERED ([ICS_FINAL_ORDER_ID] ASC)
);
IF EXISTS (SELECT TOP 1 1 
           FROM   [dbo].[ICS_FINAL_ORDER])
    BEGIN
        INSERT INTO [dbo].[tmp_ms_xx_ICS_FINAL_ORDER] ([ICS_FINAL_ORDER_ID], [ICS_FRML_ENFRC_ACTN_ID], [FINAL_ORDER_IDENT], [FINAL_ORDER_TYPE_CODE], [FINAL_ORDER_ISSUED_ENTERD_DATE], [NPDES_CLOSED_DATE], [FINAL_ORDER_QNCR_CMNTS], [CASH_CIVIL_PNLTY_REQD_AMT], [OTHR_CMNTS], [DATA_HASH])
        SELECT   [ICS_FINAL_ORDER_ID],
                 [ICS_FRML_ENFRC_ACTN_ID],
                 [FINAL_ORDER_IDENT],
                 [FINAL_ORDER_TYPE_CODE],
                 [FINAL_ORDER_ISSUED_ENTERD_DATE],
                 [NPDES_CLOSED_DATE],
                 [FINAL_ORDER_QNCR_CMNTS],
                 CAST ([CASH_CIVIL_PNLTY_REQD_AMT] AS DECIMAL (14, 2)),
                 [OTHR_CMNTS],
                 [DATA_HASH]
        FROM     [dbo].[ICS_FINAL_ORDER]
        ORDER BY [ICS_FINAL_ORDER_ID] ASC;
    END
DROP TABLE [dbo].[ICS_FINAL_ORDER];
EXECUTE sp_rename N'[dbo].[tmp_ms_xx_ICS_FINAL_ORDER]', N'ICS_FINAL_ORDER';
EXECUTE sp_rename N'[dbo].[tmp_ms_xx_constraint_PK_FINAL_ORDER1]', N'PK_FINAL_ORDER', N'OBJECT';
COMMIT TRANSACTION;
SET TRANSACTION ISOLATION LEVEL READ COMMITTED;

PRINT N'Creating Index [dbo].[ICS_FINAL_ORDER].[IX_FINL_ORD_ICS_FRM_ENF_ACT_ID]...';

CREATE NONCLUSTERED INDEX [IX_FINL_ORD_ICS_FRM_ENF_ACT_ID]
    ON [dbo].[ICS_FINAL_ORDER]([ICS_FRML_ENFRC_ACTN_ID] ASC);

PRINT N'Starting rebuilding table [dbo].[ICS_GEO_COORD]...';

BEGIN TRANSACTION;
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;
SET XACT_ABORT ON;
CREATE TABLE [dbo].[tmp_ms_xx_ICS_GEO_COORD] (
    [ICS_GEO_COORD_ID]        VARCHAR (36)  NOT NULL,
    [ICS_FAC_ID]              VARCHAR (36)  NULL,
    [ICS_COPY_MGP_LMT_SET_ID] VARCHAR (36)  NULL,
    [ICS_PRMT_FEATR_ID]       VARCHAR (36)  NULL,
    [ICS_UNPRMT_FAC_ID]       VARCHAR (36)  NULL,
    [LAT_MEAS]                DECIMAL (9, 7)  NOT NULL,
    [LONG_MEAS]               DECIMAL (10, 6)  NOT NULL,
    [HORZ_ACCURACY_MEAS]      INT           NULL,
    [GEOMETRIC_TYPE_CODE]     VARCHAR (3)   NULL,
    [HORZ_COLL_METHOD_CODE]   VARCHAR (3)   NULL,
    [HORZ_REF_DATUM_CODE]     VARCHAR (3)   NULL,
    [REF_POINT_CODE]          VARCHAR (3)   NULL,
    [SRC_MAP_SCALE_NUM]       INT           NULL,
    [DATA_HASH]               VARCHAR (100) NULL,
    CONSTRAINT [tmp_ms_xx_constraint_PK_GEO_COORD1] PRIMARY KEY CLUSTERED ([ICS_GEO_COORD_ID] ASC)
);
IF EXISTS (SELECT TOP 1 1 
           FROM   [dbo].[ICS_GEO_COORD])
    BEGIN
        INSERT INTO [dbo].[tmp_ms_xx_ICS_GEO_COORD] ([ICS_GEO_COORD_ID], [ICS_FAC_ID], [ICS_PRMT_FEATR_ID], [ICS_UNPRMT_FAC_ID], [LAT_MEAS], [LONG_MEAS], [HORZ_ACCURACY_MEAS], [GEOMETRIC_TYPE_CODE], [HORZ_COLL_METHOD_CODE], [HORZ_REF_DATUM_CODE], [REF_POINT_CODE], [SRC_MAP_SCALE_NUM], [DATA_HASH], [ICS_COPY_MGP_LMT_SET_ID])
        SELECT   [ICS_GEO_COORD_ID],
                 [ICS_FAC_ID],
                 [ICS_PRMT_FEATR_ID],
                 [ICS_UNPRMT_FAC_ID],
                 CAST ([LAT_MEAS] AS DECIMAL (9,7)),
                 CAST ([LONG_MEAS] AS DECIMAL (10,6)),
                 [HORZ_ACCURACY_MEAS],
                 [GEOMETRIC_TYPE_CODE],
                 [HORZ_COLL_METHOD_CODE],
                 [HORZ_REF_DATUM_CODE],
                 [REF_POINT_CODE],
                 [SRC_MAP_SCALE_NUM],
                 [DATA_HASH],
                 [ICS_COPY_MGP_LMT_SET_ID]
        FROM     [dbo].[ICS_GEO_COORD]
        ORDER BY [ICS_GEO_COORD_ID] ASC;
    END
DROP TABLE [dbo].[ICS_GEO_COORD];
EXECUTE sp_rename N'[dbo].[tmp_ms_xx_ICS_GEO_COORD]', N'ICS_GEO_COORD';
EXECUTE sp_rename N'[dbo].[tmp_ms_xx_constraint_PK_GEO_COORD1]', N'PK_GEO_COORD', N'OBJECT';
COMMIT TRANSACTION;
SET TRANSACTION ISOLATION LEVEL READ COMMITTED;

PRINT N'Creating Index [dbo].[ICS_GEO_COORD].[IX_GEO_COORD_ICS_FAC_ID]...';

CREATE NONCLUSTERED INDEX [IX_GEO_COORD_ICS_FAC_ID]
    ON [dbo].[ICS_GEO_COORD]([ICS_FAC_ID] ASC);

PRINT N'Creating Index [dbo].[ICS_GEO_COORD].[IX_GEO_COORD_ICS_PRMT_FEATR_ID]...';

CREATE NONCLUSTERED INDEX [IX_GEO_COORD_ICS_PRMT_FEATR_ID]
    ON [dbo].[ICS_GEO_COORD]([ICS_PRMT_FEATR_ID] ASC);

PRINT N'Creating Index [dbo].[ICS_GEO_COORD].[IX_GEO_COORD_ICS_UNPRMT_FAC_ID]...';

CREATE NONCLUSTERED INDEX [IX_GEO_COORD_ICS_UNPRMT_FAC_ID]
    ON [dbo].[ICS_GEO_COORD]([ICS_UNPRMT_FAC_ID] ASC);

PRINT N'Creating Index [dbo].[ICS_GEO_COORD].[IX_GEO_COR_ICS_COP_MG_LM_SE_ID]...';

CREATE NONCLUSTERED INDEX [IX_GEO_COR_ICS_COP_MG_LM_SE_ID]
    ON [dbo].[ICS_GEO_COORD]([ICS_COPY_MGP_LMT_SET_ID] ASC);

PRINT N'Starting rebuilding table [dbo].[ICS_GNRL_PRMT]...';

BEGIN TRANSACTION;
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;
SET XACT_ABORT ON;
CREATE TABLE [dbo].[tmp_ms_xx_ICS_GNRL_PRMT] (
    [ICS_GNRL_PRMT_ID]               VARCHAR (36)    NOT NULL,
    [ICS_PAYLOAD_ID]                 VARCHAR (36)    NOT NULL,
    [SRC_SYSTM_IDENT]                VARCHAR (50)    NULL,
    [TRANSACTION_TYPE]               CHAR (1)        NULL,
    [TRANSACTION_TIMESTAMP]          DATETIME        NULL,
    [PRMT_IDENT]                     CHAR (9)        NOT NULL,
    [ELEC_SUBM_TYPE_CODE]            VARCHAR (3)     NULL,
    [ASSC_MASTER_GNRL_PRMT_IDENT]    CHAR (9)        NULL,
    [PRMT_TYPE_CODE]                 VARCHAR (3)     NULL,
    [AGNCY_TYPE_CODE]                VARCHAR (3)     NULL,
    [PRMT_STAT_CODE]                 VARCHAR (3)     NULL,
    [PRMT_ISSUE_DATE]                DATETIME        NULL,
    [PRMT_EFFECTIVE_DATE]            DATETIME        NULL,
    [PRMT_EXPR_DATE]                 DATETIME        NULL,
    [REISSU_PRIO_PRMT_IND]           CHAR (1)        NULL,
    [BACKLOG_REASON_TXT]             VARCHAR (2000)  NULL,
    [PRMT_ISSUING_ORG_TYPE_NAME]     VARCHAR (100)   NULL,
    [PRMT_APPEALED_IND]              CHAR (1)        NULL,
    [PRMT_USR_DFND_DAT_ELM_1_TXT]    VARCHAR (30)    NULL,
    [PRMT_USR_DFND_DAT_ELM_2_TXT]    VARCHAR (30)    NULL,
    [PRMT_USR_DFND_DAT_ELM_3_TXT]    VARCHAR (30)    NULL,
    [PRMT_USR_DFND_DAT_ELM_4_TXT]    VARCHAR (30)    NULL,
    [PRMT_USR_DFND_DAT_ELM_5_TXT]    VARCHAR (30)    NULL,
    [PRMT_CMNTS_TXT]                 VARCHAR (4000)  NULL,
    [MAJOR_MINOR_RATING_CODE]        INT             NULL,
    [TTL_APPL_DSGN_FLOW_NUM]         DECIMAL (15, 7) NULL,
    [TTL_APPL_AVER_FLOW_NUM]         DECIMAL (15, 7) NULL,
    [APPL_RCVD_DATE]                 DATETIME        NULL,
    [PRMT_APPL_CMPL_DATE]            DATETIME        NULL,
    [NEW_SRC_IND]                    CHAR (1)        NULL,
    [PRMT_ST_WTR_BODY_CODE]          VARCHAR (12)    NULL,
    [PRMT_ST_WTR_BODY_NAME]          VARCHAR (50)    NULL,
    [FEDR_GRANT_IND]                 CHAR (1)        NULL,
    [DMR_COGNZNT_OFCL]               VARCHAR (30)    NULL,
    [DMR_COGNZNT_OFCL_TELEPH_NUM]    VARCHAR (15)    NULL,
    [ELEC_REP_WAIVER_TYPE_CODE]      VARCHAR (3)     NULL,
    [ELEC_REP_WAIVER_EFFECTIVE_DATE] DATETIME        NULL,
    [ELEC_REP_WAIVER_EXPR_DATE]      DATETIME        NULL,
    [MAJOR_MINOR_STAT_IND]           CHAR (1)        NULL,
    [MAJOR_MINOR_STAT_START_DATE]    DATETIME        NULL,
    [DMR_NON_RCPT_STAT_IND]          CHAR (1)        NULL,
    [DMR_NON_RCPT_STAT_START_DATE]   DATETIME        NULL,
    [KEY_HASH]                       VARCHAR (100)   NULL,
    [DATA_HASH]                      VARCHAR (100)   NULL,
    CONSTRAINT [tmp_ms_xx_constraint_PK_GNRL_PRMT1] PRIMARY KEY CLUSTERED ([ICS_GNRL_PRMT_ID] ASC)
);
IF EXISTS (SELECT TOP 1 1 
           FROM   [dbo].[ICS_GNRL_PRMT])
    BEGIN
        INSERT INTO [dbo].[tmp_ms_xx_ICS_GNRL_PRMT] ([ICS_GNRL_PRMT_ID], [ICS_PAYLOAD_ID], [SRC_SYSTM_IDENT], [TRANSACTION_TYPE], [TRANSACTION_TIMESTAMP], [PRMT_IDENT], [ELEC_SUBM_TYPE_CODE], [ASSC_MASTER_GNRL_PRMT_IDENT], [PRMT_TYPE_CODE], [AGNCY_TYPE_CODE], [PRMT_STAT_CODE], [PRMT_ISSUE_DATE], [PRMT_EFFECTIVE_DATE], [PRMT_EXPR_DATE], [REISSU_PRIO_PRMT_IND], [BACKLOG_REASON_TXT], [PRMT_ISSUING_ORG_TYPE_NAME], [PRMT_APPEALED_IND], [PRMT_USR_DFND_DAT_ELM_1_TXT], [PRMT_USR_DFND_DAT_ELM_2_TXT], [PRMT_USR_DFND_DAT_ELM_3_TXT], [PRMT_USR_DFND_DAT_ELM_4_TXT], [PRMT_USR_DFND_DAT_ELM_5_TXT], [PRMT_CMNTS_TXT], [MAJOR_MINOR_RATING_CODE], [MAJOR_MINOR_STAT_IND], [MAJOR_MINOR_STAT_START_DATE], [TTL_APPL_DSGN_FLOW_NUM], [TTL_APPL_AVER_FLOW_NUM], [APPL_RCVD_DATE], [PRMT_APPL_CMPL_DATE], [NEW_SRC_IND], [DMR_NON_RCPT_STAT_IND], [DMR_NON_RCPT_STAT_START_DATE], [PRMT_ST_WTR_BODY_CODE], [PRMT_ST_WTR_BODY_NAME], [FEDR_GRANT_IND], [DMR_COGNZNT_OFCL], [DMR_COGNZNT_OFCL_TELEPH_NUM], [ELEC_REP_WAIVER_TYPE_CODE], [ELEC_REP_WAIVER_EFFECTIVE_DATE], [ELEC_REP_WAIVER_EXPR_DATE], [KEY_HASH], [DATA_HASH])
        SELECT   [ICS_GNRL_PRMT_ID],
                 [ICS_PAYLOAD_ID],
                 [SRC_SYSTM_IDENT],
                 [TRANSACTION_TYPE],
                 [TRANSACTION_TIMESTAMP],
                 [PRMT_IDENT],
                 [ELEC_SUBM_TYPE_CODE],
                 [ASSC_MASTER_GNRL_PRMT_IDENT],
                 [PRMT_TYPE_CODE],
                 [AGNCY_TYPE_CODE],
                 [PRMT_STAT_CODE],
                 [PRMT_ISSUE_DATE],
                 [PRMT_EFFECTIVE_DATE],
                 [PRMT_EXPR_DATE],
                 [REISSU_PRIO_PRMT_IND],
                 [BACKLOG_REASON_TXT],
                 [PRMT_ISSUING_ORG_TYPE_NAME],
                 [PRMT_APPEALED_IND],
                 [PRMT_USR_DFND_DAT_ELM_1_TXT],
                 [PRMT_USR_DFND_DAT_ELM_2_TXT],
                 [PRMT_USR_DFND_DAT_ELM_3_TXT],
                 [PRMT_USR_DFND_DAT_ELM_4_TXT],
                 [PRMT_USR_DFND_DAT_ELM_5_TXT],
                 [PRMT_CMNTS_TXT],
                 [MAJOR_MINOR_RATING_CODE],
                 [MAJOR_MINOR_STAT_IND],
                 [MAJOR_MINOR_STAT_START_DATE],
                 [TTL_APPL_DSGN_FLOW_NUM],
                 [TTL_APPL_AVER_FLOW_NUM],
                 [APPL_RCVD_DATE],
                 [PRMT_APPL_CMPL_DATE],
                 [NEW_SRC_IND],
                 [DMR_NON_RCPT_STAT_IND],
                 [DMR_NON_RCPT_STAT_START_DATE],
                 [PRMT_ST_WTR_BODY_CODE],
                 [PRMT_ST_WTR_BODY_NAME],
                 [FEDR_GRANT_IND],
                 [DMR_COGNZNT_OFCL],
                 [DMR_COGNZNT_OFCL_TELEPH_NUM],
                 [ELEC_REP_WAIVER_TYPE_CODE],
                 [ELEC_REP_WAIVER_EFFECTIVE_DATE],
                 [ELEC_REP_WAIVER_EXPR_DATE],
                 [KEY_HASH],
                 [DATA_HASH]
        FROM     [dbo].[ICS_GNRL_PRMT]
        ORDER BY [ICS_GNRL_PRMT_ID] ASC;
    END
DROP TABLE [dbo].[ICS_GNRL_PRMT];
EXECUTE sp_rename N'[dbo].[tmp_ms_xx_ICS_GNRL_PRMT]', N'ICS_GNRL_PRMT';
EXECUTE sp_rename N'[dbo].[tmp_ms_xx_constraint_PK_GNRL_PRMT1]', N'PK_GNRL_PRMT', N'OBJECT';
COMMIT TRANSACTION;
SET TRANSACTION ISOLATION LEVEL READ COMMITTED;

PRINT N'Creating Index [dbo].[ICS_GNRL_PRMT].[IX_GNRL_PRMT_ICS_PAYLOAD_ID]...';

CREATE NONCLUSTERED INDEX [IX_GNRL_PRMT_ICS_PAYLOAD_ID]
    ON [dbo].[ICS_GNRL_PRMT]([ICS_PAYLOAD_ID] ASC);

PRINT N'Creating Index [dbo].[ICS_GNRL_PRMT].[IX_GNRL_PRMT_PRMT_IDENT]...';

CREATE UNIQUE NONCLUSTERED INDEX [IX_GNRL_PRMT_PRMT_IDENT]
    ON [dbo].[ICS_GNRL_PRMT]([PRMT_IDENT] ASC);

PRINT N'Altering Table [dbo].[ICS_GPCF_NOTICE_OF_TERM]...';

ALTER TABLE [dbo].[ICS_GPCF_NOTICE_OF_TERM] DROP COLUMN [ICS_SW_CNST_PRMT_ID];

PRINT N'Altering Table [dbo].[ICS_IMPACT_SSO_EVT]...';

ALTER TABLE [dbo].[ICS_IMPACT_SSO_EVT] DROP COLUMN [ICS_SSO_EVT_REP_ID];

PRINT N'Starting rebuilding table [dbo].[ICS_IMPAIRED_WTR_POLLUTANTS]...';

BEGIN TRANSACTION;
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;
SET XACT_ABORT ON;
CREATE TABLE [dbo].[tmp_ms_xx_ICS_IMPAIRED_WTR_POLLUTANTS] (
    [ICS_IMPAIRED_WTR_POLLUTANTS_ID] VARCHAR (36)  NOT NULL,
    [ICS_POLUT_LIST_ID]              VARCHAR (36)  NOT NULL,
    [IMPAIRED_WTR_POLLUTANTS]        INT           NOT NULL,
    [DATA_HASH]                      VARCHAR (100) NULL,
    CONSTRAINT [tmp_ms_xx_constraint_PK_IMPAIRED_WTR_POLLUTANTS1] PRIMARY KEY CLUSTERED ([ICS_IMPAIRED_WTR_POLLUTANTS_ID] ASC)
);
IF EXISTS (SELECT TOP 1 1 
           FROM   [dbo].[ICS_IMPAIRED_WTR_POLLUTANTS])
    BEGIN
        INSERT INTO [dbo].[tmp_ms_xx_ICS_IMPAIRED_WTR_POLLUTANTS] ([ICS_IMPAIRED_WTR_POLLUTANTS_ID], [IMPAIRED_WTR_POLLUTANTS], [DATA_HASH])
        SELECT   [ICS_IMPAIRED_WTR_POLLUTANTS_ID],
                 [IMPAIRED_WTR_POLLUTANTS],
                 [DATA_HASH]
        FROM     [dbo].[ICS_IMPAIRED_WTR_POLLUTANTS]
        ORDER BY [ICS_IMPAIRED_WTR_POLLUTANTS_ID] ASC;
    END
DROP TABLE [dbo].[ICS_IMPAIRED_WTR_POLLUTANTS];
EXECUTE sp_rename N'[dbo].[tmp_ms_xx_ICS_IMPAIRED_WTR_POLLUTANTS]', N'ICS_IMPAIRED_WTR_POLLUTANTS';
EXECUTE sp_rename N'[dbo].[tmp_ms_xx_constraint_PK_IMPAIRED_WTR_POLLUTANTS1]', N'PK_IMPAIRED_WTR_POLLUTANTS', N'OBJECT';
COMMIT TRANSACTION;
SET TRANSACTION ISOLATION LEVEL READ COMMITTED;

PRINT N'Creating Index [dbo].[ICS_IMPAIRED_WTR_POLLUTANTS].[IX_IMPR_WTR_PLL_ICS_PLU_LIS_ID]...';

CREATE NONCLUSTERED INDEX [IX_IMPR_WTR_PLL_ICS_PLU_LIS_ID]
    ON [dbo].[ICS_IMPAIRED_WTR_POLLUTANTS]([ICS_POLUT_LIST_ID] ASC);

PRINT N'Starting rebuilding table [dbo].[ICS_LMT_SET_SCHD]...';

BEGIN TRANSACTION;
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;
SET XACT_ABORT ON;
CREATE TABLE [dbo].[tmp_ms_xx_ICS_LMT_SET_SCHD] (
    [ICS_LMT_SET_SCHD_ID]          VARCHAR (36)  NOT NULL,
    [ICS_COPY_MGP_LMT_SET_ID]      VARCHAR (36)  NULL,
    [ICS_LMT_SET_ID]               VARCHAR (36)  NULL,
    [NUM_UNITS_REP_PERIOD_INTEGER] INT           NOT NULL,
    [NUM_SUBM_UNITS_INTEGER]       INT           NULL,
    [INITIAL_MON_DATE]             DATETIME      NULL,
    [INITIAL_DMR_DUE_DATE]         DATETIME      NULL,
    [LMT_SET_MOD_TYPE_CODE]        VARCHAR (3)   NULL,
    [LMT_SET_MOD_EFFECTIVE_DATE]   DATETIME      NULL,
    [DATA_HASH]                    VARCHAR (100) NULL,
    CONSTRAINT [tmp_ms_xx_constraint_PK_LMT_SET_SCHD1] PRIMARY KEY CLUSTERED ([ICS_LMT_SET_SCHD_ID] ASC)
);
IF EXISTS (SELECT TOP 1 1 
           FROM   [dbo].[ICS_LMT_SET_SCHD])
    BEGIN
        INSERT INTO [dbo].[tmp_ms_xx_ICS_LMT_SET_SCHD] ([ICS_LMT_SET_SCHD_ID], [ICS_LMT_SET_ID], [NUM_UNITS_REP_PERIOD_INTEGER], [NUM_SUBM_UNITS_INTEGER], [INITIAL_MON_DATE], [INITIAL_DMR_DUE_DATE], [LMT_SET_MOD_TYPE_CODE], [LMT_SET_MOD_EFFECTIVE_DATE], [DATA_HASH], [ICS_COPY_MGP_LMT_SET_ID])
        SELECT   [ICS_LMT_SET_SCHD_ID],
                 [ICS_LMT_SET_ID],
                 [NUM_UNITS_REP_PERIOD_INTEGER],
                 [NUM_SUBM_UNITS_INTEGER],
                 [INITIAL_MON_DATE],
                 [INITIAL_DMR_DUE_DATE],
                 [LMT_SET_MOD_TYPE_CODE],
                 [LMT_SET_MOD_EFFECTIVE_DATE],
                 [DATA_HASH],
                 [ICS_COPY_MGP_LMT_SET_ID]
        FROM     [dbo].[ICS_LMT_SET_SCHD]
        ORDER BY [ICS_LMT_SET_SCHD_ID] ASC;
    END
DROP TABLE [dbo].[ICS_LMT_SET_SCHD];
EXECUTE sp_rename N'[dbo].[tmp_ms_xx_ICS_LMT_SET_SCHD]', N'ICS_LMT_SET_SCHD';
EXECUTE sp_rename N'[dbo].[tmp_ms_xx_constraint_PK_LMT_SET_SCHD1]', N'PK_LMT_SET_SCHD', N'OBJECT';
COMMIT TRANSACTION;
SET TRANSACTION ISOLATION LEVEL READ COMMITTED;

PRINT N'Creating Index [dbo].[ICS_LMT_SET_SCHD].[IX_LMT_SE_SC_IC_CO_MG_LM_SE_ID]...';

CREATE NONCLUSTERED INDEX [IX_LMT_SE_SC_IC_CO_MG_LM_SE_ID]
    ON [dbo].[ICS_LMT_SET_SCHD]([ICS_COPY_MGP_LMT_SET_ID] ASC);

PRINT N'Creating Index [dbo].[ICS_LMT_SET_SCHD].[IX_LMT_SET_SCHD_ICS_LMT_SET_ID]...';

CREATE NONCLUSTERED INDEX [IX_LMT_SET_SCHD_ICS_LMT_SET_ID]
    ON [dbo].[ICS_LMT_SET_SCHD]([ICS_LMT_SET_ID] ASC);

PRINT N'Starting rebuilding table [dbo].[ICS_LMT_SET_STAT]...';

BEGIN TRANSACTION;
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;
SET XACT_ABORT ON;
CREATE TABLE [dbo].[tmp_ms_xx_ICS_LMT_SET_STAT] (
    [ICS_LMT_SET_STAT_ID]     VARCHAR (36)  NOT NULL,
    [ICS_COPY_MGP_LMT_SET_ID] VARCHAR (36)  NULL,
    [ICS_LMT_SET_ID]          VARCHAR (36)  NULL,
    [LMT_SET_STAT_IND]        CHAR (1)      NOT NULL,
    [LMT_SET_STAT_START_DATE] DATETIME      NOT NULL,
    [LMT_SET_STAT_REASON_TXT] VARCHAR (100) NULL,
    [DATA_HASH]               VARCHAR (100) NULL,
    CONSTRAINT [tmp_ms_xx_constraint_PK_LMT_SET_STAT1] PRIMARY KEY CLUSTERED ([ICS_LMT_SET_STAT_ID] ASC)
);
IF EXISTS (SELECT TOP 1 1 
           FROM   [dbo].[ICS_LMT_SET_STAT])
    BEGIN
        INSERT INTO [dbo].[tmp_ms_xx_ICS_LMT_SET_STAT] ([ICS_LMT_SET_STAT_ID], [ICS_LMT_SET_ID], [LMT_SET_STAT_IND], [LMT_SET_STAT_START_DATE], [LMT_SET_STAT_REASON_TXT], [DATA_HASH], [ICS_COPY_MGP_LMT_SET_ID])
        SELECT   [ICS_LMT_SET_STAT_ID],
                 [ICS_LMT_SET_ID],
                 [LMT_SET_STAT_IND],
                 [LMT_SET_STAT_START_DATE],
                 [LMT_SET_STAT_REASON_TXT],
                 [DATA_HASH],
                 [ICS_COPY_MGP_LMT_SET_ID]
        FROM     [dbo].[ICS_LMT_SET_STAT]
        ORDER BY [ICS_LMT_SET_STAT_ID] ASC;
    END
DROP TABLE [dbo].[ICS_LMT_SET_STAT];
EXECUTE sp_rename N'[dbo].[tmp_ms_xx_ICS_LMT_SET_STAT]', N'ICS_LMT_SET_STAT';
EXECUTE sp_rename N'[dbo].[tmp_ms_xx_constraint_PK_LMT_SET_STAT1]', N'PK_LMT_SET_STAT', N'OBJECT';
COMMIT TRANSACTION;
SET TRANSACTION ISOLATION LEVEL READ COMMITTED;

PRINT N'Creating Index [dbo].[ICS_LMT_SET_STAT].[IX_LMT_SE_ST_IC_CO_MG_LM_SE_ID]...';

CREATE NONCLUSTERED INDEX [IX_LMT_SE_ST_IC_CO_MG_LM_SE_ID]
    ON [dbo].[ICS_LMT_SET_STAT]([ICS_COPY_MGP_LMT_SET_ID] ASC);

PRINT N'Creating Index [dbo].[ICS_LMT_SET_STAT].[IX_LMT_SET_STAT_ICS_LMT_SET_ID]...';

CREATE NONCLUSTERED INDEX [IX_LMT_SET_STAT_ICS_LMT_SET_ID]
    ON [dbo].[ICS_LMT_SET_STAT]([ICS_LMT_SET_ID] ASC);

PRINT N'Starting rebuilding table [dbo].[ICS_LMTS]...';

BEGIN TRANSACTION;
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;
SET XACT_ABORT ON;
CREATE TABLE [dbo].[tmp_ms_xx_ICS_LMTS] (
    [ICS_LMTS_ID]                    VARCHAR (36)  NOT NULL,
    [ICS_PAYLOAD_ID]                 VARCHAR (36)  NOT NULL,
    [SRC_SYSTM_IDENT]                VARCHAR (50)  NULL,
    [TRANSACTION_TYPE]               CHAR (1)      NULL,
    [TRANSACTION_TIMESTAMP]          DATETIME      NULL,
    [PRMT_IDENT]                     CHAR (9)      NOT NULL,
    [PRMT_FEATR_IDENT]               VARCHAR (4)   NOT NULL,
    [LMT_SET_DESIGNATOR]             VARCHAR (2)   NOT NULL,
    [PARAM_CODE]                     VARCHAR (5)   NOT NULL,
    [MON_SITE_DESC_CODE]             VARCHAR (3)   NOT NULL,
    [LMT_SEASON_NUM]                 INT           NOT NULL,
    [LMT_START_DATE]                 DATETIME      NOT NULL,
    [LMT_END_DATE]                   DATETIME      NOT NULL,
    [LMT_TYPE_CODE]                  VARCHAR (3)   NULL,
    [SMPL_TYPE_TXT]                  VARCHAR (3)   NULL,
    [FREQ_OF_ANALYSIS_CODE]          VARCHAR (5)   NULL,
    [ELIGIBLE_FOR_BURDEN_REDUCTION]  CHAR (1)      NULL,
    [LMT_STAY_TYPE_CODE]             CHAR (1)      NULL,
    [STAY_START_DATE]                DATETIME      NULL,
    [STAY_END_DATE]                  DATETIME      NULL,
    [STAY_REASON_TXT]                VARCHAR (500) NULL,
    [CALCULATE_VIOL_IND]             CHAR (1)      NULL,
    [ENFRC_ACTN_IDENT]               VARCHAR (20)  NULL,
    [FINAL_ORDER_IDENT]              INT           NULL,
    [BASIS_OF_LMT]                   VARCHAR (3)   NULL,
    [LMT_MOD_TYPE_CODE]              VARCHAR (3)   NULL,
    [LMT_MOD_EFFECTIVE_DATE]         DATETIME      NULL,
    [LMT_MOD_TYPE_STAY_REASON_TXT]   VARCHAR (500) NULL,
    [LMTS_USR_DFND_FLD_1]            CHAR (1)      NULL,
    [LMTS_USR_DFND_FLD_2]            VARCHAR (30)  NULL,
    [LMTS_USR_DFND_FLD_3]            VARCHAR (150) NULL,
    [CONCEN_NUM_COND_UNIT_MEAS_CODE] VARCHAR (2)   NULL,
    [QTY_NUM_COND_UNIT_MEAS_CODE]    VARCHAR (2)   NULL,
    [KEY_HASH]                       VARCHAR (100) NULL,
    [DATA_HASH]                      VARCHAR (100) NULL,
    CONSTRAINT [tmp_ms_xx_constraint_PK_LMTS1] PRIMARY KEY CLUSTERED ([ICS_LMTS_ID] ASC)
);
IF EXISTS (SELECT TOP 1 1 
           FROM   [dbo].[ICS_LMTS])
    BEGIN
        INSERT INTO [dbo].[tmp_ms_xx_ICS_LMTS] ([ICS_LMTS_ID], [ICS_PAYLOAD_ID], [SRC_SYSTM_IDENT], [TRANSACTION_TYPE], [TRANSACTION_TIMESTAMP], [PRMT_IDENT], [PRMT_FEATR_IDENT], [LMT_SET_DESIGNATOR], [PARAM_CODE], [MON_SITE_DESC_CODE], [LMT_SEASON_NUM], [LMT_START_DATE], [LMT_END_DATE], [LMT_TYPE_CODE], [SMPL_TYPE_TXT], [FREQ_OF_ANALYSIS_CODE], [ELIGIBLE_FOR_BURDEN_REDUCTION], [LMT_STAY_TYPE_CODE], [STAY_START_DATE], [STAY_END_DATE], [STAY_REASON_TXT], [CALCULATE_VIOL_IND], [ENFRC_ACTN_IDENT], [FINAL_ORDER_IDENT], [BASIS_OF_LMT], [LMT_MOD_TYPE_CODE], [LMT_MOD_EFFECTIVE_DATE], [LMTS_USR_DFND_FLD_1], [LMTS_USR_DFND_FLD_2], [LMTS_USR_DFND_FLD_3], [CONCEN_NUM_COND_UNIT_MEAS_CODE], [QTY_NUM_COND_UNIT_MEAS_CODE], [KEY_HASH], [DATA_HASH])
        SELECT   [ICS_LMTS_ID],
                 [ICS_PAYLOAD_ID],
                 [SRC_SYSTM_IDENT],
                 [TRANSACTION_TYPE],
                 [TRANSACTION_TIMESTAMP],
                 [PRMT_IDENT],
                 [PRMT_FEATR_IDENT],
                 [LMT_SET_DESIGNATOR],
                 [PARAM_CODE],
                 [MON_SITE_DESC_CODE],
                 [LMT_SEASON_NUM],
                 [LMT_START_DATE],
                 [LMT_END_DATE],
                 [LMT_TYPE_CODE],
                 [SMPL_TYPE_TXT],
                 [FREQ_OF_ANALYSIS_CODE],
                 [ELIGIBLE_FOR_BURDEN_REDUCTION],
                 [LMT_STAY_TYPE_CODE],
                 [STAY_START_DATE],
                 [STAY_END_DATE],
                 [STAY_REASON_TXT],
                 [CALCULATE_VIOL_IND],
                 [ENFRC_ACTN_IDENT],
                 [FINAL_ORDER_IDENT],
                 [BASIS_OF_LMT],
                 [LMT_MOD_TYPE_CODE],
                 [LMT_MOD_EFFECTIVE_DATE],
                 [LMTS_USR_DFND_FLD_1],
                 [LMTS_USR_DFND_FLD_2],
                 [LMTS_USR_DFND_FLD_3],
                 [CONCEN_NUM_COND_UNIT_MEAS_CODE],
                 [QTY_NUM_COND_UNIT_MEAS_CODE],
                 [KEY_HASH],
                 [DATA_HASH]
        FROM     [dbo].[ICS_LMTS]
        ORDER BY [ICS_LMTS_ID] ASC;
    END
DROP TABLE [dbo].[ICS_LMTS];
EXECUTE sp_rename N'[dbo].[tmp_ms_xx_ICS_LMTS]', N'ICS_LMTS';
EXECUTE sp_rename N'[dbo].[tmp_ms_xx_constraint_PK_LMTS1]', N'PK_LMTS', N'OBJECT';
COMMIT TRANSACTION;
SET TRANSACTION ISOLATION LEVEL READ COMMITTED;

PRINT N'Creating Index [dbo].[ICS_LMTS].[IX_LMTS_ICS_PAYLOAD_ID]...';

CREATE NONCLUSTERED INDEX [IX_LMTS_ICS_PAYLOAD_ID]
    ON [dbo].[ICS_LMTS]([ICS_PAYLOAD_ID] ASC);

PRINT N'Creating Index [dbo].[ICS_LMTS].[IX_LM_PR_ID_PR_FE_ID_LM_SE_DS]...';

CREATE UNIQUE NONCLUSTERED INDEX [IX_LM_PR_ID_PR_FE_ID_LM_SE_DS]
    ON [dbo].[ICS_LMTS]([PRMT_IDENT] ASC, [PRMT_FEATR_IDENT] ASC, [LMT_SET_DESIGNATOR] ASC, [PARAM_CODE] ASC, [MON_SITE_DESC_CODE] ASC, [LMT_SEASON_NUM] ASC, [LMT_START_DATE] ASC, [LMT_END_DATE] ASC);

PRINT N'Starting rebuilding table [dbo].[ICS_MNUR_LTTR_PRCSS_WW_STOR]...';

BEGIN TRANSACTION;
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;
SET XACT_ABORT ON;
CREATE TABLE [dbo].[tmp_ms_xx_ICS_MNUR_LTTR_PRCSS_WW_STOR] (
    [ICS_MNUR_LTTR_PRCSS_WW_STOR_ID]      VARCHAR (36)  NOT NULL,
    [ICS_CAFO_PRMT_ID]                    VARCHAR (36)  NULL,
    [ICS_CAFO_INSP_ID]                    VARCHAR (36)  NULL,
    [MNUR_LTTR_PRCSS_WW_STOR_TYPE]        VARCHAR (3)   NOT NULL,
    [OTHR_STOR_TYPE_NAME]                 VARCHAR (50)  NULL,
    [STOR_TTL_CPCTY_MEAS]                 INT           NULL,
    [DAYS_OF_STOR]                        INT           NULL,
    [CAFOMLPW_UNIT]                       VARCHAR (3)   NULL,
    [CAFOMLPW_STOR_WITHIN_DSGN_CPCTY]     VARCHAR (3)   NULL,
    [CAFOMLPW_STOR_WITHIN_DSGN_CPCTY_TXT] VARCHAR (500) NULL,
    [DATA_HASH]                           VARCHAR (100) NULL,
    CONSTRAINT [tmp_ms_xx_constraint_PK_MNUR_LTTR_PRCSS_WW_STOR1] PRIMARY KEY CLUSTERED ([ICS_MNUR_LTTR_PRCSS_WW_STOR_ID] ASC)
);
IF EXISTS (SELECT TOP 1 1 
           FROM   [dbo].[ICS_MNUR_LTTR_PRCSS_WW_STOR])
    BEGIN
        INSERT INTO [dbo].[tmp_ms_xx_ICS_MNUR_LTTR_PRCSS_WW_STOR] ([ICS_MNUR_LTTR_PRCSS_WW_STOR_ID], [ICS_CAFO_PRMT_ID], [ICS_CAFO_INSP_ID], [MNUR_LTTR_PRCSS_WW_STOR_TYPE], [OTHR_STOR_TYPE_NAME], [STOR_TTL_CPCTY_MEAS], [DAYS_OF_STOR], [DATA_HASH])
        SELECT   [ICS_MNUR_LTTR_PRCSS_WW_STOR_ID],
                 [ICS_CAFO_PRMT_ID],
                 [ICS_CAFO_INSP_ID],
                 [MNUR_LTTR_PRCSS_WW_STOR_TYPE],
                 [OTHR_STOR_TYPE_NAME],
                 [STOR_TTL_CPCTY_MEAS],
                 [DAYS_OF_STOR],
                 [DATA_HASH]
        FROM     [dbo].[ICS_MNUR_LTTR_PRCSS_WW_STOR]
        ORDER BY [ICS_MNUR_LTTR_PRCSS_WW_STOR_ID] ASC;
    END
DROP TABLE [dbo].[ICS_MNUR_LTTR_PRCSS_WW_STOR];
EXECUTE sp_rename N'[dbo].[tmp_ms_xx_ICS_MNUR_LTTR_PRCSS_WW_STOR]', N'ICS_MNUR_LTTR_PRCSS_WW_STOR';
EXECUTE sp_rename N'[dbo].[tmp_ms_xx_constraint_PK_MNUR_LTTR_PRCSS_WW_STOR1]', N'PK_MNUR_LTTR_PRCSS_WW_STOR', N'OBJECT';
COMMIT TRANSACTION;
SET TRANSACTION ISOLATION LEVEL READ COMMITTED;

PRINT N'Creating Index [dbo].[ICS_MNUR_LTTR_PRCSS_WW_STOR].[IX_MNU_LT_PR_WW_ST_IC_CA_IN_ID]...';

CREATE NONCLUSTERED INDEX [IX_MNU_LT_PR_WW_ST_IC_CA_IN_ID]
    ON [dbo].[ICS_MNUR_LTTR_PRCSS_WW_STOR]([ICS_CAFO_INSP_ID] ASC);

PRINT N'Creating Index [dbo].[ICS_MNUR_LTTR_PRCSS_WW_STOR].[IX_MNU_LT_PR_WW_ST_IC_CA_PR_ID]...';

CREATE NONCLUSTERED INDEX [IX_MNU_LT_PR_WW_ST_IC_CA_PR_ID]
    ON [dbo].[ICS_MNUR_LTTR_PRCSS_WW_STOR]([ICS_CAFO_PRMT_ID] ASC);

PRINT N'Starting rebuilding table [dbo].[ICS_PATHOGEN_REDUCTION_TYPE]...';

BEGIN TRANSACTION;
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;
SET XACT_ABORT ON;
CREATE TABLE [dbo].[tmp_ms_xx_ICS_PATHOGEN_REDUCTION_TYPE] (
    [ICS_PATHOGEN_REDUCTION_TYPE_ID] VARCHAR (36)  NOT NULL,
    [ICS_BS_MGMT_PRACTICE_ID]        VARCHAR (36)  NULL,
    [ICS_PRMT_BS_MGMT_PRACTICE_ID]   VARCHAR (36)  NULL,
    [PATHOGEN_REDUCTION_TYPE_CODE]   VARCHAR (3)   NOT NULL,
    [DATA_HASH]                      VARCHAR (100) NULL,
    CONSTRAINT [tmp_ms_xx_constraint_PK_PATHOGEN_REDUCTION_TYPE1] PRIMARY KEY CLUSTERED ([ICS_PATHOGEN_REDUCTION_TYPE_ID] ASC)
);
IF EXISTS (SELECT TOP 1 1 
           FROM   [dbo].[ICS_PATHOGEN_REDUCTION_TYPE])
    BEGIN
        INSERT INTO [dbo].[tmp_ms_xx_ICS_PATHOGEN_REDUCTION_TYPE] ([ICS_PATHOGEN_REDUCTION_TYPE_ID], [PATHOGEN_REDUCTION_TYPE_CODE], [DATA_HASH])
        SELECT   [ICS_PATHOGEN_REDUCTION_TYPE_ID],
                 [PATHOGEN_REDUCTION_TYPE_CODE],
                 [DATA_HASH]
        FROM     [dbo].[ICS_PATHOGEN_REDUCTION_TYPE]
        ORDER BY [ICS_PATHOGEN_REDUCTION_TYPE_ID] ASC;
    END
DROP TABLE [dbo].[ICS_PATHOGEN_REDUCTION_TYPE];
EXECUTE sp_rename N'[dbo].[tmp_ms_xx_ICS_PATHOGEN_REDUCTION_TYPE]', N'ICS_PATHOGEN_REDUCTION_TYPE';
EXECUTE sp_rename N'[dbo].[tmp_ms_xx_constraint_PK_PATHOGEN_REDUCTION_TYPE1]', N'PK_PATHOGEN_REDUCTION_TYPE', N'OBJECT';
COMMIT TRANSACTION;
SET TRANSACTION ISOLATION LEVEL READ COMMITTED;

PRINT N'Creating Index [dbo].[ICS_PATHOGEN_REDUCTION_TYPE].[IX_PTH_RD_TY_IC_PR_BS_MG_PR_ID]...';

CREATE NONCLUSTERED INDEX [IX_PTH_RD_TY_IC_PR_BS_MG_PR_ID]
    ON [dbo].[ICS_PATHOGEN_REDUCTION_TYPE]([ICS_PRMT_BS_MGMT_PRACTICE_ID] ASC);

PRINT N'Creating Index [dbo].[ICS_PATHOGEN_REDUCTION_TYPE].[IX_PTH_RDC_TYP_ICS_BS_MG_PR_ID]...';

CREATE NONCLUSTERED INDEX [IX_PTH_RDC_TYP_ICS_BS_MG_PR_ID]
    ON [dbo].[ICS_PATHOGEN_REDUCTION_TYPE]([ICS_BS_MGMT_PRACTICE_ID] ASC);

PRINT N'Altering Table [dbo].[ICS_PAYLOAD]...';

ALTER TABLE [dbo].[ICS_PAYLOAD] ALTER COLUMN [BASE_TABLE_NAME] VARCHAR (50) NULL;

PRINT N'Starting rebuilding table [dbo].[ICS_PRETR_PRMT]...';

BEGIN TRANSACTION;
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;
SET XACT_ABORT ON;
CREATE TABLE [dbo].[tmp_ms_xx_ICS_PRETR_PRMT] (
    [ICS_PRETR_PRMT_ID]            VARCHAR (36)  NOT NULL,
    [ICS_PAYLOAD_ID]               VARCHAR (36)  NOT NULL,
    [SRC_SYSTM_IDENT]              VARCHAR (50)  NULL,
    [TRANSACTION_TYPE]             CHAR (1)      NULL,
    [TRANSACTION_TIMESTAMP]        DATETIME      NULL,
    [PRMT_IDENT]                   CHAR (9)      NOT NULL,
    [PRETR_PROG_REQD_IND_CODE]     CHAR (1)      NULL,
    [CONTROL_AUTH_ST_AGNCY_CODE]   CHAR (2)      NULL,
    [CONTROL_AUTH_RGNL_AGNCY_CODE] VARCHAR (2)   NULL,
    [CONTROL_AUTH_NPDES_IDENT]     CHAR (9)      NULL,
    [PRETR_PROG_APRVD_DATE]        DATETIME      NULL,
    [RCVG_RCRA_WASTE_IND]          CHAR (1)      NULL,
    [RCVG_REMEDIATION_WASTE_IND]   CHAR (1)      NULL,
    [KEY_HASH]                     VARCHAR (100) NULL,
    [DATA_HASH]                    VARCHAR (100) NULL,
    CONSTRAINT [tmp_ms_xx_constraint_PK_PRETR_PRMT1] PRIMARY KEY CLUSTERED ([ICS_PRETR_PRMT_ID] ASC)
);
IF EXISTS (SELECT TOP 1 1 
           FROM   [dbo].[ICS_PRETR_PRMT])
    BEGIN
        INSERT INTO [dbo].[tmp_ms_xx_ICS_PRETR_PRMT] ([ICS_PRETR_PRMT_ID], [ICS_PAYLOAD_ID], [SRC_SYSTM_IDENT], [TRANSACTION_TYPE], [TRANSACTION_TIMESTAMP], [PRMT_IDENT], [PRETR_PROG_REQD_IND_CODE], [CONTROL_AUTH_ST_AGNCY_CODE], [CONTROL_AUTH_RGNL_AGNCY_CODE], [CONTROL_AUTH_NPDES_IDENT], [PRETR_PROG_APRVD_DATE], [KEY_HASH], [DATA_HASH])
        SELECT   [ICS_PRETR_PRMT_ID],
                 [ICS_PAYLOAD_ID],
                 [SRC_SYSTM_IDENT],
                 [TRANSACTION_TYPE],
                 [TRANSACTION_TIMESTAMP],
                 [PRMT_IDENT],
                 [PRETR_PROG_REQD_IND_CODE],
                 [CONTROL_AUTH_ST_AGNCY_CODE],
                 [CONTROL_AUTH_RGNL_AGNCY_CODE],
                 [CONTROL_AUTH_NPDES_IDENT],
                 [PRETR_PROG_APRVD_DATE],
                 [KEY_HASH],
                 [DATA_HASH]
        FROM     [dbo].[ICS_PRETR_PRMT]
        ORDER BY [ICS_PRETR_PRMT_ID] ASC;
    END
DROP TABLE [dbo].[ICS_PRETR_PRMT];
EXECUTE sp_rename N'[dbo].[tmp_ms_xx_ICS_PRETR_PRMT]', N'ICS_PRETR_PRMT';
EXECUTE sp_rename N'[dbo].[tmp_ms_xx_constraint_PK_PRETR_PRMT1]', N'PK_PRETR_PRMT', N'OBJECT';
COMMIT TRANSACTION;
SET TRANSACTION ISOLATION LEVEL READ COMMITTED;

PRINT N'Creating Index [dbo].[ICS_PRETR_PRMT].[IX_PRETR_PRMT_ICS_PAYLOAD_ID]...';

CREATE NONCLUSTERED INDEX [IX_PRETR_PRMT_ICS_PAYLOAD_ID]
    ON [dbo].[ICS_PRETR_PRMT]([ICS_PAYLOAD_ID] ASC);

PRINT N'Creating Index [dbo].[ICS_PRETR_PRMT].[IX_PRETR_PRMT_PRMT_IDENT]...';

CREATE UNIQUE NONCLUSTERED INDEX [IX_PRETR_PRMT_PRMT_IDENT]
    ON [dbo].[ICS_PRETR_PRMT]([PRMT_IDENT] ASC);

PRINT N'Altering Table [dbo].[ICS_PROJ_SRCS_FUND]...';

ALTER TABLE [dbo].[ICS_PROJ_SRCS_FUND] DROP COLUMN [ICS_SWMS_4_PROG_REP_ID];

PRINT N'Altering Table [dbo].[ICS_SATL_COLL_SYSTM]...';

ALTER TABLE [dbo].[ICS_SATL_COLL_SYSTM] DROP COLUMN [ICS_CSO_PRMT_ID];

PRINT N'Altering Table [dbo].[ICS_SEP]...';

ALTER TABLE [dbo].[ICS_SEP] ALTER COLUMN [SEP_PNLTY_ASSESSMENT_AMT] DECIMAL (14, 2) NULL;

PRINT N'Altering Table [dbo].[ICS_SSO_INSP]...';

ALTER TABLE [dbo].[ICS_SSO_INSP] ALTER COLUMN [DURATION_SSO_OVRFLW_EVT] DECIMAL (6, 2) NULL;

PRINT N'Altering Table [dbo].[ICS_SSO_STPS]...';

ALTER TABLE [dbo].[ICS_SSO_STPS] DROP COLUMN [ICS_SSO_EVT_REP_ID];

PRINT N'Altering Table [dbo].[ICS_SSO_SYSTM_COMP]...';

ALTER TABLE [dbo].[ICS_SSO_SYSTM_COMP] DROP COLUMN [ICS_SSO_EVT_REP_ID];

PRINT N'Starting rebuilding table [dbo].[ICS_SURF_DSPL_SITE]...';

BEGIN TRANSACTION;
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;
SET XACT_ABORT ON;
CREATE TABLE [dbo].[tmp_ms_xx_ICS_SURF_DSPL_SITE] (
    [ICS_SURF_DSPL_SITE_ID]  VARCHAR (36)   NOT NULL,
    [ICS_DSCH_MON_REP_ID]    VARCHAR (36)   NOT NULL,
    [PATHOGEN_REDUCTION_IND] CHAR (1)       NULL,
    [VECTOR_REDUCTION_IND]   CHAR (1)       NULL,
    [MGMT_PRACTICE_IND]      CHAR (1)       NULL,
    [CERT_STATEMENT_IND]     CHAR (1)       NULL,
    [CERT_FIRST_NAME]        VARCHAR (30)   NULL,
    [CERT_LAST_NAME]         VARCHAR (30)   NULL,
    [CLASS_A_ALT_USED]       VARCHAR (3)    NULL,
    [CLASS_A_ALTS_TXT]       VARCHAR (4000) NULL,
    [CLASS_B_ALT_USED]       VARCHAR (3)    NULL,
    [CLASS_B_ALTS_TXT]       VARCHAR (4000) NULL,
    [VAR_ALT_USED]           VARCHAR (3)    NULL,
    [VAR_ALTS_TXT]           VARCHAR (4000) NULL,
    [DATA_HASH]              VARCHAR (100)  NULL,
    CONSTRAINT [tmp_ms_xx_constraint_PK_SURF_DSPL_SITE1] PRIMARY KEY CLUSTERED ([ICS_SURF_DSPL_SITE_ID] ASC)
);
IF EXISTS (SELECT TOP 1 1 
           FROM   [dbo].[ICS_SURF_DSPL_SITE])
    BEGIN
        INSERT INTO [dbo].[tmp_ms_xx_ICS_SURF_DSPL_SITE] ([ICS_SURF_DSPL_SITE_ID], [ICS_DSCH_MON_REP_ID], [PATHOGEN_REDUCTION_IND], [VECTOR_REDUCTION_IND], [CERT_STATEMENT_IND], [CERT_FIRST_NAME], [CERT_LAST_NAME], [CLASS_A_ALT_USED], [CLASS_A_ALTS_TXT], [CLASS_B_ALT_USED], [CLASS_B_ALTS_TXT], [VAR_ALT_USED], [VAR_ALTS_TXT], [DATA_HASH])
        SELECT   [ICS_SURF_DSPL_SITE_ID],
                 [ICS_DSCH_MON_REP_ID],
                 [PATHOGEN_REDUCTION_IND],
                 [VECTOR_REDUCTION_IND],
                 [CERT_STATEMENT_IND],
                 [CERT_FIRST_NAME],
                 [CERT_LAST_NAME],
                 [CLASS_A_ALT_USED],
                 [CLASS_A_ALTS_TXT],
                 [CLASS_B_ALT_USED],
                 [CLASS_B_ALTS_TXT],
                 [VAR_ALT_USED],
                 [VAR_ALTS_TXT],
                 [DATA_HASH]
        FROM     [dbo].[ICS_SURF_DSPL_SITE]
        ORDER BY [ICS_SURF_DSPL_SITE_ID] ASC;
    END
DROP TABLE [dbo].[ICS_SURF_DSPL_SITE];
EXECUTE sp_rename N'[dbo].[tmp_ms_xx_ICS_SURF_DSPL_SITE]', N'ICS_SURF_DSPL_SITE';
EXECUTE sp_rename N'[dbo].[tmp_ms_xx_constraint_PK_SURF_DSPL_SITE1]', N'PK_SURF_DSPL_SITE', N'OBJECT';
COMMIT TRANSACTION;
SET TRANSACTION ISOLATION LEVEL READ COMMITTED;

PRINT N'Creating Index [dbo].[ICS_SURF_DSPL_SITE].[IX_SUR_DSP_SIT_ICS_DS_MO_RE_ID]...';

CREATE NONCLUSTERED INDEX [IX_SUR_DSP_SIT_ICS_DS_MO_RE_ID]
    ON [dbo].[ICS_SURF_DSPL_SITE]([ICS_DSCH_MON_REP_ID] ASC);

PRINT N'Starting rebuilding table [dbo].[ICS_SW_CNST_PRMT]...';

BEGIN TRANSACTION;
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;
SET XACT_ABORT ON;
CREATE TABLE [dbo].[tmp_ms_xx_ICS_SW_CNST_PRMT] (
    [ICS_SW_CNST_PRMT_ID]                     VARCHAR (36)    NOT NULL,
    [ICS_PAYLOAD_ID]                          VARCHAR (36)    NOT NULL,
    [SRC_SYSTM_IDENT]                         VARCHAR (50)    NULL,
    [TRANSACTION_TYPE]                        CHAR (1)        NULL,
    [TRANSACTION_TIMESTAMP]                   DATETIME        NULL,
    [PRMT_IDENT]                              CHAR (9)        NOT NULL,
    [ST_WTR_BODY_NAME]                        VARCHAR (50)    NULL,
    [RCVG_MS_4_NAME]                          VARCHAR (50)    NULL,
    [IMPAIRED_WTR_IND]                        CHAR (1)        NULL,
    [HIST_PROP_IND]                           CHAR (1)        NULL,
    [HIST_PROP_CRIT_MET_CODE]                 VARCHAR (3)     NULL,
    [SPECIES_CRIT_HABITAT_IND]                CHAR (1)        NULL,
    [SPECIES_CRIT_MET_CODE]                   VARCHAR (3)     NULL,
    [INDST_ACTY_SIZE]                         DECIMAL (10, 2) NULL,
    [PROJ_TYPE_CODE]                          VARCHAR (3)     NULL,
    [EST_START_DATE]                          DATETIME        NULL,
    [EST_COMPLETE_DATE]                       DATETIME        NULL,
    [EST_AREA_DISTURBED_ACRES_NUM]            DECIMAL (10, 2) NULL,
    [PROJ_PLAN_SIZE_CODE]                     VARCHAR (3)     NULL,
    [STRCT_DEMOED_IND]                        CHAR (1)        NULL,
    [STRCT_DEMOED_FLOOR_SPACE_IND]            CHAR (1)        NULL,
    [PREDEV_LAND_USE_IND]                     CHAR (1)        NULL,
    [ERTH_DISTRB_ACTIVITIES_IND]              CHAR (1)        NULL,
    [ERTH_DISTRB_EMRGCY_IND]                  CHAR (1)        NULL,
    [PREVIOUS_SW_DSCH_IND]                    CHAR (1)        NULL,
    [OTHR_PRMT_IDENT]                         VARCHAR (30)    NULL,
    [CGP_IND]                                 CHAR (1)        NULL,
    [MS_4_DSCH_IND]                           CHAR (1)        NULL,
    [WTR_PROX_IND]                            CHAR (1)        NULL,
    [ANTIDEG_IND]                             CHAR (1)        NULL,
    [TRTMNT_CHEMS_IND]                        CHAR (1)        NULL,
    [CATIONIC_CHEMS_IND]                      CHAR (1)        NULL,
    [CATIONIC_CHEMS_AUTH_IND]                 CHAR (1)        NULL,
    [SWPPP_PREP_IND]                          CHAR (1)        NULL,
    [CNST_SITE_TTL_AREA]                      DECIMAL (10, 2) NULL,
    [POST_CNST_TTL_IMPERVIOUS_AREA]           DECIMAL (10, 2) NULL,
    [SOIL_FILL_MATERIAL_DESC_TXT]             VARCHAR (4000)  NULL,
    [RUNOFF_COEFFICIENT_POST_CNST]            DECIMAL (3, 2)  NULL,
    [SUBSURFACE_ERTH_DISTURBANCE_IND]         CHAR (1)        NULL,
    [PRIOR_SURVEYS_EVALS_IND]                 CHAR (1)        NULL,
    [SUBSURFACE_ERTH_DISTURBANCE_CONTROL_IND] CHAR (1)        NULL,
    [NOT_TERM_DATE]                           DATETIME        NULL,
    [NOT_SIGN_DATE]                           DATETIME        NULL,
    [NOT_POSTMARK_DATE]                       DATETIME        NULL,
    [NOT_RCVD_DATE]                           DATETIME        NULL,
    [LEW_AUTH_DATE]                           DATETIME        NULL,
    [KEY_HASH]                                VARCHAR (100)   NULL,
    [DATA_HASH]                               VARCHAR (100)   NULL,
    CONSTRAINT [tmp_ms_xx_constraint_PK_SW_CNST_PRMT1] PRIMARY KEY CLUSTERED ([ICS_SW_CNST_PRMT_ID] ASC)
);
IF EXISTS (SELECT TOP 1 1 
           FROM   [dbo].[ICS_SW_CNST_PRMT])
    BEGIN
        INSERT INTO [dbo].[tmp_ms_xx_ICS_SW_CNST_PRMT] ([ICS_SW_CNST_PRMT_ID], [ICS_PAYLOAD_ID], [SRC_SYSTM_IDENT], [TRANSACTION_TYPE], [TRANSACTION_TIMESTAMP], [PRMT_IDENT], [ST_WTR_BODY_NAME], [RCVG_MS_4_NAME], [IMPAIRED_WTR_IND], [HIST_PROP_IND], [HIST_PROP_CRIT_MET_CODE], [SPECIES_CRIT_HABITAT_IND], [SPECIES_CRIT_MET_CODE], [INDST_ACTY_SIZE], [PROJ_TYPE_CODE], [EST_START_DATE], [EST_COMPLETE_DATE], [EST_AREA_DISTURBED_ACRES_NUM], [PROJ_PLAN_SIZE_CODE], [STRCT_DEMOED_IND], [STRCT_DEMOED_FLOOR_SPACE_IND], [PREDEV_LAND_USE_IND], [ERTH_DISTRB_ACTIVITIES_IND], [ERTH_DISTRB_EMRGCY_IND], [PREVIOUS_SW_DSCH_IND], [OTHR_PRMT_IDENT], [CGP_IND], [MS_4_DSCH_IND], [WTR_PROX_IND], [ANTIDEG_IND], [TRTMNT_CHEMS_IND], [CATIONIC_CHEMS_IND], [CATIONIC_CHEMS_AUTH_IND], [SWPPP_PREP_IND], [PRIOR_SURVEYS_EVALS_IND], [KEY_HASH], [DATA_HASH])
        SELECT   [ICS_SW_CNST_PRMT_ID],
                 [ICS_PAYLOAD_ID],
                 [SRC_SYSTM_IDENT],
                 [TRANSACTION_TYPE],
                 [TRANSACTION_TIMESTAMP],
                 [PRMT_IDENT],
                 [ST_WTR_BODY_NAME],
                 [RCVG_MS_4_NAME],
                 [IMPAIRED_WTR_IND],
                 [HIST_PROP_IND],
                 [HIST_PROP_CRIT_MET_CODE],
                 [SPECIES_CRIT_HABITAT_IND],
                 [SPECIES_CRIT_MET_CODE],
                 [INDST_ACTY_SIZE],
                 [PROJ_TYPE_CODE],
                 [EST_START_DATE],
                 [EST_COMPLETE_DATE],
                 [EST_AREA_DISTURBED_ACRES_NUM],
                 [PROJ_PLAN_SIZE_CODE],
                 [STRCT_DEMOED_IND],
                 [STRCT_DEMOED_FLOOR_SPACE_IND],
                 [PREDEV_LAND_USE_IND],
                 [ERTH_DISTRB_ACTIVITIES_IND],
                 [ERTH_DISTRB_EMRGCY_IND],
                 [PREVIOUS_SW_DSCH_IND],
                 [OTHR_PRMT_IDENT],
                 [CGP_IND],
                 [MS_4_DSCH_IND],
                 [WTR_PROX_IND],
                 [ANTIDEG_IND],
                 [TRTMNT_CHEMS_IND],
                 [CATIONIC_CHEMS_IND],
                 [CATIONIC_CHEMS_AUTH_IND],
                 [SWPPP_PREP_IND],
                 [PRIOR_SURVEYS_EVALS_IND],
                 [KEY_HASH],
                 [DATA_HASH]
        FROM     [dbo].[ICS_SW_CNST_PRMT]
        ORDER BY [ICS_SW_CNST_PRMT_ID] ASC;
    END
DROP TABLE [dbo].[ICS_SW_CNST_PRMT];
EXECUTE sp_rename N'[dbo].[tmp_ms_xx_ICS_SW_CNST_PRMT]', N'ICS_SW_CNST_PRMT';
EXECUTE sp_rename N'[dbo].[tmp_ms_xx_constraint_PK_SW_CNST_PRMT1]', N'PK_SW_CNST_PRMT', N'OBJECT';
COMMIT TRANSACTION;
SET TRANSACTION ISOLATION LEVEL READ COMMITTED;

PRINT N'Creating Index [dbo].[ICS_SW_CNST_PRMT].[IX_SW_CNST_PRMT_ICS_PAYLOAD_ID]...';

CREATE NONCLUSTERED INDEX [IX_SW_CNST_PRMT_ICS_PAYLOAD_ID]
    ON [dbo].[ICS_SW_CNST_PRMT]([ICS_PAYLOAD_ID] ASC);

PRINT N'Creating Index [dbo].[ICS_SW_CNST_PRMT].[IX_SW_CNST_PRMT_PRMT_IDENT]...';

CREATE UNIQUE NONCLUSTERED INDEX [IX_SW_CNST_PRMT_PRMT_IDENT]
    ON [dbo].[ICS_SW_CNST_PRMT]([PRMT_IDENT] ASC);

PRINT N'Starting rebuilding table [dbo].[ICS_SW_INDST_PRMT]...';

BEGIN TRANSACTION;
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;
SET XACT_ABORT ON;
CREATE TABLE [dbo].[tmp_ms_xx_ICS_SW_INDST_PRMT] (
    [ICS_SW_INDST_PRMT_ID]           VARCHAR (36)    NOT NULL,
    [ICS_PAYLOAD_ID]                 VARCHAR (36)    NOT NULL,
    [SRC_SYSTM_IDENT]                VARCHAR (50)    NULL,
    [TRANSACTION_TYPE]               CHAR (1)        NULL,
    [TRANSACTION_TIMESTAMP]          DATETIME        NULL,
    [PRMT_IDENT]                     CHAR (9)        NOT NULL,
    [ST_WTR_BODY_NAME]               VARCHAR (50)    NULL,
    [RCVG_MS_4_NAME]                 VARCHAR (50)    NULL,
    [IMPAIRED_WTR_IND]               CHAR (1)        NULL,
    [HIST_PROP_IND]                  CHAR (1)        NULL,
    [HIST_PROP_CRIT_MET_CODE]        VARCHAR (3)     NULL,
    [SPECIES_CRIT_HABITAT_IND]       CHAR (1)        NULL,
    [SPECIES_CRIT_MET_CODE]          VARCHAR (3)     NULL,
    [INDST_ACTY_SIZE]                DECIMAL (10, 2) NULL,
    [WEB_ADDR_URL]                   VARCHAR (100)   NULL,
    [ACTIVITIES_EXPOSED_SW_TXT]      VARCHAR (4000)  NULL,
    [ASSC_POLLUTANTS_TXT]            VARCHAR (4000)  NULL,
    [CONTROL_MSR_TXT]                VARCHAR (4000)  NULL,
    [SCHD_CONTROL_MSR_TXT]           VARCHAR (4000)  NULL,
    [INDST_TTL_IMPERVIOUS_SURF_AREA] DECIMAL (10, 2) NULL,
    [TIER_TWO_IND]                   CHAR (1)        NULL,
    [TIER_THREE_IND]                 CHAR (1)        NULL,
    [KEY_HASH]                       VARCHAR (100)   NULL,
    [DATA_HASH]                      VARCHAR (100)   NULL,
    CONSTRAINT [tmp_ms_xx_constraint_PK_SW_INDST_PRMT1] PRIMARY KEY CLUSTERED ([ICS_SW_INDST_PRMT_ID] ASC)
);
IF EXISTS (SELECT TOP 1 1 
           FROM   [dbo].[ICS_SW_INDST_PRMT])
    BEGIN
        INSERT INTO [dbo].[tmp_ms_xx_ICS_SW_INDST_PRMT] ([ICS_SW_INDST_PRMT_ID], [ICS_PAYLOAD_ID], [SRC_SYSTM_IDENT], [TRANSACTION_TYPE], [TRANSACTION_TIMESTAMP], [PRMT_IDENT], [ST_WTR_BODY_NAME], [RCVG_MS_4_NAME], [IMPAIRED_WTR_IND], [HIST_PROP_IND], [HIST_PROP_CRIT_MET_CODE], [SPECIES_CRIT_HABITAT_IND], [SPECIES_CRIT_MET_CODE], [INDST_ACTY_SIZE], [WEB_ADDR_URL], [ACTIVITIES_EXPOSED_SW_TXT], [ASSC_POLLUTANTS_TXT], [CONTROL_MSR_TXT], [SCHD_CONTROL_MSR_TXT], [TIER_TWO_IND], [TIER_THREE_IND], [KEY_HASH], [DATA_HASH])
        SELECT   [ICS_SW_INDST_PRMT_ID],
                 [ICS_PAYLOAD_ID],
                 [SRC_SYSTM_IDENT],
                 [TRANSACTION_TYPE],
                 [TRANSACTION_TIMESTAMP],
                 [PRMT_IDENT],
                 [ST_WTR_BODY_NAME],
                 [RCVG_MS_4_NAME],
                 [IMPAIRED_WTR_IND],
                 [HIST_PROP_IND],
                 [HIST_PROP_CRIT_MET_CODE],
                 [SPECIES_CRIT_HABITAT_IND],
                 [SPECIES_CRIT_MET_CODE],
                 [INDST_ACTY_SIZE],
                 [WEB_ADDR_URL],
                 [ACTIVITIES_EXPOSED_SW_TXT],
                 [ASSC_POLLUTANTS_TXT],
                 [CONTROL_MSR_TXT],
                 [SCHD_CONTROL_MSR_TXT],
                 [TIER_TWO_IND],
                 [TIER_THREE_IND],
                 [KEY_HASH],
                 [DATA_HASH]
        FROM     [dbo].[ICS_SW_INDST_PRMT]
        ORDER BY [ICS_SW_INDST_PRMT_ID] ASC;
    END
DROP TABLE [dbo].[ICS_SW_INDST_PRMT];
EXECUTE sp_rename N'[dbo].[tmp_ms_xx_ICS_SW_INDST_PRMT]', N'ICS_SW_INDST_PRMT';
EXECUTE sp_rename N'[dbo].[tmp_ms_xx_constraint_PK_SW_INDST_PRMT1]', N'PK_SW_INDST_PRMT', N'OBJECT';
COMMIT TRANSACTION;
SET TRANSACTION ISOLATION LEVEL READ COMMITTED;

PRINT N'Creating Index [dbo].[ICS_SW_INDST_PRMT].[IX_SW_INDST_PRMT_ICS_PAYLOD_ID]...';

CREATE NONCLUSTERED INDEX [IX_SW_INDST_PRMT_ICS_PAYLOD_ID]
    ON [dbo].[ICS_SW_INDST_PRMT]([ICS_PAYLOAD_ID] ASC);

PRINT N'Creating Index [dbo].[ICS_SW_INDST_PRMT].[IX_SW_INDST_PRMT_PRMT_IDENT]...';

CREATE UNIQUE NONCLUSTERED INDEX [IX_SW_INDST_PRMT_PRMT_IDENT]
    ON [dbo].[ICS_SW_INDST_PRMT]([PRMT_IDENT] ASC);

PRINT N'Altering Table [dbo].[ICS_SW_UNPRMT_CNST_INSP]...';

ALTER TABLE [dbo].[ICS_SW_UNPRMT_CNST_INSP] ALTER COLUMN [EST_AREA_DISTURBED_ACRES_NUM] DECIMAL (10, 2) NULL;

PRINT N'Starting rebuilding table [dbo].[ICS_TMDL_POLLUTANTS]...';

BEGIN TRANSACTION;
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;
SET XACT_ABORT ON;
CREATE TABLE [dbo].[tmp_ms_xx_ICS_TMDL_POLLUTANTS] (
    [ICS_TMDL_POLLUTANTS_ID] VARCHAR (36)  NOT NULL,
    [ICS_POLUT_LIST_ID]      VARCHAR (36)  NOT NULL,
    [TMDL_IDENT]             VARCHAR (6)   NOT NULL,
    [TMDL_NAME]              VARCHAR (100) NOT NULL,
    [DATA_HASH]              VARCHAR (100) NULL,
    CONSTRAINT [tmp_ms_xx_constraint_PK_TMDL_POLLUTANTS1] PRIMARY KEY CLUSTERED ([ICS_TMDL_POLLUTANTS_ID] ASC)
);
IF EXISTS (SELECT TOP 1 1 
           FROM   [dbo].[ICS_TMDL_POLLUTANTS])
    BEGIN
        INSERT INTO [dbo].[tmp_ms_xx_ICS_TMDL_POLLUTANTS] ([ICS_TMDL_POLLUTANTS_ID], [TMDL_IDENT], [TMDL_NAME], [DATA_HASH])
        SELECT   [ICS_TMDL_POLLUTANTS_ID],
                 [TMDL_IDENT],
                 [TMDL_NAME],
                 [DATA_HASH]
        FROM     [dbo].[ICS_TMDL_POLLUTANTS]
        ORDER BY [ICS_TMDL_POLLUTANTS_ID] ASC;
    END
DROP TABLE [dbo].[ICS_TMDL_POLLUTANTS];
EXECUTE sp_rename N'[dbo].[tmp_ms_xx_ICS_TMDL_POLLUTANTS]', N'ICS_TMDL_POLLUTANTS';
EXECUTE sp_rename N'[dbo].[tmp_ms_xx_constraint_PK_TMDL_POLLUTANTS1]', N'PK_TMDL_POLLUTANTS', N'OBJECT';
COMMIT TRANSACTION;
SET TRANSACTION ISOLATION LEVEL READ COMMITTED;

PRINT N'Creating Index [dbo].[ICS_TMDL_POLLUTANTS].[IX_TMDL_PLLTN_ICS_PLUT_LIST_ID]...';

CREATE NONCLUSTERED INDEX [IX_TMDL_PLLTN_ICS_PLUT_LIST_ID]
    ON [dbo].[ICS_TMDL_POLLUTANTS]([ICS_POLUT_LIST_ID] ASC);

PRINT N'Starting rebuilding table [dbo].[ICS_UNPRMT_FAC]...';

BEGIN TRANSACTION;
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;
SET XACT_ABORT ON;
CREATE TABLE [dbo].[tmp_ms_xx_ICS_UNPRMT_FAC] (
    [ICS_UNPRMT_FAC_ID]          VARCHAR (36)    NOT NULL,
    [ICS_PAYLOAD_ID]             VARCHAR (36)    NOT NULL,
    [SRC_SYSTM_IDENT]            VARCHAR (50)    NULL,
    [TRANSACTION_TYPE]           CHAR (1)        NULL,
    [TRANSACTION_TIMESTAMP]      DATETIME        NULL,
    [PRMT_IDENT]                 CHAR (9)        NOT NULL,
    [LOCALITY_NAME]              VARCHAR (60)    NULL,
    [LOC_ADDR_CITY_CODE]         VARCHAR (12)    NULL,
    [LOC_ADDR_COUNTY_CODE]       CHAR (5)        NULL,
    [FAC_SITE_NAME]              VARCHAR (80)    NULL,
    [LOC_ADDR_TXT]               VARCHAR (50)    NULL,
    [SUPPL_LOC_TXT]              VARCHAR (50)    NULL,
    [LOC_ST_CODE]                CHAR (2)        NULL,
    [LOC_ZIP_CODE]               VARCHAR (14)    NULL,
    [LOC_COUNTRY_CODE]           VARCHAR (3)     NULL,
    [ORG_DUNS_NUM]               CHAR (9)        NULL,
    [ST_FAC_IDENT]               VARCHAR (12)    NULL,
    [ST_RGN_CODE]                VARCHAR (5)     NULL,
    [FAC_CONGR_DISTRICT_NUM]     INT             NULL,
    [FAC_TYPE_OF_OWNERSHIP_CODE] VARCHAR (3)     NULL,
    [FEDR_FAC_IDENT_NUM]         VARCHAR (12)    NULL,
    [FEDR_AGNCY_CODE]            VARCHAR (5)     NULL,
    [TRIBAL_LAND_CODE]           VARCHAR (9)     NULL,
    [CNST_PROJ_NAME]             VARCHAR (50)    NULL,
    [CNST_PROJ_LAT_MEAS]         DECIMAL (9, 7)  NULL,
    [CNST_PROJ_LONG_MEAS]        DECIMAL (10, 6) NULL,
    [SECTION_TOWNSHIP_RNG]       VARCHAR (50)    NULL,
    [FAC_CMNTS]                  VARCHAR (4000)  NULL,
    [FAC_USR_DFND_FLD_1]         VARCHAR (30)    NULL,
    [FAC_USR_DFND_FLD_2]         VARCHAR (30)    NULL,
    [FAC_USR_DFND_FLD_3]         VARCHAR (30)    NULL,
    [FAC_USR_DFND_FLD_4]         VARCHAR (30)    NULL,
    [FAC_USR_DFND_FLD_5]         VARCHAR (30)    NULL,
    [PRMT_CMNTS_TXT]             VARCHAR (4000)  NULL,
    [KEY_HASH]                   VARCHAR (100)   NULL,
    [DATA_HASH]                  VARCHAR (100)   NULL,
    CONSTRAINT [tmp_ms_xx_constraint_PK_UNPRMT_FAC1] PRIMARY KEY CLUSTERED ([ICS_UNPRMT_FAC_ID] ASC)
);
IF EXISTS (SELECT TOP 1 1 
           FROM   [dbo].[ICS_UNPRMT_FAC])
    BEGIN
        INSERT INTO [dbo].[tmp_ms_xx_ICS_UNPRMT_FAC] ([ICS_UNPRMT_FAC_ID], [ICS_PAYLOAD_ID], [SRC_SYSTM_IDENT], [TRANSACTION_TYPE], [TRANSACTION_TIMESTAMP], [PRMT_IDENT], [FAC_SITE_NAME], [LOC_ADDR_TXT], [SUPPL_LOC_TXT], [LOCALITY_NAME], [LOC_ADDR_CITY_CODE], [LOC_ADDR_COUNTY_CODE], [LOC_ST_CODE], [LOC_ZIP_CODE], [LOC_COUNTRY_CODE], [ORG_DUNS_NUM], [ST_FAC_IDENT], [ST_RGN_CODE], [FAC_CONGR_DISTRICT_NUM], [FAC_TYPE_OF_OWNERSHIP_CODE], [FEDR_FAC_IDENT_NUM], [FEDR_AGNCY_CODE], [TRIBAL_LAND_CODE], [CNST_PROJ_NAME], [CNST_PROJ_LAT_MEAS], [CNST_PROJ_LONG_MEAS], [SECTION_TOWNSHIP_RNG], [FAC_CMNTS], [FAC_USR_DFND_FLD_1], [FAC_USR_DFND_FLD_2], [FAC_USR_DFND_FLD_3], [FAC_USR_DFND_FLD_4], [FAC_USR_DFND_FLD_5], [PRMT_CMNTS_TXT], [KEY_HASH], [DATA_HASH])
        SELECT   [ICS_UNPRMT_FAC_ID],
                 [ICS_PAYLOAD_ID],
                 [SRC_SYSTM_IDENT],
                 [TRANSACTION_TYPE],
                 [TRANSACTION_TIMESTAMP],
                 [PRMT_IDENT],
                 [FAC_SITE_NAME],
                 [LOC_ADDR_TXT],
                 [SUPPL_LOC_TXT],
                 [LOCALITY_NAME],
                 [LOC_ADDR_CITY_CODE],
                 [LOC_ADDR_COUNTY_CODE],
                 [LOC_ST_CODE],
                 [LOC_ZIP_CODE],
                 [LOC_COUNTRY_CODE],
                 [ORG_DUNS_NUM],
                 [ST_FAC_IDENT],
                 [ST_RGN_CODE],
                 [FAC_CONGR_DISTRICT_NUM],
                 [FAC_TYPE_OF_OWNERSHIP_CODE],
                 [FEDR_FAC_IDENT_NUM],
                 [FEDR_AGNCY_CODE],
                 [TRIBAL_LAND_CODE],
                 [CNST_PROJ_NAME],
                 [CNST_PROJ_LAT_MEAS],
                 [CNST_PROJ_LONG_MEAS],
                 [SECTION_TOWNSHIP_RNG],
                 [FAC_CMNTS],
                 [FAC_USR_DFND_FLD_1],
                 [FAC_USR_DFND_FLD_2],
                 [FAC_USR_DFND_FLD_3],
                 [FAC_USR_DFND_FLD_4],
                 [FAC_USR_DFND_FLD_5],
                 [PRMT_CMNTS_TXT],
                 [KEY_HASH],
                 [DATA_HASH]
        FROM     [dbo].[ICS_UNPRMT_FAC]
        ORDER BY [ICS_UNPRMT_FAC_ID] ASC;
    END
DROP TABLE [dbo].[ICS_UNPRMT_FAC];
EXECUTE sp_rename N'[dbo].[tmp_ms_xx_ICS_UNPRMT_FAC]', N'ICS_UNPRMT_FAC';
EXECUTE sp_rename N'[dbo].[tmp_ms_xx_constraint_PK_UNPRMT_FAC1]', N'PK_UNPRMT_FAC', N'OBJECT';
COMMIT TRANSACTION;
SET TRANSACTION ISOLATION LEVEL READ COMMITTED;

PRINT N'Creating Index [dbo].[ICS_UNPRMT_FAC].[IX_UNPRMT_FAC_ICS_PAYLOAD_ID]...';

CREATE NONCLUSTERED INDEX [IX_UNPRMT_FAC_ICS_PAYLOAD_ID]
    ON [dbo].[ICS_UNPRMT_FAC]([ICS_PAYLOAD_ID] ASC);

PRINT N'Creating Index [dbo].[ICS_UNPRMT_FAC].[IX_UNPRMT_FAC_PRMT_IDENT]...';

CREATE UNIQUE NONCLUSTERED INDEX [IX_UNPRMT_FAC_PRMT_IDENT]
    ON [dbo].[ICS_UNPRMT_FAC]([PRMT_IDENT] ASC);

PRINT N'Starting rebuilding table [dbo].[ICS_VECTOR_A_REDUCTION_TYPE]...';

BEGIN TRANSACTION;
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;
SET XACT_ABORT ON;
CREATE TABLE [dbo].[tmp_ms_xx_ICS_VECTOR_A_REDUCTION_TYPE] (
    [ICS_VECTOR_A_REDUCTION_TYPE_ID] VARCHAR (36)  NOT NULL,
    [ICS_BS_MGMT_PRACTICE_ID]        VARCHAR (36)  NULL,
    [ICS_PRMT_BS_MGMT_PRACTICE_ID]   VARCHAR (36)  NULL,
    [VECTOR_A_REDUCTION_TYPE_CODE]   VARCHAR (3)   NOT NULL,
    [DATA_HASH]                      VARCHAR (100) NULL,
    CONSTRAINT [tmp_ms_xx_constraint_PK_VECTOR_A_REDUCTION_TYPE1] PRIMARY KEY CLUSTERED ([ICS_VECTOR_A_REDUCTION_TYPE_ID] ASC)
);
IF EXISTS (SELECT TOP 1 1 
           FROM   [dbo].[ICS_VECTOR_A_REDUCTION_TYPE])
    BEGIN
        INSERT INTO [dbo].[tmp_ms_xx_ICS_VECTOR_A_REDUCTION_TYPE] ([ICS_VECTOR_A_REDUCTION_TYPE_ID], [VECTOR_A_REDUCTION_TYPE_CODE], [DATA_HASH])
        SELECT   [ICS_VECTOR_A_REDUCTION_TYPE_ID],
                 [VECTOR_A_REDUCTION_TYPE_CODE],
                 [DATA_HASH]
        FROM     [dbo].[ICS_VECTOR_A_REDUCTION_TYPE]
        ORDER BY [ICS_VECTOR_A_REDUCTION_TYPE_ID] ASC;
    END
DROP TABLE [dbo].[ICS_VECTOR_A_REDUCTION_TYPE];
EXECUTE sp_rename N'[dbo].[tmp_ms_xx_ICS_VECTOR_A_REDUCTION_TYPE]', N'ICS_VECTOR_A_REDUCTION_TYPE';
EXECUTE sp_rename N'[dbo].[tmp_ms_xx_constraint_PK_VECTOR_A_REDUCTION_TYPE1]', N'PK_VECTOR_A_REDUCTION_TYPE', N'OBJECT';
COMMIT TRANSACTION;
SET TRANSACTION ISOLATION LEVEL READ COMMITTED;

PRINT N'Creating Index [dbo].[ICS_VECTOR_A_REDUCTION_TYPE].[IX_VC_A_RD_TY_IC_PR_BS_MG_PR_I]...';

CREATE NONCLUSTERED INDEX [IX_VC_A_RD_TY_IC_PR_BS_MG_PR_I]
    ON [dbo].[ICS_VECTOR_A_REDUCTION_TYPE]([ICS_PRMT_BS_MGMT_PRACTICE_ID] ASC);

PRINT N'Creating Index [dbo].[ICS_VECTOR_A_REDUCTION_TYPE].[IX_VCT_A_RDC_TY_IC_BS_MG_PR_ID]...';

CREATE NONCLUSTERED INDEX [IX_VCT_A_RDC_TY_IC_BS_MG_PR_ID]
    ON [dbo].[ICS_VECTOR_A_REDUCTION_TYPE]([ICS_BS_MGMT_PRACTICE_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_BS_FAC_TRTMNT]...';

CREATE TABLE [dbo].[ICS_BS_FAC_TRTMNT] (
    [ICS_BS_FAC_TRTMNT_ID]     VARCHAR (36)  NOT NULL,
    [ICS_BS_ANNUL_PROG_REP_ID] VARCHAR (36)  NULL,
    [ICS_BS_PRMT_ID]           VARCHAR (36)  NULL,
    [BS_FAC_TRTMNT_CODE]       VARCHAR (3)   NOT NULL,
    [DATA_HASH]                VARCHAR (100) NULL,
    CONSTRAINT [PK_BS_FAC_TRTMNT] PRIMARY KEY CLUSTERED ([ICS_BS_FAC_TRTMNT_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_BS_FAC_TRTMNT].[IX_BS_FAC_TR_IC_BS_AN_PR_RE_ID]...';

CREATE NONCLUSTERED INDEX [IX_BS_FAC_TR_IC_BS_AN_PR_RE_ID]
    ON [dbo].[ICS_BS_FAC_TRTMNT]([ICS_BS_ANNUL_PROG_REP_ID] ASC);

PRINT N'Creating Index [dbo].[ICS_BS_FAC_TRTMNT].[IX_BS_FAC_TRTMN_ICS_BS_PRMT_ID]...';

CREATE NONCLUSTERED INDEX [IX_BS_FAC_TRTMN_ICS_BS_PRMT_ID]
    ON [dbo].[ICS_BS_FAC_TRTMNT]([ICS_BS_PRMT_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_BS_FAC_TYPE]...';

CREATE TABLE [dbo].[ICS_BS_FAC_TYPE] (
    [ICS_BS_FAC_TYPE_ID]       VARCHAR (36)  NOT NULL,
    [ICS_BS_ANNUL_PROG_REP_ID] VARCHAR (36)  NULL,
    [ICS_BS_PRMT_ID]           VARCHAR (36)  NULL,
    [BS_FAC_TYPE_CODE]         VARCHAR (3)   NOT NULL,
    [DATA_HASH]                VARCHAR (100) NULL,
    CONSTRAINT [PK_BS_FAC_TYPE] PRIMARY KEY CLUSTERED ([ICS_BS_FAC_TYPE_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_BS_FAC_TYPE].[IX_BS_FAC_TY_IC_BS_AN_PR_RE_ID]...';

CREATE NONCLUSTERED INDEX [IX_BS_FAC_TY_IC_BS_AN_PR_RE_ID]
    ON [dbo].[ICS_BS_FAC_TYPE]([ICS_BS_ANNUL_PROG_REP_ID] ASC);

PRINT N'Creating Index [dbo].[ICS_BS_FAC_TYPE].[IX_BS_FAC_TYPE_ICS_BS_PRMT_ID]...';

CREATE NONCLUSTERED INDEX [IX_BS_FAC_TYPE_ICS_BS_PRMT_ID]
    ON [dbo].[ICS_BS_FAC_TYPE]([ICS_BS_PRMT_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_BS_INCIN_EMISSIONS_CONTROL_TYPE]...';

CREATE TABLE [dbo].[ICS_BS_INCIN_EMISSIONS_CONTROL_TYPE] (
    [ICS_BS_INCIN_EMISSIONS_CONTROL_TYPE_ID] VARCHAR (36)  NOT NULL,
    [ICS_BS_INCINERATION_ID]                 VARCHAR (36)  NOT NULL,
    [BS_EMISSIONS_CONTROL_CATG]              VARCHAR (3)   NOT NULL,
    [BS_EMISSIONS_CONTROL_TECHNOLOGY_CODE]   VARCHAR (3)   NOT NULL,
    [BS_EMISSIONS_CONTROL_OTHR_TXT]          VARCHAR (250) NULL,
    [DATA_HASH]                              VARCHAR (100) NULL,
    CONSTRAINT [PK_BS_INCN_EMISSONS_CNTRL_TYPE] PRIMARY KEY CLUSTERED ([ICS_BS_INCIN_EMISSIONS_CONTROL_TYPE_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_BS_INCIN_EMISSIONS_CONTROL_TYPE].[IX_BS_INC_EM_CN_TY_IC_BS_IN_ID]...';

CREATE NONCLUSTERED INDEX [IX_BS_INC_EM_CN_TY_IC_BS_IN_ID]
    ON [dbo].[ICS_BS_INCIN_EMISSIONS_CONTROL_TYPE]([ICS_BS_INCINERATION_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_BS_INCINERATION]...';

CREATE TABLE [dbo].[ICS_BS_INCINERATION] (
    [ICS_BS_INCINERATION_ID]        VARCHAR (36)  NOT NULL,
    [ICS_BS_MGMT_PRACTICE_ID]       VARCHAR (36)  NOT NULL,
    [BS_INCIN_IDENT]                VARCHAR (20)  NOT NULL,
    [BS_INCIN_TYPE_CODE]            VARCHAR (3)   NULL,
    [BS_INCIN_OTHR_TXT]             VARCHAR (250) NULL,
    [BS_INCIN_LAST_SIG_CHANGE_DATE] DATETIME      NULL,
    [BS_INCIN_NEW_POLUT_LMTS_IND]   CHAR (1)      NULL,
    [DATA_HASH]                     VARCHAR (100) NULL,
    CONSTRAINT [PK_BS_INCINERATION] PRIMARY KEY CLUSTERED ([ICS_BS_INCINERATION_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_BS_INCINERATION].[IX_BS_INCN_ICS_BS_MGMT_PRCT_ID]...';

CREATE NONCLUSTERED INDEX [IX_BS_INCN_ICS_BS_MGMT_PRCT_ID]
    ON [dbo].[ICS_BS_INCINERATION]([ICS_BS_MGMT_PRACTICE_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_BS_MGMT_PRACTICE]...';

CREATE TABLE [dbo].[ICS_BS_MGMT_PRACTICE] (
    [ICS_BS_MGMT_PRACTICE_ID]              VARCHAR (36)    NOT NULL,
    [ICS_BS_ANNUL_PROG_REP_ID]             VARCHAR (36)    NOT NULL,
    [SSU_IDENT]                            VARCHAR (20)    NOT NULL,
    [BS_MGMT_PRACTICE_CODE]                VARCHAR (3)     NULL,
    [BS_MGMT_PRACTICE_SUB_CATG_CODE]       VARCHAR (3)     NULL,
    [BS_MGMT_PRACTICE_SUB_CATG_TXT]        VARCHAR (250)   NULL,
    [BS_OPERATOR_TYPE_CODE]                VARCHAR (3)     NULL,
    [BS_CNTNR_TYPE_CODE]                   VARCHAR (3)     NULL,
    [SSUID_VOL_AMT]                        DECIMAL (15, 7) NULL,
    [PATHOGEN_CLASS_TYPE_CODE]             VARCHAR (3)     NULL,
    [POLUT_LOADING_RATES_EXCEEDANCE_IND]   CHAR (1)        NULL,
    [BS_MGMT_PRACTICE_VIOL_TYPE_CODE]      VARCHAR (3)     NULL,
    [BS_MGMT_PRACTICE_VIOL_TXT]            VARCHAR (2000)  NULL,
    [BS_OFF_SITE_FAC_PRMT_IDENT]           CHAR (9)        NULL,
    [SURF_DSPL_WITHOUT_LINER_IND]          CHAR (1)        NULL,
    [SURF_DSPL_SITE_SPEC_LMT_IND]          CHAR (1)        NULL,
    [SURF_DSPL_MIN_BOUNDARY_DISTANCE_CODE] VARCHAR (3)     NULL,
    [DATA_HASH]                            VARCHAR (100)   NULL,
    CONSTRAINT [PK_BS_MGMT_PRACTICE] PRIMARY KEY CLUSTERED ([ICS_BS_MGMT_PRACTICE_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_BS_MGMT_PRACTICE].[IX_BS_MGM_PR_IC_BS_AN_PR_RE_ID]...';

CREATE NONCLUSTERED INDEX [IX_BS_MGM_PR_IC_BS_AN_PR_RE_ID]
    ON [dbo].[ICS_BS_MGMT_PRACTICE]([ICS_BS_ANNUL_PROG_REP_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR]...';

CREATE TABLE [dbo].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] (
    [ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] VARCHAR (36)    NOT NULL,
    [ICS_BS_MGMT_PRACTICE_ID]                VARCHAR (36)    NULL,
    [ICS_PRMT_BS_MGMT_PRACTICE_ID]           VARCHAR (36)    NULL,
    [BS_OFF_SITE_HNDLR_APPLIER_VOL_AMT]      DECIMAL (15, 7) NULL,
    [DATA_HASH]                              VARCHAR (100)   NULL,
    CONSTRAINT [PK_BS_OFF_SITE_HNDLR_APPL_PRPR] PRIMARY KEY CLUSTERED ([ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR].[IX_BS_OF_SI_HN_AP_PR_IC_BS_MG]...';

CREATE NONCLUSTERED INDEX [IX_BS_OF_SI_HN_AP_PR_IC_BS_MG]
    ON [dbo].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR]([ICS_BS_MGMT_PRACTICE_ID] ASC);

PRINT N'Creating Index [dbo].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR].[IX_BS_OF_SI_HN_AP_PR_IC_PR_BS]...';

CREATE NONCLUSTERED INDEX [IX_BS_OF_SI_HN_AP_PR_IC_PR_BS]
    ON [dbo].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR]([ICS_PRMT_BS_MGMT_PRACTICE_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_BS_SEWAGE_SLDG_PARAM]...';

CREATE TABLE [dbo].[ICS_BS_SEWAGE_SLDG_PARAM] (
    [ICS_BS_SEWAGE_SLDG_PARAM_ID]  VARCHAR (36)  NOT NULL,
    [ICS_CMPL_MON_EVT_ID]          VARCHAR (36)  NULL,
    [ICS_BS_MGMT_PRACTICE_ID]      VARCHAR (36)  NULL,
    [ICS_BS_INCINERATION_ID]       VARCHAR (36)  NULL,
    [BS_SEWAGE_SLDG_PARAM_CODE]    INT           NOT NULL,
    [BS_SEWAGE_SLDG_PARAM_LMT]     INT           NULL,
    [PARAM_VALUE]                  VARCHAR (50)  NULL,
    [VALUE_QUALIFIER]              VARCHAR (3)   NULL,
    [NO_DAT_IND_CODE]              CHAR (1)      NULL,
    [PASS_FAIL_IND_CODE]           CHAR (1)      NULL,
    [PATHOGEN_REDUCTION_TYPE_CODE] VARCHAR (3)   NULL,
    [BS_SMPL_START_DATE]           DATETIME      NULL,
    [BS_SMPL_END_DATE]             DATETIME      NULL,
    [BS_SMPL_MN]                   CHAR (7)      NULL,
    [DATA_HASH]                    VARCHAR (100) NULL,
    CONSTRAINT [PK_BS_SEWAGE_SLDG_PARAM] PRIMARY KEY CLUSTERED ([ICS_BS_SEWAGE_SLDG_PARAM_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_BS_SEWAGE_SLDG_PARAM].[IX_BS_SWG_SL_PA_IC_BS_MG_PR_ID]...';

CREATE NONCLUSTERED INDEX [IX_BS_SWG_SL_PA_IC_BS_MG_PR_ID]
    ON [dbo].[ICS_BS_SEWAGE_SLDG_PARAM]([ICS_BS_MGMT_PRACTICE_ID] ASC);

PRINT N'Creating Index [dbo].[ICS_BS_SEWAGE_SLDG_PARAM].[IX_BS_SWG_SL_PA_IC_CM_MO_EV_ID]...';

CREATE NONCLUSTERED INDEX [IX_BS_SWG_SL_PA_IC_CM_MO_EV_ID]
    ON [dbo].[ICS_BS_SEWAGE_SLDG_PARAM]([ICS_CMPL_MON_EVT_ID] ASC);

PRINT N'Creating Index [dbo].[ICS_BS_SEWAGE_SLDG_PARAM].[IX_BS_SWG_SLD_PAR_ICS_BS_IN_ID]...';

CREATE NONCLUSTERED INDEX [IX_BS_SWG_SLD_PAR_ICS_BS_IN_ID]
    ON [dbo].[ICS_BS_SEWAGE_SLDG_PARAM]([ICS_BS_INCINERATION_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_BYPASS_TRTMNT_PLANT_EQUIPMENT]...';

CREATE TABLE [dbo].[ICS_BYPASS_TRTMNT_PLANT_EQUIPMENT] (
    [ICS_BYPASS_TRTMNT_PLANT_EQUIPMENT_ID] VARCHAR (36)  NOT NULL,
    [ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID]   VARCHAR (36)  NOT NULL,
    [BYPASS_TRTMNT_PLANT_EQUIPMENT_CODE]   VARCHAR (3)   NOT NULL,
    [DATA_HASH]                            VARCHAR (100) NULL,
    CONSTRAINT [PK_BYPASS_TRTMNT_PLNT_EQUIPMNT] PRIMARY KEY CLUSTERED ([ICS_BYPASS_TRTMNT_PLANT_EQUIPMENT_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_BYPASS_TRTMNT_PLANT_EQUIPMENT].[IX_BY_TR_PL_EQ_IC_SE_OV_BY_RE]...';

CREATE NONCLUSTERED INDEX [IX_BY_TR_PL_EQ_IC_SE_OV_BY_RE]
    ON [dbo].[ICS_BYPASS_TRTMNT_PLANT_EQUIPMENT]([ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_CAFO_ANNUL_PROG_REP]...';

CREATE TABLE [dbo].[ICS_CAFO_ANNUL_PROG_REP] (
    [ICS_CAFO_ANNUL_PROG_REP_ID]      VARCHAR (36)   NOT NULL,
    [ICS_PAYLOAD_ID]                  VARCHAR (36)   NOT NULL,
    [SRC_SYSTM_IDENT]                 VARCHAR (50)   NULL,
    [TRANSACTION_TYPE]                CHAR (1)       NULL,
    [TRANSACTION_TIMESTAMP]           DATETIME       NULL,
    [PRMT_IDENT]                      CHAR (9)       NOT NULL,
    [PROG_REP_FORM_SET_ID]            VARCHAR (50)   NOT NULL,
    [PROG_REP_FORM_ID]                INT            NULL,
    [PROG_REP_RCVD_DATE]              DATETIME       NULL,
    [PROG_REP_START_DATE]             DATETIME       NULL,
    [PROG_REP_END_DATE]               DATETIME       NULL,
    [ELEC_SUBM_TYPE_CODE]             VARCHAR (3)    NULL,
    [PROG_REP_NPDES_DAT_GRP_NUM_CODE] VARCHAR (3)    NULL,
    [NUTR_MGMT_PLAN_ACREAGE_NUM]      DECIMAL (8, 2) NULL,
    [ACTUL_LAND_APPL_ACREAGE_NUM]     DECIMAL (8, 2) NULL,
    [NMP_CERT_PLNR_IND]               CHAR (1)       NULL,
    [KEY_HASH]                        VARCHAR (100)  NULL,
    [DATA_HASH]                       VARCHAR (100)  NULL,
    CONSTRAINT [PK_CAFO_ANNUL_PROG_REP] PRIMARY KEY CLUSTERED ([ICS_CAFO_ANNUL_PROG_REP_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_CAFO_ANNUL_PROG_REP].[IX_CAFO_ANN_PRO_REP_ICS_PYL_ID]...';

CREATE NONCLUSTERED INDEX [IX_CAFO_ANN_PRO_REP_ICS_PYL_ID]
    ON [dbo].[ICS_CAFO_ANNUL_PROG_REP]([ICS_PAYLOAD_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_CAFO_LAND_APPL_FLD_INFO]...';

CREATE TABLE [dbo].[ICS_CAFO_LAND_APPL_FLD_INFO] (
    [ICS_CAFO_LAND_APPL_FLD_INFO_ID]        VARCHAR (36)   NOT NULL,
    [ICS_CAFO_ANNUL_PROG_REP_ID]            VARCHAR (36)   NOT NULL,
    [CAFO_LAND_APPL_FLD_IDENT]              VARCHAR (20)   NOT NULL,
    [CAFO_LAND_APPL_FLD_ACREAGE]            DECIMAL (8, 2) NULL,
    [CAFOMLPW_MAX_AMT_METHOD]               VARCHAR (3)    NULL,
    [CAFO_LAND_APPL_FLD_CROP_IDENT]         VARCHAR (20)   NOT NULL,
    [CAFO_LAND_APPL_FLD_CROP_CODE]          VARCHAR (4)    NULL,
    [CAFO_LAND_APPL_FLD_CROP_YIELD]         DECIMAL (8, 2) NULL,
    [CAFO_LAND_APPL_FLD_CROP_YIELD_UNIT]    VARCHAR (3)    NULL,
    [CAFO_LAND_APPL_FLD_CROP_SEEDED]        CHAR (1)       NULL,
    [CAFO_SOIL_MON_MEAS_FORM]               VARCHAR (3)    NOT NULL,
    [CAFO_SOIL_MON_MEAS_VALUE]              DECIMAL (5, 2) NULL,
    [CAFO_SOIL_MON_MEAS_VALUE_UNIT]         VARCHAR (3)    NULL,
    [CAFO_SOIL_MON_ANLYTCL_METHOD]          VARCHAR (3)    NULL,
    [CAFO_SOIL_MON_SMPL_DEPTH_INCHES]       DECIMAL (3, 1) NULL,
    [CAFO_SOIL_MON_SMPL_DATE]               DATETIME       NULL,
    [CAFO_SUPPL_FERTILIZER_MEAS_FORM]       VARCHAR (3)    NOT NULL,
    [CAFO_SUPPL_FERTILIZER_MEAS_VALUE]      DECIMAL (5, 2) NULL,
    [CAFO_SUPPL_FERTILIZER_MEAS_VALUE_UNIT] VARCHAR (3)    NULL,
    [DATA_HASH]                             VARCHAR (100)  NULL,
    CONSTRAINT [PK_CAFO_LAND_APPL_FLD_INFO] PRIMARY KEY CLUSTERED ([ICS_CAFO_LAND_APPL_FLD_INFO_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_CAFO_LAND_APPL_FLD_INFO].[IX_CA_LA_AP_FL_IN_IC_CA_AN_PR]...';

CREATE NONCLUSTERED INDEX [IX_CA_LA_AP_FL_IN_IC_CA_AN_PR]
    ON [dbo].[ICS_CAFO_LAND_APPL_FLD_INFO]([ICS_CAFO_ANNUL_PROG_REP_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_CAFO_PROD_AREA_DSCH]...';

CREATE TABLE [dbo].[ICS_CAFO_PROD_AREA_DSCH] (
    [ICS_CAFO_PROD_AREA_DSCH_ID]            VARCHAR (36)   NOT NULL,
    [ICS_CAFO_ANNUL_PROG_REP_ID]            VARCHAR (36)   NOT NULL,
    [CAFO_PROD_AREA_DSCH_DISCOVERY_DATE]    DATETIME       NOT NULL,
    [CAFO_PROD_AREA_DSCH_24HR_RAIN_EVT_IND] CHAR (1)       NULL,
    [CAFO_PROD_AREA_DSCH_DURATION_HOURS]    DECIMAL (5, 2) NULL,
    [CAFO_PROD_AREA_DSCH_VOL_GAL]           INT            NULL,
    [DATA_HASH]                             VARCHAR (100)  NULL,
    CONSTRAINT [PK_CAFO_PROD_AREA_DSCH] PRIMARY KEY CLUSTERED ([ICS_CAFO_PROD_AREA_DSCH_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_CAFO_PROD_AREA_DSCH].[IX_CA_PR_AR_DS_IC_CA_AN_PR_RE]...';

CREATE NONCLUSTERED INDEX [IX_CA_PR_AR_DS_IC_CA_AN_PR_RE]
    ON [dbo].[ICS_CAFO_PROD_AREA_DSCH]([ICS_CAFO_ANNUL_PROG_REP_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_CAFOMLPW_FLD_AMOUNTS]...';

CREATE TABLE [dbo].[ICS_CAFOMLPW_FLD_AMOUNTS] (
    [ICS_CAFOMLPW_FLD_AMOUNTS_ID]    VARCHAR (36)    NOT NULL,
    [ICS_CAFO_LAND_APPL_FLD_INFO_ID] VARCHAR (36)    NOT NULL,
    [CAFOMLPW_CODE]                  VARCHAR (3)     NOT NULL,
    [CAFOMLPW_FLD_MAX_ALLOWABLE_AMT] DECIMAL (11, 2) NULL,
    [CAFOMLPW_FLD_ACTUL_AMT]         DECIMAL (11, 2) NULL,
    [CAFOMLPW_LAND_APPL_UNIT]        VARCHAR (3)     NULL,
    [DATA_HASH]                      VARCHAR (100)   NULL,
    CONSTRAINT [PK_CAFOMLPW_FLD_AMOUNTS] PRIMARY KEY CLUSTERED ([ICS_CAFOMLPW_FLD_AMOUNTS_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_CAFOMLPW_FLD_AMOUNTS].[IX_CF_FL_AM_IC_CA_LA_AP_FL_IN]...';

CREATE NONCLUSTERED INDEX [IX_CF_FL_AM_IC_CA_LA_AP_FL_IN]
    ON [dbo].[ICS_CAFOMLPW_FLD_AMOUNTS]([ICS_CAFO_LAND_APPL_FLD_INFO_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_CAFOMLPW_NUTR_MON]...';

CREATE TABLE [dbo].[ICS_CAFOMLPW_NUTR_MON] (
    [ICS_CAFOMLPW_NUTR_MON_ID]   VARCHAR (36)   NOT NULL,
    [ICS_CAFO_ANNUL_PROG_REP_ID] VARCHAR (36)   NOT NULL,
    [CAFOMLPW_CODE]              VARCHAR (3)    NOT NULL,
    [CAFOMLPW_NUTR_FORM]         VARCHAR (3)    NULL,
    [CAFOMLPW_NUTR_VALUE]        DECIMAL (5, 2) NULL,
    [CAFOMLPW_NUTR_VALUE_UNIT]   VARCHAR (3)    NULL,
    [DATA_HASH]                  VARCHAR (100)  NULL,
    CONSTRAINT [PK_CAFOMLPW_NUTR_MON] PRIMARY KEY CLUSTERED ([ICS_CAFOMLPW_NUTR_MON_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_CAFOMLPW_NUTR_MON].[IX_CFM_NU_MO_IC_CA_AN_PR_RE_ID]...';

CREATE NONCLUSTERED INDEX [IX_CFM_NU_MO_IC_CA_AN_PR_RE_ID]
    ON [dbo].[ICS_CAFOMLPW_NUTR_MON]([ICS_CAFO_ANNUL_PROG_REP_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_CAFOMLPW_TTL_AMOUNTS]...';

CREATE TABLE [dbo].[ICS_CAFOMLPW_TTL_AMOUNTS] (
    [ICS_CAFOMLPW_TTL_AMOUNTS_ID] VARCHAR (36)    NOT NULL,
    [ICS_CAFO_ANNUL_PROG_REP_ID]  VARCHAR (36)    NULL,
    [ICS_CAFO_PRMT_ID]            VARCHAR (36)    NULL,
    [CAFOMLPW_CODE]               VARCHAR (3)     NOT NULL,
    [CAFOMLPW_AMT_GNRTD]          DECIMAL (14, 2) NULL,
    [CAFOMLPW_AMT_TRANSFERRED]    DECIMAL (14, 2) NULL,
    [CAFOMLPW_UNIT]               VARCHAR (3)     NULL,
    [DATA_HASH]                   VARCHAR (100)   NULL,
    CONSTRAINT [PK_CAFOMLPW_TTL_AMOUNTS] PRIMARY KEY CLUSTERED ([ICS_CAFOMLPW_TTL_AMOUNTS_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_CAFOMLPW_TTL_AMOUNTS].[IX_CFM_TT_AM_IC_CA_AN_PR_RE_ID]...';

CREATE NONCLUSTERED INDEX [IX_CFM_TT_AM_IC_CA_AN_PR_RE_ID]
    ON [dbo].[ICS_CAFOMLPW_TTL_AMOUNTS]([ICS_CAFO_ANNUL_PROG_REP_ID] ASC);

PRINT N'Creating Index [dbo].[ICS_CAFOMLPW_TTL_AMOUNTS].[IX_CFML_TTL_AMN_ICS_CAF_PRM_ID]...';

CREATE NONCLUSTERED INDEX [IX_CFML_TTL_AMN_ICS_CAF_PRM_ID]
    ON [dbo].[ICS_CAFOMLPW_TTL_AMOUNTS]([ICS_CAFO_PRMT_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_CMPL_MON_EVT]...';

CREATE TABLE [dbo].[ICS_CMPL_MON_EVT] (
    [ICS_CMPL_MON_EVT_ID]     VARCHAR (36)  NOT NULL,
    [ICS_BS_MGMT_PRACTICE_ID] VARCHAR (36)  NOT NULL,
    [CMPL_MON_EVT_IDENT]      INT           NOT NULL,
    [CMPL_MON_EVT_START_DATE] DATETIME      NULL,
    [CMPL_MON_EVT_END_DATE]   DATETIME      NULL,
    [DATA_HASH]               VARCHAR (100) NULL,
    CONSTRAINT [PK_CMPL_MON_EVT] PRIMARY KEY CLUSTERED ([ICS_CMPL_MON_EVT_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_CMPL_MON_EVT].[IX_CMP_MON_EVT_ICS_BS_MG_PR_ID]...';

CREATE NONCLUSTERED INDEX [IX_CMP_MON_EVT_ICS_BS_MG_PR_ID]
    ON [dbo].[ICS_CMPL_MON_EVT]([ICS_BS_MGMT_PRACTICE_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_CNST_SITE_LIST]...';

CREATE TABLE [dbo].[ICS_CNST_SITE_LIST] (
    [ICS_CNST_SITE_LIST_ID] VARCHAR (36)  NOT NULL,
    [ICS_SW_CNST_PRMT_ID]   VARCHAR (36)  NOT NULL,
    [CNST_SITE_OTHR_TXT]    VARCHAR (100) NULL,
    [DATA_HASH]             VARCHAR (100) NULL,
    CONSTRAINT [PK_CNST_SITE_LIST] PRIMARY KEY CLUSTERED ([ICS_CNST_SITE_LIST_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_CNST_SITE_LIST].[IX_CNS_SIT_LIS_ICS_SW_CN_PR_ID]...';

CREATE NONCLUSTERED INDEX [IX_CNS_SIT_LIS_ICS_SW_CN_PR_ID]
    ON [dbo].[ICS_CNST_SITE_LIST]([ICS_SW_CNST_PRMT_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_COLL_SYSTM_PRMT]...';

CREATE TABLE [dbo].[ICS_COLL_SYSTM_PRMT] (
    [ICS_COLL_SYSTM_PRMT_ID]     VARCHAR (36)   NOT NULL,
    [ICS_PAYLOAD_ID]             VARCHAR (36)   NOT NULL,
    [SRC_SYSTM_IDENT]            VARCHAR (50)   NULL,
    [TRANSACTION_TYPE]           CHAR (1)       NULL,
    [TRANSACTION_TIMESTAMP]      DATETIME       NULL,
    [PRMT_IDENT]                 CHAR (9)       NOT NULL,
    [COLL_SYSTM_IDENT]           VARCHAR (20)   NULL,
    [COLL_SYSTM_NAME]            VARCHAR (50)   NULL,
    [COLL_SYSTM_OWNER_TYPE_CODE] VARCHAR (3)    NULL,
    [COLL_SYSTM_POPL]            INT            NULL,
    [PERCENT_COLL_SYSTM_CSS]     DECIMAL (4, 1) NULL,
    [KEY_HASH]                   VARCHAR (100)  NULL,
    [DATA_HASH]                  VARCHAR (100)  NULL,
    CONSTRAINT [PK_COLL_SYSTM_PRMT] PRIMARY KEY CLUSTERED ([ICS_COLL_SYSTM_PRMT_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_COLL_SYSTM_PRMT].[IX_COLL_SYSTM_PRMT_ICS_PYLD_ID]...';

CREATE NONCLUSTERED INDEX [IX_COLL_SYSTM_PRMT_ICS_PYLD_ID]
    ON [dbo].[ICS_COLL_SYSTM_PRMT]([ICS_PAYLOAD_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_CONTROL_AUTH_PROG_INFO]...';

CREATE TABLE [dbo].[ICS_CONTROL_AUTH_PROG_INFO] (
    [ICS_CONTROL_AUTH_PROG_INFO_ID] VARCHAR (36)  NOT NULL,
    [ICS_PRETR_PROG_REP_ID]         VARCHAR (36)  NOT NULL,
    [LOC_LMTS_ADOPTION_DATE]        DATETIME      NULL,
    [LOC_LMTS_EVAL_DATE]            DATETIME      NULL,
    [POTW_DSCH_CONTAMINATION_IND]   CHAR (1)      NOT NULL,
    [POTW_DSCH_CONTAMINATION_TXT]   VARCHAR (500) NULL,
    [POTW_BS_CONTAMINATION_IND]     CHAR (1)      NOT NULL,
    [POTW_BS_CONTAMINATION_TXT]     VARCHAR (500) NULL,
    [DATA_HASH]                     VARCHAR (100) NULL,
    CONSTRAINT [PK_CONTROL_AUTH_PROG_INFO] PRIMARY KEY CLUSTERED ([ICS_CONTROL_AUTH_PROG_INFO_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_CONTROL_AUTH_PROG_INFO].[IX_CNT_AU_PR_IN_IC_PR_PR_RE_ID]...';

CREATE NONCLUSTERED INDEX [IX_CNT_AU_PR_IN_IC_PR_PR_RE_ID]
    ON [dbo].[ICS_CONTROL_AUTH_PROG_INFO]([ICS_PRETR_PROG_REP_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_COOLING_WTR_INTAKE_STRCT_CMPL_METHOD]...';

CREATE TABLE [dbo].[ICS_COOLING_WTR_INTAKE_STRCT_CMPL_METHOD] (
    [ICS_COOLING_WTR_INTAKE_STRCT_CMPL_METHOD_ID] VARCHAR (36)  NOT NULL,
    [ICS_COOLING_WTR_INTAKE_STRCT_INFO_ID]        VARCHAR (36)  NOT NULL,
    [COOLING_WTR_INTAKE_STRCT_CMPL_METHOD_CODE]   VARCHAR (3)   NOT NULL,
    [COOLING_WTR_INTAKE_STRCT_CMPL_METHOD_TXT]    VARCHAR (500) NULL,
    [DATA_HASH]                                   VARCHAR (100) NULL,
    CONSTRAINT [PK_CLNG_WTR_INTK_STRC_CMPL_MTH] PRIMARY KEY CLUSTERED ([ICS_COOLING_WTR_INTAKE_STRCT_CMPL_METHOD_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_COOLING_WTR_INTAKE_STRCT_CMPL_METHOD].[IX_CL_WT_IN_ST_CM_MT_IC_CL_WT]...';

CREATE NONCLUSTERED INDEX [IX_CL_WT_IN_ST_CM_MT_IC_CL_WT]
    ON [dbo].[ICS_COOLING_WTR_INTAKE_STRCT_CMPL_METHOD]([ICS_COOLING_WTR_INTAKE_STRCT_INFO_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_COOLING_WTR_INTAKE_STRCT_INFO]...';

CREATE TABLE [dbo].[ICS_COOLING_WTR_INTAKE_STRCT_INFO] (
    [ICS_COOLING_WTR_INTAKE_STRCT_INFO_ID]         VARCHAR (36)    NOT NULL,
    [ICS_PRMT_FEATR_ID]                            VARCHAR (36)    NOT NULL,
    [COOLING_WTR_INTAKE_STRCT_APPL_SUBPART]        INT             NULL,
    [COOLING_WTR_INTAKE_STRCT_DSGN_INTAKE_FLOW]    DECIMAL (15, 7) NULL,
    [COOLING_WTR_INTAKE_STRCT_ACTUL_INTAKE_FLOW]   DECIMAL (15, 7) NULL,
    [COOLING_WTR_ACTUL_INTAKE_STRCT_VELOCITY]      DECIMAL (6, 2)  NULL,
    [SRC_WTR_BASELINE_BIOLOGICAL_CHARACTERIZATION] VARCHAR (8000)  NULL,
    [COOLING_WTR_INTAKE_STRCT_LOC_CODE]            VARCHAR (3)     NOT NULL,
    [COOLING_WTR_INTAKE_STRCT_LOC_TXT]             VARCHAR (500)   NULL,
    [COOLING_WTR_INTAKE_STRCT_SRC_WTR_CODE]        VARCHAR (3)     NOT NULL,
    [COOLING_WTR_INTAKE_STRCT_SRC_WTR_TXT]         VARCHAR (500)   NULL,
    [DATA_HASH]                                    VARCHAR (100)   NULL,
    CONSTRAINT [PK_COOLNG_WTR_INTKE_STRCT_INFO] PRIMARY KEY CLUSTERED ([ICS_COOLING_WTR_INTAKE_STRCT_INFO_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_COOLING_WTR_INTAKE_STRCT_INFO].[IX_CLN_WT_IN_ST_IN_IC_PR_FE_ID]...';

CREATE NONCLUSTERED INDEX [IX_CLN_WT_IN_ST_IN_IC_PR_FE_ID]
    ON [dbo].[ICS_COOLING_WTR_INTAKE_STRCT_INFO]([ICS_PRMT_FEATR_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_COPY_MGPMS_4_REQ]...';

CREATE TABLE [dbo].[ICS_COPY_MGPMS_4_REQ] (
    [ICS_COPY_MGPMS_4_REQ_ID] VARCHAR (36)  NOT NULL,
    [ICS_PAYLOAD_ID]          VARCHAR (36)  NOT NULL,
    [SRC_SYSTM_IDENT]         VARCHAR (50)  NULL,
    [PRMT_IDENT]              CHAR (9)      NOT NULL,
    [TRANSACTION_TYPE]        CHAR (1)      NULL,
    [TRANSACTION_TIMESTAMP]   DATETIME      NULL,
    [KEY_HASH]                VARCHAR (100) NULL,
    [DATA_HASH]               VARCHAR (100) NULL,
    CONSTRAINT [PK_COPY_MGPMS_4_REQ] PRIMARY KEY CLUSTERED ([ICS_COPY_MGPMS_4_REQ_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_COPY_MGPMS_4_REQ].[IX_COPY_MGPM_4_REQ_ICS_PYLD_ID]...';

CREATE NONCLUSTERED INDEX [IX_COPY_MGPM_4_REQ_ICS_PYLD_ID]
    ON [dbo].[ICS_COPY_MGPMS_4_REQ]([ICS_PAYLOAD_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_CSO_CONTROL_MEAS_DETAIL]...';

CREATE TABLE [dbo].[ICS_CSO_CONTROL_MEAS_DETAIL] (
    [ICS_CSO_CONTROL_MEAS_DETAIL_ID]    VARCHAR (36)  NOT NULL,
    [ICS_CSO_LONG_TERM_CONTROL_PLAN_ID] VARCHAR (36)  NOT NULL,
    [CSO_CONTROL_MEAS_CODE]             CHAR (1)      NULL,
    [CSO_CONTROL_MEAS_CODE_OTHR_TXT]    VARCHAR (100) NULL,
    [CSO_CONTROL_MEAS_DEV_IMP_STAT]     CHAR (1)      NULL,
    [CSO_CONTROL_MEAS_CMPL_STAT]        CHAR (1)      NULL,
    [DATA_HASH]                         VARCHAR (100) NULL,
    CONSTRAINT [PK_CSO_CONTROL_MEAS_DETAIL] PRIMARY KEY CLUSTERED ([ICS_CSO_CONTROL_MEAS_DETAIL_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_CSO_CONTROL_MEAS_DETAIL].[IX_CS_CN_ME_DT_IC_CS_LO_TE_CN]...';

CREATE NONCLUSTERED INDEX [IX_CS_CN_ME_DT_IC_CS_LO_TE_CN]
    ON [dbo].[ICS_CSO_CONTROL_MEAS_DETAIL]([ICS_CSO_LONG_TERM_CONTROL_PLAN_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_CSO_LONG_TERM_CONTROL_PLAN]...';

CREATE TABLE [dbo].[ICS_CSO_LONG_TERM_CONTROL_PLAN] (
    [ICS_CSO_LONG_TERM_CONTROL_PLAN_ID] VARCHAR (36)  NOT NULL,
    [ICS_PAYLOAD_ID]                    VARCHAR (36)  NOT NULL,
    [SRC_SYSTM_IDENT]                   VARCHAR (50)  NULL,
    [TRANSACTION_TYPE]                  CHAR (1)      NULL,
    [TRANSACTION_TIMESTAMP]             DATETIME      NULL,
    [PRMT_IDENT]                        CHAR (9)      NOT NULL,
    [KEY_HASH]                          VARCHAR (100) NULL,
    [DATA_HASH]                         VARCHAR (100) NULL,
    CONSTRAINT [PK_CSO_LONG_TERM_CONTROL_PLAN] PRIMARY KEY CLUSTERED ([ICS_CSO_LONG_TERM_CONTROL_PLAN_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_CSO_LONG_TERM_CONTROL_PLAN].[IX_CSO_LON_TER_CNT_PL_IC_PY_ID]...';

CREATE NONCLUSTERED INDEX [IX_CSO_LON_TER_CNT_PL_IC_PY_ID]
    ON [dbo].[ICS_CSO_LONG_TERM_CONTROL_PLAN]([ICS_PAYLOAD_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_CWA_316B_PROG_REP]...';

CREATE TABLE [dbo].[ICS_CWA_316B_PROG_REP] (
    [ICS_CWA_316B_PROG_REP_ID]             VARCHAR (36)   NOT NULL,
    [ICS_PAYLOAD_ID]                       VARCHAR (36)   NOT NULL,
    [SRC_SYSTM_IDENT]                      VARCHAR (50)   NULL,
    [TRANSACTION_TYPE]                     CHAR (1)       NULL,
    [TRANSACTION_TIMESTAMP]                DATETIME       NULL,
    [PRMT_IDENT]                           CHAR (9)       NOT NULL,
    [PROG_REP_FORM_SET_ID]                 VARCHAR (50)   NOT NULL,
    [PROG_REP_FORM_ID]                     INT            NULL,
    [PROG_REP_RCVD_DATE]                   DATETIME       NULL,
    [PROG_REP_START_DATE]                  DATETIME       NULL,
    [PROG_REP_END_DATE]                    DATETIME       NULL,
    [ELEC_SUBM_TYPE_CODE]                  VARCHAR (3)    NULL,
    [PROG_REP_NPDES_DAT_GRP_NUM_CODE]      VARCHAR (3)    NULL,
    [CWA_316B_CRIT_HABITAT_PROTECTION_MSR] VARCHAR (8000) NULL,
    [CWA_316B_OTHR_MON_INFO]               VARCHAR (8000) NULL,
    [KEY_HASH]                             VARCHAR (100)  NULL,
    [DATA_HASH]                            VARCHAR (100)  NULL,
    CONSTRAINT [PK_CWA_316B_PROG_REP] PRIMARY KEY CLUSTERED ([ICS_CWA_316B_PROG_REP_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_CWA_316B_PROG_REP].[IX_CWA_316B_PRO_REP_ICS_PYL_ID]...';

CREATE NONCLUSTERED INDEX [IX_CWA_316B_PRO_REP_ICS_PYL_ID]
    ON [dbo].[ICS_CWA_316B_PROG_REP]([ICS_PAYLOAD_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_CWA_316B_TAKE_INFO]...';

CREATE TABLE [dbo].[ICS_CWA_316B_TAKE_INFO] (
    [ICS_CWA_316B_TAKE_INFO_ID]                    VARCHAR (36)  NOT NULL,
    [ICS_CWA_316B_PROG_REP_ID]                     VARCHAR (36)  NOT NULL,
    [CWA_316B_TAKE_IDENT]                          VARCHAR (20)  NOT NULL,
    [CWA_316B_SPECIES_NAME]                        VARCHAR (100) NULL,
    [CWA_316B_SPECIES_COMMON_NAME]                 VARCHAR (100) NULL,
    [CWA_316B_FEDR_STAT]                           VARCHAR (3)   NULL,
    [CWA_316B_LIFESTAGE_CODE]                      VARCHAR (3)   NULL,
    [CWA_316B_TAKE_METHOD_CODE]                    VARCHAR (3)   NULL,
    [CWA_316B_TAKE_METHOD_OTHR_TXT]                VARCHAR (500) NULL,
    [CWA_316B_TAKE_TYPE_CODE]                      VARCHAR (3)   NULL,
    [CWA_316B_TAKE_TYPE_OTHR_TXT]                  VARCHAR (500) NULL,
    [CWA_316B_SPECIES_NUM]                         INT           NULL,
    [CWA_316B_SPECIES_NUM_IMPINGED_ENTRAINED]      INT           NULL,
    [CWA_316B_SPECIES_NUM_IMPINGED_ENTRAINED_DATE] DATETIME      NULL,
    [DATA_HASH]                                    VARCHAR (100) NULL,
    CONSTRAINT [PK_CWA_316B_TAKE_INFO] PRIMARY KEY CLUSTERED ([ICS_CWA_316B_TAKE_INFO_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_CWA_316B_TAKE_INFO].[IX_CW_31_TA_IN_IC_CW_31_PR_RE]...';

CREATE NONCLUSTERED INDEX [IX_CW_31_TA_IN_IC_CW_31_PR_RE]
    ON [dbo].[ICS_CWA_316B_TAKE_INFO]([ICS_CWA_316B_PROG_REP_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_GNRL_PRMT_COVERAGE_MS_4_REQ]...';

CREATE TABLE [dbo].[ICS_GNRL_PRMT_COVERAGE_MS_4_REQ] (
    [ICS_GNRL_PRMT_COVERAGE_MS_4_REQ_ID] VARCHAR (36)  NOT NULL,
    [ICS_COPY_MGPMS_4_REQ_ID]            VARCHAR (36)  NOT NULL,
    [PRMT_IDENT]                         CHAR (9)      NOT NULL,
    [DATA_HASH]                          VARCHAR (100) NULL,
    CONSTRAINT [PK_GNRL_PRMT_COVERAGE_MS_4_REQ] PRIMARY KEY CLUSTERED ([ICS_GNRL_PRMT_COVERAGE_MS_4_REQ_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_GNRL_PRMT_COVERAGE_MS_4_REQ].[IX_GN_PR_CV_MS_4_RE_IC_CO_MG_4]...';

CREATE NONCLUSTERED INDEX [IX_GN_PR_CV_MS_4_RE_IC_CO_MG_4]
    ON [dbo].[ICS_GNRL_PRMT_COVERAGE_MS_4_REQ]([ICS_COPY_MGPMS_4_REQ_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_INDST_USR_INFO]...';

CREATE TABLE [dbo].[ICS_INDST_USR_INFO] (
    [ICS_INDST_USR_INFO_ID]                          VARCHAR (36)  NOT NULL,
    [ICS_INDST_USR_INVENTORY_ID]                     VARCHAR (36)  NOT NULL,
    [PRMT_IDENT]                                     CHAR (9)      NOT NULL,
    [IU_AVER_DAILY_WW_FLOW_RATE_GPD]                 INT           NULL,
    [IU_AVER_DAILY_PRCSS_WW_FLOW_RATE_GPD]           INT           NULL,
    [IU_SUBJECT_LOC_LMTS_IND]                        CHAR (1)      NULL,
    [IU_SUBJECT_LOC_LMTS_MORE_STRINGENT_CAT_STD_IND] CHAR (1)      NULL,
    [MTCIU_SUBJECT_REDUCED_REP_IND]                  CHAR (1)      NULL,
    [NUM_IU_INSP_BY_CA]                              INT           NULL,
    [NUM_IU_SMPL_EVTS_BY_CA]                         INT           NULL,
    [NUM_REQD_IU_SELF_MON_EVTS_MAX]                  INT           NULL,
    [IU_COMPLY_REQ_SELF_MON_RPTING_IND]              CHAR (1)      NULL,
    [IU_COMPLY_REQ_SELF_MON_RPTING_TXT]              VARCHAR (500) NULL,
    [NSCIU_CERT_SUBM_TO_CA_IND]                      CHAR (1)      NULL,
    [CHANGED_DISCH_SUBM_IND]                         CHAR (1)      NULL,
    [DATA_HASH]                                      VARCHAR (100) NULL,
    CONSTRAINT [PK_INDST_USR_INFO] PRIMARY KEY CLUSTERED ([ICS_INDST_USR_INFO_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_INDST_USR_INFO].[IX_IND_USR_INF_ICS_IN_US_IN_ID]...';

CREATE NONCLUSTERED INDEX [IX_IND_USR_INF_ICS_IN_US_IN_ID]
    ON [dbo].[ICS_INDST_USR_INFO]([ICS_INDST_USR_INVENTORY_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_INDST_USR_INVENTORY]...';

CREATE TABLE [dbo].[ICS_INDST_USR_INVENTORY] (
    [ICS_INDST_USR_INVENTORY_ID] VARCHAR (36)  NOT NULL,
    [ICS_PRETR_PROG_REP_ID]      VARCHAR (36)  NOT NULL,
    [INDST_USR_IND]              CHAR (1)      NULL,
    [DATA_HASH]                  VARCHAR (100) NULL,
    CONSTRAINT [PK_INDST_USR_INVENTORY] PRIMARY KEY CLUSTERED ([ICS_INDST_USR_INVENTORY_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_INDST_USR_INVENTORY].[IX_IND_USR_INV_ICS_PR_PR_RE_ID]...';

CREATE NONCLUSTERED INDEX [IX_IND_USR_INV_ICS_PR_PR_RE_ID]
    ON [dbo].[ICS_INDST_USR_INVENTORY]([ICS_PRETR_PROG_REP_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_INSP_CMNT_TXT]...';

CREATE TABLE [dbo].[ICS_INSP_CMNT_TXT] (
    [ICS_INSP_CMNT_TXT_ID] VARCHAR (36)   NOT NULL,
    [ICS_CMPL_MON_ID]      VARCHAR (36)   NOT NULL,
    [INSP_CMNT_TXT]        VARCHAR (4000) NOT NULL,
    [DATA_HASH]            VARCHAR (100)  NULL,
    CONSTRAINT [PK_INSP_CMNT_TXT] PRIMARY KEY CLUSTERED ([ICS_INSP_CMNT_TXT_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_INSP_CMNT_TXT].[IX_INSP_CMN_TXT_ICS_CMP_MON_ID]...';

CREATE NONCLUSTERED INDEX [IX_INSP_CMN_TXT_ICS_CMP_MON_ID]
    ON [dbo].[ICS_INSP_CMNT_TXT]([ICS_CMPL_MON_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_INSP_V_CONTACT]...';

CREATE TABLE [dbo].[ICS_INSP_V_CONTACT] (
    [ICS_INSP_V_CONTACT_ID] VARCHAR (36)  NOT NULL,
    [ICS_CMPL_MON_ID]         VARCHAR (36)  NOT NULL,
    [AFFIL_TYPE_TXT]          VARCHAR (3)   NOT NULL,
    [ELEC_ADDR_TXT]           VARCHAR (100) NULL,
    [DATA_HASH]               VARCHAR (100) NULL,
    CONSTRAINT [PK_INSP_V_CONTACT] PRIMARY KEY CLUSTERED ([ICS_INSP_V_CONTACT_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_INSP_V_CONTACT].[IX_INSP_V_CNT_ICS_CMP_MON_ID]...';

CREATE NONCLUSTERED INDEX [IX_INSP_V_CNT_ICS_CMP_MON_ID]
    ON [dbo].[ICS_INSP_V_CONTACT]([ICS_CMPL_MON_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_IU_ENF_ACTN_TYPES]...';

CREATE TABLE [dbo].[ICS_IU_ENF_ACTN_TYPES] (
    [ICS_IU_ENF_ACTN_TYPES_ID]  VARCHAR (36)  NOT NULL,
    [ICS_IU_ENFRC_ACTN_INFO_ID] VARCHAR (36)  NOT NULL,
    [IU_ENF_ACTN_TYPE_CODE]     VARCHAR (3)   NOT NULL,
    [IU_ENF_ACTN_TYPE_OTHR_TXT] VARCHAR (500) NULL,
    [NUM_IU_ENF_ACTIONS]        INT           NULL,
    [DATA_HASH]                 VARCHAR (100) NULL,
    CONSTRAINT [PK_IU_ENF_ACTN_TYPES] PRIMARY KEY CLUSTERED ([ICS_IU_ENF_ACTN_TYPES_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_IU_ENF_ACTN_TYPES].[IX_IU_EN_AC_TY_IC_IU_EN_AC_IN]...';

CREATE NONCLUSTERED INDEX [IX_IU_EN_AC_TY_IC_IU_EN_AC_IN]
    ON [dbo].[ICS_IU_ENF_ACTN_TYPES]([ICS_IU_ENFRC_ACTN_INFO_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_IU_ENFRC_ACTN_INFO]...';

CREATE TABLE [dbo].[ICS_IU_ENFRC_ACTN_INFO] (
    [ICS_IU_ENFRC_ACTN_INFO_ID]         VARCHAR (36)    NOT NULL,
    [ICS_INDST_USR_INFO_ID]             VARCHAR (36)    NOT NULL,
    [SNC_PRETR_ENF_CMPL_SCHED_STAT_IND] CHAR (1)        NULL,
    [IU_CASH_CIVIL_PNLTY_AMT_ASSESSED]  DECIMAL (14, 2) NULL,
    [IU_CASH_CIVIL_PNLTY_AMT_COLL]      DECIMAL (14, 2) NULL,
    [DATA_HASH]                         VARCHAR (100)   NULL,
    CONSTRAINT [PK_IU_ENFRC_ACTN_INFO] PRIMARY KEY CLUSTERED ([ICS_IU_ENFRC_ACTN_INFO_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_IU_ENFRC_ACTN_INFO].[IX_IU_ENF_AC_IN_IC_IN_US_IN_ID]...';

CREATE NONCLUSTERED INDEX [IX_IU_ENF_AC_IN_IC_IN_US_IN_ID]
    ON [dbo].[ICS_IU_ENFRC_ACTN_INFO]([ICS_INDST_USR_INFO_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_IU_VIOL_INFO]...';

CREATE TABLE [dbo].[ICS_IU_VIOL_INFO] (
    [ICS_IU_VIOL_INFO_ID]                      VARCHAR (36)   NOT NULL,
    [ICS_INDST_USR_INFO_ID]                    VARCHAR (36)   NOT NULL,
    [SNC_PRETR_STND_LMTS_IND]                  CHAR (1)       NULL,
    [SNC_RPT_RQMT_IND]                         CHAR (1)       NULL,
    [SNC_OTH_CTRL_MECH_RQMT_IND]               CHAR (1)       NULL,
    [SNC_REL_POTW_DISCH_OPER_IND]              CHAR (1)       NULL,
    [SNC_REL_POTW_DISCH_OPER_TXT]              VARCHAR (4000) NULL,
    [SNC_REL_POTW_BIO_OPER_SEWG_SLUD_MGMT_IND] CHAR (1)       NULL,
    [SNC_REL_POTW_BIO_OPER_SEWG_SLUD_MGMT_TXT] VARCHAR (4000) NULL,
    [SNC_PUBL_IND]                             CHAR (1)       NULL,
    [DATA_HASH]                                VARCHAR (100)  NULL,
    CONSTRAINT [PK_IU_VIOL_INFO] PRIMARY KEY CLUSTERED ([ICS_IU_VIOL_INFO_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_IU_VIOL_INFO].[IX_IU_VIO_INF_ICS_IND_US_IN_ID]...';

CREATE NONCLUSTERED INDEX [IX_IU_VIO_INF_ICS_IND_US_IN_ID]
    ON [dbo].[ICS_IU_VIOL_INFO]([ICS_INDST_USR_INFO_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_LNK_CMPL_MON]...';

CREATE TABLE [dbo].[ICS_LNK_CMPL_MON] (
    [ICS_LNK_CMPL_MON_ID] VARCHAR (36)  NOT NULL,
    [ICS_CMPL_MON_LNK_ID] VARCHAR (36)  NOT NULL,
    [CMPL_MON_IDENT]      VARCHAR (25)  NULL,
    [DATA_HASH]           VARCHAR (100) NULL,
    CONSTRAINT [PK_LNK_CMPL_MON] PRIMARY KEY CLUSTERED ([ICS_LNK_CMPL_MON_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_LNK_CMPL_MON].[IX_LNK_CMP_MON_ICS_CM_MO_LN_ID]...';

CREATE NONCLUSTERED INDEX [IX_LNK_CMP_MON_ICS_CM_MO_LN_ID]
    ON [dbo].[ICS_LNK_CMPL_MON]([ICS_CMPL_MON_LNK_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_LOC_LMTS_PARAMETERS]...';

CREATE TABLE [dbo].[ICS_LOC_LMTS_PARAMETERS] (
    [ICS_LOC_LMTS_PARAMETERS_ID]    VARCHAR (36)  NOT NULL,
    [ICS_CONTROL_AUTH_PROG_INFO_ID] VARCHAR (36)  NOT NULL,
    [LOC_LMTS_PARAMETERS]           VARCHAR (255) NOT NULL,
    [DATA_HASH]                     VARCHAR (100) NULL,
    CONSTRAINT [PK_LOC_LMTS_PARAMETERS] PRIMARY KEY CLUSTERED ([ICS_LOC_LMTS_PARAMETERS_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_LOC_LMTS_PARAMETERS].[IX_LOC_LM_PR_IC_CN_AU_PR_IN_ID]...';

CREATE NONCLUSTERED INDEX [IX_LOC_LM_PR_IC_CN_AU_PR_IN_ID]
    ON [dbo].[ICS_LOC_LMTS_PARAMETERS]([ICS_CONTROL_AUTH_PROG_INFO_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_LTCP_ENFORCEABLE_MECH_DETAIL]...';

CREATE TABLE [dbo].[ICS_LTCP_ENFORCEABLE_MECH_DETAIL] (
    [ICS_LTCP_ENFORCEABLE_MECH_DETAIL_ID] VARCHAR (36)  NOT NULL,
    [ICS_CSO_LONG_TERM_CONTROL_PLAN_ID]   VARCHAR (36)  NOT NULL,
    [LTCP_ENFORCEABLE_MECH_CODE]          CHAR (1)      NULL,
    [LTCP_ENFORCEABLE_MECH_CODE_OTHR_TXT] VARCHAR (100) NULL,
    [DATA_HASH]                           VARCHAR (100) NULL,
    CONSTRAINT [PK_LTCP_ENFORCEABLE_MECH_DETIL] PRIMARY KEY CLUSTERED ([ICS_LTCP_ENFORCEABLE_MECH_DETAIL_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_LTCP_ENFORCEABLE_MECH_DETAIL].[IX_LT_EN_ME_DT_IC_CS_LO_TE_CN]...';

CREATE NONCLUSTERED INDEX [IX_LT_EN_ME_DT_IC_CS_LO_TE_CN]
    ON [dbo].[ICS_LTCP_ENFORCEABLE_MECH_DETAIL]([ICS_CSO_LONG_TERM_CONTROL_PLAN_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_LTCP_MOST_RECENT_REVISION_DETAIL]...';

CREATE TABLE [dbo].[ICS_LTCP_MOST_RECENT_REVISION_DETAIL] (
    [ICS_LTCP_MOST_RECENT_REVISION_DETAIL_ID] VARCHAR (36)  NOT NULL,
    [ICS_CSO_LONG_TERM_CONTROL_PLAN_ID]       VARCHAR (36)  NOT NULL,
    [LTCP_MOST_RECENT_REVISION_DATE]          DATETIME      NULL,
    [LTCP_MOST_RECENT_REVISION_STAT]          VARCHAR (3)   NULL,
    [DATA_HASH]                               VARCHAR (100) NULL,
    CONSTRAINT [PK_LTCP_MOST_RECNT_RVISON_DTIL] PRIMARY KEY CLUSTERED ([ICS_LTCP_MOST_RECENT_REVISION_DETAIL_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_LTCP_MOST_RECENT_REVISION_DETAIL].[IX_LT_MO_RC_RV_DT_IC_CS_LO_TE]...';

CREATE NONCLUSTERED INDEX [IX_LT_MO_RC_RV_DT_IC_CS_LO_TE]
    ON [dbo].[ICS_LTCP_MOST_RECENT_REVISION_DETAIL]([ICS_CSO_LONG_TERM_CONTROL_PLAN_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_LTCP_SUMM]...';

CREATE TABLE [dbo].[ICS_LTCP_SUMM] (
    [ICS_LTCP_SUMM_ID]                    VARCHAR (36)  NOT NULL,
    [ICS_CSO_LONG_TERM_CONTROL_PLAN_ID]   VARCHAR (36)  NOT NULL,
    [LTCP_REQD_IND]                       CHAR (1)      NULL,
    [LTCP_IN_CMPL_IND]                    CHAR (1)      NULL,
    [LTCP_APRVL_DATE]                     DATETIME      NULL,
    [LTCP_AND_CSO_CONTROLS_COMPLETE_DATE] DATETIME      NULL,
    [CSO_POST_CNST_CMPL_MON_PROG]         CHAR (1)      NULL,
    [CSO_CONTROLS_OTHR_THAN_LTCP]         VARCHAR (100) NULL,
    [DATA_HASH]                           VARCHAR (100) NULL,
    CONSTRAINT [PK_LTCP_SUMM] PRIMARY KEY CLUSTERED ([ICS_LTCP_SUMM_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_LTCP_SUMM].[IX_LTC_SU_IC_CS_LO_TE_CN_PL_ID]...';

CREATE NONCLUSTERED INDEX [IX_LTC_SU_IC_CS_LO_TE_CN_PL_ID]
    ON [dbo].[ICS_LTCP_SUMM]([ICS_CSO_LONG_TERM_CONTROL_PLAN_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_MS_4_ACTY_IDENT]...';

CREATE TABLE [dbo].[ICS_MS_4_ACTY_IDENT] (
    [ICS_MS_4_ACTY_IDENT_ID]  VARCHAR (36)  NOT NULL,
    [ICS_COPY_MGPMS_4_REQ_ID] VARCHAR (36)  NOT NULL,
    [MS_4_ACTY_IDENT]         VARCHAR (40)  NOT NULL,
    [DATA_HASH]               VARCHAR (100) NULL,
    CONSTRAINT [PK_MS_4_ACTY_IDENT] PRIMARY KEY CLUSTERED ([ICS_MS_4_ACTY_IDENT_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_MS_4_ACTY_IDENT].[IX_MS_4_AC_ID_IC_CO_MG_4_RE_ID]...';

CREATE NONCLUSTERED INDEX [IX_MS_4_AC_ID_IC_CO_MG_4_RE_ID]
    ON [dbo].[ICS_MS_4_ACTY_IDENT]([ICS_COPY_MGPMS_4_REQ_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_MS_4_CNST_SW_PROCEDURES]...';

CREATE TABLE [dbo].[ICS_MS_4_CNST_SW_PROCEDURES] (
    [ICS_MS_4_CNST_SW_PROCEDURES_ID]  VARCHAR (36)   NOT NULL,
    [ICS_MS_4_CNST_SW_REQS_ID]        VARCHAR (36)   NOT NULL,
    [MS_4_ACTY_IDENT]                 VARCHAR (40)   NOT NULL,
    [MS_4_CNST_SW_PROCEDURE_TYPE]     VARCHAR (3)    NULL,
    [MS_4_CNST_SW_PROCEDURE_TXT]      VARCHAR (4000) NULL,
    [MS_4_CNST_SW_PROCEDURE_SCHD_TXT] VARCHAR (4000) NULL,
    [DATA_HASH]                       VARCHAR (100)  NULL,
    CONSTRAINT [PK_MS_4_CNST_SW_PROCEDURES] PRIMARY KEY CLUSTERED ([ICS_MS_4_CNST_SW_PROCEDURES_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_MS_4_CNST_SW_PROCEDURES].[IX_MS_4_CN_SW_PR_IC_MS_4_CN_SW]...';

CREATE NONCLUSTERED INDEX [IX_MS_4_CN_SW_PR_IC_MS_4_CN_SW]
    ON [dbo].[ICS_MS_4_CNST_SW_PROCEDURES]([ICS_MS_4_CNST_SW_REQS_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_MS_4_CNST_SW_REGULATED_ENTITY_INFO]...';

CREATE TABLE [dbo].[ICS_MS_4_CNST_SW_REGULATED_ENTITY_INFO] (
    [ICS_MS_4_CNST_SW_REGULATED_ENTITY_INFO_ID] VARCHAR (36)  NOT NULL,
    [ICS_MS_4_CNST_SW_REQS_ID]                  VARCHAR (36)  NOT NULL,
    [MS_4_ACTY_IDENT]                           VARCHAR (40)  NOT NULL,
    [MS_4_REGULATED_ENTITY_IDENT]               VARCHAR (40)  NULL,
    [MS_4_CNST_SW_EROSION_ORDINANCE_STAT]       VARCHAR (3)   NULL,
    [MS_4_CNST_SW_EROSION_ORDINANCE_STAT_TXT]   VARCHAR (500) NULL,
    [MS_4_CNST_SW_EROSION_PLAN_RVIW_STAT]       VARCHAR (3)   NULL,
    [MS_4_CNST_SW_EROSION_PLAN_RVIW_STAT_TXT]   VARCHAR (500) NULL,
    [MS_4_CNST_SW_SITE_INSP_STAT]               VARCHAR (3)   NULL,
    [MS_4_CNST_SW_SITE_INSP_STAT_TXT]           VARCHAR (500) NULL,
    [DATA_HASH]                                 VARCHAR (100) NULL,
    CONSTRAINT [PK_MS_4_CNST_SW_RGLT_ENTT_INFO] PRIMARY KEY CLUSTERED ([ICS_MS_4_CNST_SW_REGULATED_ENTITY_INFO_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_MS_4_CNST_SW_REGULATED_ENTITY_INFO].[IX_MS_4_CN_SW_RG_EN_IN_IC_MS_4]...';

CREATE NONCLUSTERED INDEX [IX_MS_4_CN_SW_RG_EN_IN_IC_MS_4]
    ON [dbo].[ICS_MS_4_CNST_SW_REGULATED_ENTITY_INFO]([ICS_MS_4_CNST_SW_REQS_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_MS_4_CNST_SW_REQS]...';

CREATE TABLE [dbo].[ICS_MS_4_CNST_SW_REQS] (
    [ICS_MS_4_CNST_SW_REQS_ID] VARCHAR (36)  NOT NULL,
    [ICS_SWMS_4_PRMT_ID]       VARCHAR (36)  NOT NULL,
    [DATA_HASH]                VARCHAR (100) NULL,
    CONSTRAINT [PK_MS_4_CNST_SW_REQS] PRIMARY KEY CLUSTERED ([ICS_MS_4_CNST_SW_REQS_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_MS_4_CNST_SW_REQS].[IX_MS_4_CN_SW_RE_IC_SW_4_PR_ID]...';

CREATE NONCLUSTERED INDEX [IX_MS_4_CN_SW_RE_IC_SW_4_PR_ID]
    ON [dbo].[ICS_MS_4_CNST_SW_REQS]([ICS_SWMS_4_PRMT_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_MS_4_ILLICIT_DETECT_PROCEDURES]...';

CREATE TABLE [dbo].[ICS_MS_4_ILLICIT_DETECT_PROCEDURES] (
    [ICS_MS_4_ILLICIT_DETECT_PROCEDURES_ID]  VARCHAR (36)   NOT NULL,
    [ICS_MS_4_ILLICIT_DETECT_REQS_ID]        VARCHAR (36)   NOT NULL,
    [MS_4_ACTY_IDENT]                        VARCHAR (40)   NOT NULL,
    [MS_4_ILLICIT_DETECT_PROCEDURE_TYPE]     VARCHAR (3)    NULL,
    [MS_4_ILLICIT_DETECT_PROCEDURE_TXT]      VARCHAR (4000) NULL,
    [MS_4_ILLICIT_DETECT_PROCEDURE_SCHD_TXT] VARCHAR (4000) NULL,
    [DATA_HASH]                              VARCHAR (100)  NULL,
    CONSTRAINT [PK_MS_4_ILLICT_DETCT_PROCEDURS] PRIMARY KEY CLUSTERED ([ICS_MS_4_ILLICIT_DETECT_PROCEDURES_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_MS_4_ILLICIT_DETECT_PROCEDURES].[IX_MS_4_IL_DT_PR_IC_MS_4_IL_DT]...';

CREATE NONCLUSTERED INDEX [IX_MS_4_IL_DT_PR_IC_MS_4_IL_DT]
    ON [dbo].[ICS_MS_4_ILLICIT_DETECT_PROCEDURES]([ICS_MS_4_ILLICIT_DETECT_REQS_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO]...';

CREATE TABLE [dbo].[ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO] (
    [ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO_ID]   VARCHAR (36)  NOT NULL,
    [ICS_MS_4_ILLICIT_DETECT_REQS_ID]                    VARCHAR (36)  NOT NULL,
    [MS_4_ACTY_IDENT]                                    VARCHAR (40)  NOT NULL,
    [MS_4_REGULATED_ENTITY_IDENT]                        VARCHAR (40)  NULL,
    [MS_4_PRMT_ILLICIT_DETECT_OUTFALL_MAPPING_DATE]      DATETIME      NULL,
    [MS_4_ILLICIT_DETECT_OUTFALL_MAPPING_STAT]           VARCHAR (3)   NULL,
    [MS_4_PRMT_ILLICIT_DETECT_OUTFALL_TTL_NUM]           INT           NULL,
    [MS_4_PRMT_ILLICIT_DETECT_OUTFALL_MAPPED_NUM]        INT           NULL,
    [MS_4_ILLICIT_DETECT_PROHIBITION_ORDINANCE_STAT]     VARCHAR (3)   NULL,
    [MS_4_ILLICIT_DETECT_PROHIBITION_ORDINANCE_STAT_TXT] VARCHAR (500) NULL,
    [DATA_HASH]                                          VARCHAR (100) NULL,
    CONSTRAINT [PK_MS_4_ILLC_DTCT_RGLT_ENT_INF] PRIMARY KEY CLUSTERED ([ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO].[IX_MS_4_IL_DT_RG_EN_IN_IC_MS_4]...';

CREATE NONCLUSTERED INDEX [IX_MS_4_IL_DT_RG_EN_IN_IC_MS_4]
    ON [dbo].[ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO]([ICS_MS_4_ILLICIT_DETECT_REQS_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO_PROG_REP]...';

CREATE TABLE [dbo].[ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO_PROG_REP] (
    [ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO_PROG_REP_ID] VARCHAR (36)   NOT NULL,
    [ICS_SWMS_4_ANNUL_PROG_REP_ID]                              VARCHAR (36)   NOT NULL,
    [MS_4_ACTY_IDENT]                                           VARCHAR (40)   NOT NULL,
    [MS_4_PROG_REP_ILLICIT_DETECT_OUTFALL_MAPPING_DATE]         DATETIME       NULL,
    [MS_4_PROG_REP_ILLICIT_DETECT_OUTFALL_TTL_NUM]              INT            NULL,
    [MS_4_PROG_REP_ILLICIT_DETECT_OUTFALL_MAPPED_NUM]           INT            NULL,
    [MS_4_REGULATED_ENTITY_CMPL_STAT]                           CHAR (1)       NULL,
    [MS_4_REGULATED_ENTITY_CMPL_STAT_TXT]                       VARCHAR (2000) NULL,
    [MS_4_PROG_REP_REQS_ACTIVITIES]                             VARCHAR (8000) NULL,
    [DATA_HASH]                                                 VARCHAR (100)  NULL,
    CONSTRAINT [PK_MS_4_ILL_DTC_RG_EN_IN_PR_RE] PRIMARY KEY CLUSTERED ([ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO_PROG_REP_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO_PROG_REP].[IX_MS_4_IL_DT_RG_EN_IN_PR_RE_I]...';

CREATE NONCLUSTERED INDEX [IX_MS_4_IL_DT_RG_EN_IN_PR_RE_I]
    ON [dbo].[ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO_PROG_REP]([ICS_SWMS_4_ANNUL_PROG_REP_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_MS_4_ILLICIT_DETECT_REQS]...';

CREATE TABLE [dbo].[ICS_MS_4_ILLICIT_DETECT_REQS] (
    [ICS_MS_4_ILLICIT_DETECT_REQS_ID] VARCHAR (36)  NOT NULL,
    [ICS_SWMS_4_PRMT_ID]              VARCHAR (36)  NOT NULL,
    [DATA_HASH]                       VARCHAR (100) NULL,
    CONSTRAINT [PK_MS_4_ILLICIT_DETECT_REQS] PRIMARY KEY CLUSTERED ([ICS_MS_4_ILLICIT_DETECT_REQS_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_MS_4_ILLICIT_DETECT_REQS].[IX_MS_4_IL_DT_RE_IC_SW_4_PR_ID]...';

CREATE NONCLUSTERED INDEX [IX_MS_4_IL_DT_RE_IC_SW_4_PR_ID]
    ON [dbo].[ICS_MS_4_ILLICIT_DETECT_REQS]([ICS_SWMS_4_PRMT_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_MS_4_INDST_SW_PROCEDURES]...';

CREATE TABLE [dbo].[ICS_MS_4_INDST_SW_PROCEDURES] (
    [ICS_MS_4_INDST_SW_PROCEDURES_ID]  VARCHAR (36)   NOT NULL,
    [ICS_MS_4_INDST_SW_REQS_ID]        VARCHAR (36)   NOT NULL,
    [MS_4_ACTY_IDENT]                  VARCHAR (40)   NOT NULL,
    [MS_4_INDST_SW_PROCEDURE_TYPE]     VARCHAR (3)    NULL,
    [MS_4_INDST_SW_PROCEDURE_TXT]      VARCHAR (4000) NULL,
    [MS_4_INDST_SW_PROCEDURE_SCHD_TXT] VARCHAR (4000) NULL,
    [DATA_HASH]                        VARCHAR (100)  NULL,
    CONSTRAINT [PK_MS_4_INDST_SW_PROCEDURES] PRIMARY KEY CLUSTERED ([ICS_MS_4_INDST_SW_PROCEDURES_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_MS_4_INDST_SW_PROCEDURES].[IX_MS_4_IN_SW_PR_IC_MS_4_IN_SW]...';

CREATE NONCLUSTERED INDEX [IX_MS_4_IN_SW_PR_IC_MS_4_IN_SW]
    ON [dbo].[ICS_MS_4_INDST_SW_PROCEDURES]([ICS_MS_4_INDST_SW_REQS_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_MS_4_INDST_SW_REGULATED_ENTITY_INFO]...';

CREATE TABLE [dbo].[ICS_MS_4_INDST_SW_REGULATED_ENTITY_INFO] (
    [ICS_MS_4_INDST_SW_REGULATED_ENTITY_INFO_ID] VARCHAR (36)  NOT NULL,
    [ICS_MS_4_INDST_SW_REQS_ID]                  VARCHAR (36)  NOT NULL,
    [MS_4_ACTY_IDENT]                            VARCHAR (40)  NOT NULL,
    [MS_4_REGULATED_ENTITY_IDENT]                VARCHAR (40)  NULL,
    [MS_4_INDST_SW_ORDINANCE_STAT]               VARCHAR (3)   NULL,
    [MS_4_INDST_SW_ORDINANCE_STAT_TXT]           VARCHAR (500) NULL,
    [MS_4_INDST_SW_INDST_INVENTORY_STAT]         VARCHAR (3)   NULL,
    [MS_4_INDST_SW_INDST_INVENTORY_STAT_TXT]     VARCHAR (500) NULL,
    [MS_4_INDST_SW_MON_STAT]                     VARCHAR (3)   NULL,
    [MS_4_INDST_SW_MON_STAT_TXT]                 VARCHAR (500) NULL,
    [DATA_HASH]                                  VARCHAR (100) NULL,
    CONSTRAINT [PK_MS_4_INDS_SW_RGLT_ENTT_INFO] PRIMARY KEY CLUSTERED ([ICS_MS_4_INDST_SW_REGULATED_ENTITY_INFO_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_MS_4_INDST_SW_REGULATED_ENTITY_INFO].[IX_MS_4_IN_SW_RG_EN_IN_IC_MS_4]...';

CREATE NONCLUSTERED INDEX [IX_MS_4_IN_SW_RG_EN_IN_IC_MS_4]
    ON [dbo].[ICS_MS_4_INDST_SW_REGULATED_ENTITY_INFO]([ICS_MS_4_INDST_SW_REQS_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_MS_4_INDST_SW_REQS]...';

CREATE TABLE [dbo].[ICS_MS_4_INDST_SW_REQS] (
    [ICS_MS_4_INDST_SW_REQS_ID] VARCHAR (36)  NOT NULL,
    [ICS_SWMS_4_PRMT_ID]        VARCHAR (36)  NOT NULL,
    [DATA_HASH]                 VARCHAR (100) NULL,
    CONSTRAINT [PK_MS_4_INDST_SW_REQS] PRIMARY KEY CLUSTERED ([ICS_MS_4_INDST_SW_REQS_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_MS_4_INDST_SW_REQS].[IX_MS_4_IN_SW_RE_IC_SW_4_PR_ID]...';

CREATE NONCLUSTERED INDEX [IX_MS_4_IN_SW_RE_IC_SW_4_PR_ID]
    ON [dbo].[ICS_MS_4_INDST_SW_REQS]([ICS_SWMS_4_PRMT_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_MS_4_OTHR_APPL_REQS]...';

CREATE TABLE [dbo].[ICS_MS_4_OTHR_APPL_REQS] (
    [ICS_MS_4_OTHR_APPL_REQS_ID]   VARCHAR (36)   NOT NULL,
    [ICS_SWMS_4_PRMT_ID]           VARCHAR (36)   NOT NULL,
    [MS_4_ACTY_IDENT]              VARCHAR (40)   NOT NULL,
    [MS_4_OTHR_APPL_REQS_TXT]      VARCHAR (4000) NULL,
    [MS_4_OTHR_APPL_REQS_SCHD_TXT] VARCHAR (4000) NULL,
    [DATA_HASH]                    VARCHAR (100)  NULL,
    CONSTRAINT [PK_MS_4_OTHR_APPL_REQS] PRIMARY KEY CLUSTERED ([ICS_MS_4_OTHR_APPL_REQS_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_MS_4_OTHR_APPL_REQS].[IX_MS_4_OT_AP_RE_IC_SW_4_PR_ID]...';

CREATE NONCLUSTERED INDEX [IX_MS_4_OT_AP_RE_IC_SW_4_PR_ID]
    ON [dbo].[ICS_MS_4_OTHR_APPL_REQS]([ICS_SWMS_4_PRMT_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_MS_4_PBLC_EDUCATION_REQS]...';

CREATE TABLE [dbo].[ICS_MS_4_PBLC_EDUCATION_REQS] (
    [ICS_MS_4_PBLC_EDUCATION_REQS_ID]              VARCHAR (36)   NOT NULL,
    [ICS_SWMS_4_PRMT_ID]                           VARCHAR (36)   NOT NULL,
    [MS_4_ACTY_IDENT]                              VARCHAR (40)   NOT NULL,
    [MS_4_PBLC_EDUCATION_REQS_TXT]                 VARCHAR (4000) NULL,
    [MS_4_PBLC_EDUCATION_SCHD_TXT]                 VARCHAR (4000) NULL,
    [MS_4_PBLC_EDUCATION_DELIVERY_OPTION]          VARCHAR (3)    NULL,
    [MS_4_PBLC_EDUCATION_DELIVERY_OPTION_OTHR_TXT] VARCHAR (500)  NULL,
    [MS_4_PBLC_EDUCATION_SUBJECT_OPTION]           VARCHAR (3)    NULL,
    [MS_4_PBLC_EDUCATION_SUBJECT_OPTION_OTHR_TXT]  VARCHAR (500)  NULL,
    [MS_4_PBLC_EDUCATION_AUDIENCE_OPTION]          VARCHAR (3)    NULL,
    [MS_4_PBLC_EDUCATION_AUDIENCE_OPTION_OTHR_TXT] VARCHAR (500)  NULL,
    [DATA_HASH]                                    VARCHAR (100)  NULL,
    CONSTRAINT [PK_MS_4_PBLC_EDUCATION_REQS] PRIMARY KEY CLUSTERED ([ICS_MS_4_PBLC_EDUCATION_REQS_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_MS_4_PBLC_EDUCATION_REQS].[IX_MS_4_PB_ED_RE_IC_SW_4_PR_ID]...';

CREATE NONCLUSTERED INDEX [IX_MS_4_PB_ED_RE_IC_SW_4_PR_ID]
    ON [dbo].[ICS_MS_4_PBLC_EDUCATION_REQS]([ICS_SWMS_4_PRMT_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_MS_4_PBLC_INVOLVEMENT_REQS]...';

CREATE TABLE [dbo].[ICS_MS_4_PBLC_INVOLVEMENT_REQS] (
    [ICS_MS_4_PBLC_INVOLVEMENT_REQS_ID]                 VARCHAR (36)   NOT NULL,
    [ICS_SWMS_4_PRMT_ID]                                VARCHAR (36)   NOT NULL,
    [MS_4_ACTY_IDENT]                                   VARCHAR (40)   NOT NULL,
    [MS_4_PBLC_INVOLVEMENT_REQS_TXT]                    VARCHAR (4000) NULL,
    [MS_4_PBLC_INVOLVEMENT_SCHD_TXT]                    VARCHAR (4000) NULL,
    [MS_4_PBLC_INVOLVEMENT_DELIVERY_OPTION]             VARCHAR (3)    NULL,
    [MS_4_PBLC_INVOLVEMENT_DELIVERY_OPTION_OTHR_TXT]    VARCHAR (500)  NULL,
    [MS_4_PBLC_INVOLVEMENT_SUBJECT_OPTION]              VARCHAR (3)    NULL,
    [MS_4_PBLC_INVOLVEMENT_SUBJECT_OPTION_OTHR_TXT]     VARCHAR (500)  NULL,
    [MS_4_PBLC_INVOLVEMENT_PARTICIPANT_OPTION]          VARCHAR (3)    NULL,
    [MS_4_PBLC_INVOLVEMENT_PARTICIPANT_OPTION_OTHR_TXT] VARCHAR (500)  NULL,
    [DATA_HASH]                                         VARCHAR (100)  NULL,
    CONSTRAINT [PK_MS_4_PBLC_INVOLVEMENT_REQS] PRIMARY KEY CLUSTERED ([ICS_MS_4_PBLC_INVOLVEMENT_REQS_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_MS_4_PBLC_INVOLVEMENT_REQS].[IX_MS_4_PB_IN_RE_IC_SW_4_PR_ID]...';

CREATE NONCLUSTERED INDEX [IX_MS_4_PB_IN_RE_IC_SW_4_PR_ID]
    ON [dbo].[ICS_MS_4_PBLC_INVOLVEMENT_REQS]([ICS_SWMS_4_PRMT_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_MS_4_POLLUTION_PREVENTION_REQS]...';

CREATE TABLE [dbo].[ICS_MS_4_POLLUTION_PREVENTION_REQS] (
    [ICS_MS_4_POLLUTION_PREVENTION_REQS_ID] VARCHAR (36)   NOT NULL,
    [ICS_SWMS_4_PRMT_ID]                    VARCHAR (36)   NOT NULL,
    [MS_4_ACTY_IDENT]                       VARCHAR (40)   NOT NULL,
    [MS_4_POLLUTION_PREVENTION_REQS_TXT]    VARCHAR (4000) NULL,
    [MS_4_POLLUTION_PREVENTION_SCHD_TXT]    VARCHAR (4000) NULL,
    [DATA_HASH]                             VARCHAR (100)  NULL,
    CONSTRAINT [PK_MS_4_POLLUTON_PRVNTION_REQS] PRIMARY KEY CLUSTERED ([ICS_MS_4_POLLUTION_PREVENTION_REQS_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_MS_4_POLLUTION_PREVENTION_REQS].[IX_MS_4_PL_PR_RE_IC_SW_4_PR_ID]...';

CREATE NONCLUSTERED INDEX [IX_MS_4_PL_PR_RE_IC_SW_4_PR_ID]
    ON [dbo].[ICS_MS_4_POLLUTION_PREVENTION_REQS]([ICS_SWMS_4_PRMT_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_MS_4_POST_CNST_SW_PROCEDURES]...';

CREATE TABLE [dbo].[ICS_MS_4_POST_CNST_SW_PROCEDURES] (
    [ICS_MS_4_POST_CNST_SW_PROCEDURES_ID]  VARCHAR (36)   NOT NULL,
    [ICS_MS_4_POST_CNST_SW_REQS_ID]        VARCHAR (36)   NOT NULL,
    [MS_4_ACTY_IDENT]                      VARCHAR (40)   NOT NULL,
    [MS_4_POST_CNST_SW_PROCEDURE_TYPE]     VARCHAR (3)    NULL,
    [MS_4_POST_CNST_SW_PROCEDURE_TXT]      VARCHAR (4000) NULL,
    [MS_4_POST_CNST_SW_PROCEDURE_SCHD_TXT] VARCHAR (4000) NULL,
    [DATA_HASH]                            VARCHAR (100)  NULL,
    CONSTRAINT [PK_MS_4_POST_CNST_SW_PROCEDURS] PRIMARY KEY CLUSTERED ([ICS_MS_4_POST_CNST_SW_PROCEDURES_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_MS_4_POST_CNST_SW_PROCEDURES].[IX_MS_4_PO_CN_SW_PR_IC_MS_4_PO]...';

CREATE NONCLUSTERED INDEX [IX_MS_4_PO_CN_SW_PR_IC_MS_4_PO]
    ON [dbo].[ICS_MS_4_POST_CNST_SW_PROCEDURES]([ICS_MS_4_POST_CNST_SW_REQS_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_MS_4_POST_CNST_SW_REGULATED_ENTITY_INFO]...';

CREATE TABLE [dbo].[ICS_MS_4_POST_CNST_SW_REGULATED_ENTITY_INFO] (
    [ICS_MS_4_POST_CNST_SW_REGULATED_ENTITY_INFO_ID] VARCHAR (36)  NOT NULL,
    [ICS_MS_4_POST_CNST_SW_REQS_ID]                  VARCHAR (36)  NOT NULL,
    [MS_4_ACTY_IDENT]                                VARCHAR (40)  NOT NULL,
    [MS_4_REGULATED_ENTITY_IDENT]                    VARCHAR (40)  NULL,
    [MS_4_POST_CNST_SW_RUNOFF_ORDINANCE_STAT]        VARCHAR (3)   NULL,
    [MS_4_POST_CNST_SW_RUNOFF_ORDINANCE_STAT_TXT]    VARCHAR (500) NULL,
    [MS_4_POST_CNST_SW_RUNOFF_PROG_STAT]             VARCHAR (3)   NULL,
    [MS_4_POST_CNST_SW_RUNOFF_PROG_STAT_TXT]         VARCHAR (500) NULL,
    [MS_4_POST_CNST_SW_RUNOFF_BMP_STAT]              VARCHAR (3)   NULL,
    [MS_4_POST_CNST_SW_RUNOFF_BMP_STAT_TXT]          VARCHAR (500) NULL,
    [DATA_HASH]                                      VARCHAR (100) NULL,
    CONSTRAINT [PK_MS_4_POS_CNS_SW_RGL_ENT_INF] PRIMARY KEY CLUSTERED ([ICS_MS_4_POST_CNST_SW_REGULATED_ENTITY_INFO_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_MS_4_POST_CNST_SW_REGULATED_ENTITY_INFO].[IX_MS_4_PO_CN_SW_RG_EN_IN_IC_M]...';

CREATE NONCLUSTERED INDEX [IX_MS_4_PO_CN_SW_RG_EN_IN_IC_M]
    ON [dbo].[ICS_MS_4_POST_CNST_SW_REGULATED_ENTITY_INFO]([ICS_MS_4_POST_CNST_SW_REQS_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_MS_4_POST_CNST_SW_REQS]...';

CREATE TABLE [dbo].[ICS_MS_4_POST_CNST_SW_REQS] (
    [ICS_MS_4_POST_CNST_SW_REQS_ID] VARCHAR (36)  NOT NULL,
    [ICS_SWMS_4_PRMT_ID]            VARCHAR (36)  NOT NULL,
    [DATA_HASH]                     VARCHAR (100) NULL,
    CONSTRAINT [PK_MS_4_POST_CNST_SW_REQS] PRIMARY KEY CLUSTERED ([ICS_MS_4_POST_CNST_SW_REQS_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_MS_4_POST_CNST_SW_REQS].[IX_MS_4_PO_CN_SW_RE_IC_SW_4_PR]...';

CREATE NONCLUSTERED INDEX [IX_MS_4_PO_CN_SW_RE_IC_SW_4_PR]
    ON [dbo].[ICS_MS_4_POST_CNST_SW_REQS]([ICS_SWMS_4_PRMT_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_MS_4_PROG_REP_ANALYSIS]...';

CREATE TABLE [dbo].[ICS_MS_4_PROG_REP_ANALYSIS] (
    [ICS_MS_4_PROG_REP_ANALYSIS_ID] VARCHAR (36)   NOT NULL,
    [ICS_SWMS_4_ANNUL_PROG_REP_ID]  VARCHAR (36)   NOT NULL,
    [MS_4_PROG_REP_ANALYSIS_TXT]    VARCHAR (8000) NOT NULL,
    [DATA_HASH]                     VARCHAR (100)  NULL,
    CONSTRAINT [PK_MS_4_PROG_REP_ANALYSIS] PRIMARY KEY CLUSTERED ([ICS_MS_4_PROG_REP_ANALYSIS_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_MS_4_PROG_REP_ANALYSIS].[IX_MS_4_PR_RE_AN_IC_SW_4_AN_PR]...';

CREATE NONCLUSTERED INDEX [IX_MS_4_PR_RE_AN_IC_SW_4_AN_PR]
    ON [dbo].[ICS_MS_4_PROG_REP_ANALYSIS]([ICS_SWMS_4_ANNUL_PROG_REP_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY]...';

CREATE TABLE [dbo].[ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY] (
    [ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY_ID] VARCHAR (36)   NOT NULL,
    [ICS_SWMS_4_ANNUL_PROG_REP_ID]               VARCHAR (36)   NOT NULL,
    [MS_4_ACTY_IDENT]                            VARCHAR (40)   NOT NULL,
    [MS_4_REGULATED_ENTITY_CMPL_STAT]            CHAR (1)       NULL,
    [MS_4_REGULATED_ENTITY_CMPL_STAT_TXT]        VARCHAR (2000) NULL,
    [MS_4_PROG_REP_REQS_ACTIVITIES]              VARCHAR (8000) NULL,
    [DATA_HASH]                                  VARCHAR (100)  NULL,
    CONSTRAINT [PK_MS_4_PROG_REP_REQS_RGLT_ENT] PRIMARY KEY CLUSTERED ([ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY].[IX_MS_4_PR_RE_RE_RG_EN_IC_SW_4]...';

CREATE NONCLUSTERED INDEX [IX_MS_4_PR_RE_RE_RG_EN_IC_SW_4]
    ON [dbo].[ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY]([ICS_SWMS_4_ANNUL_PROG_REP_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_MS_4_REGULATED_ENTITY]...';

CREATE TABLE [dbo].[ICS_MS_4_REGULATED_ENTITY] (
    [ICS_MS_4_REGULATED_ENTITY_ID]                   VARCHAR (36)  NOT NULL,
    [ICS_SWMS_4_PRMT_ID]                             VARCHAR (36)  NOT NULL,
    [MS_4_REGULATED_ENTITY_IDENT]                    VARCHAR (40)  NULL,
    [MS_4_REGULATED_ENTITY_NAME]                     VARCHAR (200) NULL,
    [MS_4_REGULATED_ENTITY_OWNERSHIP_LEVEL_CODE]     VARCHAR (3)   NULL,
    [MS_4_REGULATED_ENTITY_OWNERSHIP_LEVEL_OTHR_TXT] VARCHAR (200) NULL,
    [MS_4_REGULATED_ENTITY_CATG_CODE]                VARCHAR (3)   NULL,
    [MS_4_REGULATED_ENTITY_CATG_CODE_OTHR_TXT]       VARCHAR (200) NULL,
    [DATA_HASH]                                      VARCHAR (100) NULL,
    CONSTRAINT [PK_MS_4_REGULATED_ENTITY] PRIMARY KEY CLUSTERED ([ICS_MS_4_REGULATED_ENTITY_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_MS_4_REGULATED_ENTITY].[IX_MS_4_RGL_ENT_ICS_SW_4_PR_ID]...';

CREATE NONCLUSTERED INDEX [IX_MS_4_RGL_ENT_ICS_SW_4_PR_ID]
    ON [dbo].[ICS_MS_4_REGULATED_ENTITY]([ICS_SWMS_4_PRMT_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_MS_4_REGULATED_ENTITY_AREA]...';

CREATE TABLE [dbo].[ICS_MS_4_REGULATED_ENTITY_AREA] (
    [ICS_MS_4_REGULATED_ENTITY_AREA_ID]    VARCHAR (36)   NOT NULL,
    [ICS_SWMS_4_PRMT_ID]                   VARCHAR (36)   NOT NULL,
    [MS_4_REGULATED_ENTITY_AREA_NUM]       INT            NOT NULL,
    [MS_4_REGULATED_ENTITY_IDENT]          VARCHAR (40)   NULL,
    [MS_4_REGULATED_ENTITY_AREA_STAT_CODE] VARCHAR (3)    NULL,
    [MS_4_REGULATED_ENTITY_AREA_TXT]       VARCHAR (4000) NULL,
    [DATA_HASH]                            VARCHAR (100)  NULL,
    CONSTRAINT [PK_MS_4_REGULATED_ENTITY_AREA] PRIMARY KEY CLUSTERED ([ICS_MS_4_REGULATED_ENTITY_AREA_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_MS_4_REGULATED_ENTITY_AREA].[IX_MS_4_RG_EN_AR_IC_SW_4_PR_ID]...';

CREATE NONCLUSTERED INDEX [IX_MS_4_RG_EN_AR_IC_SW_4_PR_ID]
    ON [dbo].[ICS_MS_4_REGULATED_ENTITY_AREA]([ICS_SWMS_4_PRMT_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_MS_4_REGULATED_ENTITY_AREA_COORD]...';

CREATE TABLE [dbo].[ICS_MS_4_REGULATED_ENTITY_AREA_COORD] (
    [ICS_MS_4_REGULATED_ENTITY_AREA_COORD_ID] VARCHAR (36)    NOT NULL,
    [ICS_MS_4_REGULATED_ENTITY_AREA_ID]       VARCHAR (36)    NOT NULL,
    [LAT_MEAS]                                DECIMAL (9, 7)  NULL,
    [LONG_MEAS]                               DECIMAL (10, 6) NULL,
    [DATA_HASH]                               VARCHAR (100)   NULL,
    CONSTRAINT [PK_MS_4_RGULTD_ENTTY_AREA_CORD] PRIMARY KEY CLUSTERED ([ICS_MS_4_REGULATED_ENTITY_AREA_COORD_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_MS_4_REGULATED_ENTITY_AREA_COORD].[IX_MS_4_RG_EN_AR_CO_IC_MS_4_RG]...';

CREATE NONCLUSTERED INDEX [IX_MS_4_RG_EN_AR_CO_IC_MS_4_RG]
    ON [dbo].[ICS_MS_4_REGULATED_ENTITY_AREA_COORD]([ICS_MS_4_REGULATED_ENTITY_AREA_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_MS_4_REGULATED_ENTITY_ENFRC]...';

CREATE TABLE [dbo].[ICS_MS_4_REGULATED_ENTITY_ENFRC] (
    [ICS_MS_4_REGULATED_ENTITY_ENFRC_ID] VARCHAR (36)  NOT NULL,
    [ICS_SWMS_4_ANNUL_PROG_REP_ID]       VARCHAR (36)  NOT NULL,
    [MS_4_REGULATED_ENTITY_IDENT]        VARCHAR (40)  NULL,
    [DATA_HASH]                          VARCHAR (100) NULL,
    CONSTRAINT [PK_MS_4_REGULATED_ENTITY_ENFRC] PRIMARY KEY CLUSTERED ([ICS_MS_4_REGULATED_ENTITY_ENFRC_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_MS_4_REGULATED_ENTITY_ENFRC].[IX_MS_4_RG_EN_EN_IC_SW_4_AN_PR]...';

CREATE NONCLUSTERED INDEX [IX_MS_4_RG_EN_EN_IC_SW_4_AN_PR]
    ON [dbo].[ICS_MS_4_REGULATED_ENTITY_ENFRC]([ICS_SWMS_4_ANNUL_PROG_REP_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_MS_4_REGULATED_ENTITY_ENFRC_ACTIONS]...';

CREATE TABLE [dbo].[ICS_MS_4_REGULATED_ENTITY_ENFRC_ACTIONS] (
    [ICS_MS_4_REGULATED_ENTITY_ENFRC_ACTIONS_ID]          VARCHAR (36)  NOT NULL,
    [ICS_MS_4_REGULATED_ENTITY_ENFRC_ID]                  VARCHAR (36)  NOT NULL,
    [MS_4_REGULATED_ENTITY_ENFRC_ACTN_TYPE_CODE]          VARCHAR (3)   NOT NULL,
    [MS_4_REGULATED_ENTITY_ENFRC_ACTN_TYPE_CODE_OTHR_TXT] VARCHAR (500) NOT NULL,
    [DATA_HASH]                                           VARCHAR (100) NULL,
    CONSTRAINT [PK_MS_4_RGLTD_ENTTY_ENFRC_ACTN] PRIMARY KEY CLUSTERED ([ICS_MS_4_REGULATED_ENTITY_ENFRC_ACTIONS_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_MS_4_REGULATED_ENTITY_ENFRC_ACTIONS].[IX_MS_4_RG_EN_EN_AC_IC_MS_4_RG]...';

CREATE NONCLUSTERED INDEX [IX_MS_4_RG_EN_EN_AC_IC_MS_4_RG]
    ON [dbo].[ICS_MS_4_REGULATED_ENTITY_ENFRC_ACTIONS]([ICS_MS_4_REGULATED_ENTITY_ENFRC_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT]...';

CREATE TABLE [dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT] (
    [ICS_MS_4_REGULATED_ENTITY_IDENT_ID]         VARCHAR (36)  NOT NULL,
    [ICS_GNRL_PRMT_COVERAGE_MS_4_REQ_ID]         VARCHAR (36)  NULL,
    [ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY_ID] VARCHAR (36)  NULL,
    [ICS_MS_4_PROG_REP_ANALYSIS_ID]              VARCHAR (36)  NULL,
    [ICS_MS_4_PBLC_EDUCATION_REQS_ID]            VARCHAR (36)  NULL,
    [ICS_MS_4_PBLC_INVOLVEMENT_REQS_ID]          VARCHAR (36)  NULL,
    [ICS_MS_4_ILLICIT_DETECT_PROCEDURES_ID]      VARCHAR (36)  NULL,
    [ICS_MS_4_CNST_SW_PROCEDURES_ID]             VARCHAR (36)  NULL,
    [ICS_MS_4_POST_CNST_SW_PROCEDURES_ID]        VARCHAR (36)  NULL,
    [ICS_MS_4_POLLUTION_PREVENTION_REQS_ID]      VARCHAR (36)  NULL,
    [ICS_MS_4_INDST_SW_PROCEDURES_ID]            VARCHAR (36)  NULL,
    [ICS_MS_4_OTHR_APPL_REQS_ID]                 VARCHAR (36)  NULL,
    [MS_4_REGULATED_ENTITY_IDENT]                VARCHAR (40)  NOT NULL,
    [DATA_HASH]                                  VARCHAR (100) NULL,
    CONSTRAINT [PK_MS_4_REGULATED_ENTITY_IDENT] PRIMARY KEY CLUSTERED ([ICS_MS_4_REGULATED_ENTITY_IDENT_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT].[IX_MS_4_RG_EN_ID_IC_GN_PR_CV_M]...';

CREATE NONCLUSTERED INDEX [IX_MS_4_RG_EN_ID_IC_GN_PR_CV_M]
    ON [dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT]([ICS_GNRL_PRMT_COVERAGE_MS_4_REQ_ID] ASC);

PRINT N'Creating Index [dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT].[IX_MS_4_RG_EN_ID_IC_MS_4_CN_SW]...';

CREATE NONCLUSTERED INDEX [IX_MS_4_RG_EN_ID_IC_MS_4_CN_SW]
    ON [dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT]([ICS_MS_4_CNST_SW_PROCEDURES_ID] ASC);

PRINT N'Creating Index [dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT].[IX_MS_4_RG_EN_ID_IC_MS_4_IL_DT]...';

CREATE NONCLUSTERED INDEX [IX_MS_4_RG_EN_ID_IC_MS_4_IL_DT]
    ON [dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT]([ICS_MS_4_ILLICIT_DETECT_PROCEDURES_ID] ASC);

PRINT N'Creating Index [dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT].[IX_MS_4_RG_EN_ID_IC_MS_4_IN_SW]...';

CREATE NONCLUSTERED INDEX [IX_MS_4_RG_EN_ID_IC_MS_4_IN_SW]
    ON [dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT]([ICS_MS_4_INDST_SW_PROCEDURES_ID] ASC);

PRINT N'Creating Index [dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT].[IX_MS_4_RG_EN_ID_IC_MS_4_OT_AP]...';

CREATE NONCLUSTERED INDEX [IX_MS_4_RG_EN_ID_IC_MS_4_OT_AP]
    ON [dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT]([ICS_MS_4_OTHR_APPL_REQS_ID] ASC);

PRINT N'Creating Index [dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT].[IX_MS_4_RG_EN_ID_IC_MS_4_PB_ED]...';

CREATE NONCLUSTERED INDEX [IX_MS_4_RG_EN_ID_IC_MS_4_PB_ED]
    ON [dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT]([ICS_MS_4_PBLC_EDUCATION_REQS_ID] ASC);

PRINT N'Creating Index [dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT].[IX_MS_4_RG_EN_ID_IC_MS_4_PB_IN]...';

CREATE NONCLUSTERED INDEX [IX_MS_4_RG_EN_ID_IC_MS_4_PB_IN]
    ON [dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT]([ICS_MS_4_PBLC_INVOLVEMENT_REQS_ID] ASC);

PRINT N'Creating Index [dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT].[IX_MS_4_RG_EN_ID_IC_MS_4_PL_PR]...';

CREATE NONCLUSTERED INDEX [IX_MS_4_RG_EN_ID_IC_MS_4_PL_PR]
    ON [dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT]([ICS_MS_4_POLLUTION_PREVENTION_REQS_ID] ASC);

PRINT N'Creating Index [dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT].[IX_MS_4_RG_EN_ID_IC_MS_4_PO_CN]...';

CREATE NONCLUSTERED INDEX [IX_MS_4_RG_EN_ID_IC_MS_4_PO_CN]
    ON [dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT]([ICS_MS_4_POST_CNST_SW_PROCEDURES_ID] ASC);

PRINT N'Creating Index [dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT].[IX_MS_4_RG_EN_ID_IC_MS_4_PR_RE]...';

CREATE NONCLUSTERED INDEX [IX_MS_4_RG_EN_ID_IC_MS_4_PR_RE]
    ON [dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT]([ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY_ID] ASC);

PRINT N'Creating Index [dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT].[IX_MS_4_RG_EN_ID_IC_MS_4_PR002]...';

CREATE NONCLUSTERED INDEX [IX_MS_4_RG_EN_ID_IC_MS_4_PR002]
    ON [dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT]([ICS_MS_4_PROG_REP_ANALYSIS_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_MS_4_SWMP_CHANGES]...';

CREATE TABLE [dbo].[ICS_MS_4_SWMP_CHANGES] (
    [ICS_MS_4_SWMP_CHANGES_ID]     VARCHAR (36)   NOT NULL,
    [ICS_SWMS_4_ANNUL_PROG_REP_ID] VARCHAR (36)   NOT NULL,
    [MS_4_REGULATED_ENTITY_IDENT]  VARCHAR (40)   NULL,
    [MS_4_SWMP_CHANGE_IND]         CHAR (1)       NOT NULL,
    [MS_4_SWMP_CHANGE_IND_TXT]     VARCHAR (4000) NULL,
    [DATA_HASH]                    VARCHAR (100)  NULL,
    CONSTRAINT [PK_MS_4_SWMP_CHANGES] PRIMARY KEY CLUSTERED ([ICS_MS_4_SWMP_CHANGES_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_MS_4_SWMP_CHANGES].[IX_MS_4_SW_CH_IC_SW_4_AN_PR_RE]...';

CREATE NONCLUSTERED INDEX [IX_MS_4_SW_CH_IC_SW_4_AN_PR_RE]
    ON [dbo].[ICS_MS_4_SWMP_CHANGES]([ICS_SWMS_4_ANNUL_PROG_REP_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_NPDES_VARIANCE_PRMT]...';

CREATE TABLE [dbo].[ICS_NPDES_VARIANCE_PRMT] (
    [ICS_NPDES_VARIANCE_PRMT_ID]               VARCHAR (36)  NOT NULL,
    [ICS_PAYLOAD_ID]                           VARCHAR (36)  NOT NULL,
    [SRC_SYSTM_IDENT]                          VARCHAR (50)  NULL,
    [TRANSACTION_TYPE]                         CHAR (1)      NULL,
    [TRANSACTION_TIMESTAMP]                    DATETIME      NULL,
    [PRMT_IDENT]                               CHAR (9)      NOT NULL,
    [NPDES_VARIANCE_TYPE_CODE]                 VARCHAR (3)   NULL,
    [NPDES_VARIANCE_SUBM_DATE]                 DATETIME      NULL,
    [NPDES_VARIANCE_VERSION_TYPE]              CHAR (3)      NULL,
    [NPDES_VARIANCE_STAT_CODE]                 CHAR (3)      NULL,
    [NPDES_VARIANCE_ACTN_DATE]                 DATETIME      NULL,
    [THERMAL_VARIANCE_REQUEST_PBLC_NOTICE_IND] CHAR (1)      NULL,
    [NPDES_VARIANCE_CMNT_TXT]                  VARCHAR (500) NULL,
    [KEY_HASH]                                 VARCHAR (100) NULL,
    [DATA_HASH]                                VARCHAR (100) NULL,
    CONSTRAINT [PK_NPDES_VARIANCE_PRMT] PRIMARY KEY CLUSTERED ([ICS_NPDES_VARIANCE_PRMT_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_NPDES_VARIANCE_PRMT].[IX_NPDS_VRNCE_PRMT_ICS_PYLD_ID]...';

CREATE NONCLUSTERED INDEX [IX_NPDS_VRNCE_PRMT_ICS_PYLD_ID]
    ON [dbo].[ICS_NPDES_VARIANCE_PRMT]([ICS_PAYLOAD_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_POLUT_LIST]...';

CREATE TABLE [dbo].[ICS_POLUT_LIST] (
    [ICS_POLUT_LIST_ID] VARCHAR (36)  NOT NULL,
    [ICS_PRMT_FEATR_ID] VARCHAR (36)  NOT NULL,
    [DATA_HASH]         VARCHAR (100) NULL,
    CONSTRAINT [PK_POLUT_LIST] PRIMARY KEY CLUSTERED ([ICS_POLUT_LIST_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_POLUT_LIST].[IX_POLUT_LIST_ICS_PRMT_FETR_ID]...';

CREATE NONCLUSTERED INDEX [IX_POLUT_LIST_ICS_PRMT_FETR_ID]
    ON [dbo].[ICS_POLUT_LIST]([ICS_PRMT_FEATR_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_POTW_TRTMNT_TECHNOLOGY_PRMT]...';

CREATE TABLE [dbo].[ICS_POTW_TRTMNT_TECHNOLOGY_PRMT] (
    [ICS_POTW_TRTMNT_TECHNOLOGY_PRMT_ID]                VARCHAR (36)  NOT NULL,
    [ICS_PAYLOAD_ID]                                    VARCHAR (36)  NOT NULL,
    [SRC_SYSTM_IDENT]                                   VARCHAR (50)  NULL,
    [TRANSACTION_TYPE]                                  CHAR (1)      NULL,
    [TRANSACTION_TIMESTAMP]                             DATETIME      NULL,
    [PRMT_IDENT]                                        CHAR (9)      NOT NULL,
    [POTW_TRTMNT_LEVEL_CODE]                            VARCHAR (3)   NULL,
    [POTW_TRTMNT_LEVEL_OTHR_TXT]                        VARCHAR (100) NULL,
    [POTW_WW_DISINFECTION_TECHNOLOGY_CODE]              VARCHAR (3)   NULL,
    [POTW_WW_DISINFECTION_TECHNOLOGY_OTHR_TXT]          VARCHAR (100) NULL,
    [POTW_WW_TRTMNT_TECHNOLOGY_UNIT_OPERATION_CODE]     VARCHAR (3)   NULL,
    [POTW_WW_TRTMNT_TECHNOLOGY_UNIT_OPERATION_OTHR_TXT] VARCHAR (100) NULL,
    [KEY_HASH]                                          VARCHAR (100) NULL,
    [DATA_HASH]                                         VARCHAR (100) NULL,
    CONSTRAINT [PK_POTW_TRTMNT_TECHNOLOGY_PRMT] PRIMARY KEY CLUSTERED ([ICS_POTW_TRTMNT_TECHNOLOGY_PRMT_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_POTW_TRTMNT_TECHNOLOGY_PRMT].[IX_POTW_TRT_TCH_PRM_ICS_PYL_ID]...';

CREATE NONCLUSTERED INDEX [IX_POTW_TRT_TCH_PRM_ICS_PYL_ID]
    ON [dbo].[ICS_POTW_TRTMNT_TECHNOLOGY_PRMT]([ICS_PAYLOAD_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_PRETR_PROG_MOD]...';

CREATE TABLE [dbo].[ICS_PRETR_PROG_MOD] (
    [ICS_PRETR_PROG_MOD_ID] VARCHAR (36)  NOT NULL,
    [ICS_PRETR_PRMT_ID]     VARCHAR (36)  NOT NULL,
    [PRETR_PROG_MOD_TYPE]   VARCHAR (3)   NOT NULL,
    [PRETR_PROG_MOD_DATE]   DATETIME      NOT NULL,
    [PRETR_PROG_MOD_TXT]    VARCHAR (500) NULL,
    [DATA_HASH]             VARCHAR (100) NULL,
    CONSTRAINT [PK_PRETR_PROG_MOD] PRIMARY KEY CLUSTERED ([ICS_PRETR_PROG_MOD_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_PRETR_PROG_MOD].[IX_PRTR_PRO_MOD_ICS_PRT_PRM_ID]...';

CREATE NONCLUSTERED INDEX [IX_PRTR_PRO_MOD_ICS_PRT_PRM_ID]
    ON [dbo].[ICS_PRETR_PROG_MOD]([ICS_PRETR_PRMT_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_PRETR_PROG_REP]...';

CREATE TABLE [dbo].[ICS_PRETR_PROG_REP] (
    [ICS_PRETR_PROG_REP_ID]           VARCHAR (36)  NOT NULL,
    [ICS_PAYLOAD_ID]                  VARCHAR (36)  NOT NULL,
    [SRC_SYSTM_IDENT]                 VARCHAR (50)  NULL,
    [TRANSACTION_TYPE]                CHAR (1)      NULL,
    [TRANSACTION_TIMESTAMP]           DATETIME      NULL,
    [PRMT_IDENT]                      CHAR (9)      NOT NULL,
    [PROG_REP_FORM_SET_ID]            VARCHAR (50)  NOT NULL,
    [PROG_REP_FORM_ID]                INT           NULL,
    [PROG_REP_RCVD_DATE]              DATETIME      NULL,
    [PROG_REP_START_DATE]             DATETIME      NULL,
    [PROG_REP_END_DATE]               DATETIME      NULL,
    [ELEC_SUBM_TYPE_CODE]             VARCHAR (3)   NULL,
    [PROG_REP_NPDES_DAT_GRP_NUM_CODE] VARCHAR (3)   NULL,
    [KEY_HASH]                        VARCHAR (100) NULL,
    [DATA_HASH]                       VARCHAR (100) NULL,
    CONSTRAINT [PK_PRETR_PROG_REP] PRIMARY KEY CLUSTERED ([ICS_PRETR_PROG_REP_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_PRETR_PROG_REP].[IX_PRTR_PROG_REP_ICS_PAYLOD_ID]...';

CREATE NONCLUSTERED INDEX [IX_PRTR_PROG_REP_ICS_PAYLOD_ID]
    ON [dbo].[ICS_PRETR_PROG_REP]([ICS_PAYLOAD_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_PRMT_BS_MGMT_PRACTICE]...';

CREATE TABLE [dbo].[ICS_PRMT_BS_MGMT_PRACTICE] (
    [ICS_PRMT_BS_MGMT_PRACTICE_ID]         VARCHAR (36)    NOT NULL,
    [ICS_BS_PRMT_ID]                       VARCHAR (36)    NOT NULL,
    [SSU_IDENT]                            VARCHAR (20)    NOT NULL,
    [BS_MGMT_PRACTICE_CODE]                VARCHAR (3)     NULL,
    [BS_MGMT_PRACTICE_SUB_CATG_CODE]       VARCHAR (3)     NULL,
    [BS_MGMT_PRACTICE_SUB_CATG_TXT]        VARCHAR (250)   NULL,
    [BS_OPERATOR_TYPE_CODE]                VARCHAR (3)     NULL,
    [BS_CNTNR_TYPE_CODE]                   VARCHAR (3)     NULL,
    [SSUID_VOL_AMT]                        DECIMAL (15, 7) NULL,
    [PATHOGEN_CLASS_TYPE_CODE]             VARCHAR (3)     NULL,
    [POLUT_LOADING_RATES_EXCEEDANCE_IND]   CHAR (1)        NULL,
    [SURF_DSPL_WITHOUT_LINER_IND]          CHAR (1)        NULL,
    [SURF_DSPL_SITE_SPEC_LMT_IND]          CHAR (1)        NULL,
    [SURF_DSPL_MIN_BOUNDARY_DISTANCE_CODE] VARCHAR (3)     NULL,
    [BS_OFF_SITE_FAC_PRMT_IDENT]           CHAR (9)        NULL,
    [DATA_HASH]                            VARCHAR (100)   NULL,
    CONSTRAINT [PK_PRMT_BS_MGMT_PRACTICE] PRIMARY KEY CLUSTERED ([ICS_PRMT_BS_MGMT_PRACTICE_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_PRMT_BS_MGMT_PRACTICE].[IX_PRM_BS_MGM_PRC_ICS_BS_PR_ID]...';

CREATE NONCLUSTERED INDEX [IX_PRM_BS_MGM_PRC_ICS_BS_PR_ID]
    ON [dbo].[ICS_PRMT_BS_MGMT_PRACTICE]([ICS_BS_PRMT_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_PROPOSED_CNST_SW_BM_PS]...';

CREATE TABLE [dbo].[ICS_PROPOSED_CNST_SW_BM_PS] (
    [ICS_PROPOSED_CNST_SW_BM_PS_ID] VARCHAR (36)   NOT NULL,
    [ICS_SW_CNST_PRMT_ID]           VARCHAR (36)   NOT NULL,
    [PROPOSED_CNST_SW_BMP_CODE]     VARCHAR (3)    NOT NULL,
    [PROPOSED_CNST_SW_BMP_OTHR_TXT] VARCHAR (1000) NULL,
    [DATA_HASH]                     VARCHAR (100)  NULL,
    CONSTRAINT [PK_PROPOSED_CNST_SW_BM_PS] PRIMARY KEY CLUSTERED ([ICS_PROPOSED_CNST_SW_BM_PS_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_PROPOSED_CNST_SW_BM_PS].[IX_PR_CN_SW_BM_PS_IC_SW_CN_PR]...';

CREATE NONCLUSTERED INDEX [IX_PR_CN_SW_BM_PS_IC_SW_CN_PR]
    ON [dbo].[ICS_PROPOSED_CNST_SW_BM_PS]([ICS_SW_CNST_PRMT_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_PROPOSED_INDST_SW_BM_PS]...';

CREATE TABLE [dbo].[ICS_PROPOSED_INDST_SW_BM_PS] (
    [ICS_PROPOSED_INDST_SW_BM_PS_ID] VARCHAR (36)   NOT NULL,
    [ICS_SW_INDST_PRMT_ID]           VARCHAR (36)   NOT NULL,
    [PROPOSED_INDST_SW_BMP_CODE]     VARCHAR (3)    NOT NULL,
    [PROPOSED_INDST_SW_BMP_OTHR_TXT] VARCHAR (1000) NULL,
    [DATA_HASH]                      VARCHAR (100)  NULL,
    CONSTRAINT [PK_PROPOSED_INDST_SW_BM_PS] PRIMARY KEY CLUSTERED ([ICS_PROPOSED_INDST_SW_BM_PS_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_PROPOSED_INDST_SW_BM_PS].[IX_PR_IN_SW_BM_PS_IC_SW_IN_PR]...';

CREATE NONCLUSTERED INDEX [IX_PR_IN_SW_BM_PS_IC_SW_IN_PR]
    ON [dbo].[ICS_PROPOSED_INDST_SW_BM_PS]([ICS_SW_INDST_PRMT_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_PROPOSED_POST_CNST_SW_BM_PS]...';

CREATE TABLE [dbo].[ICS_PROPOSED_POST_CNST_SW_BM_PS] (
    [ICS_PROPOSED_POST_CNST_SW_BM_PS_ID] VARCHAR (36)   NOT NULL,
    [ICS_SW_CNST_PRMT_ID]                VARCHAR (36)   NOT NULL,
    [PROPOSED_POST_CNST_SW_BMP_CODE]     VARCHAR (3)    NOT NULL,
    [PROPOSED_POST_CNST_SW_BMP_OTHR_TXT] VARCHAR (1000) NULL,
    [DATA_HASH]                          VARCHAR (100)  NULL,
    CONSTRAINT [PK_PROPOSED_POST_CNST_SW_BM_PS] PRIMARY KEY CLUSTERED ([ICS_PROPOSED_POST_CNST_SW_BM_PS_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_PROPOSED_POST_CNST_SW_BM_PS].[IX_PR_PO_CN_SW_BM_PS_IC_SW_CN]...';

CREATE NONCLUSTERED INDEX [IX_PR_PO_CN_SW_BM_PS_IC_SW_CN]
    ON [dbo].[ICS_PROPOSED_POST_CNST_SW_BM_PS]([ICS_SW_CNST_PRMT_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_RESIDUAL_DESGN_DTRMN]...';

CREATE TABLE [dbo].[ICS_RESIDUAL_DESGN_DTRMN] (
    [ICS_RESIDUAL_DESGN_DTRMN_ID]   VARCHAR (36)   NOT NULL,
    [ICS_BASIC_PRMT_ID]             VARCHAR (36)   NULL,
    [ICS_GNRL_PRMT_ID]              VARCHAR (36)   NULL,
    [ICS_MASTER_GNRL_PRMT_ID]       VARCHAR (36)   NULL,
    [RESIDUAL_DESGN_DTRMN_CODE]     VARCHAR (3)    NOT NULL,
    [RESIDUAL_DESGN_DTRMN_OTHR_TXT] VARCHAR (1000) NULL,
    [DATA_HASH]                     VARCHAR (100)  NULL,
    CONSTRAINT [PK_RESIDUAL_DESGN_DTRMN] PRIMARY KEY CLUSTERED ([ICS_RESIDUAL_DESGN_DTRMN_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_RESIDUAL_DESGN_DTRMN].[IX_RSD_DSG_DTR_ICS_MS_GN_PR_ID]...';

CREATE NONCLUSTERED INDEX [IX_RSD_DSG_DTR_ICS_MS_GN_PR_ID]
    ON [dbo].[ICS_RESIDUAL_DESGN_DTRMN]([ICS_MASTER_GNRL_PRMT_ID] ASC);

PRINT N'Creating Index [dbo].[ICS_RESIDUAL_DESGN_DTRMN].[IX_RSDL_DSG_DTR_ICS_BSI_PRM_ID]...';

CREATE NONCLUSTERED INDEX [IX_RSDL_DSG_DTR_ICS_BSI_PRM_ID]
    ON [dbo].[ICS_RESIDUAL_DESGN_DTRMN]([ICS_BASIC_PRMT_ID] ASC);

PRINT N'Creating Index [dbo].[ICS_RESIDUAL_DESGN_DTRMN].[IX_RSDL_DSG_DTR_ICS_GNR_PRM_ID]...';

CREATE NONCLUSTERED INDEX [IX_RSDL_DSG_DTR_ICS_GNR_PRM_ID]
    ON [dbo].[ICS_RESIDUAL_DESGN_DTRMN]([ICS_GNRL_PRMT_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_SEWER_OVRFLW_BYPASS_CAUSE]...';

CREATE TABLE [dbo].[ICS_SEWER_OVRFLW_BYPASS_CAUSE] (
    [ICS_SEWER_OVRFLW_BYPASS_CAUSE_ID]   VARCHAR (36)  NOT NULL,
    [ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] VARCHAR (36)  NOT NULL,
    [SEWER_OVRFLW_BYPASS_CAUSE_CODE]     VARCHAR (3)   NOT NULL,
    [SEWER_OVRFLW_BYPASS_CAUSE_OTHR_TXT] VARCHAR (100) NULL,
    [DATA_HASH]                          VARCHAR (100) NULL,
    CONSTRAINT [PK_SEWER_OVRFLW_BYPASS_CAUSE] PRIMARY KEY CLUSTERED ([ICS_SEWER_OVRFLW_BYPASS_CAUSE_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_SEWER_OVRFLW_BYPASS_CAUSE].[IX_SE_OV_BY_CU_IC_SE_OV_BY_RE]...';

CREATE NONCLUSTERED INDEX [IX_SE_OV_BY_CU_IC_SE_OV_BY_RE]
    ON [dbo].[ICS_SEWER_OVRFLW_BYPASS_CAUSE]([ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_SEWER_OVRFLW_BYPASS_CORR_ACTN]...';

CREATE TABLE [dbo].[ICS_SEWER_OVRFLW_BYPASS_CORR_ACTN] (
    [ICS_SEWER_OVRFLW_BYPASS_CORR_ACTN_ID]   VARCHAR (36)  NOT NULL,
    [ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID]     VARCHAR (36)  NOT NULL,
    [SEWER_OVRFLW_BYPASS_CORR_ACTN_CODE]     VARCHAR (3)   NOT NULL,
    [SEWER_OVRFLW_BYPASS_CORR_ACTN_OTHR_TXT] VARCHAR (100) NULL,
    [DATA_HASH]                              VARCHAR (100) NULL,
    CONSTRAINT [PK_SEWR_OVRFLW_BYPSS_CORR_ACTN] PRIMARY KEY CLUSTERED ([ICS_SEWER_OVRFLW_BYPASS_CORR_ACTN_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_SEWER_OVRFLW_BYPASS_CORR_ACTN].[IX_SE_OV_BY_CO_AC_IC_SE_OV_BY]...';

CREATE NONCLUSTERED INDEX [IX_SE_OV_BY_CO_AC_IC_SE_OV_BY]
    ON [dbo].[ICS_SEWER_OVRFLW_BYPASS_CORR_ACTN]([ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP]...';

CREATE TABLE [dbo].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP] (
    [ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] VARCHAR (36)  NOT NULL,
    [ICS_PAYLOAD_ID]                     VARCHAR (36)  NOT NULL,
    [SRC_SYSTM_IDENT]                    VARCHAR (50)  NULL,
    [TRANSACTION_TYPE]                   CHAR (1)      NULL,
    [TRANSACTION_TIMESTAMP]              DATETIME      NULL,
    [PRMT_IDENT]                         CHAR (9)      NOT NULL,
    [PROG_REP_FORM_SET_ID]               VARCHAR (50)  NOT NULL,
    [PROG_REP_FORM_ID]                   INT           NULL,
    [PROG_REP_RCVD_DATE]                 DATETIME      NULL,
    [PROG_REP_START_DATE]                DATETIME      NULL,
    [PROG_REP_END_DATE]                  DATETIME      NULL,
    [ELEC_SUBM_TYPE_CODE]                VARCHAR (3)   NULL,
    [PROG_REP_NPDES_DAT_GRP_NUM_CODE]    VARCHAR (3)   NULL,
    [KEY_HASH]                           VARCHAR (100) NULL,
    [DATA_HASH]                          VARCHAR (100) NULL,
    CONSTRAINT [PK_SEWER_OVRFLW_BYPASS_EVT_REP] PRIMARY KEY CLUSTERED ([ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP].[IX_SEW_OVR_BYP_EVT_RE_IC_PY_ID]...';

CREATE NONCLUSTERED INDEX [IX_SEW_OVR_BYP_EVT_RE_IC_PY_ID]
    ON [dbo].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP]([ICS_PAYLOAD_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_SEWER_OVRFLW_BYPASS_IMPACT]...';

CREATE TABLE [dbo].[ICS_SEWER_OVRFLW_BYPASS_IMPACT] (
    [ICS_SEWER_OVRFLW_BYPASS_IMPACT_ID]   VARCHAR (36)  NOT NULL,
    [ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID]  VARCHAR (36)  NOT NULL,
    [SEWER_OVRFLW_BYPASS_IMPACT_CODE]     VARCHAR (3)   NOT NULL,
    [SEWER_OVRFLW_BYPASS_IMPACT_OTHR_TXT] VARCHAR (100) NULL,
    [DATA_HASH]                           VARCHAR (100) NULL,
    CONSTRAINT [PK_SEWER_OVRFLW_BYPASS_IMPACT] PRIMARY KEY CLUSTERED ([ICS_SEWER_OVRFLW_BYPASS_IMPACT_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_SEWER_OVRFLW_BYPASS_IMPACT].[IX_SE_OV_BY_IM_IC_SE_OV_BY_RE]...';

CREATE NONCLUSTERED INDEX [IX_SE_OV_BY_IM_IC_SE_OV_BY_RE]
    ON [dbo].[ICS_SEWER_OVRFLW_BYPASS_IMPACT]([ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_SEWER_OVRFLW_BYPASS_RCVG_WTR]...';

CREATE TABLE [dbo].[ICS_SEWER_OVRFLW_BYPASS_RCVG_WTR] (
    [ICS_SEWER_OVRFLW_BYPASS_RCVG_WTR_ID] VARCHAR (36)   NOT NULL,
    [ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID]  VARCHAR (36)   NOT NULL,
    [SEWER_OVRFLW_BYPASS_RCVG_WTR]        VARCHAR (1000) NOT NULL,
    [DATA_HASH]                           VARCHAR (100)  NULL,
    CONSTRAINT [PK_SEWER_OVRFLW_BYPSS_RCVG_WTR] PRIMARY KEY CLUSTERED ([ICS_SEWER_OVRFLW_BYPASS_RCVG_WTR_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_SEWER_OVRFLW_BYPASS_RCVG_WTR].[IX_SE_OV_BY_RC_WT_IC_SE_OV_BY]...';

CREATE NONCLUSTERED INDEX [IX_SE_OV_BY_RC_WT_IC_SE_OV_BY]
    ON [dbo].[ICS_SEWER_OVRFLW_BYPASS_RCVG_WTR]([ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT]...';

CREATE TABLE [dbo].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT] (
    [ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID]     VARCHAR (36)    NOT NULL,
    [ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID]     VARCHAR (36)    NOT NULL,
    [LAT_MEAS]                               DECIMAL (9, 7)  NULL,
    [LONG_MEAS]                              DECIMAL (10, 6) NULL,
    [PRMT_FEATR_IDENT]                       VARCHAR (4)     NULL,
    [DSCH_QUANTIFICATION_METHOD_CODE]        VARCHAR (3)     NULL,
    [SEWER_OVRFLW_BYPASS_DSCH_RATE_GPH]      DECIMAL (9, 1)  NULL,
    [SEWER_OVRFLW_BYPASS_DSCH_VOL_GAL]       DECIMAL (13, 1) NULL,
    [SEWER_OVRFLW_BYPASS_EVT_ID]             INT             NOT NULL,
    [SEWER_OVRFLW_BYPASS_DESC_TXT]           VARCHAR (1000)  NULL,
    [SEWER_OVRFLW_BYPASS_REP_REQ_CODE]       INT             NULL,
    [WET_WEATHER_OCCURANCE_IND]              CHAR (1)        NULL,
    [SEWER_OVRFLW_STRCT_TYPE_CODE]           VARCHAR (3)     NULL,
    [SEWER_OVRFLW_STRCT_TYPE_CODE_OTHR_TXT]  VARCHAR (100)   NULL,
    [COLL_SYSTM_IDENT]                       VARCHAR (20)    NULL,
    [ANTICIPATED_BYPASS_TXT]                 VARCHAR (1000)  NULL,
    [ANTICIPATED_BYPASS_EXPECT_LMT_VIOL]     CHAR (1)        NULL,
    [ANTICIPATED_BYPASS_EXPECT_LMT_VIOL_TXT] VARCHAR (1000)  NULL,
    [SEWER_OVRFLW_BYPASS_DURATION_HOURS]     DECIMAL (7, 2)  NOT NULL,
    [SEWER_OVRFLW_BYPASS_START_DATE_TIME]    DATETIME        NOT NULL,
    [SEWER_OVRFLW_BYPASS_END_DATE_TIME]      DATETIME        NULL,
    [DATA_HASH]                              VARCHAR (100)   NULL,
    CONSTRAINT [PK_SEWER_OVRFLW_BYPASS_REP_EVT] PRIMARY KEY CLUSTERED ([ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT].[IX_SE_OV_BY_RE_EV_IC_SE_OV_BY]...';

CREATE NONCLUSTERED INDEX [IX_SE_OV_BY_RE_EV_IC_SE_OV_BY]
    ON [dbo].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT]([ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_SEWER_OVRFLW_BYPASS_TYPE]...';

CREATE TABLE [dbo].[ICS_SEWER_OVRFLW_BYPASS_TYPE] (
    [ICS_SEWER_OVRFLW_BYPASS_TYPE_ID]    VARCHAR (36)  NOT NULL,
    [ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] VARCHAR (36)  NOT NULL,
    [SEWER_OVRFLW_BYPASS_TYPE_CODE]      VARCHAR (3)   NOT NULL,
    [DATA_HASH]                          VARCHAR (100) NULL,
    CONSTRAINT [PK_SEWER_OVRFLW_BYPASS_TYPE] PRIMARY KEY CLUSTERED ([ICS_SEWER_OVRFLW_BYPASS_TYPE_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_SEWER_OVRFLW_BYPASS_TYPE].[IX_SE_OV_BY_TY_IC_SE_OV_BY_RE]...';

CREATE NONCLUSTERED INDEX [IX_SE_OV_BY_TY_IC_SE_OV_BY_RE]
    ON [dbo].[ICS_SEWER_OVRFLW_BYPASS_TYPE]([ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_SEWER_OVRFLW_TRTMNT]...';

CREATE TABLE [dbo].[ICS_SEWER_OVRFLW_TRTMNT] (
    [ICS_SEWER_OVRFLW_TRTMNT_ID]         VARCHAR (36)  NOT NULL,
    [ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] VARCHAR (36)  NOT NULL,
    [SEWER_OVRFLW_TRTMNT_CODE]           VARCHAR (3)   NOT NULL,
    [DATA_HASH]                          VARCHAR (100) NULL,
    CONSTRAINT [PK_SEWER_OVRFLW_TRTMNT] PRIMARY KEY CLUSTERED ([ICS_SEWER_OVRFLW_TRTMNT_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_SEWER_OVRFLW_TRTMNT].[IX_SE_OV_TR_IC_SE_OV_BY_RE_EV]...';

CREATE NONCLUSTERED INDEX [IX_SE_OV_TR_IC_SE_OV_BY_RE_EV]
    ON [dbo].[ICS_SEWER_OVRFLW_TRTMNT]([ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_SIU_DESGN_TYPE]...';

CREATE TABLE [dbo].[ICS_SIU_DESGN_TYPE] (
    [ICS_SIU_DESGN_TYPE_ID] VARCHAR (36)  NOT NULL,
    [ICS_BASIC_PRMT_ID]     VARCHAR (36)  NOT NULL,
    [SIU_DESGN_TYPE]        VARCHAR (3)   NOT NULL,
    [DATA_HASH]             VARCHAR (100) NULL,
    CONSTRAINT [PK_SIU_DESGN_TYPE] PRIMARY KEY CLUSTERED ([ICS_SIU_DESGN_TYPE_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_SIU_DESGN_TYPE].[IX_SIU_DSGN_TYP_ICS_BSI_PRM_ID]...';

CREATE NONCLUSTERED INDEX [IX_SIU_DSGN_TYP_ICS_BSI_PRM_ID]
    ON [dbo].[ICS_SIU_DESGN_TYPE]([ICS_BASIC_PRMT_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_SNC_LISTING_MONTHS]...';

CREATE TABLE [dbo].[ICS_SNC_LISTING_MONTHS] (
    [ICS_SNC_LISTING_MONTHS_ID] VARCHAR (36)  NOT NULL,
    [ICS_IU_VIOL_INFO_ID]       VARCHAR (36)  NOT NULL,
    [SNC_LISTING_MONTHS]        VARCHAR (255) NOT NULL,
    [DATA_HASH]                 VARCHAR (100) NULL,
    CONSTRAINT [PK_SNC_LISTING_MONTHS] PRIMARY KEY CLUSTERED ([ICS_SNC_LISTING_MONTHS_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_SNC_LISTING_MONTHS].[IX_SNC_LST_MNT_ICS_IU_VI_IN_ID]...';

CREATE NONCLUSTERED INDEX [IX_SNC_LST_MNT_ICS_IU_VI_IN_ID]
    ON [dbo].[ICS_SNC_LISTING_MONTHS]([ICS_IU_VIOL_INFO_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_SNC_PRETR_STND_LMTS_PARAMETERS]...';

CREATE TABLE [dbo].[ICS_SNC_PRETR_STND_LMTS_PARAMETERS] (
    [ICS_SNC_PRETR_STND_LMTS_PARAMETERS_ID] VARCHAR (36)  NOT NULL,
    [ICS_IU_VIOL_INFO_ID]                   VARCHAR (36)  NOT NULL,
    [SNC_PRETR_STND_LMTS_PARAMETERS]        VARCHAR (255) NOT NULL,
    [DATA_HASH]                             VARCHAR (100) NULL,
    CONSTRAINT [PK_SNC_PRTR_STND_LMTS_PRMETERS] PRIMARY KEY CLUSTERED ([ICS_SNC_PRETR_STND_LMTS_PARAMETERS_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_SNC_PRETR_STND_LMTS_PARAMETERS].[IX_SN_PR_ST_LM_PR_IC_IU_VI_IN]...';

CREATE NONCLUSTERED INDEX [IX_SN_PR_ST_LM_PR_IC_IU_VI_IN]
    ON [dbo].[ICS_SNC_PRETR_STND_LMTS_PARAMETERS]([ICS_IU_VIOL_INFO_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_SUBSECTOR_CODE_PLUS_DESC]...';

CREATE TABLE [dbo].[ICS_SUBSECTOR_CODE_PLUS_DESC] (
    [ICS_SUBSECTOR_CODE_PLUS_DESC_ID] VARCHAR (36)  NOT NULL,
    [ICS_GPCF_NOTICE_OF_INTENT_ID]    VARCHAR (36)  NOT NULL,
    [SUBSECTOR_CODE_PLUS_DESC]        VARCHAR (304) NOT NULL,
    [DATA_HASH]                       VARCHAR (100) NULL,
    CONSTRAINT [PK_SUBSECTOR_CODE_PLUS_DESC] PRIMARY KEY CLUSTERED ([ICS_SUBSECTOR_CODE_PLUS_DESC_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_SUBSECTOR_CODE_PLUS_DESC].[IX_SB_CO_PL_DE_IC_GP_NT_OF_IN]...';

CREATE NONCLUSTERED INDEX [IX_SB_CO_PL_DE_IC_GP_NT_OF_IN]
    ON [dbo].[ICS_SUBSECTOR_CODE_PLUS_DESC]([ICS_GPCF_NOTICE_OF_INTENT_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_SWMS_4_ANNUL_PROG_REP]...';

CREATE TABLE [dbo].[ICS_SWMS_4_ANNUL_PROG_REP] (
    [ICS_SWMS_4_ANNUL_PROG_REP_ID]    VARCHAR (36)  NOT NULL,
    [ICS_PAYLOAD_ID]                  VARCHAR (36)  NOT NULL,
    [SRC_SYSTM_IDENT]                 VARCHAR (50)  NULL,
    [TRANSACTION_TYPE]                CHAR (1)      NULL,
    [TRANSACTION_TIMESTAMP]           DATETIME      NULL,
    [PRMT_IDENT]                      CHAR (9)      NOT NULL,
    [PROG_REP_FORM_SET_ID]            VARCHAR (50)  NOT NULL,
    [PROG_REP_FORM_ID]                INT           NULL,
    [PROG_REP_RCVD_DATE]              DATETIME      NULL,
    [PROG_REP_START_DATE]             DATETIME      NULL,
    [PROG_REP_END_DATE]               DATETIME      NULL,
    [ELEC_SUBM_TYPE_CODE]             VARCHAR (3)   NULL,
    [PROG_REP_NPDES_DAT_GRP_NUM_CODE] VARCHAR (3)   NULL,
    [KEY_HASH]                        VARCHAR (100) NULL,
    [DATA_HASH]                       VARCHAR (100) NULL,
    CONSTRAINT [PK_SWMS_4_ANNUL_PROG_REP] PRIMARY KEY CLUSTERED ([ICS_SWMS_4_ANNUL_PROG_REP_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_SWMS_4_ANNUL_PROG_REP].[IX_SWM_4_ANN_PRO_REP_ICS_PY_ID]...';

CREATE NONCLUSTERED INDEX [IX_SWM_4_ANN_PRO_REP_ICS_PY_ID]
    ON [dbo].[ICS_SWMS_4_ANNUL_PROG_REP]([ICS_PAYLOAD_ID] ASC);

PRINT N'Creating Table [dbo].[ICS_SWMS_4_PRMT]...';

CREATE TABLE [dbo].[ICS_SWMS_4_PRMT] (
    [ICS_SWMS_4_PRMT_ID]    VARCHAR (36)  NOT NULL,
    [ICS_PAYLOAD_ID]        VARCHAR (36)  NOT NULL,
    [SRC_SYSTM_IDENT]       VARCHAR (50)  NULL,
    [TRANSACTION_TYPE]      CHAR (1)      NULL,
    [TRANSACTION_TIMESTAMP] DATETIME      NULL,
    [PRMT_IDENT]            CHAR (9)      NOT NULL,
    [MS_4_PRMT_PHASE_CODE]  VARCHAR (3)   NULL,
    [MS_4_PRMT_PHASE_TXT]   VARCHAR (500) NULL,
    [KEY_HASH]              VARCHAR (100) NULL,
    [DATA_HASH]             VARCHAR (100) NULL,
    CONSTRAINT [PK_SWMS_4_PRMT] PRIMARY KEY CLUSTERED ([ICS_SWMS_4_PRMT_ID] ASC)
);

PRINT N'Creating Index [dbo].[ICS_SWMS_4_PRMT].[IX_SWMS_4_PRMT_ICS_PAYLOAD_ID]...';

CREATE NONCLUSTERED INDEX [IX_SWMS_4_PRMT_ICS_PAYLOAD_ID]
    ON [dbo].[ICS_SWMS_4_PRMT]([ICS_PAYLOAD_ID] ASC);

PRINT N'Creating Foreign Key [dbo].[FK_ADDR_BASIC_PRMT]...';

ALTER TABLE [dbo].[ICS_ADDR] WITH NOCHECK
    ADD CONSTRAINT [FK_ADDR_BASIC_PRMT] FOREIGN KEY ([ICS_BASIC_PRMT_ID]) REFERENCES [dbo].[ICS_BASIC_PRMT] ([ICS_BASIC_PRMT_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_ADDR_CAFO_PRMT]...';

ALTER TABLE [dbo].[ICS_ADDR] WITH NOCHECK
    ADD CONSTRAINT [FK_ADDR_CAFO_PRMT] FOREIGN KEY ([ICS_CAFO_PRMT_ID]) REFERENCES [dbo].[ICS_CAFO_PRMT] ([ICS_CAFO_PRMT_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_ADDR_FAC]...';

ALTER TABLE [dbo].[ICS_ADDR] WITH NOCHECK
    ADD CONSTRAINT [FK_ADDR_FAC] FOREIGN KEY ([ICS_FAC_ID]) REFERENCES [dbo].[ICS_FAC] ([ICS_FAC_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_ADDR_GNRL_PRMT]...';

ALTER TABLE [dbo].[ICS_ADDR] WITH NOCHECK
    ADD CONSTRAINT [FK_ADDR_GNRL_PRMT] FOREIGN KEY ([ICS_GNRL_PRMT_ID]) REFERENCES [dbo].[ICS_GNRL_PRMT] ([ICS_GNRL_PRMT_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_ADDR_PRMT_FEATR]...';

ALTER TABLE [dbo].[ICS_ADDR] WITH NOCHECK
    ADD CONSTRAINT [FK_ADDR_PRMT_FEATR] FOREIGN KEY ([ICS_PRMT_FEATR_ID]) REFERENCES [dbo].[ICS_PRMT_FEATR] ([ICS_PRMT_FEATR_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_ADDR_SW_CNST_PRMT]...';

ALTER TABLE [dbo].[ICS_ADDR] WITH NOCHECK
    ADD CONSTRAINT [FK_ADDR_SW_CNST_PRMT] FOREIGN KEY ([ICS_SW_CNST_PRMT_ID]) REFERENCES [dbo].[ICS_SW_CNST_PRMT] ([ICS_SW_CNST_PRMT_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_ADDR_SW_INDST_PRMT]...';

ALTER TABLE [dbo].[ICS_ADDR] WITH NOCHECK
    ADD CONSTRAINT [FK_ADDR_SW_INDST_PRMT] FOREIGN KEY ([ICS_SW_INDST_PRMT_ID]) REFERENCES [dbo].[ICS_SW_INDST_PRMT] ([ICS_SW_INDST_PRMT_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_ADDR_UNPRMT_FAC]...';

ALTER TABLE [dbo].[ICS_ADDR] WITH NOCHECK
    ADD CONSTRAINT [FK_ADDR_UNPRMT_FAC] FOREIGN KEY ([ICS_UNPRMT_FAC_ID]) REFERENCES [dbo].[ICS_UNPRMT_FAC] ([ICS_UNPRMT_FAC_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_TELEPH_ADDR]...';

ALTER TABLE [dbo].[ICS_TELEPH] WITH NOCHECK
    ADD CONSTRAINT [FK_TELEPH_ADDR] FOREIGN KEY ([ICS_ADDR_ID]) REFERENCES [dbo].[ICS_ADDR] ([ICS_ADDR_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_ADDR_BS_OFF_SIT_HND_APP_PRP]...';

ALTER TABLE [dbo].[ICS_ADDR] WITH NOCHECK
    ADD CONSTRAINT [FK_ADDR_BS_OFF_SIT_HND_APP_PRP] FOREIGN KEY ([ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID]) REFERENCES [dbo].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] ([ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_ANML_TYPE_CAFO_INSP]...';

ALTER TABLE [dbo].[ICS_ANML_TYPE] WITH NOCHECK
    ADD CONSTRAINT [FK_ANML_TYPE_CAFO_INSP] FOREIGN KEY ([ICS_CAFO_INSP_ID]) REFERENCES [dbo].[ICS_CAFO_INSP] ([ICS_CAFO_INSP_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_ANML_TYPE_CAFO_PRMT]...';

ALTER TABLE [dbo].[ICS_ANML_TYPE] WITH NOCHECK
    ADD CONSTRAINT [FK_ANML_TYPE_CAFO_PRMT] FOREIGN KEY ([ICS_CAFO_PRMT_ID]) REFERENCES [dbo].[ICS_CAFO_PRMT] ([ICS_CAFO_PRMT_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_ANML_TYPE_CAFO_ANNL_PRO_REP]...';

ALTER TABLE [dbo].[ICS_ANML_TYPE] WITH NOCHECK
    ADD CONSTRAINT [FK_ANML_TYPE_CAFO_ANNL_PRO_REP] FOREIGN KEY ([ICS_CAFO_ANNUL_PROG_REP_ID]) REFERENCES [dbo].[ICS_CAFO_ANNUL_PROG_REP] ([ICS_CAFO_ANNUL_PROG_REP_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_EFFLU_GUIDE_BASIC_PRMT]...';

ALTER TABLE [dbo].[ICS_EFFLU_GUIDE] WITH NOCHECK
    ADD CONSTRAINT [FK_EFFLU_GUIDE_BASIC_PRMT] FOREIGN KEY ([ICS_BASIC_PRMT_ID]) REFERENCES [dbo].[ICS_BASIC_PRMT] ([ICS_BASIC_PRMT_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_FAC_BASIC_PRMT]...';

ALTER TABLE [dbo].[ICS_FAC] WITH NOCHECK
    ADD CONSTRAINT [FK_FAC_BASIC_PRMT] FOREIGN KEY ([ICS_BASIC_PRMT_ID]) REFERENCES [dbo].[ICS_BASIC_PRMT] ([ICS_BASIC_PRMT_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_REP_NON_CMPL_STAT_BSIC_PRMT]...';

ALTER TABLE [dbo].[ICS_REP_NON_CMPL_STAT] WITH NOCHECK
    ADD CONSTRAINT [FK_REP_NON_CMPL_STAT_BSIC_PRMT] FOREIGN KEY ([ICS_BASIC_PRMT_ID]) REFERENCES [dbo].[ICS_BASIC_PRMT] ([ICS_BASIC_PRMT_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_SIC_CODE_BASIC_PRMT]...';

ALTER TABLE [dbo].[ICS_SIC_CODE] WITH NOCHECK
    ADD CONSTRAINT [FK_SIC_CODE_BASIC_PRMT] FOREIGN KEY ([ICS_BASIC_PRMT_ID]) REFERENCES [dbo].[ICS_BASIC_PRMT] ([ICS_BASIC_PRMT_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_ASSC_PRMT_BASIC_PRMT]...';

ALTER TABLE [dbo].[ICS_ASSC_PRMT] WITH NOCHECK
    ADD CONSTRAINT [FK_ASSC_PRMT_BASIC_PRMT] FOREIGN KEY ([ICS_BASIC_PRMT_ID]) REFERENCES [dbo].[ICS_BASIC_PRMT] ([ICS_BASIC_PRMT_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_BASIC_PRMT_PAYLOAD]...';

ALTER TABLE [dbo].[ICS_BASIC_PRMT] WITH NOCHECK
    ADD CONSTRAINT [FK_BASIC_PRMT_PAYLOAD] FOREIGN KEY ([ICS_PAYLOAD_ID]) REFERENCES [dbo].[ICS_PAYLOAD] ([ICS_PAYLOAD_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_CMPL_TRACK_STAT_BASIC_PRMT]...';

ALTER TABLE [dbo].[ICS_CMPL_TRACK_STAT] WITH NOCHECK
    ADD CONSTRAINT [FK_CMPL_TRACK_STAT_BASIC_PRMT] FOREIGN KEY ([ICS_BASIC_PRMT_ID]) REFERENCES [dbo].[ICS_BASIC_PRMT] ([ICS_BASIC_PRMT_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_NAICS_CODE_BASIC_PRMT]...';

ALTER TABLE [dbo].[ICS_NAICS_CODE] WITH NOCHECK
    ADD CONSTRAINT [FK_NAICS_CODE_BASIC_PRMT] FOREIGN KEY ([ICS_BASIC_PRMT_ID]) REFERENCES [dbo].[ICS_BASIC_PRMT] ([ICS_BASIC_PRMT_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_CONTACT_BASIC_PRMT]...';

ALTER TABLE [dbo].[ICS_CONTACT] WITH NOCHECK
    ADD CONSTRAINT [FK_CONTACT_BASIC_PRMT] FOREIGN KEY ([ICS_BASIC_PRMT_ID]) REFERENCES [dbo].[ICS_BASIC_PRMT] ([ICS_BASIC_PRMT_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_NPDES_DAT_GRP_NUM_BSIC_PRMT]...';

ALTER TABLE [dbo].[ICS_NPDES_DAT_GRP_NUM] WITH NOCHECK
    ADD CONSTRAINT [FK_NPDES_DAT_GRP_NUM_BSIC_PRMT] FOREIGN KEY ([ICS_BASIC_PRMT_ID]) REFERENCES [dbo].[ICS_BASIC_PRMT] ([ICS_BASIC_PRMT_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_OTHR_PRMTS_BASIC_PRMT]...';

ALTER TABLE [dbo].[ICS_OTHR_PRMTS] WITH NOCHECK
    ADD CONSTRAINT [FK_OTHR_PRMTS_BASIC_PRMT] FOREIGN KEY ([ICS_BASIC_PRMT_ID]) REFERENCES [dbo].[ICS_BASIC_PRMT] ([ICS_BASIC_PRMT_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_ANLYT_MTHD_BS_ANNL_PROG_REP]...';

ALTER TABLE [dbo].[ICS_ANLYTCL_METHOD] WITH NOCHECK
    ADD CONSTRAINT [FK_ANLYT_MTHD_BS_ANNL_PROG_REP] FOREIGN KEY ([ICS_BS_ANNUL_PROG_REP_ID]) REFERENCES [dbo].[ICS_BS_ANNUL_PROG_REP] ([ICS_BS_ANNUL_PROG_REP_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_BS_ANNUL_PROG_REP_PAYLOAD]...';

ALTER TABLE [dbo].[ICS_BS_ANNUL_PROG_REP] WITH NOCHECK
    ADD CONSTRAINT [FK_BS_ANNUL_PROG_REP_PAYLOAD] FOREIGN KEY ([ICS_PAYLOAD_ID]) REFERENCES [dbo].[ICS_PAYLOAD] ([ICS_PAYLOAD_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_BS_PRMT_PAYLOAD]...';

ALTER TABLE [dbo].[ICS_BS_PRMT] WITH NOCHECK
    ADD CONSTRAINT [FK_BS_PRMT_PAYLOAD] FOREIGN KEY ([ICS_PAYLOAD_ID]) REFERENCES [dbo].[ICS_PAYLOAD] ([ICS_PAYLOAD_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_LAND_APPL_BMP_CAFO_INSP]...';

ALTER TABLE [dbo].[ICS_LAND_APPL_BMP] WITH NOCHECK
    ADD CONSTRAINT [FK_LAND_APPL_BMP_CAFO_INSP] FOREIGN KEY ([ICS_CAFO_INSP_ID]) REFERENCES [dbo].[ICS_CAFO_INSP] ([ICS_CAFO_INSP_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_CAFO_INSP_CMPL_MON]...';

ALTER TABLE [dbo].[ICS_CAFO_INSP] WITH NOCHECK
    ADD CONSTRAINT [FK_CAFO_INSP_CMPL_MON] FOREIGN KEY ([ICS_CMPL_MON_ID]) REFERENCES [dbo].[ICS_CMPL_MON] ([ICS_CMPL_MON_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_CAFO_INSP_VIOL_TYPE_CAF_INS]...';

ALTER TABLE [dbo].[ICS_CAFO_INSP_VIOL_TYPE] WITH NOCHECK
    ADD CONSTRAINT [FK_CAFO_INSP_VIOL_TYPE_CAF_INS] FOREIGN KEY ([ICS_CAFO_INSP_ID]) REFERENCES [dbo].[ICS_CAFO_INSP] ([ICS_CAFO_INSP_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_MNUR_LTT_PRC_WW_STO_CAF_INS]...';

ALTER TABLE [dbo].[ICS_MNUR_LTTR_PRCSS_WW_STOR] WITH NOCHECK
    ADD CONSTRAINT [FK_MNUR_LTT_PRC_WW_STO_CAF_INS] FOREIGN KEY ([ICS_CAFO_INSP_ID]) REFERENCES [dbo].[ICS_CAFO_INSP] ([ICS_CAFO_INSP_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_CONTAINMENT_CAFO_INSP]...';

ALTER TABLE [dbo].[ICS_CONTAINMENT] WITH NOCHECK
    ADD CONSTRAINT [FK_CONTAINMENT_CAFO_INSP] FOREIGN KEY ([ICS_CAFO_INSP_ID]) REFERENCES [dbo].[ICS_CAFO_INSP] ([ICS_CAFO_INSP_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_CNST_SITE_CNST_SITE_LIST]...';

ALTER TABLE [dbo].[ICS_CNST_SITE] WITH NOCHECK
    ADD CONSTRAINT [FK_CNST_SITE_CNST_SITE_LIST] FOREIGN KEY ([ICS_CNST_SITE_LIST_ID]) REFERENCES [dbo].[ICS_CNST_SITE_LIST] ([ICS_CNST_SITE_LIST_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_TELEPH_CONTACT]...';

ALTER TABLE [dbo].[ICS_TELEPH] WITH NOCHECK
    ADD CONSTRAINT [FK_TELEPH_CONTACT] FOREIGN KEY ([ICS_CONTACT_ID]) REFERENCES [dbo].[ICS_CONTACT] ([ICS_CONTACT_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_CONTACT_CAFO_PRMT]...';

ALTER TABLE [dbo].[ICS_CONTACT] WITH NOCHECK
    ADD CONSTRAINT [FK_CONTACT_CAFO_PRMT] FOREIGN KEY ([ICS_CAFO_PRMT_ID]) REFERENCES [dbo].[ICS_CAFO_PRMT] ([ICS_CAFO_PRMT_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_CONTACT_CMPL_MON]...';

ALTER TABLE [dbo].[ICS_CONTACT] WITH NOCHECK
    ADD CONSTRAINT [FK_CONTACT_CMPL_MON] FOREIGN KEY ([ICS_CMPL_MON_ID]) REFERENCES [dbo].[ICS_CMPL_MON] ([ICS_CMPL_MON_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_CONTACT_FAC]...';

ALTER TABLE [dbo].[ICS_CONTACT] WITH NOCHECK
    ADD CONSTRAINT [FK_CONTACT_FAC] FOREIGN KEY ([ICS_FAC_ID]) REFERENCES [dbo].[ICS_FAC] ([ICS_FAC_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_CONTACT_GNRL_PRMT]...';

ALTER TABLE [dbo].[ICS_CONTACT] WITH NOCHECK
    ADD CONSTRAINT [FK_CONTACT_GNRL_PRMT] FOREIGN KEY ([ICS_GNRL_PRMT_ID]) REFERENCES [dbo].[ICS_GNRL_PRMT] ([ICS_GNRL_PRMT_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_CONTACT_MASTER_GNRL_PRMT]...';

ALTER TABLE [dbo].[ICS_CONTACT] WITH NOCHECK
    ADD CONSTRAINT [FK_CONTACT_MASTER_GNRL_PRMT] FOREIGN KEY ([ICS_MASTER_GNRL_PRMT_ID]) REFERENCES [dbo].[ICS_MASTER_GNRL_PRMT] ([ICS_MASTER_GNRL_PRMT_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_CONTACT_PRETR_PRMT]...';

ALTER TABLE [dbo].[ICS_CONTACT] WITH NOCHECK
    ADD CONSTRAINT [FK_CONTACT_PRETR_PRMT] FOREIGN KEY ([ICS_PRETR_PRMT_ID]) REFERENCES [dbo].[ICS_PRETR_PRMT] ([ICS_PRETR_PRMT_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_CONTACT_PRMT_FEATR]...';

ALTER TABLE [dbo].[ICS_CONTACT] WITH NOCHECK
    ADD CONSTRAINT [FK_CONTACT_PRMT_FEATR] FOREIGN KEY ([ICS_PRMT_FEATR_ID]) REFERENCES [dbo].[ICS_PRMT_FEATR] ([ICS_PRMT_FEATR_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_CONTACT_SW_CNST_PRMT]...';

ALTER TABLE [dbo].[ICS_CONTACT] WITH NOCHECK
    ADD CONSTRAINT [FK_CONTACT_SW_CNST_PRMT] FOREIGN KEY ([ICS_SW_CNST_PRMT_ID]) REFERENCES [dbo].[ICS_SW_CNST_PRMT] ([ICS_SW_CNST_PRMT_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_CONTACT_SW_INDST_PRMT]...';

ALTER TABLE [dbo].[ICS_CONTACT] WITH NOCHECK
    ADD CONSTRAINT [FK_CONTACT_SW_INDST_PRMT] FOREIGN KEY ([ICS_SW_INDST_PRMT_ID]) REFERENCES [dbo].[ICS_SW_INDST_PRMT] ([ICS_SW_INDST_PRMT_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_CONTACT_UNPRMT_FAC]...';

ALTER TABLE [dbo].[ICS_CONTACT] WITH NOCHECK
    ADD CONSTRAINT [FK_CONTACT_UNPRMT_FAC] FOREIGN KEY ([ICS_UNPRMT_FAC_ID]) REFERENCES [dbo].[ICS_UNPRMT_FAC] ([ICS_UNPRMT_FAC_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_CNTC_BS_OFF_SIT_HND_APP_PRP]...';

ALTER TABLE [dbo].[ICS_CONTACT] WITH NOCHECK
    ADD CONSTRAINT [FK_CNTC_BS_OFF_SIT_HND_APP_PRP] FOREIGN KEY ([ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID]) REFERENCES [dbo].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] ([ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_COPY_MGP_LMT_SET_PAYLOAD]...';

ALTER TABLE [dbo].[ICS_COPY_MGP_LMT_SET] WITH NOCHECK
    ADD CONSTRAINT [FK_COPY_MGP_LMT_SET_PAYLOAD] FOREIGN KEY ([ICS_PAYLOAD_ID]) REFERENCES [dbo].[ICS_PAYLOAD] ([ICS_PAYLOAD_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_REP_PARAM_DSCH_MON_REP]...';

ALTER TABLE [dbo].[ICS_REP_PARAM] WITH NOCHECK
    ADD CONSTRAINT [FK_REP_PARAM_DSCH_MON_REP] FOREIGN KEY ([ICS_DSCH_MON_REP_ID]) REFERENCES [dbo].[ICS_DSCH_MON_REP] ([ICS_DSCH_MON_REP_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_INCIN_DSCH_MON_REP]...';

ALTER TABLE [dbo].[ICS_INCIN] WITH NOCHECK
    ADD CONSTRAINT [FK_INCIN_DSCH_MON_REP] FOREIGN KEY ([ICS_DSCH_MON_REP_ID]) REFERENCES [dbo].[ICS_DSCH_MON_REP] ([ICS_DSCH_MON_REP_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_LAND_APPL_SITE_DSCH_MON_REP]...';

ALTER TABLE [dbo].[ICS_LAND_APPL_SITE] WITH NOCHECK
    ADD CONSTRAINT [FK_LAND_APPL_SITE_DSCH_MON_REP] FOREIGN KEY ([ICS_DSCH_MON_REP_ID]) REFERENCES [dbo].[ICS_DSCH_MON_REP] ([ICS_DSCH_MON_REP_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_SURF_DSPL_SITE_DSCH_MON_REP]...';

ALTER TABLE [dbo].[ICS_SURF_DSPL_SITE] WITH NOCHECK
    ADD CONSTRAINT [FK_SURF_DSPL_SITE_DSCH_MON_REP] FOREIGN KEY ([ICS_DSCH_MON_REP_ID]) REFERENCES [dbo].[ICS_DSCH_MON_REP] ([ICS_DSCH_MON_REP_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_CO_DSPL_SITE_DSCH_MON_REP]...';

ALTER TABLE [dbo].[ICS_CO_DSPL_SITE] WITH NOCHECK
    ADD CONSTRAINT [FK_CO_DSPL_SITE_DSCH_MON_REP] FOREIGN KEY ([ICS_DSCH_MON_REP_ID]) REFERENCES [dbo].[ICS_DSCH_MON_REP] ([ICS_DSCH_MON_REP_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_DSCH_MON_REP_PAYLOAD]...';

ALTER TABLE [dbo].[ICS_DSCH_MON_REP] WITH NOCHECK
    ADD CONSTRAINT [FK_DSCH_MON_REP_PAYLOAD] FOREIGN KEY ([ICS_PAYLOAD_ID]) REFERENCES [dbo].[ICS_PAYLOAD] ([ICS_PAYLOAD_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_FAC_GNRL_PRMT]...';

ALTER TABLE [dbo].[ICS_FAC] WITH NOCHECK
    ADD CONSTRAINT [FK_FAC_GNRL_PRMT] FOREIGN KEY ([ICS_GNRL_PRMT_ID]) REFERENCES [dbo].[ICS_GNRL_PRMT] ([ICS_GNRL_PRMT_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_FAC_CLASS_FAC]...';

ALTER TABLE [dbo].[ICS_FAC_CLASS] WITH NOCHECK
    ADD CONSTRAINT [FK_FAC_CLASS_FAC] FOREIGN KEY ([ICS_FAC_ID]) REFERENCES [dbo].[ICS_FAC] ([ICS_FAC_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_GEO_COORD_FAC]...';

ALTER TABLE [dbo].[ICS_GEO_COORD] WITH NOCHECK
    ADD CONSTRAINT [FK_GEO_COORD_FAC] FOREIGN KEY ([ICS_FAC_ID]) REFERENCES [dbo].[ICS_FAC] ([ICS_FAC_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_SIC_CODE_FAC]...';

ALTER TABLE [dbo].[ICS_SIC_CODE] WITH NOCHECK
    ADD CONSTRAINT [FK_SIC_CODE_FAC] FOREIGN KEY ([ICS_FAC_ID]) REFERENCES [dbo].[ICS_FAC] ([ICS_FAC_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_NAICS_CODE_FAC]...';

ALTER TABLE [dbo].[ICS_NAICS_CODE] WITH NOCHECK
    ADD CONSTRAINT [FK_NAICS_CODE_FAC] FOREIGN KEY ([ICS_FAC_ID]) REFERENCES [dbo].[ICS_FAC] ([ICS_FAC_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_ORIG_PROGS_FAC]...';

ALTER TABLE [dbo].[ICS_ORIG_PROGS] WITH NOCHECK
    ADD CONSTRAINT [FK_ORIG_PROGS_FAC] FOREIGN KEY ([ICS_FAC_ID]) REFERENCES [dbo].[ICS_FAC] ([ICS_FAC_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_PLCY_FAC]...';

ALTER TABLE [dbo].[ICS_PLCY] WITH NOCHECK
    ADD CONSTRAINT [FK_PLCY_FAC] FOREIGN KEY ([ICS_FAC_ID]) REFERENCES [dbo].[ICS_FAC] ([ICS_FAC_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_FINAL_ORDER_FRML_ENFRC_ACTN]...';

ALTER TABLE [dbo].[ICS_FINAL_ORDER] WITH NOCHECK
    ADD CONSTRAINT [FK_FINAL_ORDER_FRML_ENFRC_ACTN] FOREIGN KEY ([ICS_FRML_ENFRC_ACTN_ID]) REFERENCES [dbo].[ICS_FRML_ENFRC_ACTN] ([ICS_FRML_ENFRC_ACTN_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_FINL_ORDR_PRMT_IDNT_FIN_ORD]...';

ALTER TABLE [dbo].[ICS_FINAL_ORDER_PRMT_IDENT] WITH NOCHECK
    ADD CONSTRAINT [FK_FINL_ORDR_PRMT_IDNT_FIN_ORD] FOREIGN KEY ([ICS_FINAL_ORDER_ID]) REFERENCES [dbo].[ICS_FINAL_ORDER] ([ICS_FINAL_ORDER_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_SEP_FINAL_ORDER]...';

ALTER TABLE [dbo].[ICS_SEP] WITH NOCHECK
    ADD CONSTRAINT [FK_SEP_FINAL_ORDER] FOREIGN KEY ([ICS_FINAL_ORDER_ID]) REFERENCES [dbo].[ICS_FINAL_ORDER] ([ICS_FINAL_ORDER_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_GEO_COORD_PRMT_FEATR]...';

ALTER TABLE [dbo].[ICS_GEO_COORD] WITH NOCHECK
    ADD CONSTRAINT [FK_GEO_COORD_PRMT_FEATR] FOREIGN KEY ([ICS_PRMT_FEATR_ID]) REFERENCES [dbo].[ICS_PRMT_FEATR] ([ICS_PRMT_FEATR_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_GEO_COORD_UNPRMT_FAC]...';

ALTER TABLE [dbo].[ICS_GEO_COORD] WITH NOCHECK
    ADD CONSTRAINT [FK_GEO_COORD_UNPRMT_FAC] FOREIGN KEY ([ICS_UNPRMT_FAC_ID]) REFERENCES [dbo].[ICS_UNPRMT_FAC] ([ICS_UNPRMT_FAC_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_GEO_COORD_COPY_MGP_LMT_SET]...';

ALTER TABLE [dbo].[ICS_GEO_COORD] WITH NOCHECK
    ADD CONSTRAINT [FK_GEO_COORD_COPY_MGP_LMT_SET] FOREIGN KEY ([ICS_COPY_MGP_LMT_SET_ID]) REFERENCES [dbo].[ICS_COPY_MGP_LMT_SET] ([ICS_COPY_MGP_LMT_SET_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_EFFLU_GUIDE_GNRL_PRMT]...';

ALTER TABLE [dbo].[ICS_EFFLU_GUIDE] WITH NOCHECK
    ADD CONSTRAINT [FK_EFFLU_GUIDE_GNRL_PRMT] FOREIGN KEY ([ICS_GNRL_PRMT_ID]) REFERENCES [dbo].[ICS_GNRL_PRMT] ([ICS_GNRL_PRMT_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_GNRL_PRMT_PAYLOAD]...';

ALTER TABLE [dbo].[ICS_GNRL_PRMT] WITH NOCHECK
    ADD CONSTRAINT [FK_GNRL_PRMT_PAYLOAD] FOREIGN KEY ([ICS_PAYLOAD_ID]) REFERENCES [dbo].[ICS_PAYLOAD] ([ICS_PAYLOAD_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_REP_NON_CMPL_STAT_GNRL_PRMT]...';

ALTER TABLE [dbo].[ICS_REP_NON_CMPL_STAT] WITH NOCHECK
    ADD CONSTRAINT [FK_REP_NON_CMPL_STAT_GNRL_PRMT] FOREIGN KEY ([ICS_GNRL_PRMT_ID]) REFERENCES [dbo].[ICS_GNRL_PRMT] ([ICS_GNRL_PRMT_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_SIC_CODE_GNRL_PRMT]...';

ALTER TABLE [dbo].[ICS_SIC_CODE] WITH NOCHECK
    ADD CONSTRAINT [FK_SIC_CODE_GNRL_PRMT] FOREIGN KEY ([ICS_GNRL_PRMT_ID]) REFERENCES [dbo].[ICS_GNRL_PRMT] ([ICS_GNRL_PRMT_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_ASSC_PRMT_GNRL_PRMT]...';

ALTER TABLE [dbo].[ICS_ASSC_PRMT] WITH NOCHECK
    ADD CONSTRAINT [FK_ASSC_PRMT_GNRL_PRMT] FOREIGN KEY ([ICS_GNRL_PRMT_ID]) REFERENCES [dbo].[ICS_GNRL_PRMT] ([ICS_GNRL_PRMT_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_CMPL_TRACK_STAT_GNRL_PRMT]...';

ALTER TABLE [dbo].[ICS_CMPL_TRACK_STAT] WITH NOCHECK
    ADD CONSTRAINT [FK_CMPL_TRACK_STAT_GNRL_PRMT] FOREIGN KEY ([ICS_GNRL_PRMT_ID]) REFERENCES [dbo].[ICS_GNRL_PRMT] ([ICS_GNRL_PRMT_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_NAICS_CODE_GNRL_PRMT]...';

ALTER TABLE [dbo].[ICS_NAICS_CODE] WITH NOCHECK
    ADD CONSTRAINT [FK_NAICS_CODE_GNRL_PRMT] FOREIGN KEY ([ICS_GNRL_PRMT_ID]) REFERENCES [dbo].[ICS_GNRL_PRMT] ([ICS_GNRL_PRMT_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_NPDES_DAT_GRP_NUM_GNRL_PRMT]...';

ALTER TABLE [dbo].[ICS_NPDES_DAT_GRP_NUM] WITH NOCHECK
    ADD CONSTRAINT [FK_NPDES_DAT_GRP_NUM_GNRL_PRMT] FOREIGN KEY ([ICS_GNRL_PRMT_ID]) REFERENCES [dbo].[ICS_GNRL_PRMT] ([ICS_GNRL_PRMT_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_OTHR_PRMTS_GNRL_PRMT]...';

ALTER TABLE [dbo].[ICS_OTHR_PRMTS] WITH NOCHECK
    ADD CONSTRAINT [FK_OTHR_PRMTS_GNRL_PRMT] FOREIGN KEY ([ICS_GNRL_PRMT_ID]) REFERENCES [dbo].[ICS_GNRL_PRMT] ([ICS_GNRL_PRMT_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_IMPRD_WTR_PLLTNTS_PLUT_LIST]...';

ALTER TABLE [dbo].[ICS_IMPAIRED_WTR_POLLUTANTS] WITH NOCHECK
    ADD CONSTRAINT [FK_IMPRD_WTR_PLLTNTS_PLUT_LIST] FOREIGN KEY ([ICS_POLUT_LIST_ID]) REFERENCES [dbo].[ICS_POLUT_LIST] ([ICS_POLUT_LIST_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_LMT_SET_SCHD_LMT_SET]...';

ALTER TABLE [dbo].[ICS_LMT_SET_SCHD] WITH NOCHECK
    ADD CONSTRAINT [FK_LMT_SET_SCHD_LMT_SET] FOREIGN KEY ([ICS_LMT_SET_ID]) REFERENCES [dbo].[ICS_LMT_SET] ([ICS_LMT_SET_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_LMT_SET_SCH_COP_MGP_LMT_SET]...';

ALTER TABLE [dbo].[ICS_LMT_SET_SCHD] WITH NOCHECK
    ADD CONSTRAINT [FK_LMT_SET_SCH_COP_MGP_LMT_SET] FOREIGN KEY ([ICS_COPY_MGP_LMT_SET_ID]) REFERENCES [dbo].[ICS_COPY_MGP_LMT_SET] ([ICS_COPY_MGP_LMT_SET_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_LMT_SET_STAT_LMT_SET]...';

ALTER TABLE [dbo].[ICS_LMT_SET_STAT] WITH NOCHECK
    ADD CONSTRAINT [FK_LMT_SET_STAT_LMT_SET] FOREIGN KEY ([ICS_LMT_SET_ID]) REFERENCES [dbo].[ICS_LMT_SET] ([ICS_LMT_SET_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_LMT_SET_STA_COP_MGP_LMT_SET]...';

ALTER TABLE [dbo].[ICS_LMT_SET_STAT] WITH NOCHECK
    ADD CONSTRAINT [FK_LMT_SET_STA_COP_MGP_LMT_SET] FOREIGN KEY ([ICS_COPY_MGP_LMT_SET_ID]) REFERENCES [dbo].[ICS_COPY_MGP_LMT_SET] ([ICS_COPY_MGP_LMT_SET_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_LMTS_PAYLOAD]...';

ALTER TABLE [dbo].[ICS_LMTS] WITH NOCHECK
    ADD CONSTRAINT [FK_LMTS_PAYLOAD] FOREIGN KEY ([ICS_PAYLOAD_ID]) REFERENCES [dbo].[ICS_PAYLOAD] ([ICS_PAYLOAD_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_MN_LMT_APPLIES_LMTS]...';

ALTER TABLE [dbo].[ICS_MN_LMT_APPLIES] WITH NOCHECK
    ADD CONSTRAINT [FK_MN_LMT_APPLIES_LMTS] FOREIGN KEY ([ICS_LMTS_ID]) REFERENCES [dbo].[ICS_LMTS] ([ICS_LMTS_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_NUM_COND_LMTS]...';

ALTER TABLE [dbo].[ICS_NUM_COND] WITH NOCHECK
    ADD CONSTRAINT [FK_NUM_COND_LMTS] FOREIGN KEY ([ICS_LMTS_ID]) REFERENCES [dbo].[ICS_LMTS] ([ICS_LMTS_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_MNUR_LTT_PRC_WW_STO_CAF_PRM]...';

ALTER TABLE [dbo].[ICS_MNUR_LTTR_PRCSS_WW_STOR] WITH NOCHECK
    ADD CONSTRAINT [FK_MNUR_LTT_PRC_WW_STO_CAF_PRM] FOREIGN KEY ([ICS_CAFO_PRMT_ID]) REFERENCES [dbo].[ICS_CAFO_PRMT] ([ICS_CAFO_PRMT_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_PTHG_RDCT_TYPE_BS_MGMT_PRCT]...';

ALTER TABLE [dbo].[ICS_PATHOGEN_REDUCTION_TYPE] WITH NOCHECK
    ADD CONSTRAINT [FK_PTHG_RDCT_TYPE_BS_MGMT_PRCT] FOREIGN KEY ([ICS_BS_MGMT_PRACTICE_ID]) REFERENCES [dbo].[ICS_BS_MGMT_PRACTICE] ([ICS_BS_MGMT_PRACTICE_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_PTHG_RDC_TYP_PRM_BS_MGM_PRC]...';

ALTER TABLE [dbo].[ICS_PATHOGEN_REDUCTION_TYPE] WITH NOCHECK
    ADD CONSTRAINT [FK_PTHG_RDC_TYP_PRM_BS_MGM_PRC] FOREIGN KEY ([ICS_PRMT_BS_MGMT_PRACTICE_ID]) REFERENCES [dbo].[ICS_PRMT_BS_MGMT_PRACTICE] ([ICS_PRMT_BS_MGMT_PRACTICE_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_PRETR_PRMT_PAYLOAD]...';

ALTER TABLE [dbo].[ICS_PRETR_PRMT] WITH NOCHECK
    ADD CONSTRAINT [FK_PRETR_PRMT_PAYLOAD] FOREIGN KEY ([ICS_PAYLOAD_ID]) REFERENCES [dbo].[ICS_PAYLOAD] ([ICS_PAYLOAD_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_GPCF_NTCE_OF_INT_SW_CNS_PRM]...';

ALTER TABLE [dbo].[ICS_GPCF_NOTICE_OF_INTENT] WITH NOCHECK
    ADD CONSTRAINT [FK_GPCF_NTCE_OF_INT_SW_CNS_PRM] FOREIGN KEY ([ICS_SW_CNST_PRMT_ID]) REFERENCES [dbo].[ICS_SW_CNST_PRMT] ([ICS_SW_CNST_PRMT_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_SW_CNST_PRMT_PAYLOAD]...';

ALTER TABLE [dbo].[ICS_SW_CNST_PRMT] WITH NOCHECK
    ADD CONSTRAINT [FK_SW_CNST_PRMT_PAYLOAD] FOREIGN KEY ([ICS_PAYLOAD_ID]) REFERENCES [dbo].[ICS_PAYLOAD] ([ICS_PAYLOAD_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_TRTM_CHMS_LIST_SW_CNST_PRMT]...';

ALTER TABLE [dbo].[ICS_TRTMNT_CHEMS_LIST] WITH NOCHECK
    ADD CONSTRAINT [FK_TRTM_CHMS_LIST_SW_CNST_PRMT] FOREIGN KEY ([ICS_SW_CNST_PRMT_ID]) REFERENCES [dbo].[ICS_SW_CNST_PRMT] ([ICS_SW_CNST_PRMT_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_GPCF_NO_EXPSR_SW_INDST_PRMT]...';

ALTER TABLE [dbo].[ICS_GPCF_NO_EXPOSURE] WITH NOCHECK
    ADD CONSTRAINT [FK_GPCF_NO_EXPSR_SW_INDST_PRMT] FOREIGN KEY ([ICS_SW_INDST_PRMT_ID]) REFERENCES [dbo].[ICS_SW_INDST_PRMT] ([ICS_SW_INDST_PRMT_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_GPCF_NTCE_OF_INT_SW_IND_PRM]...';

ALTER TABLE [dbo].[ICS_GPCF_NOTICE_OF_INTENT] WITH NOCHECK
    ADD CONSTRAINT [FK_GPCF_NTCE_OF_INT_SW_IND_PRM] FOREIGN KEY ([ICS_SW_INDST_PRMT_ID]) REFERENCES [dbo].[ICS_SW_INDST_PRMT] ([ICS_SW_INDST_PRMT_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_GPCF_NTCE_OF_TER_SW_IND_PRM]...';

ALTER TABLE [dbo].[ICS_GPCF_NOTICE_OF_TERM] WITH NOCHECK
    ADD CONSTRAINT [FK_GPCF_NTCE_OF_TER_SW_IND_PRM] FOREIGN KEY ([ICS_SW_INDST_PRMT_ID]) REFERENCES [dbo].[ICS_SW_INDST_PRMT] ([ICS_SW_INDST_PRMT_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_SW_INDST_PRMT_PAYLOAD]...';

ALTER TABLE [dbo].[ICS_SW_INDST_PRMT] WITH NOCHECK
    ADD CONSTRAINT [FK_SW_INDST_PRMT_PAYLOAD] FOREIGN KEY ([ICS_PAYLOAD_ID]) REFERENCES [dbo].[ICS_PAYLOAD] ([ICS_PAYLOAD_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_TMDL_POLUT_TMDL_POLLUTANTS]...';

ALTER TABLE [dbo].[ICS_TMDL_POLUT] WITH NOCHECK
    ADD CONSTRAINT [FK_TMDL_POLUT_TMDL_POLLUTANTS] FOREIGN KEY ([ICS_TMDL_POLLUTANTS_ID]) REFERENCES [dbo].[ICS_TMDL_POLLUTANTS] ([ICS_TMDL_POLLUTANTS_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_TMDL_POLLUTANTS_POLUT_LIST]...';

ALTER TABLE [dbo].[ICS_TMDL_POLLUTANTS] WITH NOCHECK
    ADD CONSTRAINT [FK_TMDL_POLLUTANTS_POLUT_LIST] FOREIGN KEY ([ICS_POLUT_LIST_ID]) REFERENCES [dbo].[ICS_POLUT_LIST] ([ICS_POLUT_LIST_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_PRMT_COMP_TYPE_UNPRMT_FAC]...';

ALTER TABLE [dbo].[ICS_PRMT_COMP_TYPE] WITH NOCHECK
    ADD CONSTRAINT [FK_PRMT_COMP_TYPE_UNPRMT_FAC] FOREIGN KEY ([ICS_UNPRMT_FAC_ID]) REFERENCES [dbo].[ICS_UNPRMT_FAC] ([ICS_UNPRMT_FAC_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_FAC_CLASS_UNPRMT_FAC]...';

ALTER TABLE [dbo].[ICS_FAC_CLASS] WITH NOCHECK
    ADD CONSTRAINT [FK_FAC_CLASS_UNPRMT_FAC] FOREIGN KEY ([ICS_UNPRMT_FAC_ID]) REFERENCES [dbo].[ICS_UNPRMT_FAC] ([ICS_UNPRMT_FAC_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_SIC_CODE_UNPRMT_FAC]...';

ALTER TABLE [dbo].[ICS_SIC_CODE] WITH NOCHECK
    ADD CONSTRAINT [FK_SIC_CODE_UNPRMT_FAC] FOREIGN KEY ([ICS_UNPRMT_FAC_ID]) REFERENCES [dbo].[ICS_UNPRMT_FAC] ([ICS_UNPRMT_FAC_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_NAICS_CODE_UNPRMT_FAC]...';

ALTER TABLE [dbo].[ICS_NAICS_CODE] WITH NOCHECK
    ADD CONSTRAINT [FK_NAICS_CODE_UNPRMT_FAC] FOREIGN KEY ([ICS_UNPRMT_FAC_ID]) REFERENCES [dbo].[ICS_UNPRMT_FAC] ([ICS_UNPRMT_FAC_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_UNPRMT_FAC_PAYLOAD]...';

ALTER TABLE [dbo].[ICS_UNPRMT_FAC] WITH NOCHECK
    ADD CONSTRAINT [FK_UNPRMT_FAC_PAYLOAD] FOREIGN KEY ([ICS_PAYLOAD_ID]) REFERENCES [dbo].[ICS_PAYLOAD] ([ICS_PAYLOAD_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_ORIG_PROGS_UNPRMT_FAC]...';

ALTER TABLE [dbo].[ICS_ORIG_PROGS] WITH NOCHECK
    ADD CONSTRAINT [FK_ORIG_PROGS_UNPRMT_FAC] FOREIGN KEY ([ICS_UNPRMT_FAC_ID]) REFERENCES [dbo].[ICS_UNPRMT_FAC] ([ICS_UNPRMT_FAC_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_PLCY_UNPRMT_FAC]...';

ALTER TABLE [dbo].[ICS_PLCY] WITH NOCHECK
    ADD CONSTRAINT [FK_PLCY_UNPRMT_FAC] FOREIGN KEY ([ICS_UNPRMT_FAC_ID]) REFERENCES [dbo].[ICS_UNPRMT_FAC] ([ICS_UNPRMT_FAC_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_VCTR_A_RDCT_TYPE_BS_MGM_PRC]...';

ALTER TABLE [dbo].[ICS_VECTOR_A_REDUCTION_TYPE] WITH NOCHECK
    ADD CONSTRAINT [FK_VCTR_A_RDCT_TYPE_BS_MGM_PRC] FOREIGN KEY ([ICS_BS_MGMT_PRACTICE_ID]) REFERENCES [dbo].[ICS_BS_MGMT_PRACTICE] ([ICS_BS_MGMT_PRACTICE_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_VCT_A_RDC_TYP_PRM_BS_MGM_PR]...';

ALTER TABLE [dbo].[ICS_VECTOR_A_REDUCTION_TYPE] WITH NOCHECK
    ADD CONSTRAINT [FK_VCT_A_RDC_TYP_PRM_BS_MGM_PR] FOREIGN KEY ([ICS_PRMT_BS_MGMT_PRACTICE_ID]) REFERENCES [dbo].[ICS_PRMT_BS_MGMT_PRACTICE] ([ICS_PRMT_BS_MGMT_PRACTICE_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_IMPACT_SSO_EVT_SSO_INSP]...';

ALTER TABLE [dbo].[ICS_IMPACT_SSO_EVT] WITH NOCHECK
    ADD CONSTRAINT [FK_IMPACT_SSO_EVT_SSO_INSP] FOREIGN KEY ([ICS_SSO_INSP_ID]) REFERENCES [dbo].[ICS_SSO_INSP] ([ICS_SSO_INSP_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_PROJ_SRCS_FUND_SW_MS_4_INSP]...';

ALTER TABLE [dbo].[ICS_PROJ_SRCS_FUND] WITH NOCHECK
    ADD CONSTRAINT [FK_PROJ_SRCS_FUND_SW_MS_4_INSP] FOREIGN KEY ([ICS_SW_MS_4_INSP_ID]) REFERENCES [dbo].[ICS_SW_MS_4_INSP] ([ICS_SW_MS_4_INSP_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_SATL_COLL_SYSTM_POTW_PRMT]...';

ALTER TABLE [dbo].[ICS_SATL_COLL_SYSTM] WITH NOCHECK
    ADD CONSTRAINT [FK_SATL_COLL_SYSTM_POTW_PRMT] FOREIGN KEY ([ICS_POTW_PRMT_ID]) REFERENCES [dbo].[ICS_POTW_PRMT] ([ICS_POTW_PRMT_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_SSO_STPS_SSO_INSP]...';

ALTER TABLE [dbo].[ICS_SSO_STPS] WITH NOCHECK
    ADD CONSTRAINT [FK_SSO_STPS_SSO_INSP] FOREIGN KEY ([ICS_SSO_INSP_ID]) REFERENCES [dbo].[ICS_SSO_INSP] ([ICS_SSO_INSP_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_SSO_SYSTM_COMP_SSO_INSP]...';

ALTER TABLE [dbo].[ICS_SSO_SYSTM_COMP] WITH NOCHECK
    ADD CONSTRAINT [FK_SSO_SYSTM_COMP_SSO_INSP] FOREIGN KEY ([ICS_SSO_INSP_ID]) REFERENCES [dbo].[ICS_SSO_INSP] ([ICS_SSO_INSP_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_BS_FAC_TRTM_BS_ANNL_PRO_REP]...';

ALTER TABLE [dbo].[ICS_BS_FAC_TRTMNT] WITH NOCHECK
    ADD CONSTRAINT [FK_BS_FAC_TRTM_BS_ANNL_PRO_REP] FOREIGN KEY ([ICS_BS_ANNUL_PROG_REP_ID]) REFERENCES [dbo].[ICS_BS_ANNUL_PROG_REP] ([ICS_BS_ANNUL_PROG_REP_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_BS_FAC_TRTMNT_BS_PRMT]...';

ALTER TABLE [dbo].[ICS_BS_FAC_TRTMNT] WITH NOCHECK
    ADD CONSTRAINT [FK_BS_FAC_TRTMNT_BS_PRMT] FOREIGN KEY ([ICS_BS_PRMT_ID]) REFERENCES [dbo].[ICS_BS_PRMT] ([ICS_BS_PRMT_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_BS_FAC_TYPE_BS_ANNL_PRO_REP]...';

ALTER TABLE [dbo].[ICS_BS_FAC_TYPE] WITH NOCHECK
    ADD CONSTRAINT [FK_BS_FAC_TYPE_BS_ANNL_PRO_REP] FOREIGN KEY ([ICS_BS_ANNUL_PROG_REP_ID]) REFERENCES [dbo].[ICS_BS_ANNUL_PROG_REP] ([ICS_BS_ANNUL_PROG_REP_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_BS_FAC_TYPE_BS_PRMT]...';

ALTER TABLE [dbo].[ICS_BS_FAC_TYPE] WITH NOCHECK
    ADD CONSTRAINT [FK_BS_FAC_TYPE_BS_PRMT] FOREIGN KEY ([ICS_BS_PRMT_ID]) REFERENCES [dbo].[ICS_BS_PRMT] ([ICS_BS_PRMT_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_BS_INCN_EMSS_CNT_TYP_BS_INC]...';

ALTER TABLE [dbo].[ICS_BS_INCIN_EMISSIONS_CONTROL_TYPE] WITH NOCHECK
    ADD CONSTRAINT [FK_BS_INCN_EMSS_CNT_TYP_BS_INC] FOREIGN KEY ([ICS_BS_INCINERATION_ID]) REFERENCES [dbo].[ICS_BS_INCINERATION] ([ICS_BS_INCINERATION_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_BS_INCINRTON_BS_MGMT_PRCTCE]...';

ALTER TABLE [dbo].[ICS_BS_INCINERATION] WITH NOCHECK
    ADD CONSTRAINT [FK_BS_INCINRTON_BS_MGMT_PRCTCE] FOREIGN KEY ([ICS_BS_MGMT_PRACTICE_ID]) REFERENCES [dbo].[ICS_BS_MGMT_PRACTICE] ([ICS_BS_MGMT_PRACTICE_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_BS_MGMT_PRCT_BS_ANN_PRO_REP]...';

ALTER TABLE [dbo].[ICS_BS_MGMT_PRACTICE] WITH NOCHECK
    ADD CONSTRAINT [FK_BS_MGMT_PRCT_BS_ANN_PRO_REP] FOREIGN KEY ([ICS_BS_ANNUL_PROG_REP_ID]) REFERENCES [dbo].[ICS_BS_ANNUL_PROG_REP] ([ICS_BS_ANNUL_PROG_REP_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_BS_OFF_SI_HN_AP_PR_BS_MG_PR]...';

ALTER TABLE [dbo].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] WITH NOCHECK
    ADD CONSTRAINT [FK_BS_OFF_SI_HN_AP_PR_BS_MG_PR] FOREIGN KEY ([ICS_BS_MGMT_PRACTICE_ID]) REFERENCES [dbo].[ICS_BS_MGMT_PRACTICE] ([ICS_BS_MGMT_PRACTICE_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_BS_OF_SI_HN_AP_PR_PR_BS_MG]...';

ALTER TABLE [dbo].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] WITH NOCHECK
    ADD CONSTRAINT [FK_BS_OF_SI_HN_AP_PR_PR_BS_MG] FOREIGN KEY ([ICS_PRMT_BS_MGMT_PRACTICE_ID]) REFERENCES [dbo].[ICS_PRMT_BS_MGMT_PRACTICE] ([ICS_PRMT_BS_MGMT_PRACTICE_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_BS_SWGE_SLD_PAR_CMP_MON_EVT]...';

ALTER TABLE [dbo].[ICS_BS_SEWAGE_SLDG_PARAM] WITH NOCHECK
    ADD CONSTRAINT [FK_BS_SWGE_SLD_PAR_CMP_MON_EVT] FOREIGN KEY ([ICS_CMPL_MON_EVT_ID]) REFERENCES [dbo].[ICS_CMPL_MON_EVT] ([ICS_CMPL_MON_EVT_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_BS_SWGE_SLDG_PAR_BS_MGM_PRC]...';

ALTER TABLE [dbo].[ICS_BS_SEWAGE_SLDG_PARAM] WITH NOCHECK
    ADD CONSTRAINT [FK_BS_SWGE_SLDG_PAR_BS_MGM_PRC] FOREIGN KEY ([ICS_BS_MGMT_PRACTICE_ID]) REFERENCES [dbo].[ICS_BS_MGMT_PRACTICE] ([ICS_BS_MGMT_PRACTICE_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_BS_SWGE_SLDG_PARM_BS_INCNRT]...';

ALTER TABLE [dbo].[ICS_BS_SEWAGE_SLDG_PARAM] WITH NOCHECK
    ADD CONSTRAINT [FK_BS_SWGE_SLDG_PARM_BS_INCNRT] FOREIGN KEY ([ICS_BS_INCINERATION_ID]) REFERENCES [dbo].[ICS_BS_INCINERATION] ([ICS_BS_INCINERATION_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_BYP_TR_PL_EQ_SE_OV_BY_RE_EV]...';

ALTER TABLE [dbo].[ICS_BYPASS_TRTMNT_PLANT_EQUIPMENT] WITH NOCHECK
    ADD CONSTRAINT [FK_BYP_TR_PL_EQ_SE_OV_BY_RE_EV] FOREIGN KEY ([ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID]) REFERENCES [dbo].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT] ([ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_CAFO_ANNUL_PROG_REP_PAYLOAD]...';

ALTER TABLE [dbo].[ICS_CAFO_ANNUL_PROG_REP] WITH NOCHECK
    ADD CONSTRAINT [FK_CAFO_ANNUL_PROG_REP_PAYLOAD] FOREIGN KEY ([ICS_PAYLOAD_ID]) REFERENCES [dbo].[ICS_PAYLOAD] ([ICS_PAYLOAD_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_CAF_LA_AP_FL_IN_CA_AN_PR_RE]...';

ALTER TABLE [dbo].[ICS_CAFO_LAND_APPL_FLD_INFO] WITH NOCHECK
    ADD CONSTRAINT [FK_CAF_LA_AP_FL_IN_CA_AN_PR_RE] FOREIGN KEY ([ICS_CAFO_ANNUL_PROG_REP_ID]) REFERENCES [dbo].[ICS_CAFO_ANNUL_PROG_REP] ([ICS_CAFO_ANNUL_PROG_REP_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_CAF_PRO_ARE_DSC_CA_AN_PR_RE]...';

ALTER TABLE [dbo].[ICS_CAFO_PROD_AREA_DSCH] WITH NOCHECK
    ADD CONSTRAINT [FK_CAF_PRO_ARE_DSC_CA_AN_PR_RE] FOREIGN KEY ([ICS_CAFO_ANNUL_PROG_REP_ID]) REFERENCES [dbo].[ICS_CAFO_ANNUL_PROG_REP] ([ICS_CAFO_ANNUL_PROG_REP_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_CFM_FLD_AMN_CAF_LA_AP_FL_IN]...';

ALTER TABLE [dbo].[ICS_CAFOMLPW_FLD_AMOUNTS] WITH NOCHECK
    ADD CONSTRAINT [FK_CFM_FLD_AMN_CAF_LA_AP_FL_IN] FOREIGN KEY ([ICS_CAFO_LAND_APPL_FLD_INFO_ID]) REFERENCES [dbo].[ICS_CAFO_LAND_APPL_FLD_INFO] ([ICS_CAFO_LAND_APPL_FLD_INFO_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_CFM_NUT_MON_CAF_ANN_PRO_REP]...';

ALTER TABLE [dbo].[ICS_CAFOMLPW_NUTR_MON] WITH NOCHECK
    ADD CONSTRAINT [FK_CFM_NUT_MON_CAF_ANN_PRO_REP] FOREIGN KEY ([ICS_CAFO_ANNUL_PROG_REP_ID]) REFERENCES [dbo].[ICS_CAFO_ANNUL_PROG_REP] ([ICS_CAFO_ANNUL_PROG_REP_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_CFM_TTL_AMN_CAF_ANN_PRO_REP]...';

ALTER TABLE [dbo].[ICS_CAFOMLPW_TTL_AMOUNTS] WITH NOCHECK
    ADD CONSTRAINT [FK_CFM_TTL_AMN_CAF_ANN_PRO_REP] FOREIGN KEY ([ICS_CAFO_ANNUL_PROG_REP_ID]) REFERENCES [dbo].[ICS_CAFO_ANNUL_PROG_REP] ([ICS_CAFO_ANNUL_PROG_REP_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_CFOMLPW_TTL_AMNTS_CAFO_PRMT]...';

ALTER TABLE [dbo].[ICS_CAFOMLPW_TTL_AMOUNTS] WITH NOCHECK
    ADD CONSTRAINT [FK_CFOMLPW_TTL_AMNTS_CAFO_PRMT] FOREIGN KEY ([ICS_CAFO_PRMT_ID]) REFERENCES [dbo].[ICS_CAFO_PRMT] ([ICS_CAFO_PRMT_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_CMPL_MON_EVT_BS_MGMT_PRCTCE]...';

ALTER TABLE [dbo].[ICS_CMPL_MON_EVT] WITH NOCHECK
    ADD CONSTRAINT [FK_CMPL_MON_EVT_BS_MGMT_PRCTCE] FOREIGN KEY ([ICS_BS_MGMT_PRACTICE_ID]) REFERENCES [dbo].[ICS_BS_MGMT_PRACTICE] ([ICS_BS_MGMT_PRACTICE_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_CNST_SITE_LIST_SW_CNST_PRMT]...';

ALTER TABLE [dbo].[ICS_CNST_SITE_LIST] WITH NOCHECK
    ADD CONSTRAINT [FK_CNST_SITE_LIST_SW_CNST_PRMT] FOREIGN KEY ([ICS_SW_CNST_PRMT_ID]) REFERENCES [dbo].[ICS_SW_CNST_PRMT] ([ICS_SW_CNST_PRMT_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_COLL_SYSTM_PRMT_PAYLOAD]...';

ALTER TABLE [dbo].[ICS_COLL_SYSTM_PRMT] WITH NOCHECK
    ADD CONSTRAINT [FK_COLL_SYSTM_PRMT_PAYLOAD] FOREIGN KEY ([ICS_PAYLOAD_ID]) REFERENCES [dbo].[ICS_PAYLOAD] ([ICS_PAYLOAD_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_CNT_AUT_PRO_INF_PRT_PRO_REP]...';

ALTER TABLE [dbo].[ICS_CONTROL_AUTH_PROG_INFO] WITH NOCHECK
    ADD CONSTRAINT [FK_CNT_AUT_PRO_INF_PRT_PRO_REP] FOREIGN KEY ([ICS_PRETR_PROG_REP_ID]) REFERENCES [dbo].[ICS_PRETR_PROG_REP] ([ICS_PRETR_PROG_REP_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_CL_WT_IN_ST_CM_MT_CL_WT_IN]...';

ALTER TABLE [dbo].[ICS_COOLING_WTR_INTAKE_STRCT_CMPL_METHOD] WITH NOCHECK
    ADD CONSTRAINT [FK_CL_WT_IN_ST_CM_MT_CL_WT_IN] FOREIGN KEY ([ICS_COOLING_WTR_INTAKE_STRCT_INFO_ID]) REFERENCES [dbo].[ICS_COOLING_WTR_INTAKE_STRCT_INFO] ([ICS_COOLING_WTR_INTAKE_STRCT_INFO_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_CLN_WTR_INT_STR_INF_PRM_FET]...';

ALTER TABLE [dbo].[ICS_COOLING_WTR_INTAKE_STRCT_INFO] WITH NOCHECK
    ADD CONSTRAINT [FK_CLN_WTR_INT_STR_INF_PRM_FET] FOREIGN KEY ([ICS_PRMT_FEATR_ID]) REFERENCES [dbo].[ICS_PRMT_FEATR] ([ICS_PRMT_FEATR_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_COPY_MGPMS_4_REQ_PAYLOAD]...';

ALTER TABLE [dbo].[ICS_COPY_MGPMS_4_REQ] WITH NOCHECK
    ADD CONSTRAINT [FK_COPY_MGPMS_4_REQ_PAYLOAD] FOREIGN KEY ([ICS_PAYLOAD_ID]) REFERENCES [dbo].[ICS_PAYLOAD] ([ICS_PAYLOAD_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_CSO_CN_ME_DT_CS_LO_TE_CN_PL]...';

ALTER TABLE [dbo].[ICS_CSO_CONTROL_MEAS_DETAIL] WITH NOCHECK
    ADD CONSTRAINT [FK_CSO_CN_ME_DT_CS_LO_TE_CN_PL] FOREIGN KEY ([ICS_CSO_LONG_TERM_CONTROL_PLAN_ID]) REFERENCES [dbo].[ICS_CSO_LONG_TERM_CONTROL_PLAN] ([ICS_CSO_LONG_TERM_CONTROL_PLAN_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_CSO_LONG_TERM_CNTR_PLAN_PYL]...';

ALTER TABLE [dbo].[ICS_CSO_LONG_TERM_CONTROL_PLAN] WITH NOCHECK
    ADD CONSTRAINT [FK_CSO_LONG_TERM_CNTR_PLAN_PYL] FOREIGN KEY ([ICS_PAYLOAD_ID]) REFERENCES [dbo].[ICS_PAYLOAD] ([ICS_PAYLOAD_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_CWA_316B_PROG_REP_PAYLOAD]...';

ALTER TABLE [dbo].[ICS_CWA_316B_PROG_REP] WITH NOCHECK
    ADD CONSTRAINT [FK_CWA_316B_PROG_REP_PAYLOAD] FOREIGN KEY ([ICS_PAYLOAD_ID]) REFERENCES [dbo].[ICS_PAYLOAD] ([ICS_PAYLOAD_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_CWA_316_TAK_INF_CW_31_PR_RE]...';

ALTER TABLE [dbo].[ICS_CWA_316B_TAKE_INFO] WITH NOCHECK
    ADD CONSTRAINT [FK_CWA_316_TAK_INF_CW_31_PR_RE] FOREIGN KEY ([ICS_CWA_316B_PROG_REP_ID]) REFERENCES [dbo].[ICS_CWA_316B_PROG_REP] ([ICS_CWA_316B_PROG_REP_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_GN_PR_CV_MS_4_RE_CO_MG_4_RE]...';

ALTER TABLE [dbo].[ICS_GNRL_PRMT_COVERAGE_MS_4_REQ] WITH NOCHECK
    ADD CONSTRAINT [FK_GN_PR_CV_MS_4_RE_CO_MG_4_RE] FOREIGN KEY ([ICS_COPY_MGPMS_4_REQ_ID]) REFERENCES [dbo].[ICS_COPY_MGPMS_4_REQ] ([ICS_COPY_MGPMS_4_REQ_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_INDS_USR_INFO_INDS_USR_INVN]...';

ALTER TABLE [dbo].[ICS_INDST_USR_INFO] WITH NOCHECK
    ADD CONSTRAINT [FK_INDS_USR_INFO_INDS_USR_INVN] FOREIGN KEY ([ICS_INDST_USR_INVENTORY_ID]) REFERENCES [dbo].[ICS_INDST_USR_INVENTORY] ([ICS_INDST_USR_INVENTORY_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_INDS_USR_INVN_PRTR_PROG_REP]...';

ALTER TABLE [dbo].[ICS_INDST_USR_INVENTORY] WITH NOCHECK
    ADD CONSTRAINT [FK_INDS_USR_INVN_PRTR_PROG_REP] FOREIGN KEY ([ICS_PRETR_PROG_REP_ID]) REFERENCES [dbo].[ICS_PRETR_PROG_REP] ([ICS_PRETR_PROG_REP_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_INSP_CMNT_TXT_CMPL_MON]...';

ALTER TABLE [dbo].[ICS_INSP_CMNT_TXT] WITH NOCHECK
    ADD CONSTRAINT [FK_INSP_CMNT_TXT_CMPL_MON] FOREIGN KEY ([ICS_CMPL_MON_ID]) REFERENCES [dbo].[ICS_CMPL_MON] ([ICS_CMPL_MON_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_INSP_V_CONTACT_CMPL_MON]...';

ALTER TABLE [dbo].[ICS_INSP_V_CONTACT] WITH NOCHECK
    ADD CONSTRAINT [FK_INSP_V_CONTACT_CMPL_MON] FOREIGN KEY ([ICS_CMPL_MON_ID]) REFERENCES [dbo].[ICS_CMPL_MON] ([ICS_CMPL_MON_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_IU_ENF_ACT_TYP_IU_ENF_AC_IN]...';

ALTER TABLE [dbo].[ICS_IU_ENF_ACTN_TYPES] WITH NOCHECK
    ADD CONSTRAINT [FK_IU_ENF_ACT_TYP_IU_ENF_AC_IN] FOREIGN KEY ([ICS_IU_ENFRC_ACTN_INFO_ID]) REFERENCES [dbo].[ICS_IU_ENFRC_ACTN_INFO] ([ICS_IU_ENFRC_ACTN_INFO_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_IU_ENFR_ACT_INF_IND_USR_INF]...';

ALTER TABLE [dbo].[ICS_IU_ENFRC_ACTN_INFO] WITH NOCHECK
    ADD CONSTRAINT [FK_IU_ENFR_ACT_INF_IND_USR_INF] FOREIGN KEY ([ICS_INDST_USR_INFO_ID]) REFERENCES [dbo].[ICS_INDST_USR_INFO] ([ICS_INDST_USR_INFO_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_IU_VIOL_INFO_INDST_USR_INFO]...';

ALTER TABLE [dbo].[ICS_IU_VIOL_INFO] WITH NOCHECK
    ADD CONSTRAINT [FK_IU_VIOL_INFO_INDST_USR_INFO] FOREIGN KEY ([ICS_INDST_USR_INFO_ID]) REFERENCES [dbo].[ICS_INDST_USR_INFO] ([ICS_INDST_USR_INFO_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_LNK_CMPL_MON_CMPL_MON_LNK]...';

ALTER TABLE [dbo].[ICS_LNK_CMPL_MON] WITH NOCHECK
    ADD CONSTRAINT [FK_LNK_CMPL_MON_CMPL_MON_LNK] FOREIGN KEY ([ICS_CMPL_MON_LNK_ID]) REFERENCES [dbo].[ICS_CMPL_MON_LNK] ([ICS_CMPL_MON_LNK_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_LOC_LMT_PRM_CNT_AUT_PRO_INF]...';

ALTER TABLE [dbo].[ICS_LOC_LMTS_PARAMETERS] WITH NOCHECK
    ADD CONSTRAINT [FK_LOC_LMT_PRM_CNT_AUT_PRO_INF] FOREIGN KEY ([ICS_CONTROL_AUTH_PROG_INFO_ID]) REFERENCES [dbo].[ICS_CONTROL_AUTH_PROG_INFO] ([ICS_CONTROL_AUTH_PROG_INFO_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_LTC_EN_ME_DT_CS_LO_TE_CN_PL]...';

ALTER TABLE [dbo].[ICS_LTCP_ENFORCEABLE_MECH_DETAIL] WITH NOCHECK
    ADD CONSTRAINT [FK_LTC_EN_ME_DT_CS_LO_TE_CN_PL] FOREIGN KEY ([ICS_CSO_LONG_TERM_CONTROL_PLAN_ID]) REFERENCES [dbo].[ICS_CSO_LONG_TERM_CONTROL_PLAN] ([ICS_CSO_LONG_TERM_CONTROL_PLAN_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_LT_MO_RC_RV_DT_CS_LO_TE_CN]...';

ALTER TABLE [dbo].[ICS_LTCP_MOST_RECENT_REVISION_DETAIL] WITH NOCHECK
    ADD CONSTRAINT [FK_LT_MO_RC_RV_DT_CS_LO_TE_CN] FOREIGN KEY ([ICS_CSO_LONG_TERM_CONTROL_PLAN_ID]) REFERENCES [dbo].[ICS_CSO_LONG_TERM_CONTROL_PLAN] ([ICS_CSO_LONG_TERM_CONTROL_PLAN_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_LTC_SUM_CSO_LON_TER_CNT_PLA]...';

ALTER TABLE [dbo].[ICS_LTCP_SUMM] WITH NOCHECK
    ADD CONSTRAINT [FK_LTC_SUM_CSO_LON_TER_CNT_PLA] FOREIGN KEY ([ICS_CSO_LONG_TERM_CONTROL_PLAN_ID]) REFERENCES [dbo].[ICS_CSO_LONG_TERM_CONTROL_PLAN] ([ICS_CSO_LONG_TERM_CONTROL_PLAN_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_MS_4_ACTY_IDN_COP_MGP_4_REQ]...';

ALTER TABLE [dbo].[ICS_MS_4_ACTY_IDENT] WITH NOCHECK
    ADD CONSTRAINT [FK_MS_4_ACTY_IDN_COP_MGP_4_REQ] FOREIGN KEY ([ICS_COPY_MGPMS_4_REQ_ID]) REFERENCES [dbo].[ICS_COPY_MGPMS_4_REQ] ([ICS_COPY_MGPMS_4_REQ_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_MS_4_CN_SW_PR_MS_4_CN_SW_RE]...';

ALTER TABLE [dbo].[ICS_MS_4_CNST_SW_PROCEDURES] WITH NOCHECK
    ADD CONSTRAINT [FK_MS_4_CN_SW_PR_MS_4_CN_SW_RE] FOREIGN KEY ([ICS_MS_4_CNST_SW_REQS_ID]) REFERENCES [dbo].[ICS_MS_4_CNST_SW_REQS] ([ICS_MS_4_CNST_SW_REQS_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_MS_4_CN_SW_RG_EN_IN_MS_4_CN]...';

ALTER TABLE [dbo].[ICS_MS_4_CNST_SW_REGULATED_ENTITY_INFO] WITH NOCHECK
    ADD CONSTRAINT [FK_MS_4_CN_SW_RG_EN_IN_MS_4_CN] FOREIGN KEY ([ICS_MS_4_CNST_SW_REQS_ID]) REFERENCES [dbo].[ICS_MS_4_CNST_SW_REQS] ([ICS_MS_4_CNST_SW_REQS_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_MS_4_CNST_SW_REQS_SWM_4_PRM]...';

ALTER TABLE [dbo].[ICS_MS_4_CNST_SW_REQS] WITH NOCHECK
    ADD CONSTRAINT [FK_MS_4_CNST_SW_REQS_SWM_4_PRM] FOREIGN KEY ([ICS_SWMS_4_PRMT_ID]) REFERENCES [dbo].[ICS_SWMS_4_PRMT] ([ICS_SWMS_4_PRMT_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_MS_4_IL_DT_PR_MS_4_IL_DT_RE]...';

ALTER TABLE [dbo].[ICS_MS_4_ILLICIT_DETECT_PROCEDURES] WITH NOCHECK
    ADD CONSTRAINT [FK_MS_4_IL_DT_PR_MS_4_IL_DT_RE] FOREIGN KEY ([ICS_MS_4_ILLICIT_DETECT_REQS_ID]) REFERENCES [dbo].[ICS_MS_4_ILLICIT_DETECT_REQS] ([ICS_MS_4_ILLICIT_DETECT_REQS_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_MS_4_IL_DT_RG_EN_IN_MS_4_IL]...';

ALTER TABLE [dbo].[ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO] WITH NOCHECK
    ADD CONSTRAINT [FK_MS_4_IL_DT_RG_EN_IN_MS_4_IL] FOREIGN KEY ([ICS_MS_4_ILLICIT_DETECT_REQS_ID]) REFERENCES [dbo].[ICS_MS_4_ILLICIT_DETECT_REQS] ([ICS_MS_4_ILLICIT_DETECT_REQS_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_MS_4_IL_DT_RG_EN_IN_PR_RE_S]...';

ALTER TABLE [dbo].[ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO_PROG_REP] WITH NOCHECK
    ADD CONSTRAINT [FK_MS_4_IL_DT_RG_EN_IN_PR_RE_S] FOREIGN KEY ([ICS_SWMS_4_ANNUL_PROG_REP_ID]) REFERENCES [dbo].[ICS_SWMS_4_ANNUL_PROG_REP] ([ICS_SWMS_4_ANNUL_PROG_REP_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_MS_4_ILLC_DTC_REQ_SWM_4_PRM]...';

ALTER TABLE [dbo].[ICS_MS_4_ILLICIT_DETECT_REQS] WITH NOCHECK
    ADD CONSTRAINT [FK_MS_4_ILLC_DTC_REQ_SWM_4_PRM] FOREIGN KEY ([ICS_SWMS_4_PRMT_ID]) REFERENCES [dbo].[ICS_SWMS_4_PRMT] ([ICS_SWMS_4_PRMT_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_MS_4_IN_SW_PR_MS_4_IN_SW_RE]...';

ALTER TABLE [dbo].[ICS_MS_4_INDST_SW_PROCEDURES] WITH NOCHECK
    ADD CONSTRAINT [FK_MS_4_IN_SW_PR_MS_4_IN_SW_RE] FOREIGN KEY ([ICS_MS_4_INDST_SW_REQS_ID]) REFERENCES [dbo].[ICS_MS_4_INDST_SW_REQS] ([ICS_MS_4_INDST_SW_REQS_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_MS_4_IN_SW_RG_EN_IN_MS_4_IN]...';

ALTER TABLE [dbo].[ICS_MS_4_INDST_SW_REGULATED_ENTITY_INFO] WITH NOCHECK
    ADD CONSTRAINT [FK_MS_4_IN_SW_RG_EN_IN_MS_4_IN] FOREIGN KEY ([ICS_MS_4_INDST_SW_REQS_ID]) REFERENCES [dbo].[ICS_MS_4_INDST_SW_REQS] ([ICS_MS_4_INDST_SW_REQS_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_MS_4_INDS_SW_REQS_SWM_4_PRM]...';

ALTER TABLE [dbo].[ICS_MS_4_INDST_SW_REQS] WITH NOCHECK
    ADD CONSTRAINT [FK_MS_4_INDS_SW_REQS_SWM_4_PRM] FOREIGN KEY ([ICS_SWMS_4_PRMT_ID]) REFERENCES [dbo].[ICS_SWMS_4_PRMT] ([ICS_SWMS_4_PRMT_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_MS_4_OTHR_APP_REQ_SWM_4_PRM]...';

ALTER TABLE [dbo].[ICS_MS_4_OTHR_APPL_REQS] WITH NOCHECK
    ADD CONSTRAINT [FK_MS_4_OTHR_APP_REQ_SWM_4_PRM] FOREIGN KEY ([ICS_SWMS_4_PRMT_ID]) REFERENCES [dbo].[ICS_SWMS_4_PRMT] ([ICS_SWMS_4_PRMT_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_MS_4_PBLC_EDC_REQ_SWM_4_PRM]...';

ALTER TABLE [dbo].[ICS_MS_4_PBLC_EDUCATION_REQS] WITH NOCHECK
    ADD CONSTRAINT [FK_MS_4_PBLC_EDC_REQ_SWM_4_PRM] FOREIGN KEY ([ICS_SWMS_4_PRMT_ID]) REFERENCES [dbo].[ICS_SWMS_4_PRMT] ([ICS_SWMS_4_PRMT_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_MS_4_PBLC_INV_REQ_SWM_4_PRM]...';

ALTER TABLE [dbo].[ICS_MS_4_PBLC_INVOLVEMENT_REQS] WITH NOCHECK
    ADD CONSTRAINT [FK_MS_4_PBLC_INV_REQ_SWM_4_PRM] FOREIGN KEY ([ICS_SWMS_4_PRMT_ID]) REFERENCES [dbo].[ICS_SWMS_4_PRMT] ([ICS_SWMS_4_PRMT_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_MS_4_PLLT_PRV_REQ_SWM_4_PRM]...';

ALTER TABLE [dbo].[ICS_MS_4_POLLUTION_PREVENTION_REQS] WITH NOCHECK
    ADD CONSTRAINT [FK_MS_4_PLLT_PRV_REQ_SWM_4_PRM] FOREIGN KEY ([ICS_SWMS_4_PRMT_ID]) REFERENCES [dbo].[ICS_SWMS_4_PRMT] ([ICS_SWMS_4_PRMT_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_MS_4_PO_CN_SW_PR_MS_4_PO_CN]...';

ALTER TABLE [dbo].[ICS_MS_4_POST_CNST_SW_PROCEDURES] WITH NOCHECK
    ADD CONSTRAINT [FK_MS_4_PO_CN_SW_PR_MS_4_PO_CN] FOREIGN KEY ([ICS_MS_4_POST_CNST_SW_REQS_ID]) REFERENCES [dbo].[ICS_MS_4_POST_CNST_SW_REQS] ([ICS_MS_4_POST_CNST_SW_REQS_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_MS_4_PO_CN_SW_RG_EN_IN_MS_4]...';

ALTER TABLE [dbo].[ICS_MS_4_POST_CNST_SW_REGULATED_ENTITY_INFO] WITH NOCHECK
    ADD CONSTRAINT [FK_MS_4_PO_CN_SW_RG_EN_IN_MS_4] FOREIGN KEY ([ICS_MS_4_POST_CNST_SW_REQS_ID]) REFERENCES [dbo].[ICS_MS_4_POST_CNST_SW_REQS] ([ICS_MS_4_POST_CNST_SW_REQS_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_MS_4_POS_CNS_SW_REQ_SW_4_PR]...';

ALTER TABLE [dbo].[ICS_MS_4_POST_CNST_SW_REQS] WITH NOCHECK
    ADD CONSTRAINT [FK_MS_4_POS_CNS_SW_REQ_SW_4_PR] FOREIGN KEY ([ICS_SWMS_4_PRMT_ID]) REFERENCES [dbo].[ICS_SWMS_4_PRMT] ([ICS_SWMS_4_PRMT_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_MS_4_PR_RE_AN_SW_4_AN_PR_RE]...';

ALTER TABLE [dbo].[ICS_MS_4_PROG_REP_ANALYSIS] WITH NOCHECK
    ADD CONSTRAINT [FK_MS_4_PR_RE_AN_SW_4_AN_PR_RE] FOREIGN KEY ([ICS_SWMS_4_ANNUL_PROG_REP_ID]) REFERENCES [dbo].[ICS_SWMS_4_ANNUL_PROG_REP] ([ICS_SWMS_4_ANNUL_PROG_REP_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_MS_4_PR_RE_RE_RG_EN_SW_4_AN]...';

ALTER TABLE [dbo].[ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY] WITH NOCHECK
    ADD CONSTRAINT [FK_MS_4_PR_RE_RE_RG_EN_SW_4_AN] FOREIGN KEY ([ICS_SWMS_4_ANNUL_PROG_REP_ID]) REFERENCES [dbo].[ICS_SWMS_4_ANNUL_PROG_REP] ([ICS_SWMS_4_ANNUL_PROG_REP_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_MS_4_RGLTD_ENTT_SWMS_4_PRMT]...';

ALTER TABLE [dbo].[ICS_MS_4_REGULATED_ENTITY] WITH NOCHECK
    ADD CONSTRAINT [FK_MS_4_RGLTD_ENTT_SWMS_4_PRMT] FOREIGN KEY ([ICS_SWMS_4_PRMT_ID]) REFERENCES [dbo].[ICS_SWMS_4_PRMT] ([ICS_SWMS_4_PRMT_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_MS_4_RGLT_ENT_ARE_SWM_4_PRM]...';

ALTER TABLE [dbo].[ICS_MS_4_REGULATED_ENTITY_AREA] WITH NOCHECK
    ADD CONSTRAINT [FK_MS_4_RGLT_ENT_ARE_SWM_4_PRM] FOREIGN KEY ([ICS_SWMS_4_PRMT_ID]) REFERENCES [dbo].[ICS_SWMS_4_PRMT] ([ICS_SWMS_4_PRMT_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_MS_4_RG_EN_AR_CO_MS_4_RG_EN]...';

ALTER TABLE [dbo].[ICS_MS_4_REGULATED_ENTITY_AREA_COORD] WITH NOCHECK
    ADD CONSTRAINT [FK_MS_4_RG_EN_AR_CO_MS_4_RG_EN] FOREIGN KEY ([ICS_MS_4_REGULATED_ENTITY_AREA_ID]) REFERENCES [dbo].[ICS_MS_4_REGULATED_ENTITY_AREA] ([ICS_MS_4_REGULATED_ENTITY_AREA_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_MS_4_RG_EN_EN_SW_4_AN_PR_RE]...';

ALTER TABLE [dbo].[ICS_MS_4_REGULATED_ENTITY_ENFRC] WITH NOCHECK
    ADD CONSTRAINT [FK_MS_4_RG_EN_EN_SW_4_AN_PR_RE] FOREIGN KEY ([ICS_SWMS_4_ANNUL_PROG_REP_ID]) REFERENCES [dbo].[ICS_SWMS_4_ANNUL_PROG_REP] ([ICS_SWMS_4_ANNUL_PROG_REP_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_MS_4_RG_EN_EN_AC_MS_4_RG_EN]...';

ALTER TABLE [dbo].[ICS_MS_4_REGULATED_ENTITY_ENFRC_ACTIONS] WITH NOCHECK
    ADD CONSTRAINT [FK_MS_4_RG_EN_EN_AC_MS_4_RG_EN] FOREIGN KEY ([ICS_MS_4_REGULATED_ENTITY_ENFRC_ID]) REFERENCES [dbo].[ICS_MS_4_REGULATED_ENTITY_ENFRC] ([ICS_MS_4_REGULATED_ENTITY_ENFRC_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_MS_4_RG_EN_ID_GN_PR_CV_MS_4]...';

ALTER TABLE [dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT] WITH NOCHECK
    ADD CONSTRAINT [FK_MS_4_RG_EN_ID_GN_PR_CV_MS_4] FOREIGN KEY ([ICS_GNRL_PRMT_COVERAGE_MS_4_REQ_ID]) REFERENCES [dbo].[ICS_GNRL_PRMT_COVERAGE_MS_4_REQ] ([ICS_GNRL_PRMT_COVERAGE_MS_4_REQ_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_MS_4_RG_EN_ID_MS_4_CN_SW_PR]...';

ALTER TABLE [dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT] WITH NOCHECK
    ADD CONSTRAINT [FK_MS_4_RG_EN_ID_MS_4_CN_SW_PR] FOREIGN KEY ([ICS_MS_4_CNST_SW_PROCEDURES_ID]) REFERENCES [dbo].[ICS_MS_4_CNST_SW_PROCEDURES] ([ICS_MS_4_CNST_SW_PROCEDURES_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_MS_4_RG_EN_ID_MS_4_IL_DT_PR]...';

ALTER TABLE [dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT] WITH NOCHECK
    ADD CONSTRAINT [FK_MS_4_RG_EN_ID_MS_4_IL_DT_PR] FOREIGN KEY ([ICS_MS_4_ILLICIT_DETECT_PROCEDURES_ID]) REFERENCES [dbo].[ICS_MS_4_ILLICIT_DETECT_PROCEDURES] ([ICS_MS_4_ILLICIT_DETECT_PROCEDURES_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_MS_4_RG_EN_ID_MS_4_IN_SW_PR]...';

ALTER TABLE [dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT] WITH NOCHECK
    ADD CONSTRAINT [FK_MS_4_RG_EN_ID_MS_4_IN_SW_PR] FOREIGN KEY ([ICS_MS_4_INDST_SW_PROCEDURES_ID]) REFERENCES [dbo].[ICS_MS_4_INDST_SW_PROCEDURES] ([ICS_MS_4_INDST_SW_PROCEDURES_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_MS_4_RG_EN_ID_MS_4_OT_AP_RE]...';

ALTER TABLE [dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT] WITH NOCHECK
    ADD CONSTRAINT [FK_MS_4_RG_EN_ID_MS_4_OT_AP_RE] FOREIGN KEY ([ICS_MS_4_OTHR_APPL_REQS_ID]) REFERENCES [dbo].[ICS_MS_4_OTHR_APPL_REQS] ([ICS_MS_4_OTHR_APPL_REQS_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_MS_4_RG_EN_ID_MS_4_PB_ED_RE]...';

ALTER TABLE [dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT] WITH NOCHECK
    ADD CONSTRAINT [FK_MS_4_RG_EN_ID_MS_4_PB_ED_RE] FOREIGN KEY ([ICS_MS_4_PBLC_EDUCATION_REQS_ID]) REFERENCES [dbo].[ICS_MS_4_PBLC_EDUCATION_REQS] ([ICS_MS_4_PBLC_EDUCATION_REQS_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_MS_4_RG_EN_ID_MS_4_PB_IN_RE]...';

ALTER TABLE [dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT] WITH NOCHECK
    ADD CONSTRAINT [FK_MS_4_RG_EN_ID_MS_4_PB_IN_RE] FOREIGN KEY ([ICS_MS_4_PBLC_INVOLVEMENT_REQS_ID]) REFERENCES [dbo].[ICS_MS_4_PBLC_INVOLVEMENT_REQS] ([ICS_MS_4_PBLC_INVOLVEMENT_REQS_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_MS_4_RG_EN_ID_MS_4_PL_PR_RE]...';

ALTER TABLE [dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT] WITH NOCHECK
    ADD CONSTRAINT [FK_MS_4_RG_EN_ID_MS_4_PL_PR_RE] FOREIGN KEY ([ICS_MS_4_POLLUTION_PREVENTION_REQS_ID]) REFERENCES [dbo].[ICS_MS_4_POLLUTION_PREVENTION_REQS] ([ICS_MS_4_POLLUTION_PREVENTION_REQS_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_MS_4_RG_EN_ID_MS_4_PO_CN_SW]...';

ALTER TABLE [dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT] WITH NOCHECK
    ADD CONSTRAINT [FK_MS_4_RG_EN_ID_MS_4_PO_CN_SW] FOREIGN KEY ([ICS_MS_4_POST_CNST_SW_PROCEDURES_ID]) REFERENCES [dbo].[ICS_MS_4_POST_CNST_SW_PROCEDURES] ([ICS_MS_4_POST_CNST_SW_PROCEDURES_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_MS_4_RG_EN_ID_MS_4_PR_RE_AN]...';

ALTER TABLE [dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT] WITH NOCHECK
    ADD CONSTRAINT [FK_MS_4_RG_EN_ID_MS_4_PR_RE_AN] FOREIGN KEY ([ICS_MS_4_PROG_REP_ANALYSIS_ID]) REFERENCES [dbo].[ICS_MS_4_PROG_REP_ANALYSIS] ([ICS_MS_4_PROG_REP_ANALYSIS_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_MS_4_RG_EN_ID_MS_4_PR_RE_RE]...';

ALTER TABLE [dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT] WITH NOCHECK
    ADD CONSTRAINT [FK_MS_4_RG_EN_ID_MS_4_PR_RE_RE] FOREIGN KEY ([ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY_ID]) REFERENCES [dbo].[ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY] ([ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_MS_4_SWM_CHN_SWM_4_AN_PR_RE]...';

ALTER TABLE [dbo].[ICS_MS_4_SWMP_CHANGES] WITH NOCHECK
    ADD CONSTRAINT [FK_MS_4_SWM_CHN_SWM_4_AN_PR_RE] FOREIGN KEY ([ICS_SWMS_4_ANNUL_PROG_REP_ID]) REFERENCES [dbo].[ICS_SWMS_4_ANNUL_PROG_REP] ([ICS_SWMS_4_ANNUL_PROG_REP_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_NPDES_VARIANCE_PRMT_PAYLOAD]...';

ALTER TABLE [dbo].[ICS_NPDES_VARIANCE_PRMT] WITH NOCHECK
    ADD CONSTRAINT [FK_NPDES_VARIANCE_PRMT_PAYLOAD] FOREIGN KEY ([ICS_PAYLOAD_ID]) REFERENCES [dbo].[ICS_PAYLOAD] ([ICS_PAYLOAD_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_POLUT_LIST_PRMT_FEATR]...';

ALTER TABLE [dbo].[ICS_POLUT_LIST] WITH NOCHECK
    ADD CONSTRAINT [FK_POLUT_LIST_PRMT_FEATR] FOREIGN KEY ([ICS_PRMT_FEATR_ID]) REFERENCES [dbo].[ICS_PRMT_FEATR] ([ICS_PRMT_FEATR_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_POTW_TRTMN_TCHNLG_PRMT_PYLD]...';

ALTER TABLE [dbo].[ICS_POTW_TRTMNT_TECHNOLOGY_PRMT] WITH NOCHECK
    ADD CONSTRAINT [FK_POTW_TRTMN_TCHNLG_PRMT_PYLD] FOREIGN KEY ([ICS_PAYLOAD_ID]) REFERENCES [dbo].[ICS_PAYLOAD] ([ICS_PAYLOAD_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_PRETR_PROG_MOD_PRETR_PRMT]...';

ALTER TABLE [dbo].[ICS_PRETR_PROG_MOD] WITH NOCHECK
    ADD CONSTRAINT [FK_PRETR_PROG_MOD_PRETR_PRMT] FOREIGN KEY ([ICS_PRETR_PRMT_ID]) REFERENCES [dbo].[ICS_PRETR_PRMT] ([ICS_PRETR_PRMT_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_PRETR_PROG_REP_PAYLOAD]...';

ALTER TABLE [dbo].[ICS_PRETR_PROG_REP] WITH NOCHECK
    ADD CONSTRAINT [FK_PRETR_PROG_REP_PAYLOAD] FOREIGN KEY ([ICS_PAYLOAD_ID]) REFERENCES [dbo].[ICS_PAYLOAD] ([ICS_PAYLOAD_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_PRMT_BS_MGMT_PRCTCE_BS_PRMT]...';

ALTER TABLE [dbo].[ICS_PRMT_BS_MGMT_PRACTICE] WITH NOCHECK
    ADD CONSTRAINT [FK_PRMT_BS_MGMT_PRCTCE_BS_PRMT] FOREIGN KEY ([ICS_BS_PRMT_ID]) REFERENCES [dbo].[ICS_BS_PRMT] ([ICS_BS_PRMT_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_PRP_CNS_SW_BM_PS_SW_CNS_PRM]...';

ALTER TABLE [dbo].[ICS_PROPOSED_CNST_SW_BM_PS] WITH NOCHECK
    ADD CONSTRAINT [FK_PRP_CNS_SW_BM_PS_SW_CNS_PRM] FOREIGN KEY ([ICS_SW_CNST_PRMT_ID]) REFERENCES [dbo].[ICS_SW_CNST_PRMT] ([ICS_SW_CNST_PRMT_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_PRP_IND_SW_BM_PS_SW_IND_PRM]...';

ALTER TABLE [dbo].[ICS_PROPOSED_INDST_SW_BM_PS] WITH NOCHECK
    ADD CONSTRAINT [FK_PRP_IND_SW_BM_PS_SW_IND_PRM] FOREIGN KEY ([ICS_SW_INDST_PRMT_ID]) REFERENCES [dbo].[ICS_SW_INDST_PRMT] ([ICS_SW_INDST_PRMT_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_PRP_PO_CN_SW_BM_PS_SW_CN_PR]...';

ALTER TABLE [dbo].[ICS_PROPOSED_POST_CNST_SW_BM_PS] WITH NOCHECK
    ADD CONSTRAINT [FK_PRP_PO_CN_SW_BM_PS_SW_CN_PR] FOREIGN KEY ([ICS_SW_CNST_PRMT_ID]) REFERENCES [dbo].[ICS_SW_CNST_PRMT] ([ICS_SW_CNST_PRMT_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_RSDL_DSGN_DTRM_MSTR_GNR_PRM]...';

ALTER TABLE [dbo].[ICS_RESIDUAL_DESGN_DTRMN] WITH NOCHECK
    ADD CONSTRAINT [FK_RSDL_DSGN_DTRM_MSTR_GNR_PRM] FOREIGN KEY ([ICS_MASTER_GNRL_PRMT_ID]) REFERENCES [dbo].[ICS_MASTER_GNRL_PRMT] ([ICS_MASTER_GNRL_PRMT_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_RSIDUL_DSGN_DTRMN_BSIC_PRMT]...';

ALTER TABLE [dbo].[ICS_RESIDUAL_DESGN_DTRMN] WITH NOCHECK
    ADD CONSTRAINT [FK_RSIDUL_DSGN_DTRMN_BSIC_PRMT] FOREIGN KEY ([ICS_BASIC_PRMT_ID]) REFERENCES [dbo].[ICS_BASIC_PRMT] ([ICS_BASIC_PRMT_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_RSIDUL_DSGN_DTRMN_GNRL_PRMT]...';

ALTER TABLE [dbo].[ICS_RESIDUAL_DESGN_DTRMN] WITH NOCHECK
    ADD CONSTRAINT [FK_RSIDUL_DSGN_DTRMN_GNRL_PRMT] FOREIGN KEY ([ICS_GNRL_PRMT_ID]) REFERENCES [dbo].[ICS_GNRL_PRMT] ([ICS_GNRL_PRMT_ID]);

PRINT N'Creating Foreign Key [dbo].[FK_SEW_OV_BY_CU_SE_OV_BY_RE_EV]...';

ALTER TABLE [dbo].[ICS_SEWER_OVRFLW_BYPASS_CAUSE] WITH NOCHECK
    ADD CONSTRAINT [FK_SEW_OV_BY_CU_SE_OV_BY_RE_EV] FOREIGN KEY ([ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID]) REFERENCES [dbo].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT] ([ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_SE_OV_BY_CO_AC_SE_OV_BY_RE]...';

ALTER TABLE [dbo].[ICS_SEWER_OVRFLW_BYPASS_CORR_ACTN] WITH NOCHECK
    ADD CONSTRAINT [FK_SE_OV_BY_CO_AC_SE_OV_BY_RE] FOREIGN KEY ([ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID]) REFERENCES [dbo].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT] ([ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_SEWR_OVRF_BYPS_EVT_REP_PYLD]...';

ALTER TABLE [dbo].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP] WITH NOCHECK
    ADD CONSTRAINT [FK_SEWR_OVRF_BYPS_EVT_REP_PYLD] FOREIGN KEY ([ICS_PAYLOAD_ID]) REFERENCES [dbo].[ICS_PAYLOAD] ([ICS_PAYLOAD_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_SEW_OV_BY_IM_SE_OV_BY_RE_EV]...';

ALTER TABLE [dbo].[ICS_SEWER_OVRFLW_BYPASS_IMPACT] WITH NOCHECK
    ADD CONSTRAINT [FK_SEW_OV_BY_IM_SE_OV_BY_RE_EV] FOREIGN KEY ([ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID]) REFERENCES [dbo].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT] ([ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_SE_OV_BY_RC_WT_SE_OV_BY_RE]...';

ALTER TABLE [dbo].[ICS_SEWER_OVRFLW_BYPASS_RCVG_WTR] WITH NOCHECK
    ADD CONSTRAINT [FK_SE_OV_BY_RC_WT_SE_OV_BY_RE] FOREIGN KEY ([ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID]) REFERENCES [dbo].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT] ([ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_SE_OV_BY_RE_EV_SE_OV_BY_EV]...';

ALTER TABLE [dbo].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT] WITH NOCHECK
    ADD CONSTRAINT [FK_SE_OV_BY_RE_EV_SE_OV_BY_EV] FOREIGN KEY ([ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID]) REFERENCES [dbo].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP] ([ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_SEW_OV_BY_TY_SE_OV_BY_RE_EV]...';

ALTER TABLE [dbo].[ICS_SEWER_OVRFLW_BYPASS_TYPE] WITH NOCHECK
    ADD CONSTRAINT [FK_SEW_OV_BY_TY_SE_OV_BY_RE_EV] FOREIGN KEY ([ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID]) REFERENCES [dbo].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT] ([ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_SEW_OVR_TRT_SEW_OV_BY_RE_EV]...';

ALTER TABLE [dbo].[ICS_SEWER_OVRFLW_TRTMNT] WITH NOCHECK
    ADD CONSTRAINT [FK_SEW_OVR_TRT_SEW_OV_BY_RE_EV] FOREIGN KEY ([ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID]) REFERENCES [dbo].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT] ([ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_SIU_DESGN_TYPE_BASIC_PRMT]...';

ALTER TABLE [dbo].[ICS_SIU_DESGN_TYPE] WITH NOCHECK
    ADD CONSTRAINT [FK_SIU_DESGN_TYPE_BASIC_PRMT] FOREIGN KEY ([ICS_BASIC_PRMT_ID]) REFERENCES [dbo].[ICS_BASIC_PRMT] ([ICS_BASIC_PRMT_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_SNC_LSTNG_MNTH_IU_VIOL_INFO]...';

ALTER TABLE [dbo].[ICS_SNC_LISTING_MONTHS] WITH NOCHECK
    ADD CONSTRAINT [FK_SNC_LSTNG_MNTH_IU_VIOL_INFO] FOREIGN KEY ([ICS_IU_VIOL_INFO_ID]) REFERENCES [dbo].[ICS_IU_VIOL_INFO] ([ICS_IU_VIOL_INFO_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_SNC_PRT_STN_LMT_PR_IU_VI_IN]...';

ALTER TABLE [dbo].[ICS_SNC_PRETR_STND_LMTS_PARAMETERS] WITH NOCHECK
    ADD CONSTRAINT [FK_SNC_PRT_STN_LMT_PR_IU_VI_IN] FOREIGN KEY ([ICS_IU_VIOL_INFO_ID]) REFERENCES [dbo].[ICS_IU_VIOL_INFO] ([ICS_IU_VIOL_INFO_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_SBS_COD_PLU_DES_GP_NT_OF_IN]...';

ALTER TABLE [dbo].[ICS_SUBSECTOR_CODE_PLUS_DESC] WITH NOCHECK
    ADD CONSTRAINT [FK_SBS_COD_PLU_DES_GP_NT_OF_IN] FOREIGN KEY ([ICS_GPCF_NOTICE_OF_INTENT_ID]) REFERENCES [dbo].[ICS_GPCF_NOTICE_OF_INTENT] ([ICS_GPCF_NOTICE_OF_INTENT_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_SWMS_4_ANNL_PROG_REP_PAYLOD]...';

ALTER TABLE [dbo].[ICS_SWMS_4_ANNUL_PROG_REP] WITH NOCHECK
    ADD CONSTRAINT [FK_SWMS_4_ANNL_PROG_REP_PAYLOD] FOREIGN KEY ([ICS_PAYLOAD_ID]) REFERENCES [dbo].[ICS_PAYLOAD] ([ICS_PAYLOAD_ID]) ON DELETE CASCADE;

PRINT N'Creating Foreign Key [dbo].[FK_SWMS_4_PRMT_PAYLOAD]...';

ALTER TABLE [dbo].[ICS_SWMS_4_PRMT] WITH NOCHECK
    ADD CONSTRAINT [FK_SWMS_4_PRMT_PAYLOAD] FOREIGN KEY ([ICS_PAYLOAD_ID]) REFERENCES [dbo].[ICS_PAYLOAD] ([ICS_PAYLOAD_ID]) ON DELETE CASCADE;

PRINT N'Creating Extended Property [dbo].[ICS_ADDR].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: Address', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_ADDR';

PRINT N'Creating Extended Property [dbo].[ICS_ADDR].[AFFIL_TYPE_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'AffiliationTypeText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_ADDR', @level2type = N'COLUMN', @level2name = N'AFFIL_TYPE_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_ADDR].[ORG_FRML_NAME].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'OrganizationFormalName', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_ADDR', @level2type = N'COLUMN', @level2name = N'ORG_FRML_NAME';

PRINT N'Creating Extended Property [dbo].[ICS_ADDR].[ORG_DUNS_NUM].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'OrganizationDUNSNumber', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_ADDR', @level2type = N'COLUMN', @level2name = N'ORG_DUNS_NUM';

PRINT N'Creating Extended Property [dbo].[ICS_ADDR].[MAILING_ADDR_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MailingAddressText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_ADDR', @level2type = N'COLUMN', @level2name = N'MAILING_ADDR_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_ADDR].[SUPPL_ADDR_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SupplementalAddressText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_ADDR', @level2type = N'COLUMN', @level2name = N'SUPPL_ADDR_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_ADDR].[MAILING_ADDR_CITY_NAME].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MailingAddressCityName', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_ADDR', @level2type = N'COLUMN', @level2name = N'MAILING_ADDR_CITY_NAME';

PRINT N'Creating Extended Property [dbo].[ICS_ADDR].[MAILING_ADDR_ST_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MailingAddressStateCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_ADDR', @level2type = N'COLUMN', @level2name = N'MAILING_ADDR_ST_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_ADDR].[MAILING_ADDR_ZIP_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MailingAddressZipCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_ADDR', @level2type = N'COLUMN', @level2name = N'MAILING_ADDR_ZIP_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_ADDR].[COUNTY_NAME].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CountyName', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_ADDR', @level2type = N'COLUMN', @level2name = N'COUNTY_NAME';

PRINT N'Creating Extended Property [dbo].[ICS_ADDR].[MAILING_ADDR_COUNTRY_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MailingAddressCountryCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_ADDR', @level2type = N'COLUMN', @level2name = N'MAILING_ADDR_COUNTRY_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_ADDR].[DIVISION_NAME].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'DivisionName', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_ADDR', @level2type = N'COLUMN', @level2name = N'DIVISION_NAME';

PRINT N'Creating Extended Property [dbo].[ICS_ADDR].[LOC_PROVINCE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'LocationProvince', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_ADDR', @level2type = N'COLUMN', @level2name = N'LOC_PROVINCE';

PRINT N'Creating Extended Property [dbo].[ICS_ADDR].[ELEC_ADDR_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ElectronicAddressText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_ADDR', @level2type = N'COLUMN', @level2name = N'ELEC_ADDR_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_ADDR].[START_DATE_OF_ADDR_ASSC].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'StartDateOfAddressAssociation', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_ADDR', @level2type = N'COLUMN', @level2name = N'START_DATE_OF_ADDR_ASSC';

PRINT N'Creating Extended Property [dbo].[ICS_ADDR].[END_DATE_OF_ADDR_ASSC].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'EndDateOfAddressAssociation', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_ADDR', @level2type = N'COLUMN', @level2name = N'END_DATE_OF_ADDR_ASSC';

PRINT N'Creating Extended Property [dbo].[ICS_ANML_TYPE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: AnimalType', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_ANML_TYPE';

PRINT N'Creating Extended Property [dbo].[ICS_ANML_TYPE].[ANML_TYPE_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'AnimalTypeCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_ANML_TYPE', @level2type = N'COLUMN', @level2name = N'ANML_TYPE_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_ANML_TYPE].[OTHR_ANML_TYPE_NAME].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'OtherAnimalTypeName', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_ANML_TYPE', @level2type = N'COLUMN', @level2name = N'OTHR_ANML_TYPE_NAME';

PRINT N'Creating Extended Property [dbo].[ICS_ANML_TYPE].[TTL_NUM_EACH_LVSTCK].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TotalNumbersEachLivestock', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_ANML_TYPE', @level2type = N'COLUMN', @level2name = N'TTL_NUM_EACH_LVSTCK';

PRINT N'Creating Extended Property [dbo].[ICS_ANML_TYPE].[OPEN_CONFINEMNT_CNT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'OpenConfinementCount', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_ANML_TYPE', @level2type = N'COLUMN', @level2name = N'OPEN_CONFINEMNT_CNT';

PRINT N'Creating Extended Property [dbo].[ICS_ANML_TYPE].[HOUSD_UNDR_ROOF_CONFINEMNT_CNT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'HousedUnderRoofConfinementCount', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_ANML_TYPE', @level2type = N'COLUMN', @level2name = N'HOUSD_UNDR_ROOF_CONFINEMNT_CNT';

PRINT N'Creating Extended Property [dbo].[ICS_ANML_TYPE].[LIQUID_MNUR_HANDLING_SYSTM].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'LiquidManureHandlingSystem', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_ANML_TYPE', @level2type = N'COLUMN', @level2name = N'LIQUID_MNUR_HANDLING_SYSTM';

PRINT N'Creating Extended Property [dbo].[ICS_BASIC_PRMT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: BasicPermitData', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BASIC_PRMT';

PRINT N'Creating Extended Property [dbo].[ICS_BASIC_PRMT].[SRC_SYSTM_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SourceSystemIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BASIC_PRMT', @level2type = N'COLUMN', @level2name = N'SRC_SYSTM_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_BASIC_PRMT].[TRANSACTION_TYPE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TransactionType', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BASIC_PRMT', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TYPE';

PRINT N'Creating Extended Property [dbo].[ICS_BASIC_PRMT].[TRANSACTION_TIMESTAMP].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TransactionTimestamp', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BASIC_PRMT', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TIMESTAMP';

PRINT N'Creating Extended Property [dbo].[ICS_BASIC_PRMT].[PRMT_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermitIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BASIC_PRMT', @level2type = N'COLUMN', @level2name = N'PRMT_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_BASIC_PRMT].[PRMT_TYPE_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermitTypeCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BASIC_PRMT', @level2type = N'COLUMN', @level2name = N'PRMT_TYPE_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_BASIC_PRMT].[AGNCY_TYPE_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'AgencyTypeCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BASIC_PRMT', @level2type = N'COLUMN', @level2name = N'AGNCY_TYPE_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_BASIC_PRMT].[PRMT_STAT_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermitStatusCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BASIC_PRMT', @level2type = N'COLUMN', @level2name = N'PRMT_STAT_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_BASIC_PRMT].[PRMT_ISSUE_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermitIssueDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BASIC_PRMT', @level2type = N'COLUMN', @level2name = N'PRMT_ISSUE_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_BASIC_PRMT].[PRMT_EFFECTIVE_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermitEffectiveDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BASIC_PRMT', @level2type = N'COLUMN', @level2name = N'PRMT_EFFECTIVE_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_BASIC_PRMT].[PRMT_EXPR_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermitExpirationDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BASIC_PRMT', @level2type = N'COLUMN', @level2name = N'PRMT_EXPR_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_BASIC_PRMT].[REISSU_PRIO_PRMT_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ReissuancePriorityPermitIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BASIC_PRMT', @level2type = N'COLUMN', @level2name = N'REISSU_PRIO_PRMT_IND';

PRINT N'Creating Extended Property [dbo].[ICS_BASIC_PRMT].[BACKLOG_REASON_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'BacklogReasonText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BASIC_PRMT', @level2type = N'COLUMN', @level2name = N'BACKLOG_REASON_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_BASIC_PRMT].[PRMT_ISSUING_ORG_TYPE_NAME].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermitIssuinrganizationTypeName', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BASIC_PRMT', @level2type = N'COLUMN', @level2name = N'PRMT_ISSUING_ORG_TYPE_NAME';

PRINT N'Creating Extended Property [dbo].[ICS_BASIC_PRMT].[PRMT_APPEALED_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermitAppealedIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BASIC_PRMT', @level2type = N'COLUMN', @level2name = N'PRMT_APPEALED_IND';

PRINT N'Creating Extended Property [dbo].[ICS_BASIC_PRMT].[PRMT_USR_DFND_DAT_ELM_1_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermitUserDefinedDataElement1Text', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BASIC_PRMT', @level2type = N'COLUMN', @level2name = N'PRMT_USR_DFND_DAT_ELM_1_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_BASIC_PRMT].[PRMT_USR_DFND_DAT_ELM_2_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermitUserDefinedDataElement2Text', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BASIC_PRMT', @level2type = N'COLUMN', @level2name = N'PRMT_USR_DFND_DAT_ELM_2_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_BASIC_PRMT].[PRMT_USR_DFND_DAT_ELM_3_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermitUserDefinedDataElement3Text', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BASIC_PRMT', @level2type = N'COLUMN', @level2name = N'PRMT_USR_DFND_DAT_ELM_3_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_BASIC_PRMT].[PRMT_USR_DFND_DAT_ELM_4_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermitUserDefinedDataElement4Text', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BASIC_PRMT', @level2type = N'COLUMN', @level2name = N'PRMT_USR_DFND_DAT_ELM_4_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_BASIC_PRMT].[PRMT_USR_DFND_DAT_ELM_5_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermitUserDefinedDataElement5Text', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BASIC_PRMT', @level2type = N'COLUMN', @level2name = N'PRMT_USR_DFND_DAT_ELM_5_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_BASIC_PRMT].[PRMT_CMNTS_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermitCommentsText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BASIC_PRMT', @level2type = N'COLUMN', @level2name = N'PRMT_CMNTS_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_BASIC_PRMT].[MAJOR_MINOR_RATING_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MajorMinorRatingCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BASIC_PRMT', @level2type = N'COLUMN', @level2name = N'MAJOR_MINOR_RATING_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_BASIC_PRMT].[TTL_APPL_DSGN_FLOW_NUM].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TotalApplicationDesignFlowNumber', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BASIC_PRMT', @level2type = N'COLUMN', @level2name = N'TTL_APPL_DSGN_FLOW_NUM';

PRINT N'Creating Extended Property [dbo].[ICS_BASIC_PRMT].[TTL_APPL_AVER_FLOW_NUM].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TotalApplicationAverageFlowNumber', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BASIC_PRMT', @level2type = N'COLUMN', @level2name = N'TTL_APPL_AVER_FLOW_NUM';

PRINT N'Creating Extended Property [dbo].[ICS_BASIC_PRMT].[APPL_RCVD_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ApplicationReceivedDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BASIC_PRMT', @level2type = N'COLUMN', @level2name = N'APPL_RCVD_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_BASIC_PRMT].[PRMT_APPL_CMPL_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermitApplicationCompletionDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BASIC_PRMT', @level2type = N'COLUMN', @level2name = N'PRMT_APPL_CMPL_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_BASIC_PRMT].[NEW_SRC_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'NewSourceIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BASIC_PRMT', @level2type = N'COLUMN', @level2name = N'NEW_SRC_IND';

PRINT N'Creating Extended Property [dbo].[ICS_BASIC_PRMT].[PRMT_ST_WTR_BODY_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermitStateWaterBodyCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BASIC_PRMT', @level2type = N'COLUMN', @level2name = N'PRMT_ST_WTR_BODY_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_BASIC_PRMT].[PRMT_ST_WTR_BODY_NAME].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermitStateWaterBodyName', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BASIC_PRMT', @level2type = N'COLUMN', @level2name = N'PRMT_ST_WTR_BODY_NAME';

PRINT N'Creating Extended Property [dbo].[ICS_BASIC_PRMT].[FEDR_GRANT_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'FederalGrantIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BASIC_PRMT', @level2type = N'COLUMN', @level2name = N'FEDR_GRANT_IND';

PRINT N'Creating Extended Property [dbo].[ICS_BASIC_PRMT].[DMR_COGNZNT_OFCL].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'DMRCognizantOfficial', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BASIC_PRMT', @level2type = N'COLUMN', @level2name = N'DMR_COGNZNT_OFCL';

PRINT N'Creating Extended Property [dbo].[ICS_BASIC_PRMT].[DMR_COGNZNT_OFCL_TELEPH_NUM].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'DMRCognizantOfficialTelephoneNumber', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BASIC_PRMT', @level2type = N'COLUMN', @level2name = N'DMR_COGNZNT_OFCL_TELEPH_NUM';

PRINT N'Creating Extended Property [dbo].[ICS_BASIC_PRMT].[SIG_IU_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SignificantIUIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BASIC_PRMT', @level2type = N'COLUMN', @level2name = N'SIG_IU_IND';

PRINT N'Creating Extended Property [dbo].[ICS_BASIC_PRMT].[RCVG_PRMT_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ReceivingPermitIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BASIC_PRMT', @level2type = N'COLUMN', @level2name = N'RCVG_PRMT_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_BASIC_PRMT].[INDST_USR_TYPE_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'IndustrialUserTypeCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BASIC_PRMT', @level2type = N'COLUMN', @level2name = N'INDST_USR_TYPE_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_BASIC_PRMT].[ELEC_REP_WAIVER_TYPE_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ElectronicReportingWaiverTypeCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BASIC_PRMT', @level2type = N'COLUMN', @level2name = N'ELEC_REP_WAIVER_TYPE_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_BASIC_PRMT].[ELEC_REP_WAIVER_EFFECTIVE_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ElectronicReportingWaiverEffectiveDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BASIC_PRMT', @level2type = N'COLUMN', @level2name = N'ELEC_REP_WAIVER_EFFECTIVE_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_BASIC_PRMT].[ELEC_REP_WAIVER_EXPR_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ElectronicReportingWaiverExpirationDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BASIC_PRMT', @level2type = N'COLUMN', @level2name = N'ELEC_REP_WAIVER_EXPR_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_BASIC_PRMT].[MAJOR_MINOR_STAT_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MajorMinorStatusIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BASIC_PRMT', @level2type = N'COLUMN', @level2name = N'MAJOR_MINOR_STAT_IND';

PRINT N'Creating Extended Property [dbo].[ICS_BASIC_PRMT].[MAJOR_MINOR_STAT_START_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MajorMinorStatusStartDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BASIC_PRMT', @level2type = N'COLUMN', @level2name = N'MAJOR_MINOR_STAT_START_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_BASIC_PRMT].[DMR_NON_RCPT_STAT_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'DMRNonReceiptStatusIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BASIC_PRMT', @level2type = N'COLUMN', @level2name = N'DMR_NON_RCPT_STAT_IND';

PRINT N'Creating Extended Property [dbo].[ICS_BASIC_PRMT].[DMR_NON_RCPT_STAT_START_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'DMRNonReceiptStatusStartDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BASIC_PRMT', @level2type = N'COLUMN', @level2name = N'DMR_NON_RCPT_STAT_START_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_BS_ANNUL_PROG_REP].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: BiosolidsAnnualProgramReportData', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_ANNUL_PROG_REP';

PRINT N'Creating Extended Property [dbo].[ICS_BS_ANNUL_PROG_REP].[SRC_SYSTM_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SourceSystemIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_ANNUL_PROG_REP', @level2type = N'COLUMN', @level2name = N'SRC_SYSTM_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_BS_ANNUL_PROG_REP].[TRANSACTION_TYPE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TransactionType', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_ANNUL_PROG_REP', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TYPE';

PRINT N'Creating Extended Property [dbo].[ICS_BS_ANNUL_PROG_REP].[TRANSACTION_TIMESTAMP].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TransactionTimestamp', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_ANNUL_PROG_REP', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TIMESTAMP';

PRINT N'Creating Extended Property [dbo].[ICS_BS_ANNUL_PROG_REP].[PRMT_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermitIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_ANNUL_PROG_REP', @level2type = N'COLUMN', @level2name = N'PRMT_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_BS_ANNUL_PROG_REP].[PROG_REP_FORM_SET_ID].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ProgramReportFormSetID', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_ANNUL_PROG_REP', @level2type = N'COLUMN', @level2name = N'PROG_REP_FORM_SET_ID';

PRINT N'Creating Extended Property [dbo].[ICS_BS_ANNUL_PROG_REP].[PROG_REP_FORM_ID].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ProgramReportFormID', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_ANNUL_PROG_REP', @level2type = N'COLUMN', @level2name = N'PROG_REP_FORM_ID';

PRINT N'Creating Extended Property [dbo].[ICS_BS_ANNUL_PROG_REP].[PROG_REP_RCVD_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ProgramReportReceivedDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_ANNUL_PROG_REP', @level2type = N'COLUMN', @level2name = N'PROG_REP_RCVD_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_BS_ANNUL_PROG_REP].[PROG_REP_START_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ProgramReportStartDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_ANNUL_PROG_REP', @level2type = N'COLUMN', @level2name = N'PROG_REP_START_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_BS_ANNUL_PROG_REP].[PROG_REP_END_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ProgramReportEndDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_ANNUL_PROG_REP', @level2type = N'COLUMN', @level2name = N'PROG_REP_END_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_BS_ANNUL_PROG_REP].[ELEC_SUBM_TYPE_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ElectronicSubmissionTypeCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_ANNUL_PROG_REP', @level2type = N'COLUMN', @level2name = N'ELEC_SUBM_TYPE_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_BS_ANNUL_PROG_REP].[PROG_REP_NPDES_DAT_GRP_NUM_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ProgramReportNPDESDataGroupNumberCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_ANNUL_PROG_REP', @level2type = N'COLUMN', @level2name = N'PROG_REP_NPDES_DAT_GRP_NUM_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_BS_ANNUL_PROG_REP].[BS_FAC_TYPE_OTHR_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'BiosolidsFacilityTypeOtherText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_ANNUL_PROG_REP', @level2type = N'COLUMN', @level2name = N'BS_FAC_TYPE_OTHR_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_BS_ANNUL_PROG_REP].[BS_FAC_TTL_VOL_AMT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'BiosolidsFacilityTotalVolumeAmount', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_ANNUL_PROG_REP', @level2type = N'COLUMN', @level2name = N'BS_FAC_TTL_VOL_AMT';

PRINT N'Creating Extended Property [dbo].[ICS_BS_ANNUL_PROG_REP].[BS_FAC_TRTMNT_OTHR_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'BiosolidsFacilityTreatmentOtherText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_ANNUL_PROG_REP', @level2type = N'COLUMN', @level2name = N'BS_FAC_TRTMNT_OTHR_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_BS_ANNUL_PROG_REP].[BS_ANNUL_PROG_REP_CMNT_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'BiosolidsAnnualProgramReportCommentText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_ANNUL_PROG_REP', @level2type = N'COLUMN', @level2name = N'BS_ANNUL_PROG_REP_CMNT_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_BS_PRMT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: BiosolidsPermitData', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_PRMT';

PRINT N'Creating Extended Property [dbo].[ICS_BS_PRMT].[SRC_SYSTM_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SourceSystemIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_PRMT', @level2type = N'COLUMN', @level2name = N'SRC_SYSTM_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_BS_PRMT].[TRANSACTION_TYPE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TransactionType', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_PRMT', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TYPE';

PRINT N'Creating Extended Property [dbo].[ICS_BS_PRMT].[TRANSACTION_TIMESTAMP].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TransactionTimestamp', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_PRMT', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TIMESTAMP';

PRINT N'Creating Extended Property [dbo].[ICS_BS_PRMT].[PRMT_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermitIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_PRMT', @level2type = N'COLUMN', @level2name = N'PRMT_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_BS_PRMT].[BS_FAC_TYPE_OTHR_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'BiosolidsFacilityTypeOtherText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_PRMT', @level2type = N'COLUMN', @level2name = N'BS_FAC_TYPE_OTHR_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_BS_PRMT].[BS_FAC_TTL_VOL_AMT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'BiosolidsFacilityTotalVolumeAmount', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_PRMT', @level2type = N'COLUMN', @level2name = N'BS_FAC_TTL_VOL_AMT';

PRINT N'Creating Extended Property [dbo].[ICS_BS_PRMT].[BS_FAC_TRTMNT_OTHR_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'BiosolidsFacilityTreatmentOtherText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_PRMT', @level2type = N'COLUMN', @level2name = N'BS_FAC_TRTMNT_OTHR_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_CAFO_INSP].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: CAFOInspection', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_INSP';

PRINT N'Creating Extended Property [dbo].[ICS_CAFO_INSP].[CAFO_CLASS_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CAFOClassificationCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_INSP', @level2type = N'COLUMN', @level2name = N'CAFO_CLASS_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_CAFO_INSP].[IS_ANML_FAC_TYPE_CAFO_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'IsAnimalFacilityTypeCAFOIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_INSP', @level2type = N'COLUMN', @level2name = N'IS_ANML_FAC_TYPE_CAFO_IND';

PRINT N'Creating Extended Property [dbo].[ICS_CAFO_INSP].[CAFO_DESGN_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CAFODesignationDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_INSP', @level2type = N'COLUMN', @level2name = N'CAFO_DESGN_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_CAFO_INSP].[CAFO_DESGN_REASON_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CAFODesignationReasonText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_INSP', @level2type = N'COLUMN', @level2name = N'CAFO_DESGN_REASON_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_CAFO_INSP].[DSCH_DRNG_YEAR_PROD_AREA_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'DischargesDuringYearProductionAreaIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_INSP', @level2type = N'COLUMN', @level2name = N'DSCH_DRNG_YEAR_PROD_AREA_IND';

PRINT N'Creating Extended Property [dbo].[ICS_CAFO_INSP].[DSCH_DRNG_YEAR_LAND_APPL_AREA_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'DischargesDuringYearLandApplicationAreaIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_INSP', @level2type = N'COLUMN', @level2name = N'DSCH_DRNG_YEAR_LAND_APPL_AREA_IND';

PRINT N'Creating Extended Property [dbo].[ICS_CAFO_INSP].[CAFO_DSCH_DRNG_YEAR_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CAFODischargesDuringYearText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_INSP', @level2type = N'COLUMN', @level2name = N'CAFO_DSCH_DRNG_YEAR_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_CAFO_INSP].[NUM_ACRES_CONTRB_DRAIN].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'NumberAcresContributingDrainage', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_INSP', @level2type = N'COLUMN', @level2name = N'NUM_ACRES_CONTRB_DRAIN';

PRINT N'Creating Extended Property [dbo].[ICS_CAFO_INSP].[APPL_MEAS_AVAIL_LAND_NUM].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ApplicationMeasureAvailableLandNumber', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_INSP', @level2type = N'COLUMN', @level2name = N'APPL_MEAS_AVAIL_LAND_NUM';

PRINT N'Creating Extended Property [dbo].[ICS_CAFO_INSP].[SOLID_MNUR_LTTR_GNRTD_AMT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SolidManureLitterGeneratedAmount', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_INSP', @level2type = N'COLUMN', @level2name = N'SOLID_MNUR_LTTR_GNRTD_AMT';

PRINT N'Creating Extended Property [dbo].[ICS_CAFO_INSP].[LIQUID_MNUR_WW_GNRTD_AMT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'LiquidManureWastewaterGeneratedAmount', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_INSP', @level2type = N'COLUMN', @level2name = N'LIQUID_MNUR_WW_GNRTD_AMT';

PRINT N'Creating Extended Property [dbo].[ICS_CAFO_INSP].[SOLID_MNUR_LTTR_TRANS_AMT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SolidManureLitterTransferAmount', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_INSP', @level2type = N'COLUMN', @level2name = N'SOLID_MNUR_LTTR_TRANS_AMT';

PRINT N'Creating Extended Property [dbo].[ICS_CAFO_INSP].[LIQUID_MNUR_WW_TRANS_AMT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'LiquidManureWastewaterTransferAmount', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_INSP', @level2type = N'COLUMN', @level2name = N'LIQUID_MNUR_WW_TRANS_AMT';

PRINT N'Creating Extended Property [dbo].[ICS_CAFO_INSP].[NMP_DVLPD_CERT_PLNR_APRVD_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'NMPDevelopedCertifiedPlannerApprovedIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_INSP', @level2type = N'COLUMN', @level2name = N'NMP_DVLPD_CERT_PLNR_APRVD_IND';

PRINT N'Creating Extended Property [dbo].[ICS_CAFO_INSP].[NMP_DVLPD_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'NMPDevelopedDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_INSP', @level2type = N'COLUMN', @level2name = N'NMP_DVLPD_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_CAFO_INSP].[NMP_LAST_UPDATED_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'NMPLastUpdatedDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_INSP', @level2type = N'COLUMN', @level2name = N'NMP_LAST_UPDATED_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_CAFO_INSP].[ENVR_MGMT_SYSTM_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'EnvironmentalManagementSystemIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_INSP', @level2type = N'COLUMN', @level2name = N'ENVR_MGMT_SYSTM_IND';

PRINT N'Creating Extended Property [dbo].[ICS_CAFO_INSP].[EMS_DVLPD_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'EMSDevelopedDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_INSP', @level2type = N'COLUMN', @level2name = N'EMS_DVLPD_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_CAFO_INSP].[EMS_LAST_UPDATED_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'EMSLastUpdatedDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_INSP', @level2type = N'COLUMN', @level2name = N'EMS_LAST_UPDATED_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_CAFO_INSP].[LVSTCK_MAX_CPCTY_NUM].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'LivestockMaximumCapacityNumber', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_INSP', @level2type = N'COLUMN', @level2name = N'LVSTCK_MAX_CPCTY_NUM';

PRINT N'Creating Extended Property [dbo].[ICS_CAFO_INSP].[LVSTCK_CPCTY_DTRMN_BS_UPON_NUM].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'LivestockCapacityDeterminationBasedUponNumber', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_INSP', @level2type = N'COLUMN', @level2name = N'LVSTCK_CPCTY_DTRMN_BS_UPON_NUM';

PRINT N'Creating Extended Property [dbo].[ICS_CAFO_INSP].[AUTH_LVSTCK_CPCTY_NUM].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'AuthorizedLivestockCapacityNumber', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_INSP', @level2type = N'COLUMN', @level2name = N'AUTH_LVSTCK_CPCTY_NUM';

PRINT N'Creating Extended Property [dbo].[ICS_CNST_SITE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: String', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CNST_SITE';

PRINT N'Creating Extended Property [dbo].[ICS_CNST_SITE].[CNST_SITE_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ConstructionSiteCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CNST_SITE', @level2type = N'COLUMN', @level2name = N'CNST_SITE_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_CONTACT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: Contact', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CONTACT';

PRINT N'Creating Extended Property [dbo].[ICS_CONTACT].[AFFIL_TYPE_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'AffiliationTypeText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CONTACT', @level2type = N'COLUMN', @level2name = N'AFFIL_TYPE_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_CONTACT].[FIRST_NAME].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'FirstName', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CONTACT', @level2type = N'COLUMN', @level2name = N'FIRST_NAME';

PRINT N'Creating Extended Property [dbo].[ICS_CONTACT].[MIDDLE_NAME].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MiddleName', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CONTACT', @level2type = N'COLUMN', @level2name = N'MIDDLE_NAME';

PRINT N'Creating Extended Property [dbo].[ICS_CONTACT].[LAST_NAME].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'LastName', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CONTACT', @level2type = N'COLUMN', @level2name = N'LAST_NAME';

PRINT N'Creating Extended Property [dbo].[ICS_CONTACT].[INDVL_TITLE_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'IndividualTitleText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CONTACT', @level2type = N'COLUMN', @level2name = N'INDVL_TITLE_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_CONTACT].[ORG_FRML_NAME].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'OrganizationFormalName', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CONTACT', @level2type = N'COLUMN', @level2name = N'ORG_FRML_NAME';

PRINT N'Creating Extended Property [dbo].[ICS_CONTACT].[ST_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'StateCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CONTACT', @level2type = N'COLUMN', @level2name = N'ST_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_CONTACT].[RGN_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'RegionCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CONTACT', @level2type = N'COLUMN', @level2name = N'RGN_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_CONTACT].[ELEC_ADDR_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ElectronicAddressText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CONTACT', @level2type = N'COLUMN', @level2name = N'ELEC_ADDR_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_CONTACT].[START_DATE_OF_CONTACT_ASSC].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'StartDateOfContactAssociation', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CONTACT', @level2type = N'COLUMN', @level2name = N'START_DATE_OF_CONTACT_ASSC';

PRINT N'Creating Extended Property [dbo].[ICS_CONTACT].[END_DATE_OF_CONTACT_ASSC].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'EndDateOfContactAssociation', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CONTACT', @level2type = N'COLUMN', @level2name = N'END_DATE_OF_CONTACT_ASSC';

PRINT N'Creating Extended Property [dbo].[ICS_COPY_MGP_LMT_SET].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: CopyMGPLimitSetData', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_COPY_MGP_LMT_SET';

PRINT N'Creating Extended Property [dbo].[ICS_COPY_MGP_LMT_SET].[SRC_SYSTM_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SourceSystemIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_COPY_MGP_LMT_SET', @level2type = N'COLUMN', @level2name = N'SRC_SYSTM_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_COPY_MGP_LMT_SET].[TRANSACTION_TYPE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TransactionType', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_COPY_MGP_LMT_SET', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TYPE';

PRINT N'Creating Extended Property [dbo].[ICS_COPY_MGP_LMT_SET].[TRANSACTION_TIMESTAMP].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TransactionTimestamp', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_COPY_MGP_LMT_SET', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TIMESTAMP';

PRINT N'Creating Extended Property [dbo].[ICS_COPY_MGP_LMT_SET].[PRMT_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermitIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_COPY_MGP_LMT_SET', @level2type = N'COLUMN', @level2name = N'PRMT_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_COPY_MGP_LMT_SET].[PRMT_FEATR_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermittedFeatureIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_COPY_MGP_LMT_SET', @level2type = N'COLUMN', @level2name = N'PRMT_FEATR_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_COPY_MGP_LMT_SET].[LMT_SET_DESIGNATOR].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'LimitSetDesignator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_COPY_MGP_LMT_SET', @level2type = N'COLUMN', @level2name = N'LMT_SET_DESIGNATOR';

PRINT N'Creating Extended Property [dbo].[ICS_COPY_MGP_LMT_SET].[TRGT_GNRL_PRMT_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TargetGeneralPermitIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_COPY_MGP_LMT_SET', @level2type = N'COLUMN', @level2name = N'TRGT_GNRL_PRMT_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_COPY_MGP_LMT_SET].[TRGT_GNRL_PRMT_FEATR_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TargetGeneralPermittedFeatureIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_COPY_MGP_LMT_SET', @level2type = N'COLUMN', @level2name = N'TRGT_GNRL_PRMT_FEATR_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_COPY_MGP_LMT_SET].[TRGT_GNRL_LMT_SET_DESIGNATOR].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TargetGeneralLimitSetDesignator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_COPY_MGP_LMT_SET', @level2type = N'COLUMN', @level2name = N'TRGT_GNRL_LMT_SET_DESIGNATOR';

PRINT N'Creating Extended Property [dbo].[ICS_COPY_MGP_LMT_SET].[PRMT_FEATR_TYPE_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermittedFeatureTypeCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_COPY_MGP_LMT_SET', @level2type = N'COLUMN', @level2name = N'PRMT_FEATR_TYPE_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_COPY_MGP_LMT_SET].[PRMT_FEATR_DESC].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermittedFeatureDescription', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_COPY_MGP_LMT_SET', @level2type = N'COLUMN', @level2name = N'PRMT_FEATR_DESC';

PRINT N'Creating Extended Property [dbo].[ICS_COPY_MGP_LMT_SET].[PRMT_FEATR_ST_WTR_BODY_NAME].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermittedFeatureStateWaterBodyName', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_COPY_MGP_LMT_SET', @level2type = N'COLUMN', @level2name = N'PRMT_FEATR_ST_WTR_BODY_NAME';

PRINT N'Creating Extended Property [dbo].[ICS_COPY_MGP_LMT_SET].[IMPAIRED_WTR_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ImpairedWaterIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_COPY_MGP_LMT_SET', @level2type = N'COLUMN', @level2name = N'IMPAIRED_WTR_IND';

PRINT N'Creating Extended Property [dbo].[ICS_COPY_MGP_LMT_SET].[TMDL_COMPLETED_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TMDLCompletedIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_COPY_MGP_LMT_SET', @level2type = N'COLUMN', @level2name = N'TMDL_COMPLETED_IND';

PRINT N'Creating Extended Property [dbo].[ICS_COPY_MGP_LMT_SET].[PRMT_FEATR_USR_DFND_DAT_ELM_1].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermittedFeatureUserDefinedDataElement1', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_COPY_MGP_LMT_SET', @level2type = N'COLUMN', @level2name = N'PRMT_FEATR_USR_DFND_DAT_ELM_1';

PRINT N'Creating Extended Property [dbo].[ICS_COPY_MGP_LMT_SET].[PRMT_FEATR_USR_DFND_DAT_ELM_2].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermittedFeatureUserDefinedDataElement2', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_COPY_MGP_LMT_SET', @level2type = N'COLUMN', @level2name = N'PRMT_FEATR_USR_DFND_DAT_ELM_2';

PRINT N'Creating Extended Property [dbo].[ICS_COPY_MGP_LMT_SET].[LMT_SET_NAME_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'LimitSetNameText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_COPY_MGP_LMT_SET', @level2type = N'COLUMN', @level2name = N'LMT_SET_NAME_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_COPY_MGP_LMT_SET].[DMR_PRE_PRINT_CMNTS_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'DMRPrePrintCommentsText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_COPY_MGP_LMT_SET', @level2type = N'COLUMN', @level2name = N'DMR_PRE_PRINT_CMNTS_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_DSCH_MON_REP].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: DischargeMonitoringReportData', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_DSCH_MON_REP';

PRINT N'Creating Extended Property [dbo].[ICS_DSCH_MON_REP].[SRC_SYSTM_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SourceSystemIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_DSCH_MON_REP', @level2type = N'COLUMN', @level2name = N'SRC_SYSTM_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_DSCH_MON_REP].[TRANSACTION_TYPE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TransactionType', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_DSCH_MON_REP', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TYPE';

PRINT N'Creating Extended Property [dbo].[ICS_DSCH_MON_REP].[TRANSACTION_TIMESTAMP].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TransactionTimestamp', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_DSCH_MON_REP', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TIMESTAMP';

PRINT N'Creating Extended Property [dbo].[ICS_DSCH_MON_REP].[PRMT_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermitIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_DSCH_MON_REP', @level2type = N'COLUMN', @level2name = N'PRMT_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_DSCH_MON_REP].[PRMT_FEATR_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermittedFeatureIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_DSCH_MON_REP', @level2type = N'COLUMN', @level2name = N'PRMT_FEATR_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_DSCH_MON_REP].[LMT_SET_DESIGNATOR].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'LimitSetDesignator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_DSCH_MON_REP', @level2type = N'COLUMN', @level2name = N'LMT_SET_DESIGNATOR';

PRINT N'Creating Extended Property [dbo].[ICS_DSCH_MON_REP].[MON_PERIOD_END_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MonitoringPeriodEndDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_DSCH_MON_REP', @level2type = N'COLUMN', @level2name = N'MON_PERIOD_END_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_DSCH_MON_REP].[DMR_NO_DSCH_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'DMRNoDischargeIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_DSCH_MON_REP', @level2type = N'COLUMN', @level2name = N'DMR_NO_DSCH_IND';

PRINT N'Creating Extended Property [dbo].[ICS_DSCH_MON_REP].[DMR_NO_DSCH_RCVD_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'DMRNoDischargeReceivedDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_DSCH_MON_REP', @level2type = N'COLUMN', @level2name = N'DMR_NO_DSCH_RCVD_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_DSCH_MON_REP].[ELEC_SUBM_TYPE_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ElectronicSubmissionTypeCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_DSCH_MON_REP', @level2type = N'COLUMN', @level2name = N'ELEC_SUBM_TYPE_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_DSCH_MON_REP].[SIGN_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SignatureDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_DSCH_MON_REP', @level2type = N'COLUMN', @level2name = N'SIGN_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_DSCH_MON_REP].[PRNCPL_EXEC_OFFCR_FIRST_NAME].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PrincipalExecutiveOfficerFirstName', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_DSCH_MON_REP', @level2type = N'COLUMN', @level2name = N'PRNCPL_EXEC_OFFCR_FIRST_NAME';

PRINT N'Creating Extended Property [dbo].[ICS_DSCH_MON_REP].[PRNCPL_EXEC_OFFCR_LAST_NAME].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PrincipalExecutiveOfficerLastName', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_DSCH_MON_REP', @level2type = N'COLUMN', @level2name = N'PRNCPL_EXEC_OFFCR_LAST_NAME';

PRINT N'Creating Extended Property [dbo].[ICS_DSCH_MON_REP].[PRNCPL_EXEC_OFFCR_TITLE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PrincipalExecutiveOfficerTitle', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_DSCH_MON_REP', @level2type = N'COLUMN', @level2name = N'PRNCPL_EXEC_OFFCR_TITLE';

PRINT N'Creating Extended Property [dbo].[ICS_DSCH_MON_REP].[PRNCPL_EXEC_OFFCR_TELEPH].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PrincipalExecutiveOfficerTelephone', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_DSCH_MON_REP', @level2type = N'COLUMN', @level2name = N'PRNCPL_EXEC_OFFCR_TELEPH';

PRINT N'Creating Extended Property [dbo].[ICS_DSCH_MON_REP].[SIGN_FIRST_NAME].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SignatoryFirstName', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_DSCH_MON_REP', @level2type = N'COLUMN', @level2name = N'SIGN_FIRST_NAME';

PRINT N'Creating Extended Property [dbo].[ICS_DSCH_MON_REP].[SIGN_LAST_NAME].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SignatoryLastName', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_DSCH_MON_REP', @level2type = N'COLUMN', @level2name = N'SIGN_LAST_NAME';

PRINT N'Creating Extended Property [dbo].[ICS_DSCH_MON_REP].[SIGN_TELEPH].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SignatoryTelephone', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_DSCH_MON_REP', @level2type = N'COLUMN', @level2name = N'SIGN_TELEPH';

PRINT N'Creating Extended Property [dbo].[ICS_DSCH_MON_REP].[REP_CMNT_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ReportCommentText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_DSCH_MON_REP', @level2type = N'COLUMN', @level2name = N'REP_CMNT_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_FAC].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: Facility', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_FAC';

PRINT N'Creating Extended Property [dbo].[ICS_FAC].[LOCALITY_NAME].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'LocalityName', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_FAC', @level2type = N'COLUMN', @level2name = N'LOCALITY_NAME';

PRINT N'Creating Extended Property [dbo].[ICS_FAC].[LOC_ADDR_CITY_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'LocationAddressCityCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_FAC', @level2type = N'COLUMN', @level2name = N'LOC_ADDR_CITY_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_FAC].[LOC_ADDR_COUNTY_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'LocationAddressCountyCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_FAC', @level2type = N'COLUMN', @level2name = N'LOC_ADDR_COUNTY_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_FAC].[FAC_SITE_NAME].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'FacilitySiteName', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_FAC', @level2type = N'COLUMN', @level2name = N'FAC_SITE_NAME';

PRINT N'Creating Extended Property [dbo].[ICS_FAC].[LOC_ADDR_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'LocationAddressText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_FAC', @level2type = N'COLUMN', @level2name = N'LOC_ADDR_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_FAC].[SUPPL_LOC_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SupplementalLocationText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_FAC', @level2type = N'COLUMN', @level2name = N'SUPPL_LOC_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_FAC].[LOC_ST_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'LocationStateCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_FAC', @level2type = N'COLUMN', @level2name = N'LOC_ST_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_FAC].[LOC_ZIP_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'LocationZipCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_FAC', @level2type = N'COLUMN', @level2name = N'LOC_ZIP_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_FAC].[LOC_COUNTRY_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'LocationCountryCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_FAC', @level2type = N'COLUMN', @level2name = N'LOC_COUNTRY_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_FAC].[ORG_DUNS_NUM].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'OrganizationDUNSNumber', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_FAC', @level2type = N'COLUMN', @level2name = N'ORG_DUNS_NUM';

PRINT N'Creating Extended Property [dbo].[ICS_FAC].[ST_FAC_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'StateFacilityIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_FAC', @level2type = N'COLUMN', @level2name = N'ST_FAC_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_FAC].[ST_RGN_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'StateRegionCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_FAC', @level2type = N'COLUMN', @level2name = N'ST_RGN_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_FAC].[FAC_CONGR_DISTRICT_NUM].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'FacilityCongressionalDistrictNumber', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_FAC', @level2type = N'COLUMN', @level2name = N'FAC_CONGR_DISTRICT_NUM';

PRINT N'Creating Extended Property [dbo].[ICS_FAC].[FAC_TYPE_OF_OWNERSHIP_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'FacilityTypeOfOwnershipCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_FAC', @level2type = N'COLUMN', @level2name = N'FAC_TYPE_OF_OWNERSHIP_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_FAC].[FEDR_FAC_IDENT_NUM].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'FederalFacilityIdentificationNumber', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_FAC', @level2type = N'COLUMN', @level2name = N'FEDR_FAC_IDENT_NUM';

PRINT N'Creating Extended Property [dbo].[ICS_FAC].[FEDR_AGNCY_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'FederalAgencyCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_FAC', @level2type = N'COLUMN', @level2name = N'FEDR_AGNCY_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_FAC].[TRIBAL_LAND_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TribalLandCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_FAC', @level2type = N'COLUMN', @level2name = N'TRIBAL_LAND_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_FAC].[CNST_PROJ_NAME].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ConstructionProjectName', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_FAC', @level2type = N'COLUMN', @level2name = N'CNST_PROJ_NAME';

PRINT N'Creating Extended Property [dbo].[ICS_FAC].[CNST_PROJ_LAT_MEAS].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ConstructionProjectLatitudeMeasure', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_FAC', @level2type = N'COLUMN', @level2name = N'CNST_PROJ_LAT_MEAS';

PRINT N'Creating Extended Property [dbo].[ICS_FAC].[CNST_PROJ_LONG_MEAS].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ConstructionProjectLongitudeMeasure', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_FAC', @level2type = N'COLUMN', @level2name = N'CNST_PROJ_LONG_MEAS';

PRINT N'Creating Extended Property [dbo].[ICS_FAC].[SECTION_TOWNSHIP_RNG].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SectionTownshipRange', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_FAC', @level2type = N'COLUMN', @level2name = N'SECTION_TOWNSHIP_RNG';

PRINT N'Creating Extended Property [dbo].[ICS_FAC].[FAC_CMNTS].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'FacilityComments', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_FAC', @level2type = N'COLUMN', @level2name = N'FAC_CMNTS';

PRINT N'Creating Extended Property [dbo].[ICS_FAC].[FAC_USR_DFND_FLD_1].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'FacilityUserDefinedField1', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_FAC', @level2type = N'COLUMN', @level2name = N'FAC_USR_DFND_FLD_1';

PRINT N'Creating Extended Property [dbo].[ICS_FAC].[FAC_USR_DFND_FLD_2].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'FacilityUserDefinedField2', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_FAC', @level2type = N'COLUMN', @level2name = N'FAC_USR_DFND_FLD_2';

PRINT N'Creating Extended Property [dbo].[ICS_FAC].[FAC_USR_DFND_FLD_3].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'FacilityUserDefinedField3', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_FAC', @level2type = N'COLUMN', @level2name = N'FAC_USR_DFND_FLD_3';

PRINT N'Creating Extended Property [dbo].[ICS_FAC].[FAC_USR_DFND_FLD_4].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'FacilityUserDefinedField4', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_FAC', @level2type = N'COLUMN', @level2name = N'FAC_USR_DFND_FLD_4';

PRINT N'Creating Extended Property [dbo].[ICS_FAC].[FAC_USR_DFND_FLD_5].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'FacilityUserDefinedField5', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_FAC', @level2type = N'COLUMN', @level2name = N'FAC_USR_DFND_FLD_5';

PRINT N'Creating Extended Property [dbo].[ICS_FINAL_ORDER].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: FinalOrder', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_FINAL_ORDER';

PRINT N'Creating Extended Property [dbo].[ICS_FINAL_ORDER].[FINAL_ORDER_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'FinalOrderIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_FINAL_ORDER', @level2type = N'COLUMN', @level2name = N'FINAL_ORDER_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_FINAL_ORDER].[FINAL_ORDER_TYPE_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'FinalOrderTypeCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_FINAL_ORDER', @level2type = N'COLUMN', @level2name = N'FINAL_ORDER_TYPE_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_FINAL_ORDER].[FINAL_ORDER_ISSUED_ENTERD_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'FinalOrderIssuedEnteredDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_FINAL_ORDER', @level2type = N'COLUMN', @level2name = N'FINAL_ORDER_ISSUED_ENTERD_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_FINAL_ORDER].[NPDES_CLOSED_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'NPDESClosedDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_FINAL_ORDER', @level2type = N'COLUMN', @level2name = N'NPDES_CLOSED_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_FINAL_ORDER].[FINAL_ORDER_QNCR_CMNTS].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'FinalOrderQNCRComments', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_FINAL_ORDER', @level2type = N'COLUMN', @level2name = N'FINAL_ORDER_QNCR_CMNTS';

PRINT N'Creating Extended Property [dbo].[ICS_FINAL_ORDER].[CASH_CIVIL_PNLTY_REQD_AMT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CashCivilPenaltyRequiredAmount', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_FINAL_ORDER', @level2type = N'COLUMN', @level2name = N'CASH_CIVIL_PNLTY_REQD_AMT';

PRINT N'Creating Extended Property [dbo].[ICS_FINAL_ORDER].[CASH_CIVIL_PNLTY_COLL_AMT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CashCivilPenaltyCollectedAmount', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_FINAL_ORDER', @level2type = N'COLUMN', @level2name = N'CASH_CIVIL_PNLTY_COLL_AMT';

PRINT N'Creating Extended Property [dbo].[ICS_FINAL_ORDER].[OTHR_CMNTS].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'OtherComments', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_FINAL_ORDER', @level2type = N'COLUMN', @level2name = N'OTHR_CMNTS';

PRINT N'Creating Extended Property [dbo].[ICS_GEO_COORD].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: GeographicCoordinates', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_GEO_COORD';

PRINT N'Creating Extended Property [dbo].[ICS_GEO_COORD].[LAT_MEAS].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'LatitudeMeasure', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_GEO_COORD', @level2type = N'COLUMN', @level2name = N'LAT_MEAS';

PRINT N'Creating Extended Property [dbo].[ICS_GEO_COORD].[LONG_MEAS].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'LongitudeMeasure', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_GEO_COORD', @level2type = N'COLUMN', @level2name = N'LONG_MEAS';

PRINT N'Creating Extended Property [dbo].[ICS_GEO_COORD].[HORZ_ACCURACY_MEAS].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'HorizontalAccuracyMeasure', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_GEO_COORD', @level2type = N'COLUMN', @level2name = N'HORZ_ACCURACY_MEAS';

PRINT N'Creating Extended Property [dbo].[ICS_GEO_COORD].[GEOMETRIC_TYPE_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'GeometricTypeCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_GEO_COORD', @level2type = N'COLUMN', @level2name = N'GEOMETRIC_TYPE_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_GEO_COORD].[HORZ_COLL_METHOD_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'HorizontalCollectionMethodCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_GEO_COORD', @level2type = N'COLUMN', @level2name = N'HORZ_COLL_METHOD_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_GEO_COORD].[HORZ_REF_DATUM_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'HorizontalReferenceDatumCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_GEO_COORD', @level2type = N'COLUMN', @level2name = N'HORZ_REF_DATUM_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_GEO_COORD].[REF_POINT_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ReferencePointCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_GEO_COORD', @level2type = N'COLUMN', @level2name = N'REF_POINT_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_GEO_COORD].[SRC_MAP_SCALE_NUM].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SourceMapScaleNumber', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_GEO_COORD', @level2type = N'COLUMN', @level2name = N'SRC_MAP_SCALE_NUM';

PRINT N'Creating Extended Property [dbo].[ICS_GNRL_PRMT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: GeneralPermitData', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_GNRL_PRMT';

PRINT N'Creating Extended Property [dbo].[ICS_GNRL_PRMT].[SRC_SYSTM_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SourceSystemIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_GNRL_PRMT', @level2type = N'COLUMN', @level2name = N'SRC_SYSTM_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_GNRL_PRMT].[TRANSACTION_TYPE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TransactionType', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_GNRL_PRMT', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TYPE';

PRINT N'Creating Extended Property [dbo].[ICS_GNRL_PRMT].[TRANSACTION_TIMESTAMP].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TransactionTimestamp', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_GNRL_PRMT', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TIMESTAMP';

PRINT N'Creating Extended Property [dbo].[ICS_GNRL_PRMT].[PRMT_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermitIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_GNRL_PRMT', @level2type = N'COLUMN', @level2name = N'PRMT_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_GNRL_PRMT].[ELEC_SUBM_TYPE_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ElectronicSubmissionTypeCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_GNRL_PRMT', @level2type = N'COLUMN', @level2name = N'ELEC_SUBM_TYPE_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_GNRL_PRMT].[ASSC_MASTER_GNRL_PRMT_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'AssociatedMasterGeneralPermitIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_GNRL_PRMT', @level2type = N'COLUMN', @level2name = N'ASSC_MASTER_GNRL_PRMT_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_GNRL_PRMT].[PRMT_TYPE_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermitTypeCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_GNRL_PRMT', @level2type = N'COLUMN', @level2name = N'PRMT_TYPE_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_GNRL_PRMT].[AGNCY_TYPE_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'AgencyTypeCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_GNRL_PRMT', @level2type = N'COLUMN', @level2name = N'AGNCY_TYPE_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_GNRL_PRMT].[PRMT_STAT_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermitStatusCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_GNRL_PRMT', @level2type = N'COLUMN', @level2name = N'PRMT_STAT_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_GNRL_PRMT].[PRMT_ISSUE_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermitIssueDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_GNRL_PRMT', @level2type = N'COLUMN', @level2name = N'PRMT_ISSUE_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_GNRL_PRMT].[PRMT_EFFECTIVE_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermitEffectiveDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_GNRL_PRMT', @level2type = N'COLUMN', @level2name = N'PRMT_EFFECTIVE_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_GNRL_PRMT].[PRMT_EXPR_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermitExpirationDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_GNRL_PRMT', @level2type = N'COLUMN', @level2name = N'PRMT_EXPR_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_GNRL_PRMT].[REISSU_PRIO_PRMT_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ReissuancePriorityPermitIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_GNRL_PRMT', @level2type = N'COLUMN', @level2name = N'REISSU_PRIO_PRMT_IND';

PRINT N'Creating Extended Property [dbo].[ICS_GNRL_PRMT].[BACKLOG_REASON_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'BacklogReasonText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_GNRL_PRMT', @level2type = N'COLUMN', @level2name = N'BACKLOG_REASON_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_GNRL_PRMT].[PRMT_ISSUING_ORG_TYPE_NAME].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermitIssuinrganizationTypeName', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_GNRL_PRMT', @level2type = N'COLUMN', @level2name = N'PRMT_ISSUING_ORG_TYPE_NAME';

PRINT N'Creating Extended Property [dbo].[ICS_GNRL_PRMT].[PRMT_APPEALED_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermitAppealedIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_GNRL_PRMT', @level2type = N'COLUMN', @level2name = N'PRMT_APPEALED_IND';

PRINT N'Creating Extended Property [dbo].[ICS_GNRL_PRMT].[PRMT_USR_DFND_DAT_ELM_1_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermitUserDefinedDataElement1Text', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_GNRL_PRMT', @level2type = N'COLUMN', @level2name = N'PRMT_USR_DFND_DAT_ELM_1_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_GNRL_PRMT].[PRMT_USR_DFND_DAT_ELM_2_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermitUserDefinedDataElement2Text', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_GNRL_PRMT', @level2type = N'COLUMN', @level2name = N'PRMT_USR_DFND_DAT_ELM_2_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_GNRL_PRMT].[PRMT_USR_DFND_DAT_ELM_3_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermitUserDefinedDataElement3Text', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_GNRL_PRMT', @level2type = N'COLUMN', @level2name = N'PRMT_USR_DFND_DAT_ELM_3_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_GNRL_PRMT].[PRMT_USR_DFND_DAT_ELM_4_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermitUserDefinedDataElement4Text', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_GNRL_PRMT', @level2type = N'COLUMN', @level2name = N'PRMT_USR_DFND_DAT_ELM_4_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_GNRL_PRMT].[PRMT_USR_DFND_DAT_ELM_5_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermitUserDefinedDataElement5Text', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_GNRL_PRMT', @level2type = N'COLUMN', @level2name = N'PRMT_USR_DFND_DAT_ELM_5_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_GNRL_PRMT].[PRMT_CMNTS_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermitCommentsText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_GNRL_PRMT', @level2type = N'COLUMN', @level2name = N'PRMT_CMNTS_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_GNRL_PRMT].[MAJOR_MINOR_RATING_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MajorMinorRatingCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_GNRL_PRMT', @level2type = N'COLUMN', @level2name = N'MAJOR_MINOR_RATING_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_GNRL_PRMT].[TTL_APPL_DSGN_FLOW_NUM].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TotalApplicationDesignFlowNumber', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_GNRL_PRMT', @level2type = N'COLUMN', @level2name = N'TTL_APPL_DSGN_FLOW_NUM';

PRINT N'Creating Extended Property [dbo].[ICS_GNRL_PRMT].[TTL_APPL_AVER_FLOW_NUM].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TotalApplicationAverageFlowNumber', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_GNRL_PRMT', @level2type = N'COLUMN', @level2name = N'TTL_APPL_AVER_FLOW_NUM';

PRINT N'Creating Extended Property [dbo].[ICS_GNRL_PRMT].[APPL_RCVD_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ApplicationReceivedDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_GNRL_PRMT', @level2type = N'COLUMN', @level2name = N'APPL_RCVD_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_GNRL_PRMT].[PRMT_APPL_CMPL_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermitApplicationCompletionDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_GNRL_PRMT', @level2type = N'COLUMN', @level2name = N'PRMT_APPL_CMPL_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_GNRL_PRMT].[NEW_SRC_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'NewSourceIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_GNRL_PRMT', @level2type = N'COLUMN', @level2name = N'NEW_SRC_IND';

PRINT N'Creating Extended Property [dbo].[ICS_GNRL_PRMT].[PRMT_ST_WTR_BODY_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermitStateWaterBodyCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_GNRL_PRMT', @level2type = N'COLUMN', @level2name = N'PRMT_ST_WTR_BODY_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_GNRL_PRMT].[PRMT_ST_WTR_BODY_NAME].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermitStateWaterBodyName', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_GNRL_PRMT', @level2type = N'COLUMN', @level2name = N'PRMT_ST_WTR_BODY_NAME';

PRINT N'Creating Extended Property [dbo].[ICS_GNRL_PRMT].[FEDR_GRANT_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'FederalGrantIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_GNRL_PRMT', @level2type = N'COLUMN', @level2name = N'FEDR_GRANT_IND';

PRINT N'Creating Extended Property [dbo].[ICS_GNRL_PRMT].[DMR_COGNZNT_OFCL].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'DMRCognizantOfficial', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_GNRL_PRMT', @level2type = N'COLUMN', @level2name = N'DMR_COGNZNT_OFCL';

PRINT N'Creating Extended Property [dbo].[ICS_GNRL_PRMT].[DMR_COGNZNT_OFCL_TELEPH_NUM].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'DMRCognizantOfficialTelephoneNumber', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_GNRL_PRMT', @level2type = N'COLUMN', @level2name = N'DMR_COGNZNT_OFCL_TELEPH_NUM';

PRINT N'Creating Extended Property [dbo].[ICS_GNRL_PRMT].[ELEC_REP_WAIVER_TYPE_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ElectronicReportingWaiverTypeCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_GNRL_PRMT', @level2type = N'COLUMN', @level2name = N'ELEC_REP_WAIVER_TYPE_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_GNRL_PRMT].[ELEC_REP_WAIVER_EFFECTIVE_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ElectronicReportingWaiverEffectiveDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_GNRL_PRMT', @level2type = N'COLUMN', @level2name = N'ELEC_REP_WAIVER_EFFECTIVE_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_GNRL_PRMT].[ELEC_REP_WAIVER_EXPR_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ElectronicReportingWaiverExpirationDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_GNRL_PRMT', @level2type = N'COLUMN', @level2name = N'ELEC_REP_WAIVER_EXPR_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_GNRL_PRMT].[MAJOR_MINOR_STAT_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MajorMinorStatusIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_GNRL_PRMT', @level2type = N'COLUMN', @level2name = N'MAJOR_MINOR_STAT_IND';

PRINT N'Creating Extended Property [dbo].[ICS_GNRL_PRMT].[MAJOR_MINOR_STAT_START_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MajorMinorStatusStartDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_GNRL_PRMT', @level2type = N'COLUMN', @level2name = N'MAJOR_MINOR_STAT_START_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_GNRL_PRMT].[DMR_NON_RCPT_STAT_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'DMRNonReceiptStatusIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_GNRL_PRMT', @level2type = N'COLUMN', @level2name = N'DMR_NON_RCPT_STAT_IND';

PRINT N'Creating Extended Property [dbo].[ICS_GNRL_PRMT].[DMR_NON_RCPT_STAT_START_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'DMRNonReceiptStatusStartDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_GNRL_PRMT', @level2type = N'COLUMN', @level2name = N'DMR_NON_RCPT_STAT_START_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_IMPAIRED_WTR_POLLUTANTS].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: CustomXmlStringFormatInt32', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_IMPAIRED_WTR_POLLUTANTS';

PRINT N'Creating Extended Property [dbo].[ICS_IMPAIRED_WTR_POLLUTANTS].[IMPAIRED_WTR_POLLUTANTS].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ImpairedWaterPollutants', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_IMPAIRED_WTR_POLLUTANTS', @level2type = N'COLUMN', @level2name = N'IMPAIRED_WTR_POLLUTANTS';

PRINT N'Creating Extended Property [dbo].[ICS_LMT_SET_SCHD].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: LimitSetSchedule', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LMT_SET_SCHD';

PRINT N'Creating Extended Property [dbo].[ICS_LMT_SET_SCHD].[NUM_UNITS_REP_PERIOD_INTEGER].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'NumberUnitsReportPeriodInteger', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LMT_SET_SCHD', @level2type = N'COLUMN', @level2name = N'NUM_UNITS_REP_PERIOD_INTEGER';

PRINT N'Creating Extended Property [dbo].[ICS_LMT_SET_SCHD].[NUM_SUBM_UNITS_INTEGER].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'NumberSubmissionUnitsInteger', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LMT_SET_SCHD', @level2type = N'COLUMN', @level2name = N'NUM_SUBM_UNITS_INTEGER';

PRINT N'Creating Extended Property [dbo].[ICS_LMT_SET_SCHD].[INITIAL_MON_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'InitialMonitoringDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LMT_SET_SCHD', @level2type = N'COLUMN', @level2name = N'INITIAL_MON_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_LMT_SET_SCHD].[INITIAL_DMR_DUE_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'InitialDMRDueDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LMT_SET_SCHD', @level2type = N'COLUMN', @level2name = N'INITIAL_DMR_DUE_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_LMT_SET_SCHD].[LMT_SET_MOD_TYPE_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'LimitSetModificationTypeCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LMT_SET_SCHD', @level2type = N'COLUMN', @level2name = N'LMT_SET_MOD_TYPE_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_LMT_SET_SCHD].[LMT_SET_MOD_EFFECTIVE_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'LimitSetModificationEffectiveDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LMT_SET_SCHD', @level2type = N'COLUMN', @level2name = N'LMT_SET_MOD_EFFECTIVE_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_LMT_SET_STAT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: LimitSetStatus', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LMT_SET_STAT';

PRINT N'Creating Extended Property [dbo].[ICS_LMT_SET_STAT].[LMT_SET_STAT_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'LimitSetStatusIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LMT_SET_STAT', @level2type = N'COLUMN', @level2name = N'LMT_SET_STAT_IND';

PRINT N'Creating Extended Property [dbo].[ICS_LMT_SET_STAT].[LMT_SET_STAT_START_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'LimitSetStatusStartDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LMT_SET_STAT', @level2type = N'COLUMN', @level2name = N'LMT_SET_STAT_START_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_LMT_SET_STAT].[LMT_SET_STAT_REASON_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'LimitSetStatusReasonText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LMT_SET_STAT', @level2type = N'COLUMN', @level2name = N'LMT_SET_STAT_REASON_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_LMTS].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: LimitsData', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LMTS';

PRINT N'Creating Extended Property [dbo].[ICS_LMTS].[SRC_SYSTM_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SourceSystemIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LMTS', @level2type = N'COLUMN', @level2name = N'SRC_SYSTM_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_LMTS].[TRANSACTION_TYPE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TransactionType', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LMTS', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TYPE';

PRINT N'Creating Extended Property [dbo].[ICS_LMTS].[TRANSACTION_TIMESTAMP].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TransactionTimestamp', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LMTS', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TIMESTAMP';

PRINT N'Creating Extended Property [dbo].[ICS_LMTS].[PRMT_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermitIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LMTS', @level2type = N'COLUMN', @level2name = N'PRMT_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_LMTS].[PRMT_FEATR_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermittedFeatureIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LMTS', @level2type = N'COLUMN', @level2name = N'PRMT_FEATR_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_LMTS].[LMT_SET_DESIGNATOR].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'LimitSetDesignator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LMTS', @level2type = N'COLUMN', @level2name = N'LMT_SET_DESIGNATOR';

PRINT N'Creating Extended Property [dbo].[ICS_LMTS].[PARAM_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ParameterCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LMTS', @level2type = N'COLUMN', @level2name = N'PARAM_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_LMTS].[MON_SITE_DESC_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MonitoringSiteDescriptionCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LMTS', @level2type = N'COLUMN', @level2name = N'MON_SITE_DESC_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_LMTS].[LMT_SEASON_NUM].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'LimitSeasonNumber', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LMTS', @level2type = N'COLUMN', @level2name = N'LMT_SEASON_NUM';

PRINT N'Creating Extended Property [dbo].[ICS_LMTS].[LMT_START_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'LimitStartDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LMTS', @level2type = N'COLUMN', @level2name = N'LMT_START_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_LMTS].[LMT_END_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'LimitEndDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LMTS', @level2type = N'COLUMN', @level2name = N'LMT_END_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_LMTS].[LMT_TYPE_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'LimitTypeCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LMTS', @level2type = N'COLUMN', @level2name = N'LMT_TYPE_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_LMTS].[SMPL_TYPE_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SampleTypeText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LMTS', @level2type = N'COLUMN', @level2name = N'SMPL_TYPE_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_LMTS].[FREQ_OF_ANALYSIS_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'FrequencyOfAnalysisCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LMTS', @level2type = N'COLUMN', @level2name = N'FREQ_OF_ANALYSIS_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_LMTS].[ELIGIBLE_FOR_BURDEN_REDUCTION].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'EligibleForBurdenReduction', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LMTS', @level2type = N'COLUMN', @level2name = N'ELIGIBLE_FOR_BURDEN_REDUCTION';

PRINT N'Creating Extended Property [dbo].[ICS_LMTS].[LMT_STAY_TYPE_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'LimitStayTypeCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LMTS', @level2type = N'COLUMN', @level2name = N'LMT_STAY_TYPE_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_LMTS].[STAY_START_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'StayStartDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LMTS', @level2type = N'COLUMN', @level2name = N'STAY_START_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_LMTS].[STAY_END_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'StayEndDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LMTS', @level2type = N'COLUMN', @level2name = N'STAY_END_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_LMTS].[STAY_REASON_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'StayReasonText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LMTS', @level2type = N'COLUMN', @level2name = N'STAY_REASON_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_LMTS].[CALCULATE_VIOL_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CalculateViolationsIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LMTS', @level2type = N'COLUMN', @level2name = N'CALCULATE_VIOL_IND';

PRINT N'Creating Extended Property [dbo].[ICS_LMTS].[ENFRC_ACTN_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'EnforcementActionIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LMTS', @level2type = N'COLUMN', @level2name = N'ENFRC_ACTN_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_LMTS].[FINAL_ORDER_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'FinalOrderIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LMTS', @level2type = N'COLUMN', @level2name = N'FINAL_ORDER_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_LMTS].[BASIS_OF_LMT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'BasisOfLimit', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LMTS', @level2type = N'COLUMN', @level2name = N'BASIS_OF_LMT';

PRINT N'Creating Extended Property [dbo].[ICS_LMTS].[LMT_MOD_TYPE_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'LimitModificationTypeCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LMTS', @level2type = N'COLUMN', @level2name = N'LMT_MOD_TYPE_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_LMTS].[LMT_MOD_EFFECTIVE_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'LimitModificationEffectiveDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LMTS', @level2type = N'COLUMN', @level2name = N'LMT_MOD_EFFECTIVE_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_LMTS].[LMT_MOD_TYPE_STAY_REASON_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'LimitModificationTypeStayReasonText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LMTS', @level2type = N'COLUMN', @level2name = N'LMT_MOD_TYPE_STAY_REASON_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_LMTS].[LMTS_USR_DFND_FLD_1].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'LimitsUserDefinedField1', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LMTS', @level2type = N'COLUMN', @level2name = N'LMTS_USR_DFND_FLD_1';

PRINT N'Creating Extended Property [dbo].[ICS_LMTS].[LMTS_USR_DFND_FLD_2].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'LimitsUserDefinedField2', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LMTS', @level2type = N'COLUMN', @level2name = N'LMTS_USR_DFND_FLD_2';

PRINT N'Creating Extended Property [dbo].[ICS_LMTS].[LMTS_USR_DFND_FLD_3].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'LimitsUserDefinedField3', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LMTS', @level2type = N'COLUMN', @level2name = N'LMTS_USR_DFND_FLD_3';

PRINT N'Creating Extended Property [dbo].[ICS_LMTS].[CONCEN_NUM_COND_UNIT_MEAS_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ConcentrationNumericConditionUnitMeasureCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LMTS', @level2type = N'COLUMN', @level2name = N'CONCEN_NUM_COND_UNIT_MEAS_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_LMTS].[QTY_NUM_COND_UNIT_MEAS_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'QuantityNumericConditionUnitMeasureCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LMTS', @level2type = N'COLUMN', @level2name = N'QTY_NUM_COND_UNIT_MEAS_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_MNUR_LTTR_PRCSS_WW_STOR].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: ManureLitterProcessedWastewaterStorage', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MNUR_LTTR_PRCSS_WW_STOR';

PRINT N'Creating Extended Property [dbo].[ICS_MNUR_LTTR_PRCSS_WW_STOR].[MNUR_LTTR_PRCSS_WW_STOR_TYPE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ManureLitterProcessedWastewaterStorageType', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MNUR_LTTR_PRCSS_WW_STOR', @level2type = N'COLUMN', @level2name = N'MNUR_LTTR_PRCSS_WW_STOR_TYPE';

PRINT N'Creating Extended Property [dbo].[ICS_MNUR_LTTR_PRCSS_WW_STOR].[OTHR_STOR_TYPE_NAME].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'OtherStorageTypeName', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MNUR_LTTR_PRCSS_WW_STOR', @level2type = N'COLUMN', @level2name = N'OTHR_STOR_TYPE_NAME';

PRINT N'Creating Extended Property [dbo].[ICS_MNUR_LTTR_PRCSS_WW_STOR].[STOR_TTL_CPCTY_MEAS].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'StorageTotalCapacityMeasure', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MNUR_LTTR_PRCSS_WW_STOR', @level2type = N'COLUMN', @level2name = N'STOR_TTL_CPCTY_MEAS';

PRINT N'Creating Extended Property [dbo].[ICS_MNUR_LTTR_PRCSS_WW_STOR].[DAYS_OF_STOR].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'DaysOfStorage', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MNUR_LTTR_PRCSS_WW_STOR', @level2type = N'COLUMN', @level2name = N'DAYS_OF_STOR';

PRINT N'Creating Extended Property [dbo].[ICS_MNUR_LTTR_PRCSS_WW_STOR].[CAFOMLPW_UNIT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CAFOMLPWUnit', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MNUR_LTTR_PRCSS_WW_STOR', @level2type = N'COLUMN', @level2name = N'CAFOMLPW_UNIT';

PRINT N'Creating Extended Property [dbo].[ICS_MNUR_LTTR_PRCSS_WW_STOR].[CAFOMLPW_STOR_WITHIN_DSGN_CPCTY].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CAFOMLPWStorageWithinDesignCapacity', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MNUR_LTTR_PRCSS_WW_STOR', @level2type = N'COLUMN', @level2name = N'CAFOMLPW_STOR_WITHIN_DSGN_CPCTY';

PRINT N'Creating Extended Property [dbo].[ICS_MNUR_LTTR_PRCSS_WW_STOR].[CAFOMLPW_STOR_WITHIN_DSGN_CPCTY_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CAFOMLPWStorageWithinDesignCapacityText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MNUR_LTTR_PRCSS_WW_STOR', @level2type = N'COLUMN', @level2name = N'CAFOMLPW_STOR_WITHIN_DSGN_CPCTY_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_PATHOGEN_REDUCTION_TYPE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: String', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PATHOGEN_REDUCTION_TYPE';

PRINT N'Creating Extended Property [dbo].[ICS_PATHOGEN_REDUCTION_TYPE].[PATHOGEN_REDUCTION_TYPE_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PathogenReductionTypeCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PATHOGEN_REDUCTION_TYPE', @level2type = N'COLUMN', @level2name = N'PATHOGEN_REDUCTION_TYPE_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_PRETR_PRMT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: PretreatmentPermitData', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PRMT';

PRINT N'Creating Extended Property [dbo].[ICS_PRETR_PRMT].[SRC_SYSTM_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SourceSystemIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PRMT', @level2type = N'COLUMN', @level2name = N'SRC_SYSTM_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_PRETR_PRMT].[TRANSACTION_TYPE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TransactionType', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PRMT', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TYPE';

PRINT N'Creating Extended Property [dbo].[ICS_PRETR_PRMT].[TRANSACTION_TIMESTAMP].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TransactionTimestamp', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PRMT', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TIMESTAMP';

PRINT N'Creating Extended Property [dbo].[ICS_PRETR_PRMT].[PRMT_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermitIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PRMT', @level2type = N'COLUMN', @level2name = N'PRMT_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_PRETR_PRMT].[PRETR_PROG_REQD_IND_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PretreatmentProgramRequiredIndicatorCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PRMT', @level2type = N'COLUMN', @level2name = N'PRETR_PROG_REQD_IND_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_PRETR_PRMT].[CONTROL_AUTH_ST_AGNCY_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ControlAuthorityStateAgencyCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PRMT', @level2type = N'COLUMN', @level2name = N'CONTROL_AUTH_ST_AGNCY_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_PRETR_PRMT].[CONTROL_AUTH_RGNL_AGNCY_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ControlAuthorityRegionalAgencyCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PRMT', @level2type = N'COLUMN', @level2name = N'CONTROL_AUTH_RGNL_AGNCY_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_PRETR_PRMT].[CONTROL_AUTH_NPDES_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ControlAuthorityNPDESIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PRMT', @level2type = N'COLUMN', @level2name = N'CONTROL_AUTH_NPDES_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_PRETR_PRMT].[PRETR_PROG_APRVD_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PretreatmentProgramApprovedDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PRMT', @level2type = N'COLUMN', @level2name = N'PRETR_PROG_APRVD_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_PRETR_PRMT].[RCVG_RCRA_WASTE_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ReceivingRCRAWasteIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PRMT', @level2type = N'COLUMN', @level2name = N'RCVG_RCRA_WASTE_IND';

PRINT N'Creating Extended Property [dbo].[ICS_PRETR_PRMT].[RCVG_REMEDIATION_WASTE_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ReceivingRemediationWasteIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PRMT', @level2type = N'COLUMN', @level2name = N'RCVG_REMEDIATION_WASTE_IND';

PRINT N'Creating Extended Property [dbo].[ICS_SURF_DSPL_SITE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: SurfaceDisposalSite', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SURF_DSPL_SITE';

PRINT N'Creating Extended Property [dbo].[ICS_SURF_DSPL_SITE].[PATHOGEN_REDUCTION_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PathogenReductionIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SURF_DSPL_SITE', @level2type = N'COLUMN', @level2name = N'PATHOGEN_REDUCTION_IND';

PRINT N'Creating Extended Property [dbo].[ICS_SURF_DSPL_SITE].[VECTOR_REDUCTION_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'VectorReductionIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SURF_DSPL_SITE', @level2type = N'COLUMN', @level2name = N'VECTOR_REDUCTION_IND';

PRINT N'Creating Extended Property [dbo].[ICS_SURF_DSPL_SITE].[MGMT_PRACTICE_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ManagementPracticesIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SURF_DSPL_SITE', @level2type = N'COLUMN', @level2name = N'MGMT_PRACTICE_IND';

PRINT N'Creating Extended Property [dbo].[ICS_SURF_DSPL_SITE].[CERT_STATEMENT_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CertificationStatementIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SURF_DSPL_SITE', @level2type = N'COLUMN', @level2name = N'CERT_STATEMENT_IND';

PRINT N'Creating Extended Property [dbo].[ICS_SURF_DSPL_SITE].[CERT_FIRST_NAME].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CertifierFirstName', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SURF_DSPL_SITE', @level2type = N'COLUMN', @level2name = N'CERT_FIRST_NAME';

PRINT N'Creating Extended Property [dbo].[ICS_SURF_DSPL_SITE].[CERT_LAST_NAME].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CertifierLastName', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SURF_DSPL_SITE', @level2type = N'COLUMN', @level2name = N'CERT_LAST_NAME';

PRINT N'Creating Extended Property [dbo].[ICS_SURF_DSPL_SITE].[CLASS_A_ALT_USED].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ClassAAlternativeUsed', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SURF_DSPL_SITE', @level2type = N'COLUMN', @level2name = N'CLASS_A_ALT_USED';

PRINT N'Creating Extended Property [dbo].[ICS_SURF_DSPL_SITE].[CLASS_A_ALTS_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ClassAAlternativesText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SURF_DSPL_SITE', @level2type = N'COLUMN', @level2name = N'CLASS_A_ALTS_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_SURF_DSPL_SITE].[CLASS_B_ALT_USED].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ClassBAlternativeUsed', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SURF_DSPL_SITE', @level2type = N'COLUMN', @level2name = N'CLASS_B_ALT_USED';

PRINT N'Creating Extended Property [dbo].[ICS_SURF_DSPL_SITE].[CLASS_B_ALTS_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ClassBAlternativesText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SURF_DSPL_SITE', @level2type = N'COLUMN', @level2name = N'CLASS_B_ALTS_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_SURF_DSPL_SITE].[VAR_ALT_USED].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'VARAlternativeUsed', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SURF_DSPL_SITE', @level2type = N'COLUMN', @level2name = N'VAR_ALT_USED';

PRINT N'Creating Extended Property [dbo].[ICS_SURF_DSPL_SITE].[VAR_ALTS_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'VARAlternativesText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SURF_DSPL_SITE', @level2type = N'COLUMN', @level2name = N'VAR_ALTS_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_SW_CNST_PRMT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: SWConstructionPermitData', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_CNST_PRMT';

PRINT N'Creating Extended Property [dbo].[ICS_SW_CNST_PRMT].[SRC_SYSTM_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SourceSystemIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_CNST_PRMT', @level2type = N'COLUMN', @level2name = N'SRC_SYSTM_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_SW_CNST_PRMT].[TRANSACTION_TYPE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TransactionType', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_CNST_PRMT', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TYPE';

PRINT N'Creating Extended Property [dbo].[ICS_SW_CNST_PRMT].[TRANSACTION_TIMESTAMP].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TransactionTimestamp', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_CNST_PRMT', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TIMESTAMP';

PRINT N'Creating Extended Property [dbo].[ICS_SW_CNST_PRMT].[PRMT_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermitIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_CNST_PRMT', @level2type = N'COLUMN', @level2name = N'PRMT_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_SW_CNST_PRMT].[ST_WTR_BODY_NAME].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'StateWaterBodyName', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_CNST_PRMT', @level2type = N'COLUMN', @level2name = N'ST_WTR_BODY_NAME';

PRINT N'Creating Extended Property [dbo].[ICS_SW_CNST_PRMT].[RCVG_MS_4_NAME].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ReceivingMS4Name', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_CNST_PRMT', @level2type = N'COLUMN', @level2name = N'RCVG_MS_4_NAME';

PRINT N'Creating Extended Property [dbo].[ICS_SW_CNST_PRMT].[IMPAIRED_WTR_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ImpairedWaterIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_CNST_PRMT', @level2type = N'COLUMN', @level2name = N'IMPAIRED_WTR_IND';

PRINT N'Creating Extended Property [dbo].[ICS_SW_CNST_PRMT].[HIST_PROP_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'HistoricPropertyIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_CNST_PRMT', @level2type = N'COLUMN', @level2name = N'HIST_PROP_IND';

PRINT N'Creating Extended Property [dbo].[ICS_SW_CNST_PRMT].[HIST_PROP_CRIT_MET_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'HistoricPropertyCriterionMetCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_CNST_PRMT', @level2type = N'COLUMN', @level2name = N'HIST_PROP_CRIT_MET_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_SW_CNST_PRMT].[SPECIES_CRIT_HABITAT_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SpeciesCriticalHabitatIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_CNST_PRMT', @level2type = N'COLUMN', @level2name = N'SPECIES_CRIT_HABITAT_IND';

PRINT N'Creating Extended Property [dbo].[ICS_SW_CNST_PRMT].[SPECIES_CRIT_MET_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SpeciesCriterionMetCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_CNST_PRMT', @level2type = N'COLUMN', @level2name = N'SPECIES_CRIT_MET_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_SW_CNST_PRMT].[INDST_ACTY_SIZE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'IndustrialActivitySize', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_CNST_PRMT', @level2type = N'COLUMN', @level2name = N'INDST_ACTY_SIZE';

PRINT N'Creating Extended Property [dbo].[ICS_SW_CNST_PRMT].[PROJ_TYPE_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ProjectTypeCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_CNST_PRMT', @level2type = N'COLUMN', @level2name = N'PROJ_TYPE_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_SW_CNST_PRMT].[EST_START_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'EstimatedStartDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_CNST_PRMT', @level2type = N'COLUMN', @level2name = N'EST_START_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_SW_CNST_PRMT].[EST_COMPLETE_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'EstimatedCompleteDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_CNST_PRMT', @level2type = N'COLUMN', @level2name = N'EST_COMPLETE_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_SW_CNST_PRMT].[EST_AREA_DISTURBED_ACRES_NUM].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'EstimatedAreaDisturbedAcresNumber', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_CNST_PRMT', @level2type = N'COLUMN', @level2name = N'EST_AREA_DISTURBED_ACRES_NUM';

PRINT N'Creating Extended Property [dbo].[ICS_SW_CNST_PRMT].[PROJ_PLAN_SIZE_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ProjectPlanSizeCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_CNST_PRMT', @level2type = N'COLUMN', @level2name = N'PROJ_PLAN_SIZE_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_SW_CNST_PRMT].[STRCT_DEMOED_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'StructureDemolishedIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_CNST_PRMT', @level2type = N'COLUMN', @level2name = N'STRCT_DEMOED_IND';

PRINT N'Creating Extended Property [dbo].[ICS_SW_CNST_PRMT].[STRCT_DEMOED_FLOOR_SPACE_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'StructureDemolishedFloorSpaceIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_CNST_PRMT', @level2type = N'COLUMN', @level2name = N'STRCT_DEMOED_FLOOR_SPACE_IND';

PRINT N'Creating Extended Property [dbo].[ICS_SW_CNST_PRMT].[PREDEV_LAND_USE_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PredevelopmentLandUseIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_CNST_PRMT', @level2type = N'COLUMN', @level2name = N'PREDEV_LAND_USE_IND';

PRINT N'Creating Extended Property [dbo].[ICS_SW_CNST_PRMT].[ERTH_DISTRB_ACTIVITIES_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'EarthDisturbingActivitiesIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_CNST_PRMT', @level2type = N'COLUMN', @level2name = N'ERTH_DISTRB_ACTIVITIES_IND';

PRINT N'Creating Extended Property [dbo].[ICS_SW_CNST_PRMT].[ERTH_DISTRB_EMRGCY_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'EarthDisturbingEmergencyIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_CNST_PRMT', @level2type = N'COLUMN', @level2name = N'ERTH_DISTRB_EMRGCY_IND';

PRINT N'Creating Extended Property [dbo].[ICS_SW_CNST_PRMT].[PREVIOUS_SW_DSCH_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PreviousStormwaterDischargesIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_CNST_PRMT', @level2type = N'COLUMN', @level2name = N'PREVIOUS_SW_DSCH_IND';

PRINT N'Creating Extended Property [dbo].[ICS_SW_CNST_PRMT].[OTHR_PRMT_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'OtherPermitIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_CNST_PRMT', @level2type = N'COLUMN', @level2name = N'OTHR_PRMT_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_SW_CNST_PRMT].[CGP_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CGPIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_CNST_PRMT', @level2type = N'COLUMN', @level2name = N'CGP_IND';

PRINT N'Creating Extended Property [dbo].[ICS_SW_CNST_PRMT].[MS_4_DSCH_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4DischargeIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_CNST_PRMT', @level2type = N'COLUMN', @level2name = N'MS_4_DSCH_IND';

PRINT N'Creating Extended Property [dbo].[ICS_SW_CNST_PRMT].[WTR_PROX_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'WaterProximityIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_CNST_PRMT', @level2type = N'COLUMN', @level2name = N'WTR_PROX_IND';

PRINT N'Creating Extended Property [dbo].[ICS_SW_CNST_PRMT].[ANTIDEG_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'AntidegradationIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_CNST_PRMT', @level2type = N'COLUMN', @level2name = N'ANTIDEG_IND';

PRINT N'Creating Extended Property [dbo].[ICS_SW_CNST_PRMT].[TRTMNT_CHEMS_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TreatmentChemicalsIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_CNST_PRMT', @level2type = N'COLUMN', @level2name = N'TRTMNT_CHEMS_IND';

PRINT N'Creating Extended Property [dbo].[ICS_SW_CNST_PRMT].[CATIONIC_CHEMS_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CationicChemicalsIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_CNST_PRMT', @level2type = N'COLUMN', @level2name = N'CATIONIC_CHEMS_IND';

PRINT N'Creating Extended Property [dbo].[ICS_SW_CNST_PRMT].[CATIONIC_CHEMS_AUTH_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CationicChemicalsAuthorizationIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_CNST_PRMT', @level2type = N'COLUMN', @level2name = N'CATIONIC_CHEMS_AUTH_IND';

PRINT N'Creating Extended Property [dbo].[ICS_SW_CNST_PRMT].[SWPPP_PREP_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SWPPPPreparedIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_CNST_PRMT', @level2type = N'COLUMN', @level2name = N'SWPPP_PREP_IND';

PRINT N'Creating Extended Property [dbo].[ICS_SW_CNST_PRMT].[CNST_SITE_TTL_AREA].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ConstructionSiteTotalArea', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_CNST_PRMT', @level2type = N'COLUMN', @level2name = N'CNST_SITE_TTL_AREA';

PRINT N'Creating Extended Property [dbo].[ICS_SW_CNST_PRMT].[POST_CNST_TTL_IMPERVIOUS_AREA].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PostConstructionTotalImperviousArea', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_CNST_PRMT', @level2type = N'COLUMN', @level2name = N'POST_CNST_TTL_IMPERVIOUS_AREA';

PRINT N'Creating Extended Property [dbo].[ICS_SW_CNST_PRMT].[SOIL_FILL_MATERIAL_DESC_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SoilFillMaterialDescriptionText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_CNST_PRMT', @level2type = N'COLUMN', @level2name = N'SOIL_FILL_MATERIAL_DESC_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_SW_CNST_PRMT].[RUNOFF_COEFFICIENT_POST_CNST].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'RunoffCoefficientPostConstruction', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_CNST_PRMT', @level2type = N'COLUMN', @level2name = N'RUNOFF_COEFFICIENT_POST_CNST';

PRINT N'Creating Extended Property [dbo].[ICS_SW_CNST_PRMT].[SUBSURFACE_ERTH_DISTURBANCE_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SubsurfaceEarthDisturbanceIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_CNST_PRMT', @level2type = N'COLUMN', @level2name = N'SUBSURFACE_ERTH_DISTURBANCE_IND';

PRINT N'Creating Extended Property [dbo].[ICS_SW_CNST_PRMT].[PRIOR_SURVEYS_EVALS_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PriorSurveysEvaluationsIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_CNST_PRMT', @level2type = N'COLUMN', @level2name = N'PRIOR_SURVEYS_EVALS_IND';

PRINT N'Creating Extended Property [dbo].[ICS_SW_CNST_PRMT].[SUBSURFACE_ERTH_DISTURBANCE_CONTROL_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SubsurfaceEarthDisturbanceControlIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_CNST_PRMT', @level2type = N'COLUMN', @level2name = N'SUBSURFACE_ERTH_DISTURBANCE_CONTROL_IND';

PRINT N'Creating Extended Property [dbo].[ICS_SW_CNST_PRMT].[NOT_TERM_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'NOTTerminationDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_CNST_PRMT', @level2type = N'COLUMN', @level2name = N'NOT_TERM_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_SW_CNST_PRMT].[NOT_SIGN_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'NOTSignatureDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_CNST_PRMT', @level2type = N'COLUMN', @level2name = N'NOT_SIGN_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_SW_CNST_PRMT].[NOT_POSTMARK_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'NOTPostmarkDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_CNST_PRMT', @level2type = N'COLUMN', @level2name = N'NOT_POSTMARK_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_SW_CNST_PRMT].[NOT_RCVD_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'NOTReceivedDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_CNST_PRMT', @level2type = N'COLUMN', @level2name = N'NOT_RCVD_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_SW_CNST_PRMT].[LEW_AUTH_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'LEWAuthorizationDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_CNST_PRMT', @level2type = N'COLUMN', @level2name = N'LEW_AUTH_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_SW_INDST_PRMT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: SWIndustrialPermitData', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_INDST_PRMT';

PRINT N'Creating Extended Property [dbo].[ICS_SW_INDST_PRMT].[SRC_SYSTM_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SourceSystemIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_INDST_PRMT', @level2type = N'COLUMN', @level2name = N'SRC_SYSTM_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_SW_INDST_PRMT].[TRANSACTION_TYPE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TransactionType', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_INDST_PRMT', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TYPE';

PRINT N'Creating Extended Property [dbo].[ICS_SW_INDST_PRMT].[TRANSACTION_TIMESTAMP].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TransactionTimestamp', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_INDST_PRMT', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TIMESTAMP';

PRINT N'Creating Extended Property [dbo].[ICS_SW_INDST_PRMT].[PRMT_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermitIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_INDST_PRMT', @level2type = N'COLUMN', @level2name = N'PRMT_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_SW_INDST_PRMT].[ST_WTR_BODY_NAME].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'StateWaterBodyName', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_INDST_PRMT', @level2type = N'COLUMN', @level2name = N'ST_WTR_BODY_NAME';

PRINT N'Creating Extended Property [dbo].[ICS_SW_INDST_PRMT].[RCVG_MS_4_NAME].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ReceivingMS4Name', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_INDST_PRMT', @level2type = N'COLUMN', @level2name = N'RCVG_MS_4_NAME';

PRINT N'Creating Extended Property [dbo].[ICS_SW_INDST_PRMT].[IMPAIRED_WTR_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ImpairedWaterIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_INDST_PRMT', @level2type = N'COLUMN', @level2name = N'IMPAIRED_WTR_IND';

PRINT N'Creating Extended Property [dbo].[ICS_SW_INDST_PRMT].[HIST_PROP_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'HistoricPropertyIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_INDST_PRMT', @level2type = N'COLUMN', @level2name = N'HIST_PROP_IND';

PRINT N'Creating Extended Property [dbo].[ICS_SW_INDST_PRMT].[HIST_PROP_CRIT_MET_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'HistoricPropertyCriterionMetCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_INDST_PRMT', @level2type = N'COLUMN', @level2name = N'HIST_PROP_CRIT_MET_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_SW_INDST_PRMT].[SPECIES_CRIT_HABITAT_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SpeciesCriticalHabitatIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_INDST_PRMT', @level2type = N'COLUMN', @level2name = N'SPECIES_CRIT_HABITAT_IND';

PRINT N'Creating Extended Property [dbo].[ICS_SW_INDST_PRMT].[SPECIES_CRIT_MET_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SpeciesCriterionMetCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_INDST_PRMT', @level2type = N'COLUMN', @level2name = N'SPECIES_CRIT_MET_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_SW_INDST_PRMT].[INDST_ACTY_SIZE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'IndustrialActivitySize', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_INDST_PRMT', @level2type = N'COLUMN', @level2name = N'INDST_ACTY_SIZE';

PRINT N'Creating Extended Property [dbo].[ICS_SW_INDST_PRMT].[WEB_ADDR_URL].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'WebAddressURL', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_INDST_PRMT', @level2type = N'COLUMN', @level2name = N'WEB_ADDR_URL';

PRINT N'Creating Extended Property [dbo].[ICS_SW_INDST_PRMT].[ACTIVITIES_EXPOSED_SW_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ActivitiesExposedSWText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_INDST_PRMT', @level2type = N'COLUMN', @level2name = N'ACTIVITIES_EXPOSED_SW_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_SW_INDST_PRMT].[ASSC_POLLUTANTS_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'AssociatedPollutantsText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_INDST_PRMT', @level2type = N'COLUMN', @level2name = N'ASSC_POLLUTANTS_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_SW_INDST_PRMT].[CONTROL_MSR_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ControlMeasuresText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_INDST_PRMT', @level2type = N'COLUMN', @level2name = N'CONTROL_MSR_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_SW_INDST_PRMT].[SCHD_CONTROL_MSR_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ScheduleControlMeasuresText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_INDST_PRMT', @level2type = N'COLUMN', @level2name = N'SCHD_CONTROL_MSR_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_SW_INDST_PRMT].[INDST_TTL_IMPERVIOUS_SURF_AREA].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'IndustrialTotalImperviousSurfaceArea', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_INDST_PRMT', @level2type = N'COLUMN', @level2name = N'INDST_TTL_IMPERVIOUS_SURF_AREA';

PRINT N'Creating Extended Property [dbo].[ICS_SW_INDST_PRMT].[TIER_TWO_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TierTwoIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_INDST_PRMT', @level2type = N'COLUMN', @level2name = N'TIER_TWO_IND';

PRINT N'Creating Extended Property [dbo].[ICS_SW_INDST_PRMT].[TIER_THREE_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TierThreeIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SW_INDST_PRMT', @level2type = N'COLUMN', @level2name = N'TIER_THREE_IND';

PRINT N'Creating Extended Property [dbo].[ICS_TMDL_POLLUTANTS].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: TMDLPollutants', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_TMDL_POLLUTANTS';

PRINT N'Creating Extended Property [dbo].[ICS_TMDL_POLLUTANTS].[TMDL_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TMDLIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_TMDL_POLLUTANTS', @level2type = N'COLUMN', @level2name = N'TMDL_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_TMDL_POLLUTANTS].[TMDL_NAME].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TMDLName', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_TMDL_POLLUTANTS', @level2type = N'COLUMN', @level2name = N'TMDL_NAME';

PRINT N'Creating Extended Property [dbo].[ICS_UNPRMT_FAC].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: UnpermittedFacilityData', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_UNPRMT_FAC';

PRINT N'Creating Extended Property [dbo].[ICS_UNPRMT_FAC].[SRC_SYSTM_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SourceSystemIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_UNPRMT_FAC', @level2type = N'COLUMN', @level2name = N'SRC_SYSTM_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_UNPRMT_FAC].[TRANSACTION_TYPE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TransactionType', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_UNPRMT_FAC', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TYPE';

PRINT N'Creating Extended Property [dbo].[ICS_UNPRMT_FAC].[TRANSACTION_TIMESTAMP].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TransactionTimestamp', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_UNPRMT_FAC', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TIMESTAMP';

PRINT N'Creating Extended Property [dbo].[ICS_UNPRMT_FAC].[PRMT_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermitIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_UNPRMT_FAC', @level2type = N'COLUMN', @level2name = N'PRMT_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_UNPRMT_FAC].[LOCALITY_NAME].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'LocalityName', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_UNPRMT_FAC', @level2type = N'COLUMN', @level2name = N'LOCALITY_NAME';

PRINT N'Creating Extended Property [dbo].[ICS_UNPRMT_FAC].[LOC_ADDR_CITY_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'LocationAddressCityCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_UNPRMT_FAC', @level2type = N'COLUMN', @level2name = N'LOC_ADDR_CITY_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_UNPRMT_FAC].[LOC_ADDR_COUNTY_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'LocationAddressCountyCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_UNPRMT_FAC', @level2type = N'COLUMN', @level2name = N'LOC_ADDR_COUNTY_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_UNPRMT_FAC].[FAC_SITE_NAME].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'FacilitySiteName', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_UNPRMT_FAC', @level2type = N'COLUMN', @level2name = N'FAC_SITE_NAME';

PRINT N'Creating Extended Property [dbo].[ICS_UNPRMT_FAC].[LOC_ADDR_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'LocationAddressText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_UNPRMT_FAC', @level2type = N'COLUMN', @level2name = N'LOC_ADDR_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_UNPRMT_FAC].[SUPPL_LOC_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SupplementalLocationText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_UNPRMT_FAC', @level2type = N'COLUMN', @level2name = N'SUPPL_LOC_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_UNPRMT_FAC].[LOC_ST_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'LocationStateCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_UNPRMT_FAC', @level2type = N'COLUMN', @level2name = N'LOC_ST_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_UNPRMT_FAC].[LOC_ZIP_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'LocationZipCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_UNPRMT_FAC', @level2type = N'COLUMN', @level2name = N'LOC_ZIP_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_UNPRMT_FAC].[LOC_COUNTRY_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'LocationCountryCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_UNPRMT_FAC', @level2type = N'COLUMN', @level2name = N'LOC_COUNTRY_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_UNPRMT_FAC].[ORG_DUNS_NUM].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'OrganizationDUNSNumber', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_UNPRMT_FAC', @level2type = N'COLUMN', @level2name = N'ORG_DUNS_NUM';

PRINT N'Creating Extended Property [dbo].[ICS_UNPRMT_FAC].[ST_FAC_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'StateFacilityIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_UNPRMT_FAC', @level2type = N'COLUMN', @level2name = N'ST_FAC_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_UNPRMT_FAC].[ST_RGN_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'StateRegionCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_UNPRMT_FAC', @level2type = N'COLUMN', @level2name = N'ST_RGN_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_UNPRMT_FAC].[FAC_CONGR_DISTRICT_NUM].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'FacilityCongressionalDistrictNumber', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_UNPRMT_FAC', @level2type = N'COLUMN', @level2name = N'FAC_CONGR_DISTRICT_NUM';

PRINT N'Creating Extended Property [dbo].[ICS_UNPRMT_FAC].[FAC_TYPE_OF_OWNERSHIP_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'FacilityTypeOfOwnershipCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_UNPRMT_FAC', @level2type = N'COLUMN', @level2name = N'FAC_TYPE_OF_OWNERSHIP_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_UNPRMT_FAC].[FEDR_FAC_IDENT_NUM].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'FederalFacilityIdentificationNumber', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_UNPRMT_FAC', @level2type = N'COLUMN', @level2name = N'FEDR_FAC_IDENT_NUM';

PRINT N'Creating Extended Property [dbo].[ICS_UNPRMT_FAC].[FEDR_AGNCY_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'FederalAgencyCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_UNPRMT_FAC', @level2type = N'COLUMN', @level2name = N'FEDR_AGNCY_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_UNPRMT_FAC].[TRIBAL_LAND_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TribalLandCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_UNPRMT_FAC', @level2type = N'COLUMN', @level2name = N'TRIBAL_LAND_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_UNPRMT_FAC].[CNST_PROJ_NAME].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ConstructionProjectName', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_UNPRMT_FAC', @level2type = N'COLUMN', @level2name = N'CNST_PROJ_NAME';

PRINT N'Creating Extended Property [dbo].[ICS_UNPRMT_FAC].[CNST_PROJ_LAT_MEAS].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ConstructionProjectLatitudeMeasure', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_UNPRMT_FAC', @level2type = N'COLUMN', @level2name = N'CNST_PROJ_LAT_MEAS';

PRINT N'Creating Extended Property [dbo].[ICS_UNPRMT_FAC].[CNST_PROJ_LONG_MEAS].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ConstructionProjectLongitudeMeasure', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_UNPRMT_FAC', @level2type = N'COLUMN', @level2name = N'CNST_PROJ_LONG_MEAS';

PRINT N'Creating Extended Property [dbo].[ICS_UNPRMT_FAC].[SECTION_TOWNSHIP_RNG].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SectionTownshipRange', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_UNPRMT_FAC', @level2type = N'COLUMN', @level2name = N'SECTION_TOWNSHIP_RNG';

PRINT N'Creating Extended Property [dbo].[ICS_UNPRMT_FAC].[FAC_CMNTS].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'FacilityComments', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_UNPRMT_FAC', @level2type = N'COLUMN', @level2name = N'FAC_CMNTS';

PRINT N'Creating Extended Property [dbo].[ICS_UNPRMT_FAC].[FAC_USR_DFND_FLD_1].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'FacilityUserDefinedField1', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_UNPRMT_FAC', @level2type = N'COLUMN', @level2name = N'FAC_USR_DFND_FLD_1';

PRINT N'Creating Extended Property [dbo].[ICS_UNPRMT_FAC].[FAC_USR_DFND_FLD_2].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'FacilityUserDefinedField2', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_UNPRMT_FAC', @level2type = N'COLUMN', @level2name = N'FAC_USR_DFND_FLD_2';

PRINT N'Creating Extended Property [dbo].[ICS_UNPRMT_FAC].[FAC_USR_DFND_FLD_3].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'FacilityUserDefinedField3', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_UNPRMT_FAC', @level2type = N'COLUMN', @level2name = N'FAC_USR_DFND_FLD_3';

PRINT N'Creating Extended Property [dbo].[ICS_UNPRMT_FAC].[FAC_USR_DFND_FLD_4].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'FacilityUserDefinedField4', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_UNPRMT_FAC', @level2type = N'COLUMN', @level2name = N'FAC_USR_DFND_FLD_4';

PRINT N'Creating Extended Property [dbo].[ICS_UNPRMT_FAC].[FAC_USR_DFND_FLD_5].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'FacilityUserDefinedField5', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_UNPRMT_FAC', @level2type = N'COLUMN', @level2name = N'FAC_USR_DFND_FLD_5';

PRINT N'Creating Extended Property [dbo].[ICS_UNPRMT_FAC].[PRMT_CMNTS_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermitCommentsText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_UNPRMT_FAC', @level2type = N'COLUMN', @level2name = N'PRMT_CMNTS_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_VECTOR_A_REDUCTION_TYPE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: String', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_VECTOR_A_REDUCTION_TYPE';

PRINT N'Creating Extended Property [dbo].[ICS_VECTOR_A_REDUCTION_TYPE].[VECTOR_A_REDUCTION_TYPE_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'VectorAttractionReductionTypeCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_VECTOR_A_REDUCTION_TYPE', @level2type = N'COLUMN', @level2name = N'VECTOR_A_REDUCTION_TYPE_CODE';

PRINT N'Altering Extended Property [dbo].[ICS_TMDL_POLUT].[MS_Description]...';

EXECUTE sp_updateextendedproperty @name = N'MS_Description', @value = N'Schema element: CustomXmlStringFormatInt32', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_TMDL_POLUT';

PRINT N'Creating Extended Property [dbo].[ICS_BS_FAC_TRTMNT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: String', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_FAC_TRTMNT';

PRINT N'Creating Extended Property [dbo].[ICS_BS_FAC_TRTMNT].[BS_FAC_TRTMNT_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'BiosolidsFacilityTreatmentCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_FAC_TRTMNT', @level2type = N'COLUMN', @level2name = N'BS_FAC_TRTMNT_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_BS_FAC_TYPE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: String', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_FAC_TYPE';

PRINT N'Creating Extended Property [dbo].[ICS_BS_FAC_TYPE].[BS_FAC_TYPE_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'BiosolidsFacilityTypeCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_FAC_TYPE', @level2type = N'COLUMN', @level2name = N'BS_FAC_TYPE_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_BS_INCIN_EMISSIONS_CONTROL_TYPE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: BiosolidsIncineratorEmissionsControlType', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_INCIN_EMISSIONS_CONTROL_TYPE';

PRINT N'Creating Extended Property [dbo].[ICS_BS_INCIN_EMISSIONS_CONTROL_TYPE].[BS_EMISSIONS_CONTROL_CATG].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'BiosolidsEmissionsControlCatery', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_INCIN_EMISSIONS_CONTROL_TYPE', @level2type = N'COLUMN', @level2name = N'BS_EMISSIONS_CONTROL_CATG';

PRINT N'Creating Extended Property [dbo].[ICS_BS_INCIN_EMISSIONS_CONTROL_TYPE].[BS_EMISSIONS_CONTROL_TECHNOLOGY_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'BiosolidsEmissionsControlTechnologyCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_INCIN_EMISSIONS_CONTROL_TYPE', @level2type = N'COLUMN', @level2name = N'BS_EMISSIONS_CONTROL_TECHNOLOGY_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_BS_INCIN_EMISSIONS_CONTROL_TYPE].[BS_EMISSIONS_CONTROL_OTHR_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'BiosolidsEmissionsControlOtherText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_INCIN_EMISSIONS_CONTROL_TYPE', @level2type = N'COLUMN', @level2name = N'BS_EMISSIONS_CONTROL_OTHR_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_BS_INCINERATION].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: BiosolidsIncinerationData', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_INCINERATION';

PRINT N'Creating Extended Property [dbo].[ICS_BS_INCINERATION].[BS_INCIN_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'BiosolidsIncineratorIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_INCINERATION', @level2type = N'COLUMN', @level2name = N'BS_INCIN_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_BS_INCINERATION].[BS_INCIN_TYPE_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'BiosolidsIncineratorTypeCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_INCINERATION', @level2type = N'COLUMN', @level2name = N'BS_INCIN_TYPE_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_BS_INCINERATION].[BS_INCIN_OTHR_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'BiosolidsIncineratorOtherText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_INCINERATION', @level2type = N'COLUMN', @level2name = N'BS_INCIN_OTHR_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_BS_INCINERATION].[BS_INCIN_LAST_SIG_CHANGE_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'BiosolidsIncineratorLastSignificantChangeDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_INCINERATION', @level2type = N'COLUMN', @level2name = N'BS_INCIN_LAST_SIG_CHANGE_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_BS_INCINERATION].[BS_INCIN_NEW_POLUT_LMTS_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'BiosolidsIncineratorNewPollutantLimitsIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_INCINERATION', @level2type = N'COLUMN', @level2name = N'BS_INCIN_NEW_POLUT_LMTS_IND';

PRINT N'Creating Extended Property [dbo].[ICS_BS_MGMT_PRACTICE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: BiosolidsManagementPracticeData', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_MGMT_PRACTICE';

PRINT N'Creating Extended Property [dbo].[ICS_BS_MGMT_PRACTICE].[SSU_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SSUIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_MGMT_PRACTICE', @level2type = N'COLUMN', @level2name = N'SSU_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_BS_MGMT_PRACTICE].[BS_MGMT_PRACTICE_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'BiosolidsManagementPracticeCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_MGMT_PRACTICE', @level2type = N'COLUMN', @level2name = N'BS_MGMT_PRACTICE_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_BS_MGMT_PRACTICE].[BS_MGMT_PRACTICE_SUB_CATG_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'BiosolidsManagementPracticeSubCateryCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_MGMT_PRACTICE', @level2type = N'COLUMN', @level2name = N'BS_MGMT_PRACTICE_SUB_CATG_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_BS_MGMT_PRACTICE].[BS_MGMT_PRACTICE_SUB_CATG_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'BiosolidsManagementPracticeSubCateryText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_MGMT_PRACTICE', @level2type = N'COLUMN', @level2name = N'BS_MGMT_PRACTICE_SUB_CATG_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_BS_MGMT_PRACTICE].[BS_OPERATOR_TYPE_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'BiosolidsOperatorTypeCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_MGMT_PRACTICE', @level2type = N'COLUMN', @level2name = N'BS_OPERATOR_TYPE_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_BS_MGMT_PRACTICE].[BS_CNTNR_TYPE_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'BiosolidsContainerTypeCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_MGMT_PRACTICE', @level2type = N'COLUMN', @level2name = N'BS_CNTNR_TYPE_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_BS_MGMT_PRACTICE].[SSUID_VOL_AMT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SSUIDVolumeAmount', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_MGMT_PRACTICE', @level2type = N'COLUMN', @level2name = N'SSUID_VOL_AMT';

PRINT N'Creating Extended Property [dbo].[ICS_BS_MGMT_PRACTICE].[PATHOGEN_CLASS_TYPE_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PathogenClassTypeCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_MGMT_PRACTICE', @level2type = N'COLUMN', @level2name = N'PATHOGEN_CLASS_TYPE_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_BS_MGMT_PRACTICE].[POLUT_LOADING_RATES_EXCEEDANCE_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PollutantLoadingRatesExceedanceIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_MGMT_PRACTICE', @level2type = N'COLUMN', @level2name = N'POLUT_LOADING_RATES_EXCEEDANCE_IND';

PRINT N'Creating Extended Property [dbo].[ICS_BS_MGMT_PRACTICE].[BS_MGMT_PRACTICE_VIOL_TYPE_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'BiosolidsManagementPracticeViolationTypeCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_MGMT_PRACTICE', @level2type = N'COLUMN', @level2name = N'BS_MGMT_PRACTICE_VIOL_TYPE_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_BS_MGMT_PRACTICE].[BS_MGMT_PRACTICE_VIOL_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'BiosolidsManagementPracticeViolationText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_MGMT_PRACTICE', @level2type = N'COLUMN', @level2name = N'BS_MGMT_PRACTICE_VIOL_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_BS_MGMT_PRACTICE].[BS_OFF_SITE_FAC_PRMT_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'BiosolidsOffSiteFacilityPermitIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_MGMT_PRACTICE', @level2type = N'COLUMN', @level2name = N'BS_OFF_SITE_FAC_PRMT_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_BS_MGMT_PRACTICE].[SURF_DSPL_WITHOUT_LINER_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SurfaceDisposalWithoutLinerIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_MGMT_PRACTICE', @level2type = N'COLUMN', @level2name = N'SURF_DSPL_WITHOUT_LINER_IND';

PRINT N'Creating Extended Property [dbo].[ICS_BS_MGMT_PRACTICE].[SURF_DSPL_SITE_SPEC_LMT_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SurfaceDisposalSiteSpecificLimitIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_MGMT_PRACTICE', @level2type = N'COLUMN', @level2name = N'SURF_DSPL_SITE_SPEC_LMT_IND';

PRINT N'Creating Extended Property [dbo].[ICS_BS_MGMT_PRACTICE].[SURF_DSPL_MIN_BOUNDARY_DISTANCE_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SurfaceDisposalMinimumBoundaryDistanceCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_MGMT_PRACTICE', @level2type = N'COLUMN', @level2name = N'SURF_DSPL_MIN_BOUNDARY_DISTANCE_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: BiosolidsOffSiteHandlerApplierPreparer', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR';

PRINT N'Creating Extended Property [dbo].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR].[BS_OFF_SITE_HNDLR_APPLIER_VOL_AMT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'BiosolidsOffSiteHandlerApplierVolumeAmount', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR', @level2type = N'COLUMN', @level2name = N'BS_OFF_SITE_HNDLR_APPLIER_VOL_AMT';

PRINT N'Creating Extended Property [dbo].[ICS_BS_SEWAGE_SLDG_PARAM].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: BiosolidsSewageSludgeParameter', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_SEWAGE_SLDG_PARAM';

PRINT N'Creating Extended Property [dbo].[ICS_BS_SEWAGE_SLDG_PARAM].[BS_SEWAGE_SLDG_PARAM_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'BiosolidsSewageSludgeParameterCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_SEWAGE_SLDG_PARAM', @level2type = N'COLUMN', @level2name = N'BS_SEWAGE_SLDG_PARAM_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_BS_SEWAGE_SLDG_PARAM].[BS_SEWAGE_SLDG_PARAM_LMT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'BiosolidsSewageSludgeParameterLimit', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_SEWAGE_SLDG_PARAM', @level2type = N'COLUMN', @level2name = N'BS_SEWAGE_SLDG_PARAM_LMT';

PRINT N'Creating Extended Property [dbo].[ICS_BS_SEWAGE_SLDG_PARAM].[PARAM_VALUE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ParameterValue', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_SEWAGE_SLDG_PARAM', @level2type = N'COLUMN', @level2name = N'PARAM_VALUE';

PRINT N'Creating Extended Property [dbo].[ICS_BS_SEWAGE_SLDG_PARAM].[VALUE_QUALIFIER].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ValueQualifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_SEWAGE_SLDG_PARAM', @level2type = N'COLUMN', @level2name = N'VALUE_QUALIFIER';

PRINT N'Creating Extended Property [dbo].[ICS_BS_SEWAGE_SLDG_PARAM].[NO_DAT_IND_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'NoDataIndicatorCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_SEWAGE_SLDG_PARAM', @level2type = N'COLUMN', @level2name = N'NO_DAT_IND_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_BS_SEWAGE_SLDG_PARAM].[PASS_FAIL_IND_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PassFailIndicatorCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_SEWAGE_SLDG_PARAM', @level2type = N'COLUMN', @level2name = N'PASS_FAIL_IND_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_BS_SEWAGE_SLDG_PARAM].[PATHOGEN_REDUCTION_TYPE_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PathogenReductionTypeCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_SEWAGE_SLDG_PARAM', @level2type = N'COLUMN', @level2name = N'PATHOGEN_REDUCTION_TYPE_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_BS_SEWAGE_SLDG_PARAM].[BS_SMPL_START_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'BiosolidsSampleStartDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_SEWAGE_SLDG_PARAM', @level2type = N'COLUMN', @level2name = N'BS_SMPL_START_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_BS_SEWAGE_SLDG_PARAM].[BS_SMPL_END_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'BiosolidsSampleEndDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_SEWAGE_SLDG_PARAM', @level2type = N'COLUMN', @level2name = N'BS_SMPL_END_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_BS_SEWAGE_SLDG_PARAM].[BS_SMPL_MN].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'BiosolidsSampleMonth', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BS_SEWAGE_SLDG_PARAM', @level2type = N'COLUMN', @level2name = N'BS_SMPL_MN';

PRINT N'Creating Extended Property [dbo].[ICS_BYPASS_TRTMNT_PLANT_EQUIPMENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: String', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BYPASS_TRTMNT_PLANT_EQUIPMENT';

PRINT N'Creating Extended Property [dbo].[ICS_BYPASS_TRTMNT_PLANT_EQUIPMENT].[BYPASS_TRTMNT_PLANT_EQUIPMENT_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'BypassTreatmentPlantEquipmentCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_BYPASS_TRTMNT_PLANT_EQUIPMENT', @level2type = N'COLUMN', @level2name = N'BYPASS_TRTMNT_PLANT_EQUIPMENT_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_CAFO_ANNUL_PROG_REP].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: CAFOAnnualProgramReportData', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_ANNUL_PROG_REP';

PRINT N'Creating Extended Property [dbo].[ICS_CAFO_ANNUL_PROG_REP].[SRC_SYSTM_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SourceSystemIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_ANNUL_PROG_REP', @level2type = N'COLUMN', @level2name = N'SRC_SYSTM_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_CAFO_ANNUL_PROG_REP].[TRANSACTION_TYPE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TransactionType', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_ANNUL_PROG_REP', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TYPE';

PRINT N'Creating Extended Property [dbo].[ICS_CAFO_ANNUL_PROG_REP].[TRANSACTION_TIMESTAMP].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TransactionTimestamp', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_ANNUL_PROG_REP', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TIMESTAMP';

PRINT N'Creating Extended Property [dbo].[ICS_CAFO_ANNUL_PROG_REP].[PRMT_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermitIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_ANNUL_PROG_REP', @level2type = N'COLUMN', @level2name = N'PRMT_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_CAFO_ANNUL_PROG_REP].[PROG_REP_FORM_SET_ID].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ProgramReportFormSetID', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_ANNUL_PROG_REP', @level2type = N'COLUMN', @level2name = N'PROG_REP_FORM_SET_ID';

PRINT N'Creating Extended Property [dbo].[ICS_CAFO_ANNUL_PROG_REP].[PROG_REP_FORM_ID].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ProgramReportFormID', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_ANNUL_PROG_REP', @level2type = N'COLUMN', @level2name = N'PROG_REP_FORM_ID';

PRINT N'Creating Extended Property [dbo].[ICS_CAFO_ANNUL_PROG_REP].[PROG_REP_RCVD_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ProgramReportReceivedDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_ANNUL_PROG_REP', @level2type = N'COLUMN', @level2name = N'PROG_REP_RCVD_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_CAFO_ANNUL_PROG_REP].[PROG_REP_START_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ProgramReportStartDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_ANNUL_PROG_REP', @level2type = N'COLUMN', @level2name = N'PROG_REP_START_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_CAFO_ANNUL_PROG_REP].[PROG_REP_END_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ProgramReportEndDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_ANNUL_PROG_REP', @level2type = N'COLUMN', @level2name = N'PROG_REP_END_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_CAFO_ANNUL_PROG_REP].[ELEC_SUBM_TYPE_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ElectronicSubmissionTypeCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_ANNUL_PROG_REP', @level2type = N'COLUMN', @level2name = N'ELEC_SUBM_TYPE_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_CAFO_ANNUL_PROG_REP].[PROG_REP_NPDES_DAT_GRP_NUM_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ProgramReportNPDESDataGroupNumberCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_ANNUL_PROG_REP', @level2type = N'COLUMN', @level2name = N'PROG_REP_NPDES_DAT_GRP_NUM_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_CAFO_ANNUL_PROG_REP].[NUTR_MGMT_PLAN_ACREAGE_NUM].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'NutrientManagementPlanAcreageNumber', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_ANNUL_PROG_REP', @level2type = N'COLUMN', @level2name = N'NUTR_MGMT_PLAN_ACREAGE_NUM';

PRINT N'Creating Extended Property [dbo].[ICS_CAFO_ANNUL_PROG_REP].[ACTUL_LAND_APPL_ACREAGE_NUM].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ActualLandApplicationAcreageNumber', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_ANNUL_PROG_REP', @level2type = N'COLUMN', @level2name = N'ACTUL_LAND_APPL_ACREAGE_NUM';

PRINT N'Creating Extended Property [dbo].[ICS_CAFO_ANNUL_PROG_REP].[NMP_CERT_PLNR_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'NMPCertifiedPlannerIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_ANNUL_PROG_REP', @level2type = N'COLUMN', @level2name = N'NMP_CERT_PLNR_IND';

PRINT N'Creating Extended Property [dbo].[ICS_CAFO_LAND_APPL_FLD_INFO].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: CAFOLandApplicationFieldInformation', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_LAND_APPL_FLD_INFO';

PRINT N'Creating Extended Property [dbo].[ICS_CAFO_LAND_APPL_FLD_INFO].[CAFO_LAND_APPL_FLD_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CAFOLandApplicationFieldIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_LAND_APPL_FLD_INFO', @level2type = N'COLUMN', @level2name = N'CAFO_LAND_APPL_FLD_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_CAFO_LAND_APPL_FLD_INFO].[CAFO_LAND_APPL_FLD_ACREAGE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CAFOLandApplicationFieldAcreage', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_LAND_APPL_FLD_INFO', @level2type = N'COLUMN', @level2name = N'CAFO_LAND_APPL_FLD_ACREAGE';

PRINT N'Creating Extended Property [dbo].[ICS_CAFO_LAND_APPL_FLD_INFO].[CAFOMLPW_MAX_AMT_METHOD].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CAFOMLPWMaximumAmountMethod', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_LAND_APPL_FLD_INFO', @level2type = N'COLUMN', @level2name = N'CAFOMLPW_MAX_AMT_METHOD';

PRINT N'Creating Extended Property [dbo].[ICS_CAFO_LAND_APPL_FLD_INFO].[CAFO_LAND_APPL_FLD_CROP_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CAFOLandApplicationFieldCropIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_LAND_APPL_FLD_INFO', @level2type = N'COLUMN', @level2name = N'CAFO_LAND_APPL_FLD_CROP_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_CAFO_LAND_APPL_FLD_INFO].[CAFO_LAND_APPL_FLD_CROP_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CAFOLandApplicationFieldCropCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_LAND_APPL_FLD_INFO', @level2type = N'COLUMN', @level2name = N'CAFO_LAND_APPL_FLD_CROP_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_CAFO_LAND_APPL_FLD_INFO].[CAFO_LAND_APPL_FLD_CROP_YIELD].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CAFOLandApplicationFieldCropYield', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_LAND_APPL_FLD_INFO', @level2type = N'COLUMN', @level2name = N'CAFO_LAND_APPL_FLD_CROP_YIELD';

PRINT N'Creating Extended Property [dbo].[ICS_CAFO_LAND_APPL_FLD_INFO].[CAFO_LAND_APPL_FLD_CROP_YIELD_UNIT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CAFOLandApplicationFieldCropYieldUnit', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_LAND_APPL_FLD_INFO', @level2type = N'COLUMN', @level2name = N'CAFO_LAND_APPL_FLD_CROP_YIELD_UNIT';

PRINT N'Creating Extended Property [dbo].[ICS_CAFO_LAND_APPL_FLD_INFO].[CAFO_LAND_APPL_FLD_CROP_SEEDED].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CAFOLandApplicationFieldCropSeeded', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_LAND_APPL_FLD_INFO', @level2type = N'COLUMN', @level2name = N'CAFO_LAND_APPL_FLD_CROP_SEEDED';

PRINT N'Creating Extended Property [dbo].[ICS_CAFO_LAND_APPL_FLD_INFO].[CAFO_SOIL_MON_MEAS_FORM].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CAFOSoilMonitoringMeasurementForm', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_LAND_APPL_FLD_INFO', @level2type = N'COLUMN', @level2name = N'CAFO_SOIL_MON_MEAS_FORM';

PRINT N'Creating Extended Property [dbo].[ICS_CAFO_LAND_APPL_FLD_INFO].[CAFO_SOIL_MON_MEAS_VALUE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CAFOSoilMonitoringMeasurementValue', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_LAND_APPL_FLD_INFO', @level2type = N'COLUMN', @level2name = N'CAFO_SOIL_MON_MEAS_VALUE';

PRINT N'Creating Extended Property [dbo].[ICS_CAFO_LAND_APPL_FLD_INFO].[CAFO_SOIL_MON_MEAS_VALUE_UNIT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CAFOSoilMonitoringMeasurementValueUnit', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_LAND_APPL_FLD_INFO', @level2type = N'COLUMN', @level2name = N'CAFO_SOIL_MON_MEAS_VALUE_UNIT';

PRINT N'Creating Extended Property [dbo].[ICS_CAFO_LAND_APPL_FLD_INFO].[CAFO_SOIL_MON_ANLYTCL_METHOD].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CAFOSoilMonitoringAnalyticalMethod', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_LAND_APPL_FLD_INFO', @level2type = N'COLUMN', @level2name = N'CAFO_SOIL_MON_ANLYTCL_METHOD';

PRINT N'Creating Extended Property [dbo].[ICS_CAFO_LAND_APPL_FLD_INFO].[CAFO_SOIL_MON_SMPL_DEPTH_INCHES].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CAFOSoilMonitoringSampleDepthInches', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_LAND_APPL_FLD_INFO', @level2type = N'COLUMN', @level2name = N'CAFO_SOIL_MON_SMPL_DEPTH_INCHES';

PRINT N'Creating Extended Property [dbo].[ICS_CAFO_LAND_APPL_FLD_INFO].[CAFO_SOIL_MON_SMPL_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CAFOSoilMonitoringSampleDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_LAND_APPL_FLD_INFO', @level2type = N'COLUMN', @level2name = N'CAFO_SOIL_MON_SMPL_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_CAFO_LAND_APPL_FLD_INFO].[CAFO_SUPPL_FERTILIZER_MEAS_FORM].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CAFOSupplementalFertilizerMeasurementForm', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_LAND_APPL_FLD_INFO', @level2type = N'COLUMN', @level2name = N'CAFO_SUPPL_FERTILIZER_MEAS_FORM';

PRINT N'Creating Extended Property [dbo].[ICS_CAFO_LAND_APPL_FLD_INFO].[CAFO_SUPPL_FERTILIZER_MEAS_VALUE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CAFOSupplementalFertilizerMeasurementValue', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_LAND_APPL_FLD_INFO', @level2type = N'COLUMN', @level2name = N'CAFO_SUPPL_FERTILIZER_MEAS_VALUE';

PRINT N'Creating Extended Property [dbo].[ICS_CAFO_LAND_APPL_FLD_INFO].[CAFO_SUPPL_FERTILIZER_MEAS_VALUE_UNIT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CAFOSupplementalFertilizerMeasurementValueUnit', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_LAND_APPL_FLD_INFO', @level2type = N'COLUMN', @level2name = N'CAFO_SUPPL_FERTILIZER_MEAS_VALUE_UNIT';

PRINT N'Creating Extended Property [dbo].[ICS_CAFO_PROD_AREA_DSCH].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: CAFOProductionAreaDischarge', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_PROD_AREA_DSCH';

PRINT N'Creating Extended Property [dbo].[ICS_CAFO_PROD_AREA_DSCH].[CAFO_PROD_AREA_DSCH_DISCOVERY_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CAFOProductionAreaDischargeDiscoveryDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_PROD_AREA_DSCH', @level2type = N'COLUMN', @level2name = N'CAFO_PROD_AREA_DSCH_DISCOVERY_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_CAFO_PROD_AREA_DSCH].[CAFO_PROD_AREA_DSCH_24HR_RAIN_EVT_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CAFOProductionAreaDischarge24hrRainEventIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_PROD_AREA_DSCH', @level2type = N'COLUMN', @level2name = N'CAFO_PROD_AREA_DSCH_24HR_RAIN_EVT_IND';

PRINT N'Creating Extended Property [dbo].[ICS_CAFO_PROD_AREA_DSCH].[CAFO_PROD_AREA_DSCH_DURATION_HOURS].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CAFOProductionAreaDischargeDurationHours', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_PROD_AREA_DSCH', @level2type = N'COLUMN', @level2name = N'CAFO_PROD_AREA_DSCH_DURATION_HOURS';

PRINT N'Creating Extended Property [dbo].[ICS_CAFO_PROD_AREA_DSCH].[CAFO_PROD_AREA_DSCH_VOL_GAL].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CAFOProductionAreaDischargeVolumeGallons', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFO_PROD_AREA_DSCH', @level2type = N'COLUMN', @level2name = N'CAFO_PROD_AREA_DSCH_VOL_GAL';

PRINT N'Creating Extended Property [dbo].[ICS_CAFOMLPW_FLD_AMOUNTS].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: CAFOMLPWFieldAmounts', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFOMLPW_FLD_AMOUNTS';

PRINT N'Creating Extended Property [dbo].[ICS_CAFOMLPW_FLD_AMOUNTS].[CAFOMLPW_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CAFOMLPWCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFOMLPW_FLD_AMOUNTS', @level2type = N'COLUMN', @level2name = N'CAFOMLPW_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_CAFOMLPW_FLD_AMOUNTS].[CAFOMLPW_FLD_MAX_ALLOWABLE_AMT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CAFOMLPWFieldMaxAllowableAmount', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFOMLPW_FLD_AMOUNTS', @level2type = N'COLUMN', @level2name = N'CAFOMLPW_FLD_MAX_ALLOWABLE_AMT';

PRINT N'Creating Extended Property [dbo].[ICS_CAFOMLPW_FLD_AMOUNTS].[CAFOMLPW_FLD_ACTUL_AMT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CAFOMLPWFieldActualAmount', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFOMLPW_FLD_AMOUNTS', @level2type = N'COLUMN', @level2name = N'CAFOMLPW_FLD_ACTUL_AMT';

PRINT N'Creating Extended Property [dbo].[ICS_CAFOMLPW_FLD_AMOUNTS].[CAFOMLPW_LAND_APPL_UNIT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CAFOMLPWLandApplicationUnit', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFOMLPW_FLD_AMOUNTS', @level2type = N'COLUMN', @level2name = N'CAFOMLPW_LAND_APPL_UNIT';

PRINT N'Creating Extended Property [dbo].[ICS_CAFOMLPW_NUTR_MON].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: CAFOMLPWNutrientMonitoring', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFOMLPW_NUTR_MON';

PRINT N'Creating Extended Property [dbo].[ICS_CAFOMLPW_NUTR_MON].[CAFOMLPW_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CAFOMLPWCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFOMLPW_NUTR_MON', @level2type = N'COLUMN', @level2name = N'CAFOMLPW_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_CAFOMLPW_NUTR_MON].[CAFOMLPW_NUTR_FORM].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CAFOMLPWNutrientForm', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFOMLPW_NUTR_MON', @level2type = N'COLUMN', @level2name = N'CAFOMLPW_NUTR_FORM';

PRINT N'Creating Extended Property [dbo].[ICS_CAFOMLPW_NUTR_MON].[CAFOMLPW_NUTR_VALUE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CAFOMLPWNutrientValue', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFOMLPW_NUTR_MON', @level2type = N'COLUMN', @level2name = N'CAFOMLPW_NUTR_VALUE';

PRINT N'Creating Extended Property [dbo].[ICS_CAFOMLPW_NUTR_MON].[CAFOMLPW_NUTR_VALUE_UNIT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CAFOMLPWNutrientValueUnit', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFOMLPW_NUTR_MON', @level2type = N'COLUMN', @level2name = N'CAFOMLPW_NUTR_VALUE_UNIT';

PRINT N'Creating Extended Property [dbo].[ICS_CAFOMLPW_TTL_AMOUNTS].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: CAFOMLPWTotalAmounts', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFOMLPW_TTL_AMOUNTS';

PRINT N'Creating Extended Property [dbo].[ICS_CAFOMLPW_TTL_AMOUNTS].[CAFOMLPW_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CAFOMLPWCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFOMLPW_TTL_AMOUNTS', @level2type = N'COLUMN', @level2name = N'CAFOMLPW_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_CAFOMLPW_TTL_AMOUNTS].[CAFOMLPW_AMT_GNRTD].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CAFOMLPWAmountGenerated', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFOMLPW_TTL_AMOUNTS', @level2type = N'COLUMN', @level2name = N'CAFOMLPW_AMT_GNRTD';

PRINT N'Creating Extended Property [dbo].[ICS_CAFOMLPW_TTL_AMOUNTS].[CAFOMLPW_AMT_TRANSFERRED].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CAFOMLPWAmountTransferred', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFOMLPW_TTL_AMOUNTS', @level2type = N'COLUMN', @level2name = N'CAFOMLPW_AMT_TRANSFERRED';

PRINT N'Creating Extended Property [dbo].[ICS_CAFOMLPW_TTL_AMOUNTS].[CAFOMLPW_UNIT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CAFOMLPWUnit', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CAFOMLPW_TTL_AMOUNTS', @level2type = N'COLUMN', @level2name = N'CAFOMLPW_UNIT';

PRINT N'Creating Extended Property [dbo].[ICS_CMPL_MON_EVT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: ComplianceMonitoringEventData', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CMPL_MON_EVT';

PRINT N'Creating Extended Property [dbo].[ICS_CMPL_MON_EVT].[CMPL_MON_EVT_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ComplianceMonitoringEventIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CMPL_MON_EVT', @level2type = N'COLUMN', @level2name = N'CMPL_MON_EVT_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_CMPL_MON_EVT].[CMPL_MON_EVT_START_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ComplianceMonitoringEventStartDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CMPL_MON_EVT', @level2type = N'COLUMN', @level2name = N'CMPL_MON_EVT_START_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_CMPL_MON_EVT].[CMPL_MON_EVT_END_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ComplianceMonitoringEventEndDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CMPL_MON_EVT', @level2type = N'COLUMN', @level2name = N'CMPL_MON_EVT_END_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_CNST_SITE_LIST].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: ConstructionSiteList', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CNST_SITE_LIST';

PRINT N'Creating Extended Property [dbo].[ICS_CNST_SITE_LIST].[CNST_SITE_OTHR_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ConstructionSiteOtherText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CNST_SITE_LIST', @level2type = N'COLUMN', @level2name = N'CNST_SITE_OTHR_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_COLL_SYSTM_PRMT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: CollectionSystemPermitData', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_COLL_SYSTM_PRMT';

PRINT N'Creating Extended Property [dbo].[ICS_COLL_SYSTM_PRMT].[SRC_SYSTM_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SourceSystemIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_COLL_SYSTM_PRMT', @level2type = N'COLUMN', @level2name = N'SRC_SYSTM_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_COLL_SYSTM_PRMT].[TRANSACTION_TYPE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TransactionType', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_COLL_SYSTM_PRMT', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TYPE';

PRINT N'Creating Extended Property [dbo].[ICS_COLL_SYSTM_PRMT].[TRANSACTION_TIMESTAMP].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TransactionTimestamp', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_COLL_SYSTM_PRMT', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TIMESTAMP';

PRINT N'Creating Extended Property [dbo].[ICS_COLL_SYSTM_PRMT].[PRMT_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermitIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_COLL_SYSTM_PRMT', @level2type = N'COLUMN', @level2name = N'PRMT_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_COLL_SYSTM_PRMT].[COLL_SYSTM_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CollectionSystemIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_COLL_SYSTM_PRMT', @level2type = N'COLUMN', @level2name = N'COLL_SYSTM_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_COLL_SYSTM_PRMT].[COLL_SYSTM_NAME].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CollectionSystemName', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_COLL_SYSTM_PRMT', @level2type = N'COLUMN', @level2name = N'COLL_SYSTM_NAME';

PRINT N'Creating Extended Property [dbo].[ICS_COLL_SYSTM_PRMT].[COLL_SYSTM_OWNER_TYPE_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CollectionSystemOwnerTypeCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_COLL_SYSTM_PRMT', @level2type = N'COLUMN', @level2name = N'COLL_SYSTM_OWNER_TYPE_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_COLL_SYSTM_PRMT].[COLL_SYSTM_POPL].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CollectionSystemPopulation', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_COLL_SYSTM_PRMT', @level2type = N'COLUMN', @level2name = N'COLL_SYSTM_POPL';

PRINT N'Creating Extended Property [dbo].[ICS_COLL_SYSTM_PRMT].[PERCENT_COLL_SYSTM_CSS].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PercentCollectionSystemCSS', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_COLL_SYSTM_PRMT', @level2type = N'COLUMN', @level2name = N'PERCENT_COLL_SYSTM_CSS';

PRINT N'Creating Extended Property [dbo].[ICS_CONTROL_AUTH_PROG_INFO].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: ControlAuthorityProgramInformation', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CONTROL_AUTH_PROG_INFO';

PRINT N'Creating Extended Property [dbo].[ICS_CONTROL_AUTH_PROG_INFO].[LOC_LMTS_ADOPTION_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'LocalLimitsAdoptionDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CONTROL_AUTH_PROG_INFO', @level2type = N'COLUMN', @level2name = N'LOC_LMTS_ADOPTION_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_CONTROL_AUTH_PROG_INFO].[LOC_LMTS_EVAL_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'LocalLimitsEvaluationDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CONTROL_AUTH_PROG_INFO', @level2type = N'COLUMN', @level2name = N'LOC_LMTS_EVAL_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_CONTROL_AUTH_PROG_INFO].[POTW_DSCH_CONTAMINATION_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'POTWDischargeContaminationIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CONTROL_AUTH_PROG_INFO', @level2type = N'COLUMN', @level2name = N'POTW_DSCH_CONTAMINATION_IND';

PRINT N'Creating Extended Property [dbo].[ICS_CONTROL_AUTH_PROG_INFO].[POTW_DSCH_CONTAMINATION_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'POTWDischargeContaminationText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CONTROL_AUTH_PROG_INFO', @level2type = N'COLUMN', @level2name = N'POTW_DSCH_CONTAMINATION_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_CONTROL_AUTH_PROG_INFO].[POTW_BS_CONTAMINATION_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'POTWBiosolidsContaminationIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CONTROL_AUTH_PROG_INFO', @level2type = N'COLUMN', @level2name = N'POTW_BS_CONTAMINATION_IND';

PRINT N'Creating Extended Property [dbo].[ICS_CONTROL_AUTH_PROG_INFO].[POTW_BS_CONTAMINATION_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'POTWBiosolidsContaminationText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CONTROL_AUTH_PROG_INFO', @level2type = N'COLUMN', @level2name = N'POTW_BS_CONTAMINATION_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_COOLING_WTR_INTAKE_STRCT_CMPL_METHOD].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: CoolingWaterIntakeStructureComplianceMethod', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_COOLING_WTR_INTAKE_STRCT_CMPL_METHOD';

PRINT N'Creating Extended Property [dbo].[ICS_COOLING_WTR_INTAKE_STRCT_CMPL_METHOD].[COOLING_WTR_INTAKE_STRCT_CMPL_METHOD_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CoolingWaterIntakeStructureComplianceMethodCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_COOLING_WTR_INTAKE_STRCT_CMPL_METHOD', @level2type = N'COLUMN', @level2name = N'COOLING_WTR_INTAKE_STRCT_CMPL_METHOD_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_COOLING_WTR_INTAKE_STRCT_CMPL_METHOD].[COOLING_WTR_INTAKE_STRCT_CMPL_METHOD_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CoolingWaterIntakeStructureComplianceMethodText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_COOLING_WTR_INTAKE_STRCT_CMPL_METHOD', @level2type = N'COLUMN', @level2name = N'COOLING_WTR_INTAKE_STRCT_CMPL_METHOD_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_COOLING_WTR_INTAKE_STRCT_INFO].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: CoolingWaterIntakeStructureInformation', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_COOLING_WTR_INTAKE_STRCT_INFO';

PRINT N'Creating Extended Property [dbo].[ICS_COOLING_WTR_INTAKE_STRCT_INFO].[COOLING_WTR_INTAKE_STRCT_APPL_SUBPART].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CoolingWaterIntakeStructureApplicableSubpart', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_COOLING_WTR_INTAKE_STRCT_INFO', @level2type = N'COLUMN', @level2name = N'COOLING_WTR_INTAKE_STRCT_APPL_SUBPART';

PRINT N'Creating Extended Property [dbo].[ICS_COOLING_WTR_INTAKE_STRCT_INFO].[COOLING_WTR_INTAKE_STRCT_DSGN_INTAKE_FLOW].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CoolingWaterIntakeStructureDesignIntakeFlow', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_COOLING_WTR_INTAKE_STRCT_INFO', @level2type = N'COLUMN', @level2name = N'COOLING_WTR_INTAKE_STRCT_DSGN_INTAKE_FLOW';

PRINT N'Creating Extended Property [dbo].[ICS_COOLING_WTR_INTAKE_STRCT_INFO].[COOLING_WTR_INTAKE_STRCT_ACTUL_INTAKE_FLOW].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CoolingWaterIntakeStructureActualIntakeFlow', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_COOLING_WTR_INTAKE_STRCT_INFO', @level2type = N'COLUMN', @level2name = N'COOLING_WTR_INTAKE_STRCT_ACTUL_INTAKE_FLOW';

PRINT N'Creating Extended Property [dbo].[ICS_COOLING_WTR_INTAKE_STRCT_INFO].[COOLING_WTR_ACTUL_INTAKE_STRCT_VELOCITY].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CoolingWaterActualIntakeStructureVelocity', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_COOLING_WTR_INTAKE_STRCT_INFO', @level2type = N'COLUMN', @level2name = N'COOLING_WTR_ACTUL_INTAKE_STRCT_VELOCITY';

PRINT N'Creating Extended Property [dbo].[ICS_COOLING_WTR_INTAKE_STRCT_INFO].[SRC_WTR_BASELINE_BIOLOGICAL_CHARACTERIZATION].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SourceWaterBaselineBiologicalCharacterization', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_COOLING_WTR_INTAKE_STRCT_INFO', @level2type = N'COLUMN', @level2name = N'SRC_WTR_BASELINE_BIOLOGICAL_CHARACTERIZATION';

PRINT N'Creating Extended Property [dbo].[ICS_COOLING_WTR_INTAKE_STRCT_INFO].[COOLING_WTR_INTAKE_STRCT_LOC_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CoolingWaterIntakeStructureLocationCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_COOLING_WTR_INTAKE_STRCT_INFO', @level2type = N'COLUMN', @level2name = N'COOLING_WTR_INTAKE_STRCT_LOC_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_COOLING_WTR_INTAKE_STRCT_INFO].[COOLING_WTR_INTAKE_STRCT_LOC_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CoolingWaterIntakeStructureLocationText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_COOLING_WTR_INTAKE_STRCT_INFO', @level2type = N'COLUMN', @level2name = N'COOLING_WTR_INTAKE_STRCT_LOC_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_COOLING_WTR_INTAKE_STRCT_INFO].[COOLING_WTR_INTAKE_STRCT_SRC_WTR_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CoolingWaterIntakeStructureSourceWaterCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_COOLING_WTR_INTAKE_STRCT_INFO', @level2type = N'COLUMN', @level2name = N'COOLING_WTR_INTAKE_STRCT_SRC_WTR_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_COOLING_WTR_INTAKE_STRCT_INFO].[COOLING_WTR_INTAKE_STRCT_SRC_WTR_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CoolingWaterIntakeStructureSourceWaterText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_COOLING_WTR_INTAKE_STRCT_INFO', @level2type = N'COLUMN', @level2name = N'COOLING_WTR_INTAKE_STRCT_SRC_WTR_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_COPY_MGPMS_4_REQ].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: CopyMGPMS4RequirementData', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_COPY_MGPMS_4_REQ';

PRINT N'Creating Extended Property [dbo].[ICS_COPY_MGPMS_4_REQ].[SRC_SYSTM_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SourceSystemIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_COPY_MGPMS_4_REQ', @level2type = N'COLUMN', @level2name = N'SRC_SYSTM_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_COPY_MGPMS_4_REQ].[PRMT_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermitIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_COPY_MGPMS_4_REQ', @level2type = N'COLUMN', @level2name = N'PRMT_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_COPY_MGPMS_4_REQ].[TRANSACTION_TYPE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TransactionType', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_COPY_MGPMS_4_REQ', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TYPE';

PRINT N'Creating Extended Property [dbo].[ICS_COPY_MGPMS_4_REQ].[TRANSACTION_TIMESTAMP].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TransactionTimestamp', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_COPY_MGPMS_4_REQ', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TIMESTAMP';

PRINT N'Creating Extended Property [dbo].[ICS_CSO_CONTROL_MEAS_DETAIL].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: CSOControlMeasureDetail', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CSO_CONTROL_MEAS_DETAIL';

PRINT N'Creating Extended Property [dbo].[ICS_CSO_CONTROL_MEAS_DETAIL].[CSO_CONTROL_MEAS_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CSOControlMeasureCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CSO_CONTROL_MEAS_DETAIL', @level2type = N'COLUMN', @level2name = N'CSO_CONTROL_MEAS_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_CSO_CONTROL_MEAS_DETAIL].[CSO_CONTROL_MEAS_CODE_OTHR_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CSOControlMeasureCodeOtherText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CSO_CONTROL_MEAS_DETAIL', @level2type = N'COLUMN', @level2name = N'CSO_CONTROL_MEAS_CODE_OTHR_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_CSO_CONTROL_MEAS_DETAIL].[CSO_CONTROL_MEAS_DEV_IMP_STAT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CSOControlMeasureDevImpStatus', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CSO_CONTROL_MEAS_DETAIL', @level2type = N'COLUMN', @level2name = N'CSO_CONTROL_MEAS_DEV_IMP_STAT';

PRINT N'Creating Extended Property [dbo].[ICS_CSO_CONTROL_MEAS_DETAIL].[CSO_CONTROL_MEAS_CMPL_STAT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CSOControlMeasureComplianceStatus', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CSO_CONTROL_MEAS_DETAIL', @level2type = N'COLUMN', @level2name = N'CSO_CONTROL_MEAS_CMPL_STAT';

PRINT N'Creating Extended Property [dbo].[ICS_CSO_LONG_TERM_CONTROL_PLAN].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: CSOLongTermControlPlanData', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CSO_LONG_TERM_CONTROL_PLAN';

PRINT N'Creating Extended Property [dbo].[ICS_CSO_LONG_TERM_CONTROL_PLAN].[SRC_SYSTM_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SourceSystemIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CSO_LONG_TERM_CONTROL_PLAN', @level2type = N'COLUMN', @level2name = N'SRC_SYSTM_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_CSO_LONG_TERM_CONTROL_PLAN].[TRANSACTION_TYPE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TransactionType', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CSO_LONG_TERM_CONTROL_PLAN', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TYPE';

PRINT N'Creating Extended Property [dbo].[ICS_CSO_LONG_TERM_CONTROL_PLAN].[TRANSACTION_TIMESTAMP].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TransactionTimestamp', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CSO_LONG_TERM_CONTROL_PLAN', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TIMESTAMP';

PRINT N'Creating Extended Property [dbo].[ICS_CSO_LONG_TERM_CONTROL_PLAN].[PRMT_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermitIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CSO_LONG_TERM_CONTROL_PLAN', @level2type = N'COLUMN', @level2name = N'PRMT_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_CWA_316B_PROG_REP].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: CWA316bProgramReportData', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CWA_316B_PROG_REP';

PRINT N'Creating Extended Property [dbo].[ICS_CWA_316B_PROG_REP].[SRC_SYSTM_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SourceSystemIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CWA_316B_PROG_REP', @level2type = N'COLUMN', @level2name = N'SRC_SYSTM_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_CWA_316B_PROG_REP].[TRANSACTION_TYPE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TransactionType', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CWA_316B_PROG_REP', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TYPE';

PRINT N'Creating Extended Property [dbo].[ICS_CWA_316B_PROG_REP].[TRANSACTION_TIMESTAMP].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TransactionTimestamp', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CWA_316B_PROG_REP', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TIMESTAMP';

PRINT N'Creating Extended Property [dbo].[ICS_CWA_316B_PROG_REP].[PRMT_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermitIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CWA_316B_PROG_REP', @level2type = N'COLUMN', @level2name = N'PRMT_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_CWA_316B_PROG_REP].[PROG_REP_FORM_SET_ID].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ProgramReportFormSetID', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CWA_316B_PROG_REP', @level2type = N'COLUMN', @level2name = N'PROG_REP_FORM_SET_ID';

PRINT N'Creating Extended Property [dbo].[ICS_CWA_316B_PROG_REP].[PROG_REP_FORM_ID].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ProgramReportFormID', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CWA_316B_PROG_REP', @level2type = N'COLUMN', @level2name = N'PROG_REP_FORM_ID';

PRINT N'Creating Extended Property [dbo].[ICS_CWA_316B_PROG_REP].[PROG_REP_RCVD_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ProgramReportReceivedDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CWA_316B_PROG_REP', @level2type = N'COLUMN', @level2name = N'PROG_REP_RCVD_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_CWA_316B_PROG_REP].[PROG_REP_START_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ProgramReportStartDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CWA_316B_PROG_REP', @level2type = N'COLUMN', @level2name = N'PROG_REP_START_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_CWA_316B_PROG_REP].[PROG_REP_END_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ProgramReportEndDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CWA_316B_PROG_REP', @level2type = N'COLUMN', @level2name = N'PROG_REP_END_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_CWA_316B_PROG_REP].[ELEC_SUBM_TYPE_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ElectronicSubmissionTypeCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CWA_316B_PROG_REP', @level2type = N'COLUMN', @level2name = N'ELEC_SUBM_TYPE_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_CWA_316B_PROG_REP].[PROG_REP_NPDES_DAT_GRP_NUM_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ProgramReportNPDESDataGroupNumberCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CWA_316B_PROG_REP', @level2type = N'COLUMN', @level2name = N'PROG_REP_NPDES_DAT_GRP_NUM_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_CWA_316B_PROG_REP].[CWA_316B_CRIT_HABITAT_PROTECTION_MSR].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CWA316bCriticalHabitatProtectionMeasures', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CWA_316B_PROG_REP', @level2type = N'COLUMN', @level2name = N'CWA_316B_CRIT_HABITAT_PROTECTION_MSR';

PRINT N'Creating Extended Property [dbo].[ICS_CWA_316B_PROG_REP].[CWA_316B_OTHR_MON_INFO].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CWA316bOtherMonitoringInformation', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CWA_316B_PROG_REP', @level2type = N'COLUMN', @level2name = N'CWA_316B_OTHR_MON_INFO';

PRINT N'Creating Extended Property [dbo].[ICS_CWA_316B_TAKE_INFO].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: CWA316bTakeInformation', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CWA_316B_TAKE_INFO';

PRINT N'Creating Extended Property [dbo].[ICS_CWA_316B_TAKE_INFO].[CWA_316B_TAKE_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CWA316bTakeIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CWA_316B_TAKE_INFO', @level2type = N'COLUMN', @level2name = N'CWA_316B_TAKE_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_CWA_316B_TAKE_INFO].[CWA_316B_SPECIES_NAME].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CWA316bSpeciesName', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CWA_316B_TAKE_INFO', @level2type = N'COLUMN', @level2name = N'CWA_316B_SPECIES_NAME';

PRINT N'Creating Extended Property [dbo].[ICS_CWA_316B_TAKE_INFO].[CWA_316B_SPECIES_COMMON_NAME].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CWA316bSpeciesCommonName', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CWA_316B_TAKE_INFO', @level2type = N'COLUMN', @level2name = N'CWA_316B_SPECIES_COMMON_NAME';

PRINT N'Creating Extended Property [dbo].[ICS_CWA_316B_TAKE_INFO].[CWA_316B_FEDR_STAT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CWA316bFederalStatus', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CWA_316B_TAKE_INFO', @level2type = N'COLUMN', @level2name = N'CWA_316B_FEDR_STAT';

PRINT N'Creating Extended Property [dbo].[ICS_CWA_316B_TAKE_INFO].[CWA_316B_LIFESTAGE_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CWA316bLifestageCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CWA_316B_TAKE_INFO', @level2type = N'COLUMN', @level2name = N'CWA_316B_LIFESTAGE_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_CWA_316B_TAKE_INFO].[CWA_316B_TAKE_METHOD_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CWA316bTakeMethodCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CWA_316B_TAKE_INFO', @level2type = N'COLUMN', @level2name = N'CWA_316B_TAKE_METHOD_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_CWA_316B_TAKE_INFO].[CWA_316B_TAKE_METHOD_OTHR_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CWA316bTakeMethodOtherText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CWA_316B_TAKE_INFO', @level2type = N'COLUMN', @level2name = N'CWA_316B_TAKE_METHOD_OTHR_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_CWA_316B_TAKE_INFO].[CWA_316B_TAKE_TYPE_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CWA316bTakeTypeCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CWA_316B_TAKE_INFO', @level2type = N'COLUMN', @level2name = N'CWA_316B_TAKE_TYPE_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_CWA_316B_TAKE_INFO].[CWA_316B_TAKE_TYPE_OTHR_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CWA316bTakeTypeOtherText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CWA_316B_TAKE_INFO', @level2type = N'COLUMN', @level2name = N'CWA_316B_TAKE_TYPE_OTHR_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_CWA_316B_TAKE_INFO].[CWA_316B_SPECIES_NUM].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CWA316bSpeciesNumber', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CWA_316B_TAKE_INFO', @level2type = N'COLUMN', @level2name = N'CWA_316B_SPECIES_NUM';

PRINT N'Creating Extended Property [dbo].[ICS_CWA_316B_TAKE_INFO].[CWA_316B_SPECIES_NUM_IMPINGED_ENTRAINED].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CWA316bSpeciesNumberImpingedEntrained', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CWA_316B_TAKE_INFO', @level2type = N'COLUMN', @level2name = N'CWA_316B_SPECIES_NUM_IMPINGED_ENTRAINED';

PRINT N'Creating Extended Property [dbo].[ICS_CWA_316B_TAKE_INFO].[CWA_316B_SPECIES_NUM_IMPINGED_ENTRAINED_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CWA316bSpeciesNumberImpingedEntrainedDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_CWA_316B_TAKE_INFO', @level2type = N'COLUMN', @level2name = N'CWA_316B_SPECIES_NUM_IMPINGED_ENTRAINED_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_GNRL_PRMT_COVERAGE_MS_4_REQ].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: GeneralPermitCoverageMS4Requirement', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_GNRL_PRMT_COVERAGE_MS_4_REQ';

PRINT N'Creating Extended Property [dbo].[ICS_GNRL_PRMT_COVERAGE_MS_4_REQ].[PRMT_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermitIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_GNRL_PRMT_COVERAGE_MS_4_REQ', @level2type = N'COLUMN', @level2name = N'PRMT_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_INDST_USR_INFO].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: IndustrialUserInformation', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_INDST_USR_INFO';

PRINT N'Creating Extended Property [dbo].[ICS_INDST_USR_INFO].[PRMT_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermitIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_INDST_USR_INFO', @level2type = N'COLUMN', @level2name = N'PRMT_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_INDST_USR_INFO].[IU_AVER_DAILY_WW_FLOW_RATE_GPD].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'IUAverageDailyWastewaterFlowRateGPD', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_INDST_USR_INFO', @level2type = N'COLUMN', @level2name = N'IU_AVER_DAILY_WW_FLOW_RATE_GPD';

PRINT N'Creating Extended Property [dbo].[ICS_INDST_USR_INFO].[IU_AVER_DAILY_PRCSS_WW_FLOW_RATE_GPD].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'IUAverageDailyProcessWastewaterFlowRateGPD', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_INDST_USR_INFO', @level2type = N'COLUMN', @level2name = N'IU_AVER_DAILY_PRCSS_WW_FLOW_RATE_GPD';

PRINT N'Creating Extended Property [dbo].[ICS_INDST_USR_INFO].[IU_SUBJECT_LOC_LMTS_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'IUSubjectLocalLimitsIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_INDST_USR_INFO', @level2type = N'COLUMN', @level2name = N'IU_SUBJECT_LOC_LMTS_IND';

PRINT N'Creating Extended Property [dbo].[ICS_INDST_USR_INFO].[IU_SUBJECT_LOC_LMTS_MORE_STRINGENT_CAT_STD_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'IUSubjectLocalLimitsMoreStringentCatStdIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_INDST_USR_INFO', @level2type = N'COLUMN', @level2name = N'IU_SUBJECT_LOC_LMTS_MORE_STRINGENT_CAT_STD_IND';

PRINT N'Creating Extended Property [dbo].[ICS_INDST_USR_INFO].[MTCIU_SUBJECT_REDUCED_REP_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MTCIUSubjectReducedReportingIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_INDST_USR_INFO', @level2type = N'COLUMN', @level2name = N'MTCIU_SUBJECT_REDUCED_REP_IND';

PRINT N'Creating Extended Property [dbo].[ICS_INDST_USR_INFO].[NUM_IU_INSP_BY_CA].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'NumberIUInspectionsByCA', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_INDST_USR_INFO', @level2type = N'COLUMN', @level2name = N'NUM_IU_INSP_BY_CA';

PRINT N'Creating Extended Property [dbo].[ICS_INDST_USR_INFO].[NUM_IU_SMPL_EVTS_BY_CA].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'NumberIUSamplingEventsByCA', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_INDST_USR_INFO', @level2type = N'COLUMN', @level2name = N'NUM_IU_SMPL_EVTS_BY_CA';

PRINT N'Creating Extended Property [dbo].[ICS_INDST_USR_INFO].[NUM_REQD_IU_SELF_MON_EVTS_MAX].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'NumberReqdIUSelfMonEventsMaximum', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_INDST_USR_INFO', @level2type = N'COLUMN', @level2name = N'NUM_REQD_IU_SELF_MON_EVTS_MAX';

PRINT N'Creating Extended Property [dbo].[ICS_INDST_USR_INFO].[IU_COMPLY_REQ_SELF_MON_RPTING_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'IUComplyReqSelfMonRptingIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_INDST_USR_INFO', @level2type = N'COLUMN', @level2name = N'IU_COMPLY_REQ_SELF_MON_RPTING_IND';

PRINT N'Creating Extended Property [dbo].[ICS_INDST_USR_INFO].[IU_COMPLY_REQ_SELF_MON_RPTING_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'IUComplyReqSelfMonRptingText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_INDST_USR_INFO', @level2type = N'COLUMN', @level2name = N'IU_COMPLY_REQ_SELF_MON_RPTING_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_INDST_USR_INFO].[NSCIU_CERT_SUBM_TO_CA_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'NSCIUCertSubmToCAIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_INDST_USR_INFO', @level2type = N'COLUMN', @level2name = N'NSCIU_CERT_SUBM_TO_CA_IND';

PRINT N'Creating Extended Property [dbo].[ICS_INDST_USR_INFO].[CHANGED_DISCH_SUBM_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ChangedDischSubmIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_INDST_USR_INFO', @level2type = N'COLUMN', @level2name = N'CHANGED_DISCH_SUBM_IND';

PRINT N'Creating Extended Property [dbo].[ICS_INDST_USR_INVENTORY].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: IndustrialUserInventory', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_INDST_USR_INVENTORY';

PRINT N'Creating Extended Property [dbo].[ICS_INDST_USR_INVENTORY].[INDST_USR_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'IndustrialUserIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_INDST_USR_INVENTORY', @level2type = N'COLUMN', @level2name = N'INDST_USR_IND';

PRINT N'Creating Extended Property [dbo].[ICS_INSP_CMNT_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: String', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_INSP_CMNT_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_INSP_CMNT_TXT].[INSP_CMNT_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'InspectionCommentText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_INSP_CMNT_TXT', @level2type = N'COLUMN', @level2name = N'INSP_CMNT_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_INSP_V_CONTACT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: InspectionvernmentContact', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_INSP_V_CONTACT';

PRINT N'Creating Extended Property [dbo].[ICS_INSP_V_CONTACT].[AFFIL_TYPE_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'AffiliationTypeText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_INSP_V_CONTACT', @level2type = N'COLUMN', @level2name = N'AFFIL_TYPE_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_INSP_V_CONTACT].[ELEC_ADDR_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ElectronicAddressText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_INSP_V_CONTACT', @level2type = N'COLUMN', @level2name = N'ELEC_ADDR_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_IU_ENF_ACTN_TYPES].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: IUEnfActionTypes', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_IU_ENF_ACTN_TYPES';

PRINT N'Creating Extended Property [dbo].[ICS_IU_ENF_ACTN_TYPES].[IU_ENF_ACTN_TYPE_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'IUEnfActionTypeCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_IU_ENF_ACTN_TYPES', @level2type = N'COLUMN', @level2name = N'IU_ENF_ACTN_TYPE_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_IU_ENF_ACTN_TYPES].[IU_ENF_ACTN_TYPE_OTHR_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'IUEnfActionTypeOtherText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_IU_ENF_ACTN_TYPES', @level2type = N'COLUMN', @level2name = N'IU_ENF_ACTN_TYPE_OTHR_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_IU_ENF_ACTN_TYPES].[NUM_IU_ENF_ACTIONS].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'NumIUEnfActions', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_IU_ENF_ACTN_TYPES', @level2type = N'COLUMN', @level2name = N'NUM_IU_ENF_ACTIONS';

PRINT N'Creating Extended Property [dbo].[ICS_IU_ENFRC_ACTN_INFO].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: IUEnforcementActionInformation', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_IU_ENFRC_ACTN_INFO';

PRINT N'Creating Extended Property [dbo].[ICS_IU_ENFRC_ACTN_INFO].[SNC_PRETR_ENF_CMPL_SCHED_STAT_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SNCPretrEnfCmplSchedStatusIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_IU_ENFRC_ACTN_INFO', @level2type = N'COLUMN', @level2name = N'SNC_PRETR_ENF_CMPL_SCHED_STAT_IND';

PRINT N'Creating Extended Property [dbo].[ICS_IU_ENFRC_ACTN_INFO].[IU_CASH_CIVIL_PNLTY_AMT_ASSESSED].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'IUCashCivilPenaltyAmountAssessed', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_IU_ENFRC_ACTN_INFO', @level2type = N'COLUMN', @level2name = N'IU_CASH_CIVIL_PNLTY_AMT_ASSESSED';

PRINT N'Creating Extended Property [dbo].[ICS_IU_ENFRC_ACTN_INFO].[IU_CASH_CIVIL_PNLTY_AMT_COLL].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'IUCashCivilPenaltyAmountCollected', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_IU_ENFRC_ACTN_INFO', @level2type = N'COLUMN', @level2name = N'IU_CASH_CIVIL_PNLTY_AMT_COLL';

PRINT N'Creating Extended Property [dbo].[ICS_IU_VIOL_INFO].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: IUViolationInformation', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_IU_VIOL_INFO';

PRINT N'Creating Extended Property [dbo].[ICS_IU_VIOL_INFO].[SNC_PRETR_STND_LMTS_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SNCPretrStndLimitsIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_IU_VIOL_INFO', @level2type = N'COLUMN', @level2name = N'SNC_PRETR_STND_LMTS_IND';

PRINT N'Creating Extended Property [dbo].[ICS_IU_VIOL_INFO].[SNC_RPT_RQMT_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SNCRptRqmtIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_IU_VIOL_INFO', @level2type = N'COLUMN', @level2name = N'SNC_RPT_RQMT_IND';

PRINT N'Creating Extended Property [dbo].[ICS_IU_VIOL_INFO].[SNC_OTH_CTRL_MECH_RQMT_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SNCOthCtrlMechRqmtIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_IU_VIOL_INFO', @level2type = N'COLUMN', @level2name = N'SNC_OTH_CTRL_MECH_RQMT_IND';

PRINT N'Creating Extended Property [dbo].[ICS_IU_VIOL_INFO].[SNC_REL_POTW_DISCH_OPER_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SNCRelPOTWDischOperIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_IU_VIOL_INFO', @level2type = N'COLUMN', @level2name = N'SNC_REL_POTW_DISCH_OPER_IND';

PRINT N'Creating Extended Property [dbo].[ICS_IU_VIOL_INFO].[SNC_REL_POTW_DISCH_OPER_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SNCRelPOTWDischOperText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_IU_VIOL_INFO', @level2type = N'COLUMN', @level2name = N'SNC_REL_POTW_DISCH_OPER_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_IU_VIOL_INFO].[SNC_REL_POTW_BIO_OPER_SEWG_SLUD_MGMT_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SNCRelPOTWBioOperSewgSludMgmtIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_IU_VIOL_INFO', @level2type = N'COLUMN', @level2name = N'SNC_REL_POTW_BIO_OPER_SEWG_SLUD_MGMT_IND';

PRINT N'Creating Extended Property [dbo].[ICS_IU_VIOL_INFO].[SNC_REL_POTW_BIO_OPER_SEWG_SLUD_MGMT_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SNCRelPOTWBioOperSewgSludMgmtText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_IU_VIOL_INFO', @level2type = N'COLUMN', @level2name = N'SNC_REL_POTW_BIO_OPER_SEWG_SLUD_MGMT_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_IU_VIOL_INFO].[SNC_PUBL_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SNCPublishedIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_IU_VIOL_INFO', @level2type = N'COLUMN', @level2name = N'SNC_PUBL_IND';

PRINT N'Creating Extended Property [dbo].[ICS_LNK_CMPL_MON].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: LinkageComplianceMonitoring', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LNK_CMPL_MON';

PRINT N'Creating Extended Property [dbo].[ICS_LNK_CMPL_MON].[CMPL_MON_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ComplianceMonitoringIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LNK_CMPL_MON', @level2type = N'COLUMN', @level2name = N'CMPL_MON_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_LOC_LMTS_PARAMETERS].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: String', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LOC_LMTS_PARAMETERS';

PRINT N'Creating Extended Property [dbo].[ICS_LOC_LMTS_PARAMETERS].[LOC_LMTS_PARAMETERS].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'LocalLimitsParameters', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LOC_LMTS_PARAMETERS', @level2type = N'COLUMN', @level2name = N'LOC_LMTS_PARAMETERS';

PRINT N'Creating Extended Property [dbo].[ICS_LTCP_ENFORCEABLE_MECH_DETAIL].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: LTCPEnforceableMechanismDetail', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LTCP_ENFORCEABLE_MECH_DETAIL';

PRINT N'Creating Extended Property [dbo].[ICS_LTCP_ENFORCEABLE_MECH_DETAIL].[LTCP_ENFORCEABLE_MECH_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'LTCPEnforceableMechanismCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LTCP_ENFORCEABLE_MECH_DETAIL', @level2type = N'COLUMN', @level2name = N'LTCP_ENFORCEABLE_MECH_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_LTCP_ENFORCEABLE_MECH_DETAIL].[LTCP_ENFORCEABLE_MECH_CODE_OTHR_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'LTCPEnforceableMechanismCodeOtherText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LTCP_ENFORCEABLE_MECH_DETAIL', @level2type = N'COLUMN', @level2name = N'LTCP_ENFORCEABLE_MECH_CODE_OTHR_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_LTCP_MOST_RECENT_REVISION_DETAIL].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: LTCPMostRecentRevisionDetail', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LTCP_MOST_RECENT_REVISION_DETAIL';

PRINT N'Creating Extended Property [dbo].[ICS_LTCP_MOST_RECENT_REVISION_DETAIL].[LTCP_MOST_RECENT_REVISION_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'LTCPMostRecentRevisionDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LTCP_MOST_RECENT_REVISION_DETAIL', @level2type = N'COLUMN', @level2name = N'LTCP_MOST_RECENT_REVISION_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_LTCP_MOST_RECENT_REVISION_DETAIL].[LTCP_MOST_RECENT_REVISION_STAT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'LTCPMostRecentRevisionStatus', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LTCP_MOST_RECENT_REVISION_DETAIL', @level2type = N'COLUMN', @level2name = N'LTCP_MOST_RECENT_REVISION_STAT';

PRINT N'Creating Extended Property [dbo].[ICS_LTCP_SUMM].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: LTCPSummary', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LTCP_SUMM';

PRINT N'Creating Extended Property [dbo].[ICS_LTCP_SUMM].[LTCP_REQD_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'LTCPRequiredIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LTCP_SUMM', @level2type = N'COLUMN', @level2name = N'LTCP_REQD_IND';

PRINT N'Creating Extended Property [dbo].[ICS_LTCP_SUMM].[LTCP_IN_CMPL_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'LTCPInComplianceIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LTCP_SUMM', @level2type = N'COLUMN', @level2name = N'LTCP_IN_CMPL_IND';

PRINT N'Creating Extended Property [dbo].[ICS_LTCP_SUMM].[LTCP_APRVL_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'LTCPApprovalDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LTCP_SUMM', @level2type = N'COLUMN', @level2name = N'LTCP_APRVL_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_LTCP_SUMM].[LTCP_AND_CSO_CONTROLS_COMPLETE_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'LTCPAndCSOControlsCompleteDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LTCP_SUMM', @level2type = N'COLUMN', @level2name = N'LTCP_AND_CSO_CONTROLS_COMPLETE_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_LTCP_SUMM].[CSO_POST_CNST_CMPL_MON_PROG].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CSOPostConstructionComplianceMonitoringProgram', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LTCP_SUMM', @level2type = N'COLUMN', @level2name = N'CSO_POST_CNST_CMPL_MON_PROG';

PRINT N'Creating Extended Property [dbo].[ICS_LTCP_SUMM].[CSO_CONTROLS_OTHR_THAN_LTCP].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CSOControlsOtherThanLTCP', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_LTCP_SUMM', @level2type = N'COLUMN', @level2name = N'CSO_CONTROLS_OTHR_THAN_LTCP';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_ACTY_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: String', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_ACTY_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_ACTY_IDENT].[MS_4_ACTY_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4ActivityIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_ACTY_IDENT', @level2type = N'COLUMN', @level2name = N'MS_4_ACTY_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_CNST_SW_PROCEDURES].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: MS4ConstructionStormwaterProcedures', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_CNST_SW_PROCEDURES';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_CNST_SW_PROCEDURES].[MS_4_ACTY_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4ActivityIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_CNST_SW_PROCEDURES', @level2type = N'COLUMN', @level2name = N'MS_4_ACTY_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_CNST_SW_PROCEDURES].[MS_4_CNST_SW_PROCEDURE_TYPE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4ConstructionStormwaterProcedureType', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_CNST_SW_PROCEDURES', @level2type = N'COLUMN', @level2name = N'MS_4_CNST_SW_PROCEDURE_TYPE';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_CNST_SW_PROCEDURES].[MS_4_CNST_SW_PROCEDURE_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4ConstructionStormwaterProcedureText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_CNST_SW_PROCEDURES', @level2type = N'COLUMN', @level2name = N'MS_4_CNST_SW_PROCEDURE_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_CNST_SW_PROCEDURES].[MS_4_CNST_SW_PROCEDURE_SCHD_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4ConstructionStormwaterProcedureScheduleText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_CNST_SW_PROCEDURES', @level2type = N'COLUMN', @level2name = N'MS_4_CNST_SW_PROCEDURE_SCHD_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_CNST_SW_REGULATED_ENTITY_INFO].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: MS4ConstructionStormwaterRegulatedEntityInformation', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_CNST_SW_REGULATED_ENTITY_INFO';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_CNST_SW_REGULATED_ENTITY_INFO].[MS_4_ACTY_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4ActivityIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_CNST_SW_REGULATED_ENTITY_INFO', @level2type = N'COLUMN', @level2name = N'MS_4_ACTY_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_CNST_SW_REGULATED_ENTITY_INFO].[MS_4_REGULATED_ENTITY_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4RegulatedEntityIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_CNST_SW_REGULATED_ENTITY_INFO', @level2type = N'COLUMN', @level2name = N'MS_4_REGULATED_ENTITY_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_CNST_SW_REGULATED_ENTITY_INFO].[MS_4_CNST_SW_EROSION_ORDINANCE_STAT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4ConstructionStormwaterErosionOrdinanceStatus', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_CNST_SW_REGULATED_ENTITY_INFO', @level2type = N'COLUMN', @level2name = N'MS_4_CNST_SW_EROSION_ORDINANCE_STAT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_CNST_SW_REGULATED_ENTITY_INFO].[MS_4_CNST_SW_EROSION_ORDINANCE_STAT_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4ConstructionStormwaterErosionOrdinanceStatusText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_CNST_SW_REGULATED_ENTITY_INFO', @level2type = N'COLUMN', @level2name = N'MS_4_CNST_SW_EROSION_ORDINANCE_STAT_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_CNST_SW_REGULATED_ENTITY_INFO].[MS_4_CNST_SW_EROSION_PLAN_RVIW_STAT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4ConstructionStormwaterErosionPlanReviewStatus', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_CNST_SW_REGULATED_ENTITY_INFO', @level2type = N'COLUMN', @level2name = N'MS_4_CNST_SW_EROSION_PLAN_RVIW_STAT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_CNST_SW_REGULATED_ENTITY_INFO].[MS_4_CNST_SW_EROSION_PLAN_RVIW_STAT_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4ConstructionStormwaterErosionPlanReviewStatusText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_CNST_SW_REGULATED_ENTITY_INFO', @level2type = N'COLUMN', @level2name = N'MS_4_CNST_SW_EROSION_PLAN_RVIW_STAT_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_CNST_SW_REGULATED_ENTITY_INFO].[MS_4_CNST_SW_SITE_INSP_STAT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4ConstructionStormwaterSiteInspectionStatus', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_CNST_SW_REGULATED_ENTITY_INFO', @level2type = N'COLUMN', @level2name = N'MS_4_CNST_SW_SITE_INSP_STAT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_CNST_SW_REGULATED_ENTITY_INFO].[MS_4_CNST_SW_SITE_INSP_STAT_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4ConstructionStormwaterSiteInspectionStatusText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_CNST_SW_REGULATED_ENTITY_INFO', @level2type = N'COLUMN', @level2name = N'MS_4_CNST_SW_SITE_INSP_STAT_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_CNST_SW_REQS].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: MS4ConstructionStormwaterRequirements', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_CNST_SW_REQS';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_ILLICIT_DETECT_PROCEDURES].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: MS4IllicitDetectionProcedures', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_ILLICIT_DETECT_PROCEDURES';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_ILLICIT_DETECT_PROCEDURES].[MS_4_ACTY_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4ActivityIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_ILLICIT_DETECT_PROCEDURES', @level2type = N'COLUMN', @level2name = N'MS_4_ACTY_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_ILLICIT_DETECT_PROCEDURES].[MS_4_ILLICIT_DETECT_PROCEDURE_TYPE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4IllicitDetectionProcedureType', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_ILLICIT_DETECT_PROCEDURES', @level2type = N'COLUMN', @level2name = N'MS_4_ILLICIT_DETECT_PROCEDURE_TYPE';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_ILLICIT_DETECT_PROCEDURES].[MS_4_ILLICIT_DETECT_PROCEDURE_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4IllicitDetectionProcedureText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_ILLICIT_DETECT_PROCEDURES', @level2type = N'COLUMN', @level2name = N'MS_4_ILLICIT_DETECT_PROCEDURE_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_ILLICIT_DETECT_PROCEDURES].[MS_4_ILLICIT_DETECT_PROCEDURE_SCHD_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4IllicitDetectionProcedureScheduleText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_ILLICIT_DETECT_PROCEDURES', @level2type = N'COLUMN', @level2name = N'MS_4_ILLICIT_DETECT_PROCEDURE_SCHD_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: MS4IllicitDetectionRegulatedEntityInformation', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO].[MS_4_ACTY_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4ActivityIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO', @level2type = N'COLUMN', @level2name = N'MS_4_ACTY_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO].[MS_4_REGULATED_ENTITY_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4RegulatedEntityIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO', @level2type = N'COLUMN', @level2name = N'MS_4_REGULATED_ENTITY_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO].[MS_4_PRMT_ILLICIT_DETECT_OUTFALL_MAPPING_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4PermitIllicitDetectionOutfallMappingDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO', @level2type = N'COLUMN', @level2name = N'MS_4_PRMT_ILLICIT_DETECT_OUTFALL_MAPPING_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO].[MS_4_ILLICIT_DETECT_OUTFALL_MAPPING_STAT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4IllicitDetectionOutfallMappingStatus', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO', @level2type = N'COLUMN', @level2name = N'MS_4_ILLICIT_DETECT_OUTFALL_MAPPING_STAT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO].[MS_4_PRMT_ILLICIT_DETECT_OUTFALL_TTL_NUM].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4PermitIllicitDetectionOutfallTotalNumber', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO', @level2type = N'COLUMN', @level2name = N'MS_4_PRMT_ILLICIT_DETECT_OUTFALL_TTL_NUM';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO].[MS_4_PRMT_ILLICIT_DETECT_OUTFALL_MAPPED_NUM].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4PermitIllicitDetectionOutfallMappedNumber', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO', @level2type = N'COLUMN', @level2name = N'MS_4_PRMT_ILLICIT_DETECT_OUTFALL_MAPPED_NUM';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO].[MS_4_ILLICIT_DETECT_PROHIBITION_ORDINANCE_STAT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4IllicitDetectionProhibitionOrdinanceStatus', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO', @level2type = N'COLUMN', @level2name = N'MS_4_ILLICIT_DETECT_PROHIBITION_ORDINANCE_STAT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO].[MS_4_ILLICIT_DETECT_PROHIBITION_ORDINANCE_STAT_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4IllicitDetectionProhibitionOrdinanceStatusText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO', @level2type = N'COLUMN', @level2name = N'MS_4_ILLICIT_DETECT_PROHIBITION_ORDINANCE_STAT_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO_PROG_REP].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: MS4IllicitDetectionRegulatedEntityInformationProgramReport', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO_PROG_REP';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO_PROG_REP].[MS_4_ACTY_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4ActivityIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO_PROG_REP', @level2type = N'COLUMN', @level2name = N'MS_4_ACTY_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO_PROG_REP].[MS_4_PROG_REP_ILLICIT_DETECT_OUTFALL_MAPPING_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4ProgramReportIllicitDetectionOutfallMappingDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO_PROG_REP', @level2type = N'COLUMN', @level2name = N'MS_4_PROG_REP_ILLICIT_DETECT_OUTFALL_MAPPING_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO_PROG_REP].[MS_4_PROG_REP_ILLICIT_DETECT_OUTFALL_TTL_NUM].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4ProgramReportIllicitDetectionOutfallTotalNumber', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO_PROG_REP', @level2type = N'COLUMN', @level2name = N'MS_4_PROG_REP_ILLICIT_DETECT_OUTFALL_TTL_NUM';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO_PROG_REP].[MS_4_PROG_REP_ILLICIT_DETECT_OUTFALL_MAPPED_NUM].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4ProgramReportIllicitDetectionOutfallMappedNumber', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO_PROG_REP', @level2type = N'COLUMN', @level2name = N'MS_4_PROG_REP_ILLICIT_DETECT_OUTFALL_MAPPED_NUM';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO_PROG_REP].[MS_4_REGULATED_ENTITY_CMPL_STAT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4RegulatedEntityComplianceStatus', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO_PROG_REP', @level2type = N'COLUMN', @level2name = N'MS_4_REGULATED_ENTITY_CMPL_STAT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO_PROG_REP].[MS_4_REGULATED_ENTITY_CMPL_STAT_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4RegulatedEntityComplianceStatusText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO_PROG_REP', @level2type = N'COLUMN', @level2name = N'MS_4_REGULATED_ENTITY_CMPL_STAT_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO_PROG_REP].[MS_4_PROG_REP_REQS_ACTIVITIES].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4ProgramReportRequirementsActivities', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO_PROG_REP', @level2type = N'COLUMN', @level2name = N'MS_4_PROG_REP_REQS_ACTIVITIES';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_ILLICIT_DETECT_REQS].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: MS4IllicitDetectionRequirements', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_ILLICIT_DETECT_REQS';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_INDST_SW_PROCEDURES].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: MS4IndustrialStormwaterProcedures', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_INDST_SW_PROCEDURES';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_INDST_SW_PROCEDURES].[MS_4_ACTY_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4ActivityIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_INDST_SW_PROCEDURES', @level2type = N'COLUMN', @level2name = N'MS_4_ACTY_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_INDST_SW_PROCEDURES].[MS_4_INDST_SW_PROCEDURE_TYPE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4IndustrialStormwaterProcedureType', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_INDST_SW_PROCEDURES', @level2type = N'COLUMN', @level2name = N'MS_4_INDST_SW_PROCEDURE_TYPE';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_INDST_SW_PROCEDURES].[MS_4_INDST_SW_PROCEDURE_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4IndustrialStormwaterProcedureText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_INDST_SW_PROCEDURES', @level2type = N'COLUMN', @level2name = N'MS_4_INDST_SW_PROCEDURE_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_INDST_SW_PROCEDURES].[MS_4_INDST_SW_PROCEDURE_SCHD_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4IndustrialStormwaterProcedureScheduleText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_INDST_SW_PROCEDURES', @level2type = N'COLUMN', @level2name = N'MS_4_INDST_SW_PROCEDURE_SCHD_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_INDST_SW_REGULATED_ENTITY_INFO].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: MS4IndustrialStormwaterRegulatedEntityInformation', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_INDST_SW_REGULATED_ENTITY_INFO';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_INDST_SW_REGULATED_ENTITY_INFO].[MS_4_ACTY_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4ActivityIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_INDST_SW_REGULATED_ENTITY_INFO', @level2type = N'COLUMN', @level2name = N'MS_4_ACTY_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_INDST_SW_REGULATED_ENTITY_INFO].[MS_4_REGULATED_ENTITY_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4RegulatedEntityIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_INDST_SW_REGULATED_ENTITY_INFO', @level2type = N'COLUMN', @level2name = N'MS_4_REGULATED_ENTITY_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_INDST_SW_REGULATED_ENTITY_INFO].[MS_4_INDST_SW_ORDINANCE_STAT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4IndustrialStormwaterOrdinanceStatus', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_INDST_SW_REGULATED_ENTITY_INFO', @level2type = N'COLUMN', @level2name = N'MS_4_INDST_SW_ORDINANCE_STAT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_INDST_SW_REGULATED_ENTITY_INFO].[MS_4_INDST_SW_ORDINANCE_STAT_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4IndustrialStormwaterOrdinanceStatusText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_INDST_SW_REGULATED_ENTITY_INFO', @level2type = N'COLUMN', @level2name = N'MS_4_INDST_SW_ORDINANCE_STAT_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_INDST_SW_REGULATED_ENTITY_INFO].[MS_4_INDST_SW_INDST_INVENTORY_STAT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4IndustrialStormwaterIndustrialInventoryStatus', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_INDST_SW_REGULATED_ENTITY_INFO', @level2type = N'COLUMN', @level2name = N'MS_4_INDST_SW_INDST_INVENTORY_STAT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_INDST_SW_REGULATED_ENTITY_INFO].[MS_4_INDST_SW_INDST_INVENTORY_STAT_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4IndustrialStormwaterIndustrialInventoryStatusText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_INDST_SW_REGULATED_ENTITY_INFO', @level2type = N'COLUMN', @level2name = N'MS_4_INDST_SW_INDST_INVENTORY_STAT_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_INDST_SW_REGULATED_ENTITY_INFO].[MS_4_INDST_SW_MON_STAT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4IndustrialStormwaterMonitoringStatus', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_INDST_SW_REGULATED_ENTITY_INFO', @level2type = N'COLUMN', @level2name = N'MS_4_INDST_SW_MON_STAT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_INDST_SW_REGULATED_ENTITY_INFO].[MS_4_INDST_SW_MON_STAT_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4IndustrialStormwaterMonitoringStatusText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_INDST_SW_REGULATED_ENTITY_INFO', @level2type = N'COLUMN', @level2name = N'MS_4_INDST_SW_MON_STAT_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_INDST_SW_REQS].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: MS4IndustrialStormwaterRequirements', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_INDST_SW_REQS';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_OTHR_APPL_REQS].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: MS4OtherApplicableRequirements', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_OTHR_APPL_REQS';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_OTHR_APPL_REQS].[MS_4_ACTY_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4ActivityIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_OTHR_APPL_REQS', @level2type = N'COLUMN', @level2name = N'MS_4_ACTY_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_OTHR_APPL_REQS].[MS_4_OTHR_APPL_REQS_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4OtherApplicableRequirementsText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_OTHR_APPL_REQS', @level2type = N'COLUMN', @level2name = N'MS_4_OTHR_APPL_REQS_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_OTHR_APPL_REQS].[MS_4_OTHR_APPL_REQS_SCHD_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4OtherApplicableRequirementsScheduleText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_OTHR_APPL_REQS', @level2type = N'COLUMN', @level2name = N'MS_4_OTHR_APPL_REQS_SCHD_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_PBLC_EDUCATION_REQS].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: MS4PublicEducationRequirements', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_PBLC_EDUCATION_REQS';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_PBLC_EDUCATION_REQS].[MS_4_ACTY_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4ActivityIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_PBLC_EDUCATION_REQS', @level2type = N'COLUMN', @level2name = N'MS_4_ACTY_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_PBLC_EDUCATION_REQS].[MS_4_PBLC_EDUCATION_REQS_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4PublicEducationRequirementsText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_PBLC_EDUCATION_REQS', @level2type = N'COLUMN', @level2name = N'MS_4_PBLC_EDUCATION_REQS_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_PBLC_EDUCATION_REQS].[MS_4_PBLC_EDUCATION_SCHD_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4PublicEducationScheduleText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_PBLC_EDUCATION_REQS', @level2type = N'COLUMN', @level2name = N'MS_4_PBLC_EDUCATION_SCHD_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_PBLC_EDUCATION_REQS].[MS_4_PBLC_EDUCATION_DELIVERY_OPTION].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4PublicEducationDeliveryOption', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_PBLC_EDUCATION_REQS', @level2type = N'COLUMN', @level2name = N'MS_4_PBLC_EDUCATION_DELIVERY_OPTION';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_PBLC_EDUCATION_REQS].[MS_4_PBLC_EDUCATION_DELIVERY_OPTION_OTHR_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4PublicEducationDeliveryOptionOtherText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_PBLC_EDUCATION_REQS', @level2type = N'COLUMN', @level2name = N'MS_4_PBLC_EDUCATION_DELIVERY_OPTION_OTHR_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_PBLC_EDUCATION_REQS].[MS_4_PBLC_EDUCATION_SUBJECT_OPTION].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4PublicEducationSubjectOption', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_PBLC_EDUCATION_REQS', @level2type = N'COLUMN', @level2name = N'MS_4_PBLC_EDUCATION_SUBJECT_OPTION';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_PBLC_EDUCATION_REQS].[MS_4_PBLC_EDUCATION_SUBJECT_OPTION_OTHR_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4PublicEducationSubjectOptionOtherText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_PBLC_EDUCATION_REQS', @level2type = N'COLUMN', @level2name = N'MS_4_PBLC_EDUCATION_SUBJECT_OPTION_OTHR_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_PBLC_EDUCATION_REQS].[MS_4_PBLC_EDUCATION_AUDIENCE_OPTION].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4PublicEducationAudienceOption', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_PBLC_EDUCATION_REQS', @level2type = N'COLUMN', @level2name = N'MS_4_PBLC_EDUCATION_AUDIENCE_OPTION';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_PBLC_EDUCATION_REQS].[MS_4_PBLC_EDUCATION_AUDIENCE_OPTION_OTHR_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4PublicEducationAudienceOptionOtherText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_PBLC_EDUCATION_REQS', @level2type = N'COLUMN', @level2name = N'MS_4_PBLC_EDUCATION_AUDIENCE_OPTION_OTHR_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_PBLC_INVOLVEMENT_REQS].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: MS4PublicInvolvementRequirements', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_PBLC_INVOLVEMENT_REQS';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_PBLC_INVOLVEMENT_REQS].[MS_4_ACTY_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4ActivityIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_PBLC_INVOLVEMENT_REQS', @level2type = N'COLUMN', @level2name = N'MS_4_ACTY_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_PBLC_INVOLVEMENT_REQS].[MS_4_PBLC_INVOLVEMENT_REQS_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4PublicInvolvementRequirementsText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_PBLC_INVOLVEMENT_REQS', @level2type = N'COLUMN', @level2name = N'MS_4_PBLC_INVOLVEMENT_REQS_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_PBLC_INVOLVEMENT_REQS].[MS_4_PBLC_INVOLVEMENT_SCHD_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4PublicInvolvementScheduleText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_PBLC_INVOLVEMENT_REQS', @level2type = N'COLUMN', @level2name = N'MS_4_PBLC_INVOLVEMENT_SCHD_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_PBLC_INVOLVEMENT_REQS].[MS_4_PBLC_INVOLVEMENT_DELIVERY_OPTION].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4PublicInvolvementDeliveryOption', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_PBLC_INVOLVEMENT_REQS', @level2type = N'COLUMN', @level2name = N'MS_4_PBLC_INVOLVEMENT_DELIVERY_OPTION';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_PBLC_INVOLVEMENT_REQS].[MS_4_PBLC_INVOLVEMENT_DELIVERY_OPTION_OTHR_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4PublicInvolvementDeliveryOptionOtherText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_PBLC_INVOLVEMENT_REQS', @level2type = N'COLUMN', @level2name = N'MS_4_PBLC_INVOLVEMENT_DELIVERY_OPTION_OTHR_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_PBLC_INVOLVEMENT_REQS].[MS_4_PBLC_INVOLVEMENT_SUBJECT_OPTION].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4PublicInvolvementSubjectOption', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_PBLC_INVOLVEMENT_REQS', @level2type = N'COLUMN', @level2name = N'MS_4_PBLC_INVOLVEMENT_SUBJECT_OPTION';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_PBLC_INVOLVEMENT_REQS].[MS_4_PBLC_INVOLVEMENT_SUBJECT_OPTION_OTHR_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4PublicInvolvementSubjectOptionOtherText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_PBLC_INVOLVEMENT_REQS', @level2type = N'COLUMN', @level2name = N'MS_4_PBLC_INVOLVEMENT_SUBJECT_OPTION_OTHR_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_PBLC_INVOLVEMENT_REQS].[MS_4_PBLC_INVOLVEMENT_PARTICIPANT_OPTION].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4PublicInvolvementParticipantOption', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_PBLC_INVOLVEMENT_REQS', @level2type = N'COLUMN', @level2name = N'MS_4_PBLC_INVOLVEMENT_PARTICIPANT_OPTION';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_PBLC_INVOLVEMENT_REQS].[MS_4_PBLC_INVOLVEMENT_PARTICIPANT_OPTION_OTHR_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4PublicInvolvementParticipantOptionOtherText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_PBLC_INVOLVEMENT_REQS', @level2type = N'COLUMN', @level2name = N'MS_4_PBLC_INVOLVEMENT_PARTICIPANT_OPTION_OTHR_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_POLLUTION_PREVENTION_REQS].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: MS4PollutionPreventionRequirements', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_POLLUTION_PREVENTION_REQS';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_POLLUTION_PREVENTION_REQS].[MS_4_ACTY_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4ActivityIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_POLLUTION_PREVENTION_REQS', @level2type = N'COLUMN', @level2name = N'MS_4_ACTY_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_POLLUTION_PREVENTION_REQS].[MS_4_POLLUTION_PREVENTION_REQS_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4PollutionPreventionRequirementsText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_POLLUTION_PREVENTION_REQS', @level2type = N'COLUMN', @level2name = N'MS_4_POLLUTION_PREVENTION_REQS_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_POLLUTION_PREVENTION_REQS].[MS_4_POLLUTION_PREVENTION_SCHD_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4PollutionPreventionScheduleText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_POLLUTION_PREVENTION_REQS', @level2type = N'COLUMN', @level2name = N'MS_4_POLLUTION_PREVENTION_SCHD_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_POST_CNST_SW_PROCEDURES].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: MS4PostConstructionStormwaterProcedures', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_POST_CNST_SW_PROCEDURES';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_POST_CNST_SW_PROCEDURES].[MS_4_ACTY_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4ActivityIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_POST_CNST_SW_PROCEDURES', @level2type = N'COLUMN', @level2name = N'MS_4_ACTY_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_POST_CNST_SW_PROCEDURES].[MS_4_POST_CNST_SW_PROCEDURE_TYPE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4PostConstructionStormwaterProcedureType', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_POST_CNST_SW_PROCEDURES', @level2type = N'COLUMN', @level2name = N'MS_4_POST_CNST_SW_PROCEDURE_TYPE';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_POST_CNST_SW_PROCEDURES].[MS_4_POST_CNST_SW_PROCEDURE_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4PostConstructionStormwaterProcedureText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_POST_CNST_SW_PROCEDURES', @level2type = N'COLUMN', @level2name = N'MS_4_POST_CNST_SW_PROCEDURE_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_POST_CNST_SW_PROCEDURES].[MS_4_POST_CNST_SW_PROCEDURE_SCHD_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4PostConstructionStormwaterProcedureScheduleText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_POST_CNST_SW_PROCEDURES', @level2type = N'COLUMN', @level2name = N'MS_4_POST_CNST_SW_PROCEDURE_SCHD_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_POST_CNST_SW_REGULATED_ENTITY_INFO].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: MS4PostConstructionStormwaterRegulatedEntityInformation', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_POST_CNST_SW_REGULATED_ENTITY_INFO';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_POST_CNST_SW_REGULATED_ENTITY_INFO].[MS_4_ACTY_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4ActivityIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_POST_CNST_SW_REGULATED_ENTITY_INFO', @level2type = N'COLUMN', @level2name = N'MS_4_ACTY_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_POST_CNST_SW_REGULATED_ENTITY_INFO].[MS_4_REGULATED_ENTITY_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4RegulatedEntityIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_POST_CNST_SW_REGULATED_ENTITY_INFO', @level2type = N'COLUMN', @level2name = N'MS_4_REGULATED_ENTITY_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_POST_CNST_SW_REGULATED_ENTITY_INFO].[MS_4_POST_CNST_SW_RUNOFF_ORDINANCE_STAT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4PostConstructionStormwaterRunoffOrdinanceStatus', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_POST_CNST_SW_REGULATED_ENTITY_INFO', @level2type = N'COLUMN', @level2name = N'MS_4_POST_CNST_SW_RUNOFF_ORDINANCE_STAT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_POST_CNST_SW_REGULATED_ENTITY_INFO].[MS_4_POST_CNST_SW_RUNOFF_ORDINANCE_STAT_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4PostConstructionStormwaterRunoffOrdinanceStatusText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_POST_CNST_SW_REGULATED_ENTITY_INFO', @level2type = N'COLUMN', @level2name = N'MS_4_POST_CNST_SW_RUNOFF_ORDINANCE_STAT_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_POST_CNST_SW_REGULATED_ENTITY_INFO].[MS_4_POST_CNST_SW_RUNOFF_PROG_STAT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4PostConstructionStormwaterRunoffProgramStatus', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_POST_CNST_SW_REGULATED_ENTITY_INFO', @level2type = N'COLUMN', @level2name = N'MS_4_POST_CNST_SW_RUNOFF_PROG_STAT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_POST_CNST_SW_REGULATED_ENTITY_INFO].[MS_4_POST_CNST_SW_RUNOFF_PROG_STAT_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4PostConstructionStormwaterRunoffProgramStatusText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_POST_CNST_SW_REGULATED_ENTITY_INFO', @level2type = N'COLUMN', @level2name = N'MS_4_POST_CNST_SW_RUNOFF_PROG_STAT_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_POST_CNST_SW_REGULATED_ENTITY_INFO].[MS_4_POST_CNST_SW_RUNOFF_BMP_STAT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4PostConstructionStormwaterRunoffBMPStatus', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_POST_CNST_SW_REGULATED_ENTITY_INFO', @level2type = N'COLUMN', @level2name = N'MS_4_POST_CNST_SW_RUNOFF_BMP_STAT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_POST_CNST_SW_REGULATED_ENTITY_INFO].[MS_4_POST_CNST_SW_RUNOFF_BMP_STAT_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4PostConstructionStormwaterRunoffBMPStatusText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_POST_CNST_SW_REGULATED_ENTITY_INFO', @level2type = N'COLUMN', @level2name = N'MS_4_POST_CNST_SW_RUNOFF_BMP_STAT_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_POST_CNST_SW_REQS].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: MS4PostConstructionStormwaterRequirements', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_POST_CNST_SW_REQS';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_PROG_REP_ANALYSIS].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: MS4ProgramReportAnalysis', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_PROG_REP_ANALYSIS';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_PROG_REP_ANALYSIS].[MS_4_PROG_REP_ANALYSIS_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4ProgramReportAnalysisText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_PROG_REP_ANALYSIS', @level2type = N'COLUMN', @level2name = N'MS_4_PROG_REP_ANALYSIS_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: MS4ProgramReportRequirementsRegulatedEntity', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY].[MS_4_ACTY_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4ActivityIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY', @level2type = N'COLUMN', @level2name = N'MS_4_ACTY_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY].[MS_4_REGULATED_ENTITY_CMPL_STAT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4RegulatedEntityComplianceStatus', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY', @level2type = N'COLUMN', @level2name = N'MS_4_REGULATED_ENTITY_CMPL_STAT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY].[MS_4_REGULATED_ENTITY_CMPL_STAT_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4RegulatedEntityComplianceStatusText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY', @level2type = N'COLUMN', @level2name = N'MS_4_REGULATED_ENTITY_CMPL_STAT_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY].[MS_4_PROG_REP_REQS_ACTIVITIES].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4ProgramReportRequirementsActivities', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY', @level2type = N'COLUMN', @level2name = N'MS_4_PROG_REP_REQS_ACTIVITIES';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_REGULATED_ENTITY].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: MS4RegulatedEntity', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_REGULATED_ENTITY';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_REGULATED_ENTITY].[MS_4_REGULATED_ENTITY_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4RegulatedEntityIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_REGULATED_ENTITY', @level2type = N'COLUMN', @level2name = N'MS_4_REGULATED_ENTITY_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_REGULATED_ENTITY].[MS_4_REGULATED_ENTITY_NAME].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4RegulatedEntityName', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_REGULATED_ENTITY', @level2type = N'COLUMN', @level2name = N'MS_4_REGULATED_ENTITY_NAME';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_REGULATED_ENTITY].[MS_4_REGULATED_ENTITY_OWNERSHIP_LEVEL_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4RegulatedEntityOwnershipLevelCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_REGULATED_ENTITY', @level2type = N'COLUMN', @level2name = N'MS_4_REGULATED_ENTITY_OWNERSHIP_LEVEL_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_REGULATED_ENTITY].[MS_4_REGULATED_ENTITY_OWNERSHIP_LEVEL_OTHR_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4RegulatedEntityOwnershipLevelOtherText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_REGULATED_ENTITY', @level2type = N'COLUMN', @level2name = N'MS_4_REGULATED_ENTITY_OWNERSHIP_LEVEL_OTHR_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_REGULATED_ENTITY].[MS_4_REGULATED_ENTITY_CATG_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4RegulatedEntityCateryCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_REGULATED_ENTITY', @level2type = N'COLUMN', @level2name = N'MS_4_REGULATED_ENTITY_CATG_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_REGULATED_ENTITY].[MS_4_REGULATED_ENTITY_CATG_CODE_OTHR_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4RegulatedEntityCateryCodeOtherText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_REGULATED_ENTITY', @level2type = N'COLUMN', @level2name = N'MS_4_REGULATED_ENTITY_CATG_CODE_OTHR_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_REGULATED_ENTITY_AREA].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: MS4RegulatedEntityArea', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_REGULATED_ENTITY_AREA';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_REGULATED_ENTITY_AREA].[MS_4_REGULATED_ENTITY_AREA_NUM].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4RegulatedEntityAreaNumber', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_REGULATED_ENTITY_AREA', @level2type = N'COLUMN', @level2name = N'MS_4_REGULATED_ENTITY_AREA_NUM';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_REGULATED_ENTITY_AREA].[MS_4_REGULATED_ENTITY_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4RegulatedEntityIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_REGULATED_ENTITY_AREA', @level2type = N'COLUMN', @level2name = N'MS_4_REGULATED_ENTITY_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_REGULATED_ENTITY_AREA].[MS_4_REGULATED_ENTITY_AREA_STAT_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4RegulatedEntityAreaStatusCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_REGULATED_ENTITY_AREA', @level2type = N'COLUMN', @level2name = N'MS_4_REGULATED_ENTITY_AREA_STAT_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_REGULATED_ENTITY_AREA].[MS_4_REGULATED_ENTITY_AREA_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4RegulatedEntityAreaText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_REGULATED_ENTITY_AREA', @level2type = N'COLUMN', @level2name = N'MS_4_REGULATED_ENTITY_AREA_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_REGULATED_ENTITY_AREA_COORD].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: MS4RegulatedEntityAreaCoordinates', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_REGULATED_ENTITY_AREA_COORD';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_REGULATED_ENTITY_AREA_COORD].[LAT_MEAS].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'LatitudeMeasure', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_REGULATED_ENTITY_AREA_COORD', @level2type = N'COLUMN', @level2name = N'LAT_MEAS';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_REGULATED_ENTITY_AREA_COORD].[LONG_MEAS].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'LongitudeMeasure', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_REGULATED_ENTITY_AREA_COORD', @level2type = N'COLUMN', @level2name = N'LONG_MEAS';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_REGULATED_ENTITY_ENFRC].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: MS4RegulatedEntityEnforcement', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_REGULATED_ENTITY_ENFRC';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_REGULATED_ENTITY_ENFRC].[MS_4_REGULATED_ENTITY_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4RegulatedEntityIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_REGULATED_ENTITY_ENFRC', @level2type = N'COLUMN', @level2name = N'MS_4_REGULATED_ENTITY_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_REGULATED_ENTITY_ENFRC_ACTIONS].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: MS4RegulatedEntityEnforcementActions', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_REGULATED_ENTITY_ENFRC_ACTIONS';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_REGULATED_ENTITY_ENFRC_ACTIONS].[MS_4_REGULATED_ENTITY_ENFRC_ACTN_TYPE_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4RegulatedEntityEnforcementActionTypeCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_REGULATED_ENTITY_ENFRC_ACTIONS', @level2type = N'COLUMN', @level2name = N'MS_4_REGULATED_ENTITY_ENFRC_ACTN_TYPE_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_REGULATED_ENTITY_ENFRC_ACTIONS].[MS_4_REGULATED_ENTITY_ENFRC_ACTN_TYPE_CODE_OTHR_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4RegulatedEntityEnforcementActionTypeCodeOtherText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_REGULATED_ENTITY_ENFRC_ACTIONS', @level2type = N'COLUMN', @level2name = N'MS_4_REGULATED_ENTITY_ENFRC_ACTN_TYPE_CODE_OTHR_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: String', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_REGULATED_ENTITY_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT].[MS_4_REGULATED_ENTITY_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4RegulatedEntityIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_REGULATED_ENTITY_IDENT', @level2type = N'COLUMN', @level2name = N'MS_4_REGULATED_ENTITY_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_SWMP_CHANGES].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: MS4SWMPChanges', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_SWMP_CHANGES';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_SWMP_CHANGES].[MS_4_REGULATED_ENTITY_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4RegulatedEntityIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_SWMP_CHANGES', @level2type = N'COLUMN', @level2name = N'MS_4_REGULATED_ENTITY_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_SWMP_CHANGES].[MS_4_SWMP_CHANGE_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4SWMPChangeIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_SWMP_CHANGES', @level2type = N'COLUMN', @level2name = N'MS_4_SWMP_CHANGE_IND';

PRINT N'Creating Extended Property [dbo].[ICS_MS_4_SWMP_CHANGES].[MS_4_SWMP_CHANGE_IND_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4SWMPChangeIndicatorText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_MS_4_SWMP_CHANGES', @level2type = N'COLUMN', @level2name = N'MS_4_SWMP_CHANGE_IND_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_NPDES_VARIANCE_PRMT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: NPDESVariancePermitData', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_NPDES_VARIANCE_PRMT';

PRINT N'Creating Extended Property [dbo].[ICS_NPDES_VARIANCE_PRMT].[SRC_SYSTM_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SourceSystemIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_NPDES_VARIANCE_PRMT', @level2type = N'COLUMN', @level2name = N'SRC_SYSTM_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_NPDES_VARIANCE_PRMT].[TRANSACTION_TYPE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TransactionType', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_NPDES_VARIANCE_PRMT', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TYPE';

PRINT N'Creating Extended Property [dbo].[ICS_NPDES_VARIANCE_PRMT].[TRANSACTION_TIMESTAMP].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TransactionTimestamp', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_NPDES_VARIANCE_PRMT', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TIMESTAMP';

PRINT N'Creating Extended Property [dbo].[ICS_NPDES_VARIANCE_PRMT].[PRMT_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermitIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_NPDES_VARIANCE_PRMT', @level2type = N'COLUMN', @level2name = N'PRMT_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_NPDES_VARIANCE_PRMT].[NPDES_VARIANCE_TYPE_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'NPDESVarianceTypeCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_NPDES_VARIANCE_PRMT', @level2type = N'COLUMN', @level2name = N'NPDES_VARIANCE_TYPE_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_NPDES_VARIANCE_PRMT].[NPDES_VARIANCE_SUBM_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'NPDESVarianceSubmissionDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_NPDES_VARIANCE_PRMT', @level2type = N'COLUMN', @level2name = N'NPDES_VARIANCE_SUBM_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_NPDES_VARIANCE_PRMT].[NPDES_VARIANCE_VERSION_TYPE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'NPDESVarianceVersionType', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_NPDES_VARIANCE_PRMT', @level2type = N'COLUMN', @level2name = N'NPDES_VARIANCE_VERSION_TYPE';

PRINT N'Creating Extended Property [dbo].[ICS_NPDES_VARIANCE_PRMT].[NPDES_VARIANCE_STAT_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'NPDESVarianceStatusCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_NPDES_VARIANCE_PRMT', @level2type = N'COLUMN', @level2name = N'NPDES_VARIANCE_STAT_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_NPDES_VARIANCE_PRMT].[NPDES_VARIANCE_ACTN_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'NPDESVarianceActionDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_NPDES_VARIANCE_PRMT', @level2type = N'COLUMN', @level2name = N'NPDES_VARIANCE_ACTN_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_NPDES_VARIANCE_PRMT].[THERMAL_VARIANCE_REQUEST_PBLC_NOTICE_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ThermalVarianceRequestPublicNoticeIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_NPDES_VARIANCE_PRMT', @level2type = N'COLUMN', @level2name = N'THERMAL_VARIANCE_REQUEST_PBLC_NOTICE_IND';

PRINT N'Creating Extended Property [dbo].[ICS_NPDES_VARIANCE_PRMT].[NPDES_VARIANCE_CMNT_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'NPDESVarianceCommentText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_NPDES_VARIANCE_PRMT', @level2type = N'COLUMN', @level2name = N'NPDES_VARIANCE_CMNT_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_POLUT_LIST].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: PollutantList', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_POLUT_LIST';

PRINT N'Creating Extended Property [dbo].[ICS_POTW_TRTMNT_TECHNOLOGY_PRMT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: POTWTreatmentTechnologyPermitData', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_POTW_TRTMNT_TECHNOLOGY_PRMT';

PRINT N'Creating Extended Property [dbo].[ICS_POTW_TRTMNT_TECHNOLOGY_PRMT].[SRC_SYSTM_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SourceSystemIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_POTW_TRTMNT_TECHNOLOGY_PRMT', @level2type = N'COLUMN', @level2name = N'SRC_SYSTM_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_POTW_TRTMNT_TECHNOLOGY_PRMT].[TRANSACTION_TYPE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TransactionType', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_POTW_TRTMNT_TECHNOLOGY_PRMT', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TYPE';

PRINT N'Creating Extended Property [dbo].[ICS_POTW_TRTMNT_TECHNOLOGY_PRMT].[TRANSACTION_TIMESTAMP].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TransactionTimestamp', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_POTW_TRTMNT_TECHNOLOGY_PRMT', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TIMESTAMP';

PRINT N'Creating Extended Property [dbo].[ICS_POTW_TRTMNT_TECHNOLOGY_PRMT].[PRMT_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermitIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_POTW_TRTMNT_TECHNOLOGY_PRMT', @level2type = N'COLUMN', @level2name = N'PRMT_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_POTW_TRTMNT_TECHNOLOGY_PRMT].[POTW_TRTMNT_LEVEL_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'POTWTreatmentLevelCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_POTW_TRTMNT_TECHNOLOGY_PRMT', @level2type = N'COLUMN', @level2name = N'POTW_TRTMNT_LEVEL_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_POTW_TRTMNT_TECHNOLOGY_PRMT].[POTW_TRTMNT_LEVEL_OTHR_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'POTWTreatmentLevelOtherText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_POTW_TRTMNT_TECHNOLOGY_PRMT', @level2type = N'COLUMN', @level2name = N'POTW_TRTMNT_LEVEL_OTHR_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_POTW_TRTMNT_TECHNOLOGY_PRMT].[POTW_WW_DISINFECTION_TECHNOLOGY_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'POTWWastewaterDisinfectionTechnologyCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_POTW_TRTMNT_TECHNOLOGY_PRMT', @level2type = N'COLUMN', @level2name = N'POTW_WW_DISINFECTION_TECHNOLOGY_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_POTW_TRTMNT_TECHNOLOGY_PRMT].[POTW_WW_DISINFECTION_TECHNOLOGY_OTHR_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'POTWWastewaterDisinfectionTechnologyOtherText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_POTW_TRTMNT_TECHNOLOGY_PRMT', @level2type = N'COLUMN', @level2name = N'POTW_WW_DISINFECTION_TECHNOLOGY_OTHR_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_POTW_TRTMNT_TECHNOLOGY_PRMT].[POTW_WW_TRTMNT_TECHNOLOGY_UNIT_OPERATION_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'POTWWastewaterTreatmentTechnologyUnitOperationCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_POTW_TRTMNT_TECHNOLOGY_PRMT', @level2type = N'COLUMN', @level2name = N'POTW_WW_TRTMNT_TECHNOLOGY_UNIT_OPERATION_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_POTW_TRTMNT_TECHNOLOGY_PRMT].[POTW_WW_TRTMNT_TECHNOLOGY_UNIT_OPERATION_OTHR_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'POTWWastewaterTreatmentTechnologyUnitOperationOtherText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_POTW_TRTMNT_TECHNOLOGY_PRMT', @level2type = N'COLUMN', @level2name = N'POTW_WW_TRTMNT_TECHNOLOGY_UNIT_OPERATION_OTHR_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_PRETR_PROG_MOD].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: PretreatmentProgramModification', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PROG_MOD';

PRINT N'Creating Extended Property [dbo].[ICS_PRETR_PROG_MOD].[PRETR_PROG_MOD_TYPE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PretreatmentProgramModificationType', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PROG_MOD', @level2type = N'COLUMN', @level2name = N'PRETR_PROG_MOD_TYPE';

PRINT N'Creating Extended Property [dbo].[ICS_PRETR_PROG_MOD].[PRETR_PROG_MOD_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PretreatmentProgramModificationDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PROG_MOD', @level2type = N'COLUMN', @level2name = N'PRETR_PROG_MOD_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_PRETR_PROG_MOD].[PRETR_PROG_MOD_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PretreatmentProgramModificationText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PROG_MOD', @level2type = N'COLUMN', @level2name = N'PRETR_PROG_MOD_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_PRETR_PROG_REP].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: PretreatmentProgramReportData', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PROG_REP';

PRINT N'Creating Extended Property [dbo].[ICS_PRETR_PROG_REP].[SRC_SYSTM_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SourceSystemIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PROG_REP', @level2type = N'COLUMN', @level2name = N'SRC_SYSTM_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_PRETR_PROG_REP].[TRANSACTION_TYPE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TransactionType', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PROG_REP', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TYPE';

PRINT N'Creating Extended Property [dbo].[ICS_PRETR_PROG_REP].[TRANSACTION_TIMESTAMP].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TransactionTimestamp', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PROG_REP', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TIMESTAMP';

PRINT N'Creating Extended Property [dbo].[ICS_PRETR_PROG_REP].[PRMT_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermitIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PROG_REP', @level2type = N'COLUMN', @level2name = N'PRMT_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_PRETR_PROG_REP].[PROG_REP_FORM_SET_ID].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ProgramReportFormSetID', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PROG_REP', @level2type = N'COLUMN', @level2name = N'PROG_REP_FORM_SET_ID';

PRINT N'Creating Extended Property [dbo].[ICS_PRETR_PROG_REP].[PROG_REP_FORM_ID].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ProgramReportFormID', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PROG_REP', @level2type = N'COLUMN', @level2name = N'PROG_REP_FORM_ID';

PRINT N'Creating Extended Property [dbo].[ICS_PRETR_PROG_REP].[PROG_REP_RCVD_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ProgramReportReceivedDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PROG_REP', @level2type = N'COLUMN', @level2name = N'PROG_REP_RCVD_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_PRETR_PROG_REP].[PROG_REP_START_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ProgramReportStartDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PROG_REP', @level2type = N'COLUMN', @level2name = N'PROG_REP_START_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_PRETR_PROG_REP].[PROG_REP_END_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ProgramReportEndDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PROG_REP', @level2type = N'COLUMN', @level2name = N'PROG_REP_END_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_PRETR_PROG_REP].[ELEC_SUBM_TYPE_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ElectronicSubmissionTypeCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PROG_REP', @level2type = N'COLUMN', @level2name = N'ELEC_SUBM_TYPE_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_PRETR_PROG_REP].[PROG_REP_NPDES_DAT_GRP_NUM_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ProgramReportNPDESDataGroupNumberCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRETR_PROG_REP', @level2type = N'COLUMN', @level2name = N'PROG_REP_NPDES_DAT_GRP_NUM_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_PRMT_BS_MGMT_PRACTICE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: PermitBiosolidsManagementPracticeData', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRMT_BS_MGMT_PRACTICE';

PRINT N'Creating Extended Property [dbo].[ICS_PRMT_BS_MGMT_PRACTICE].[SSU_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SSUIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRMT_BS_MGMT_PRACTICE', @level2type = N'COLUMN', @level2name = N'SSU_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_PRMT_BS_MGMT_PRACTICE].[BS_MGMT_PRACTICE_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'BiosolidsManagementPracticeCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRMT_BS_MGMT_PRACTICE', @level2type = N'COLUMN', @level2name = N'BS_MGMT_PRACTICE_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_PRMT_BS_MGMT_PRACTICE].[BS_MGMT_PRACTICE_SUB_CATG_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'BiosolidsManagementPracticeSubCateryCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRMT_BS_MGMT_PRACTICE', @level2type = N'COLUMN', @level2name = N'BS_MGMT_PRACTICE_SUB_CATG_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_PRMT_BS_MGMT_PRACTICE].[BS_MGMT_PRACTICE_SUB_CATG_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'BiosolidsManagementPracticeSubCateryText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRMT_BS_MGMT_PRACTICE', @level2type = N'COLUMN', @level2name = N'BS_MGMT_PRACTICE_SUB_CATG_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_PRMT_BS_MGMT_PRACTICE].[BS_OPERATOR_TYPE_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'BiosolidsOperatorTypeCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRMT_BS_MGMT_PRACTICE', @level2type = N'COLUMN', @level2name = N'BS_OPERATOR_TYPE_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_PRMT_BS_MGMT_PRACTICE].[BS_CNTNR_TYPE_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'BiosolidsContainerTypeCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRMT_BS_MGMT_PRACTICE', @level2type = N'COLUMN', @level2name = N'BS_CNTNR_TYPE_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_PRMT_BS_MGMT_PRACTICE].[SSUID_VOL_AMT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SSUIDVolumeAmount', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRMT_BS_MGMT_PRACTICE', @level2type = N'COLUMN', @level2name = N'SSUID_VOL_AMT';

PRINT N'Creating Extended Property [dbo].[ICS_PRMT_BS_MGMT_PRACTICE].[PATHOGEN_CLASS_TYPE_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PathogenClassTypeCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRMT_BS_MGMT_PRACTICE', @level2type = N'COLUMN', @level2name = N'PATHOGEN_CLASS_TYPE_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_PRMT_BS_MGMT_PRACTICE].[POLUT_LOADING_RATES_EXCEEDANCE_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PollutantLoadingRatesExceedanceIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRMT_BS_MGMT_PRACTICE', @level2type = N'COLUMN', @level2name = N'POLUT_LOADING_RATES_EXCEEDANCE_IND';

PRINT N'Creating Extended Property [dbo].[ICS_PRMT_BS_MGMT_PRACTICE].[SURF_DSPL_WITHOUT_LINER_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SurfaceDisposalWithoutLinerIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRMT_BS_MGMT_PRACTICE', @level2type = N'COLUMN', @level2name = N'SURF_DSPL_WITHOUT_LINER_IND';

PRINT N'Creating Extended Property [dbo].[ICS_PRMT_BS_MGMT_PRACTICE].[SURF_DSPL_SITE_SPEC_LMT_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SurfaceDisposalSiteSpecificLimitIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRMT_BS_MGMT_PRACTICE', @level2type = N'COLUMN', @level2name = N'SURF_DSPL_SITE_SPEC_LMT_IND';

PRINT N'Creating Extended Property [dbo].[ICS_PRMT_BS_MGMT_PRACTICE].[SURF_DSPL_MIN_BOUNDARY_DISTANCE_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SurfaceDisposalMinimumBoundaryDistanceCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRMT_BS_MGMT_PRACTICE', @level2type = N'COLUMN', @level2name = N'SURF_DSPL_MIN_BOUNDARY_DISTANCE_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_PRMT_BS_MGMT_PRACTICE].[BS_OFF_SITE_FAC_PRMT_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'BiosolidsOffSiteFacilityPermitIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PRMT_BS_MGMT_PRACTICE', @level2type = N'COLUMN', @level2name = N'BS_OFF_SITE_FAC_PRMT_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_PROPOSED_CNST_SW_BM_PS].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: ProposedConstructionStormwaterBMPs', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PROPOSED_CNST_SW_BM_PS';

PRINT N'Creating Extended Property [dbo].[ICS_PROPOSED_CNST_SW_BM_PS].[PROPOSED_CNST_SW_BMP_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ProposedConstructionStormwaterBMPCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PROPOSED_CNST_SW_BM_PS', @level2type = N'COLUMN', @level2name = N'PROPOSED_CNST_SW_BMP_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_PROPOSED_CNST_SW_BM_PS].[PROPOSED_CNST_SW_BMP_OTHR_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ProposedConstructionStormwaterBMPOtherText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PROPOSED_CNST_SW_BM_PS', @level2type = N'COLUMN', @level2name = N'PROPOSED_CNST_SW_BMP_OTHR_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_PROPOSED_INDST_SW_BM_PS].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: ProposedIndustrialStormwaterBMPs', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PROPOSED_INDST_SW_BM_PS';

PRINT N'Creating Extended Property [dbo].[ICS_PROPOSED_INDST_SW_BM_PS].[PROPOSED_INDST_SW_BMP_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ProposedIndustrialStormwaterBMPCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PROPOSED_INDST_SW_BM_PS', @level2type = N'COLUMN', @level2name = N'PROPOSED_INDST_SW_BMP_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_PROPOSED_INDST_SW_BM_PS].[PROPOSED_INDST_SW_BMP_OTHR_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ProposedIndustrialStormwaterBMPOtherText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PROPOSED_INDST_SW_BM_PS', @level2type = N'COLUMN', @level2name = N'PROPOSED_INDST_SW_BMP_OTHR_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_PROPOSED_POST_CNST_SW_BM_PS].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: ProposedPostConstructionStormwaterBMPs', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PROPOSED_POST_CNST_SW_BM_PS';

PRINT N'Creating Extended Property [dbo].[ICS_PROPOSED_POST_CNST_SW_BM_PS].[PROPOSED_POST_CNST_SW_BMP_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ProposedPostConstructionStormwaterBMPCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PROPOSED_POST_CNST_SW_BM_PS', @level2type = N'COLUMN', @level2name = N'PROPOSED_POST_CNST_SW_BMP_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_PROPOSED_POST_CNST_SW_BM_PS].[PROPOSED_POST_CNST_SW_BMP_OTHR_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ProposedPostConstructionStormwaterBMPOtherText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_PROPOSED_POST_CNST_SW_BM_PS', @level2type = N'COLUMN', @level2name = N'PROPOSED_POST_CNST_SW_BMP_OTHR_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_RESIDUAL_DESGN_DTRMN].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: ResidualDesignationDetermination', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_RESIDUAL_DESGN_DTRMN';

PRINT N'Creating Extended Property [dbo].[ICS_RESIDUAL_DESGN_DTRMN].[RESIDUAL_DESGN_DTRMN_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ResidualDesignationDeterminationCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_RESIDUAL_DESGN_DTRMN', @level2type = N'COLUMN', @level2name = N'RESIDUAL_DESGN_DTRMN_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_RESIDUAL_DESGN_DTRMN].[RESIDUAL_DESGN_DTRMN_OTHR_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ResidualDesignationDeterminationOtherText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_RESIDUAL_DESGN_DTRMN', @level2type = N'COLUMN', @level2name = N'RESIDUAL_DESGN_DTRMN_OTHR_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_SEWER_OVRFLW_BYPASS_CAUSE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: SewerOverflowBypassCause', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SEWER_OVRFLW_BYPASS_CAUSE';

PRINT N'Creating Extended Property [dbo].[ICS_SEWER_OVRFLW_BYPASS_CAUSE].[SEWER_OVRFLW_BYPASS_CAUSE_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SewerOverflowBypassCauseCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SEWER_OVRFLW_BYPASS_CAUSE', @level2type = N'COLUMN', @level2name = N'SEWER_OVRFLW_BYPASS_CAUSE_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_SEWER_OVRFLW_BYPASS_CAUSE].[SEWER_OVRFLW_BYPASS_CAUSE_OTHR_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SewerOverflowBypassCauseOtherText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SEWER_OVRFLW_BYPASS_CAUSE', @level2type = N'COLUMN', @level2name = N'SEWER_OVRFLW_BYPASS_CAUSE_OTHR_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_SEWER_OVRFLW_BYPASS_CORR_ACTN].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: SewerOverflowBypassCorrectiveAction', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SEWER_OVRFLW_BYPASS_CORR_ACTN';

PRINT N'Creating Extended Property [dbo].[ICS_SEWER_OVRFLW_BYPASS_CORR_ACTN].[SEWER_OVRFLW_BYPASS_CORR_ACTN_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SewerOverflowBypassCorrectiveActionCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SEWER_OVRFLW_BYPASS_CORR_ACTN', @level2type = N'COLUMN', @level2name = N'SEWER_OVRFLW_BYPASS_CORR_ACTN_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_SEWER_OVRFLW_BYPASS_CORR_ACTN].[SEWER_OVRFLW_BYPASS_CORR_ACTN_OTHR_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SewerOverflowBypassCorrectiveActionOtherText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SEWER_OVRFLW_BYPASS_CORR_ACTN', @level2type = N'COLUMN', @level2name = N'SEWER_OVRFLW_BYPASS_CORR_ACTN_OTHR_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: SewerOverflowBypassEventReportData', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SEWER_OVRFLW_BYPASS_EVT_REP';

PRINT N'Creating Extended Property [dbo].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP].[SRC_SYSTM_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SourceSystemIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SEWER_OVRFLW_BYPASS_EVT_REP', @level2type = N'COLUMN', @level2name = N'SRC_SYSTM_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP].[TRANSACTION_TYPE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TransactionType', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SEWER_OVRFLW_BYPASS_EVT_REP', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TYPE';

PRINT N'Creating Extended Property [dbo].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP].[TRANSACTION_TIMESTAMP].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TransactionTimestamp', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SEWER_OVRFLW_BYPASS_EVT_REP', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TIMESTAMP';

PRINT N'Creating Extended Property [dbo].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP].[PRMT_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermitIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SEWER_OVRFLW_BYPASS_EVT_REP', @level2type = N'COLUMN', @level2name = N'PRMT_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP].[PROG_REP_FORM_SET_ID].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ProgramReportFormSetID', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SEWER_OVRFLW_BYPASS_EVT_REP', @level2type = N'COLUMN', @level2name = N'PROG_REP_FORM_SET_ID';

PRINT N'Creating Extended Property [dbo].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP].[PROG_REP_FORM_ID].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ProgramReportFormID', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SEWER_OVRFLW_BYPASS_EVT_REP', @level2type = N'COLUMN', @level2name = N'PROG_REP_FORM_ID';

PRINT N'Creating Extended Property [dbo].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP].[PROG_REP_RCVD_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ProgramReportReceivedDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SEWER_OVRFLW_BYPASS_EVT_REP', @level2type = N'COLUMN', @level2name = N'PROG_REP_RCVD_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP].[PROG_REP_START_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ProgramReportStartDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SEWER_OVRFLW_BYPASS_EVT_REP', @level2type = N'COLUMN', @level2name = N'PROG_REP_START_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP].[PROG_REP_END_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ProgramReportEndDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SEWER_OVRFLW_BYPASS_EVT_REP', @level2type = N'COLUMN', @level2name = N'PROG_REP_END_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP].[ELEC_SUBM_TYPE_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ElectronicSubmissionTypeCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SEWER_OVRFLW_BYPASS_EVT_REP', @level2type = N'COLUMN', @level2name = N'ELEC_SUBM_TYPE_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP].[PROG_REP_NPDES_DAT_GRP_NUM_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ProgramReportNPDESDataGroupNumberCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SEWER_OVRFLW_BYPASS_EVT_REP', @level2type = N'COLUMN', @level2name = N'PROG_REP_NPDES_DAT_GRP_NUM_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_SEWER_OVRFLW_BYPASS_IMPACT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: SewerOverflowBypassImpact', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SEWER_OVRFLW_BYPASS_IMPACT';

PRINT N'Creating Extended Property [dbo].[ICS_SEWER_OVRFLW_BYPASS_IMPACT].[SEWER_OVRFLW_BYPASS_IMPACT_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SewerOverflowBypassImpactCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SEWER_OVRFLW_BYPASS_IMPACT', @level2type = N'COLUMN', @level2name = N'SEWER_OVRFLW_BYPASS_IMPACT_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_SEWER_OVRFLW_BYPASS_IMPACT].[SEWER_OVRFLW_BYPASS_IMPACT_OTHR_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SewerOverflowBypassImpactOtherText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SEWER_OVRFLW_BYPASS_IMPACT', @level2type = N'COLUMN', @level2name = N'SEWER_OVRFLW_BYPASS_IMPACT_OTHR_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_SEWER_OVRFLW_BYPASS_RCVG_WTR].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: String', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SEWER_OVRFLW_BYPASS_RCVG_WTR';

PRINT N'Creating Extended Property [dbo].[ICS_SEWER_OVRFLW_BYPASS_RCVG_WTR].[SEWER_OVRFLW_BYPASS_RCVG_WTR].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SewerOverflowBypassReceivingWater', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SEWER_OVRFLW_BYPASS_RCVG_WTR', @level2type = N'COLUMN', @level2name = N'SEWER_OVRFLW_BYPASS_RCVG_WTR';

PRINT N'Creating Extended Property [dbo].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: SewerOverflowBypassReportEvent', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SEWER_OVRFLW_BYPASS_REP_EVT';

PRINT N'Creating Extended Property [dbo].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT].[LAT_MEAS].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'LatitudeMeasure', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SEWER_OVRFLW_BYPASS_REP_EVT', @level2type = N'COLUMN', @level2name = N'LAT_MEAS';

PRINT N'Creating Extended Property [dbo].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT].[LONG_MEAS].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'LongitudeMeasure', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SEWER_OVRFLW_BYPASS_REP_EVT', @level2type = N'COLUMN', @level2name = N'LONG_MEAS';

PRINT N'Creating Extended Property [dbo].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT].[PRMT_FEATR_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermittedFeatureIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SEWER_OVRFLW_BYPASS_REP_EVT', @level2type = N'COLUMN', @level2name = N'PRMT_FEATR_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT].[DSCH_QUANTIFICATION_METHOD_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'DischargeQuantificationMethodCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SEWER_OVRFLW_BYPASS_REP_EVT', @level2type = N'COLUMN', @level2name = N'DSCH_QUANTIFICATION_METHOD_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT].[SEWER_OVRFLW_BYPASS_DSCH_RATE_GPH].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SewerOverflowBypassDischargeRateGPH', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SEWER_OVRFLW_BYPASS_REP_EVT', @level2type = N'COLUMN', @level2name = N'SEWER_OVRFLW_BYPASS_DSCH_RATE_GPH';

PRINT N'Creating Extended Property [dbo].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT].[SEWER_OVRFLW_BYPASS_DSCH_VOL_GAL].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SewerOverflowBypassDischargeVolumeGallons', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SEWER_OVRFLW_BYPASS_REP_EVT', @level2type = N'COLUMN', @level2name = N'SEWER_OVRFLW_BYPASS_DSCH_VOL_GAL';

PRINT N'Creating Extended Property [dbo].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT].[SEWER_OVRFLW_BYPASS_EVT_ID].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SewerOverflowBypassEventID', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SEWER_OVRFLW_BYPASS_REP_EVT', @level2type = N'COLUMN', @level2name = N'SEWER_OVRFLW_BYPASS_EVT_ID';

PRINT N'Creating Extended Property [dbo].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT].[SEWER_OVRFLW_BYPASS_DESC_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SewerOverflowBypassDescriptionText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SEWER_OVRFLW_BYPASS_REP_EVT', @level2type = N'COLUMN', @level2name = N'SEWER_OVRFLW_BYPASS_DESC_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT].[SEWER_OVRFLW_BYPASS_REP_REQ_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SewerOverflowBypassReportingRequirementCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SEWER_OVRFLW_BYPASS_REP_EVT', @level2type = N'COLUMN', @level2name = N'SEWER_OVRFLW_BYPASS_REP_REQ_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT].[WET_WEATHER_OCCURANCE_IND].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'WetWeatherOccuranceIndicator', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SEWER_OVRFLW_BYPASS_REP_EVT', @level2type = N'COLUMN', @level2name = N'WET_WEATHER_OCCURANCE_IND';

PRINT N'Creating Extended Property [dbo].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT].[SEWER_OVRFLW_STRCT_TYPE_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SewerOverflowStructureTypeCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SEWER_OVRFLW_BYPASS_REP_EVT', @level2type = N'COLUMN', @level2name = N'SEWER_OVRFLW_STRCT_TYPE_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT].[SEWER_OVRFLW_STRCT_TYPE_CODE_OTHR_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SewerOverflowStructureTypeCodeOtherText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SEWER_OVRFLW_BYPASS_REP_EVT', @level2type = N'COLUMN', @level2name = N'SEWER_OVRFLW_STRCT_TYPE_CODE_OTHR_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT].[COLL_SYSTM_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'CollectionSystemIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SEWER_OVRFLW_BYPASS_REP_EVT', @level2type = N'COLUMN', @level2name = N'COLL_SYSTM_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT].[ANTICIPATED_BYPASS_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'AnticipatedBypassText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SEWER_OVRFLW_BYPASS_REP_EVT', @level2type = N'COLUMN', @level2name = N'ANTICIPATED_BYPASS_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT].[ANTICIPATED_BYPASS_EXPECT_LMT_VIOL].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'AnticipatedBypassExpectLimitViolation', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SEWER_OVRFLW_BYPASS_REP_EVT', @level2type = N'COLUMN', @level2name = N'ANTICIPATED_BYPASS_EXPECT_LMT_VIOL';

PRINT N'Creating Extended Property [dbo].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT].[ANTICIPATED_BYPASS_EXPECT_LMT_VIOL_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'AnticipatedBypassExpectLimitViolationText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SEWER_OVRFLW_BYPASS_REP_EVT', @level2type = N'COLUMN', @level2name = N'ANTICIPATED_BYPASS_EXPECT_LMT_VIOL_TXT';

PRINT N'Creating Extended Property [dbo].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT].[SEWER_OVRFLW_BYPASS_DURATION_HOURS].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SewerOverflowBypassDurationHours', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SEWER_OVRFLW_BYPASS_REP_EVT', @level2type = N'COLUMN', @level2name = N'SEWER_OVRFLW_BYPASS_DURATION_HOURS';

PRINT N'Creating Extended Property [dbo].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT].[SEWER_OVRFLW_BYPASS_START_DATE_TIME].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SewerOverflowBypassStartDateTime', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SEWER_OVRFLW_BYPASS_REP_EVT', @level2type = N'COLUMN', @level2name = N'SEWER_OVRFLW_BYPASS_START_DATE_TIME';

PRINT N'Creating Extended Property [dbo].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT].[SEWER_OVRFLW_BYPASS_END_DATE_TIME].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SewerOverflowBypassEndDateTime', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SEWER_OVRFLW_BYPASS_REP_EVT', @level2type = N'COLUMN', @level2name = N'SEWER_OVRFLW_BYPASS_END_DATE_TIME';

PRINT N'Creating Extended Property [dbo].[ICS_SEWER_OVRFLW_BYPASS_TYPE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: String', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SEWER_OVRFLW_BYPASS_TYPE';

PRINT N'Creating Extended Property [dbo].[ICS_SEWER_OVRFLW_BYPASS_TYPE].[SEWER_OVRFLW_BYPASS_TYPE_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SewerOverflowBypassTypeCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SEWER_OVRFLW_BYPASS_TYPE', @level2type = N'COLUMN', @level2name = N'SEWER_OVRFLW_BYPASS_TYPE_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_SEWER_OVRFLW_TRTMNT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: String', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SEWER_OVRFLW_TRTMNT';

PRINT N'Creating Extended Property [dbo].[ICS_SEWER_OVRFLW_TRTMNT].[SEWER_OVRFLW_TRTMNT_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SewerOverflowTreatmentCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SEWER_OVRFLW_TRTMNT', @level2type = N'COLUMN', @level2name = N'SEWER_OVRFLW_TRTMNT_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_SIU_DESGN_TYPE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: String', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SIU_DESGN_TYPE';

PRINT N'Creating Extended Property [dbo].[ICS_SIU_DESGN_TYPE].[SIU_DESGN_TYPE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SIUDesignationType', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SIU_DESGN_TYPE', @level2type = N'COLUMN', @level2name = N'SIU_DESGN_TYPE';

PRINT N'Creating Extended Property [dbo].[ICS_SNC_LISTING_MONTHS].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: String', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SNC_LISTING_MONTHS';

PRINT N'Creating Extended Property [dbo].[ICS_SNC_LISTING_MONTHS].[SNC_LISTING_MONTHS].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SNCListingMonths', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SNC_LISTING_MONTHS', @level2type = N'COLUMN', @level2name = N'SNC_LISTING_MONTHS';

PRINT N'Creating Extended Property [dbo].[ICS_SNC_PRETR_STND_LMTS_PARAMETERS].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: String', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SNC_PRETR_STND_LMTS_PARAMETERS';

PRINT N'Creating Extended Property [dbo].[ICS_SNC_PRETR_STND_LMTS_PARAMETERS].[SNC_PRETR_STND_LMTS_PARAMETERS].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SNCPretrStndLimitsParameters', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SNC_PRETR_STND_LMTS_PARAMETERS', @level2type = N'COLUMN', @level2name = N'SNC_PRETR_STND_LMTS_PARAMETERS';

PRINT N'Creating Extended Property [dbo].[ICS_SUBSECTOR_CODE_PLUS_DESC].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: String', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SUBSECTOR_CODE_PLUS_DESC';

PRINT N'Creating Extended Property [dbo].[ICS_SUBSECTOR_CODE_PLUS_DESC].[SUBSECTOR_CODE_PLUS_DESC].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SubsectorCodePlusDescription', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SUBSECTOR_CODE_PLUS_DESC', @level2type = N'COLUMN', @level2name = N'SUBSECTOR_CODE_PLUS_DESC';

PRINT N'Creating Extended Property [dbo].[ICS_SWMS_4_ANNUL_PROG_REP].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: SWMS4AnnualProgramReportData', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_ANNUL_PROG_REP';

PRINT N'Creating Extended Property [dbo].[ICS_SWMS_4_ANNUL_PROG_REP].[SRC_SYSTM_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SourceSystemIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_ANNUL_PROG_REP', @level2type = N'COLUMN', @level2name = N'SRC_SYSTM_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_SWMS_4_ANNUL_PROG_REP].[TRANSACTION_TYPE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TransactionType', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_ANNUL_PROG_REP', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TYPE';

PRINT N'Creating Extended Property [dbo].[ICS_SWMS_4_ANNUL_PROG_REP].[TRANSACTION_TIMESTAMP].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TransactionTimestamp', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_ANNUL_PROG_REP', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TIMESTAMP';

PRINT N'Creating Extended Property [dbo].[ICS_SWMS_4_ANNUL_PROG_REP].[PRMT_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermitIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_ANNUL_PROG_REP', @level2type = N'COLUMN', @level2name = N'PRMT_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_SWMS_4_ANNUL_PROG_REP].[PROG_REP_FORM_SET_ID].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ProgramReportFormSetID', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_ANNUL_PROG_REP', @level2type = N'COLUMN', @level2name = N'PROG_REP_FORM_SET_ID';

PRINT N'Creating Extended Property [dbo].[ICS_SWMS_4_ANNUL_PROG_REP].[PROG_REP_FORM_ID].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ProgramReportFormID', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_ANNUL_PROG_REP', @level2type = N'COLUMN', @level2name = N'PROG_REP_FORM_ID';

PRINT N'Creating Extended Property [dbo].[ICS_SWMS_4_ANNUL_PROG_REP].[PROG_REP_RCVD_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ProgramReportReceivedDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_ANNUL_PROG_REP', @level2type = N'COLUMN', @level2name = N'PROG_REP_RCVD_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_SWMS_4_ANNUL_PROG_REP].[PROG_REP_START_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ProgramReportStartDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_ANNUL_PROG_REP', @level2type = N'COLUMN', @level2name = N'PROG_REP_START_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_SWMS_4_ANNUL_PROG_REP].[PROG_REP_END_DATE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ProgramReportEndDate', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_ANNUL_PROG_REP', @level2type = N'COLUMN', @level2name = N'PROG_REP_END_DATE';

PRINT N'Creating Extended Property [dbo].[ICS_SWMS_4_ANNUL_PROG_REP].[ELEC_SUBM_TYPE_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ElectronicSubmissionTypeCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_ANNUL_PROG_REP', @level2type = N'COLUMN', @level2name = N'ELEC_SUBM_TYPE_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_SWMS_4_ANNUL_PROG_REP].[PROG_REP_NPDES_DAT_GRP_NUM_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'ProgramReportNPDESDataGroupNumberCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_ANNUL_PROG_REP', @level2type = N'COLUMN', @level2name = N'PROG_REP_NPDES_DAT_GRP_NUM_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_SWMS_4_PRMT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'Schema element: SWMS4PermitData', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_PRMT';

PRINT N'Creating Extended Property [dbo].[ICS_SWMS_4_PRMT].[SRC_SYSTM_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'SourceSystemIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_PRMT', @level2type = N'COLUMN', @level2name = N'SRC_SYSTM_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_SWMS_4_PRMT].[TRANSACTION_TYPE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TransactionType', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_PRMT', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TYPE';

PRINT N'Creating Extended Property [dbo].[ICS_SWMS_4_PRMT].[TRANSACTION_TIMESTAMP].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'TransactionTimestamp', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_PRMT', @level2type = N'COLUMN', @level2name = N'TRANSACTION_TIMESTAMP';

PRINT N'Creating Extended Property [dbo].[ICS_SWMS_4_PRMT].[PRMT_IDENT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'PermitIdentifier', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_PRMT', @level2type = N'COLUMN', @level2name = N'PRMT_IDENT';

PRINT N'Creating Extended Property [dbo].[ICS_SWMS_4_PRMT].[MS_4_PRMT_PHASE_CODE].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4PermitPhaseCode', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_PRMT', @level2type = N'COLUMN', @level2name = N'MS_4_PRMT_PHASE_CODE';

PRINT N'Creating Extended Property [dbo].[ICS_SWMS_4_PRMT].[MS_4_PRMT_PHASE_TXT].[MS_Description]...';

EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'MS4PermitPhaseText', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ICS_SWMS_4_PRMT', @level2type = N'COLUMN', @level2name = N'MS_4_PRMT_PHASE_TXT';

PRINT N'Checking existing data against newly created constraints';

ALTER TABLE [dbo].[ICS_ADDR] WITH CHECK CHECK CONSTRAINT [FK_ADDR_BASIC_PRMT];
ALTER TABLE [dbo].[ICS_ADDR] WITH CHECK CHECK CONSTRAINT [FK_ADDR_CAFO_PRMT];
ALTER TABLE [dbo].[ICS_ADDR] WITH CHECK CHECK CONSTRAINT [FK_ADDR_FAC];
ALTER TABLE [dbo].[ICS_ADDR] WITH CHECK CHECK CONSTRAINT [FK_ADDR_GNRL_PRMT];
ALTER TABLE [dbo].[ICS_ADDR] WITH CHECK CHECK CONSTRAINT [FK_ADDR_PRMT_FEATR];
ALTER TABLE [dbo].[ICS_ADDR] WITH CHECK CHECK CONSTRAINT [FK_ADDR_SW_CNST_PRMT];
ALTER TABLE [dbo].[ICS_ADDR] WITH CHECK CHECK CONSTRAINT [FK_ADDR_SW_INDST_PRMT];
ALTER TABLE [dbo].[ICS_ADDR] WITH CHECK CHECK CONSTRAINT [FK_ADDR_UNPRMT_FAC];
ALTER TABLE [dbo].[ICS_TELEPH] WITH CHECK CHECK CONSTRAINT [FK_TELEPH_ADDR];
ALTER TABLE [dbo].[ICS_ADDR] WITH CHECK CHECK CONSTRAINT [FK_ADDR_BS_OFF_SIT_HND_APP_PRP];
ALTER TABLE [dbo].[ICS_ANML_TYPE] WITH CHECK CHECK CONSTRAINT [FK_ANML_TYPE_CAFO_INSP];
ALTER TABLE [dbo].[ICS_ANML_TYPE] WITH CHECK CHECK CONSTRAINT [FK_ANML_TYPE_CAFO_PRMT];
ALTER TABLE [dbo].[ICS_ANML_TYPE] WITH CHECK CHECK CONSTRAINT [FK_ANML_TYPE_CAFO_ANNL_PRO_REP];
ALTER TABLE [dbo].[ICS_EFFLU_GUIDE] WITH CHECK CHECK CONSTRAINT [FK_EFFLU_GUIDE_BASIC_PRMT];
ALTER TABLE [dbo].[ICS_FAC] WITH CHECK CHECK CONSTRAINT [FK_FAC_BASIC_PRMT];
ALTER TABLE [dbo].[ICS_REP_NON_CMPL_STAT] WITH CHECK CHECK CONSTRAINT [FK_REP_NON_CMPL_STAT_BSIC_PRMT];
ALTER TABLE [dbo].[ICS_SIC_CODE] WITH CHECK CHECK CONSTRAINT [FK_SIC_CODE_BASIC_PRMT];
ALTER TABLE [dbo].[ICS_ASSC_PRMT] WITH CHECK CHECK CONSTRAINT [FK_ASSC_PRMT_BASIC_PRMT];
ALTER TABLE [dbo].[ICS_BASIC_PRMT] WITH CHECK CHECK CONSTRAINT [FK_BASIC_PRMT_PAYLOAD];
ALTER TABLE [dbo].[ICS_CMPL_TRACK_STAT] WITH CHECK CHECK CONSTRAINT [FK_CMPL_TRACK_STAT_BASIC_PRMT];
ALTER TABLE [dbo].[ICS_NAICS_CODE] WITH CHECK CHECK CONSTRAINT [FK_NAICS_CODE_BASIC_PRMT];
ALTER TABLE [dbo].[ICS_CONTACT] WITH CHECK CHECK CONSTRAINT [FK_CONTACT_BASIC_PRMT];
ALTER TABLE [dbo].[ICS_NPDES_DAT_GRP_NUM] WITH CHECK CHECK CONSTRAINT [FK_NPDES_DAT_GRP_NUM_BSIC_PRMT];
ALTER TABLE [dbo].[ICS_OTHR_PRMTS] WITH CHECK CHECK CONSTRAINT [FK_OTHR_PRMTS_BASIC_PRMT];
ALTER TABLE [dbo].[ICS_ANLYTCL_METHOD] WITH CHECK CHECK CONSTRAINT [FK_ANLYT_MTHD_BS_ANNL_PROG_REP];
ALTER TABLE [dbo].[ICS_BS_ANNUL_PROG_REP] WITH CHECK CHECK CONSTRAINT [FK_BS_ANNUL_PROG_REP_PAYLOAD];
ALTER TABLE [dbo].[ICS_BS_PRMT] WITH CHECK CHECK CONSTRAINT [FK_BS_PRMT_PAYLOAD];
ALTER TABLE [dbo].[ICS_LAND_APPL_BMP] WITH CHECK CHECK CONSTRAINT [FK_LAND_APPL_BMP_CAFO_INSP];
ALTER TABLE [dbo].[ICS_CAFO_INSP] WITH CHECK CHECK CONSTRAINT [FK_CAFO_INSP_CMPL_MON];
ALTER TABLE [dbo].[ICS_CAFO_INSP_VIOL_TYPE] WITH CHECK CHECK CONSTRAINT [FK_CAFO_INSP_VIOL_TYPE_CAF_INS];
ALTER TABLE [dbo].[ICS_MNUR_LTTR_PRCSS_WW_STOR] WITH CHECK CHECK CONSTRAINT [FK_MNUR_LTT_PRC_WW_STO_CAF_INS];
ALTER TABLE [dbo].[ICS_CONTAINMENT] WITH CHECK CHECK CONSTRAINT [FK_CONTAINMENT_CAFO_INSP];
ALTER TABLE [dbo].[ICS_CNST_SITE] WITH CHECK CHECK CONSTRAINT [FK_CNST_SITE_CNST_SITE_LIST];
ALTER TABLE [dbo].[ICS_TELEPH] WITH CHECK CHECK CONSTRAINT [FK_TELEPH_CONTACT];
ALTER TABLE [dbo].[ICS_CONTACT] WITH CHECK CHECK CONSTRAINT [FK_CONTACT_CAFO_PRMT];
ALTER TABLE [dbo].[ICS_CONTACT] WITH CHECK CHECK CONSTRAINT [FK_CONTACT_CMPL_MON];
ALTER TABLE [dbo].[ICS_CONTACT] WITH CHECK CHECK CONSTRAINT [FK_CONTACT_FAC];
ALTER TABLE [dbo].[ICS_CONTACT] WITH CHECK CHECK CONSTRAINT [FK_CONTACT_GNRL_PRMT];
ALTER TABLE [dbo].[ICS_CONTACT] WITH CHECK CHECK CONSTRAINT [FK_CONTACT_MASTER_GNRL_PRMT];
ALTER TABLE [dbo].[ICS_CONTACT] WITH CHECK CHECK CONSTRAINT [FK_CONTACT_PRETR_PRMT];
ALTER TABLE [dbo].[ICS_CONTACT] WITH CHECK CHECK CONSTRAINT [FK_CONTACT_PRMT_FEATR];
ALTER TABLE [dbo].[ICS_CONTACT] WITH CHECK CHECK CONSTRAINT [FK_CONTACT_SW_CNST_PRMT];
ALTER TABLE [dbo].[ICS_CONTACT] WITH CHECK CHECK CONSTRAINT [FK_CONTACT_SW_INDST_PRMT];
ALTER TABLE [dbo].[ICS_CONTACT] WITH CHECK CHECK CONSTRAINT [FK_CONTACT_UNPRMT_FAC];
ALTER TABLE [dbo].[ICS_CONTACT] WITH CHECK CHECK CONSTRAINT [FK_CNTC_BS_OFF_SIT_HND_APP_PRP];
ALTER TABLE [dbo].[ICS_COPY_MGP_LMT_SET] WITH CHECK CHECK CONSTRAINT [FK_COPY_MGP_LMT_SET_PAYLOAD];
ALTER TABLE [dbo].[ICS_REP_PARAM] WITH CHECK CHECK CONSTRAINT [FK_REP_PARAM_DSCH_MON_REP];
ALTER TABLE [dbo].[ICS_INCIN] WITH CHECK CHECK CONSTRAINT [FK_INCIN_DSCH_MON_REP];
ALTER TABLE [dbo].[ICS_LAND_APPL_SITE] WITH CHECK CHECK CONSTRAINT [FK_LAND_APPL_SITE_DSCH_MON_REP];
ALTER TABLE [dbo].[ICS_SURF_DSPL_SITE] WITH CHECK CHECK CONSTRAINT [FK_SURF_DSPL_SITE_DSCH_MON_REP];
ALTER TABLE [dbo].[ICS_CO_DSPL_SITE] WITH CHECK CHECK CONSTRAINT [FK_CO_DSPL_SITE_DSCH_MON_REP];
ALTER TABLE [dbo].[ICS_DSCH_MON_REP] WITH CHECK CHECK CONSTRAINT [FK_DSCH_MON_REP_PAYLOAD];
ALTER TABLE [dbo].[ICS_FAC] WITH CHECK CHECK CONSTRAINT [FK_FAC_GNRL_PRMT];
ALTER TABLE [dbo].[ICS_FAC_CLASS] WITH CHECK CHECK CONSTRAINT [FK_FAC_CLASS_FAC];
ALTER TABLE [dbo].[ICS_GEO_COORD] WITH CHECK CHECK CONSTRAINT [FK_GEO_COORD_FAC];
ALTER TABLE [dbo].[ICS_SIC_CODE] WITH CHECK CHECK CONSTRAINT [FK_SIC_CODE_FAC];
ALTER TABLE [dbo].[ICS_NAICS_CODE] WITH CHECK CHECK CONSTRAINT [FK_NAICS_CODE_FAC];
ALTER TABLE [dbo].[ICS_ORIG_PROGS] WITH CHECK CHECK CONSTRAINT [FK_ORIG_PROGS_FAC];
ALTER TABLE [dbo].[ICS_PLCY] WITH CHECK CHECK CONSTRAINT [FK_PLCY_FAC];
ALTER TABLE [dbo].[ICS_FINAL_ORDER] WITH CHECK CHECK CONSTRAINT [FK_FINAL_ORDER_FRML_ENFRC_ACTN];
ALTER TABLE [dbo].[ICS_FINAL_ORDER_PRMT_IDENT] WITH CHECK CHECK CONSTRAINT [FK_FINL_ORDR_PRMT_IDNT_FIN_ORD];
ALTER TABLE [dbo].[ICS_SEP] WITH CHECK CHECK CONSTRAINT [FK_SEP_FINAL_ORDER];
ALTER TABLE [dbo].[ICS_GEO_COORD] WITH CHECK CHECK CONSTRAINT [FK_GEO_COORD_PRMT_FEATR];
ALTER TABLE [dbo].[ICS_GEO_COORD] WITH CHECK CHECK CONSTRAINT [FK_GEO_COORD_UNPRMT_FAC];
ALTER TABLE [dbo].[ICS_GEO_COORD] WITH CHECK CHECK CONSTRAINT [FK_GEO_COORD_COPY_MGP_LMT_SET];
ALTER TABLE [dbo].[ICS_EFFLU_GUIDE] WITH CHECK CHECK CONSTRAINT [FK_EFFLU_GUIDE_GNRL_PRMT];
ALTER TABLE [dbo].[ICS_GNRL_PRMT] WITH CHECK CHECK CONSTRAINT [FK_GNRL_PRMT_PAYLOAD];
ALTER TABLE [dbo].[ICS_REP_NON_CMPL_STAT] WITH CHECK CHECK CONSTRAINT [FK_REP_NON_CMPL_STAT_GNRL_PRMT];
ALTER TABLE [dbo].[ICS_SIC_CODE] WITH CHECK CHECK CONSTRAINT [FK_SIC_CODE_GNRL_PRMT];
ALTER TABLE [dbo].[ICS_ASSC_PRMT] WITH CHECK CHECK CONSTRAINT [FK_ASSC_PRMT_GNRL_PRMT];
ALTER TABLE [dbo].[ICS_CMPL_TRACK_STAT] WITH CHECK CHECK CONSTRAINT [FK_CMPL_TRACK_STAT_GNRL_PRMT];
ALTER TABLE [dbo].[ICS_NAICS_CODE] WITH CHECK CHECK CONSTRAINT [FK_NAICS_CODE_GNRL_PRMT];
ALTER TABLE [dbo].[ICS_NPDES_DAT_GRP_NUM] WITH CHECK CHECK CONSTRAINT [FK_NPDES_DAT_GRP_NUM_GNRL_PRMT];
ALTER TABLE [dbo].[ICS_OTHR_PRMTS] WITH CHECK CHECK CONSTRAINT [FK_OTHR_PRMTS_GNRL_PRMT];
ALTER TABLE [dbo].[ICS_IMPAIRED_WTR_POLLUTANTS] WITH CHECK CHECK CONSTRAINT [FK_IMPRD_WTR_PLLTNTS_PLUT_LIST];
ALTER TABLE [dbo].[ICS_LMT_SET_SCHD] WITH CHECK CHECK CONSTRAINT [FK_LMT_SET_SCHD_LMT_SET];
ALTER TABLE [dbo].[ICS_LMT_SET_SCHD] WITH CHECK CHECK CONSTRAINT [FK_LMT_SET_SCH_COP_MGP_LMT_SET];
ALTER TABLE [dbo].[ICS_LMT_SET_STAT] WITH CHECK CHECK CONSTRAINT [FK_LMT_SET_STAT_LMT_SET];
ALTER TABLE [dbo].[ICS_LMT_SET_STAT] WITH CHECK CHECK CONSTRAINT [FK_LMT_SET_STA_COP_MGP_LMT_SET];
ALTER TABLE [dbo].[ICS_LMTS] WITH CHECK CHECK CONSTRAINT [FK_LMTS_PAYLOAD];
ALTER TABLE [dbo].[ICS_MN_LMT_APPLIES] WITH CHECK CHECK CONSTRAINT [FK_MN_LMT_APPLIES_LMTS];
ALTER TABLE [dbo].[ICS_NUM_COND] WITH CHECK CHECK CONSTRAINT [FK_NUM_COND_LMTS];
ALTER TABLE [dbo].[ICS_MNUR_LTTR_PRCSS_WW_STOR] WITH CHECK CHECK CONSTRAINT [FK_MNUR_LTT_PRC_WW_STO_CAF_PRM];
ALTER TABLE [dbo].[ICS_PATHOGEN_REDUCTION_TYPE] WITH CHECK CHECK CONSTRAINT [FK_PTHG_RDCT_TYPE_BS_MGMT_PRCT];
ALTER TABLE [dbo].[ICS_PATHOGEN_REDUCTION_TYPE] WITH CHECK CHECK CONSTRAINT [FK_PTHG_RDC_TYP_PRM_BS_MGM_PRC];
ALTER TABLE [dbo].[ICS_PRETR_PRMT] WITH CHECK CHECK CONSTRAINT [FK_PRETR_PRMT_PAYLOAD];
ALTER TABLE [dbo].[ICS_GPCF_NOTICE_OF_INTENT] WITH CHECK CHECK CONSTRAINT [FK_GPCF_NTCE_OF_INT_SW_CNS_PRM];
ALTER TABLE [dbo].[ICS_SW_CNST_PRMT] WITH CHECK CHECK CONSTRAINT [FK_SW_CNST_PRMT_PAYLOAD];
ALTER TABLE [dbo].[ICS_TRTMNT_CHEMS_LIST] WITH CHECK CHECK CONSTRAINT [FK_TRTM_CHMS_LIST_SW_CNST_PRMT];
ALTER TABLE [dbo].[ICS_GPCF_NO_EXPOSURE] WITH CHECK CHECK CONSTRAINT [FK_GPCF_NO_EXPSR_SW_INDST_PRMT];
ALTER TABLE [dbo].[ICS_GPCF_NOTICE_OF_INTENT] WITH CHECK CHECK CONSTRAINT [FK_GPCF_NTCE_OF_INT_SW_IND_PRM];
ALTER TABLE [dbo].[ICS_GPCF_NOTICE_OF_TERM] WITH CHECK CHECK CONSTRAINT [FK_GPCF_NTCE_OF_TER_SW_IND_PRM];
ALTER TABLE [dbo].[ICS_SW_INDST_PRMT] WITH CHECK CHECK CONSTRAINT [FK_SW_INDST_PRMT_PAYLOAD];
ALTER TABLE [dbo].[ICS_TMDL_POLUT] WITH CHECK CHECK CONSTRAINT [FK_TMDL_POLUT_TMDL_POLLUTANTS];
ALTER TABLE [dbo].[ICS_TMDL_POLLUTANTS] WITH CHECK CHECK CONSTRAINT [FK_TMDL_POLLUTANTS_POLUT_LIST];
ALTER TABLE [dbo].[ICS_PRMT_COMP_TYPE] WITH CHECK CHECK CONSTRAINT [FK_PRMT_COMP_TYPE_UNPRMT_FAC];
ALTER TABLE [dbo].[ICS_FAC_CLASS] WITH CHECK CHECK CONSTRAINT [FK_FAC_CLASS_UNPRMT_FAC];
ALTER TABLE [dbo].[ICS_SIC_CODE] WITH CHECK CHECK CONSTRAINT [FK_SIC_CODE_UNPRMT_FAC];
ALTER TABLE [dbo].[ICS_NAICS_CODE] WITH CHECK CHECK CONSTRAINT [FK_NAICS_CODE_UNPRMT_FAC];
ALTER TABLE [dbo].[ICS_UNPRMT_FAC] WITH CHECK CHECK CONSTRAINT [FK_UNPRMT_FAC_PAYLOAD];
ALTER TABLE [dbo].[ICS_ORIG_PROGS] WITH CHECK CHECK CONSTRAINT [FK_ORIG_PROGS_UNPRMT_FAC];
ALTER TABLE [dbo].[ICS_PLCY] WITH CHECK CHECK CONSTRAINT [FK_PLCY_UNPRMT_FAC];
ALTER TABLE [dbo].[ICS_VECTOR_A_REDUCTION_TYPE] WITH CHECK CHECK CONSTRAINT [FK_VCTR_A_RDCT_TYPE_BS_MGM_PRC];
ALTER TABLE [dbo].[ICS_VECTOR_A_REDUCTION_TYPE] WITH CHECK CHECK CONSTRAINT [FK_VCT_A_RDC_TYP_PRM_BS_MGM_PR];
ALTER TABLE [dbo].[ICS_IMPACT_SSO_EVT] WITH CHECK CHECK CONSTRAINT [FK_IMPACT_SSO_EVT_SSO_INSP];
ALTER TABLE [dbo].[ICS_PROJ_SRCS_FUND] WITH CHECK CHECK CONSTRAINT [FK_PROJ_SRCS_FUND_SW_MS_4_INSP];
ALTER TABLE [dbo].[ICS_SATL_COLL_SYSTM] WITH CHECK CHECK CONSTRAINT [FK_SATL_COLL_SYSTM_POTW_PRMT];
ALTER TABLE [dbo].[ICS_SSO_STPS] WITH CHECK CHECK CONSTRAINT [FK_SSO_STPS_SSO_INSP];
ALTER TABLE [dbo].[ICS_SSO_SYSTM_COMP] WITH CHECK CHECK CONSTRAINT [FK_SSO_SYSTM_COMP_SSO_INSP];
ALTER TABLE [dbo].[ICS_BS_FAC_TRTMNT] WITH CHECK CHECK CONSTRAINT [FK_BS_FAC_TRTM_BS_ANNL_PRO_REP];
ALTER TABLE [dbo].[ICS_BS_FAC_TRTMNT] WITH CHECK CHECK CONSTRAINT [FK_BS_FAC_TRTMNT_BS_PRMT];
ALTER TABLE [dbo].[ICS_BS_FAC_TYPE] WITH CHECK CHECK CONSTRAINT [FK_BS_FAC_TYPE_BS_ANNL_PRO_REP];
ALTER TABLE [dbo].[ICS_BS_FAC_TYPE] WITH CHECK CHECK CONSTRAINT [FK_BS_FAC_TYPE_BS_PRMT];
ALTER TABLE [dbo].[ICS_BS_INCIN_EMISSIONS_CONTROL_TYPE] WITH CHECK CHECK CONSTRAINT [FK_BS_INCN_EMSS_CNT_TYP_BS_INC];
ALTER TABLE [dbo].[ICS_BS_INCINERATION] WITH CHECK CHECK CONSTRAINT [FK_BS_INCINRTON_BS_MGMT_PRCTCE];
ALTER TABLE [dbo].[ICS_BS_MGMT_PRACTICE] WITH CHECK CHECK CONSTRAINT [FK_BS_MGMT_PRCT_BS_ANN_PRO_REP];
ALTER TABLE [dbo].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] WITH CHECK CHECK CONSTRAINT [FK_BS_OFF_SI_HN_AP_PR_BS_MG_PR];
ALTER TABLE [dbo].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] WITH CHECK CHECK CONSTRAINT [FK_BS_OF_SI_HN_AP_PR_PR_BS_MG];
ALTER TABLE [dbo].[ICS_BS_SEWAGE_SLDG_PARAM] WITH CHECK CHECK CONSTRAINT [FK_BS_SWGE_SLD_PAR_CMP_MON_EVT];
ALTER TABLE [dbo].[ICS_BS_SEWAGE_SLDG_PARAM] WITH CHECK CHECK CONSTRAINT [FK_BS_SWGE_SLDG_PAR_BS_MGM_PRC];
ALTER TABLE [dbo].[ICS_BS_SEWAGE_SLDG_PARAM] WITH CHECK CHECK CONSTRAINT [FK_BS_SWGE_SLDG_PARM_BS_INCNRT];
ALTER TABLE [dbo].[ICS_BYPASS_TRTMNT_PLANT_EQUIPMENT] WITH CHECK CHECK CONSTRAINT [FK_BYP_TR_PL_EQ_SE_OV_BY_RE_EV];
ALTER TABLE [dbo].[ICS_CAFO_ANNUL_PROG_REP] WITH CHECK CHECK CONSTRAINT [FK_CAFO_ANNUL_PROG_REP_PAYLOAD];
ALTER TABLE [dbo].[ICS_CAFO_LAND_APPL_FLD_INFO] WITH CHECK CHECK CONSTRAINT [FK_CAF_LA_AP_FL_IN_CA_AN_PR_RE];
ALTER TABLE [dbo].[ICS_CAFO_PROD_AREA_DSCH] WITH CHECK CHECK CONSTRAINT [FK_CAF_PRO_ARE_DSC_CA_AN_PR_RE];
ALTER TABLE [dbo].[ICS_CAFOMLPW_FLD_AMOUNTS] WITH CHECK CHECK CONSTRAINT [FK_CFM_FLD_AMN_CAF_LA_AP_FL_IN];
ALTER TABLE [dbo].[ICS_CAFOMLPW_NUTR_MON] WITH CHECK CHECK CONSTRAINT [FK_CFM_NUT_MON_CAF_ANN_PRO_REP];
ALTER TABLE [dbo].[ICS_CAFOMLPW_TTL_AMOUNTS] WITH CHECK CHECK CONSTRAINT [FK_CFM_TTL_AMN_CAF_ANN_PRO_REP];
ALTER TABLE [dbo].[ICS_CAFOMLPW_TTL_AMOUNTS] WITH CHECK CHECK CONSTRAINT [FK_CFOMLPW_TTL_AMNTS_CAFO_PRMT];
ALTER TABLE [dbo].[ICS_CMPL_MON_EVT] WITH CHECK CHECK CONSTRAINT [FK_CMPL_MON_EVT_BS_MGMT_PRCTCE];
ALTER TABLE [dbo].[ICS_CNST_SITE_LIST] WITH CHECK CHECK CONSTRAINT [FK_CNST_SITE_LIST_SW_CNST_PRMT];
ALTER TABLE [dbo].[ICS_COLL_SYSTM_PRMT] WITH CHECK CHECK CONSTRAINT [FK_COLL_SYSTM_PRMT_PAYLOAD];
ALTER TABLE [dbo].[ICS_CONTROL_AUTH_PROG_INFO] WITH CHECK CHECK CONSTRAINT [FK_CNT_AUT_PRO_INF_PRT_PRO_REP];
ALTER TABLE [dbo].[ICS_COOLING_WTR_INTAKE_STRCT_CMPL_METHOD] WITH CHECK CHECK CONSTRAINT [FK_CL_WT_IN_ST_CM_MT_CL_WT_IN];
ALTER TABLE [dbo].[ICS_COOLING_WTR_INTAKE_STRCT_INFO] WITH CHECK CHECK CONSTRAINT [FK_CLN_WTR_INT_STR_INF_PRM_FET];
ALTER TABLE [dbo].[ICS_COPY_MGPMS_4_REQ] WITH CHECK CHECK CONSTRAINT [FK_COPY_MGPMS_4_REQ_PAYLOAD];
ALTER TABLE [dbo].[ICS_CSO_CONTROL_MEAS_DETAIL] WITH CHECK CHECK CONSTRAINT [FK_CSO_CN_ME_DT_CS_LO_TE_CN_PL];
ALTER TABLE [dbo].[ICS_CSO_LONG_TERM_CONTROL_PLAN] WITH CHECK CHECK CONSTRAINT [FK_CSO_LONG_TERM_CNTR_PLAN_PYL];
ALTER TABLE [dbo].[ICS_CWA_316B_PROG_REP] WITH CHECK CHECK CONSTRAINT [FK_CWA_316B_PROG_REP_PAYLOAD];
ALTER TABLE [dbo].[ICS_CWA_316B_TAKE_INFO] WITH CHECK CHECK CONSTRAINT [FK_CWA_316_TAK_INF_CW_31_PR_RE];
ALTER TABLE [dbo].[ICS_GNRL_PRMT_COVERAGE_MS_4_REQ] WITH CHECK CHECK CONSTRAINT [FK_GN_PR_CV_MS_4_RE_CO_MG_4_RE];
ALTER TABLE [dbo].[ICS_INDST_USR_INFO] WITH CHECK CHECK CONSTRAINT [FK_INDS_USR_INFO_INDS_USR_INVN];
ALTER TABLE [dbo].[ICS_INDST_USR_INVENTORY] WITH CHECK CHECK CONSTRAINT [FK_INDS_USR_INVN_PRTR_PROG_REP];
ALTER TABLE [dbo].[ICS_INSP_CMNT_TXT] WITH CHECK CHECK CONSTRAINT [FK_INSP_CMNT_TXT_CMPL_MON];
ALTER TABLE [dbo].[ICS_INSP_V_CONTACT] WITH CHECK CHECK CONSTRAINT [FK_INSP_V_CONTACT_CMPL_MON];
ALTER TABLE [dbo].[ICS_IU_ENF_ACTN_TYPES] WITH CHECK CHECK CONSTRAINT [FK_IU_ENF_ACT_TYP_IU_ENF_AC_IN];
ALTER TABLE [dbo].[ICS_IU_ENFRC_ACTN_INFO] WITH CHECK CHECK CONSTRAINT [FK_IU_ENFR_ACT_INF_IND_USR_INF];
ALTER TABLE [dbo].[ICS_IU_VIOL_INFO] WITH CHECK CHECK CONSTRAINT [FK_IU_VIOL_INFO_INDST_USR_INFO];
ALTER TABLE [dbo].[ICS_LNK_CMPL_MON] WITH CHECK CHECK CONSTRAINT [FK_LNK_CMPL_MON_CMPL_MON_LNK];
ALTER TABLE [dbo].[ICS_LOC_LMTS_PARAMETERS] WITH CHECK CHECK CONSTRAINT [FK_LOC_LMT_PRM_CNT_AUT_PRO_INF];
ALTER TABLE [dbo].[ICS_LTCP_ENFORCEABLE_MECH_DETAIL] WITH CHECK CHECK CONSTRAINT [FK_LTC_EN_ME_DT_CS_LO_TE_CN_PL];
ALTER TABLE [dbo].[ICS_LTCP_MOST_RECENT_REVISION_DETAIL] WITH CHECK CHECK CONSTRAINT [FK_LT_MO_RC_RV_DT_CS_LO_TE_CN];
ALTER TABLE [dbo].[ICS_LTCP_SUMM] WITH CHECK CHECK CONSTRAINT [FK_LTC_SUM_CSO_LON_TER_CNT_PLA];
ALTER TABLE [dbo].[ICS_MS_4_ACTY_IDENT] WITH CHECK CHECK CONSTRAINT [FK_MS_4_ACTY_IDN_COP_MGP_4_REQ];
ALTER TABLE [dbo].[ICS_MS_4_CNST_SW_PROCEDURES] WITH CHECK CHECK CONSTRAINT [FK_MS_4_CN_SW_PR_MS_4_CN_SW_RE];
ALTER TABLE [dbo].[ICS_MS_4_CNST_SW_REGULATED_ENTITY_INFO] WITH CHECK CHECK CONSTRAINT [FK_MS_4_CN_SW_RG_EN_IN_MS_4_CN];
ALTER TABLE [dbo].[ICS_MS_4_CNST_SW_REQS] WITH CHECK CHECK CONSTRAINT [FK_MS_4_CNST_SW_REQS_SWM_4_PRM];
ALTER TABLE [dbo].[ICS_MS_4_ILLICIT_DETECT_PROCEDURES] WITH CHECK CHECK CONSTRAINT [FK_MS_4_IL_DT_PR_MS_4_IL_DT_RE];
ALTER TABLE [dbo].[ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO] WITH CHECK CHECK CONSTRAINT [FK_MS_4_IL_DT_RG_EN_IN_MS_4_IL];
ALTER TABLE [dbo].[ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO_PROG_REP] WITH CHECK CHECK CONSTRAINT [FK_MS_4_IL_DT_RG_EN_IN_PR_RE_S];
ALTER TABLE [dbo].[ICS_MS_4_ILLICIT_DETECT_REQS] WITH CHECK CHECK CONSTRAINT [FK_MS_4_ILLC_DTC_REQ_SWM_4_PRM];
ALTER TABLE [dbo].[ICS_MS_4_INDST_SW_PROCEDURES] WITH CHECK CHECK CONSTRAINT [FK_MS_4_IN_SW_PR_MS_4_IN_SW_RE];
ALTER TABLE [dbo].[ICS_MS_4_INDST_SW_REGULATED_ENTITY_INFO] WITH CHECK CHECK CONSTRAINT [FK_MS_4_IN_SW_RG_EN_IN_MS_4_IN];
ALTER TABLE [dbo].[ICS_MS_4_INDST_SW_REQS] WITH CHECK CHECK CONSTRAINT [FK_MS_4_INDS_SW_REQS_SWM_4_PRM];
ALTER TABLE [dbo].[ICS_MS_4_OTHR_APPL_REQS] WITH CHECK CHECK CONSTRAINT [FK_MS_4_OTHR_APP_REQ_SWM_4_PRM];
ALTER TABLE [dbo].[ICS_MS_4_PBLC_EDUCATION_REQS] WITH CHECK CHECK CONSTRAINT [FK_MS_4_PBLC_EDC_REQ_SWM_4_PRM];
ALTER TABLE [dbo].[ICS_MS_4_PBLC_INVOLVEMENT_REQS] WITH CHECK CHECK CONSTRAINT [FK_MS_4_PBLC_INV_REQ_SWM_4_PRM];
ALTER TABLE [dbo].[ICS_MS_4_POLLUTION_PREVENTION_REQS] WITH CHECK CHECK CONSTRAINT [FK_MS_4_PLLT_PRV_REQ_SWM_4_PRM];
ALTER TABLE [dbo].[ICS_MS_4_POST_CNST_SW_PROCEDURES] WITH CHECK CHECK CONSTRAINT [FK_MS_4_PO_CN_SW_PR_MS_4_PO_CN];
ALTER TABLE [dbo].[ICS_MS_4_POST_CNST_SW_REGULATED_ENTITY_INFO] WITH CHECK CHECK CONSTRAINT [FK_MS_4_PO_CN_SW_RG_EN_IN_MS_4];
ALTER TABLE [dbo].[ICS_MS_4_POST_CNST_SW_REQS] WITH CHECK CHECK CONSTRAINT [FK_MS_4_POS_CNS_SW_REQ_SW_4_PR];
ALTER TABLE [dbo].[ICS_MS_4_PROG_REP_ANALYSIS] WITH CHECK CHECK CONSTRAINT [FK_MS_4_PR_RE_AN_SW_4_AN_PR_RE];
ALTER TABLE [dbo].[ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY] WITH CHECK CHECK CONSTRAINT [FK_MS_4_PR_RE_RE_RG_EN_SW_4_AN];
ALTER TABLE [dbo].[ICS_MS_4_REGULATED_ENTITY] WITH CHECK CHECK CONSTRAINT [FK_MS_4_RGLTD_ENTT_SWMS_4_PRMT];
ALTER TABLE [dbo].[ICS_MS_4_REGULATED_ENTITY_AREA] WITH CHECK CHECK CONSTRAINT [FK_MS_4_RGLT_ENT_ARE_SWM_4_PRM];
ALTER TABLE [dbo].[ICS_MS_4_REGULATED_ENTITY_AREA_COORD] WITH CHECK CHECK CONSTRAINT [FK_MS_4_RG_EN_AR_CO_MS_4_RG_EN];
ALTER TABLE [dbo].[ICS_MS_4_REGULATED_ENTITY_ENFRC] WITH CHECK CHECK CONSTRAINT [FK_MS_4_RG_EN_EN_SW_4_AN_PR_RE];
ALTER TABLE [dbo].[ICS_MS_4_REGULATED_ENTITY_ENFRC_ACTIONS] WITH CHECK CHECK CONSTRAINT [FK_MS_4_RG_EN_EN_AC_MS_4_RG_EN];
ALTER TABLE [dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT] WITH CHECK CHECK CONSTRAINT [FK_MS_4_RG_EN_ID_GN_PR_CV_MS_4];
ALTER TABLE [dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT] WITH CHECK CHECK CONSTRAINT [FK_MS_4_RG_EN_ID_MS_4_CN_SW_PR];
ALTER TABLE [dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT] WITH CHECK CHECK CONSTRAINT [FK_MS_4_RG_EN_ID_MS_4_IL_DT_PR];
ALTER TABLE [dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT] WITH CHECK CHECK CONSTRAINT [FK_MS_4_RG_EN_ID_MS_4_IN_SW_PR];
ALTER TABLE [dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT] WITH CHECK CHECK CONSTRAINT [FK_MS_4_RG_EN_ID_MS_4_OT_AP_RE];
ALTER TABLE [dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT] WITH CHECK CHECK CONSTRAINT [FK_MS_4_RG_EN_ID_MS_4_PB_ED_RE];
ALTER TABLE [dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT] WITH CHECK CHECK CONSTRAINT [FK_MS_4_RG_EN_ID_MS_4_PB_IN_RE];
ALTER TABLE [dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT] WITH CHECK CHECK CONSTRAINT [FK_MS_4_RG_EN_ID_MS_4_PL_PR_RE];
ALTER TABLE [dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT] WITH CHECK CHECK CONSTRAINT [FK_MS_4_RG_EN_ID_MS_4_PO_CN_SW];
ALTER TABLE [dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT] WITH CHECK CHECK CONSTRAINT [FK_MS_4_RG_EN_ID_MS_4_PR_RE_AN];
ALTER TABLE [dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT] WITH CHECK CHECK CONSTRAINT [FK_MS_4_RG_EN_ID_MS_4_PR_RE_RE];
ALTER TABLE [dbo].[ICS_MS_4_SWMP_CHANGES] WITH CHECK CHECK CONSTRAINT [FK_MS_4_SWM_CHN_SWM_4_AN_PR_RE];
ALTER TABLE [dbo].[ICS_NPDES_VARIANCE_PRMT] WITH CHECK CHECK CONSTRAINT [FK_NPDES_VARIANCE_PRMT_PAYLOAD];
ALTER TABLE [dbo].[ICS_POLUT_LIST] WITH CHECK CHECK CONSTRAINT [FK_POLUT_LIST_PRMT_FEATR];
ALTER TABLE [dbo].[ICS_POTW_TRTMNT_TECHNOLOGY_PRMT] WITH CHECK CHECK CONSTRAINT [FK_POTW_TRTMN_TCHNLG_PRMT_PYLD];
ALTER TABLE [dbo].[ICS_PRETR_PROG_MOD] WITH CHECK CHECK CONSTRAINT [FK_PRETR_PROG_MOD_PRETR_PRMT];
ALTER TABLE [dbo].[ICS_PRETR_PROG_REP] WITH CHECK CHECK CONSTRAINT [FK_PRETR_PROG_REP_PAYLOAD];
ALTER TABLE [dbo].[ICS_PRMT_BS_MGMT_PRACTICE] WITH CHECK CHECK CONSTRAINT [FK_PRMT_BS_MGMT_PRCTCE_BS_PRMT];
ALTER TABLE [dbo].[ICS_PROPOSED_CNST_SW_BM_PS] WITH CHECK CHECK CONSTRAINT [FK_PRP_CNS_SW_BM_PS_SW_CNS_PRM];
ALTER TABLE [dbo].[ICS_PROPOSED_INDST_SW_BM_PS] WITH CHECK CHECK CONSTRAINT [FK_PRP_IND_SW_BM_PS_SW_IND_PRM];
ALTER TABLE [dbo].[ICS_PROPOSED_POST_CNST_SW_BM_PS] WITH CHECK CHECK CONSTRAINT [FK_PRP_PO_CN_SW_BM_PS_SW_CN_PR];
ALTER TABLE [dbo].[ICS_RESIDUAL_DESGN_DTRMN] WITH CHECK CHECK CONSTRAINT [FK_RSDL_DSGN_DTRM_MSTR_GNR_PRM];
ALTER TABLE [dbo].[ICS_RESIDUAL_DESGN_DTRMN] WITH CHECK CHECK CONSTRAINT [FK_RSIDUL_DSGN_DTRMN_BSIC_PRMT];
ALTER TABLE [dbo].[ICS_RESIDUAL_DESGN_DTRMN] WITH CHECK CHECK CONSTRAINT [FK_RSIDUL_DSGN_DTRMN_GNRL_PRMT];
ALTER TABLE [dbo].[ICS_SEWER_OVRFLW_BYPASS_CAUSE] WITH CHECK CHECK CONSTRAINT [FK_SEW_OV_BY_CU_SE_OV_BY_RE_EV];
ALTER TABLE [dbo].[ICS_SEWER_OVRFLW_BYPASS_CORR_ACTN] WITH CHECK CHECK CONSTRAINT [FK_SE_OV_BY_CO_AC_SE_OV_BY_RE];
ALTER TABLE [dbo].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP] WITH CHECK CHECK CONSTRAINT [FK_SEWR_OVRF_BYPS_EVT_REP_PYLD];
ALTER TABLE [dbo].[ICS_SEWER_OVRFLW_BYPASS_IMPACT] WITH CHECK CHECK CONSTRAINT [FK_SEW_OV_BY_IM_SE_OV_BY_RE_EV];
ALTER TABLE [dbo].[ICS_SEWER_OVRFLW_BYPASS_RCVG_WTR] WITH CHECK CHECK CONSTRAINT [FK_SE_OV_BY_RC_WT_SE_OV_BY_RE];
ALTER TABLE [dbo].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT] WITH CHECK CHECK CONSTRAINT [FK_SE_OV_BY_RE_EV_SE_OV_BY_EV];
ALTER TABLE [dbo].[ICS_SEWER_OVRFLW_BYPASS_TYPE] WITH CHECK CHECK CONSTRAINT [FK_SEW_OV_BY_TY_SE_OV_BY_RE_EV];
ALTER TABLE [dbo].[ICS_SEWER_OVRFLW_TRTMNT] WITH CHECK CHECK CONSTRAINT [FK_SEW_OVR_TRT_SEW_OV_BY_RE_EV];
ALTER TABLE [dbo].[ICS_SIU_DESGN_TYPE] WITH CHECK CHECK CONSTRAINT [FK_SIU_DESGN_TYPE_BASIC_PRMT];
ALTER TABLE [dbo].[ICS_SNC_LISTING_MONTHS] WITH CHECK CHECK CONSTRAINT [FK_SNC_LSTNG_MNTH_IU_VIOL_INFO];
ALTER TABLE [dbo].[ICS_SNC_PRETR_STND_LMTS_PARAMETERS] WITH CHECK CHECK CONSTRAINT [FK_SNC_PRT_STN_LMT_PR_IU_VI_IN];
ALTER TABLE [dbo].[ICS_SUBSECTOR_CODE_PLUS_DESC] WITH CHECK CHECK CONSTRAINT [FK_SBS_COD_PLU_DES_GP_NT_OF_IN];
ALTER TABLE [dbo].[ICS_SWMS_4_ANNUL_PROG_REP] WITH CHECK CHECK CONSTRAINT [FK_SWMS_4_ANNL_PROG_REP_PAYLOD];
ALTER TABLE [dbo].[ICS_SWMS_4_PRMT] WITH CHECK CHECK CONSTRAINT [FK_SWMS_4_PRMT_PAYLOAD];

commit;
PRINT N'Update complete.';

ALTER TABLE ICS_PAYLOAD ALTER COLUMN OPERATION varchar(80);
ALTER TABLE ICS_PAYLOAD ALTER COLUMN BASE_TABLE_NAME varchar(80)


INSERT INTO dbo.ICS_PAYLOAD SELECT 'BasicPermit', 'BasicPermitSubmission', 'N', 'N', null, 'ICS_BASIC_PRMT' WHERE NOT EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P WHERE P.ICS_PAYLOAD_ID = 'BasicPermit')
INSERT INTO dbo.ICS_PAYLOAD SELECT 'BiosolidsAnnualProgramReport', 'BiosolidsAnnualProgramReportSubmission', 'N', 'N', null, 'ICS_BS_ANNUL_PROG_REP' WHERE NOT EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P WHERE P.ICS_PAYLOAD_ID = 'BiosolidsAnnualProgramReport')
INSERT INTO dbo.ICS_PAYLOAD SELECT 'BiosolidsPermit', 'BiosolidsPermitSubmission', 'N', 'N', null, 'ICS_BS_PRMT' WHERE NOT EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P WHERE P.ICS_PAYLOAD_ID = 'BiosolidsPermit')
INSERT INTO dbo.ICS_PAYLOAD SELECT 'CAFOAnnualProgramReport', 'CAFOAnnualProgramReportSubmission', 'N', 'N', null, 'ICS_CAFO_ANNUL_PROG_REP' WHERE NOT EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P WHERE P.ICS_PAYLOAD_ID = 'CAFOAnnualProgramReport')
INSERT INTO dbo.ICS_PAYLOAD SELECT 'CAFOPermit', 'CAFOPermitSubmission', 'N', 'N', null, 'ICS_CAFO_PRMT' WHERE NOT EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P WHERE P.ICS_PAYLOAD_ID = 'CAFOPermit')
INSERT INTO dbo.ICS_PAYLOAD SELECT 'ComplianceMonitoring', 'ComplianceMonitoringSubmission', 'N', 'N', null, 'ICS_CMPL_MON' WHERE NOT EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P WHERE P.ICS_PAYLOAD_ID = 'ComplianceMonitoring')
INSERT INTO dbo.ICS_PAYLOAD SELECT 'ComplianceMonitoringLinkage', 'ComplianceMonitoringLinkageSubmission', 'N', 'N', null, 'ICS_CMPL_MON_LNK' WHERE NOT EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P WHERE P.ICS_PAYLOAD_ID = 'ComplianceMonitoringLinkage')
INSERT INTO dbo.ICS_PAYLOAD SELECT 'ComplianceSchedule', 'ComplianceScheduleSubmission', 'N', 'N', null, 'ICS_CMPL_SCHD' WHERE NOT EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P WHERE P.ICS_PAYLOAD_ID = 'ComplianceSchedule')
INSERT INTO dbo.ICS_PAYLOAD SELECT 'CollectionSystemPermit', 'CollectionSystemPermitSubmission', 'N', 'N', null, 'ICS_COLL_SYSTM_PRMT' WHERE NOT EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P WHERE P.ICS_PAYLOAD_ID = 'CollectionSystemPermit')
INSERT INTO dbo.ICS_PAYLOAD SELECT 'CopyMGPLimitSet', 'CopyMGPLimitSetSubmission', 'N', 'N', null, 'ICS_COPY_MGP_LMT_SET' WHERE NOT EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P WHERE P.ICS_PAYLOAD_ID = 'CopyMGPLimitSet')
INSERT INTO dbo.ICS_PAYLOAD SELECT 'CopyMGPMS4Requirement', 'CopyMGPMS4RequirementSubmission', 'N', 'N', null, 'ICS_COPY_MGPMS_4_REQ' WHERE NOT EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P WHERE P.ICS_PAYLOAD_ID = 'CopyMGPMS4Requirement')
INSERT INTO dbo.ICS_PAYLOAD SELECT 'CSOLongTermControlPlan', 'CSOLongTermControlPlanSubmission', 'N', 'N', null, 'ICS_CSO_LONG_TERM_CONTROL_PLAN' WHERE NOT EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P WHERE P.ICS_PAYLOAD_ID = 'CSOLongTermControlPlan')
INSERT INTO dbo.ICS_PAYLOAD SELECT 'CWA316bProgramReport', 'CWA316bProgramReportSubmission', 'N', 'N', null, 'ICS_CWA_316B_PROG_REP' WHERE NOT EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P WHERE P.ICS_PAYLOAD_ID = 'CWA316bProgramReport')
INSERT INTO dbo.ICS_PAYLOAD SELECT 'DMRViolation', 'DMRViolationSubmission', 'N', 'N', null, 'ICS_DMR_VIOL' WHERE NOT EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P WHERE P.ICS_PAYLOAD_ID = 'DMRViolation')
INSERT INTO dbo.ICS_PAYLOAD SELECT 'DischargeMonitoringReport', 'DischargeMonitoringReportSubmission', 'N', 'N', null, 'ICS_DSCH_MON_REP' WHERE NOT EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P WHERE P.ICS_PAYLOAD_ID = 'DischargeMonitoringReport')
INSERT INTO dbo.ICS_PAYLOAD SELECT 'EffluentTradePartner', 'EffluentTradePartnerSubmission', 'N', 'N', null, 'ICS_EFFLU_TRADE_PRTNER' WHERE NOT EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P WHERE P.ICS_PAYLOAD_ID = 'EffluentTradePartner')
INSERT INTO dbo.ICS_PAYLOAD SELECT 'EnforcementActionMilestone', 'EnforcementActionMilestoneSubmission', 'N', 'N', null, 'ICS_ENFRC_ACTN_MILESTONE' WHERE NOT EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P WHERE P.ICS_PAYLOAD_ID = 'EnforcementActionMilestone')
INSERT INTO dbo.ICS_PAYLOAD SELECT 'EnforcementActionViolationLinkage', 'EnforcementActionViolationLinkageSubmission', 'N', 'N', null, 'ICS_ENFRC_ACTN_VIOL_LNK' WHERE NOT EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P WHERE P.ICS_PAYLOAD_ID = 'EnforcementActionViolationLinkage')
INSERT INTO dbo.ICS_PAYLOAD SELECT 'FinalOrderViolationLinkage', 'FinalOrderViolationLinkageSubmission', 'N', 'N', null, 'ICS_FINAL_ORDER_VIOL_LNK' WHERE NOT EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P WHERE P.ICS_PAYLOAD_ID = 'FinalOrderViolationLinkage')
INSERT INTO dbo.ICS_PAYLOAD SELECT 'FormalEnforcementAction', 'FormalEnforcementActionSubmission', 'N', 'N', null, 'ICS_FRML_ENFRC_ACTN' WHERE NOT EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P WHERE P.ICS_PAYLOAD_ID = 'FormalEnforcementAction')
INSERT INTO dbo.ICS_PAYLOAD SELECT 'GeneralPermit', 'GeneralPermitSubmission', 'N', 'N', null, 'ICS_GNRL_PRMT' WHERE NOT EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P WHERE P.ICS_PAYLOAD_ID = 'GeneralPermit')
INSERT INTO dbo.ICS_PAYLOAD SELECT 'HistoricalPermitScheduleEvents', 'HistoricalPermitScheduleEventsSubmission', 'N', 'N', null, 'ICS_HIST_PRMT_SCHD_EVTS' WHERE NOT EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P WHERE P.ICS_PAYLOAD_ID = 'HistoricalPermitScheduleEvents')
INSERT INTO dbo.ICS_PAYLOAD SELECT 'InformalEnforcementAction', 'InformalEnforcementActionSubmission', 'N', 'N', null, 'ICS_INFRML_ENFRC_ACTN' WHERE NOT EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P WHERE P.ICS_PAYLOAD_ID = 'InformalEnforcementAction')
INSERT INTO dbo.ICS_PAYLOAD SELECT 'LimitSet', 'LimitSetSubmission', 'N', 'N', null, 'ICS_LMT_SET' WHERE NOT EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P WHERE P.ICS_PAYLOAD_ID = 'LimitSet')
INSERT INTO dbo.ICS_PAYLOAD SELECT 'Limits', 'LimitsSubmission', 'N', 'N', null, 'ICS_LMTS' WHERE NOT EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P WHERE P.ICS_PAYLOAD_ID = 'Limits')
INSERT INTO dbo.ICS_PAYLOAD SELECT 'MasterGeneralPermit', 'MasterGeneralPermitSubmission', 'N', 'N', null, 'ICS_MASTER_GNRL_PRMT' WHERE NOT EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P WHERE P.ICS_PAYLOAD_ID = 'MasterGeneralPermit')
INSERT INTO dbo.ICS_PAYLOAD SELECT 'NarrativeConditionSchedule', 'NarrativeConditionScheduleSubmission', 'N', 'N', null, 'ICS_NARR_COND_SCHD' WHERE NOT EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P WHERE P.ICS_PAYLOAD_ID = 'NarrativeConditionSchedule')
INSERT INTO dbo.ICS_PAYLOAD SELECT 'NPDESVariancePermit', 'NPDESVariancePermitSubmission', 'N', 'N', null, 'ICS_NPDES_VARIANCE_PRMT' WHERE NOT EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P WHERE P.ICS_PAYLOAD_ID = 'NPDESVariancePermit')
INSERT INTO dbo.ICS_PAYLOAD SELECT 'ParameterLimits', 'ParameterLimitsSubmission', 'N', 'N', null, 'ICS_PARAM_LMTS' WHERE NOT EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P WHERE P.ICS_PAYLOAD_ID = 'ParameterLimits')
INSERT INTO dbo.ICS_PAYLOAD SELECT 'POTWPermit', 'POTWPermitSubmission', 'N', 'N', null, 'ICS_POTW_PRMT' WHERE NOT EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P WHERE P.ICS_PAYLOAD_ID = 'POTWPermit')
INSERT INTO dbo.ICS_PAYLOAD SELECT 'POTWTreatmentTechnologyPermit', 'POTWTreatmentTechnologyPermitSubmission', 'N', 'N', null, 'ICS_POTW_TRTMNT_TECHNOLOGY_PRMT' WHERE NOT EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P WHERE P.ICS_PAYLOAD_ID = 'POTWTreatmentTechnologyPermit')
INSERT INTO dbo.ICS_PAYLOAD SELECT 'PretreatmentPermit', 'PretreatmentPermitSubmission', 'N', 'N', null, 'ICS_PRETR_PRMT' WHERE NOT EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P WHERE P.ICS_PAYLOAD_ID = 'PretreatmentPermit')
INSERT INTO dbo.ICS_PAYLOAD SELECT 'PretreatmentProgramReport', 'PretreatmentProgramReportSubmission', 'N', 'N', null, 'ICS_PRETR_PROG_REP' WHERE NOT EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P WHERE P.ICS_PAYLOAD_ID = 'PretreatmentProgramReport')
INSERT INTO dbo.ICS_PAYLOAD SELECT 'PermittedFeature', 'PermittedFeatureSubmission', 'N', 'N', null, 'ICS_PRMT_FEATR' WHERE NOT EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P WHERE P.ICS_PAYLOAD_ID = 'PermittedFeature')
INSERT INTO dbo.ICS_PAYLOAD SELECT 'PermitReissuance', 'PermitReissuanceSubmission', 'N', 'N', null, 'ICS_PRMT_REISSU' WHERE NOT EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P WHERE P.ICS_PAYLOAD_ID = 'PermitReissuance')
INSERT INTO dbo.ICS_PAYLOAD SELECT 'PermitTermination', 'PermitTerminationSubmission', 'N', 'N', null, 'ICS_PRMT_TERM' WHERE NOT EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P WHERE P.ICS_PAYLOAD_ID = 'PermitTermination')
INSERT INTO dbo.ICS_PAYLOAD SELECT 'PermitTrackingEvent', 'PermitTrackingEventSubmission', 'N', 'N', null, 'ICS_PRMT_TRACK_EVT' WHERE NOT EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P WHERE P.ICS_PAYLOAD_ID = 'PermitTrackingEvent')
INSERT INTO dbo.ICS_PAYLOAD SELECT 'ScheduleEventViolation', 'ScheduleEventViolationSubmission', 'N', 'N', null, 'ICS_SCHD_EVT_VIOL' WHERE NOT EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P WHERE P.ICS_PAYLOAD_ID = 'ScheduleEventViolation')
INSERT INTO dbo.ICS_PAYLOAD SELECT 'SewerOverflowBypassEventReport', 'SewerOverflowBypassEventReportSubmission', 'N', 'N', null, 'ICS_SEWER_OVRFLW_BYPASS_EVT_REP' WHERE NOT EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P WHERE P.ICS_PAYLOAD_ID = 'SewerOverflowBypassEventReport')
INSERT INTO dbo.ICS_PAYLOAD SELECT 'SingleEventViolation', 'SingleEventViolationSubmission', 'N', 'N', null, 'ICS_SNGL_EVT_VIOL' WHERE NOT EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P WHERE P.ICS_PAYLOAD_ID = 'SingleEventViolation')
INSERT INTO dbo.ICS_PAYLOAD SELECT 'SWConstructionPermit', 'SWConstructionPermitSubmission', 'N', 'N', null, 'ICS_SW_CNST_PRMT' WHERE NOT EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P WHERE P.ICS_PAYLOAD_ID = 'SWConstructionPermit')
INSERT INTO dbo.ICS_PAYLOAD SELECT 'SWIndustrialAnnualReport', 'SWIndustrialAnnualReportSubmission', 'N', 'N', null, 'ICS_SW_INDST_ANNUL_REP' WHERE NOT EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P WHERE P.ICS_PAYLOAD_ID = 'SWIndustrialAnnualReport')
INSERT INTO dbo.ICS_PAYLOAD SELECT 'SWIndustrialPermit', 'SWIndustrialPermitSubmission', 'N', 'N', null, 'ICS_SW_INDST_PRMT' WHERE NOT EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P WHERE P.ICS_PAYLOAD_ID = 'SWIndustrialPermit')
INSERT INTO dbo.ICS_PAYLOAD SELECT 'SWMS4AnnualProgramReport', 'SWMS4AnnualProgramReportSubmission', 'N', 'N', null, 'ICS_SWMS_4_ANNUL_PROG_REP' WHERE NOT EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P WHERE P.ICS_PAYLOAD_ID = 'SWMS4AnnualProgramReport')
INSERT INTO dbo.ICS_PAYLOAD SELECT 'SWMS4Permit', 'SWMS4PermitSubmission', 'N', 'N', null, 'ICS_SWMS_4_PRMT' WHERE NOT EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P WHERE P.ICS_PAYLOAD_ID = 'SWMS4Permit')
INSERT INTO dbo.ICS_PAYLOAD SELECT 'UnpermittedFacility', 'UnpermittedFacilitySubmission', 'N', 'N', null, 'ICS_UNPRMT_FAC' WHERE NOT EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P WHERE P.ICS_PAYLOAD_ID = 'UnpermittedFacility')


update dbo.ICS_PAYLOAD set BASE_TABLE_NAME = 'ICS_BASIC_PRMT' ,ETL_PROCEDURE = 'ics_etl_basicpermit'  where ICS_PAYLOAD_ID = 'BasicPermit';
update dbo.ICS_PAYLOAD set BASE_TABLE_NAME = 'ICS_BS_ANNUL_PROG_REP' ,ETL_PROCEDURE = 'ics_etl_biosolidsannualprogramreport'  where ICS_PAYLOAD_ID = 'BiosolidsAnnualProgramReport';
update dbo.ICS_PAYLOAD set BASE_TABLE_NAME = 'ICS_BS_PRMT' ,ETL_PROCEDURE = 'ics_etl_biosolidspermit'  where ICS_PAYLOAD_ID = 'BiosolidsPermit';
update dbo.ICS_PAYLOAD set BASE_TABLE_NAME = 'ICS_CAFO_ANNUL_PROG_REP' ,ETL_PROCEDURE = 'ics_etl_cafoannualprogramreport'  where ICS_PAYLOAD_ID = 'CAFOAnnualProgramReport';
update dbo.ICS_PAYLOAD set BASE_TABLE_NAME = 'ICS_CAFO_PRMT' ,ETL_PROCEDURE = 'ics_etl_cafopermit'  where ICS_PAYLOAD_ID = 'CAFOPermit';
update dbo.ICS_PAYLOAD set BASE_TABLE_NAME = 'ICS_COLL_SYSTM_PRMT' ,ETL_PROCEDURE = 'ics_etl_collectionsystempermit'  where ICS_PAYLOAD_ID = 'CollectionSystemPermit';
update dbo.ICS_PAYLOAD set BASE_TABLE_NAME = 'ICS_CMPL_MON' ,ETL_PROCEDURE = 'ics_etl_compliancemonitoring'  where ICS_PAYLOAD_ID = 'ComplianceMonitoring';
update dbo.ICS_PAYLOAD set BASE_TABLE_NAME = 'ICS_CMPL_MON_LNK' ,ETL_PROCEDURE = 'ics_etl_compliancemonitoringlinkage'  where ICS_PAYLOAD_ID = 'ComplianceMonitoringLinkage';
update dbo.ICS_PAYLOAD set BASE_TABLE_NAME = 'ICS_CMPL_SCHD' ,ETL_PROCEDURE = 'ics_etl_complianceschedule'  where ICS_PAYLOAD_ID = 'ComplianceSchedule';
update dbo.ICS_PAYLOAD set BASE_TABLE_NAME = 'ICS_COPY_MGP_LMT_SET' ,ETL_PROCEDURE = 'ics_etl_copymgplimitset'  where ICS_PAYLOAD_ID = 'CopyMGPLimitSet';
update dbo.ICS_PAYLOAD set BASE_TABLE_NAME = 'ICS_COPY_MGP_LMT_SET' ,ETL_PROCEDURE = 'ics_etl_copymgpms4requirement'  where ICS_PAYLOAD_ID = 'CopyMGPMS4Requirement';
update dbo.ICS_PAYLOAD set BASE_TABLE_NAME = 'ICS_CSO_LONG_TERM_CONTROL_PLAN' ,ETL_PROCEDURE = 'ics_etl_csolongtermcontrolplan'  where ICS_PAYLOAD_ID = 'CSOLongTermControlPlan';
update dbo.ICS_PAYLOAD set BASE_TABLE_NAME = 'ICS_CWA_316B_PROG_REP' ,ETL_PROCEDURE = 'ics_etl_cwa316bprogramreport'  where ICS_PAYLOAD_ID = 'CWA316bProgramReport';
update dbo.ICS_PAYLOAD set BASE_TABLE_NAME = 'ICS_DSCH_MON_REP' ,ETL_PROCEDURE = 'ics_etl_dischargemonitoringreport'  where ICS_PAYLOAD_ID = 'DischargeMonitoringReport';
update dbo.ICS_PAYLOAD set BASE_TABLE_NAME = 'ICS_DMR_VIOL' ,ETL_PROCEDURE = 'ics_etl_dmrviolation'  where ICS_PAYLOAD_ID = 'DMRViolation';
update dbo.ICS_PAYLOAD set BASE_TABLE_NAME = 'ICS_EFFLU_TRADE_PRTNER' ,ETL_PROCEDURE = 'ics_etl_effluenttradepartner'  where ICS_PAYLOAD_ID = 'EffluentTradePartner';
update dbo.ICS_PAYLOAD set BASE_TABLE_NAME = 'ICS_ENFRC_ACTN_MILESTONE' ,ETL_PROCEDURE = 'ics_etl_enforcementactionmilestone'  where ICS_PAYLOAD_ID = 'EnforcementActionMilestone';
update dbo.ICS_PAYLOAD set BASE_TABLE_NAME = 'ICS_ENFRC_ACTN_VIOL_LNK' ,ETL_PROCEDURE = 'ics_etl_enforcementactionviolationlinkage'  where ICS_PAYLOAD_ID = 'EnforcementActionViolationLinkage';
update dbo.ICS_PAYLOAD set BASE_TABLE_NAME = 'ICS_FINAL_ORDER_VIOL_LNK' ,ETL_PROCEDURE = 'ics_etl_finalorderviolationlinkage'  where ICS_PAYLOAD_ID = 'FinalOrderViolationLinkage';
update dbo.ICS_PAYLOAD set BASE_TABLE_NAME = 'ICS_FRML_ENFRC_ACTN' ,ETL_PROCEDURE = 'ics_etl_formalenforcementaction'  where ICS_PAYLOAD_ID = 'FormalEnforcementAction';
update dbo.ICS_PAYLOAD set BASE_TABLE_NAME = 'ICS_GNRL_PRMT' ,ETL_PROCEDURE = 'ics_etl_generalpermit'  where ICS_PAYLOAD_ID = 'GeneralPermit';
update dbo.ICS_PAYLOAD set BASE_TABLE_NAME = 'ICS_HIST_PRMT_SCHD_EVTS' ,ETL_PROCEDURE = 'ics_etl_historicalpermitscheduleevents'  where ICS_PAYLOAD_ID = 'HistoricalPermitScheduleEvents';
update dbo.ICS_PAYLOAD set BASE_TABLE_NAME = 'ICS_INFRML_ENFRC_ACTN' ,ETL_PROCEDURE = 'ics_etl_informalenforcementaction'  where ICS_PAYLOAD_ID = 'InformalEnforcementAction';
update dbo.ICS_PAYLOAD set BASE_TABLE_NAME = 'ICS_LMTS' ,ETL_PROCEDURE = 'ics_etl_limits'  where ICS_PAYLOAD_ID = 'Limits';
update dbo.ICS_PAYLOAD set BASE_TABLE_NAME = 'ICS_LMT_SET' ,ETL_PROCEDURE = 'ics_etl_limitset'  where ICS_PAYLOAD_ID = 'LimitSet';
update dbo.ICS_PAYLOAD set BASE_TABLE_NAME = 'ICS_MASTER_GNRL_PRMT' ,ETL_PROCEDURE = 'ics_etl_mastergeneralpermit'  where ICS_PAYLOAD_ID = 'MasterGeneralPermit';
update dbo.ICS_PAYLOAD set BASE_TABLE_NAME = 'ICS_NARR_COND_SCHD' ,ETL_PROCEDURE = 'ics_etl_narrativeconditionschedule'  where ICS_PAYLOAD_ID = 'NarrativeConditionSchedule';
update dbo.ICS_PAYLOAD set BASE_TABLE_NAME = 'ICS_NPDES_VARIANCE_PRMT' ,ETL_PROCEDURE = 'ics_etl_npdesvariancepermit'  where ICS_PAYLOAD_ID = 'NPDESVariancePermit';
update dbo.ICS_PAYLOAD set BASE_TABLE_NAME = 'ICS_PARAM_LMTS' ,ETL_PROCEDURE = 'ics_etl_parameterlimits'  where ICS_PAYLOAD_ID = 'ParameterLimits';
update dbo.ICS_PAYLOAD set BASE_TABLE_NAME = 'ICS_PRMT_REISSU' ,ETL_PROCEDURE = 'ics_etl_permitreissuance'  where ICS_PAYLOAD_ID = 'PermitReissuance';
update dbo.ICS_PAYLOAD set BASE_TABLE_NAME = 'ICS_PRMT_FEATR' ,ETL_PROCEDURE = 'ics_etl_permittedfeature'  where ICS_PAYLOAD_ID = 'PermittedFeature';
update dbo.ICS_PAYLOAD set BASE_TABLE_NAME = 'ICS_PRMT_TERM' ,ETL_PROCEDURE = 'ics_etl_permittermination'  where ICS_PAYLOAD_ID = 'PermitTermination';
update dbo.ICS_PAYLOAD set BASE_TABLE_NAME = 'ICS_PRMT_TRACK_EVT' ,ETL_PROCEDURE = 'ics_etl_permittrackingevent'  where ICS_PAYLOAD_ID = 'PermitTrackingEvent';
update dbo.ICS_PAYLOAD set BASE_TABLE_NAME = 'ICS_POTW_PRMT' ,ETL_PROCEDURE = 'ics_etl_potwpermit'  where ICS_PAYLOAD_ID = 'POTWPermit';
update dbo.ICS_PAYLOAD set BASE_TABLE_NAME = 'ICS_POTW_TRTMNT_TECHNOLOGY_PRMT' ,ETL_PROCEDURE = 'ics_etl_potwtreatmenttechnologypermit'  where ICS_PAYLOAD_ID = 'POTWTreatmentTechnologyPermit';
update dbo.ICS_PAYLOAD set BASE_TABLE_NAME = 'ICS_PRETR_PRMT' ,ETL_PROCEDURE = 'ics_etl_pretreatmentpermit'  where ICS_PAYLOAD_ID = 'PretreatmentPermit';
update dbo.ICS_PAYLOAD set BASE_TABLE_NAME = 'ICS_PRETR_PROG_REP' ,ETL_PROCEDURE = 'ics_etl_pretreatmentprogramreport'  where ICS_PAYLOAD_ID = 'PretreatmentProgramReport';
update dbo.ICS_PAYLOAD set BASE_TABLE_NAME = 'ICS_SCHD_EVT_VIOL' ,ETL_PROCEDURE = 'ics_etl_scheduleeventviolation'  where ICS_PAYLOAD_ID = 'ScheduleEventViolation';
update dbo.ICS_PAYLOAD set BASE_TABLE_NAME = 'ICS_SEWER_OVRFLW_BYPASS_EVT_REP' ,ETL_PROCEDURE = 'ics_etl_seweroverflowbypasseventreport'  where ICS_PAYLOAD_ID = 'SewerOverflowBypassEventReport';
update dbo.ICS_PAYLOAD set BASE_TABLE_NAME = 'ICS_SNGL_EVT_VIOL' ,ETL_PROCEDURE = 'ics_etl_singleeventviolation'  where ICS_PAYLOAD_ID = 'SingleEventViolation';
update dbo.ICS_PAYLOAD set BASE_TABLE_NAME = 'ICS_SW_CNST_PRMT' ,ETL_PROCEDURE = 'ics_etl_swconstructionpermit'  where ICS_PAYLOAD_ID = 'SWConstructionPermit';
update dbo.ICS_PAYLOAD set BASE_TABLE_NAME = 'ICS_SW_INDST_ANNUL_REP' ,ETL_PROCEDURE = 'ics_etl_swindustrialannualreport'  where ICS_PAYLOAD_ID = 'SWIndustrialAnnualReport';
update dbo.ICS_PAYLOAD set BASE_TABLE_NAME = 'ICS_SW_INDST_PRMT' ,ETL_PROCEDURE = 'ics_etl_swindustrialpermit'  where ICS_PAYLOAD_ID = 'SWIndustrialPermit';
update dbo.ICS_PAYLOAD set BASE_TABLE_NAME = 'ICS_SWMS_4_ANNUL_PROG_REP' ,ETL_PROCEDURE = 'ics_etl_swms4annualprogramreport'  where ICS_PAYLOAD_ID = 'SWMS4AnnualProgramReport';
update dbo.ICS_PAYLOAD set BASE_TABLE_NAME = 'ICS_SWMS_4_PRMT' ,ETL_PROCEDURE = 'ics_etl_swms4permit'  where ICS_PAYLOAD_ID = 'SWMS4Permit';
update dbo.ICS_PAYLOAD set BASE_TABLE_NAME = 'ICS_UNPRMT_FAC' ,ETL_PROCEDURE = 'ics_etl_unpermittedfacility'  where ICS_PAYLOAD_ID = 'UnpermittedFacility';

-- 5.14 New columns in ICS_SUBM_RESULTS

IF COLUMNPROPERTY(OBJECT_ID('dbo.ICS_SUBM_RESULTS'), 'PROG_REP_FORM_SET_ID', 'ColumnId') IS NULL
BEGIN
	ALTER TABLE dbo.ICS_SUBM_RESULTS ADD PROG_REP_FORM_SET_ID VARCHAR(50) NULL
END

IF COLUMNPROPERTY(OBJECT_ID('dbo.ICS_SUBM_RESULTS'), 'PROG_REP_FORM_ID', 'ColumnId') IS NULL
BEGIN
	ALTER TABLE dbo.ICS_SUBM_RESULTS ADD PROG_REP_FORM_ID INT NULL
END

IF COLUMNPROPERTY(OBJECT_ID('dbo.ICS_SUBM_RESULTS'), 'COLL_SYSTM_IDENT', 'ColumnId') IS NULL
BEGIN
	ALTER TABLE dbo.ICS_SUBM_RESULTS ADD COLL_SYSTM_IDENT VARCHAR(20) NULL
END

IF COLUMNPROPERTY(OBJECT_ID('dbo.ICS_SUBM_RESULTS'), 'NPDES_VARIANCE_TYPE_CODE', 'ColumnId') IS NULL
BEGIN
	ALTER TABLE dbo.ICS_SUBM_RESULTS ADD NPDES_VARIANCE_TYPE_CODE VARCHAR(3) NULL
END

IF COLUMNPROPERTY(OBJECT_ID('dbo.ICS_SUBM_RESULTS'), 'NPDES_VARIANCE_SUBM_DATE', 'ColumnId') IS NULL
BEGIN
	ALTER TABLE dbo.ICS_SUBM_RESULTS ADD NPDES_VARIANCE_SUBM_DATE DATETIME NULL
END

-- CREATE UNIQUE INDICES


if(
SELECT count(1)
FROM sys.indexes 
WHERE name='IX_BASIC_PRMT_PRMT_IDENT' AND object_id = OBJECT_ID('dbo.ICS_BASIC_PRMT')) = 0 
	BEGIN
	CREATE UNIQUE NONCLUSTERED INDEX IX_BASIC_PRMT_PRMT_IDENT ON dbo.ICS_BASIC_PRMT
	(
		PRMT_IDENT
	)

	END
GO

if(
SELECT count(1)
FROM sys.indexes 
WHERE name='IX_BS_ANL_REP_PR_ID_RE_CV_DA' AND object_id = OBJECT_ID('dbo.ICS_BS_ANNUL_PROG_REP')) = 0 
	BEGIN
	CREATE UNIQUE NONCLUSTERED INDEX IX_BS_ANL_REP_PR_ID_RE_CV_DA ON dbo.ICS_BS_ANNUL_PROG_REP
	(
		PRMT_IDENT,PROG_REP_FORM_SET_ID,PROG_REP_FORM_ID
	)

	END
GO

if(
SELECT count(1)
FROM sys.indexes 
WHERE name='IX_BK_BS_ANNUL_PROG_REP' AND object_id = OBJECT_ID('dbo.ICS_BS_ANNUL_PROG_REP')) = 0 
	BEGIN
	CREATE UNIQUE NONCLUSTERED INDEX IX_BK_BS_ANNUL_PROG_REP ON dbo.ICS_BS_ANNUL_PROG_REP
	(
		PRMT_IDENT,PROG_REP_FORM_SET_ID,PROG_REP_FORM_ID
	)

	END
GO

if(
SELECT count(1)
FROM sys.indexes 
WHERE name='IX_BS_PRMT_PRMT_IDENT' AND object_id = OBJECT_ID('dbo.ICS_BS_PRMT')) = 0 
	BEGIN
	CREATE UNIQUE NONCLUSTERED INDEX IX_BS_PRMT_PRMT_IDENT ON dbo.ICS_BS_PRMT
	(
		PRMT_IDENT
	)

	END
GO

if(
SELECT count(1)
FROM sys.indexes 
WHERE name='IX_BK_CAFO_ANNUL_PROG_REP' AND object_id = OBJECT_ID('dbo.ICS_CAFO_ANNUL_PROG_REP')) = 0 
	BEGIN
	CREATE UNIQUE NONCLUSTERED INDEX IX_BK_CAFO_ANNUL_PROG_REP ON dbo.ICS_CAFO_ANNUL_PROG_REP
	(
		PRMT_IDENT,PROG_REP_FORM_SET_ID,PROG_REP_FORM_ID
	)

	END
GO

if(
SELECT count(1)
FROM sys.indexes 
WHERE name='IX_CAFO_PRMT_PRMT_IDENT' AND object_id = OBJECT_ID('dbo.ICS_CAFO_PRMT')) = 0 
	BEGIN
	CREATE UNIQUE NONCLUSTERED INDEX IX_CAFO_PRMT_PRMT_IDENT ON dbo.ICS_CAFO_PRMT
	(
		PRMT_IDENT
	)

	END
GO

if(
SELECT count(1)
FROM sys.indexes 
WHERE name='IX_BK_COLL_SYSTM_PRMT' AND object_id = OBJECT_ID('dbo.ICS_COLL_SYSTM_PRMT')) = 0 
	BEGIN
	CREATE UNIQUE NONCLUSTERED INDEX IX_BK_COLL_SYSTM_PRMT ON dbo.ICS_COLL_SYSTM_PRMT
	(
		PRMT_IDENT,COLL_SYSTM_IDENT
	)

	END
GO

if(
SELECT count(1)
FROM sys.indexes 
WHERE name='IX_CMPL_MON_CMPL_MON_IDENT' AND object_id = OBJECT_ID('dbo.ICS_CMPL_MON')) = 0 
	BEGIN
	CREATE UNIQUE NONCLUSTERED INDEX IX_CMPL_MON_CMPL_MON_IDENT ON dbo.ICS_CMPL_MON
	(
		CMPL_MON_IDENT
	)

	END
GO

if(
SELECT count(1)
FROM sys.indexes 
WHERE name='IX_CM_SC_EN_AC_ID_FI_OR_ID_PR' AND object_id = OBJECT_ID('dbo.ICS_CMPL_SCHD')) = 0 
	BEGIN
	CREATE UNIQUE NONCLUSTERED INDEX IX_CM_SC_EN_AC_ID_FI_OR_ID_PR ON dbo.ICS_CMPL_SCHD
	(
		ENFRC_ACTN_IDENT, FINAL_ORDER_IDENT, PRMT_IDENT, CMPL_SCHD_NUM
	)

	END
GO

if(
SELECT count(1)
FROM sys.indexes 
WHERE name='IX_BK_COPY_MGP_LMT_SET' AND object_id = OBJECT_ID('dbo.ICS_COPY_MGP_LMT_SET')) = 0 
	BEGIN
	CREATE UNIQUE NONCLUSTERED INDEX IX_BK_COPY_MGP_LMT_SET ON dbo.ICS_COPY_MGP_LMT_SET
	(
		PRMT_IDENT,PRMT_FEATR_IDENT,LMT_SET_DESIGNATOR
	)

	END
GO

if(
SELECT count(1)
FROM sys.indexes 
WHERE name='IX_BK_COPY_MGPMS_4_REQ' AND object_id = OBJECT_ID('dbo.ICS_COPY_MGPMS_4_REQ')) = 0 
	BEGIN
	CREATE UNIQUE NONCLUSTERED INDEX IX_BK_COPY_MGPMS_4_REQ ON dbo.ICS_COPY_MGPMS_4_REQ
	(
		PRMT_IDENT
	)

	END
GO

if(
SELECT count(1)
FROM sys.indexes 
WHERE name='IX_BK_CSO_LONG_TERM_CONTROL_PLAN' AND object_id = OBJECT_ID('dbo.ICS_CSO_LONG_TERM_CONTROL_PLAN')) = 0 
	BEGIN
	CREATE UNIQUE NONCLUSTERED INDEX IX_BK_CSO_LONG_TERM_CONTROL_PLAN ON dbo.ICS_CSO_LONG_TERM_CONTROL_PLAN
	(
		PRMT_IDENT
	)

	END
GO

if(
SELECT count(1)
FROM sys.indexes 
WHERE name='IX_BK_ICS_CWA_316B_PROG_REP' AND object_id = OBJECT_ID('dbo.ICS_CWA_316B_PROG_REP')) = 0 
	BEGIN
	CREATE UNIQUE NONCLUSTERED INDEX IX_BK_ICS_CWA_316B_PROG_REP ON dbo.ICS_CWA_316B_PROG_REP
	(
		PRMT_IDENT,PROG_REP_FORM_SET_ID,PROG_REP_FORM_ID
	)

	END
GO

if(
SELECT count(1)
FROM sys.indexes 
WHERE name='IX_DS_MO_RE_PR_ID_PR_FE_ID_LM' AND object_id = OBJECT_ID('dbo.ICS_DSCH_MON_REP')) = 0 
	BEGIN
	CREATE UNIQUE NONCLUSTERED INDEX IX_DS_MO_RE_PR_ID_PR_FE_ID_LM ON dbo.ICS_DSCH_MON_REP
	(
		PRMT_IDENT, PRMT_FEATR_IDENT, LMT_SET_DESIGNATOR, MON_PERIOD_END_DATE
	)

	END
GO

if(
SELECT count(1)
FROM sys.indexes 
WHERE name='IX_DM_VI_PR_ID_PR_FE_ID_LM_SE' AND object_id = OBJECT_ID('dbo.ICS_DMR_VIOL')) = 0 
	BEGIN
	CREATE UNIQUE NONCLUSTERED INDEX IX_DM_VI_PR_ID_PR_FE_ID_LM_SE ON dbo.ICS_DMR_VIOL
	(
		PRMT_IDENT, PRMT_FEATR_IDENT, LMT_SET_DESIGNATOR, MON_PERIOD_END_DATE, PARAM_CODE, MON_SITE_DESC_CODE, LMT_SEASON_NUM, NUM_REP_CODE, NUM_REP_VIOL_CODE
	)

	END
GO

if(
SELECT count(1)
FROM sys.indexes 
WHERE name='IX_EF_TR_PR_PR_ID_PR_FE_ID_LM' AND object_id = OBJECT_ID('dbo.ICS_EFFLU_TRADE_PRTNER')) = 0 
	BEGIN
	CREATE UNIQUE NONCLUSTERED INDEX IX_EF_TR_PR_PR_ID_PR_FE_ID_LM ON dbo.ICS_EFFLU_TRADE_PRTNER
	(
		PRMT_IDENT, PRMT_FEATR_IDENT, LMT_SET_DESIGNATOR, PARAM_CODE, MON_SITE_DESC_CODE, LMT_SEASON_NUM, LMT_START_DATE, LMT_END_DATE, LMT_MOD_EFFECTIVE_DATE, TRADE_ID
	)

	END
GO

if(
SELECT count(1)
FROM sys.indexes 
WHERE name='IX_ENF_AC_ML_EN_AC_ID_ML_TY_CO' AND object_id = OBJECT_ID('dbo.ICS_ENFRC_ACTN_MILESTONE')) = 0 
	BEGIN
	CREATE UNIQUE NONCLUSTERED INDEX IX_ENF_AC_ML_EN_AC_ID_ML_TY_CO ON dbo.ICS_ENFRC_ACTN_MILESTONE
	(
		ENFRC_ACTN_IDENT, MILESTONE_TYPE_CODE
	)

	END
GO

if(
SELECT count(1)
FROM sys.indexes 
WHERE name='IX_FRML_ENFR_ACTN_ENFR_ACT_IDN' AND object_id = OBJECT_ID('dbo.ICS_FRML_ENFRC_ACTN')) = 0 
	BEGIN
	CREATE UNIQUE NONCLUSTERED INDEX IX_FRML_ENFR_ACTN_ENFR_ACT_IDN ON dbo.ICS_FRML_ENFRC_ACTN
	(
		ENFRC_ACTN_IDENT
	)

	END
GO

if(
SELECT count(1)
FROM sys.indexes 
WHERE name='IX_GNRL_PRMT_PRMT_IDENT' AND object_id = OBJECT_ID('dbo.ICS_GNRL_PRMT')) = 0 
	BEGIN
	CREATE UNIQUE NONCLUSTERED INDEX IX_GNRL_PRMT_PRMT_IDENT ON dbo.ICS_GNRL_PRMT
	(
		PRMT_IDENT
	)

	END
GO

if(
SELECT count(1)
FROM sys.indexes 
WHERE name='IX_HI_PR_SC_EV_PR_ID_PR_EF_DA' AND object_id = OBJECT_ID('dbo.ICS_HIST_PRMT_SCHD_EVTS')) = 0 
	BEGIN
	CREATE UNIQUE NONCLUSTERED INDEX IX_HI_PR_SC_EV_PR_ID_PR_EF_DA ON dbo.ICS_HIST_PRMT_SCHD_EVTS
	(
		PRMT_IDENT, PRMT_EFFECTIVE_DATE, NARR_COND_NUM, SCHD_EVT_CODE, SCHD_DATE
	)

	END
GO

if(
SELECT count(1)
FROM sys.indexes 
WHERE name='IX_INFR_ENFR_ACTN_ENFR_ACT_IDN' AND object_id = OBJECT_ID('dbo.ICS_INFRML_ENFRC_ACTN')) = 0 
	BEGIN
	CREATE UNIQUE NONCLUSTERED INDEX IX_INFR_ENFR_ACTN_ENFR_ACT_IDN ON dbo.ICS_INFRML_ENFRC_ACTN
	(
		ENFRC_ACTN_IDENT
	)

	END
GO

if(
SELECT count(1)
FROM sys.indexes 
WHERE name='IX_LM_PR_ID_PR_FE_ID_LM_SE_DS' AND object_id = OBJECT_ID('dbo.ICS_LMTS')) = 0 
	BEGIN
	CREATE UNIQUE NONCLUSTERED INDEX IX_LM_PR_ID_PR_FE_ID_LM_SE_DS ON dbo.ICS_LMTS
	(
		PRMT_IDENT, PRMT_FEATR_IDENT, LMT_SET_DESIGNATOR, PARAM_CODE, MON_SITE_DESC_CODE, LMT_SEASON_NUM, LMT_START_DATE, LMT_END_DATE
	)

	END
GO

if(
SELECT count(1)
FROM sys.indexes 
WHERE name='IX_LM_SE_PR_ID_PR_FE_ID_LM_SE' AND object_id = OBJECT_ID('dbo.ICS_LMT_SET')) = 0 
	BEGIN
	CREATE UNIQUE NONCLUSTERED INDEX IX_LM_SE_PR_ID_PR_FE_ID_LM_SE ON dbo.ICS_LMT_SET
	(
		PRMT_IDENT, PRMT_FEATR_IDENT, LMT_SET_DESIGNATOR
	)

	END
GO

if(
SELECT count(1)
FROM sys.indexes 
WHERE name='IX_MASTER_GNRL_PRMT_PRMT_IDENT' AND object_id = OBJECT_ID('dbo.ICS_MASTER_GNRL_PRMT')) = 0 
	BEGIN
	CREATE UNIQUE NONCLUSTERED INDEX IX_MASTER_GNRL_PRMT_PRMT_IDENT ON dbo.ICS_MASTER_GNRL_PRMT
	(
		PRMT_IDENT
	)

	END
GO

if(
SELECT count(1)
FROM sys.indexes 
WHERE name='IX_NAR_CON_SCH_PRM_ID_NA_CO_NU' AND object_id = OBJECT_ID('dbo.ICS_NARR_COND_SCHD')) = 0 
	BEGIN
	CREATE UNIQUE NONCLUSTERED INDEX IX_NAR_CON_SCH_PRM_ID_NA_CO_NU ON dbo.ICS_NARR_COND_SCHD
	(
		PRMT_IDENT, NARR_COND_NUM
	)

	END
GO

if(
SELECT count(1)
FROM sys.indexes 
WHERE name='IX_BK_NPDES_VARIANCE_PRMT' AND object_id = OBJECT_ID('dbo.ICS_NPDES_VARIANCE_PRMT')) = 0 
	BEGIN
	CREATE UNIQUE NONCLUSTERED INDEX IX_BK_NPDES_VARIANCE_PRMT ON dbo.ICS_NPDES_VARIANCE_PRMT
	(
		PRMT_IDENT,NPDES_VARIANCE_TYPE_CODE,NPDES_VARIANCE_SUBM_DATE
	)

	END
GO

if(
SELECT count(1)
FROM sys.indexes 
WHERE name='IX_PA_LM_PR_ID_PR_FE_ID_LM_SE' AND object_id = OBJECT_ID('dbo.ICS_PARAM_LMTS')) = 0 
	BEGIN
	CREATE UNIQUE NONCLUSTERED INDEX IX_PA_LM_PR_ID_PR_FE_ID_LM_SE ON dbo.ICS_PARAM_LMTS
	(
		PRMT_IDENT, PRMT_FEATR_IDENT, LMT_SET_DESIGNATOR, PARAM_CODE, MON_SITE_DESC_CODE, LMT_SEASON_NUM
	)

	END
GO

if(
SELECT count(1)
FROM sys.indexes 
WHERE name='IX_PRM_RSS_PRM_IDN_PRM_ISS_DAT' AND object_id = OBJECT_ID('dbo.ICS_PRMT_REISSU')) = 0 
	BEGIN
	CREATE UNIQUE NONCLUSTERED INDEX IX_PRM_RSS_PRM_IDN_PRM_ISS_DAT ON dbo.ICS_PRMT_REISSU
	(
		PRMT_IDENT, PRMT_ISSUE_DATE
	)

	END
GO

if(
SELECT count(1)
FROM sys.indexes 
WHERE name='IX_PRM_FET_PRM_IDN_PRM_FET_IDN' AND object_id = OBJECT_ID('dbo.ICS_PRMT_FEATR')) = 0 
	BEGIN
	CREATE UNIQUE NONCLUSTERED INDEX IX_PRM_FET_PRM_IDN_PRM_FET_IDN ON dbo.ICS_PRMT_FEATR
	(
		PRMT_IDENT, PRMT_FEATR_IDENT
	)

	END
GO

if(
SELECT count(1)
FROM sys.indexes 
WHERE name='IX_PRMT_TERM_PRMT_IDENT' AND object_id = OBJECT_ID('dbo.ICS_PRMT_TERM')) = 0 
	BEGIN
	CREATE UNIQUE NONCLUSTERED INDEX IX_PRMT_TERM_PRMT_IDENT ON dbo.ICS_PRMT_TERM
	(
		PRMT_IDENT
	)

	END
GO

if(
SELECT count(1)
FROM sys.indexes 
WHERE name='IX_PR_TR_EV_PR_ID_PR_TR_EV_CO' AND object_id = OBJECT_ID('dbo.ICS_PRMT_TRACK_EVT')) = 0 
	BEGIN
	CREATE UNIQUE NONCLUSTERED INDEX IX_PR_TR_EV_PR_ID_PR_TR_EV_CO ON dbo.ICS_PRMT_TRACK_EVT
	(
		PRMT_IDENT, PRMT_TRACK_EVT_CODE, PRMT_TRACK_EVT_DATE
	)

	END
GO

if(
SELECT count(1)
FROM sys.indexes 
WHERE name='IX_POTW_PRMT_PRMT_IDENT' AND object_id = OBJECT_ID('dbo.ICS_POTW_PRMT')) = 0 
	BEGIN
	CREATE UNIQUE NONCLUSTERED INDEX IX_POTW_PRMT_PRMT_IDENT ON dbo.ICS_POTW_PRMT
	(
		PRMT_IDENT
	)

	END
GO

if(
SELECT count(1)
FROM sys.indexes 
WHERE name='IX_BK_POTW_TRTMNT_TECHNOLOGY_PRMT' AND object_id = OBJECT_ID('dbo.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT')) = 0 
	BEGIN
	CREATE UNIQUE NONCLUSTERED INDEX IX_BK_POTW_TRTMNT_TECHNOLOGY_PRMT ON dbo.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT
	(
		PRMT_IDENT
	)

	END
GO

if(
SELECT count(1)
FROM sys.indexes 
WHERE name='IX_PRETR_PRMT_PRMT_IDENT' AND object_id = OBJECT_ID('dbo.ICS_PRETR_PRMT')) = 0 
	BEGIN
	CREATE UNIQUE NONCLUSTERED INDEX IX_PRETR_PRMT_PRMT_IDENT ON dbo.ICS_PRETR_PRMT
	(
		PRMT_IDENT
	)

	END
GO

if(
SELECT count(1)
FROM sys.indexes 
WHERE name='IX_BK_PRETR_PROG_REP' AND object_id = OBJECT_ID('dbo.ICS_PRETR_PROG_REP')) = 0 
	BEGIN
	CREATE UNIQUE NONCLUSTERED INDEX IX_BK_PRETR_PROG_REP ON dbo.ICS_PRETR_PROG_REP
	(
		PRMT_IDENT,PROG_REP_FORM_SET_ID,PROG_REP_FORM_ID
	)

	END
GO

if(
SELECT count(1)
FROM sys.indexes 
WHERE name='IX_BK_SEWER_OVRFLW_BYPASS_EVT_REP' AND object_id = OBJECT_ID('dbo.ICS_SEWER_OVRFLW_BYPASS_EVT_REP')) = 0 
	BEGIN
	CREATE UNIQUE NONCLUSTERED INDEX IX_BK_SEWER_OVRFLW_BYPASS_EVT_REP ON dbo.ICS_SEWER_OVRFLW_BYPASS_EVT_REP
	(
		PRMT_IDENT,PROG_REP_FORM_SET_ID,PROG_REP_FORM_ID
	)

	END
GO

if(
SELECT count(1)
FROM sys.indexes 
WHERE name='IX_SN_EV_VI_PR_ID_SN_EV_VI_CO' AND object_id = OBJECT_ID('dbo.ICS_SNGL_EVT_VIOL')) = 0 
	BEGIN
	CREATE UNIQUE NONCLUSTERED INDEX IX_SN_EV_VI_PR_ID_SN_EV_VI_CO ON dbo.ICS_SNGL_EVT_VIOL
	(
		PRMT_IDENT, SNGL_EVT_VIOL_CODE, SNGL_EVT_VIOL_DATE
	)

	END
GO

if(
SELECT count(1)
FROM sys.indexes 
WHERE name='IX_SW_CNST_PRMT_PRMT_IDENT' AND object_id = OBJECT_ID('dbo.ICS_SW_CNST_PRMT')) = 0 
	BEGIN
	CREATE UNIQUE NONCLUSTERED INDEX IX_SW_CNST_PRMT_PRMT_IDENT ON dbo.ICS_SW_CNST_PRMT
	(
		PRMT_IDENT
	)

	END
GO

if(
SELECT count(1)
FROM sys.indexes 
WHERE name='IX_SW_IN_AN_RE_PR_ID_IN_SW_AN' AND object_id = OBJECT_ID('dbo.ICS_SW_INDST_ANNUL_REP')) = 0 
	BEGIN
	CREATE UNIQUE NONCLUSTERED INDEX IX_SW_IN_AN_RE_PR_ID_IN_SW_AN ON dbo.ICS_SW_INDST_ANNUL_REP
	(
		PRMT_IDENT, INDST_SW_ANNUL_REP_RCVD_DATE
	)

	END
GO

if(
SELECT count(1)
FROM sys.indexes 
WHERE name='IX_SW_INDST_PRMT_PRMT_IDENT' AND object_id = OBJECT_ID('dbo.ICS_SW_INDST_PRMT')) = 0 
	BEGIN
	CREATE UNIQUE NONCLUSTERED INDEX IX_SW_INDST_PRMT_PRMT_IDENT ON dbo.ICS_SW_INDST_PRMT
	(
		PRMT_IDENT
	)

	END
GO

if(
SELECT count(1)
FROM sys.indexes 
WHERE name='IX_BK_SWMS_4_ANNUL_PROG_REP' AND object_id = OBJECT_ID('dbo.ICS_SWMS_4_ANNUL_PROG_REP')) = 0 
	BEGIN
	CREATE UNIQUE NONCLUSTERED INDEX IX_BK_SWMS_4_ANNUL_PROG_REP ON dbo.ICS_SWMS_4_ANNUL_PROG_REP
	(
		PRMT_IDENT,PROG_REP_FORM_SET_ID,PROG_REP_FORM_ID
	)

	END
GO

if(
SELECT count(1)
FROM sys.indexes 
WHERE name='IX_BK_SWMS_4_PRMT' AND object_id = OBJECT_ID('dbo.ICS_SWMS_4_PRMT')) = 0 
	BEGIN
	CREATE UNIQUE NONCLUSTERED INDEX IX_BK_SWMS_4_PRMT ON dbo.ICS_SWMS_4_PRMT
	(
		PRMT_IDENT
	)

	END
GO

if(
SELECT count(1)
FROM sys.indexes 
WHERE name='IX_UNPRMT_FAC_PRMT_IDENT' AND object_id = OBJECT_ID('dbo.ICS_UNPRMT_FAC')) = 0 
	BEGIN
	CREATE UNIQUE NONCLUSTERED INDEX IX_UNPRMT_FAC_PRMT_IDENT ON dbo.ICS_UNPRMT_FAC
	(
		PRMT_IDENT
	)

	END
GO


-- ADD NEW ICS_SUBM_RESULT columns for 5.14 (new keys for OECA data, no results yet)
IF COLUMNPROPERTY(OBJECT_ID('dbo.ICS_SUBM_RESULTS'), 'PROG_REP_FORM_SET_ID', 'ColumnId') IS NULL
BEGIN
	alter table ICS_SUBM_RESULTS ADD PROG_REP_FORM_SET_ID VARCHAR(50)
END
GO
IF COLUMNPROPERTY(OBJECT_ID('dbo.ICS_SUBM_RESULTS'), 'PROG_REP_FORM_ID', 'ColumnId') IS NULL
BEGIN
	alter table ICS_SUBM_RESULTS ADD PROG_REP_FORM_ID INT
END

IF COLUMNPROPERTY(OBJECT_ID('dbo.ICS_SUBM_RESULTS'), 'COLL_SYSTM_IDENT', 'ColumnId') IS NULL
BEGIN
	alter table ICS_SUBM_RESULTS ADD COLL_SYSTM_IDENT VARCHAR(20)
END
GO
IF COLUMNPROPERTY(OBJECT_ID('dbo.ICS_SUBM_RESULTS'), 'NPDES_VARIANCE_TYPE_CODE', 'ColumnId') IS NULL
BEGIN
	alter table ICS_SUBM_RESULTS ADD NPDES_VARIANCE_TYPE_CODE varchar(3)
END
GO
IF COLUMNPROPERTY(OBJECT_ID('dbo.ICS_SUBM_RESULTS'), 'NPDES_VARIANCE_SUBM_DATE', 'ColumnId') IS NULL
BEGIN
	alter table ICS_SUBM_RESULTS ADD NPDES_VARIANCE_SUBM_DATE datetime
END
GO


-- Update ICS_ABOUT_DB

delete from dbo.ICS_ABOUT_DB where DATA_KEY in ('ICIS_NPDES_VERSION','DEPLOY_DATE','DEPLOY_ANALYST');
insert into dbo.ICS_ABOUT_DB(ICS_ABOUT_DB_ID,DATA_KEY,DATA_VALUE) VALUES(NEWID(),'ICIS_NPDES_VERSION','5.14');
insert into dbo.ICS_ABOUT_DB(ICS_ABOUT_DB_ID,DATA_KEY,DATA_VALUE) VALUES(NEWID(),'DEPLOY_DATE',GETDATE());
insert into dbo.ICS_ABOUT_DB(ICS_ABOUT_DB_ID,DATA_KEY,DATA_VALUE) VALUES(NEWID(),'DEPLOY_ANALYST','Windsor');

