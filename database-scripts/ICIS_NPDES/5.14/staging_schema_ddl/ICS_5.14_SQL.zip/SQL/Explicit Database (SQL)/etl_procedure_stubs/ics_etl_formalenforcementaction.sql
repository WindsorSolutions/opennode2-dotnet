﻿
/*************************************************************************************************
** ObjectName: ics_etl_FormalEnforcementAction
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the FormalEnforcementActionSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/18/2025   Windsor      Created 
**
***************************************************************************************************/
CREATE OR ALTER PROCEDURE dbo.ics_etl_FormalEnforcementAction

AS

BEGIN
---------------------------- 
-- ICS_FRML_ENFRC_ACTN
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- /ICS_FRML_ENFRC_ACTN/ICS_FINAL_ORDER/ICS_FINAL_ORDER_PRMT_IDENT
DELETE
  FROM dbo.ICS_FINAL_ORDER_PRMT_IDENT
 WHERE ICS_FINAL_ORDER_ID IN
          (SELECT ICS_FINAL_ORDER.ICS_FINAL_ORDER_ID
             FROM dbo.ICS_FRML_ENFRC_ACTN
                  JOIN dbo.ICS_FINAL_ORDER ON ICS_FINAL_ORDER.ICS_FRML_ENFRC_ACTN_id = ICS_FRML_ENFRC_ACTN.ICS_FRML_ENFRC_ACTN_id
          );

-- /ICS_FRML_ENFRC_ACTN/ICS_FINAL_ORDER/ICS_SEP
DELETE
  FROM dbo.ICS_SEP
 WHERE ICS_FINAL_ORDER_ID IN
          (SELECT ICS_FINAL_ORDER.ICS_FINAL_ORDER_ID
             FROM dbo.ICS_FRML_ENFRC_ACTN
                  JOIN dbo.ICS_FINAL_ORDER ON ICS_FINAL_ORDER.ICS_FRML_ENFRC_ACTN_id = ICS_FRML_ENFRC_ACTN.ICS_FRML_ENFRC_ACTN_id
          );

-- /ICS_FRML_ENFRC_ACTN/ICS_ENFRC_ACTN_GOV_CONTACT
DELETE
  FROM dbo.ICS_ENFRC_ACTN_GOV_CONTACT
 WHERE ICS_FRML_ENFRC_ACTN_ID IN
          (SELECT ICS_FRML_ENFRC_ACTN.ICS_FRML_ENFRC_ACTN_ID
             FROM dbo.ICS_FRML_ENFRC_ACTN
          );

-- /ICS_FRML_ENFRC_ACTN/ICS_ENFRC_ACTN_TYPE
DELETE
  FROM dbo.ICS_ENFRC_ACTN_TYPE
 WHERE ICS_FRML_ENFRC_ACTN_ID IN
          (SELECT ICS_FRML_ENFRC_ACTN.ICS_FRML_ENFRC_ACTN_ID
             FROM dbo.ICS_FRML_ENFRC_ACTN
          );

-- /ICS_FRML_ENFRC_ACTN/ICS_ENFRC_AGNCY
DELETE
  FROM dbo.ICS_ENFRC_AGNCY
 WHERE ICS_FRML_ENFRC_ACTN_ID IN
          (SELECT ICS_FRML_ENFRC_ACTN.ICS_FRML_ENFRC_ACTN_ID
             FROM dbo.ICS_FRML_ENFRC_ACTN
          );

-- /ICS_FRML_ENFRC_ACTN/ICS_FINAL_ORDER
DELETE
  FROM dbo.ICS_FINAL_ORDER
 WHERE ICS_FRML_ENFRC_ACTN_ID IN
          (SELECT ICS_FRML_ENFRC_ACTN.ICS_FRML_ENFRC_ACTN_ID
             FROM dbo.ICS_FRML_ENFRC_ACTN
          );

-- /ICS_FRML_ENFRC_ACTN/ICS_PRMT_IDENT
DELETE
  FROM dbo.ICS_PRMT_IDENT
 WHERE ICS_FRML_ENFRC_ACTN_ID IN
          (SELECT ICS_FRML_ENFRC_ACTN.ICS_FRML_ENFRC_ACTN_ID
             FROM dbo.ICS_FRML_ENFRC_ACTN
          );

-- /ICS_FRML_ENFRC_ACTN/ICS_PROGS_VIOL
DELETE
  FROM dbo.ICS_PROGS_VIOL
 WHERE ICS_FRML_ENFRC_ACTN_ID IN
          (SELECT ICS_FRML_ENFRC_ACTN.ICS_FRML_ENFRC_ACTN_ID
             FROM dbo.ICS_FRML_ENFRC_ACTN
          );

-- /ICS_FRML_ENFRC_ACTN
DELETE
  FROM dbo.ICS_FRML_ENFRC_ACTN;


-- /ICS_FRML_ENFRC_ACTN
INSERT INTO dbo.ICS_FRML_ENFRC_ACTN (
     [ICS_FRML_ENFRC_ACTN_ID]
   , [ICS_PAYLOAD_ID]
   , [SRC_SYSTM_IDENT]
   , [TRANSACTION_TYPE]
   , [TRANSACTION_TIMESTAMP]
   , [ENFRC_ACTN_IDENT]
   , [ENFRC_ACTN_NAME]
   , [FORUM]
   , [RESL_TYPE_CODE]
   , [COMBINED_OR_SUPERSEDED_BY_EAID]
   , [REASON_DELETING_RECORD]
   , [FRML_EA_USR_DFND_FLD_1]
   , [FRML_EA_USR_DFND_FLD_2]
   , [FRML_EA_USR_DFND_FLD_3]
   , [FRML_EA_USR_DFND_FLD_4]
   , [FRML_EA_USR_DFND_FLD_5]
   , [FRML_EA_USR_DFND_FLD_6]
   , [ENFRC_AGNCY_NAME]
   , [KEY_HASH]
   , [DATA_HASH])
SELECT 
     null  --ICS_FRML_ENFRC_ACTN_ID, 
   , null  --ICS_PAYLOAD_ID, 
   , null  --SRC_SYSTM_IDENT, SourceSystemIdentifier
   , null  --TRANSACTION_TYPE, TransactionType
   , null  --TRANSACTION_TIMESTAMP, TransactionTimestamp
   , null  --ENFRC_ACTN_IDENT, EnforcementActionIdentifier
   , null  --ENFRC_ACTN_NAME, EnforcementActionName
   , null  --FORUM, Forum
   , null  --RESL_TYPE_CODE, ResolutionTypeCode
   , null  --COMBINED_OR_SUPERSEDED_BY_EAID, CombinedOrSupersededByEAID
   , null  --REASON_DELETING_RECORD, ReasonDeletingRecord
   , null  --FRML_EA_USR_DFND_FLD_1, FormalEAUserDefinedField1
   , null  --FRML_EA_USR_DFND_FLD_2, FormalEAUserDefinedField2
   , null  --FRML_EA_USR_DFND_FLD_3, FormalEAUserDefinedField3
   , null  --FRML_EA_USR_DFND_FLD_4, FormalEAUserDefinedField4
   , null  --FRML_EA_USR_DFND_FLD_5, FormalEAUserDefinedField5
   , null  --FRML_EA_USR_DFND_FLD_6, FormalEAUserDefinedField6
   , null  --ENFRC_AGNCY_NAME, EnforcementAgencyName
   , null  --KEY_HASH, 
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_FRML_ENFRC_ACTN/ICS_ENFRC_ACTN_GOV_CONTACT
INSERT INTO dbo.ICS_ENFRC_ACTN_GOV_CONTACT (
     [ICS_ENFRC_ACTN_GOV_CONTACT_ID]
   , [ICS_FRML_ENFRC_ACTN_ID]
   , [ICS_INFRML_ENFRC_ACTN_ID]
   , [AFFIL_TYPE_TXT]
   , [ELEC_ADDR_TXT]
   , [START_DATE_OF_CONTACT_ASSC]
   , [END_DATE_OF_CONTACT_ASSC]
   , [DATA_HASH])
SELECT 
     null  --ICS_ENFRC_ACTN_GOV_CONTACT_ID, 
   , null  --ICS_FRML_ENFRC_ACTN_ID, 
   , null  --ICS_INFRML_ENFRC_ACTN_ID, 
   , null  --AFFIL_TYPE_TXT, AffiliationTypeText
   , null  --ELEC_ADDR_TXT, ElectronicAddressText
   , null  --START_DATE_OF_CONTACT_ASSC, StartDateOfContactAssociation
   , null  --END_DATE_OF_CONTACT_ASSC, EndDateOfContactAssociation
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_FRML_ENFRC_ACTN/ICS_ENFRC_ACTN_TYPE
INSERT INTO dbo.ICS_ENFRC_ACTN_TYPE (
     [ICS_ENFRC_ACTN_TYPE_ID]
   , [ICS_FRML_ENFRC_ACTN_ID]
   , [ENFRC_ACTN_TYPE_CODE]
   , [DATA_HASH])
SELECT 
     null  --ICS_ENFRC_ACTN_TYPE_ID, 
   , null  --ICS_FRML_ENFRC_ACTN_ID, 
   , null  --ENFRC_ACTN_TYPE_CODE, EnforcementActionTypeCode
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_FRML_ENFRC_ACTN/ICS_ENFRC_AGNCY
INSERT INTO dbo.ICS_ENFRC_AGNCY (
     [ICS_ENFRC_AGNCY_ID]
   , [ICS_FRML_ENFRC_ACTN_ID]
   , [ICS_INFRML_ENFRC_ACTN_ID]
   , [ENFRC_AGNCY_TYPE_CODE]
   , [AGNCY_LEAD_IND]
   , [DATA_HASH])
SELECT 
     null  --ICS_ENFRC_AGNCY_ID, 
   , null  --ICS_FRML_ENFRC_ACTN_ID, 
   , null  --ICS_INFRML_ENFRC_ACTN_ID, 
   , null  --ENFRC_AGNCY_TYPE_CODE, EnforcementAgencyTypeCode
   , null  --AGNCY_LEAD_IND, AgencyLeadIndicator
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_FRML_ENFRC_ACTN/ICS_FINAL_ORDER
INSERT INTO dbo.ICS_FINAL_ORDER (
     [ICS_FINAL_ORDER_ID]
   , [ICS_FRML_ENFRC_ACTN_ID]
   , [FINAL_ORDER_IDENT]
   , [FINAL_ORDER_TYPE_CODE]
   , [FINAL_ORDER_ISSUED_ENTERD_DATE]
   , [NPDES_CLOSED_DATE]
   , [FINAL_ORDER_QNCR_CMNTS]
   , [CASH_CIVIL_PNLTY_REQD_AMT]
   , [CASH_CIVIL_PNLTY_COLL_AMT]
   , [OTHR_CMNTS]
   , [DATA_HASH])
SELECT 
     null  --ICS_FINAL_ORDER_ID, 
   , null  --ICS_FRML_ENFRC_ACTN_ID, 
   , null  --FINAL_ORDER_IDENT, FinalOrderIdentifier
   , null  --FINAL_ORDER_TYPE_CODE, FinalOrderTypeCode
   , null  --FINAL_ORDER_ISSUED_ENTERD_DATE, FinalOrderIssuedEnteredDate
   , null  --NPDES_CLOSED_DATE, NPDESClosedDate
   , null  --FINAL_ORDER_QNCR_CMNTS, FinalOrderQNCRComments
   , null  --CASH_CIVIL_PNLTY_REQD_AMT, CashCivilPenaltyRequiredAmount
   , null  --CASH_CIVIL_PNLTY_COLL_AMT, CashCivilPenaltyCollectedAmount
   , null  --OTHR_CMNTS, OtherComments
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_FRML_ENFRC_ACTN/ICS_FINAL_ORDER/ICS_FINAL_ORDER_PRMT_IDENT
INSERT INTO dbo.ICS_FINAL_ORDER_PRMT_IDENT (
     [ICS_FINAL_ORDER_PRMT_IDENT_ID]
   , [ICS_FINAL_ORDER_ID]
   , [FINAL_ORDER_PRMT_IDENT]
   , [DATA_HASH])
SELECT 
     null  --ICS_FINAL_ORDER_PRMT_IDENT_ID, 
   , null  --ICS_FINAL_ORDER_ID, 
   , null  --FINAL_ORDER_PRMT_IDENT, FinalOrderPermitIdentifier
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_FRML_ENFRC_ACTN/ICS_FINAL_ORDER/ICS_SEP
INSERT INTO dbo.ICS_SEP (
     [ICS_SEP_ID]
   , [ICS_FINAL_ORDER_ID]
   , [SEP_IDENT]
   , [SEP_DESC]
   , [SEP_PNLTY_ASSESSMENT_AMT]
   , [DATA_HASH])
SELECT 
     null  --ICS_SEP_ID, 
   , null  --ICS_FINAL_ORDER_ID, 
   , null  --SEP_IDENT, SupplementalEnvironmentalProjectIdentifier
   , null  --SEP_DESC, SupplementalEnvironmentalProjectDescription
   , null  --SEP_PNLTY_ASSESSMENT_AMT, SupplementalEnvironmentalProjectPenaltyAssessmentAmount
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_FRML_ENFRC_ACTN/ICS_PRMT_IDENT
INSERT INTO dbo.ICS_PRMT_IDENT (
     [ICS_PRMT_IDENT_ID]
   , [ICS_FRML_ENFRC_ACTN_ID]
   , [ICS_INFRML_ENFRC_ACTN_ID]
   , [PRMT_IDENT]
   , [DATA_HASH])
SELECT 
     null  --ICS_PRMT_IDENT_ID, 
   , null  --ICS_FRML_ENFRC_ACTN_ID, 
   , null  --ICS_INFRML_ENFRC_ACTN_ID, 
   , null  --PRMT_IDENT, PermitIdentifier
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_FRML_ENFRC_ACTN/ICS_PROGS_VIOL
INSERT INTO dbo.ICS_PROGS_VIOL (
     [ICS_PROGS_VIOL_ID]
   , [ICS_FRML_ENFRC_ACTN_ID]
   , [ICS_INFRML_ENFRC_ACTN_ID]
   , [PROGS_VIOL_CODE]
   , [DATA_HASH])
SELECT 
     null  --ICS_PROGS_VIOL_ID, 
   , null  --ICS_FRML_ENFRC_ACTN_ID, 
   , null  --ICS_INFRML_ENFRC_ACTN_ID, 
   , null  --PROGS_VIOL_CODE, ProgramsViolatedCode
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

END;
