﻿
/*************************************************************************************************
** ObjectName: ics_etl_ParameterLimits
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the ParameterLimitsSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/18/2025   Windsor      Created 
**
***************************************************************************************************/
CREATE OR ALTER PROCEDURE dbo.ics_etl_ParameterLimits

AS

BEGIN
---------------------------- 
-- ICS_PARAM_LMTS
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- /ICS_PARAM_LMTS/ICS_LMT/ICS_MN_LMT_APPLIES
DELETE
  FROM dbo.ICS_MN_LMT_APPLIES
 WHERE ICS_LMT_ID IN
          (SELECT ICS_LMT.ICS_LMT_ID
             FROM dbo.ICS_PARAM_LMTS
                  JOIN dbo.ICS_LMT ON ICS_LMT.ICS_PARAM_LMTS_id = ICS_PARAM_LMTS.ICS_PARAM_LMTS_id
          );

-- /ICS_PARAM_LMTS/ICS_LMT/ICS_NUM_COND
DELETE
  FROM dbo.ICS_NUM_COND
 WHERE ICS_LMT_ID IN
          (SELECT ICS_LMT.ICS_LMT_ID
             FROM dbo.ICS_PARAM_LMTS
                  JOIN dbo.ICS_LMT ON ICS_LMT.ICS_PARAM_LMTS_id = ICS_PARAM_LMTS.ICS_PARAM_LMTS_id
          );

-- /ICS_PARAM_LMTS/ICS_LMT
DELETE
  FROM dbo.ICS_LMT
 WHERE ICS_PARAM_LMTS_ID IN
          (SELECT ICS_PARAM_LMTS.ICS_PARAM_LMTS_ID
             FROM dbo.ICS_PARAM_LMTS
          );

-- /ICS_PARAM_LMTS
DELETE
  FROM dbo.ICS_PARAM_LMTS;


-- /ICS_PARAM_LMTS
INSERT INTO dbo.ICS_PARAM_LMTS (
     [ICS_PARAM_LMTS_ID]
   , [ICS_PAYLOAD_ID]
   , [SRC_SYSTM_IDENT]
   , [TRANSACTION_TYPE]
   , [TRANSACTION_TIMESTAMP]
   , [PRMT_IDENT]
   , [PRMT_FEATR_IDENT]
   , [LMT_SET_DESIGNATOR]
   , [PARAM_CODE]
   , [MON_SITE_DESC_CODE]
   , [LMT_SEASON_NUM]
   , [KEY_HASH]
   , [DATA_HASH])
SELECT 
     null  --ICS_PARAM_LMTS_ID, 
   , null  --ICS_PAYLOAD_ID, 
   , null  --SRC_SYSTM_IDENT, SourceSystemIdentifier
   , null  --TRANSACTION_TYPE, TransactionType
   , null  --TRANSACTION_TIMESTAMP, TransactionTimestamp
   , null  --PRMT_IDENT, PermitIdentifier
   , null  --PRMT_FEATR_IDENT, PermittedFeatureIdentifier
   , null  --LMT_SET_DESIGNATOR, LimitSetDesignator
   , null  --PARAM_CODE, ParameterCode
   , null  --MON_SITE_DESC_CODE, MonitoringSiteDescriptionCode
   , null  --LMT_SEASON_NUM, LimitSeasonNumber
   , null  --KEY_HASH, 
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_PARAM_LMTS/ICS_LMT
INSERT INTO dbo.ICS_LMT (
     [ICS_LMT_ID]
   , [ICS_PARAM_LMTS_ID]
   , [LMT_START_DATE]
   , [LMT_END_DATE]
   , [LMT_TYPE_CODE]
   , [SMPL_TYPE_TXT]
   , [FREQ_OF_ANALYSIS_CODE]
   , [ELIGIBLE_FOR_BURDEN_REDUCTION]
   , [LMT_STAY_TYPE_CODE]
   , [STAY_START_DATE]
   , [STAY_END_DATE]
   , [STAY_REASON_TXT]
   , [CALCULATE_VIOL_IND]
   , [ENFRC_ACTN_IDENT]
   , [FINAL_ORDER_IDENT]
   , [BASIS_OF_LMT]
   , [LMT_MOD_TYPE_CODE]
   , [LMT_MOD_EFFECTIVE_DATE]
   , [LMT_MOD_TYPE_STAY_REASON_TXT]
   , [LMTS_USR_DFND_FLD_1]
   , [LMTS_USR_DFND_FLD_2]
   , [LMTS_USR_DFND_FLD_3]
   , [CONCEN_NUM_COND_UNIT_MEAS_CODE]
   , [QTY_NUM_COND_UNIT_MEAS_CODE]
   , [DATA_HASH])
SELECT 
     null  --ICS_LMT_ID, 
   , null  --ICS_PARAM_LMTS_ID, 
   , null  --LMT_START_DATE, LimitStartDate
   , null  --LMT_END_DATE, LimitEndDate
   , null  --LMT_TYPE_CODE, LimitTypeCode
   , null  --SMPL_TYPE_TXT, SampleTypeText
   , null  --FREQ_OF_ANALYSIS_CODE, FrequencyOfAnalysisCode
   , null  --ELIGIBLE_FOR_BURDEN_REDUCTION, EligibleForBurdenReduction
   , null  --LMT_STAY_TYPE_CODE, LimitStayTypeCode
   , null  --STAY_START_DATE, StayStartDate
   , null  --STAY_END_DATE, StayEndDate
   , null  --STAY_REASON_TXT, StayReasonText
   , null  --CALCULATE_VIOL_IND, CalculateViolationsIndicator
   , null  --ENFRC_ACTN_IDENT, EnforcementActionIdentifier
   , null  --FINAL_ORDER_IDENT, FinalOrderIdentifier
   , null  --BASIS_OF_LMT, BasisOfLimit
   , null  --LMT_MOD_TYPE_CODE, LimitModificationTypeCode
   , null  --LMT_MOD_EFFECTIVE_DATE, LimitModificationEffectiveDate
   , null  --LMT_MOD_TYPE_STAY_REASON_TXT, LimitModificationTypeStayReasonText
   , null  --LMTS_USR_DFND_FLD_1, LimitsUserDefinedField1
   , null  --LMTS_USR_DFND_FLD_2, LimitsUserDefinedField2
   , null  --LMTS_USR_DFND_FLD_3, LimitsUserDefinedField3
   , null  --CONCEN_NUM_COND_UNIT_MEAS_CODE, ConcentrationNumericConditionUnitMeasureCode
   , null  --QTY_NUM_COND_UNIT_MEAS_CODE, QuantityNumericConditionUnitMeasureCode
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_PARAM_LMTS/ICS_LMT/ICS_MN_LMT_APPLIES
INSERT INTO dbo.ICS_MN_LMT_APPLIES (
     [ICS_MN_LMT_APPLIES_ID]
   , [ICS_LMTS_ID]
   , [ICS_LMT_ID]
   , [MN_LMT_APPLIES]
   , [DATA_HASH])
SELECT 
     null  --ICS_MN_LMT_APPLIES_ID, 
   , null  --ICS_LMTS_ID, 
   , null  --ICS_LMT_ID, 
   , null  --MN_LMT_APPLIES, MonthLimitApplies
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_PARAM_LMTS/ICS_LMT/ICS_NUM_COND
INSERT INTO dbo.ICS_NUM_COND (
     [ICS_NUM_COND_ID]
   , [ICS_LMTS_ID]
   , [ICS_LMT_ID]
   , [NUM_COND_TXT]
   , [NUM_COND_QTY]
   , [NUM_COND_STAT_BASE_CODE]
   , [NUM_COND_QUALIFIER]
   , [NUM_COND_OPT_MON_IND]
   , [NUM_COND_STAY_VALUE]
   , [DATA_HASH])
SELECT 
     null  --ICS_NUM_COND_ID, 
   , null  --ICS_LMTS_ID, 
   , null  --ICS_LMT_ID, 
   , null  --NUM_COND_TXT, NumericConditionText
   , null  --NUM_COND_QTY, NumericConditionQuantity
   , null  --NUM_COND_STAT_BASE_CODE, NumericConditionStatisticalBaseCode
   , null  --NUM_COND_QUALIFIER, NumericConditionQualifier
   , null  --NUM_COND_OPT_MON_IND, NumericConditionOptionalMonitoringIndicator
   , null  --NUM_COND_STAY_VALUE, NumericConditionStayValue
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

END;
