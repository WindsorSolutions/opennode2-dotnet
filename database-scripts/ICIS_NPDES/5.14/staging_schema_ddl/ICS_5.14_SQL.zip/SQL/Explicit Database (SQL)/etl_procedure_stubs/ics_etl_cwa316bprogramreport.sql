﻿
/*************************************************************************************************
** ObjectName: ics_etl_CWA316bProgramReport
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the CWA316bProgramReportSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/18/2025   Windsor      Created 
**
***************************************************************************************************/
CREATE OR ALTER PROCEDURE dbo.ics_etl_CWA316bProgramReport

AS

BEGIN
---------------------------- 
-- ICS_CWA_316B_PROG_REP
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- /ICS_CWA_316B_PROG_REP/ICS_CWA_316B_TAKE_INFO
DELETE
  FROM dbo.ICS_CWA_316B_TAKE_INFO
 WHERE ICS_CWA_316B_PROG_REP_ID IN
          (SELECT ICS_CWA_316B_PROG_REP.ICS_CWA_316B_PROG_REP_ID
             FROM dbo.ICS_CWA_316B_PROG_REP
          );

-- /ICS_CWA_316B_PROG_REP
DELETE
  FROM dbo.ICS_CWA_316B_PROG_REP;


-- /ICS_CWA_316B_PROG_REP
INSERT INTO dbo.ICS_CWA_316B_PROG_REP (
     [ICS_CWA_316B_PROG_REP_ID]
   , [ICS_PAYLOAD_ID]
   , [SRC_SYSTM_IDENT]
   , [TRANSACTION_TYPE]
   , [TRANSACTION_TIMESTAMP]
   , [PRMT_IDENT]
   , [PROG_REP_FORM_SET_ID]
   , [PROG_REP_FORM_ID]
   , [PROG_REP_RCVD_DATE]
   , [PROG_REP_START_DATE]
   , [PROG_REP_END_DATE]
   , [ELEC_SUBM_TYPE_CODE]
   , [PROG_REP_NPDES_DAT_GRP_NUM_CODE]
   , [CWA_316B_CRIT_HABITAT_PROTECTION_MSR]
   , [CWA_316B_OTHR_MON_INFO]
   , [KEY_HASH]
   , [DATA_HASH])
SELECT 
     null  --ICS_CWA_316B_PROG_REP_ID, 
   , null  --ICS_PAYLOAD_ID, 
   , null  --SRC_SYSTM_IDENT, SourceSystemIdentifier
   , null  --TRANSACTION_TYPE, TransactionType
   , null  --TRANSACTION_TIMESTAMP, TransactionTimestamp
   , null  --PRMT_IDENT, PermitIdentifier
   , null  --PROG_REP_FORM_SET_ID, ProgramReportFormSetID
   , null  --PROG_REP_FORM_ID, ProgramReportFormID
   , null  --PROG_REP_RCVD_DATE, ProgramReportReceivedDate
   , null  --PROG_REP_START_DATE, ProgramReportStartDate
   , null  --PROG_REP_END_DATE, ProgramReportEndDate
   , null  --ELEC_SUBM_TYPE_CODE, ElectronicSubmissionTypeCode
   , null  --PROG_REP_NPDES_DAT_GRP_NUM_CODE, ProgramReportNPDESDataGroupNumberCode
   , null  --CWA_316B_CRIT_HABITAT_PROTECTION_MSR, CWA316bCriticalHabitatProtectionMeasures
   , null  --CWA_316B_OTHR_MON_INFO, CWA316bOtherMonitoringInformation
   , null  --KEY_HASH, 
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CWA_316B_PROG_REP/ICS_CWA_316B_TAKE_INFO
INSERT INTO dbo.ICS_CWA_316B_TAKE_INFO (
     [ICS_CWA_316B_TAKE_INFO_ID]
   , [ICS_CWA_316B_PROG_REP_ID]
   , [CWA_316B_TAKE_IDENT]
   , [CWA_316B_SPECIES_NAME]
   , [CWA_316B_SPECIES_COMMON_NAME]
   , [CWA_316B_FEDR_STAT]
   , [CWA_316B_LIFESTAGE_CODE]
   , [CWA_316B_TAKE_METHOD_CODE]
   , [CWA_316B_TAKE_METHOD_OTHR_TXT]
   , [CWA_316B_TAKE_TYPE_CODE]
   , [CWA_316B_TAKE_TYPE_OTHR_TXT]
   , [CWA_316B_SPECIES_NUM]
   , [CWA_316B_SPECIES_NUM_IMPINGED_ENTRAINED]
   , [CWA_316B_SPECIES_NUM_IMPINGED_ENTRAINED_DATE]
   , [DATA_HASH])
SELECT 
     null  --ICS_CWA_316B_TAKE_INFO_ID, 
   , null  --ICS_CWA_316B_PROG_REP_ID, 
   , null  --CWA_316B_TAKE_IDENT, CWA316bTakeIdentifier
   , null  --CWA_316B_SPECIES_NAME, CWA316bSpeciesName
   , null  --CWA_316B_SPECIES_COMMON_NAME, CWA316bSpeciesCommonName
   , null  --CWA_316B_FEDR_STAT, CWA316bFederalStatus
   , null  --CWA_316B_LIFESTAGE_CODE, CWA316bLifestageCode
   , null  --CWA_316B_TAKE_METHOD_CODE, CWA316bTakeMethodCode
   , null  --CWA_316B_TAKE_METHOD_OTHR_TXT, CWA316bTakeMethodOtherText
   , null  --CWA_316B_TAKE_TYPE_CODE, CWA316bTakeTypeCode
   , null  --CWA_316B_TAKE_TYPE_OTHR_TXT, CWA316bTakeTypeOtherText
   , null  --CWA_316B_SPECIES_NUM, CWA316bSpeciesNumber
   , null  --CWA_316B_SPECIES_NUM_IMPINGED_ENTRAINED, CWA316bSpeciesNumberImpingedEntrained
   , null  --CWA_316B_SPECIES_NUM_IMPINGED_ENTRAINED_DATE, CWA316bSpeciesNumberImpingedEntrainedDate
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

END;
