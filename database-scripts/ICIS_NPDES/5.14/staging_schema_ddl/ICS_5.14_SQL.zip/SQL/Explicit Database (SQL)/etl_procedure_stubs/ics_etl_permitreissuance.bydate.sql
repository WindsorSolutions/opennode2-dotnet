﻿
/*************************************************************************************************
** ObjectName: ics_etl_PermitReissuance
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the PermitReissuanceSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/18/2025   Windsor      Created 
** 5/5/2026    Windsor      Default to Date based Reissuances
***************************************************************************************************/
CREATE OR ALTER PROCEDURE ics_flow_local.dbo.ics_etl_PermitReissuance

AS

BEGIN
---------------------------- 
-- ICS_PRMT_REISSU
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- /ICS_PRMT_REISSU
DELETE
  FROM ics_flow_local.dbo.ICS_PRMT_REISSU;


-- /ICS_PRMT_REISSU
INSERT INTO ics_flow_local.dbo.ICS_PRMT_REISSU (
     [ICS_PRMT_REISSU_ID]
   , [ICS_PAYLOAD_ID]
   , [SRC_SYSTM_IDENT]
   , [TRANSACTION_TYPE]
   , [TRANSACTION_TIMESTAMP]
   , [PRMT_IDENT]
   , [PRMT_ISSUE_DATE]
   , [PRMT_EFFECTIVE_DATE]
   , [PRMT_EXPR_DATE]
   , [KEY_HASH]
   , [DATA_HASH])
SELECT
  newid() AS ICS_PRMT_REISSU_ID,
  'PermitReissuance' AS PAYLOAD_ID,
  p_local.SRC_SYSTM_IDENT,  
  'C' AS TRANSACTION_TYPE,
  getdate() as TRANSACTION_TIMESTAMP,
  p_local.PRMT_IDENT,
  TRY_CONVERT(DATE, p_local.PRMT_ISSUE_DATE) as PRMT_ISSUE_DATE,
  TRY_CONVERT(DATE, p_local.PRMT_EFFECTIVE_DATE) as PRMT_EFFECTIVE_DATE,
  TRY_CONVERT(DATE, p_local.PRMT_EXPR_DATE) as PRMT_EXPR_DATE,
  null as KEY_HASH,
  null as DATA_HASH

 FROM
	(
	  select PRMT_IDENT, SRC_SYSTM_IDENT, PRMT_ISSUE_DATE, PRMT_EFFECTIVE_DATE, PRMT_EXPR_DATE
	  FROM ics_flow_local.dbo.ICS_BASIC_PRMT
	  UNION
	  select PRMT_IDENT, SRC_SYSTM_IDENT, PRMT_ISSUE_DATE, PRMT_EFFECTIVE_DATE, PRMT_EXPR_DATE
	  FROM ics_flow_local.dbo.ICS_GNRL_PRMT
	  UNION
	  select PRMT_IDENT, SRC_SYSTM_IDENT, PRMT_ISSUE_DATE, PRMT_EFFECTIVE_DATE, PRMT_EXPR_DATE
	  FROM ics_flow_local.dbo.ICS_MASTER_GNRL_PRMT  
	) p_local
join
	(
	  select PRMT_IDENT, SRC_SYSTM_IDENT, PRMT_ISSUE_DATE, PRMT_EFFECTIVE_DATE, PRMT_EXPR_DATE
	  FROM ics_flow_icis.dbo.ICS_BASIC_PRMT
	  UNION
	  select PRMT_IDENT, SRC_SYSTM_IDENT, PRMT_ISSUE_DATE, PRMT_EFFECTIVE_DATE, PRMT_EXPR_DATE
	  FROM ics_flow_icis.dbo.ICS_GNRL_PRMT
	  UNION
	  select PRMT_IDENT, SRC_SYSTM_IDENT, PRMT_ISSUE_DATE, PRMT_EFFECTIVE_DATE, PRMT_EXPR_DATE
	  FROM ics_flow_icis.dbo.ICS_MASTER_GNRL_PRMT 
	) p_icis
ON p_local.PRMT_IDENT = p_icis.PRMT_IDENT
WHERE 1=1
	AND( 
	   TRY_CONVERT(DATE, p_local.PRMT_EFFECTIVE_DATE) > TRY_CONVERT(DATE, p_icis.PRMT_EFFECTIVE_DATE) -- null will not be computed
	 --  OR (p_icis.PRMT_IDENT is not null AND p_icis.PRMT_EFFECTIVE_DATE is null)
	 )
	 -- Do not send a Re-issuance if we are also sending a termination for the permit
	AND p_local.PRMT_IDENT not in (SELECT PRMT_IDENT from ics_flow_local.dbo.ICS_PRMT_TERM)
	-- Do not send for permits where dates are incomplete (they should not be loaded anyway)
	and p_local.PRMT_EFFECTIVE_DATE is not null
	and p_local.PRMT_ISSUE_DATE is not null
	and p_local.PRMT_EXPR_DATE is not null
;

END;
GO
