﻿
/*************************************************************************************************
** ObjectName: ics_etl_SWConstructionPermit
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the SWConstructionPermitSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/18/2025   Windsor      Created 
**
***************************************************************************************************/
CREATE OR ALTER PROCEDURE dbo.ics_etl_SWConstructionPermit

AS

BEGIN
---------------------------- 
-- ICS_SW_CNST_PRMT
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- /ICS_SW_CNST_PRMT/ICS_ADDR/ICS_TELEPH
DELETE
  FROM dbo.ICS_TELEPH
 WHERE ICS_ADDR_ID IN
          (SELECT ICS_ADDR.ICS_ADDR_ID
             FROM dbo.ICS_SW_CNST_PRMT
                  JOIN dbo.ICS_ADDR ON ICS_ADDR.ICS_SW_CNST_PRMT_id = ICS_SW_CNST_PRMT.ICS_SW_CNST_PRMT_id
          );

-- /ICS_SW_CNST_PRMT/ICS_CNST_SITE_LIST/ICS_CNST_SITE
DELETE
  FROM dbo.ICS_CNST_SITE
 WHERE ICS_CNST_SITE_LIST_ID IN
          (SELECT ICS_CNST_SITE_LIST.ICS_CNST_SITE_LIST_ID
             FROM dbo.ICS_SW_CNST_PRMT
                  JOIN dbo.ICS_CNST_SITE_LIST ON ICS_CNST_SITE_LIST.ICS_SW_CNST_PRMT_id = ICS_SW_CNST_PRMT.ICS_SW_CNST_PRMT_id
          );

-- /ICS_SW_CNST_PRMT/ICS_CONTACT/ICS_TELEPH
DELETE
  FROM dbo.ICS_TELEPH
 WHERE ICS_CONTACT_ID IN
          (SELECT ICS_CONTACT.ICS_CONTACT_ID
             FROM dbo.ICS_SW_CNST_PRMT
                  JOIN dbo.ICS_CONTACT ON ICS_CONTACT.ICS_SW_CNST_PRMT_id = ICS_SW_CNST_PRMT.ICS_SW_CNST_PRMT_id
          );

-- /ICS_SW_CNST_PRMT/ICS_GPCF_NOTICE_OF_INTENT/ICS_SUBSECTOR_CODE_PLUS_DESC
DELETE
  FROM dbo.ICS_SUBSECTOR_CODE_PLUS_DESC
 WHERE ICS_GPCF_NOTICE_OF_INTENT_ID IN
          (SELECT ICS_GPCF_NOTICE_OF_INTENT.ICS_GPCF_NOTICE_OF_INTENT_ID
             FROM dbo.ICS_SW_CNST_PRMT
                  JOIN dbo.ICS_GPCF_NOTICE_OF_INTENT ON ICS_GPCF_NOTICE_OF_INTENT.ICS_SW_CNST_PRMT_id = ICS_SW_CNST_PRMT.ICS_SW_CNST_PRMT_id
          );

-- /ICS_SW_CNST_PRMT/ICS_ADDR
DELETE
  FROM dbo.ICS_ADDR
 WHERE ICS_SW_CNST_PRMT_ID IN
          (SELECT ICS_SW_CNST_PRMT.ICS_SW_CNST_PRMT_ID
             FROM dbo.ICS_SW_CNST_PRMT
          );

-- /ICS_SW_CNST_PRMT/ICS_CNST_SITE_LIST
DELETE
  FROM dbo.ICS_CNST_SITE_LIST
 WHERE ICS_SW_CNST_PRMT_ID IN
          (SELECT ICS_SW_CNST_PRMT.ICS_SW_CNST_PRMT_ID
             FROM dbo.ICS_SW_CNST_PRMT
          );

-- /ICS_SW_CNST_PRMT/ICS_CONTACT
DELETE
  FROM dbo.ICS_CONTACT
 WHERE ICS_SW_CNST_PRMT_ID IN
          (SELECT ICS_SW_CNST_PRMT.ICS_SW_CNST_PRMT_ID
             FROM dbo.ICS_SW_CNST_PRMT
          );

-- /ICS_SW_CNST_PRMT/ICS_GPCF_NOTICE_OF_INTENT
DELETE
  FROM dbo.ICS_GPCF_NOTICE_OF_INTENT
 WHERE ICS_SW_CNST_PRMT_ID IN
          (SELECT ICS_SW_CNST_PRMT.ICS_SW_CNST_PRMT_ID
             FROM dbo.ICS_SW_CNST_PRMT
          );

-- /ICS_SW_CNST_PRMT/ICS_PROPOSED_CNST_SW_BM_PS
DELETE
  FROM dbo.ICS_PROPOSED_CNST_SW_BM_PS
 WHERE ICS_SW_CNST_PRMT_ID IN
          (SELECT ICS_SW_CNST_PRMT.ICS_SW_CNST_PRMT_ID
             FROM dbo.ICS_SW_CNST_PRMT
          );

-- /ICS_SW_CNST_PRMT/ICS_PROPOSED_POST_CNST_SW_BM_PS
DELETE
  FROM dbo.ICS_PROPOSED_POST_CNST_SW_BM_PS
 WHERE ICS_SW_CNST_PRMT_ID IN
          (SELECT ICS_SW_CNST_PRMT.ICS_SW_CNST_PRMT_ID
             FROM dbo.ICS_SW_CNST_PRMT
          );

-- /ICS_SW_CNST_PRMT/ICS_TRTMNT_CHEMS_LIST
DELETE
  FROM dbo.ICS_TRTMNT_CHEMS_LIST
 WHERE ICS_SW_CNST_PRMT_ID IN
          (SELECT ICS_SW_CNST_PRMT.ICS_SW_CNST_PRMT_ID
             FROM dbo.ICS_SW_CNST_PRMT
          );

-- /ICS_SW_CNST_PRMT
DELETE
  FROM dbo.ICS_SW_CNST_PRMT;


-- /ICS_SW_CNST_PRMT
INSERT INTO dbo.ICS_SW_CNST_PRMT (
     [ICS_SW_CNST_PRMT_ID]
   , [ICS_PAYLOAD_ID]
   , [SRC_SYSTM_IDENT]
   , [TRANSACTION_TYPE]
   , [TRANSACTION_TIMESTAMP]
   , [PRMT_IDENT]
   , [ST_WTR_BODY_NAME]
   , [RCVG_MS_4_NAME]
   , [IMPAIRED_WTR_IND]
   , [HIST_PROP_IND]
   , [HIST_PROP_CRIT_MET_CODE]
   , [SPECIES_CRIT_HABITAT_IND]
   , [SPECIES_CRIT_MET_CODE]
   , [INDST_ACTY_SIZE]
   , [PROJ_TYPE_CODE]
   , [EST_START_DATE]
   , [EST_COMPLETE_DATE]
   , [EST_AREA_DISTURBED_ACRES_NUM]
   , [PROJ_PLAN_SIZE_CODE]
   , [STRCT_DEMOED_IND]
   , [STRCT_DEMOED_FLOOR_SPACE_IND]
   , [PREDEV_LAND_USE_IND]
   , [ERTH_DISTRB_ACTIVITIES_IND]
   , [ERTH_DISTRB_EMRGCY_IND]
   , [PREVIOUS_SW_DSCH_IND]
   , [OTHR_PRMT_IDENT]
   , [CGP_IND]
   , [MS_4_DSCH_IND]
   , [WTR_PROX_IND]
   , [ANTIDEG_IND]
   , [TRTMNT_CHEMS_IND]
   , [CATIONIC_CHEMS_IND]
   , [CATIONIC_CHEMS_AUTH_IND]
   , [SWPPP_PREP_IND]
   , [CNST_SITE_TTL_AREA]
   , [POST_CNST_TTL_IMPERVIOUS_AREA]
   , [SOIL_FILL_MATERIAL_DESC_TXT]
   , [RUNOFF_COEFFICIENT_POST_CNST]
   , [SUBSURFACE_ERTH_DISTURBANCE_IND]
   , [PRIOR_SURVEYS_EVALS_IND]
   , [SUBSURFACE_ERTH_DISTURBANCE_CONTROL_IND]
   , [NOT_TERM_DATE]
   , [NOT_SIGN_DATE]
   , [NOT_POSTMARK_DATE]
   , [NOT_RCVD_DATE]
   , [LEW_AUTH_DATE]
   , [KEY_HASH]
   , [DATA_HASH])
SELECT 
     null  --ICS_SW_CNST_PRMT_ID, 
   , null  --ICS_PAYLOAD_ID, 
   , null  --SRC_SYSTM_IDENT, SourceSystemIdentifier
   , null  --TRANSACTION_TYPE, TransactionType
   , null  --TRANSACTION_TIMESTAMP, TransactionTimestamp
   , null  --PRMT_IDENT, PermitIdentifier
   , null  --ST_WTR_BODY_NAME, StateWaterBodyName
   , null  --RCVG_MS_4_NAME, ReceivingMS4Name
   , null  --IMPAIRED_WTR_IND, ImpairedWaterIndicator
   , null  --HIST_PROP_IND, HistoricPropertyIndicator
   , null  --HIST_PROP_CRIT_MET_CODE, HistoricPropertyCriterionMetCode
   , null  --SPECIES_CRIT_HABITAT_IND, SpeciesCriticalHabitatIndicator
   , null  --SPECIES_CRIT_MET_CODE, SpeciesCriterionMetCode
   , null  --INDST_ACTY_SIZE, IndustrialActivitySize
   , null  --PROJ_TYPE_CODE, ProjectTypeCode
   , null  --EST_START_DATE, EstimatedStartDate
   , null  --EST_COMPLETE_DATE, EstimatedCompleteDate
   , null  --EST_AREA_DISTURBED_ACRES_NUM, EstimatedAreaDisturbedAcresNumber
   , null  --PROJ_PLAN_SIZE_CODE, ProjectPlanSizeCode
   , null  --STRCT_DEMOED_IND, StructureDemolishedIndicator
   , null  --STRCT_DEMOED_FLOOR_SPACE_IND, StructureDemolishedFloorSpaceIndicator
   , null  --PREDEV_LAND_USE_IND, PredevelopmentLandUseIndicator
   , null  --ERTH_DISTRB_ACTIVITIES_IND, EarthDisturbingActivitiesIndicator
   , null  --ERTH_DISTRB_EMRGCY_IND, EarthDisturbingEmergencyIndicator
   , null  --PREVIOUS_SW_DSCH_IND, PreviousStormwaterDischargesIndicator
   , null  --OTHR_PRMT_IDENT, OtherPermitIdentifier
   , null  --CGP_IND, CGPIndicator
   , null  --MS_4_DSCH_IND, MS4DischargeIndicator
   , null  --WTR_PROX_IND, WaterProximityIndicator
   , null  --ANTIDEG_IND, AntidegradationIndicator
   , null  --TRTMNT_CHEMS_IND, TreatmentChemicalsIndicator
   , null  --CATIONIC_CHEMS_IND, CationicChemicalsIndicator
   , null  --CATIONIC_CHEMS_AUTH_IND, CationicChemicalsAuthorizationIndicator
   , null  --SWPPP_PREP_IND, SWPPPPreparedIndicator
   , null  --CNST_SITE_TTL_AREA, ConstructionSiteTotalArea
   , null  --POST_CNST_TTL_IMPERVIOUS_AREA, PostConstructionTotalImperviousArea
   , null  --SOIL_FILL_MATERIAL_DESC_TXT, SoilFillMaterialDescriptionText
   , null  --RUNOFF_COEFFICIENT_POST_CNST, RunoffCoefficientPostConstruction
   , null  --SUBSURFACE_ERTH_DISTURBANCE_IND, SubsurfaceEarthDisturbanceIndicator
   , null  --PRIOR_SURVEYS_EVALS_IND, PriorSurveysEvaluationsIndicator
   , null  --SUBSURFACE_ERTH_DISTURBANCE_CONTROL_IND, SubsurfaceEarthDisturbanceControlIndicator
   , null  --NOT_TERM_DATE, NOTTerminationDate
   , null  --NOT_SIGN_DATE, NOTSignatureDate
   , null  --NOT_POSTMARK_DATE, NOTPostmarkDate
   , null  --NOT_RCVD_DATE, NOTReceivedDate
   , null  --LEW_AUTH_DATE, LEWAuthorizationDate
   , null  --KEY_HASH, 
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_SW_CNST_PRMT/ICS_ADDR
INSERT INTO dbo.ICS_ADDR (
     [ICS_ADDR_ID]
   , [ICS_FAC_ID]
   , [ICS_BASIC_PRMT_ID]
   , [ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID]
   , [ICS_CAFO_PRMT_ID]
   , [ICS_GNRL_PRMT_ID]
   , [ICS_PRMT_FEATR_ID]
   , [ICS_SW_CNST_PRMT_ID]
   , [ICS_SW_INDST_PRMT_ID]
   , [ICS_UNPRMT_FAC_ID]
   , [AFFIL_TYPE_TXT]
   , [ORG_FRML_NAME]
   , [ORG_DUNS_NUM]
   , [MAILING_ADDR_TXT]
   , [SUPPL_ADDR_TXT]
   , [MAILING_ADDR_CITY_NAME]
   , [MAILING_ADDR_ST_CODE]
   , [MAILING_ADDR_ZIP_CODE]
   , [COUNTY_NAME]
   , [MAILING_ADDR_COUNTRY_CODE]
   , [DIVISION_NAME]
   , [LOC_PROVINCE]
   , [ELEC_ADDR_TXT]
   , [START_DATE_OF_ADDR_ASSC]
   , [END_DATE_OF_ADDR_ASSC]
   , [DATA_HASH])
SELECT 
     null  --ICS_ADDR_ID, 
   , null  --ICS_FAC_ID, 
   , null  --ICS_BASIC_PRMT_ID, 
   , null  --ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID, 
   , null  --ICS_CAFO_PRMT_ID, 
   , null  --ICS_GNRL_PRMT_ID, 
   , null  --ICS_PRMT_FEATR_ID, 
   , null  --ICS_SW_CNST_PRMT_ID, 
   , null  --ICS_SW_INDST_PRMT_ID, 
   , null  --ICS_UNPRMT_FAC_ID, 
   , null  --AFFIL_TYPE_TXT, AffiliationTypeText
   , null  --ORG_FRML_NAME, OrganizationFormalName
   , null  --ORG_DUNS_NUM, OrganizationDUNSNumber
   , null  --MAILING_ADDR_TXT, MailingAddressText
   , null  --SUPPL_ADDR_TXT, SupplementalAddressText
   , null  --MAILING_ADDR_CITY_NAME, MailingAddressCityName
   , null  --MAILING_ADDR_ST_CODE, MailingAddressStateCode
   , null  --MAILING_ADDR_ZIP_CODE, MailingAddressZipCode
   , null  --COUNTY_NAME, CountyName
   , null  --MAILING_ADDR_COUNTRY_CODE, MailingAddressCountryCode
   , null  --DIVISION_NAME, DivisionName
   , null  --LOC_PROVINCE, LocationProvince
   , null  --ELEC_ADDR_TXT, ElectronicAddressText
   , null  --START_DATE_OF_ADDR_ASSC, StartDateOfAddressAssociation
   , null  --END_DATE_OF_ADDR_ASSC, EndDateOfAddressAssociation
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_SW_CNST_PRMT/ICS_ADDR/ICS_TELEPH
INSERT INTO dbo.ICS_TELEPH (
     [ICS_TELEPH_ID]
   , [ICS_CONTACT_ID]
   , [ICS_ADDR_ID]
   , [ICS_EFFLU_TRADE_PRTNER_ADDR_ID]
   , [TELEPH_NUM_TYPE_CODE]
   , [TELEPH_NUM]
   , [TELEPH_EXT_NUM]
   , [DATA_HASH])
SELECT 
     null  --ICS_TELEPH_ID, 
   , null  --ICS_CONTACT_ID, 
   , null  --ICS_ADDR_ID, 
   , null  --ICS_EFFLU_TRADE_PRTNER_ADDR_ID, 
   , null  --TELEPH_NUM_TYPE_CODE, TelephoneNumberTypeCode
   , null  --TELEPH_NUM, TelephoneNumber
   , null  --TELEPH_EXT_NUM, TelephoneExtensionNumber
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_SW_CNST_PRMT/ICS_CNST_SITE_LIST
INSERT INTO dbo.ICS_CNST_SITE_LIST (
     [ICS_CNST_SITE_LIST_ID]
   , [ICS_SW_CNST_PRMT_ID]
   , [CNST_SITE_OTHR_TXT]
   , [DATA_HASH])
SELECT 
     null  --ICS_CNST_SITE_LIST_ID, 
   , null  --ICS_SW_CNST_PRMT_ID, 
   , null  --CNST_SITE_OTHR_TXT, ConstructionSiteOtherText
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_SW_CNST_PRMT/ICS_CNST_SITE_LIST/ICS_CNST_SITE
INSERT INTO dbo.ICS_CNST_SITE (
     [ICS_CNST_SITE_ID]
   , [ICS_CNST_SITE_LIST_ID]
   , [CNST_SITE_CODE]
   , [DATA_HASH])
SELECT 
     null  --ICS_CNST_SITE_ID, 
   , null  --ICS_CNST_SITE_LIST_ID, 
   , null  --CNST_SITE_CODE, ConstructionSiteCode
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_SW_CNST_PRMT/ICS_CONTACT
INSERT INTO dbo.ICS_CONTACT (
     [ICS_CONTACT_ID]
   , [ICS_FAC_ID]
   , [ICS_BASIC_PRMT_ID]
   , [ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID]
   , [ICS_CAFO_PRMT_ID]
   , [ICS_CMPL_MON_ID]
   , [ICS_GNRL_PRMT_ID]
   , [ICS_MASTER_GNRL_PRMT_ID]
   , [ICS_PRMT_FEATR_ID]
   , [ICS_PRETR_PRMT_ID]
   , [ICS_SW_CNST_PRMT_ID]
   , [ICS_SW_INDST_PRMT_ID]
   , [ICS_UNPRMT_FAC_ID]
   , [AFFIL_TYPE_TXT]
   , [FIRST_NAME]
   , [MIDDLE_NAME]
   , [LAST_NAME]
   , [INDVL_TITLE_TXT]
   , [ORG_FRML_NAME]
   , [ST_CODE]
   , [RGN_CODE]
   , [ELEC_ADDR_TXT]
   , [START_DATE_OF_CONTACT_ASSC]
   , [END_DATE_OF_CONTACT_ASSC]
   , [DATA_HASH])
SELECT 
     null  --ICS_CONTACT_ID, 
   , null  --ICS_FAC_ID, 
   , null  --ICS_BASIC_PRMT_ID, 
   , null  --ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID, 
   , null  --ICS_CAFO_PRMT_ID, 
   , null  --ICS_CMPL_MON_ID, 
   , null  --ICS_GNRL_PRMT_ID, 
   , null  --ICS_MASTER_GNRL_PRMT_ID, 
   , null  --ICS_PRMT_FEATR_ID, 
   , null  --ICS_PRETR_PRMT_ID, 
   , null  --ICS_SW_CNST_PRMT_ID, 
   , null  --ICS_SW_INDST_PRMT_ID, 
   , null  --ICS_UNPRMT_FAC_ID, 
   , null  --AFFIL_TYPE_TXT, AffiliationTypeText
   , null  --FIRST_NAME, FirstName
   , null  --MIDDLE_NAME, MiddleName
   , null  --LAST_NAME, LastName
   , null  --INDVL_TITLE_TXT, IndividualTitleText
   , null  --ORG_FRML_NAME, OrganizationFormalName
   , null  --ST_CODE, StateCode
   , null  --RGN_CODE, RegionCode
   , null  --ELEC_ADDR_TXT, ElectronicAddressText
   , null  --START_DATE_OF_CONTACT_ASSC, StartDateOfContactAssociation
   , null  --END_DATE_OF_CONTACT_ASSC, EndDateOfContactAssociation
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_SW_CNST_PRMT/ICS_CONTACT/ICS_TELEPH
INSERT INTO dbo.ICS_TELEPH (
     [ICS_TELEPH_ID]
   , [ICS_CONTACT_ID]
   , [ICS_ADDR_ID]
   , [ICS_EFFLU_TRADE_PRTNER_ADDR_ID]
   , [TELEPH_NUM_TYPE_CODE]
   , [TELEPH_NUM]
   , [TELEPH_EXT_NUM]
   , [DATA_HASH])
SELECT 
     null  --ICS_TELEPH_ID, 
   , null  --ICS_CONTACT_ID, 
   , null  --ICS_ADDR_ID, 
   , null  --ICS_EFFLU_TRADE_PRTNER_ADDR_ID, 
   , null  --TELEPH_NUM_TYPE_CODE, TelephoneNumberTypeCode
   , null  --TELEPH_NUM, TelephoneNumber
   , null  --TELEPH_EXT_NUM, TelephoneExtensionNumber
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_SW_CNST_PRMT/ICS_GPCF_NOTICE_OF_INTENT
INSERT INTO dbo.ICS_GPCF_NOTICE_OF_INTENT (
     [ICS_GPCF_NOTICE_OF_INTENT_ID]
   , [ICS_SW_CNST_PRMT_ID]
   , [ICS_SW_INDST_PRMT_ID]
   , [NOI_SIGN_DATE]
   , [NOI_POSTMARK_DATE]
   , [NOI_RCVD_DATE]
   , [COMPLETE_NOI_RCVD_DATE]
   , [FEDR_CERCLA_DSCH_IND]
   , [DATA_HASH])
SELECT 
     null  --ICS_GPCF_NOTICE_OF_INTENT_ID, 
   , null  --ICS_SW_CNST_PRMT_ID, 
   , null  --ICS_SW_INDST_PRMT_ID, 
   , null  --NOI_SIGN_DATE, NOISignatureDate
   , null  --NOI_POSTMARK_DATE, NOIPostmarkDate
   , null  --NOI_RCVD_DATE, NOIReceivedDate
   , null  --COMPLETE_NOI_RCVD_DATE, CompleteNOIReceivedDate
   , null  --FEDR_CERCLA_DSCH_IND, FederalCERCLADischargeIndicator
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_SW_CNST_PRMT/ICS_GPCF_NOTICE_OF_INTENT/ICS_SUBSECTOR_CODE_PLUS_DESC
INSERT INTO dbo.ICS_SUBSECTOR_CODE_PLUS_DESC (
     [ICS_SUBSECTOR_CODE_PLUS_DESC_ID]
   , [ICS_GPCF_NOTICE_OF_INTENT_ID]
   , [SUBSECTOR_CODE_PLUS_DESC]
   , [DATA_HASH])
SELECT 
     null  --ICS_SUBSECTOR_CODE_PLUS_DESC_ID, 
   , null  --ICS_GPCF_NOTICE_OF_INTENT_ID, 
   , null  --SUBSECTOR_CODE_PLUS_DESC, SubsectorCodePlusDescription
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_SW_CNST_PRMT/ICS_PROPOSED_CNST_SW_BM_PS
INSERT INTO dbo.ICS_PROPOSED_CNST_SW_BM_PS (
     [ICS_PROPOSED_CNST_SW_BM_PS_ID]
   , [ICS_SW_CNST_PRMT_ID]
   , [PROPOSED_CNST_SW_BMP_CODE]
   , [PROPOSED_CNST_SW_BMP_OTHR_TXT]
   , [DATA_HASH])
SELECT 
     null  --ICS_PROPOSED_CNST_SW_BM_PS_ID, 
   , null  --ICS_SW_CNST_PRMT_ID, 
   , null  --PROPOSED_CNST_SW_BMP_CODE, ProposedConstructionStormwaterBMPCode
   , null  --PROPOSED_CNST_SW_BMP_OTHR_TXT, ProposedConstructionStormwaterBMPOtherText
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_SW_CNST_PRMT/ICS_PROPOSED_POST_CNST_SW_BM_PS
INSERT INTO dbo.ICS_PROPOSED_POST_CNST_SW_BM_PS (
     [ICS_PROPOSED_POST_CNST_SW_BM_PS_ID]
   , [ICS_SW_CNST_PRMT_ID]
   , [PROPOSED_POST_CNST_SW_BMP_CODE]
   , [PROPOSED_POST_CNST_SW_BMP_OTHR_TXT]
   , [DATA_HASH])
SELECT 
     null  --ICS_PROPOSED_POST_CNST_SW_BM_PS_ID, 
   , null  --ICS_SW_CNST_PRMT_ID, 
   , null  --PROPOSED_POST_CNST_SW_BMP_CODE, ProposedPostConstructionStormwaterBMPCode
   , null  --PROPOSED_POST_CNST_SW_BMP_OTHR_TXT, ProposedPostConstructionStormwaterBMPOtherText
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_SW_CNST_PRMT/ICS_TRTMNT_CHEMS_LIST
INSERT INTO dbo.ICS_TRTMNT_CHEMS_LIST (
     [ICS_TRTMNT_CHEMS_LIST_ID]
   , [ICS_SW_CNST_PRMT_ID]
   , [TRTMNT_CHEMS_LIST]
   , [DATA_HASH])
SELECT 
     null  --ICS_TRTMNT_CHEMS_LIST_ID, 
   , null  --ICS_SW_CNST_PRMT_ID, 
   , null  --TRTMNT_CHEMS_LIST, TreatmentChemicalsList
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

END;
