﻿
/*************************************************************************************************
** ObjectName: ics_etl_ComplianceMonitoringLinkage
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the ComplianceMonitoringLinkageSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/18/2025   Windsor      Created 
**
***************************************************************************************************/
CREATE OR ALTER PROCEDURE dbo.ics_etl_ComplianceMonitoringLinkage

AS

BEGIN
---------------------------- 
-- ICS_CMPL_MON_LNK
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- /ICS_CMPL_MON_LNK/ICS_LNK_CMPL_MON
DELETE
  FROM dbo.ICS_LNK_CMPL_MON
 WHERE ICS_CMPL_MON_LNK_ID IN
          (SELECT ICS_CMPL_MON_LNK.ICS_CMPL_MON_LNK_ID
             FROM dbo.ICS_CMPL_MON_LNK
          );

-- /ICS_CMPL_MON_LNK/ICS_LNK_ENFRC_ACTN
DELETE
  FROM dbo.ICS_LNK_ENFRC_ACTN
 WHERE ICS_CMPL_MON_LNK_ID IN
          (SELECT ICS_CMPL_MON_LNK.ICS_CMPL_MON_LNK_ID
             FROM dbo.ICS_CMPL_MON_LNK
          );

-- /ICS_CMPL_MON_LNK/ICS_LNK_SNGL_EVT
DELETE
  FROM dbo.ICS_LNK_SNGL_EVT
 WHERE ICS_CMPL_MON_LNK_ID IN
          (SELECT ICS_CMPL_MON_LNK.ICS_CMPL_MON_LNK_ID
             FROM dbo.ICS_CMPL_MON_LNK
          );

-- /ICS_CMPL_MON_LNK
DELETE
  FROM dbo.ICS_CMPL_MON_LNK;


-- /ICS_CMPL_MON_LNK
INSERT INTO dbo.ICS_CMPL_MON_LNK (
     [ICS_CMPL_MON_LNK_ID]
   , [ICS_PAYLOAD_ID]
   , [SRC_SYSTM_IDENT]
   , [TRANSACTION_TYPE]
   , [TRANSACTION_TIMESTAMP]
   , [CMPL_MON_IDENT]
   , [KEY_HASH]
   , [DATA_HASH])
SELECT 
     null  --ICS_CMPL_MON_LNK_ID, 
   , null  --ICS_PAYLOAD_ID, 
   , null  --SRC_SYSTM_IDENT, SourceSystemIdentifier
   , null  --TRANSACTION_TYPE, TransactionType
   , null  --TRANSACTION_TIMESTAMP, TransactionTimestamp
   , null  --CMPL_MON_IDENT, ComplianceMonitoringIdentifier
   , null  --KEY_HASH, 
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON_LNK/ICS_LNK_CMPL_MON
INSERT INTO dbo.ICS_LNK_CMPL_MON (
     [ICS_LNK_CMPL_MON_ID]
   , [ICS_CMPL_MON_LNK_ID]
   , [CMPL_MON_IDENT]
   , [DATA_HASH])
SELECT 
     null  --ICS_LNK_CMPL_MON_ID, 
   , null  --ICS_CMPL_MON_LNK_ID, 
   , null  --CMPL_MON_IDENT, ComplianceMonitoringIdentifier
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON_LNK/ICS_LNK_ENFRC_ACTN
INSERT INTO dbo.ICS_LNK_ENFRC_ACTN (
     [ICS_LNK_ENFRC_ACTN_ID]
   , [ICS_CMPL_MON_LNK_ID]
   , [ENFRC_ACTN_IDENT]
   , [DATA_HASH])
SELECT 
     null  --ICS_LNK_ENFRC_ACTN_ID, 
   , null  --ICS_CMPL_MON_LNK_ID, 
   , null  --ENFRC_ACTN_IDENT, EnforcementActionIdentifier
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_MON_LNK/ICS_LNK_SNGL_EVT
INSERT INTO dbo.ICS_LNK_SNGL_EVT (
     [ICS_LNK_SNGL_EVT_ID]
   , [ICS_CMPL_MON_LNK_ID]
   , [PRMT_IDENT]
   , [SNGL_EVT_VIOL_CODE]
   , [SNGL_EVT_VIOL_DATE]
   , [DATA_HASH])
SELECT 
     null  --ICS_LNK_SNGL_EVT_ID, 
   , null  --ICS_CMPL_MON_LNK_ID, 
   , null  --PRMT_IDENT, PermitIdentifier
   , null  --SNGL_EVT_VIOL_CODE, SingleEventViolationCode
   , null  --SNGL_EVT_VIOL_DATE, SingleEventViolationDate
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

END;
