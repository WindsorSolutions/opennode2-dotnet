﻿
/*************************************************************************************************
** ObjectName: ics_etl_MasterGeneralPermit
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the MasterGeneralPermitSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/18/2025   Windsor      Created 
**
***************************************************************************************************/
CREATE OR ALTER PROCEDURE dbo.ics_etl_MasterGeneralPermit

AS

BEGIN
---------------------------- 
-- ICS_MASTER_GNRL_PRMT
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- /ICS_MASTER_GNRL_PRMT/ICS_CONTACT/ICS_TELEPH
DELETE
  FROM dbo.ICS_TELEPH
 WHERE ICS_CONTACT_ID IN
          (SELECT ICS_CONTACT.ICS_CONTACT_ID
             FROM dbo.ICS_MASTER_GNRL_PRMT
                  JOIN dbo.ICS_CONTACT ON ICS_CONTACT.ICS_MASTER_GNRL_PRMT_id = ICS_MASTER_GNRL_PRMT.ICS_MASTER_GNRL_PRMT_id
          );

-- /ICS_MASTER_GNRL_PRMT/ICS_ASSC_PRMT
DELETE
  FROM dbo.ICS_ASSC_PRMT
 WHERE ICS_MASTER_GNRL_PRMT_ID IN
          (SELECT ICS_MASTER_GNRL_PRMT.ICS_MASTER_GNRL_PRMT_ID
             FROM dbo.ICS_MASTER_GNRL_PRMT
          );

-- /ICS_MASTER_GNRL_PRMT/ICS_CONTACT
DELETE
  FROM dbo.ICS_CONTACT
 WHERE ICS_MASTER_GNRL_PRMT_ID IN
          (SELECT ICS_MASTER_GNRL_PRMT.ICS_MASTER_GNRL_PRMT_ID
             FROM dbo.ICS_MASTER_GNRL_PRMT
          );

-- /ICS_MASTER_GNRL_PRMT/ICS_NAICS_CODE
DELETE
  FROM dbo.ICS_NAICS_CODE
 WHERE ICS_MASTER_GNRL_PRMT_ID IN
          (SELECT ICS_MASTER_GNRL_PRMT.ICS_MASTER_GNRL_PRMT_ID
             FROM dbo.ICS_MASTER_GNRL_PRMT
          );

-- /ICS_MASTER_GNRL_PRMT/ICS_OTHR_PRMTS
DELETE
  FROM dbo.ICS_OTHR_PRMTS
 WHERE ICS_MASTER_GNRL_PRMT_ID IN
          (SELECT ICS_MASTER_GNRL_PRMT.ICS_MASTER_GNRL_PRMT_ID
             FROM dbo.ICS_MASTER_GNRL_PRMT
          );

-- /ICS_MASTER_GNRL_PRMT/ICS_PRMT_COMP_TYPE
DELETE
  FROM dbo.ICS_PRMT_COMP_TYPE
 WHERE ICS_MASTER_GNRL_PRMT_ID IN
          (SELECT ICS_MASTER_GNRL_PRMT.ICS_MASTER_GNRL_PRMT_ID
             FROM dbo.ICS_MASTER_GNRL_PRMT
          );

-- /ICS_MASTER_GNRL_PRMT/ICS_RESIDUAL_DESGN_DTRMN
DELETE
  FROM dbo.ICS_RESIDUAL_DESGN_DTRMN
 WHERE ICS_MASTER_GNRL_PRMT_ID IN
          (SELECT ICS_MASTER_GNRL_PRMT.ICS_MASTER_GNRL_PRMT_ID
             FROM dbo.ICS_MASTER_GNRL_PRMT
          );

-- /ICS_MASTER_GNRL_PRMT/ICS_SIC_CODE
DELETE
  FROM dbo.ICS_SIC_CODE
 WHERE ICS_MASTER_GNRL_PRMT_ID IN
          (SELECT ICS_MASTER_GNRL_PRMT.ICS_MASTER_GNRL_PRMT_ID
             FROM dbo.ICS_MASTER_GNRL_PRMT
          );

-- /ICS_MASTER_GNRL_PRMT
DELETE
  FROM dbo.ICS_MASTER_GNRL_PRMT;


-- /ICS_MASTER_GNRL_PRMT
INSERT INTO dbo.ICS_MASTER_GNRL_PRMT (
     [ICS_MASTER_GNRL_PRMT_ID]
   , [ICS_PAYLOAD_ID]
   , [SRC_SYSTM_IDENT]
   , [TRANSACTION_TYPE]
   , [TRANSACTION_TIMESTAMP]
   , [PRMT_IDENT]
   , [PRMT_TYPE_CODE]
   , [AGNCY_TYPE_CODE]
   , [PRMT_ISSUE_DATE]
   , [PRMT_EFFECTIVE_DATE]
   , [PRMT_EXPR_DATE]
   , [REISSU_PRIO_PRMT_IND]
   , [BACKLOG_REASON_TXT]
   , [PRMT_ISSUING_ORG_TYPE_NAME]
   , [PRMT_APPEALED_IND]
   , [PRMT_USR_DFND_DAT_ELM_1_TXT]
   , [PRMT_USR_DFND_DAT_ELM_2_TXT]
   , [PRMT_USR_DFND_DAT_ELM_3_TXT]
   , [PRMT_USR_DFND_DAT_ELM_4_TXT]
   , [PRMT_USR_DFND_DAT_ELM_5_TXT]
   , [PRMT_CMNTS_TXT]
   , [GNRL_PRMT_INDST_CATG]
   , [PRMT_NAME]
   , [KEY_HASH]
   , [DATA_HASH])
SELECT 
     null  --ICS_MASTER_GNRL_PRMT_ID, 
   , null  --ICS_PAYLOAD_ID, 
   , null  --SRC_SYSTM_IDENT, SourceSystemIdentifier
   , null  --TRANSACTION_TYPE, TransactionType
   , null  --TRANSACTION_TIMESTAMP, TransactionTimestamp
   , null  --PRMT_IDENT, PermitIdentifier
   , null  --PRMT_TYPE_CODE, PermitTypeCode
   , null  --AGNCY_TYPE_CODE, AgencyTypeCode
   , null  --PRMT_ISSUE_DATE, PermitIssueDate
   , null  --PRMT_EFFECTIVE_DATE, PermitEffectiveDate
   , null  --PRMT_EXPR_DATE, PermitExpirationDate
   , null  --REISSU_PRIO_PRMT_IND, ReissuancePriorityPermitIndicator
   , null  --BACKLOG_REASON_TXT, BacklogReasonText
   , null  --PRMT_ISSUING_ORG_TYPE_NAME, PermitIssuingOrganizationTypeName
   , null  --PRMT_APPEALED_IND, PermitAppealedIndicator
   , null  --PRMT_USR_DFND_DAT_ELM_1_TXT, PermitUserDefinedDataElement1Text
   , null  --PRMT_USR_DFND_DAT_ELM_2_TXT, PermitUserDefinedDataElement2Text
   , null  --PRMT_USR_DFND_DAT_ELM_3_TXT, PermitUserDefinedDataElement3Text
   , null  --PRMT_USR_DFND_DAT_ELM_4_TXT, PermitUserDefinedDataElement4Text
   , null  --PRMT_USR_DFND_DAT_ELM_5_TXT, PermitUserDefinedDataElement5Text
   , null  --PRMT_CMNTS_TXT, PermitCommentsText
   , null  --GNRL_PRMT_INDST_CATG, GeneralPermitIndustrialCategory
   , null  --PRMT_NAME, PermitName
   , null  --KEY_HASH, 
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_MASTER_GNRL_PRMT/ICS_ASSC_PRMT
INSERT INTO dbo.ICS_ASSC_PRMT (
     [ICS_ASSC_PRMT_ID]
   , [ICS_BASIC_PRMT_ID]
   , [ICS_GNRL_PRMT_ID]
   , [ICS_MASTER_GNRL_PRMT_ID]
   , [ASSC_PRMT_IDENT]
   , [ASSC_PRMT_REASON_CODE]
   , [DATA_HASH])
SELECT 
     null  --ICS_ASSC_PRMT_ID, 
   , null  --ICS_BASIC_PRMT_ID, 
   , null  --ICS_GNRL_PRMT_ID, 
   , null  --ICS_MASTER_GNRL_PRMT_ID, 
   , null  --ASSC_PRMT_IDENT, AssociatedPermitIdentifier
   , null  --ASSC_PRMT_REASON_CODE, AssociatedPermitReasonCode
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_MASTER_GNRL_PRMT/ICS_CONTACT
INSERT INTO dbo.ICS_CONTACT (
     [ICS_CONTACT_ID]
   , [ICS_FAC_ID]
   , [ICS_BASIC_PRMT_ID]
   , [ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID]
   , [ICS_CAFO_PRMT_ID]
   , [ICS_CMPL_MON_ID]
   , [ICS_GNRL_PRMT_ID]
   , [ICS_MASTER_GNRL_PRMT_ID]
   , [ICS_PRMT_FEATR_ID]
   , [ICS_PRETR_PRMT_ID]
   , [ICS_SW_CNST_PRMT_ID]
   , [ICS_SW_INDST_PRMT_ID]
   , [ICS_UNPRMT_FAC_ID]
   , [AFFIL_TYPE_TXT]
   , [FIRST_NAME]
   , [MIDDLE_NAME]
   , [LAST_NAME]
   , [INDVL_TITLE_TXT]
   , [ORG_FRML_NAME]
   , [ST_CODE]
   , [RGN_CODE]
   , [ELEC_ADDR_TXT]
   , [START_DATE_OF_CONTACT_ASSC]
   , [END_DATE_OF_CONTACT_ASSC]
   , [DATA_HASH])
SELECT 
     null  --ICS_CONTACT_ID, 
   , null  --ICS_FAC_ID, 
   , null  --ICS_BASIC_PRMT_ID, 
   , null  --ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID, 
   , null  --ICS_CAFO_PRMT_ID, 
   , null  --ICS_CMPL_MON_ID, 
   , null  --ICS_GNRL_PRMT_ID, 
   , null  --ICS_MASTER_GNRL_PRMT_ID, 
   , null  --ICS_PRMT_FEATR_ID, 
   , null  --ICS_PRETR_PRMT_ID, 
   , null  --ICS_SW_CNST_PRMT_ID, 
   , null  --ICS_SW_INDST_PRMT_ID, 
   , null  --ICS_UNPRMT_FAC_ID, 
   , null  --AFFIL_TYPE_TXT, AffiliationTypeText
   , null  --FIRST_NAME, FirstName
   , null  --MIDDLE_NAME, MiddleName
   , null  --LAST_NAME, LastName
   , null  --INDVL_TITLE_TXT, IndividualTitleText
   , null  --ORG_FRML_NAME, OrganizationFormalName
   , null  --ST_CODE, StateCode
   , null  --RGN_CODE, RegionCode
   , null  --ELEC_ADDR_TXT, ElectronicAddressText
   , null  --START_DATE_OF_CONTACT_ASSC, StartDateOfContactAssociation
   , null  --END_DATE_OF_CONTACT_ASSC, EndDateOfContactAssociation
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_MASTER_GNRL_PRMT/ICS_CONTACT/ICS_TELEPH
INSERT INTO dbo.ICS_TELEPH (
     [ICS_TELEPH_ID]
   , [ICS_CONTACT_ID]
   , [ICS_ADDR_ID]
   , [ICS_EFFLU_TRADE_PRTNER_ADDR_ID]
   , [TELEPH_NUM_TYPE_CODE]
   , [TELEPH_NUM]
   , [TELEPH_EXT_NUM]
   , [DATA_HASH])
SELECT 
     null  --ICS_TELEPH_ID, 
   , null  --ICS_CONTACT_ID, 
   , null  --ICS_ADDR_ID, 
   , null  --ICS_EFFLU_TRADE_PRTNER_ADDR_ID, 
   , null  --TELEPH_NUM_TYPE_CODE, TelephoneNumberTypeCode
   , null  --TELEPH_NUM, TelephoneNumber
   , null  --TELEPH_EXT_NUM, TelephoneExtensionNumber
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_MASTER_GNRL_PRMT/ICS_NAICS_CODE
INSERT INTO dbo.ICS_NAICS_CODE (
     [ICS_NAICS_CODE_ID]
   , [ICS_BASIC_PRMT_ID]
   , [ICS_FAC_ID]
   , [ICS_GNRL_PRMT_ID]
   , [ICS_MASTER_GNRL_PRMT_ID]
   , [ICS_UNPRMT_FAC_ID]
   , [NAICS_CODE]
   , [NAICS_PRIMARY_IND_CODE]
   , [DATA_HASH])
SELECT 
     null  --ICS_NAICS_CODE_ID, 
   , null  --ICS_BASIC_PRMT_ID, 
   , null  --ICS_FAC_ID, 
   , null  --ICS_GNRL_PRMT_ID, 
   , null  --ICS_MASTER_GNRL_PRMT_ID, 
   , null  --ICS_UNPRMT_FAC_ID, 
   , null  --NAICS_CODE, NAICSCode
   , null  --NAICS_PRIMARY_IND_CODE, NAICSPrimaryIndicatorCode
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_MASTER_GNRL_PRMT/ICS_OTHR_PRMTS
INSERT INTO dbo.ICS_OTHR_PRMTS (
     [ICS_OTHR_PRMTS_ID]
   , [ICS_BASIC_PRMT_ID]
   , [ICS_GNRL_PRMT_ID]
   , [ICS_MASTER_GNRL_PRMT_ID]
   , [OTHR_PRMT_IDENT]
   , [OTHR_ORG_NAME]
   , [OTHR_PRMT_IDENT_CNTXT_NAME]
   , [DATA_HASH])
SELECT 
     null  --ICS_OTHR_PRMTS_ID, 
   , null  --ICS_BASIC_PRMT_ID, 
   , null  --ICS_GNRL_PRMT_ID, 
   , null  --ICS_MASTER_GNRL_PRMT_ID, 
   , null  --OTHR_PRMT_IDENT, OtherPermitIdentifier
   , null  --OTHR_ORG_NAME, OtherOrganizationName
   , null  --OTHR_PRMT_IDENT_CNTXT_NAME, OtherPermitIdentifierContextName
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_MASTER_GNRL_PRMT/ICS_PRMT_COMP_TYPE
INSERT INTO dbo.ICS_PRMT_COMP_TYPE (
     [ICS_PRMT_COMP_TYPE_ID]
   , [ICS_MASTER_GNRL_PRMT_ID]
   , [ICS_UNPRMT_FAC_ID]
   , [PRMT_COMP_TYPE_CODE]
   , [DATA_HASH])
SELECT 
     null  --ICS_PRMT_COMP_TYPE_ID, 
   , null  --ICS_MASTER_GNRL_PRMT_ID, 
   , null  --ICS_UNPRMT_FAC_ID, 
   , null  --PRMT_COMP_TYPE_CODE, PermitComponentTypeCode
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_MASTER_GNRL_PRMT/ICS_RESIDUAL_DESGN_DTRMN
INSERT INTO dbo.ICS_RESIDUAL_DESGN_DTRMN (
     [ICS_RESIDUAL_DESGN_DTRMN_ID]
   , [ICS_BASIC_PRMT_ID]
   , [ICS_GNRL_PRMT_ID]
   , [ICS_MASTER_GNRL_PRMT_ID]
   , [RESIDUAL_DESGN_DTRMN_CODE]
   , [RESIDUAL_DESGN_DTRMN_OTHR_TXT]
   , [DATA_HASH])
SELECT 
     null  --ICS_RESIDUAL_DESGN_DTRMN_ID, 
   , null  --ICS_BASIC_PRMT_ID, 
   , null  --ICS_GNRL_PRMT_ID, 
   , null  --ICS_MASTER_GNRL_PRMT_ID, 
   , null  --RESIDUAL_DESGN_DTRMN_CODE, ResidualDesignationDeterminationCode
   , null  --RESIDUAL_DESGN_DTRMN_OTHR_TXT, ResidualDesignationDeterminationOtherText
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_MASTER_GNRL_PRMT/ICS_SIC_CODE
INSERT INTO dbo.ICS_SIC_CODE (
     [ICS_SIC_CODE_ID]
   , [ICS_BASIC_PRMT_ID]
   , [ICS_FAC_ID]
   , [ICS_GNRL_PRMT_ID]
   , [ICS_MASTER_GNRL_PRMT_ID]
   , [ICS_UNPRMT_FAC_ID]
   , [SIC_CODE]
   , [SIC_PRIMARY_IND_CODE]
   , [DATA_HASH])
SELECT 
     null  --ICS_SIC_CODE_ID, 
   , null  --ICS_BASIC_PRMT_ID, 
   , null  --ICS_FAC_ID, 
   , null  --ICS_GNRL_PRMT_ID, 
   , null  --ICS_MASTER_GNRL_PRMT_ID, 
   , null  --ICS_UNPRMT_FAC_ID, 
   , null  --SIC_CODE, SICCode
   , null  --SIC_PRIMARY_IND_CODE, SICPrimaryIndicatorCode
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

END;
