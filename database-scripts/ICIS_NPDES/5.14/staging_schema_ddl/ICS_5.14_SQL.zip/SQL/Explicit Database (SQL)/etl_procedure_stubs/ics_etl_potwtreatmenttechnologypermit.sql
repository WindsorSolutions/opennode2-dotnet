﻿
/*************************************************************************************************
** ObjectName: ics_etl_POTWTreatmentTechnologyPermit
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the POTWTreatmentTechnologyPermitSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/18/2025   Windsor      Created 
**
***************************************************************************************************/
CREATE OR ALTER PROCEDURE dbo.ics_etl_POTWTreatmentTechnologyPermit

AS

BEGIN
---------------------------- 
-- ICS_POTW_TRTMNT_TECHNOLOGY_PRMT
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- /ICS_POTW_TRTMNT_TECHNOLOGY_PRMT
DELETE
  FROM dbo.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT;


-- /ICS_POTW_TRTMNT_TECHNOLOGY_PRMT
INSERT INTO dbo.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT (
     [ICS_POTW_TRTMNT_TECHNOLOGY_PRMT_ID]
   , [ICS_PAYLOAD_ID]
   , [SRC_SYSTM_IDENT]
   , [TRANSACTION_TYPE]
   , [TRANSACTION_TIMESTAMP]
   , [PRMT_IDENT]
   , [POTW_TRTMNT_LEVEL_CODE]
   , [POTW_TRTMNT_LEVEL_OTHR_TXT]
   , [POTW_WW_DISINFECTION_TECHNOLOGY_CODE]
   , [POTW_WW_DISINFECTION_TECHNOLOGY_OTHR_TXT]
   , [POTW_WW_TRTMNT_TECHNOLOGY_UNIT_OPERATION_CODE]
   , [POTW_WW_TRTMNT_TECHNOLOGY_UNIT_OPERATION_OTHR_TXT]
   , [KEY_HASH]
   , [DATA_HASH])
SELECT 
     null  --ICS_POTW_TRTMNT_TECHNOLOGY_PRMT_ID, 
   , null  --ICS_PAYLOAD_ID, 
   , null  --SRC_SYSTM_IDENT, SourceSystemIdentifier
   , null  --TRANSACTION_TYPE, TransactionType
   , null  --TRANSACTION_TIMESTAMP, TransactionTimestamp
   , null  --PRMT_IDENT, PermitIdentifier
   , null  --POTW_TRTMNT_LEVEL_CODE, POTWTreatmentLevelCode
   , null  --POTW_TRTMNT_LEVEL_OTHR_TXT, POTWTreatmentLevelOtherText
   , null  --POTW_WW_DISINFECTION_TECHNOLOGY_CODE, POTWWastewaterDisinfectionTechnologyCode
   , null  --POTW_WW_DISINFECTION_TECHNOLOGY_OTHR_TXT, POTWWastewaterDisinfectionTechnologyOtherText
   , null  --POTW_WW_TRTMNT_TECHNOLOGY_UNIT_OPERATION_CODE, POTWWastewaterTreatmentTechnologyUnitOperationCode
   , null  --POTW_WW_TRTMNT_TECHNOLOGY_UNIT_OPERATION_OTHR_TXT, POTWWastewaterTreatmentTechnologyUnitOperationOtherText
   , null  --KEY_HASH, 
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

END;
