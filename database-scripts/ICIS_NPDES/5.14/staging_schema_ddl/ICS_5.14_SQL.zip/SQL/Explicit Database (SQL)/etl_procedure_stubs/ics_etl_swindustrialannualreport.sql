﻿
/*************************************************************************************************
** ObjectName: ics_etl_SWIndustrialAnnualReport
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the SWIndustrialAnnualReportSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/18/2025   Windsor      Created 
**
***************************************************************************************************/
CREATE OR ALTER PROCEDURE dbo.ics_etl_SWIndustrialAnnualReport

AS

BEGIN
---------------------------- 
-- ICS_SW_INDST_ANNUL_REP
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- /ICS_SW_INDST_ANNUL_REP
DELETE
  FROM dbo.ICS_SW_INDST_ANNUL_REP;


-- /ICS_SW_INDST_ANNUL_REP
INSERT INTO dbo.ICS_SW_INDST_ANNUL_REP (
     [ICS_SW_INDST_ANNUL_REP_ID]
   , [ICS_PAYLOAD_ID]
   , [SRC_SYSTM_IDENT]
   , [TRANSACTION_TYPE]
   , [TRANSACTION_TIMESTAMP]
   , [PRMT_IDENT]
   , [INDST_SW_ANNUL_REP_RCVD_DATE]
   , [FAC_INSP_SUMM_TXT]
   , [VISUAL_ASSESSMENT_SUMM_TXT]
   , [NO_FURTHER_REDUCTION_SUMM_TXT]
   , [CORR_ACTN_SUMM_TXT]
   , [KEY_HASH]
   , [DATA_HASH])
SELECT 
     null  --ICS_SW_INDST_ANNUL_REP_ID, 
   , null  --ICS_PAYLOAD_ID, 
   , null  --SRC_SYSTM_IDENT, SourceSystemIdentifier
   , null  --TRANSACTION_TYPE, TransactionType
   , null  --TRANSACTION_TIMESTAMP, TransactionTimestamp
   , null  --PRMT_IDENT, PermitIdentifier
   , null  --INDST_SW_ANNUL_REP_RCVD_DATE, IndustrialStormWaterAnnualReportReceivedDate
   , null  --FAC_INSP_SUMM_TXT, FacilityInspectionSummaryText
   , null  --VISUAL_ASSESSMENT_SUMM_TXT, VisualAssessmentSummaryText
   , null  --NO_FURTHER_REDUCTION_SUMM_TXT, NoFurtherReductionSummaryText
   , null  --CORR_ACTN_SUMM_TXT, CorrectiveActionSummaryText
   , null  --KEY_HASH, 
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

END;
