﻿
/*************************************************************************************************
** ObjectName: ics_etl_ComplianceSchedule
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the ComplianceScheduleSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/18/2025   Windsor      Created 
**
***************************************************************************************************/
CREATE OR ALTER PROCEDURE dbo.ics_etl_ComplianceSchedule

AS

BEGIN
---------------------------- 
-- ICS_CMPL_SCHD
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- /ICS_CMPL_SCHD/ICS_CMPL_SCHD_EVT
DELETE
  FROM dbo.ICS_CMPL_SCHD_EVT
 WHERE ICS_CMPL_SCHD_ID IN
          (SELECT ICS_CMPL_SCHD.ICS_CMPL_SCHD_ID
             FROM dbo.ICS_CMPL_SCHD
          );

-- /ICS_CMPL_SCHD
DELETE
  FROM dbo.ICS_CMPL_SCHD;


-- /ICS_CMPL_SCHD
INSERT INTO dbo.ICS_CMPL_SCHD (
     [ICS_CMPL_SCHD_ID]
   , [ICS_PAYLOAD_ID]
   , [SRC_SYSTM_IDENT]
   , [TRANSACTION_TYPE]
   , [TRANSACTION_TIMESTAMP]
   , [ENFRC_ACTN_IDENT]
   , [FINAL_ORDER_IDENT]
   , [PRMT_IDENT]
   , [CMPL_SCHD_NUM]
   , [CMPL_SCHD_CMNTS]
   , [SCHD_DESC_CODE]
   , [KEY_HASH]
   , [DATA_HASH])
SELECT 
     null  --ICS_CMPL_SCHD_ID, 
   , null  --ICS_PAYLOAD_ID, 
   , null  --SRC_SYSTM_IDENT, SourceSystemIdentifier
   , null  --TRANSACTION_TYPE, TransactionType
   , null  --TRANSACTION_TIMESTAMP, TransactionTimestamp
   , null  --ENFRC_ACTN_IDENT, EnforcementActionIdentifier
   , null  --FINAL_ORDER_IDENT, FinalOrderIdentifier
   , null  --PRMT_IDENT, PermitIdentifier
   , null  --CMPL_SCHD_NUM, ComplianceScheduleNumber
   , null  --CMPL_SCHD_CMNTS, ComplianceScheduleComments
   , null  --SCHD_DESC_CODE, ScheduleDescriptorCode
   , null  --KEY_HASH, 
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CMPL_SCHD/ICS_CMPL_SCHD_EVT
INSERT INTO dbo.ICS_CMPL_SCHD_EVT (
     [ICS_CMPL_SCHD_EVT_ID]
   , [ICS_CMPL_SCHD_ID]
   , [SCHD_EVT_CODE]
   , [SCHD_DATE]
   , [SCHD_REP_RCVD_DATE]
   , [SCHD_ACTUL_DATE]
   , [SCHD_PROJ_DATE]
   , [SCHD_USR_DFND_DAT_ELM_1]
   , [SCHD_USR_DFND_DAT_ELM_2]
   , [SCHD_EVT_CMNTS]
   , [CMPL_SCHD_PNLTY_AMT]
   , [DATA_HASH])
SELECT 
     null  --ICS_CMPL_SCHD_EVT_ID, 
   , null  --ICS_CMPL_SCHD_ID, 
   , null  --SCHD_EVT_CODE, ScheduleEventCode
   , null  --SCHD_DATE, ScheduleDate
   , null  --SCHD_REP_RCVD_DATE, ScheduleReportReceivedDate
   , null  --SCHD_ACTUL_DATE, ScheduleActualDate
   , null  --SCHD_PROJ_DATE, ScheduleProjectedDate
   , null  --SCHD_USR_DFND_DAT_ELM_1, ScheduleUserDefinedDataElement1
   , null  --SCHD_USR_DFND_DAT_ELM_2, ScheduleUserDefinedDataElement2
   , null  --SCHD_EVT_CMNTS, ScheduleEventComments
   , null  --CMPL_SCHD_PNLTY_AMT, ComplianceSchedulePenaltyAmount
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

END;
