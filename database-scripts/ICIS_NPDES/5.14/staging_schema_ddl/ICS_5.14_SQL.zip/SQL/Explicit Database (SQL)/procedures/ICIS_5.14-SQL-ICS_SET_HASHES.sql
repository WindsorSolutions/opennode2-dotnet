IF NOT EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND OBJECT_ID = OBJECT_ID('dbo.ICS_SET_HASHES'))
  EXEC('CREATE PROCEDURE [dbo].[ICS_SET_HASHES] AS BEGIN SET NOCOUNT ON; END')
GO

/*
Copyright (c) 2012, The Environmental Council of the States (ECOS)
All rights reserved.
 
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
 
 * Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
 * Neither the name of the ECOS nor the names of its contributors may
   be used to endorse or promote products derived from this software
   without specific prior written permission.
 
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/

/******************************************************************************************************************************
** ObjectName: dbo.ICS_SET_HASHES
**
** Author: Windsor Solutions, Inc.
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure will detect data changes made within the ICIS 5.8 schema and then sets the transaction type
**               flags so the data can be bundled and submitted to an exchange partner.
**
** Inputs:  -- NA --  
**
**
** Revision History:      
** ----------------------------------------------------------------------------------------------------------------------------
**  Date         Analyst     Description
** ----------------------------------------------------------------------------------------------------------------------------
** 06/12/2017    Windsor     Baselined from v5.6 procedure. 
** 08/05/2019    TConrad/CRT ENFLOW-9: Add the key_hash to the where clause of each sub-select to improve perf of roll-up data 
** 04/06/2025    CTyler      Update to v5.14
** 04/15/2026    CTyler   Fix dbo schema refernce in cursor, change UNION ALL to UNION ALL
** 04/15/2026    CTyler      Refactored: eliminated nested cursor loops (key_hash + payload_type_process).
**                           Each payload type now processed set-based using STRING_AGG + GROUP BY key_hash.
**                           Removed ICS_KEY_HASH working table dependency.
**                           NOTE: Hash values produced by this version differ from the prior rolling-hash method.
**                           A one-time full resubmission will occur on first execution after deployment.
** 04/26/2026    CTyler      use varchar_max for string_agg
** 05/15/2026    CTyler    Cleanup dev commments, add missing schema

******************************************************************************************************************************/
ALTER PROCEDURE dbo.ICS_SET_HASHES AS

SET NOCOUNT ON;


BEGIN


 
-- -=-=-=-=-=-=- START COPY TO INDICATED SECTION IN ICS_SET_HASHES -=-=-=-=-=-=-=-=-=
 /*************************************************/  
  /* START - Set all KEY_HASH and DATA_HASH fields */
  /*************************************************/  

UPDATE dbo.ics_addr
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  affil_type_txt
	+ org_frml_name
	+ ISNULL(org_duns_num,'')
	+ mailing_addr_txt
	+ ISNULL(suppl_addr_txt,'')
	+ mailing_addr_city_name
	+ mailing_addr_st_code
	+ mailing_addr_zip_code
	+ ISNULL(county_name,'')
	+ ISNULL(mailing_addr_country_code,'')
	+ ISNULL(division_name,'')
	+ ISNULL(loc_province,'')
	+ ISNULL(elec_addr_txt,'')
	+ ISNULL(CONVERT(varchar(50), start_date_of_addr_assc),'')
	+ ISNULL(CONVERT(varchar(50), end_date_of_addr_assc),'')
);
UPDATE dbo.ics_anlytcl_method
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  anlytcl_method_type_code
	+ ISNULL(anlytcl_method_othr_type_txt,'')
);
UPDATE dbo.ics_anml_type
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  anml_type_code
	+ ISNULL(othr_anml_type_name,'')
	+ ISNULL(CONVERT(varchar(50), ttl_num_each_lvstck),'')
	+ ISNULL(CONVERT(varchar(50), open_confinemnt_cnt),'')
	+ ISNULL(CONVERT(varchar(50), housd_undr_roof_confinemnt_cnt),'')
	+ ISNULL(liquid_mnur_handling_systm,'')
);
UPDATE dbo.ics_assc_prmt
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(assc_prmt_ident,'')
	+ assc_prmt_reason_code
);
UPDATE dbo.ics_basic_prmt
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', dbo.ics_basic_prmt.prmt_ident),
      data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ ISNULL(prmt_type_code,'')
	+ ISNULL(agncy_type_code,'')
	+ ISNULL(prmt_stat_code,'')
	+ ISNULL(CONVERT(varchar(50), prmt_issue_date),'')
	+ ISNULL(CONVERT(varchar(50), prmt_effective_date),'')
	+ ISNULL(CONVERT(varchar(50), prmt_expr_date),'')
	+ ISNULL(reissu_prio_prmt_ind,'')
	+ ISNULL(backlog_reason_txt,'')
	+ ISNULL(prmt_issuing_org_type_name,'')
	+ ISNULL(prmt_appealed_ind,'')
	+ ISNULL(prmt_usr_dfnd_dat_elm_1_txt,'')
	+ ISNULL(prmt_usr_dfnd_dat_elm_2_txt,'')
	+ ISNULL(prmt_usr_dfnd_dat_elm_3_txt,'')
	+ ISNULL(prmt_usr_dfnd_dat_elm_4_txt,'')
	+ ISNULL(prmt_usr_dfnd_dat_elm_5_txt,'')
	+ ISNULL(prmt_cmnts_txt,'')
	+ ISNULL(CONVERT(varchar(50), major_minor_rating_code),'')
	+ ISNULL(CONVERT(varchar(50), ttl_appl_dsgn_flow_num),'')
	+ ISNULL(CONVERT(varchar(50), ttl_appl_aver_flow_num),'')
	+ ISNULL(CONVERT(varchar(50), appl_rcvd_date),'')
	+ ISNULL(CONVERT(varchar(50), prmt_appl_cmpl_date),'')
	+ ISNULL(new_src_ind,'')
	+ ISNULL(prmt_st_wtr_body_code,'')
	+ ISNULL(prmt_st_wtr_body_name,'')
	+ ISNULL(fedr_grant_ind,'')
	+ ISNULL(dmr_cognznt_ofcl,'')
	+ ISNULL(dmr_cognznt_ofcl_teleph_num,'')
	+ ISNULL(sig_iu_ind,'')
	+ ISNULL(rcvg_prmt_ident,'')
	+ ISNULL(indst_usr_type_code,'')
	+ ISNULL(elec_rep_waiver_type_code,'')
	+ ISNULL(CONVERT(varchar(50), elec_rep_waiver_effective_date),'')
	+ ISNULL(CONVERT(varchar(50), elec_rep_waiver_expr_date),'')
	+ ISNULL(major_minor_stat_ind,'')
	+ ISNULL(CONVERT(varchar(50), major_minor_stat_start_date),'')
	+ ISNULL(dmr_non_rcpt_stat_ind,'')
	+ ISNULL(CONVERT(varchar(50), dmr_non_rcpt_stat_start_date),'')
);
UPDATE dbo.ics_bs_annul_prog_rep
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', prmt_ident + PROG_REP_FORM_SET_ID + CONVERT(varchar(50), PROG_REP_FORM_ID) ),
      data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	   ISNULL(prmt_ident,'')
	+ ISNULL(CONVERT(varchar(50), prog_rep_rcvd_date),'')
	+ ISNULL(CONVERT(varchar(50), prog_rep_start_date),'')
	+ ISNULL(CONVERT(varchar(50), prog_rep_end_date),'')
	+ ISNULL(elec_subm_type_code,'')
	+ ISNULL(prog_rep_npdes_dat_grp_num_code,'')
	+ ISNULL(bs_fac_type_othr_txt,'')
	+ ISNULL(CONVERT(varchar(50), bs_fac_ttl_vol_amt),'')
	+ ISNULL(bs_fac_trtmnt_othr_txt,'')
	+ ISNULL(bs_annul_prog_rep_cmnt_txt,'')
);
UPDATE dbo.ics_bs_fac_trtmnt
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  bs_fac_trtmnt_code
);
UPDATE dbo.ics_bs_fac_type
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  bs_fac_type_code
);
UPDATE dbo.ics_bs_incin_emissions_control_type
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  bs_emissions_control_catg
	+ bs_emissions_control_technology_code
	+ ISNULL(bs_emissions_control_othr_txt,'')
);
UPDATE dbo.ics_bs_incineration
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  bs_incin_ident
	+ ISNULL(bs_incin_type_code,'')
	+ ISNULL(bs_incin_othr_txt,'')
	+ ISNULL(CONVERT(varchar(50), bs_incin_last_sig_change_date),'')
	+ ISNULL(bs_incin_new_polut_lmts_ind,'')
);
UPDATE dbo.ics_bs_mgmt_practice
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  ssu_ident
	+ ISNULL(bs_mgmt_practice_code,'')
	+ ISNULL(bs_mgmt_practice_sub_catg_code,'')
	+ ISNULL(bs_mgmt_practice_sub_catg_txt,'')
	+ ISNULL(bs_operator_type_code,'')
	+ ISNULL(bs_cntnr_type_code,'')
	+ ISNULL(CONVERT(varchar(50), ssuid_vol_amt),'')
	+ ISNULL(pathogen_class_type_code,'')
	+ ISNULL(polut_loading_rates_exceedance_ind,'')
	+ ISNULL(bs_mgmt_practice_viol_type_code,'')
	+ ISNULL(bs_mgmt_practice_viol_txt,'')
	+ ISNULL(bs_off_site_fac_prmt_ident,'')
	+ ISNULL(surf_dspl_without_liner_ind,'')
	+ ISNULL(surf_dspl_site_spec_lmt_ind,'')
	+ ISNULL(surf_dspl_min_boundary_distance_code,'')
);
UPDATE dbo.ics_bs_off_site_hndlr_applier_prepr
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(CONVERT(varchar(50), bs_off_site_hndlr_applier_vol_amt),'')
);
UPDATE dbo.ics_bs_prmt
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', dbo.ics_bs_prmt.prmt_ident),
      data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ ISNULL(bs_fac_type_othr_txt,'')
	+ ISNULL(CONVERT(varchar(50), bs_fac_ttl_vol_amt),'')
	+ ISNULL(bs_fac_trtmnt_othr_txt,'')
);
UPDATE dbo.ics_bs_sewage_sldg_param
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  CONVERT(varchar(50), bs_sewage_sldg_param_code)
	+ ISNULL(CONVERT(varchar(50), bs_sewage_sldg_param_lmt),'')
	+ ISNULL(param_value,'')
	+ ISNULL(value_qualifier,'')
	+ ISNULL(no_dat_ind_code,'')
	+ ISNULL(pass_fail_ind_code,'')
	+ ISNULL(pathogen_reduction_type_code,'')
	+ ISNULL(CONVERT(varchar(50), bs_smpl_start_date),'')
	+ ISNULL(CONVERT(varchar(50), bs_smpl_end_date),'')
	+ ISNULL(bs_smpl_mn,'')
);
UPDATE dbo.ics_bypass_trtmnt_plant_equipment
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  bypass_trtmnt_plant_equipment_code
);
UPDATE dbo.ics_cafo_annul_prog_rep
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', prmt_ident + PROG_REP_FORM_SET_ID + CONVERT(varchar(50), PROG_REP_FORM_ID) ),
      data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ ISNULL(CONVERT(varchar(50), prog_rep_rcvd_date),'')
	+ ISNULL(CONVERT(varchar(50), prog_rep_start_date),'')
	+ ISNULL(CONVERT(varchar(50), prog_rep_end_date),'')
	+ ISNULL(elec_subm_type_code,'')
	+ ISNULL(prog_rep_npdes_dat_grp_num_code,'')
	+ ISNULL(CONVERT(varchar(50), nutr_mgmt_plan_acreage_num),'')
	+ ISNULL(CONVERT(varchar(50), actul_land_appl_acreage_num),'')
	+ ISNULL(nmp_cert_plnr_ind,'')
);
UPDATE dbo.ics_cafo_insp
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(cafo_class_code,'')
	+ ISNULL(is_anml_fac_type_cafo_ind,'')
	+ ISNULL(CONVERT(varchar(50), cafo_desgn_date),'')
	+ ISNULL(cafo_desgn_reason_txt,'')
	+ ISNULL(dsch_drng_year_prod_area_ind,'')
	+ ISNULL(dsch_drng_year_land_appl_area_ind,'')
	+ ISNULL(cafo_dsch_drng_year_txt,'')
	+ ISNULL(CONVERT(varchar(50), num_acres_contrb_drain),'')
	+ ISNULL(CONVERT(varchar(50), appl_meas_avail_land_num),'')
	+ ISNULL(CONVERT(varchar(50), solid_mnur_lttr_gnrtd_amt),'')
	+ ISNULL(CONVERT(varchar(50), liquid_mnur_ww_gnrtd_amt),'')
	+ ISNULL(CONVERT(varchar(50), solid_mnur_lttr_trans_amt),'')
	+ ISNULL(CONVERT(varchar(50), liquid_mnur_ww_trans_amt),'')
	+ ISNULL(nmp_dvlpd_cert_plnr_aprvd_ind,'')
	+ ISNULL(CONVERT(varchar(50), nmp_dvlpd_date),'')
	+ ISNULL(CONVERT(varchar(50), nmp_last_updated_date),'')
	+ ISNULL(envr_mgmt_systm_ind,'')
	+ ISNULL(CONVERT(varchar(50), ems_dvlpd_date),'')
	+ ISNULL(CONVERT(varchar(50), ems_last_updated_date),'')
	+ ISNULL(CONVERT(varchar(50), lvstck_max_cpcty_num),'')
	+ ISNULL(CONVERT(varchar(50), lvstck_cpcty_dtrmn_bs_upon_num),'')
	+ ISNULL(CONVERT(varchar(50), auth_lvstck_cpcty_num),'')
);
UPDATE dbo.ics_cafo_insp_viol_type
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  cafo_insp_viol_type_code
);
UPDATE dbo.ics_cafo_land_appl_fld_info
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  cafo_land_appl_fld_ident
	+ ISNULL(CONVERT(varchar(50), cafo_land_appl_fld_acreage),'')
	+ ISNULL(cafomlpw_max_amt_method,'')
	+ cafo_land_appl_fld_crop_ident
	+ ISNULL(cafo_land_appl_fld_crop_code,'')
	+ ISNULL(CONVERT(varchar(50), cafo_land_appl_fld_crop_yield),'')
	+ ISNULL(cafo_land_appl_fld_crop_yield_unit,'')
	+ ISNULL(cafo_land_appl_fld_crop_seeded,'')
	+ cafo_soil_mon_meas_form
	+ ISNULL(CONVERT(varchar(50), cafo_soil_mon_meas_value),'')
	+ ISNULL(cafo_soil_mon_meas_value_unit,'')
	+ ISNULL(cafo_soil_mon_anlytcl_method,'')
	+ ISNULL(CONVERT(varchar(50), cafo_soil_mon_smpl_depth_inches),'')
	+ ISNULL(CONVERT(varchar(50), cafo_soil_mon_smpl_date),'')
	+ cafo_suppl_fertilizer_meas_form
	+ ISNULL(CONVERT(varchar(50), cafo_suppl_fertilizer_meas_value),'')
	+ ISNULL(cafo_suppl_fertilizer_meas_value_unit,'')
);
UPDATE dbo.ics_cafo_prmt
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', dbo.ics_cafo_prmt.prmt_ident),
      data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ ISNULL(cafo_class_code,'')
	+ ISNULL(is_anml_fac_type_cafo_ind,'')
	+ ISNULL(CONVERT(varchar(50), cafo_desgn_date),'')
	+ ISNULL(cafo_desgn_reason_txt,'')
	+ ISNULL(CONVERT(varchar(50), num_acres_contrb_drain),'')
	+ ISNULL(CONVERT(varchar(50), appl_meas_avail_land_num),'')
	+ ISNULL(CONVERT(varchar(50), solid_mnur_lttr_gnrtd_amt),'')
	+ ISNULL(CONVERT(varchar(50), liquid_mnur_ww_gnrtd_amt),'')
	+ ISNULL(CONVERT(varchar(50), solid_mnur_lttr_trans_amt),'')
	+ ISNULL(CONVERT(varchar(50), liquid_mnur_ww_trans_amt),'')
	+ ISNULL(nmp_dvlpd_cert_plnr_aprvd_ind,'')
	+ ISNULL(CONVERT(varchar(50), nmp_dvlpd_date),'')
	+ ISNULL(CONVERT(varchar(50), nmp_last_updated_date),'')
	+ ISNULL(envr_mgmt_systm_ind,'')
	+ ISNULL(CONVERT(varchar(50), ems_dvlpd_date),'')
	+ ISNULL(CONVERT(varchar(50), ems_last_updated_date),'')
	+ ISNULL(CONVERT(varchar(50), lvstck_max_cpcty_num),'')
	+ ISNULL(CONVERT(varchar(50), lvstck_cpcty_dtrmn_bs_upon_num),'')
	+ ISNULL(CONVERT(varchar(50), auth_lvstck_cpcty_num),'')
	+ ISNULL(legal_desc_txt,'')
);
UPDATE dbo.ics_cafo_prod_area_dsch
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  CONVERT(varchar(50), cafo_prod_area_dsch_discovery_date)
	+ ISNULL(cafo_prod_area_dsch_24hr_rain_evt_ind,'')
	+ ISNULL(CONVERT(varchar(50), cafo_prod_area_dsch_duration_hours),'')
	+ ISNULL(CONVERT(varchar(50), cafo_prod_area_dsch_vol_gal),'')
);
UPDATE dbo.ics_cafomlpw_fld_amounts
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  cafomlpw_code
	+ ISNULL(CONVERT(varchar(50), cafomlpw_fld_max_allowable_amt),'')
	+ ISNULL(CONVERT(varchar(50), cafomlpw_fld_actul_amt),'')
	+ ISNULL(cafomlpw_land_appl_unit,'')
);
UPDATE dbo.ics_cafomlpw_nutr_mon
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  cafomlpw_code
	+ ISNULL(cafomlpw_nutr_form,'')
	+ ISNULL(CONVERT(varchar(50), cafomlpw_nutr_value),'')
	+ ISNULL(cafomlpw_nutr_value_unit,'')
);
UPDATE dbo.ics_cafomlpw_ttl_amounts
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  cafomlpw_code
	+ ISNULL(CONVERT(varchar(50), cafomlpw_amt_gnrtd),'')
	+ ISNULL(CONVERT(varchar(50), cafomlpw_amt_transferred),'')
	+ ISNULL(cafomlpw_unit,'')
);
UPDATE dbo.ics_cmpl_insp_type
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  cmpl_insp_type_code
);
UPDATE dbo.ics_cmpl_mon
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', cmpl_mon_ident),
      data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	   cmpl_mon_ident
	+ ISNULL(prmt_ident,'')
	+ ISNULL(cmpl_mon_acty_type_code,'')
	+ ISNULL(cmpl_mon_catg_code,'')
	+ ISNULL(CONVERT(varchar(50), cmpl_mon_date),'')
	+ ISNULL(CONVERT(varchar(50), cmpl_mon_start_date),'')
	+ ISNULL(cmpl_mon_acty_name,'')
	+ ISNULL(biomon_insp_method,'')
	+ ISNULL(CONVERT(varchar(50), cmpl_mon_agncy_code),'')
	+ ISNULL(st_statute_viol_name,'')
	+ ISNULL(epa_assist_ind,'')
	+ ISNULL(st_fedr_joint_ind,'')
	+ ISNULL(joint_insp_reason_code,'')
	+ ISNULL(lead_party,'')
	+ ISNULL(CONVERT(varchar(50), num_days_phys_cond_acty),'')
	+ ISNULL(CONVERT(varchar(50), num_hours_phys_cond_acty),'')
	+ ISNULL(CONVERT(varchar(50), cmpl_mon_actn_outcome_code),'')
	+ ISNULL(insp_rating_code,'')
	+ ISNULL(multimedia_ind,'')
	+ ISNULL(fedr_fac_ind,'')
	+ ISNULL(fedr_fac_ind_cmnt,'')
	+ ISNULL(insp_usr_dfnd_fld_1,'')
	+ ISNULL(insp_usr_dfnd_fld_2,'')
	+ ISNULL(insp_usr_dfnd_fld_3,'')
	+ ISNULL(CONVERT(varchar(50), insp_usr_dfnd_fld_4),'')
	+ ISNULL(CONVERT(varchar(50), insp_usr_dfnd_fld_5),'')
	+ ISNULL(insp_usr_dfnd_fld_6,'')
	+ ISNULL(CONVERT(varchar(50), cmpl_mon_planned_start_date),'')
	+ ISNULL(CONVERT(varchar(50), cmpl_mon_planned_end_date),'')
);
UPDATE dbo.ics_cmpl_mon_actn_reason
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  cmpl_mon_actn_reason_code
);
UPDATE dbo.ics_cmpl_mon_agncy_type
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  cmpl_mon_agncy_type_code
);
UPDATE dbo.ics_cmpl_mon_evt
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  CONVERT(varchar(50), cmpl_mon_evt_ident)
	+ ISNULL(CONVERT(varchar(50), cmpl_mon_evt_start_date),'')
	+ ISNULL(CONVERT(varchar(50), cmpl_mon_evt_end_date),'')
);
UPDATE dbo.ics_cmpl_mon_lnk
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	   cmpl_mon_ident
);
UPDATE dbo.ics_cmpl_schd
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', CONVERT(varchar(50),ics_cmpl_schd.enfrc_actn_ident) + CONVERT(varchar(50),final_order_ident) + prmt_ident +CONVERT(varchar(50), cmpl_schd_num)),
      data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	   enfrc_actn_ident
	+ ISNULL(CONVERT(varchar(50), final_order_ident),'')
	+ prmt_ident
	+ CONVERT(varchar(50), cmpl_schd_num)
	+ ISNULL(cmpl_schd_cmnts,'')
	+ ISNULL(schd_desc_code,'')
);
UPDATE dbo.ics_cmpl_schd_evt
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  schd_evt_code
	+ CONVERT(varchar(50), schd_date)
	+ ISNULL(CONVERT(varchar(50), schd_rep_rcvd_date),'')
	+ ISNULL(CONVERT(varchar(50), schd_actul_date),'')
	+ ISNULL(CONVERT(varchar(50), schd_proj_date),'')
	+ ISNULL(schd_usr_dfnd_dat_elm_1,'')
	+ ISNULL(schd_usr_dfnd_dat_elm_2,'')
	+ ISNULL(schd_evt_cmnts,'')
	+ ISNULL(CONVERT(varchar(50), cmpl_schd_pnlty_amt),'')
);
UPDATE dbo.ics_cmpl_schd_evt_viol_elem
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  enfrc_actn_ident
	+ ISNULL(CONVERT(varchar(50), final_order_ident),'')
	+ prmt_ident
	+ CONVERT(varchar(50), cmpl_schd_num)
	+ schd_evt_code
	+ CONVERT(varchar(50), schd_date)
	+ schd_viol_code
);
UPDATE dbo.ics_cmpl_schd_viol
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  enfrc_actn_ident
	+ ISNULL(CONVERT(varchar(50), final_order_ident),'')
	+ prmt_ident
	+ CONVERT(varchar(50), cmpl_schd_num)
	+ schd_evt_code
	+ CONVERT(varchar(50), schd_date)
);
UPDATE dbo.ics_cmpl_track_stat
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(stat_code,'')
	+ ISNULL(CONVERT(varchar(50), stat_start_date),'')
	+ ISNULL(stat_reason,'')
);
UPDATE dbo.ics_cnst_site
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  cnst_site_code
);
UPDATE dbo.ics_cnst_site_list
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(cnst_site_othr_txt,'')
);
UPDATE dbo.ics_co_dspl_site
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(part_258_cmpl_ind,'')
	+ ISNULL(paint_filter_test_result,'')
	+ ISNULL(tclp_test_result,'')
);
UPDATE dbo.ics_coll_systm_prmt
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', prmt_ident + COLL_SYSTM_IDENT),
      data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ ISNULL(coll_systm_ident,'')
	+ ISNULL(coll_systm_name,'')
	+ ISNULL(coll_systm_owner_type_code,'')
	+ ISNULL(CONVERT(varchar(50), coll_systm_popl),'')
	+ ISNULL(CONVERT(varchar(50), percent_coll_systm_css),'')
);
UPDATE dbo.ics_contact
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  affil_type_txt
	+ first_name
	+ ISNULL(middle_name,'')
	+ last_name
	+ indvl_title_txt
	+ ISNULL(org_frml_name,'')
	+ ISNULL(st_code,'')
	+ ISNULL(rgn_code,'')
	+ ISNULL(elec_addr_txt,'')
	+ ISNULL(CONVERT(varchar(50), start_date_of_contact_assc),'')
	+ ISNULL(CONVERT(varchar(50), end_date_of_contact_assc),'')
);
UPDATE dbo.ics_containment
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  containment_type_code
	+ ISNULL(othr_containment_type_name,'')
	+ ISNULL(CONVERT(varchar(50), containment_cpcty_num),'')
);
UPDATE dbo.ics_control_auth_prog_info
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(CONVERT(varchar(50), loc_lmts_adoption_date),'')
	+ ISNULL(CONVERT(varchar(50), loc_lmts_eval_date),'')
	+ potw_dsch_contamination_ind
	+ ISNULL(potw_dsch_contamination_txt,'')
	+ potw_bs_contamination_ind
	+ ISNULL(potw_bs_contamination_txt,'')
);
UPDATE dbo.ics_cooling_wtr_intake_strct_cmpl_method
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  cooling_wtr_intake_strct_cmpl_method_code
	+ ISNULL(cooling_wtr_intake_strct_cmpl_method_txt,'')
);
UPDATE dbo.ics_cooling_wtr_intake_strct_info
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(CONVERT(varchar(50), cooling_wtr_intake_strct_appl_subpart),'')
	+ ISNULL(CONVERT(varchar(50), cooling_wtr_intake_strct_dsgn_intake_flow),'')
	+ ISNULL(CONVERT(varchar(50), cooling_wtr_intake_strct_actul_intake_flow),'')
	+ ISNULL(CONVERT(varchar(50), cooling_wtr_actul_intake_strct_velocity),'')
	+ ISNULL(src_wtr_baseline_biological_characterization,'')
	+ cooling_wtr_intake_strct_loc_code
	+ ISNULL(cooling_wtr_intake_strct_loc_txt,'')
	+ cooling_wtr_intake_strct_src_wtr_code
	+ ISNULL(cooling_wtr_intake_strct_src_wtr_txt,'')
);
UPDATE dbo.ics_copy_mgp_lmt_set
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', prmt_ident + prmt_featr_ident + lmt_set_designator),
   -- key_hash = dbo.HASHBYTES_VARCHAR('SHA1', prmt_ident + prmt_featr_ident + lmt_set_designator + trgt_gnrl_prmt_ident + trgt_gnrl_prmt_featr_ident + trgt_gnrl_lmt_set_designator),
       data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ prmt_featr_ident
	+ lmt_set_designator
	+ ISNULL(trgt_gnrl_prmt_ident,'')
	+ ISNULL(trgt_gnrl_prmt_featr_ident,'')
	+ ISNULL(trgt_gnrl_lmt_set_designator,'')
	+ ISNULL(prmt_featr_type_code,'')
	+ ISNULL(prmt_featr_desc,'')
	+ ISNULL(prmt_featr_st_wtr_body_name,'')
	+ ISNULL(impaired_wtr_ind,'')
	+ ISNULL(tmdl_completed_ind,'')
	+ ISNULL(prmt_featr_usr_dfnd_dat_elm_1,'')
	+ ISNULL(prmt_featr_usr_dfnd_dat_elm_2,'')
	+ ISNULL(lmt_set_name_txt,'')
	+ ISNULL(dmr_pre_print_cmnts_txt,'')
);
UPDATE dbo.ics_copy_mgpms_4_req
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', dbo.ics_copy_mgpms_4_req.prmt_ident),
      data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
);
UPDATE dbo.ics_crop_types_harvested
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  crop_types_harvested
);
UPDATE dbo.ics_crop_types_planted
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  crop_types_planted
);
UPDATE dbo.ics_cso_control_meas_detail
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(cso_control_meas_code,'')
	+ ISNULL(cso_control_meas_code_othr_txt,'')
	+ ISNULL(cso_control_meas_dev_imp_stat,'')
	+ ISNULL(cso_control_meas_cmpl_stat,'')
);
UPDATE dbo.ics_cso_insp
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(CONVERT(varchar(50), cso_evt_date),'')
	+ ISNULL(dry_or_wet_weather_ind,'')
	+ ISNULL(prmt_featr_ident,'')
	+ ISNULL(CONVERT(varchar(50), lat_meas),'')
	+ ISNULL(CONVERT(varchar(50), long_meas),'')
	+ ISNULL(cso_ovrflw_loc_street,'')
	+ ISNULL(CONVERT(varchar(50), duration_cso_ovrflw_evt),'')
	+ ISNULL(CONVERT(varchar(50), dsch_vol_treated),'')
	+ ISNULL(CONVERT(varchar(50), dsch_vol_untreated),'')
	+ ISNULL(corr_actn_taken_desc_txt,'')
	+ ISNULL(CONVERT(varchar(50), inches_precip),'')
);
UPDATE dbo.ics_cso_long_term_control_plan
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', dbo.ics_cso_long_term_control_plan.prmt_ident),
      data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
);
UPDATE dbo.ics_cwa_316b_prog_rep
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', prmt_ident + PROG_REP_FORM_SET_ID + CONVERT(varchar(50), PROG_REP_FORM_ID) ),
      data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ ISNULL(CONVERT(varchar(50), prog_rep_rcvd_date),'')
	+ ISNULL(CONVERT(varchar(50), prog_rep_start_date),'')
	+ ISNULL(CONVERT(varchar(50), prog_rep_end_date),'')
	+ ISNULL(elec_subm_type_code,'')
	+ ISNULL(prog_rep_npdes_dat_grp_num_code,'')
	+ ISNULL(cwa_316b_crit_habitat_protection_msr,'')
	+ ISNULL(cwa_316b_othr_mon_info,'')
);
UPDATE dbo.ics_cwa_316b_take_info
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  cwa_316b_take_ident
	+ ISNULL(cwa_316b_species_name,'')
	+ ISNULL(cwa_316b_species_common_name,'')
	+ ISNULL(cwa_316b_fedr_stat,'')
	+ ISNULL(cwa_316b_lifestage_code,'')
	+ ISNULL(cwa_316b_take_method_code,'')
	+ ISNULL(cwa_316b_take_method_othr_txt,'')
	+ ISNULL(cwa_316b_take_type_code,'')
	+ ISNULL(cwa_316b_take_type_othr_txt,'')
	+ ISNULL(CONVERT(varchar(50), cwa_316b_species_num),'')
	+ ISNULL(CONVERT(varchar(50), cwa_316b_species_num_impinged_entrained),'')
	+ ISNULL(CONVERT(varchar(50), cwa_316b_species_num_impinged_entrained_date),'')
);
UPDATE dbo.ics_dmr_viol
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', dbo.ics_dmr_viol.prmt_ident + prmt_featr_ident + lmt_set_designator +CONVERT(varchar(50), mon_period_end_date) + param_code + mon_site_desc_code +CONVERT(varchar(50), lmt_season_num) +CONVERT(varchar(50), num_rep_code) +CONVERT(varchar(50), num_rep_viol_code)),
      data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ prmt_featr_ident
	+ lmt_set_designator
	+ CONVERT(varchar(50), mon_period_end_date)
	+ param_code
	+ mon_site_desc_code
	+ CONVERT(varchar(50), lmt_season_num)
	+ num_rep_code
	+ num_rep_viol_code
	+ ISNULL(rep_non_cmpl_detect_code,'')
	+ ISNULL(CONVERT(varchar(50), rep_non_cmpl_detect_date),'')
	+ ISNULL(rep_non_cmpl_resl_code,'')
	+ ISNULL(CONVERT(varchar(50), rep_non_cmpl_resl_date),'')
);
UPDATE dbo.ics_dsch_mon_rep
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', dbo.ics_dsch_mon_rep.prmt_ident + prmt_featr_ident + lmt_set_designator +CONVERT(varchar(50), mon_period_end_date)),
      data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ prmt_featr_ident
	+ lmt_set_designator
	+ CONVERT(varchar(50), mon_period_end_date)
	+ ISNULL(dmr_no_dsch_ind,'')
	+ ISNULL(CONVERT(varchar(50), dmr_no_dsch_rcvd_date),'')
	+ ISNULL(elec_subm_type_code,'')
	+ ISNULL(CONVERT(varchar(50), sign_date),'')
	+ ISNULL(prncpl_exec_offcr_first_name,'')
	+ ISNULL(prncpl_exec_offcr_last_name,'')
	+ ISNULL(prncpl_exec_offcr_title,'')
	+ ISNULL(prncpl_exec_offcr_teleph,'')
	+ ISNULL(sign_first_name,'')
	+ ISNULL(sign_last_name,'')
	+ ISNULL(sign_teleph,'')
	+ ISNULL(rep_cmnt_txt,'')
);
UPDATE dbo.ics_dsch_mon_rep_param_viol
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  prmt_ident
	+ prmt_featr_ident
	+ lmt_set_designator
	+ CONVERT(varchar(50), mon_period_end_date)
	+ param_code
	+ mon_site_desc_code
	+ CONVERT(varchar(50), lmt_season_num)
);
UPDATE dbo.ics_dsch_mon_rep_viol
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  prmt_ident
	+ prmt_featr_ident
	+ lmt_set_designator
	+ CONVERT(varchar(50), mon_period_end_date)
);
UPDATE dbo.ics_efflu_guide
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  efflu_guide_code
);
UPDATE dbo.ics_efflu_trade_prtner
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', dbo.ics_efflu_trade_prtner.prmt_ident + prmt_featr_ident + lmt_set_designator + param_code + mon_site_desc_code +CONVERT(varchar(50), lmt_season_num) +CONVERT(varchar(50), lmt_start_date) +CONVERT(varchar(50), lmt_end_date) +CONVERT(varchar(50), lmt_mod_effective_date) + trade_id),
      data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ prmt_featr_ident
	+ lmt_set_designator
	+ param_code
	+ mon_site_desc_code
	+ CONVERT(varchar(50), lmt_season_num)
	+ CONVERT(varchar(50), lmt_start_date)
	+ CONVERT(varchar(50), lmt_end_date)
	+ ISNULL(CONVERT(varchar(50), lmt_mod_effective_date),'')
	+ ISNULL(trade_prtner_npdesid,'')
	+ ISNULL(trade_prtner_type,'')
	+ ISNULL(CONVERT(varchar(50), trade_prtner_start_date),'')
	+ ISNULL(CONVERT(varchar(50), trade_prtner_end_date),'')
);
UPDATE dbo.ics_efflu_trade_prtner_addr
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(org_frml_name,'')
	+ ISNULL(org_duns_num,'')
	+ ISNULL(loc_name,'')
	+ ISNULL(mailing_addr_txt,'')
	+ ISNULL(suppl_addr_txt,'')
	+ ISNULL(mailing_addr_city_name,'')
	+ ISNULL(mailing_addr_country_code,'')
	+ ISNULL(loc_province,'')
	+ ISNULL(mailing_addr_st_code,'')
	+ ISNULL(mailing_addr_zip_code,'')
	+ ISNULL(county_name,'')
	+ ISNULL(division_name,'')
	+ ISNULL(elec_addr_txt,'')
);
UPDATE dbo.ics_enfrc_actn_gov_contact
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  affil_type_txt
	+ ISNULL(elec_addr_txt,'')
	+ ISNULL(CONVERT(varchar(50), start_date_of_contact_assc),'')
	+ ISNULL(CONVERT(varchar(50), end_date_of_contact_assc),'')
);
UPDATE dbo.ics_enfrc_actn_milestone
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', dbo.ics_enfrc_actn_milestone.enfrc_actn_ident + milestone_type_code),
      data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	   enfrc_actn_ident
	+ milestone_type_code
	+ ISNULL(CONVERT(varchar(50), milestone_planned_date),'')
	+ ISNULL(CONVERT(varchar(50), milestone_actul_date),'')
);
UPDATE dbo.ics_enfrc_actn_type
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  enfrc_actn_type_code
);
UPDATE dbo.ics_enfrc_actn_viol_lnk
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	   enfrc_actn_ident
);
UPDATE dbo.ics_enfrc_agncy
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  enfrc_agncy_type_code
	+ agncy_lead_ind
);
UPDATE dbo.ics_fac
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(locality_name,'')
	+ ISNULL(loc_addr_city_code,'')
	+ ISNULL(loc_addr_county_code,'')
	+ ISNULL(fac_site_name,'')
	+ ISNULL(loc_addr_txt,'')
	+ ISNULL(suppl_loc_txt,'')
	+ ISNULL(loc_st_code,'')
	+ ISNULL(loc_zip_code,'')
	+ ISNULL(loc_country_code,'')
	+ ISNULL(org_duns_num,'')
	+ ISNULL(st_fac_ident,'')
	+ ISNULL(st_rgn_code,'')
	+ ISNULL(CONVERT(varchar(50), fac_congr_district_num),'')
	+ ISNULL(fac_type_of_ownership_code,'')
	+ ISNULL(fedr_fac_ident_num,'')
	+ ISNULL(fedr_agncy_code,'')
	+ ISNULL(tribal_land_code,'')
	+ ISNULL(cnst_proj_name,'')
	+ ISNULL(CONVERT(varchar(50), cnst_proj_lat_meas),'')
	+ ISNULL(CONVERT(varchar(50), cnst_proj_long_meas),'')
	+ ISNULL(section_township_rng,'')
	+ ISNULL(fac_cmnts,'')
	+ ISNULL(fac_usr_dfnd_fld_1,'')
	+ ISNULL(fac_usr_dfnd_fld_2,'')
	+ ISNULL(fac_usr_dfnd_fld_3,'')
	+ ISNULL(fac_usr_dfnd_fld_4,'')
	+ ISNULL(fac_usr_dfnd_fld_5,'')
);
UPDATE dbo.ics_fac_class
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  fac_class
);
UPDATE dbo.ics_final_order
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  CONVERT(varchar(50), final_order_ident)
	+ ISNULL(final_order_type_code,'')
	+ ISNULL(CONVERT(varchar(50), final_order_issued_enterd_date),'')
	+ ISNULL(CONVERT(varchar(50), npdes_closed_date),'')
	+ ISNULL(final_order_qncr_cmnts,'')
	+ ISNULL(CONVERT(varchar(50), cash_civil_pnlty_reqd_amt),'')
	+ ISNULL(CONVERT(varchar(50), cash_civil_pnlty_coll_amt),'')
	+ ISNULL(othr_cmnts,'')
);
UPDATE dbo.ics_final_order_prmt_ident
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  final_order_prmt_ident
);
UPDATE dbo.ics_final_order_viol_lnk
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	   enfrc_actn_ident
	+ CONVERT(varchar(50), final_order_ident)
);
UPDATE dbo.ics_frml_enfrc_actn
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', dbo.ics_frml_enfrc_actn.enfrc_actn_ident),
      data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	   enfrc_actn_ident
	+ ISNULL(enfrc_actn_name,'')
	+ ISNULL(forum,'')
	+ ISNULL(resl_type_code,'')
	+ ISNULL(combined_or_superseded_by_eaid,'')
	+ ISNULL(reason_deleting_record,'')
	+ ISNULL(frml_ea_usr_dfnd_fld_1,'')
	+ ISNULL(frml_ea_usr_dfnd_fld_2,'')
	+ ISNULL(frml_ea_usr_dfnd_fld_3,'')
	+ ISNULL(CONVERT(varchar(50), frml_ea_usr_dfnd_fld_4),'')
	+ ISNULL(CONVERT(varchar(50), frml_ea_usr_dfnd_fld_5),'')
	+ ISNULL(frml_ea_usr_dfnd_fld_6,'')
	+ ISNULL(enfrc_agncy_name,'')
);
UPDATE dbo.ics_geo_coord
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  CONVERT(varchar(50), lat_meas)
	+ CONVERT(varchar(50), long_meas)
	+ ISNULL(CONVERT(varchar(50), horz_accuracy_meas),'')
	+ ISNULL(geometric_type_code,'')
	+ ISNULL(horz_coll_method_code,'')
	+ ISNULL(horz_ref_datum_code,'')
	+ ISNULL(ref_point_code,'')
	+ ISNULL(CONVERT(varchar(50), src_map_scale_num),'')
);
UPDATE dbo.ics_gnrl_prmt
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', dbo.ics_gnrl_prmt.prmt_ident),
      data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ ISNULL(elec_subm_type_code,'')
	+ ISNULL(assc_master_gnrl_prmt_ident,'')
	+ ISNULL(prmt_type_code,'')
	+ ISNULL(agncy_type_code,'')
	+ ISNULL(prmt_stat_code,'')
	+ ISNULL(CONVERT(varchar(50), prmt_issue_date),'')
	+ ISNULL(CONVERT(varchar(50), prmt_effective_date),'')
	+ ISNULL(CONVERT(varchar(50), prmt_expr_date),'')
	+ ISNULL(reissu_prio_prmt_ind,'')
	+ ISNULL(backlog_reason_txt,'')
	+ ISNULL(prmt_issuing_org_type_name,'')
	+ ISNULL(prmt_appealed_ind,'')
	+ ISNULL(prmt_usr_dfnd_dat_elm_1_txt,'')
	+ ISNULL(prmt_usr_dfnd_dat_elm_2_txt,'')
	+ ISNULL(prmt_usr_dfnd_dat_elm_3_txt,'')
	+ ISNULL(prmt_usr_dfnd_dat_elm_4_txt,'')
	+ ISNULL(prmt_usr_dfnd_dat_elm_5_txt,'')
	+ ISNULL(prmt_cmnts_txt,'')
	+ ISNULL(CONVERT(varchar(50), major_minor_rating_code),'')
	+ ISNULL(CONVERT(varchar(50), ttl_appl_dsgn_flow_num),'')
	+ ISNULL(CONVERT(varchar(50), ttl_appl_aver_flow_num),'')
	+ ISNULL(CONVERT(varchar(50), appl_rcvd_date),'')
	+ ISNULL(CONVERT(varchar(50), prmt_appl_cmpl_date),'')
	+ ISNULL(new_src_ind,'')
	+ ISNULL(prmt_st_wtr_body_code,'')
	+ ISNULL(prmt_st_wtr_body_name,'')
	+ ISNULL(fedr_grant_ind,'')
	+ ISNULL(dmr_cognznt_ofcl,'')
	+ ISNULL(dmr_cognznt_ofcl_teleph_num,'')
	+ ISNULL(elec_rep_waiver_type_code,'')
	+ ISNULL(CONVERT(varchar(50), elec_rep_waiver_effective_date),'')
	+ ISNULL(CONVERT(varchar(50), elec_rep_waiver_expr_date),'')
	+ ISNULL(major_minor_stat_ind,'')
	+ ISNULL(CONVERT(varchar(50), major_minor_stat_start_date),'')
	+ ISNULL(dmr_non_rcpt_stat_ind,'')
	+ ISNULL(CONVERT(varchar(50), dmr_non_rcpt_stat_start_date),'')
);
UPDATE dbo.ics_gnrl_prmt_coverage_ms_4_req
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  prmt_ident
);
UPDATE dbo.ics_gpcf_no_exposure
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(CONVERT(varchar(50), no_exposure_auth_date),'')
	+ ISNULL(CONVERT(varchar(50), no_exposure_postmark_date),'')
	+ ISNULL(CONVERT(varchar(50), no_exposure_eval_date),'')
	+ ISNULL(no_exposure_eval_basis_code,'')
	+ ISNULL(no_exposure_criteria_met_ind,'')
	+ ISNULL(CONVERT(varchar(50), paved_roof_size),'')
);
UPDATE dbo.ics_gpcf_notice_of_intent
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(CONVERT(varchar(50), noi_sign_date),'')
	+ ISNULL(CONVERT(varchar(50), noi_postmark_date),'')
	+ ISNULL(CONVERT(varchar(50), noi_rcvd_date),'')
	+ ISNULL(CONVERT(varchar(50), complete_noi_rcvd_date),'')
	+ ISNULL(fedr_cercla_dsch_ind,'')
);
UPDATE dbo.ics_gpcf_notice_of_term
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(CONVERT(varchar(50), not_term_date),'')
	+ ISNULL(CONVERT(varchar(50), not_sign_date),'')
	+ ISNULL(CONVERT(varchar(50), not_postmark_date),'')
	+ ISNULL(CONVERT(varchar(50), not_rcvd_date),'')
);
UPDATE dbo.ics_hist_prmt_schd_evts
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', dbo.ics_hist_prmt_schd_evts.prmt_ident +CONVERT(varchar(50), prmt_effective_date) +CONVERT(varchar(50), narr_cond_num) + schd_evt_code +CONVERT(varchar(50), schd_date) +CONVERT(varchar(50), narr_cond_num) + schd_evt_code +CONVERT(varchar(50), schd_date)),
      data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ CONVERT(varchar(50), prmt_effective_date)
	+ ISNULL(CONVERT(varchar(50), narr_cond_num),'')
	+ schd_evt_code
	+ CONVERT(varchar(50), schd_date)
	+ ISNULL(CONVERT(varchar(50), schd_rep_rcvd_date),'')
	+ ISNULL(CONVERT(varchar(50), schd_actul_date),'')
	+ ISNULL(CONVERT(varchar(50), schd_proj_date),'')
	+ ISNULL(schd_usr_dfnd_dat_elm_1,'')
	+ ISNULL(schd_usr_dfnd_dat_elm_2,'')
	+ ISNULL(schd_evt_cmnts,'')
);
UPDATE dbo.ics_impact_sso_evt
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  impact_sso_evt
);
UPDATE dbo.ics_impaired_wtr_pollutants
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  CONVERT(varchar(50), impaired_wtr_pollutants)
);
UPDATE dbo.ics_incin
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(beryllium_cmpl_ind,'')
	+ ISNULL(mercury_cmpl_ind,'')
);
UPDATE dbo.ics_indst_usr_info
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  prmt_ident
	+ ISNULL(CONVERT(varchar(50), iu_aver_daily_ww_flow_rate_gpd),'')
	+ ISNULL(CONVERT(varchar(50), iu_aver_daily_prcss_ww_flow_rate_gpd),'')
	+ ISNULL(iu_subject_loc_lmts_ind,'')
	+ ISNULL(iu_subject_loc_lmts_more_stringent_cat_std_ind,'')
	+ ISNULL(mtciu_subject_reduced_rep_ind,'')
	+ ISNULL(CONVERT(varchar(50), num_iu_insp_by_ca),'')
	+ ISNULL(CONVERT(varchar(50), num_iu_smpl_evts_by_ca),'')
	+ ISNULL(CONVERT(varchar(50), num_reqd_iu_self_mon_evts_max),'')
	+ ISNULL(iu_comply_req_self_mon_rpting_ind,'')
	+ ISNULL(iu_comply_req_self_mon_rpting_txt,'')
	+ ISNULL(nsciu_cert_subm_to_ca_ind,'')
	+ ISNULL(changed_disch_subm_ind,'')
);
UPDATE dbo.ics_indst_usr_inventory
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(indst_usr_ind,'')
);
UPDATE dbo.ics_infrml_enfrc_actn
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', dbo.ics_infrml_enfrc_actn.enfrc_actn_ident),
      data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	   enfrc_actn_ident
	+ ISNULL(enfrc_actn_type_code,'')
	+ ISNULL(enfrc_actn_name,'')
	+ ISNULL(CONVERT(varchar(50), achieved_date),'')
	+ ISNULL(file_num,'')
	+ ISNULL(reason_deleting_record,'')
	+ ISNULL(infrml_ea_cmnt_txt,'')
	+ ISNULL(infrml_ea_usr_dfnd_fld_1,'')
	+ ISNULL(infrml_ea_usr_dfnd_fld_2,'')
	+ ISNULL(infrml_ea_usr_dfnd_fld_3,'')
	+ ISNULL(CONVERT(varchar(50), infrml_ea_usr_dfnd_fld_4),'')
	+ ISNULL(CONVERT(varchar(50), infrml_ea_usr_dfnd_fld_5),'')
	+ ISNULL(infrml_ea_usr_dfnd_fld_6,'')
	+ ISNULL(enfrc_agncy_name,'')
);
UPDATE dbo.ics_insp_cmnt_txt
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  insp_cmnt_txt
);
UPDATE dbo.ics_insp_gov_contact
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  affil_type_txt
	+ ISNULL(elec_addr_txt,'')
);
UPDATE dbo.ics_iu_enf_actn_types
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  iu_enf_actn_type_code
	+ ISNULL(iu_enf_actn_type_othr_txt,'')
	+ ISNULL(CONVERT(varchar(50), num_iu_enf_actions),'')
);
UPDATE dbo.ics_iu_enfrc_actn_info
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(snc_pretr_enf_cmpl_sched_stat_ind,'')
	+ ISNULL(CONVERT(varchar(50), iu_cash_civil_pnlty_amt_assessed),'')
	+ ISNULL(CONVERT(varchar(50), iu_cash_civil_pnlty_amt_coll),'')
);
UPDATE dbo.ics_iu_viol_info
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(snc_pretr_stnd_lmts_ind,'')
	+ ISNULL(snc_rpt_rqmt_ind,'')
	+ ISNULL(snc_oth_ctrl_mech_rqmt_ind,'')
	+ ISNULL(snc_rel_potw_disch_oper_ind,'')
	+ ISNULL(snc_rel_potw_disch_oper_txt,'')
	+ ISNULL(snc_rel_potw_bio_oper_sewg_slud_mgmt_ind,'')
	+ ISNULL(snc_rel_potw_bio_oper_sewg_slud_mgmt_txt,'')
	+ ISNULL(snc_publ_ind,'')
);
UPDATE dbo.ics_land_appl_bmp
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  land_appl_bmp_type_code
	+ ISNULL(othr_land_appl_bmp_type_name,'')
);
UPDATE dbo.ics_land_appl_site
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(CONVERT(varchar(50), polut_met_for_land_appl),'')
	+ ISNULL(pathogen_reduction_ind,'')
	+ ISNULL(vector_reduction_ind,'')
	+ ISNULL(CONVERT(varchar(50), agronomic_gal_rate_for_fld),'')
	+ ISNULL(CONVERT(varchar(50), agronomic_dmt_rate_for_fld),'')
	+ ISNULL(class_a_alt_used,'')
	+ ISNULL(class_a_alts_txt,'')
	+ ISNULL(class_b_alt_used,'')
	+ ISNULL(class_b_alts_txt,'')
	+ ISNULL(var_alt_used,'')
	+ ISNULL(var_alts_txt,'')
);
UPDATE dbo.ics_lmt
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  CONVERT(varchar(50), lmt_start_date)
	+ CONVERT(varchar(50), lmt_end_date)
	+ ISNULL(lmt_type_code,'')
	+ ISNULL(smpl_type_txt,'')
	+ ISNULL(freq_of_analysis_code,'')
	+ ISNULL(eligible_for_burden_reduction,'')
	+ ISNULL(lmt_stay_type_code,'')
	+ ISNULL(CONVERT(varchar(50), stay_start_date),'')
	+ ISNULL(CONVERT(varchar(50), stay_end_date),'')
	+ ISNULL(stay_reason_txt,'')
	+ ISNULL(calculate_viol_ind,'')
	+ ISNULL(enfrc_actn_ident,'')
	+ ISNULL(CONVERT(varchar(50), final_order_ident),'')
	+ ISNULL(basis_of_lmt,'')
	+ ISNULL(lmt_mod_type_code,'')
	+ ISNULL(CONVERT(varchar(50), lmt_mod_effective_date),'')
	+ ISNULL(lmt_mod_type_stay_reason_txt,'')
	+ ISNULL(lmts_usr_dfnd_fld_1,'')
	+ ISNULL(lmts_usr_dfnd_fld_2,'')
	+ ISNULL(lmts_usr_dfnd_fld_3,'')
	+ ISNULL(concen_num_cond_unit_meas_code,'')
	+ ISNULL(qty_num_cond_unit_meas_code,'')
);
UPDATE dbo.ics_lmt_set
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', dbo.ics_lmt_set.prmt_ident + prmt_featr_ident + lmt_set_designator),
      data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ prmt_featr_ident
	+ lmt_set_designator
	+ ISNULL(lmt_set_type,'')
	+ ISNULL(lmt_set_name_txt,'')
	+ ISNULL(dmr_pre_print_cmnts_txt,'')
	+ ISNULL(agncy_reviewer,'')
	+ ISNULL(CONVERT(varchar(50), lmt_set_usr_dfnd_dat_elm_1_txt),'')
	+ ISNULL(lmt_set_usr_dfnd_dat_elm_2_txt,'')
);
UPDATE dbo.ics_lmt_set_months_appl
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  lmt_set_months_appl
);
UPDATE dbo.ics_lmt_set_schd
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  CONVERT(varchar(50), num_units_rep_period_integer)
	+ ISNULL(CONVERT(varchar(50), num_subm_units_integer),'')
	+ ISNULL(CONVERT(varchar(50), initial_mon_date),'')
	+ ISNULL(CONVERT(varchar(50), initial_dmr_due_date),'')
	+ ISNULL(lmt_set_mod_type_code,'')
	+ ISNULL(CONVERT(varchar(50), lmt_set_mod_effective_date),'')
);
UPDATE dbo.ics_lmt_set_stat
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  lmt_set_stat_ind
	+ CONVERT(varchar(50), lmt_set_stat_start_date)
	+ ISNULL(lmt_set_stat_reason_txt,'')
);
UPDATE dbo.ics_lmts
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', dbo.ics_lmts.prmt_ident + prmt_featr_ident + lmt_set_designator + param_code + mon_site_desc_code +CONVERT(varchar(50), lmt_season_num) +CONVERT(varchar(50), lmt_start_date) +CONVERT(varchar(50), lmt_end_date)),
      data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ prmt_featr_ident
	+ lmt_set_designator
	+ param_code
	+ mon_site_desc_code
	+ CONVERT(varchar(50), lmt_season_num)
	+ CONVERT(varchar(50), lmt_start_date)
	+ CONVERT(varchar(50), lmt_end_date)
	+ ISNULL(lmt_type_code,'')
	+ ISNULL(smpl_type_txt,'')
	+ ISNULL(freq_of_analysis_code,'')
	+ ISNULL(eligible_for_burden_reduction,'')
	+ ISNULL(lmt_stay_type_code,'')
	+ ISNULL(CONVERT(varchar(50), stay_start_date),'')
	+ ISNULL(CONVERT(varchar(50), stay_end_date),'')
	+ ISNULL(stay_reason_txt,'')
	+ ISNULL(calculate_viol_ind,'')
	+ ISNULL(enfrc_actn_ident,'')
	+ ISNULL(CONVERT(varchar(50), final_order_ident),'')
	+ ISNULL(basis_of_lmt,'')
	+ ISNULL(lmt_mod_type_code,'')
	+ ISNULL(CONVERT(varchar(50), lmt_mod_effective_date),'')
	+ ISNULL(lmt_mod_type_stay_reason_txt,'')
	+ ISNULL(lmts_usr_dfnd_fld_1,'')
	+ ISNULL(lmts_usr_dfnd_fld_2,'')
	+ ISNULL(lmts_usr_dfnd_fld_3,'')
	+ ISNULL(concen_num_cond_unit_meas_code,'')
	+ ISNULL(qty_num_cond_unit_meas_code,'')
);
UPDATE dbo.ics_lnk_cmpl_mon
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(cmpl_mon_ident,'')
);
UPDATE dbo.ics_lnk_enfrc_actn
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  enfrc_actn_ident
);
UPDATE dbo.ics_lnk_sngl_evt
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  prmt_ident
	+ sngl_evt_viol_code
	+ CONVERT(varchar(50), sngl_evt_viol_date)
);
UPDATE dbo.ics_loc_lmts_parameters
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  loc_lmts_parameters
);
UPDATE dbo.ics_ltcp_enforceable_mech_detail
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(ltcp_enforceable_mech_code,'')
	+ ISNULL(ltcp_enforceable_mech_code_othr_txt,'')
);
UPDATE dbo.ics_ltcp_most_recent_revision_detail
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(CONVERT(varchar(50), ltcp_most_recent_revision_date),'')
	+ ISNULL(ltcp_most_recent_revision_stat,'')
);
UPDATE dbo.ics_ltcp_summ
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(ltcp_reqd_ind,'')
	+ ISNULL(ltcp_in_cmpl_ind,'')
	+ ISNULL(CONVERT(varchar(50), ltcp_aprvl_date),'')
	+ ISNULL(CONVERT(varchar(50), ltcp_and_cso_controls_complete_date),'')
	+ ISNULL(cso_post_cnst_cmpl_mon_prog,'')
	+ ISNULL(cso_controls_othr_than_ltcp,'')
);
UPDATE dbo.ics_master_gnrl_prmt
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', dbo.ics_master_gnrl_prmt.prmt_ident),
      data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ ISNULL(prmt_type_code,'')
	+ ISNULL(agncy_type_code,'')
	+ ISNULL(CONVERT(varchar(50), prmt_issue_date),'')
	+ ISNULL(CONVERT(varchar(50), prmt_effective_date),'')
	+ ISNULL(CONVERT(varchar(50), prmt_expr_date),'')
	+ ISNULL(reissu_prio_prmt_ind,'')
	+ ISNULL(backlog_reason_txt,'')
	+ ISNULL(prmt_issuing_org_type_name,'')
	+ ISNULL(prmt_appealed_ind,'')
	+ ISNULL(prmt_usr_dfnd_dat_elm_1_txt,'')
	+ ISNULL(prmt_usr_dfnd_dat_elm_2_txt,'')
	+ ISNULL(prmt_usr_dfnd_dat_elm_3_txt,'')
	+ ISNULL(prmt_usr_dfnd_dat_elm_4_txt,'')
	+ ISNULL(prmt_usr_dfnd_dat_elm_5_txt,'')
	+ ISNULL(prmt_cmnts_txt,'')
	+ ISNULL(gnrl_prmt_indst_catg,'')
	+ ISNULL(prmt_name,'')
);
UPDATE dbo.ics_mn_lmt_applies
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  mn_lmt_applies
);
UPDATE dbo.ics_mnur_lttr_prcss_ww_stor
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  mnur_lttr_prcss_ww_stor_type
	+ ISNULL(othr_stor_type_name,'')
	+ ISNULL(CONVERT(varchar(50), stor_ttl_cpcty_meas),'')
	+ ISNULL(CONVERT(varchar(50), days_of_stor),'')
	+ ISNULL(cafomlpw_unit,'')
	+ ISNULL(cafomlpw_stor_within_dsgn_cpcty,'')
	+ ISNULL(cafomlpw_stor_within_dsgn_cpcty_txt,'')
);
UPDATE dbo.ics_ms_4_acty_ident
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  ms_4_acty_ident
);
UPDATE dbo.ics_ms_4_cnst_sw_procedures
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  ms_4_acty_ident
	+ ISNULL(ms_4_cnst_sw_procedure_type,'')
	+ ISNULL(ms_4_cnst_sw_procedure_txt,'')
	+ ISNULL(ms_4_cnst_sw_procedure_schd_txt,'')
);
UPDATE dbo.ics_ms_4_cnst_sw_regulated_entity_info
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  ms_4_acty_ident
	+ ISNULL(ms_4_regulated_entity_ident,'')
	+ ISNULL(ms_4_cnst_sw_erosion_ordinance_stat,'')
	+ ISNULL(ms_4_cnst_sw_erosion_ordinance_stat_txt,'')
	+ ISNULL(ms_4_cnst_sw_erosion_plan_rviw_stat,'')
	+ ISNULL(ms_4_cnst_sw_erosion_plan_rviw_stat_txt,'')
	+ ISNULL(ms_4_cnst_sw_site_insp_stat,'')
	+ ISNULL(ms_4_cnst_sw_site_insp_stat_txt,'')
);
UPDATE dbo.ics_ms_4_cnst_sw_reqs
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
null);
UPDATE dbo.ics_ms_4_illicit_detect_procedures
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  ms_4_acty_ident
	+ ISNULL(ms_4_illicit_detect_procedure_type,'')
	+ ISNULL(ms_4_illicit_detect_procedure_txt,'')
	+ ISNULL(ms_4_illicit_detect_procedure_schd_txt,'')
);
UPDATE dbo.ics_ms_4_illicit_detect_regulated_entity_info
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  ms_4_acty_ident
	+ ISNULL(ms_4_regulated_entity_ident,'')
	+ ISNULL(CONVERT(varchar(50), ms_4_prmt_illicit_detect_outfall_mapping_date),'')
	+ ISNULL(ms_4_illicit_detect_outfall_mapping_stat,'')
	+ ISNULL(CONVERT(varchar(50), ms_4_prmt_illicit_detect_outfall_ttl_num),'')
	+ ISNULL(CONVERT(varchar(50), ms_4_prmt_illicit_detect_outfall_mapped_num),'')
	+ ISNULL(ms_4_illicit_detect_prohibition_ordinance_stat,'')
	+ ISNULL(ms_4_illicit_detect_prohibition_ordinance_stat_txt,'')
);
UPDATE dbo.ics_ms_4_illicit_detect_regulated_entity_info_prog_rep
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  ms_4_acty_ident
	+ ISNULL(CONVERT(varchar(50), ms_4_prog_rep_illicit_detect_outfall_mapping_date),'')
	+ ISNULL(CONVERT(varchar(50), ms_4_prog_rep_illicit_detect_outfall_ttl_num),'')
	+ ISNULL(CONVERT(varchar(50), ms_4_prog_rep_illicit_detect_outfall_mapped_num),'')
	+ ISNULL(ms_4_regulated_entity_cmpl_stat,'')
	+ ISNULL(ms_4_regulated_entity_cmpl_stat_txt,'')
	+ ISNULL(ms_4_prog_rep_reqs_activities,'')
);
UPDATE dbo.ics_ms_4_illicit_detect_reqs
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
null);
UPDATE dbo.ics_ms_4_indst_sw_procedures
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  ms_4_acty_ident
	+ ISNULL(ms_4_indst_sw_procedure_type,'')
	+ ISNULL(ms_4_indst_sw_procedure_txt,'')
	+ ISNULL(ms_4_indst_sw_procedure_schd_txt,'')
);
UPDATE dbo.ics_ms_4_indst_sw_regulated_entity_info
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  ms_4_acty_ident
	+ ISNULL(ms_4_regulated_entity_ident,'')
	+ ISNULL(ms_4_indst_sw_ordinance_stat,'')
	+ ISNULL(ms_4_indst_sw_ordinance_stat_txt,'')
	+ ISNULL(ms_4_indst_sw_indst_inventory_stat,'')
	+ ISNULL(ms_4_indst_sw_indst_inventory_stat_txt,'')
	+ ISNULL(ms_4_indst_sw_mon_stat,'')
	+ ISNULL(ms_4_indst_sw_mon_stat_txt,'')
);
UPDATE dbo.ics_ms_4_indst_sw_reqs
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
null);
UPDATE dbo.ics_ms_4_othr_appl_reqs
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  ms_4_acty_ident
	+ ISNULL(ms_4_othr_appl_reqs_txt,'')
	+ ISNULL(ms_4_othr_appl_reqs_schd_txt,'')
);
UPDATE dbo.ics_ms_4_pblc_education_reqs
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  ms_4_acty_ident
	+ ISNULL(ms_4_pblc_education_reqs_txt,'')
	+ ISNULL(ms_4_pblc_education_schd_txt,'')
	+ ISNULL(ms_4_pblc_education_delivery_option,'')
	+ ISNULL(ms_4_pblc_education_delivery_option_othr_txt,'')
	+ ISNULL(ms_4_pblc_education_subject_option,'')
	+ ISNULL(ms_4_pblc_education_subject_option_othr_txt,'')
	+ ISNULL(ms_4_pblc_education_audience_option,'')
	+ ISNULL(ms_4_pblc_education_audience_option_othr_txt,'')
);
UPDATE dbo.ics_ms_4_pblc_involvement_reqs
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  ms_4_acty_ident
	+ ISNULL(ms_4_pblc_involvement_reqs_txt,'')
	+ ISNULL(ms_4_pblc_involvement_schd_txt,'')
	+ ISNULL(ms_4_pblc_involvement_delivery_option,'')
	+ ISNULL(ms_4_pblc_involvement_delivery_option_othr_txt,'')
	+ ISNULL(ms_4_pblc_involvement_subject_option,'')
	+ ISNULL(ms_4_pblc_involvement_subject_option_othr_txt,'')
	+ ISNULL(ms_4_pblc_involvement_participant_option,'')
	+ ISNULL(ms_4_pblc_involvement_participant_option_othr_txt,'')
);
UPDATE dbo.ics_ms_4_pollution_prevention_reqs
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  ms_4_acty_ident
	+ ISNULL(ms_4_pollution_prevention_reqs_txt,'')
	+ ISNULL(ms_4_pollution_prevention_schd_txt,'')
);
UPDATE dbo.ics_ms_4_post_cnst_sw_procedures
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  ms_4_acty_ident
	+ ISNULL(ms_4_post_cnst_sw_procedure_type,'')
	+ ISNULL(ms_4_post_cnst_sw_procedure_txt,'')
	+ ISNULL(ms_4_post_cnst_sw_procedure_schd_txt,'')
);
UPDATE dbo.ics_ms_4_post_cnst_sw_regulated_entity_info
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  ms_4_acty_ident
	+ ISNULL(ms_4_regulated_entity_ident,'')
	+ ISNULL(ms_4_post_cnst_sw_runoff_ordinance_stat,'')
	+ ISNULL(ms_4_post_cnst_sw_runoff_ordinance_stat_txt,'')
	+ ISNULL(ms_4_post_cnst_sw_runoff_prog_stat,'')
	+ ISNULL(ms_4_post_cnst_sw_runoff_prog_stat_txt,'')
	+ ISNULL(ms_4_post_cnst_sw_runoff_bmp_stat,'')
	+ ISNULL(ms_4_post_cnst_sw_runoff_bmp_stat_txt,'')
);
UPDATE dbo.ics_ms_4_post_cnst_sw_reqs
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
null);
UPDATE dbo.ics_ms_4_prog_rep_analysis
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  ms_4_prog_rep_analysis_txt
);
UPDATE dbo.ics_ms_4_prog_rep_reqs_regulated_entity
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  ms_4_acty_ident
	+ ISNULL(ms_4_regulated_entity_cmpl_stat,'')
	+ ISNULL(ms_4_regulated_entity_cmpl_stat_txt,'')
	+ ISNULL(ms_4_prog_rep_reqs_activities,'')
);
UPDATE dbo.ics_ms_4_regulated_entity
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(ms_4_regulated_entity_ident,'')
	+ ISNULL(ms_4_regulated_entity_name,'')
	+ ISNULL(ms_4_regulated_entity_ownership_level_code,'')
	+ ISNULL(ms_4_regulated_entity_ownership_level_othr_txt,'')
	+ ISNULL(ms_4_regulated_entity_catg_code,'')
	+ ISNULL(ms_4_regulated_entity_catg_code_othr_txt,'')
);
UPDATE dbo.ics_ms_4_regulated_entity_area
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  CONVERT(varchar(50), ms_4_regulated_entity_area_num)
	+ ISNULL(ms_4_regulated_entity_ident,'')
	+ ISNULL(ms_4_regulated_entity_area_stat_code,'')
	+ ISNULL(ms_4_regulated_entity_area_txt,'')
);
UPDATE dbo.ics_ms_4_regulated_entity_area_coord
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(CONVERT(varchar(50), lat_meas),'')
	+ ISNULL(CONVERT(varchar(50), long_meas),'')
);
UPDATE dbo.ics_ms_4_regulated_entity_enfrc
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(ms_4_regulated_entity_ident,'')
);
UPDATE dbo.ics_ms_4_regulated_entity_enfrc_actions
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  ms_4_regulated_entity_enfrc_actn_type_code
	+ ms_4_regulated_entity_enfrc_actn_type_code_othr_txt
);
UPDATE dbo.ics_ms_4_regulated_entity_ident
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  ms_4_regulated_entity_ident
);
UPDATE dbo.ics_ms_4_swmp_changes
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(ms_4_regulated_entity_ident,'')
	+ ms_4_swmp_change_ind
	+ ISNULL(ms_4_swmp_change_ind_txt,'')
);
UPDATE dbo.ics_naics_code
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  naics_code
	+ naics_primary_ind_code
);
UPDATE dbo.ics_narr_cond_schd
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', dbo.ics_narr_cond_schd.prmt_ident +CONVERT(varchar(50), narr_cond_num)),
      data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ CONVERT(varchar(50), narr_cond_num)
	+ ISNULL(narr_cond_code,'')
	+ ISNULL(cmnts,'')
);
UPDATE dbo.ics_nat_prio
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  CONVERT(varchar(50), nat_prio_code)
);
UPDATE dbo.ics_npdes_dat_grp_num
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  npdes_dat_grp_num_code
);
UPDATE dbo.ics_npdes_variance_prmt
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', concat(prmt_ident,npdes_variance_type_code,CONVERT(varchar(50), NPDES_VARIANCE_SUBM_DATE))),
      data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ ISNULL(npdes_variance_type_code,'')
	+ ISNULL(CONVERT(varchar(50), npdes_variance_subm_date),'')
	+ ISNULL(npdes_variance_version_type,'')
	+ ISNULL(npdes_variance_stat_code,'')
	+ ISNULL(CONVERT(varchar(50), npdes_variance_actn_date),'')
	+ ISNULL(thermal_variance_request_pblc_notice_ind,'')
	+ ISNULL(npdes_variance_cmnt_txt,'')
);
UPDATE dbo.ics_num_cond
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  num_cond_txt
	+ ISNULL(num_cond_qty,'')
	+ ISNULL(num_cond_stat_base_code,'')
	+ ISNULL(num_cond_qualifier,'')
	+ ISNULL(num_cond_opt_mon_ind,'')
	+ ISNULL(num_cond_stay_value,'')
);
UPDATE dbo.ics_num_rep
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  num_rep_code
	+ ISNULL(CONVERT(varchar(50), num_rep_rcvd_date),'')
	+ ISNULL(num_rep_no_dsch_ind,'')
	+ ISNULL(num_cond_qty,'')
	+ ISNULL(num_cond_adjusted_qty,'')
	+ ISNULL(num_cond_qualifier,'')
);
UPDATE dbo.ics_orig_progs
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  orig_progs_code
);
UPDATE dbo.ics_othr_prmts
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  othr_prmt_ident
	+ ISNULL(othr_org_name,'')
	+ ISNULL(othr_prmt_ident_cntxt_name,'')
);
UPDATE dbo.ics_param_lmts
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', dbo.ics_param_lmts.prmt_ident + prmt_featr_ident + lmt_set_designator + param_code + mon_site_desc_code +CONVERT(varchar(50), lmt_season_num)),
      data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ prmt_featr_ident
	+ lmt_set_designator
	+ param_code
	+ mon_site_desc_code
	+ CONVERT(varchar(50), lmt_season_num)
);
UPDATE dbo.ics_pathogen_reduction_type
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  pathogen_reduction_type_code
);
UPDATE dbo.ics_plcy
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  plcy_code
);
UPDATE dbo.ics_polut_list
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
null);
UPDATE dbo.ics_potw_prmt
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', dbo.ics_potw_prmt.prmt_ident),
      data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ ISNULL(CONVERT(varchar(50), sscs_popl_served_num),'')
	+ ISNULL(CONVERT(varchar(50), combined_sscs_systm_length),'')
);
UPDATE dbo.ics_potw_trtmnt_technology_prmt
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', dbo.ics_potw_trtmnt_technology_prmt.prmt_ident),
      data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ ISNULL(potw_trtmnt_level_code,'')
	+ ISNULL(potw_trtmnt_level_othr_txt,'')
	+ ISNULL(potw_ww_disinfection_technology_code,'')
	+ ISNULL(potw_ww_disinfection_technology_othr_txt,'')
	+ ISNULL(potw_ww_trtmnt_technology_unit_operation_code,'')
	+ ISNULL(potw_ww_trtmnt_technology_unit_operation_othr_txt,'')
);
UPDATE dbo.ics_pretr_insp
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(suo_ref,'')
	+ ISNULL(CONVERT(varchar(50), suo_date),'')
	+ ISNULL(acceptance_haz_waste,'')
	+ ISNULL(acceptance_non_haz_indst_waste,'')
	+ ISNULL(acceptance_huled_domstic_wstes,'')
	+ ISNULL(annul_pretr_budget,'')
	+ ISNULL(inadequacy_smpl_insp_ind,'')
	+ ISNULL(adequacy_pretr_resources,'')
	+ ISNULL(dfcnc_idntfd_drng_iu_file_rviw,'')
	+ ISNULL(control_mech_dfcnc,'')
	+ ISNULL(legal_auth_dfcnc,'')
	+ ISNULL(dfcnc_intrprt_appl_pretr_stndr,'')
	+ ISNULL(dfcnc_dat_mgmt_pblc_prticipton,'')
	+ ISNULL(viol_iu_schd_rmd_msr,'')
	+ ISNULL(frml_rspn_viol_iu_schd_rmd_msr,'')
	+ ISNULL(CONVERT(varchar(50), annul_freq_influnt_toxcnt_smpl),'')
	+ ISNULL(CONVERT(varchar(50), annul_freq_efflu_toxcnt_smpl),'')
	+ ISNULL(CONVERT(varchar(50), annul_freq_sldg_toxcnt_smpl),'')
	+ ISNULL(CONVERT(varchar(50), num_si_us),'')
	+ ISNULL(CONVERT(varchar(50), si_us_without_control_mech),'')
	+ ISNULL(CONVERT(varchar(50), si_us_not_inspected),'')
	+ ISNULL(CONVERT(varchar(50), si_us_not_smpl),'')
	+ ISNULL(CONVERT(varchar(50), si_us_on_schd),'')
	+ ISNULL(CONVERT(varchar(50), si_us_snc_with_pretr_stndr),'')
	+ ISNULL(CONVERT(varchar(50), si_us_snc_with_rep_reqs),'')
	+ ISNULL(CONVERT(varchar(50), si_us_snc_with_pretr_schd),'')
	+ ISNULL(CONVERT(varchar(50), si_us_snc_publ_newspaper),'')
	+ ISNULL(CONVERT(varchar(50), viol_notices_issued_si_us),'')
	+ ISNULL(CONVERT(varchar(50), admin_orders_issued_si_us),'')
	+ ISNULL(CONVERT(varchar(50), civil_suts_fild_aginst_si_us),'')
	+ ISNULL(CONVERT(varchar(50), criminl_suts_fild_aginst_si_us),'')
	+ ISNULL(CONVERT(varchar(50), dollar_amt_pnlty_coll),'')
	+ ISNULL(i_us_whc_pnlty_hav_bee_coll,'')
	+ ISNULL(CONVERT(varchar(50), num_ci_us),'')
	+ ISNULL(CONVERT(varchar(50), ci_us_in_snc),'')
	+ ISNULL(pass_through_interference_ind,'')
);
UPDATE dbo.ics_pretr_prmt
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', dbo.ics_pretr_prmt.prmt_ident),
      data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ ISNULL(pretr_prog_reqd_ind_code,'')
	+ ISNULL(control_auth_st_agncy_code,'')
	+ ISNULL(control_auth_rgnl_agncy_code,'')
	+ ISNULL(control_auth_npdes_ident,'')
	+ ISNULL(CONVERT(varchar(50), pretr_prog_aprvd_date),'')
	+ ISNULL(rcvg_rcra_waste_ind,'')
	+ ISNULL(rcvg_remediation_waste_ind,'')
);
UPDATE dbo.ics_pretr_prog_mod
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  pretr_prog_mod_type
	+ CONVERT(varchar(50), pretr_prog_mod_date)
	+ ISNULL(pretr_prog_mod_txt,'')
);
UPDATE dbo.ics_pretr_prog_rep
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', prmt_ident + PROG_REP_FORM_SET_ID + CONVERT(varchar(50), PROG_REP_FORM_ID) ),
      data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ ISNULL(CONVERT(varchar(50), prog_rep_rcvd_date),'')
	+ ISNULL(CONVERT(varchar(50), prog_rep_start_date),'')
	+ ISNULL(CONVERT(varchar(50), prog_rep_end_date),'')
	+ ISNULL(elec_subm_type_code,'')
	+ ISNULL(prog_rep_npdes_dat_grp_num_code,'')
);
UPDATE dbo.ics_prmt_bs_mgmt_practice
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  ssu_ident
	+ ISNULL(bs_mgmt_practice_code,'')
	+ ISNULL(bs_mgmt_practice_sub_catg_code,'')
	+ ISNULL(bs_mgmt_practice_sub_catg_txt,'')
	+ ISNULL(bs_operator_type_code,'')
	+ ISNULL(bs_cntnr_type_code,'')
	+ ISNULL(CONVERT(varchar(50), ssuid_vol_amt),'')
	+ ISNULL(pathogen_class_type_code,'')
	+ ISNULL(polut_loading_rates_exceedance_ind,'')
	+ ISNULL(surf_dspl_without_liner_ind,'')
	+ ISNULL(surf_dspl_site_spec_lmt_ind,'')
	+ ISNULL(surf_dspl_min_boundary_distance_code,'')
	+ ISNULL(bs_off_site_fac_prmt_ident,'')
);
UPDATE dbo.ics_prmt_comp_type
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  prmt_comp_type_code
);
UPDATE dbo.ics_prmt_featr
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', dbo.ics_prmt_featr.prmt_ident + prmt_featr_ident),
      data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ prmt_featr_ident
	+ ISNULL(prmt_featr_type_code,'')
	+ ISNULL(prmt_featr_desc,'')
	+ ISNULL(CONVERT(varchar(50), prmt_featr_dsgn_flow_num),'')
	+ ISNULL(CONVERT(varchar(50), prmt_featr_actul_aver_flow_num),'')
	+ ISNULL(prmt_featr_st_wtr_body_code,'')
	+ ISNULL(prmt_featr_st_wtr_body_name,'')
	+ ISNULL(tier_level_name,'')
	+ ISNULL(impaired_wtr_ind,'')
	+ ISNULL(tmdl_completed_ind,'')
	+ ISNULL(prmt_featr_usr_dfnd_dat_elm_1,'')
	+ ISNULL(prmt_featr_usr_dfnd_dat_elm_2,'')
	+ ISNULL(CONVERT(varchar(50), fld_size),'')
	+ ISNULL(is_site_own_by_fac,'')
	+ ISNULL(is_systm_lined_with_leachate,'')
	+ ISNULL(does_unit_hav_daily_cover,'')
	+ ISNULL(CONVERT(varchar(50), prop_boundary_distance),'')
	+ ISNULL(is_reqd_nitrate_ground_wtr,'')
	+ ISNULL(CONVERT(varchar(50), well_num),'')
	+ ISNULL(src_prmt_featr_detail_txt,'')
);
UPDATE dbo.ics_prmt_featr_char
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  prmt_featr_char
);
UPDATE dbo.ics_prmt_featr_trtmnt_type
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  prmt_featr_trtmnt_type_code
);
UPDATE dbo.ics_prmt_ident
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  prmt_ident
);
UPDATE dbo.ics_prmt_reissu
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', dbo.ics_prmt_reissu.prmt_ident),
      data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ CONVERT(varchar(50), prmt_issue_date)
	+ CONVERT(varchar(50), prmt_effective_date)
	+ CONVERT(varchar(50), prmt_expr_date)
);
UPDATE dbo.ics_prmt_schd_evt
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  schd_evt_code
	+ CONVERT(varchar(50), schd_date)
	+ ISNULL(CONVERT(varchar(50), schd_rep_rcvd_date),'')
	+ ISNULL(CONVERT(varchar(50), schd_actul_date),'')
	+ ISNULL(CONVERT(varchar(50), schd_proj_date),'')
	+ ISNULL(schd_usr_dfnd_dat_elm_1,'')
	+ ISNULL(schd_usr_dfnd_dat_elm_2,'')
	+ ISNULL(schd_evt_cmnts,'')
);
UPDATE dbo.ics_prmt_schd_evt_viol_elem
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  prmt_ident
	+ CONVERT(varchar(50), narr_cond_num)
	+ schd_evt_code
	+ CONVERT(varchar(50), schd_date)
	+ schd_viol_code
);
UPDATE dbo.ics_prmt_schd_viol
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  prmt_ident
	+ CONVERT(varchar(50), narr_cond_num)
	+ schd_evt_code
	+ CONVERT(varchar(50), schd_date)
);
UPDATE dbo.ics_prmt_term
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', dbo.ics_prmt_term.prmt_ident),
      data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ CONVERT(varchar(50), prmt_term_date)
);
UPDATE dbo.ics_prmt_track_evt
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', dbo.ics_prmt_track_evt.prmt_ident + prmt_track_evt_code +CONVERT(varchar(50), prmt_track_evt_date)),
      data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ prmt_track_evt_code
	+ CONVERT(varchar(50), prmt_track_evt_date)
	+ ISNULL(prmt_track_cmnts_txt,'')
);
UPDATE dbo.ics_prog
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  prog_code
);
UPDATE dbo.ics_prog_defcy_type
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  prog_defcy_type_code
);
UPDATE dbo.ics_progs_viol
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  progs_viol_code
);
UPDATE dbo.ics_proj_srcs_fund
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  proj_srcs_fund_code
);
UPDATE dbo.ics_proj_type
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  proj_type_code
	+ ISNULL(proj_type_code_othr_desc,'')
);
UPDATE dbo.ics_proposed_cnst_sw_bm_ps
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  proposed_cnst_sw_bmp_code
	+ ISNULL(proposed_cnst_sw_bmp_othr_txt,'')
);
UPDATE dbo.ics_proposed_indst_sw_bm_ps
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  proposed_indst_sw_bmp_code
	+ ISNULL(proposed_indst_sw_bmp_othr_txt,'')
);
UPDATE dbo.ics_proposed_post_cnst_sw_bm_ps
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  proposed_post_cnst_sw_bmp_code
	+ ISNULL(proposed_post_cnst_sw_bmp_othr_txt,'')
);
UPDATE dbo.ics_rep_non_cmpl_stat
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(CONVERT(varchar(50), rep_non_cmpl_stat_code_year),'')
	+ ISNULL(CONVERT(varchar(50), rep_non_cmpl_stat_code_quarter),'')
	+ ISNULL(rep_non_cmpl_manual_stat_code,'')
);
UPDATE dbo.ics_rep_param
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  param_code
	+ mon_site_desc_code
	+ CONVERT(varchar(50), lmt_season_num)
	+ ISNULL(rep_smpl_type_txt,'')
	+ ISNULL(rep_freq_code,'')
	+ ISNULL(CONVERT(varchar(50), rep_num_of_excursions),'')
	+ ISNULL(concen_num_rep_unit_meas_code,'')
	+ ISNULL(qty_num_rep_unit_meas_code,'')
);
UPDATE dbo.ics_residual_desgn_dtrmn
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  residual_desgn_dtrmn_code
	+ ISNULL(residual_desgn_dtrmn_othr_txt,'')
);
UPDATE dbo.ics_satl_coll_systm
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  satl_coll_systm_ident
	+ satl_coll_systm_name
);
UPDATE dbo.ics_schd_evt_viol
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	   ISNULL(rep_non_cmpl_resl_code,'')
	+ ISNULL(CONVERT(varchar(50), rep_non_cmpl_resl_date),'')
);
UPDATE dbo.ics_sep
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  CONVERT(varchar(50), sep_ident)
	+ ISNULL(sep_desc,'')
	+ ISNULL(CONVERT(varchar(50), sep_pnlty_assessment_amt),'')
);
UPDATE dbo.ics_sewer_ovrflw_bypass_cause
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  sewer_ovrflw_bypass_cause_code
	+ ISNULL(sewer_ovrflw_bypass_cause_othr_txt,'')
);
UPDATE dbo.ics_sewer_ovrflw_bypass_corr_actn
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  sewer_ovrflw_bypass_corr_actn_code
	+ ISNULL(sewer_ovrflw_bypass_corr_actn_othr_txt,'')
);
UPDATE dbo.ics_sewer_ovrflw_bypass_evt_rep
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', prmt_ident + PROG_REP_FORM_SET_ID + CONVERT(varchar(50), PROG_REP_FORM_ID) ),
      data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ ISNULL(CONVERT(varchar(50), prog_rep_rcvd_date),'')
	+ ISNULL(CONVERT(varchar(50), prog_rep_start_date),'')
	+ ISNULL(CONVERT(varchar(50), prog_rep_end_date),'')
	+ ISNULL(elec_subm_type_code,'')
	+ ISNULL(prog_rep_npdes_dat_grp_num_code,'')
);
UPDATE dbo.ics_sewer_ovrflw_bypass_impact
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  sewer_ovrflw_bypass_impact_code
	+ ISNULL(sewer_ovrflw_bypass_impact_othr_txt,'')
);
UPDATE dbo.ics_sewer_ovrflw_bypass_rcvg_wtr
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  sewer_ovrflw_bypass_rcvg_wtr
);
UPDATE dbo.ics_sewer_ovrflw_bypass_rep_evt
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(CONVERT(varchar(50), lat_meas),'')
	+ ISNULL(CONVERT(varchar(50), long_meas),'')
	+ ISNULL(prmt_featr_ident,'')
	+ ISNULL(dsch_quantification_method_code,'')
	+ ISNULL(CONVERT(varchar(50), sewer_ovrflw_bypass_dsch_rate_gph),'')
	+ ISNULL(CONVERT(varchar(50), sewer_ovrflw_bypass_dsch_vol_gal),'')
	+ ISNULL(sewer_ovrflw_bypass_desc_txt,'')
	+ ISNULL(CONVERT(varchar(50), sewer_ovrflw_bypass_rep_req_code),'')
	+ ISNULL(wet_weather_occurance_ind,'')
	+ ISNULL(sewer_ovrflw_strct_type_code,'')
	+ ISNULL(sewer_ovrflw_strct_type_code_othr_txt,'')
	+ ISNULL(coll_systm_ident,'')
	+ ISNULL(anticipated_bypass_txt,'')
	+ ISNULL(anticipated_bypass_expect_lmt_viol,'')
	+ ISNULL(anticipated_bypass_expect_lmt_viol_txt,'')
	+ CONVERT(varchar(50), sewer_ovrflw_bypass_duration_hours)
	+ CONVERT(varchar(50), sewer_ovrflw_bypass_start_date_time)
	+ ISNULL(CONVERT(varchar(50), sewer_ovrflw_bypass_end_date_time),'')
);
UPDATE dbo.ics_sewer_ovrflw_bypass_type
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  sewer_ovrflw_bypass_type_code
);
UPDATE dbo.ics_sewer_ovrflw_trtmnt
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  sewer_ovrflw_trtmnt_code
);
UPDATE dbo.ics_sic_code
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  sic_code
	+ sic_primary_ind_code
);
UPDATE dbo.ics_siu_desgn_type
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  siu_desgn_type
);
UPDATE dbo.ics_snc_listing_months
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  snc_listing_months
);
UPDATE dbo.ics_snc_pretr_stnd_lmts_parameters
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  snc_pretr_stnd_lmts_parameters
);
UPDATE dbo.ics_sngl_evt_viol
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', dbo.ics_sngl_evt_viol.prmt_ident + sngl_evt_viol_code +CONVERT(varchar(50), sngl_evt_viol_date)),
      data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ sngl_evt_viol_code
	+ CONVERT(varchar(50), sngl_evt_viol_date)
	+ ISNULL(CONVERT(varchar(50), sngl_evt_viol_end_date),'')
	+ ISNULL(rep_non_cmpl_detect_code,'')
	+ ISNULL(CONVERT(varchar(50), rep_non_cmpl_detect_date),'')
	+ ISNULL(rep_non_cmpl_resl_code,'')
	+ ISNULL(CONVERT(varchar(50), rep_non_cmpl_resl_date),'')
	+ ISNULL(sngl_evt_usr_dfnd_fld_1,'')
	+ ISNULL(sngl_evt_usr_dfnd_fld_2,'')
	+ ISNULL(sngl_evt_usr_dfnd_fld_3,'')
	+ ISNULL(sngl_evt_usr_dfnd_fld_4,'')
	+ ISNULL(sngl_evt_usr_dfnd_fld_5,'')
	+ ISNULL(sngl_evt_cmnt_txt,'')
);
UPDATE dbo.ics_sngl_evts_viol
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  prmt_ident
	+ sngl_evt_viol_code
	+ CONVERT(varchar(50), sngl_evt_viol_date)
);
UPDATE dbo.ics_sso_insp
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(CONVERT(varchar(50), sso_evt_date),'')
	+ ISNULL(cause_sso_ovrflw_evt,'')
	+ ISNULL(CONVERT(varchar(50), lat_meas),'')
	+ ISNULL(CONVERT(varchar(50), long_meas),'')
	+ ISNULL(sso_ovrflw_loc_street,'')
	+ ISNULL(CONVERT(varchar(50), duration_sso_ovrflw_evt),'')
	+ ISNULL(CONVERT(varchar(50), sso_vol),'')
	+ ISNULL(name_rcvg_wtr,'')
	+ ISNULL(desc_stps_taken,'')
);
UPDATE dbo.ics_sso_stps
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  stps_rduce_prevnt_mitigte
	+ ISNULL(othr_stps_rduce_prevnt_mitigte,'')
);
UPDATE dbo.ics_sso_systm_comp
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  systm_comp
	+ ISNULL(othr_systm_comp,'')
);
UPDATE dbo.ics_subsector_code_plus_desc
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  subsector_code_plus_desc
);
UPDATE dbo.ics_surf_dspl_site
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(pathogen_reduction_ind,'')
	+ ISNULL(vector_reduction_ind,'')
	+ ISNULL(mgmt_practice_ind,'')
	+ ISNULL(cert_statement_ind,'')
	+ ISNULL(cert_first_name,'')
	+ ISNULL(cert_last_name,'')
	+ ISNULL(class_a_alt_used,'')
	+ ISNULL(class_a_alts_txt,'')
	+ ISNULL(class_b_alt_used,'')
	+ ISNULL(class_b_alts_txt,'')
	+ ISNULL(var_alt_used,'')
	+ ISNULL(var_alts_txt,'')
);
UPDATE dbo.ics_sw_cnst_indst_insp
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(swppp_eval_basis_code,'')
	+ ISNULL(CONVERT(varchar(50), swppp_eval_date),'')
	+ ISNULL(swppp_eval_desc_txt,'')
	+ ISNULL(CONVERT(varchar(50), no_exposure_auth_date),'')
);
UPDATE dbo.ics_sw_cnst_insp
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
null);
UPDATE dbo.ics_sw_cnst_non_cnst_insp
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
null);
UPDATE dbo.ics_sw_cnst_prmt
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', dbo.ics_sw_cnst_prmt.prmt_ident),
      data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ ISNULL(st_wtr_body_name,'')
	+ ISNULL(rcvg_ms_4_name,'')
	+ ISNULL(impaired_wtr_ind,'')
	+ ISNULL(hist_prop_ind,'')
	+ ISNULL(hist_prop_crit_met_code,'')
	+ ISNULL(species_crit_habitat_ind,'')
	+ ISNULL(species_crit_met_code,'')
	+ ISNULL(CONVERT(varchar(50), indst_acty_size),'')
	+ ISNULL(proj_type_code,'')
	+ ISNULL(CONVERT(varchar(50), est_start_date),'')
	+ ISNULL(CONVERT(varchar(50), est_complete_date),'')
	+ ISNULL(CONVERT(varchar(50), est_area_disturbed_acres_num),'')
	+ ISNULL(proj_plan_size_code,'')
	+ ISNULL(strct_demoed_ind,'')
	+ ISNULL(strct_demoed_floor_space_ind,'')
	+ ISNULL(predev_land_use_ind,'')
	+ ISNULL(erth_distrb_activities_ind,'')
	+ ISNULL(erth_distrb_emrgcy_ind,'')
	+ ISNULL(previous_sw_dsch_ind,'')
	+ ISNULL(othr_prmt_ident,'')
	+ ISNULL(cgp_ind,'')
	+ ISNULL(ms_4_dsch_ind,'')
	+ ISNULL(wtr_prox_ind,'')
	+ ISNULL(antideg_ind,'')
	+ ISNULL(trtmnt_chems_ind,'')
	+ ISNULL(cationic_chems_ind,'')
	+ ISNULL(cationic_chems_auth_ind,'')
	+ ISNULL(swppp_prep_ind,'')
	+ ISNULL(CONVERT(varchar(50), cnst_site_ttl_area),'')
	+ ISNULL(CONVERT(varchar(50), post_cnst_ttl_impervious_area),'')
	+ ISNULL(soil_fill_material_desc_txt,'')
	+ ISNULL(CONVERT(varchar(50), runoff_coefficient_post_cnst),'')
	+ ISNULL(subsurface_erth_disturbance_ind,'')
	+ ISNULL(prior_surveys_evals_ind,'')
	+ ISNULL(subsurface_erth_disturbance_control_ind,'')
	+ ISNULL(CONVERT(varchar(50), not_term_date),'')
	+ ISNULL(CONVERT(varchar(50), not_sign_date),'')
	+ ISNULL(CONVERT(varchar(50), not_postmark_date),'')
	+ ISNULL(CONVERT(varchar(50), not_rcvd_date),'')
	+ ISNULL(CONVERT(varchar(50), lew_auth_date),'')
);
UPDATE dbo.ics_sw_indst_annul_rep
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', dbo.ics_sw_indst_annul_rep.prmt_ident +CONVERT(varchar(50), indst_sw_annul_rep_rcvd_date)),
      data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ CONVERT(varchar(50), indst_sw_annul_rep_rcvd_date)
	+ ISNULL(fac_insp_summ_txt,'')
	+ ISNULL(visual_assessment_summ_txt,'')
	+ ISNULL(no_further_reduction_summ_txt,'')
	+ ISNULL(corr_actn_summ_txt,'')
);
UPDATE dbo.ics_sw_indst_prmt
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', dbo.ics_sw_indst_prmt.prmt_ident),
      data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ ISNULL(st_wtr_body_name,'')
	+ ISNULL(rcvg_ms_4_name,'')
	+ ISNULL(impaired_wtr_ind,'')
	+ ISNULL(hist_prop_ind,'')
	+ ISNULL(hist_prop_crit_met_code,'')
	+ ISNULL(species_crit_habitat_ind,'')
	+ ISNULL(species_crit_met_code,'')
	+ ISNULL(CONVERT(varchar(50), indst_acty_size),'')
	+ ISNULL(web_addr_url,'')
	+ ISNULL(activities_exposed_sw_txt,'')
	+ ISNULL(assc_pollutants_txt,'')
	+ ISNULL(control_msr_txt,'')
	+ ISNULL(schd_control_msr_txt,'')
	+ ISNULL(CONVERT(varchar(50), indst_ttl_impervious_surf_area),'')
	+ ISNULL(tier_two_ind,'')
	+ ISNULL(tier_three_ind,'')
);
UPDATE dbo.ics_sw_ms_4_insp
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(CONVERT(varchar(50), ms_4_annul_expen_dollars),'')
	+ ISNULL(CONVERT(varchar(50), ms_4_annul_expen_year),'')
	+ ISNULL(CONVERT(varchar(50), ms_4_budget_dollars),'')
	+ ISNULL(CONVERT(varchar(50), ms_4_budget_year),'')
	+ ISNULL(major_outfall_est_meas_ind,'')
	+ ISNULL(CONVERT(varchar(50), major_outfall_num),'')
	+ ISNULL(minor_outfall_est_meas_ind,'')
	+ ISNULL(CONVERT(varchar(50), minor_outfall_num),'')
);
UPDATE dbo.ics_sw_non_cnst_insp
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
null);
UPDATE dbo.ics_sw_unprmt_cnst_insp
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  ISNULL(CONVERT(varchar(50), est_start_date),'')
	+ ISNULL(CONVERT(varchar(50), est_complete_date),'')
	+ ISNULL(CONVERT(varchar(50), est_area_disturbed_acres_num),'')
	+ ISNULL(proj_plan_size_code,'')
);
UPDATE dbo.ics_swms_4_annul_prog_rep
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', prmt_ident + PROG_REP_FORM_SET_ID + CONVERT(varchar(50), PROG_REP_FORM_ID) ),
      data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ ISNULL(CONVERT(varchar(50), prog_rep_rcvd_date),'')
	+ ISNULL(CONVERT(varchar(50), prog_rep_start_date),'')
	+ ISNULL(CONVERT(varchar(50), prog_rep_end_date),'')
	+ ISNULL(elec_subm_type_code,'')
	+ ISNULL(prog_rep_npdes_dat_grp_num_code,'')
);
UPDATE dbo.ics_swms_4_prmt
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', dbo.ics_swms_4_prmt.prmt_ident),
      data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ ISNULL(ms_4_prmt_phase_code,'')
	+ ISNULL(ms_4_prmt_phase_txt,'')
);
UPDATE dbo.ics_teleph
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  teleph_num_type_code
	+ ISNULL(teleph_num,'')
	+ ISNULL(teleph_ext_num,'')
);
UPDATE dbo.ics_tmdl_pollutants
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  tmdl_ident
	+ tmdl_name
);
UPDATE dbo.ics_tmdl_polut
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  CONVERT(varchar(50), tmdl_polut_code)
);
UPDATE dbo.ics_trtmnt_chems_list
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  trtmnt_chems_list
);
UPDATE dbo.ics_unprmt_fac
   SET key_hash = dbo.HASHBYTES_VARCHAR('SHA1', dbo.ics_unprmt_fac.prmt_ident),
      data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	   prmt_ident
	+ ISNULL(locality_name,'')
	+ ISNULL(loc_addr_city_code,'')
	+ ISNULL(loc_addr_county_code,'')
	+ ISNULL(fac_site_name,'')
	+ ISNULL(loc_addr_txt,'')
	+ ISNULL(suppl_loc_txt,'')
	+ ISNULL(loc_st_code,'')
	+ ISNULL(loc_zip_code,'')
	+ ISNULL(loc_country_code,'')
	+ ISNULL(org_duns_num,'')
	+ ISNULL(st_fac_ident,'')
	+ ISNULL(st_rgn_code,'')
	+ ISNULL(CONVERT(varchar(50), fac_congr_district_num),'')
	+ ISNULL(fac_type_of_ownership_code,'')
	+ ISNULL(fedr_fac_ident_num,'')
	+ ISNULL(fedr_agncy_code,'')
	+ ISNULL(tribal_land_code,'')
	+ ISNULL(cnst_proj_name,'')
	+ ISNULL(CONVERT(varchar(50), cnst_proj_lat_meas),'')
	+ ISNULL(CONVERT(varchar(50), cnst_proj_long_meas),'')
	+ ISNULL(section_township_rng,'')
	+ ISNULL(fac_cmnts,'')
	+ ISNULL(fac_usr_dfnd_fld_1,'')
	+ ISNULL(fac_usr_dfnd_fld_2,'')
	+ ISNULL(fac_usr_dfnd_fld_3,'')
	+ ISNULL(fac_usr_dfnd_fld_4,'')
	+ ISNULL(fac_usr_dfnd_fld_5,'')
	+ ISNULL(prmt_cmnts_txt,'')
);
UPDATE dbo.ics_vector_a_reduction_type
    SET data_hash = dbo.HASHBYTES_VARCHAR('SHA1', 
	  vector_a_reduction_type_code
);

--Create KEY_HASH for modules with conditional keys (5 data families)

UPDATE dbo.ics_cmpl_mon_lnk
   SET KEY_HASH = dbo.HASHBYTES_VARCHAR('SHA1',
						ics_cmpl_mon_lnk.cmpl_mon_ident
                         + COALESCE(
                                   ics_lnk_cmpl_mon.cmpl_mon_ident
								   ,ics_lnk_enfrc_actn.enfrc_actn_ident
                                   ,CONCAT(
										ics_lnk_sngl_evt.prmt_ident
										,ics_lnk_sngl_evt.sngl_evt_viol_code
										,CONVERT(varchar(50), ics_lnk_sngl_evt.sngl_evt_viol_date)
                                    ) 
                         )
						)
	FROM dbo.ics_cmpl_mon_lnk ics_cmpl_mon_lnk
		LEFT JOIN dbo.ics_lnk_cmpl_mon ics_lnk_cmpl_mon on ics_lnk_cmpl_mon.ics_cmpl_mon_lnk_id = ics_cmpl_mon_lnk.ics_cmpl_mon_lnk_id
		LEFT JOIN dbo.ics_lnk_enfrc_actn ics_lnk_enfrc_actn on ics_lnk_enfrc_actn.ics_cmpl_mon_lnk_id = ics_cmpl_mon_lnk.ics_cmpl_mon_lnk_id
		LEFT JOIN dbo.ics_lnk_sngl_evt ics_lnk_sngl_evt on ics_lnk_sngl_evt.ics_cmpl_mon_lnk_id = ics_cmpl_mon_lnk.ics_cmpl_mon_lnk_id
;


-- 2025-04-13 CRT: new method
-- ------------------------------
-- ICS_SCHD_EVT_VIOL

   update [dbo].[ICS_SCHD_EVT_VIOL] 
  set KEY_HASH = dbo.HASHBYTES_VARCHAR('SHA1',
	   concat(
	   PRMT_IDENT
	   ,NARR_COND_NUM
	   ,SCHD_EVT_CODE
	   ,SCHD_DATE
	   ,SCHD_VIOL_CODE
	   ))
 from [dbo].[ICS_SCHD_EVT_VIOL] [ICS_SCHD_EVT_VIOL]    JOIN [dbo].[ICS_PRMT_SCHD_EVT_VIOL_ELEM] [I1]   ON [I1].[ICS_SCHD_EVT_VIOL_ID] = [ICS_SCHD_EVT_VIOL].[ICS_SCHD_EVT_VIOL_ID]   
 ;

  update [ICS_SCHD_EVT_VIOL] 
  set KEY_HASH = dbo.HASHBYTES_VARCHAR('SHA1',
	   concat(
	   ENFRC_ACTN_IDENT
	   ,FINAL_ORDER_IDENT
	   ,PRMT_IDENT
	   ,CMPL_SCHD_NUM
	   ,SCHD_EVT_CODE
	   ,SCHD_DATE
	   ))
  from [dbo].[ICS_SCHD_EVT_VIOL] [ICS_SCHD_EVT_VIOL]    JOIN [dbo].[ICS_CMPL_SCHD_EVT_VIOL_ELEM] [I2]   ON [I2].[ICS_SCHD_EVT_VIOL_ID] = [ICS_SCHD_EVT_VIOL].[ICS_SCHD_EVT_VIOL_ID]   
;
  

-- 2025-04-13 CRT: try new method
-- ------------------------------
-- ICS_ENFRC_ACTN_VIOL_LNK
update [dbo].ICS_ENFRC_ACTN_VIOL_LNK set KEY_HASH = 
(select KEY_HASH from
(

	-- DMR (DMR Parameter)
	select 
	[ICS_ENFRC_ACTN_VIOL_LNK].[ICS_ENFRC_ACTN_VIOL_LNK_ID],
	   dbo.HASHBYTES_VARCHAR('SHA1',
	   concat(
	[ICS_ENFRC_ACTN_VIOL_LNK].ENFRC_ACTN_IDENT
	,PRMT_IDENT
	,PRMT_FEATR_IDENT
	,LMT_SET_DESIGNATOR
	,MON_PERIOD_END_DATE
	,PARAM_CODE
	,MON_SITE_DESC_CODE
	,LMT_SEASON_NUM
	)) as KEY_HASH
	from [dbo].[ICS_ENFRC_ACTN_VIOL_LNK] [ICS_ENFRC_ACTN_VIOL_LNK]    JOIN [dbo].[ICS_DSCH_MON_REP_PARAM_VIOL] [I1]   ON [I1].[ICS_ENFRC_ACTN_VIOL_LNK_ID] = [ICS_ENFRC_ACTN_VIOL_LNK].[ICS_ENFRC_ACTN_VIOL_LNK_ID]   

	UNION ALL
	-- DV (DMR)
	select 
	[ICS_ENFRC_ACTN_VIOL_LNK].[ICS_ENFRC_ACTN_VIOL_LNK_ID],
	   dbo.HASHBYTES_VARCHAR('SHA1',
	   concat(
	[ICS_ENFRC_ACTN_VIOL_LNK].ENFRC_ACTN_IDENT
	,PRMT_IDENT
	,PRMT_FEATR_IDENT
	,LMT_SET_DESIGNATOR
	,MON_PERIOD_END_DATE
	))
	from [dbo].[ICS_ENFRC_ACTN_VIOL_LNK] [ICS_ENFRC_ACTN_VIOL_LNK]    JOIN [dbo].[ICS_DSCH_MON_REP_VIOL] [I2]   ON [I2].[ICS_ENFRC_ACTN_VIOL_LNK_ID] = [ICS_ENFRC_ACTN_VIOL_LNK].[ICS_ENFRC_ACTN_VIOL_LNK_ID]   

	UNION ALL
	-- Permit ScheduleViolation 
	select
	[ICS_ENFRC_ACTN_VIOL_LNK].[ICS_ENFRC_ACTN_VIOL_LNK_ID],
	   dbo.HASHBYTES_VARCHAR('SHA1',
	   concat(
	[ICS_ENFRC_ACTN_VIOL_LNK].ENFRC_ACTN_IDENT
	,PRMT_IDENT
	,NARR_COND_NUM
	,SCHD_EVT_CODE
	,SCHD_DATE
	))
	from [dbo].[ICS_ENFRC_ACTN_VIOL_LNK] [ICS_ENFRC_ACTN_VIOL_LNK]    JOIN [dbo].[ICS_PRMT_SCHD_VIOL] [I3]   ON [I3].[ICS_ENFRC_ACTN_VIOL_LNK_ID] = [ICS_ENFRC_ACTN_VIOL_LNK].[ICS_ENFRC_ACTN_VIOL_LNK_ID]   

	UNION ALL
	-- SEV
	select 
	[ICS_ENFRC_ACTN_VIOL_LNK].[ICS_ENFRC_ACTN_VIOL_LNK_ID],
	   dbo.HASHBYTES_VARCHAR('SHA1',
	   concat(
	[ICS_ENFRC_ACTN_VIOL_LNK].ENFRC_ACTN_IDENT
	,PRMT_IDENT
	,SNGL_EVT_VIOL_CODE
	,SNGL_EVT_VIOL_DATE
	))
	from [dbo].[ICS_ENFRC_ACTN_VIOL_LNK] [ICS_ENFRC_ACTN_VIOL_LNK]    JOIN [dbo].[ICS_SNGL_EVTS_VIOL] [I4]   ON [I4].[ICS_ENFRC_ACTN_VIOL_LNK_ID] = [ICS_ENFRC_ACTN_VIOL_LNK].[ICS_ENFRC_ACTN_VIOL_LNK_ID]   

	UNION ALL
	-- CS  Compliance Schedule Violation
	select  
	[ICS_ENFRC_ACTN_VIOL_LNK].[ICS_ENFRC_ACTN_VIOL_LNK_ID],
	   dbo.HASHBYTES_VARCHAR('SHA1',
	   concat(
	[ICS_ENFRC_ACTN_VIOL_LNK].ENFRC_ACTN_IDENT
	,FINAL_ORDER_IDENT
	,PRMT_IDENT
	,CMPL_SCHD_NUM
	,SCHD_EVT_CODE
	,SCHD_DATE
	))
	from [dbo].[ICS_ENFRC_ACTN_VIOL_LNK] [ICS_ENFRC_ACTN_VIOL_LNK]    JOIN [dbo].[ICS_CMPL_SCHD_VIOL] [I5]   ON [I5].[ICS_ENFRC_ACTN_VIOL_LNK_ID] = [ICS_ENFRC_ACTN_VIOL_LNK].[ICS_ENFRC_ACTN_VIOL_LNK_ID]   

) vw
where
vw.ICS_ENFRC_ACTN_VIOL_LNK_ID = ICS_ENFRC_ACTN_VIOL_LNK.ICS_ENFRC_ACTN_VIOL_LNK_ID)
;


-- 2025-04-13 CRT: try new method
-- ------------------------------
-- ICS_FINAL_ORDER_VIOL_LNK
update [dbo].ICS_FINAL_ORDER_VIOL_LNK set KEY_HASH = 
(select KEY_HASH from
(

	-- DMR (DMR Parameter)
	select 
	[ICS_FINAL_ORDER_VIOL_LNK].[ICS_FINAL_ORDER_VIOL_LNK_ID],
	   dbo.HASHBYTES_VARCHAR('SHA1',
	   concat(
	[ICS_FINAL_ORDER_VIOL_LNK].ENFRC_ACTN_IDENT
	,[ICS_FINAL_ORDER_VIOL_LNK].FINAL_ORDER_IDENT
	,PRMT_IDENT
	,PRMT_FEATR_IDENT
	,LMT_SET_DESIGNATOR
	,MON_PERIOD_END_DATE
	,PARAM_CODE
	,MON_SITE_DESC_CODE
	,LMT_SEASON_NUM
	)) as KEY_HASH
	from [dbo].[ICS_FINAL_ORDER_VIOL_LNK] [ICS_FINAL_ORDER_VIOL_LNK]    JOIN [dbo].[ICS_DSCH_MON_REP_PARAM_VIOL] [I1]   ON [I1].[ICS_FINAL_ORDER_VIOL_LNK_ID] = [ICS_FINAL_ORDER_VIOL_LNK].[ICS_FINAL_ORDER_VIOL_LNK_ID]   

	UNION ALL
	-- DV (DMR)
	select 
	[ICS_FINAL_ORDER_VIOL_LNK].[ICS_FINAL_ORDER_VIOL_LNK_ID],
	   dbo.HASHBYTES_VARCHAR('SHA1',
	   concat(
	[ICS_FINAL_ORDER_VIOL_LNK].ENFRC_ACTN_IDENT
	,[ICS_FINAL_ORDER_VIOL_LNK].FINAL_ORDER_IDENT
	,PRMT_IDENT
	,PRMT_FEATR_IDENT
	,LMT_SET_DESIGNATOR
	,MON_PERIOD_END_DATE
	))
	from [dbo].[ICS_FINAL_ORDER_VIOL_LNK] [ICS_FINAL_ORDER_VIOL_LNK]    JOIN [dbo].[ICS_DSCH_MON_REP_VIOL] [I2]   ON [I2].[ICS_FINAL_ORDER_VIOL_LNK_ID] = [ICS_FINAL_ORDER_VIOL_LNK].[ICS_FINAL_ORDER_VIOL_LNK_ID]   

	UNION ALL
	-- Permit ScheduleViolation 
	select
	[ICS_FINAL_ORDER_VIOL_LNK].[ICS_FINAL_ORDER_VIOL_LNK_ID],
	   dbo.HASHBYTES_VARCHAR('SHA1',
	   concat(
	[ICS_FINAL_ORDER_VIOL_LNK].ENFRC_ACTN_IDENT
	,[ICS_FINAL_ORDER_VIOL_LNK].FINAL_ORDER_IDENT
	,PRMT_IDENT
	,NARR_COND_NUM
	,SCHD_EVT_CODE
	,SCHD_DATE
	))
	from [dbo].[ICS_FINAL_ORDER_VIOL_LNK] [ICS_FINAL_ORDER_VIOL_LNK]    JOIN [dbo].[ICS_PRMT_SCHD_VIOL] [I3]   ON [I3].[ICS_FINAL_ORDER_VIOL_LNK_ID] = [ICS_FINAL_ORDER_VIOL_LNK].[ICS_FINAL_ORDER_VIOL_LNK_ID]   

	UNION ALL
	-- SEV
	select 
	[ICS_FINAL_ORDER_VIOL_LNK].[ICS_FINAL_ORDER_VIOL_LNK_ID],
	   dbo.HASHBYTES_VARCHAR('SHA1',
	   concat(
	[ICS_FINAL_ORDER_VIOL_LNK].ENFRC_ACTN_IDENT
	,[ICS_FINAL_ORDER_VIOL_LNK].FINAL_ORDER_IDENT
	,PRMT_IDENT
	,SNGL_EVT_VIOL_CODE
	,SNGL_EVT_VIOL_DATE
	))
	from [dbo].[ICS_FINAL_ORDER_VIOL_LNK] [ICS_FINAL_ORDER_VIOL_LNK]    JOIN [dbo].[ICS_SNGL_EVTS_VIOL] [I4]   ON [I4].[ICS_FINAL_ORDER_VIOL_LNK_ID] = [ICS_FINAL_ORDER_VIOL_LNK].[ICS_FINAL_ORDER_VIOL_LNK_ID]   

	UNION ALL
	-- CS  Compliance Schedule Violation
	select  
	[ICS_FINAL_ORDER_VIOL_LNK].[ICS_FINAL_ORDER_VIOL_LNK_ID],
	   dbo.HASHBYTES_VARCHAR('SHA1',
	   concat(
	[ICS_FINAL_ORDER_VIOL_LNK].ENFRC_ACTN_IDENT
	,[ICS_FINAL_ORDER_VIOL_LNK].FINAL_ORDER_IDENT
	,I5.FINAL_ORDER_IDENT
	,PRMT_IDENT
	,CMPL_SCHD_NUM
	,SCHD_EVT_CODE
	,SCHD_DATE
	))
	from [dbo].[ICS_FINAL_ORDER_VIOL_LNK] [ICS_FINAL_ORDER_VIOL_LNK]    JOIN [dbo].[ICS_CMPL_SCHD_VIOL] [I5]   ON [I5].[ICS_FINAL_ORDER_VIOL_LNK_ID] = [ICS_FINAL_ORDER_VIOL_LNK].[ICS_FINAL_ORDER_VIOL_LNK_ID]   

) vw
where
vw.ICS_FINAL_ORDER_VIOL_LNK_ID = ICS_FINAL_ORDER_VIOL_LNK.ICS_FINAL_ORDER_VIOL_LNK_ID)
;


  /************************************/  
  /* START - Process DATA_HASH values */
  /* START - Process DATA_HASH values */
  /* START - Process DATA_HASH values */
  /************************************/ 
 

  /*****************************************************************************/
  /* START - Set-based DATA_HASH roll-up (replaces nested cursor loops)        */
  /* Each block collects all child data_hash values for every key_hash         */
  /* and writes a single SHA1 of their sorted concatenation to the parent.     */
  /*****************************************************************************/

  -- [1] ICS_BASIC_PRMT
  IF EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P
             JOIN dbo.ICS_BASIC_PRMT C ON P.ICS_PAYLOAD_ID = C.ICS_PAYLOAD_ID
             WHERE P.ENABLED = 'Y')
  BEGIN
    ;WITH all_hashes (key_hash, data_hash) AS (

				
			 
				-- /[dbo].[ICS_BASIC_PRMT] 
				
				SELECT KEY_HASH, ICS_BASIC_PRMT.DATA_HASH 
				 from [dbo].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
				
			 
				-- /[dbo].[ICS_BASIC_PRMT]/[dbo].[ICS_CONTACT] 
				 UNION ALL 
				SELECT KEY_HASH, I1.DATA_HASH 
				 from [dbo].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [dbo].[ICS_CONTACT] [I1]
 ON [I1].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
				
			 
				-- /[dbo].[ICS_BASIC_PRMT]/[dbo].[ICS_CONTACT]/[dbo].[ICS_TELEPH] 
				 UNION ALL 
				SELECT KEY_HASH, I2.DATA_HASH 
				 from [dbo].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [dbo].[ICS_CONTACT] [I1]
 ON [I1].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 JOIN [dbo].[ICS_TELEPH] [I2]
 ON [I2].[ICS_CONTACT_ID] = [I1].[ICS_CONTACT_ID] 
				
			 
				-- /[dbo].[ICS_BASIC_PRMT]/[dbo].[ICS_NPDES_DAT_GRP_NUM] 
				 UNION ALL 
				SELECT KEY_HASH, I3.DATA_HASH 
				 from [dbo].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [dbo].[ICS_NPDES_DAT_GRP_NUM] [I3]
 ON [I3].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
				
			 
				-- /[dbo].[ICS_BASIC_PRMT]/[dbo].[ICS_OTHR_PRMTS] 
				 UNION ALL 
				SELECT KEY_HASH, I4.DATA_HASH 
				 from [dbo].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [dbo].[ICS_OTHR_PRMTS] [I4]
 ON [I4].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
				
			 
				-- /[dbo].[ICS_BASIC_PRMT]/[dbo].[ICS_EFFLU_GUIDE] 
				 UNION ALL 
				SELECT KEY_HASH, I5.DATA_HASH 
				 from [dbo].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [dbo].[ICS_EFFLU_GUIDE] [I5]
 ON [I5].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
				
			 
				-- /[dbo].[ICS_BASIC_PRMT]/[dbo].[ICS_FAC] 
				 UNION ALL 
				SELECT KEY_HASH, I6.DATA_HASH 
				 from [dbo].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [dbo].[ICS_FAC] [I6]
 ON [I6].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
				
			 
				-- /[dbo].[ICS_BASIC_PRMT]/[dbo].[ICS_FAC]/[dbo].[ICS_CONTACT] 
				 UNION ALL 
				SELECT KEY_HASH, I7.DATA_HASH 
				 from [dbo].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [dbo].[ICS_FAC] [I6]
 ON [I6].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 JOIN [dbo].[ICS_CONTACT] [I7]
 ON [I7].[ICS_FAC_ID] = [I6].[ICS_FAC_ID] 
				
			 
				-- /[dbo].[ICS_BASIC_PRMT]/[dbo].[ICS_FAC]/[dbo].[ICS_CONTACT]/[dbo].[ICS_TELEPH] 
				 UNION ALL 
				SELECT KEY_HASH, I8.DATA_HASH 
				 from [dbo].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [dbo].[ICS_FAC] [I6]
 ON [I6].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 JOIN [dbo].[ICS_CONTACT] [I7]
 ON [I7].[ICS_FAC_ID] = [I6].[ICS_FAC_ID] 
 JOIN [dbo].[ICS_TELEPH] [I8]
 ON [I8].[ICS_CONTACT_ID] = [I7].[ICS_CONTACT_ID] 
				
			 
				-- /[dbo].[ICS_BASIC_PRMT]/[dbo].[ICS_FAC]/[dbo].[ICS_ORIG_PROGS] 
				 UNION ALL 
				SELECT KEY_HASH, I9.DATA_HASH 
				 from [dbo].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [dbo].[ICS_FAC] [I6]
 ON [I6].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 JOIN [dbo].[ICS_ORIG_PROGS] [I9]
 ON [I9].[ICS_FAC_ID] = [I6].[ICS_FAC_ID] 
				
			 
				-- /[dbo].[ICS_BASIC_PRMT]/[dbo].[ICS_FAC]/[dbo].[ICS_PLCY] 
				 UNION ALL 
				SELECT KEY_HASH, I10.DATA_HASH 
				 from [dbo].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [dbo].[ICS_FAC] [I6]
 ON [I6].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 JOIN [dbo].[ICS_PLCY] [I10]
 ON [I10].[ICS_FAC_ID] = [I6].[ICS_FAC_ID] 
				
			 
				-- /[dbo].[ICS_BASIC_PRMT]/[dbo].[ICS_FAC]/[dbo].[ICS_FAC_CLASS] 
				 UNION ALL 
				SELECT KEY_HASH, I11.DATA_HASH 
				 from [dbo].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [dbo].[ICS_FAC] [I6]
 ON [I6].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 JOIN [dbo].[ICS_FAC_CLASS] [I11]
 ON [I11].[ICS_FAC_ID] = [I6].[ICS_FAC_ID] 
				
			 
				-- /[dbo].[ICS_BASIC_PRMT]/[dbo].[ICS_FAC]/[dbo].[ICS_GEO_COORD] 
				 UNION ALL 
				SELECT KEY_HASH, I12.DATA_HASH 
				 from [dbo].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [dbo].[ICS_FAC] [I6]
 ON [I6].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 JOIN [dbo].[ICS_GEO_COORD] [I12]
 ON [I12].[ICS_FAC_ID] = [I6].[ICS_FAC_ID] 
				
			 
				-- /[dbo].[ICS_BASIC_PRMT]/[dbo].[ICS_FAC]/[dbo].[ICS_SIC_CODE] 
				 UNION ALL 
				SELECT KEY_HASH, I13.DATA_HASH 
				 from [dbo].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [dbo].[ICS_FAC] [I6]
 ON [I6].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 JOIN [dbo].[ICS_SIC_CODE] [I13]
 ON [I13].[ICS_FAC_ID] = [I6].[ICS_FAC_ID] 
				
			 
				-- /[dbo].[ICS_BASIC_PRMT]/[dbo].[ICS_FAC]/[dbo].[ICS_ADDR] 
				 UNION ALL 
				SELECT KEY_HASH, I14.DATA_HASH 
				 from [dbo].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [dbo].[ICS_FAC] [I6]
 ON [I6].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 JOIN [dbo].[ICS_ADDR] [I14]
 ON [I14].[ICS_FAC_ID] = [I6].[ICS_FAC_ID] 
				
			 
				-- /[dbo].[ICS_BASIC_PRMT]/[dbo].[ICS_FAC]/[dbo].[ICS_ADDR]/[dbo].[ICS_TELEPH] 
				 UNION ALL 
				SELECT KEY_HASH, I15.DATA_HASH 
				 from [dbo].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [dbo].[ICS_FAC] [I6]
 ON [I6].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 JOIN [dbo].[ICS_ADDR] [I14]
 ON [I14].[ICS_FAC_ID] = [I6].[ICS_FAC_ID] 
 JOIN [dbo].[ICS_TELEPH] [I15]
 ON [I15].[ICS_ADDR_ID] = [I14].[ICS_ADDR_ID] 
				
			 
				-- /[dbo].[ICS_BASIC_PRMT]/[dbo].[ICS_FAC]/[dbo].[ICS_NAICS_CODE] 
				 UNION ALL 
				SELECT KEY_HASH, I16.DATA_HASH 
				 from [dbo].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [dbo].[ICS_FAC] [I6]
 ON [I6].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 JOIN [dbo].[ICS_NAICS_CODE] [I16]
 ON [I16].[ICS_FAC_ID] = [I6].[ICS_FAC_ID] 
				
			 
				-- /[dbo].[ICS_BASIC_PRMT]/[dbo].[ICS_REP_NON_CMPL_STAT] 
				 UNION ALL 
				SELECT KEY_HASH, I17.DATA_HASH 
				 from [dbo].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [dbo].[ICS_REP_NON_CMPL_STAT] [I17]
 ON [I17].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
				
			 
				-- /[dbo].[ICS_BASIC_PRMT]/[dbo].[ICS_RESIDUAL_DESGN_DTRMN] 
				 UNION ALL 
				SELECT KEY_HASH, I18.DATA_HASH 
				 from [dbo].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [dbo].[ICS_RESIDUAL_DESGN_DTRMN] [I18]
 ON [I18].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
				
			 
				-- /[dbo].[ICS_BASIC_PRMT]/[dbo].[ICS_SIC_CODE] 
				 UNION ALL 
				SELECT KEY_HASH, I19.DATA_HASH 
				 from [dbo].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [dbo].[ICS_SIC_CODE] [I19]
 ON [I19].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
				
			 
				-- /[dbo].[ICS_BASIC_PRMT]/[dbo].[ICS_SIU_DESGN_TYPE] 
				 UNION ALL 
				SELECT KEY_HASH, I20.DATA_HASH 
				 from [dbo].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [dbo].[ICS_SIU_DESGN_TYPE] [I20]
 ON [I20].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
				
			 
				-- /[dbo].[ICS_BASIC_PRMT]/[dbo].[ICS_ADDR] 
				 UNION ALL 
				SELECT KEY_HASH, I21.DATA_HASH 
				 from [dbo].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [dbo].[ICS_ADDR] [I21]
 ON [I21].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
				
			 
				-- /[dbo].[ICS_BASIC_PRMT]/[dbo].[ICS_ADDR]/[dbo].[ICS_TELEPH] 
				 UNION ALL 
				SELECT KEY_HASH, I22.DATA_HASH 
				 from [dbo].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [dbo].[ICS_ADDR] [I21]
 ON [I21].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
 JOIN [dbo].[ICS_TELEPH] [I22]
 ON [I22].[ICS_ADDR_ID] = [I21].[ICS_ADDR_ID] 
				
			 
				-- /[dbo].[ICS_BASIC_PRMT]/[dbo].[ICS_ASSC_PRMT] 
				 UNION ALL 
				SELECT KEY_HASH, I23.DATA_HASH 
				 from [dbo].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [dbo].[ICS_ASSC_PRMT] [I23]
 ON [I23].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
				
			 
				-- /[dbo].[ICS_BASIC_PRMT]/[dbo].[ICS_CMPL_TRACK_STAT] 
				 UNION ALL 
				SELECT KEY_HASH, I24.DATA_HASH 
				 from [dbo].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [dbo].[ICS_CMPL_TRACK_STAT] [I24]
 ON [I24].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
				
			 
				-- /[dbo].[ICS_BASIC_PRMT]/[dbo].[ICS_NAICS_CODE] 
				 UNION ALL 
				SELECT KEY_HASH, I25.DATA_HASH 
				 from [dbo].[ICS_BASIC_PRMT] [ICS_BASIC_PRMT] 
 JOIN [dbo].[ICS_NAICS_CODE] [I25]
 ON [I25].[ICS_BASIC_PRMT_ID] = [ICS_BASIC_PRMT].[ICS_BASIC_PRMT_ID] 
							  
    ),
    rolled (key_hash, rolled_hash) AS (
      SELECT
        key_hash,
        dbo.HASHBYTES_VARCHAR('SHA1',
          STRING_AGG(cast(data_hash as varchar(max)), '') WITHIN GROUP (ORDER BY data_hash)
        ) AS rolled_hash
      FROM all_hashes
      GROUP BY key_hash
    )
    UPDATE p
       SET p.data_hash = r.rolled_hash
      FROM dbo.ICS_BASIC_PRMT p
      JOIN rolled r ON r.key_hash = p.key_hash;
  END;

  -- [2] ICS_BS_ANNUL_PROG_REP
  IF EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P
             JOIN dbo.ICS_BS_ANNUL_PROG_REP C ON P.ICS_PAYLOAD_ID = C.ICS_PAYLOAD_ID
             WHERE P.ENABLED = 'Y')
  BEGIN
    ;WITH all_hashes (key_hash, data_hash) AS (

				
			 
				-- /[dbo].[ICS_BS_ANNUL_PROG_REP] 
				
				SELECT KEY_HASH, ICS_BS_ANNUL_PROG_REP.DATA_HASH 
				 from [dbo].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
				
			 
				-- /[dbo].[ICS_BS_ANNUL_PROG_REP]/[dbo].[ICS_ANLYTCL_METHOD] 
				 UNION ALL 
				SELECT KEY_HASH, I1.DATA_HASH 
				 from [dbo].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [dbo].[ICS_ANLYTCL_METHOD] [I1]
 ON [I1].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
				
			 
				-- /[dbo].[ICS_BS_ANNUL_PROG_REP]/[dbo].[ICS_BS_FAC_TRTMNT] 
				 UNION ALL 
				SELECT KEY_HASH, I2.DATA_HASH 
				 from [dbo].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [dbo].[ICS_BS_FAC_TRTMNT] [I2]
 ON [I2].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
				
			 
				-- /[dbo].[ICS_BS_ANNUL_PROG_REP]/[dbo].[ICS_BS_FAC_TYPE] 
				 UNION ALL 
				SELECT KEY_HASH, I3.DATA_HASH 
				 from [dbo].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [dbo].[ICS_BS_FAC_TYPE] [I3]
 ON [I3].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
				
			 
				-- /[dbo].[ICS_BS_ANNUL_PROG_REP]/[dbo].[ICS_BS_MGMT_PRACTICE] 
				 UNION ALL 
				SELECT KEY_HASH, I4.DATA_HASH 
				 from [dbo].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [dbo].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
				
			 
				-- /[dbo].[ICS_BS_ANNUL_PROG_REP]/[dbo].[ICS_BS_MGMT_PRACTICE]/[dbo].[ICS_PATHOGEN_REDUCTION_TYPE] 
				 UNION ALL 
				SELECT KEY_HASH, I5.DATA_HASH 
				 from [dbo].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [dbo].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [dbo].[ICS_PATHOGEN_REDUCTION_TYPE] [I5]
 ON [I5].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
				
			 
				-- /[dbo].[ICS_BS_ANNUL_PROG_REP]/[dbo].[ICS_BS_MGMT_PRACTICE]/[dbo].[ICS_BS_INCINERATION] 
				 UNION ALL 
				SELECT KEY_HASH, I6.DATA_HASH 
				 from [dbo].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [dbo].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [dbo].[ICS_BS_INCINERATION] [I6]
 ON [I6].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
				
			 
				-- /[dbo].[ICS_BS_ANNUL_PROG_REP]/[dbo].[ICS_BS_MGMT_PRACTICE]/[dbo].[ICS_BS_INCINERATION]/[dbo].[ICS_BS_INCIN_EMISSIONS_CONTROL_TYPE] 
				 UNION ALL 
				SELECT KEY_HASH, I7.DATA_HASH 
				 from [dbo].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [dbo].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [dbo].[ICS_BS_INCINERATION] [I6]
 ON [I6].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
 JOIN [dbo].[ICS_BS_INCIN_EMISSIONS_CONTROL_TYPE] [I7]
 ON [I7].[ICS_BS_INCINERATION_ID] = [I6].[ICS_BS_INCINERATION_ID] 
				
			 
				-- /[dbo].[ICS_BS_ANNUL_PROG_REP]/[dbo].[ICS_BS_MGMT_PRACTICE]/[dbo].[ICS_BS_INCINERATION]/[dbo].[ICS_BS_SEWAGE_SLDG_PARAM] 
				 UNION ALL 
				SELECT KEY_HASH, I8.DATA_HASH 
				 from [dbo].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [dbo].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [dbo].[ICS_BS_INCINERATION] [I6]
 ON [I6].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
 JOIN [dbo].[ICS_BS_SEWAGE_SLDG_PARAM] [I8]
 ON [I8].[ICS_BS_INCINERATION_ID] = [I6].[ICS_BS_INCINERATION_ID] 
				
			 
				-- /[dbo].[ICS_BS_ANNUL_PROG_REP]/[dbo].[ICS_BS_MGMT_PRACTICE]/[dbo].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] 
				 UNION ALL 
				SELECT KEY_HASH, I9.DATA_HASH 
				 from [dbo].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [dbo].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [dbo].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] [I9]
 ON [I9].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
				
			 
				-- /[dbo].[ICS_BS_ANNUL_PROG_REP]/[dbo].[ICS_BS_MGMT_PRACTICE]/[dbo].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR]/[dbo].[ICS_ADDR] 
				 UNION ALL 
				SELECT KEY_HASH, I10.DATA_HASH 
				 from [dbo].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [dbo].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [dbo].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] [I9]
 ON [I9].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
 JOIN [dbo].[ICS_ADDR] [I10]
 ON [I10].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] = [I9].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] 
				
			 
				-- /[dbo].[ICS_BS_ANNUL_PROG_REP]/[dbo].[ICS_BS_MGMT_PRACTICE]/[dbo].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR]/[dbo].[ICS_ADDR]/[dbo].[ICS_TELEPH] 
				 UNION ALL 
				SELECT KEY_HASH, I11.DATA_HASH 
				 from [dbo].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [dbo].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [dbo].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] [I9]
 ON [I9].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
 JOIN [dbo].[ICS_ADDR] [I10]
 ON [I10].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] = [I9].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] 
 JOIN [dbo].[ICS_TELEPH] [I11]
 ON [I11].[ICS_ADDR_ID] = [I10].[ICS_ADDR_ID] 
				
			 
				-- /[dbo].[ICS_BS_ANNUL_PROG_REP]/[dbo].[ICS_BS_MGMT_PRACTICE]/[dbo].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR]/[dbo].[ICS_CONTACT] 
				 UNION ALL 
				SELECT KEY_HASH, I12.DATA_HASH 
				 from [dbo].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [dbo].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [dbo].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] [I9]
 ON [I9].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
 JOIN [dbo].[ICS_CONTACT] [I12]
 ON [I12].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] = [I9].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] 
				
			 
				-- /[dbo].[ICS_BS_ANNUL_PROG_REP]/[dbo].[ICS_BS_MGMT_PRACTICE]/[dbo].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR]/[dbo].[ICS_CONTACT]/[dbo].[ICS_TELEPH] 
				 UNION ALL 
				SELECT KEY_HASH, I13.DATA_HASH 
				 from [dbo].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [dbo].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [dbo].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] [I9]
 ON [I9].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
 JOIN [dbo].[ICS_CONTACT] [I12]
 ON [I12].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] = [I9].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] 
 JOIN [dbo].[ICS_TELEPH] [I13]
 ON [I13].[ICS_CONTACT_ID] = [I12].[ICS_CONTACT_ID] 
				
			 
				-- /[dbo].[ICS_BS_ANNUL_PROG_REP]/[dbo].[ICS_BS_MGMT_PRACTICE]/[dbo].[ICS_BS_SEWAGE_SLDG_PARAM] 
				 UNION ALL 
				SELECT KEY_HASH, I14.DATA_HASH 
				 from [dbo].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [dbo].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [dbo].[ICS_BS_SEWAGE_SLDG_PARAM] [I14]
 ON [I14].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
				
			 
				-- /[dbo].[ICS_BS_ANNUL_PROG_REP]/[dbo].[ICS_BS_MGMT_PRACTICE]/[dbo].[ICS_VECTOR_A_REDUCTION_TYPE] 
				 UNION ALL 
				SELECT KEY_HASH, I15.DATA_HASH 
				 from [dbo].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [dbo].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [dbo].[ICS_VECTOR_A_REDUCTION_TYPE] [I15]
 ON [I15].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
				
			 
				-- /[dbo].[ICS_BS_ANNUL_PROG_REP]/[dbo].[ICS_BS_MGMT_PRACTICE]/[dbo].[ICS_CMPL_MON_EVT] 
				 UNION ALL 
				SELECT KEY_HASH, I16.DATA_HASH 
				 from [dbo].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [dbo].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [dbo].[ICS_CMPL_MON_EVT] [I16]
 ON [I16].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
				
			 
				-- /[dbo].[ICS_BS_ANNUL_PROG_REP]/[dbo].[ICS_BS_MGMT_PRACTICE]/[dbo].[ICS_CMPL_MON_EVT]/[dbo].[ICS_BS_SEWAGE_SLDG_PARAM] 
				 UNION ALL 
				SELECT KEY_HASH, I17.DATA_HASH 
				 from [dbo].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [dbo].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [dbo].[ICS_CMPL_MON_EVT] [I16]
 ON [I16].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
 JOIN [dbo].[ICS_BS_SEWAGE_SLDG_PARAM] [I17]
 ON [I17].[ICS_CMPL_MON_EVT_ID] = [I16].[ICS_CMPL_MON_EVT_ID] 
							  
    ),
    rolled (key_hash, rolled_hash) AS (
      SELECT
        key_hash,
        dbo.HASHBYTES_VARCHAR('SHA1',
          STRING_AGG(cast(data_hash as varchar(max)), '') WITHIN GROUP (ORDER BY data_hash)
        ) AS rolled_hash
      FROM all_hashes
      GROUP BY key_hash
    )
    UPDATE p
       SET p.data_hash = r.rolled_hash
      FROM dbo.ICS_BS_ANNUL_PROG_REP p
      JOIN rolled r ON r.key_hash = p.key_hash;
  END;

  -- [3] ICS_BS_ANNUL_PROG_REP
  IF EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P
             JOIN dbo.ICS_BS_ANNUL_PROG_REP C ON P.ICS_PAYLOAD_ID = C.ICS_PAYLOAD_ID
             WHERE P.ENABLED = 'Y')
  BEGIN
    ;WITH all_hashes (key_hash, data_hash) AS (

				
			 
				-- /[dbo].[ICS_BS_ANNUL_PROG_REP] 
				
				SELECT KEY_HASH, ICS_BS_ANNUL_PROG_REP.DATA_HASH 
				 from [dbo].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
				
			 
				-- /[dbo].[ICS_BS_ANNUL_PROG_REP]/[dbo].[ICS_ANLYTCL_METHOD] 
				 UNION ALL 
				SELECT KEY_HASH, I1.DATA_HASH 
				 from [dbo].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [dbo].[ICS_ANLYTCL_METHOD] [I1]
 ON [I1].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
				
			 
				-- /[dbo].[ICS_BS_ANNUL_PROG_REP]/[dbo].[ICS_BS_FAC_TRTMNT] 
				 UNION ALL 
				SELECT KEY_HASH, I2.DATA_HASH 
				 from [dbo].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [dbo].[ICS_BS_FAC_TRTMNT] [I2]
 ON [I2].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
				
			 
				-- /[dbo].[ICS_BS_ANNUL_PROG_REP]/[dbo].[ICS_BS_FAC_TYPE] 
				 UNION ALL 
				SELECT KEY_HASH, I3.DATA_HASH 
				 from [dbo].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [dbo].[ICS_BS_FAC_TYPE] [I3]
 ON [I3].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
				
			 
				-- /[dbo].[ICS_BS_ANNUL_PROG_REP]/[dbo].[ICS_BS_MGMT_PRACTICE] 
				 UNION ALL 
				SELECT KEY_HASH, I4.DATA_HASH 
				 from [dbo].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [dbo].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
				
			 
				-- /[dbo].[ICS_BS_ANNUL_PROG_REP]/[dbo].[ICS_BS_MGMT_PRACTICE]/[dbo].[ICS_PATHOGEN_REDUCTION_TYPE] 
				 UNION ALL 
				SELECT KEY_HASH, I5.DATA_HASH 
				 from [dbo].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [dbo].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [dbo].[ICS_PATHOGEN_REDUCTION_TYPE] [I5]
 ON [I5].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
				
			 
				-- /[dbo].[ICS_BS_ANNUL_PROG_REP]/[dbo].[ICS_BS_MGMT_PRACTICE]/[dbo].[ICS_BS_INCINERATION] 
				 UNION ALL 
				SELECT KEY_HASH, I6.DATA_HASH 
				 from [dbo].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [dbo].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [dbo].[ICS_BS_INCINERATION] [I6]
 ON [I6].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
				
			 
				-- /[dbo].[ICS_BS_ANNUL_PROG_REP]/[dbo].[ICS_BS_MGMT_PRACTICE]/[dbo].[ICS_BS_INCINERATION]/[dbo].[ICS_BS_INCIN_EMISSIONS_CONTROL_TYPE] 
				 UNION ALL 
				SELECT KEY_HASH, I7.DATA_HASH 
				 from [dbo].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [dbo].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [dbo].[ICS_BS_INCINERATION] [I6]
 ON [I6].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
 JOIN [dbo].[ICS_BS_INCIN_EMISSIONS_CONTROL_TYPE] [I7]
 ON [I7].[ICS_BS_INCINERATION_ID] = [I6].[ICS_BS_INCINERATION_ID] 
				
			 
				-- /[dbo].[ICS_BS_ANNUL_PROG_REP]/[dbo].[ICS_BS_MGMT_PRACTICE]/[dbo].[ICS_BS_INCINERATION]/[dbo].[ICS_BS_SEWAGE_SLDG_PARAM] 
				 UNION ALL 
				SELECT KEY_HASH, I8.DATA_HASH 
				 from [dbo].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [dbo].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [dbo].[ICS_BS_INCINERATION] [I6]
 ON [I6].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
 JOIN [dbo].[ICS_BS_SEWAGE_SLDG_PARAM] [I8]
 ON [I8].[ICS_BS_INCINERATION_ID] = [I6].[ICS_BS_INCINERATION_ID] 
				
			 
				-- /[dbo].[ICS_BS_ANNUL_PROG_REP]/[dbo].[ICS_BS_MGMT_PRACTICE]/[dbo].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] 
				 UNION ALL 
				SELECT KEY_HASH, I9.DATA_HASH 
				 from [dbo].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [dbo].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [dbo].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] [I9]
 ON [I9].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
				
			 
				-- /[dbo].[ICS_BS_ANNUL_PROG_REP]/[dbo].[ICS_BS_MGMT_PRACTICE]/[dbo].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR]/[dbo].[ICS_ADDR] 
				 UNION ALL 
				SELECT KEY_HASH, I10.DATA_HASH 
				 from [dbo].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [dbo].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [dbo].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] [I9]
 ON [I9].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
 JOIN [dbo].[ICS_ADDR] [I10]
 ON [I10].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] = [I9].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] 
				
			 
				-- /[dbo].[ICS_BS_ANNUL_PROG_REP]/[dbo].[ICS_BS_MGMT_PRACTICE]/[dbo].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR]/[dbo].[ICS_ADDR]/[dbo].[ICS_TELEPH] 
				 UNION ALL 
				SELECT KEY_HASH, I11.DATA_HASH 
				 from [dbo].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [dbo].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [dbo].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] [I9]
 ON [I9].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
 JOIN [dbo].[ICS_ADDR] [I10]
 ON [I10].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] = [I9].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] 
 JOIN [dbo].[ICS_TELEPH] [I11]
 ON [I11].[ICS_ADDR_ID] = [I10].[ICS_ADDR_ID] 
				
			 
				-- /[dbo].[ICS_BS_ANNUL_PROG_REP]/[dbo].[ICS_BS_MGMT_PRACTICE]/[dbo].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR]/[dbo].[ICS_CONTACT] 
				 UNION ALL 
				SELECT KEY_HASH, I12.DATA_HASH 
				 from [dbo].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [dbo].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [dbo].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] [I9]
 ON [I9].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
 JOIN [dbo].[ICS_CONTACT] [I12]
 ON [I12].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] = [I9].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] 
				
			 
				-- /[dbo].[ICS_BS_ANNUL_PROG_REP]/[dbo].[ICS_BS_MGMT_PRACTICE]/[dbo].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR]/[dbo].[ICS_CONTACT]/[dbo].[ICS_TELEPH] 
				 UNION ALL 
				SELECT KEY_HASH, I13.DATA_HASH 
				 from [dbo].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [dbo].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [dbo].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] [I9]
 ON [I9].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
 JOIN [dbo].[ICS_CONTACT] [I12]
 ON [I12].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] = [I9].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] 
 JOIN [dbo].[ICS_TELEPH] [I13]
 ON [I13].[ICS_CONTACT_ID] = [I12].[ICS_CONTACT_ID] 
				
			 
				-- /[dbo].[ICS_BS_ANNUL_PROG_REP]/[dbo].[ICS_BS_MGMT_PRACTICE]/[dbo].[ICS_BS_SEWAGE_SLDG_PARAM] 
				 UNION ALL 
				SELECT KEY_HASH, I14.DATA_HASH 
				 from [dbo].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [dbo].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [dbo].[ICS_BS_SEWAGE_SLDG_PARAM] [I14]
 ON [I14].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
				
			 
				-- /[dbo].[ICS_BS_ANNUL_PROG_REP]/[dbo].[ICS_BS_MGMT_PRACTICE]/[dbo].[ICS_VECTOR_A_REDUCTION_TYPE] 
				 UNION ALL 
				SELECT KEY_HASH, I15.DATA_HASH 
				 from [dbo].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [dbo].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [dbo].[ICS_VECTOR_A_REDUCTION_TYPE] [I15]
 ON [I15].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
				
			 
				-- /[dbo].[ICS_BS_ANNUL_PROG_REP]/[dbo].[ICS_BS_MGMT_PRACTICE]/[dbo].[ICS_CMPL_MON_EVT] 
				 UNION ALL 
				SELECT KEY_HASH, I16.DATA_HASH 
				 from [dbo].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [dbo].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [dbo].[ICS_CMPL_MON_EVT] [I16]
 ON [I16].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
				
			 
				-- /[dbo].[ICS_BS_ANNUL_PROG_REP]/[dbo].[ICS_BS_MGMT_PRACTICE]/[dbo].[ICS_CMPL_MON_EVT]/[dbo].[ICS_BS_SEWAGE_SLDG_PARAM] 
				 UNION ALL 
				SELECT KEY_HASH, I17.DATA_HASH 
				 from [dbo].[ICS_BS_ANNUL_PROG_REP] [ICS_BS_ANNUL_PROG_REP] 
 JOIN [dbo].[ICS_BS_MGMT_PRACTICE] [I4]
 ON [I4].[ICS_BS_ANNUL_PROG_REP_ID] = [ICS_BS_ANNUL_PROG_REP].[ICS_BS_ANNUL_PROG_REP_ID] 
 JOIN [dbo].[ICS_CMPL_MON_EVT] [I16]
 ON [I16].[ICS_BS_MGMT_PRACTICE_ID] = [I4].[ICS_BS_MGMT_PRACTICE_ID] 
 JOIN [dbo].[ICS_BS_SEWAGE_SLDG_PARAM] [I17]
 ON [I17].[ICS_CMPL_MON_EVT_ID] = [I16].[ICS_CMPL_MON_EVT_ID] 
							  
    ),
    rolled (key_hash, rolled_hash) AS (
      SELECT
        key_hash,
        dbo.HASHBYTES_VARCHAR('SHA1',
          STRING_AGG(cast(data_hash as varchar(max)), '') WITHIN GROUP (ORDER BY data_hash)
        ) AS rolled_hash
      FROM all_hashes
      GROUP BY key_hash
    )
    UPDATE p
       SET p.data_hash = r.rolled_hash
      FROM dbo.ICS_BS_ANNUL_PROG_REP p
      JOIN rolled r ON r.key_hash = p.key_hash;
  END;

  -- [4] ICS_BS_PRMT
  IF EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P
             JOIN dbo.ICS_BS_PRMT C ON P.ICS_PAYLOAD_ID = C.ICS_PAYLOAD_ID
             WHERE P.ENABLED = 'Y')
  BEGIN
    ;WITH all_hashes (key_hash, data_hash) AS (

				
			 
				-- /[dbo].[ICS_BS_PRMT] 
				
				SELECT KEY_HASH, ICS_BS_PRMT.DATA_HASH 
				 from [dbo].[ICS_BS_PRMT] [ICS_BS_PRMT] 
				
			 
				-- /[dbo].[ICS_BS_PRMT]/[dbo].[ICS_PRMT_BS_MGMT_PRACTICE] 
				 UNION ALL 
				SELECT KEY_HASH, I1.DATA_HASH 
				 from [dbo].[ICS_BS_PRMT] [ICS_BS_PRMT] 
 JOIN [dbo].[ICS_PRMT_BS_MGMT_PRACTICE] [I1]
 ON [I1].[ICS_BS_PRMT_ID] = [ICS_BS_PRMT].[ICS_BS_PRMT_ID] 
				
			 
				-- /[dbo].[ICS_BS_PRMT]/[dbo].[ICS_PRMT_BS_MGMT_PRACTICE]/[dbo].[ICS_PATHOGEN_REDUCTION_TYPE] 
				 UNION ALL 
				SELECT KEY_HASH, I2.DATA_HASH 
				 from [dbo].[ICS_BS_PRMT] [ICS_BS_PRMT] 
 JOIN [dbo].[ICS_PRMT_BS_MGMT_PRACTICE] [I1]
 ON [I1].[ICS_BS_PRMT_ID] = [ICS_BS_PRMT].[ICS_BS_PRMT_ID] 
 JOIN [dbo].[ICS_PATHOGEN_REDUCTION_TYPE] [I2]
 ON [I2].[ICS_PRMT_BS_MGMT_PRACTICE_ID] = [I1].[ICS_PRMT_BS_MGMT_PRACTICE_ID] 
				
			 
				-- /[dbo].[ICS_BS_PRMT]/[dbo].[ICS_PRMT_BS_MGMT_PRACTICE]/[dbo].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] 
				 UNION ALL 
				SELECT KEY_HASH, I3.DATA_HASH 
				 from [dbo].[ICS_BS_PRMT] [ICS_BS_PRMT] 
 JOIN [dbo].[ICS_PRMT_BS_MGMT_PRACTICE] [I1]
 ON [I1].[ICS_BS_PRMT_ID] = [ICS_BS_PRMT].[ICS_BS_PRMT_ID] 
 JOIN [dbo].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] [I3]
 ON [I3].[ICS_PRMT_BS_MGMT_PRACTICE_ID] = [I1].[ICS_PRMT_BS_MGMT_PRACTICE_ID] 
				
			 
				-- /[dbo].[ICS_BS_PRMT]/[dbo].[ICS_PRMT_BS_MGMT_PRACTICE]/[dbo].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR]/[dbo].[ICS_ADDR] 
				 UNION ALL 
				SELECT KEY_HASH, I4.DATA_HASH 
				 from [dbo].[ICS_BS_PRMT] [ICS_BS_PRMT] 
 JOIN [dbo].[ICS_PRMT_BS_MGMT_PRACTICE] [I1]
 ON [I1].[ICS_BS_PRMT_ID] = [ICS_BS_PRMT].[ICS_BS_PRMT_ID] 
 JOIN [dbo].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] [I3]
 ON [I3].[ICS_PRMT_BS_MGMT_PRACTICE_ID] = [I1].[ICS_PRMT_BS_MGMT_PRACTICE_ID] 
 JOIN [dbo].[ICS_ADDR] [I4]
 ON [I4].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] = [I3].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] 
				
			 
				-- /[dbo].[ICS_BS_PRMT]/[dbo].[ICS_PRMT_BS_MGMT_PRACTICE]/[dbo].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR]/[dbo].[ICS_ADDR]/[dbo].[ICS_TELEPH] 
				 UNION ALL 
				SELECT KEY_HASH, I5.DATA_HASH 
				 from [dbo].[ICS_BS_PRMT] [ICS_BS_PRMT] 
 JOIN [dbo].[ICS_PRMT_BS_MGMT_PRACTICE] [I1]
 ON [I1].[ICS_BS_PRMT_ID] = [ICS_BS_PRMT].[ICS_BS_PRMT_ID] 
 JOIN [dbo].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] [I3]
 ON [I3].[ICS_PRMT_BS_MGMT_PRACTICE_ID] = [I1].[ICS_PRMT_BS_MGMT_PRACTICE_ID] 
 JOIN [dbo].[ICS_ADDR] [I4]
 ON [I4].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] = [I3].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] 
 JOIN [dbo].[ICS_TELEPH] [I5]
 ON [I5].[ICS_ADDR_ID] = [I4].[ICS_ADDR_ID] 
				
			 
				-- /[dbo].[ICS_BS_PRMT]/[dbo].[ICS_PRMT_BS_MGMT_PRACTICE]/[dbo].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR]/[dbo].[ICS_CONTACT] 
				 UNION ALL 
				SELECT KEY_HASH, I6.DATA_HASH 
				 from [dbo].[ICS_BS_PRMT] [ICS_BS_PRMT] 
 JOIN [dbo].[ICS_PRMT_BS_MGMT_PRACTICE] [I1]
 ON [I1].[ICS_BS_PRMT_ID] = [ICS_BS_PRMT].[ICS_BS_PRMT_ID] 
 JOIN [dbo].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] [I3]
 ON [I3].[ICS_PRMT_BS_MGMT_PRACTICE_ID] = [I1].[ICS_PRMT_BS_MGMT_PRACTICE_ID] 
 JOIN [dbo].[ICS_CONTACT] [I6]
 ON [I6].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] = [I3].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] 
				
			 
				-- /[dbo].[ICS_BS_PRMT]/[dbo].[ICS_PRMT_BS_MGMT_PRACTICE]/[dbo].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR]/[dbo].[ICS_CONTACT]/[dbo].[ICS_TELEPH] 
				 UNION ALL 
				SELECT KEY_HASH, I7.DATA_HASH 
				 from [dbo].[ICS_BS_PRMT] [ICS_BS_PRMT] 
 JOIN [dbo].[ICS_PRMT_BS_MGMT_PRACTICE] [I1]
 ON [I1].[ICS_BS_PRMT_ID] = [ICS_BS_PRMT].[ICS_BS_PRMT_ID] 
 JOIN [dbo].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR] [I3]
 ON [I3].[ICS_PRMT_BS_MGMT_PRACTICE_ID] = [I1].[ICS_PRMT_BS_MGMT_PRACTICE_ID] 
 JOIN [dbo].[ICS_CONTACT] [I6]
 ON [I6].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] = [I3].[ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID] 
 JOIN [dbo].[ICS_TELEPH] [I7]
 ON [I7].[ICS_CONTACT_ID] = [I6].[ICS_CONTACT_ID] 
				
			 
				-- /[dbo].[ICS_BS_PRMT]/[dbo].[ICS_PRMT_BS_MGMT_PRACTICE]/[dbo].[ICS_VECTOR_A_REDUCTION_TYPE] 
				 UNION ALL 
				SELECT KEY_HASH, I8.DATA_HASH 
				 from [dbo].[ICS_BS_PRMT] [ICS_BS_PRMT] 
 JOIN [dbo].[ICS_PRMT_BS_MGMT_PRACTICE] [I1]
 ON [I1].[ICS_BS_PRMT_ID] = [ICS_BS_PRMT].[ICS_BS_PRMT_ID] 
 JOIN [dbo].[ICS_VECTOR_A_REDUCTION_TYPE] [I8]
 ON [I8].[ICS_PRMT_BS_MGMT_PRACTICE_ID] = [I1].[ICS_PRMT_BS_MGMT_PRACTICE_ID] 
				
			 
				-- /[dbo].[ICS_BS_PRMT]/[dbo].[ICS_BS_FAC_TRTMNT] 
				 UNION ALL 
				SELECT KEY_HASH, I9.DATA_HASH 
				 from [dbo].[ICS_BS_PRMT] [ICS_BS_PRMT] 
 JOIN [dbo].[ICS_BS_FAC_TRTMNT] [I9]
 ON [I9].[ICS_BS_PRMT_ID] = [ICS_BS_PRMT].[ICS_BS_PRMT_ID] 
				
			 
				-- /[dbo].[ICS_BS_PRMT]/[dbo].[ICS_BS_FAC_TYPE] 
				 UNION ALL 
				SELECT KEY_HASH, I10.DATA_HASH 
				 from [dbo].[ICS_BS_PRMT] [ICS_BS_PRMT] 
 JOIN [dbo].[ICS_BS_FAC_TYPE] [I10]
 ON [I10].[ICS_BS_PRMT_ID] = [ICS_BS_PRMT].[ICS_BS_PRMT_ID] 
							  
    ),
    rolled (key_hash, rolled_hash) AS (
      SELECT
        key_hash,
        dbo.HASHBYTES_VARCHAR('SHA1',
          STRING_AGG(cast(data_hash as varchar(max)), '') WITHIN GROUP (ORDER BY data_hash)
        ) AS rolled_hash
      FROM all_hashes
      GROUP BY key_hash
    )
    UPDATE p
       SET p.data_hash = r.rolled_hash
      FROM dbo.ICS_BS_PRMT p
      JOIN rolled r ON r.key_hash = p.key_hash;
  END;

  -- [5] ICS_CAFO_ANNUL_PROG_REP
  IF EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P
             JOIN dbo.ICS_CAFO_ANNUL_PROG_REP C ON P.ICS_PAYLOAD_ID = C.ICS_PAYLOAD_ID
             WHERE P.ENABLED = 'Y')
  BEGIN
    ;WITH all_hashes (key_hash, data_hash) AS (

				
			 
				-- /[dbo].[ICS_CAFO_ANNUL_PROG_REP] 
				
				SELECT KEY_HASH, ICS_CAFO_ANNUL_PROG_REP.DATA_HASH 
				 from [dbo].[ICS_CAFO_ANNUL_PROG_REP] [ICS_CAFO_ANNUL_PROG_REP] 
				
			 
				-- /[dbo].[ICS_CAFO_ANNUL_PROG_REP]/[dbo].[ICS_ANML_TYPE] 
				 UNION ALL 
				SELECT KEY_HASH, I1.DATA_HASH 
				 from [dbo].[ICS_CAFO_ANNUL_PROG_REP] [ICS_CAFO_ANNUL_PROG_REP] 
 JOIN [dbo].[ICS_ANML_TYPE] [I1]
 ON [I1].[ICS_CAFO_ANNUL_PROG_REP_ID] = [ICS_CAFO_ANNUL_PROG_REP].[ICS_CAFO_ANNUL_PROG_REP_ID] 
				
			 
				-- /[dbo].[ICS_CAFO_ANNUL_PROG_REP]/[dbo].[ICS_CAFO_LAND_APPL_FLD_INFO] 
				 UNION ALL 
				SELECT KEY_HASH, I2.DATA_HASH 
				 from [dbo].[ICS_CAFO_ANNUL_PROG_REP] [ICS_CAFO_ANNUL_PROG_REP] 
 JOIN [dbo].[ICS_CAFO_LAND_APPL_FLD_INFO] [I2]
 ON [I2].[ICS_CAFO_ANNUL_PROG_REP_ID] = [ICS_CAFO_ANNUL_PROG_REP].[ICS_CAFO_ANNUL_PROG_REP_ID] 
				
			 
				-- /[dbo].[ICS_CAFO_ANNUL_PROG_REP]/[dbo].[ICS_CAFO_LAND_APPL_FLD_INFO]/[dbo].[ICS_CAFOMLPW_FLD_AMOUNTS] 
				 UNION ALL 
				SELECT KEY_HASH, I3.DATA_HASH 
				 from [dbo].[ICS_CAFO_ANNUL_PROG_REP] [ICS_CAFO_ANNUL_PROG_REP] 
 JOIN [dbo].[ICS_CAFO_LAND_APPL_FLD_INFO] [I2]
 ON [I2].[ICS_CAFO_ANNUL_PROG_REP_ID] = [ICS_CAFO_ANNUL_PROG_REP].[ICS_CAFO_ANNUL_PROG_REP_ID] 
 JOIN [dbo].[ICS_CAFOMLPW_FLD_AMOUNTS] [I3]
 ON [I3].[ICS_CAFO_LAND_APPL_FLD_INFO_ID] = [I2].[ICS_CAFO_LAND_APPL_FLD_INFO_ID] 
				
			 
				-- /[dbo].[ICS_CAFO_ANNUL_PROG_REP]/[dbo].[ICS_CAFO_PROD_AREA_DSCH] 
				 UNION ALL 
				SELECT KEY_HASH, I4.DATA_HASH 
				 from [dbo].[ICS_CAFO_ANNUL_PROG_REP] [ICS_CAFO_ANNUL_PROG_REP] 
 JOIN [dbo].[ICS_CAFO_PROD_AREA_DSCH] [I4]
 ON [I4].[ICS_CAFO_ANNUL_PROG_REP_ID] = [ICS_CAFO_ANNUL_PROG_REP].[ICS_CAFO_ANNUL_PROG_REP_ID] 
				
			 
				-- /[dbo].[ICS_CAFO_ANNUL_PROG_REP]/[dbo].[ICS_CAFOMLPW_NUTR_MON] 
				 UNION ALL 
				SELECT KEY_HASH, I5.DATA_HASH 
				 from [dbo].[ICS_CAFO_ANNUL_PROG_REP] [ICS_CAFO_ANNUL_PROG_REP] 
 JOIN [dbo].[ICS_CAFOMLPW_NUTR_MON] [I5]
 ON [I5].[ICS_CAFO_ANNUL_PROG_REP_ID] = [ICS_CAFO_ANNUL_PROG_REP].[ICS_CAFO_ANNUL_PROG_REP_ID] 
				
			 
				-- /[dbo].[ICS_CAFO_ANNUL_PROG_REP]/[dbo].[ICS_CAFOMLPW_TTL_AMOUNTS] 
				 UNION ALL 
				SELECT KEY_HASH, I6.DATA_HASH 
				 from [dbo].[ICS_CAFO_ANNUL_PROG_REP] [ICS_CAFO_ANNUL_PROG_REP] 
 JOIN [dbo].[ICS_CAFOMLPW_TTL_AMOUNTS] [I6]
 ON [I6].[ICS_CAFO_ANNUL_PROG_REP_ID] = [ICS_CAFO_ANNUL_PROG_REP].[ICS_CAFO_ANNUL_PROG_REP_ID] 
							  
    ),
    rolled (key_hash, rolled_hash) AS (
      SELECT
        key_hash,
        dbo.HASHBYTES_VARCHAR('SHA1',
          STRING_AGG(cast(data_hash as varchar(max)), '') WITHIN GROUP (ORDER BY data_hash)
        ) AS rolled_hash
      FROM all_hashes
      GROUP BY key_hash
    )
    UPDATE p
       SET p.data_hash = r.rolled_hash
      FROM dbo.ICS_CAFO_ANNUL_PROG_REP p
      JOIN rolled r ON r.key_hash = p.key_hash;
  END;

  -- [6] ICS_CAFO_PRMT
  IF EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P
             JOIN dbo.ICS_CAFO_PRMT C ON P.ICS_PAYLOAD_ID = C.ICS_PAYLOAD_ID
             WHERE P.ENABLED = 'Y')
  BEGIN
    ;WITH all_hashes (key_hash, data_hash) AS (

				
			 
				-- /[dbo].[ICS_CAFO_PRMT] 
				
				SELECT KEY_HASH, ICS_CAFO_PRMT.DATA_HASH 
				 from [dbo].[ICS_CAFO_PRMT] [ICS_CAFO_PRMT] 
				
			 
				-- /[dbo].[ICS_CAFO_PRMT]/[dbo].[ICS_CONTACT] 
				 UNION ALL 
				SELECT KEY_HASH, I1.DATA_HASH 
				 from [dbo].[ICS_CAFO_PRMT] [ICS_CAFO_PRMT] 
 JOIN [dbo].[ICS_CONTACT] [I1]
 ON [I1].[ICS_CAFO_PRMT_ID] = [ICS_CAFO_PRMT].[ICS_CAFO_PRMT_ID] 
				
			 
				-- /[dbo].[ICS_CAFO_PRMT]/[dbo].[ICS_CONTACT]/[dbo].[ICS_TELEPH] 
				 UNION ALL 
				SELECT KEY_HASH, I2.DATA_HASH 
				 from [dbo].[ICS_CAFO_PRMT] [ICS_CAFO_PRMT] 
 JOIN [dbo].[ICS_CONTACT] [I1]
 ON [I1].[ICS_CAFO_PRMT_ID] = [ICS_CAFO_PRMT].[ICS_CAFO_PRMT_ID] 
 JOIN [dbo].[ICS_TELEPH] [I2]
 ON [I2].[ICS_CONTACT_ID] = [I1].[ICS_CONTACT_ID] 
				
			 
				-- /[dbo].[ICS_CAFO_PRMT]/[dbo].[ICS_CONTAINMENT] 
				 UNION ALL 
				SELECT KEY_HASH, I3.DATA_HASH 
				 from [dbo].[ICS_CAFO_PRMT] [ICS_CAFO_PRMT] 
 JOIN [dbo].[ICS_CONTAINMENT] [I3]
 ON [I3].[ICS_CAFO_PRMT_ID] = [ICS_CAFO_PRMT].[ICS_CAFO_PRMT_ID] 
				
			 
				-- /[dbo].[ICS_CAFO_PRMT]/[dbo].[ICS_LAND_APPL_BMP] 
				 UNION ALL 
				SELECT KEY_HASH, I4.DATA_HASH 
				 from [dbo].[ICS_CAFO_PRMT] [ICS_CAFO_PRMT] 
 JOIN [dbo].[ICS_LAND_APPL_BMP] [I4]
 ON [I4].[ICS_CAFO_PRMT_ID] = [ICS_CAFO_PRMT].[ICS_CAFO_PRMT_ID] 
				
			 
				-- /[dbo].[ICS_CAFO_PRMT]/[dbo].[ICS_ADDR] 
				 UNION ALL 
				SELECT KEY_HASH, I5.DATA_HASH 
				 from [dbo].[ICS_CAFO_PRMT] [ICS_CAFO_PRMT] 
 JOIN [dbo].[ICS_ADDR] [I5]
 ON [I5].[ICS_CAFO_PRMT_ID] = [ICS_CAFO_PRMT].[ICS_CAFO_PRMT_ID] 
				
			 
				-- /[dbo].[ICS_CAFO_PRMT]/[dbo].[ICS_ADDR]/[dbo].[ICS_TELEPH] 
				 UNION ALL 
				SELECT KEY_HASH, I6.DATA_HASH 
				 from [dbo].[ICS_CAFO_PRMT] [ICS_CAFO_PRMT] 
 JOIN [dbo].[ICS_ADDR] [I5]
 ON [I5].[ICS_CAFO_PRMT_ID] = [ICS_CAFO_PRMT].[ICS_CAFO_PRMT_ID] 
 JOIN [dbo].[ICS_TELEPH] [I6]
 ON [I6].[ICS_ADDR_ID] = [I5].[ICS_ADDR_ID] 
				
			 
				-- /[dbo].[ICS_CAFO_PRMT]/[dbo].[ICS_ANML_TYPE] 
				 UNION ALL 
				SELECT KEY_HASH, I7.DATA_HASH 
				 from [dbo].[ICS_CAFO_PRMT] [ICS_CAFO_PRMT] 
 JOIN [dbo].[ICS_ANML_TYPE] [I7]
 ON [I7].[ICS_CAFO_PRMT_ID] = [ICS_CAFO_PRMT].[ICS_CAFO_PRMT_ID] 
				
			 
				-- /[dbo].[ICS_CAFO_PRMT]/[dbo].[ICS_MNUR_LTTR_PRCSS_WW_STOR] 
				 UNION ALL 
				SELECT KEY_HASH, I8.DATA_HASH 
				 from [dbo].[ICS_CAFO_PRMT] [ICS_CAFO_PRMT] 
 JOIN [dbo].[ICS_MNUR_LTTR_PRCSS_WW_STOR] [I8]
 ON [I8].[ICS_CAFO_PRMT_ID] = [ICS_CAFO_PRMT].[ICS_CAFO_PRMT_ID] 
				
			 
				-- /[dbo].[ICS_CAFO_PRMT]/[dbo].[ICS_CAFOMLPW_TTL_AMOUNTS] 
				 UNION ALL 
				SELECT KEY_HASH, I9.DATA_HASH 
				 from [dbo].[ICS_CAFO_PRMT] [ICS_CAFO_PRMT] 
 JOIN [dbo].[ICS_CAFOMLPW_TTL_AMOUNTS] [I9]
 ON [I9].[ICS_CAFO_PRMT_ID] = [ICS_CAFO_PRMT].[ICS_CAFO_PRMT_ID] 
							  
    ),
    rolled (key_hash, rolled_hash) AS (
      SELECT
        key_hash,
        dbo.HASHBYTES_VARCHAR('SHA1',
          STRING_AGG(cast(data_hash as varchar(max)), '') WITHIN GROUP (ORDER BY data_hash)
        ) AS rolled_hash
      FROM all_hashes
      GROUP BY key_hash
    )
    UPDATE p
       SET p.data_hash = r.rolled_hash
      FROM dbo.ICS_CAFO_PRMT p
      JOIN rolled r ON r.key_hash = p.key_hash;
  END;

  -- [7] ICS_COLL_SYSTM_PRMT
  IF EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P
             JOIN dbo.ICS_COLL_SYSTM_PRMT C ON P.ICS_PAYLOAD_ID = C.ICS_PAYLOAD_ID
             WHERE P.ENABLED = 'Y')
  BEGIN
    ;WITH all_hashes (key_hash, data_hash) AS (

				
			 
				-- /[dbo].[ICS_COLL_SYSTM_PRMT] 
				
				SELECT KEY_HASH, ICS_COLL_SYSTM_PRMT.DATA_HASH 
				 from [dbo].[ICS_COLL_SYSTM_PRMT] [ICS_COLL_SYSTM_PRMT] 
							  
    ),
    rolled (key_hash, rolled_hash) AS (
      SELECT
        key_hash,
        dbo.HASHBYTES_VARCHAR('SHA1',
          STRING_AGG(cast(data_hash as varchar(max)), '') WITHIN GROUP (ORDER BY data_hash)
        ) AS rolled_hash
      FROM all_hashes
      GROUP BY key_hash
    )
    UPDATE p
       SET p.data_hash = r.rolled_hash
      FROM dbo.ICS_COLL_SYSTM_PRMT p
      JOIN rolled r ON r.key_hash = p.key_hash;
  END;

  -- [8] ICS_CMPL_MON
  IF EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P
             JOIN dbo.ICS_CMPL_MON C ON P.ICS_PAYLOAD_ID = C.ICS_PAYLOAD_ID
             WHERE P.ENABLED = 'Y')
  BEGIN
    ;WITH all_hashes (key_hash, data_hash) AS (

				
			 
				-- /[dbo].[ICS_CMPL_MON] 
				
				SELECT KEY_HASH, ICS_CMPL_MON.DATA_HASH 
				 from [dbo].[ICS_CMPL_MON] [ICS_CMPL_MON] 
				
			 
				-- /[dbo].[ICS_CMPL_MON]/[dbo].[ICS_CONTACT] 
				 UNION ALL 
				SELECT KEY_HASH, I1.DATA_HASH 
				 from [dbo].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [dbo].[ICS_CONTACT] [I1]
 ON [I1].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
				
			 
				-- /[dbo].[ICS_CMPL_MON]/[dbo].[ICS_CONTACT]/[dbo].[ICS_TELEPH] 
				 UNION ALL 
				SELECT KEY_HASH, I2.DATA_HASH 
				 from [dbo].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [dbo].[ICS_CONTACT] [I1]
 ON [I1].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN [dbo].[ICS_TELEPH] [I2]
 ON [I2].[ICS_CONTACT_ID] = [I1].[ICS_CONTACT_ID] 
				
			 
				-- /[dbo].[ICS_CMPL_MON]/[dbo].[ICS_NAT_PRIO] 
				 UNION ALL 
				SELECT KEY_HASH, I3.DATA_HASH 
				 from [dbo].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [dbo].[ICS_NAT_PRIO] [I3]
 ON [I3].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
				
			 
				-- /[dbo].[ICS_CMPL_MON]/[dbo].[ICS_CSO_INSP] 
				 UNION ALL 
				SELECT KEY_HASH, I4.DATA_HASH 
				 from [dbo].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [dbo].[ICS_CSO_INSP] [I4]
 ON [I4].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
				
			 
				-- /[dbo].[ICS_CMPL_MON]/[dbo].[ICS_PRETR_INSP] 
				 UNION ALL 
				SELECT KEY_HASH, I5.DATA_HASH 
				 from [dbo].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [dbo].[ICS_PRETR_INSP] [I5]
 ON [I5].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
				
			 
				-- /[dbo].[ICS_CMPL_MON]/[dbo].[ICS_PROG] 
				 UNION ALL 
				SELECT KEY_HASH, I6.DATA_HASH 
				 from [dbo].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [dbo].[ICS_PROG] [I6]
 ON [I6].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
				
			 
				-- /[dbo].[ICS_CMPL_MON]/[dbo].[ICS_PROG_DEFCY_TYPE] 
				 UNION ALL 
				SELECT KEY_HASH, I7.DATA_HASH 
				 from [dbo].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [dbo].[ICS_PROG_DEFCY_TYPE] [I7]
 ON [I7].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
				
			 
				-- /[dbo].[ICS_CMPL_MON]/[dbo].[ICS_INSP_CMNT_TXT] 
				 UNION ALL 
				SELECT KEY_HASH, I8.DATA_HASH 
				 from [dbo].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [dbo].[ICS_INSP_CMNT_TXT] [I8]
 ON [I8].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
				
			 
				-- /[dbo].[ICS_CMPL_MON]/[dbo].[ICS_INSP_GOV_CONTACT] 
				 UNION ALL 
				SELECT KEY_HASH, I9.DATA_HASH 
				 from [dbo].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [dbo].[ICS_INSP_GOV_CONTACT] [I9]
 ON [I9].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
				
			 
				-- /[dbo].[ICS_CMPL_MON]/[dbo].[ICS_SSO_INSP] 
				 UNION ALL 
				SELECT KEY_HASH, I10.DATA_HASH 
				 from [dbo].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [dbo].[ICS_SSO_INSP] [I10]
 ON [I10].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
				
			 
				-- /[dbo].[ICS_CMPL_MON]/[dbo].[ICS_SSO_INSP]/[dbo].[ICS_IMPACT_SSO_EVT] 
				 UNION ALL 
				SELECT KEY_HASH, I11.DATA_HASH 
				 from [dbo].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [dbo].[ICS_SSO_INSP] [I10]
 ON [I10].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN [dbo].[ICS_IMPACT_SSO_EVT] [I11]
 ON [I11].[ICS_SSO_INSP_ID] = [I10].[ICS_SSO_INSP_ID] 
				
			 
				-- /[dbo].[ICS_CMPL_MON]/[dbo].[ICS_SSO_INSP]/[dbo].[ICS_SSO_STPS] 
				 UNION ALL 
				SELECT KEY_HASH, I12.DATA_HASH 
				 from [dbo].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [dbo].[ICS_SSO_INSP] [I10]
 ON [I10].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN [dbo].[ICS_SSO_STPS] [I12]
 ON [I12].[ICS_SSO_INSP_ID] = [I10].[ICS_SSO_INSP_ID] 
				
			 
				-- /[dbo].[ICS_CMPL_MON]/[dbo].[ICS_SSO_INSP]/[dbo].[ICS_SSO_SYSTM_COMP] 
				 UNION ALL 
				SELECT KEY_HASH, I13.DATA_HASH 
				 from [dbo].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [dbo].[ICS_SSO_INSP] [I10]
 ON [I10].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN [dbo].[ICS_SSO_SYSTM_COMP] [I13]
 ON [I13].[ICS_SSO_INSP_ID] = [I10].[ICS_SSO_INSP_ID] 
				
			 
				-- /[dbo].[ICS_CMPL_MON]/[dbo].[ICS_SW_CNST_INSP] 
				 UNION ALL 
				SELECT KEY_HASH, I14.DATA_HASH 
				 from [dbo].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [dbo].[ICS_SW_CNST_INSP] [I14]
 ON [I14].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
				
			 
				-- /[dbo].[ICS_CMPL_MON]/[dbo].[ICS_SW_CNST_INSP]/[dbo].[ICS_SW_CNST_INDST_INSP] 
				 UNION ALL 
				SELECT KEY_HASH, I15.DATA_HASH 
				 from [dbo].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [dbo].[ICS_SW_CNST_INSP] [I14]
 ON [I14].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN [dbo].[ICS_SW_CNST_INDST_INSP] [I15]
 ON [I15].[ICS_SW_CNST_INSP_ID] = [I14].[ICS_SW_CNST_INSP_ID] 
				
			 
				-- /[dbo].[ICS_CMPL_MON]/[dbo].[ICS_SW_CNST_INSP]/[dbo].[ICS_SW_UNPRMT_CNST_INSP] 
				 UNION ALL 
				SELECT KEY_HASH, I16.DATA_HASH 
				 from [dbo].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [dbo].[ICS_SW_CNST_INSP] [I14]
 ON [I14].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN [dbo].[ICS_SW_UNPRMT_CNST_INSP] [I16]
 ON [I16].[ICS_SW_CNST_INSP_ID] = [I14].[ICS_SW_CNST_INSP_ID] 
				
			 
				-- /[dbo].[ICS_CMPL_MON]/[dbo].[ICS_SW_CNST_INSP]/[dbo].[ICS_SW_UNPRMT_CNST_INSP]/[dbo].[ICS_PROJ_TYPE] 
				 UNION ALL 
				SELECT KEY_HASH, I17.DATA_HASH 
				 from [dbo].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [dbo].[ICS_SW_CNST_INSP] [I14]
 ON [I14].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN [dbo].[ICS_SW_UNPRMT_CNST_INSP] [I16]
 ON [I16].[ICS_SW_CNST_INSP_ID] = [I14].[ICS_SW_CNST_INSP_ID] 
 JOIN [dbo].[ICS_PROJ_TYPE] [I17]
 ON [I17].[ICS_SW_UNPRMT_CNST_INSP_ID] = [I16].[ICS_SW_UNPRMT_CNST_INSP_ID] 
				
			 
				-- /[dbo].[ICS_CMPL_MON]/[dbo].[ICS_SW_CNST_NON_CNST_INSP] 
				 UNION ALL 
				SELECT KEY_HASH, I18.DATA_HASH 
				 from [dbo].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [dbo].[ICS_SW_CNST_NON_CNST_INSP] [I18]
 ON [I18].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
				
			 
				-- /[dbo].[ICS_CMPL_MON]/[dbo].[ICS_SW_CNST_NON_CNST_INSP]/[dbo].[ICS_SW_CNST_INDST_INSP] 
				 UNION ALL 
				SELECT KEY_HASH, I19.DATA_HASH 
				 from [dbo].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [dbo].[ICS_SW_CNST_NON_CNST_INSP] [I18]
 ON [I18].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN [dbo].[ICS_SW_CNST_INDST_INSP] [I19]
 ON [I19].[ICS_SW_CNST_NON_CNST_INSP_ID] = [I18].[ICS_SW_CNST_NON_CNST_INSP_ID] 
				
			 
				-- /[dbo].[ICS_CMPL_MON]/[dbo].[ICS_SW_CNST_NON_CNST_INSP]/[dbo].[ICS_SW_UNPRMT_CNST_INSP] 
				 UNION ALL 
				SELECT KEY_HASH, I20.DATA_HASH 
				 from [dbo].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [dbo].[ICS_SW_CNST_NON_CNST_INSP] [I18]
 ON [I18].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN [dbo].[ICS_SW_UNPRMT_CNST_INSP] [I20]
 ON [I20].[ICS_SW_CNST_NON_CNST_INSP_ID] = [I18].[ICS_SW_CNST_NON_CNST_INSP_ID] 
				
			 
				-- /[dbo].[ICS_CMPL_MON]/[dbo].[ICS_SW_CNST_NON_CNST_INSP]/[dbo].[ICS_SW_UNPRMT_CNST_INSP]/[dbo].[ICS_PROJ_TYPE] 
				 UNION ALL 
				SELECT KEY_HASH, I21.DATA_HASH 
				 from [dbo].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [dbo].[ICS_SW_CNST_NON_CNST_INSP] [I18]
 ON [I18].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN [dbo].[ICS_SW_UNPRMT_CNST_INSP] [I20]
 ON [I20].[ICS_SW_CNST_NON_CNST_INSP_ID] = [I18].[ICS_SW_CNST_NON_CNST_INSP_ID] 
 JOIN [dbo].[ICS_PROJ_TYPE] [I21]
 ON [I21].[ICS_SW_UNPRMT_CNST_INSP_ID] = [I20].[ICS_SW_UNPRMT_CNST_INSP_ID] 
				
			 
				-- /[dbo].[ICS_CMPL_MON]/[dbo].[ICS_SW_MS_4_INSP] 
				 UNION ALL 
				SELECT KEY_HASH, I22.DATA_HASH 
				 from [dbo].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [dbo].[ICS_SW_MS_4_INSP] [I22]
 ON [I22].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
				
			 
				-- /[dbo].[ICS_CMPL_MON]/[dbo].[ICS_SW_MS_4_INSP]/[dbo].[ICS_PROJ_SRCS_FUND] 
				 UNION ALL 
				SELECT KEY_HASH, I23.DATA_HASH 
				 from [dbo].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [dbo].[ICS_SW_MS_4_INSP] [I22]
 ON [I22].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN [dbo].[ICS_PROJ_SRCS_FUND] [I23]
 ON [I23].[ICS_SW_MS_4_INSP_ID] = [I22].[ICS_SW_MS_4_INSP_ID] 
				
			 
				-- /[dbo].[ICS_CMPL_MON]/[dbo].[ICS_SW_NON_CNST_INSP] 
				 UNION ALL 
				SELECT KEY_HASH, I24.DATA_HASH 
				 from [dbo].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [dbo].[ICS_SW_NON_CNST_INSP] [I24]
 ON [I24].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
				
			 
				-- /[dbo].[ICS_CMPL_MON]/[dbo].[ICS_SW_NON_CNST_INSP]/[dbo].[ICS_SW_CNST_INDST_INSP] 
				 UNION ALL 
				SELECT KEY_HASH, I25.DATA_HASH 
				 from [dbo].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [dbo].[ICS_SW_NON_CNST_INSP] [I24]
 ON [I24].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN [dbo].[ICS_SW_CNST_INDST_INSP] [I25]
 ON [I25].[ICS_SW_NON_CNST_INSP_ID] = [I24].[ICS_SW_NON_CNST_INSP_ID] 
				
			 
				-- /[dbo].[ICS_CMPL_MON]/[dbo].[ICS_SW_NON_CNST_INSP]/[dbo].[ICS_SW_UNPRMT_CNST_INSP] 
				 UNION ALL 
				SELECT KEY_HASH, I26.DATA_HASH 
				 from [dbo].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [dbo].[ICS_SW_NON_CNST_INSP] [I24]
 ON [I24].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN [dbo].[ICS_SW_UNPRMT_CNST_INSP] [I26]
 ON [I26].[ICS_SW_NON_CNST_INSP_ID] = [I24].[ICS_SW_NON_CNST_INSP_ID] 
				
			 
				-- /[dbo].[ICS_CMPL_MON]/[dbo].[ICS_SW_NON_CNST_INSP]/[dbo].[ICS_SW_UNPRMT_CNST_INSP]/[dbo].[ICS_PROJ_TYPE] 
				 UNION ALL 
				SELECT KEY_HASH, I27.DATA_HASH 
				 from [dbo].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [dbo].[ICS_SW_NON_CNST_INSP] [I24]
 ON [I24].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN [dbo].[ICS_SW_UNPRMT_CNST_INSP] [I26]
 ON [I26].[ICS_SW_NON_CNST_INSP_ID] = [I24].[ICS_SW_NON_CNST_INSP_ID] 
 JOIN [dbo].[ICS_PROJ_TYPE] [I27]
 ON [I27].[ICS_SW_UNPRMT_CNST_INSP_ID] = [I26].[ICS_SW_UNPRMT_CNST_INSP_ID] 
				
			 
				-- /[dbo].[ICS_CMPL_MON]/[dbo].[ICS_CAFO_INSP] 
				 UNION ALL 
				SELECT KEY_HASH, I28.DATA_HASH 
				 from [dbo].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [dbo].[ICS_CAFO_INSP] [I28]
 ON [I28].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
				
			 
				-- /[dbo].[ICS_CMPL_MON]/[dbo].[ICS_CAFO_INSP]/[dbo].[ICS_CONTAINMENT] 
				 UNION ALL 
				SELECT KEY_HASH, I29.DATA_HASH 
				 from [dbo].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [dbo].[ICS_CAFO_INSP] [I28]
 ON [I28].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN [dbo].[ICS_CONTAINMENT] [I29]
 ON [I29].[ICS_CAFO_INSP_ID] = [I28].[ICS_CAFO_INSP_ID] 
				
			 
				-- /[dbo].[ICS_CMPL_MON]/[dbo].[ICS_CAFO_INSP]/[dbo].[ICS_LAND_APPL_BMP] 
				 UNION ALL 
				SELECT KEY_HASH, I30.DATA_HASH 
				 from [dbo].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [dbo].[ICS_CAFO_INSP] [I28]
 ON [I28].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN [dbo].[ICS_LAND_APPL_BMP] [I30]
 ON [I30].[ICS_CAFO_INSP_ID] = [I28].[ICS_CAFO_INSP_ID] 
				
			 
				-- /[dbo].[ICS_CMPL_MON]/[dbo].[ICS_CAFO_INSP]/[dbo].[ICS_ANML_TYPE] 
				 UNION ALL 
				SELECT KEY_HASH, I31.DATA_HASH 
				 from [dbo].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [dbo].[ICS_CAFO_INSP] [I28]
 ON [I28].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN [dbo].[ICS_ANML_TYPE] [I31]
 ON [I31].[ICS_CAFO_INSP_ID] = [I28].[ICS_CAFO_INSP_ID] 
				
			 
				-- /[dbo].[ICS_CMPL_MON]/[dbo].[ICS_CAFO_INSP]/[dbo].[ICS_MNUR_LTTR_PRCSS_WW_STOR] 
				 UNION ALL 
				SELECT KEY_HASH, I32.DATA_HASH 
				 from [dbo].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [dbo].[ICS_CAFO_INSP] [I28]
 ON [I28].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN [dbo].[ICS_MNUR_LTTR_PRCSS_WW_STOR] [I32]
 ON [I32].[ICS_CAFO_INSP_ID] = [I28].[ICS_CAFO_INSP_ID] 
				
			 
				-- /[dbo].[ICS_CMPL_MON]/[dbo].[ICS_CAFO_INSP]/[dbo].[ICS_CAFO_INSP_VIOL_TYPE] 
				 UNION ALL 
				SELECT KEY_HASH, I33.DATA_HASH 
				 from [dbo].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [dbo].[ICS_CAFO_INSP] [I28]
 ON [I28].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
 JOIN [dbo].[ICS_CAFO_INSP_VIOL_TYPE] [I33]
 ON [I33].[ICS_CAFO_INSP_ID] = [I28].[ICS_CAFO_INSP_ID] 
				
			 
				-- /[dbo].[ICS_CMPL_MON]/[dbo].[ICS_CMPL_INSP_TYPE] 
				 UNION ALL 
				SELECT KEY_HASH, I34.DATA_HASH 
				 from [dbo].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [dbo].[ICS_CMPL_INSP_TYPE] [I34]
 ON [I34].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
				
			 
				-- /[dbo].[ICS_CMPL_MON]/[dbo].[ICS_CMPL_MON_ACTN_REASON] 
				 UNION ALL 
				SELECT KEY_HASH, I35.DATA_HASH 
				 from [dbo].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [dbo].[ICS_CMPL_MON_ACTN_REASON] [I35]
 ON [I35].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
				
			 
				-- /[dbo].[ICS_CMPL_MON]/[dbo].[ICS_CMPL_MON_AGNCY_TYPE] 
				 UNION ALL 
				SELECT KEY_HASH, I36.DATA_HASH 
				 from [dbo].[ICS_CMPL_MON] [ICS_CMPL_MON] 
 JOIN [dbo].[ICS_CMPL_MON_AGNCY_TYPE] [I36]
 ON [I36].[ICS_CMPL_MON_ID] = [ICS_CMPL_MON].[ICS_CMPL_MON_ID] 
							  
    ),
    rolled (key_hash, rolled_hash) AS (
      SELECT
        key_hash,
        dbo.HASHBYTES_VARCHAR('SHA1',
          STRING_AGG(cast(data_hash as varchar(max)), '') WITHIN GROUP (ORDER BY data_hash)
        ) AS rolled_hash
      FROM all_hashes
      GROUP BY key_hash
    )
    UPDATE p
       SET p.data_hash = r.rolled_hash
      FROM dbo.ICS_CMPL_MON p
      JOIN rolled r ON r.key_hash = p.key_hash;
  END;

  -- [9] ICS_CMPL_MON_LNK
  IF EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P
             JOIN dbo.ICS_CMPL_MON_LNK C ON P.ICS_PAYLOAD_ID = C.ICS_PAYLOAD_ID
             WHERE P.ENABLED = 'Y')
  BEGIN
    ;WITH all_hashes (key_hash, data_hash) AS (
                     -- /ICS_CMPL_MON_LNK
                      SELECT key_hash
                           , child.data_hash
                        FROM dbo.ics_cmpl_mon_lnk child
                      UNION ALL
                      SELECT key_hash
                           , child.data_hash
                        FROM dbo.ics_cmpl_mon_lnk
                        JOIN dbo.ics_lnk_enfrc_actn child
                          ON child.ics_cmpl_mon_lnk_id = ics_cmpl_mon_lnk.ics_cmpl_mon_lnk_id
                      UNION ALL
                      SELECT key_hash
                           , child.data_hash
                        FROM dbo.ics_cmpl_mon_lnk
                        JOIN dbo.ics_lnk_sngl_evt child
                          ON child.ics_cmpl_mon_lnk_id = ics_cmpl_mon_lnk.ics_cmpl_mon_lnk_id
                      UNION ALL
                      SELECT key_hash
                           , child.data_hash
                        FROM dbo.ics_cmpl_mon_lnk
                        JOIN dbo.ics_lnk_cmpl_mon child
                          ON child.ics_cmpl_mon_lnk_id = ics_cmpl_mon_lnk.ics_cmpl_mon_lnk_id					  
    ),
    rolled (key_hash, rolled_hash) AS (
      SELECT
        key_hash,
        dbo.HASHBYTES_VARCHAR('SHA1',
          STRING_AGG(cast(data_hash as varchar(max)), '') WITHIN GROUP (ORDER BY data_hash)
        ) AS rolled_hash
      FROM all_hashes
      GROUP BY key_hash
    )
    UPDATE p
       SET p.data_hash = r.rolled_hash
      FROM dbo.ICS_CMPL_MON_LNK p
      JOIN rolled r ON r.key_hash = p.key_hash;
  END;

  -- [10] ICS_CMPL_SCHD
  IF EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P
             JOIN dbo.ICS_CMPL_SCHD C ON P.ICS_PAYLOAD_ID = C.ICS_PAYLOAD_ID
             WHERE P.ENABLED = 'Y')
  BEGIN
    ;WITH all_hashes (key_hash, data_hash) AS (

				
			 
				-- /[dbo].[ICS_CMPL_SCHD] 
				
				SELECT KEY_HASH, ICS_CMPL_SCHD.DATA_HASH 
				 from [dbo].[ICS_CMPL_SCHD] [ICS_CMPL_SCHD] 
				
			 
				-- /[dbo].[ICS_CMPL_SCHD]/[dbo].[ICS_CMPL_SCHD_EVT] 
				 UNION ALL 
				SELECT KEY_HASH, I1.DATA_HASH 
				 from [dbo].[ICS_CMPL_SCHD] [ICS_CMPL_SCHD] 
 JOIN [dbo].[ICS_CMPL_SCHD_EVT] [I1]
 ON [I1].[ICS_CMPL_SCHD_ID] = [ICS_CMPL_SCHD].[ICS_CMPL_SCHD_ID] 
							  
    ),
    rolled (key_hash, rolled_hash) AS (
      SELECT
        key_hash,
        dbo.HASHBYTES_VARCHAR('SHA1',
          STRING_AGG(cast(data_hash as varchar(max)), '') WITHIN GROUP (ORDER BY data_hash)
        ) AS rolled_hash
      FROM all_hashes
      GROUP BY key_hash
    )
    UPDATE p
       SET p.data_hash = r.rolled_hash
      FROM dbo.ICS_CMPL_SCHD p
      JOIN rolled r ON r.key_hash = p.key_hash;
  END;

  -- [11] ICS_COPY_MGP_LMT_SET
  IF EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P
             JOIN dbo.ICS_COPY_MGP_LMT_SET C ON P.ICS_PAYLOAD_ID = C.ICS_PAYLOAD_ID
             WHERE P.ENABLED = 'Y')
  BEGIN
    ;WITH all_hashes (key_hash, data_hash) AS (
                      -- /ICS_COPY_MGP_LMT_SET
                      SELECT key_hash
                           , child.data_hash
                        FROM dbo.ics_copy_mgp_lmt_set child
                      UNION ALL
                      -- /ICS_COPY_MGP_LMT_SET/ICS_LMT_SET_SCHD
                      SELECT key_hash
                           , child.data_hash
                        FROM dbo.ics_copy_mgp_lmt_set
                        JOIN dbo.ics_lmt_set_schd child
                          ON child.ics_copy_mgp_lmt_set_id = ICS_COPY_MGP_LMT_SET.ics_copy_mgp_lmt_set_id
                      UNION ALL
                      -- /ICS_COPY_MGP_LMT_SET/ICS_LMT_SET_STAT
                      SELECT key_hash
                           , child.data_hash
                        FROM dbo.ics_copy_mgp_lmt_set
                        JOIN dbo.ics_lmt_set_stat child
                          ON child.ics_copy_mgp_lmt_set_id = ICS_COPY_MGP_LMT_SET.ics_copy_mgp_lmt_set_id
                      UNION ALL
                      -- /ICS_COPY_MGP_LMT_SET/ICS_GEO_COORD
                      SELECT key_hash
                           , child.data_hash
                        FROM dbo.ics_copy_mgp_lmt_set
                        JOIN dbo.ics_geo_coord child
                          ON child.ics_copy_mgp_lmt_set_id = ICS_COPY_MGP_LMT_SET.ics_copy_mgp_lmt_set_id
							  
    ),
    rolled (key_hash, rolled_hash) AS (
      SELECT
        key_hash,
        dbo.HASHBYTES_VARCHAR('SHA1',
          STRING_AGG(cast(data_hash as varchar(max)), '') WITHIN GROUP (ORDER BY data_hash)
        ) AS rolled_hash
      FROM all_hashes
      GROUP BY key_hash
    )
    UPDATE p
       SET p.data_hash = r.rolled_hash
      FROM dbo.ICS_COPY_MGP_LMT_SET p
      JOIN rolled r ON r.key_hash = p.key_hash;
  END;

  -- [12] ICS_COPY_MGPMS_4_REQ
  IF EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P
             JOIN dbo.ICS_COPY_MGPMS_4_REQ C ON P.ICS_PAYLOAD_ID = C.ICS_PAYLOAD_ID
             WHERE P.ENABLED = 'Y')
  BEGIN
    ;WITH all_hashes (key_hash, data_hash) AS (

				
			 
				-- /[dbo].[ICS_COPY_MGPMS_4_REQ] 
				
				SELECT KEY_HASH, ICS_COPY_MGPMS_4_REQ.DATA_HASH 
				 from [dbo].[ICS_COPY_MGPMS_4_REQ] [ICS_COPY_MGPMS_4_REQ] 
				
			 
				-- /[dbo].[ICS_COPY_MGPMS_4_REQ]/[dbo].[ICS_GNRL_PRMT_COVERAGE_MS_4_REQ] 
				 UNION ALL 
				SELECT KEY_HASH, I1.DATA_HASH 
				 from [dbo].[ICS_COPY_MGPMS_4_REQ] [ICS_COPY_MGPMS_4_REQ] 
 JOIN [dbo].[ICS_GNRL_PRMT_COVERAGE_MS_4_REQ] [I1]
 ON [I1].[ICS_COPY_MGPMS_4_REQ_ID] = [ICS_COPY_MGPMS_4_REQ].[ICS_COPY_MGPMS_4_REQ_ID] 
				
			 
				-- /[dbo].[ICS_COPY_MGPMS_4_REQ]/[dbo].[ICS_GNRL_PRMT_COVERAGE_MS_4_REQ]/[dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT] 
				 UNION ALL 
				SELECT KEY_HASH, I2.DATA_HASH 
				 from [dbo].[ICS_COPY_MGPMS_4_REQ] [ICS_COPY_MGPMS_4_REQ] 
 JOIN [dbo].[ICS_GNRL_PRMT_COVERAGE_MS_4_REQ] [I1]
 ON [I1].[ICS_COPY_MGPMS_4_REQ_ID] = [ICS_COPY_MGPMS_4_REQ].[ICS_COPY_MGPMS_4_REQ_ID] 
 JOIN [dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT] [I2]
 ON [I2].[ICS_GNRL_PRMT_COVERAGE_MS_4_REQ_ID] = [I1].[ICS_GNRL_PRMT_COVERAGE_MS_4_REQ_ID] 
				
			 
				-- /[dbo].[ICS_COPY_MGPMS_4_REQ]/[dbo].[ICS_MS_4_ACTY_IDENT] 
				 UNION ALL 
				SELECT KEY_HASH, I3.DATA_HASH 
				 from [dbo].[ICS_COPY_MGPMS_4_REQ] [ICS_COPY_MGPMS_4_REQ] 
 JOIN [dbo].[ICS_MS_4_ACTY_IDENT] [I3]
 ON [I3].[ICS_COPY_MGPMS_4_REQ_ID] = [ICS_COPY_MGPMS_4_REQ].[ICS_COPY_MGPMS_4_REQ_ID] 
							  
    ),
    rolled (key_hash, rolled_hash) AS (
      SELECT
        key_hash,
        dbo.HASHBYTES_VARCHAR('SHA1',
          STRING_AGG(cast(data_hash as varchar(max)), '') WITHIN GROUP (ORDER BY data_hash)
        ) AS rolled_hash
      FROM all_hashes
      GROUP BY key_hash
    )
    UPDATE p
       SET p.data_hash = r.rolled_hash
      FROM dbo.ICS_COPY_MGPMS_4_REQ p
      JOIN rolled r ON r.key_hash = p.key_hash;
  END;

  -- [13] ICS_CSO_LONG_TERM_CONTROL_PLAN
  IF EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P
             JOIN dbo.ICS_CSO_LONG_TERM_CONTROL_PLAN C ON P.ICS_PAYLOAD_ID = C.ICS_PAYLOAD_ID
             WHERE P.ENABLED = 'Y')
  BEGIN
    ;WITH all_hashes (key_hash, data_hash) AS (

				
			 
				-- /[dbo].[ICS_CSO_LONG_TERM_CONTROL_PLAN] 
				
				SELECT KEY_HASH, ICS_CSO_LONG_TERM_CONTROL_PLAN.DATA_HASH 
				 from [dbo].[ICS_CSO_LONG_TERM_CONTROL_PLAN] [ICS_CSO_LONG_TERM_CONTROL_PLAN] 
				
			 
				-- /[dbo].[ICS_CSO_LONG_TERM_CONTROL_PLAN]/[dbo].[ICS_CSO_CONTROL_MEAS_DETAIL] 
				 UNION ALL 
				SELECT KEY_HASH, I1.DATA_HASH 
				 from [dbo].[ICS_CSO_LONG_TERM_CONTROL_PLAN] [ICS_CSO_LONG_TERM_CONTROL_PLAN] 
 JOIN [dbo].[ICS_CSO_CONTROL_MEAS_DETAIL] [I1]
 ON [I1].[ICS_CSO_LONG_TERM_CONTROL_PLAN_ID] = [ICS_CSO_LONG_TERM_CONTROL_PLAN].[ICS_CSO_LONG_TERM_CONTROL_PLAN_ID] 
				
			 
				-- /[dbo].[ICS_CSO_LONG_TERM_CONTROL_PLAN]/[dbo].[ICS_LTCP_ENFORCEABLE_MECH_DETAIL] 
				 UNION ALL 
				SELECT KEY_HASH, I2.DATA_HASH 
				 from [dbo].[ICS_CSO_LONG_TERM_CONTROL_PLAN] [ICS_CSO_LONG_TERM_CONTROL_PLAN] 
 JOIN [dbo].[ICS_LTCP_ENFORCEABLE_MECH_DETAIL] [I2]
 ON [I2].[ICS_CSO_LONG_TERM_CONTROL_PLAN_ID] = [ICS_CSO_LONG_TERM_CONTROL_PLAN].[ICS_CSO_LONG_TERM_CONTROL_PLAN_ID] 
				
			 
				-- /[dbo].[ICS_CSO_LONG_TERM_CONTROL_PLAN]/[dbo].[ICS_LTCP_MOST_RECENT_REVISION_DETAIL] 
				 UNION ALL 
				SELECT KEY_HASH, I3.DATA_HASH 
				 from [dbo].[ICS_CSO_LONG_TERM_CONTROL_PLAN] [ICS_CSO_LONG_TERM_CONTROL_PLAN] 
 JOIN [dbo].[ICS_LTCP_MOST_RECENT_REVISION_DETAIL] [I3]
 ON [I3].[ICS_CSO_LONG_TERM_CONTROL_PLAN_ID] = [ICS_CSO_LONG_TERM_CONTROL_PLAN].[ICS_CSO_LONG_TERM_CONTROL_PLAN_ID] 
				
			 
				-- /[dbo].[ICS_CSO_LONG_TERM_CONTROL_PLAN]/[dbo].[ICS_LTCP_SUMM] 
				 UNION ALL 
				SELECT KEY_HASH, I4.DATA_HASH 
				 from [dbo].[ICS_CSO_LONG_TERM_CONTROL_PLAN] [ICS_CSO_LONG_TERM_CONTROL_PLAN] 
 JOIN [dbo].[ICS_LTCP_SUMM] [I4]
 ON [I4].[ICS_CSO_LONG_TERM_CONTROL_PLAN_ID] = [ICS_CSO_LONG_TERM_CONTROL_PLAN].[ICS_CSO_LONG_TERM_CONTROL_PLAN_ID] 
							  
    ),
    rolled (key_hash, rolled_hash) AS (
      SELECT
        key_hash,
        dbo.HASHBYTES_VARCHAR('SHA1',
          STRING_AGG(cast(data_hash as varchar(max)), '') WITHIN GROUP (ORDER BY data_hash)
        ) AS rolled_hash
      FROM all_hashes
      GROUP BY key_hash
    )
    UPDATE p
       SET p.data_hash = r.rolled_hash
      FROM dbo.ICS_CSO_LONG_TERM_CONTROL_PLAN p
      JOIN rolled r ON r.key_hash = p.key_hash;
  END;

  -- [14] ICS_CWA_316B_PROG_REP
  IF EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P
             JOIN dbo.ICS_CWA_316B_PROG_REP C ON P.ICS_PAYLOAD_ID = C.ICS_PAYLOAD_ID
             WHERE P.ENABLED = 'Y')
  BEGIN
    ;WITH all_hashes (key_hash, data_hash) AS (

				
			 
				-- /[dbo].[ICS_CWA_316B_PROG_REP] 
				
				SELECT KEY_HASH, ICS_CWA_316B_PROG_REP.DATA_HASH 
				 from [dbo].[ICS_CWA_316B_PROG_REP] [ICS_CWA_316B_PROG_REP] 
				
			 
				-- /[dbo].[ICS_CWA_316B_PROG_REP]/[dbo].[ICS_CWA_316B_TAKE_INFO] 
				 UNION ALL 
				SELECT KEY_HASH, I1.DATA_HASH 
				 from [dbo].[ICS_CWA_316B_PROG_REP] [ICS_CWA_316B_PROG_REP] 
 JOIN [dbo].[ICS_CWA_316B_TAKE_INFO] [I1]
 ON [I1].[ICS_CWA_316B_PROG_REP_ID] = [ICS_CWA_316B_PROG_REP].[ICS_CWA_316B_PROG_REP_ID] 
							  
    ),
    rolled (key_hash, rolled_hash) AS (
      SELECT
        key_hash,
        dbo.HASHBYTES_VARCHAR('SHA1',
          STRING_AGG(cast(data_hash as varchar(max)), '') WITHIN GROUP (ORDER BY data_hash)
        ) AS rolled_hash
      FROM all_hashes
      GROUP BY key_hash
    )
    UPDATE p
       SET p.data_hash = r.rolled_hash
      FROM dbo.ICS_CWA_316B_PROG_REP p
      JOIN rolled r ON r.key_hash = p.key_hash;
  END;

  -- [15] ICS_DSCH_MON_REP
  IF EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P
             JOIN dbo.ICS_DSCH_MON_REP C ON P.ICS_PAYLOAD_ID = C.ICS_PAYLOAD_ID
             WHERE P.ENABLED = 'Y')
  BEGIN
    ;WITH all_hashes (key_hash, data_hash) AS (

				
			 
				-- /[dbo].[ICS_DSCH_MON_REP] 
				
				SELECT KEY_HASH, ICS_DSCH_MON_REP.DATA_HASH 
				 from [dbo].[ICS_DSCH_MON_REP] [ICS_DSCH_MON_REP] 
				
			 
				-- /[dbo].[ICS_DSCH_MON_REP]/[dbo].[ICS_REP_PARAM] 
				 UNION ALL 
				SELECT KEY_HASH, I1.DATA_HASH 
				 from [dbo].[ICS_DSCH_MON_REP] [ICS_DSCH_MON_REP] 
 JOIN [dbo].[ICS_REP_PARAM] [I1]
 ON [I1].[ICS_DSCH_MON_REP_ID] = [ICS_DSCH_MON_REP].[ICS_DSCH_MON_REP_ID] 
				
			 
				-- /[dbo].[ICS_DSCH_MON_REP]/[dbo].[ICS_REP_PARAM]/[dbo].[ICS_NUM_REP] 
				 UNION ALL 
				SELECT KEY_HASH, I2.DATA_HASH 
				 from [dbo].[ICS_DSCH_MON_REP] [ICS_DSCH_MON_REP] 
 JOIN [dbo].[ICS_REP_PARAM] [I1]
 ON [I1].[ICS_DSCH_MON_REP_ID] = [ICS_DSCH_MON_REP].[ICS_DSCH_MON_REP_ID] 
 JOIN [dbo].[ICS_NUM_REP] [I2]
 ON [I2].[ICS_REP_PARAM_ID] = [I1].[ICS_REP_PARAM_ID] 
				
			 
				-- /[dbo].[ICS_DSCH_MON_REP]/[dbo].[ICS_INCIN] 
				 UNION ALL 
				SELECT KEY_HASH, I3.DATA_HASH 
				 from [dbo].[ICS_DSCH_MON_REP] [ICS_DSCH_MON_REP] 
 JOIN [dbo].[ICS_INCIN] [I3]
 ON [I3].[ICS_DSCH_MON_REP_ID] = [ICS_DSCH_MON_REP].[ICS_DSCH_MON_REP_ID] 
				
			 
				-- /[dbo].[ICS_DSCH_MON_REP]/[dbo].[ICS_LAND_APPL_SITE] 
				 UNION ALL 
				SELECT KEY_HASH, I4.DATA_HASH 
				 from [dbo].[ICS_DSCH_MON_REP] [ICS_DSCH_MON_REP] 
 JOIN [dbo].[ICS_LAND_APPL_SITE] [I4]
 ON [I4].[ICS_DSCH_MON_REP_ID] = [ICS_DSCH_MON_REP].[ICS_DSCH_MON_REP_ID] 
				
			 
				-- /[dbo].[ICS_DSCH_MON_REP]/[dbo].[ICS_LAND_APPL_SITE]/[dbo].[ICS_CROP_TYPES_HARVESTED] 
				 UNION ALL 
				SELECT KEY_HASH, I5.DATA_HASH 
				 from [dbo].[ICS_DSCH_MON_REP] [ICS_DSCH_MON_REP] 
 JOIN [dbo].[ICS_LAND_APPL_SITE] [I4]
 ON [I4].[ICS_DSCH_MON_REP_ID] = [ICS_DSCH_MON_REP].[ICS_DSCH_MON_REP_ID] 
 JOIN [dbo].[ICS_CROP_TYPES_HARVESTED] [I5]
 ON [I5].[ICS_LAND_APPL_SITE_ID] = [I4].[ICS_LAND_APPL_SITE_ID] 
				
			 
				-- /[dbo].[ICS_DSCH_MON_REP]/[dbo].[ICS_LAND_APPL_SITE]/[dbo].[ICS_CROP_TYPES_PLANTED] 
				 UNION ALL 
				SELECT KEY_HASH, I6.DATA_HASH 
				 from [dbo].[ICS_DSCH_MON_REP] [ICS_DSCH_MON_REP] 
 JOIN [dbo].[ICS_LAND_APPL_SITE] [I4]
 ON [I4].[ICS_DSCH_MON_REP_ID] = [ICS_DSCH_MON_REP].[ICS_DSCH_MON_REP_ID] 
 JOIN [dbo].[ICS_CROP_TYPES_PLANTED] [I6]
 ON [I6].[ICS_LAND_APPL_SITE_ID] = [I4].[ICS_LAND_APPL_SITE_ID] 
				
			 
				-- /[dbo].[ICS_DSCH_MON_REP]/[dbo].[ICS_SURF_DSPL_SITE] 
				 UNION ALL 
				SELECT KEY_HASH, I7.DATA_HASH 
				 from [dbo].[ICS_DSCH_MON_REP] [ICS_DSCH_MON_REP] 
 JOIN [dbo].[ICS_SURF_DSPL_SITE] [I7]
 ON [I7].[ICS_DSCH_MON_REP_ID] = [ICS_DSCH_MON_REP].[ICS_DSCH_MON_REP_ID] 
				
			 
				-- /[dbo].[ICS_DSCH_MON_REP]/[dbo].[ICS_CO_DSPL_SITE] 
				 UNION ALL 
				SELECT KEY_HASH, I8.DATA_HASH 
				 from [dbo].[ICS_DSCH_MON_REP] [ICS_DSCH_MON_REP] 
 JOIN [dbo].[ICS_CO_DSPL_SITE] [I8]
 ON [I8].[ICS_DSCH_MON_REP_ID] = [ICS_DSCH_MON_REP].[ICS_DSCH_MON_REP_ID] 
							  
    ),
    rolled (key_hash, rolled_hash) AS (
      SELECT
        key_hash,
        dbo.HASHBYTES_VARCHAR('SHA1',
          STRING_AGG(cast(data_hash as varchar(max)), '') WITHIN GROUP (ORDER BY data_hash)
        ) AS rolled_hash
      FROM all_hashes
      GROUP BY key_hash
    )
    UPDATE p
       SET p.data_hash = r.rolled_hash
      FROM dbo.ICS_DSCH_MON_REP p
      JOIN rolled r ON r.key_hash = p.key_hash;
  END;

  -- [16] ICS_DMR_VIOL
  IF EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P
             JOIN dbo.ICS_DMR_VIOL C ON P.ICS_PAYLOAD_ID = C.ICS_PAYLOAD_ID
             WHERE P.ENABLED = 'Y')
  BEGIN
    ;WITH all_hashes (key_hash, data_hash) AS (

				
			 
				-- /[dbo].[ICS_DMR_VIOL] 
				
				SELECT KEY_HASH, ICS_DMR_VIOL.DATA_HASH 
				 from [dbo].[ICS_DMR_VIOL] [ICS_DMR_VIOL] 
							  
    ),
    rolled (key_hash, rolled_hash) AS (
      SELECT
        key_hash,
        dbo.HASHBYTES_VARCHAR('SHA1',
          STRING_AGG(cast(data_hash as varchar(max)), '') WITHIN GROUP (ORDER BY data_hash)
        ) AS rolled_hash
      FROM all_hashes
      GROUP BY key_hash
    )
    UPDATE p
       SET p.data_hash = r.rolled_hash
      FROM dbo.ICS_DMR_VIOL p
      JOIN rolled r ON r.key_hash = p.key_hash;
  END;

  -- [17] ICS_EFFLU_TRADE_PRTNER
  IF EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P
             JOIN dbo.ICS_EFFLU_TRADE_PRTNER C ON P.ICS_PAYLOAD_ID = C.ICS_PAYLOAD_ID
             WHERE P.ENABLED = 'Y')
  BEGIN
    ;WITH all_hashes (key_hash, data_hash) AS (

				
			 
				-- /[dbo].[ICS_EFFLU_TRADE_PRTNER] 
				
				SELECT KEY_HASH, ICS_EFFLU_TRADE_PRTNER.DATA_HASH 
				 from [dbo].[ICS_EFFLU_TRADE_PRTNER] [ICS_EFFLU_TRADE_PRTNER] 
				
			 
				-- /[dbo].[ICS_EFFLU_TRADE_PRTNER]/[dbo].[ICS_EFFLU_TRADE_PRTNER_ADDR] 
				 UNION ALL 
				SELECT KEY_HASH, I1.DATA_HASH 
				 from [dbo].[ICS_EFFLU_TRADE_PRTNER] [ICS_EFFLU_TRADE_PRTNER] 
 JOIN [dbo].[ICS_EFFLU_TRADE_PRTNER_ADDR] [I1]
 ON [I1].[ICS_EFFLU_TRADE_PRTNER_ID] = [ICS_EFFLU_TRADE_PRTNER].[ICS_EFFLU_TRADE_PRTNER_ID] 
				
			 
				-- /[dbo].[ICS_EFFLU_TRADE_PRTNER]/[dbo].[ICS_EFFLU_TRADE_PRTNER_ADDR]/[dbo].[ICS_TELEPH] 
				 UNION ALL 
				SELECT KEY_HASH, I2.DATA_HASH 
				 from [dbo].[ICS_EFFLU_TRADE_PRTNER] [ICS_EFFLU_TRADE_PRTNER] 
 JOIN [dbo].[ICS_EFFLU_TRADE_PRTNER_ADDR] [I1]
 ON [I1].[ICS_EFFLU_TRADE_PRTNER_ID] = [ICS_EFFLU_TRADE_PRTNER].[ICS_EFFLU_TRADE_PRTNER_ID] 
 JOIN [dbo].[ICS_TELEPH] [I2]
 ON [I2].[ICS_EFFLU_TRADE_PRTNER_ADDR_ID] = [I1].[ICS_EFFLU_TRADE_PRTNER_ADDR_ID] 
							  
    ),
    rolled (key_hash, rolled_hash) AS (
      SELECT
        key_hash,
        dbo.HASHBYTES_VARCHAR('SHA1',
          STRING_AGG(cast(data_hash as varchar(max)), '') WITHIN GROUP (ORDER BY data_hash)
        ) AS rolled_hash
      FROM all_hashes
      GROUP BY key_hash
    )
    UPDATE p
       SET p.data_hash = r.rolled_hash
      FROM dbo.ICS_EFFLU_TRADE_PRTNER p
      JOIN rolled r ON r.key_hash = p.key_hash;
  END;

  -- [18] ICS_ENFRC_ACTN_MILESTONE
  IF EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P
             JOIN dbo.ICS_ENFRC_ACTN_MILESTONE C ON P.ICS_PAYLOAD_ID = C.ICS_PAYLOAD_ID
             WHERE P.ENABLED = 'Y')
  BEGIN
    ;WITH all_hashes (key_hash, data_hash) AS (

				
			 
				-- /[dbo].[ICS_ENFRC_ACTN_MILESTONE] 
				
				SELECT KEY_HASH, ICS_ENFRC_ACTN_MILESTONE.DATA_HASH 
				 from [dbo].[ICS_ENFRC_ACTN_MILESTONE] [ICS_ENFRC_ACTN_MILESTONE] 
							  
    ),
    rolled (key_hash, rolled_hash) AS (
      SELECT
        key_hash,
        dbo.HASHBYTES_VARCHAR('SHA1',
          STRING_AGG(cast(data_hash as varchar(max)), '') WITHIN GROUP (ORDER BY data_hash)
        ) AS rolled_hash
      FROM all_hashes
      GROUP BY key_hash
    )
    UPDATE p
       SET p.data_hash = r.rolled_hash
      FROM dbo.ICS_ENFRC_ACTN_MILESTONE p
      JOIN rolled r ON r.key_hash = p.key_hash;
  END;

  -- [19] ICS_ENFRC_ACTN_VIOL_LNK
  IF EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P
             JOIN dbo.ICS_ENFRC_ACTN_VIOL_LNK C ON P.ICS_PAYLOAD_ID = C.ICS_PAYLOAD_ID
             WHERE P.ENABLED = 'Y')
  BEGIN
    ;WITH all_hashes (key_hash, data_hash) AS (
                     -- /ICS_ENFRC_ACTN_VIOL_LNK
                      SELECT key_hash
                           , child.data_hash
                        FROM dbo.ics_enfrc_actn_viol_lnk child
                      UNION ALL
                      -- /ICS_ENFRC_ACTN_VIOL_LNK/ICS_CMPL_SCHD_VIOL
                      SELECT key_hash
                           , child.data_hash
                        FROM dbo.ics_enfrc_actn_viol_lnk
                        JOIN dbo.ics_cmpl_schd_viol child
                          ON child.ics_enfrc_actn_viol_lnk_id = ics_enfrc_actn_viol_lnk.ics_enfrc_actn_viol_lnk_id
                      UNION ALL
                      -- /ICS_ENFRC_ACTN_VIOL_LNK/ICS_DSCH_MON_REP_PARAM_VIOL
                      SELECT key_hash
                           , child.data_hash
                        FROM dbo.ics_enfrc_actn_viol_lnk
                        JOIN dbo.ics_dsch_mon_rep_param_viol child
                          ON child.ics_enfrc_actn_viol_lnk_id = ics_enfrc_actn_viol_lnk.ics_enfrc_actn_viol_lnk_id
                      UNION ALL
                      -- /ICS_ENFRC_ACTN_VIOL_LNK/ICS_DSCH_MON_REP_VIOL
                      SELECT key_hash
                           , child.data_hash
                        FROM dbo.ics_enfrc_actn_viol_lnk
                        JOIN dbo.ics_dsch_mon_rep_viol child
                          ON child.ics_enfrc_actn_viol_lnk_id = ics_enfrc_actn_viol_lnk.ics_enfrc_actn_viol_lnk_id
                      UNION ALL
                      -- /ICS_ENFRC_ACTN_VIOL_LNK/ICS_PRMT_SCHD_VIOL
                      SELECT key_hash
                           , child.data_hash
                        FROM dbo.ics_enfrc_actn_viol_lnk
                        JOIN dbo.ics_prmt_schd_viol child
                          ON child.ics_enfrc_actn_viol_lnk_id = ics_enfrc_actn_viol_lnk.ics_enfrc_actn_viol_lnk_id
                      UNION ALL
                      -- /ICS_ENFRC_ACTN_VIOL_LNK/ICS_SNGL_EVTS_VIOL
                      SELECT key_hash
                           , child.data_hash
                        FROM dbo.ics_enfrc_actn_viol_lnk
                        JOIN dbo.ics_sngl_evts_viol child
                          ON child.ics_enfrc_actn_viol_lnk_id = ics_enfrc_actn_viol_lnk.ics_enfrc_actn_viol_lnk_id
							  
    ),
    rolled (key_hash, rolled_hash) AS (
      SELECT
        key_hash,
        dbo.HASHBYTES_VARCHAR('SHA1',
          STRING_AGG(cast(data_hash as varchar(max)), '') WITHIN GROUP (ORDER BY data_hash)
        ) AS rolled_hash
      FROM all_hashes
      GROUP BY key_hash
    )
    UPDATE p
       SET p.data_hash = r.rolled_hash
      FROM dbo.ICS_ENFRC_ACTN_VIOL_LNK p
      JOIN rolled r ON r.key_hash = p.key_hash;
  END;

  -- [20] ICS_FINAL_ORDER_VIOL_LNK
  IF EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P
             JOIN dbo.ICS_FINAL_ORDER_VIOL_LNK C ON P.ICS_PAYLOAD_ID = C.ICS_PAYLOAD_ID
             WHERE P.ENABLED = 'Y')
  BEGIN
    ;WITH all_hashes (key_hash, data_hash) AS (
                      -- /ICS_FINAL_ORDER_VIOL_LNK
                      SELECT key_hash
                           , child.data_hash
                        FROM dbo.ics_final_order_viol_lnk child
                      UNION ALL
                      -- /ICS_FINAL_ORDER_VIOL_LNK/ICS_CMPL_SCHD_VIOL
                      SELECT key_hash
                           , child.data_hash
                        FROM dbo.ics_final_order_viol_lnk
                        JOIN dbo.ics_cmpl_schd_viol child
                          ON child.ics_final_order_viol_lnk_id = ics_final_order_viol_lnk.ics_final_order_viol_lnk_id
                      UNION ALL
                      -- /ICS_FINAL_ORDER_VIOL_LNK/ICS_DSCH_MON_REP_PARAM_VIOL
                      SELECT key_hash
                           , child.data_hash
                        FROM dbo.ics_final_order_viol_lnk
                        JOIN dbo.ics_dsch_mon_rep_param_viol child
                          ON child.ics_final_order_viol_lnk_id = ics_final_order_viol_lnk.ics_final_order_viol_lnk_id
                      UNION ALL
                      -- /ICS_FINAL_ORDER_VIOL_LNK/ICS_DSCH_MON_REP_VIOL
                      SELECT key_hash
                           , child.data_hash
                        FROM dbo.ics_final_order_viol_lnk
                        JOIN dbo.ics_dsch_mon_rep_viol child
                          ON child.ics_final_order_viol_lnk_id = ics_final_order_viol_lnk.ics_final_order_viol_lnk_id
                      UNION ALL
                      -- /ICS_FINAL_ORDER_VIOL_LNK/ICS_PRMT_SCHD_VIOL
                      SELECT key_hash
                           , child.data_hash
                        FROM dbo.ics_final_order_viol_lnk
                        JOIN dbo.ics_prmt_schd_viol child
                          ON child.ics_final_order_viol_lnk_id = ics_final_order_viol_lnk.ics_final_order_viol_lnk_id
                      UNION ALL
                      -- /ICS_FINAL_ORDER_VIOL_LNK/ICS_SNGL_EVTS_VIOL
                      SELECT key_hash
                           , child.data_hash
                        FROM dbo.ics_final_order_viol_lnk
                        JOIN dbo.ics_sngl_evts_viol child
                          ON child.ics_final_order_viol_lnk_id = ics_final_order_viol_lnk.ics_final_order_viol_lnk_id
							  
    ),
    rolled (key_hash, rolled_hash) AS (
      SELECT
        key_hash,
        dbo.HASHBYTES_VARCHAR('SHA1',
          STRING_AGG(cast(data_hash as varchar(max)), '') WITHIN GROUP (ORDER BY data_hash)
        ) AS rolled_hash
      FROM all_hashes
      GROUP BY key_hash
    )
    UPDATE p
       SET p.data_hash = r.rolled_hash
      FROM dbo.ICS_FINAL_ORDER_VIOL_LNK p
      JOIN rolled r ON r.key_hash = p.key_hash;
  END;

  -- [21] ICS_FRML_ENFRC_ACTN
  IF EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P
             JOIN dbo.ICS_FRML_ENFRC_ACTN C ON P.ICS_PAYLOAD_ID = C.ICS_PAYLOAD_ID
             WHERE P.ENABLED = 'Y')
  BEGIN
    ;WITH all_hashes (key_hash, data_hash) AS (

				
			 
				-- /[dbo].[ICS_FRML_ENFRC_ACTN] 
				
				SELECT KEY_HASH, ICS_FRML_ENFRC_ACTN.DATA_HASH 
				 from [dbo].[ICS_FRML_ENFRC_ACTN] [ICS_FRML_ENFRC_ACTN] 
				
			 
				-- /[dbo].[ICS_FRML_ENFRC_ACTN]/[dbo].[ICS_PRMT_IDENT] 
				 UNION ALL 
				SELECT KEY_HASH, I1.DATA_HASH 
				 from [dbo].[ICS_FRML_ENFRC_ACTN] [ICS_FRML_ENFRC_ACTN] 
 JOIN [dbo].[ICS_PRMT_IDENT] [I1]
 ON [I1].[ICS_FRML_ENFRC_ACTN_ID] = [ICS_FRML_ENFRC_ACTN].[ICS_FRML_ENFRC_ACTN_ID] 
				
			 
				-- /[dbo].[ICS_FRML_ENFRC_ACTN]/[dbo].[ICS_ENFRC_ACTN_GOV_CONTACT] 
				 UNION ALL 
				SELECT KEY_HASH, I2.DATA_HASH 
				 from [dbo].[ICS_FRML_ENFRC_ACTN] [ICS_FRML_ENFRC_ACTN] 
 JOIN [dbo].[ICS_ENFRC_ACTN_GOV_CONTACT] [I2]
 ON [I2].[ICS_FRML_ENFRC_ACTN_ID] = [ICS_FRML_ENFRC_ACTN].[ICS_FRML_ENFRC_ACTN_ID] 
				
			 
				-- /[dbo].[ICS_FRML_ENFRC_ACTN]/[dbo].[ICS_ENFRC_ACTN_TYPE] 
				 UNION ALL 
				SELECT KEY_HASH, I3.DATA_HASH 
				 from [dbo].[ICS_FRML_ENFRC_ACTN] [ICS_FRML_ENFRC_ACTN] 
 JOIN [dbo].[ICS_ENFRC_ACTN_TYPE] [I3]
 ON [I3].[ICS_FRML_ENFRC_ACTN_ID] = [ICS_FRML_ENFRC_ACTN].[ICS_FRML_ENFRC_ACTN_ID] 
				
			 
				-- /[dbo].[ICS_FRML_ENFRC_ACTN]/[dbo].[ICS_ENFRC_AGNCY] 
				 UNION ALL 
				SELECT KEY_HASH, I4.DATA_HASH 
				 from [dbo].[ICS_FRML_ENFRC_ACTN] [ICS_FRML_ENFRC_ACTN] 
 JOIN [dbo].[ICS_ENFRC_AGNCY] [I4]
 ON [I4].[ICS_FRML_ENFRC_ACTN_ID] = [ICS_FRML_ENFRC_ACTN].[ICS_FRML_ENFRC_ACTN_ID] 
				
			 
				-- /[dbo].[ICS_FRML_ENFRC_ACTN]/[dbo].[ICS_PROGS_VIOL] 
				 UNION ALL 
				SELECT KEY_HASH, I5.DATA_HASH 
				 from [dbo].[ICS_FRML_ENFRC_ACTN] [ICS_FRML_ENFRC_ACTN] 
 JOIN [dbo].[ICS_PROGS_VIOL] [I5]
 ON [I5].[ICS_FRML_ENFRC_ACTN_ID] = [ICS_FRML_ENFRC_ACTN].[ICS_FRML_ENFRC_ACTN_ID] 
				
			 
				-- /[dbo].[ICS_FRML_ENFRC_ACTN]/[dbo].[ICS_FINAL_ORDER] 
				 UNION ALL 
				SELECT KEY_HASH, I6.DATA_HASH 
				 from [dbo].[ICS_FRML_ENFRC_ACTN] [ICS_FRML_ENFRC_ACTN] 
 JOIN [dbo].[ICS_FINAL_ORDER] [I6]
 ON [I6].[ICS_FRML_ENFRC_ACTN_ID] = [ICS_FRML_ENFRC_ACTN].[ICS_FRML_ENFRC_ACTN_ID] 
				
			 
				-- /[dbo].[ICS_FRML_ENFRC_ACTN]/[dbo].[ICS_FINAL_ORDER]/[dbo].[ICS_FINAL_ORDER_PRMT_IDENT] 
				 UNION ALL 
				SELECT KEY_HASH, I7.DATA_HASH 
				 from [dbo].[ICS_FRML_ENFRC_ACTN] [ICS_FRML_ENFRC_ACTN] 
 JOIN [dbo].[ICS_FINAL_ORDER] [I6]
 ON [I6].[ICS_FRML_ENFRC_ACTN_ID] = [ICS_FRML_ENFRC_ACTN].[ICS_FRML_ENFRC_ACTN_ID] 
 JOIN [dbo].[ICS_FINAL_ORDER_PRMT_IDENT] [I7]
 ON [I7].[ICS_FINAL_ORDER_ID] = [I6].[ICS_FINAL_ORDER_ID] 
				
			 
				-- /[dbo].[ICS_FRML_ENFRC_ACTN]/[dbo].[ICS_FINAL_ORDER]/[dbo].[ICS_SEP] 
				 UNION ALL 
				SELECT KEY_HASH, I8.DATA_HASH 
				 from [dbo].[ICS_FRML_ENFRC_ACTN] [ICS_FRML_ENFRC_ACTN] 
 JOIN [dbo].[ICS_FINAL_ORDER] [I6]
 ON [I6].[ICS_FRML_ENFRC_ACTN_ID] = [ICS_FRML_ENFRC_ACTN].[ICS_FRML_ENFRC_ACTN_ID] 
 JOIN [dbo].[ICS_SEP] [I8]
 ON [I8].[ICS_FINAL_ORDER_ID] = [I6].[ICS_FINAL_ORDER_ID] 
							  
    ),
    rolled (key_hash, rolled_hash) AS (
      SELECT
        key_hash,
        dbo.HASHBYTES_VARCHAR('SHA1',
          STRING_AGG(cast(data_hash as varchar(max)), '') WITHIN GROUP (ORDER BY data_hash)
        ) AS rolled_hash
      FROM all_hashes
      GROUP BY key_hash
    )
    UPDATE p
       SET p.data_hash = r.rolled_hash
      FROM dbo.ICS_FRML_ENFRC_ACTN p
      JOIN rolled r ON r.key_hash = p.key_hash;
  END;

  -- [22] ICS_GNRL_PRMT
  IF EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P
             JOIN dbo.ICS_GNRL_PRMT C ON P.ICS_PAYLOAD_ID = C.ICS_PAYLOAD_ID
             WHERE P.ENABLED = 'Y')
  BEGIN
    ;WITH all_hashes (key_hash, data_hash) AS (

				
			 
				-- /[dbo].[ICS_GNRL_PRMT] 
				
				SELECT KEY_HASH, ICS_GNRL_PRMT.DATA_HASH 
				 from [dbo].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
				
			 
				-- /[dbo].[ICS_GNRL_PRMT]/[dbo].[ICS_NAICS_CODE] 
				 UNION ALL 
				SELECT KEY_HASH, I1.DATA_HASH 
				 from [dbo].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [dbo].[ICS_NAICS_CODE] [I1]
 ON [I1].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
				
			 
				-- /[dbo].[ICS_GNRL_PRMT]/[dbo].[ICS_CONTACT] 
				 UNION ALL 
				SELECT KEY_HASH, I2.DATA_HASH 
				 from [dbo].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [dbo].[ICS_CONTACT] [I2]
 ON [I2].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
				
			 
				-- /[dbo].[ICS_GNRL_PRMT]/[dbo].[ICS_CONTACT]/[dbo].[ICS_TELEPH] 
				 UNION ALL 
				SELECT KEY_HASH, I3.DATA_HASH 
				 from [dbo].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [dbo].[ICS_CONTACT] [I2]
 ON [I2].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 JOIN [dbo].[ICS_TELEPH] [I3]
 ON [I3].[ICS_CONTACT_ID] = [I2].[ICS_CONTACT_ID] 
				
			 
				-- /[dbo].[ICS_GNRL_PRMT]/[dbo].[ICS_NPDES_DAT_GRP_NUM] 
				 UNION ALL 
				SELECT KEY_HASH, I4.DATA_HASH 
				 from [dbo].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [dbo].[ICS_NPDES_DAT_GRP_NUM] [I4]
 ON [I4].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
				
			 
				-- /[dbo].[ICS_GNRL_PRMT]/[dbo].[ICS_OTHR_PRMTS] 
				 UNION ALL 
				SELECT KEY_HASH, I5.DATA_HASH 
				 from [dbo].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [dbo].[ICS_OTHR_PRMTS] [I5]
 ON [I5].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
				
			 
				-- /[dbo].[ICS_GNRL_PRMT]/[dbo].[ICS_EFFLU_GUIDE] 
				 UNION ALL 
				SELECT KEY_HASH, I6.DATA_HASH 
				 from [dbo].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [dbo].[ICS_EFFLU_GUIDE] [I6]
 ON [I6].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
				
			 
				-- /[dbo].[ICS_GNRL_PRMT]/[dbo].[ICS_FAC] 
				 UNION ALL 
				SELECT KEY_HASH, I7.DATA_HASH 
				 from [dbo].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [dbo].[ICS_FAC] [I7]
 ON [I7].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
				
			 
				-- /[dbo].[ICS_GNRL_PRMT]/[dbo].[ICS_FAC]/[dbo].[ICS_CONTACT] 
				 UNION ALL 
				SELECT KEY_HASH, I8.DATA_HASH 
				 from [dbo].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [dbo].[ICS_FAC] [I7]
 ON [I7].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 JOIN [dbo].[ICS_CONTACT] [I8]
 ON [I8].[ICS_FAC_ID] = [I7].[ICS_FAC_ID] 
				
			 
				-- /[dbo].[ICS_GNRL_PRMT]/[dbo].[ICS_FAC]/[dbo].[ICS_CONTACT]/[dbo].[ICS_TELEPH] 
				 UNION ALL 
				SELECT KEY_HASH, I9.DATA_HASH 
				 from [dbo].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [dbo].[ICS_FAC] [I7]
 ON [I7].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 JOIN [dbo].[ICS_CONTACT] [I8]
 ON [I8].[ICS_FAC_ID] = [I7].[ICS_FAC_ID] 
 JOIN [dbo].[ICS_TELEPH] [I9]
 ON [I9].[ICS_CONTACT_ID] = [I8].[ICS_CONTACT_ID] 
				
			 
				-- /[dbo].[ICS_GNRL_PRMT]/[dbo].[ICS_FAC]/[dbo].[ICS_ORIG_PROGS] 
				 UNION ALL 
				SELECT KEY_HASH, I10.DATA_HASH 
				 from [dbo].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [dbo].[ICS_FAC] [I7]
 ON [I7].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 JOIN [dbo].[ICS_ORIG_PROGS] [I10]
 ON [I10].[ICS_FAC_ID] = [I7].[ICS_FAC_ID] 
				
			 
				-- /[dbo].[ICS_GNRL_PRMT]/[dbo].[ICS_FAC]/[dbo].[ICS_PLCY] 
				 UNION ALL 
				SELECT KEY_HASH, I11.DATA_HASH 
				 from [dbo].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [dbo].[ICS_FAC] [I7]
 ON [I7].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 JOIN [dbo].[ICS_PLCY] [I11]
 ON [I11].[ICS_FAC_ID] = [I7].[ICS_FAC_ID] 
				
			 
				-- /[dbo].[ICS_GNRL_PRMT]/[dbo].[ICS_FAC]/[dbo].[ICS_FAC_CLASS] 
				 UNION ALL 
				SELECT KEY_HASH, I12.DATA_HASH 
				 from [dbo].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [dbo].[ICS_FAC] [I7]
 ON [I7].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 JOIN [dbo].[ICS_FAC_CLASS] [I12]
 ON [I12].[ICS_FAC_ID] = [I7].[ICS_FAC_ID] 
				
			 
				-- /[dbo].[ICS_GNRL_PRMT]/[dbo].[ICS_FAC]/[dbo].[ICS_GEO_COORD] 
				 UNION ALL 
				SELECT KEY_HASH, I13.DATA_HASH 
				 from [dbo].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [dbo].[ICS_FAC] [I7]
 ON [I7].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 JOIN [dbo].[ICS_GEO_COORD] [I13]
 ON [I13].[ICS_FAC_ID] = [I7].[ICS_FAC_ID] 
				
			 
				-- /[dbo].[ICS_GNRL_PRMT]/[dbo].[ICS_FAC]/[dbo].[ICS_SIC_CODE] 
				 UNION ALL 
				SELECT KEY_HASH, I14.DATA_HASH 
				 from [dbo].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [dbo].[ICS_FAC] [I7]
 ON [I7].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 JOIN [dbo].[ICS_SIC_CODE] [I14]
 ON [I14].[ICS_FAC_ID] = [I7].[ICS_FAC_ID] 
				
			 
				-- /[dbo].[ICS_GNRL_PRMT]/[dbo].[ICS_FAC]/[dbo].[ICS_ADDR] 
				 UNION ALL 
				SELECT KEY_HASH, I15.DATA_HASH 
				 from [dbo].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [dbo].[ICS_FAC] [I7]
 ON [I7].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 JOIN [dbo].[ICS_ADDR] [I15]
 ON [I15].[ICS_FAC_ID] = [I7].[ICS_FAC_ID] 
				
			 
				-- /[dbo].[ICS_GNRL_PRMT]/[dbo].[ICS_FAC]/[dbo].[ICS_ADDR]/[dbo].[ICS_TELEPH] 
				 UNION ALL 
				SELECT KEY_HASH, I16.DATA_HASH 
				 from [dbo].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [dbo].[ICS_FAC] [I7]
 ON [I7].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 JOIN [dbo].[ICS_ADDR] [I15]
 ON [I15].[ICS_FAC_ID] = [I7].[ICS_FAC_ID] 
 JOIN [dbo].[ICS_TELEPH] [I16]
 ON [I16].[ICS_ADDR_ID] = [I15].[ICS_ADDR_ID] 
				
			 
				-- /[dbo].[ICS_GNRL_PRMT]/[dbo].[ICS_FAC]/[dbo].[ICS_NAICS_CODE] 
				 UNION ALL 
				SELECT KEY_HASH, I17.DATA_HASH 
				 from [dbo].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [dbo].[ICS_FAC] [I7]
 ON [I7].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 JOIN [dbo].[ICS_NAICS_CODE] [I17]
 ON [I17].[ICS_FAC_ID] = [I7].[ICS_FAC_ID] 
				
			 
				-- /[dbo].[ICS_GNRL_PRMT]/[dbo].[ICS_REP_NON_CMPL_STAT] 
				 UNION ALL 
				SELECT KEY_HASH, I18.DATA_HASH 
				 from [dbo].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [dbo].[ICS_REP_NON_CMPL_STAT] [I18]
 ON [I18].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
				
			 
				-- /[dbo].[ICS_GNRL_PRMT]/[dbo].[ICS_RESIDUAL_DESGN_DTRMN] 
				 UNION ALL 
				SELECT KEY_HASH, I19.DATA_HASH 
				 from [dbo].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [dbo].[ICS_RESIDUAL_DESGN_DTRMN] [I19]
 ON [I19].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
				
			 
				-- /[dbo].[ICS_GNRL_PRMT]/[dbo].[ICS_SIC_CODE] 
				 UNION ALL 
				SELECT KEY_HASH, I20.DATA_HASH 
				 from [dbo].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [dbo].[ICS_SIC_CODE] [I20]
 ON [I20].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
				
			 
				-- /[dbo].[ICS_GNRL_PRMT]/[dbo].[ICS_ADDR] 
				 UNION ALL 
				SELECT KEY_HASH, I21.DATA_HASH 
				 from [dbo].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [dbo].[ICS_ADDR] [I21]
 ON [I21].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
				
			 
				-- /[dbo].[ICS_GNRL_PRMT]/[dbo].[ICS_ADDR]/[dbo].[ICS_TELEPH] 
				 UNION ALL 
				SELECT KEY_HASH, I22.DATA_HASH 
				 from [dbo].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [dbo].[ICS_ADDR] [I21]
 ON [I21].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
 JOIN [dbo].[ICS_TELEPH] [I22]
 ON [I22].[ICS_ADDR_ID] = [I21].[ICS_ADDR_ID] 
				
			 
				-- /[dbo].[ICS_GNRL_PRMT]/[dbo].[ICS_ASSC_PRMT] 
				 UNION ALL 
				SELECT KEY_HASH, I23.DATA_HASH 
				 from [dbo].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [dbo].[ICS_ASSC_PRMT] [I23]
 ON [I23].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
				
			 
				-- /[dbo].[ICS_GNRL_PRMT]/[dbo].[ICS_CMPL_TRACK_STAT] 
				 UNION ALL 
				SELECT KEY_HASH, I24.DATA_HASH 
				 from [dbo].[ICS_GNRL_PRMT] [ICS_GNRL_PRMT] 
 JOIN [dbo].[ICS_CMPL_TRACK_STAT] [I24]
 ON [I24].[ICS_GNRL_PRMT_ID] = [ICS_GNRL_PRMT].[ICS_GNRL_PRMT_ID] 
							  
    ),
    rolled (key_hash, rolled_hash) AS (
      SELECT
        key_hash,
        dbo.HASHBYTES_VARCHAR('SHA1',
          STRING_AGG(cast(data_hash as varchar(max)), '') WITHIN GROUP (ORDER BY data_hash)
        ) AS rolled_hash
      FROM all_hashes
      GROUP BY key_hash
    )
    UPDATE p
       SET p.data_hash = r.rolled_hash
      FROM dbo.ICS_GNRL_PRMT p
      JOIN rolled r ON r.key_hash = p.key_hash;
  END;

  -- [23] ICS_HIST_PRMT_SCHD_EVTS
  IF EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P
             JOIN dbo.ICS_HIST_PRMT_SCHD_EVTS C ON P.ICS_PAYLOAD_ID = C.ICS_PAYLOAD_ID
             WHERE P.ENABLED = 'Y')
  BEGIN
    ;WITH all_hashes (key_hash, data_hash) AS (

				
			 
				-- /[dbo].[ICS_HIST_PRMT_SCHD_EVTS] 
				
				SELECT KEY_HASH, ICS_HIST_PRMT_SCHD_EVTS.DATA_HASH 
				 from [dbo].[ICS_HIST_PRMT_SCHD_EVTS] [ICS_HIST_PRMT_SCHD_EVTS] 
							  
    ),
    rolled (key_hash, rolled_hash) AS (
      SELECT
        key_hash,
        dbo.HASHBYTES_VARCHAR('SHA1',
          STRING_AGG(cast(data_hash as varchar(max)), '') WITHIN GROUP (ORDER BY data_hash)
        ) AS rolled_hash
      FROM all_hashes
      GROUP BY key_hash
    )
    UPDATE p
       SET p.data_hash = r.rolled_hash
      FROM dbo.ICS_HIST_PRMT_SCHD_EVTS p
      JOIN rolled r ON r.key_hash = p.key_hash;
  END;

  -- [24] ICS_INFRML_ENFRC_ACTN
  IF EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P
             JOIN dbo.ICS_INFRML_ENFRC_ACTN C ON P.ICS_PAYLOAD_ID = C.ICS_PAYLOAD_ID
             WHERE P.ENABLED = 'Y')
  BEGIN
    ;WITH all_hashes (key_hash, data_hash) AS (

				
			 
				-- /[dbo].[ICS_INFRML_ENFRC_ACTN] 
				
				SELECT KEY_HASH, ICS_INFRML_ENFRC_ACTN.DATA_HASH 
				 from [dbo].[ICS_INFRML_ENFRC_ACTN] [ICS_INFRML_ENFRC_ACTN] 
				
			 
				-- /[dbo].[ICS_INFRML_ENFRC_ACTN]/[dbo].[ICS_PRMT_IDENT] 
				 UNION ALL 
				SELECT KEY_HASH, I1.DATA_HASH 
				 from [dbo].[ICS_INFRML_ENFRC_ACTN] [ICS_INFRML_ENFRC_ACTN] 
 JOIN [dbo].[ICS_PRMT_IDENT] [I1]
 ON [I1].[ICS_INFRML_ENFRC_ACTN_ID] = [ICS_INFRML_ENFRC_ACTN].[ICS_INFRML_ENFRC_ACTN_ID] 
				
			 
				-- /[dbo].[ICS_INFRML_ENFRC_ACTN]/[dbo].[ICS_ENFRC_ACTN_GOV_CONTACT] 
				 UNION ALL 
				SELECT KEY_HASH, I2.DATA_HASH 
				 from [dbo].[ICS_INFRML_ENFRC_ACTN] [ICS_INFRML_ENFRC_ACTN] 
 JOIN [dbo].[ICS_ENFRC_ACTN_GOV_CONTACT] [I2]
 ON [I2].[ICS_INFRML_ENFRC_ACTN_ID] = [ICS_INFRML_ENFRC_ACTN].[ICS_INFRML_ENFRC_ACTN_ID] 
				
			 
				-- /[dbo].[ICS_INFRML_ENFRC_ACTN]/[dbo].[ICS_ENFRC_AGNCY] 
				 UNION ALL 
				SELECT KEY_HASH, I3.DATA_HASH 
				 from [dbo].[ICS_INFRML_ENFRC_ACTN] [ICS_INFRML_ENFRC_ACTN] 
 JOIN [dbo].[ICS_ENFRC_AGNCY] [I3]
 ON [I3].[ICS_INFRML_ENFRC_ACTN_ID] = [ICS_INFRML_ENFRC_ACTN].[ICS_INFRML_ENFRC_ACTN_ID] 
				
			 
				-- /[dbo].[ICS_INFRML_ENFRC_ACTN]/[dbo].[ICS_PROGS_VIOL] 
				 UNION ALL 
				SELECT KEY_HASH, I4.DATA_HASH 
				 from [dbo].[ICS_INFRML_ENFRC_ACTN] [ICS_INFRML_ENFRC_ACTN] 
 JOIN [dbo].[ICS_PROGS_VIOL] [I4]
 ON [I4].[ICS_INFRML_ENFRC_ACTN_ID] = [ICS_INFRML_ENFRC_ACTN].[ICS_INFRML_ENFRC_ACTN_ID] 
							  
    ),
    rolled (key_hash, rolled_hash) AS (
      SELECT
        key_hash,
        dbo.HASHBYTES_VARCHAR('SHA1',
          STRING_AGG(cast(data_hash as varchar(max)), '') WITHIN GROUP (ORDER BY data_hash)
        ) AS rolled_hash
      FROM all_hashes
      GROUP BY key_hash
    )
    UPDATE p
       SET p.data_hash = r.rolled_hash
      FROM dbo.ICS_INFRML_ENFRC_ACTN p
      JOIN rolled r ON r.key_hash = p.key_hash;
  END;

  -- [25] ICS_LMTS
  IF EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P
             JOIN dbo.ICS_LMTS C ON P.ICS_PAYLOAD_ID = C.ICS_PAYLOAD_ID
             WHERE P.ENABLED = 'Y')
  BEGIN
    ;WITH all_hashes (key_hash, data_hash) AS (

				
			 
				-- /[dbo].[ICS_LMTS] 
				
				SELECT KEY_HASH, ICS_LMTS.DATA_HASH 
				 from [dbo].[ICS_LMTS] [ICS_LMTS] 
				
			 
				-- /[dbo].[ICS_LMTS]/[dbo].[ICS_NUM_COND] 
				 UNION ALL 
				SELECT KEY_HASH, I1.DATA_HASH 
				 from [dbo].[ICS_LMTS] [ICS_LMTS] 
 JOIN [dbo].[ICS_NUM_COND] [I1]
 ON [I1].[ICS_LMTS_ID] = [ICS_LMTS].[ICS_LMTS_ID] 
				
			 
				-- /[dbo].[ICS_LMTS]/[dbo].[ICS_MN_LMT_APPLIES] 
				 UNION ALL 
				SELECT KEY_HASH, I2.DATA_HASH 
				 from [dbo].[ICS_LMTS] [ICS_LMTS] 
 JOIN [dbo].[ICS_MN_LMT_APPLIES] [I2]
 ON [I2].[ICS_LMTS_ID] = [ICS_LMTS].[ICS_LMTS_ID] 
							  
    ),
    rolled (key_hash, rolled_hash) AS (
      SELECT
        key_hash,
        dbo.HASHBYTES_VARCHAR('SHA1',
          STRING_AGG(cast(data_hash as varchar(max)), '') WITHIN GROUP (ORDER BY data_hash)
        ) AS rolled_hash
      FROM all_hashes
      GROUP BY key_hash
    )
    UPDATE p
       SET p.data_hash = r.rolled_hash
      FROM dbo.ICS_LMTS p
      JOIN rolled r ON r.key_hash = p.key_hash;
  END;

  -- [26] ICS_LMT_SET
  IF EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P
             JOIN dbo.ICS_LMT_SET C ON P.ICS_PAYLOAD_ID = C.ICS_PAYLOAD_ID
             WHERE P.ENABLED = 'Y')
  BEGIN
    ;WITH all_hashes (key_hash, data_hash) AS (

				
			 
				-- /[dbo].[ICS_LMT_SET] 
				
				SELECT KEY_HASH, ICS_LMT_SET.DATA_HASH 
				 from [dbo].[ICS_LMT_SET] [ICS_LMT_SET] 
				
			 
				-- /[dbo].[ICS_LMT_SET]/[dbo].[ICS_LMT_SET_MONTHS_APPL] 
				 UNION ALL 
				SELECT KEY_HASH, I1.DATA_HASH 
				 from [dbo].[ICS_LMT_SET] [ICS_LMT_SET] 
 JOIN [dbo].[ICS_LMT_SET_MONTHS_APPL] [I1]
 ON [I1].[ICS_LMT_SET_ID] = [ICS_LMT_SET].[ICS_LMT_SET_ID] 
				
			 
				-- /[dbo].[ICS_LMT_SET]/[dbo].[ICS_LMT_SET_SCHD] 
				 UNION ALL 
				SELECT KEY_HASH, I2.DATA_HASH 
				 from [dbo].[ICS_LMT_SET] [ICS_LMT_SET] 
 JOIN [dbo].[ICS_LMT_SET_SCHD] [I2]
 ON [I2].[ICS_LMT_SET_ID] = [ICS_LMT_SET].[ICS_LMT_SET_ID] 
				
			 
				-- /[dbo].[ICS_LMT_SET]/[dbo].[ICS_LMT_SET_STAT] 
				 UNION ALL 
				SELECT KEY_HASH, I3.DATA_HASH 
				 from [dbo].[ICS_LMT_SET] [ICS_LMT_SET] 
 JOIN [dbo].[ICS_LMT_SET_STAT] [I3]
 ON [I3].[ICS_LMT_SET_ID] = [ICS_LMT_SET].[ICS_LMT_SET_ID] 
							  
    ),
    rolled (key_hash, rolled_hash) AS (
      SELECT
        key_hash,
        dbo.HASHBYTES_VARCHAR('SHA1',
          STRING_AGG(cast(data_hash as varchar(max)), '') WITHIN GROUP (ORDER BY data_hash)
        ) AS rolled_hash
      FROM all_hashes
      GROUP BY key_hash
    )
    UPDATE p
       SET p.data_hash = r.rolled_hash
      FROM dbo.ICS_LMT_SET p
      JOIN rolled r ON r.key_hash = p.key_hash;
  END;

  -- [27] ICS_MASTER_GNRL_PRMT
  IF EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P
             JOIN dbo.ICS_MASTER_GNRL_PRMT C ON P.ICS_PAYLOAD_ID = C.ICS_PAYLOAD_ID
             WHERE P.ENABLED = 'Y')
  BEGIN
    ;WITH all_hashes (key_hash, data_hash) AS (
                     -- /ICS_MASTER_GNRL_PRMT
                      SELECT key_hash
                           , child.data_hash
                        FROM dbo.ics_master_gnrl_prmt child
                      UNION ALL
                      -- /ICS_MASTER_GNRL_PRMT/ICS_ASSC_PRMT
                      SELECT key_hash
                           , child.data_hash
                        FROM dbo.ics_master_gnrl_prmt
                        JOIN dbo.ics_assc_prmt child
                          ON child.ics_master_gnrl_prmt_id = ics_master_gnrl_prmt.ics_master_gnrl_prmt_id
                      UNION ALL
                      -- /ICS_MASTER_GNRL_PRMT/ICS_CONTACT
                      SELECT key_hash
                           , child.data_hash
                        FROM dbo.ics_master_gnrl_prmt
                        JOIN dbo.ics_contact child
                          ON child.ics_master_gnrl_prmt_id = ics_master_gnrl_prmt.ics_master_gnrl_prmt_id
                      UNION ALL
                      -- /ICS_MASTER_GNRL_PRMT/ICS_CONTACT/ICS_TELEPH
                      SELECT key_hash
                           , child.data_hash
                        FROM dbo.ics_master_gnrl_prmt
                        JOIN dbo.ics_contact
                          ON ics_contact.ics_master_gnrl_prmt_id = ics_master_gnrl_prmt.ics_master_gnrl_prmt_id
                        JOIN dbo.ics_teleph child
                          ON child.ics_contact_id = ics_contact.ics_contact_id
                      UNION ALL
                      -- /ICS_MASTER_GNRL_PRMT/ICS_NAICS_CODE
                      SELECT key_hash
                           , child.data_hash
                        FROM dbo.ics_master_gnrl_prmt
                        JOIN dbo.ics_naics_code child
                          ON child.ics_master_gnrl_prmt_id = ics_master_gnrl_prmt.ics_master_gnrl_prmt_id
                      UNION ALL
                      -- /ICS_MASTER_GNRL_PRMT/ICS_OTHR_PRMTS
                      SELECT key_hash
                           , child.data_hash
                        FROM dbo.ics_master_gnrl_prmt
                        JOIN dbo.ics_othr_prmts child
                          ON child.ics_master_gnrl_prmt_id = ics_master_gnrl_prmt.ics_master_gnrl_prmt_id
                      UNION ALL
                      -- /ICS_MASTER_GNRL_PRMT/ICS_PRMT_COMP_TYPE
                      SELECT key_hash
                           , child.data_hash
                        FROM dbo.ics_master_gnrl_prmt
                        JOIN dbo.ics_prmt_comp_type child
                          ON child.ics_master_gnrl_prmt_id = ics_master_gnrl_prmt.ics_master_gnrl_prmt_id
                      UNION ALL
                      -- /ICS_MASTER_GNRL_PRMT/ICS_SIC_CODE
                      SELECT key_hash
                           , child.data_hash
                        FROM dbo.ics_master_gnrl_prmt
                        JOIN dbo.ics_sic_code child
                          ON child.ics_master_gnrl_prmt_id = ics_master_gnrl_prmt.ics_master_gnrl_prmt_id
							  
    ),
    rolled (key_hash, rolled_hash) AS (
      SELECT
        key_hash,
        dbo.HASHBYTES_VARCHAR('SHA1',
          STRING_AGG(cast(data_hash as varchar(max)), '') WITHIN GROUP (ORDER BY data_hash)
        ) AS rolled_hash
      FROM all_hashes
      GROUP BY key_hash
    )
    UPDATE p
       SET p.data_hash = r.rolled_hash
      FROM dbo.ICS_MASTER_GNRL_PRMT p
      JOIN rolled r ON r.key_hash = p.key_hash;
  END;

  -- [28] ICS_NARR_COND_SCHD
  IF EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P
             JOIN dbo.ICS_NARR_COND_SCHD C ON P.ICS_PAYLOAD_ID = C.ICS_PAYLOAD_ID
             WHERE P.ENABLED = 'Y')
  BEGIN
    ;WITH all_hashes (key_hash, data_hash) AS (

				
			 
				-- /[dbo].[ICS_NARR_COND_SCHD] 
				
				SELECT KEY_HASH, ICS_NARR_COND_SCHD.DATA_HASH 
				 from [dbo].[ICS_NARR_COND_SCHD] [ICS_NARR_COND_SCHD] 
				
			 
				-- /[dbo].[ICS_NARR_COND_SCHD]/[dbo].[ICS_PRMT_SCHD_EVT] 
				 UNION ALL 
				SELECT KEY_HASH, I1.DATA_HASH 
				 from [dbo].[ICS_NARR_COND_SCHD] [ICS_NARR_COND_SCHD] 
 JOIN [dbo].[ICS_PRMT_SCHD_EVT] [I1]
 ON [I1].[ICS_NARR_COND_SCHD_ID] = [ICS_NARR_COND_SCHD].[ICS_NARR_COND_SCHD_ID] 
							  
    ),
    rolled (key_hash, rolled_hash) AS (
      SELECT
        key_hash,
        dbo.HASHBYTES_VARCHAR('SHA1',
          STRING_AGG(cast(data_hash as varchar(max)), '') WITHIN GROUP (ORDER BY data_hash)
        ) AS rolled_hash
      FROM all_hashes
      GROUP BY key_hash
    )
    UPDATE p
       SET p.data_hash = r.rolled_hash
      FROM dbo.ICS_NARR_COND_SCHD p
      JOIN rolled r ON r.key_hash = p.key_hash;
  END;

  -- [29] ICS_NPDES_VARIANCE_PRMT
  IF EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P
             JOIN dbo.ICS_NPDES_VARIANCE_PRMT C ON P.ICS_PAYLOAD_ID = C.ICS_PAYLOAD_ID
             WHERE P.ENABLED = 'Y')
  BEGIN
    ;WITH all_hashes (key_hash, data_hash) AS (

				
			 
				-- /[dbo].[ICS_NPDES_VARIANCE_PRMT] 
				
				SELECT KEY_HASH, ICS_NPDES_VARIANCE_PRMT.DATA_HASH 
				 from [dbo].[ICS_NPDES_VARIANCE_PRMT] [ICS_NPDES_VARIANCE_PRMT] 
							  
    ),
    rolled (key_hash, rolled_hash) AS (
      SELECT
        key_hash,
        dbo.HASHBYTES_VARCHAR('SHA1',
          STRING_AGG(cast(data_hash as varchar(max)), '') WITHIN GROUP (ORDER BY data_hash)
        ) AS rolled_hash
      FROM all_hashes
      GROUP BY key_hash
    )
    UPDATE p
       SET p.data_hash = r.rolled_hash
      FROM dbo.ICS_NPDES_VARIANCE_PRMT p
      JOIN rolled r ON r.key_hash = p.key_hash;
  END;

  -- [30] ICS_PARAM_LMTS
  IF EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P
             JOIN dbo.ICS_PARAM_LMTS C ON P.ICS_PAYLOAD_ID = C.ICS_PAYLOAD_ID
             WHERE P.ENABLED = 'Y')
  BEGIN
    ;WITH all_hashes (key_hash, data_hash) AS (

				
			 
				-- /[dbo].[ICS_PARAM_LMTS] 
				
				SELECT KEY_HASH, ICS_PARAM_LMTS.DATA_HASH 
				 from [dbo].[ICS_PARAM_LMTS] [ICS_PARAM_LMTS] 
				
			 
				-- /[dbo].[ICS_PARAM_LMTS]/[dbo].[ICS_LMT] 
				 UNION ALL 
				SELECT KEY_HASH, I1.DATA_HASH 
				 from [dbo].[ICS_PARAM_LMTS] [ICS_PARAM_LMTS] 
 JOIN [dbo].[ICS_LMT] [I1]
 ON [I1].[ICS_PARAM_LMTS_ID] = [ICS_PARAM_LMTS].[ICS_PARAM_LMTS_ID] 
				
			 
				-- /[dbo].[ICS_PARAM_LMTS]/[dbo].[ICS_LMT]/[dbo].[ICS_NUM_COND] 
				 UNION ALL 
				SELECT KEY_HASH, I2.DATA_HASH 
				 from [dbo].[ICS_PARAM_LMTS] [ICS_PARAM_LMTS] 
 JOIN [dbo].[ICS_LMT] [I1]
 ON [I1].[ICS_PARAM_LMTS_ID] = [ICS_PARAM_LMTS].[ICS_PARAM_LMTS_ID] 
 JOIN [dbo].[ICS_NUM_COND] [I2]
 ON [I2].[ICS_LMT_ID] = [I1].[ICS_LMT_ID] 
				
			 
				-- /[dbo].[ICS_PARAM_LMTS]/[dbo].[ICS_LMT]/[dbo].[ICS_MN_LMT_APPLIES] 
				 UNION ALL 
				SELECT KEY_HASH, I3.DATA_HASH 
				 from [dbo].[ICS_PARAM_LMTS] [ICS_PARAM_LMTS] 
 JOIN [dbo].[ICS_LMT] [I1]
 ON [I1].[ICS_PARAM_LMTS_ID] = [ICS_PARAM_LMTS].[ICS_PARAM_LMTS_ID] 
 JOIN [dbo].[ICS_MN_LMT_APPLIES] [I3]
 ON [I3].[ICS_LMT_ID] = [I1].[ICS_LMT_ID] 
							  
    ),
    rolled (key_hash, rolled_hash) AS (
      SELECT
        key_hash,
        dbo.HASHBYTES_VARCHAR('SHA1',
          STRING_AGG(cast(data_hash as varchar(max)), '') WITHIN GROUP (ORDER BY data_hash)
        ) AS rolled_hash
      FROM all_hashes
      GROUP BY key_hash
    )
    UPDATE p
       SET p.data_hash = r.rolled_hash
      FROM dbo.ICS_PARAM_LMTS p
      JOIN rolled r ON r.key_hash = p.key_hash;
  END;

  -- [31] ICS_PRMT_REISSU
  IF EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P
             JOIN dbo.ICS_PRMT_REISSU C ON P.ICS_PAYLOAD_ID = C.ICS_PAYLOAD_ID
             WHERE P.ENABLED = 'Y')
  BEGIN
    ;WITH all_hashes (key_hash, data_hash) AS (

				
			 
				-- /[dbo].[ICS_PRMT_REISSU] 
				
				SELECT KEY_HASH, ICS_PRMT_REISSU.DATA_HASH 
				 from [dbo].[ICS_PRMT_REISSU] [ICS_PRMT_REISSU] 
							  
    ),
    rolled (key_hash, rolled_hash) AS (
      SELECT
        key_hash,
        dbo.HASHBYTES_VARCHAR('SHA1',
          STRING_AGG(cast(data_hash as varchar(max)), '') WITHIN GROUP (ORDER BY data_hash)
        ) AS rolled_hash
      FROM all_hashes
      GROUP BY key_hash
    )
    UPDATE p
       SET p.data_hash = r.rolled_hash
      FROM dbo.ICS_PRMT_REISSU p
      JOIN rolled r ON r.key_hash = p.key_hash;
  END;

  -- [32] ICS_PRMT_FEATR
  IF EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P
             JOIN dbo.ICS_PRMT_FEATR C ON P.ICS_PAYLOAD_ID = C.ICS_PAYLOAD_ID
             WHERE P.ENABLED = 'Y')
  BEGIN
    ;WITH all_hashes (key_hash, data_hash) AS (

				
			 
				-- /[dbo].[ICS_PRMT_FEATR] 
				
				SELECT KEY_HASH, ICS_PRMT_FEATR.DATA_HASH 
				 from [dbo].[ICS_PRMT_FEATR] [ICS_PRMT_FEATR] 
				
			 
				-- /[dbo].[ICS_PRMT_FEATR]/[dbo].[ICS_CONTACT] 
				 UNION ALL 
				SELECT KEY_HASH, I1.DATA_HASH 
				 from [dbo].[ICS_PRMT_FEATR] [ICS_PRMT_FEATR] 
 JOIN [dbo].[ICS_CONTACT] [I1]
 ON [I1].[ICS_PRMT_FEATR_ID] = [ICS_PRMT_FEATR].[ICS_PRMT_FEATR_ID] 
				
			 
				-- /[dbo].[ICS_PRMT_FEATR]/[dbo].[ICS_CONTACT]/[dbo].[ICS_TELEPH] 
				 UNION ALL 
				SELECT KEY_HASH, I2.DATA_HASH 
				 from [dbo].[ICS_PRMT_FEATR] [ICS_PRMT_FEATR] 
 JOIN [dbo].[ICS_CONTACT] [I1]
 ON [I1].[ICS_PRMT_FEATR_ID] = [ICS_PRMT_FEATR].[ICS_PRMT_FEATR_ID] 
 JOIN [dbo].[ICS_TELEPH] [I2]
 ON [I2].[ICS_CONTACT_ID] = [I1].[ICS_CONTACT_ID] 
				
			 
				-- /[dbo].[ICS_PRMT_FEATR]/[dbo].[ICS_COOLING_WTR_INTAKE_STRCT_INFO] 
				 UNION ALL 
				SELECT KEY_HASH, I3.DATA_HASH 
				 from [dbo].[ICS_PRMT_FEATR] [ICS_PRMT_FEATR] 
 JOIN [dbo].[ICS_COOLING_WTR_INTAKE_STRCT_INFO] [I3]
 ON [I3].[ICS_PRMT_FEATR_ID] = [ICS_PRMT_FEATR].[ICS_PRMT_FEATR_ID] 
				
			 
				-- /[dbo].[ICS_PRMT_FEATR]/[dbo].[ICS_COOLING_WTR_INTAKE_STRCT_INFO]/[dbo].[ICS_COOLING_WTR_INTAKE_STRCT_CMPL_METHOD] 
				 UNION ALL 
				SELECT KEY_HASH, I4.DATA_HASH 
				 from [dbo].[ICS_PRMT_FEATR] [ICS_PRMT_FEATR] 
 JOIN [dbo].[ICS_COOLING_WTR_INTAKE_STRCT_INFO] [I3]
 ON [I3].[ICS_PRMT_FEATR_ID] = [ICS_PRMT_FEATR].[ICS_PRMT_FEATR_ID] 
 JOIN [dbo].[ICS_COOLING_WTR_INTAKE_STRCT_CMPL_METHOD] [I4]
 ON [I4].[ICS_COOLING_WTR_INTAKE_STRCT_INFO_ID] = [I3].[ICS_COOLING_WTR_INTAKE_STRCT_INFO_ID] 
				
			 
				-- /[dbo].[ICS_PRMT_FEATR]/[dbo].[ICS_POLUT_LIST] 
				 UNION ALL 
				SELECT KEY_HASH, I5.DATA_HASH 
				 from [dbo].[ICS_PRMT_FEATR] [ICS_PRMT_FEATR] 
 JOIN [dbo].[ICS_POLUT_LIST] [I5]
 ON [I5].[ICS_PRMT_FEATR_ID] = [ICS_PRMT_FEATR].[ICS_PRMT_FEATR_ID] 
				
			 
				-- /[dbo].[ICS_PRMT_FEATR]/[dbo].[ICS_POLUT_LIST]/[dbo].[ICS_IMPAIRED_WTR_POLLUTANTS] 
				 UNION ALL 
				SELECT KEY_HASH, I6.DATA_HASH 
				 from [dbo].[ICS_PRMT_FEATR] [ICS_PRMT_FEATR] 
 JOIN [dbo].[ICS_POLUT_LIST] [I5]
 ON [I5].[ICS_PRMT_FEATR_ID] = [ICS_PRMT_FEATR].[ICS_PRMT_FEATR_ID] 
 JOIN [dbo].[ICS_IMPAIRED_WTR_POLLUTANTS] [I6]
 ON [I6].[ICS_POLUT_LIST_ID] = [I5].[ICS_POLUT_LIST_ID] 
				
			 
				-- /[dbo].[ICS_PRMT_FEATR]/[dbo].[ICS_POLUT_LIST]/[dbo].[ICS_TMDL_POLLUTANTS] 
				 UNION ALL 
				SELECT KEY_HASH, I7.DATA_HASH 
				 from [dbo].[ICS_PRMT_FEATR] [ICS_PRMT_FEATR] 
 JOIN [dbo].[ICS_POLUT_LIST] [I5]
 ON [I5].[ICS_PRMT_FEATR_ID] = [ICS_PRMT_FEATR].[ICS_PRMT_FEATR_ID] 
 JOIN [dbo].[ICS_TMDL_POLLUTANTS] [I7]
 ON [I7].[ICS_POLUT_LIST_ID] = [I5].[ICS_POLUT_LIST_ID] 
				
			 
				-- /[dbo].[ICS_PRMT_FEATR]/[dbo].[ICS_POLUT_LIST]/[dbo].[ICS_TMDL_POLLUTANTS]/[dbo].[ICS_TMDL_POLUT] 
				 UNION ALL 
				SELECT KEY_HASH, I8.DATA_HASH 
				 from [dbo].[ICS_PRMT_FEATR] [ICS_PRMT_FEATR] 
 JOIN [dbo].[ICS_POLUT_LIST] [I5]
 ON [I5].[ICS_PRMT_FEATR_ID] = [ICS_PRMT_FEATR].[ICS_PRMT_FEATR_ID] 
 JOIN [dbo].[ICS_TMDL_POLLUTANTS] [I7]
 ON [I7].[ICS_POLUT_LIST_ID] = [I5].[ICS_POLUT_LIST_ID] 
 JOIN [dbo].[ICS_TMDL_POLUT] [I8]
 ON [I8].[ICS_TMDL_POLLUTANTS_ID] = [I7].[ICS_TMDL_POLLUTANTS_ID] 
				
			 
				-- /[dbo].[ICS_PRMT_FEATR]/[dbo].[ICS_PRMT_FEATR_CHAR] 
				 UNION ALL 
				SELECT KEY_HASH, I9.DATA_HASH 
				 from [dbo].[ICS_PRMT_FEATR] [ICS_PRMT_FEATR] 
 JOIN [dbo].[ICS_PRMT_FEATR_CHAR] [I9]
 ON [I9].[ICS_PRMT_FEATR_ID] = [ICS_PRMT_FEATR].[ICS_PRMT_FEATR_ID] 
				
			 
				-- /[dbo].[ICS_PRMT_FEATR]/[dbo].[ICS_PRMT_FEATR_TRTMNT_TYPE] 
				 UNION ALL 
				SELECT KEY_HASH, I10.DATA_HASH 
				 from [dbo].[ICS_PRMT_FEATR] [ICS_PRMT_FEATR] 
 JOIN [dbo].[ICS_PRMT_FEATR_TRTMNT_TYPE] [I10]
 ON [I10].[ICS_PRMT_FEATR_ID] = [ICS_PRMT_FEATR].[ICS_PRMT_FEATR_ID] 
				
			 
				-- /[dbo].[ICS_PRMT_FEATR]/[dbo].[ICS_GEO_COORD] 
				 UNION ALL 
				SELECT KEY_HASH, I11.DATA_HASH 
				 from [dbo].[ICS_PRMT_FEATR] [ICS_PRMT_FEATR] 
 JOIN [dbo].[ICS_GEO_COORD] [I11]
 ON [I11].[ICS_PRMT_FEATR_ID] = [ICS_PRMT_FEATR].[ICS_PRMT_FEATR_ID] 
				
			 
				-- /[dbo].[ICS_PRMT_FEATR]/[dbo].[ICS_ADDR] 
				 UNION ALL 
				SELECT KEY_HASH, I12.DATA_HASH 
				 from [dbo].[ICS_PRMT_FEATR] [ICS_PRMT_FEATR] 
 JOIN [dbo].[ICS_ADDR] [I12]
 ON [I12].[ICS_PRMT_FEATR_ID] = [ICS_PRMT_FEATR].[ICS_PRMT_FEATR_ID] 
				
			 
				-- /[dbo].[ICS_PRMT_FEATR]/[dbo].[ICS_ADDR]/[dbo].[ICS_TELEPH] 
				 UNION ALL 
				SELECT KEY_HASH, I13.DATA_HASH 
				 from [dbo].[ICS_PRMT_FEATR] [ICS_PRMT_FEATR] 
 JOIN [dbo].[ICS_ADDR] [I12]
 ON [I12].[ICS_PRMT_FEATR_ID] = [ICS_PRMT_FEATR].[ICS_PRMT_FEATR_ID] 
 JOIN [dbo].[ICS_TELEPH] [I13]
 ON [I13].[ICS_ADDR_ID] = [I12].[ICS_ADDR_ID] 
							  
    ),
    rolled (key_hash, rolled_hash) AS (
      SELECT
        key_hash,
        dbo.HASHBYTES_VARCHAR('SHA1',
          STRING_AGG(cast(data_hash as varchar(max)), '') WITHIN GROUP (ORDER BY data_hash)
        ) AS rolled_hash
      FROM all_hashes
      GROUP BY key_hash
    )
    UPDATE p
       SET p.data_hash = r.rolled_hash
      FROM dbo.ICS_PRMT_FEATR p
      JOIN rolled r ON r.key_hash = p.key_hash;
  END;

  -- [33] ICS_PRMT_TERM
  IF EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P
             JOIN dbo.ICS_PRMT_TERM C ON P.ICS_PAYLOAD_ID = C.ICS_PAYLOAD_ID
             WHERE P.ENABLED = 'Y')
  BEGIN
    ;WITH all_hashes (key_hash, data_hash) AS (

				
			 
				-- /[dbo].[ICS_PRMT_TERM] 
				
				SELECT KEY_HASH, ICS_PRMT_TERM.DATA_HASH 
				 from [dbo].[ICS_PRMT_TERM] [ICS_PRMT_TERM] 
							  
    ),
    rolled (key_hash, rolled_hash) AS (
      SELECT
        key_hash,
        dbo.HASHBYTES_VARCHAR('SHA1',
          STRING_AGG(cast(data_hash as varchar(max)), '') WITHIN GROUP (ORDER BY data_hash)
        ) AS rolled_hash
      FROM all_hashes
      GROUP BY key_hash
    )
    UPDATE p
       SET p.data_hash = r.rolled_hash
      FROM dbo.ICS_PRMT_TERM p
      JOIN rolled r ON r.key_hash = p.key_hash;
  END;

  -- [34] ICS_PRMT_TRACK_EVT
  IF EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P
             JOIN dbo.ICS_PRMT_TRACK_EVT C ON P.ICS_PAYLOAD_ID = C.ICS_PAYLOAD_ID
             WHERE P.ENABLED = 'Y')
  BEGIN
    ;WITH all_hashes (key_hash, data_hash) AS (

				
			 
				-- /[dbo].[ICS_PRMT_TRACK_EVT] 
				
				SELECT KEY_HASH, ICS_PRMT_TRACK_EVT.DATA_HASH 
				 from [dbo].[ICS_PRMT_TRACK_EVT] [ICS_PRMT_TRACK_EVT] 
							  
    ),
    rolled (key_hash, rolled_hash) AS (
      SELECT
        key_hash,
        dbo.HASHBYTES_VARCHAR('SHA1',
          STRING_AGG(cast(data_hash as varchar(max)), '') WITHIN GROUP (ORDER BY data_hash)
        ) AS rolled_hash
      FROM all_hashes
      GROUP BY key_hash
    )
    UPDATE p
       SET p.data_hash = r.rolled_hash
      FROM dbo.ICS_PRMT_TRACK_EVT p
      JOIN rolled r ON r.key_hash = p.key_hash;
  END;

  -- [35] ICS_POTW_PRMT
  IF EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P
             JOIN dbo.ICS_POTW_PRMT C ON P.ICS_PAYLOAD_ID = C.ICS_PAYLOAD_ID
             WHERE P.ENABLED = 'Y')
  BEGIN
    ;WITH all_hashes (key_hash, data_hash) AS (

				
			 
				-- /[dbo].[ICS_POTW_PRMT] 
				
				SELECT KEY_HASH, ICS_POTW_PRMT.DATA_HASH 
				 from [dbo].[ICS_POTW_PRMT] [ICS_POTW_PRMT] 
				
			 
				-- /[dbo].[ICS_POTW_PRMT]/[dbo].[ICS_SATL_COLL_SYSTM] 
				 UNION ALL 
				SELECT KEY_HASH, I1.DATA_HASH 
				 from [dbo].[ICS_POTW_PRMT] [ICS_POTW_PRMT] 
 JOIN [dbo].[ICS_SATL_COLL_SYSTM] [I1]
 ON [I1].[ICS_POTW_PRMT_ID] = [ICS_POTW_PRMT].[ICS_POTW_PRMT_ID] 
							  
    ),
    rolled (key_hash, rolled_hash) AS (
      SELECT
        key_hash,
        dbo.HASHBYTES_VARCHAR('SHA1',
          STRING_AGG(cast(data_hash as varchar(max)), '') WITHIN GROUP (ORDER BY data_hash)
        ) AS rolled_hash
      FROM all_hashes
      GROUP BY key_hash
    )
    UPDATE p
       SET p.data_hash = r.rolled_hash
      FROM dbo.ICS_POTW_PRMT p
      JOIN rolled r ON r.key_hash = p.key_hash;
  END;

  -- [36] ICS_POTW_TRTMNT_TECHNOLOGY_PRMT
  IF EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P
             JOIN dbo.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT C ON P.ICS_PAYLOAD_ID = C.ICS_PAYLOAD_ID
             WHERE P.ENABLED = 'Y')
  BEGIN
    ;WITH all_hashes (key_hash, data_hash) AS (

				
			 
				-- /[dbo].[ICS_POTW_TRTMNT_TECHNOLOGY_PRMT] 
				
				SELECT KEY_HASH, ICS_POTW_TRTMNT_TECHNOLOGY_PRMT.DATA_HASH 
				 from [dbo].[ICS_POTW_TRTMNT_TECHNOLOGY_PRMT] [ICS_POTW_TRTMNT_TECHNOLOGY_PRMT] 
							  
    ),
    rolled (key_hash, rolled_hash) AS (
      SELECT
        key_hash,
        dbo.HASHBYTES_VARCHAR('SHA1',
          STRING_AGG(cast(data_hash as varchar(max)), '') WITHIN GROUP (ORDER BY data_hash)
        ) AS rolled_hash
      FROM all_hashes
      GROUP BY key_hash
    )
    UPDATE p
       SET p.data_hash = r.rolled_hash
      FROM dbo.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT p
      JOIN rolled r ON r.key_hash = p.key_hash;
  END;

  -- [37] ICS_PRETR_PRMT
  IF EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P
             JOIN dbo.ICS_PRETR_PRMT C ON P.ICS_PAYLOAD_ID = C.ICS_PAYLOAD_ID
             WHERE P.ENABLED = 'Y')
  BEGIN
    ;WITH all_hashes (key_hash, data_hash) AS (

				
			 
				-- /[dbo].[ICS_PRETR_PRMT] 
				
				SELECT KEY_HASH, ICS_PRETR_PRMT.DATA_HASH 
				 from [dbo].[ICS_PRETR_PRMT] [ICS_PRETR_PRMT] 
				
			 
				-- /[dbo].[ICS_PRETR_PRMT]/[dbo].[ICS_CONTACT] 
				 UNION ALL 
				SELECT KEY_HASH, I1.DATA_HASH 
				 from [dbo].[ICS_PRETR_PRMT] [ICS_PRETR_PRMT] 
 JOIN [dbo].[ICS_CONTACT] [I1]
 ON [I1].[ICS_PRETR_PRMT_ID] = [ICS_PRETR_PRMT].[ICS_PRETR_PRMT_ID] 
				
			 
				-- /[dbo].[ICS_PRETR_PRMT]/[dbo].[ICS_CONTACT]/[dbo].[ICS_TELEPH] 
				 UNION ALL 
				SELECT KEY_HASH, I2.DATA_HASH 
				 from [dbo].[ICS_PRETR_PRMT] [ICS_PRETR_PRMT] 
 JOIN [dbo].[ICS_CONTACT] [I1]
 ON [I1].[ICS_PRETR_PRMT_ID] = [ICS_PRETR_PRMT].[ICS_PRETR_PRMT_ID] 
 JOIN [dbo].[ICS_TELEPH] [I2]
 ON [I2].[ICS_CONTACT_ID] = [I1].[ICS_CONTACT_ID] 
				
			 
				-- /[dbo].[ICS_PRETR_PRMT]/[dbo].[ICS_PRETR_PROG_MOD] 
				 UNION ALL 
				SELECT KEY_HASH, I3.DATA_HASH 
				 from [dbo].[ICS_PRETR_PRMT] [ICS_PRETR_PRMT] 
 JOIN [dbo].[ICS_PRETR_PROG_MOD] [I3]
 ON [I3].[ICS_PRETR_PRMT_ID] = [ICS_PRETR_PRMT].[ICS_PRETR_PRMT_ID] 
							  
    ),
    rolled (key_hash, rolled_hash) AS (
      SELECT
        key_hash,
        dbo.HASHBYTES_VARCHAR('SHA1',
          STRING_AGG(cast(data_hash as varchar(max)), '') WITHIN GROUP (ORDER BY data_hash)
        ) AS rolled_hash
      FROM all_hashes
      GROUP BY key_hash
    )
    UPDATE p
       SET p.data_hash = r.rolled_hash
      FROM dbo.ICS_PRETR_PRMT p
      JOIN rolled r ON r.key_hash = p.key_hash;
  END;

  -- [38] ICS_PRETR_PROG_REP
  IF EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P
             JOIN dbo.ICS_PRETR_PROG_REP C ON P.ICS_PAYLOAD_ID = C.ICS_PAYLOAD_ID
             WHERE P.ENABLED = 'Y')
  BEGIN
    ;WITH all_hashes (key_hash, data_hash) AS (

				
			 
				-- /[dbo].[ICS_PRETR_PROG_REP] 
				
				SELECT KEY_HASH, ICS_PRETR_PROG_REP.DATA_HASH 
				 from [dbo].[ICS_PRETR_PROG_REP] [ICS_PRETR_PROG_REP] 
				
			 
				-- /[dbo].[ICS_PRETR_PROG_REP]/[dbo].[ICS_CONTROL_AUTH_PROG_INFO] 
				 UNION ALL 
				SELECT KEY_HASH, I1.DATA_HASH 
				 from [dbo].[ICS_PRETR_PROG_REP] [ICS_PRETR_PROG_REP] 
 JOIN [dbo].[ICS_CONTROL_AUTH_PROG_INFO] [I1]
 ON [I1].[ICS_PRETR_PROG_REP_ID] = [ICS_PRETR_PROG_REP].[ICS_PRETR_PROG_REP_ID] 
				
			 
				-- /[dbo].[ICS_PRETR_PROG_REP]/[dbo].[ICS_CONTROL_AUTH_PROG_INFO]/[dbo].[ICS_LOC_LMTS_PARAMETERS] 
				 UNION ALL 
				SELECT KEY_HASH, I2.DATA_HASH 
				 from [dbo].[ICS_PRETR_PROG_REP] [ICS_PRETR_PROG_REP] 
 JOIN [dbo].[ICS_CONTROL_AUTH_PROG_INFO] [I1]
 ON [I1].[ICS_PRETR_PROG_REP_ID] = [ICS_PRETR_PROG_REP].[ICS_PRETR_PROG_REP_ID] 
 JOIN [dbo].[ICS_LOC_LMTS_PARAMETERS] [I2]
 ON [I2].[ICS_CONTROL_AUTH_PROG_INFO_ID] = [I1].[ICS_CONTROL_AUTH_PROG_INFO_ID] 
				
			 
				-- /[dbo].[ICS_PRETR_PROG_REP]/[dbo].[ICS_INDST_USR_INVENTORY] 
				 UNION ALL 
				SELECT KEY_HASH, I3.DATA_HASH 
				 from [dbo].[ICS_PRETR_PROG_REP] [ICS_PRETR_PROG_REP] 
 JOIN [dbo].[ICS_INDST_USR_INVENTORY] [I3]
 ON [I3].[ICS_PRETR_PROG_REP_ID] = [ICS_PRETR_PROG_REP].[ICS_PRETR_PROG_REP_ID] 
				
			 
				-- /[dbo].[ICS_PRETR_PROG_REP]/[dbo].[ICS_INDST_USR_INVENTORY]/[dbo].[ICS_INDST_USR_INFO] 
				 UNION ALL 
				SELECT KEY_HASH, I4.DATA_HASH 
				 from [dbo].[ICS_PRETR_PROG_REP] [ICS_PRETR_PROG_REP] 
 JOIN [dbo].[ICS_INDST_USR_INVENTORY] [I3]
 ON [I3].[ICS_PRETR_PROG_REP_ID] = [ICS_PRETR_PROG_REP].[ICS_PRETR_PROG_REP_ID] 
 JOIN [dbo].[ICS_INDST_USR_INFO] [I4]
 ON [I4].[ICS_INDST_USR_INVENTORY_ID] = [I3].[ICS_INDST_USR_INVENTORY_ID] 
				
			 
				-- /[dbo].[ICS_PRETR_PROG_REP]/[dbo].[ICS_INDST_USR_INVENTORY]/[dbo].[ICS_INDST_USR_INFO]/[dbo].[ICS_IU_ENFRC_ACTN_INFO] 
				 UNION ALL 
				SELECT KEY_HASH, I5.DATA_HASH 
				 from [dbo].[ICS_PRETR_PROG_REP] [ICS_PRETR_PROG_REP] 
 JOIN [dbo].[ICS_INDST_USR_INVENTORY] [I3]
 ON [I3].[ICS_PRETR_PROG_REP_ID] = [ICS_PRETR_PROG_REP].[ICS_PRETR_PROG_REP_ID] 
 JOIN [dbo].[ICS_INDST_USR_INFO] [I4]
 ON [I4].[ICS_INDST_USR_INVENTORY_ID] = [I3].[ICS_INDST_USR_INVENTORY_ID] 
 JOIN [dbo].[ICS_IU_ENFRC_ACTN_INFO] [I5]
 ON [I5].[ICS_INDST_USR_INFO_ID] = [I4].[ICS_INDST_USR_INFO_ID] 
				
			 
				-- /[dbo].[ICS_PRETR_PROG_REP]/[dbo].[ICS_INDST_USR_INVENTORY]/[dbo].[ICS_INDST_USR_INFO]/[dbo].[ICS_IU_ENFRC_ACTN_INFO]/[dbo].[ICS_IU_ENF_ACTN_TYPES] 
				 UNION ALL 
				SELECT KEY_HASH, I6.DATA_HASH 
				 from [dbo].[ICS_PRETR_PROG_REP] [ICS_PRETR_PROG_REP] 
 JOIN [dbo].[ICS_INDST_USR_INVENTORY] [I3]
 ON [I3].[ICS_PRETR_PROG_REP_ID] = [ICS_PRETR_PROG_REP].[ICS_PRETR_PROG_REP_ID] 
 JOIN [dbo].[ICS_INDST_USR_INFO] [I4]
 ON [I4].[ICS_INDST_USR_INVENTORY_ID] = [I3].[ICS_INDST_USR_INVENTORY_ID] 
 JOIN [dbo].[ICS_IU_ENFRC_ACTN_INFO] [I5]
 ON [I5].[ICS_INDST_USR_INFO_ID] = [I4].[ICS_INDST_USR_INFO_ID] 
 JOIN [dbo].[ICS_IU_ENF_ACTN_TYPES] [I6]
 ON [I6].[ICS_IU_ENFRC_ACTN_INFO_ID] = [I5].[ICS_IU_ENFRC_ACTN_INFO_ID] 
				
			 
				-- /[dbo].[ICS_PRETR_PROG_REP]/[dbo].[ICS_INDST_USR_INVENTORY]/[dbo].[ICS_INDST_USR_INFO]/[dbo].[ICS_IU_VIOL_INFO] 
				 UNION ALL 
				SELECT KEY_HASH, I7.DATA_HASH 
				 from [dbo].[ICS_PRETR_PROG_REP] [ICS_PRETR_PROG_REP] 
 JOIN [dbo].[ICS_INDST_USR_INVENTORY] [I3]
 ON [I3].[ICS_PRETR_PROG_REP_ID] = [ICS_PRETR_PROG_REP].[ICS_PRETR_PROG_REP_ID] 
 JOIN [dbo].[ICS_INDST_USR_INFO] [I4]
 ON [I4].[ICS_INDST_USR_INVENTORY_ID] = [I3].[ICS_INDST_USR_INVENTORY_ID] 
 JOIN [dbo].[ICS_IU_VIOL_INFO] [I7]
 ON [I7].[ICS_INDST_USR_INFO_ID] = [I4].[ICS_INDST_USR_INFO_ID] 
				
			 
				-- /[dbo].[ICS_PRETR_PROG_REP]/[dbo].[ICS_INDST_USR_INVENTORY]/[dbo].[ICS_INDST_USR_INFO]/[dbo].[ICS_IU_VIOL_INFO]/[dbo].[ICS_SNC_LISTING_MONTHS] 
				 UNION ALL 
				SELECT KEY_HASH, I8.DATA_HASH 
				 from [dbo].[ICS_PRETR_PROG_REP] [ICS_PRETR_PROG_REP] 
 JOIN [dbo].[ICS_INDST_USR_INVENTORY] [I3]
 ON [I3].[ICS_PRETR_PROG_REP_ID] = [ICS_PRETR_PROG_REP].[ICS_PRETR_PROG_REP_ID] 
 JOIN [dbo].[ICS_INDST_USR_INFO] [I4]
 ON [I4].[ICS_INDST_USR_INVENTORY_ID] = [I3].[ICS_INDST_USR_INVENTORY_ID] 
 JOIN [dbo].[ICS_IU_VIOL_INFO] [I7]
 ON [I7].[ICS_INDST_USR_INFO_ID] = [I4].[ICS_INDST_USR_INFO_ID] 
 JOIN [dbo].[ICS_SNC_LISTING_MONTHS] [I8]
 ON [I8].[ICS_IU_VIOL_INFO_ID] = [I7].[ICS_IU_VIOL_INFO_ID] 
				
			 
				-- /[dbo].[ICS_PRETR_PROG_REP]/[dbo].[ICS_INDST_USR_INVENTORY]/[dbo].[ICS_INDST_USR_INFO]/[dbo].[ICS_IU_VIOL_INFO]/[dbo].[ICS_SNC_PRETR_STND_LMTS_PARAMETERS] 
				 UNION ALL 
				SELECT KEY_HASH, I9.DATA_HASH 
				 from [dbo].[ICS_PRETR_PROG_REP] [ICS_PRETR_PROG_REP] 
 JOIN [dbo].[ICS_INDST_USR_INVENTORY] [I3]
 ON [I3].[ICS_PRETR_PROG_REP_ID] = [ICS_PRETR_PROG_REP].[ICS_PRETR_PROG_REP_ID] 
 JOIN [dbo].[ICS_INDST_USR_INFO] [I4]
 ON [I4].[ICS_INDST_USR_INVENTORY_ID] = [I3].[ICS_INDST_USR_INVENTORY_ID] 
 JOIN [dbo].[ICS_IU_VIOL_INFO] [I7]
 ON [I7].[ICS_INDST_USR_INFO_ID] = [I4].[ICS_INDST_USR_INFO_ID] 
 JOIN [dbo].[ICS_SNC_PRETR_STND_LMTS_PARAMETERS] [I9]
 ON [I9].[ICS_IU_VIOL_INFO_ID] = [I7].[ICS_IU_VIOL_INFO_ID] 
							  
    ),
    rolled (key_hash, rolled_hash) AS (
      SELECT
        key_hash,
        dbo.HASHBYTES_VARCHAR('SHA1',
          STRING_AGG(cast(data_hash as varchar(max)), '') WITHIN GROUP (ORDER BY data_hash)
        ) AS rolled_hash
      FROM all_hashes
      GROUP BY key_hash
    )
    UPDATE p
       SET p.data_hash = r.rolled_hash
      FROM dbo.ICS_PRETR_PROG_REP p
      JOIN rolled r ON r.key_hash = p.key_hash;
  END;

  -- [39] ICS_SCHD_EVT_VIOL
  IF EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P
             JOIN dbo.ICS_SCHD_EVT_VIOL C ON P.ICS_PAYLOAD_ID = C.ICS_PAYLOAD_ID
             WHERE P.ENABLED = 'Y')
  BEGIN
    ;WITH all_hashes (key_hash, data_hash) AS (
                      -- /ICS_SCHD_EVT_VIOL
                      SELECT key_hash
                           , child.data_hash
                        FROM dbo.ics_schd_evt_viol child
                      UNION ALL
                      -- /ICS_SCHD_EVT_VIOL/ICS_CMPL_SCHD_EVT_VIOL_ELEM
                      SELECT key_hash
                           , child.data_hash
                        FROM dbo.ics_schd_evt_viol
                        JOIN dbo.ics_cmpl_schd_evt_viol_elem child
                          ON child.ics_schd_evt_viol_id = ics_schd_evt_viol.ics_schd_evt_viol_id
                      UNION ALL
                      -- /ICS_SCHD_EVT_VIOL/ICS_PRMT_SCHD_EVT_VIOL_ELEM
                      SELECT key_hash
                           , child.data_hash
                        FROM dbo.ics_schd_evt_viol
                        JOIN dbo.ics_prmt_schd_evt_viol_elem child
                          ON child.ics_schd_evt_viol_id = ics_schd_evt_viol.ics_schd_evt_viol_id
							  
    ),
    rolled (key_hash, rolled_hash) AS (
      SELECT
        key_hash,
        dbo.HASHBYTES_VARCHAR('SHA1',
          STRING_AGG(cast(data_hash as varchar(max)), '') WITHIN GROUP (ORDER BY data_hash)
        ) AS rolled_hash
      FROM all_hashes
      GROUP BY key_hash
    )
    UPDATE p
       SET p.data_hash = r.rolled_hash
      FROM dbo.ICS_SCHD_EVT_VIOL p
      JOIN rolled r ON r.key_hash = p.key_hash;
  END;

  -- [40] ICS_SEWER_OVRFLW_BYPASS_EVT_REP
  IF EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P
             JOIN dbo.ICS_SEWER_OVRFLW_BYPASS_EVT_REP C ON P.ICS_PAYLOAD_ID = C.ICS_PAYLOAD_ID
             WHERE P.ENABLED = 'Y')
  BEGIN
    ;WITH all_hashes (key_hash, data_hash) AS (

				
			 
				-- /[dbo].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP] 
				
				SELECT KEY_HASH, ICS_SEWER_OVRFLW_BYPASS_EVT_REP.DATA_HASH 
				 from [dbo].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP] [ICS_SEWER_OVRFLW_BYPASS_EVT_REP] 
				
			 
				-- /[dbo].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP]/[dbo].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT] 
				 UNION ALL 
				SELECT KEY_HASH, I1.DATA_HASH 
				 from [dbo].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP] [ICS_SEWER_OVRFLW_BYPASS_EVT_REP] 
 JOIN [dbo].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT] [I1]
 ON [I1].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] = [ICS_SEWER_OVRFLW_BYPASS_EVT_REP].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] 
				
			 
				-- /[dbo].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP]/[dbo].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT]/[dbo].[ICS_SEWER_OVRFLW_BYPASS_CAUSE] 
				 UNION ALL 
				SELECT KEY_HASH, I2.DATA_HASH 
				 from [dbo].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP] [ICS_SEWER_OVRFLW_BYPASS_EVT_REP] 
 JOIN [dbo].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT] [I1]
 ON [I1].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] = [ICS_SEWER_OVRFLW_BYPASS_EVT_REP].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] 
 JOIN [dbo].[ICS_SEWER_OVRFLW_BYPASS_CAUSE] [I2]
 ON [I2].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] = [I1].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] 
				
			 
				-- /[dbo].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP]/[dbo].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT]/[dbo].[ICS_SEWER_OVRFLW_BYPASS_CORR_ACTN] 
				 UNION ALL 
				SELECT KEY_HASH, I3.DATA_HASH 
				 from [dbo].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP] [ICS_SEWER_OVRFLW_BYPASS_EVT_REP] 
 JOIN [dbo].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT] [I1]
 ON [I1].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] = [ICS_SEWER_OVRFLW_BYPASS_EVT_REP].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] 
 JOIN [dbo].[ICS_SEWER_OVRFLW_BYPASS_CORR_ACTN] [I3]
 ON [I3].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] = [I1].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] 
				
			 
				-- /[dbo].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP]/[dbo].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT]/[dbo].[ICS_SEWER_OVRFLW_BYPASS_IMPACT] 
				 UNION ALL 
				SELECT KEY_HASH, I4.DATA_HASH 
				 from [dbo].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP] [ICS_SEWER_OVRFLW_BYPASS_EVT_REP] 
 JOIN [dbo].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT] [I1]
 ON [I1].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] = [ICS_SEWER_OVRFLW_BYPASS_EVT_REP].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] 
 JOIN [dbo].[ICS_SEWER_OVRFLW_BYPASS_IMPACT] [I4]
 ON [I4].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] = [I1].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] 
				
			 
				-- /[dbo].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP]/[dbo].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT]/[dbo].[ICS_SEWER_OVRFLW_BYPASS_RCVG_WTR] 
				 UNION ALL 
				SELECT KEY_HASH, I5.DATA_HASH 
				 from [dbo].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP] [ICS_SEWER_OVRFLW_BYPASS_EVT_REP] 
 JOIN [dbo].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT] [I1]
 ON [I1].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] = [ICS_SEWER_OVRFLW_BYPASS_EVT_REP].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] 
 JOIN [dbo].[ICS_SEWER_OVRFLW_BYPASS_RCVG_WTR] [I5]
 ON [I5].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] = [I1].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] 
				
			 
				-- /[dbo].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP]/[dbo].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT]/[dbo].[ICS_SEWER_OVRFLW_BYPASS_TYPE] 
				 UNION ALL 
				SELECT KEY_HASH, I6.DATA_HASH 
				 from [dbo].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP] [ICS_SEWER_OVRFLW_BYPASS_EVT_REP] 
 JOIN [dbo].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT] [I1]
 ON [I1].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] = [ICS_SEWER_OVRFLW_BYPASS_EVT_REP].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] 
 JOIN [dbo].[ICS_SEWER_OVRFLW_BYPASS_TYPE] [I6]
 ON [I6].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] = [I1].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] 
				
			 
				-- /[dbo].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP]/[dbo].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT]/[dbo].[ICS_SEWER_OVRFLW_TRTMNT] 
				 UNION ALL 
				SELECT KEY_HASH, I7.DATA_HASH 
				 from [dbo].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP] [ICS_SEWER_OVRFLW_BYPASS_EVT_REP] 
 JOIN [dbo].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT] [I1]
 ON [I1].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] = [ICS_SEWER_OVRFLW_BYPASS_EVT_REP].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] 
 JOIN [dbo].[ICS_SEWER_OVRFLW_TRTMNT] [I7]
 ON [I7].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] = [I1].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] 
				
			 
				-- /[dbo].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP]/[dbo].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT]/[dbo].[ICS_BYPASS_TRTMNT_PLANT_EQUIPMENT] 
				 UNION ALL 
				SELECT KEY_HASH, I8.DATA_HASH 
				 from [dbo].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP] [ICS_SEWER_OVRFLW_BYPASS_EVT_REP] 
 JOIN [dbo].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT] [I1]
 ON [I1].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] = [ICS_SEWER_OVRFLW_BYPASS_EVT_REP].[ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID] 
 JOIN [dbo].[ICS_BYPASS_TRTMNT_PLANT_EQUIPMENT] [I8]
 ON [I8].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] = [I1].[ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID] 
							  
    ),
    rolled (key_hash, rolled_hash) AS (
      SELECT
        key_hash,
        dbo.HASHBYTES_VARCHAR('SHA1',
          STRING_AGG(cast(data_hash as varchar(max)), '') WITHIN GROUP (ORDER BY data_hash)
        ) AS rolled_hash
      FROM all_hashes
      GROUP BY key_hash
    )
    UPDATE p
       SET p.data_hash = r.rolled_hash
      FROM dbo.ICS_SEWER_OVRFLW_BYPASS_EVT_REP p
      JOIN rolled r ON r.key_hash = p.key_hash;
  END;

  -- [41] ICS_SNGL_EVT_VIOL
  IF EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P
             JOIN dbo.ICS_SNGL_EVT_VIOL C ON P.ICS_PAYLOAD_ID = C.ICS_PAYLOAD_ID
             WHERE P.ENABLED = 'Y')
  BEGIN
    ;WITH all_hashes (key_hash, data_hash) AS (

				
			 
				-- /[dbo].[ICS_SNGL_EVT_VIOL] 
				
				SELECT KEY_HASH, ICS_SNGL_EVT_VIOL.DATA_HASH 
				 from [dbo].[ICS_SNGL_EVT_VIOL] [ICS_SNGL_EVT_VIOL] 
							  
    ),
    rolled (key_hash, rolled_hash) AS (
      SELECT
        key_hash,
        dbo.HASHBYTES_VARCHAR('SHA1',
          STRING_AGG(cast(data_hash as varchar(max)), '') WITHIN GROUP (ORDER BY data_hash)
        ) AS rolled_hash
      FROM all_hashes
      GROUP BY key_hash
    )
    UPDATE p
       SET p.data_hash = r.rolled_hash
      FROM dbo.ICS_SNGL_EVT_VIOL p
      JOIN rolled r ON r.key_hash = p.key_hash;
  END;

  -- [42] ICS_SW_CNST_PRMT
  IF EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P
             JOIN dbo.ICS_SW_CNST_PRMT C ON P.ICS_PAYLOAD_ID = C.ICS_PAYLOAD_ID
             WHERE P.ENABLED = 'Y')
  BEGIN
    ;WITH all_hashes (key_hash, data_hash) AS (

				
			 
				-- /[dbo].[ICS_SW_CNST_PRMT] 
				
				SELECT KEY_HASH, ICS_SW_CNST_PRMT.DATA_HASH 
				 from [dbo].[ICS_SW_CNST_PRMT] [ICS_SW_CNST_PRMT] 
				
			 
				-- /[dbo].[ICS_SW_CNST_PRMT]/[dbo].[ICS_CONTACT] 
				 UNION ALL 
				SELECT KEY_HASH, I1.DATA_HASH 
				 from [dbo].[ICS_SW_CNST_PRMT] [ICS_SW_CNST_PRMT] 
 JOIN [dbo].[ICS_CONTACT] [I1]
 ON [I1].[ICS_SW_CNST_PRMT_ID] = [ICS_SW_CNST_PRMT].[ICS_SW_CNST_PRMT_ID] 
				
			 
				-- /[dbo].[ICS_SW_CNST_PRMT]/[dbo].[ICS_CONTACT]/[dbo].[ICS_TELEPH] 
				 UNION ALL 
				SELECT KEY_HASH, I2.DATA_HASH 
				 from [dbo].[ICS_SW_CNST_PRMT] [ICS_SW_CNST_PRMT] 
 JOIN [dbo].[ICS_CONTACT] [I1]
 ON [I1].[ICS_SW_CNST_PRMT_ID] = [ICS_SW_CNST_PRMT].[ICS_SW_CNST_PRMT_ID] 
 JOIN [dbo].[ICS_TELEPH] [I2]
 ON [I2].[ICS_CONTACT_ID] = [I1].[ICS_CONTACT_ID] 
				
			 
				-- /[dbo].[ICS_SW_CNST_PRMT]/[dbo].[ICS_PROPOSED_CNST_SW_BM_PS] 
				 UNION ALL 
				SELECT KEY_HASH, I3.DATA_HASH 
				 from [dbo].[ICS_SW_CNST_PRMT] [ICS_SW_CNST_PRMT] 
 JOIN [dbo].[ICS_PROPOSED_CNST_SW_BM_PS] [I3]
 ON [I3].[ICS_SW_CNST_PRMT_ID] = [ICS_SW_CNST_PRMT].[ICS_SW_CNST_PRMT_ID] 
				
			 
				-- /[dbo].[ICS_SW_CNST_PRMT]/[dbo].[ICS_PROPOSED_POST_CNST_SW_BM_PS] 
				 UNION ALL 
				SELECT KEY_HASH, I4.DATA_HASH 
				 from [dbo].[ICS_SW_CNST_PRMT] [ICS_SW_CNST_PRMT] 
 JOIN [dbo].[ICS_PROPOSED_POST_CNST_SW_BM_PS] [I4]
 ON [I4].[ICS_SW_CNST_PRMT_ID] = [ICS_SW_CNST_PRMT].[ICS_SW_CNST_PRMT_ID] 
				
			 
				-- /[dbo].[ICS_SW_CNST_PRMT]/[dbo].[ICS_GPCF_NOTICE_OF_INTENT] 
				 UNION ALL 
				SELECT KEY_HASH, I5.DATA_HASH 
				 from [dbo].[ICS_SW_CNST_PRMT] [ICS_SW_CNST_PRMT] 
 JOIN [dbo].[ICS_GPCF_NOTICE_OF_INTENT] [I5]
 ON [I5].[ICS_SW_CNST_PRMT_ID] = [ICS_SW_CNST_PRMT].[ICS_SW_CNST_PRMT_ID] 
				
			 
				-- /[dbo].[ICS_SW_CNST_PRMT]/[dbo].[ICS_GPCF_NOTICE_OF_INTENT]/[dbo].[ICS_SUBSECTOR_CODE_PLUS_DESC] 
				 UNION ALL 
				SELECT KEY_HASH, I6.DATA_HASH 
				 from [dbo].[ICS_SW_CNST_PRMT] [ICS_SW_CNST_PRMT] 
 JOIN [dbo].[ICS_GPCF_NOTICE_OF_INTENT] [I5]
 ON [I5].[ICS_SW_CNST_PRMT_ID] = [ICS_SW_CNST_PRMT].[ICS_SW_CNST_PRMT_ID] 
 JOIN [dbo].[ICS_SUBSECTOR_CODE_PLUS_DESC] [I6]
 ON [I6].[ICS_GPCF_NOTICE_OF_INTENT_ID] = [I5].[ICS_GPCF_NOTICE_OF_INTENT_ID] 
				
			 
				-- /[dbo].[ICS_SW_CNST_PRMT]/[dbo].[ICS_ADDR] 
				 UNION ALL 
				SELECT KEY_HASH, I7.DATA_HASH 
				 from [dbo].[ICS_SW_CNST_PRMT] [ICS_SW_CNST_PRMT] 
 JOIN [dbo].[ICS_ADDR] [I7]
 ON [I7].[ICS_SW_CNST_PRMT_ID] = [ICS_SW_CNST_PRMT].[ICS_SW_CNST_PRMT_ID] 
				
			 
				-- /[dbo].[ICS_SW_CNST_PRMT]/[dbo].[ICS_ADDR]/[dbo].[ICS_TELEPH] 
				 UNION ALL 
				SELECT KEY_HASH, I8.DATA_HASH 
				 from [dbo].[ICS_SW_CNST_PRMT] [ICS_SW_CNST_PRMT] 
 JOIN [dbo].[ICS_ADDR] [I7]
 ON [I7].[ICS_SW_CNST_PRMT_ID] = [ICS_SW_CNST_PRMT].[ICS_SW_CNST_PRMT_ID] 
 JOIN [dbo].[ICS_TELEPH] [I8]
 ON [I8].[ICS_ADDR_ID] = [I7].[ICS_ADDR_ID] 
				
			 
				-- /[dbo].[ICS_SW_CNST_PRMT]/[dbo].[ICS_TRTMNT_CHEMS_LIST] 
				 UNION ALL 
				SELECT KEY_HASH, I9.DATA_HASH 
				 from [dbo].[ICS_SW_CNST_PRMT] [ICS_SW_CNST_PRMT] 
 JOIN [dbo].[ICS_TRTMNT_CHEMS_LIST] [I9]
 ON [I9].[ICS_SW_CNST_PRMT_ID] = [ICS_SW_CNST_PRMT].[ICS_SW_CNST_PRMT_ID] 
				
			 
				-- /[dbo].[ICS_SW_CNST_PRMT]/[dbo].[ICS_CNST_SITE_LIST] 
				 UNION ALL 
				SELECT KEY_HASH, I10.DATA_HASH 
				 from [dbo].[ICS_SW_CNST_PRMT] [ICS_SW_CNST_PRMT] 
 JOIN [dbo].[ICS_CNST_SITE_LIST] [I10]
 ON [I10].[ICS_SW_CNST_PRMT_ID] = [ICS_SW_CNST_PRMT].[ICS_SW_CNST_PRMT_ID] 
				
			 
				-- /[dbo].[ICS_SW_CNST_PRMT]/[dbo].[ICS_CNST_SITE_LIST]/[dbo].[ICS_CNST_SITE] 
				 UNION ALL 
				SELECT KEY_HASH, I11.DATA_HASH 
				 from [dbo].[ICS_SW_CNST_PRMT] [ICS_SW_CNST_PRMT] 
 JOIN [dbo].[ICS_CNST_SITE_LIST] [I10]
 ON [I10].[ICS_SW_CNST_PRMT_ID] = [ICS_SW_CNST_PRMT].[ICS_SW_CNST_PRMT_ID] 
 JOIN [dbo].[ICS_CNST_SITE] [I11]
 ON [I11].[ICS_CNST_SITE_LIST_ID] = [I10].[ICS_CNST_SITE_LIST_ID] 
							  
    ),
    rolled (key_hash, rolled_hash) AS (
      SELECT
        key_hash,
        dbo.HASHBYTES_VARCHAR('SHA1',
          STRING_AGG(cast(data_hash as varchar(max)), '') WITHIN GROUP (ORDER BY data_hash)
        ) AS rolled_hash
      FROM all_hashes
      GROUP BY key_hash
    )
    UPDATE p
       SET p.data_hash = r.rolled_hash
      FROM dbo.ICS_SW_CNST_PRMT p
      JOIN rolled r ON r.key_hash = p.key_hash;
  END;

  -- [43] ICS_SW_INDST_ANNUL_REP
  IF EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P
             JOIN dbo.ICS_SW_INDST_ANNUL_REP C ON P.ICS_PAYLOAD_ID = C.ICS_PAYLOAD_ID
             WHERE P.ENABLED = 'Y')
  BEGIN
    ;WITH all_hashes (key_hash, data_hash) AS (

				
			 
				-- /[dbo].[ICS_SW_INDST_ANNUL_REP] 
				
				SELECT KEY_HASH, ICS_SW_INDST_ANNUL_REP.DATA_HASH 
				 from [dbo].[ICS_SW_INDST_ANNUL_REP] [ICS_SW_INDST_ANNUL_REP] 
							  
    ),
    rolled (key_hash, rolled_hash) AS (
      SELECT
        key_hash,
        dbo.HASHBYTES_VARCHAR('SHA1',
          STRING_AGG(cast(data_hash as varchar(max)), '') WITHIN GROUP (ORDER BY data_hash)
        ) AS rolled_hash
      FROM all_hashes
      GROUP BY key_hash
    )
    UPDATE p
       SET p.data_hash = r.rolled_hash
      FROM dbo.ICS_SW_INDST_ANNUL_REP p
      JOIN rolled r ON r.key_hash = p.key_hash;
  END;

  -- [44] ICS_SW_INDST_PRMT
  IF EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P
             JOIN dbo.ICS_SW_INDST_PRMT C ON P.ICS_PAYLOAD_ID = C.ICS_PAYLOAD_ID
             WHERE P.ENABLED = 'Y')
  BEGIN
    ;WITH all_hashes (key_hash, data_hash) AS (

				
			 
				-- /[dbo].[ICS_SW_INDST_PRMT] 
				
				SELECT KEY_HASH, ICS_SW_INDST_PRMT.DATA_HASH 
				 from [dbo].[ICS_SW_INDST_PRMT] [ICS_SW_INDST_PRMT] 
				
			 
				-- /[dbo].[ICS_SW_INDST_PRMT]/[dbo].[ICS_CONTACT] 
				 UNION ALL 
				SELECT KEY_HASH, I1.DATA_HASH 
				 from [dbo].[ICS_SW_INDST_PRMT] [ICS_SW_INDST_PRMT] 
 JOIN [dbo].[ICS_CONTACT] [I1]
 ON [I1].[ICS_SW_INDST_PRMT_ID] = [ICS_SW_INDST_PRMT].[ICS_SW_INDST_PRMT_ID] 
				
			 
				-- /[dbo].[ICS_SW_INDST_PRMT]/[dbo].[ICS_CONTACT]/[dbo].[ICS_TELEPH] 
				 UNION ALL 
				SELECT KEY_HASH, I2.DATA_HASH 
				 from [dbo].[ICS_SW_INDST_PRMT] [ICS_SW_INDST_PRMT] 
 JOIN [dbo].[ICS_CONTACT] [I1]
 ON [I1].[ICS_SW_INDST_PRMT_ID] = [ICS_SW_INDST_PRMT].[ICS_SW_INDST_PRMT_ID] 
 JOIN [dbo].[ICS_TELEPH] [I2]
 ON [I2].[ICS_CONTACT_ID] = [I1].[ICS_CONTACT_ID] 
				
			 
				-- /[dbo].[ICS_SW_INDST_PRMT]/[dbo].[ICS_PROPOSED_INDST_SW_BM_PS] 
				 UNION ALL 
				SELECT KEY_HASH, I3.DATA_HASH 
				 from [dbo].[ICS_SW_INDST_PRMT] [ICS_SW_INDST_PRMT] 
 JOIN [dbo].[ICS_PROPOSED_INDST_SW_BM_PS] [I3]
 ON [I3].[ICS_SW_INDST_PRMT_ID] = [ICS_SW_INDST_PRMT].[ICS_SW_INDST_PRMT_ID] 
				
			 
				-- /[dbo].[ICS_SW_INDST_PRMT]/[dbo].[ICS_GPCF_NO_EXPOSURE] 
				 UNION ALL 
				SELECT KEY_HASH, I4.DATA_HASH 
				 from [dbo].[ICS_SW_INDST_PRMT] [ICS_SW_INDST_PRMT] 
 JOIN [dbo].[ICS_GPCF_NO_EXPOSURE] [I4]
 ON [I4].[ICS_SW_INDST_PRMT_ID] = [ICS_SW_INDST_PRMT].[ICS_SW_INDST_PRMT_ID] 
				
			 
				-- /[dbo].[ICS_SW_INDST_PRMT]/[dbo].[ICS_GPCF_NOTICE_OF_INTENT] 
				 UNION ALL 
				SELECT KEY_HASH, I5.DATA_HASH 
				 from [dbo].[ICS_SW_INDST_PRMT] [ICS_SW_INDST_PRMT] 
 JOIN [dbo].[ICS_GPCF_NOTICE_OF_INTENT] [I5]
 ON [I5].[ICS_SW_INDST_PRMT_ID] = [ICS_SW_INDST_PRMT].[ICS_SW_INDST_PRMT_ID] 
				
			 
				-- /[dbo].[ICS_SW_INDST_PRMT]/[dbo].[ICS_GPCF_NOTICE_OF_INTENT]/[dbo].[ICS_SUBSECTOR_CODE_PLUS_DESC] 
				 UNION ALL 
				SELECT KEY_HASH, I6.DATA_HASH 
				 from [dbo].[ICS_SW_INDST_PRMT] [ICS_SW_INDST_PRMT] 
 JOIN [dbo].[ICS_GPCF_NOTICE_OF_INTENT] [I5]
 ON [I5].[ICS_SW_INDST_PRMT_ID] = [ICS_SW_INDST_PRMT].[ICS_SW_INDST_PRMT_ID] 
 JOIN [dbo].[ICS_SUBSECTOR_CODE_PLUS_DESC] [I6]
 ON [I6].[ICS_GPCF_NOTICE_OF_INTENT_ID] = [I5].[ICS_GPCF_NOTICE_OF_INTENT_ID] 
				
			 
				-- /[dbo].[ICS_SW_INDST_PRMT]/[dbo].[ICS_GPCF_NOTICE_OF_TERM] 
				 UNION ALL 
				SELECT KEY_HASH, I7.DATA_HASH 
				 from [dbo].[ICS_SW_INDST_PRMT] [ICS_SW_INDST_PRMT] 
 JOIN [dbo].[ICS_GPCF_NOTICE_OF_TERM] [I7]
 ON [I7].[ICS_SW_INDST_PRMT_ID] = [ICS_SW_INDST_PRMT].[ICS_SW_INDST_PRMT_ID] 
				
			 
				-- /[dbo].[ICS_SW_INDST_PRMT]/[dbo].[ICS_ADDR] 
				 UNION ALL 
				SELECT KEY_HASH, I8.DATA_HASH 
				 from [dbo].[ICS_SW_INDST_PRMT] [ICS_SW_INDST_PRMT] 
 JOIN [dbo].[ICS_ADDR] [I8]
 ON [I8].[ICS_SW_INDST_PRMT_ID] = [ICS_SW_INDST_PRMT].[ICS_SW_INDST_PRMT_ID] 
				
			 
				-- /[dbo].[ICS_SW_INDST_PRMT]/[dbo].[ICS_ADDR]/[dbo].[ICS_TELEPH] 
				 UNION ALL 
				SELECT KEY_HASH, I9.DATA_HASH 
				 from [dbo].[ICS_SW_INDST_PRMT] [ICS_SW_INDST_PRMT] 
 JOIN [dbo].[ICS_ADDR] [I8]
 ON [I8].[ICS_SW_INDST_PRMT_ID] = [ICS_SW_INDST_PRMT].[ICS_SW_INDST_PRMT_ID] 
 JOIN [dbo].[ICS_TELEPH] [I9]
 ON [I9].[ICS_ADDR_ID] = [I8].[ICS_ADDR_ID] 
							  
    ),
    rolled (key_hash, rolled_hash) AS (
      SELECT
        key_hash,
        dbo.HASHBYTES_VARCHAR('SHA1',
          STRING_AGG(cast(data_hash as varchar(max)), '') WITHIN GROUP (ORDER BY data_hash)
        ) AS rolled_hash
      FROM all_hashes
      GROUP BY key_hash
    )
    UPDATE p
       SET p.data_hash = r.rolled_hash
      FROM dbo.ICS_SW_INDST_PRMT p
      JOIN rolled r ON r.key_hash = p.key_hash;
  END;

  -- [45] ICS_SWMS_4_ANNUL_PROG_REP
  IF EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P
             JOIN dbo.ICS_SWMS_4_ANNUL_PROG_REP C ON P.ICS_PAYLOAD_ID = C.ICS_PAYLOAD_ID
             WHERE P.ENABLED = 'Y')
  BEGIN
    ;WITH all_hashes (key_hash, data_hash) AS (

				
			 
				-- /[dbo].[ICS_SWMS_4_ANNUL_PROG_REP] 
				
				SELECT KEY_HASH, ICS_SWMS_4_ANNUL_PROG_REP.DATA_HASH 
				 from [dbo].[ICS_SWMS_4_ANNUL_PROG_REP] [ICS_SWMS_4_ANNUL_PROG_REP] 
				
			 
				-- /[dbo].[ICS_SWMS_4_ANNUL_PROG_REP]/[dbo].[ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO_PROG_REP] 
				 UNION ALL 
				SELECT KEY_HASH, I1.DATA_HASH 
				 from [dbo].[ICS_SWMS_4_ANNUL_PROG_REP] [ICS_SWMS_4_ANNUL_PROG_REP] 
 JOIN [dbo].[ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO_PROG_REP] [I1]
 ON [I1].[ICS_SWMS_4_ANNUL_PROG_REP_ID] = [ICS_SWMS_4_ANNUL_PROG_REP].[ICS_SWMS_4_ANNUL_PROG_REP_ID] 
				
			 
				-- /[dbo].[ICS_SWMS_4_ANNUL_PROG_REP]/[dbo].[ICS_MS_4_PROG_REP_ANALYSIS] 
				 UNION ALL 
				SELECT KEY_HASH, I2.DATA_HASH 
				 from [dbo].[ICS_SWMS_4_ANNUL_PROG_REP] [ICS_SWMS_4_ANNUL_PROG_REP] 
 JOIN [dbo].[ICS_MS_4_PROG_REP_ANALYSIS] [I2]
 ON [I2].[ICS_SWMS_4_ANNUL_PROG_REP_ID] = [ICS_SWMS_4_ANNUL_PROG_REP].[ICS_SWMS_4_ANNUL_PROG_REP_ID] 
				
			 
				-- /[dbo].[ICS_SWMS_4_ANNUL_PROG_REP]/[dbo].[ICS_MS_4_PROG_REP_ANALYSIS]/[dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT] 
				 UNION ALL 
				SELECT KEY_HASH, I3.DATA_HASH 
				 from [dbo].[ICS_SWMS_4_ANNUL_PROG_REP] [ICS_SWMS_4_ANNUL_PROG_REP] 
 JOIN [dbo].[ICS_MS_4_PROG_REP_ANALYSIS] [I2]
 ON [I2].[ICS_SWMS_4_ANNUL_PROG_REP_ID] = [ICS_SWMS_4_ANNUL_PROG_REP].[ICS_SWMS_4_ANNUL_PROG_REP_ID] 
 JOIN [dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT] [I3]
 ON [I3].[ICS_MS_4_PROG_REP_ANALYSIS_ID] = [I2].[ICS_MS_4_PROG_REP_ANALYSIS_ID] 
				
			 
				-- /[dbo].[ICS_SWMS_4_ANNUL_PROG_REP]/[dbo].[ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY] 
				 UNION ALL 
				SELECT KEY_HASH, I4.DATA_HASH 
				 from [dbo].[ICS_SWMS_4_ANNUL_PROG_REP] [ICS_SWMS_4_ANNUL_PROG_REP] 
 JOIN [dbo].[ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY] [I4]
 ON [I4].[ICS_SWMS_4_ANNUL_PROG_REP_ID] = [ICS_SWMS_4_ANNUL_PROG_REP].[ICS_SWMS_4_ANNUL_PROG_REP_ID] 
				
			 
				-- /[dbo].[ICS_SWMS_4_ANNUL_PROG_REP]/[dbo].[ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY]/[dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT] 
				 UNION ALL 
				SELECT KEY_HASH, I5.DATA_HASH 
				 from [dbo].[ICS_SWMS_4_ANNUL_PROG_REP] [ICS_SWMS_4_ANNUL_PROG_REP] 
 JOIN [dbo].[ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY] [I4]
 ON [I4].[ICS_SWMS_4_ANNUL_PROG_REP_ID] = [ICS_SWMS_4_ANNUL_PROG_REP].[ICS_SWMS_4_ANNUL_PROG_REP_ID] 
 JOIN [dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT] [I5]
 ON [I5].[ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY_ID] = [I4].[ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY_ID] 
				
			 
				-- /[dbo].[ICS_SWMS_4_ANNUL_PROG_REP]/[dbo].[ICS_MS_4_REGULATED_ENTITY_ENFRC] 
				 UNION ALL 
				SELECT KEY_HASH, I6.DATA_HASH 
				 from [dbo].[ICS_SWMS_4_ANNUL_PROG_REP] [ICS_SWMS_4_ANNUL_PROG_REP] 
 JOIN [dbo].[ICS_MS_4_REGULATED_ENTITY_ENFRC] [I6]
 ON [I6].[ICS_SWMS_4_ANNUL_PROG_REP_ID] = [ICS_SWMS_4_ANNUL_PROG_REP].[ICS_SWMS_4_ANNUL_PROG_REP_ID] 
				
			 
				-- /[dbo].[ICS_SWMS_4_ANNUL_PROG_REP]/[dbo].[ICS_MS_4_REGULATED_ENTITY_ENFRC]/[dbo].[ICS_MS_4_REGULATED_ENTITY_ENFRC_ACTIONS] 
				 UNION ALL 
				SELECT KEY_HASH, I7.DATA_HASH 
				 from [dbo].[ICS_SWMS_4_ANNUL_PROG_REP] [ICS_SWMS_4_ANNUL_PROG_REP] 
 JOIN [dbo].[ICS_MS_4_REGULATED_ENTITY_ENFRC] [I6]
 ON [I6].[ICS_SWMS_4_ANNUL_PROG_REP_ID] = [ICS_SWMS_4_ANNUL_PROG_REP].[ICS_SWMS_4_ANNUL_PROG_REP_ID] 
 JOIN [dbo].[ICS_MS_4_REGULATED_ENTITY_ENFRC_ACTIONS] [I7]
 ON [I7].[ICS_MS_4_REGULATED_ENTITY_ENFRC_ID] = [I6].[ICS_MS_4_REGULATED_ENTITY_ENFRC_ID] 
				
			 
				-- /[dbo].[ICS_SWMS_4_ANNUL_PROG_REP]/[dbo].[ICS_MS_4_SWMP_CHANGES] 
				 UNION ALL 
				SELECT KEY_HASH, I8.DATA_HASH 
				 from [dbo].[ICS_SWMS_4_ANNUL_PROG_REP] [ICS_SWMS_4_ANNUL_PROG_REP] 
 JOIN [dbo].[ICS_MS_4_SWMP_CHANGES] [I8]
 ON [I8].[ICS_SWMS_4_ANNUL_PROG_REP_ID] = [ICS_SWMS_4_ANNUL_PROG_REP].[ICS_SWMS_4_ANNUL_PROG_REP_ID] 
							  
    ),
    rolled (key_hash, rolled_hash) AS (
      SELECT
        key_hash,
        dbo.HASHBYTES_VARCHAR('SHA1',
          STRING_AGG(cast(data_hash as varchar(max)), '') WITHIN GROUP (ORDER BY data_hash)
        ) AS rolled_hash
      FROM all_hashes
      GROUP BY key_hash
    )
    UPDATE p
       SET p.data_hash = r.rolled_hash
      FROM dbo.ICS_SWMS_4_ANNUL_PROG_REP p
      JOIN rolled r ON r.key_hash = p.key_hash;
  END;

  -- [46] ICS_SWMS_4_PRMT
  IF EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P
             JOIN dbo.ICS_SWMS_4_PRMT C ON P.ICS_PAYLOAD_ID = C.ICS_PAYLOAD_ID
             WHERE P.ENABLED = 'Y')
  BEGIN
    ;WITH all_hashes (key_hash, data_hash) AS (

				
			 
				-- /[dbo].[ICS_SWMS_4_PRMT] 
				
				SELECT KEY_HASH, ICS_SWMS_4_PRMT.DATA_HASH 
				 from [dbo].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
				
			 
				-- /[dbo].[ICS_SWMS_4_PRMT]/[dbo].[ICS_MS_4_CNST_SW_REQS] 
				 UNION ALL 
				SELECT KEY_HASH, I1.DATA_HASH 
				 from [dbo].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [dbo].[ICS_MS_4_CNST_SW_REQS] [I1]
 ON [I1].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
				
			 
				-- /[dbo].[ICS_SWMS_4_PRMT]/[dbo].[ICS_MS_4_CNST_SW_REQS]/[dbo].[ICS_MS_4_CNST_SW_PROCEDURES] 
				 UNION ALL 
				SELECT KEY_HASH, I2.DATA_HASH 
				 from [dbo].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [dbo].[ICS_MS_4_CNST_SW_REQS] [I1]
 ON [I1].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN [dbo].[ICS_MS_4_CNST_SW_PROCEDURES] [I2]
 ON [I2].[ICS_MS_4_CNST_SW_REQS_ID] = [I1].[ICS_MS_4_CNST_SW_REQS_ID] 
				
			 
				-- /[dbo].[ICS_SWMS_4_PRMT]/[dbo].[ICS_MS_4_CNST_SW_REQS]/[dbo].[ICS_MS_4_CNST_SW_PROCEDURES]/[dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT] 
				 UNION ALL 
				SELECT KEY_HASH, I3.DATA_HASH 
				 from [dbo].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [dbo].[ICS_MS_4_CNST_SW_REQS] [I1]
 ON [I1].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN [dbo].[ICS_MS_4_CNST_SW_PROCEDURES] [I2]
 ON [I2].[ICS_MS_4_CNST_SW_REQS_ID] = [I1].[ICS_MS_4_CNST_SW_REQS_ID] 
 JOIN [dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT] [I3]
 ON [I3].[ICS_MS_4_CNST_SW_PROCEDURES_ID] = [I2].[ICS_MS_4_CNST_SW_PROCEDURES_ID] 
				
			 
				-- /[dbo].[ICS_SWMS_4_PRMT]/[dbo].[ICS_MS_4_CNST_SW_REQS]/[dbo].[ICS_MS_4_CNST_SW_REGULATED_ENTITY_INFO] 
				 UNION ALL 
				SELECT KEY_HASH, I4.DATA_HASH 
				 from [dbo].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [dbo].[ICS_MS_4_CNST_SW_REQS] [I1]
 ON [I1].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN [dbo].[ICS_MS_4_CNST_SW_REGULATED_ENTITY_INFO] [I4]
 ON [I4].[ICS_MS_4_CNST_SW_REQS_ID] = [I1].[ICS_MS_4_CNST_SW_REQS_ID] 
				
			 
				-- /[dbo].[ICS_SWMS_4_PRMT]/[dbo].[ICS_MS_4_ILLICIT_DETECT_REQS] 
				 UNION ALL 
				SELECT KEY_HASH, I5.DATA_HASH 
				 from [dbo].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [dbo].[ICS_MS_4_ILLICIT_DETECT_REQS] [I5]
 ON [I5].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
				
			 
				-- /[dbo].[ICS_SWMS_4_PRMT]/[dbo].[ICS_MS_4_ILLICIT_DETECT_REQS]/[dbo].[ICS_MS_4_ILLICIT_DETECT_PROCEDURES] 
				 UNION ALL 
				SELECT KEY_HASH, I6.DATA_HASH 
				 from [dbo].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [dbo].[ICS_MS_4_ILLICIT_DETECT_REQS] [I5]
 ON [I5].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN [dbo].[ICS_MS_4_ILLICIT_DETECT_PROCEDURES] [I6]
 ON [I6].[ICS_MS_4_ILLICIT_DETECT_REQS_ID] = [I5].[ICS_MS_4_ILLICIT_DETECT_REQS_ID] 
				
			 
				-- /[dbo].[ICS_SWMS_4_PRMT]/[dbo].[ICS_MS_4_ILLICIT_DETECT_REQS]/[dbo].[ICS_MS_4_ILLICIT_DETECT_PROCEDURES]/[dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT] 
				 UNION ALL 
				SELECT KEY_HASH, I7.DATA_HASH 
				 from [dbo].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [dbo].[ICS_MS_4_ILLICIT_DETECT_REQS] [I5]
 ON [I5].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN [dbo].[ICS_MS_4_ILLICIT_DETECT_PROCEDURES] [I6]
 ON [I6].[ICS_MS_4_ILLICIT_DETECT_REQS_ID] = [I5].[ICS_MS_4_ILLICIT_DETECT_REQS_ID] 
 JOIN [dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT] [I7]
 ON [I7].[ICS_MS_4_ILLICIT_DETECT_PROCEDURES_ID] = [I6].[ICS_MS_4_ILLICIT_DETECT_PROCEDURES_ID] 
				
			 
				-- /[dbo].[ICS_SWMS_4_PRMT]/[dbo].[ICS_MS_4_ILLICIT_DETECT_REQS]/[dbo].[ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO] 
				 UNION ALL 
				SELECT KEY_HASH, I8.DATA_HASH 
				 from [dbo].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [dbo].[ICS_MS_4_ILLICIT_DETECT_REQS] [I5]
 ON [I5].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN [dbo].[ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO] [I8]
 ON [I8].[ICS_MS_4_ILLICIT_DETECT_REQS_ID] = [I5].[ICS_MS_4_ILLICIT_DETECT_REQS_ID] 
				
			 
				-- /[dbo].[ICS_SWMS_4_PRMT]/[dbo].[ICS_MS_4_INDST_SW_REQS] 
				 UNION ALL 
				SELECT KEY_HASH, I9.DATA_HASH 
				 from [dbo].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [dbo].[ICS_MS_4_INDST_SW_REQS] [I9]
 ON [I9].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
				
			 
				-- /[dbo].[ICS_SWMS_4_PRMT]/[dbo].[ICS_MS_4_INDST_SW_REQS]/[dbo].[ICS_MS_4_INDST_SW_PROCEDURES] 
				 UNION ALL 
				SELECT KEY_HASH, I10.DATA_HASH 
				 from [dbo].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [dbo].[ICS_MS_4_INDST_SW_REQS] [I9]
 ON [I9].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN [dbo].[ICS_MS_4_INDST_SW_PROCEDURES] [I10]
 ON [I10].[ICS_MS_4_INDST_SW_REQS_ID] = [I9].[ICS_MS_4_INDST_SW_REQS_ID] 
				
			 
				-- /[dbo].[ICS_SWMS_4_PRMT]/[dbo].[ICS_MS_4_INDST_SW_REQS]/[dbo].[ICS_MS_4_INDST_SW_PROCEDURES]/[dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT] 
				 UNION ALL 
				SELECT KEY_HASH, I11.DATA_HASH 
				 from [dbo].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [dbo].[ICS_MS_4_INDST_SW_REQS] [I9]
 ON [I9].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN [dbo].[ICS_MS_4_INDST_SW_PROCEDURES] [I10]
 ON [I10].[ICS_MS_4_INDST_SW_REQS_ID] = [I9].[ICS_MS_4_INDST_SW_REQS_ID] 
 JOIN [dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT] [I11]
 ON [I11].[ICS_MS_4_INDST_SW_PROCEDURES_ID] = [I10].[ICS_MS_4_INDST_SW_PROCEDURES_ID] 
				
			 
				-- /[dbo].[ICS_SWMS_4_PRMT]/[dbo].[ICS_MS_4_INDST_SW_REQS]/[dbo].[ICS_MS_4_INDST_SW_REGULATED_ENTITY_INFO] 
				 UNION ALL 
				SELECT KEY_HASH, I12.DATA_HASH 
				 from [dbo].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [dbo].[ICS_MS_4_INDST_SW_REQS] [I9]
 ON [I9].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN [dbo].[ICS_MS_4_INDST_SW_REGULATED_ENTITY_INFO] [I12]
 ON [I12].[ICS_MS_4_INDST_SW_REQS_ID] = [I9].[ICS_MS_4_INDST_SW_REQS_ID] 
				
			 
				-- /[dbo].[ICS_SWMS_4_PRMT]/[dbo].[ICS_MS_4_OTHR_APPL_REQS] 
				 UNION ALL 
				SELECT KEY_HASH, I13.DATA_HASH 
				 from [dbo].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [dbo].[ICS_MS_4_OTHR_APPL_REQS] [I13]
 ON [I13].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
				
			 
				-- /[dbo].[ICS_SWMS_4_PRMT]/[dbo].[ICS_MS_4_OTHR_APPL_REQS]/[dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT] 
				 UNION ALL 
				SELECT KEY_HASH, I14.DATA_HASH 
				 from [dbo].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [dbo].[ICS_MS_4_OTHR_APPL_REQS] [I13]
 ON [I13].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN [dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT] [I14]
 ON [I14].[ICS_MS_4_OTHR_APPL_REQS_ID] = [I13].[ICS_MS_4_OTHR_APPL_REQS_ID] 
				
			 
				-- /[dbo].[ICS_SWMS_4_PRMT]/[dbo].[ICS_MS_4_PBLC_EDUCATION_REQS] 
				 UNION ALL 
				SELECT KEY_HASH, I15.DATA_HASH 
				 from [dbo].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [dbo].[ICS_MS_4_PBLC_EDUCATION_REQS] [I15]
 ON [I15].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
				
			 
				-- /[dbo].[ICS_SWMS_4_PRMT]/[dbo].[ICS_MS_4_PBLC_EDUCATION_REQS]/[dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT] 
				 UNION ALL 
				SELECT KEY_HASH, I16.DATA_HASH 
				 from [dbo].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [dbo].[ICS_MS_4_PBLC_EDUCATION_REQS] [I15]
 ON [I15].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN [dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT] [I16]
 ON [I16].[ICS_MS_4_PBLC_EDUCATION_REQS_ID] = [I15].[ICS_MS_4_PBLC_EDUCATION_REQS_ID] 
				
			 
				-- /[dbo].[ICS_SWMS_4_PRMT]/[dbo].[ICS_MS_4_PBLC_INVOLVEMENT_REQS] 
				 UNION ALL 
				SELECT KEY_HASH, I17.DATA_HASH 
				 from [dbo].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [dbo].[ICS_MS_4_PBLC_INVOLVEMENT_REQS] [I17]
 ON [I17].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
				
			 
				-- /[dbo].[ICS_SWMS_4_PRMT]/[dbo].[ICS_MS_4_PBLC_INVOLVEMENT_REQS]/[dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT] 
				 UNION ALL 
				SELECT KEY_HASH, I18.DATA_HASH 
				 from [dbo].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [dbo].[ICS_MS_4_PBLC_INVOLVEMENT_REQS] [I17]
 ON [I17].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN [dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT] [I18]
 ON [I18].[ICS_MS_4_PBLC_INVOLVEMENT_REQS_ID] = [I17].[ICS_MS_4_PBLC_INVOLVEMENT_REQS_ID] 
				
			 
				-- /[dbo].[ICS_SWMS_4_PRMT]/[dbo].[ICS_MS_4_POLLUTION_PREVENTION_REQS] 
				 UNION ALL 
				SELECT KEY_HASH, I19.DATA_HASH 
				 from [dbo].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [dbo].[ICS_MS_4_POLLUTION_PREVENTION_REQS] [I19]
 ON [I19].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
				
			 
				-- /[dbo].[ICS_SWMS_4_PRMT]/[dbo].[ICS_MS_4_POLLUTION_PREVENTION_REQS]/[dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT] 
				 UNION ALL 
				SELECT KEY_HASH, I20.DATA_HASH 
				 from [dbo].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [dbo].[ICS_MS_4_POLLUTION_PREVENTION_REQS] [I19]
 ON [I19].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN [dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT] [I20]
 ON [I20].[ICS_MS_4_POLLUTION_PREVENTION_REQS_ID] = [I19].[ICS_MS_4_POLLUTION_PREVENTION_REQS_ID] 
				
			 
				-- /[dbo].[ICS_SWMS_4_PRMT]/[dbo].[ICS_MS_4_POST_CNST_SW_REQS] 
				 UNION ALL 
				SELECT KEY_HASH, I21.DATA_HASH 
				 from [dbo].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [dbo].[ICS_MS_4_POST_CNST_SW_REQS] [I21]
 ON [I21].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
				
			 
				-- /[dbo].[ICS_SWMS_4_PRMT]/[dbo].[ICS_MS_4_POST_CNST_SW_REQS]/[dbo].[ICS_MS_4_POST_CNST_SW_PROCEDURES] 
				 UNION ALL 
				SELECT KEY_HASH, I22.DATA_HASH 
				 from [dbo].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [dbo].[ICS_MS_4_POST_CNST_SW_REQS] [I21]
 ON [I21].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN [dbo].[ICS_MS_4_POST_CNST_SW_PROCEDURES] [I22]
 ON [I22].[ICS_MS_4_POST_CNST_SW_REQS_ID] = [I21].[ICS_MS_4_POST_CNST_SW_REQS_ID] 
				
			 
				-- /[dbo].[ICS_SWMS_4_PRMT]/[dbo].[ICS_MS_4_POST_CNST_SW_REQS]/[dbo].[ICS_MS_4_POST_CNST_SW_PROCEDURES]/[dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT] 
				 UNION ALL 
				SELECT KEY_HASH, I23.DATA_HASH 
				 from [dbo].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [dbo].[ICS_MS_4_POST_CNST_SW_REQS] [I21]
 ON [I21].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN [dbo].[ICS_MS_4_POST_CNST_SW_PROCEDURES] [I22]
 ON [I22].[ICS_MS_4_POST_CNST_SW_REQS_ID] = [I21].[ICS_MS_4_POST_CNST_SW_REQS_ID] 
 JOIN [dbo].[ICS_MS_4_REGULATED_ENTITY_IDENT] [I23]
 ON [I23].[ICS_MS_4_POST_CNST_SW_PROCEDURES_ID] = [I22].[ICS_MS_4_POST_CNST_SW_PROCEDURES_ID] 
				
			 
				-- /[dbo].[ICS_SWMS_4_PRMT]/[dbo].[ICS_MS_4_POST_CNST_SW_REQS]/[dbo].[ICS_MS_4_POST_CNST_SW_REGULATED_ENTITY_INFO] 
				 UNION ALL 
				SELECT KEY_HASH, I24.DATA_HASH 
				 from [dbo].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [dbo].[ICS_MS_4_POST_CNST_SW_REQS] [I21]
 ON [I21].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN [dbo].[ICS_MS_4_POST_CNST_SW_REGULATED_ENTITY_INFO] [I24]
 ON [I24].[ICS_MS_4_POST_CNST_SW_REQS_ID] = [I21].[ICS_MS_4_POST_CNST_SW_REQS_ID] 
				
			 
				-- /[dbo].[ICS_SWMS_4_PRMT]/[dbo].[ICS_MS_4_REGULATED_ENTITY] 
				 UNION ALL 
				SELECT KEY_HASH, I25.DATA_HASH 
				 from [dbo].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [dbo].[ICS_MS_4_REGULATED_ENTITY] [I25]
 ON [I25].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
				
			 
				-- /[dbo].[ICS_SWMS_4_PRMT]/[dbo].[ICS_MS_4_REGULATED_ENTITY_AREA] 
				 UNION ALL 
				SELECT KEY_HASH, I26.DATA_HASH 
				 from [dbo].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [dbo].[ICS_MS_4_REGULATED_ENTITY_AREA] [I26]
 ON [I26].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
				
			 
				-- /[dbo].[ICS_SWMS_4_PRMT]/[dbo].[ICS_MS_4_REGULATED_ENTITY_AREA]/[dbo].[ICS_MS_4_REGULATED_ENTITY_AREA_COORD] 
				 UNION ALL 
				SELECT KEY_HASH, I27.DATA_HASH 
				 from [dbo].[ICS_SWMS_4_PRMT] [ICS_SWMS_4_PRMT] 
 JOIN [dbo].[ICS_MS_4_REGULATED_ENTITY_AREA] [I26]
 ON [I26].[ICS_SWMS_4_PRMT_ID] = [ICS_SWMS_4_PRMT].[ICS_SWMS_4_PRMT_ID] 
 JOIN [dbo].[ICS_MS_4_REGULATED_ENTITY_AREA_COORD] [I27]
 ON [I27].[ICS_MS_4_REGULATED_ENTITY_AREA_ID] = [I26].[ICS_MS_4_REGULATED_ENTITY_AREA_ID] 
							  
    ),
    rolled (key_hash, rolled_hash) AS (
      SELECT
        key_hash,
        dbo.HASHBYTES_VARCHAR('SHA1',
          STRING_AGG(cast(data_hash as varchar(max)), '') WITHIN GROUP (ORDER BY data_hash)
        ) AS rolled_hash
      FROM all_hashes
      GROUP BY key_hash
    )
    UPDATE p
       SET p.data_hash = r.rolled_hash
      FROM dbo.ICS_SWMS_4_PRMT p
      JOIN rolled r ON r.key_hash = p.key_hash;
  END;

  -- [47] ICS_UNPRMT_FAC
  IF EXISTS (SELECT 1 FROM dbo.ICS_PAYLOAD P
             JOIN dbo.ICS_UNPRMT_FAC C ON P.ICS_PAYLOAD_ID = C.ICS_PAYLOAD_ID
             WHERE P.ENABLED = 'Y')
  BEGIN
    ;WITH all_hashes (key_hash, data_hash) AS (

				
			 
				-- /[dbo].[ICS_UNPRMT_FAC] 
				
				SELECT KEY_HASH, ICS_UNPRMT_FAC.DATA_HASH 
				 from [dbo].[ICS_UNPRMT_FAC] [ICS_UNPRMT_FAC] 
				
			 
				-- /[dbo].[ICS_UNPRMT_FAC]/[dbo].[ICS_NAICS_CODE] 
				 UNION ALL 
				SELECT KEY_HASH, I1.DATA_HASH 
				 from [dbo].[ICS_UNPRMT_FAC] [ICS_UNPRMT_FAC] 
 JOIN [dbo].[ICS_NAICS_CODE] [I1]
 ON [I1].[ICS_UNPRMT_FAC_ID] = [ICS_UNPRMT_FAC].[ICS_UNPRMT_FAC_ID] 
				
			 
				-- /[dbo].[ICS_UNPRMT_FAC]/[dbo].[ICS_CONTACT] 
				 UNION ALL 
				SELECT KEY_HASH, I2.DATA_HASH 
				 from [dbo].[ICS_UNPRMT_FAC] [ICS_UNPRMT_FAC] 
 JOIN [dbo].[ICS_CONTACT] [I2]
 ON [I2].[ICS_UNPRMT_FAC_ID] = [ICS_UNPRMT_FAC].[ICS_UNPRMT_FAC_ID] 
				
			 
				-- /[dbo].[ICS_UNPRMT_FAC]/[dbo].[ICS_CONTACT]/[dbo].[ICS_TELEPH] 
				 UNION ALL 
				SELECT KEY_HASH, I3.DATA_HASH 
				 from [dbo].[ICS_UNPRMT_FAC] [ICS_UNPRMT_FAC] 
 JOIN [dbo].[ICS_CONTACT] [I2]
 ON [I2].[ICS_UNPRMT_FAC_ID] = [ICS_UNPRMT_FAC].[ICS_UNPRMT_FAC_ID] 
 JOIN [dbo].[ICS_TELEPH] [I3]
 ON [I3].[ICS_CONTACT_ID] = [I2].[ICS_CONTACT_ID] 
				
			 
				-- /[dbo].[ICS_UNPRMT_FAC]/[dbo].[ICS_ORIG_PROGS] 
				 UNION ALL 
				SELECT KEY_HASH, I4.DATA_HASH 
				 from [dbo].[ICS_UNPRMT_FAC] [ICS_UNPRMT_FAC] 
 JOIN [dbo].[ICS_ORIG_PROGS] [I4]
 ON [I4].[ICS_UNPRMT_FAC_ID] = [ICS_UNPRMT_FAC].[ICS_UNPRMT_FAC_ID] 
				
			 
				-- /[dbo].[ICS_UNPRMT_FAC]/[dbo].[ICS_PLCY] 
				 UNION ALL 
				SELECT KEY_HASH, I5.DATA_HASH 
				 from [dbo].[ICS_UNPRMT_FAC] [ICS_UNPRMT_FAC] 
 JOIN [dbo].[ICS_PLCY] [I5]
 ON [I5].[ICS_UNPRMT_FAC_ID] = [ICS_UNPRMT_FAC].[ICS_UNPRMT_FAC_ID] 
				
			 
				-- /[dbo].[ICS_UNPRMT_FAC]/[dbo].[ICS_PRMT_COMP_TYPE] 
				 UNION ALL 
				SELECT KEY_HASH, I6.DATA_HASH 
				 from [dbo].[ICS_UNPRMT_FAC] [ICS_UNPRMT_FAC] 
 JOIN [dbo].[ICS_PRMT_COMP_TYPE] [I6]
 ON [I6].[ICS_UNPRMT_FAC_ID] = [ICS_UNPRMT_FAC].[ICS_UNPRMT_FAC_ID] 
				
			 
				-- /[dbo].[ICS_UNPRMT_FAC]/[dbo].[ICS_FAC_CLASS] 
				 UNION ALL 
				SELECT KEY_HASH, I7.DATA_HASH 
				 from [dbo].[ICS_UNPRMT_FAC] [ICS_UNPRMT_FAC] 
 JOIN [dbo].[ICS_FAC_CLASS] [I7]
 ON [I7].[ICS_UNPRMT_FAC_ID] = [ICS_UNPRMT_FAC].[ICS_UNPRMT_FAC_ID] 
				
			 
				-- /[dbo].[ICS_UNPRMT_FAC]/[dbo].[ICS_GEO_COORD] 
				 UNION ALL 
				SELECT KEY_HASH, I8.DATA_HASH 
				 from [dbo].[ICS_UNPRMT_FAC] [ICS_UNPRMT_FAC] 
 JOIN [dbo].[ICS_GEO_COORD] [I8]
 ON [I8].[ICS_UNPRMT_FAC_ID] = [ICS_UNPRMT_FAC].[ICS_UNPRMT_FAC_ID] 
				
			 
				-- /[dbo].[ICS_UNPRMT_FAC]/[dbo].[ICS_SIC_CODE] 
				 UNION ALL 
				SELECT KEY_HASH, I9.DATA_HASH 
				 from [dbo].[ICS_UNPRMT_FAC] [ICS_UNPRMT_FAC] 
 JOIN [dbo].[ICS_SIC_CODE] [I9]
 ON [I9].[ICS_UNPRMT_FAC_ID] = [ICS_UNPRMT_FAC].[ICS_UNPRMT_FAC_ID] 
				
			 
				-- /[dbo].[ICS_UNPRMT_FAC]/[dbo].[ICS_ADDR] 
				 UNION ALL 
				SELECT KEY_HASH, I10.DATA_HASH 
				 from [dbo].[ICS_UNPRMT_FAC] [ICS_UNPRMT_FAC] 
 JOIN [dbo].[ICS_ADDR] [I10]
 ON [I10].[ICS_UNPRMT_FAC_ID] = [ICS_UNPRMT_FAC].[ICS_UNPRMT_FAC_ID] 
				
			 
				-- /[dbo].[ICS_UNPRMT_FAC]/[dbo].[ICS_ADDR]/[dbo].[ICS_TELEPH] 
				 UNION ALL 
				SELECT KEY_HASH, I11.DATA_HASH 
				 from [dbo].[ICS_UNPRMT_FAC] [ICS_UNPRMT_FAC] 
 JOIN [dbo].[ICS_ADDR] [I10]
 ON [I10].[ICS_UNPRMT_FAC_ID] = [ICS_UNPRMT_FAC].[ICS_UNPRMT_FAC_ID] 
 JOIN [dbo].[ICS_TELEPH] [I11]
 ON [I11].[ICS_ADDR_ID] = [I10].[ICS_ADDR_ID] 
							  
    ),
    rolled (key_hash, rolled_hash) AS (
      SELECT
        key_hash,
        dbo.HASHBYTES_VARCHAR('SHA1',
          STRING_AGG(cast(data_hash as varchar(max)), '') WITHIN GROUP (ORDER BY data_hash)
        ) AS rolled_hash
      FROM all_hashes
      GROUP BY key_hash
    )
    UPDATE p
       SET p.data_hash = r.rolled_hash
      FROM dbo.ICS_UNPRMT_FAC p
      JOIN rolled r ON r.key_hash = p.key_hash;
  END;
/* -=-=-=-=-=-=- END COPY TO INDICATED SECTION IN ICS_SET_HASHES -=-=-=-=-=-=-=-=-= */  

END