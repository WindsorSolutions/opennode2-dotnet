IF NOT EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND OBJECT_ID = OBJECT_ID('dbo.ICS_CHANGE_DETECTION'))
  EXEC('CREATE PROCEDURE [dbo].[ICS_CHANGE_DETECTION] AS BEGIN SET NOCOUNT ON; END')
GO

/*
Copyright (c) 2012, The Environmental Council of the States (ECOS)
All rights reserved.
 
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
 
 * Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
 * Neither the name of the ECOS nor the names of its contributors may
   be used to endorse or promote products derived from this software
   without specific prior written permission.
 
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/

/******************************************************************************************************************************
** ObjectName: ICS_CHANGE_DETECTION
**
** Author: Windsor Solutions, Inc.
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure will detect data changes made within the ICIS 5.8 schema and then sets the transaction type
**               flags so the data can be bundled and submitted to an exchange partner.
**
** Inputs:  -- NA --  
**
**
** Revision History:      
** ----------------------------------------------------------------------------------------------------------------------------
**  Date         Analyst     Description
** ----------------------------------------------------------------------------------------------------------------------------
** 06/12/2017  Windsor      Baselined from v5.6 procedure. 
** 06/30/2017  Chris Tyler  Made key_hash calculation consistent on links
** 07/10/2017  Chris Tyler  Added marker for copy to ICS_SET_DATA_HASH
** 07/18/2018  TK Conrad    Comment out the setting of termination change flag when cdv = 2 (terminations are a one-time event).
** 02/22/2019  Chris Tyler  Added restriction to insertion of Delete record to prevent permit and permit child objects from getting 
                            deleted when they are in the process of a termination or re-issuance flow.  That is: 
                            ICS_BASIC_PRMT, ICS_BS_PRMT, ICS_CAFO_PRMT, ICS_CSO_PRMT, ICS_GNRL_PRMT, ICS_MASTER_GNRL_PRMT, ICS_POTW_PRMT,
                            ICS_PRETR_PRMT, ICS_SW_CNST_PRMT, ICS_SW_INDST_PRMT, ICS_SWMS_4_LARGE_PRMT, ICS_SWMS_4_SMALL_PRMT, ICS_UNPRMT_FAC
                            Restrict for Re-issuance also for: ICS_NARR_COND_SCHD, ICS_PRMT_FEATR, ICS_LMT_SET, ICS_LMTS, ICS_PARAM_LMTS.
** 05/07/2019  TK Conrad    Add the key_hash to the where clause of each sub-select to improve perfof roll-up data hashing.
** 04/01/2025 Chris Tyler   Modifications for 5.14 
** 07/03/2025  WRensmith    Bypass auto-gen deletes if no rows are present in the local staging table (NCORE-6649)
** 07/03/2025  WRensmith    Clear out transaction codes for basic and general permits that are being reissued same day but with prior effective date 
** 04/15/2026 Chris Tyler   Fix dbo schema reference in cursor, change UNION ALL to UNION ALL
** 04/16/2026 Chris Tyler   Refactor: use string_agg instead of cursors, Seperate hashing to ICS_SET_HASHES, eliminate cdv view dependancy
** 05/14/2026 Chris Tyler   SingleEventViolation use X not D for delete
******************************************************************************************************************************/
ALTER PROCEDURE dbo.ICS_CHANGE_DETECTION 

AS

BEGIN 

SET NOCOUNT ON;

DECLARE @v_sql_statement AS NVARCHAR(4000);
DECLARE @v_sql_param AS NVARCHAR(100);
DECLARE @p_payload_type AS NVARCHAR(50); 

/* Working Hash Variables */
--DECLARE @v_data_hash AS VARCHAR(100);
DECLARE @v_key_hash AS VARCHAR(100);
DECLARE @v_enabled AS CHAR(1);
DECLARE @v_working_data_hash AS VARCHAR(100);
   
       

BEGIN

 /*  Initialize working table ICS_KEY_HASH */
 DELETE FROM dbo.ics_key_hash;
 
 /*  
  * Reset transaction_type on all payload tables  
  */
update  dbo.ICS_BASIC_PRMT SET TRANSACTION_TYPE = null;
update  dbo.ICS_BS_ANNUL_PROG_REP SET TRANSACTION_TYPE = null;
update  dbo.ICS_BS_PRMT SET TRANSACTION_TYPE = null;
update  dbo.ICS_CAFO_ANNUL_PROG_REP SET TRANSACTION_TYPE = null;
update  dbo.ICS_CAFO_PRMT SET TRANSACTION_TYPE = null;
update  dbo.ICS_COLL_SYSTM_PRMT SET TRANSACTION_TYPE = null;
update  dbo.ICS_CMPL_MON SET TRANSACTION_TYPE = null;
update  dbo.ICS_CMPL_MON_LNK SET TRANSACTION_TYPE = null;
update  dbo.ICS_CMPL_SCHD SET TRANSACTION_TYPE = null;
update  dbo.ICS_COPY_MGP_LMT_SET SET TRANSACTION_TYPE = null;
update  dbo.ICS_COPY_MGPMS_4_REQ SET TRANSACTION_TYPE = null;
update  dbo.ICS_CSO_LONG_TERM_CONTROL_PLAN SET TRANSACTION_TYPE = null;
update  dbo.ICS_CWA_316B_PROG_REP SET TRANSACTION_TYPE = null;
update  dbo.ICS_DSCH_MON_REP SET TRANSACTION_TYPE = null;
update  dbo.ICS_DMR_VIOL SET TRANSACTION_TYPE = null;
update  dbo.ICS_EFFLU_TRADE_PRTNER SET TRANSACTION_TYPE = null;
update  dbo.ICS_ENFRC_ACTN_MILESTONE SET TRANSACTION_TYPE = null;
update  dbo.ICS_ENFRC_ACTN_VIOL_LNK SET TRANSACTION_TYPE = null;
update  dbo.ICS_FINAL_ORDER_VIOL_LNK SET TRANSACTION_TYPE = null;
update  dbo.ICS_FRML_ENFRC_ACTN SET TRANSACTION_TYPE = null;
update  dbo.ICS_GNRL_PRMT SET TRANSACTION_TYPE = null;
update  dbo.ICS_HIST_PRMT_SCHD_EVTS SET TRANSACTION_TYPE = null;
update  dbo.ICS_INFRML_ENFRC_ACTN SET TRANSACTION_TYPE = null;
update  dbo.ICS_LMTS SET TRANSACTION_TYPE = null;
update  dbo.ICS_LMT_SET SET TRANSACTION_TYPE = null;
update  dbo.ICS_MASTER_GNRL_PRMT SET TRANSACTION_TYPE = null;
update  dbo.ICS_NARR_COND_SCHD SET TRANSACTION_TYPE = null;
update  dbo.ICS_NPDES_VARIANCE_PRMT SET TRANSACTION_TYPE = null;
update  dbo.ICS_PARAM_LMTS SET TRANSACTION_TYPE = null;
update  dbo.ICS_PRMT_REISSU SET TRANSACTION_TYPE = null;
update  dbo.ICS_PRMT_FEATR SET TRANSACTION_TYPE = null;
update  dbo.ICS_PRMT_TERM SET TRANSACTION_TYPE = null;
update  dbo.ICS_PRMT_TRACK_EVT SET TRANSACTION_TYPE = null;
update  dbo.ICS_POTW_PRMT SET TRANSACTION_TYPE = null;
update  dbo.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT SET TRANSACTION_TYPE = null;
update  dbo.ICS_PRETR_PRMT SET TRANSACTION_TYPE = null;
update  dbo.ICS_PRETR_PROG_REP SET TRANSACTION_TYPE = null;
update  dbo.ICS_SCHD_EVT_VIOL SET TRANSACTION_TYPE = null;
update  dbo.ICS_SEWER_OVRFLW_BYPASS_EVT_REP SET TRANSACTION_TYPE = null;
update  dbo.ICS_SNGL_EVT_VIOL SET TRANSACTION_TYPE = null;
update  dbo.ICS_SW_CNST_PRMT SET TRANSACTION_TYPE = null;
update  dbo.ICS_SW_INDST_ANNUL_REP SET TRANSACTION_TYPE = null;
update  dbo.ICS_SW_INDST_PRMT SET TRANSACTION_TYPE = null;
update  dbo.ICS_SWMS_4_ANNUL_PROG_REP SET TRANSACTION_TYPE = null;
update  dbo.ICS_SWMS_4_PRMT SET TRANSACTION_TYPE = null;
update  dbo.ICS_UNPRMT_FAC SET TRANSACTION_TYPE = null;
   
   
 -- Call procedure to set hashes (key_hash and data_hash) for all records where enabled in ICS_PAYLOAD  
 exec dbo.ICS_SET_HASHES;
 

   --PRINT 'Change Detection: Begin setting transaction_type at ' + CONVERT(VARCHAR(24),GETDATE(),113)

  /******************************************************************************************************************************
  ** Description:  The following code sets the new, change, replace, etc... ics transaction_type flags throughout the entire ICS 
  **               schema.  Once these flags are set the data will be marked as either new, changed and will allow the OPENNODE2 
  **               plug-in the ability to pull the data, bundle into .xml, and then submit to an exchange partner.
  ******************************************************************************************************************************/
  -- Generates SQL INSERT and UPDATE Statements to set TransactionCode values based on changes to staged data
-- Date Generated: Monday, July 09, 2012








-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_BASIC_PRMT
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.dbo.ICS_BASIC_PRMT 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'BasicPermitSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_BASIC_PRMT icis where icis.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.dbo.ICS_BASIC_PRMT 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'BasicPermitSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_BASIC_PRMT icis where icis.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH AND icis.DATA_HASH != ICS_BASIC_PRMT.DATA_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_BS_ANNUL_PROG_REP
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.dbo.ICS_BS_ANNUL_PROG_REP 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'BiosolidsAnnualProgramReportSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_BS_ANNUL_PROG_REP icis where icis.KEY_HASH = ICS_BS_ANNUL_PROG_REP.KEY_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.dbo.ICS_BS_ANNUL_PROG_REP 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'BiosolidsAnnualProgramReportSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_BS_ANNUL_PROG_REP icis where icis.KEY_HASH = ICS_BS_ANNUL_PROG_REP.KEY_HASH AND icis.DATA_HASH != ICS_BS_ANNUL_PROG_REP.DATA_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_BS_PRMT
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.dbo.ICS_BS_PRMT 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'BiosolidsPermitSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_BS_PRMT icis where icis.KEY_HASH = ICS_BS_PRMT.KEY_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.dbo.ICS_BS_PRMT 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'BiosolidsPermitSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_BS_PRMT icis where icis.KEY_HASH = ICS_BS_PRMT.KEY_HASH AND icis.DATA_HASH != ICS_BS_PRMT.DATA_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_CAFO_ANNUL_PROG_REP
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.dbo.ICS_CAFO_ANNUL_PROG_REP 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'CAFOAnnualProgramReportSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_CAFO_ANNUL_PROG_REP icis where icis.KEY_HASH = ICS_CAFO_ANNUL_PROG_REP.KEY_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.dbo.ICS_CAFO_ANNUL_PROG_REP 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'CAFOAnnualProgramReportSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_CAFO_ANNUL_PROG_REP icis where icis.KEY_HASH = ICS_CAFO_ANNUL_PROG_REP.KEY_HASH AND icis.DATA_HASH != ICS_CAFO_ANNUL_PROG_REP.DATA_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_CAFO_PRMT
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.dbo.ICS_CAFO_PRMT 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'CAFOPermitSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_CAFO_PRMT icis where icis.KEY_HASH = ICS_CAFO_PRMT.KEY_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.dbo.ICS_CAFO_PRMT 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'CAFOPermitSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_CAFO_PRMT icis where icis.KEY_HASH = ICS_CAFO_PRMT.KEY_HASH AND icis.DATA_HASH != ICS_CAFO_PRMT.DATA_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_COLL_SYSTM_PRMT
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.dbo.ICS_COLL_SYSTM_PRMT 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'CollectionSystemPermitSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_COLL_SYSTM_PRMT icis where icis.KEY_HASH = ICS_COLL_SYSTM_PRMT.KEY_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.dbo.ICS_COLL_SYSTM_PRMT 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'CollectionSystemPermitSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_COLL_SYSTM_PRMT icis where icis.KEY_HASH = ICS_COLL_SYSTM_PRMT.KEY_HASH AND icis.DATA_HASH != ICS_COLL_SYSTM_PRMT.DATA_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_CMPL_MON
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.dbo.ICS_CMPL_MON 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'ComplianceMonitoringSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_CMPL_MON icis where icis.KEY_HASH = ICS_CMPL_MON.KEY_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.dbo.ICS_CMPL_MON 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'ComplianceMonitoringSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_CMPL_MON icis where icis.KEY_HASH = ICS_CMPL_MON.KEY_HASH AND icis.DATA_HASH != ICS_CMPL_MON.DATA_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_CMPL_MON_LNK
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.dbo.ICS_CMPL_MON_LNK 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'ComplianceMonitoringLinkageSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_CMPL_MON_LNK icis where icis.KEY_HASH = ICS_CMPL_MON_LNK.KEY_HASH);

-- -- Change/Replace
-- update ICS_FLOW_LOCAL.dbo.ICS_CMPL_MON_LNK 
-- set TRANSACTION_TYPE = 'R' WHERE
-- 	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'ComplianceMonitoringLinkageSubmission')
-- 	AND exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_CMPL_MON_LNK icis where icis.KEY_HASH = ICS_CMPL_MON_LNK.KEY_HASH AND icis.DATA_HASH != ICS_CMPL_MON_LNK.DATA_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_CMPL_SCHD
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.dbo.ICS_CMPL_SCHD 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'ComplianceScheduleSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_CMPL_SCHD icis where icis.KEY_HASH = ICS_CMPL_SCHD.KEY_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.dbo.ICS_CMPL_SCHD 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'ComplianceScheduleSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_CMPL_SCHD icis where icis.KEY_HASH = ICS_CMPL_SCHD.KEY_HASH AND icis.DATA_HASH != ICS_CMPL_SCHD.DATA_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_COPY_MGP_LMT_SET
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.dbo.ICS_COPY_MGP_LMT_SET 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'CopyMGPLimitSetSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_COPY_MGP_LMT_SET icis where icis.KEY_HASH = ICS_COPY_MGP_LMT_SET.KEY_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.dbo.ICS_COPY_MGP_LMT_SET 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'CopyMGPLimitSetSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_COPY_MGP_LMT_SET icis where icis.KEY_HASH = ICS_COPY_MGP_LMT_SET.KEY_HASH AND icis.DATA_HASH != ICS_COPY_MGP_LMT_SET.DATA_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_COPY_MGPMS_4_REQ
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.dbo.ICS_COPY_MGPMS_4_REQ 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'CopyMGPMS4RequirementSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_COPY_MGPMS_4_REQ icis where icis.KEY_HASH = ICS_COPY_MGPMS_4_REQ.KEY_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.dbo.ICS_COPY_MGPMS_4_REQ 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'CopyMGPMS4RequirementSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_COPY_MGPMS_4_REQ icis where icis.KEY_HASH = ICS_COPY_MGPMS_4_REQ.KEY_HASH AND icis.DATA_HASH != ICS_COPY_MGPMS_4_REQ.DATA_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_CSO_LONG_TERM_CONTROL_PLAN
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.dbo.ICS_CSO_LONG_TERM_CONTROL_PLAN 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'CSOLongTermControlPlanSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_CSO_LONG_TERM_CONTROL_PLAN icis where icis.KEY_HASH = ICS_CSO_LONG_TERM_CONTROL_PLAN.KEY_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.dbo.ICS_CSO_LONG_TERM_CONTROL_PLAN 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'CSOLongTermControlPlanSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_CSO_LONG_TERM_CONTROL_PLAN icis where icis.KEY_HASH = ICS_CSO_LONG_TERM_CONTROL_PLAN.KEY_HASH AND icis.DATA_HASH != ICS_CSO_LONG_TERM_CONTROL_PLAN.DATA_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_CWA_316B_PROG_REP
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.dbo.ICS_CWA_316B_PROG_REP 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'CWA316bProgramReportSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_CWA_316B_PROG_REP icis where icis.KEY_HASH = ICS_CWA_316B_PROG_REP.KEY_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.dbo.ICS_CWA_316B_PROG_REP 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'CWA316bProgramReportSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_CWA_316B_PROG_REP icis where icis.KEY_HASH = ICS_CWA_316B_PROG_REP.KEY_HASH AND icis.DATA_HASH != ICS_CWA_316B_PROG_REP.DATA_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_DSCH_MON_REP
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.dbo.ICS_DSCH_MON_REP 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'DischargeMonitoringReportSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_DSCH_MON_REP icis where icis.KEY_HASH = ICS_DSCH_MON_REP.KEY_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.dbo.ICS_DSCH_MON_REP 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'DischargeMonitoringReportSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_DSCH_MON_REP icis where icis.KEY_HASH = ICS_DSCH_MON_REP.KEY_HASH AND icis.DATA_HASH != ICS_DSCH_MON_REP.DATA_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_DMR_VIOL
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.dbo.ICS_DMR_VIOL 
set TRANSACTION_TYPE = 'C' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'DMRViolationSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_DMR_VIOL icis where icis.KEY_HASH = ICS_DMR_VIOL.KEY_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.dbo.ICS_DMR_VIOL 
set TRANSACTION_TYPE = 'C' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'DMRViolationSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_DMR_VIOL icis where icis.KEY_HASH = ICS_DMR_VIOL.KEY_HASH AND icis.DATA_HASH != ICS_DMR_VIOL.DATA_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_EFFLU_TRADE_PRTNER
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.dbo.ICS_EFFLU_TRADE_PRTNER 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'EffluentTradePartnerSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_EFFLU_TRADE_PRTNER icis where icis.KEY_HASH = ICS_EFFLU_TRADE_PRTNER.KEY_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.dbo.ICS_EFFLU_TRADE_PRTNER 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'EffluentTradePartnerSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_EFFLU_TRADE_PRTNER icis where icis.KEY_HASH = ICS_EFFLU_TRADE_PRTNER.KEY_HASH AND icis.DATA_HASH != ICS_EFFLU_TRADE_PRTNER.DATA_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_ENFRC_ACTN_MILESTONE
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.dbo.ICS_ENFRC_ACTN_MILESTONE 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'EnforcementActionMilestoneSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_ENFRC_ACTN_MILESTONE icis where icis.KEY_HASH = ICS_ENFRC_ACTN_MILESTONE.KEY_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.dbo.ICS_ENFRC_ACTN_MILESTONE 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'EnforcementActionMilestoneSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_ENFRC_ACTN_MILESTONE icis where icis.KEY_HASH = ICS_ENFRC_ACTN_MILESTONE.KEY_HASH AND icis.DATA_HASH != ICS_ENFRC_ACTN_MILESTONE.DATA_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_ENFRC_ACTN_VIOL_LNK
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.dbo.ICS_ENFRC_ACTN_VIOL_LNK 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'EnforcementActionViolationLinkageSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_ENFRC_ACTN_VIOL_LNK icis where icis.KEY_HASH = ICS_ENFRC_ACTN_VIOL_LNK.KEY_HASH);

---- Change/Replace
--update ICS_FLOW_LOCAL.dbo.ICS_ENFRC_ACTN_VIOL_LNK 
--set TRANSACTION_TYPE = 'R' WHERE
--	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'EnforcementActionViolationLinkageSubmission')
--	AND exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_ENFRC_ACTN_VIOL_LNK icis where icis.KEY_HASH = ICS_ENFRC_ACTN_VIOL_LNK.KEY_HASH AND icis.DATA_HASH != ICS_ENFRC_ACTN_VIOL_LNK.DATA_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_FINAL_ORDER_VIOL_LNK
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.dbo.ICS_FINAL_ORDER_VIOL_LNK 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'FinalOrderViolationLinkageSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_FINAL_ORDER_VIOL_LNK icis where icis.KEY_HASH = ICS_FINAL_ORDER_VIOL_LNK.KEY_HASH);

-- -- Change/Replace
-- update ICS_FLOW_LOCAL.dbo.ICS_FINAL_ORDER_VIOL_LNK 
-- set TRANSACTION_TYPE = 'R' WHERE
-- 	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'FinalOrderViolationLinkageSubmission')
-- 	AND exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_FINAL_ORDER_VIOL_LNK icis where icis.KEY_HASH = ICS_FINAL_ORDER_VIOL_LNK.KEY_HASH AND icis.DATA_HASH != ICS_FINAL_ORDER_VIOL_LNK.DATA_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_FRML_ENFRC_ACTN
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.dbo.ICS_FRML_ENFRC_ACTN 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'FormalEnforcementActionSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_FRML_ENFRC_ACTN icis where icis.KEY_HASH = ICS_FRML_ENFRC_ACTN.KEY_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.dbo.ICS_FRML_ENFRC_ACTN 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'FormalEnforcementActionSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_FRML_ENFRC_ACTN icis where icis.KEY_HASH = ICS_FRML_ENFRC_ACTN.KEY_HASH AND icis.DATA_HASH != ICS_FRML_ENFRC_ACTN.DATA_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_GNRL_PRMT
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.dbo.ICS_GNRL_PRMT 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'GeneralPermitSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_GNRL_PRMT icis where icis.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.dbo.ICS_GNRL_PRMT 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'GeneralPermitSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_GNRL_PRMT icis where icis.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH AND icis.DATA_HASH != ICS_GNRL_PRMT.DATA_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_HIST_PRMT_SCHD_EVTS
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.dbo.ICS_HIST_PRMT_SCHD_EVTS 
set TRANSACTION_TYPE = 'C' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'HistoricalPermitScheduleEventsSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_HIST_PRMT_SCHD_EVTS icis where icis.KEY_HASH = ICS_HIST_PRMT_SCHD_EVTS.KEY_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.dbo.ICS_HIST_PRMT_SCHD_EVTS 
set TRANSACTION_TYPE = 'C' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'HistoricalPermitScheduleEventsSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_HIST_PRMT_SCHD_EVTS icis where icis.KEY_HASH = ICS_HIST_PRMT_SCHD_EVTS.KEY_HASH AND icis.DATA_HASH != ICS_HIST_PRMT_SCHD_EVTS.DATA_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_INFRML_ENFRC_ACTN
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.dbo.ICS_INFRML_ENFRC_ACTN 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'InformalEnforcementActionSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_INFRML_ENFRC_ACTN icis where icis.KEY_HASH = ICS_INFRML_ENFRC_ACTN.KEY_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.dbo.ICS_INFRML_ENFRC_ACTN 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'InformalEnforcementActionSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_INFRML_ENFRC_ACTN icis where icis.KEY_HASH = ICS_INFRML_ENFRC_ACTN.KEY_HASH AND icis.DATA_HASH != ICS_INFRML_ENFRC_ACTN.DATA_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_LMTS
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.dbo.ICS_LMTS 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'LimitsSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_LMTS icis where icis.KEY_HASH = ICS_LMTS.KEY_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.dbo.ICS_LMTS 
set TRANSACTION_TYPE = 'C' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'LimitsSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_LMTS icis where icis.KEY_HASH = ICS_LMTS.KEY_HASH AND icis.DATA_HASH != ICS_LMTS.DATA_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_LMT_SET
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.dbo.ICS_LMT_SET 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'LimitSetSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_LMT_SET icis where icis.KEY_HASH = ICS_LMT_SET.KEY_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.dbo.ICS_LMT_SET 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'LimitSetSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_LMT_SET icis where icis.KEY_HASH = ICS_LMT_SET.KEY_HASH AND icis.DATA_HASH != ICS_LMT_SET.DATA_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_MASTER_GNRL_PRMT
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.dbo.ICS_MASTER_GNRL_PRMT 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'MasterGeneralPermitSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_MASTER_GNRL_PRMT icis where icis.KEY_HASH = ICS_MASTER_GNRL_PRMT.KEY_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.dbo.ICS_MASTER_GNRL_PRMT 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'MasterGeneralPermitSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_MASTER_GNRL_PRMT icis where icis.KEY_HASH = ICS_MASTER_GNRL_PRMT.KEY_HASH AND icis.DATA_HASH != ICS_MASTER_GNRL_PRMT.DATA_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_NARR_COND_SCHD
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.dbo.ICS_NARR_COND_SCHD 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'NarrativeConditionScheduleSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_NARR_COND_SCHD icis where icis.KEY_HASH = ICS_NARR_COND_SCHD.KEY_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.dbo.ICS_NARR_COND_SCHD 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'NarrativeConditionScheduleSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_NARR_COND_SCHD icis where icis.KEY_HASH = ICS_NARR_COND_SCHD.KEY_HASH AND icis.DATA_HASH != ICS_NARR_COND_SCHD.DATA_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_NPDES_VARIANCE_PRMT
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.dbo.ICS_NPDES_VARIANCE_PRMT 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'NPDESVariancePermitSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_NPDES_VARIANCE_PRMT icis where icis.KEY_HASH = ICS_NPDES_VARIANCE_PRMT.KEY_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.dbo.ICS_NPDES_VARIANCE_PRMT 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'NPDESVariancePermitSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_NPDES_VARIANCE_PRMT icis where icis.KEY_HASH = ICS_NPDES_VARIANCE_PRMT.KEY_HASH AND icis.DATA_HASH != ICS_NPDES_VARIANCE_PRMT.DATA_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_PARAM_LMTS
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.dbo.ICS_PARAM_LMTS 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'ParameterLimitsSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_PARAM_LMTS icis where icis.KEY_HASH = ICS_PARAM_LMTS.KEY_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.dbo.ICS_PARAM_LMTS 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'ParameterLimitsSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_PARAM_LMTS icis where icis.KEY_HASH = ICS_PARAM_LMTS.KEY_HASH AND icis.DATA_HASH != ICS_PARAM_LMTS.DATA_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_PRMT_REISSU
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.dbo.ICS_PRMT_REISSU 
set TRANSACTION_TYPE = 'C' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'PermitReissuanceSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_PRMT_REISSU icis where icis.KEY_HASH = ICS_PRMT_REISSU.KEY_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.dbo.ICS_PRMT_REISSU 
set TRANSACTION_TYPE = 'C' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'PermitReissuanceSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_PRMT_REISSU icis where icis.KEY_HASH = ICS_PRMT_REISSU.KEY_HASH AND icis.DATA_HASH != ICS_PRMT_REISSU.DATA_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_PRMT_FEATR
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.dbo.ICS_PRMT_FEATR 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'PermittedFeatureSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_PRMT_FEATR icis where icis.KEY_HASH = ICS_PRMT_FEATR.KEY_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.dbo.ICS_PRMT_FEATR 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'PermittedFeatureSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_PRMT_FEATR icis where icis.KEY_HASH = ICS_PRMT_FEATR.KEY_HASH AND icis.DATA_HASH != ICS_PRMT_FEATR.DATA_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_PRMT_TERM
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.dbo.ICS_PRMT_TERM 
set TRANSACTION_TYPE = 'C' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'PermitTerminationSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_PRMT_TERM icis where icis.KEY_HASH = ICS_PRMT_TERM.KEY_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.dbo.ICS_PRMT_TERM 
set TRANSACTION_TYPE = 'C' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'PermitTerminationSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_PRMT_TERM icis where icis.KEY_HASH = ICS_PRMT_TERM.KEY_HASH AND icis.DATA_HASH != ICS_PRMT_TERM.DATA_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_PRMT_TRACK_EVT
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.dbo.ICS_PRMT_TRACK_EVT 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'PermitTrackingEventSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_PRMT_TRACK_EVT icis where icis.KEY_HASH = ICS_PRMT_TRACK_EVT.KEY_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.dbo.ICS_PRMT_TRACK_EVT 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'PermitTrackingEventSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_PRMT_TRACK_EVT icis where icis.KEY_HASH = ICS_PRMT_TRACK_EVT.KEY_HASH AND icis.DATA_HASH != ICS_PRMT_TRACK_EVT.DATA_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_POTW_PRMT
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.dbo.ICS_POTW_PRMT 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'POTWPermitSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_POTW_PRMT icis where icis.KEY_HASH = ICS_POTW_PRMT.KEY_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.dbo.ICS_POTW_PRMT 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'POTWPermitSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_POTW_PRMT icis where icis.KEY_HASH = ICS_POTW_PRMT.KEY_HASH AND icis.DATA_HASH != ICS_POTW_PRMT.DATA_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_POTW_TRTMNT_TECHNOLOGY_PRMT
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.dbo.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'POTWTreatmentTechnologyPermitSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT icis where icis.KEY_HASH = ICS_POTW_TRTMNT_TECHNOLOGY_PRMT.KEY_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.dbo.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'POTWTreatmentTechnologyPermitSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT icis where icis.KEY_HASH = ICS_POTW_TRTMNT_TECHNOLOGY_PRMT.KEY_HASH AND icis.DATA_HASH != ICS_POTW_TRTMNT_TECHNOLOGY_PRMT.DATA_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_PRETR_PRMT
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.dbo.ICS_PRETR_PRMT 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'PretreatmentPermitSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_PRETR_PRMT icis where icis.KEY_HASH = ICS_PRETR_PRMT.KEY_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.dbo.ICS_PRETR_PRMT 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'PretreatmentPermitSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_PRETR_PRMT icis where icis.KEY_HASH = ICS_PRETR_PRMT.KEY_HASH AND icis.DATA_HASH != ICS_PRETR_PRMT.DATA_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_PRETR_PROG_REP
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.dbo.ICS_PRETR_PROG_REP 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'PretreatmentProgramReportSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_PRETR_PROG_REP icis where icis.KEY_HASH = ICS_PRETR_PROG_REP.KEY_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.dbo.ICS_PRETR_PROG_REP 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'PretreatmentProgramReportSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_PRETR_PROG_REP icis where icis.KEY_HASH = ICS_PRETR_PROG_REP.KEY_HASH AND icis.DATA_HASH != ICS_PRETR_PROG_REP.DATA_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_SCHD_EVT_VIOL
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.dbo.ICS_SCHD_EVT_VIOL 
set TRANSACTION_TYPE = 'C' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'ScheduleEventViolationSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_SCHD_EVT_VIOL icis where icis.KEY_HASH = ICS_SCHD_EVT_VIOL.KEY_HASH);

-- -- Change/Replace
-- update ICS_FLOW_LOCAL.dbo.ICS_SCHD_EVT_VIOL 
-- set TRANSACTION_TYPE = 'C' WHERE
-- 	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'ScheduleEventViolationSubmission')
-- 	AND exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_SCHD_EVT_VIOL icis where icis.KEY_HASH = ICS_SCHD_EVT_VIOL.KEY_HASH AND icis.DATA_HASH != ICS_SCHD_EVT_VIOL.DATA_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_SEWER_OVRFLW_BYPASS_EVT_REP
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.dbo.ICS_SEWER_OVRFLW_BYPASS_EVT_REP 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'SewerOverflowBypassEventReportSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_SEWER_OVRFLW_BYPASS_EVT_REP icis where icis.KEY_HASH = ICS_SEWER_OVRFLW_BYPASS_EVT_REP.KEY_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.dbo.ICS_SEWER_OVRFLW_BYPASS_EVT_REP 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'SewerOverflowBypassEventReportSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_SEWER_OVRFLW_BYPASS_EVT_REP icis where icis.KEY_HASH = ICS_SEWER_OVRFLW_BYPASS_EVT_REP.KEY_HASH AND icis.DATA_HASH != ICS_SEWER_OVRFLW_BYPASS_EVT_REP.DATA_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_SNGL_EVT_VIOL
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.dbo.ICS_SNGL_EVT_VIOL 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'SingleEventViolationSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_SNGL_EVT_VIOL icis where icis.KEY_HASH = ICS_SNGL_EVT_VIOL.KEY_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.dbo.ICS_SNGL_EVT_VIOL 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'SingleEventViolationSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_SNGL_EVT_VIOL icis where icis.KEY_HASH = ICS_SNGL_EVT_VIOL.KEY_HASH AND icis.DATA_HASH != ICS_SNGL_EVT_VIOL.DATA_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_SW_CNST_PRMT
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.dbo.ICS_SW_CNST_PRMT 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'SWConstructionPermitSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_SW_CNST_PRMT icis where icis.KEY_HASH = ICS_SW_CNST_PRMT.KEY_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.dbo.ICS_SW_CNST_PRMT 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'SWConstructionPermitSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_SW_CNST_PRMT icis where icis.KEY_HASH = ICS_SW_CNST_PRMT.KEY_HASH AND icis.DATA_HASH != ICS_SW_CNST_PRMT.DATA_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_SW_INDST_ANNUL_REP
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.dbo.ICS_SW_INDST_ANNUL_REP 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'SWIndustrialAnnualReportSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_SW_INDST_ANNUL_REP icis where icis.KEY_HASH = ICS_SW_INDST_ANNUL_REP.KEY_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.dbo.ICS_SW_INDST_ANNUL_REP 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'SWIndustrialAnnualReportSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_SW_INDST_ANNUL_REP icis where icis.KEY_HASH = ICS_SW_INDST_ANNUL_REP.KEY_HASH AND icis.DATA_HASH != ICS_SW_INDST_ANNUL_REP.DATA_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_SW_INDST_PRMT
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.dbo.ICS_SW_INDST_PRMT 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'SWIndustrialPermitSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_SW_INDST_PRMT icis where icis.KEY_HASH = ICS_SW_INDST_PRMT.KEY_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.dbo.ICS_SW_INDST_PRMT 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'SWIndustrialPermitSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_SW_INDST_PRMT icis where icis.KEY_HASH = ICS_SW_INDST_PRMT.KEY_HASH AND icis.DATA_HASH != ICS_SW_INDST_PRMT.DATA_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_SWMS_4_ANNUL_PROG_REP
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.dbo.ICS_SWMS_4_ANNUL_PROG_REP 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'SWMS4AnnualProgramReportSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_SWMS_4_ANNUL_PROG_REP icis where icis.KEY_HASH = ICS_SWMS_4_ANNUL_PROG_REP.KEY_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.dbo.ICS_SWMS_4_ANNUL_PROG_REP 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'SWMS4AnnualProgramReportSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_SWMS_4_ANNUL_PROG_REP icis where icis.KEY_HASH = ICS_SWMS_4_ANNUL_PROG_REP.KEY_HASH AND icis.DATA_HASH != ICS_SWMS_4_ANNUL_PROG_REP.DATA_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_SWMS_4_PRMT
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.dbo.ICS_SWMS_4_PRMT 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'SWMS4PermitSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_SWMS_4_PRMT icis where icis.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.dbo.ICS_SWMS_4_PRMT 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'SWMS4PermitSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_SWMS_4_PRMT icis where icis.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH AND icis.DATA_HASH != ICS_SWMS_4_PRMT.DATA_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_UNPRMT_FAC
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.dbo.ICS_UNPRMT_FAC 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'UnpermittedFacilitySubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_UNPRMT_FAC icis where icis.KEY_HASH = ICS_UNPRMT_FAC.KEY_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.dbo.ICS_UNPRMT_FAC 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'UnpermittedFacilitySubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.dbo.ICS_UNPRMT_FAC icis where icis.KEY_HASH = ICS_UNPRMT_FAC.KEY_HASH AND icis.DATA_HASH != ICS_UNPRMT_FAC.DATA_HASH);

	

-- ----------------------------------------------------------------------------
-- Set Delete transactions when enabled
-- ----------------------------------------------------------------------------

-- ICS_BASIC_PRMT
-- ----------------------------------------------------------------------------


 INSERT INTO ICS_FLOW_LOCAL.dbo.ICS_BASIC_PRMT
       ( ICS_BASIC_PRMT_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT
       , key_hash
       , data_hash) 
   SELECT 
		newid()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT
        , key_hash
        , data_hash
     FROM ICS_FLOW_ICIS.dbo.ICS_BASIC_PRMT icis
WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'BasicPermitSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.dbo.ICS_BASIC_PRMT loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.dbo.ICS_BASIC_PRMT) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_BS_ANNUL_PROG_REP
-- ----------------------------------------------------------------------------


 INSERT INTO ICS_FLOW_LOCAL.dbo.ICS_BS_ANNUL_PROG_REP
       ( ICS_BS_ANNUL_PROG_REP_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT,PROG_REP_FORM_SET_ID,PROG_REP_FORM_ID
       , key_hash
       , data_hash) 
   SELECT 
		newid()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT,PROG_REP_FORM_SET_ID,PROG_REP_FORM_ID
        , key_hash
        , data_hash
     FROM ICS_FLOW_ICIS.dbo.ICS_BS_ANNUL_PROG_REP icis
WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'BiosolidsAnnualProgramReportSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.dbo.ICS_BS_ANNUL_PROG_REP loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.dbo.ICS_BS_ANNUL_PROG_REP) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_BS_PRMT
-- ----------------------------------------------------------------------------


 INSERT INTO ICS_FLOW_LOCAL.dbo.ICS_BS_PRMT
       ( ICS_BS_PRMT_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT
       , key_hash
       , data_hash) 
   SELECT 
		newid()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT
        , key_hash
        , data_hash
     FROM ICS_FLOW_ICIS.dbo.ICS_BS_PRMT icis
WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'BiosolidsPermitSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.dbo.ICS_BS_PRMT loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.dbo.ICS_BS_PRMT) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_CAFO_ANNUL_PROG_REP
-- ----------------------------------------------------------------------------


 INSERT INTO ICS_FLOW_LOCAL.dbo.ICS_CAFO_ANNUL_PROG_REP
       ( ICS_CAFO_ANNUL_PROG_REP_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT,PROG_REP_FORM_SET_ID,PROG_REP_FORM_ID
       , key_hash
       , data_hash) 
   SELECT 
		newid()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT,PROG_REP_FORM_SET_ID,PROG_REP_FORM_ID
        , key_hash
        , data_hash
     FROM ICS_FLOW_ICIS.dbo.ICS_CAFO_ANNUL_PROG_REP icis
WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'CAFOAnnualProgramReportSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.dbo.ICS_CAFO_ANNUL_PROG_REP loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.dbo.ICS_CAFO_ANNUL_PROG_REP) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_CAFO_PRMT
-- ----------------------------------------------------------------------------


 INSERT INTO ICS_FLOW_LOCAL.dbo.ICS_CAFO_PRMT
       ( ICS_CAFO_PRMT_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT
       , key_hash
       , data_hash) 
   SELECT 
		newid()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT
        , key_hash
        , data_hash
     FROM ICS_FLOW_ICIS.dbo.ICS_CAFO_PRMT icis
WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'CAFOPermitSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.dbo.ICS_CAFO_PRMT loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.dbo.ICS_CAFO_PRMT) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_COLL_SYSTM_PRMT
-- ----------------------------------------------------------------------------


 INSERT INTO ICS_FLOW_LOCAL.dbo.ICS_COLL_SYSTM_PRMT
       ( ICS_COLL_SYSTM_PRMT_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT,COLL_SYSTM_IDENT
       , key_hash
       , data_hash) 
   SELECT 
		newid()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT,COLL_SYSTM_IDENT
        , key_hash
        , data_hash
     FROM ICS_FLOW_ICIS.dbo.ICS_COLL_SYSTM_PRMT icis
WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'CollectionSystemPermitSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.dbo.ICS_COLL_SYSTM_PRMT loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.dbo.ICS_COLL_SYSTM_PRMT) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_CMPL_MON
-- ----------------------------------------------------------------------------


 INSERT INTO ICS_FLOW_LOCAL.dbo.ICS_CMPL_MON
       ( ICS_CMPL_MON_ID
	   ,ics_payload_id
       , transaction_type
       , CMPL_MON_IDENT
       , key_hash
       , data_hash) 
   SELECT 
		newid()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , CMPL_MON_IDENT
        , key_hash
        , data_hash
     FROM ICS_FLOW_ICIS.dbo.ICS_CMPL_MON icis
WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'ComplianceMonitoringSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.dbo.ICS_CMPL_MON loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.dbo.ICS_CMPL_MON) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_CMPL_SCHD
-- ----------------------------------------------------------------------------


 INSERT INTO ICS_FLOW_LOCAL.dbo.ICS_CMPL_SCHD
       ( ICS_CMPL_SCHD_ID
	   ,ics_payload_id
       , transaction_type
       , ENFRC_ACTN_IDENT, FINAL_ORDER_IDENT, PRMT_IDENT, CMPL_SCHD_NUM
       , key_hash
       , data_hash) 
   SELECT 
		newid()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , ENFRC_ACTN_IDENT, FINAL_ORDER_IDENT, PRMT_IDENT, CMPL_SCHD_NUM
        , key_hash
        , data_hash
     FROM ICS_FLOW_ICIS.dbo.ICS_CMPL_SCHD icis
WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'ComplianceScheduleSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.dbo.ICS_CMPL_SCHD loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.dbo.ICS_CMPL_SCHD) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_COPY_MGP_LMT_SET
-- ----------------------------------------------------------------------------


 INSERT INTO ICS_FLOW_LOCAL.dbo.ICS_COPY_MGP_LMT_SET
       ( ICS_COPY_MGP_LMT_SET_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT,PRMT_FEATR_IDENT,LMT_SET_DESIGNATOR
       , key_hash
       , data_hash) 
   SELECT 
		newid()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT,PRMT_FEATR_IDENT,LMT_SET_DESIGNATOR
        , key_hash
        , data_hash
     FROM ICS_FLOW_ICIS.dbo.ICS_COPY_MGP_LMT_SET icis
WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'CopyMGPLimitSetSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.dbo.ICS_COPY_MGP_LMT_SET loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.dbo.ICS_COPY_MGP_LMT_SET) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_COPY_MGPMS_4_REQ
-- ----------------------------------------------------------------------------


 INSERT INTO ICS_FLOW_LOCAL.dbo.ICS_COPY_MGPMS_4_REQ
       ( ICS_COPY_MGPMS_4_REQ_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT
       , key_hash
       , data_hash) 
   SELECT 
		newid()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT
        , key_hash
        , data_hash
     FROM ICS_FLOW_ICIS.dbo.ICS_COPY_MGPMS_4_REQ icis
WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'CopyMGPMS4RequirementSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.dbo.ICS_COPY_MGPMS_4_REQ loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.dbo.ICS_COPY_MGPMS_4_REQ) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_CSO_LONG_TERM_CONTROL_PLAN
-- ----------------------------------------------------------------------------


 INSERT INTO ICS_FLOW_LOCAL.dbo.ICS_CSO_LONG_TERM_CONTROL_PLAN
       ( ICS_CSO_LONG_TERM_CONTROL_PLAN_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT
       , key_hash
       , data_hash) 
   SELECT 
		newid()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT
        , key_hash
        , data_hash
     FROM ICS_FLOW_ICIS.dbo.ICS_CSO_LONG_TERM_CONTROL_PLAN icis
WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'CSOLongTermControlPlanSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.dbo.ICS_CSO_LONG_TERM_CONTROL_PLAN loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.dbo.ICS_CSO_LONG_TERM_CONTROL_PLAN) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_CWA_316B_PROG_REP
-- ----------------------------------------------------------------------------


 INSERT INTO ICS_FLOW_LOCAL.dbo.ICS_CWA_316B_PROG_REP
       ( ICS_CWA_316B_PROG_REP_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT,PROG_REP_FORM_SET_ID,PROG_REP_FORM_ID
       , key_hash
       , data_hash) 
   SELECT 
		newid()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT,PROG_REP_FORM_SET_ID,PROG_REP_FORM_ID
        , key_hash
        , data_hash
     FROM ICS_FLOW_ICIS.dbo.ICS_CWA_316B_PROG_REP icis
WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'CWA316bProgramReportSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.dbo.ICS_CWA_316B_PROG_REP loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.dbo.ICS_CWA_316B_PROG_REP) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_DSCH_MON_REP
-- ----------------------------------------------------------------------------


 INSERT INTO ICS_FLOW_LOCAL.dbo.ICS_DSCH_MON_REP
       ( ICS_DSCH_MON_REP_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT, PRMT_FEATR_IDENT, LMT_SET_DESIGNATOR, MON_PERIOD_END_DATE
       , key_hash
       , data_hash) 
   SELECT 
		newid()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT, PRMT_FEATR_IDENT, LMT_SET_DESIGNATOR, MON_PERIOD_END_DATE
        , key_hash
        , data_hash
     FROM ICS_FLOW_ICIS.dbo.ICS_DSCH_MON_REP icis
WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'DischargeMonitoringReportSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.dbo.ICS_DSCH_MON_REP loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.dbo.ICS_DSCH_MON_REP) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_DMR_VIOL
-- ----------------------------------------------------------------------------

-- Deletes not supported for ICS_DMR_VIOL

-- ICS_EFFLU_TRADE_PRTNER
-- ----------------------------------------------------------------------------


 INSERT INTO ICS_FLOW_LOCAL.dbo.ICS_EFFLU_TRADE_PRTNER
       ( ICS_EFFLU_TRADE_PRTNER_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT, PRMT_FEATR_IDENT, LMT_SET_DESIGNATOR, PARAM_CODE, MON_SITE_DESC_CODE, LMT_SEASON_NUM, LMT_START_DATE, LMT_END_DATE, LMT_MOD_EFFECTIVE_DATE, TRADE_ID
       , key_hash
       , data_hash) 
   SELECT 
		newid()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT, PRMT_FEATR_IDENT, LMT_SET_DESIGNATOR, PARAM_CODE, MON_SITE_DESC_CODE, LMT_SEASON_NUM, LMT_START_DATE, LMT_END_DATE, LMT_MOD_EFFECTIVE_DATE, TRADE_ID
        , key_hash
        , data_hash
     FROM ICS_FLOW_ICIS.dbo.ICS_EFFLU_TRADE_PRTNER icis
WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'EffluentTradePartnerSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.dbo.ICS_EFFLU_TRADE_PRTNER loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.dbo.ICS_EFFLU_TRADE_PRTNER) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_ENFRC_ACTN_MILESTONE
-- ----------------------------------------------------------------------------

-- Deletes not supported for ICS_ENFRC_ACTN_MILESTONE

-- ICS_FRML_ENFRC_ACTN
-- ----------------------------------------------------------------------------


 INSERT INTO ICS_FLOW_LOCAL.dbo.ICS_FRML_ENFRC_ACTN
       ( ICS_FRML_ENFRC_ACTN_ID
	   ,ics_payload_id
       , transaction_type
       , ENFRC_ACTN_IDENT
       , key_hash
       , data_hash) 
   SELECT 
		newid()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , ENFRC_ACTN_IDENT
        , key_hash
        , data_hash
     FROM ICS_FLOW_ICIS.dbo.ICS_FRML_ENFRC_ACTN icis
WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'FormalEnforcementActionSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.dbo.ICS_FRML_ENFRC_ACTN loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.dbo.ICS_FRML_ENFRC_ACTN) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_GNRL_PRMT
-- ----------------------------------------------------------------------------


 INSERT INTO ICS_FLOW_LOCAL.dbo.ICS_GNRL_PRMT
       ( ICS_GNRL_PRMT_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT
       , key_hash
       , data_hash) 
   SELECT 
		newid()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT
        , key_hash
        , data_hash
     FROM ICS_FLOW_ICIS.dbo.ICS_GNRL_PRMT icis
WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'GeneralPermitSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.dbo.ICS_GNRL_PRMT loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.dbo.ICS_GNRL_PRMT) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_HIST_PRMT_SCHD_EVTS
-- ----------------------------------------------------------------------------

-- Deletes not supported for ICS_HIST_PRMT_SCHD_EVTS

-- ICS_INFRML_ENFRC_ACTN
-- ----------------------------------------------------------------------------


 INSERT INTO ICS_FLOW_LOCAL.dbo.ICS_INFRML_ENFRC_ACTN
       ( ICS_INFRML_ENFRC_ACTN_ID
	   ,ics_payload_id
       , transaction_type
       , ENFRC_ACTN_IDENT
       , key_hash
       , data_hash) 
   SELECT 
		newid()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , ENFRC_ACTN_IDENT
        , key_hash
        , data_hash
     FROM ICS_FLOW_ICIS.dbo.ICS_INFRML_ENFRC_ACTN icis
WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'InformalEnforcementActionSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.dbo.ICS_INFRML_ENFRC_ACTN loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.dbo.ICS_INFRML_ENFRC_ACTN) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_LMTS
-- ----------------------------------------------------------------------------


 INSERT INTO ICS_FLOW_LOCAL.dbo.ICS_LMTS
       ( ICS_LMTS_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT, PRMT_FEATR_IDENT, LMT_SET_DESIGNATOR, PARAM_CODE, MON_SITE_DESC_CODE, LMT_SEASON_NUM, LMT_START_DATE, LMT_END_DATE
       , key_hash
       , data_hash) 
   SELECT 
		newid()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT, PRMT_FEATR_IDENT, LMT_SET_DESIGNATOR, PARAM_CODE, MON_SITE_DESC_CODE, LMT_SEASON_NUM, LMT_START_DATE, LMT_END_DATE
        , key_hash
        , data_hash
     FROM ICS_FLOW_ICIS.dbo.ICS_LMTS icis
WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'LimitsSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.dbo.ICS_LMTS loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.dbo.ICS_LMTS) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_LMT_SET
-- ----------------------------------------------------------------------------


 INSERT INTO ICS_FLOW_LOCAL.dbo.ICS_LMT_SET
       ( ICS_LMT_SET_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT, PRMT_FEATR_IDENT, LMT_SET_DESIGNATOR
       , key_hash
       , data_hash) 
   SELECT 
		newid()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT, PRMT_FEATR_IDENT, LMT_SET_DESIGNATOR
        , key_hash
        , data_hash
     FROM ICS_FLOW_ICIS.dbo.ICS_LMT_SET icis
WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'LimitSetSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.dbo.ICS_LMT_SET loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.dbo.ICS_LMT_SET) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_MASTER_GNRL_PRMT
-- ----------------------------------------------------------------------------


 INSERT INTO ICS_FLOW_LOCAL.dbo.ICS_MASTER_GNRL_PRMT
       ( ICS_MASTER_GNRL_PRMT_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT
       , key_hash
       , data_hash) 
   SELECT 
		newid()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT
        , key_hash
        , data_hash
     FROM ICS_FLOW_ICIS.dbo.ICS_MASTER_GNRL_PRMT icis
WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'MasterGeneralPermitSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.dbo.ICS_MASTER_GNRL_PRMT loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.dbo.ICS_MASTER_GNRL_PRMT) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_NARR_COND_SCHD
-- ----------------------------------------------------------------------------


 INSERT INTO ICS_FLOW_LOCAL.dbo.ICS_NARR_COND_SCHD
       ( ICS_NARR_COND_SCHD_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT, NARR_COND_NUM
       , key_hash
       , data_hash) 
   SELECT 
		newid()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT, NARR_COND_NUM
        , key_hash
        , data_hash
     FROM ICS_FLOW_ICIS.dbo.ICS_NARR_COND_SCHD icis
WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'NarrativeConditionScheduleSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.dbo.ICS_NARR_COND_SCHD loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.dbo.ICS_NARR_COND_SCHD) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_NPDES_VARIANCE_PRMT
-- ----------------------------------------------------------------------------


 INSERT INTO ICS_FLOW_LOCAL.dbo.ICS_NPDES_VARIANCE_PRMT
       ( ICS_NPDES_VARIANCE_PRMT_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT,NPDES_VARIANCE_TYPE_CODE,NPDES_VARIANCE_SUBM_DATE
       , key_hash
       , data_hash) 
   SELECT 
		newid()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT,NPDES_VARIANCE_TYPE_CODE,NPDES_VARIANCE_SUBM_DATE
        , key_hash
        , data_hash
     FROM ICS_FLOW_ICIS.dbo.ICS_NPDES_VARIANCE_PRMT icis
WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'NPDESVariancePermitSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.dbo.ICS_NPDES_VARIANCE_PRMT loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.dbo.ICS_NPDES_VARIANCE_PRMT) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_PARAM_LMTS
-- ----------------------------------------------------------------------------


 INSERT INTO ICS_FLOW_LOCAL.dbo.ICS_PARAM_LMTS
       ( ICS_PARAM_LMTS_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT, PRMT_FEATR_IDENT, LMT_SET_DESIGNATOR, PARAM_CODE, MON_SITE_DESC_CODE, LMT_SEASON_NUM
       , key_hash
       , data_hash) 
   SELECT 
		newid()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT, PRMT_FEATR_IDENT, LMT_SET_DESIGNATOR, PARAM_CODE, MON_SITE_DESC_CODE, LMT_SEASON_NUM
        , key_hash
        , data_hash
     FROM ICS_FLOW_ICIS.dbo.ICS_PARAM_LMTS icis
WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'ParameterLimitsSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.dbo.ICS_PARAM_LMTS loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.dbo.ICS_PARAM_LMTS) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_PRMT_REISSU
-- ----------------------------------------------------------------------------

-- Deletes not supported for ICS_PRMT_REISSU

-- ICS_PRMT_FEATR
-- ----------------------------------------------------------------------------


 INSERT INTO ICS_FLOW_LOCAL.dbo.ICS_PRMT_FEATR
       ( ICS_PRMT_FEATR_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT, PRMT_FEATR_IDENT
       , key_hash
       , data_hash) 
   SELECT 
		newid()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT, PRMT_FEATR_IDENT
        , key_hash
        , data_hash
     FROM ICS_FLOW_ICIS.dbo.ICS_PRMT_FEATR icis
WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'PermittedFeatureSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.dbo.ICS_PRMT_FEATR loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.dbo.ICS_PRMT_FEATR) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_PRMT_TERM
-- ----------------------------------------------------------------------------

-- Deletes not supported for ICS_PRMT_TERM

-- ICS_PRMT_TRACK_EVT
-- ----------------------------------------------------------------------------


 INSERT INTO ICS_FLOW_LOCAL.dbo.ICS_PRMT_TRACK_EVT
       ( ICS_PRMT_TRACK_EVT_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT, PRMT_TRACK_EVT_CODE, PRMT_TRACK_EVT_DATE
       , key_hash
       , data_hash) 
   SELECT 
		newid()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT, PRMT_TRACK_EVT_CODE, PRMT_TRACK_EVT_DATE
        , key_hash
        , data_hash
     FROM ICS_FLOW_ICIS.dbo.ICS_PRMT_TRACK_EVT icis
WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'PermitTrackingEventSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.dbo.ICS_PRMT_TRACK_EVT loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.dbo.ICS_PRMT_TRACK_EVT) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_POTW_PRMT
-- ----------------------------------------------------------------------------


 INSERT INTO ICS_FLOW_LOCAL.dbo.ICS_POTW_PRMT
       ( ICS_POTW_PRMT_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT
       , key_hash
       , data_hash) 
   SELECT 
		newid()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT
        , key_hash
        , data_hash
     FROM ICS_FLOW_ICIS.dbo.ICS_POTW_PRMT icis
WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'POTWPermitSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.dbo.ICS_POTW_PRMT loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.dbo.ICS_POTW_PRMT) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_POTW_TRTMNT_TECHNOLOGY_PRMT
-- ----------------------------------------------------------------------------


 INSERT INTO ICS_FLOW_LOCAL.dbo.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT
       ( ICS_POTW_TRTMNT_TECHNOLOGY_PRMT_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT
       , key_hash
       , data_hash) 
   SELECT 
		newid()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT
        , key_hash
        , data_hash
     FROM ICS_FLOW_ICIS.dbo.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT icis
WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'POTWTreatmentTechnologyPermitSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.dbo.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.dbo.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_PRETR_PRMT
-- ----------------------------------------------------------------------------


 INSERT INTO ICS_FLOW_LOCAL.dbo.ICS_PRETR_PRMT
       ( ICS_PRETR_PRMT_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT
       , key_hash
       , data_hash) 
   SELECT 
		newid()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT
        , key_hash
        , data_hash
     FROM ICS_FLOW_ICIS.dbo.ICS_PRETR_PRMT icis
WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'PretreatmentPermitSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.dbo.ICS_PRETR_PRMT loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.dbo.ICS_PRETR_PRMT) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_PRETR_PROG_REP
-- ----------------------------------------------------------------------------


 INSERT INTO ICS_FLOW_LOCAL.dbo.ICS_PRETR_PROG_REP
       ( ICS_PRETR_PROG_REP_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT,PROG_REP_FORM_SET_ID,PROG_REP_FORM_ID
       , key_hash
       , data_hash) 
   SELECT 
		newid()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT,PROG_REP_FORM_SET_ID,PROG_REP_FORM_ID
        , key_hash
        , data_hash
     FROM ICS_FLOW_ICIS.dbo.ICS_PRETR_PROG_REP icis
WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'PretreatmentProgramReportSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.dbo.ICS_PRETR_PROG_REP loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.dbo.ICS_PRETR_PROG_REP) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_SEWER_OVRFLW_BYPASS_EVT_REP
-- ----------------------------------------------------------------------------


 INSERT INTO ICS_FLOW_LOCAL.dbo.ICS_SEWER_OVRFLW_BYPASS_EVT_REP
       ( ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT,PROG_REP_FORM_SET_ID,PROG_REP_FORM_ID
       , key_hash
       , data_hash) 
   SELECT 
		newid()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT,PROG_REP_FORM_SET_ID,PROG_REP_FORM_ID
        , key_hash
        , data_hash
     FROM ICS_FLOW_ICIS.dbo.ICS_SEWER_OVRFLW_BYPASS_EVT_REP icis
WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'SewerOverflowBypassEventReportSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.dbo.ICS_SEWER_OVRFLW_BYPASS_EVT_REP loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.dbo.ICS_SEWER_OVRFLW_BYPASS_EVT_REP) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_SNGL_EVT_VIOL
-- ----------------------------------------------------------------------------


 INSERT INTO ICS_FLOW_LOCAL.dbo.ICS_SNGL_EVT_VIOL
       ( ICS_SNGL_EVT_VIOL_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT, SNGL_EVT_VIOL_CODE, SNGL_EVT_VIOL_DATE
       , key_hash
       , data_hash) 
   SELECT 
		newid()
		, icis.ics_payload_id
        , 'X' AS transaction_type
        , PRMT_IDENT, SNGL_EVT_VIOL_CODE, SNGL_EVT_VIOL_DATE
        , key_hash
        , data_hash
     FROM ICS_FLOW_ICIS.dbo.ICS_SNGL_EVT_VIOL icis
WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'SingleEventViolationSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.dbo.ICS_SNGL_EVT_VIOL loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.dbo.ICS_SNGL_EVT_VIOL) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_SW_CNST_PRMT
-- ----------------------------------------------------------------------------


 INSERT INTO ICS_FLOW_LOCAL.dbo.ICS_SW_CNST_PRMT
       ( ICS_SW_CNST_PRMT_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT
       , key_hash
       , data_hash) 
   SELECT 
		newid()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT
        , key_hash
        , data_hash
     FROM ICS_FLOW_ICIS.dbo.ICS_SW_CNST_PRMT icis
WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'SWConstructionPermitSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.dbo.ICS_SW_CNST_PRMT loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.dbo.ICS_SW_CNST_PRMT) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_SW_INDST_ANNUL_REP
-- ----------------------------------------------------------------------------


 INSERT INTO ICS_FLOW_LOCAL.dbo.ICS_SW_INDST_ANNUL_REP
       ( ICS_SW_INDST_ANNUL_REP_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT, INDST_SW_ANNUL_REP_RCVD_DATE
       , key_hash
       , data_hash) 
   SELECT 
		newid()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT, INDST_SW_ANNUL_REP_RCVD_DATE
        , key_hash
        , data_hash
     FROM ICS_FLOW_ICIS.dbo.ICS_SW_INDST_ANNUL_REP icis
WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'SWIndustrialAnnualReportSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.dbo.ICS_SW_INDST_ANNUL_REP loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.dbo.ICS_SW_INDST_ANNUL_REP) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_SW_INDST_PRMT
-- ----------------------------------------------------------------------------


 INSERT INTO ICS_FLOW_LOCAL.dbo.ICS_SW_INDST_PRMT
       ( ICS_SW_INDST_PRMT_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT
       , key_hash
       , data_hash) 
   SELECT 
		newid()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT
        , key_hash
        , data_hash
     FROM ICS_FLOW_ICIS.dbo.ICS_SW_INDST_PRMT icis
WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'SWIndustrialPermitSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.dbo.ICS_SW_INDST_PRMT loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.dbo.ICS_SW_INDST_PRMT) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_SWMS_4_ANNUL_PROG_REP
-- ----------------------------------------------------------------------------


 INSERT INTO ICS_FLOW_LOCAL.dbo.ICS_SWMS_4_ANNUL_PROG_REP
       ( ICS_SWMS_4_ANNUL_PROG_REP_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT,PROG_REP_FORM_SET_ID,PROG_REP_FORM_ID
       , key_hash
       , data_hash) 
   SELECT 
		newid()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT,PROG_REP_FORM_SET_ID,PROG_REP_FORM_ID
        , key_hash
        , data_hash
     FROM ICS_FLOW_ICIS.dbo.ICS_SWMS_4_ANNUL_PROG_REP icis
WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'SWMS4AnnualProgramReportSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.dbo.ICS_SWMS_4_ANNUL_PROG_REP loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.dbo.ICS_SWMS_4_ANNUL_PROG_REP) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_SWMS_4_PRMT
-- ----------------------------------------------------------------------------


 INSERT INTO ICS_FLOW_LOCAL.dbo.ICS_SWMS_4_PRMT
       ( ICS_SWMS_4_PRMT_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT
       , key_hash
       , data_hash) 
   SELECT 
		newid()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT
        , key_hash
        , data_hash
     FROM ICS_FLOW_ICIS.dbo.ICS_SWMS_4_PRMT icis
WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'SWMS4PermitSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.dbo.ICS_SWMS_4_PRMT loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.dbo.ICS_SWMS_4_PRMT) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_UNPRMT_FAC
-- ----------------------------------------------------------------------------


 INSERT INTO ICS_FLOW_LOCAL.dbo.ICS_UNPRMT_FAC
       ( ICS_UNPRMT_FAC_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT
       , key_hash
       , data_hash) 
   SELECT 
		newid()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT
        , key_hash
        , data_hash
     FROM ICS_FLOW_ICIS.dbo.ICS_UNPRMT_FAC icis
WHERE
	exists (select 1 from ICS_FLOW_LOCAL.dbo.ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'UnpermittedFacilitySubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.dbo.ICS_UNPRMT_FAC loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.dbo.ICS_UNPRMT_FAC) -- do not delete if no other records for saftey
	;	 
	 
			   
-- ------------------
-- Choice Key Deletes
-- ------------------
-- ---------------------------------
-- ICS_CMPL_MON_LNK (3 paths)
-- ---------------------------------

delete from ics_flow_local.dbo.ICS_KEY_HASH;

insert into ics_flow_local.dbo.ICS_KEY_HASH 
select icis.KEY_HASH 
      from ics_flow_icis.dbo.ICS_CMPL_MON_LNK icis 
      where 1=1
      and not exists (select 1 from ics_flow_local.dbo.ICS_CMPL_MON_LNK loc where loc.KEY_HASH = icis.KEY_HASH OR loc.ICS_CMPL_MON_LNK_ID = icis.ICS_CMPL_MON_LNK_ID) 
      and exists (select 1 from ics_flow_local.dbo.ICS_PAYLOAD where OPERATION = 'ComplianceMonitoringLinkageSubmission' and ENABLED = 'Y' and AUTO_GEN_DELETES = 'Y')
      ;


-- ICS_CMPL_MON_LNK - CM LINK
INSERT INTO ics_flow_local.dbo.ICS_CMPL_MON_LNK
           (
		   ICS_CMPL_MON_LNK_ID
           ,ICS_PAYLOAD_ID
           ,SRC_SYSTM_IDENT
           ,TRANSACTION_TYPE
           ,TRANSACTION_TIMESTAMP
           ,CMPL_MON_IDENT
           ,KEY_HASH
           ,DATA_HASH
		   )

     SELECT 
 		   ICS_CMPL_MON_LNK.ICS_CMPL_MON_LNK_ID
           ,ICS_CMPL_MON_LNK.ICS_PAYLOAD_ID
           ,ICS_CMPL_MON_LNK.SRC_SYSTM_IDENT
           ,'X' as TRANSACTION_TYPE
           ,ICS_CMPL_MON_LNK.TRANSACTION_TIMESTAMP
           ,ICS_CMPL_MON_LNK.CMPL_MON_IDENT
           ,ICS_CMPL_MON_LNK.KEY_HASH
           ,null DATA_HASH
              from ics_flow_icis.dbo.ICS_CMPL_MON_LNK ICS_CMPL_MON_LNK 
              join ics_flow_icis.dbo.ICS_LNK_CMPL_MON LNKCM on LNKCM.ICS_CMPL_MON_LNK_ID = ICS_CMPL_MON_LNK.ICS_CMPL_MON_LNK_ID
              where  ICS_CMPL_MON_LNK.KEY_HASH  in (select KEY_HASH from ics_flow_local.dbo.ICS_KEY_HASH)
              
;

 INSERT INTO ics_flow_local.dbo.ICS_LNK_CMPL_MON
     SELECT LNKCM.*
              from ics_flow_icis.dbo.ICS_CMPL_MON_LNK ICS_CMPL_MON_LNK 
              join ics_flow_icis.dbo.ICS_LNK_CMPL_MON LNKCM on LNKCM.ICS_CMPL_MON_LNK_ID = ICS_CMPL_MON_LNK.ICS_CMPL_MON_LNK_ID
              where  ICS_CMPL_MON_LNK.KEY_HASH  in (select KEY_HASH from ics_flow_local.dbo.ICS_KEY_HASH)
 ;
 
 -- ICS_CMPL_MON_LNK - EA Link
 
INSERT INTO ics_flow_local.dbo.ICS_CMPL_MON_LNK
           (
		   ICS_CMPL_MON_LNK_ID
           ,ICS_PAYLOAD_ID
           ,SRC_SYSTM_IDENT
           ,TRANSACTION_TYPE
           ,TRANSACTION_TIMESTAMP
           ,CMPL_MON_IDENT
           ,KEY_HASH
           ,DATA_HASH
		   )

     SELECT 
 		   ICS_CMPL_MON_LNK.ICS_CMPL_MON_LNK_ID
           ,ICS_CMPL_MON_LNK.ICS_PAYLOAD_ID
           ,ICS_CMPL_MON_LNK.SRC_SYSTM_IDENT
           ,'X' as TRANSACTION_TYPE
           ,ICS_CMPL_MON_LNK.TRANSACTION_TIMESTAMP
           ,ICS_CMPL_MON_LNK.CMPL_MON_IDENT
           ,ICS_CMPL_MON_LNK.KEY_HASH
           ,null DATA_HASH
          from ics_flow_icis.dbo.ICS_CMPL_MON_LNK ICS_CMPL_MON_LNK 
          JOIN ics_flow_icis.dbo.ICS_LNK_ENFRC_ACTN I2  ON I2.ICS_CMPL_MON_LNK_ID = ICS_CMPL_MON_LNK.ICS_CMPL_MON_LNK_ID
          where  ICS_CMPL_MON_LNK.KEY_HASH  in (select KEY_HASH from ics_flow_local.dbo.ICS_KEY_HASH)
;

 INSERT INTO ics_flow_local.dbo.ICS_LNK_ENFRC_ACTN
   SELECT I2.*
          from ics_flow_icis.dbo.ICS_CMPL_MON_LNK ICS_CMPL_MON_LNK 
          JOIN ics_flow_icis.dbo.ICS_LNK_ENFRC_ACTN I2  ON I2.ICS_CMPL_MON_LNK_ID = ICS_CMPL_MON_LNK.ICS_CMPL_MON_LNK_ID
          where  ICS_CMPL_MON_LNK.KEY_HASH  in (select KEY_HASH from ics_flow_local.dbo.ICS_KEY_HASH)
;

-- ICS_CMPL_MON_LNK - SEV link
INSERT INTO ics_flow_local.dbo.ICS_CMPL_MON_LNK
           (
		   ICS_CMPL_MON_LNK_ID
           ,ICS_PAYLOAD_ID
           ,SRC_SYSTM_IDENT
           ,TRANSACTION_TYPE
           ,TRANSACTION_TIMESTAMP
           ,CMPL_MON_IDENT
           ,KEY_HASH
           ,DATA_HASH
		   )

     SELECT 
 		   ICS_CMPL_MON_LNK.ICS_CMPL_MON_LNK_ID
           ,ICS_CMPL_MON_LNK.ICS_PAYLOAD_ID
           ,ICS_CMPL_MON_LNK.SRC_SYSTM_IDENT
           ,'X' as TRANSACTION_TYPE
           ,ICS_CMPL_MON_LNK.TRANSACTION_TIMESTAMP
           ,ICS_CMPL_MON_LNK.CMPL_MON_IDENT
           ,ICS_CMPL_MON_LNK.KEY_HASH
           ,null DATA_HASH
 from ics_flow_icis.dbo.ICS_CMPL_MON_LNK ICS_CMPL_MON_LNK 
 JOIN ics_flow_icis.dbo.ICS_LNK_SNGL_EVT I3
 ON I3.ICS_CMPL_MON_LNK_ID = ICS_CMPL_MON_LNK.ICS_CMPL_MON_LNK_ID 
where  ICS_CMPL_MON_LNK.KEY_HASH  in (select KEY_HASH from ics_flow_local.dbo.ICS_KEY_HASH)
;

insert into ics_flow_local.dbo.ICS_LNK_SNGL_EVT
      SELECT I3.*
 from ics_flow_icis.dbo.ICS_CMPL_MON_LNK ICS_CMPL_MON_LNK 
 JOIN ics_flow_icis.dbo.ICS_LNK_SNGL_EVT I3
 ON I3.ICS_CMPL_MON_LNK_ID = ICS_CMPL_MON_LNK.ICS_CMPL_MON_LNK_ID 
where  ICS_CMPL_MON_LNK.KEY_HASH  in (select KEY_HASH from ics_flow_local.dbo.ICS_KEY_HASH)
;
 -- ------------------------------------------------------
-- ICS_FINAL_ORDER_VIOL_LNK 
-- 6 paths
-- -------------------------------------------------------

delete from ics_flow_local.dbo.ICS_KEY_HASH;

insert into ics_flow_local.dbo.ICS_KEY_HASH
select KEY_HASH from ics_flow_icis.dbo.ics_final_order_viol_lnk icis
      where  1=1
      and not exists (select 1 from ics_flow_local.dbo.ics_final_order_viol_lnk loc where loc.KEY_HASH = icis.KEY_HASH OR loc.ics_final_order_viol_lnk_id = icis.ics_final_order_viol_lnk_id) 
      and exists (select 1 from ics_flow_local.dbo.ICS_PAYLOAD where OPERATION = 'FinalOrderViolationLinkageSubmission' and ENABLED = 'Y' and AUTO_GEN_DELETES = 'Y')
      ;
      

  INSERT INTO  ics_flow_local.dbo.ics_final_order_viol_lnk
             ( ics_final_order_viol_lnk_id
             , ics_payload_id
             , src_systm_ident
             , transaction_type
             , transaction_timestamp
             , enfrc_actn_ident
             , final_order_ident
             , key_hash
             , data_hash)
      SELECT ics_final_order_viol_lnk.ics_final_order_viol_lnk_id -- changed from local to icis to be like EA (not sure point of local)
           , (SELECT ics_payload_id
                FROM ics_flow_local.dbo.ics_payload 
               WHERE operation = 'FinalOrderViolationLinkageSubmission') AS ics_payload_id
             , ics_final_order_viol_lnk.src_systm_ident
             , 'X' AS transaction_type
             , ics_final_order_viol_lnk.transaction_timestamp
             , ics_final_order_viol_lnk.enfrc_actn_ident
             , ics_final_order_viol_lnk.final_order_ident
             , ics_final_order_viol_lnk.key_hash
             , ics_final_order_viol_lnk.data_hash
        FROM ics_flow_icis.dbo.ics_final_order_viol_lnk ics_final_order_viol_lnk
        JOIN ics_flow_local.dbo.ICS_KEY_HASH KH on KH.KEY_HASH = ics_final_order_viol_lnk.KEY_HASH;
  
      
 
--    ICS_DSCH_MON_REP_PARAM_VIOL
INSERT INTO  ics_flow_local.dbo.ICS_DSCH_MON_REP_PARAM_VIOL
           ( ICS_DSCH_MON_REP_PARAM_VIOL_ID
           , ICS_ENFRC_ACTN_VIOL_LNK_ID
           , ICS_FINAL_ORDER_VIOL_LNK_ID
           , PRMT_IDENT
           , PRMT_FEATR_IDENT
           , LMT_SET_DESIGNATOR
           , MON_PERIOD_END_DATE
           , PARAM_CODE
           , MON_SITE_DESC_CODE
           , LMT_SEASON_NUM
           , DATA_HASH)
      SELECT ics_dsch_mon_rep_param_viol.ICS_DSCH_MON_REP_PARAM_VIOL_ID
           , NULL AS ICS_ENFRC_ACTN_VIOL_LNK_ID
           , ics_dsch_mon_rep_param_viol.ics_final_order_viol_lnk_id as ics_final_order_viol_lnk_id
           , ics_dsch_mon_rep_param_viol.prmt_ident as prmt_ident
           , ics_dsch_mon_rep_param_viol.prmt_featr_ident as prmt_featr_ident
           , ics_dsch_mon_rep_param_viol.lmt_set_designator as lmt_set_designator
           , ics_dsch_mon_rep_param_viol.mon_period_end_date as mon_period_end_date
           , ics_dsch_mon_rep_param_viol.param_code as param_code
           , ics_dsch_mon_rep_param_viol.mon_site_desc_code as mon_site_desc_code
           , ics_dsch_mon_rep_param_viol.lmt_season_num as lmt_season_num
           , ics_dsch_mon_rep_param_viol.data_hash as data_hash
    FROM  ics_flow_icis.dbo.ics_final_order_viol_lnk ifov
   join ics_flow_local.dbo.ICS_KEY_HASH KH on KH.KEY_HASH = ifov.KEY_HASH
    JOIN  ics_flow_icis.dbo.ics_dsch_mon_rep_param_viol ics_dsch_mon_rep_param_viol ON ifov.ics_final_order_viol_lnk_id = ics_dsch_mon_rep_param_viol.ics_final_order_viol_lnk_id
   ;     
      
      
--    ICS_DSCH_MON_REP_VIOL
INSERT INTO  ics_flow_local.dbo.ICS_DSCH_MON_REP_VIOL
           ( ICS_DSCH_MON_REP_VIOL_ID
           , ICS_ENFRC_ACTN_VIOL_LNK_ID
           , ICS_FINAL_ORDER_VIOL_LNK_ID
           , PRMT_IDENT
           , PRMT_FEATR_IDENT
           , LMT_SET_DESIGNATOR
           , MON_PERIOD_END_DATE
           , DATA_HASH)
      SELECT ics_dsch_mon_rep_viol.ICS_DSCH_MON_REP_VIOL_ID
           , NULL AS ICS_ENFRC_ACTN_VIOL_LNK_ID
           , ics_dsch_mon_rep_viol.ics_final_order_viol_lnk_id as ics_final_order_viol_lnk_id
           , ics_dsch_mon_rep_viol.prmt_ident as prmt_ident
           , ics_dsch_mon_rep_viol.prmt_featr_ident as prmt_featr_ident
           , ics_dsch_mon_rep_viol.lmt_set_designator as lmt_set_designator
           , ics_dsch_mon_rep_viol.mon_period_end_date as mon_period_end_date
           , ics_dsch_mon_rep_viol.data_hash as data_hash
   FROM ics_flow_icis.dbo.ics_dsch_mon_rep_viol ics_dsch_mon_rep_viol
   JOIN ics_flow_icis.dbo.ics_final_order_viol_lnk ifov
     ON ifov.ics_final_order_viol_lnk_id = ics_dsch_mon_rep_viol.ics_final_order_viol_lnk_id
   join ics_flow_local.dbo.ICS_KEY_HASH KH on KH.KEY_HASH = ifov.KEY_HASH;        
 
--    ICS_PRMT_SCHD_VIOL
INSERT INTO  ics_flow_local.dbo.ICS_PRMT_SCHD_VIOL
           ( ICS_PRMT_SCHD_VIOL_ID
           , ICS_ENFRC_ACTN_VIOL_LNK_ID
           , ICS_FINAL_ORDER_VIOL_LNK_ID
           , PRMT_IDENT
           , NARR_COND_NUM
           , SCHD_EVT_CODE
           , SCHD_DATE
           , DATA_HASH)
      SELECT ics_prmt_schd_viol.ICS_PRMT_SCHD_VIOL_ID
           , NULL AS ICS_ENFRC_ACTN_VIOL_LNK_ID
           , ics_prmt_schd_viol.ics_final_order_viol_lnk_id as ics_final_order_viol_lnk_id
           , ics_prmt_schd_viol.prmt_ident as prmt_ident
           , ics_prmt_schd_viol.narr_cond_num as narr_cond_num
           , ics_prmt_schd_viol.schd_evt_code as schd_evt_code
           , ics_prmt_schd_viol.schd_date as schd_date
           , ics_prmt_schd_viol.data_hash as data_hash
   FROM ics_flow_icis.dbo.ics_prmt_schd_viol ics_prmt_schd_viol
   JOIN ics_flow_icis.dbo.ics_final_order_viol_lnk ifov
     ON ifov.ics_final_order_viol_lnk_id = ics_prmt_schd_viol.ics_final_order_viol_lnk_id
   join ics_flow_local.dbo.ICS_KEY_HASH KH on KH.KEY_HASH = ifov.KEY_HASH;    
      
      
 --    ICS_SNGL_EVTS_VIOL
INSERT INTO ics_flow_local.dbo.ics_sngl_evts_viol
           (ics_sngl_evts_viol_id
           ,ics_enfrc_actn_viol_lnk_id
           ,ics_final_order_viol_lnk_id
           ,prmt_ident
           ,sngl_evt_viol_code
           ,sngl_evt_viol_date
           ,data_hash)
      SELECT ics_sngl_evts_viol.ics_sngl_evts_viol_id
           , NULL as ics_enfrc_actn_viol_lnk_id
           , ics_sngl_evts_viol.ics_final_order_viol_lnk_id as ics_final_order_viol_lnk_id
           , ics_sngl_evts_viol.prmt_ident as prmt_ident
           , ics_sngl_evts_viol.sngl_evt_viol_code as sngl_evt_viol_code
           , ics_sngl_evts_viol.sngl_evt_viol_date as sngl_evt_viol_date
           , ics_sngl_evts_viol.data_hash as data_hash
        FROM ics_flow_icis.dbo.ics_sngl_evts_viol ics_sngl_evts_viol
   JOIN ics_flow_icis.dbo.ics_final_order_viol_lnk ifov
     ON ifov.ics_final_order_viol_lnk_id = ics_sngl_evts_viol.ics_final_order_viol_lnk_id
   join ics_flow_local.dbo.ICS_KEY_HASH KH on KH.KEY_HASH = ifov.KEY_HASH;    
      
      
 --    ICS_CMPL_SCHD_VIOL
      INSERT INTO ics_flow_local.dbo.ICS_CMPL_SCHD_VIOL
           ( ICS_CMPL_SCHD_VIOL_ID
           , ICS_ENFRC_ACTN_VIOL_LNK_ID
           , ICS_FINAL_ORDER_VIOL_LNK_ID
           , ENFRC_ACTN_IDENT
           , FINAL_ORDER_IDENT
           , PRMT_IDENT
           , CMPL_SCHD_NUM
           , SCHD_EVT_CODE
           , SCHD_DATE
           , DATA_HASH)
      SELECT ics_cmpl_schd_viol.ICS_CMPL_SCHD_VIOL_ID
           , NULL AS ICS_ENFRC_ACTN_VIOL_LNK_ID
           , ics_cmpl_schd_viol.ics_final_order_viol_lnk_id as ics_final_order_viol_lnk_id
           , ics_cmpl_schd_viol.enfrc_actn_ident as enfrc_actn_ident
           , ics_cmpl_schd_viol.final_order_ident as final_order_ident
           , ics_cmpl_schd_viol.prmt_ident as prmt_ident
           , ics_cmpl_schd_viol.cmpl_schd_num as cmpl_schd_num
           , ics_cmpl_schd_viol.schd_evt_code as schd_evt_code
           , ics_cmpl_schd_viol.schd_date as schd_date
           , ics_cmpl_schd_viol.data_hash as data_hash   
        FROM ics_flow_icis.dbo.ics_cmpl_schd_viol ics_cmpl_schd_viol
   JOIN ics_flow_icis.dbo.ics_final_order_viol_lnk ifov
     ON ifov.ics_final_order_viol_lnk_id = ics_cmpl_schd_viol.ics_final_order_viol_lnk_id
   join ics_flow_local.dbo.ICS_KEY_HASH KH on KH.KEY_HASH = ifov.KEY_HASH;    
      



/* **************************************************
  * ICS_ENFRC_ACTN_VIOL_LNK:  Set Delete Transactions  
  * 6 paths
  * **************************************************/

delete from ics_flow_local.dbo.ICS_KEY_HASH;

insert into ics_flow_local.dbo.ICS_KEY_HASH
select icis.KEY_HASH from ics_flow_icis.dbo.ics_enfrc_actn_viol_lnk icis
      where 1=1
      and not exists (select 1 from ics_flow_local.dbo.ics_enfrc_actn_viol_lnk loc where loc.KEY_HASH = icis.KEY_HASH OR loc.ics_enfrc_actn_viol_lnk_id = icis.ics_enfrc_actn_viol_lnk_id) 
      and exists (select 1 from ics_flow_local.dbo.ICS_PAYLOAD where OPERATION = 'EnforcementActionViolationLinkageSubmission' and ENABLED = 'Y' and AUTO_GEN_DELETES = 'Y')
      ;

 /*  
 *  ICS_ENFRC_ACTN_VIOL_LNK
 */                                     
 INSERT INTO ics_flow_local.dbo.ics_enfrc_actn_viol_lnk
      ( ics_enfrc_actn_viol_lnk_id
      , ics_payload_id
      , src_systm_ident
      , transaction_type
      , transaction_timestamp
      , enfrc_actn_ident
      , key_hash
      , data_hash)
 SELECT ics_enfrc_actn_viol_lnk.ics_enfrc_actn_viol_lnk_id AS ICS_ENFRC_ACTN_VIOL_LNK_ID
      , (SELECT ics_payload_id
           FROM ics_flow_local.dbo.ics_payload 
          WHERE operation = 'EnforcementActionViolationLinkageSubmission') AS ics_payload_id
      , ics_enfrc_actn_viol_lnk.src_systm_ident AS src_systm_ident
      , 'x' AS transaction_type
      , ics_enfrc_actn_viol_lnk.transaction_timestamp AS transaction_timestamp
      , ics_enfrc_actn_viol_lnk.enfrc_actn_ident AS enfrc_actn_ident
      , NULL AS key_hash
      , NULL AS data_hash
   FROM ics_flow_icis.dbo.ics_enfrc_actn_viol_lnk ics_enfrc_actn_viol_lnk     	  
 JOIN ics_flow_local.dbo.ICS_KEY_HASH KH on KH.KEY_HASH = ics_enfrc_actn_viol_lnk.KEY_HASH;
      

   /*
   * ICS_PRMT_SCHD_VIOL
   */
   INSERT INTO ics_flow_local.dbo.ics_prmt_schd_viol
       ( ics_prmt_schd_viol_id
       , ics_enfrc_actn_viol_lnk_id
       , ics_final_order_viol_lnk_id
       , prmt_ident
       , narr_cond_num
       , schd_evt_code
       , schd_date
       , data_hash)
  SELECT ics_prmt_schd_viol.ics_prmt_schd_viol_id
       , ics_prmt_schd_viol.ics_enfrc_actn_viol_lnk_id AS ics_enfrc_actn_viol_lnk_id
       , NULL AS ics_final_order_viol_lnk_id
       , ics_prmt_schd_viol.prmt_ident AS prmt_ident
       , ics_prmt_schd_viol.narr_cond_num AS narr_cond_num
       , ics_prmt_schd_viol.schd_evt_code AS schd_evt_code
       , ics_prmt_schd_viol.schd_date AS schd_date
       , ics_prmt_schd_viol.data_hash  AS data_hash
   FROM ics_flow_icis.dbo.ics_prmt_schd_viol ics_prmt_schd_viol
   JOIN ics_flow_icis.dbo.ics_enfrc_actn_viol_lnk ieav
     ON ieav.ics_enfrc_actn_viol_lnk_id = ics_prmt_schd_viol.ics_enfrc_actn_viol_lnk_id   	  
 JOIN ics_flow_local.dbo.ICS_KEY_HASH KH on KH.KEY_HASH = ieav.KEY_HASH
 ;    
          

  /*
   * ICS_CMPL_SCHD_VIOL
   */
   INSERT INTO ics_flow_local.dbo.ics_cmpl_schd_viol
        ( ics_cmpl_schd_viol_id
        , ics_enfrc_actn_viol_lnk_id
        , ics_final_order_viol_lnk_id
        , enfrc_actn_ident
        , final_order_ident
        , prmt_ident
        , cmpl_schd_num
        , schd_evt_code
        , schd_date
        , data_hash)
   SELECT ics_cmpl_schd_viol.ics_cmpl_schd_viol_id
        , ics_cmpl_schd_viol.ics_enfrc_actn_viol_lnk_id AS ics_enfrc_actn_viol_lnk_id
        , NULL AS ics_final_order_viol_lnk_id
        , ics_cmpl_schd_viol.enfrc_actn_ident AS enfrc_actn_ident
        , ics_cmpl_schd_viol.final_order_ident AS final_order_ident
        , ics_cmpl_schd_viol.prmt_ident AS prmt_ident
        , ics_cmpl_schd_viol.cmpl_schd_num AS cmpl_schd_num
        , ics_cmpl_schd_viol.schd_evt_code AS schd_evt_code
        , ics_cmpl_schd_viol.schd_date AS schd_date
        , ics_cmpl_schd_viol.data_hash AS data_hash
    FROM ics_flow_icis.dbo.ics_cmpl_schd_viol ics_cmpl_schd_viol 
   JOIN ics_flow_icis.dbo.ics_enfrc_actn_viol_lnk ieav
     ON ieav.ics_enfrc_actn_viol_lnk_id = ics_cmpl_schd_viol.ics_enfrc_actn_viol_lnk_id    
   JOIN ics_flow_local.dbo.ICS_KEY_HASH KH on KH.KEY_HASH = ieav.KEY_HASH
   ;

  /*
   * ICS_DSCH_MON_REP_VIOL
   */
   INSERT INTO ics_flow_local.dbo.ics_dsch_mon_rep_viol
       ( ics_dsch_mon_rep_viol_id
       , ics_enfrc_actn_viol_lnk_id
       , ics_final_order_viol_lnk_id
       , prmt_ident
       , prmt_featr_ident
       , lmt_set_designator
       , mon_period_end_date
       , data_hash)
  SELECT ics_dsch_mon_rep_viol.ics_dsch_mon_rep_viol_id
       , ics_dsch_mon_rep_viol.ics_enfrc_actn_viol_lnk_id AS ics_enfrc_actn_viol_lnk_id
       , NULL AS ics_final_order_viol_lnk_id
       , ics_dsch_mon_rep_viol.prmt_ident AS prmt_ident
       , ics_dsch_mon_rep_viol.prmt_featr_ident AS prmt_featr_ident
       , ics_dsch_mon_rep_viol.lmt_set_designator AS lmt_set_designator
       , ics_dsch_mon_rep_viol.mon_period_end_date AS mon_period_end_date
       , ics_dsch_mon_rep_viol.data_hash AS data_hash
   FROM ics_flow_icis.dbo.ics_dsch_mon_rep_viol ics_dsch_mon_rep_viol
   JOIN ics_flow_icis.dbo.ics_enfrc_actn_viol_lnk ieav
     ON ieav.ics_enfrc_actn_viol_lnk_id = ics_dsch_mon_rep_viol.ics_enfrc_actn_viol_lnk_id    
   JOIN ics_flow_local.dbo.ICS_KEY_HASH KH on KH.KEY_HASH = ieav.KEY_HASH
   ;    
          


   
  /*
   * ICS_DSCH_MON_REP_PARAM_VIOL
   */
   INSERT INTO ics_flow_local.dbo.ics_dsch_mon_rep_param_viol
        ( ics_dsch_mon_rep_param_viol_id
        , ics_enfrc_actn_viol_lnk_id
        , ics_final_order_viol_lnk_id
        , prmt_ident
        , prmt_featr_ident
        , lmt_set_designator
        , mon_period_end_date
        , param_code
        , mon_site_desc_code
        , lmt_season_num
        , data_hash)
   SELECT ics_dsch_mon_rep_param_viol.ics_dsch_mon_rep_param_viol_id
        , ics_dsch_mon_rep_param_viol.ics_enfrc_actn_viol_lnk_id AS ics_enfrc_actn_viol_lnk_id
        , NULL AS ics_final_order_viol_lnk_id
        , ics_dsch_mon_rep_param_viol.prmt_ident AS prmt_ident
        , ics_dsch_mon_rep_param_viol.prmt_featr_ident AS prmt_featr_ident
        , ics_dsch_mon_rep_param_viol.lmt_set_designator AS lmt_set_designator
        , ics_dsch_mon_rep_param_viol.mon_period_end_date AS mon_period_end_date
        , ics_dsch_mon_rep_param_viol.param_code AS param_code
        , ics_dsch_mon_rep_param_viol.mon_site_desc_code AS mon_site_desc_code
        , ics_dsch_mon_rep_param_viol.lmt_season_num AS lmt_season_num
        , ics_dsch_mon_rep_param_viol.data_hash AS data_hash
    FROM ics_flow_icis.dbo.ics_dsch_mon_rep_param_viol ics_dsch_mon_rep_param_viol
   JOIN ics_flow_icis.dbo.ics_enfrc_actn_viol_lnk ieav
     ON ieav.ics_enfrc_actn_viol_lnk_id = ics_dsch_mon_rep_param_viol.ics_enfrc_actn_viol_lnk_id    
   JOIN ics_flow_local.dbo.ICS_KEY_HASH KH on KH.KEY_HASH = ieav.KEY_HASH
   ;

  /*
   * ICS_SNGL_EVTS_VIOL 
   */
   INSERT INTO ics_flow_local.dbo.ics_sngl_evts_viol
        ( ics_sngl_evts_viol_id
        , ics_enfrc_actn_viol_lnk_id
        , ics_final_order_viol_lnk_id
        , prmt_ident
        , sngl_evt_viol_code
        , sngl_evt_viol_date
        , data_hash)
   SELECT ics_sngl_evts_viol.ics_sngl_evts_viol_id
        , ics_sngl_evts_viol.ics_enfrc_actn_viol_lnk_id AS ics_enfrc_actn_viol_lnk_id
        , NULL AS ics_final_order_viol_lnk_id
        , ics_sngl_evts_viol.prmt_ident AS prmt_ident
        , ics_sngl_evts_viol.sngl_evt_viol_code AS sngl_evt_viol_code
        , ics_sngl_evts_viol.sngl_evt_viol_date AS sngl_evt_viol_date
        , ics_sngl_evts_viol.data_hash AS data_hash
    FROM ics_flow_icis.dbo.ics_sngl_evts_viol ics_sngl_evts_viol
   JOIN ics_flow_icis.dbo.ics_enfrc_actn_viol_lnk ieav
     ON ieav.ics_enfrc_actn_viol_lnk_id = ics_sngl_evts_viol.ics_enfrc_actn_viol_lnk_id    
   JOIN ics_flow_local.dbo.ICS_KEY_HASH KH on KH.KEY_HASH = ieav.KEY_HASH
   ;



-- ------------------------------
-- ICS_SCHD_EVT_VIOL
-- 2 paths
-- ------------------------------

delete from ics_flow_local.dbo.ICS_KEY_HASH;

insert into ics_flow_local.dbo.ICS_KEY_HASH
select icis.KEY_HASH from ics_flow_icis.dbo.ICS_SCHD_EVT_VIOL icis
      where 1=1
      and not exists (select 1 from ics_flow_local.dbo.ICS_SCHD_EVT_VIOL loc where loc.KEY_HASH = icis.KEY_HASH OR loc.ICS_SCHD_EVT_VIOL_ID = icis.ICS_SCHD_EVT_VIOL_ID) 
      and exists (select 1 from ics_flow_local.dbo.ICS_PAYLOAD where OPERATION = 'ScheduleEventViolationSubmission' and ENABLED = 'Y' and AUTO_GEN_DELETES = 'Y')
      ;

insert into ics_flow_local.dbo.ICS_SCHD_EVT_VIOL
      ( ICS_SCHD_EVT_VIOL_id
      , ics_payload_id
      , src_systm_ident
      , transaction_type
      , transaction_timestamp
      , key_hash
      , data_hash)
 SELECT ICS_SCHD_EVT_VIOL.ICS_SCHD_EVT_VIOL_ID AS ICS_SCHD_EVT_VIOL_ID
      , (SELECT ics_payload_id
           FROM ics_flow_local.dbo.ics_payload 
          WHERE operation = 'ScheduleEventViolationSubmission') AS ics_payload_id
      , ICS_SCHD_EVT_VIOL.src_systm_ident AS src_systm_ident
      , 'x' AS transaction_type
      , ICS_SCHD_EVT_VIOL.transaction_timestamp AS transaction_timestamp
      , NULL AS key_hash
      , NULL AS data_hash
   FROM ics_flow_icis.dbo.ICS_SCHD_EVT_VIOL ICS_SCHD_EVT_VIOL     	  
 JOIN ics_flow_local.dbo.ICS_KEY_HASH KH on KH.KEY_HASH = ICS_SCHD_EVT_VIOL.KEY_HASH;





INSERT INTO ics_flow_local.dbo.ICS_PRMT_SCHD_EVT_VIOL_ELEM
           (ICS_PRMT_SCHD_EVT_VIOL_ELEM_ID
           ,ICS_SCHD_EVT_VIOL_ID
           ,PRMT_IDENT
           ,NARR_COND_NUM
           ,SCHD_EVT_CODE
           ,SCHD_DATE
           ,SCHD_VIOL_CODE
           )
select
ICS_PRMT_SCHD_EVT_VIOL_ELEM.ICS_PRMT_SCHD_EVT_VIOL_ELEM_ID
           ,ICS_PRMT_SCHD_EVT_VIOL_ELEM.ICS_SCHD_EVT_VIOL_ID
           ,PRMT_IDENT
           ,NARR_COND_NUM
           ,SCHD_EVT_CODE
           ,SCHD_DATE
           ,SCHD_VIOL_CODE
           from ics_flow_icis.dbo.ICS_PRMT_SCHD_EVT_VIOL_ELEM ICS_PRMT_SCHD_EVT_VIOL_ELEM
           join ics_flow_icis.dbo.ICS_SCHD_EVT_VIOL SEV on SEV.ICS_SCHD_EVT_VIOL_ID = ICS_PRMT_SCHD_EVT_VIOL_ELEM.ICS_SCHD_EVT_VIOL_ID
           join ics_flow_local.dbo.ICS_KEY_HASH kh on kh.KEY_HASH = SEV.key_hash
;






INSERT INTO ics_flow_local.dbo.ICS_CMPL_SCHD_EVT_VIOL_ELEM
           (
           ICS_CMPL_SCHD_EVT_VIOL_ELEM_ID
           ,ICS_SCHD_EVT_VIOL_ID
           ,ENFRC_ACTN_IDENT
           ,FINAL_ORDER_IDENT
           ,PRMT_IDENT
           ,CMPL_SCHD_NUM
           ,SCHD_EVT_CODE
           ,SCHD_DATE
           ,SCHD_VIOL_CODE
           )
select
           ICS_CMPL_SCHD_EVT_VIOL_ELEM.ICS_CMPL_SCHD_EVT_VIOL_ELEM_ID
           ,ICS_CMPL_SCHD_EVT_VIOL_ELEM.ICS_SCHD_EVT_VIOL_ID
           ,ENFRC_ACTN_IDENT
           ,FINAL_ORDER_IDENT
           ,PRMT_IDENT
           ,CMPL_SCHD_NUM
           ,SCHD_EVT_CODE
           ,SCHD_DATE
           ,SCHD_VIOL_CODE
    from ics_flow_icis.dbo.ICS_CMPL_SCHD_EVT_VIOL_ELEM 
           join ics_flow_icis.dbo.ICS_SCHD_EVT_VIOL SEV on SEV.ICS_SCHD_EVT_VIOL_ID = ICS_CMPL_SCHD_EVT_VIOL_ELEM.ICS_SCHD_EVT_VIOL_ID
           join ics_flow_local.dbo.ICS_KEY_HASH kh on kh.KEY_HASH = SEV.key_hash
    ;



     --PRINT 'Change Detection: Completed at ' + CONVERT(VARCHAR(24),GETDATE(),113)

     UPDATE BP
	 SET TRANSACTION_TYPE = NULL
	 FROM dbo.ICS_BASIC_PRMT BP
	 WHERE EXISTS (SELECT 1 
					 FROM dbo.ICS_PRMT_REISSU R 
					WHERE R.TRANSACTION_TYPE IS NOT NULL
					  AND R.PRMT_IDENT = BP.PRMT_IDENT
					  AND R.PRMT_EFFECTIVE_DATE > BP.PRMT_EFFECTIVE_DATE)
	AND BP.TRANSACTION_TYPE IS NOT NULL

	 UPDATE GP
	 SET TRANSACTION_TYPE = NULL
	 FROM dbo.ICS_GNRL_PRMT GP
	 WHERE EXISTS (SELECT 1 
					 FROM dbo.ICS_PRMT_REISSU R 
					WHERE R.TRANSACTION_TYPE IS NOT NULL
					  AND R.PRMT_IDENT = GP.PRMT_IDENT
					  AND R.PRMT_EFFECTIVE_DATE > GP.PRMT_EFFECTIVE_DATE)
	  AND GP.TRANSACTION_TYPE IS NOT NULL

END;

END