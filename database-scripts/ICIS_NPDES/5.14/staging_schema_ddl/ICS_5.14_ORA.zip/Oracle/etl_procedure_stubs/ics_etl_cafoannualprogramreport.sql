﻿
/*************************************************************************************************
** ObjectName: ics_etl_CAFOAnnualProgramReportSubmission
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the CAFOAnnualProgramReportSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/18/2025   Windsor      Created 
**
***************************************************************************************************/
CREATE OR REPLACE PROCEDURE ICS_FLOW_LOCAL.ics_etl_CAFOAnnualProgramReportSubmission

AS

BEGIN
---------------------------- 
-- ICS_CAFO_ANNUL_PROG_REP
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- 
DELETE
  FROM ICS_FLOW_LOCAL.ICS_CAFO_ANNUL_PROG_REP;


-- /ICS_CAFO_ANNUL_PROG_REP
INSERT INTO ICS_FLOW_LOCAL.ICS_CAFO_ANNUL_PROG_REP (
     ICS_CAFO_ANNUL_PROG_REP_ID
   , ICS_PAYLOAD_ID
   , SRC_SYSTM_IDENT
   , TRANSACTION_TYPE
   , TRANSACTION_TIMESTAMP
   , PRMT_IDENT
   , PROG_REP_FORM_SET_ID
   , PROG_REP_FORM_ID
   , PROG_REP_RCVD_DATE
   , PROG_REP_START_DATE
   , PROG_REP_END_DATE
   , ELEC_SUBM_TYPE_CODE
   , PROG_REP_NPDES_DAT_GRP_NUM_CODE
   , NUTR_MGMT_PLAN_ACREAGE_NUM
   , ACTUL_LAND_APPL_ACREAGE_NUM
   , NMP_CERT_PLNR_IND
   , KEY_HASH
   , DATA_HASH)
SELECT 
     null  --ICS_CAFO_ANNUL_PROG_REP_ID, 
   , null  --ICS_PAYLOAD_ID, 
   , null  --SRC_SYSTM_IDENT, SourceSystemIdentifier
   , null  --TRANSACTION_TYPE, TransactionType
   , null  --TRANSACTION_TIMESTAMP, TransactionTimestamp
   , null  --PRMT_IDENT, PermitIdentifier
   , null  --PROG_REP_FORM_SET_ID, ProgramReportFormSetID
   , null  --PROG_REP_FORM_ID, ProgramReportFormID
   , null  --PROG_REP_RCVD_DATE, ProgramReportReceivedDate
   , null  --PROG_REP_START_DATE, ProgramReportStartDate
   , null  --PROG_REP_END_DATE, ProgramReportEndDate
   , null  --ELEC_SUBM_TYPE_CODE, ElectronicSubmissionTypeCode
   , null  --PROG_REP_NPDES_DAT_GRP_NUM_CODE, ProgramReportNPDESDataGroupNumberCode
   , null  --NUTR_MGMT_PLAN_ACREAGE_NUM, NutrientManagementPlanAcreageNumber
   , null  --ACTUL_LAND_APPL_ACREAGE_NUM, ActualLandApplicationAcreageNumber
   , null  --NMP_CERT_PLNR_IND, NMPCertifiedPlannerIndicator
   , null  --KEY_HASH, 
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CAFO_ANNUL_PROG_REP/ICS_ANML_TYPE
INSERT INTO ICS_FLOW_LOCAL.ICS_ANML_TYPE (
     ICS_ANML_TYPE_ID
   , ICS_CAFO_ANNUL_PROG_REP_ID
   , ICS_CAFO_PRMT_ID
   , ICS_CAFO_INSP_ID
   , ANML_TYPE_CODE
   , OTHR_ANML_TYPE_NAME
   , TTL_NUM_EACH_LVSTCK
   , OPEN_CONFINEMNT_CNT
   , HOUSD_UNDR_ROOF_CONFINEMNT_CNT
   , LIQUID_MNUR_HANDLING_SYSTM
   , DATA_HASH)
SELECT 
     null  --ICS_ANML_TYPE_ID, 
   , null  --ICS_CAFO_ANNUL_PROG_REP_ID, 
   , null  --ICS_CAFO_PRMT_ID, 
   , null  --ICS_CAFO_INSP_ID, 
   , null  --ANML_TYPE_CODE, AnimalTypeCode
   , null  --OTHR_ANML_TYPE_NAME, OtherAnimalTypeName
   , null  --TTL_NUM_EACH_LVSTCK, TotalNumbersEachLivestock
   , null  --OPEN_CONFINEMNT_CNT, OpenConfinementCount
   , null  --HOUSD_UNDR_ROOF_CONFINEMNT_CNT, HousedUnderRoofConfinementCount
   , null  --LIQUID_MNUR_HANDLING_SYSTM, LiquidManureHandlingSystem
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CAFO_ANNUL_PROG_REP/ICS_CAFO_LAND_APPL_FLD_INFO
INSERT INTO ICS_FLOW_LOCAL.ICS_CAFO_LAND_APPL_FLD_INFO (
     ICS_CAFO_LAND_APPL_FLD_INFO_ID
   , ICS_CAFO_ANNUL_PROG_REP_ID
   , CAFO_LAND_APPL_FLD_IDENT
   , CAFO_LAND_APPL_FLD_ACREAGE
   , CAFOMLPW_MAX_AMT_METHOD
   , CAFO_LAND_APPL_FLD_CROP_IDENT
   , CAFO_LAND_APPL_FLD_CROP_CODE
   , CAFO_LAND_APPL_FLD_CROP_YIELD
   , CAFO_LAND_APPL_FLD_CROP_YIELD_UNIT
   , CAFO_LAND_APPL_FLD_CROP_SEEDED
   , CAFO_SOIL_MON_MEAS_FORM
   , CAFO_SOIL_MON_MEAS_VALUE
   , CAFO_SOIL_MON_MEAS_VALUE_UNIT
   , CAFO_SOIL_MON_ANLYTCL_METHOD
   , CAFO_SOIL_MON_SMPL_DEPTH_INCHES
   , CAFO_SOIL_MON_SMPL_DATE
   , CAFO_SUPPL_FERTILIZER_MEAS_FORM
   , CAFO_SUPPL_FERTILIZER_MEAS_VALUE
   , CAFO_SUPPL_FERTILIZER_MEAS_VALUE_UNIT
   , DATA_HASH)
SELECT 
     null  --ICS_CAFO_LAND_APPL_FLD_INFO_ID, 
   , null  --ICS_CAFO_ANNUL_PROG_REP_ID, 
   , null  --CAFO_LAND_APPL_FLD_IDENT, CAFOLandApplicationFieldIdentifier
   , null  --CAFO_LAND_APPL_FLD_ACREAGE, CAFOLandApplicationFieldAcreage
   , null  --CAFOMLPW_MAX_AMT_METHOD, CAFOMLPWMaximumAmountMethod
   , null  --CAFO_LAND_APPL_FLD_CROP_IDENT, CAFOLandApplicationFieldCropIdentifier
   , null  --CAFO_LAND_APPL_FLD_CROP_CODE, CAFOLandApplicationFieldCropCode
   , null  --CAFO_LAND_APPL_FLD_CROP_YIELD, CAFOLandApplicationFieldCropYield
   , null  --CAFO_LAND_APPL_FLD_CROP_YIELD_UNIT, CAFOLandApplicationFieldCropYieldUnit
   , null  --CAFO_LAND_APPL_FLD_CROP_SEEDED, CAFOLandApplicationFieldCropSeeded
   , null  --CAFO_SOIL_MON_MEAS_FORM, CAFOSoilMonitoringMeasurementForm
   , null  --CAFO_SOIL_MON_MEAS_VALUE, CAFOSoilMonitoringMeasurementValue
   , null  --CAFO_SOIL_MON_MEAS_VALUE_UNIT, CAFOSoilMonitoringMeasurementValueUnit
   , null  --CAFO_SOIL_MON_ANLYTCL_METHOD, CAFOSoilMonitoringAnalyticalMethod
   , null  --CAFO_SOIL_MON_SMPL_DEPTH_INCHES, CAFOSoilMonitoringSampleDepthInches
   , null  --CAFO_SOIL_MON_SMPL_DATE, CAFOSoilMonitoringSampleDate
   , null  --CAFO_SUPPL_FERTILIZER_MEAS_FORM, CAFOSupplementalFertilizerMeasurementForm
   , null  --CAFO_SUPPL_FERTILIZER_MEAS_VALUE, CAFOSupplementalFertilizerMeasurementValue
   , null  --CAFO_SUPPL_FERTILIZER_MEAS_VALUE_UNIT, CAFOSupplementalFertilizerMeasurementValueUnit
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CAFO_ANNUL_PROG_REP/ICS_CAFO_LAND_APPL_FLD_INFO/ICS_CAFOMLPW_FLD_AMOUNTS
INSERT INTO ICS_FLOW_LOCAL.ICS_CAFOMLPW_FLD_AMOUNTS (
     ICS_CAFOMLPW_FLD_AMOUNTS_ID
   , ICS_CAFO_LAND_APPL_FLD_INFO_ID
   , CAFOMLPW_CODE
   , CAFOMLPW_FLD_MAX_ALLOWABLE_AMT
   , CAFOMLPW_FLD_ACTUL_AMT
   , CAFOMLPW_LAND_APPL_UNIT
   , DATA_HASH)
SELECT 
     null  --ICS_CAFOMLPW_FLD_AMOUNTS_ID, 
   , null  --ICS_CAFO_LAND_APPL_FLD_INFO_ID, 
   , null  --CAFOMLPW_CODE, CAFOMLPWCode
   , null  --CAFOMLPW_FLD_MAX_ALLOWABLE_AMT, CAFOMLPWFieldMaxAllowableAmount
   , null  --CAFOMLPW_FLD_ACTUL_AMT, CAFOMLPWFieldActualAmount
   , null  --CAFOMLPW_LAND_APPL_UNIT, CAFOMLPWLandApplicationUnit
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CAFO_ANNUL_PROG_REP/ICS_CAFO_PROD_AREA_DSCH
INSERT INTO ICS_FLOW_LOCAL.ICS_CAFO_PROD_AREA_DSCH (
     ICS_CAFO_PROD_AREA_DSCH_ID
   , ICS_CAFO_ANNUL_PROG_REP_ID
   , CAFO_PROD_AREA_DSCH_DISCOVERY_DATE
   , CAFO_PROD_AREA_DSCH_24HR_RAIN_EVT_IND
   , CAFO_PROD_AREA_DSCH_DURATION_HOURS
   , CAFO_PROD_AREA_DSCH_VOL_GAL
   , DATA_HASH)
SELECT 
     null  --ICS_CAFO_PROD_AREA_DSCH_ID, 
   , null  --ICS_CAFO_ANNUL_PROG_REP_ID, 
   , null  --CAFO_PROD_AREA_DSCH_DISCOVERY_DATE, CAFOProductionAreaDischargeDiscoveryDate
   , null  --CAFO_PROD_AREA_DSCH_24HR_RAIN_EVT_IND, CAFOProductionAreaDischarge24hrRainEventIndicator
   , null  --CAFO_PROD_AREA_DSCH_DURATION_HOURS, CAFOProductionAreaDischargeDurationHours
   , null  --CAFO_PROD_AREA_DSCH_VOL_GAL, CAFOProductionAreaDischargeVolumeGallons
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CAFO_ANNUL_PROG_REP/ICS_CAFOMLPW_NUTR_MON
INSERT INTO ICS_FLOW_LOCAL.ICS_CAFOMLPW_NUTR_MON (
     ICS_CAFOMLPW_NUTR_MON_ID
   , ICS_CAFO_ANNUL_PROG_REP_ID
   , CAFOMLPW_CODE
   , CAFOMLPW_NUTR_FORM
   , CAFOMLPW_NUTR_VALUE
   , CAFOMLPW_NUTR_VALUE_UNIT
   , DATA_HASH)
SELECT 
     null  --ICS_CAFOMLPW_NUTR_MON_ID, 
   , null  --ICS_CAFO_ANNUL_PROG_REP_ID, 
   , null  --CAFOMLPW_CODE, CAFOMLPWCode
   , null  --CAFOMLPW_NUTR_FORM, CAFOMLPWNutrientForm
   , null  --CAFOMLPW_NUTR_VALUE, CAFOMLPWNutrientValue
   , null  --CAFOMLPW_NUTR_VALUE_UNIT, CAFOMLPWNutrientValueUnit
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CAFO_ANNUL_PROG_REP/ICS_CAFOMLPW_TTL_AMOUNTS
INSERT INTO ICS_FLOW_LOCAL.ICS_CAFOMLPW_TTL_AMOUNTS (
     ICS_CAFOMLPW_TTL_AMOUNTS_ID
   , ICS_CAFO_ANNUL_PROG_REP_ID
   , ICS_CAFO_PRMT_ID
   , CAFOMLPW_CODE
   , CAFOMLPW_AMT_GNRTD
   , CAFOMLPW_AMT_TRANSFERRED
   , CAFOMLPW_UNIT
   , DATA_HASH)
SELECT 
     null  --ICS_CAFOMLPW_TTL_AMOUNTS_ID, 
   , null  --ICS_CAFO_ANNUL_PROG_REP_ID, 
   , null  --ICS_CAFO_PRMT_ID, 
   , null  --CAFOMLPW_CODE, CAFOMLPWCode
   , null  --CAFOMLPW_AMT_GNRTD, CAFOMLPWAmountGenerated
   , null  --CAFOMLPW_AMT_TRANSFERRED, CAFOMLPWAmountTransferred
   , null  --CAFOMLPW_UNIT, CAFOMLPWUnit
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

END;
