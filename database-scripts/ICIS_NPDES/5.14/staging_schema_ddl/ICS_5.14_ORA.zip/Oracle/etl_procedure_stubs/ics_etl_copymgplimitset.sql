﻿
/*************************************************************************************************
** ObjectName: ics_etl_CopyMGPLimitSetSubmission
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the CopyMGPLimitSetSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/18/2025   Windsor      Created 
**
***************************************************************************************************/
CREATE OR REPLACE PROCEDURE ICS_FLOW_LOCAL.ics_etl_CopyMGPLimitSetSubmission

AS

BEGIN
---------------------------- 
-- ICS_COPY_MGP_LMT_SET
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- 
DELETE
  FROM ICS_FLOW_LOCAL.ICS_COPY_MGP_LMT_SET;


-- /ICS_COPY_MGP_LMT_SET
INSERT INTO ICS_FLOW_LOCAL.ICS_COPY_MGP_LMT_SET (
     ICS_COPY_MGP_LMT_SET_ID
   , ICS_PAYLOAD_ID
   , SRC_SYSTM_IDENT
   , TRANSACTION_TYPE
   , TRANSACTION_TIMESTAMP
   , PRMT_IDENT
   , PRMT_FEATR_IDENT
   , LMT_SET_DESIGNATOR
   , TRGT_GNRL_PRMT_IDENT
   , TRGT_GNRL_PRMT_FEATR_IDENT
   , TRGT_GNRL_LMT_SET_DESIGNATOR
   , PRMT_FEATR_TYPE_CODE
   , PRMT_FEATR_DESC
   , PRMT_FEATR_ST_WTR_BODY_NAME
   , IMPAIRED_WTR_IND
   , TMDL_COMPLETED_IND
   , PRMT_FEATR_USR_DFND_DAT_ELM_1
   , PRMT_FEATR_USR_DFND_DAT_ELM_2
   , LMT_SET_NAME_TXT
   , DMR_PRE_PRINT_CMNTS_TXT
   , KEY_HASH
   , DATA_HASH)
SELECT 
     null  --ICS_COPY_MGP_LMT_SET_ID, 
   , null  --ICS_PAYLOAD_ID, 
   , null  --SRC_SYSTM_IDENT, SourceSystemIdentifier
   , null  --TRANSACTION_TYPE, TransactionType
   , null  --TRANSACTION_TIMESTAMP, TransactionTimestamp
   , null  --PRMT_IDENT, PermitIdentifier
   , null  --PRMT_FEATR_IDENT, PermittedFeatureIdentifier
   , null  --LMT_SET_DESIGNATOR, LimitSetDesignator
   , null  --TRGT_GNRL_PRMT_IDENT, TargetGeneralPermitIdentifier
   , null  --TRGT_GNRL_PRMT_FEATR_IDENT, TargetGeneralPermittedFeatureIdentifier
   , null  --TRGT_GNRL_LMT_SET_DESIGNATOR, TargetGeneralLimitSetDesignator
   , null  --PRMT_FEATR_TYPE_CODE, PermittedFeatureTypeCode
   , null  --PRMT_FEATR_DESC, PermittedFeatureDescription
   , null  --PRMT_FEATR_ST_WTR_BODY_NAME, PermittedFeatureStateWaterBodyName
   , null  --IMPAIRED_WTR_IND, ImpairedWaterIndicator
   , null  --TMDL_COMPLETED_IND, TMDLCompletedIndicator
   , null  --PRMT_FEATR_USR_DFND_DAT_ELM_1, PermittedFeatureUserDefinedDataElement1
   , null  --PRMT_FEATR_USR_DFND_DAT_ELM_2, PermittedFeatureUserDefinedDataElement2
   , null  --LMT_SET_NAME_TXT, LimitSetNameText
   , null  --DMR_PRE_PRINT_CMNTS_TXT, DMRPrePrintCommentsText
   , null  --KEY_HASH, 
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_COPY_MGP_LMT_SET/ICS_GEO_COORD
INSERT INTO ICS_FLOW_LOCAL.ICS_GEO_COORD (
     ICS_GEO_COORD_ID
   , ICS_FAC_ID
   , ICS_COPY_MGP_LMT_SET_ID
   , ICS_PRMT_FEATR_ID
   , ICS_UNPRMT_FAC_ID
   , LAT_MEAS
   , LONG_MEAS
   , HORZ_ACCURACY_MEAS
   , GEOMETRIC_TYPE_CODE
   , HORZ_COLL_METHOD_CODE
   , HORZ_REF_DATUM_CODE
   , REF_POINT_CODE
   , SRC_MAP_SCALE_NUM
   , DATA_HASH)
SELECT 
     null  --ICS_GEO_COORD_ID, 
   , null  --ICS_FAC_ID, 
   , null  --ICS_COPY_MGP_LMT_SET_ID, 
   , null  --ICS_PRMT_FEATR_ID, 
   , null  --ICS_UNPRMT_FAC_ID, 
   , null  --LAT_MEAS, LatitudeMeasure
   , null  --LONG_MEAS, LongitudeMeasure
   , null  --HORZ_ACCURACY_MEAS, HorizontalAccuracyMeasure
   , null  --GEOMETRIC_TYPE_CODE, GeometricTypeCode
   , null  --HORZ_COLL_METHOD_CODE, HorizontalCollectionMethodCode
   , null  --HORZ_REF_DATUM_CODE, HorizontalReferenceDatumCode
   , null  --REF_POINT_CODE, ReferencePointCode
   , null  --SRC_MAP_SCALE_NUM, SourceMapScaleNumber
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_COPY_MGP_LMT_SET/ICS_LMT_SET_SCHD
INSERT INTO ICS_FLOW_LOCAL.ICS_LMT_SET_SCHD (
     ICS_LMT_SET_SCHD_ID
   , ICS_COPY_MGP_LMT_SET_ID
   , ICS_LMT_SET_ID
   , NUM_UNITS_REP_PERIOD_INTEGER
   , NUM_SUBM_UNITS_INTEGER
   , INITIAL_MON_DATE
   , INITIAL_DMR_DUE_DATE
   , LMT_SET_MOD_TYPE_CODE
   , LMT_SET_MOD_EFFECTIVE_DATE
   , DATA_HASH)
SELECT 
     null  --ICS_LMT_SET_SCHD_ID, 
   , null  --ICS_COPY_MGP_LMT_SET_ID, 
   , null  --ICS_LMT_SET_ID, 
   , null  --NUM_UNITS_REP_PERIOD_INTEGER, NumberUnitsReportPeriodInteger
   , null  --NUM_SUBM_UNITS_INTEGER, NumberSubmissionUnitsInteger
   , null  --INITIAL_MON_DATE, InitialMonitoringDate
   , null  --INITIAL_DMR_DUE_DATE, InitialDMRDueDate
   , null  --LMT_SET_MOD_TYPE_CODE, LimitSetModificationTypeCode
   , null  --LMT_SET_MOD_EFFECTIVE_DATE, LimitSetModificationEffectiveDate
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_COPY_MGP_LMT_SET/ICS_LMT_SET_STAT
INSERT INTO ICS_FLOW_LOCAL.ICS_LMT_SET_STAT (
     ICS_LMT_SET_STAT_ID
   , ICS_COPY_MGP_LMT_SET_ID
   , ICS_LMT_SET_ID
   , LMT_SET_STAT_IND
   , LMT_SET_STAT_START_DATE
   , LMT_SET_STAT_REASON_TXT
   , DATA_HASH)
SELECT 
     null  --ICS_LMT_SET_STAT_ID, 
   , null  --ICS_COPY_MGP_LMT_SET_ID, 
   , null  --ICS_LMT_SET_ID, 
   , null  --LMT_SET_STAT_IND, LimitSetStatusIndicator
   , null  --LMT_SET_STAT_START_DATE, LimitSetStatusStartDate
   , null  --LMT_SET_STAT_REASON_TXT, LimitSetStatusReasonText
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

END;
