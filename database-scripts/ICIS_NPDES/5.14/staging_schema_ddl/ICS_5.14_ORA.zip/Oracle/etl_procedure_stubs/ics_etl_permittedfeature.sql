﻿
/*************************************************************************************************
** ObjectName: ics_etl_PermittedFeatureSubmission
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the PermittedFeatureSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/18/2025   Windsor      Created 
**
***************************************************************************************************/
CREATE OR REPLACE PROCEDURE ICS_FLOW_LOCAL.ics_etl_PermittedFeatureSubmission

AS

BEGIN
---------------------------- 
-- ICS_PRMT_FEATR
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- 
DELETE
  FROM ICS_FLOW_LOCAL.ICS_PRMT_FEATR;


-- /ICS_PRMT_FEATR
INSERT INTO ICS_FLOW_LOCAL.ICS_PRMT_FEATR (
     ICS_PRMT_FEATR_ID
   , ICS_PAYLOAD_ID
   , SRC_SYSTM_IDENT
   , TRANSACTION_TYPE
   , TRANSACTION_TIMESTAMP
   , PRMT_IDENT
   , PRMT_FEATR_IDENT
   , PRMT_FEATR_TYPE_CODE
   , PRMT_FEATR_DESC
   , PRMT_FEATR_DSGN_FLOW_NUM
   , PRMT_FEATR_ACTUL_AVER_FLOW_NUM
   , PRMT_FEATR_ST_WTR_BODY_CODE
   , PRMT_FEATR_ST_WTR_BODY_NAME
   , TIER_LEVEL_NAME
   , IMPAIRED_WTR_IND
   , TMDL_COMPLETED_IND
   , PRMT_FEATR_USR_DFND_DAT_ELM_1
   , PRMT_FEATR_USR_DFND_DAT_ELM_2
   , FLD_SIZE
   , IS_SITE_OWN_BY_FAC
   , IS_SYSTM_LINED_WITH_LEACHATE
   , DOES_UNIT_HAV_DAILY_COVER
   , PROP_BOUNDARY_DISTANCE
   , IS_REQD_NITRATE_GROUND_WTR
   , WELL_NUM
   , SRC_PRMT_FEATR_DETAIL_TXT
   , KEY_HASH
   , DATA_HASH)
SELECT 
     null  --ICS_PRMT_FEATR_ID, 
   , null  --ICS_PAYLOAD_ID, 
   , null  --SRC_SYSTM_IDENT, SourceSystemIdentifier
   , null  --TRANSACTION_TYPE, TransactionType
   , null  --TRANSACTION_TIMESTAMP, TransactionTimestamp
   , null  --PRMT_IDENT, PermitIdentifier
   , null  --PRMT_FEATR_IDENT, PermittedFeatureIdentifier
   , null  --PRMT_FEATR_TYPE_CODE, PermittedFeatureTypeCode
   , null  --PRMT_FEATR_DESC, PermittedFeatureDescription
   , null  --PRMT_FEATR_DSGN_FLOW_NUM, PermittedFeatureDesignFlowNumber
   , null  --PRMT_FEATR_ACTUL_AVER_FLOW_NUM, PermittedFeatureActualAverageFlowNumber
   , null  --PRMT_FEATR_ST_WTR_BODY_CODE, PermittedFeatureStateWaterBodyCode
   , null  --PRMT_FEATR_ST_WTR_BODY_NAME, PermittedFeatureStateWaterBodyName
   , null  --TIER_LEVEL_NAME, TierLevelName
   , null  --IMPAIRED_WTR_IND, ImpairedWaterIndicator
   , null  --TMDL_COMPLETED_IND, TMDLCompletedIndicator
   , null  --PRMT_FEATR_USR_DFND_DAT_ELM_1, PermittedFeatureUserDefinedDataElement1
   , null  --PRMT_FEATR_USR_DFND_DAT_ELM_2, PermittedFeatureUserDefinedDataElement2
   , null  --FLD_SIZE, FieldSize
   , null  --IS_SITE_OWN_BY_FAC, IsSiteOwnByFacility
   , null  --IS_SYSTM_LINED_WITH_LEACHATE, IsSystemLinedWithLeachate
   , null  --DOES_UNIT_HAV_DAILY_COVER, DoesUnitHaveDailyCover
   , null  --PROP_BOUNDARY_DISTANCE, PropertyBoundaryDistance
   , null  --IS_REQD_NITRATE_GROUND_WTR, IsRequiredNitrateGroundWater
   , null  --WELL_NUM, WellNumber
   , null  --SRC_PRMT_FEATR_DETAIL_TXT, SourcePermittedFeatureDetailText
   , null  --KEY_HASH, 
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_PRMT_FEATR/ICS_ADDR
INSERT INTO ICS_FLOW_LOCAL.ICS_ADDR (
     ICS_ADDR_ID
   , ICS_FAC_ID
   , ICS_BASIC_PRMT_ID
   , ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID
   , ICS_CAFO_PRMT_ID
   , ICS_GNRL_PRMT_ID
   , ICS_PRMT_FEATR_ID
   , ICS_SW_CNST_PRMT_ID
   , ICS_SW_INDST_PRMT_ID
   , ICS_UNPRMT_FAC_ID
   , AFFIL_TYPE_TXT
   , ORG_FRML_NAME
   , ORG_DUNS_NUM
   , MAILING_ADDR_TXT
   , SUPPL_ADDR_TXT
   , MAILING_ADDR_CITY_NAME
   , MAILING_ADDR_ST_CODE
   , MAILING_ADDR_ZIP_CODE
   , COUNTY_NAME
   , MAILING_ADDR_COUNTRY_CODE
   , DIVISION_NAME
   , LOC_PROVINCE
   , ELEC_ADDR_TXT
   , START_DATE_OF_ADDR_ASSC
   , END_DATE_OF_ADDR_ASSC
   , DATA_HASH)
SELECT 
     null  --ICS_ADDR_ID, 
   , null  --ICS_FAC_ID, 
   , null  --ICS_BASIC_PRMT_ID, 
   , null  --ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID, 
   , null  --ICS_CAFO_PRMT_ID, 
   , null  --ICS_GNRL_PRMT_ID, 
   , null  --ICS_PRMT_FEATR_ID, 
   , null  --ICS_SW_CNST_PRMT_ID, 
   , null  --ICS_SW_INDST_PRMT_ID, 
   , null  --ICS_UNPRMT_FAC_ID, 
   , null  --AFFIL_TYPE_TXT, AffiliationTypeText
   , null  --ORG_FRML_NAME, OrganizationFormalName
   , null  --ORG_DUNS_NUM, OrganizationDUNSNumber
   , null  --MAILING_ADDR_TXT, MailingAddressText
   , null  --SUPPL_ADDR_TXT, SupplementalAddressText
   , null  --MAILING_ADDR_CITY_NAME, MailingAddressCityName
   , null  --MAILING_ADDR_ST_CODE, MailingAddressStateCode
   , null  --MAILING_ADDR_ZIP_CODE, MailingAddressZipCode
   , null  --COUNTY_NAME, CountyName
   , null  --MAILING_ADDR_COUNTRY_CODE, MailingAddressCountryCode
   , null  --DIVISION_NAME, DivisionName
   , null  --LOC_PROVINCE, LocationProvince
   , null  --ELEC_ADDR_TXT, ElectronicAddressText
   , null  --START_DATE_OF_ADDR_ASSC, StartDateOfAddressAssociation
   , null  --END_DATE_OF_ADDR_ASSC, EndDateOfAddressAssociation
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_PRMT_FEATR/ICS_ADDR/ICS_TELEPH
INSERT INTO ICS_FLOW_LOCAL.ICS_TELEPH (
     ICS_TELEPH_ID
   , ICS_CONTACT_ID
   , ICS_ADDR_ID
   , ICS_EFFLU_TRADE_PRTNER_ADDR_ID
   , TELEPH_NUM_TYPE_CODE
   , TELEPH_NUM
   , TELEPH_EXT_NUM
   , DATA_HASH)
SELECT 
     null  --ICS_TELEPH_ID, 
   , null  --ICS_CONTACT_ID, 
   , null  --ICS_ADDR_ID, 
   , null  --ICS_EFFLU_TRADE_PRTNER_ADDR_ID, 
   , null  --TELEPH_NUM_TYPE_CODE, TelephoneNumberTypeCode
   , null  --TELEPH_NUM, TelephoneNumber
   , null  --TELEPH_EXT_NUM, TelephoneExtensionNumber
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_PRMT_FEATR/ICS_CONTACT
INSERT INTO ICS_FLOW_LOCAL.ICS_CONTACT (
     ICS_CONTACT_ID
   , ICS_FAC_ID
   , ICS_BASIC_PRMT_ID
   , ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID
   , ICS_CAFO_PRMT_ID
   , ICS_CMPL_MON_ID
   , ICS_GNRL_PRMT_ID
   , ICS_MASTER_GNRL_PRMT_ID
   , ICS_PRMT_FEATR_ID
   , ICS_PRETR_PRMT_ID
   , ICS_SW_CNST_PRMT_ID
   , ICS_SW_INDST_PRMT_ID
   , ICS_UNPRMT_FAC_ID
   , AFFIL_TYPE_TXT
   , FIRST_NAME
   , MIDDLE_NAME
   , LAST_NAME
   , INDVL_TITLE_TXT
   , ORG_FRML_NAME
   , ST_CODE
   , RGN_CODE
   , ELEC_ADDR_TXT
   , START_DATE_OF_CONTACT_ASSC
   , END_DATE_OF_CONTACT_ASSC
   , DATA_HASH)
SELECT 
     null  --ICS_CONTACT_ID, 
   , null  --ICS_FAC_ID, 
   , null  --ICS_BASIC_PRMT_ID, 
   , null  --ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID, 
   , null  --ICS_CAFO_PRMT_ID, 
   , null  --ICS_CMPL_MON_ID, 
   , null  --ICS_GNRL_PRMT_ID, 
   , null  --ICS_MASTER_GNRL_PRMT_ID, 
   , null  --ICS_PRMT_FEATR_ID, 
   , null  --ICS_PRETR_PRMT_ID, 
   , null  --ICS_SW_CNST_PRMT_ID, 
   , null  --ICS_SW_INDST_PRMT_ID, 
   , null  --ICS_UNPRMT_FAC_ID, 
   , null  --AFFIL_TYPE_TXT, AffiliationTypeText
   , null  --FIRST_NAME, FirstName
   , null  --MIDDLE_NAME, MiddleName
   , null  --LAST_NAME, LastName
   , null  --INDVL_TITLE_TXT, IndividualTitleText
   , null  --ORG_FRML_NAME, OrganizationFormalName
   , null  --ST_CODE, StateCode
   , null  --RGN_CODE, RegionCode
   , null  --ELEC_ADDR_TXT, ElectronicAddressText
   , null  --START_DATE_OF_CONTACT_ASSC, StartDateOfContactAssociation
   , null  --END_DATE_OF_CONTACT_ASSC, EndDateOfContactAssociation
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_PRMT_FEATR/ICS_CONTACT/ICS_TELEPH
INSERT INTO ICS_FLOW_LOCAL.ICS_TELEPH (
     ICS_TELEPH_ID
   , ICS_CONTACT_ID
   , ICS_ADDR_ID
   , ICS_EFFLU_TRADE_PRTNER_ADDR_ID
   , TELEPH_NUM_TYPE_CODE
   , TELEPH_NUM
   , TELEPH_EXT_NUM
   , DATA_HASH)
SELECT 
     null  --ICS_TELEPH_ID, 
   , null  --ICS_CONTACT_ID, 
   , null  --ICS_ADDR_ID, 
   , null  --ICS_EFFLU_TRADE_PRTNER_ADDR_ID, 
   , null  --TELEPH_NUM_TYPE_CODE, TelephoneNumberTypeCode
   , null  --TELEPH_NUM, TelephoneNumber
   , null  --TELEPH_EXT_NUM, TelephoneExtensionNumber
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_PRMT_FEATR/ICS_COOLING_WTR_INTAKE_STRCT_INFO
INSERT INTO ICS_FLOW_LOCAL.ICS_COOLING_WTR_INTAKE_STRCT_INFO (
     ICS_COOLING_WTR_INTAKE_STRCT_INFO_ID
   , ICS_PRMT_FEATR_ID
   , COOLING_WTR_INTAKE_STRCT_APPL_SUBPART
   , COOLING_WTR_INTAKE_STRCT_DSGN_INTAKE_FLOW
   , COOLING_WTR_INTAKE_STRCT_ACTUL_INTAKE_FLOW
   , COOLING_WTR_ACTUL_INTAKE_STRCT_VELOCITY
   , SRC_WTR_BASELINE_BIOLOGICAL_CHARACTERIZATION
   , COOLING_WTR_INTAKE_STRCT_LOC_CODE
   , COOLING_WTR_INTAKE_STRCT_LOC_TXT
   , COOLING_WTR_INTAKE_STRCT_SRC_WTR_CODE
   , COOLING_WTR_INTAKE_STRCT_SRC_WTR_TXT
   , DATA_HASH)
SELECT 
     null  --ICS_COOLING_WTR_INTAKE_STRCT_INFO_ID, 
   , null  --ICS_PRMT_FEATR_ID, 
   , null  --COOLING_WTR_INTAKE_STRCT_APPL_SUBPART, CoolingWaterIntakeStructureApplicableSubpart
   , null  --COOLING_WTR_INTAKE_STRCT_DSGN_INTAKE_FLOW, CoolingWaterIntakeStructureDesignIntakeFlow
   , null  --COOLING_WTR_INTAKE_STRCT_ACTUL_INTAKE_FLOW, CoolingWaterIntakeStructureActualIntakeFlow
   , null  --COOLING_WTR_ACTUL_INTAKE_STRCT_VELOCITY, CoolingWaterActualIntakeStructureVelocity
   , null  --SRC_WTR_BASELINE_BIOLOGICAL_CHARACTERIZATION, SourceWaterBaselineBiologicalCharacterization
   , null  --COOLING_WTR_INTAKE_STRCT_LOC_CODE, CoolingWaterIntakeStructureLocationCode
   , null  --COOLING_WTR_INTAKE_STRCT_LOC_TXT, CoolingWaterIntakeStructureLocationText
   , null  --COOLING_WTR_INTAKE_STRCT_SRC_WTR_CODE, CoolingWaterIntakeStructureSourceWaterCode
   , null  --COOLING_WTR_INTAKE_STRCT_SRC_WTR_TXT, CoolingWaterIntakeStructureSourceWaterText
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_PRMT_FEATR/ICS_COOLING_WTR_INTAKE_STRCT_INFO/ICS_COOLING_WTR_INTAKE_STRCT_CMPL_METHOD
INSERT INTO ICS_FLOW_LOCAL.ICS_COOLING_WTR_INTAKE_STRCT_CMPL_METHOD (
     ICS_COOLING_WTR_INTAKE_STRCT_CMPL_METHOD_ID
   , ICS_COOLING_WTR_INTAKE_STRCT_INFO_ID
   , COOLING_WTR_INTAKE_STRCT_CMPL_METHOD_CODE
   , COOLING_WTR_INTAKE_STRCT_CMPL_METHOD_TXT
   , DATA_HASH)
SELECT 
     null  --ICS_COOLING_WTR_INTAKE_STRCT_CMPL_METHOD_ID, 
   , null  --ICS_COOLING_WTR_INTAKE_STRCT_INFO_ID, 
   , null  --COOLING_WTR_INTAKE_STRCT_CMPL_METHOD_CODE, CoolingWaterIntakeStructureComplianceMethodCode
   , null  --COOLING_WTR_INTAKE_STRCT_CMPL_METHOD_TXT, CoolingWaterIntakeStructureComplianceMethodText
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_PRMT_FEATR/ICS_GEO_COORD
INSERT INTO ICS_FLOW_LOCAL.ICS_GEO_COORD (
     ICS_GEO_COORD_ID
   , ICS_FAC_ID
   , ICS_COPY_MGP_LMT_SET_ID
   , ICS_PRMT_FEATR_ID
   , ICS_UNPRMT_FAC_ID
   , LAT_MEAS
   , LONG_MEAS
   , HORZ_ACCURACY_MEAS
   , GEOMETRIC_TYPE_CODE
   , HORZ_COLL_METHOD_CODE
   , HORZ_REF_DATUM_CODE
   , REF_POINT_CODE
   , SRC_MAP_SCALE_NUM
   , DATA_HASH)
SELECT 
     null  --ICS_GEO_COORD_ID, 
   , null  --ICS_FAC_ID, 
   , null  --ICS_COPY_MGP_LMT_SET_ID, 
   , null  --ICS_PRMT_FEATR_ID, 
   , null  --ICS_UNPRMT_FAC_ID, 
   , null  --LAT_MEAS, LatitudeMeasure
   , null  --LONG_MEAS, LongitudeMeasure
   , null  --HORZ_ACCURACY_MEAS, HorizontalAccuracyMeasure
   , null  --GEOMETRIC_TYPE_CODE, GeometricTypeCode
   , null  --HORZ_COLL_METHOD_CODE, HorizontalCollectionMethodCode
   , null  --HORZ_REF_DATUM_CODE, HorizontalReferenceDatumCode
   , null  --REF_POINT_CODE, ReferencePointCode
   , null  --SRC_MAP_SCALE_NUM, SourceMapScaleNumber
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_PRMT_FEATR/ICS_POLUT_LIST
INSERT INTO ICS_FLOW_LOCAL.ICS_POLUT_LIST (
     ICS_POLUT_LIST_ID
   , ICS_PRMT_FEATR_ID
   , DATA_HASH)
SELECT 
     null  --ICS_POLUT_LIST_ID, 
   , null  --ICS_PRMT_FEATR_ID, 
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_PRMT_FEATR/ICS_POLUT_LIST/ICS_IMPAIRED_WTR_POLLUTANTS
INSERT INTO ICS_FLOW_LOCAL.ICS_IMPAIRED_WTR_POLLUTANTS (
     ICS_IMPAIRED_WTR_POLLUTANTS_ID
   , ICS_POLUT_LIST_ID
   , IMPAIRED_WTR_POLLUTANTS
   , DATA_HASH)
SELECT 
     null  --ICS_IMPAIRED_WTR_POLLUTANTS_ID, 
   , null  --ICS_POLUT_LIST_ID, 
   , null  --IMPAIRED_WTR_POLLUTANTS, ImpairedWaterPollutants
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_PRMT_FEATR/ICS_POLUT_LIST/ICS_TMDL_POLLUTANTS
INSERT INTO ICS_FLOW_LOCAL.ICS_TMDL_POLLUTANTS (
     ICS_TMDL_POLLUTANTS_ID
   , ICS_POLUT_LIST_ID
   , TMDL_IDENT
   , TMDL_NAME
   , DATA_HASH)
SELECT 
     null  --ICS_TMDL_POLLUTANTS_ID, 
   , null  --ICS_POLUT_LIST_ID, 
   , null  --TMDL_IDENT, TMDLIdentifier
   , null  --TMDL_NAME, TMDLName
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_PRMT_FEATR/ICS_POLUT_LIST/ICS_TMDL_POLLUTANTS/ICS_TMDL_POLUT
INSERT INTO ICS_FLOW_LOCAL.ICS_TMDL_POLUT (
     ICS_TMDL_POLUT_ID
   , ICS_TMDL_POLLUTANTS_ID
   , TMDL_POLUT_CODE
   , DATA_HASH)
SELECT 
     null  --ICS_TMDL_POLUT_ID, 
   , null  --ICS_TMDL_POLLUTANTS_ID, 
   , null  --TMDL_POLUT_CODE, TMDLPollutantCode
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_PRMT_FEATR/ICS_PRMT_FEATR_CHAR
INSERT INTO ICS_FLOW_LOCAL.ICS_PRMT_FEATR_CHAR (
     ICS_PRMT_FEATR_CHAR_ID
   , ICS_PRMT_FEATR_ID
   , PRMT_FEATR_CHAR
   , DATA_HASH)
SELECT 
     null  --ICS_PRMT_FEATR_CHAR_ID, 
   , null  --ICS_PRMT_FEATR_ID, 
   , null  --PRMT_FEATR_CHAR, PermittedFeatureCharacteristics
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_PRMT_FEATR/ICS_PRMT_FEATR_TRTMNT_TYPE
INSERT INTO ICS_FLOW_LOCAL.ICS_PRMT_FEATR_TRTMNT_TYPE (
     ICS_PRMT_FEATR_TRTMNT_TYPE_ID
   , ICS_PRMT_FEATR_ID
   , PRMT_FEATR_TRTMNT_TYPE_CODE
   , DATA_HASH)
SELECT 
     null  --ICS_PRMT_FEATR_TRTMNT_TYPE_ID, 
   , null  --ICS_PRMT_FEATR_ID, 
   , null  --PRMT_FEATR_TRTMNT_TYPE_CODE, PermittedFeatureTreatmentTypeCode
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

END;
