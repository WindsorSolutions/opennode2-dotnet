
/*
This view will return a list of errors and the number of their occurance in the Last submission.
It is usefull for finding and repairing problems with flow results from ICIS.

*/

create or replace view VW_RESULT_SUMMARY
as
select 
  SUBM_TYPE_NAME
  ,RESULT_CODE
  ,COUNT(*) AS thecount
  ,MAX(RESULT_DESC) AS MAX_RESULT_DESC  
from ICS_FLOW_LOCAL.ICS_SUBM_RESULTS
where 1=1 
AND RESULT_CODE IS NOT NULL
AND RESULT_TYPE_CODE = 'Error'
AND SUBM_TRANSACTION_ID = 
(
SELECT  SUBM_TRANSACTION_ID FROM ICS_FLOw_LOCAL.ICS_SUBM_TRACK WHERE SUBM_DATE_TIME = 
(SELECT MAX(SUBM_DATE_TIME) FROM ICS_FLOw_LOCAL.ICS_SUBM_TRACK WHERE SUBM_TRANSACTION_STAT = 'Completed')
)
group by
  SUBM_TYPE_NAME
  ,RESULT_CODE
ORDER BY  
SUBM_TYPE_NAME,
COUNT(*) DESC,
SUBM_TYPE_NAME
;
