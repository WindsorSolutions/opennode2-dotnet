/*
Copyright (c) 2012, The Environmental Council of the States (ECOS)
All rights reserved.
 
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
 
 * Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
 * Neither the name of the ECOS nor the names of its contributors may
   be used to endorse or promote products derived from this software
   without specific prior written permission.
 
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/
/* ***************************
 *  Grants to ICS_FLOW_ICIS  *
 *  Grants to ICS_FLOW_ICIS  *
 *  Grants to ICS_FLOW_ICIS  *
 *****************************/
 /*****************************************************************************************************************************   
 *
 *  Script Name:  ICIS_5.0-ORA-DDL-GRANTS-ICS_FLOW_ICIS.sql
 *
 *  Company:  Windsor Solutions, Inc.
 *  
 *  Purpose:  This script grants CRUD rights for all the objects owned by ICS_FLOW_ICIS to ICS_FLOW_LOCAL
 *   
 *  Maintenance:
 *  
 *    Analyst         Date            Comment 
 *    ----------      ----------      ------------------------------------------------------------------------------
 *    Windsor         09/10/2014      Created from 4.0 baseline.
 *    Windsor         09/10/2014      Added grant on new 5.0 object ICS_SW_INDST_ANNUL_REP.
 *    Windsor         10/03/2014      Added grant on new 5.0 object ICS_SUBSCTOR_CODE_PLUS_DESC
 *    KJeffery        09/27/2016      Updates to support the ICIS 5.6 XML schema changes.
 *    KJames          09/05/2017      Added schema prefixes to the newer ICIS 5.8 database objects.
 *    WRensmith       04/02/2025      Replace with loop to grant on all objects
 *    CTyler          01/26/2026      Fix comment, run on ICIS to grant to LOCAL
 ****************************************************************************************************************************   
 */
BEGIN
  FOR t IN (SELECT table_name 
            FROM all_tables 
            WHERE owner = 'ICS_FLOW_ICIS') LOOP
    EXECUTE IMMEDIATE 'GRANT SELECT, INSERT, UPDATE, DELETE ON ICS_FLOW_ICIS.' || t.table_name || ' TO ICS_FLOW_LOCAL';
  END LOOP;
END;