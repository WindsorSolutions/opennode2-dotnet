
-- This script attempts to find permits which were fake-mirrored... that is, the data_hash in ics_flow_icis
-- was set to the value in ics_flow_local so that they will not be detected to flow. 
--
--Since this operation does not truly mirror the data, but rather only sets the data_hash on the base tables,
-- we can detect any record that has none of the necessary child tables as being a fake-mirrored record (also sometimes referd to as 'seeded'


-- LIMIT_SET
UPDATE ics_flow_icis.ICS_LMT_SET LS
SET (LS.DATA_HASH, LS.TRANSACTION_TYPE) = (
    SELECT LCL.DATA_HASH, 'M'
    FROM ICS_FLOW_LOCAL.ICS_LMT_SET LCL
    WHERE LCL.KEY_HASH = LS.KEY_HASH
)
WHERE EXISTS (
    SELECT 1 FROM ICS_FLOW_LOCAL.ICS_LMT_SET LCL WHERE LCL.KEY_HASH = LS.KEY_HASH
)
AND NOT EXISTS (
    SELECT 1 FROM ics_flow_icis.ICS_LMT_SET_SCHD LSS WHERE LSS.ICS_LMT_SET_ID = LS.ICS_LMT_SET_ID
);

-- Parameter Limits
UPDATE ics_flow_icis.ICS_PARAM_LMTS BASE
SET (BASE.DATA_HASH, BASE.TRANSACTION_TYPE) = (
    SELECT LCL.DATA_HASH, 'M'
    FROM ICS_FLOW_LOCAL.ICS_PARAM_LMTS LCL
    WHERE LCL.KEY_HASH = BASE.KEY_HASH
)
WHERE EXISTS (
    SELECT 1 FROM ICS_FLOW_LOCAL.ICS_PARAM_LMTS LCL WHERE LCL.KEY_HASH = BASE.KEY_HASH
)
AND NOT EXISTS (
    SELECT 1 FROM ics_flow_icis.ICS_LMT CHILD WHERE CHILD.ICS_PARAM_LMTS_ID = BASE.ICS_PARAM_LMTS_ID
);

-- General Permits
UPDATE ics_flow_icis.ICS_GNRL_PRMT BASE
SET (BASE.DATA_HASH, BASE.TRANSACTION_TYPE) = (
    SELECT LCL.DATA_HASH, 'M'
    FROM ICS_FLOW_LOCAL.ICS_GNRL_PRMT LCL
    WHERE LCL.KEY_HASH = BASE.KEY_HASH
)
WHERE EXISTS (
    SELECT 1 FROM ICS_FLOW_LOCAL.ICS_GNRL_PRMT LCL WHERE LCL.KEY_HASH = BASE.KEY_HASH
)
AND NOT EXISTS (
    SELECT 1 FROM ics_flow_icis.ICS_FAC CHILD WHERE CHILD.ICS_GNRL_PRMT_ID = BASE.ICS_GNRL_PRMT_ID
);

-- Basic Permit
UPDATE ics_flow_icis.ICS_BASIC_PRMT BASE
SET (BASE.DATA_HASH, BASE.TRANSACTION_TYPE) = (
    SELECT LCL.DATA_HASH, 'M'
    FROM ICS_FLOW_LOCAL.ICS_BASIC_PRMT LCL
    WHERE LCL.KEY_HASH = BASE.KEY_HASH
)
WHERE EXISTS (
    SELECT 1 FROM ICS_FLOW_LOCAL.ICS_BASIC_PRMT LCL WHERE LCL.KEY_HASH = BASE.KEY_HASH
)
AND NOT EXISTS (
    SELECT 1 FROM ics_flow_icis.ICS_FAC CHILD WHERE CHILD.ICS_BASIC_PRMT_ID = BASE.ICS_BASIC_PRMT_ID
);

commit;

