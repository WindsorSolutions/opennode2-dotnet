
/*
-- ICIS_5.14.StashAndDrop5.8Tables.sql


Run this First when upgrading from 5.8 or 5.81

Actions:
1 - Makes backups of all ICS prefixed tables as tables with the I58 refix
2 - Removes all ICS prefixed tables

*/
-- 2025-06-09 CRT - Script created


declare
   c int;
begin
       select count(*) into c from user_procedures where object_type = 'PROCEDURE' and object_name = 'ICS_SET_HASHES';
       if c = 1 then
          execute immediate 'DROP PROCEDURE ICS_SET_HASHES';
       end if;
end;
/


-- Make backup stacks of all ICIS 5.8 data 
begin
  for i in (select object_name from user_objects where object_type = 'TABLE' and OBJECT_NAME like 'ICS%')
  loop
    execute immediate 'CREATE table ' || 'I58' || SUBSTR(i.object_name,4,30) || ' as select * from ' || i.object_name;
  end loop;
end;
/

-- -------------------------------------------
-- Drop all FKs on ICS objects (Anything with ICS prefix)
-- -------------------------------------------
-- remove all FKs
begin
  for i in 
		(
		  select
			col.table_name AS TABLE_NAME,
			col.column_name as COLUMN_NAME,    
			cc.constraint_name as FK_NAME,
			rel.table_name AS FK_TABLE_NAME,
			rel.column_name as FK_COLUMN_NAME
		from
			user_tab_columns col
			join user_cons_columns con 
			  on col.table_name = con.table_name 
			 and col.column_name = con.column_name
			join user_constraints cc 
			  on con.constraint_name = cc.constraint_name
			join user_cons_columns rel 
			  on cc.r_constraint_name = rel.constraint_name 
			 and con.position = rel.position
		where
			cc.constraint_type = 'R'
			and col.table_name  like 'ICS%'
		) 
  loop
    execute immediate 	'ALTER TABLE "' || i.TABLE_NAME || '" DROP CONSTRAINT "' || i.FK_NAME || '"';
  end loop;
end;
/

      
-- -------------------------
-- Drop all ICS tables (the 5.8 ones)
-- ------------------------

begin
  for i in (select object_name from user_objects where object_type = 'TABLE' and OBJECT_NAME like 'ICS%')
  loop
    execute immediate 'drop table ' || i.object_name;
  end loop;
end;
/

-- Run 5.14 tables creation HERE


