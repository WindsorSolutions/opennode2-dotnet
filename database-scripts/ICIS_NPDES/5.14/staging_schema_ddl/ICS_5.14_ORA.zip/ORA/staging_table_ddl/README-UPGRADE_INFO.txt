Regarding upgrade of Oracle schemas from 5.8 or 5.81 to 5.14:

Due to the extensive changes with the 5.14 schema, we have modified the method of upgrading from 5.8 or 5.8.1 for Oracle.
Instead of a script that alters existing tables, the update method consists of 3 steps: 
Step 1 - Run ICIS_5.14.StashAndDrop5.8Tables.sql : This script will save all 5.8 tables into ones prefixed with I58, and remove the ICS tables from the schema.
Step 2 - Run ICIS_5.14-ORA-DDL.sql : Run ICIS_5.14.ICIS_5.14-ORA-DDL.sql to create the ICS 5.14 objects in the schema.
Step 3 - Run ICIS_5.14.RestoreData5.8To5.14.sql:  Run this to copy data, where it fits, from 5.8 to 5.14.

Only data that fits between 5.8 and 5.14 will be present after upgrade.  Specifically, only columns on table paths that are included exactly in both schemas.

This copy of data will be useful for ICS_FLOW_ICIS as it will reduce the amount of resends when starting 5.14 and retains a record of sent data. However, most data will still resend.
Since ICS_FLOW_LOCAL is cleared on each run, the I58 tables can be removed after update if desired. (Data can also be removed in ICS_FLOW_ICIS after update is complete, but recommend making sure flow is solid first)

Procedures and Views still need to be upgraded after this, as per normal upgrade procedure.
