﻿
/*************************************************************************************************
** ObjectName: ics_etl_NPDESVariancePermitSubmission
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the NPDESVariancePermitSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/18/2025   Windsor      Created 
**
***************************************************************************************************/
CREATE OR REPLACE PROCEDURE ICS_FLOW_LOCAL.ics_etl_NPDESVariancePermitSubmission

AS

BEGIN
---------------------------- 
-- ICS_NPDES_VARIANCE_PRMT
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- 
DELETE
  FROM ICS_FLOW_LOCAL.ICS_NPDES_VARIANCE_PRMT;


-- /ICS_NPDES_VARIANCE_PRMT
INSERT INTO ICS_FLOW_LOCAL.ICS_NPDES_VARIANCE_PRMT (
     ICS_NPDES_VARIANCE_PRMT_ID
   , ICS_PAYLOAD_ID
   , SRC_SYSTM_IDENT
   , TRANSACTION_TYPE
   , TRANSACTION_TIMESTAMP
   , PRMT_IDENT
   , NPDES_VARIANCE_TYPE_CODE
   , NPDES_VARIANCE_SUBM_DATE
   , NPDES_VARIANCE_VERSION_TYPE
   , NPDES_VARIANCE_STAT_CODE
   , NPDES_VARIANCE_ACTN_DATE
   , THERMAL_VARIANCE_REQUEST_PBLC_NOTICE_IND
   , NPDES_VARIANCE_CMNT_TXT
   , KEY_HASH
   , DATA_HASH)
SELECT 
     null  --ICS_NPDES_VARIANCE_PRMT_ID, 
   , null  --ICS_PAYLOAD_ID, 
   , null  --SRC_SYSTM_IDENT, SourceSystemIdentifier
   , null  --TRANSACTION_TYPE, TransactionType
   , null  --TRANSACTION_TIMESTAMP, TransactionTimestamp
   , null  --PRMT_IDENT, PermitIdentifier
   , null  --NPDES_VARIANCE_TYPE_CODE, NPDESVarianceTypeCode
   , null  --NPDES_VARIANCE_SUBM_DATE, NPDESVarianceSubmissionDate
   , null  --NPDES_VARIANCE_VERSION_TYPE, NPDESVarianceVersionType
   , null  --NPDES_VARIANCE_STAT_CODE, NPDESVarianceStatusCode
   , null  --NPDES_VARIANCE_ACTN_DATE, NPDESVarianceActionDate
   , null  --THERMAL_VARIANCE_REQUEST_PBLC_NOTICE_IND, ThermalVarianceRequestPublicNoticeIndicator
   , null  --NPDES_VARIANCE_CMNT_TXT, NPDESVarianceCommentText
   , null  --KEY_HASH, 
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

END;
