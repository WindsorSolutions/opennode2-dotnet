﻿
/*************************************************************************************************
** ObjectName: ics_etl_NarrativeConditionScheduleSubmission
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the NarrativeConditionScheduleSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/18/2025   Windsor      Created 
**
***************************************************************************************************/
CREATE OR REPLACE PROCEDURE ICS_FLOW_LOCAL.ics_etl_NarrativeConditionScheduleSubmission

AS

BEGIN
---------------------------- 
-- ICS_NARR_COND_SCHD
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- 
DELETE
  FROM ICS_FLOW_LOCAL.ICS_NARR_COND_SCHD;


-- /ICS_NARR_COND_SCHD
INSERT INTO ICS_FLOW_LOCAL.ICS_NARR_COND_SCHD (
     ICS_NARR_COND_SCHD_ID
   , ICS_PAYLOAD_ID
   , SRC_SYSTM_IDENT
   , TRANSACTION_TYPE
   , TRANSACTION_TIMESTAMP
   , PRMT_IDENT
   , NARR_COND_NUM
   , NARR_COND_CODE
   , CMNTS
   , KEY_HASH
   , DATA_HASH)
SELECT 
     null  --ICS_NARR_COND_SCHD_ID, 
   , null  --ICS_PAYLOAD_ID, 
   , null  --SRC_SYSTM_IDENT, SourceSystemIdentifier
   , null  --TRANSACTION_TYPE, TransactionType
   , null  --TRANSACTION_TIMESTAMP, TransactionTimestamp
   , null  --PRMT_IDENT, PermitIdentifier
   , null  --NARR_COND_NUM, NarrativeConditionNumber
   , null  --NARR_COND_CODE, NarrativeConditionCode
   , null  --CMNTS, Comments
   , null  --KEY_HASH, 
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_NARR_COND_SCHD/ICS_PRMT_SCHD_EVT
INSERT INTO ICS_FLOW_LOCAL.ICS_PRMT_SCHD_EVT (
     ICS_PRMT_SCHD_EVT_ID
   , ICS_NARR_COND_SCHD_ID
   , SCHD_EVT_CODE
   , SCHD_DATE
   , SCHD_REP_RCVD_DATE
   , SCHD_ACTUL_DATE
   , SCHD_PROJ_DATE
   , SCHD_USR_DFND_DAT_ELM_1
   , SCHD_USR_DFND_DAT_ELM_2
   , SCHD_EVT_CMNTS
   , DATA_HASH)
SELECT 
     null  --ICS_PRMT_SCHD_EVT_ID, 
   , null  --ICS_NARR_COND_SCHD_ID, 
   , null  --SCHD_EVT_CODE, ScheduleEventCode
   , null  --SCHD_DATE, ScheduleDate
   , null  --SCHD_REP_RCVD_DATE, ScheduleReportReceivedDate
   , null  --SCHD_ACTUL_DATE, ScheduleActualDate
   , null  --SCHD_PROJ_DATE, ScheduleProjectedDate
   , null  --SCHD_USR_DFND_DAT_ELM_1, ScheduleUserDefinedDataElement1
   , null  --SCHD_USR_DFND_DAT_ELM_2, ScheduleUserDefinedDataElement2
   , null  --SCHD_EVT_CMNTS, ScheduleEventComments
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

END;
