﻿
/*************************************************************************************************
** ObjectName: ics_etl_PermitReissuanceSubmission
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the PermitReissuanceSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/18/2025   Windsor      Created 
**
***************************************************************************************************/
CREATE OR REPLACE PROCEDURE ICS_FLOW_LOCAL.ics_etl_PermitReissuanceSubmission

AS

BEGIN

-- This procedure provides standard logic for loading permt re-issuance payloads when permit effective dates are advanced in the other permit staging tables. 
-- This approach does not depend directly on the source system or ETL logic.

---------------------------- 
-- ICS_PRMT_REISSU
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- 
DELETE
  FROM ICS_FLOW_LOCAL.ICS_PRMT_REISSU;


-- /ICS_PRMT_REISSU
 INSERT INTO ICS_PRMT_REISSU
(
  ICS_PRMT_REISSU_ID,
  ICS_PAYLOAD_ID,
  TRANSACTION_TYPE,
  PRMT_IDENT,
  PRMT_ISSUE_DATE,
  PRMT_EFFECTIVE_DATE,
  PRMT_EXPR_DATE
)
SELECT
  sys_guid() AS ICS_PRMT_REISSU_ID,
  'PermitReissuance' AS PAYLOAD_ID,
  'C' AS TRANSACTION_TYPE,
  p_local.PRMT_IDENT,
  p_local.PRMT_ISSUE_DATE,
  p_local.PRMT_EFFECTIVE_DATE,
  p_local.PRMT_EXPR_DATE

 FROM
(
  select PRMT_IDENT, PRMT_ISSUE_DATE, PRMT_EFFECTIVE_DATE, PRMT_EXPR_DATE
  FROM ics_flow_local.ICS_BASIC_PRMT
  UNION
  select PRMT_IDENT, PRMT_ISSUE_DATE, PRMT_EFFECTIVE_DATE, PRMT_EXPR_DATE
  FROM ics_flow_local.ICS_GNRL_PRMT
  UNION
  select PRMT_IDENT, PRMT_ISSUE_DATE, PRMT_EFFECTIVE_DATE, PRMT_EXPR_DATE
  FROM ics_flow_local.ICS_MASTER_GNRL_PRMT  
) p_local
join
(
  select PRMT_IDENT, PRMT_ISSUE_DATE, PRMT_EFFECTIVE_DATE, PRMT_EXPR_DATE
  FROM ics_flow_icis.ICS_BASIC_PRMT
  UNION
  select PRMT_IDENT, PRMT_ISSUE_DATE, PRMT_EFFECTIVE_DATE, PRMT_EXPR_DATE
  FROM ics_flow_icis.ICS_GNRL_PRMT
  UNION
  select PRMT_IDENT, PRMT_ISSUE_DATE, PRMT_EFFECTIVE_DATE, PRMT_EXPR_DATE
  FROM ics_flow_icis.ICS_MASTER_GNRL_PRMT 
) p_icis
ON p_local.PRMT_IDENT = p_icis.PRMT_IDENT
WHERE 1=1
AND( 
   trunc(p_local.PRMT_EFFECTIVE_DATE) > trunc(p_icis.PRMT_EFFECTIVE_DATE) -- null will not be computed
 --  OR (p_icis.PRMT_IDENT is not null AND p_icis.PRMT_EFFECTIVE_DATE is null)
 )
 -- Do not send a Re-issuance if we are also sending a termination for the permit
AND p_local.PRMT_IDENT not in (SELECT PRMT_IDENT from ICS_PRMT_TERM)
-- Do not send for permits where dates are incomplete (they should not be loaded anyway)
and p_local.PRMT_EFFECTIVE_DATE is not null
and p_local.PRMT_ISSUE_DATE is not null
and p_local.PRMT_EXPR_DATE is not null
;

  COMMIT;
  
END;
