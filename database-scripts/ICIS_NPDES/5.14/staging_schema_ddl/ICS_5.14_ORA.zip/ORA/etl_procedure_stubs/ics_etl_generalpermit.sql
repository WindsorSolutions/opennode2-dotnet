﻿
/*************************************************************************************************
** ObjectName: ics_etl_GeneralPermitSubmission
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the GeneralPermitSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/18/2025   Windsor      Created 
**
***************************************************************************************************/
CREATE OR REPLACE PROCEDURE ICS_FLOW_LOCAL.ics_etl_GeneralPermitSubmission

AS

BEGIN
---------------------------- 
-- ICS_GNRL_PRMT
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- 
DELETE
  FROM ICS_FLOW_LOCAL.ICS_GNRL_PRMT;


-- /ICS_GNRL_PRMT
INSERT INTO ICS_FLOW_LOCAL.ICS_GNRL_PRMT (
     ICS_GNRL_PRMT_ID
   , ICS_PAYLOAD_ID
   , SRC_SYSTM_IDENT
   , TRANSACTION_TYPE
   , TRANSACTION_TIMESTAMP
   , PRMT_IDENT
   , ELEC_SUBM_TYPE_CODE
   , ASSC_MASTER_GNRL_PRMT_IDENT
   , PRMT_TYPE_CODE
   , AGNCY_TYPE_CODE
   , PRMT_STAT_CODE
   , PRMT_ISSUE_DATE
   , PRMT_EFFECTIVE_DATE
   , PRMT_EXPR_DATE
   , REISSU_PRIO_PRMT_IND
   , BACKLOG_REASON_TXT
   , PRMT_ISSUING_ORG_TYPE_NAME
   , PRMT_APPEALED_IND
   , PRMT_USR_DFND_DAT_ELM_1_TXT
   , PRMT_USR_DFND_DAT_ELM_2_TXT
   , PRMT_USR_DFND_DAT_ELM_3_TXT
   , PRMT_USR_DFND_DAT_ELM_4_TXT
   , PRMT_USR_DFND_DAT_ELM_5_TXT
   , PRMT_CMNTS_TXT
   , MAJOR_MINOR_RATING_CODE
   , TTL_APPL_DSGN_FLOW_NUM
   , TTL_APPL_AVER_FLOW_NUM
   , APPL_RCVD_DATE
   , PRMT_APPL_CMPL_DATE
   , NEW_SRC_IND
   , PRMT_ST_WTR_BODY_CODE
   , PRMT_ST_WTR_BODY_NAME
   , FEDR_GRANT_IND
   , DMR_COGNZNT_OFCL
   , DMR_COGNZNT_OFCL_TELEPH_NUM
   , ELEC_REP_WAIVER_TYPE_CODE
   , ELEC_REP_WAIVER_EFFECTIVE_DATE
   , ELEC_REP_WAIVER_EXPR_DATE
   , MAJOR_MINOR_STAT_IND
   , MAJOR_MINOR_STAT_START_DATE
   , DMR_NON_RCPT_STAT_IND
   , DMR_NON_RCPT_STAT_START_DATE
   , KEY_HASH
   , DATA_HASH)
SELECT 
     null  --ICS_GNRL_PRMT_ID, 
   , null  --ICS_PAYLOAD_ID, 
   , null  --SRC_SYSTM_IDENT, SourceSystemIdentifier
   , null  --TRANSACTION_TYPE, TransactionType
   , null  --TRANSACTION_TIMESTAMP, TransactionTimestamp
   , null  --PRMT_IDENT, PermitIdentifier
   , null  --ELEC_SUBM_TYPE_CODE, ElectronicSubmissionTypeCode
   , null  --ASSC_MASTER_GNRL_PRMT_IDENT, AssociatedMasterGeneralPermitIdentifier
   , null  --PRMT_TYPE_CODE, PermitTypeCode
   , null  --AGNCY_TYPE_CODE, AgencyTypeCode
   , null  --PRMT_STAT_CODE, PermitStatusCode
   , null  --PRMT_ISSUE_DATE, PermitIssueDate
   , null  --PRMT_EFFECTIVE_DATE, PermitEffectiveDate
   , null  --PRMT_EXPR_DATE, PermitExpirationDate
   , null  --REISSU_PRIO_PRMT_IND, ReissuancePriorityPermitIndicator
   , null  --BACKLOG_REASON_TXT, BacklogReasonText
   , null  --PRMT_ISSUING_ORG_TYPE_NAME, PermitIssuingOrganizationTypeName
   , null  --PRMT_APPEALED_IND, PermitAppealedIndicator
   , null  --PRMT_USR_DFND_DAT_ELM_1_TXT, PermitUserDefinedDataElement1Text
   , null  --PRMT_USR_DFND_DAT_ELM_2_TXT, PermitUserDefinedDataElement2Text
   , null  --PRMT_USR_DFND_DAT_ELM_3_TXT, PermitUserDefinedDataElement3Text
   , null  --PRMT_USR_DFND_DAT_ELM_4_TXT, PermitUserDefinedDataElement4Text
   , null  --PRMT_USR_DFND_DAT_ELM_5_TXT, PermitUserDefinedDataElement5Text
   , null  --PRMT_CMNTS_TXT, PermitCommentsText
   , null  --MAJOR_MINOR_RATING_CODE, MajorMinorRatingCode
   , null  --TTL_APPL_DSGN_FLOW_NUM, TotalApplicationDesignFlowNumber
   , null  --TTL_APPL_AVER_FLOW_NUM, TotalApplicationAverageFlowNumber
   , null  --APPL_RCVD_DATE, ApplicationReceivedDate
   , null  --PRMT_APPL_CMPL_DATE, PermitApplicationCompletionDate
   , null  --NEW_SRC_IND, NewSourceIndicator
   , null  --PRMT_ST_WTR_BODY_CODE, PermitStateWaterBodyCode
   , null  --PRMT_ST_WTR_BODY_NAME, PermitStateWaterBodyName
   , null  --FEDR_GRANT_IND, FederalGrantIndicator
   , null  --DMR_COGNZNT_OFCL, DMRCognizantOfficial
   , null  --DMR_COGNZNT_OFCL_TELEPH_NUM, DMRCognizantOfficialTelephoneNumber
   , null  --ELEC_REP_WAIVER_TYPE_CODE, ElectronicReportingWaiverTypeCode
   , null  --ELEC_REP_WAIVER_EFFECTIVE_DATE, ElectronicReportingWaiverEffectiveDate
   , null  --ELEC_REP_WAIVER_EXPR_DATE, ElectronicReportingWaiverExpirationDate
   , null  --MAJOR_MINOR_STAT_IND, MajorMinorStatusIndicator
   , null  --MAJOR_MINOR_STAT_START_DATE, MajorMinorStatusStartDate
   , null  --DMR_NON_RCPT_STAT_IND, DMRNonReceiptStatusIndicator
   , null  --DMR_NON_RCPT_STAT_START_DATE, DMRNonReceiptStatusStartDate
   , null  --KEY_HASH, 
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_GNRL_PRMT/ICS_ADDR
INSERT INTO ICS_FLOW_LOCAL.ICS_ADDR (
     ICS_ADDR_ID
   , ICS_FAC_ID
   , ICS_BASIC_PRMT_ID
   , ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID
   , ICS_CAFO_PRMT_ID
   , ICS_GNRL_PRMT_ID
   , ICS_PRMT_FEATR_ID
   , ICS_SW_CNST_PRMT_ID
   , ICS_SW_INDST_PRMT_ID
   , ICS_UNPRMT_FAC_ID
   , AFFIL_TYPE_TXT
   , ORG_FRML_NAME
   , ORG_DUNS_NUM
   , MAILING_ADDR_TXT
   , SUPPL_ADDR_TXT
   , MAILING_ADDR_CITY_NAME
   , MAILING_ADDR_ST_CODE
   , MAILING_ADDR_ZIP_CODE
   , COUNTY_NAME
   , MAILING_ADDR_COUNTRY_CODE
   , DIVISION_NAME
   , LOC_PROVINCE
   , ELEC_ADDR_TXT
   , START_DATE_OF_ADDR_ASSC
   , END_DATE_OF_ADDR_ASSC
   , DATA_HASH)
SELECT 
     null  --ICS_ADDR_ID, 
   , null  --ICS_FAC_ID, 
   , null  --ICS_BASIC_PRMT_ID, 
   , null  --ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID, 
   , null  --ICS_CAFO_PRMT_ID, 
   , null  --ICS_GNRL_PRMT_ID, 
   , null  --ICS_PRMT_FEATR_ID, 
   , null  --ICS_SW_CNST_PRMT_ID, 
   , null  --ICS_SW_INDST_PRMT_ID, 
   , null  --ICS_UNPRMT_FAC_ID, 
   , null  --AFFIL_TYPE_TXT, AffiliationTypeText
   , null  --ORG_FRML_NAME, OrganizationFormalName
   , null  --ORG_DUNS_NUM, OrganizationDUNSNumber
   , null  --MAILING_ADDR_TXT, MailingAddressText
   , null  --SUPPL_ADDR_TXT, SupplementalAddressText
   , null  --MAILING_ADDR_CITY_NAME, MailingAddressCityName
   , null  --MAILING_ADDR_ST_CODE, MailingAddressStateCode
   , null  --MAILING_ADDR_ZIP_CODE, MailingAddressZipCode
   , null  --COUNTY_NAME, CountyName
   , null  --MAILING_ADDR_COUNTRY_CODE, MailingAddressCountryCode
   , null  --DIVISION_NAME, DivisionName
   , null  --LOC_PROVINCE, LocationProvince
   , null  --ELEC_ADDR_TXT, ElectronicAddressText
   , null  --START_DATE_OF_ADDR_ASSC, StartDateOfAddressAssociation
   , null  --END_DATE_OF_ADDR_ASSC, EndDateOfAddressAssociation
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_GNRL_PRMT/ICS_ADDR/ICS_TELEPH
INSERT INTO ICS_FLOW_LOCAL.ICS_TELEPH (
     ICS_TELEPH_ID
   , ICS_CONTACT_ID
   , ICS_ADDR_ID
   , ICS_EFFLU_TRADE_PRTNER_ADDR_ID
   , TELEPH_NUM_TYPE_CODE
   , TELEPH_NUM
   , TELEPH_EXT_NUM
   , DATA_HASH)
SELECT 
     null  --ICS_TELEPH_ID, 
   , null  --ICS_CONTACT_ID, 
   , null  --ICS_ADDR_ID, 
   , null  --ICS_EFFLU_TRADE_PRTNER_ADDR_ID, 
   , null  --TELEPH_NUM_TYPE_CODE, TelephoneNumberTypeCode
   , null  --TELEPH_NUM, TelephoneNumber
   , null  --TELEPH_EXT_NUM, TelephoneExtensionNumber
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_GNRL_PRMT/ICS_ASSC_PRMT
INSERT INTO ICS_FLOW_LOCAL.ICS_ASSC_PRMT (
     ICS_ASSC_PRMT_ID
   , ICS_BASIC_PRMT_ID
   , ICS_GNRL_PRMT_ID
   , ICS_MASTER_GNRL_PRMT_ID
   , ASSC_PRMT_IDENT
   , ASSC_PRMT_REASON_CODE
   , DATA_HASH)
SELECT 
     null  --ICS_ASSC_PRMT_ID, 
   , null  --ICS_BASIC_PRMT_ID, 
   , null  --ICS_GNRL_PRMT_ID, 
   , null  --ICS_MASTER_GNRL_PRMT_ID, 
   , null  --ASSC_PRMT_IDENT, AssociatedPermitIdentifier
   , null  --ASSC_PRMT_REASON_CODE, AssociatedPermitReasonCode
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_GNRL_PRMT/ICS_CMPL_TRACK_STAT
INSERT INTO ICS_FLOW_LOCAL.ICS_CMPL_TRACK_STAT (
     ICS_CMPL_TRACK_STAT_ID
   , ICS_BASIC_PRMT_ID
   , ICS_GNRL_PRMT_ID
   , STAT_CODE
   , STAT_START_DATE
   , STAT_REASON
   , DATA_HASH)
SELECT 
     null  --ICS_CMPL_TRACK_STAT_ID, 
   , null  --ICS_BASIC_PRMT_ID, 
   , null  --ICS_GNRL_PRMT_ID, 
   , null  --STAT_CODE, StatusCode
   , null  --STAT_START_DATE, StatusStartDate
   , null  --STAT_REASON, StatusReason
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_GNRL_PRMT/ICS_CONTACT
INSERT INTO ICS_FLOW_LOCAL.ICS_CONTACT (
     ICS_CONTACT_ID
   , ICS_FAC_ID
   , ICS_BASIC_PRMT_ID
   , ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID
   , ICS_CAFO_PRMT_ID
   , ICS_CMPL_MON_ID
   , ICS_GNRL_PRMT_ID
   , ICS_MASTER_GNRL_PRMT_ID
   , ICS_PRMT_FEATR_ID
   , ICS_PRETR_PRMT_ID
   , ICS_SW_CNST_PRMT_ID
   , ICS_SW_INDST_PRMT_ID
   , ICS_UNPRMT_FAC_ID
   , AFFIL_TYPE_TXT
   , FIRST_NAME
   , MIDDLE_NAME
   , LAST_NAME
   , INDVL_TITLE_TXT
   , ORG_FRML_NAME
   , ST_CODE
   , RGN_CODE
   , ELEC_ADDR_TXT
   , START_DATE_OF_CONTACT_ASSC
   , END_DATE_OF_CONTACT_ASSC
   , DATA_HASH)
SELECT 
     null  --ICS_CONTACT_ID, 
   , null  --ICS_FAC_ID, 
   , null  --ICS_BASIC_PRMT_ID, 
   , null  --ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID, 
   , null  --ICS_CAFO_PRMT_ID, 
   , null  --ICS_CMPL_MON_ID, 
   , null  --ICS_GNRL_PRMT_ID, 
   , null  --ICS_MASTER_GNRL_PRMT_ID, 
   , null  --ICS_PRMT_FEATR_ID, 
   , null  --ICS_PRETR_PRMT_ID, 
   , null  --ICS_SW_CNST_PRMT_ID, 
   , null  --ICS_SW_INDST_PRMT_ID, 
   , null  --ICS_UNPRMT_FAC_ID, 
   , null  --AFFIL_TYPE_TXT, AffiliationTypeText
   , null  --FIRST_NAME, FirstName
   , null  --MIDDLE_NAME, MiddleName
   , null  --LAST_NAME, LastName
   , null  --INDVL_TITLE_TXT, IndividualTitleText
   , null  --ORG_FRML_NAME, OrganizationFormalName
   , null  --ST_CODE, StateCode
   , null  --RGN_CODE, RegionCode
   , null  --ELEC_ADDR_TXT, ElectronicAddressText
   , null  --START_DATE_OF_CONTACT_ASSC, StartDateOfContactAssociation
   , null  --END_DATE_OF_CONTACT_ASSC, EndDateOfContactAssociation
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_GNRL_PRMT/ICS_CONTACT/ICS_TELEPH
INSERT INTO ICS_FLOW_LOCAL.ICS_TELEPH (
     ICS_TELEPH_ID
   , ICS_CONTACT_ID
   , ICS_ADDR_ID
   , ICS_EFFLU_TRADE_PRTNER_ADDR_ID
   , TELEPH_NUM_TYPE_CODE
   , TELEPH_NUM
   , TELEPH_EXT_NUM
   , DATA_HASH)
SELECT 
     null  --ICS_TELEPH_ID, 
   , null  --ICS_CONTACT_ID, 
   , null  --ICS_ADDR_ID, 
   , null  --ICS_EFFLU_TRADE_PRTNER_ADDR_ID, 
   , null  --TELEPH_NUM_TYPE_CODE, TelephoneNumberTypeCode
   , null  --TELEPH_NUM, TelephoneNumber
   , null  --TELEPH_EXT_NUM, TelephoneExtensionNumber
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_GNRL_PRMT/ICS_EFFLU_GUIDE
INSERT INTO ICS_FLOW_LOCAL.ICS_EFFLU_GUIDE (
     ICS_EFFLU_GUIDE_ID
   , ICS_BASIC_PRMT_ID
   , ICS_GNRL_PRMT_ID
   , EFFLU_GUIDE_CODE
   , DATA_HASH)
SELECT 
     null  --ICS_EFFLU_GUIDE_ID, 
   , null  --ICS_BASIC_PRMT_ID, 
   , null  --ICS_GNRL_PRMT_ID, 
   , null  --EFFLU_GUIDE_CODE, EffluentGuidelineCode
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_GNRL_PRMT/ICS_FAC
INSERT INTO ICS_FLOW_LOCAL.ICS_FAC (
     ICS_FAC_ID
   , ICS_BASIC_PRMT_ID
   , ICS_GNRL_PRMT_ID
   , LOCALITY_NAME
   , LOC_ADDR_CITY_CODE
   , LOC_ADDR_COUNTY_CODE
   , FAC_SITE_NAME
   , LOC_ADDR_TXT
   , SUPPL_LOC_TXT
   , LOC_ST_CODE
   , LOC_ZIP_CODE
   , LOC_COUNTRY_CODE
   , ORG_DUNS_NUM
   , ST_FAC_IDENT
   , ST_RGN_CODE
   , FAC_CONGR_DISTRICT_NUM
   , FAC_TYPE_OF_OWNERSHIP_CODE
   , FEDR_FAC_IDENT_NUM
   , FEDR_AGNCY_CODE
   , TRIBAL_LAND_CODE
   , CNST_PROJ_NAME
   , CNST_PROJ_LAT_MEAS
   , CNST_PROJ_LONG_MEAS
   , SECTION_TOWNSHIP_RNG
   , FAC_CMNTS
   , FAC_USR_DFND_FLD_1
   , FAC_USR_DFND_FLD_2
   , FAC_USR_DFND_FLD_3
   , FAC_USR_DFND_FLD_4
   , FAC_USR_DFND_FLD_5
   , DATA_HASH)
SELECT 
     null  --ICS_FAC_ID, 
   , null  --ICS_BASIC_PRMT_ID, 
   , null  --ICS_GNRL_PRMT_ID, 
   , null  --LOCALITY_NAME, LocalityName
   , null  --LOC_ADDR_CITY_CODE, LocationAddressCityCode
   , null  --LOC_ADDR_COUNTY_CODE, LocationAddressCountyCode
   , null  --FAC_SITE_NAME, FacilitySiteName
   , null  --LOC_ADDR_TXT, LocationAddressText
   , null  --SUPPL_LOC_TXT, SupplementalLocationText
   , null  --LOC_ST_CODE, LocationStateCode
   , null  --LOC_ZIP_CODE, LocationZipCode
   , null  --LOC_COUNTRY_CODE, LocationCountryCode
   , null  --ORG_DUNS_NUM, OrganizationDUNSNumber
   , null  --ST_FAC_IDENT, StateFacilityIdentifier
   , null  --ST_RGN_CODE, StateRegionCode
   , null  --FAC_CONGR_DISTRICT_NUM, FacilityCongressionalDistrictNumber
   , null  --FAC_TYPE_OF_OWNERSHIP_CODE, FacilityTypeOfOwnershipCode
   , null  --FEDR_FAC_IDENT_NUM, FederalFacilityIdentificationNumber
   , null  --FEDR_AGNCY_CODE, FederalAgencyCode
   , null  --TRIBAL_LAND_CODE, TribalLandCode
   , null  --CNST_PROJ_NAME, ConstructionProjectName
   , null  --CNST_PROJ_LAT_MEAS, ConstructionProjectLatitudeMeasure
   , null  --CNST_PROJ_LONG_MEAS, ConstructionProjectLongitudeMeasure
   , null  --SECTION_TOWNSHIP_RNG, SectionTownshipRange
   , null  --FAC_CMNTS, FacilityComments
   , null  --FAC_USR_DFND_FLD_1, FacilityUserDefinedField1
   , null  --FAC_USR_DFND_FLD_2, FacilityUserDefinedField2
   , null  --FAC_USR_DFND_FLD_3, FacilityUserDefinedField3
   , null  --FAC_USR_DFND_FLD_4, FacilityUserDefinedField4
   , null  --FAC_USR_DFND_FLD_5, FacilityUserDefinedField5
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_GNRL_PRMT/ICS_FAC/ICS_ADDR
INSERT INTO ICS_FLOW_LOCAL.ICS_ADDR (
     ICS_ADDR_ID
   , ICS_FAC_ID
   , ICS_BASIC_PRMT_ID
   , ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID
   , ICS_CAFO_PRMT_ID
   , ICS_GNRL_PRMT_ID
   , ICS_PRMT_FEATR_ID
   , ICS_SW_CNST_PRMT_ID
   , ICS_SW_INDST_PRMT_ID
   , ICS_UNPRMT_FAC_ID
   , AFFIL_TYPE_TXT
   , ORG_FRML_NAME
   , ORG_DUNS_NUM
   , MAILING_ADDR_TXT
   , SUPPL_ADDR_TXT
   , MAILING_ADDR_CITY_NAME
   , MAILING_ADDR_ST_CODE
   , MAILING_ADDR_ZIP_CODE
   , COUNTY_NAME
   , MAILING_ADDR_COUNTRY_CODE
   , DIVISION_NAME
   , LOC_PROVINCE
   , ELEC_ADDR_TXT
   , START_DATE_OF_ADDR_ASSC
   , END_DATE_OF_ADDR_ASSC
   , DATA_HASH)
SELECT 
     null  --ICS_ADDR_ID, 
   , null  --ICS_FAC_ID, 
   , null  --ICS_BASIC_PRMT_ID, 
   , null  --ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID, 
   , null  --ICS_CAFO_PRMT_ID, 
   , null  --ICS_GNRL_PRMT_ID, 
   , null  --ICS_PRMT_FEATR_ID, 
   , null  --ICS_SW_CNST_PRMT_ID, 
   , null  --ICS_SW_INDST_PRMT_ID, 
   , null  --ICS_UNPRMT_FAC_ID, 
   , null  --AFFIL_TYPE_TXT, AffiliationTypeText
   , null  --ORG_FRML_NAME, OrganizationFormalName
   , null  --ORG_DUNS_NUM, OrganizationDUNSNumber
   , null  --MAILING_ADDR_TXT, MailingAddressText
   , null  --SUPPL_ADDR_TXT, SupplementalAddressText
   , null  --MAILING_ADDR_CITY_NAME, MailingAddressCityName
   , null  --MAILING_ADDR_ST_CODE, MailingAddressStateCode
   , null  --MAILING_ADDR_ZIP_CODE, MailingAddressZipCode
   , null  --COUNTY_NAME, CountyName
   , null  --MAILING_ADDR_COUNTRY_CODE, MailingAddressCountryCode
   , null  --DIVISION_NAME, DivisionName
   , null  --LOC_PROVINCE, LocationProvince
   , null  --ELEC_ADDR_TXT, ElectronicAddressText
   , null  --START_DATE_OF_ADDR_ASSC, StartDateOfAddressAssociation
   , null  --END_DATE_OF_ADDR_ASSC, EndDateOfAddressAssociation
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_GNRL_PRMT/ICS_FAC/ICS_ADDR/ICS_TELEPH
INSERT INTO ICS_FLOW_LOCAL.ICS_TELEPH (
     ICS_TELEPH_ID
   , ICS_CONTACT_ID
   , ICS_ADDR_ID
   , ICS_EFFLU_TRADE_PRTNER_ADDR_ID
   , TELEPH_NUM_TYPE_CODE
   , TELEPH_NUM
   , TELEPH_EXT_NUM
   , DATA_HASH)
SELECT 
     null  --ICS_TELEPH_ID, 
   , null  --ICS_CONTACT_ID, 
   , null  --ICS_ADDR_ID, 
   , null  --ICS_EFFLU_TRADE_PRTNER_ADDR_ID, 
   , null  --TELEPH_NUM_TYPE_CODE, TelephoneNumberTypeCode
   , null  --TELEPH_NUM, TelephoneNumber
   , null  --TELEPH_EXT_NUM, TelephoneExtensionNumber
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_GNRL_PRMT/ICS_FAC/ICS_CONTACT
INSERT INTO ICS_FLOW_LOCAL.ICS_CONTACT (
     ICS_CONTACT_ID
   , ICS_FAC_ID
   , ICS_BASIC_PRMT_ID
   , ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID
   , ICS_CAFO_PRMT_ID
   , ICS_CMPL_MON_ID
   , ICS_GNRL_PRMT_ID
   , ICS_MASTER_GNRL_PRMT_ID
   , ICS_PRMT_FEATR_ID
   , ICS_PRETR_PRMT_ID
   , ICS_SW_CNST_PRMT_ID
   , ICS_SW_INDST_PRMT_ID
   , ICS_UNPRMT_FAC_ID
   , AFFIL_TYPE_TXT
   , FIRST_NAME
   , MIDDLE_NAME
   , LAST_NAME
   , INDVL_TITLE_TXT
   , ORG_FRML_NAME
   , ST_CODE
   , RGN_CODE
   , ELEC_ADDR_TXT
   , START_DATE_OF_CONTACT_ASSC
   , END_DATE_OF_CONTACT_ASSC
   , DATA_HASH)
SELECT 
     null  --ICS_CONTACT_ID, 
   , null  --ICS_FAC_ID, 
   , null  --ICS_BASIC_PRMT_ID, 
   , null  --ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID, 
   , null  --ICS_CAFO_PRMT_ID, 
   , null  --ICS_CMPL_MON_ID, 
   , null  --ICS_GNRL_PRMT_ID, 
   , null  --ICS_MASTER_GNRL_PRMT_ID, 
   , null  --ICS_PRMT_FEATR_ID, 
   , null  --ICS_PRETR_PRMT_ID, 
   , null  --ICS_SW_CNST_PRMT_ID, 
   , null  --ICS_SW_INDST_PRMT_ID, 
   , null  --ICS_UNPRMT_FAC_ID, 
   , null  --AFFIL_TYPE_TXT, AffiliationTypeText
   , null  --FIRST_NAME, FirstName
   , null  --MIDDLE_NAME, MiddleName
   , null  --LAST_NAME, LastName
   , null  --INDVL_TITLE_TXT, IndividualTitleText
   , null  --ORG_FRML_NAME, OrganizationFormalName
   , null  --ST_CODE, StateCode
   , null  --RGN_CODE, RegionCode
   , null  --ELEC_ADDR_TXT, ElectronicAddressText
   , null  --START_DATE_OF_CONTACT_ASSC, StartDateOfContactAssociation
   , null  --END_DATE_OF_CONTACT_ASSC, EndDateOfContactAssociation
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_GNRL_PRMT/ICS_FAC/ICS_CONTACT/ICS_TELEPH
INSERT INTO ICS_FLOW_LOCAL.ICS_TELEPH (
     ICS_TELEPH_ID
   , ICS_CONTACT_ID
   , ICS_ADDR_ID
   , ICS_EFFLU_TRADE_PRTNER_ADDR_ID
   , TELEPH_NUM_TYPE_CODE
   , TELEPH_NUM
   , TELEPH_EXT_NUM
   , DATA_HASH)
SELECT 
     null  --ICS_TELEPH_ID, 
   , null  --ICS_CONTACT_ID, 
   , null  --ICS_ADDR_ID, 
   , null  --ICS_EFFLU_TRADE_PRTNER_ADDR_ID, 
   , null  --TELEPH_NUM_TYPE_CODE, TelephoneNumberTypeCode
   , null  --TELEPH_NUM, TelephoneNumber
   , null  --TELEPH_EXT_NUM, TelephoneExtensionNumber
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_GNRL_PRMT/ICS_FAC/ICS_FAC_CLASS
INSERT INTO ICS_FLOW_LOCAL.ICS_FAC_CLASS (
     ICS_FAC_CLASS_ID
   , ICS_FAC_ID
   , ICS_UNPRMT_FAC_ID
   , FAC_CLASS
   , DATA_HASH)
SELECT 
     null  --ICS_FAC_CLASS_ID, 
   , null  --ICS_FAC_ID, 
   , null  --ICS_UNPRMT_FAC_ID, 
   , null  --FAC_CLASS, FacilityClassification
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_GNRL_PRMT/ICS_FAC/ICS_GEO_COORD
INSERT INTO ICS_FLOW_LOCAL.ICS_GEO_COORD (
     ICS_GEO_COORD_ID
   , ICS_FAC_ID
   , ICS_COPY_MGP_LMT_SET_ID
   , ICS_PRMT_FEATR_ID
   , ICS_UNPRMT_FAC_ID
   , LAT_MEAS
   , LONG_MEAS
   , HORZ_ACCURACY_MEAS
   , GEOMETRIC_TYPE_CODE
   , HORZ_COLL_METHOD_CODE
   , HORZ_REF_DATUM_CODE
   , REF_POINT_CODE
   , SRC_MAP_SCALE_NUM
   , DATA_HASH)
SELECT 
     null  --ICS_GEO_COORD_ID, 
   , null  --ICS_FAC_ID, 
   , null  --ICS_COPY_MGP_LMT_SET_ID, 
   , null  --ICS_PRMT_FEATR_ID, 
   , null  --ICS_UNPRMT_FAC_ID, 
   , null  --LAT_MEAS, LatitudeMeasure
   , null  --LONG_MEAS, LongitudeMeasure
   , null  --HORZ_ACCURACY_MEAS, HorizontalAccuracyMeasure
   , null  --GEOMETRIC_TYPE_CODE, GeometricTypeCode
   , null  --HORZ_COLL_METHOD_CODE, HorizontalCollectionMethodCode
   , null  --HORZ_REF_DATUM_CODE, HorizontalReferenceDatumCode
   , null  --REF_POINT_CODE, ReferencePointCode
   , null  --SRC_MAP_SCALE_NUM, SourceMapScaleNumber
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_GNRL_PRMT/ICS_FAC/ICS_NAICS_CODE
INSERT INTO ICS_FLOW_LOCAL.ICS_NAICS_CODE (
     ICS_NAICS_CODE_ID
   , ICS_BASIC_PRMT_ID
   , ICS_FAC_ID
   , ICS_GNRL_PRMT_ID
   , ICS_MASTER_GNRL_PRMT_ID
   , ICS_UNPRMT_FAC_ID
   , NAICS_CODE
   , NAICS_PRIMARY_IND_CODE
   , DATA_HASH)
SELECT 
     null  --ICS_NAICS_CODE_ID, 
   , null  --ICS_BASIC_PRMT_ID, 
   , null  --ICS_FAC_ID, 
   , null  --ICS_GNRL_PRMT_ID, 
   , null  --ICS_MASTER_GNRL_PRMT_ID, 
   , null  --ICS_UNPRMT_FAC_ID, 
   , null  --NAICS_CODE, NAICSCode
   , null  --NAICS_PRIMARY_IND_CODE, NAICSPrimaryIndicatorCode
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_GNRL_PRMT/ICS_FAC/ICS_ORIG_PROGS
INSERT INTO ICS_FLOW_LOCAL.ICS_ORIG_PROGS (
     ICS_ORIG_PROGS_ID
   , ICS_FAC_ID
   , ICS_UNPRMT_FAC_ID
   , ORIG_PROGS_CODE
   , DATA_HASH)
SELECT 
     null  --ICS_ORIG_PROGS_ID, 
   , null  --ICS_FAC_ID, 
   , null  --ICS_UNPRMT_FAC_ID, 
   , null  --ORIG_PROGS_CODE, OriginatingProgramsCode
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_GNRL_PRMT/ICS_FAC/ICS_PLCY
INSERT INTO ICS_FLOW_LOCAL.ICS_PLCY (
     ICS_PLCY_ID
   , ICS_FAC_ID
   , ICS_UNPRMT_FAC_ID
   , PLCY_CODE
   , DATA_HASH)
SELECT 
     null  --ICS_PLCY_ID, 
   , null  --ICS_FAC_ID, 
   , null  --ICS_UNPRMT_FAC_ID, 
   , null  --PLCY_CODE, PolicyCode
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_GNRL_PRMT/ICS_FAC/ICS_SIC_CODE
INSERT INTO ICS_FLOW_LOCAL.ICS_SIC_CODE (
     ICS_SIC_CODE_ID
   , ICS_BASIC_PRMT_ID
   , ICS_FAC_ID
   , ICS_GNRL_PRMT_ID
   , ICS_MASTER_GNRL_PRMT_ID
   , ICS_UNPRMT_FAC_ID
   , SIC_CODE
   , SIC_PRIMARY_IND_CODE
   , DATA_HASH)
SELECT 
     null  --ICS_SIC_CODE_ID, 
   , null  --ICS_BASIC_PRMT_ID, 
   , null  --ICS_FAC_ID, 
   , null  --ICS_GNRL_PRMT_ID, 
   , null  --ICS_MASTER_GNRL_PRMT_ID, 
   , null  --ICS_UNPRMT_FAC_ID, 
   , null  --SIC_CODE, SICCode
   , null  --SIC_PRIMARY_IND_CODE, SICPrimaryIndicatorCode
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_GNRL_PRMT/ICS_NAICS_CODE
INSERT INTO ICS_FLOW_LOCAL.ICS_NAICS_CODE (
     ICS_NAICS_CODE_ID
   , ICS_BASIC_PRMT_ID
   , ICS_FAC_ID
   , ICS_GNRL_PRMT_ID
   , ICS_MASTER_GNRL_PRMT_ID
   , ICS_UNPRMT_FAC_ID
   , NAICS_CODE
   , NAICS_PRIMARY_IND_CODE
   , DATA_HASH)
SELECT 
     null  --ICS_NAICS_CODE_ID, 
   , null  --ICS_BASIC_PRMT_ID, 
   , null  --ICS_FAC_ID, 
   , null  --ICS_GNRL_PRMT_ID, 
   , null  --ICS_MASTER_GNRL_PRMT_ID, 
   , null  --ICS_UNPRMT_FAC_ID, 
   , null  --NAICS_CODE, NAICSCode
   , null  --NAICS_PRIMARY_IND_CODE, NAICSPrimaryIndicatorCode
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_GNRL_PRMT/ICS_NPDES_DAT_GRP_NUM
INSERT INTO ICS_FLOW_LOCAL.ICS_NPDES_DAT_GRP_NUM (
     ICS_NPDES_DAT_GRP_NUM_ID
   , ICS_BASIC_PRMT_ID
   , ICS_GNRL_PRMT_ID
   , NPDES_DAT_GRP_NUM_CODE
   , DATA_HASH)
SELECT 
     null  --ICS_NPDES_DAT_GRP_NUM_ID, 
   , null  --ICS_BASIC_PRMT_ID, 
   , null  --ICS_GNRL_PRMT_ID, 
   , null  --NPDES_DAT_GRP_NUM_CODE, NPDESDataGroupNumberCode
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_GNRL_PRMT/ICS_OTHR_PRMTS
INSERT INTO ICS_FLOW_LOCAL.ICS_OTHR_PRMTS (
     ICS_OTHR_PRMTS_ID
   , ICS_BASIC_PRMT_ID
   , ICS_GNRL_PRMT_ID
   , ICS_MASTER_GNRL_PRMT_ID
   , OTHR_PRMT_IDENT
   , OTHR_ORG_NAME
   , OTHR_PRMT_IDENT_CNTXT_NAME
   , DATA_HASH)
SELECT 
     null  --ICS_OTHR_PRMTS_ID, 
   , null  --ICS_BASIC_PRMT_ID, 
   , null  --ICS_GNRL_PRMT_ID, 
   , null  --ICS_MASTER_GNRL_PRMT_ID, 
   , null  --OTHR_PRMT_IDENT, OtherPermitIdentifier
   , null  --OTHR_ORG_NAME, OtherOrganizationName
   , null  --OTHR_PRMT_IDENT_CNTXT_NAME, OtherPermitIdentifierContextName
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_GNRL_PRMT/ICS_REP_NON_CMPL_STAT
INSERT INTO ICS_FLOW_LOCAL.ICS_REP_NON_CMPL_STAT (
     ICS_REP_NON_CMPL_STAT_ID
   , ICS_BASIC_PRMT_ID
   , ICS_GNRL_PRMT_ID
   , REP_NON_CMPL_STAT_CODE_YEAR
   , REP_NON_CMPL_STAT_CODE_QUARTER
   , REP_NON_CMPL_MANUAL_STAT_CODE
   , DATA_HASH)
SELECT 
     null  --ICS_REP_NON_CMPL_STAT_ID, 
   , null  --ICS_BASIC_PRMT_ID, 
   , null  --ICS_GNRL_PRMT_ID, 
   , null  --REP_NON_CMPL_STAT_CODE_YEAR, ReportableNonComplianceStatusCodeYear
   , null  --REP_NON_CMPL_STAT_CODE_QUARTER, ReportableNonComplianceStatusCodeQuarter
   , null  --REP_NON_CMPL_MANUAL_STAT_CODE, ReportableNonComplianceManualStatusCode
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_GNRL_PRMT/ICS_RESIDUAL_DESGN_DTRMN
INSERT INTO ICS_FLOW_LOCAL.ICS_RESIDUAL_DESGN_DTRMN (
     ICS_RESIDUAL_DESGN_DTRMN_ID
   , ICS_BASIC_PRMT_ID
   , ICS_GNRL_PRMT_ID
   , ICS_MASTER_GNRL_PRMT_ID
   , RESIDUAL_DESGN_DTRMN_CODE
   , RESIDUAL_DESGN_DTRMN_OTHR_TXT
   , DATA_HASH)
SELECT 
     null  --ICS_RESIDUAL_DESGN_DTRMN_ID, 
   , null  --ICS_BASIC_PRMT_ID, 
   , null  --ICS_GNRL_PRMT_ID, 
   , null  --ICS_MASTER_GNRL_PRMT_ID, 
   , null  --RESIDUAL_DESGN_DTRMN_CODE, ResidualDesignationDeterminationCode
   , null  --RESIDUAL_DESGN_DTRMN_OTHR_TXT, ResidualDesignationDeterminationOtherText
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_GNRL_PRMT/ICS_SIC_CODE
INSERT INTO ICS_FLOW_LOCAL.ICS_SIC_CODE (
     ICS_SIC_CODE_ID
   , ICS_BASIC_PRMT_ID
   , ICS_FAC_ID
   , ICS_GNRL_PRMT_ID
   , ICS_MASTER_GNRL_PRMT_ID
   , ICS_UNPRMT_FAC_ID
   , SIC_CODE
   , SIC_PRIMARY_IND_CODE
   , DATA_HASH)
SELECT 
     null  --ICS_SIC_CODE_ID, 
   , null  --ICS_BASIC_PRMT_ID, 
   , null  --ICS_FAC_ID, 
   , null  --ICS_GNRL_PRMT_ID, 
   , null  --ICS_MASTER_GNRL_PRMT_ID, 
   , null  --ICS_UNPRMT_FAC_ID, 
   , null  --SIC_CODE, SICCode
   , null  --SIC_PRIMARY_IND_CODE, SICPrimaryIndicatorCode
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

END;
