﻿
/*************************************************************************************************
** ObjectName: ics_etl_SewerOverflowBypassEventReportSubmission
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the SewerOverflowBypassEventReportSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/18/2025   Windsor      Created 
**
***************************************************************************************************/
CREATE OR REPLACE PROCEDURE ICS_FLOW_LOCAL.ics_etl_SewerOverflowBypassEventReportSubmission

AS

BEGIN
---------------------------- 
-- ICS_SEWER_OVRFLW_BYPASS_EVT_REP
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- 
DELETE
  FROM ICS_FLOW_LOCAL.ICS_SEWER_OVRFLW_BYPASS_EVT_REP;


-- /ICS_SEWER_OVRFLW_BYPASS_EVT_REP
INSERT INTO ICS_FLOW_LOCAL.ICS_SEWER_OVRFLW_BYPASS_EVT_REP (
     ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID
   , ICS_PAYLOAD_ID
   , SRC_SYSTM_IDENT
   , TRANSACTION_TYPE
   , TRANSACTION_TIMESTAMP
   , PRMT_IDENT
   , PROG_REP_FORM_SET_ID
   , PROG_REP_FORM_ID
   , PROG_REP_RCVD_DATE
   , PROG_REP_START_DATE
   , PROG_REP_END_DATE
   , ELEC_SUBM_TYPE_CODE
   , PROG_REP_NPDES_DAT_GRP_NUM_CODE
   , KEY_HASH
   , DATA_HASH)
SELECT 
     null  --ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID, 
   , null  --ICS_PAYLOAD_ID, 
   , null  --SRC_SYSTM_IDENT, SourceSystemIdentifier
   , null  --TRANSACTION_TYPE, TransactionType
   , null  --TRANSACTION_TIMESTAMP, TransactionTimestamp
   , null  --PRMT_IDENT, PermitIdentifier
   , null  --PROG_REP_FORM_SET_ID, ProgramReportFormSetID
   , null  --PROG_REP_FORM_ID, ProgramReportFormID
   , null  --PROG_REP_RCVD_DATE, ProgramReportReceivedDate
   , null  --PROG_REP_START_DATE, ProgramReportStartDate
   , null  --PROG_REP_END_DATE, ProgramReportEndDate
   , null  --ELEC_SUBM_TYPE_CODE, ElectronicSubmissionTypeCode
   , null  --PROG_REP_NPDES_DAT_GRP_NUM_CODE, ProgramReportNPDESDataGroupNumberCode
   , null  --KEY_HASH, 
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_SEWER_OVRFLW_BYPASS_EVT_REP/ICS_SEWER_OVRFLW_BYPASS_REP_EVT
INSERT INTO ICS_FLOW_LOCAL.ICS_SEWER_OVRFLW_BYPASS_REP_EVT (
     ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID
   , ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID
   , LAT_MEAS
   , LONG_MEAS
   , PRMT_FEATR_IDENT
   , DSCH_QUANTIFICATION_METHOD_CODE
   , SEWER_OVRFLW_BYPASS_DSCH_RATE_GPH
   , SEWER_OVRFLW_BYPASS_DSCH_VOL_GAL
   , SEWER_OVRFLW_BYPASS_EVT_ID
   , SEWER_OVRFLW_BYPASS_DESC_TXT
   , SEWER_OVRFLW_BYPASS_REP_REQ_CODE
   , WET_WEATHER_OCCURANCE_IND
   , SEWER_OVRFLW_STRCT_TYPE_CODE
   , SEWER_OVRFLW_STRCT_TYPE_CODE_OTHR_TXT
   , COLL_SYSTM_IDENT
   , ANTICIPATED_BYPASS_TXT
   , ANTICIPATED_BYPASS_EXPECT_LMT_VIOL
   , ANTICIPATED_BYPASS_EXPECT_LMT_VIOL_TXT
   , SEWER_OVRFLW_BYPASS_DURATION_HOURS
   , SEWER_OVRFLW_BYPASS_START_DATE_TIME
   , SEWER_OVRFLW_BYPASS_END_DATE_TIME
   , DATA_HASH)
SELECT 
     null  --ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID, 
   , null  --ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID, 
   , null  --LAT_MEAS, LatitudeMeasure
   , null  --LONG_MEAS, LongitudeMeasure
   , null  --PRMT_FEATR_IDENT, PermittedFeatureIdentifier
   , null  --DSCH_QUANTIFICATION_METHOD_CODE, DischargeQuantificationMethodCode
   , null  --SEWER_OVRFLW_BYPASS_DSCH_RATE_GPH, SewerOverflowBypassDischargeRateGPH
   , null  --SEWER_OVRFLW_BYPASS_DSCH_VOL_GAL, SewerOverflowBypassDischargeVolumeGallons
   , null  --SEWER_OVRFLW_BYPASS_EVT_ID, SewerOverflowBypassEventID
   , null  --SEWER_OVRFLW_BYPASS_DESC_TXT, SewerOverflowBypassDescriptionText
   , null  --SEWER_OVRFLW_BYPASS_REP_REQ_CODE, SewerOverflowBypassReportingRequirementCode
   , null  --WET_WEATHER_OCCURANCE_IND, WetWeatherOccuranceIndicator
   , null  --SEWER_OVRFLW_STRCT_TYPE_CODE, SewerOverflowStructureTypeCode
   , null  --SEWER_OVRFLW_STRCT_TYPE_CODE_OTHR_TXT, SewerOverflowStructureTypeCodeOtherText
   , null  --COLL_SYSTM_IDENT, CollectionSystemIdentifier
   , null  --ANTICIPATED_BYPASS_TXT, AnticipatedBypassText
   , null  --ANTICIPATED_BYPASS_EXPECT_LMT_VIOL, AnticipatedBypassExpectLimitViolation
   , null  --ANTICIPATED_BYPASS_EXPECT_LMT_VIOL_TXT, AnticipatedBypassExpectLimitViolationText
   , null  --SEWER_OVRFLW_BYPASS_DURATION_HOURS, SewerOverflowBypassDurationHours
   , null  --SEWER_OVRFLW_BYPASS_START_DATE_TIME, SewerOverflowBypassStartDateTime
   , null  --SEWER_OVRFLW_BYPASS_END_DATE_TIME, SewerOverflowBypassEndDateTime
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_SEWER_OVRFLW_BYPASS_EVT_REP/ICS_SEWER_OVRFLW_BYPASS_REP_EVT/ICS_BYPASS_TRTMNT_PLANT_EQUIPMENT
INSERT INTO ICS_FLOW_LOCAL.ICS_BYPASS_TRTMNT_PLANT_EQUIPMENT (
     ICS_BYPASS_TRTMNT_PLANT_EQUIPMENT_ID
   , ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID
   , BYPASS_TRTMNT_PLANT_EQUIPMENT_CODE
   , DATA_HASH)
SELECT 
     null  --ICS_BYPASS_TRTMNT_PLANT_EQUIPMENT_ID, 
   , null  --ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID, 
   , null  --BYPASS_TRTMNT_PLANT_EQUIPMENT_CODE, BypassTreatmentPlantEquipmentCode
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_SEWER_OVRFLW_BYPASS_EVT_REP/ICS_SEWER_OVRFLW_BYPASS_REP_EVT/ICS_SEWER_OVRFLW_BYPASS_CAUSE
INSERT INTO ICS_FLOW_LOCAL.ICS_SEWER_OVRFLW_BYPASS_CAUSE (
     ICS_SEWER_OVRFLW_BYPASS_CAUSE_ID
   , ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID
   , SEWER_OVRFLW_BYPASS_CAUSE_CODE
   , SEWER_OVRFLW_BYPASS_CAUSE_OTHR_TXT
   , DATA_HASH)
SELECT 
     null  --ICS_SEWER_OVRFLW_BYPASS_CAUSE_ID, 
   , null  --ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID, 
   , null  --SEWER_OVRFLW_BYPASS_CAUSE_CODE, SewerOverflowBypassCauseCode
   , null  --SEWER_OVRFLW_BYPASS_CAUSE_OTHR_TXT, SewerOverflowBypassCauseOtherText
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_SEWER_OVRFLW_BYPASS_EVT_REP/ICS_SEWER_OVRFLW_BYPASS_REP_EVT/ICS_SEWER_OVRFLW_BYPASS_CORR_ACTN
INSERT INTO ICS_FLOW_LOCAL.ICS_SEWER_OVRFLW_BYPASS_CORR_ACTN (
     ICS_SEWER_OVRFLW_BYPASS_CORR_ACTN_ID
   , ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID
   , SEWER_OVRFLW_BYPASS_CORR_ACTN_CODE
   , SEWER_OVRFLW_BYPASS_CORR_ACTN_OTHR_TXT
   , DATA_HASH)
SELECT 
     null  --ICS_SEWER_OVRFLW_BYPASS_CORR_ACTN_ID, 
   , null  --ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID, 
   , null  --SEWER_OVRFLW_BYPASS_CORR_ACTN_CODE, SewerOverflowBypassCorrectiveActionCode
   , null  --SEWER_OVRFLW_BYPASS_CORR_ACTN_OTHR_TXT, SewerOverflowBypassCorrectiveActionOtherText
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_SEWER_OVRFLW_BYPASS_EVT_REP/ICS_SEWER_OVRFLW_BYPASS_REP_EVT/ICS_SEWER_OVRFLW_BYPASS_IMPACT
INSERT INTO ICS_FLOW_LOCAL.ICS_SEWER_OVRFLW_BYPASS_IMPACT (
     ICS_SEWER_OVRFLW_BYPASS_IMPACT_ID
   , ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID
   , SEWER_OVRFLW_BYPASS_IMPACT_CODE
   , SEWER_OVRFLW_BYPASS_IMPACT_OTHR_TXT
   , DATA_HASH)
SELECT 
     null  --ICS_SEWER_OVRFLW_BYPASS_IMPACT_ID, 
   , null  --ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID, 
   , null  --SEWER_OVRFLW_BYPASS_IMPACT_CODE, SewerOverflowBypassImpactCode
   , null  --SEWER_OVRFLW_BYPASS_IMPACT_OTHR_TXT, SewerOverflowBypassImpactOtherText
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_SEWER_OVRFLW_BYPASS_EVT_REP/ICS_SEWER_OVRFLW_BYPASS_REP_EVT/ICS_SEWER_OVRFLW_BYPASS_RCVG_WTR
INSERT INTO ICS_FLOW_LOCAL.ICS_SEWER_OVRFLW_BYPASS_RCVG_WTR (
     ICS_SEWER_OVRFLW_BYPASS_RCVG_WTR_ID
   , ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID
   , SEWER_OVRFLW_BYPASS_RCVG_WTR
   , DATA_HASH)
SELECT 
     null  --ICS_SEWER_OVRFLW_BYPASS_RCVG_WTR_ID, 
   , null  --ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID, 
   , null  --SEWER_OVRFLW_BYPASS_RCVG_WTR, SewerOverflowBypassReceivingWater
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_SEWER_OVRFLW_BYPASS_EVT_REP/ICS_SEWER_OVRFLW_BYPASS_REP_EVT/ICS_SEWER_OVRFLW_BYPASS_TYPE
INSERT INTO ICS_FLOW_LOCAL.ICS_SEWER_OVRFLW_BYPASS_TYPE (
     ICS_SEWER_OVRFLW_BYPASS_TYPE_ID
   , ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID
   , SEWER_OVRFLW_BYPASS_TYPE_CODE
   , DATA_HASH)
SELECT 
     null  --ICS_SEWER_OVRFLW_BYPASS_TYPE_ID, 
   , null  --ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID, 
   , null  --SEWER_OVRFLW_BYPASS_TYPE_CODE, SewerOverflowBypassTypeCode
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_SEWER_OVRFLW_BYPASS_EVT_REP/ICS_SEWER_OVRFLW_BYPASS_REP_EVT/ICS_SEWER_OVRFLW_TRTMNT
INSERT INTO ICS_FLOW_LOCAL.ICS_SEWER_OVRFLW_TRTMNT (
     ICS_SEWER_OVRFLW_TRTMNT_ID
   , ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID
   , SEWER_OVRFLW_TRTMNT_CODE
   , DATA_HASH)
SELECT 
     null  --ICS_SEWER_OVRFLW_TRTMNT_ID, 
   , null  --ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID, 
   , null  --SEWER_OVRFLW_TRTMNT_CODE, SewerOverflowTreatmentCode
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

END;
