﻿
/*************************************************************************************************
** ObjectName: ics_etl_CSOLongTermControlPlanSubmission
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the CSOLongTermControlPlanSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/18/2025   Windsor      Created 
**
***************************************************************************************************/
CREATE OR REPLACE PROCEDURE ICS_FLOW_LOCAL.ics_etl_CSOLongTermControlPlanSubmission

AS

BEGIN
---------------------------- 
-- ICS_CSO_LONG_TERM_CONTROL_PLAN
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- 
DELETE
  FROM ICS_FLOW_LOCAL.ICS_CSO_LONG_TERM_CONTROL_PLAN;


-- /ICS_CSO_LONG_TERM_CONTROL_PLAN
INSERT INTO ICS_FLOW_LOCAL.ICS_CSO_LONG_TERM_CONTROL_PLAN (
     ICS_CSO_LONG_TERM_CONTROL_PLAN_ID
   , ICS_PAYLOAD_ID
   , SRC_SYSTM_IDENT
   , TRANSACTION_TYPE
   , TRANSACTION_TIMESTAMP
   , PRMT_IDENT
   , KEY_HASH
   , DATA_HASH)
SELECT 
     null  --ICS_CSO_LONG_TERM_CONTROL_PLAN_ID, 
   , null  --ICS_PAYLOAD_ID, 
   , null  --SRC_SYSTM_IDENT, SourceSystemIdentifier
   , null  --TRANSACTION_TYPE, TransactionType
   , null  --TRANSACTION_TIMESTAMP, TransactionTimestamp
   , null  --PRMT_IDENT, PermitIdentifier
   , null  --KEY_HASH, 
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CSO_LONG_TERM_CONTROL_PLAN/ICS_CSO_CONTROL_MEAS_DETAIL
INSERT INTO ICS_FLOW_LOCAL.ICS_CSO_CONTROL_MEAS_DETAIL (
     ICS_CSO_CONTROL_MEAS_DETAIL_ID
   , ICS_CSO_LONG_TERM_CONTROL_PLAN_ID
   , CSO_CONTROL_MEAS_CODE
   , CSO_CONTROL_MEAS_CODE_OTHR_TXT
   , CSO_CONTROL_MEAS_DEV_IMP_STAT
   , CSO_CONTROL_MEAS_CMPL_STAT
   , DATA_HASH)
SELECT 
     null  --ICS_CSO_CONTROL_MEAS_DETAIL_ID, 
   , null  --ICS_CSO_LONG_TERM_CONTROL_PLAN_ID, 
   , null  --CSO_CONTROL_MEAS_CODE, CSOControlMeasureCode
   , null  --CSO_CONTROL_MEAS_CODE_OTHR_TXT, CSOControlMeasureCodeOtherText
   , null  --CSO_CONTROL_MEAS_DEV_IMP_STAT, CSOControlMeasureDevImpStatus
   , null  --CSO_CONTROL_MEAS_CMPL_STAT, CSOControlMeasureComplianceStatus
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CSO_LONG_TERM_CONTROL_PLAN/ICS_LTCP_ENFORCEABLE_MECH_DETAIL
INSERT INTO ICS_FLOW_LOCAL.ICS_LTCP_ENFORCEABLE_MECH_DETAIL (
     ICS_LTCP_ENFORCEABLE_MECH_DETAIL_ID
   , ICS_CSO_LONG_TERM_CONTROL_PLAN_ID
   , LTCP_ENFORCEABLE_MECH_CODE
   , LTCP_ENFORCEABLE_MECH_CODE_OTHR_TXT
   , DATA_HASH)
SELECT 
     null  --ICS_LTCP_ENFORCEABLE_MECH_DETAIL_ID, 
   , null  --ICS_CSO_LONG_TERM_CONTROL_PLAN_ID, 
   , null  --LTCP_ENFORCEABLE_MECH_CODE, LTCPEnforceableMechanismCode
   , null  --LTCP_ENFORCEABLE_MECH_CODE_OTHR_TXT, LTCPEnforceableMechanismCodeOtherText
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CSO_LONG_TERM_CONTROL_PLAN/ICS_LTCP_MOST_RECENT_REVISION_DETAIL
INSERT INTO ICS_FLOW_LOCAL.ICS_LTCP_MOST_RECENT_REVISION_DETAIL (
     ICS_LTCP_MOST_RECENT_REVISION_DETAIL_ID
   , ICS_CSO_LONG_TERM_CONTROL_PLAN_ID
   , LTCP_MOST_RECENT_REVISION_DATE
   , LTCP_MOST_RECENT_REVISION_STAT
   , DATA_HASH)
SELECT 
     null  --ICS_LTCP_MOST_RECENT_REVISION_DETAIL_ID, 
   , null  --ICS_CSO_LONG_TERM_CONTROL_PLAN_ID, 
   , null  --LTCP_MOST_RECENT_REVISION_DATE, LTCPMostRecentRevisionDate
   , null  --LTCP_MOST_RECENT_REVISION_STAT, LTCPMostRecentRevisionStatus
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_CSO_LONG_TERM_CONTROL_PLAN/ICS_LTCP_SUMM
INSERT INTO ICS_FLOW_LOCAL.ICS_LTCP_SUMM (
     ICS_LTCP_SUMM_ID
   , ICS_CSO_LONG_TERM_CONTROL_PLAN_ID
   , LTCP_REQD_IND
   , LTCP_IN_CMPL_IND
   , LTCP_APRVL_DATE
   , LTCP_AND_CSO_CONTROLS_COMPLETE_DATE
   , CSO_POST_CNST_CMPL_MON_PROG
   , CSO_CONTROLS_OTHR_THAN_LTCP
   , DATA_HASH)
SELECT 
     null  --ICS_LTCP_SUMM_ID, 
   , null  --ICS_CSO_LONG_TERM_CONTROL_PLAN_ID, 
   , null  --LTCP_REQD_IND, LTCPRequiredIndicator
   , null  --LTCP_IN_CMPL_IND, LTCPInComplianceIndicator
   , null  --LTCP_APRVL_DATE, LTCPApprovalDate
   , null  --LTCP_AND_CSO_CONTROLS_COMPLETE_DATE, LTCPAndCSOControlsCompleteDate
   , null  --CSO_POST_CNST_CMPL_MON_PROG, CSOPostConstructionComplianceMonitoringProgram
   , null  --CSO_CONTROLS_OTHR_THAN_LTCP, CSOControlsOtherThanLTCP
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

END;
