﻿
/*************************************************************************************************
** ObjectName: ics_etl_DischargeMonitoringReportSubmission
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the DischargeMonitoringReportSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/18/2025   Windsor      Created 
**
***************************************************************************************************/
CREATE OR REPLACE PROCEDURE ICS_FLOW_LOCAL.ics_etl_DischargeMonitoringReportSubmission

AS

BEGIN
---------------------------- 
-- ICS_DSCH_MON_REP
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- 
DELETE
  FROM ICS_FLOW_LOCAL.ICS_DSCH_MON_REP;


-- /ICS_DSCH_MON_REP
INSERT INTO ICS_FLOW_LOCAL.ICS_DSCH_MON_REP (
     ICS_DSCH_MON_REP_ID
   , ICS_PAYLOAD_ID
   , SRC_SYSTM_IDENT
   , TRANSACTION_TYPE
   , TRANSACTION_TIMESTAMP
   , PRMT_IDENT
   , PRMT_FEATR_IDENT
   , LMT_SET_DESIGNATOR
   , MON_PERIOD_END_DATE
   , DMR_NO_DSCH_IND
   , DMR_NO_DSCH_RCVD_DATE
   , ELEC_SUBM_TYPE_CODE
   , SIGN_DATE
   , PRNCPL_EXEC_OFFCR_FIRST_NAME
   , PRNCPL_EXEC_OFFCR_LAST_NAME
   , PRNCPL_EXEC_OFFCR_TITLE
   , PRNCPL_EXEC_OFFCR_TELEPH
   , SIGN_FIRST_NAME
   , SIGN_LAST_NAME
   , SIGN_TELEPH
   , REP_CMNT_TXT
   , KEY_HASH
   , DATA_HASH)
SELECT 
     null  --ICS_DSCH_MON_REP_ID, 
   , null  --ICS_PAYLOAD_ID, 
   , null  --SRC_SYSTM_IDENT, SourceSystemIdentifier
   , null  --TRANSACTION_TYPE, TransactionType
   , null  --TRANSACTION_TIMESTAMP, TransactionTimestamp
   , null  --PRMT_IDENT, PermitIdentifier
   , null  --PRMT_FEATR_IDENT, PermittedFeatureIdentifier
   , null  --LMT_SET_DESIGNATOR, LimitSetDesignator
   , null  --MON_PERIOD_END_DATE, MonitoringPeriodEndDate
   , null  --DMR_NO_DSCH_IND, DMRNoDischargeIndicator
   , null  --DMR_NO_DSCH_RCVD_DATE, DMRNoDischargeReceivedDate
   , null  --ELEC_SUBM_TYPE_CODE, ElectronicSubmissionTypeCode
   , null  --SIGN_DATE, SignatureDate
   , null  --PRNCPL_EXEC_OFFCR_FIRST_NAME, PrincipalExecutiveOfficerFirstName
   , null  --PRNCPL_EXEC_OFFCR_LAST_NAME, PrincipalExecutiveOfficerLastName
   , null  --PRNCPL_EXEC_OFFCR_TITLE, PrincipalExecutiveOfficerTitle
   , null  --PRNCPL_EXEC_OFFCR_TELEPH, PrincipalExecutiveOfficerTelephone
   , null  --SIGN_FIRST_NAME, SignatoryFirstName
   , null  --SIGN_LAST_NAME, SignatoryLastName
   , null  --SIGN_TELEPH, SignatoryTelephone
   , null  --REP_CMNT_TXT, ReportCommentText
   , null  --KEY_HASH, 
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_DSCH_MON_REP/ICS_CO_DSPL_SITE
INSERT INTO ICS_FLOW_LOCAL.ICS_CO_DSPL_SITE (
     ICS_CO_DSPL_SITE_ID
   , ICS_DSCH_MON_REP_ID
   , PART_258_CMPL_IND
   , PAINT_FILTER_TEST_RESULT
   , TCLP_TEST_RESULT
   , DATA_HASH)
SELECT 
     null  --ICS_CO_DSPL_SITE_ID, 
   , null  --ICS_DSCH_MON_REP_ID, 
   , null  --PART_258_CMPL_IND, Part258ComplianceIndicator
   , null  --PAINT_FILTER_TEST_RESULT, PaintFilterTestResult
   , null  --TCLP_TEST_RESULT, TCLPTestResult
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_DSCH_MON_REP/ICS_INCIN
INSERT INTO ICS_FLOW_LOCAL.ICS_INCIN (
     ICS_INCIN_ID
   , ICS_DSCH_MON_REP_ID
   , BERYLLIUM_CMPL_IND
   , MERCURY_CMPL_IND
   , DATA_HASH)
SELECT 
     null  --ICS_INCIN_ID, 
   , null  --ICS_DSCH_MON_REP_ID, 
   , null  --BERYLLIUM_CMPL_IND, BerylliumComplianceIndicator
   , null  --MERCURY_CMPL_IND, MercuryComplianceIndicator
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_DSCH_MON_REP/ICS_LAND_APPL_SITE
INSERT INTO ICS_FLOW_LOCAL.ICS_LAND_APPL_SITE (
     ICS_LAND_APPL_SITE_ID
   , ICS_DSCH_MON_REP_ID
   , POLUT_MET_FOR_LAND_APPL
   , PATHOGEN_REDUCTION_IND
   , VECTOR_REDUCTION_IND
   , AGRONOMIC_GAL_RATE_FOR_FLD
   , AGRONOMIC_DMT_RATE_FOR_FLD
   , CLASS_A_ALT_USED
   , CLASS_A_ALTS_TXT
   , CLASS_B_ALT_USED
   , CLASS_B_ALTS_TXT
   , VAR_ALT_USED
   , VAR_ALTS_TXT
   , DATA_HASH)
SELECT 
     null  --ICS_LAND_APPL_SITE_ID, 
   , null  --ICS_DSCH_MON_REP_ID, 
   , null  --POLUT_MET_FOR_LAND_APPL, PollutantMetForLandApplication
   , null  --PATHOGEN_REDUCTION_IND, PathogenReductionIndicator
   , null  --VECTOR_REDUCTION_IND, VectorReductionIndicator
   , null  --AGRONOMIC_GAL_RATE_FOR_FLD, AgronomicGallonsRateForField
   , null  --AGRONOMIC_DMT_RATE_FOR_FLD, AgronomicDMTRateForField
   , null  --CLASS_A_ALT_USED, ClassAAlternativeUsed
   , null  --CLASS_A_ALTS_TXT, ClassAAlternativesText
   , null  --CLASS_B_ALT_USED, ClassBAlternativeUsed
   , null  --CLASS_B_ALTS_TXT, ClassBAlternativesText
   , null  --VAR_ALT_USED, VARAlternativeUsed
   , null  --VAR_ALTS_TXT, VARAlternativesText
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_DSCH_MON_REP/ICS_LAND_APPL_SITE/ICS_CROP_TYPES_HARVESTED
INSERT INTO ICS_FLOW_LOCAL.ICS_CROP_TYPES_HARVESTED (
     ICS_CROP_TYPES_HARVESTED_ID
   , ICS_LAND_APPL_SITE_ID
   , CROP_TYPES_HARVESTED
   , DATA_HASH)
SELECT 
     null  --ICS_CROP_TYPES_HARVESTED_ID, 
   , null  --ICS_LAND_APPL_SITE_ID, 
   , null  --CROP_TYPES_HARVESTED, CropTypesHarvested
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_DSCH_MON_REP/ICS_LAND_APPL_SITE/ICS_CROP_TYPES_PLANTED
INSERT INTO ICS_FLOW_LOCAL.ICS_CROP_TYPES_PLANTED (
     ICS_CROP_TYPES_PLANTED_ID
   , ICS_LAND_APPL_SITE_ID
   , CROP_TYPES_PLANTED
   , DATA_HASH)
SELECT 
     null  --ICS_CROP_TYPES_PLANTED_ID, 
   , null  --ICS_LAND_APPL_SITE_ID, 
   , null  --CROP_TYPES_PLANTED, CropTypesPlanted
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_DSCH_MON_REP/ICS_REP_PARAM
INSERT INTO ICS_FLOW_LOCAL.ICS_REP_PARAM (
     ICS_REP_PARAM_ID
   , ICS_DSCH_MON_REP_ID
   , PARAM_CODE
   , MON_SITE_DESC_CODE
   , LMT_SEASON_NUM
   , REP_SMPL_TYPE_TXT
   , REP_FREQ_CODE
   , REP_NUM_OF_EXCURSIONS
   , CONCEN_NUM_REP_UNIT_MEAS_CODE
   , QTY_NUM_REP_UNIT_MEAS_CODE
   , DATA_HASH)
SELECT 
     null  --ICS_REP_PARAM_ID, 
   , null  --ICS_DSCH_MON_REP_ID, 
   , null  --PARAM_CODE, ParameterCode
   , null  --MON_SITE_DESC_CODE, MonitoringSiteDescriptionCode
   , null  --LMT_SEASON_NUM, LimitSeasonNumber
   , null  --REP_SMPL_TYPE_TXT, ReportSampleTypeText
   , null  --REP_FREQ_CODE, ReportingFrequencyCode
   , null  --REP_NUM_OF_EXCURSIONS, ReportNumberOfExcursions
   , null  --CONCEN_NUM_REP_UNIT_MEAS_CODE, ConcentrationNumericReportUnitMeasureCode
   , null  --QTY_NUM_REP_UNIT_MEAS_CODE, QuantityNumericReportUnitMeasureCode
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_DSCH_MON_REP/ICS_REP_PARAM/ICS_NUM_REP
INSERT INTO ICS_FLOW_LOCAL.ICS_NUM_REP (
     ICS_NUM_REP_ID
   , ICS_REP_PARAM_ID
   , NUM_REP_CODE
   , NUM_REP_RCVD_DATE
   , NUM_REP_NO_DSCH_IND
   , NUM_COND_QTY
   , NUM_COND_ADJUSTED_QTY
   , NUM_COND_QUALIFIER
   , DATA_HASH)
SELECT 
     null  --ICS_NUM_REP_ID, 
   , null  --ICS_REP_PARAM_ID, 
   , null  --NUM_REP_CODE, NumericReportCode
   , null  --NUM_REP_RCVD_DATE, NumericReportReceivedDate
   , null  --NUM_REP_NO_DSCH_IND, NumericReportNoDischargeIndicator
   , null  --NUM_COND_QTY, NumericConditionQuantity
   , null  --NUM_COND_ADJUSTED_QTY, NumericConditionAdjustedQuantity
   , null  --NUM_COND_QUALIFIER, NumericConditionQualifier
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_DSCH_MON_REP/ICS_SURF_DSPL_SITE
INSERT INTO ICS_FLOW_LOCAL.ICS_SURF_DSPL_SITE (
     ICS_SURF_DSPL_SITE_ID
   , ICS_DSCH_MON_REP_ID
   , PATHOGEN_REDUCTION_IND
   , VECTOR_REDUCTION_IND
   , MGMT_PRACTICE_IND
   , CERT_STATEMENT_IND
   , CERT_FIRST_NAME
   , CERT_LAST_NAME
   , CLASS_A_ALT_USED
   , CLASS_A_ALTS_TXT
   , CLASS_B_ALT_USED
   , CLASS_B_ALTS_TXT
   , VAR_ALT_USED
   , VAR_ALTS_TXT
   , DATA_HASH)
SELECT 
     null  --ICS_SURF_DSPL_SITE_ID, 
   , null  --ICS_DSCH_MON_REP_ID, 
   , null  --PATHOGEN_REDUCTION_IND, PathogenReductionIndicator
   , null  --VECTOR_REDUCTION_IND, VectorReductionIndicator
   , null  --MGMT_PRACTICE_IND, ManagementPracticesIndicator
   , null  --CERT_STATEMENT_IND, CertificationStatementIndicator
   , null  --CERT_FIRST_NAME, CertifierFirstName
   , null  --CERT_LAST_NAME, CertifierLastName
   , null  --CLASS_A_ALT_USED, ClassAAlternativeUsed
   , null  --CLASS_A_ALTS_TXT, ClassAAlternativesText
   , null  --CLASS_B_ALT_USED, ClassBAlternativeUsed
   , null  --CLASS_B_ALTS_TXT, ClassBAlternativesText
   , null  --VAR_ALT_USED, VARAlternativeUsed
   , null  --VAR_ALTS_TXT, VARAlternativesText
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

END;
