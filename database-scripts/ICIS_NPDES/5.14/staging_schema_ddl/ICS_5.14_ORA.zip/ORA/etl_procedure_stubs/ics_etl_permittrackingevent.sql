﻿
/*************************************************************************************************
** ObjectName: ics_etl_PermitTrackingEventSubmission
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the PermitTrackingEventSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/18/2025   Windsor      Created 
**
***************************************************************************************************/
CREATE OR REPLACE PROCEDURE ICS_FLOW_LOCAL.ics_etl_PermitTrackingEventSubmission

AS

BEGIN
---------------------------- 
-- ICS_PRMT_TRACK_EVT
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- 
DELETE
  FROM ICS_FLOW_LOCAL.ICS_PRMT_TRACK_EVT;


-- /ICS_PRMT_TRACK_EVT
INSERT INTO ICS_FLOW_LOCAL.ICS_PRMT_TRACK_EVT (
     ICS_PRMT_TRACK_EVT_ID
   , ICS_PAYLOAD_ID
   , SRC_SYSTM_IDENT
   , TRANSACTION_TYPE
   , TRANSACTION_TIMESTAMP
   , PRMT_IDENT
   , PRMT_TRACK_EVT_CODE
   , PRMT_TRACK_EVT_DATE
   , PRMT_TRACK_CMNTS_TXT
   , KEY_HASH
   , DATA_HASH)
SELECT 
     null  --ICS_PRMT_TRACK_EVT_ID, 
   , null  --ICS_PAYLOAD_ID, 
   , null  --SRC_SYSTM_IDENT, SourceSystemIdentifier
   , null  --TRANSACTION_TYPE, TransactionType
   , null  --TRANSACTION_TIMESTAMP, TransactionTimestamp
   , null  --PRMT_IDENT, PermitIdentifier
   , null  --PRMT_TRACK_EVT_CODE, PermitTrackingEventCode
   , null  --PRMT_TRACK_EVT_DATE, PermitTrackingEventDate
   , null  --PRMT_TRACK_CMNTS_TXT, PermitTrackingCommentsText
   , null  --KEY_HASH, 
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

END;
