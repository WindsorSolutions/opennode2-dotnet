﻿
/*************************************************************************************************
** ObjectName: ics_etl_InformalEnforcementActionSubmission
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure performs the ETL for the InformalEnforcementActionSubmission module
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 3/18/2025   Windsor      Created 
**
***************************************************************************************************/
CREATE OR REPLACE PROCEDURE ICS_FLOW_LOCAL.ics_etl_InformalEnforcementActionSubmission

AS

BEGIN
---------------------------- 
-- ICS_INFRML_ENFRC_ACTN
---------------------------- 

-- DELETE statements are for 'purge and replace' approach to ETL
-- 
DELETE
  FROM ICS_FLOW_LOCAL.ICS_INFRML_ENFRC_ACTN;


-- /ICS_INFRML_ENFRC_ACTN
INSERT INTO ICS_FLOW_LOCAL.ICS_INFRML_ENFRC_ACTN (
     ICS_INFRML_ENFRC_ACTN_ID
   , ICS_PAYLOAD_ID
   , SRC_SYSTM_IDENT
   , TRANSACTION_TYPE
   , TRANSACTION_TIMESTAMP
   , ENFRC_ACTN_IDENT
   , ENFRC_ACTN_TYPE_CODE
   , ENFRC_ACTN_NAME
   , ACHIEVED_DATE
   , FILE_NUM
   , REASON_DELETING_RECORD
   , INFRML_EA_CMNT_TXT
   , INFRML_EA_USR_DFND_FLD_1
   , INFRML_EA_USR_DFND_FLD_2
   , INFRML_EA_USR_DFND_FLD_3
   , INFRML_EA_USR_DFND_FLD_4
   , INFRML_EA_USR_DFND_FLD_5
   , INFRML_EA_USR_DFND_FLD_6
   , ENFRC_AGNCY_NAME
   , KEY_HASH
   , DATA_HASH)
SELECT 
     null  --ICS_INFRML_ENFRC_ACTN_ID, 
   , null  --ICS_PAYLOAD_ID, 
   , null  --SRC_SYSTM_IDENT, SourceSystemIdentifier
   , null  --TRANSACTION_TYPE, TransactionType
   , null  --TRANSACTION_TIMESTAMP, TransactionTimestamp
   , null  --ENFRC_ACTN_IDENT, EnforcementActionIdentifier
   , null  --ENFRC_ACTN_TYPE_CODE, EnforcementActionTypeCode
   , null  --ENFRC_ACTN_NAME, EnforcementActionName
   , null  --ACHIEVED_DATE, AchievedDate
   , null  --FILE_NUM, FileNumber
   , null  --REASON_DELETING_RECORD, ReasonDeletingRecord
   , null  --INFRML_EA_CMNT_TXT, InformalEACommentText
   , null  --INFRML_EA_USR_DFND_FLD_1, InformalEAUserDefinedField1
   , null  --INFRML_EA_USR_DFND_FLD_2, InformalEAUserDefinedField2
   , null  --INFRML_EA_USR_DFND_FLD_3, InformalEAUserDefinedField3
   , null  --INFRML_EA_USR_DFND_FLD_4, InformalEAUserDefinedField4
   , null  --INFRML_EA_USR_DFND_FLD_5, InformalEAUserDefinedField5
   , null  --INFRML_EA_USR_DFND_FLD_6, InformalEAUserDefinedField6
   , null  --ENFRC_AGNCY_NAME, EnforcementAgencyName
   , null  --KEY_HASH, 
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_INFRML_ENFRC_ACTN/ICS_ENFRC_ACTN_GOV_CONTACT
INSERT INTO ICS_FLOW_LOCAL.ICS_ENFRC_ACTN_GOV_CONTACT (
     ICS_ENFRC_ACTN_GOV_CONTACT_ID
   , ICS_FRML_ENFRC_ACTN_ID
   , ICS_INFRML_ENFRC_ACTN_ID
   , AFFIL_TYPE_TXT
   , ELEC_ADDR_TXT
   , START_DATE_OF_CONTACT_ASSC
   , END_DATE_OF_CONTACT_ASSC
   , DATA_HASH)
SELECT 
     null  --ICS_ENFRC_ACTN_GOV_CONTACT_ID, 
   , null  --ICS_FRML_ENFRC_ACTN_ID, 
   , null  --ICS_INFRML_ENFRC_ACTN_ID, 
   , null  --AFFIL_TYPE_TXT, AffiliationTypeText
   , null  --ELEC_ADDR_TXT, ElectronicAddressText
   , null  --START_DATE_OF_CONTACT_ASSC, StartDateOfContactAssociation
   , null  --END_DATE_OF_CONTACT_ASSC, EndDateOfContactAssociation
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_INFRML_ENFRC_ACTN/ICS_ENFRC_AGNCY
INSERT INTO ICS_FLOW_LOCAL.ICS_ENFRC_AGNCY (
     ICS_ENFRC_AGNCY_ID
   , ICS_FRML_ENFRC_ACTN_ID
   , ICS_INFRML_ENFRC_ACTN_ID
   , ENFRC_AGNCY_TYPE_CODE
   , AGNCY_LEAD_IND
   , DATA_HASH)
SELECT 
     null  --ICS_ENFRC_AGNCY_ID, 
   , null  --ICS_FRML_ENFRC_ACTN_ID, 
   , null  --ICS_INFRML_ENFRC_ACTN_ID, 
   , null  --ENFRC_AGNCY_TYPE_CODE, EnforcementAgencyTypeCode
   , null  --AGNCY_LEAD_IND, AgencyLeadIndicator
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_INFRML_ENFRC_ACTN/ICS_PRMT_IDENT
INSERT INTO ICS_FLOW_LOCAL.ICS_PRMT_IDENT (
     ICS_PRMT_IDENT_ID
   , ICS_FRML_ENFRC_ACTN_ID
   , ICS_INFRML_ENFRC_ACTN_ID
   , PRMT_IDENT
   , DATA_HASH)
SELECT 
     null  --ICS_PRMT_IDENT_ID, 
   , null  --ICS_FRML_ENFRC_ACTN_ID, 
   , null  --ICS_INFRML_ENFRC_ACTN_ID, 
   , null  --PRMT_IDENT, PermitIdentifier
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

-- /ICS_INFRML_ENFRC_ACTN/ICS_PROGS_VIOL
INSERT INTO ICS_FLOW_LOCAL.ICS_PROGS_VIOL (
     ICS_PROGS_VIOL_ID
   , ICS_FRML_ENFRC_ACTN_ID
   , ICS_INFRML_ENFRC_ACTN_ID
   , PROGS_VIOL_CODE
   , DATA_HASH)
SELECT 
     null  --ICS_PROGS_VIOL_ID, 
   , null  --ICS_FRML_ENFRC_ACTN_ID, 
   , null  --ICS_INFRML_ENFRC_ACTN_ID, 
   , null  --PROGS_VIOL_CODE, ProgramsViolatedCode
   , null  --DATA_HASH, 
WHERE 1 = 0; --mapping row not found!

END;
