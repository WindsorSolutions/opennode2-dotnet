CREATE OR REPLACE PROCEDURE ics_process_accepted_trans (p_transaction_id IN varchar2) AS

/*
Copyright (c) 2012, The Environmental Council of the States (ECOS)
All rights reserved.
 
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
 
 * Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
 * Neither the name of the ECOS nor the names of its contributors may
   be used to endorse or promote products derived from this software
   without specific prior written permission.
 
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/

/*************************************************************************************************
** Object Name: ics_process_accepted_trans
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure uses the data in ICS_SUBM_RESULTS table to copy the data for accepted
**               transactions from the LOCAL to ICIS schema/database. It should only be executed by
**               the OpenNode2 plugin as part of the GetICISStatusAndProcessReports service execution
**
** Notes:  Step 1: Remove processing results from previous submissions
**         Step 2: Update key_hash with hashed business key data
**         Step 3: Move accepted transactions from LOCAL to ICIS database
**         Step 4: Copy business keys where ICIS returnes error that key is already present in ICIS
**         Step 5: Record counts into ICS_SUBM_HIST
**         
**         Quit procedure if no records are returned relating to the current transaction. ICIS will return 
**         an empty processing report if there is a severe error in the ICIS submission processor at EPA.
**
** Revision History:
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 2025-04-16    CTyler      Recreated for 5.14 , 
** 2025-05-20    CTyler      Added OECA Assume all data section
** 2025-06-09    CTyler     Conditional grant to ICS_FLOW_LOCAL_USER since not usually used
***************************************************************************************************/


v_count number;

BEGIN

-- ==============================================================
-- OECA Assume All Data Accepted 
--
-- This logic assumes that all data sent was accepted for OECA.
-- This may change in the future if results are returned
-- ==============================================================
insert into ICS_FLOW_LOCAL.ICS_SUBM_RESULTS (ICS_SUBM_RESULTS_ID,TRANSACTION_TYPE,SUBM_TRANSACTION_ID,CREATED_DATE_TIME,RESULT_TYPE_CODE,SUBM_TYPE_NAME,PRMT_IDENT,PROG_REP_FORM_SET_ID,PROG_REP_FORM_ID) select sys_guid() as ICS_SUBM_RESULTS_ID,'R' as TRANSACTION_TYPE,p_transaction_id as SUBM_TRANSACTION_ID,SYSDATE as CREATE_DATE_TIME,'Accepted' as RESULT_TYPE_CODE,'BiosolidsAnnualProgramReportSubmission',PRMT_IDENT,PROG_REP_FORM_SET_ID,PROG_REP_FORM_ID from ICS_FLOW_LOCAL.ICS_BS_ANNUL_PROG_REP WHERE TRANSACTION_TYPE is not null;
insert into ICS_FLOW_LOCAL.ICS_SUBM_RESULTS (ICS_SUBM_RESULTS_ID,TRANSACTION_TYPE,SUBM_TRANSACTION_ID,CREATED_DATE_TIME,RESULT_TYPE_CODE,SUBM_TYPE_NAME,PRMT_IDENT,PROG_REP_FORM_SET_ID,PROG_REP_FORM_ID) select sys_guid() as ICS_SUBM_RESULTS_ID,'R' as TRANSACTION_TYPE,p_transaction_id as SUBM_TRANSACTION_ID,SYSDATE as CREATE_DATE_TIME,'Accepted' as RESULT_TYPE_CODE,'CAFOAnnualProgramReportSubmission',PRMT_IDENT,PROG_REP_FORM_SET_ID,PROG_REP_FORM_ID from ICS_FLOW_LOCAL.ICS_CAFO_ANNUL_PROG_REP WHERE TRANSACTION_TYPE is not null;
insert into ICS_FLOW_LOCAL.ICS_SUBM_RESULTS (ICS_SUBM_RESULTS_ID,TRANSACTION_TYPE,SUBM_TRANSACTION_ID,CREATED_DATE_TIME,RESULT_TYPE_CODE,SUBM_TYPE_NAME,PRMT_IDENT,COLL_SYSTM_IDENT) select sys_guid() as ICS_SUBM_RESULTS_ID,'R' as TRANSACTION_TYPE,p_transaction_id as SUBM_TRANSACTION_ID,SYSDATE as CREATE_DATE_TIME,'Accepted' as RESULT_TYPE_CODE,'CollectionSystemPermitSubmission',PRMT_IDENT,COLL_SYSTM_IDENT from ICS_FLOW_LOCAL.ICS_COLL_SYSTM_PRMT WHERE TRANSACTION_TYPE is not null;
insert into ICS_FLOW_LOCAL.ICS_SUBM_RESULTS (ICS_SUBM_RESULTS_ID,TRANSACTION_TYPE,SUBM_TRANSACTION_ID,CREATED_DATE_TIME,RESULT_TYPE_CODE,SUBM_TYPE_NAME,PRMT_IDENT) select sys_guid() as ICS_SUBM_RESULTS_ID,'R' as TRANSACTION_TYPE,p_transaction_id as SUBM_TRANSACTION_ID,SYSDATE as CREATE_DATE_TIME,'Accepted' as RESULT_TYPE_CODE,'CopyMGPMS4RequirementSubmission',PRMT_IDENT from ICS_FLOW_LOCAL.ICS_COPY_MGPMS_4_REQ WHERE TRANSACTION_TYPE is not null;
insert into ICS_FLOW_LOCAL.ICS_SUBM_RESULTS (ICS_SUBM_RESULTS_ID,TRANSACTION_TYPE,SUBM_TRANSACTION_ID,CREATED_DATE_TIME,RESULT_TYPE_CODE,SUBM_TYPE_NAME,PRMT_IDENT) select sys_guid() as ICS_SUBM_RESULTS_ID,'R' as TRANSACTION_TYPE,p_transaction_id as SUBM_TRANSACTION_ID,SYSDATE as CREATE_DATE_TIME,'Accepted' as RESULT_TYPE_CODE,'CSOLongTermControlPlanSubmission',PRMT_IDENT from ICS_FLOW_LOCAL.ICS_CSO_LONG_TERM_CONTROL_PLAN WHERE TRANSACTION_TYPE is not null;
insert into ICS_FLOW_LOCAL.ICS_SUBM_RESULTS (ICS_SUBM_RESULTS_ID,TRANSACTION_TYPE,SUBM_TRANSACTION_ID,CREATED_DATE_TIME,RESULT_TYPE_CODE,SUBM_TYPE_NAME,PRMT_IDENT,PROG_REP_FORM_SET_ID,PROG_REP_FORM_ID) select sys_guid() as ICS_SUBM_RESULTS_ID,'R' as TRANSACTION_TYPE,p_transaction_id as SUBM_TRANSACTION_ID,SYSDATE as CREATE_DATE_TIME,'Accepted' as RESULT_TYPE_CODE,'CWA316bProgramReportSubmission',PRMT_IDENT,PROG_REP_FORM_SET_ID,PROG_REP_FORM_ID from ICS_FLOW_LOCAL.ICS_CWA_316B_PROG_REP WHERE TRANSACTION_TYPE is not null;
insert into ICS_FLOW_LOCAL.ICS_SUBM_RESULTS (ICS_SUBM_RESULTS_ID,TRANSACTION_TYPE,SUBM_TRANSACTION_ID,CREATED_DATE_TIME,RESULT_TYPE_CODE,SUBM_TYPE_NAME,PRMT_IDENT,NPDES_VARIANCE_TYPE_CODE,NPDES_VARIANCE_SUBM_DATE) select sys_guid() as ICS_SUBM_RESULTS_ID,'R' as TRANSACTION_TYPE,p_transaction_id as SUBM_TRANSACTION_ID,SYSDATE as CREATE_DATE_TIME,'Accepted' as RESULT_TYPE_CODE,'NPDESVariancePermitSubmission',PRMT_IDENT,NPDES_VARIANCE_TYPE_CODE,NPDES_VARIANCE_SUBM_DATE from ICS_FLOW_LOCAL.ICS_NPDES_VARIANCE_PRMT WHERE TRANSACTION_TYPE is not null;
insert into ICS_FLOW_LOCAL.ICS_SUBM_RESULTS (ICS_SUBM_RESULTS_ID,TRANSACTION_TYPE,SUBM_TRANSACTION_ID,CREATED_DATE_TIME,RESULT_TYPE_CODE,SUBM_TYPE_NAME,PRMT_IDENT) select sys_guid() as ICS_SUBM_RESULTS_ID,'R' as TRANSACTION_TYPE,p_transaction_id as SUBM_TRANSACTION_ID,SYSDATE as CREATE_DATE_TIME,'Accepted' as RESULT_TYPE_CODE,'POTWTreatmentTechnologyPermitSubmission',PRMT_IDENT from ICS_FLOW_LOCAL.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT WHERE TRANSACTION_TYPE is not null;
insert into ICS_FLOW_LOCAL.ICS_SUBM_RESULTS (ICS_SUBM_RESULTS_ID,TRANSACTION_TYPE,SUBM_TRANSACTION_ID,CREATED_DATE_TIME,RESULT_TYPE_CODE,SUBM_TYPE_NAME,PRMT_IDENT,PROG_REP_FORM_SET_ID,PROG_REP_FORM_ID) select sys_guid() as ICS_SUBM_RESULTS_ID,'R' as TRANSACTION_TYPE,p_transaction_id as SUBM_TRANSACTION_ID,SYSDATE as CREATE_DATE_TIME,'Accepted' as RESULT_TYPE_CODE,'PretreatmentProgramReportSubmission',PRMT_IDENT,PROG_REP_FORM_SET_ID,PROG_REP_FORM_ID from ICS_FLOW_LOCAL.ICS_PRETR_PROG_REP WHERE TRANSACTION_TYPE is not null;
insert into ICS_FLOW_LOCAL.ICS_SUBM_RESULTS (ICS_SUBM_RESULTS_ID,TRANSACTION_TYPE,SUBM_TRANSACTION_ID,CREATED_DATE_TIME,RESULT_TYPE_CODE,SUBM_TYPE_NAME,PRMT_IDENT,PROG_REP_FORM_SET_ID,PROG_REP_FORM_ID) select sys_guid() as ICS_SUBM_RESULTS_ID,'R' as TRANSACTION_TYPE,p_transaction_id as SUBM_TRANSACTION_ID,SYSDATE as CREATE_DATE_TIME,'Accepted' as RESULT_TYPE_CODE,'SewerOverflowBypassEventReportSubmission',PRMT_IDENT,PROG_REP_FORM_SET_ID,PROG_REP_FORM_ID from ICS_FLOW_LOCAL.ICS_SEWER_OVRFLW_BYPASS_EVT_REP WHERE TRANSACTION_TYPE is not null;
insert into ICS_FLOW_LOCAL.ICS_SUBM_RESULTS (ICS_SUBM_RESULTS_ID,TRANSACTION_TYPE,SUBM_TRANSACTION_ID,CREATED_DATE_TIME,RESULT_TYPE_CODE,SUBM_TYPE_NAME,PRMT_IDENT,PROG_REP_FORM_SET_ID,PROG_REP_FORM_ID) select sys_guid() as ICS_SUBM_RESULTS_ID,'R' as TRANSACTION_TYPE,p_transaction_id as SUBM_TRANSACTION_ID,SYSDATE as CREATE_DATE_TIME,'Accepted' as RESULT_TYPE_CODE,'SWMS4AnnualProgramReportSubmission',PRMT_IDENT,PROG_REP_FORM_SET_ID,PROG_REP_FORM_ID from ICS_FLOW_LOCAL.ICS_SWMS_4_ANNUL_PROG_REP WHERE TRANSACTION_TYPE is not null;
insert into ICS_FLOW_LOCAL.ICS_SUBM_RESULTS (ICS_SUBM_RESULTS_ID,TRANSACTION_TYPE,SUBM_TRANSACTION_ID,CREATED_DATE_TIME,RESULT_TYPE_CODE,SUBM_TYPE_NAME,PRMT_IDENT) select sys_guid() as ICS_SUBM_RESULTS_ID,'R' as TRANSACTION_TYPE,p_transaction_id as SUBM_TRANSACTION_ID,SYSDATE as CREATE_DATE_TIME,'Accepted' as RESULT_TYPE_CODE,'SWMS4PermitSubmission',PRMT_IDENT from ICS_FLOW_LOCAL.ICS_SWMS_4_PRMT WHERE TRANSACTION_TYPE is not null;



SELECT COUNT(1) INTO v_count FROM ics_subm_results WHERE subm_transaction_id = p_transaction_id;

IF v_count = 0 THEN
   RETURN;
END IF;

--Step 1: Remove processing results from previous submissions

    --Remove all old Accepted records
    DELETE 
      FROM ics_subm_results 
     WHERE (result_type_code = 'Accepted' OR result_code IN ('DMR300', 'BGP010'))
       AND subm_transaction_id != p_transaction_id;
       
    --Delete errors if there was at least one accepted transaction for the same submission type in the latest submission 
    DELETE 
      FROM ics_subm_results 
     WHERE result_type_code IN ('Error','Warning')
       AND subm_type_name IN (SELECT subm_type_name
	                              FROM ics_subm_results
                               WHERE subm_transaction_id = p_transaction_id
                                 AND subm_type_name <> 'DischargeMonitoringReportSubmission'
                                 AND result_type_code = 'Accepted')
       AND subm_transaction_id != p_transaction_id;

    --Remove previous DMR error transactions where same business key values exist in the most recent submission
    --This will leave previous DMR errors in the results table that have not yet been corrected.
    DELETE
      FROM ics_subm_results
     WHERE subm_type_name = 'DischargeMonitoringReportSubmission'
       AND subm_transaction_id != p_transaction_id
       AND result_type_code = 'Error'
       AND EXISTS (SELECT 1
             FROM ics_subm_results r
            WHERE r.subm_type_name = 'DischargeMonitoringReportSubmission'
              AND r.subm_transaction_id = p_transaction_id
              AND r.prmt_ident         = ics_subm_results.prmt_ident
              AND r.prmt_featr_ident   = ics_subm_results.prmt_featr_ident
              AND r.lmt_set_designator = ics_subm_results.lmt_set_designator
              AND r.param_code         = ics_subm_results.param_code
              AND r.mon_site_desc_code = ics_subm_results.mon_site_desc_code
              AND r.lmt_season_num     = ics_subm_results.lmt_season_num);
 

--Step 2: Update key_hash with hashed business key data
UPDATE ics_subm_results
   SET key_hash = MD5_HASH(prmt_ident)
 WHERE subm_transaction_id = p_transaction_id
   AND subm_type_name IN ('BasicPermitSubmission'
                         ,'BiosolidsPermitSubmission'
                         ,'CAFOPermitSubmission'
                         ,'CSOPermitSubmission'
                         ,'GeneralPermitSubmission'
                         ,'MasterGeneralPermitSubmission'
                         ,'PermitReissuanceSubmission'
                         ,'PermitTerminationSubmission'
                         ,'POTWPermitSubmission'
                         ,'PretreatmentPermitSubmission'
                         ,'SWConstructionPermitSubmission'
                         ,'SWIndustrialPermitSubmission'
                         ,'SWMS4LargePermitSubmission'
                         ,'SWMS4SmallPermitSubmission'
                         ,'UnpermittedFacilitySubmission');


-- KEYHASH for ICS_BASIC_PRMT
UPDATE ics_subm_results
   SET key_hash = MD5_HASH(
		PRMT_IDENT 
	)
 WHERE subm_type_name = 'BasicPermitSubmission'
   AND subm_transaction_id = p_transaction_id;


-- KEYHASH for ICS_BS_ANNUL_PROG_REP
UPDATE ics_subm_results
   SET key_hash = MD5_HASH(
		PRMT_IDENT 
		||PROG_REP_FORM_SET_ID 
		||PROG_REP_FORM_ID 
	)
 WHERE subm_type_name = 'BiosolidsAnnualProgramReportSubmission'
   AND subm_transaction_id = p_transaction_id;


-- KEYHASH for ICS_BS_PRMT
UPDATE ics_subm_results
   SET key_hash = MD5_HASH(
		PRMT_IDENT 
	)
 WHERE subm_type_name = 'BiosolidsPermitSubmission'
   AND subm_transaction_id = p_transaction_id;


-- KEYHASH for ICS_CAFO_ANNUL_PROG_REP
UPDATE ics_subm_results
   SET key_hash = MD5_HASH(
		PRMT_IDENT 
		||PROG_REP_FORM_SET_ID 
		||PROG_REP_FORM_ID 
	)
 WHERE subm_type_name = 'CAFOAnnualProgramReportSubmission'
   AND subm_transaction_id = p_transaction_id;


-- KEYHASH for ICS_CAFO_PRMT
UPDATE ics_subm_results
   SET key_hash = MD5_HASH(
		PRMT_IDENT 
	)
 WHERE subm_type_name = 'CAFOPermitSubmission'
   AND subm_transaction_id = p_transaction_id;


-- KEYHASH for ICS_COLL_SYSTM_PRMT
UPDATE ics_subm_results
   SET key_hash = MD5_HASH(
		PRMT_IDENT 
		||COLL_SYSTM_IDENT 
	)
 WHERE subm_type_name = 'CollectionSystemPermitSubmission'
   AND subm_transaction_id = p_transaction_id;


-- KEYHASH for ICS_CMPL_MON
UPDATE ics_subm_results
   SET key_hash = MD5_HASH(
		CMPL_MON_IDENT 
	)
 WHERE subm_type_name = 'ComplianceMonitoringSubmission'
   AND subm_transaction_id = p_transaction_id;


-- KEYHASH for ICS_CMPL_SCHD
UPDATE ics_subm_results
   SET key_hash = MD5_HASH(
		ENFRC_ACTN_IDENT 
		||FINAL_ORDER_IDENT 
		||PRMT_IDENT 
		||CMPL_SCHD_NUM 
	)
 WHERE subm_type_name = 'ComplianceScheduleSubmission'
   AND subm_transaction_id = p_transaction_id;


-- KEYHASH for ICS_COPY_MGP_LMT_SET
UPDATE ics_subm_results
   SET key_hash = MD5_HASH(
		PRMT_IDENT 
		||PRMT_FEATR_IDENT 
		||LMT_SET_DESIGNATOR 
	)
 WHERE subm_type_name = 'CopyMGPLimitSetSubmission'
   AND subm_transaction_id = p_transaction_id;


-- KEYHASH for ICS_COPY_MGPMS_4_REQ
UPDATE ics_subm_results
   SET key_hash = MD5_HASH(
		PRMT_IDENT 
	)
 WHERE subm_type_name = 'CopyMGPMS4RequirementSubmission'
   AND subm_transaction_id = p_transaction_id;


-- KEYHASH for ICS_CSO_LONG_TERM_CONTROL_PLAN
UPDATE ics_subm_results
   SET key_hash = MD5_HASH(
		PRMT_IDENT 
	)
 WHERE subm_type_name = 'CSOLongTermControlPlanSubmission'
   AND subm_transaction_id = p_transaction_id;


-- KEYHASH for ICS_CWA_316B_PROG_REP
UPDATE ics_subm_results
   SET key_hash = MD5_HASH(
		PRMT_IDENT 
		||PROG_REP_FORM_SET_ID 
		||PROG_REP_FORM_ID 
	)
 WHERE subm_type_name = 'CWA316bProgramReportSubmission'
   AND subm_transaction_id = p_transaction_id;


-- KEYHASH for ICS_DSCH_MON_REP
UPDATE ics_subm_results
   SET key_hash = MD5_HASH(
		PRMT_IDENT 
		||PRMT_FEATR_IDENT 
		||LMT_SET_DESIGNATOR 
		||MON_PERIOD_END_DATE 
	)
 WHERE subm_type_name = 'DischargeMonitoringReportSubmission'
   AND subm_transaction_id = p_transaction_id;


-- KEYHASH for ICS_DMR_VIOL
UPDATE ics_subm_results
   SET key_hash = MD5_HASH(
		PRMT_IDENT 
		||PRMT_FEATR_IDENT 
		||LMT_SET_DESIGNATOR 
		||MON_PERIOD_END_DATE 
		||PARAM_CODE 
		||MON_SITE_DESC_CODE 
		||LMT_SEASON_NUM 
		||NUM_REP_CODE 
		||NUM_REP_VIOL_CODE 
	)
 WHERE subm_type_name = 'DMRViolationSubmission'
   AND subm_transaction_id = p_transaction_id;


-- KEYHASH for ICS_EFFLU_TRADE_PRTNER
UPDATE ics_subm_results
   SET key_hash = MD5_HASH(
		PRMT_IDENT 
		||PRMT_FEATR_IDENT 
		||LMT_SET_DESIGNATOR 
		||PARAM_CODE 
		||MON_SITE_DESC_CODE 
		||LMT_SEASON_NUM 
		||LMT_START_DATE 
		||LMT_END_DATE 
		||LMT_MOD_EFFECTIVE_DATE 
		||TRADE_ID 
	)
 WHERE subm_type_name = 'EffluentTradePartnerSubmission'
   AND subm_transaction_id = p_transaction_id;


-- KEYHASH for ICS_ENFRC_ACTN_MILESTONE
UPDATE ics_subm_results
   SET key_hash = MD5_HASH(
		ENFRC_ACTN_IDENT 
		||MILESTONE_TYPE_CODE 
	)
 WHERE subm_type_name = 'EnforcementActionMilestoneSubmission'
   AND subm_transaction_id = p_transaction_id;


-- KEYHASH for ICS_FRML_ENFRC_ACTN
UPDATE ics_subm_results
   SET key_hash = MD5_HASH(
		ENFRC_ACTN_IDENT 
	)
 WHERE subm_type_name = 'FormalEnforcementActionSubmission'
   AND subm_transaction_id = p_transaction_id;


-- KEYHASH for ICS_GNRL_PRMT
UPDATE ics_subm_results
   SET key_hash = MD5_HASH(
		PRMT_IDENT 
	)
 WHERE subm_type_name = 'GeneralPermitSubmission'
   AND subm_transaction_id = p_transaction_id;


-- KEYHASH for ICS_HIST_PRMT_SCHD_EVTS
UPDATE ics_subm_results
   SET key_hash = MD5_HASH(
		PRMT_IDENT 
		||PRMT_EFFECTIVE_DATE 
		||NARR_COND_NUM 
		||SCHD_EVT_CODE 
		||SCHD_DATE 
	)
 WHERE subm_type_name = 'HistoricalPermitScheduleEventsSubmission'
   AND subm_transaction_id = p_transaction_id;


-- KEYHASH for ICS_INFRML_ENFRC_ACTN
UPDATE ics_subm_results
   SET key_hash = MD5_HASH(
		ENFRC_ACTN_IDENT 
	)
 WHERE subm_type_name = 'InformalEnforcementActionSubmission'
   AND subm_transaction_id = p_transaction_id;


-- KEYHASH for ICS_LMTS
UPDATE ics_subm_results
   SET key_hash = MD5_HASH(
		PRMT_IDENT 
		||PRMT_FEATR_IDENT 
		||LMT_SET_DESIGNATOR 
		||PARAM_CODE 
		||MON_SITE_DESC_CODE 
		||LMT_SEASON_NUM 
		||LMT_START_DATE 
		||LMT_END_DATE 
	)
 WHERE subm_type_name = 'LimitsSubmission'
   AND subm_transaction_id = p_transaction_id;


-- KEYHASH for ICS_LMT_SET
UPDATE ics_subm_results
   SET key_hash = MD5_HASH(
		PRMT_IDENT 
		||PRMT_FEATR_IDENT 
		||LMT_SET_DESIGNATOR 
	)
 WHERE subm_type_name = 'LimitSetSubmission'
   AND subm_transaction_id = p_transaction_id;


-- KEYHASH for ICS_MASTER_GNRL_PRMT
UPDATE ics_subm_results
   SET key_hash = MD5_HASH(
		PRMT_IDENT 
	)
 WHERE subm_type_name = 'MasterGeneralPermitSubmission'
   AND subm_transaction_id = p_transaction_id;


-- KEYHASH for ICS_NARR_COND_SCHD
UPDATE ics_subm_results
   SET key_hash = MD5_HASH(
		PRMT_IDENT 
		||NARR_COND_NUM 
	)
 WHERE subm_type_name = 'NarrativeConditionScheduleSubmission'
   AND subm_transaction_id = p_transaction_id;


-- KEYHASH for ICS_NPDES_VARIANCE_PRMT
UPDATE ics_subm_results
   SET key_hash = MD5_HASH(
		PRMT_IDENT 
		||NPDES_VARIANCE_TYPE_CODE 
		||NPDES_VARIANCE_SUBM_DATE 
	)
 WHERE subm_type_name = 'NPDESVariancePermitSubmission'
   AND subm_transaction_id = p_transaction_id;


-- KEYHASH for ICS_PARAM_LMTS
UPDATE ics_subm_results
   SET key_hash = MD5_HASH(
		PRMT_IDENT 
		||PRMT_FEATR_IDENT 
		||LMT_SET_DESIGNATOR 
		||PARAM_CODE 
		||MON_SITE_DESC_CODE 
		||LMT_SEASON_NUM 
	)
 WHERE subm_type_name = 'ParameterLimitsSubmission'
   AND subm_transaction_id = p_transaction_id;


-- KEYHASH for ICS_PRMT_REISSU
UPDATE ics_subm_results
   SET key_hash = MD5_HASH(
		PRMT_IDENT 
		||PRMT_ISSUE_DATE 
	)
 WHERE subm_type_name = 'PermitReissuanceSubmission'
   AND subm_transaction_id = p_transaction_id;


-- KEYHASH for ICS_PRMT_FEATR
UPDATE ics_subm_results
   SET key_hash = MD5_HASH(
		PRMT_IDENT 
		||PRMT_FEATR_IDENT 
	)
 WHERE subm_type_name = 'PermittedFeatureSubmission'
   AND subm_transaction_id = p_transaction_id;


-- KEYHASH for ICS_PRMT_TERM
UPDATE ics_subm_results
   SET key_hash = MD5_HASH(
		PRMT_IDENT 
	)
 WHERE subm_type_name = 'PermitTerminationSubmission'
   AND subm_transaction_id = p_transaction_id;


-- KEYHASH for ICS_PRMT_TRACK_EVT
UPDATE ics_subm_results
   SET key_hash = MD5_HASH(
		PRMT_IDENT 
		||PRMT_TRACK_EVT_CODE 
		||PRMT_TRACK_EVT_DATE 
	)
 WHERE subm_type_name = 'PermitTrackingEventSubmission'
   AND subm_transaction_id = p_transaction_id;


-- KEYHASH for ICS_POTW_PRMT
UPDATE ics_subm_results
   SET key_hash = MD5_HASH(
		PRMT_IDENT 
	)
 WHERE subm_type_name = 'POTWPermitSubmission'
   AND subm_transaction_id = p_transaction_id;


-- KEYHASH for ICS_POTW_TRTMNT_TECHNOLOGY_PRMT
UPDATE ics_subm_results
   SET key_hash = MD5_HASH(
		PRMT_IDENT 
	)
 WHERE subm_type_name = 'POTWTreatmentTechnologyPermitSubmission'
   AND subm_transaction_id = p_transaction_id;


-- KEYHASH for ICS_PRETR_PRMT
UPDATE ics_subm_results
   SET key_hash = MD5_HASH(
		PRMT_IDENT 
	)
 WHERE subm_type_name = 'PretreatmentPermitSubmission'
   AND subm_transaction_id = p_transaction_id;


-- KEYHASH for ICS_PRETR_PROG_REP
UPDATE ics_subm_results
   SET key_hash = MD5_HASH(
		PRMT_IDENT 
		||PROG_REP_FORM_SET_ID 
		||PROG_REP_FORM_ID 
	)
 WHERE subm_type_name = 'PretreatmentProgramReportSubmission'
   AND subm_transaction_id = p_transaction_id;


-- KEYHASH for ICS_SEWER_OVRFLW_BYPASS_EVT_REP
UPDATE ics_subm_results
   SET key_hash = MD5_HASH(
		PRMT_IDENT 
		||PROG_REP_FORM_SET_ID 
		||PROG_REP_FORM_ID 
	)
 WHERE subm_type_name = 'SewerOverflowBypassEventReportSubmission'
   AND subm_transaction_id = p_transaction_id;


-- KEYHASH for ICS_SNGL_EVT_VIOL
UPDATE ics_subm_results
   SET key_hash = MD5_HASH(
		PRMT_IDENT 
		||SNGL_EVT_VIOL_CODE 
		||SNGL_EVT_VIOL_DATE 
	)
 WHERE subm_type_name = 'SingleEventViolationSubmission'
   AND subm_transaction_id = p_transaction_id;


-- KEYHASH for ICS_SW_CNST_PRMT
UPDATE ics_subm_results
   SET key_hash = MD5_HASH(
		PRMT_IDENT 
	)
 WHERE subm_type_name = 'SWConstructionPermitSubmission'
   AND subm_transaction_id = p_transaction_id;


-- KEYHASH for ICS_SW_INDST_ANNUL_REP
UPDATE ics_subm_results
   SET key_hash = MD5_HASH(
		PRMT_IDENT 
		||INDST_SW_ANNUL_REP_RCVD_DATE 
	)
 WHERE subm_type_name = 'SWIndustrialAnnualReportSubmission'
   AND subm_transaction_id = p_transaction_id;


-- KEYHASH for ICS_SW_INDST_PRMT
UPDATE ics_subm_results
   SET key_hash = MD5_HASH(
		PRMT_IDENT 
	)
 WHERE subm_type_name = 'SWIndustrialPermitSubmission'
   AND subm_transaction_id = p_transaction_id;


-- KEYHASH for ICS_SWMS_4_ANNUL_PROG_REP
UPDATE ics_subm_results
   SET key_hash = MD5_HASH(
		PRMT_IDENT 
		||PROG_REP_FORM_SET_ID 
		||PROG_REP_FORM_ID 
	)
 WHERE subm_type_name = 'SWMS4AnnualProgramReportSubmission'
   AND subm_transaction_id = p_transaction_id;


-- KEYHASH for ICS_SWMS_4_PRMT
UPDATE ics_subm_results
   SET key_hash = MD5_HASH(
		PRMT_IDENT 
	)
 WHERE subm_type_name = 'SWMS4PermitSubmission'
   AND subm_transaction_id = p_transaction_id;


-- KEYHASH for ICS_UNPRMT_FAC
UPDATE ics_subm_results
   SET key_hash = MD5_HASH(
		PRMT_IDENT 
	)
 WHERE subm_type_name = 'UnpermittedFacilitySubmission'
   AND subm_transaction_id = p_transaction_id;

	

-- ----------------
-- KeyHASH for  Choice Key payloads (manual)

-- 1) ComplianceMonitoringLinkageSubmission
UPDATE ICS_SUBM_RESULTS m
   SET m.key_hash =
     MD5_HASH(
       m.cmpl_mon_ident
       || COALESCE(
            m.cmpl_mon_ident_2,
            m.enfrc_actn_ident,
            m.prmt_ident
            || m.sngl_evt_viol_code
            || m.sngl_evt_viol_date
          )
     )
 WHERE m.subm_type_name      = 'ComplianceMonitoringLinkageSubmission'
;

-- 2) EnforcementActionViolationLinkageSubmission – DMR Value
UPDATE ICS_SUBM_RESULTS m
   SET m.key_hash =
     MD5_HASH(
       m.enfrc_actn_ident
       || m.prmt_ident
       || m.prmt_featr_ident
       || m.lmt_set_designator
       || m.mon_period_end_date
       || m.param_code
       || m.mon_site_desc_code
       || m.lmt_season_num
     )
 WHERE m.subm_type_name = 'EnforcementActionViolationLinkageSubmission'
   AND m.param_code     IS NOT NULL
;

-- 3) EnforcementActionViolationLinkageSubmission – DMR (form)
UPDATE ICS_SUBM_RESULTS m
   SET m.key_hash =
     MD5_HASH(
       m.enfrc_actn_ident
       || m.prmt_ident
       || m.prmt_featr_ident
       || m.lmt_set_designator
       || m.mon_period_end_date
     )
 WHERE m.subm_type_name      = 'EnforcementActionViolationLinkageSubmission'
   AND m.mon_period_end_date IS NOT NULL
   AND m.param_code         IS NULL
;

-- 4) EnforcementActionViolationLinkageSubmission – Permit Schedule Violation
UPDATE ICS_SUBM_RESULTS m
   SET m.key_hash =
     MD5_HASH(
       m.enfrc_actn_ident
       || m.prmt_ident
       || m.narr_cond_num
       || m.schd_evt_code
       || m.schd_date
     )
 WHERE m.subm_type_name = 'EnforcementActionViolationLinkageSubmission'
   AND m.narr_cond_num  IS NOT NULL
;

-- 5) EnforcementActionViolationLinkageSubmission – Single Event Violation
UPDATE ICS_SUBM_RESULTS m
   SET m.key_hash =
     MD5_HASH(
       m.enfrc_actn_ident
       || m.prmt_ident
       || m.sngl_evt_viol_code
       || m.sngl_evt_viol_date
     )
 WHERE m.subm_type_name     = 'EnforcementActionViolationLinkageSubmission'
   AND m.sngl_evt_viol_code IS NOT NULL
;

-- 6) EnforcementActionViolationLinkageSubmission – Compliance Schedule
UPDATE ICS_SUBM_RESULTS m
   SET m.key_hash =
     MD5_HASH(
       m.enfrc_actn_ident
       || m.final_order_ident
       || m.prmt_ident
       || TO_CHAR(m.cmpl_schd_num)
       || m.schd_evt_code
       || m.schd_date
     )
 WHERE m.subm_type_name   = 'EnforcementActionViolationLinkageSubmission'
   AND m.cmpl_schd_num    IS NOT NULL
;

-- 7) FinalOrderViolationLinkageSubmission – DMR Value
UPDATE ICS_SUBM_RESULTS m
   SET m.key_hash =
     MD5_HASH(
       m.enfrc_actn_ident
       || m.final_order_ident
       || m.prmt_ident
       || m.prmt_featr_ident
       || m.lmt_set_designator
       || m.mon_period_end_date
       || m.param_code
       || m.mon_site_desc_code
       || m.lmt_season_num
     )
 WHERE m.subm_type_name = 'FinalOrderViolationLinkageSubmission'
   AND m.param_code     IS NOT NULL
;

-- 8) FinalOrderViolationLinkageSubmission – DMR (form)
UPDATE ICS_SUBM_RESULTS m
   SET m.key_hash =
     MD5_HASH(
       m.enfrc_actn_ident
       || m.final_order_ident
       || m.prmt_ident
       || m.prmt_featr_ident
       || m.lmt_set_designator
       || m.mon_period_end_date
     )
 WHERE m.subm_type_name      = 'FinalOrderViolationLinkageSubmission'
   AND m.mon_period_end_date IS NOT NULL
   AND m.param_code         IS NULL
;

-- 9) FinalOrderViolationLinkageSubmission – Permit Schedule Violation
UPDATE ICS_SUBM_RESULTS m
   SET m.key_hash =
     MD5_HASH(
       m.enfrc_actn_ident
       || m.final_order_ident
       || m.prmt_ident
       || m.narr_cond_num
       || m.schd_evt_code
       || m.schd_date
     )
 WHERE m.subm_type_name  = 'FinalOrderViolationLinkageSubmission'
   AND m.narr_cond_num   IS NOT NULL
;

--10) FinalOrderViolationLinkageSubmission – Single Event Violation
UPDATE ICS_SUBM_RESULTS m
   SET m.key_hash =
     MD5_HASH(
       m.enfrc_actn_ident
       || m.final_order_ident
       || m.prmt_ident
       || m.sngl_evt_viol_code
       || m.sngl_evt_viol_date
     )
 WHERE m.subm_type_name      = 'FinalOrderViolationLinkageSubmission'
   AND m.sngl_evt_viol_code  IS NOT NULL
;

--11) FinalOrderViolationLinkageSubmission – Compliance Schedule
UPDATE ICS_SUBM_RESULTS m
   SET m.key_hash =
     MD5_HASH(
       m.enfrc_actn_ident
       || m.final_order_ident
       || m.final_order_ident_2
       || m.prmt_ident
       || m.cmpl_schd_num
       || m.schd_evt_code
       || m.schd_date
     )
 WHERE m.subm_type_name   = 'FinalOrderViolationLinkageSubmission'
   AND m.cmpl_schd_num    IS NOT NULL
;

--12) ScheduleEventViolationSubmission – ENFRC_ACTN_IDENT branch
UPDATE ICS_SUBM_RESULTS m
   SET m.key_hash =
     MD5_HASH(
       m.enfrc_actn_ident
       || m.final_order_ident
       || m.prmt_ident
       || m.cmpl_schd_num
       || m.schd_evt_code
       || m.schd_date
     )
 WHERE m.subm_type_name      = 'ScheduleEventViolationSubmission'
   AND m.enfrc_actn_ident    IS NOT NULL
;

--13) ScheduleEventViolationSubmission – NARR_COND_NUM branch
UPDATE ICS_SUBM_RESULTS m
   SET m.key_hash =
     MD5_HASH(
       m.prmt_ident
       || m.narr_cond_num
       || m.schd_evt_code
       || m.schd_date
       || m.schd_viol_code
     )
 WHERE m.subm_type_name     = 'ScheduleEventViolationSubmission'
   AND m.narr_cond_num      IS NOT NULL
;

-- ----------------

--Delete errors from previous submissions where here is an error for the same key in the current submission
    DELETE 
      FROM ics_subm_results 
     WHERE result_type_code IN ('Error','Warning')
       AND key_hash IN (SELECT key_hash 
                          FROM ics_subm_results 
                         WHERE subm_transaction_id = p_transaction_id
                           AND result_type_code IN ('Error','Warning'))
       AND subm_transaction_id != p_transaction_id;



/*
  *  Step 3: Move accepted transactions from LOCAL to ICIS schema
  *          FOR EACH PAYLOAD TYPE:
  *          1.  First prune data from the ICS_FLOW_ICIS schema to make room for new data coming across
  *              - Delete for basic permit, general permit, permitted feature, limit set, parameter limit, and limit data
  *                for permits that have been reissued.
  *              - Delete all data for permit that has been terminated 
  *          2.  Second copy accepted data from ICS_FLOW_LOCAL into ics_flow_icis.
  */




-- Remove any old records for ICS_BASIC_PRMT
		
-- Remove any old records for ICS_BASIC_PRMT
				
-- /ICS_BASIC_PRMT/ICS_NAICS_CODE
DELETE
  FROM ics_flow_icis.ICS_NAICS_CODE
 WHERE ICS_NAICS_CODE.ICS_BASIC_PRMT_ID IN
          (SELECT I25.ICS_BASIC_PRMT_ID
              from ics_flow_icis.ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ics_flow_icis.ICS_NAICS_CODE I25
 ON I25.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_BASIC_PRMT/ICS_CMPL_TRACK_STAT
DELETE
  FROM ics_flow_icis.ICS_CMPL_TRACK_STAT
 WHERE ICS_CMPL_TRACK_STAT.ICS_BASIC_PRMT_ID IN
          (SELECT I24.ICS_BASIC_PRMT_ID
              from ics_flow_icis.ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ics_flow_icis.ICS_CMPL_TRACK_STAT I24
 ON I24.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_BASIC_PRMT/ICS_ASSC_PRMT
DELETE
  FROM ics_flow_icis.ICS_ASSC_PRMT
 WHERE ICS_ASSC_PRMT.ICS_BASIC_PRMT_ID IN
          (SELECT I23.ICS_BASIC_PRMT_ID
              from ics_flow_icis.ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ics_flow_icis.ICS_ASSC_PRMT I23
 ON I23.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_BASIC_PRMT/ICS_ADDR/ICS_TELEPH
DELETE
  FROM ics_flow_icis.ICS_TELEPH
 WHERE ICS_TELEPH.ICS_ADDR_ID IN
          (SELECT I22.ICS_ADDR_ID
              from ics_flow_icis.ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ics_flow_icis.ICS_ADDR I21
 ON I21.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
 JOIN ics_flow_icis.ICS_TELEPH I22
 ON I22.ICS_ADDR_ID = I21.ICS_ADDR_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_BASIC_PRMT/ICS_ADDR
DELETE
  FROM ics_flow_icis.ICS_ADDR
 WHERE ICS_ADDR.ICS_BASIC_PRMT_ID IN
          (SELECT I21.ICS_BASIC_PRMT_ID
              from ics_flow_icis.ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ics_flow_icis.ICS_ADDR I21
 ON I21.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_BASIC_PRMT/ICS_SIU_DESGN_TYPE
DELETE
  FROM ics_flow_icis.ICS_SIU_DESGN_TYPE
 WHERE ICS_SIU_DESGN_TYPE.ICS_BASIC_PRMT_ID IN
          (SELECT I20.ICS_BASIC_PRMT_ID
              from ics_flow_icis.ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ics_flow_icis.ICS_SIU_DESGN_TYPE I20
 ON I20.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_BASIC_PRMT/ICS_SIC_CODE
DELETE
  FROM ics_flow_icis.ICS_SIC_CODE
 WHERE ICS_SIC_CODE.ICS_BASIC_PRMT_ID IN
          (SELECT I19.ICS_BASIC_PRMT_ID
              from ics_flow_icis.ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ics_flow_icis.ICS_SIC_CODE I19
 ON I19.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_BASIC_PRMT/ICS_RESIDUAL_DESGN_DTRMN
DELETE
  FROM ics_flow_icis.ICS_RESIDUAL_DESGN_DTRMN
 WHERE ICS_RESIDUAL_DESGN_DTRMN.ICS_BASIC_PRMT_ID IN
          (SELECT I18.ICS_BASIC_PRMT_ID
              from ics_flow_icis.ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ics_flow_icis.ICS_RESIDUAL_DESGN_DTRMN I18
 ON I18.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_BASIC_PRMT/ICS_REP_NON_CMPL_STAT
DELETE
  FROM ics_flow_icis.ICS_REP_NON_CMPL_STAT
 WHERE ICS_REP_NON_CMPL_STAT.ICS_BASIC_PRMT_ID IN
          (SELECT I17.ICS_BASIC_PRMT_ID
              from ics_flow_icis.ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ics_flow_icis.ICS_REP_NON_CMPL_STAT I17
 ON I17.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_BASIC_PRMT/ICS_FAC/ICS_NAICS_CODE
DELETE
  FROM ics_flow_icis.ICS_NAICS_CODE
 WHERE ICS_NAICS_CODE.ICS_FAC_ID IN
          (SELECT I16.ICS_FAC_ID
              from ics_flow_icis.ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ics_flow_icis.ICS_FAC I6
 ON I6.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
 JOIN ics_flow_icis.ICS_NAICS_CODE I16
 ON I16.ICS_FAC_ID = I6.ICS_FAC_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_BASIC_PRMT/ICS_FAC/ICS_ADDR/ICS_TELEPH
DELETE
  FROM ics_flow_icis.ICS_TELEPH
 WHERE ICS_TELEPH.ICS_ADDR_ID IN
          (SELECT I15.ICS_ADDR_ID
              from ics_flow_icis.ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ics_flow_icis.ICS_FAC I6
 ON I6.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
 JOIN ics_flow_icis.ICS_ADDR I14
 ON I14.ICS_FAC_ID = I6.ICS_FAC_ID 
 JOIN ics_flow_icis.ICS_TELEPH I15
 ON I15.ICS_ADDR_ID = I14.ICS_ADDR_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_BASIC_PRMT/ICS_FAC/ICS_ADDR
DELETE
  FROM ics_flow_icis.ICS_ADDR
 WHERE ICS_ADDR.ICS_FAC_ID IN
          (SELECT I14.ICS_FAC_ID
              from ics_flow_icis.ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ics_flow_icis.ICS_FAC I6
 ON I6.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
 JOIN ics_flow_icis.ICS_ADDR I14
 ON I14.ICS_FAC_ID = I6.ICS_FAC_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_BASIC_PRMT/ICS_FAC/ICS_SIC_CODE
DELETE
  FROM ics_flow_icis.ICS_SIC_CODE
 WHERE ICS_SIC_CODE.ICS_FAC_ID IN
          (SELECT I13.ICS_FAC_ID
              from ics_flow_icis.ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ics_flow_icis.ICS_FAC I6
 ON I6.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
 JOIN ics_flow_icis.ICS_SIC_CODE I13
 ON I13.ICS_FAC_ID = I6.ICS_FAC_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_BASIC_PRMT/ICS_FAC/ICS_GEO_COORD
DELETE
  FROM ics_flow_icis.ICS_GEO_COORD
 WHERE ICS_GEO_COORD.ICS_FAC_ID IN
          (SELECT I12.ICS_FAC_ID
              from ics_flow_icis.ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ics_flow_icis.ICS_FAC I6
 ON I6.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
 JOIN ics_flow_icis.ICS_GEO_COORD I12
 ON I12.ICS_FAC_ID = I6.ICS_FAC_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_BASIC_PRMT/ICS_FAC/ICS_FAC_CLASS
DELETE
  FROM ics_flow_icis.ICS_FAC_CLASS
 WHERE ICS_FAC_CLASS.ICS_FAC_ID IN
          (SELECT I11.ICS_FAC_ID
              from ics_flow_icis.ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ics_flow_icis.ICS_FAC I6
 ON I6.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
 JOIN ics_flow_icis.ICS_FAC_CLASS I11
 ON I11.ICS_FAC_ID = I6.ICS_FAC_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_BASIC_PRMT/ICS_FAC/ICS_PLCY
DELETE
  FROM ics_flow_icis.ICS_PLCY
 WHERE ICS_PLCY.ICS_FAC_ID IN
          (SELECT I10.ICS_FAC_ID
              from ics_flow_icis.ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ics_flow_icis.ICS_FAC I6
 ON I6.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
 JOIN ics_flow_icis.ICS_PLCY I10
 ON I10.ICS_FAC_ID = I6.ICS_FAC_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_BASIC_PRMT/ICS_FAC/ICS_ORIG_PROGS
DELETE
  FROM ics_flow_icis.ICS_ORIG_PROGS
 WHERE ICS_ORIG_PROGS.ICS_FAC_ID IN
          (SELECT I9.ICS_FAC_ID
              from ics_flow_icis.ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ics_flow_icis.ICS_FAC I6
 ON I6.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
 JOIN ics_flow_icis.ICS_ORIG_PROGS I9
 ON I9.ICS_FAC_ID = I6.ICS_FAC_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_BASIC_PRMT/ICS_FAC/ICS_CONTACT/ICS_TELEPH
DELETE
  FROM ics_flow_icis.ICS_TELEPH
 WHERE ICS_TELEPH.ICS_CONTACT_ID IN
          (SELECT I8.ICS_CONTACT_ID
              from ics_flow_icis.ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ics_flow_icis.ICS_FAC I6
 ON I6.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
 JOIN ics_flow_icis.ICS_CONTACT I7
 ON I7.ICS_FAC_ID = I6.ICS_FAC_ID 
 JOIN ics_flow_icis.ICS_TELEPH I8
 ON I8.ICS_CONTACT_ID = I7.ICS_CONTACT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_BASIC_PRMT/ICS_FAC/ICS_CONTACT
DELETE
  FROM ics_flow_icis.ICS_CONTACT
 WHERE ICS_CONTACT.ICS_FAC_ID IN
          (SELECT I7.ICS_FAC_ID
              from ics_flow_icis.ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ics_flow_icis.ICS_FAC I6
 ON I6.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
 JOIN ics_flow_icis.ICS_CONTACT I7
 ON I7.ICS_FAC_ID = I6.ICS_FAC_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_BASIC_PRMT/ICS_FAC
DELETE
  FROM ics_flow_icis.ICS_FAC
 WHERE ICS_FAC.ICS_BASIC_PRMT_ID IN
          (SELECT I6.ICS_BASIC_PRMT_ID
              from ics_flow_icis.ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ics_flow_icis.ICS_FAC I6
 ON I6.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_BASIC_PRMT/ICS_EFFLU_GUIDE
DELETE
  FROM ics_flow_icis.ICS_EFFLU_GUIDE
 WHERE ICS_EFFLU_GUIDE.ICS_BASIC_PRMT_ID IN
          (SELECT I5.ICS_BASIC_PRMT_ID
              from ics_flow_icis.ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ics_flow_icis.ICS_EFFLU_GUIDE I5
 ON I5.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_BASIC_PRMT/ICS_OTHR_PRMTS
DELETE
  FROM ics_flow_icis.ICS_OTHR_PRMTS
 WHERE ICS_OTHR_PRMTS.ICS_BASIC_PRMT_ID IN
          (SELECT I4.ICS_BASIC_PRMT_ID
              from ics_flow_icis.ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ics_flow_icis.ICS_OTHR_PRMTS I4
 ON I4.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_BASIC_PRMT/ICS_NPDES_DAT_GRP_NUM
DELETE
  FROM ics_flow_icis.ICS_NPDES_DAT_GRP_NUM
 WHERE ICS_NPDES_DAT_GRP_NUM.ICS_BASIC_PRMT_ID IN
          (SELECT I3.ICS_BASIC_PRMT_ID
              from ics_flow_icis.ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ics_flow_icis.ICS_NPDES_DAT_GRP_NUM I3
 ON I3.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_BASIC_PRMT/ICS_CONTACT/ICS_TELEPH
DELETE
  FROM ics_flow_icis.ICS_TELEPH
 WHERE ICS_TELEPH.ICS_CONTACT_ID IN
          (SELECT I2.ICS_CONTACT_ID
              from ics_flow_icis.ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ics_flow_icis.ICS_CONTACT I1
 ON I1.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
 JOIN ics_flow_icis.ICS_TELEPH I2
 ON I2.ICS_CONTACT_ID = I1.ICS_CONTACT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_BASIC_PRMT/ICS_CONTACT
DELETE
  FROM ics_flow_icis.ICS_CONTACT
 WHERE ICS_CONTACT.ICS_BASIC_PRMT_ID IN
          (SELECT I1.ICS_BASIC_PRMT_ID
              from ics_flow_icis.ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ics_flow_icis.ICS_CONTACT I1
 ON I1.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_BASIC_PRMT
DELETE
  FROM ics_flow_icis.ICS_BASIC_PRMT
 WHERE ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID IN
          (SELECT ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID
              from ics_flow_icis.ICS_BASIC_PRMT ICS_BASIC_PRMT 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

	
-- Add accepted records for ICS_BASIC_PRMT


-- /ICS_BASIC_PRMT/ICS_NAICS_CODE
DELETE
  FROM ics_flow_icis.ICS_NAICS_CODE
 WHERE ICS_NAICS_CODE.ICS_BASIC_PRMT_ID IN
          (SELECT I25.ICS_BASIC_PRMT_ID
              from ics_flow_icis.ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ics_flow_icis.ICS_NAICS_CODE I25
 ON I25.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_BASIC_PRMT/ICS_CMPL_TRACK_STAT
DELETE
  FROM ics_flow_icis.ICS_CMPL_TRACK_STAT
 WHERE ICS_CMPL_TRACK_STAT.ICS_BASIC_PRMT_ID IN
          (SELECT I24.ICS_BASIC_PRMT_ID
              from ics_flow_icis.ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ics_flow_icis.ICS_CMPL_TRACK_STAT I24
 ON I24.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_BASIC_PRMT/ICS_ASSC_PRMT
DELETE
  FROM ics_flow_icis.ICS_ASSC_PRMT
 WHERE ICS_ASSC_PRMT.ICS_BASIC_PRMT_ID IN
          (SELECT I23.ICS_BASIC_PRMT_ID
              from ics_flow_icis.ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ics_flow_icis.ICS_ASSC_PRMT I23
 ON I23.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_BASIC_PRMT/ICS_ADDR/ICS_TELEPH
DELETE
  FROM ics_flow_icis.ICS_TELEPH
 WHERE ICS_TELEPH.ICS_ADDR_ID IN
          (SELECT I22.ICS_ADDR_ID
              from ics_flow_icis.ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ics_flow_icis.ICS_ADDR I21
 ON I21.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
 JOIN ics_flow_icis.ICS_TELEPH I22
 ON I22.ICS_ADDR_ID = I21.ICS_ADDR_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_BASIC_PRMT/ICS_ADDR
DELETE
  FROM ics_flow_icis.ICS_ADDR
 WHERE ICS_ADDR.ICS_BASIC_PRMT_ID IN
          (SELECT I21.ICS_BASIC_PRMT_ID
              from ics_flow_icis.ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ics_flow_icis.ICS_ADDR I21
 ON I21.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_BASIC_PRMT/ICS_SIU_DESGN_TYPE
DELETE
  FROM ics_flow_icis.ICS_SIU_DESGN_TYPE
 WHERE ICS_SIU_DESGN_TYPE.ICS_BASIC_PRMT_ID IN
          (SELECT I20.ICS_BASIC_PRMT_ID
              from ics_flow_icis.ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ics_flow_icis.ICS_SIU_DESGN_TYPE I20
 ON I20.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_BASIC_PRMT/ICS_SIC_CODE
DELETE
  FROM ics_flow_icis.ICS_SIC_CODE
 WHERE ICS_SIC_CODE.ICS_BASIC_PRMT_ID IN
          (SELECT I19.ICS_BASIC_PRMT_ID
              from ics_flow_icis.ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ics_flow_icis.ICS_SIC_CODE I19
 ON I19.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_BASIC_PRMT/ICS_RESIDUAL_DESGN_DTRMN
DELETE
  FROM ics_flow_icis.ICS_RESIDUAL_DESGN_DTRMN
 WHERE ICS_RESIDUAL_DESGN_DTRMN.ICS_BASIC_PRMT_ID IN
          (SELECT I18.ICS_BASIC_PRMT_ID
              from ics_flow_icis.ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ics_flow_icis.ICS_RESIDUAL_DESGN_DTRMN I18
 ON I18.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_BASIC_PRMT/ICS_REP_NON_CMPL_STAT
DELETE
  FROM ics_flow_icis.ICS_REP_NON_CMPL_STAT
 WHERE ICS_REP_NON_CMPL_STAT.ICS_BASIC_PRMT_ID IN
          (SELECT I17.ICS_BASIC_PRMT_ID
              from ics_flow_icis.ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ics_flow_icis.ICS_REP_NON_CMPL_STAT I17
 ON I17.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_BASIC_PRMT/ICS_FAC/ICS_NAICS_CODE
DELETE
  FROM ics_flow_icis.ICS_NAICS_CODE
 WHERE ICS_NAICS_CODE.ICS_FAC_ID IN
          (SELECT I16.ICS_FAC_ID
              from ics_flow_icis.ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ics_flow_icis.ICS_FAC I6
 ON I6.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
 JOIN ics_flow_icis.ICS_NAICS_CODE I16
 ON I16.ICS_FAC_ID = I6.ICS_FAC_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_BASIC_PRMT/ICS_FAC/ICS_ADDR/ICS_TELEPH
DELETE
  FROM ics_flow_icis.ICS_TELEPH
 WHERE ICS_TELEPH.ICS_ADDR_ID IN
          (SELECT I15.ICS_ADDR_ID
              from ics_flow_icis.ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ics_flow_icis.ICS_FAC I6
 ON I6.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
 JOIN ics_flow_icis.ICS_ADDR I14
 ON I14.ICS_FAC_ID = I6.ICS_FAC_ID 
 JOIN ics_flow_icis.ICS_TELEPH I15
 ON I15.ICS_ADDR_ID = I14.ICS_ADDR_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_BASIC_PRMT/ICS_FAC/ICS_ADDR
DELETE
  FROM ics_flow_icis.ICS_ADDR
 WHERE ICS_ADDR.ICS_FAC_ID IN
          (SELECT I14.ICS_FAC_ID
              from ics_flow_icis.ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ics_flow_icis.ICS_FAC I6
 ON I6.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
 JOIN ics_flow_icis.ICS_ADDR I14
 ON I14.ICS_FAC_ID = I6.ICS_FAC_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_BASIC_PRMT/ICS_FAC/ICS_SIC_CODE
DELETE
  FROM ics_flow_icis.ICS_SIC_CODE
 WHERE ICS_SIC_CODE.ICS_FAC_ID IN
          (SELECT I13.ICS_FAC_ID
              from ics_flow_icis.ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ics_flow_icis.ICS_FAC I6
 ON I6.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
 JOIN ics_flow_icis.ICS_SIC_CODE I13
 ON I13.ICS_FAC_ID = I6.ICS_FAC_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_BASIC_PRMT/ICS_FAC/ICS_GEO_COORD
DELETE
  FROM ics_flow_icis.ICS_GEO_COORD
 WHERE ICS_GEO_COORD.ICS_FAC_ID IN
          (SELECT I12.ICS_FAC_ID
              from ics_flow_icis.ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ics_flow_icis.ICS_FAC I6
 ON I6.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
 JOIN ics_flow_icis.ICS_GEO_COORD I12
 ON I12.ICS_FAC_ID = I6.ICS_FAC_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_BASIC_PRMT/ICS_FAC/ICS_FAC_CLASS
DELETE
  FROM ics_flow_icis.ICS_FAC_CLASS
 WHERE ICS_FAC_CLASS.ICS_FAC_ID IN
          (SELECT I11.ICS_FAC_ID
              from ics_flow_icis.ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ics_flow_icis.ICS_FAC I6
 ON I6.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
 JOIN ics_flow_icis.ICS_FAC_CLASS I11
 ON I11.ICS_FAC_ID = I6.ICS_FAC_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_BASIC_PRMT/ICS_FAC/ICS_PLCY
DELETE
  FROM ics_flow_icis.ICS_PLCY
 WHERE ICS_PLCY.ICS_FAC_ID IN
          (SELECT I10.ICS_FAC_ID
              from ics_flow_icis.ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ics_flow_icis.ICS_FAC I6
 ON I6.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
 JOIN ics_flow_icis.ICS_PLCY I10
 ON I10.ICS_FAC_ID = I6.ICS_FAC_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_BASIC_PRMT/ICS_FAC/ICS_ORIG_PROGS
DELETE
  FROM ics_flow_icis.ICS_ORIG_PROGS
 WHERE ICS_ORIG_PROGS.ICS_FAC_ID IN
          (SELECT I9.ICS_FAC_ID
              from ics_flow_icis.ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ics_flow_icis.ICS_FAC I6
 ON I6.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
 JOIN ics_flow_icis.ICS_ORIG_PROGS I9
 ON I9.ICS_FAC_ID = I6.ICS_FAC_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_BASIC_PRMT/ICS_FAC/ICS_CONTACT/ICS_TELEPH
DELETE
  FROM ics_flow_icis.ICS_TELEPH
 WHERE ICS_TELEPH.ICS_CONTACT_ID IN
          (SELECT I8.ICS_CONTACT_ID
              from ics_flow_icis.ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ics_flow_icis.ICS_FAC I6
 ON I6.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
 JOIN ics_flow_icis.ICS_CONTACT I7
 ON I7.ICS_FAC_ID = I6.ICS_FAC_ID 
 JOIN ics_flow_icis.ICS_TELEPH I8
 ON I8.ICS_CONTACT_ID = I7.ICS_CONTACT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_BASIC_PRMT/ICS_FAC/ICS_CONTACT
DELETE
  FROM ics_flow_icis.ICS_CONTACT
 WHERE ICS_CONTACT.ICS_FAC_ID IN
          (SELECT I7.ICS_FAC_ID
              from ics_flow_icis.ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ics_flow_icis.ICS_FAC I6
 ON I6.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
 JOIN ics_flow_icis.ICS_CONTACT I7
 ON I7.ICS_FAC_ID = I6.ICS_FAC_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_BASIC_PRMT/ICS_FAC
DELETE
  FROM ics_flow_icis.ICS_FAC
 WHERE ICS_FAC.ICS_BASIC_PRMT_ID IN
          (SELECT I6.ICS_BASIC_PRMT_ID
              from ics_flow_icis.ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ics_flow_icis.ICS_FAC I6
 ON I6.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_BASIC_PRMT/ICS_EFFLU_GUIDE
DELETE
  FROM ics_flow_icis.ICS_EFFLU_GUIDE
 WHERE ICS_EFFLU_GUIDE.ICS_BASIC_PRMT_ID IN
          (SELECT I5.ICS_BASIC_PRMT_ID
              from ics_flow_icis.ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ics_flow_icis.ICS_EFFLU_GUIDE I5
 ON I5.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_BASIC_PRMT/ICS_OTHR_PRMTS
DELETE
  FROM ics_flow_icis.ICS_OTHR_PRMTS
 WHERE ICS_OTHR_PRMTS.ICS_BASIC_PRMT_ID IN
          (SELECT I4.ICS_BASIC_PRMT_ID
              from ics_flow_icis.ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ics_flow_icis.ICS_OTHR_PRMTS I4
 ON I4.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_BASIC_PRMT/ICS_NPDES_DAT_GRP_NUM
DELETE
  FROM ics_flow_icis.ICS_NPDES_DAT_GRP_NUM
 WHERE ICS_NPDES_DAT_GRP_NUM.ICS_BASIC_PRMT_ID IN
          (SELECT I3.ICS_BASIC_PRMT_ID
              from ics_flow_icis.ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ics_flow_icis.ICS_NPDES_DAT_GRP_NUM I3
 ON I3.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_BASIC_PRMT/ICS_CONTACT/ICS_TELEPH
DELETE
  FROM ics_flow_icis.ICS_TELEPH
 WHERE ICS_TELEPH.ICS_CONTACT_ID IN
          (SELECT I2.ICS_CONTACT_ID
              from ics_flow_icis.ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ics_flow_icis.ICS_CONTACT I1
 ON I1.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
 JOIN ics_flow_icis.ICS_TELEPH I2
 ON I2.ICS_CONTACT_ID = I1.ICS_CONTACT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_BASIC_PRMT/ICS_CONTACT
DELETE
  FROM ics_flow_icis.ICS_CONTACT
 WHERE ICS_CONTACT.ICS_BASIC_PRMT_ID IN
          (SELECT I1.ICS_BASIC_PRMT_ID
              from ics_flow_icis.ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ics_flow_icis.ICS_CONTACT I1
 ON I1.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_BASIC_PRMT
DELETE
  FROM ics_flow_icis.ICS_BASIC_PRMT
 WHERE ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID IN
          (SELECT ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID
              from ics_flow_icis.ICS_BASIC_PRMT ICS_BASIC_PRMT 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BasicPermitSubmission')
                  OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BASIC_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

	
-- Add accepted records for ICS_BASIC_PRMT


-- /ICS_BASIC_PRMT
INSERT INTO ics_flow_icis.ICS_BASIC_PRMT
     SELECT ICS_BASIC_PRMT.*
              from ICS_BASIC_PRMT ICS_BASIC_PRMT 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
       WHERE ICS_BASIC_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'BasicPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission');


-- /ICS_BASIC_PRMT/ICS_CONTACT
INSERT INTO ics_flow_icis.ICS_CONTACT
     SELECT I1.*
              from ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ICS_CONTACT I1
 ON I1.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
       WHERE ICS_BASIC_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'BasicPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission');


-- /ICS_BASIC_PRMT/ICS_CONTACT/ICS_TELEPH
INSERT INTO ics_flow_icis.ICS_TELEPH
     SELECT I2.*
              from ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ICS_CONTACT I1
 ON I1.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
 JOIN ICS_TELEPH I2
 ON I2.ICS_CONTACT_ID = I1.ICS_CONTACT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
       WHERE ICS_BASIC_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'BasicPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission');


-- /ICS_BASIC_PRMT/ICS_NPDES_DAT_GRP_NUM
INSERT INTO ics_flow_icis.ICS_NPDES_DAT_GRP_NUM
     SELECT I3.*
              from ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ICS_NPDES_DAT_GRP_NUM I3
 ON I3.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
       WHERE ICS_BASIC_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'BasicPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission');


-- /ICS_BASIC_PRMT/ICS_OTHR_PRMTS
INSERT INTO ics_flow_icis.ICS_OTHR_PRMTS
     SELECT I4.*
              from ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ICS_OTHR_PRMTS I4
 ON I4.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
       WHERE ICS_BASIC_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'BasicPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission');


-- /ICS_BASIC_PRMT/ICS_EFFLU_GUIDE
INSERT INTO ics_flow_icis.ICS_EFFLU_GUIDE
     SELECT I5.*
              from ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ICS_EFFLU_GUIDE I5
 ON I5.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
       WHERE ICS_BASIC_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'BasicPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission');


-- /ICS_BASIC_PRMT/ICS_FAC
INSERT INTO ics_flow_icis.ICS_FAC
     SELECT I6.*
              from ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ICS_FAC I6
 ON I6.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
       WHERE ICS_BASIC_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'BasicPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission');


-- /ICS_BASIC_PRMT/ICS_FAC/ICS_CONTACT
INSERT INTO ics_flow_icis.ICS_CONTACT
     SELECT I7.*
              from ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ICS_FAC I6
 ON I6.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
 JOIN ICS_CONTACT I7
 ON I7.ICS_FAC_ID = I6.ICS_FAC_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
       WHERE ICS_BASIC_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'BasicPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission');


-- /ICS_BASIC_PRMT/ICS_FAC/ICS_CONTACT/ICS_TELEPH
INSERT INTO ics_flow_icis.ICS_TELEPH
     SELECT I8.*
              from ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ICS_FAC I6
 ON I6.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
 JOIN ICS_CONTACT I7
 ON I7.ICS_FAC_ID = I6.ICS_FAC_ID 
 JOIN ICS_TELEPH I8
 ON I8.ICS_CONTACT_ID = I7.ICS_CONTACT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
       WHERE ICS_BASIC_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'BasicPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission');


-- /ICS_BASIC_PRMT/ICS_FAC/ICS_ORIG_PROGS
INSERT INTO ics_flow_icis.ICS_ORIG_PROGS
     SELECT I9.*
              from ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ICS_FAC I6
 ON I6.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
 JOIN ICS_ORIG_PROGS I9
 ON I9.ICS_FAC_ID = I6.ICS_FAC_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
       WHERE ICS_BASIC_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'BasicPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission');


-- /ICS_BASIC_PRMT/ICS_FAC/ICS_PLCY
INSERT INTO ics_flow_icis.ICS_PLCY
     SELECT I10.*
              from ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ICS_FAC I6
 ON I6.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
 JOIN ICS_PLCY I10
 ON I10.ICS_FAC_ID = I6.ICS_FAC_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
       WHERE ICS_BASIC_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'BasicPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission');


-- /ICS_BASIC_PRMT/ICS_FAC/ICS_FAC_CLASS
INSERT INTO ics_flow_icis.ICS_FAC_CLASS
     SELECT I11.*
              from ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ICS_FAC I6
 ON I6.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
 JOIN ICS_FAC_CLASS I11
 ON I11.ICS_FAC_ID = I6.ICS_FAC_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
       WHERE ICS_BASIC_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'BasicPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission');


-- /ICS_BASIC_PRMT/ICS_FAC/ICS_GEO_COORD
INSERT INTO ics_flow_icis.ICS_GEO_COORD
     SELECT I12.*
              from ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ICS_FAC I6
 ON I6.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
 JOIN ICS_GEO_COORD I12
 ON I12.ICS_FAC_ID = I6.ICS_FAC_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
       WHERE ICS_BASIC_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'BasicPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission');


-- /ICS_BASIC_PRMT/ICS_FAC/ICS_SIC_CODE
INSERT INTO ics_flow_icis.ICS_SIC_CODE
     SELECT I13.*
              from ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ICS_FAC I6
 ON I6.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
 JOIN ICS_SIC_CODE I13
 ON I13.ICS_FAC_ID = I6.ICS_FAC_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
       WHERE ICS_BASIC_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'BasicPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission');


-- /ICS_BASIC_PRMT/ICS_FAC/ICS_ADDR
INSERT INTO ics_flow_icis.ICS_ADDR
     SELECT I14.*
              from ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ICS_FAC I6
 ON I6.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
 JOIN ICS_ADDR I14
 ON I14.ICS_FAC_ID = I6.ICS_FAC_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
       WHERE ICS_BASIC_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'BasicPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission');


-- /ICS_BASIC_PRMT/ICS_FAC/ICS_ADDR/ICS_TELEPH
INSERT INTO ics_flow_icis.ICS_TELEPH
     SELECT I15.*
              from ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ICS_FAC I6
 ON I6.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
 JOIN ICS_ADDR I14
 ON I14.ICS_FAC_ID = I6.ICS_FAC_ID 
 JOIN ICS_TELEPH I15
 ON I15.ICS_ADDR_ID = I14.ICS_ADDR_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
       WHERE ICS_BASIC_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'BasicPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission');


-- /ICS_BASIC_PRMT/ICS_FAC/ICS_NAICS_CODE
INSERT INTO ics_flow_icis.ICS_NAICS_CODE
     SELECT I16.*
              from ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ICS_FAC I6
 ON I6.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
 JOIN ICS_NAICS_CODE I16
 ON I16.ICS_FAC_ID = I6.ICS_FAC_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
       WHERE ICS_BASIC_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'BasicPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission');


-- /ICS_BASIC_PRMT/ICS_REP_NON_CMPL_STAT
INSERT INTO ics_flow_icis.ICS_REP_NON_CMPL_STAT
     SELECT I17.*
              from ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ICS_REP_NON_CMPL_STAT I17
 ON I17.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
       WHERE ICS_BASIC_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'BasicPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission');


-- /ICS_BASIC_PRMT/ICS_RESIDUAL_DESGN_DTRMN
INSERT INTO ics_flow_icis.ICS_RESIDUAL_DESGN_DTRMN
     SELECT I18.*
              from ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ICS_RESIDUAL_DESGN_DTRMN I18
 ON I18.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
       WHERE ICS_BASIC_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'BasicPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission');


-- /ICS_BASIC_PRMT/ICS_SIC_CODE
INSERT INTO ics_flow_icis.ICS_SIC_CODE
     SELECT I19.*
              from ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ICS_SIC_CODE I19
 ON I19.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
       WHERE ICS_BASIC_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'BasicPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission');


-- /ICS_BASIC_PRMT/ICS_SIU_DESGN_TYPE
INSERT INTO ics_flow_icis.ICS_SIU_DESGN_TYPE
     SELECT I20.*
              from ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ICS_SIU_DESGN_TYPE I20
 ON I20.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
       WHERE ICS_BASIC_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'BasicPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission');


-- /ICS_BASIC_PRMT/ICS_ADDR
INSERT INTO ics_flow_icis.ICS_ADDR
     SELECT I21.*
              from ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ICS_ADDR I21
 ON I21.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
       WHERE ICS_BASIC_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'BasicPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission');


-- /ICS_BASIC_PRMT/ICS_ADDR/ICS_TELEPH
INSERT INTO ics_flow_icis.ICS_TELEPH
     SELECT I22.*
              from ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ICS_ADDR I21
 ON I21.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
 JOIN ICS_TELEPH I22
 ON I22.ICS_ADDR_ID = I21.ICS_ADDR_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
       WHERE ICS_BASIC_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'BasicPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission');


-- /ICS_BASIC_PRMT/ICS_ASSC_PRMT
INSERT INTO ics_flow_icis.ICS_ASSC_PRMT
     SELECT I23.*
              from ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ICS_ASSC_PRMT I23
 ON I23.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
       WHERE ICS_BASIC_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'BasicPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission');


-- /ICS_BASIC_PRMT/ICS_CMPL_TRACK_STAT
INSERT INTO ics_flow_icis.ICS_CMPL_TRACK_STAT
     SELECT I24.*
              from ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ICS_CMPL_TRACK_STAT I24
 ON I24.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
       WHERE ICS_BASIC_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'BasicPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission');


-- /ICS_BASIC_PRMT/ICS_NAICS_CODE
INSERT INTO ics_flow_icis.ICS_NAICS_CODE
     SELECT I25.*
              from ICS_BASIC_PRMT ICS_BASIC_PRMT 
 JOIN ICS_NAICS_CODE I25
 ON I25.ICS_BASIC_PRMT_ID = ICS_BASIC_PRMT.ICS_BASIC_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH
       WHERE ICS_BASIC_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'BasicPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BasicPermitSubmission');
	




-- Remove any old records for ICS_BS_ANNUL_PROG_REP
				
-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICE/ICS_CMPL_MON_EVT/ICS_BS_SEWAGE_SLDG_PARAM
DELETE
  FROM ics_flow_icis.ICS_BS_SEWAGE_SLDG_PARAM
 WHERE ICS_BS_SEWAGE_SLDG_PARAM.ICS_CMPL_MON_EVT_ID IN
          (SELECT I17.ICS_CMPL_MON_EVT_ID
              from ics_flow_icis.ICS_BS_ANNUL_PROG_REP ICS_BS_ANNUL_PROG_REP 
 JOIN ics_flow_icis.ICS_BS_MGMT_PRACTICE I4
 ON I4.ICS_BS_ANNUL_PROG_REP_ID = ICS_BS_ANNUL_PROG_REP.ICS_BS_ANNUL_PROG_REP_ID 
 JOIN ics_flow_icis.ICS_CMPL_MON_EVT I16
 ON I16.ICS_BS_MGMT_PRACTICE_ID = I4.ICS_BS_MGMT_PRACTICE_ID 
 JOIN ics_flow_icis.ICS_BS_SEWAGE_SLDG_PARAM I17
 ON I17.ICS_CMPL_MON_EVT_ID = I16.ICS_CMPL_MON_EVT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_ANNUL_PROG_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission')
                  OR ICS_BS_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICE/ICS_CMPL_MON_EVT
DELETE
  FROM ics_flow_icis.ICS_CMPL_MON_EVT
 WHERE ICS_CMPL_MON_EVT.ICS_BS_MGMT_PRACTICE_ID IN
          (SELECT I16.ICS_BS_MGMT_PRACTICE_ID
              from ics_flow_icis.ICS_BS_ANNUL_PROG_REP ICS_BS_ANNUL_PROG_REP 
 JOIN ics_flow_icis.ICS_BS_MGMT_PRACTICE I4
 ON I4.ICS_BS_ANNUL_PROG_REP_ID = ICS_BS_ANNUL_PROG_REP.ICS_BS_ANNUL_PROG_REP_ID 
 JOIN ics_flow_icis.ICS_CMPL_MON_EVT I16
 ON I16.ICS_BS_MGMT_PRACTICE_ID = I4.ICS_BS_MGMT_PRACTICE_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_ANNUL_PROG_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission')
                  OR ICS_BS_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICE/ICS_VECTOR_A_REDUCTION_TYPE
DELETE
  FROM ics_flow_icis.ICS_VECTOR_A_REDUCTION_TYPE
 WHERE ICS_VECTOR_A_REDUCTION_TYPE.ICS_BS_MGMT_PRACTICE_ID IN
          (SELECT I15.ICS_BS_MGMT_PRACTICE_ID
              from ics_flow_icis.ICS_BS_ANNUL_PROG_REP ICS_BS_ANNUL_PROG_REP 
 JOIN ics_flow_icis.ICS_BS_MGMT_PRACTICE I4
 ON I4.ICS_BS_ANNUL_PROG_REP_ID = ICS_BS_ANNUL_PROG_REP.ICS_BS_ANNUL_PROG_REP_ID 
 JOIN ics_flow_icis.ICS_VECTOR_A_REDUCTION_TYPE I15
 ON I15.ICS_BS_MGMT_PRACTICE_ID = I4.ICS_BS_MGMT_PRACTICE_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_ANNUL_PROG_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission')
                  OR ICS_BS_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICE/ICS_BS_SEWAGE_SLDG_PARAM
DELETE
  FROM ics_flow_icis.ICS_BS_SEWAGE_SLDG_PARAM
 WHERE ICS_BS_SEWAGE_SLDG_PARAM.ICS_BS_MGMT_PRACTICE_ID IN
          (SELECT I14.ICS_BS_MGMT_PRACTICE_ID
              from ics_flow_icis.ICS_BS_ANNUL_PROG_REP ICS_BS_ANNUL_PROG_REP 
 JOIN ics_flow_icis.ICS_BS_MGMT_PRACTICE I4
 ON I4.ICS_BS_ANNUL_PROG_REP_ID = ICS_BS_ANNUL_PROG_REP.ICS_BS_ANNUL_PROG_REP_ID 
 JOIN ics_flow_icis.ICS_BS_SEWAGE_SLDG_PARAM I14
 ON I14.ICS_BS_MGMT_PRACTICE_ID = I4.ICS_BS_MGMT_PRACTICE_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_ANNUL_PROG_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission')
                  OR ICS_BS_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICE/ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR/ICS_CONTACT/ICS_TELEPH
DELETE
  FROM ics_flow_icis.ICS_TELEPH
 WHERE ICS_TELEPH.ICS_CONTACT_ID IN
          (SELECT I13.ICS_CONTACT_ID
              from ics_flow_icis.ICS_BS_ANNUL_PROG_REP ICS_BS_ANNUL_PROG_REP 
 JOIN ics_flow_icis.ICS_BS_MGMT_PRACTICE I4
 ON I4.ICS_BS_ANNUL_PROG_REP_ID = ICS_BS_ANNUL_PROG_REP.ICS_BS_ANNUL_PROG_REP_ID 
 JOIN ics_flow_icis.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR I9
 ON I9.ICS_BS_MGMT_PRACTICE_ID = I4.ICS_BS_MGMT_PRACTICE_ID 
 JOIN ics_flow_icis.ICS_CONTACT I12
 ON I12.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID = I9.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID 
 JOIN ics_flow_icis.ICS_TELEPH I13
 ON I13.ICS_CONTACT_ID = I12.ICS_CONTACT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_ANNUL_PROG_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission')
                  OR ICS_BS_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICE/ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR/ICS_CONTACT
DELETE
  FROM ics_flow_icis.ICS_CONTACT
 WHERE ICS_CONTACT.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID IN
          (SELECT I12.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID
              from ics_flow_icis.ICS_BS_ANNUL_PROG_REP ICS_BS_ANNUL_PROG_REP 
 JOIN ics_flow_icis.ICS_BS_MGMT_PRACTICE I4
 ON I4.ICS_BS_ANNUL_PROG_REP_ID = ICS_BS_ANNUL_PROG_REP.ICS_BS_ANNUL_PROG_REP_ID 
 JOIN ics_flow_icis.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR I9
 ON I9.ICS_BS_MGMT_PRACTICE_ID = I4.ICS_BS_MGMT_PRACTICE_ID 
 JOIN ics_flow_icis.ICS_CONTACT I12
 ON I12.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID = I9.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_ANNUL_PROG_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission')
                  OR ICS_BS_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICE/ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR/ICS_ADDR/ICS_TELEPH
DELETE
  FROM ics_flow_icis.ICS_TELEPH
 WHERE ICS_TELEPH.ICS_ADDR_ID IN
          (SELECT I11.ICS_ADDR_ID
              from ics_flow_icis.ICS_BS_ANNUL_PROG_REP ICS_BS_ANNUL_PROG_REP 
 JOIN ics_flow_icis.ICS_BS_MGMT_PRACTICE I4
 ON I4.ICS_BS_ANNUL_PROG_REP_ID = ICS_BS_ANNUL_PROG_REP.ICS_BS_ANNUL_PROG_REP_ID 
 JOIN ics_flow_icis.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR I9
 ON I9.ICS_BS_MGMT_PRACTICE_ID = I4.ICS_BS_MGMT_PRACTICE_ID 
 JOIN ics_flow_icis.ICS_ADDR I10
 ON I10.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID = I9.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID 
 JOIN ics_flow_icis.ICS_TELEPH I11
 ON I11.ICS_ADDR_ID = I10.ICS_ADDR_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_ANNUL_PROG_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission')
                  OR ICS_BS_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICE/ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR/ICS_ADDR
DELETE
  FROM ics_flow_icis.ICS_ADDR
 WHERE ICS_ADDR.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID IN
          (SELECT I10.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID
              from ics_flow_icis.ICS_BS_ANNUL_PROG_REP ICS_BS_ANNUL_PROG_REP 
 JOIN ics_flow_icis.ICS_BS_MGMT_PRACTICE I4
 ON I4.ICS_BS_ANNUL_PROG_REP_ID = ICS_BS_ANNUL_PROG_REP.ICS_BS_ANNUL_PROG_REP_ID 
 JOIN ics_flow_icis.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR I9
 ON I9.ICS_BS_MGMT_PRACTICE_ID = I4.ICS_BS_MGMT_PRACTICE_ID 
 JOIN ics_flow_icis.ICS_ADDR I10
 ON I10.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID = I9.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_ANNUL_PROG_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission')
                  OR ICS_BS_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICE/ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR
DELETE
  FROM ics_flow_icis.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR
 WHERE ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR.ICS_BS_MGMT_PRACTICE_ID IN
          (SELECT I9.ICS_BS_MGMT_PRACTICE_ID
              from ics_flow_icis.ICS_BS_ANNUL_PROG_REP ICS_BS_ANNUL_PROG_REP 
 JOIN ics_flow_icis.ICS_BS_MGMT_PRACTICE I4
 ON I4.ICS_BS_ANNUL_PROG_REP_ID = ICS_BS_ANNUL_PROG_REP.ICS_BS_ANNUL_PROG_REP_ID 
 JOIN ics_flow_icis.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR I9
 ON I9.ICS_BS_MGMT_PRACTICE_ID = I4.ICS_BS_MGMT_PRACTICE_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_ANNUL_PROG_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission')
                  OR ICS_BS_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICE/ICS_BS_INCINERATION/ICS_BS_SEWAGE_SLDG_PARAM
DELETE
  FROM ics_flow_icis.ICS_BS_SEWAGE_SLDG_PARAM
 WHERE ICS_BS_SEWAGE_SLDG_PARAM.ICS_BS_INCINERATION_ID IN
          (SELECT I8.ICS_BS_INCINERATION_ID
              from ics_flow_icis.ICS_BS_ANNUL_PROG_REP ICS_BS_ANNUL_PROG_REP 
 JOIN ics_flow_icis.ICS_BS_MGMT_PRACTICE I4
 ON I4.ICS_BS_ANNUL_PROG_REP_ID = ICS_BS_ANNUL_PROG_REP.ICS_BS_ANNUL_PROG_REP_ID 
 JOIN ics_flow_icis.ICS_BS_INCINERATION I6
 ON I6.ICS_BS_MGMT_PRACTICE_ID = I4.ICS_BS_MGMT_PRACTICE_ID 
 JOIN ics_flow_icis.ICS_BS_SEWAGE_SLDG_PARAM I8
 ON I8.ICS_BS_INCINERATION_ID = I6.ICS_BS_INCINERATION_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_ANNUL_PROG_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission')
                  OR ICS_BS_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICE/ICS_BS_INCINERATION/ICS_BS_INCIN_EMISSIONS_CONTROL_TYPE
DELETE
  FROM ics_flow_icis.ICS_BS_INCIN_EMISSIONS_CONTROL_TYPE
 WHERE ICS_BS_INCIN_EMISSIONS_CONTROL_TYPE.ICS_BS_INCINERATION_ID IN
          (SELECT I7.ICS_BS_INCINERATION_ID
              from ics_flow_icis.ICS_BS_ANNUL_PROG_REP ICS_BS_ANNUL_PROG_REP 
 JOIN ics_flow_icis.ICS_BS_MGMT_PRACTICE I4
 ON I4.ICS_BS_ANNUL_PROG_REP_ID = ICS_BS_ANNUL_PROG_REP.ICS_BS_ANNUL_PROG_REP_ID 
 JOIN ics_flow_icis.ICS_BS_INCINERATION I6
 ON I6.ICS_BS_MGMT_PRACTICE_ID = I4.ICS_BS_MGMT_PRACTICE_ID 
 JOIN ics_flow_icis.ICS_BS_INCIN_EMISSIONS_CONTROL_TYPE I7
 ON I7.ICS_BS_INCINERATION_ID = I6.ICS_BS_INCINERATION_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_ANNUL_PROG_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission')
                  OR ICS_BS_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICE/ICS_BS_INCINERATION
DELETE
  FROM ics_flow_icis.ICS_BS_INCINERATION
 WHERE ICS_BS_INCINERATION.ICS_BS_MGMT_PRACTICE_ID IN
          (SELECT I6.ICS_BS_MGMT_PRACTICE_ID
              from ics_flow_icis.ICS_BS_ANNUL_PROG_REP ICS_BS_ANNUL_PROG_REP 
 JOIN ics_flow_icis.ICS_BS_MGMT_PRACTICE I4
 ON I4.ICS_BS_ANNUL_PROG_REP_ID = ICS_BS_ANNUL_PROG_REP.ICS_BS_ANNUL_PROG_REP_ID 
 JOIN ics_flow_icis.ICS_BS_INCINERATION I6
 ON I6.ICS_BS_MGMT_PRACTICE_ID = I4.ICS_BS_MGMT_PRACTICE_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_ANNUL_PROG_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission')
                  OR ICS_BS_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICE/ICS_PATHOGEN_REDUCTION_TYPE
DELETE
  FROM ics_flow_icis.ICS_PATHOGEN_REDUCTION_TYPE
 WHERE ICS_PATHOGEN_REDUCTION_TYPE.ICS_BS_MGMT_PRACTICE_ID IN
          (SELECT I5.ICS_BS_MGMT_PRACTICE_ID
              from ics_flow_icis.ICS_BS_ANNUL_PROG_REP ICS_BS_ANNUL_PROG_REP 
 JOIN ics_flow_icis.ICS_BS_MGMT_PRACTICE I4
 ON I4.ICS_BS_ANNUL_PROG_REP_ID = ICS_BS_ANNUL_PROG_REP.ICS_BS_ANNUL_PROG_REP_ID 
 JOIN ics_flow_icis.ICS_PATHOGEN_REDUCTION_TYPE I5
 ON I5.ICS_BS_MGMT_PRACTICE_ID = I4.ICS_BS_MGMT_PRACTICE_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_ANNUL_PROG_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission')
                  OR ICS_BS_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICE
DELETE
  FROM ics_flow_icis.ICS_BS_MGMT_PRACTICE
 WHERE ICS_BS_MGMT_PRACTICE.ICS_BS_ANNUL_PROG_REP_ID IN
          (SELECT I4.ICS_BS_ANNUL_PROG_REP_ID
              from ics_flow_icis.ICS_BS_ANNUL_PROG_REP ICS_BS_ANNUL_PROG_REP 
 JOIN ics_flow_icis.ICS_BS_MGMT_PRACTICE I4
 ON I4.ICS_BS_ANNUL_PROG_REP_ID = ICS_BS_ANNUL_PROG_REP.ICS_BS_ANNUL_PROG_REP_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_ANNUL_PROG_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission')
                  OR ICS_BS_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_FAC_TYPE
DELETE
  FROM ics_flow_icis.ICS_BS_FAC_TYPE
 WHERE ICS_BS_FAC_TYPE.ICS_BS_ANNUL_PROG_REP_ID IN
          (SELECT I3.ICS_BS_ANNUL_PROG_REP_ID
              from ics_flow_icis.ICS_BS_ANNUL_PROG_REP ICS_BS_ANNUL_PROG_REP 
 JOIN ics_flow_icis.ICS_BS_FAC_TYPE I3
 ON I3.ICS_BS_ANNUL_PROG_REP_ID = ICS_BS_ANNUL_PROG_REP.ICS_BS_ANNUL_PROG_REP_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_ANNUL_PROG_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission')
                  OR ICS_BS_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_FAC_TRTMNT
DELETE
  FROM ics_flow_icis.ICS_BS_FAC_TRTMNT
 WHERE ICS_BS_FAC_TRTMNT.ICS_BS_ANNUL_PROG_REP_ID IN
          (SELECT I2.ICS_BS_ANNUL_PROG_REP_ID
              from ics_flow_icis.ICS_BS_ANNUL_PROG_REP ICS_BS_ANNUL_PROG_REP 
 JOIN ics_flow_icis.ICS_BS_FAC_TRTMNT I2
 ON I2.ICS_BS_ANNUL_PROG_REP_ID = ICS_BS_ANNUL_PROG_REP.ICS_BS_ANNUL_PROG_REP_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_ANNUL_PROG_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission')
                  OR ICS_BS_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_BS_ANNUL_PROG_REP/ICS_ANLYTCL_METHOD
DELETE
  FROM ics_flow_icis.ICS_ANLYTCL_METHOD
 WHERE ICS_ANLYTCL_METHOD.ICS_BS_ANNUL_PROG_REP_ID IN
          (SELECT I1.ICS_BS_ANNUL_PROG_REP_ID
              from ics_flow_icis.ICS_BS_ANNUL_PROG_REP ICS_BS_ANNUL_PROG_REP 
 JOIN ics_flow_icis.ICS_ANLYTCL_METHOD I1
 ON I1.ICS_BS_ANNUL_PROG_REP_ID = ICS_BS_ANNUL_PROG_REP.ICS_BS_ANNUL_PROG_REP_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_ANNUL_PROG_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission')
                  OR ICS_BS_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_BS_ANNUL_PROG_REP
DELETE
  FROM ics_flow_icis.ICS_BS_ANNUL_PROG_REP
 WHERE ICS_BS_ANNUL_PROG_REP.ICS_BS_ANNUL_PROG_REP_ID IN
          (SELECT ICS_BS_ANNUL_PROG_REP.ICS_BS_ANNUL_PROG_REP_ID
              from ics_flow_icis.ICS_BS_ANNUL_PROG_REP ICS_BS_ANNUL_PROG_REP 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_ANNUL_PROG_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission')
                  OR ICS_BS_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

	
-- Add accepted records for ICS_BS_ANNUL_PROG_REP


-- /ICS_BS_ANNUL_PROG_REP
INSERT INTO ics_flow_icis.ICS_BS_ANNUL_PROG_REP
     SELECT ICS_BS_ANNUL_PROG_REP.*
              from ICS_BS_ANNUL_PROG_REP ICS_BS_ANNUL_PROG_REP 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_ANNUL_PROG_REP.KEY_HASH
       WHERE ICS_BS_ANNUL_PROG_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'BiosolidsAnnualProgramReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission');


-- /ICS_BS_ANNUL_PROG_REP/ICS_ANLYTCL_METHOD
INSERT INTO ics_flow_icis.ICS_ANLYTCL_METHOD
     SELECT I1.*
              from ICS_BS_ANNUL_PROG_REP ICS_BS_ANNUL_PROG_REP 
 JOIN ICS_ANLYTCL_METHOD I1
 ON I1.ICS_BS_ANNUL_PROG_REP_ID = ICS_BS_ANNUL_PROG_REP.ICS_BS_ANNUL_PROG_REP_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_ANNUL_PROG_REP.KEY_HASH
       WHERE ICS_BS_ANNUL_PROG_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'BiosolidsAnnualProgramReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission');


-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_FAC_TRTMNT
INSERT INTO ics_flow_icis.ICS_BS_FAC_TRTMNT
     SELECT I2.*
              from ICS_BS_ANNUL_PROG_REP ICS_BS_ANNUL_PROG_REP 
 JOIN ICS_BS_FAC_TRTMNT I2
 ON I2.ICS_BS_ANNUL_PROG_REP_ID = ICS_BS_ANNUL_PROG_REP.ICS_BS_ANNUL_PROG_REP_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_ANNUL_PROG_REP.KEY_HASH
       WHERE ICS_BS_ANNUL_PROG_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'BiosolidsAnnualProgramReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission');


-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_FAC_TYPE
INSERT INTO ics_flow_icis.ICS_BS_FAC_TYPE
     SELECT I3.*
              from ICS_BS_ANNUL_PROG_REP ICS_BS_ANNUL_PROG_REP 
 JOIN ICS_BS_FAC_TYPE I3
 ON I3.ICS_BS_ANNUL_PROG_REP_ID = ICS_BS_ANNUL_PROG_REP.ICS_BS_ANNUL_PROG_REP_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_ANNUL_PROG_REP.KEY_HASH
       WHERE ICS_BS_ANNUL_PROG_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'BiosolidsAnnualProgramReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission');


-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICE
INSERT INTO ics_flow_icis.ICS_BS_MGMT_PRACTICE
     SELECT I4.*
              from ICS_BS_ANNUL_PROG_REP ICS_BS_ANNUL_PROG_REP 
 JOIN ICS_BS_MGMT_PRACTICE I4
 ON I4.ICS_BS_ANNUL_PROG_REP_ID = ICS_BS_ANNUL_PROG_REP.ICS_BS_ANNUL_PROG_REP_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_ANNUL_PROG_REP.KEY_HASH
       WHERE ICS_BS_ANNUL_PROG_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'BiosolidsAnnualProgramReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission');


-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICE/ICS_PATHOGEN_REDUCTION_TYPE
INSERT INTO ics_flow_icis.ICS_PATHOGEN_REDUCTION_TYPE
     SELECT I5.*
              from ICS_BS_ANNUL_PROG_REP ICS_BS_ANNUL_PROG_REP 
 JOIN ICS_BS_MGMT_PRACTICE I4
 ON I4.ICS_BS_ANNUL_PROG_REP_ID = ICS_BS_ANNUL_PROG_REP.ICS_BS_ANNUL_PROG_REP_ID 
 JOIN ICS_PATHOGEN_REDUCTION_TYPE I5
 ON I5.ICS_BS_MGMT_PRACTICE_ID = I4.ICS_BS_MGMT_PRACTICE_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_ANNUL_PROG_REP.KEY_HASH
       WHERE ICS_BS_ANNUL_PROG_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'BiosolidsAnnualProgramReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission');


-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICE/ICS_BS_INCINERATION
INSERT INTO ics_flow_icis.ICS_BS_INCINERATION
     SELECT I6.*
              from ICS_BS_ANNUL_PROG_REP ICS_BS_ANNUL_PROG_REP 
 JOIN ICS_BS_MGMT_PRACTICE I4
 ON I4.ICS_BS_ANNUL_PROG_REP_ID = ICS_BS_ANNUL_PROG_REP.ICS_BS_ANNUL_PROG_REP_ID 
 JOIN ICS_BS_INCINERATION I6
 ON I6.ICS_BS_MGMT_PRACTICE_ID = I4.ICS_BS_MGMT_PRACTICE_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_ANNUL_PROG_REP.KEY_HASH
       WHERE ICS_BS_ANNUL_PROG_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'BiosolidsAnnualProgramReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission');


-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICE/ICS_BS_INCINERATION/ICS_BS_INCIN_EMISSIONS_CONTROL_TYPE
INSERT INTO ics_flow_icis.ICS_BS_INCIN_EMISSIONS_CONTROL_TYPE
     SELECT I7.*
              from ICS_BS_ANNUL_PROG_REP ICS_BS_ANNUL_PROG_REP 
 JOIN ICS_BS_MGMT_PRACTICE I4
 ON I4.ICS_BS_ANNUL_PROG_REP_ID = ICS_BS_ANNUL_PROG_REP.ICS_BS_ANNUL_PROG_REP_ID 
 JOIN ICS_BS_INCINERATION I6
 ON I6.ICS_BS_MGMT_PRACTICE_ID = I4.ICS_BS_MGMT_PRACTICE_ID 
 JOIN ICS_BS_INCIN_EMISSIONS_CONTROL_TYPE I7
 ON I7.ICS_BS_INCINERATION_ID = I6.ICS_BS_INCINERATION_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_ANNUL_PROG_REP.KEY_HASH
       WHERE ICS_BS_ANNUL_PROG_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'BiosolidsAnnualProgramReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission');


-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICE/ICS_BS_INCINERATION/ICS_BS_SEWAGE_SLDG_PARAM
INSERT INTO ics_flow_icis.ICS_BS_SEWAGE_SLDG_PARAM
     SELECT I8.*
              from ICS_BS_ANNUL_PROG_REP ICS_BS_ANNUL_PROG_REP 
 JOIN ICS_BS_MGMT_PRACTICE I4
 ON I4.ICS_BS_ANNUL_PROG_REP_ID = ICS_BS_ANNUL_PROG_REP.ICS_BS_ANNUL_PROG_REP_ID 
 JOIN ICS_BS_INCINERATION I6
 ON I6.ICS_BS_MGMT_PRACTICE_ID = I4.ICS_BS_MGMT_PRACTICE_ID 
 JOIN ICS_BS_SEWAGE_SLDG_PARAM I8
 ON I8.ICS_BS_INCINERATION_ID = I6.ICS_BS_INCINERATION_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_ANNUL_PROG_REP.KEY_HASH
       WHERE ICS_BS_ANNUL_PROG_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'BiosolidsAnnualProgramReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission');


-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICE/ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR
INSERT INTO ics_flow_icis.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR
     SELECT I9.*
              from ICS_BS_ANNUL_PROG_REP ICS_BS_ANNUL_PROG_REP 
 JOIN ICS_BS_MGMT_PRACTICE I4
 ON I4.ICS_BS_ANNUL_PROG_REP_ID = ICS_BS_ANNUL_PROG_REP.ICS_BS_ANNUL_PROG_REP_ID 
 JOIN ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR I9
 ON I9.ICS_BS_MGMT_PRACTICE_ID = I4.ICS_BS_MGMT_PRACTICE_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_ANNUL_PROG_REP.KEY_HASH
       WHERE ICS_BS_ANNUL_PROG_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'BiosolidsAnnualProgramReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission');


-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICE/ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR/ICS_ADDR
INSERT INTO ics_flow_icis.ICS_ADDR
     SELECT I10.*
              from ICS_BS_ANNUL_PROG_REP ICS_BS_ANNUL_PROG_REP 
 JOIN ICS_BS_MGMT_PRACTICE I4
 ON I4.ICS_BS_ANNUL_PROG_REP_ID = ICS_BS_ANNUL_PROG_REP.ICS_BS_ANNUL_PROG_REP_ID 
 JOIN ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR I9
 ON I9.ICS_BS_MGMT_PRACTICE_ID = I4.ICS_BS_MGMT_PRACTICE_ID 
 JOIN ICS_ADDR I10
 ON I10.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID = I9.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_ANNUL_PROG_REP.KEY_HASH
       WHERE ICS_BS_ANNUL_PROG_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'BiosolidsAnnualProgramReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission');


-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICE/ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR/ICS_ADDR/ICS_TELEPH
INSERT INTO ics_flow_icis.ICS_TELEPH
     SELECT I11.*
              from ICS_BS_ANNUL_PROG_REP ICS_BS_ANNUL_PROG_REP 
 JOIN ICS_BS_MGMT_PRACTICE I4
 ON I4.ICS_BS_ANNUL_PROG_REP_ID = ICS_BS_ANNUL_PROG_REP.ICS_BS_ANNUL_PROG_REP_ID 
 JOIN ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR I9
 ON I9.ICS_BS_MGMT_PRACTICE_ID = I4.ICS_BS_MGMT_PRACTICE_ID 
 JOIN ICS_ADDR I10
 ON I10.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID = I9.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID 
 JOIN ICS_TELEPH I11
 ON I11.ICS_ADDR_ID = I10.ICS_ADDR_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_ANNUL_PROG_REP.KEY_HASH
       WHERE ICS_BS_ANNUL_PROG_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'BiosolidsAnnualProgramReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission');


-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICE/ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR/ICS_CONTACT
INSERT INTO ics_flow_icis.ICS_CONTACT
     SELECT I12.*
              from ICS_BS_ANNUL_PROG_REP ICS_BS_ANNUL_PROG_REP 
 JOIN ICS_BS_MGMT_PRACTICE I4
 ON I4.ICS_BS_ANNUL_PROG_REP_ID = ICS_BS_ANNUL_PROG_REP.ICS_BS_ANNUL_PROG_REP_ID 
 JOIN ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR I9
 ON I9.ICS_BS_MGMT_PRACTICE_ID = I4.ICS_BS_MGMT_PRACTICE_ID 
 JOIN ICS_CONTACT I12
 ON I12.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID = I9.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_ANNUL_PROG_REP.KEY_HASH
       WHERE ICS_BS_ANNUL_PROG_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'BiosolidsAnnualProgramReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission');


-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICE/ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR/ICS_CONTACT/ICS_TELEPH
INSERT INTO ics_flow_icis.ICS_TELEPH
     SELECT I13.*
              from ICS_BS_ANNUL_PROG_REP ICS_BS_ANNUL_PROG_REP 
 JOIN ICS_BS_MGMT_PRACTICE I4
 ON I4.ICS_BS_ANNUL_PROG_REP_ID = ICS_BS_ANNUL_PROG_REP.ICS_BS_ANNUL_PROG_REP_ID 
 JOIN ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR I9
 ON I9.ICS_BS_MGMT_PRACTICE_ID = I4.ICS_BS_MGMT_PRACTICE_ID 
 JOIN ICS_CONTACT I12
 ON I12.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID = I9.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID 
 JOIN ICS_TELEPH I13
 ON I13.ICS_CONTACT_ID = I12.ICS_CONTACT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_ANNUL_PROG_REP.KEY_HASH
       WHERE ICS_BS_ANNUL_PROG_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'BiosolidsAnnualProgramReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission');


-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICE/ICS_BS_SEWAGE_SLDG_PARAM
INSERT INTO ics_flow_icis.ICS_BS_SEWAGE_SLDG_PARAM
     SELECT I14.*
              from ICS_BS_ANNUL_PROG_REP ICS_BS_ANNUL_PROG_REP 
 JOIN ICS_BS_MGMT_PRACTICE I4
 ON I4.ICS_BS_ANNUL_PROG_REP_ID = ICS_BS_ANNUL_PROG_REP.ICS_BS_ANNUL_PROG_REP_ID 
 JOIN ICS_BS_SEWAGE_SLDG_PARAM I14
 ON I14.ICS_BS_MGMT_PRACTICE_ID = I4.ICS_BS_MGMT_PRACTICE_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_ANNUL_PROG_REP.KEY_HASH
       WHERE ICS_BS_ANNUL_PROG_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'BiosolidsAnnualProgramReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission');


-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICE/ICS_VECTOR_A_REDUCTION_TYPE
INSERT INTO ics_flow_icis.ICS_VECTOR_A_REDUCTION_TYPE
     SELECT I15.*
              from ICS_BS_ANNUL_PROG_REP ICS_BS_ANNUL_PROG_REP 
 JOIN ICS_BS_MGMT_PRACTICE I4
 ON I4.ICS_BS_ANNUL_PROG_REP_ID = ICS_BS_ANNUL_PROG_REP.ICS_BS_ANNUL_PROG_REP_ID 
 JOIN ICS_VECTOR_A_REDUCTION_TYPE I15
 ON I15.ICS_BS_MGMT_PRACTICE_ID = I4.ICS_BS_MGMT_PRACTICE_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_ANNUL_PROG_REP.KEY_HASH
       WHERE ICS_BS_ANNUL_PROG_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'BiosolidsAnnualProgramReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission');


-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICE/ICS_CMPL_MON_EVT
INSERT INTO ics_flow_icis.ICS_CMPL_MON_EVT
     SELECT I16.*
              from ICS_BS_ANNUL_PROG_REP ICS_BS_ANNUL_PROG_REP 
 JOIN ICS_BS_MGMT_PRACTICE I4
 ON I4.ICS_BS_ANNUL_PROG_REP_ID = ICS_BS_ANNUL_PROG_REP.ICS_BS_ANNUL_PROG_REP_ID 
 JOIN ICS_CMPL_MON_EVT I16
 ON I16.ICS_BS_MGMT_PRACTICE_ID = I4.ICS_BS_MGMT_PRACTICE_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_ANNUL_PROG_REP.KEY_HASH
       WHERE ICS_BS_ANNUL_PROG_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'BiosolidsAnnualProgramReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission');


-- /ICS_BS_ANNUL_PROG_REP/ICS_BS_MGMT_PRACTICE/ICS_CMPL_MON_EVT/ICS_BS_SEWAGE_SLDG_PARAM
INSERT INTO ics_flow_icis.ICS_BS_SEWAGE_SLDG_PARAM
     SELECT I17.*
              from ICS_BS_ANNUL_PROG_REP ICS_BS_ANNUL_PROG_REP 
 JOIN ICS_BS_MGMT_PRACTICE I4
 ON I4.ICS_BS_ANNUL_PROG_REP_ID = ICS_BS_ANNUL_PROG_REP.ICS_BS_ANNUL_PROG_REP_ID 
 JOIN ICS_CMPL_MON_EVT I16
 ON I16.ICS_BS_MGMT_PRACTICE_ID = I4.ICS_BS_MGMT_PRACTICE_ID 
 JOIN ICS_BS_SEWAGE_SLDG_PARAM I17
 ON I17.ICS_CMPL_MON_EVT_ID = I16.ICS_CMPL_MON_EVT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_ANNUL_PROG_REP.KEY_HASH
       WHERE ICS_BS_ANNUL_PROG_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'BiosolidsAnnualProgramReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsAnnualProgramReportSubmission');
	




-- Remove any old records for ICS_BS_PRMT
				
-- /ICS_BS_PRMT/ICS_BS_FAC_TYPE
DELETE
  FROM ics_flow_icis.ICS_BS_FAC_TYPE
 WHERE ICS_BS_FAC_TYPE.ICS_BS_PRMT_ID IN
          (SELECT I10.ICS_BS_PRMT_ID
              from ics_flow_icis.ICS_BS_PRMT ICS_BS_PRMT 
 JOIN ics_flow_icis.ICS_BS_FAC_TYPE I10
 ON I10.ICS_BS_PRMT_ID = ICS_BS_PRMT.ICS_BS_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BiosolidsPermitSubmission')
                  OR ICS_BS_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BS_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_BS_PRMT/ICS_BS_FAC_TRTMNT
DELETE
  FROM ics_flow_icis.ICS_BS_FAC_TRTMNT
 WHERE ICS_BS_FAC_TRTMNT.ICS_BS_PRMT_ID IN
          (SELECT I9.ICS_BS_PRMT_ID
              from ics_flow_icis.ICS_BS_PRMT ICS_BS_PRMT 
 JOIN ics_flow_icis.ICS_BS_FAC_TRTMNT I9
 ON I9.ICS_BS_PRMT_ID = ICS_BS_PRMT.ICS_BS_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BiosolidsPermitSubmission')
                  OR ICS_BS_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BS_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_BS_PRMT/ICS_PRMT_BS_MGMT_PRACTICE/ICS_VECTOR_A_REDUCTION_TYPE
DELETE
  FROM ics_flow_icis.ICS_VECTOR_A_REDUCTION_TYPE
 WHERE ICS_VECTOR_A_REDUCTION_TYPE.ICS_PRMT_BS_MGMT_PRACTICE_ID IN
          (SELECT I8.ICS_PRMT_BS_MGMT_PRACTICE_ID
              from ics_flow_icis.ICS_BS_PRMT ICS_BS_PRMT 
 JOIN ics_flow_icis.ICS_PRMT_BS_MGMT_PRACTICE I1
 ON I1.ICS_BS_PRMT_ID = ICS_BS_PRMT.ICS_BS_PRMT_ID 
 JOIN ics_flow_icis.ICS_VECTOR_A_REDUCTION_TYPE I8
 ON I8.ICS_PRMT_BS_MGMT_PRACTICE_ID = I1.ICS_PRMT_BS_MGMT_PRACTICE_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BiosolidsPermitSubmission')
                  OR ICS_BS_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BS_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_BS_PRMT/ICS_PRMT_BS_MGMT_PRACTICE/ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR/ICS_CONTACT/ICS_TELEPH
DELETE
  FROM ics_flow_icis.ICS_TELEPH
 WHERE ICS_TELEPH.ICS_CONTACT_ID IN
          (SELECT I7.ICS_CONTACT_ID
              from ics_flow_icis.ICS_BS_PRMT ICS_BS_PRMT 
 JOIN ics_flow_icis.ICS_PRMT_BS_MGMT_PRACTICE I1
 ON I1.ICS_BS_PRMT_ID = ICS_BS_PRMT.ICS_BS_PRMT_ID 
 JOIN ics_flow_icis.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR I3
 ON I3.ICS_PRMT_BS_MGMT_PRACTICE_ID = I1.ICS_PRMT_BS_MGMT_PRACTICE_ID 
 JOIN ics_flow_icis.ICS_CONTACT I6
 ON I6.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID = I3.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID 
 JOIN ics_flow_icis.ICS_TELEPH I7
 ON I7.ICS_CONTACT_ID = I6.ICS_CONTACT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BiosolidsPermitSubmission')
                  OR ICS_BS_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BS_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_BS_PRMT/ICS_PRMT_BS_MGMT_PRACTICE/ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR/ICS_CONTACT
DELETE
  FROM ics_flow_icis.ICS_CONTACT
 WHERE ICS_CONTACT.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID IN
          (SELECT I6.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID
              from ics_flow_icis.ICS_BS_PRMT ICS_BS_PRMT 
 JOIN ics_flow_icis.ICS_PRMT_BS_MGMT_PRACTICE I1
 ON I1.ICS_BS_PRMT_ID = ICS_BS_PRMT.ICS_BS_PRMT_ID 
 JOIN ics_flow_icis.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR I3
 ON I3.ICS_PRMT_BS_MGMT_PRACTICE_ID = I1.ICS_PRMT_BS_MGMT_PRACTICE_ID 
 JOIN ics_flow_icis.ICS_CONTACT I6
 ON I6.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID = I3.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BiosolidsPermitSubmission')
                  OR ICS_BS_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BS_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_BS_PRMT/ICS_PRMT_BS_MGMT_PRACTICE/ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR/ICS_ADDR/ICS_TELEPH
DELETE
  FROM ics_flow_icis.ICS_TELEPH
 WHERE ICS_TELEPH.ICS_ADDR_ID IN
          (SELECT I5.ICS_ADDR_ID
              from ics_flow_icis.ICS_BS_PRMT ICS_BS_PRMT 
 JOIN ics_flow_icis.ICS_PRMT_BS_MGMT_PRACTICE I1
 ON I1.ICS_BS_PRMT_ID = ICS_BS_PRMT.ICS_BS_PRMT_ID 
 JOIN ics_flow_icis.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR I3
 ON I3.ICS_PRMT_BS_MGMT_PRACTICE_ID = I1.ICS_PRMT_BS_MGMT_PRACTICE_ID 
 JOIN ics_flow_icis.ICS_ADDR I4
 ON I4.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID = I3.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID 
 JOIN ics_flow_icis.ICS_TELEPH I5
 ON I5.ICS_ADDR_ID = I4.ICS_ADDR_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BiosolidsPermitSubmission')
                  OR ICS_BS_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BS_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_BS_PRMT/ICS_PRMT_BS_MGMT_PRACTICE/ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR/ICS_ADDR
DELETE
  FROM ics_flow_icis.ICS_ADDR
 WHERE ICS_ADDR.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID IN
          (SELECT I4.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID
              from ics_flow_icis.ICS_BS_PRMT ICS_BS_PRMT 
 JOIN ics_flow_icis.ICS_PRMT_BS_MGMT_PRACTICE I1
 ON I1.ICS_BS_PRMT_ID = ICS_BS_PRMT.ICS_BS_PRMT_ID 
 JOIN ics_flow_icis.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR I3
 ON I3.ICS_PRMT_BS_MGMT_PRACTICE_ID = I1.ICS_PRMT_BS_MGMT_PRACTICE_ID 
 JOIN ics_flow_icis.ICS_ADDR I4
 ON I4.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID = I3.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BiosolidsPermitSubmission')
                  OR ICS_BS_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BS_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_BS_PRMT/ICS_PRMT_BS_MGMT_PRACTICE/ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR
DELETE
  FROM ics_flow_icis.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR
 WHERE ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR.ICS_PRMT_BS_MGMT_PRACTICE_ID IN
          (SELECT I3.ICS_PRMT_BS_MGMT_PRACTICE_ID
              from ics_flow_icis.ICS_BS_PRMT ICS_BS_PRMT 
 JOIN ics_flow_icis.ICS_PRMT_BS_MGMT_PRACTICE I1
 ON I1.ICS_BS_PRMT_ID = ICS_BS_PRMT.ICS_BS_PRMT_ID 
 JOIN ics_flow_icis.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR I3
 ON I3.ICS_PRMT_BS_MGMT_PRACTICE_ID = I1.ICS_PRMT_BS_MGMT_PRACTICE_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BiosolidsPermitSubmission')
                  OR ICS_BS_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BS_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_BS_PRMT/ICS_PRMT_BS_MGMT_PRACTICE/ICS_PATHOGEN_REDUCTION_TYPE
DELETE
  FROM ics_flow_icis.ICS_PATHOGEN_REDUCTION_TYPE
 WHERE ICS_PATHOGEN_REDUCTION_TYPE.ICS_PRMT_BS_MGMT_PRACTICE_ID IN
          (SELECT I2.ICS_PRMT_BS_MGMT_PRACTICE_ID
              from ics_flow_icis.ICS_BS_PRMT ICS_BS_PRMT 
 JOIN ics_flow_icis.ICS_PRMT_BS_MGMT_PRACTICE I1
 ON I1.ICS_BS_PRMT_ID = ICS_BS_PRMT.ICS_BS_PRMT_ID 
 JOIN ics_flow_icis.ICS_PATHOGEN_REDUCTION_TYPE I2
 ON I2.ICS_PRMT_BS_MGMT_PRACTICE_ID = I1.ICS_PRMT_BS_MGMT_PRACTICE_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BiosolidsPermitSubmission')
                  OR ICS_BS_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BS_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_BS_PRMT/ICS_PRMT_BS_MGMT_PRACTICE
DELETE
  FROM ics_flow_icis.ICS_PRMT_BS_MGMT_PRACTICE
 WHERE ICS_PRMT_BS_MGMT_PRACTICE.ICS_BS_PRMT_ID IN
          (SELECT I1.ICS_BS_PRMT_ID
              from ics_flow_icis.ICS_BS_PRMT ICS_BS_PRMT 
 JOIN ics_flow_icis.ICS_PRMT_BS_MGMT_PRACTICE I1
 ON I1.ICS_BS_PRMT_ID = ICS_BS_PRMT.ICS_BS_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BiosolidsPermitSubmission')
                  OR ICS_BS_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BS_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_BS_PRMT
DELETE
  FROM ics_flow_icis.ICS_BS_PRMT
 WHERE ICS_BS_PRMT.ICS_BS_PRMT_ID IN
          (SELECT ICS_BS_PRMT.ICS_BS_PRMT_ID
              from ics_flow_icis.ICS_BS_PRMT ICS_BS_PRMT 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'BiosolidsPermitSubmission')
                  OR ICS_BS_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_BS_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

	
-- Add accepted records for ICS_BS_PRMT


-- /ICS_BS_PRMT
INSERT INTO ics_flow_icis.ICS_BS_PRMT
     SELECT ICS_BS_PRMT.*
              from ICS_BS_PRMT ICS_BS_PRMT 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_PRMT.KEY_HASH
       WHERE ICS_BS_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'BiosolidsPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsPermitSubmission');


-- /ICS_BS_PRMT/ICS_PRMT_BS_MGMT_PRACTICE
INSERT INTO ics_flow_icis.ICS_PRMT_BS_MGMT_PRACTICE
     SELECT I1.*
              from ICS_BS_PRMT ICS_BS_PRMT 
 JOIN ICS_PRMT_BS_MGMT_PRACTICE I1
 ON I1.ICS_BS_PRMT_ID = ICS_BS_PRMT.ICS_BS_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_PRMT.KEY_HASH
       WHERE ICS_BS_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'BiosolidsPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsPermitSubmission');


-- /ICS_BS_PRMT/ICS_PRMT_BS_MGMT_PRACTICE/ICS_PATHOGEN_REDUCTION_TYPE
INSERT INTO ics_flow_icis.ICS_PATHOGEN_REDUCTION_TYPE
     SELECT I2.*
              from ICS_BS_PRMT ICS_BS_PRMT 
 JOIN ICS_PRMT_BS_MGMT_PRACTICE I1
 ON I1.ICS_BS_PRMT_ID = ICS_BS_PRMT.ICS_BS_PRMT_ID 
 JOIN ICS_PATHOGEN_REDUCTION_TYPE I2
 ON I2.ICS_PRMT_BS_MGMT_PRACTICE_ID = I1.ICS_PRMT_BS_MGMT_PRACTICE_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_PRMT.KEY_HASH
       WHERE ICS_BS_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'BiosolidsPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsPermitSubmission');


-- /ICS_BS_PRMT/ICS_PRMT_BS_MGMT_PRACTICE/ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR
INSERT INTO ics_flow_icis.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR
     SELECT I3.*
              from ICS_BS_PRMT ICS_BS_PRMT 
 JOIN ICS_PRMT_BS_MGMT_PRACTICE I1
 ON I1.ICS_BS_PRMT_ID = ICS_BS_PRMT.ICS_BS_PRMT_ID 
 JOIN ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR I3
 ON I3.ICS_PRMT_BS_MGMT_PRACTICE_ID = I1.ICS_PRMT_BS_MGMT_PRACTICE_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_PRMT.KEY_HASH
       WHERE ICS_BS_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'BiosolidsPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsPermitSubmission');


-- /ICS_BS_PRMT/ICS_PRMT_BS_MGMT_PRACTICE/ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR/ICS_ADDR
INSERT INTO ics_flow_icis.ICS_ADDR
     SELECT I4.*
              from ICS_BS_PRMT ICS_BS_PRMT 
 JOIN ICS_PRMT_BS_MGMT_PRACTICE I1
 ON I1.ICS_BS_PRMT_ID = ICS_BS_PRMT.ICS_BS_PRMT_ID 
 JOIN ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR I3
 ON I3.ICS_PRMT_BS_MGMT_PRACTICE_ID = I1.ICS_PRMT_BS_MGMT_PRACTICE_ID 
 JOIN ICS_ADDR I4
 ON I4.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID = I3.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_PRMT.KEY_HASH
       WHERE ICS_BS_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'BiosolidsPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsPermitSubmission');


-- /ICS_BS_PRMT/ICS_PRMT_BS_MGMT_PRACTICE/ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR/ICS_ADDR/ICS_TELEPH
INSERT INTO ics_flow_icis.ICS_TELEPH
     SELECT I5.*
              from ICS_BS_PRMT ICS_BS_PRMT 
 JOIN ICS_PRMT_BS_MGMT_PRACTICE I1
 ON I1.ICS_BS_PRMT_ID = ICS_BS_PRMT.ICS_BS_PRMT_ID 
 JOIN ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR I3
 ON I3.ICS_PRMT_BS_MGMT_PRACTICE_ID = I1.ICS_PRMT_BS_MGMT_PRACTICE_ID 
 JOIN ICS_ADDR I4
 ON I4.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID = I3.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID 
 JOIN ICS_TELEPH I5
 ON I5.ICS_ADDR_ID = I4.ICS_ADDR_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_PRMT.KEY_HASH
       WHERE ICS_BS_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'BiosolidsPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsPermitSubmission');


-- /ICS_BS_PRMT/ICS_PRMT_BS_MGMT_PRACTICE/ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR/ICS_CONTACT
INSERT INTO ics_flow_icis.ICS_CONTACT
     SELECT I6.*
              from ICS_BS_PRMT ICS_BS_PRMT 
 JOIN ICS_PRMT_BS_MGMT_PRACTICE I1
 ON I1.ICS_BS_PRMT_ID = ICS_BS_PRMT.ICS_BS_PRMT_ID 
 JOIN ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR I3
 ON I3.ICS_PRMT_BS_MGMT_PRACTICE_ID = I1.ICS_PRMT_BS_MGMT_PRACTICE_ID 
 JOIN ICS_CONTACT I6
 ON I6.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID = I3.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_PRMT.KEY_HASH
       WHERE ICS_BS_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'BiosolidsPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsPermitSubmission');


-- /ICS_BS_PRMT/ICS_PRMT_BS_MGMT_PRACTICE/ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR/ICS_CONTACT/ICS_TELEPH
INSERT INTO ics_flow_icis.ICS_TELEPH
     SELECT I7.*
              from ICS_BS_PRMT ICS_BS_PRMT 
 JOIN ICS_PRMT_BS_MGMT_PRACTICE I1
 ON I1.ICS_BS_PRMT_ID = ICS_BS_PRMT.ICS_BS_PRMT_ID 
 JOIN ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR I3
 ON I3.ICS_PRMT_BS_MGMT_PRACTICE_ID = I1.ICS_PRMT_BS_MGMT_PRACTICE_ID 
 JOIN ICS_CONTACT I6
 ON I6.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID = I3.ICS_BS_OFF_SITE_HNDLR_APPLIER_PREPR_ID 
 JOIN ICS_TELEPH I7
 ON I7.ICS_CONTACT_ID = I6.ICS_CONTACT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_PRMT.KEY_HASH
       WHERE ICS_BS_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'BiosolidsPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsPermitSubmission');


-- /ICS_BS_PRMT/ICS_PRMT_BS_MGMT_PRACTICE/ICS_VECTOR_A_REDUCTION_TYPE
INSERT INTO ics_flow_icis.ICS_VECTOR_A_REDUCTION_TYPE
     SELECT I8.*
              from ICS_BS_PRMT ICS_BS_PRMT 
 JOIN ICS_PRMT_BS_MGMT_PRACTICE I1
 ON I1.ICS_BS_PRMT_ID = ICS_BS_PRMT.ICS_BS_PRMT_ID 
 JOIN ICS_VECTOR_A_REDUCTION_TYPE I8
 ON I8.ICS_PRMT_BS_MGMT_PRACTICE_ID = I1.ICS_PRMT_BS_MGMT_PRACTICE_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_PRMT.KEY_HASH
       WHERE ICS_BS_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'BiosolidsPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsPermitSubmission');


-- /ICS_BS_PRMT/ICS_BS_FAC_TRTMNT
INSERT INTO ics_flow_icis.ICS_BS_FAC_TRTMNT
     SELECT I9.*
              from ICS_BS_PRMT ICS_BS_PRMT 
 JOIN ICS_BS_FAC_TRTMNT I9
 ON I9.ICS_BS_PRMT_ID = ICS_BS_PRMT.ICS_BS_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_PRMT.KEY_HASH
       WHERE ICS_BS_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'BiosolidsPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsPermitSubmission');


-- /ICS_BS_PRMT/ICS_BS_FAC_TYPE
INSERT INTO ics_flow_icis.ICS_BS_FAC_TYPE
     SELECT I10.*
              from ICS_BS_PRMT ICS_BS_PRMT 
 JOIN ICS_BS_FAC_TYPE I10
 ON I10.ICS_BS_PRMT_ID = ICS_BS_PRMT.ICS_BS_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_BS_PRMT.KEY_HASH
       WHERE ICS_BS_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'BiosolidsPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'BiosolidsPermitSubmission');
	




-- Remove any old records for ICS_CAFO_ANNUL_PROG_REP
				
-- /ICS_CAFO_ANNUL_PROG_REP/ICS_CAFOMLPW_TTL_AMOUNTS
DELETE
  FROM ics_flow_icis.ICS_CAFOMLPW_TTL_AMOUNTS
 WHERE ICS_CAFOMLPW_TTL_AMOUNTS.ICS_CAFO_ANNUL_PROG_REP_ID IN
          (SELECT I6.ICS_CAFO_ANNUL_PROG_REP_ID
              from ics_flow_icis.ICS_CAFO_ANNUL_PROG_REP ICS_CAFO_ANNUL_PROG_REP 
 JOIN ics_flow_icis.ICS_CAFOMLPW_TTL_AMOUNTS I6
 ON I6.ICS_CAFO_ANNUL_PROG_REP_ID = ICS_CAFO_ANNUL_PROG_REP.ICS_CAFO_ANNUL_PROG_REP_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CAFO_ANNUL_PROG_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CAFOAnnualProgramReportSubmission')
                  OR ICS_CAFO_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_CAFO_ANNUL_PROG_REP/ICS_CAFOMLPW_NUTR_MON
DELETE
  FROM ics_flow_icis.ICS_CAFOMLPW_NUTR_MON
 WHERE ICS_CAFOMLPW_NUTR_MON.ICS_CAFO_ANNUL_PROG_REP_ID IN
          (SELECT I5.ICS_CAFO_ANNUL_PROG_REP_ID
              from ics_flow_icis.ICS_CAFO_ANNUL_PROG_REP ICS_CAFO_ANNUL_PROG_REP 
 JOIN ics_flow_icis.ICS_CAFOMLPW_NUTR_MON I5
 ON I5.ICS_CAFO_ANNUL_PROG_REP_ID = ICS_CAFO_ANNUL_PROG_REP.ICS_CAFO_ANNUL_PROG_REP_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CAFO_ANNUL_PROG_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CAFOAnnualProgramReportSubmission')
                  OR ICS_CAFO_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_CAFO_ANNUL_PROG_REP/ICS_CAFO_PROD_AREA_DSCH
DELETE
  FROM ics_flow_icis.ICS_CAFO_PROD_AREA_DSCH
 WHERE ICS_CAFO_PROD_AREA_DSCH.ICS_CAFO_ANNUL_PROG_REP_ID IN
          (SELECT I4.ICS_CAFO_ANNUL_PROG_REP_ID
              from ics_flow_icis.ICS_CAFO_ANNUL_PROG_REP ICS_CAFO_ANNUL_PROG_REP 
 JOIN ics_flow_icis.ICS_CAFO_PROD_AREA_DSCH I4
 ON I4.ICS_CAFO_ANNUL_PROG_REP_ID = ICS_CAFO_ANNUL_PROG_REP.ICS_CAFO_ANNUL_PROG_REP_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CAFO_ANNUL_PROG_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CAFOAnnualProgramReportSubmission')
                  OR ICS_CAFO_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_CAFO_ANNUL_PROG_REP/ICS_CAFO_LAND_APPL_FLD_INFO/ICS_CAFOMLPW_FLD_AMOUNTS
DELETE
  FROM ics_flow_icis.ICS_CAFOMLPW_FLD_AMOUNTS
 WHERE ICS_CAFOMLPW_FLD_AMOUNTS.ICS_CAFO_LAND_APPL_FLD_INFO_ID IN
          (SELECT I3.ICS_CAFO_LAND_APPL_FLD_INFO_ID
              from ics_flow_icis.ICS_CAFO_ANNUL_PROG_REP ICS_CAFO_ANNUL_PROG_REP 
 JOIN ics_flow_icis.ICS_CAFO_LAND_APPL_FLD_INFO I2
 ON I2.ICS_CAFO_ANNUL_PROG_REP_ID = ICS_CAFO_ANNUL_PROG_REP.ICS_CAFO_ANNUL_PROG_REP_ID 
 JOIN ics_flow_icis.ICS_CAFOMLPW_FLD_AMOUNTS I3
 ON I3.ICS_CAFO_LAND_APPL_FLD_INFO_ID = I2.ICS_CAFO_LAND_APPL_FLD_INFO_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CAFO_ANNUL_PROG_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CAFOAnnualProgramReportSubmission')
                  OR ICS_CAFO_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_CAFO_ANNUL_PROG_REP/ICS_CAFO_LAND_APPL_FLD_INFO
DELETE
  FROM ics_flow_icis.ICS_CAFO_LAND_APPL_FLD_INFO
 WHERE ICS_CAFO_LAND_APPL_FLD_INFO.ICS_CAFO_ANNUL_PROG_REP_ID IN
          (SELECT I2.ICS_CAFO_ANNUL_PROG_REP_ID
              from ics_flow_icis.ICS_CAFO_ANNUL_PROG_REP ICS_CAFO_ANNUL_PROG_REP 
 JOIN ics_flow_icis.ICS_CAFO_LAND_APPL_FLD_INFO I2
 ON I2.ICS_CAFO_ANNUL_PROG_REP_ID = ICS_CAFO_ANNUL_PROG_REP.ICS_CAFO_ANNUL_PROG_REP_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CAFO_ANNUL_PROG_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CAFOAnnualProgramReportSubmission')
                  OR ICS_CAFO_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_CAFO_ANNUL_PROG_REP/ICS_ANML_TYPE
DELETE
  FROM ics_flow_icis.ICS_ANML_TYPE
 WHERE ICS_ANML_TYPE.ICS_CAFO_ANNUL_PROG_REP_ID IN
          (SELECT I1.ICS_CAFO_ANNUL_PROG_REP_ID
              from ics_flow_icis.ICS_CAFO_ANNUL_PROG_REP ICS_CAFO_ANNUL_PROG_REP 
 JOIN ics_flow_icis.ICS_ANML_TYPE I1
 ON I1.ICS_CAFO_ANNUL_PROG_REP_ID = ICS_CAFO_ANNUL_PROG_REP.ICS_CAFO_ANNUL_PROG_REP_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CAFO_ANNUL_PROG_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CAFOAnnualProgramReportSubmission')
                  OR ICS_CAFO_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_CAFO_ANNUL_PROG_REP
DELETE
  FROM ics_flow_icis.ICS_CAFO_ANNUL_PROG_REP
 WHERE ICS_CAFO_ANNUL_PROG_REP.ICS_CAFO_ANNUL_PROG_REP_ID IN
          (SELECT ICS_CAFO_ANNUL_PROG_REP.ICS_CAFO_ANNUL_PROG_REP_ID
              from ics_flow_icis.ICS_CAFO_ANNUL_PROG_REP ICS_CAFO_ANNUL_PROG_REP 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CAFO_ANNUL_PROG_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CAFOAnnualProgramReportSubmission')
                  OR ICS_CAFO_ANNUL_PROG_REP.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

	
-- Add accepted records for ICS_CAFO_ANNUL_PROG_REP


-- /ICS_CAFO_ANNUL_PROG_REP
INSERT INTO ics_flow_icis.ICS_CAFO_ANNUL_PROG_REP
     SELECT ICS_CAFO_ANNUL_PROG_REP.*
              from ICS_CAFO_ANNUL_PROG_REP ICS_CAFO_ANNUL_PROG_REP 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CAFO_ANNUL_PROG_REP.KEY_HASH
       WHERE ICS_CAFO_ANNUL_PROG_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'CAFOAnnualProgramReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CAFOAnnualProgramReportSubmission');


-- /ICS_CAFO_ANNUL_PROG_REP/ICS_ANML_TYPE
INSERT INTO ics_flow_icis.ICS_ANML_TYPE
     SELECT I1.*
              from ICS_CAFO_ANNUL_PROG_REP ICS_CAFO_ANNUL_PROG_REP 
 JOIN ICS_ANML_TYPE I1
 ON I1.ICS_CAFO_ANNUL_PROG_REP_ID = ICS_CAFO_ANNUL_PROG_REP.ICS_CAFO_ANNUL_PROG_REP_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CAFO_ANNUL_PROG_REP.KEY_HASH
       WHERE ICS_CAFO_ANNUL_PROG_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'CAFOAnnualProgramReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CAFOAnnualProgramReportSubmission');


-- /ICS_CAFO_ANNUL_PROG_REP/ICS_CAFO_LAND_APPL_FLD_INFO
INSERT INTO ics_flow_icis.ICS_CAFO_LAND_APPL_FLD_INFO
     SELECT I2.*
              from ICS_CAFO_ANNUL_PROG_REP ICS_CAFO_ANNUL_PROG_REP 
 JOIN ICS_CAFO_LAND_APPL_FLD_INFO I2
 ON I2.ICS_CAFO_ANNUL_PROG_REP_ID = ICS_CAFO_ANNUL_PROG_REP.ICS_CAFO_ANNUL_PROG_REP_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CAFO_ANNUL_PROG_REP.KEY_HASH
       WHERE ICS_CAFO_ANNUL_PROG_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'CAFOAnnualProgramReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CAFOAnnualProgramReportSubmission');


-- /ICS_CAFO_ANNUL_PROG_REP/ICS_CAFO_LAND_APPL_FLD_INFO/ICS_CAFOMLPW_FLD_AMOUNTS
INSERT INTO ics_flow_icis.ICS_CAFOMLPW_FLD_AMOUNTS
     SELECT I3.*
              from ICS_CAFO_ANNUL_PROG_REP ICS_CAFO_ANNUL_PROG_REP 
 JOIN ICS_CAFO_LAND_APPL_FLD_INFO I2
 ON I2.ICS_CAFO_ANNUL_PROG_REP_ID = ICS_CAFO_ANNUL_PROG_REP.ICS_CAFO_ANNUL_PROG_REP_ID 
 JOIN ICS_CAFOMLPW_FLD_AMOUNTS I3
 ON I3.ICS_CAFO_LAND_APPL_FLD_INFO_ID = I2.ICS_CAFO_LAND_APPL_FLD_INFO_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CAFO_ANNUL_PROG_REP.KEY_HASH
       WHERE ICS_CAFO_ANNUL_PROG_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'CAFOAnnualProgramReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CAFOAnnualProgramReportSubmission');


-- /ICS_CAFO_ANNUL_PROG_REP/ICS_CAFO_PROD_AREA_DSCH
INSERT INTO ics_flow_icis.ICS_CAFO_PROD_AREA_DSCH
     SELECT I4.*
              from ICS_CAFO_ANNUL_PROG_REP ICS_CAFO_ANNUL_PROG_REP 
 JOIN ICS_CAFO_PROD_AREA_DSCH I4
 ON I4.ICS_CAFO_ANNUL_PROG_REP_ID = ICS_CAFO_ANNUL_PROG_REP.ICS_CAFO_ANNUL_PROG_REP_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CAFO_ANNUL_PROG_REP.KEY_HASH
       WHERE ICS_CAFO_ANNUL_PROG_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'CAFOAnnualProgramReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CAFOAnnualProgramReportSubmission');


-- /ICS_CAFO_ANNUL_PROG_REP/ICS_CAFOMLPW_NUTR_MON
INSERT INTO ics_flow_icis.ICS_CAFOMLPW_NUTR_MON
     SELECT I5.*
              from ICS_CAFO_ANNUL_PROG_REP ICS_CAFO_ANNUL_PROG_REP 
 JOIN ICS_CAFOMLPW_NUTR_MON I5
 ON I5.ICS_CAFO_ANNUL_PROG_REP_ID = ICS_CAFO_ANNUL_PROG_REP.ICS_CAFO_ANNUL_PROG_REP_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CAFO_ANNUL_PROG_REP.KEY_HASH
       WHERE ICS_CAFO_ANNUL_PROG_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'CAFOAnnualProgramReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CAFOAnnualProgramReportSubmission');


-- /ICS_CAFO_ANNUL_PROG_REP/ICS_CAFOMLPW_TTL_AMOUNTS
INSERT INTO ics_flow_icis.ICS_CAFOMLPW_TTL_AMOUNTS
     SELECT I6.*
              from ICS_CAFO_ANNUL_PROG_REP ICS_CAFO_ANNUL_PROG_REP 
 JOIN ICS_CAFOMLPW_TTL_AMOUNTS I6
 ON I6.ICS_CAFO_ANNUL_PROG_REP_ID = ICS_CAFO_ANNUL_PROG_REP.ICS_CAFO_ANNUL_PROG_REP_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CAFO_ANNUL_PROG_REP.KEY_HASH
       WHERE ICS_CAFO_ANNUL_PROG_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'CAFOAnnualProgramReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CAFOAnnualProgramReportSubmission');
	




-- Remove any old records for ICS_CAFO_PRMT
				
-- /ICS_CAFO_PRMT/ICS_CAFOMLPW_TTL_AMOUNTS
DELETE
  FROM ics_flow_icis.ICS_CAFOMLPW_TTL_AMOUNTS
 WHERE ICS_CAFOMLPW_TTL_AMOUNTS.ICS_CAFO_PRMT_ID IN
          (SELECT I9.ICS_CAFO_PRMT_ID
              from ics_flow_icis.ICS_CAFO_PRMT ICS_CAFO_PRMT 
 JOIN ics_flow_icis.ICS_CAFOMLPW_TTL_AMOUNTS I9
 ON I9.ICS_CAFO_PRMT_ID = ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CAFO_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CAFOPermitSubmission')
                  OR ICS_CAFO_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_CAFO_PRMT/ICS_MNUR_LTTR_PRCSS_WW_STOR
DELETE
  FROM ics_flow_icis.ICS_MNUR_LTTR_PRCSS_WW_STOR
 WHERE ICS_MNUR_LTTR_PRCSS_WW_STOR.ICS_CAFO_PRMT_ID IN
          (SELECT I8.ICS_CAFO_PRMT_ID
              from ics_flow_icis.ICS_CAFO_PRMT ICS_CAFO_PRMT 
 JOIN ics_flow_icis.ICS_MNUR_LTTR_PRCSS_WW_STOR I8
 ON I8.ICS_CAFO_PRMT_ID = ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CAFO_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CAFOPermitSubmission')
                  OR ICS_CAFO_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_CAFO_PRMT/ICS_ANML_TYPE
DELETE
  FROM ics_flow_icis.ICS_ANML_TYPE
 WHERE ICS_ANML_TYPE.ICS_CAFO_PRMT_ID IN
          (SELECT I7.ICS_CAFO_PRMT_ID
              from ics_flow_icis.ICS_CAFO_PRMT ICS_CAFO_PRMT 
 JOIN ics_flow_icis.ICS_ANML_TYPE I7
 ON I7.ICS_CAFO_PRMT_ID = ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CAFO_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CAFOPermitSubmission')
                  OR ICS_CAFO_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_CAFO_PRMT/ICS_ADDR/ICS_TELEPH
DELETE
  FROM ics_flow_icis.ICS_TELEPH
 WHERE ICS_TELEPH.ICS_ADDR_ID IN
          (SELECT I6.ICS_ADDR_ID
              from ics_flow_icis.ICS_CAFO_PRMT ICS_CAFO_PRMT 
 JOIN ics_flow_icis.ICS_ADDR I5
 ON I5.ICS_CAFO_PRMT_ID = ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID 
 JOIN ics_flow_icis.ICS_TELEPH I6
 ON I6.ICS_ADDR_ID = I5.ICS_ADDR_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CAFO_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CAFOPermitSubmission')
                  OR ICS_CAFO_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_CAFO_PRMT/ICS_ADDR
DELETE
  FROM ics_flow_icis.ICS_ADDR
 WHERE ICS_ADDR.ICS_CAFO_PRMT_ID IN
          (SELECT I5.ICS_CAFO_PRMT_ID
              from ics_flow_icis.ICS_CAFO_PRMT ICS_CAFO_PRMT 
 JOIN ics_flow_icis.ICS_ADDR I5
 ON I5.ICS_CAFO_PRMT_ID = ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CAFO_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CAFOPermitSubmission')
                  OR ICS_CAFO_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_CAFO_PRMT/ICS_LAND_APPL_BMP
DELETE
  FROM ics_flow_icis.ICS_LAND_APPL_BMP
 WHERE ICS_LAND_APPL_BMP.ICS_CAFO_PRMT_ID IN
          (SELECT I4.ICS_CAFO_PRMT_ID
              from ics_flow_icis.ICS_CAFO_PRMT ICS_CAFO_PRMT 
 JOIN ics_flow_icis.ICS_LAND_APPL_BMP I4
 ON I4.ICS_CAFO_PRMT_ID = ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CAFO_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CAFOPermitSubmission')
                  OR ICS_CAFO_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_CAFO_PRMT/ICS_CONTAINMENT
DELETE
  FROM ics_flow_icis.ICS_CONTAINMENT
 WHERE ICS_CONTAINMENT.ICS_CAFO_PRMT_ID IN
          (SELECT I3.ICS_CAFO_PRMT_ID
              from ics_flow_icis.ICS_CAFO_PRMT ICS_CAFO_PRMT 
 JOIN ics_flow_icis.ICS_CONTAINMENT I3
 ON I3.ICS_CAFO_PRMT_ID = ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CAFO_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CAFOPermitSubmission')
                  OR ICS_CAFO_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_CAFO_PRMT/ICS_CONTACT/ICS_TELEPH
DELETE
  FROM ics_flow_icis.ICS_TELEPH
 WHERE ICS_TELEPH.ICS_CONTACT_ID IN
          (SELECT I2.ICS_CONTACT_ID
              from ics_flow_icis.ICS_CAFO_PRMT ICS_CAFO_PRMT 
 JOIN ics_flow_icis.ICS_CONTACT I1
 ON I1.ICS_CAFO_PRMT_ID = ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID 
 JOIN ics_flow_icis.ICS_TELEPH I2
 ON I2.ICS_CONTACT_ID = I1.ICS_CONTACT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CAFO_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CAFOPermitSubmission')
                  OR ICS_CAFO_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_CAFO_PRMT/ICS_CONTACT
DELETE
  FROM ics_flow_icis.ICS_CONTACT
 WHERE ICS_CONTACT.ICS_CAFO_PRMT_ID IN
          (SELECT I1.ICS_CAFO_PRMT_ID
              from ics_flow_icis.ICS_CAFO_PRMT ICS_CAFO_PRMT 
 JOIN ics_flow_icis.ICS_CONTACT I1
 ON I1.ICS_CAFO_PRMT_ID = ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CAFO_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CAFOPermitSubmission')
                  OR ICS_CAFO_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_CAFO_PRMT
DELETE
  FROM ics_flow_icis.ICS_CAFO_PRMT
 WHERE ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID IN
          (SELECT ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID
              from ics_flow_icis.ICS_CAFO_PRMT ICS_CAFO_PRMT 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CAFO_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CAFOPermitSubmission')
                  OR ICS_CAFO_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

	
-- Add accepted records for ICS_CAFO_PRMT


-- /ICS_CAFO_PRMT
INSERT INTO ics_flow_icis.ICS_CAFO_PRMT
     SELECT ICS_CAFO_PRMT.*
              from ICS_CAFO_PRMT ICS_CAFO_PRMT 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CAFO_PRMT.KEY_HASH
       WHERE ICS_CAFO_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'CAFOPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CAFOPermitSubmission');


-- /ICS_CAFO_PRMT/ICS_CONTACT
INSERT INTO ics_flow_icis.ICS_CONTACT
     SELECT I1.*
              from ICS_CAFO_PRMT ICS_CAFO_PRMT 
 JOIN ICS_CONTACT I1
 ON I1.ICS_CAFO_PRMT_ID = ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CAFO_PRMT.KEY_HASH
       WHERE ICS_CAFO_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'CAFOPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CAFOPermitSubmission');


-- /ICS_CAFO_PRMT/ICS_CONTACT/ICS_TELEPH
INSERT INTO ics_flow_icis.ICS_TELEPH
     SELECT I2.*
              from ICS_CAFO_PRMT ICS_CAFO_PRMT 
 JOIN ICS_CONTACT I1
 ON I1.ICS_CAFO_PRMT_ID = ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID 
 JOIN ICS_TELEPH I2
 ON I2.ICS_CONTACT_ID = I1.ICS_CONTACT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CAFO_PRMT.KEY_HASH
       WHERE ICS_CAFO_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'CAFOPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CAFOPermitSubmission');


-- /ICS_CAFO_PRMT/ICS_CONTAINMENT
INSERT INTO ics_flow_icis.ICS_CONTAINMENT
     SELECT I3.*
              from ICS_CAFO_PRMT ICS_CAFO_PRMT 
 JOIN ICS_CONTAINMENT I3
 ON I3.ICS_CAFO_PRMT_ID = ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CAFO_PRMT.KEY_HASH
       WHERE ICS_CAFO_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'CAFOPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CAFOPermitSubmission');


-- /ICS_CAFO_PRMT/ICS_LAND_APPL_BMP
INSERT INTO ics_flow_icis.ICS_LAND_APPL_BMP
     SELECT I4.*
              from ICS_CAFO_PRMT ICS_CAFO_PRMT 
 JOIN ICS_LAND_APPL_BMP I4
 ON I4.ICS_CAFO_PRMT_ID = ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CAFO_PRMT.KEY_HASH
       WHERE ICS_CAFO_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'CAFOPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CAFOPermitSubmission');


-- /ICS_CAFO_PRMT/ICS_ADDR
INSERT INTO ics_flow_icis.ICS_ADDR
     SELECT I5.*
              from ICS_CAFO_PRMT ICS_CAFO_PRMT 
 JOIN ICS_ADDR I5
 ON I5.ICS_CAFO_PRMT_ID = ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CAFO_PRMT.KEY_HASH
       WHERE ICS_CAFO_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'CAFOPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CAFOPermitSubmission');


-- /ICS_CAFO_PRMT/ICS_ADDR/ICS_TELEPH
INSERT INTO ics_flow_icis.ICS_TELEPH
     SELECT I6.*
              from ICS_CAFO_PRMT ICS_CAFO_PRMT 
 JOIN ICS_ADDR I5
 ON I5.ICS_CAFO_PRMT_ID = ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID 
 JOIN ICS_TELEPH I6
 ON I6.ICS_ADDR_ID = I5.ICS_ADDR_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CAFO_PRMT.KEY_HASH
       WHERE ICS_CAFO_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'CAFOPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CAFOPermitSubmission');


-- /ICS_CAFO_PRMT/ICS_ANML_TYPE
INSERT INTO ics_flow_icis.ICS_ANML_TYPE
     SELECT I7.*
              from ICS_CAFO_PRMT ICS_CAFO_PRMT 
 JOIN ICS_ANML_TYPE I7
 ON I7.ICS_CAFO_PRMT_ID = ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CAFO_PRMT.KEY_HASH
       WHERE ICS_CAFO_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'CAFOPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CAFOPermitSubmission');


-- /ICS_CAFO_PRMT/ICS_MNUR_LTTR_PRCSS_WW_STOR
INSERT INTO ics_flow_icis.ICS_MNUR_LTTR_PRCSS_WW_STOR
     SELECT I8.*
              from ICS_CAFO_PRMT ICS_CAFO_PRMT 
 JOIN ICS_MNUR_LTTR_PRCSS_WW_STOR I8
 ON I8.ICS_CAFO_PRMT_ID = ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CAFO_PRMT.KEY_HASH
       WHERE ICS_CAFO_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'CAFOPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CAFOPermitSubmission');


-- /ICS_CAFO_PRMT/ICS_CAFOMLPW_TTL_AMOUNTS
INSERT INTO ics_flow_icis.ICS_CAFOMLPW_TTL_AMOUNTS
     SELECT I9.*
              from ICS_CAFO_PRMT ICS_CAFO_PRMT 
 JOIN ICS_CAFOMLPW_TTL_AMOUNTS I9
 ON I9.ICS_CAFO_PRMT_ID = ICS_CAFO_PRMT.ICS_CAFO_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CAFO_PRMT.KEY_HASH
       WHERE ICS_CAFO_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'CAFOPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CAFOPermitSubmission');
	




-- Remove any old records for ICS_COLL_SYSTM_PRMT
				
-- /ICS_COLL_SYSTM_PRMT
DELETE
  FROM ics_flow_icis.ICS_COLL_SYSTM_PRMT
 WHERE ICS_COLL_SYSTM_PRMT.ICS_COLL_SYSTM_PRMT_ID IN
          (SELECT ICS_COLL_SYSTM_PRMT.ICS_COLL_SYSTM_PRMT_ID
              from ics_flow_icis.ICS_COLL_SYSTM_PRMT ICS_COLL_SYSTM_PRMT 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_COLL_SYSTM_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CollectionSystemPermitSubmission')
                  OR ICS_COLL_SYSTM_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_COLL_SYSTM_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

	
-- Add accepted records for ICS_COLL_SYSTM_PRMT


-- /ICS_COLL_SYSTM_PRMT
INSERT INTO ics_flow_icis.ICS_COLL_SYSTM_PRMT
     SELECT ICS_COLL_SYSTM_PRMT.*
              from ICS_COLL_SYSTM_PRMT ICS_COLL_SYSTM_PRMT 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_COLL_SYSTM_PRMT.KEY_HASH
       WHERE ICS_COLL_SYSTM_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'CollectionSystemPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CollectionSystemPermitSubmission');
	




-- Remove any old records for ICS_CMPL_MON
				
-- /ICS_CMPL_MON/ICS_CMPL_MON_AGNCY_TYPE
DELETE
  FROM ics_flow_icis.ICS_CMPL_MON_AGNCY_TYPE
 WHERE ICS_CMPL_MON_AGNCY_TYPE.ICS_CMPL_MON_ID IN
          (SELECT I36.ICS_CMPL_MON_ID
              from ics_flow_icis.ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ics_flow_icis.ICS_CMPL_MON_AGNCY_TYPE I36
 ON I36.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_CMPL_MON/ICS_CMPL_MON_ACTN_REASON
DELETE
  FROM ics_flow_icis.ICS_CMPL_MON_ACTN_REASON
 WHERE ICS_CMPL_MON_ACTN_REASON.ICS_CMPL_MON_ID IN
          (SELECT I35.ICS_CMPL_MON_ID
              from ics_flow_icis.ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ics_flow_icis.ICS_CMPL_MON_ACTN_REASON I35
 ON I35.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_CMPL_MON/ICS_CMPL_INSP_TYPE
DELETE
  FROM ics_flow_icis.ICS_CMPL_INSP_TYPE
 WHERE ICS_CMPL_INSP_TYPE.ICS_CMPL_MON_ID IN
          (SELECT I34.ICS_CMPL_MON_ID
              from ics_flow_icis.ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ics_flow_icis.ICS_CMPL_INSP_TYPE I34
 ON I34.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_CMPL_MON/ICS_CAFO_INSP/ICS_CAFO_INSP_VIOL_TYPE
DELETE
  FROM ics_flow_icis.ICS_CAFO_INSP_VIOL_TYPE
 WHERE ICS_CAFO_INSP_VIOL_TYPE.ICS_CAFO_INSP_ID IN
          (SELECT I33.ICS_CAFO_INSP_ID
              from ics_flow_icis.ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ics_flow_icis.ICS_CAFO_INSP I28
 ON I28.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
 JOIN ics_flow_icis.ICS_CAFO_INSP_VIOL_TYPE I33
 ON I33.ICS_CAFO_INSP_ID = I28.ICS_CAFO_INSP_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_CMPL_MON/ICS_CAFO_INSP/ICS_MNUR_LTTR_PRCSS_WW_STOR
DELETE
  FROM ics_flow_icis.ICS_MNUR_LTTR_PRCSS_WW_STOR
 WHERE ICS_MNUR_LTTR_PRCSS_WW_STOR.ICS_CAFO_INSP_ID IN
          (SELECT I32.ICS_CAFO_INSP_ID
              from ics_flow_icis.ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ics_flow_icis.ICS_CAFO_INSP I28
 ON I28.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
 JOIN ics_flow_icis.ICS_MNUR_LTTR_PRCSS_WW_STOR I32
 ON I32.ICS_CAFO_INSP_ID = I28.ICS_CAFO_INSP_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_CMPL_MON/ICS_CAFO_INSP/ICS_ANML_TYPE
DELETE
  FROM ics_flow_icis.ICS_ANML_TYPE
 WHERE ICS_ANML_TYPE.ICS_CAFO_INSP_ID IN
          (SELECT I31.ICS_CAFO_INSP_ID
              from ics_flow_icis.ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ics_flow_icis.ICS_CAFO_INSP I28
 ON I28.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
 JOIN ics_flow_icis.ICS_ANML_TYPE I31
 ON I31.ICS_CAFO_INSP_ID = I28.ICS_CAFO_INSP_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_CMPL_MON/ICS_CAFO_INSP/ICS_LAND_APPL_BMP
DELETE
  FROM ics_flow_icis.ICS_LAND_APPL_BMP
 WHERE ICS_LAND_APPL_BMP.ICS_CAFO_INSP_ID IN
          (SELECT I30.ICS_CAFO_INSP_ID
              from ics_flow_icis.ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ics_flow_icis.ICS_CAFO_INSP I28
 ON I28.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
 JOIN ics_flow_icis.ICS_LAND_APPL_BMP I30
 ON I30.ICS_CAFO_INSP_ID = I28.ICS_CAFO_INSP_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_CMPL_MON/ICS_CAFO_INSP/ICS_CONTAINMENT
DELETE
  FROM ics_flow_icis.ICS_CONTAINMENT
 WHERE ICS_CONTAINMENT.ICS_CAFO_INSP_ID IN
          (SELECT I29.ICS_CAFO_INSP_ID
              from ics_flow_icis.ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ics_flow_icis.ICS_CAFO_INSP I28
 ON I28.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
 JOIN ics_flow_icis.ICS_CONTAINMENT I29
 ON I29.ICS_CAFO_INSP_ID = I28.ICS_CAFO_INSP_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_CMPL_MON/ICS_CAFO_INSP
DELETE
  FROM ics_flow_icis.ICS_CAFO_INSP
 WHERE ICS_CAFO_INSP.ICS_CMPL_MON_ID IN
          (SELECT I28.ICS_CMPL_MON_ID
              from ics_flow_icis.ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ics_flow_icis.ICS_CAFO_INSP I28
 ON I28.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_CMPL_MON/ICS_SW_NON_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP/ICS_PROJ_TYPE
DELETE
  FROM ics_flow_icis.ICS_PROJ_TYPE
 WHERE ICS_PROJ_TYPE.ICS_SW_UNPRMT_CNST_INSP_ID IN
          (SELECT I27.ICS_SW_UNPRMT_CNST_INSP_ID
              from ics_flow_icis.ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ics_flow_icis.ICS_SW_NON_CNST_INSP I24
 ON I24.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
 JOIN ics_flow_icis.ICS_SW_UNPRMT_CNST_INSP I26
 ON I26.ICS_SW_NON_CNST_INSP_ID = I24.ICS_SW_NON_CNST_INSP_ID 
 JOIN ics_flow_icis.ICS_PROJ_TYPE I27
 ON I27.ICS_SW_UNPRMT_CNST_INSP_ID = I26.ICS_SW_UNPRMT_CNST_INSP_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_CMPL_MON/ICS_SW_NON_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP
DELETE
  FROM ics_flow_icis.ICS_SW_UNPRMT_CNST_INSP
 WHERE ICS_SW_UNPRMT_CNST_INSP.ICS_SW_NON_CNST_INSP_ID IN
          (SELECT I26.ICS_SW_NON_CNST_INSP_ID
              from ics_flow_icis.ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ics_flow_icis.ICS_SW_NON_CNST_INSP I24
 ON I24.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
 JOIN ics_flow_icis.ICS_SW_UNPRMT_CNST_INSP I26
 ON I26.ICS_SW_NON_CNST_INSP_ID = I24.ICS_SW_NON_CNST_INSP_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_CMPL_MON/ICS_SW_NON_CNST_INSP/ICS_SW_CNST_INDST_INSP
DELETE
  FROM ics_flow_icis.ICS_SW_CNST_INDST_INSP
 WHERE ICS_SW_CNST_INDST_INSP.ICS_SW_NON_CNST_INSP_ID IN
          (SELECT I25.ICS_SW_NON_CNST_INSP_ID
              from ics_flow_icis.ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ics_flow_icis.ICS_SW_NON_CNST_INSP I24
 ON I24.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
 JOIN ics_flow_icis.ICS_SW_CNST_INDST_INSP I25
 ON I25.ICS_SW_NON_CNST_INSP_ID = I24.ICS_SW_NON_CNST_INSP_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_CMPL_MON/ICS_SW_NON_CNST_INSP
DELETE
  FROM ics_flow_icis.ICS_SW_NON_CNST_INSP
 WHERE ICS_SW_NON_CNST_INSP.ICS_CMPL_MON_ID IN
          (SELECT I24.ICS_CMPL_MON_ID
              from ics_flow_icis.ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ics_flow_icis.ICS_SW_NON_CNST_INSP I24
 ON I24.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_CMPL_MON/ICS_SW_MS_4_INSP/ICS_PROJ_SRCS_FUND
DELETE
  FROM ics_flow_icis.ICS_PROJ_SRCS_FUND
 WHERE ICS_PROJ_SRCS_FUND.ICS_SW_MS_4_INSP_ID IN
          (SELECT I23.ICS_SW_MS_4_INSP_ID
              from ics_flow_icis.ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ics_flow_icis.ICS_SW_MS_4_INSP I22
 ON I22.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
 JOIN ics_flow_icis.ICS_PROJ_SRCS_FUND I23
 ON I23.ICS_SW_MS_4_INSP_ID = I22.ICS_SW_MS_4_INSP_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_CMPL_MON/ICS_SW_MS_4_INSP
DELETE
  FROM ics_flow_icis.ICS_SW_MS_4_INSP
 WHERE ICS_SW_MS_4_INSP.ICS_CMPL_MON_ID IN
          (SELECT I22.ICS_CMPL_MON_ID
              from ics_flow_icis.ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ics_flow_icis.ICS_SW_MS_4_INSP I22
 ON I22.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_CMPL_MON/ICS_SW_CNST_NON_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP/ICS_PROJ_TYPE
DELETE
  FROM ics_flow_icis.ICS_PROJ_TYPE
 WHERE ICS_PROJ_TYPE.ICS_SW_UNPRMT_CNST_INSP_ID IN
          (SELECT I21.ICS_SW_UNPRMT_CNST_INSP_ID
              from ics_flow_icis.ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ics_flow_icis.ICS_SW_CNST_NON_CNST_INSP I18
 ON I18.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
 JOIN ics_flow_icis.ICS_SW_UNPRMT_CNST_INSP I20
 ON I20.ICS_SW_CNST_NON_CNST_INSP_ID = I18.ICS_SW_CNST_NON_CNST_INSP_ID 
 JOIN ics_flow_icis.ICS_PROJ_TYPE I21
 ON I21.ICS_SW_UNPRMT_CNST_INSP_ID = I20.ICS_SW_UNPRMT_CNST_INSP_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_CMPL_MON/ICS_SW_CNST_NON_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP
DELETE
  FROM ics_flow_icis.ICS_SW_UNPRMT_CNST_INSP
 WHERE ICS_SW_UNPRMT_CNST_INSP.ICS_SW_CNST_NON_CNST_INSP_ID IN
          (SELECT I20.ICS_SW_CNST_NON_CNST_INSP_ID
              from ics_flow_icis.ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ics_flow_icis.ICS_SW_CNST_NON_CNST_INSP I18
 ON I18.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
 JOIN ics_flow_icis.ICS_SW_UNPRMT_CNST_INSP I20
 ON I20.ICS_SW_CNST_NON_CNST_INSP_ID = I18.ICS_SW_CNST_NON_CNST_INSP_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_CMPL_MON/ICS_SW_CNST_NON_CNST_INSP/ICS_SW_CNST_INDST_INSP
DELETE
  FROM ics_flow_icis.ICS_SW_CNST_INDST_INSP
 WHERE ICS_SW_CNST_INDST_INSP.ICS_SW_CNST_NON_CNST_INSP_ID IN
          (SELECT I19.ICS_SW_CNST_NON_CNST_INSP_ID
              from ics_flow_icis.ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ics_flow_icis.ICS_SW_CNST_NON_CNST_INSP I18
 ON I18.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
 JOIN ics_flow_icis.ICS_SW_CNST_INDST_INSP I19
 ON I19.ICS_SW_CNST_NON_CNST_INSP_ID = I18.ICS_SW_CNST_NON_CNST_INSP_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_CMPL_MON/ICS_SW_CNST_NON_CNST_INSP
DELETE
  FROM ics_flow_icis.ICS_SW_CNST_NON_CNST_INSP
 WHERE ICS_SW_CNST_NON_CNST_INSP.ICS_CMPL_MON_ID IN
          (SELECT I18.ICS_CMPL_MON_ID
              from ics_flow_icis.ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ics_flow_icis.ICS_SW_CNST_NON_CNST_INSP I18
 ON I18.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_CMPL_MON/ICS_SW_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP/ICS_PROJ_TYPE
DELETE
  FROM ics_flow_icis.ICS_PROJ_TYPE
 WHERE ICS_PROJ_TYPE.ICS_SW_UNPRMT_CNST_INSP_ID IN
          (SELECT I17.ICS_SW_UNPRMT_CNST_INSP_ID
              from ics_flow_icis.ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ics_flow_icis.ICS_SW_CNST_INSP I14
 ON I14.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
 JOIN ics_flow_icis.ICS_SW_UNPRMT_CNST_INSP I16
 ON I16.ICS_SW_CNST_INSP_ID = I14.ICS_SW_CNST_INSP_ID 
 JOIN ics_flow_icis.ICS_PROJ_TYPE I17
 ON I17.ICS_SW_UNPRMT_CNST_INSP_ID = I16.ICS_SW_UNPRMT_CNST_INSP_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_CMPL_MON/ICS_SW_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP
DELETE
  FROM ics_flow_icis.ICS_SW_UNPRMT_CNST_INSP
 WHERE ICS_SW_UNPRMT_CNST_INSP.ICS_SW_CNST_INSP_ID IN
          (SELECT I16.ICS_SW_CNST_INSP_ID
              from ics_flow_icis.ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ics_flow_icis.ICS_SW_CNST_INSP I14
 ON I14.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
 JOIN ics_flow_icis.ICS_SW_UNPRMT_CNST_INSP I16
 ON I16.ICS_SW_CNST_INSP_ID = I14.ICS_SW_CNST_INSP_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_CMPL_MON/ICS_SW_CNST_INSP/ICS_SW_CNST_INDST_INSP
DELETE
  FROM ics_flow_icis.ICS_SW_CNST_INDST_INSP
 WHERE ICS_SW_CNST_INDST_INSP.ICS_SW_CNST_INSP_ID IN
          (SELECT I15.ICS_SW_CNST_INSP_ID
              from ics_flow_icis.ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ics_flow_icis.ICS_SW_CNST_INSP I14
 ON I14.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
 JOIN ics_flow_icis.ICS_SW_CNST_INDST_INSP I15
 ON I15.ICS_SW_CNST_INSP_ID = I14.ICS_SW_CNST_INSP_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_CMPL_MON/ICS_SW_CNST_INSP
DELETE
  FROM ics_flow_icis.ICS_SW_CNST_INSP
 WHERE ICS_SW_CNST_INSP.ICS_CMPL_MON_ID IN
          (SELECT I14.ICS_CMPL_MON_ID
              from ics_flow_icis.ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ics_flow_icis.ICS_SW_CNST_INSP I14
 ON I14.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_CMPL_MON/ICS_SSO_INSP/ICS_SSO_SYSTM_COMP
DELETE
  FROM ics_flow_icis.ICS_SSO_SYSTM_COMP
 WHERE ICS_SSO_SYSTM_COMP.ICS_SSO_INSP_ID IN
          (SELECT I13.ICS_SSO_INSP_ID
              from ics_flow_icis.ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ics_flow_icis.ICS_SSO_INSP I10
 ON I10.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
 JOIN ics_flow_icis.ICS_SSO_SYSTM_COMP I13
 ON I13.ICS_SSO_INSP_ID = I10.ICS_SSO_INSP_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_CMPL_MON/ICS_SSO_INSP/ICS_SSO_STPS
DELETE
  FROM ics_flow_icis.ICS_SSO_STPS
 WHERE ICS_SSO_STPS.ICS_SSO_INSP_ID IN
          (SELECT I12.ICS_SSO_INSP_ID
              from ics_flow_icis.ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ics_flow_icis.ICS_SSO_INSP I10
 ON I10.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
 JOIN ics_flow_icis.ICS_SSO_STPS I12
 ON I12.ICS_SSO_INSP_ID = I10.ICS_SSO_INSP_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_CMPL_MON/ICS_SSO_INSP/ICS_IMPACT_SSO_EVT
DELETE
  FROM ics_flow_icis.ICS_IMPACT_SSO_EVT
 WHERE ICS_IMPACT_SSO_EVT.ICS_SSO_INSP_ID IN
          (SELECT I11.ICS_SSO_INSP_ID
              from ics_flow_icis.ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ics_flow_icis.ICS_SSO_INSP I10
 ON I10.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
 JOIN ics_flow_icis.ICS_IMPACT_SSO_EVT I11
 ON I11.ICS_SSO_INSP_ID = I10.ICS_SSO_INSP_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_CMPL_MON/ICS_SSO_INSP
DELETE
  FROM ics_flow_icis.ICS_SSO_INSP
 WHERE ICS_SSO_INSP.ICS_CMPL_MON_ID IN
          (SELECT I10.ICS_CMPL_MON_ID
              from ics_flow_icis.ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ics_flow_icis.ICS_SSO_INSP I10
 ON I10.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_CMPL_MON/ICS_INSP_GOV_CONTACT
DELETE
  FROM ics_flow_icis.ICS_INSP_GOV_CONTACT
 WHERE ICS_INSP_GOV_CONTACT.ICS_CMPL_MON_ID IN
          (SELECT I9.ICS_CMPL_MON_ID
              from ics_flow_icis.ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ics_flow_icis.ICS_INSP_GOV_CONTACT I9
 ON I9.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_CMPL_MON/ICS_INSP_CMNT_TXT
DELETE
  FROM ics_flow_icis.ICS_INSP_CMNT_TXT
 WHERE ICS_INSP_CMNT_TXT.ICS_CMPL_MON_ID IN
          (SELECT I8.ICS_CMPL_MON_ID
              from ics_flow_icis.ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ics_flow_icis.ICS_INSP_CMNT_TXT I8
 ON I8.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_CMPL_MON/ICS_PROG_DEFCY_TYPE
DELETE
  FROM ics_flow_icis.ICS_PROG_DEFCY_TYPE
 WHERE ICS_PROG_DEFCY_TYPE.ICS_CMPL_MON_ID IN
          (SELECT I7.ICS_CMPL_MON_ID
              from ics_flow_icis.ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ics_flow_icis.ICS_PROG_DEFCY_TYPE I7
 ON I7.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_CMPL_MON/ICS_PROG
DELETE
  FROM ics_flow_icis.ICS_PROG
 WHERE ICS_PROG.ICS_CMPL_MON_ID IN
          (SELECT I6.ICS_CMPL_MON_ID
              from ics_flow_icis.ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ics_flow_icis.ICS_PROG I6
 ON I6.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_CMPL_MON/ICS_PRETR_INSP
DELETE
  FROM ics_flow_icis.ICS_PRETR_INSP
 WHERE ICS_PRETR_INSP.ICS_CMPL_MON_ID IN
          (SELECT I5.ICS_CMPL_MON_ID
              from ics_flow_icis.ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ics_flow_icis.ICS_PRETR_INSP I5
 ON I5.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_CMPL_MON/ICS_CSO_INSP
DELETE
  FROM ics_flow_icis.ICS_CSO_INSP
 WHERE ICS_CSO_INSP.ICS_CMPL_MON_ID IN
          (SELECT I4.ICS_CMPL_MON_ID
              from ics_flow_icis.ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ics_flow_icis.ICS_CSO_INSP I4
 ON I4.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_CMPL_MON/ICS_NAT_PRIO
DELETE
  FROM ics_flow_icis.ICS_NAT_PRIO
 WHERE ICS_NAT_PRIO.ICS_CMPL_MON_ID IN
          (SELECT I3.ICS_CMPL_MON_ID
              from ics_flow_icis.ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ics_flow_icis.ICS_NAT_PRIO I3
 ON I3.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_CMPL_MON/ICS_CONTACT/ICS_TELEPH
DELETE
  FROM ics_flow_icis.ICS_TELEPH
 WHERE ICS_TELEPH.ICS_CONTACT_ID IN
          (SELECT I2.ICS_CONTACT_ID
              from ics_flow_icis.ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ics_flow_icis.ICS_CONTACT I1
 ON I1.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
 JOIN ics_flow_icis.ICS_TELEPH I2
 ON I2.ICS_CONTACT_ID = I1.ICS_CONTACT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_CMPL_MON/ICS_CONTACT
DELETE
  FROM ics_flow_icis.ICS_CONTACT
 WHERE ICS_CONTACT.ICS_CMPL_MON_ID IN
          (SELECT I1.ICS_CMPL_MON_ID
              from ics_flow_icis.ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ics_flow_icis.ICS_CONTACT I1
 ON I1.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_CMPL_MON
DELETE
  FROM ics_flow_icis.ICS_CMPL_MON
 WHERE ICS_CMPL_MON.ICS_CMPL_MON_ID IN
          (SELECT ICS_CMPL_MON.ICS_CMPL_MON_ID
              from ics_flow_icis.ICS_CMPL_MON ICS_CMPL_MON 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringSubmission')
                  OR ICS_CMPL_MON.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

	
-- Add accepted records for ICS_CMPL_MON


-- /ICS_CMPL_MON
INSERT INTO ics_flow_icis.ICS_CMPL_MON
     SELECT ICS_CMPL_MON.*
              from ICS_CMPL_MON ICS_CMPL_MON 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'ComplianceMonitoringSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');


-- /ICS_CMPL_MON/ICS_CONTACT
INSERT INTO ics_flow_icis.ICS_CONTACT
     SELECT I1.*
              from ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ICS_CONTACT I1
 ON I1.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'ComplianceMonitoringSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');


-- /ICS_CMPL_MON/ICS_CONTACT/ICS_TELEPH
INSERT INTO ics_flow_icis.ICS_TELEPH
     SELECT I2.*
              from ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ICS_CONTACT I1
 ON I1.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
 JOIN ICS_TELEPH I2
 ON I2.ICS_CONTACT_ID = I1.ICS_CONTACT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'ComplianceMonitoringSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');


-- /ICS_CMPL_MON/ICS_NAT_PRIO
INSERT INTO ics_flow_icis.ICS_NAT_PRIO
     SELECT I3.*
              from ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ICS_NAT_PRIO I3
 ON I3.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'ComplianceMonitoringSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');


-- /ICS_CMPL_MON/ICS_CSO_INSP
INSERT INTO ics_flow_icis.ICS_CSO_INSP
     SELECT I4.*
              from ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ICS_CSO_INSP I4
 ON I4.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'ComplianceMonitoringSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');


-- /ICS_CMPL_MON/ICS_PRETR_INSP
INSERT INTO ics_flow_icis.ICS_PRETR_INSP
     SELECT I5.*
              from ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ICS_PRETR_INSP I5
 ON I5.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'ComplianceMonitoringSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');


-- /ICS_CMPL_MON/ICS_PROG
INSERT INTO ics_flow_icis.ICS_PROG
     SELECT I6.*
              from ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ICS_PROG I6
 ON I6.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'ComplianceMonitoringSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');


-- /ICS_CMPL_MON/ICS_PROG_DEFCY_TYPE
INSERT INTO ics_flow_icis.ICS_PROG_DEFCY_TYPE
     SELECT I7.*
              from ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ICS_PROG_DEFCY_TYPE I7
 ON I7.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'ComplianceMonitoringSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');


-- /ICS_CMPL_MON/ICS_INSP_CMNT_TXT
INSERT INTO ics_flow_icis.ICS_INSP_CMNT_TXT
     SELECT I8.*
              from ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ICS_INSP_CMNT_TXT I8
 ON I8.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'ComplianceMonitoringSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');


-- /ICS_CMPL_MON/ICS_INSP_GOV_CONTACT
INSERT INTO ics_flow_icis.ICS_INSP_GOV_CONTACT
     SELECT I9.*
              from ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ICS_INSP_GOV_CONTACT I9
 ON I9.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'ComplianceMonitoringSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');


-- /ICS_CMPL_MON/ICS_SSO_INSP
INSERT INTO ics_flow_icis.ICS_SSO_INSP
     SELECT I10.*
              from ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ICS_SSO_INSP I10
 ON I10.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'ComplianceMonitoringSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');


-- /ICS_CMPL_MON/ICS_SSO_INSP/ICS_IMPACT_SSO_EVT
INSERT INTO ics_flow_icis.ICS_IMPACT_SSO_EVT
     SELECT I11.*
              from ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ICS_SSO_INSP I10
 ON I10.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
 JOIN ICS_IMPACT_SSO_EVT I11
 ON I11.ICS_SSO_INSP_ID = I10.ICS_SSO_INSP_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'ComplianceMonitoringSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');


-- /ICS_CMPL_MON/ICS_SSO_INSP/ICS_SSO_STPS
INSERT INTO ics_flow_icis.ICS_SSO_STPS
     SELECT I12.*
              from ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ICS_SSO_INSP I10
 ON I10.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
 JOIN ICS_SSO_STPS I12
 ON I12.ICS_SSO_INSP_ID = I10.ICS_SSO_INSP_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'ComplianceMonitoringSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');


-- /ICS_CMPL_MON/ICS_SSO_INSP/ICS_SSO_SYSTM_COMP
INSERT INTO ics_flow_icis.ICS_SSO_SYSTM_COMP
     SELECT I13.*
              from ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ICS_SSO_INSP I10
 ON I10.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
 JOIN ICS_SSO_SYSTM_COMP I13
 ON I13.ICS_SSO_INSP_ID = I10.ICS_SSO_INSP_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'ComplianceMonitoringSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');


-- /ICS_CMPL_MON/ICS_SW_CNST_INSP
INSERT INTO ics_flow_icis.ICS_SW_CNST_INSP
     SELECT I14.*
              from ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ICS_SW_CNST_INSP I14
 ON I14.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'ComplianceMonitoringSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');


-- /ICS_CMPL_MON/ICS_SW_CNST_INSP/ICS_SW_CNST_INDST_INSP
INSERT INTO ics_flow_icis.ICS_SW_CNST_INDST_INSP
     SELECT I15.*
              from ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ICS_SW_CNST_INSP I14
 ON I14.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
 JOIN ICS_SW_CNST_INDST_INSP I15
 ON I15.ICS_SW_CNST_INSP_ID = I14.ICS_SW_CNST_INSP_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'ComplianceMonitoringSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');


-- /ICS_CMPL_MON/ICS_SW_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP
INSERT INTO ics_flow_icis.ICS_SW_UNPRMT_CNST_INSP
     SELECT I16.*
              from ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ICS_SW_CNST_INSP I14
 ON I14.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
 JOIN ICS_SW_UNPRMT_CNST_INSP I16
 ON I16.ICS_SW_CNST_INSP_ID = I14.ICS_SW_CNST_INSP_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'ComplianceMonitoringSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');


-- /ICS_CMPL_MON/ICS_SW_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP/ICS_PROJ_TYPE
INSERT INTO ics_flow_icis.ICS_PROJ_TYPE
     SELECT I17.*
              from ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ICS_SW_CNST_INSP I14
 ON I14.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
 JOIN ICS_SW_UNPRMT_CNST_INSP I16
 ON I16.ICS_SW_CNST_INSP_ID = I14.ICS_SW_CNST_INSP_ID 
 JOIN ICS_PROJ_TYPE I17
 ON I17.ICS_SW_UNPRMT_CNST_INSP_ID = I16.ICS_SW_UNPRMT_CNST_INSP_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'ComplianceMonitoringSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');


-- /ICS_CMPL_MON/ICS_SW_CNST_NON_CNST_INSP
INSERT INTO ics_flow_icis.ICS_SW_CNST_NON_CNST_INSP
     SELECT I18.*
              from ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ICS_SW_CNST_NON_CNST_INSP I18
 ON I18.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'ComplianceMonitoringSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');


-- /ICS_CMPL_MON/ICS_SW_CNST_NON_CNST_INSP/ICS_SW_CNST_INDST_INSP
INSERT INTO ics_flow_icis.ICS_SW_CNST_INDST_INSP
     SELECT I19.*
              from ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ICS_SW_CNST_NON_CNST_INSP I18
 ON I18.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
 JOIN ICS_SW_CNST_INDST_INSP I19
 ON I19.ICS_SW_CNST_NON_CNST_INSP_ID = I18.ICS_SW_CNST_NON_CNST_INSP_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'ComplianceMonitoringSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');


-- /ICS_CMPL_MON/ICS_SW_CNST_NON_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP
INSERT INTO ics_flow_icis.ICS_SW_UNPRMT_CNST_INSP
     SELECT I20.*
              from ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ICS_SW_CNST_NON_CNST_INSP I18
 ON I18.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
 JOIN ICS_SW_UNPRMT_CNST_INSP I20
 ON I20.ICS_SW_CNST_NON_CNST_INSP_ID = I18.ICS_SW_CNST_NON_CNST_INSP_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'ComplianceMonitoringSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');


-- /ICS_CMPL_MON/ICS_SW_CNST_NON_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP/ICS_PROJ_TYPE
INSERT INTO ics_flow_icis.ICS_PROJ_TYPE
     SELECT I21.*
              from ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ICS_SW_CNST_NON_CNST_INSP I18
 ON I18.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
 JOIN ICS_SW_UNPRMT_CNST_INSP I20
 ON I20.ICS_SW_CNST_NON_CNST_INSP_ID = I18.ICS_SW_CNST_NON_CNST_INSP_ID 
 JOIN ICS_PROJ_TYPE I21
 ON I21.ICS_SW_UNPRMT_CNST_INSP_ID = I20.ICS_SW_UNPRMT_CNST_INSP_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'ComplianceMonitoringSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');


-- /ICS_CMPL_MON/ICS_SW_MS_4_INSP
INSERT INTO ics_flow_icis.ICS_SW_MS_4_INSP
     SELECT I22.*
              from ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ICS_SW_MS_4_INSP I22
 ON I22.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'ComplianceMonitoringSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');


-- /ICS_CMPL_MON/ICS_SW_MS_4_INSP/ICS_PROJ_SRCS_FUND
INSERT INTO ics_flow_icis.ICS_PROJ_SRCS_FUND
     SELECT I23.*
              from ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ICS_SW_MS_4_INSP I22
 ON I22.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
 JOIN ICS_PROJ_SRCS_FUND I23
 ON I23.ICS_SW_MS_4_INSP_ID = I22.ICS_SW_MS_4_INSP_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'ComplianceMonitoringSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');


-- /ICS_CMPL_MON/ICS_SW_NON_CNST_INSP
INSERT INTO ics_flow_icis.ICS_SW_NON_CNST_INSP
     SELECT I24.*
              from ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ICS_SW_NON_CNST_INSP I24
 ON I24.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'ComplianceMonitoringSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');


-- /ICS_CMPL_MON/ICS_SW_NON_CNST_INSP/ICS_SW_CNST_INDST_INSP
INSERT INTO ics_flow_icis.ICS_SW_CNST_INDST_INSP
     SELECT I25.*
              from ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ICS_SW_NON_CNST_INSP I24
 ON I24.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
 JOIN ICS_SW_CNST_INDST_INSP I25
 ON I25.ICS_SW_NON_CNST_INSP_ID = I24.ICS_SW_NON_CNST_INSP_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'ComplianceMonitoringSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');


-- /ICS_CMPL_MON/ICS_SW_NON_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP
INSERT INTO ics_flow_icis.ICS_SW_UNPRMT_CNST_INSP
     SELECT I26.*
              from ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ICS_SW_NON_CNST_INSP I24
 ON I24.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
 JOIN ICS_SW_UNPRMT_CNST_INSP I26
 ON I26.ICS_SW_NON_CNST_INSP_ID = I24.ICS_SW_NON_CNST_INSP_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'ComplianceMonitoringSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');


-- /ICS_CMPL_MON/ICS_SW_NON_CNST_INSP/ICS_SW_UNPRMT_CNST_INSP/ICS_PROJ_TYPE
INSERT INTO ics_flow_icis.ICS_PROJ_TYPE
     SELECT I27.*
              from ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ICS_SW_NON_CNST_INSP I24
 ON I24.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
 JOIN ICS_SW_UNPRMT_CNST_INSP I26
 ON I26.ICS_SW_NON_CNST_INSP_ID = I24.ICS_SW_NON_CNST_INSP_ID 
 JOIN ICS_PROJ_TYPE I27
 ON I27.ICS_SW_UNPRMT_CNST_INSP_ID = I26.ICS_SW_UNPRMT_CNST_INSP_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'ComplianceMonitoringSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');


-- /ICS_CMPL_MON/ICS_CAFO_INSP
INSERT INTO ics_flow_icis.ICS_CAFO_INSP
     SELECT I28.*
              from ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ICS_CAFO_INSP I28
 ON I28.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'ComplianceMonitoringSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');


-- /ICS_CMPL_MON/ICS_CAFO_INSP/ICS_CONTAINMENT
INSERT INTO ics_flow_icis.ICS_CONTAINMENT
     SELECT I29.*
              from ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ICS_CAFO_INSP I28
 ON I28.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
 JOIN ICS_CONTAINMENT I29
 ON I29.ICS_CAFO_INSP_ID = I28.ICS_CAFO_INSP_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'ComplianceMonitoringSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');


-- /ICS_CMPL_MON/ICS_CAFO_INSP/ICS_LAND_APPL_BMP
INSERT INTO ics_flow_icis.ICS_LAND_APPL_BMP
     SELECT I30.*
              from ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ICS_CAFO_INSP I28
 ON I28.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
 JOIN ICS_LAND_APPL_BMP I30
 ON I30.ICS_CAFO_INSP_ID = I28.ICS_CAFO_INSP_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'ComplianceMonitoringSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');


-- /ICS_CMPL_MON/ICS_CAFO_INSP/ICS_ANML_TYPE
INSERT INTO ics_flow_icis.ICS_ANML_TYPE
     SELECT I31.*
              from ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ICS_CAFO_INSP I28
 ON I28.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
 JOIN ICS_ANML_TYPE I31
 ON I31.ICS_CAFO_INSP_ID = I28.ICS_CAFO_INSP_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'ComplianceMonitoringSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');


-- /ICS_CMPL_MON/ICS_CAFO_INSP/ICS_MNUR_LTTR_PRCSS_WW_STOR
INSERT INTO ics_flow_icis.ICS_MNUR_LTTR_PRCSS_WW_STOR
     SELECT I32.*
              from ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ICS_CAFO_INSP I28
 ON I28.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
 JOIN ICS_MNUR_LTTR_PRCSS_WW_STOR I32
 ON I32.ICS_CAFO_INSP_ID = I28.ICS_CAFO_INSP_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'ComplianceMonitoringSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');


-- /ICS_CMPL_MON/ICS_CAFO_INSP/ICS_CAFO_INSP_VIOL_TYPE
INSERT INTO ics_flow_icis.ICS_CAFO_INSP_VIOL_TYPE
     SELECT I33.*
              from ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ICS_CAFO_INSP I28
 ON I28.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
 JOIN ICS_CAFO_INSP_VIOL_TYPE I33
 ON I33.ICS_CAFO_INSP_ID = I28.ICS_CAFO_INSP_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'ComplianceMonitoringSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');


-- /ICS_CMPL_MON/ICS_CMPL_INSP_TYPE
INSERT INTO ics_flow_icis.ICS_CMPL_INSP_TYPE
     SELECT I34.*
              from ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ICS_CMPL_INSP_TYPE I34
 ON I34.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'ComplianceMonitoringSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');


-- /ICS_CMPL_MON/ICS_CMPL_MON_ACTN_REASON
INSERT INTO ics_flow_icis.ICS_CMPL_MON_ACTN_REASON
     SELECT I35.*
              from ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ICS_CMPL_MON_ACTN_REASON I35
 ON I35.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'ComplianceMonitoringSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');


-- /ICS_CMPL_MON/ICS_CMPL_MON_AGNCY_TYPE
INSERT INTO ics_flow_icis.ICS_CMPL_MON_AGNCY_TYPE
     SELECT I36.*
              from ICS_CMPL_MON ICS_CMPL_MON 
 JOIN ICS_CMPL_MON_AGNCY_TYPE I36
 ON I36.ICS_CMPL_MON_ID = ICS_CMPL_MON.ICS_CMPL_MON_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON.KEY_HASH
       WHERE ICS_CMPL_MON.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'ComplianceMonitoringSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringSubmission');
	




-- Remove any old records for ICS_CMPL_MON_LNK
				
-- /ICS_CMPL_MON_LNK/ICS_LNK_SNGL_EVT
DELETE
  FROM ics_flow_icis.ICS_LNK_SNGL_EVT
 WHERE ICS_LNK_SNGL_EVT.ICS_CMPL_MON_LNK_ID IN
          (SELECT I3.ICS_CMPL_MON_LNK_ID
              from ics_flow_icis.ICS_CMPL_MON_LNK ICS_CMPL_MON_LNK 
 JOIN ics_flow_icis.ICS_LNK_SNGL_EVT I3
 ON I3.ICS_CMPL_MON_LNK_ID = ICS_CMPL_MON_LNK.ICS_CMPL_MON_LNK_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON_LNK.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringLinkageSubmission')
                 
                 
);

				
-- /ICS_CMPL_MON_LNK/ICS_LNK_ENFRC_ACTN
DELETE
  FROM ics_flow_icis.ICS_LNK_ENFRC_ACTN
 WHERE ICS_LNK_ENFRC_ACTN.ICS_CMPL_MON_LNK_ID IN
          (SELECT I2.ICS_CMPL_MON_LNK_ID
              from ics_flow_icis.ICS_CMPL_MON_LNK ICS_CMPL_MON_LNK 
 JOIN ics_flow_icis.ICS_LNK_ENFRC_ACTN I2
 ON I2.ICS_CMPL_MON_LNK_ID = ICS_CMPL_MON_LNK.ICS_CMPL_MON_LNK_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON_LNK.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringLinkageSubmission')
                 
                 
);

				
-- /ICS_CMPL_MON_LNK/ICS_LNK_CMPL_MON
DELETE
  FROM ics_flow_icis.ICS_LNK_CMPL_MON
 WHERE ICS_LNK_CMPL_MON.ICS_CMPL_MON_LNK_ID IN
          (SELECT I1.ICS_CMPL_MON_LNK_ID
              from ics_flow_icis.ICS_CMPL_MON_LNK ICS_CMPL_MON_LNK 
 JOIN ics_flow_icis.ICS_LNK_CMPL_MON I1
 ON I1.ICS_CMPL_MON_LNK_ID = ICS_CMPL_MON_LNK.ICS_CMPL_MON_LNK_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON_LNK.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringLinkageSubmission')
                 
                 
);

				
-- /ICS_CMPL_MON_LNK
DELETE
  FROM ics_flow_icis.ICS_CMPL_MON_LNK
 WHERE ICS_CMPL_MON_LNK.ICS_CMPL_MON_LNK_ID IN
          (SELECT ICS_CMPL_MON_LNK.ICS_CMPL_MON_LNK_ID
              from ics_flow_icis.ICS_CMPL_MON_LNK ICS_CMPL_MON_LNK 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON_LNK.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceMonitoringLinkageSubmission')
                 
                 
);

	
-- Add accepted records for ICS_CMPL_MON_LNK


-- /ICS_CMPL_MON_LNK
INSERT INTO ics_flow_icis.ICS_CMPL_MON_LNK
     SELECT ICS_CMPL_MON_LNK.*
              from ICS_CMPL_MON_LNK ICS_CMPL_MON_LNK 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON_LNK.KEY_HASH
       WHERE ICS_CMPL_MON_LNK.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'ComplianceMonitoringLinkageSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringLinkageSubmission');


-- /ICS_CMPL_MON_LNK/ICS_LNK_CMPL_MON
INSERT INTO ics_flow_icis.ICS_LNK_CMPL_MON
     SELECT I1.*
              from ICS_CMPL_MON_LNK ICS_CMPL_MON_LNK 
 JOIN ICS_LNK_CMPL_MON I1
 ON I1.ICS_CMPL_MON_LNK_ID = ICS_CMPL_MON_LNK.ICS_CMPL_MON_LNK_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON_LNK.KEY_HASH
       WHERE ICS_CMPL_MON_LNK.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'ComplianceMonitoringLinkageSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringLinkageSubmission');


-- /ICS_CMPL_MON_LNK/ICS_LNK_ENFRC_ACTN
INSERT INTO ics_flow_icis.ICS_LNK_ENFRC_ACTN
     SELECT I2.*
              from ICS_CMPL_MON_LNK ICS_CMPL_MON_LNK 
 JOIN ICS_LNK_ENFRC_ACTN I2
 ON I2.ICS_CMPL_MON_LNK_ID = ICS_CMPL_MON_LNK.ICS_CMPL_MON_LNK_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON_LNK.KEY_HASH
       WHERE ICS_CMPL_MON_LNK.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'ComplianceMonitoringLinkageSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringLinkageSubmission');


-- /ICS_CMPL_MON_LNK/ICS_LNK_SNGL_EVT
INSERT INTO ics_flow_icis.ICS_LNK_SNGL_EVT
     SELECT I3.*
              from ICS_CMPL_MON_LNK ICS_CMPL_MON_LNK 
 JOIN ICS_LNK_SNGL_EVT I3
 ON I3.ICS_CMPL_MON_LNK_ID = ICS_CMPL_MON_LNK.ICS_CMPL_MON_LNK_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_MON_LNK.KEY_HASH
       WHERE ICS_CMPL_MON_LNK.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'ComplianceMonitoringLinkageSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceMonitoringLinkageSubmission');
	




-- Remove any old records for ICS_CMPL_SCHD
				
-- /ICS_CMPL_SCHD/ICS_CMPL_SCHD_EVT
DELETE
  FROM ics_flow_icis.ICS_CMPL_SCHD_EVT
 WHERE ICS_CMPL_SCHD_EVT.ICS_CMPL_SCHD_ID IN
          (SELECT I1.ICS_CMPL_SCHD_ID
              from ics_flow_icis.ICS_CMPL_SCHD ICS_CMPL_SCHD 
 JOIN ics_flow_icis.ICS_CMPL_SCHD_EVT I1
 ON I1.ICS_CMPL_SCHD_ID = ICS_CMPL_SCHD.ICS_CMPL_SCHD_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_SCHD.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceScheduleSubmission')
                  OR ICS_CMPL_SCHD.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_CMPL_SCHD
DELETE
  FROM ics_flow_icis.ICS_CMPL_SCHD
 WHERE ICS_CMPL_SCHD.ICS_CMPL_SCHD_ID IN
          (SELECT ICS_CMPL_SCHD.ICS_CMPL_SCHD_ID
              from ics_flow_icis.ICS_CMPL_SCHD ICS_CMPL_SCHD 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_SCHD.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ComplianceScheduleSubmission')
                  OR ICS_CMPL_SCHD.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

	
-- Add accepted records for ICS_CMPL_SCHD


-- /ICS_CMPL_SCHD
INSERT INTO ics_flow_icis.ICS_CMPL_SCHD
     SELECT ICS_CMPL_SCHD.*
              from ICS_CMPL_SCHD ICS_CMPL_SCHD 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_SCHD.KEY_HASH
       WHERE ICS_CMPL_SCHD.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'ComplianceScheduleSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceScheduleSubmission');


-- /ICS_CMPL_SCHD/ICS_CMPL_SCHD_EVT
INSERT INTO ics_flow_icis.ICS_CMPL_SCHD_EVT
     SELECT I1.*
              from ICS_CMPL_SCHD ICS_CMPL_SCHD 
 JOIN ICS_CMPL_SCHD_EVT I1
 ON I1.ICS_CMPL_SCHD_ID = ICS_CMPL_SCHD.ICS_CMPL_SCHD_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CMPL_SCHD.KEY_HASH
       WHERE ICS_CMPL_SCHD.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'ComplianceScheduleSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ComplianceScheduleSubmission');
	




-- Remove any old records for ICS_COPY_MGP_LMT_SET
				
-- /ICS_COPY_MGP_LMT_SET/ICS_LMT_SET_STAT
DELETE
  FROM ics_flow_icis.ICS_LMT_SET_STAT
 WHERE ICS_LMT_SET_STAT.ICS_COPY_MGP_LMT_SET_ID IN
          (SELECT I3.ICS_COPY_MGP_LMT_SET_ID
              from ics_flow_icis.ICS_COPY_MGP_LMT_SET ICS_COPY_MGP_LMT_SET 
 JOIN ics_flow_icis.ICS_LMT_SET_STAT I3
 ON I3.ICS_COPY_MGP_LMT_SET_ID = ICS_COPY_MGP_LMT_SET.ICS_COPY_MGP_LMT_SET_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_COPY_MGP_LMT_SET.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CopyMGPLimitSetSubmission')
                 
                 
);

				
-- /ICS_COPY_MGP_LMT_SET/ICS_LMT_SET_SCHD
DELETE
  FROM ics_flow_icis.ICS_LMT_SET_SCHD
 WHERE ICS_LMT_SET_SCHD.ICS_COPY_MGP_LMT_SET_ID IN
          (SELECT I2.ICS_COPY_MGP_LMT_SET_ID
              from ics_flow_icis.ICS_COPY_MGP_LMT_SET ICS_COPY_MGP_LMT_SET 
 JOIN ics_flow_icis.ICS_LMT_SET_SCHD I2
 ON I2.ICS_COPY_MGP_LMT_SET_ID = ICS_COPY_MGP_LMT_SET.ICS_COPY_MGP_LMT_SET_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_COPY_MGP_LMT_SET.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CopyMGPLimitSetSubmission')
                 
                 
);

				
-- /ICS_COPY_MGP_LMT_SET/ICS_GEO_COORD
DELETE
  FROM ics_flow_icis.ICS_GEO_COORD
 WHERE ICS_GEO_COORD.ICS_COPY_MGP_LMT_SET_ID IN
          (SELECT I1.ICS_COPY_MGP_LMT_SET_ID
              from ics_flow_icis.ICS_COPY_MGP_LMT_SET ICS_COPY_MGP_LMT_SET 
 JOIN ics_flow_icis.ICS_GEO_COORD I1
 ON I1.ICS_COPY_MGP_LMT_SET_ID = ICS_COPY_MGP_LMT_SET.ICS_COPY_MGP_LMT_SET_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_COPY_MGP_LMT_SET.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CopyMGPLimitSetSubmission')
                 
                 
);

				
-- /ICS_COPY_MGP_LMT_SET
DELETE
  FROM ics_flow_icis.ICS_COPY_MGP_LMT_SET
 WHERE ICS_COPY_MGP_LMT_SET.ICS_COPY_MGP_LMT_SET_ID IN
          (SELECT ICS_COPY_MGP_LMT_SET.ICS_COPY_MGP_LMT_SET_ID
              from ics_flow_icis.ICS_COPY_MGP_LMT_SET ICS_COPY_MGP_LMT_SET 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_COPY_MGP_LMT_SET.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CopyMGPLimitSetSubmission')
                 
                 
);

	
-- Add accepted records for ICS_COPY_MGP_LMT_SET


-- /ICS_COPY_MGP_LMT_SET
INSERT INTO ics_flow_icis.ICS_COPY_MGP_LMT_SET
     SELECT ICS_COPY_MGP_LMT_SET.*
              from ICS_COPY_MGP_LMT_SET ICS_COPY_MGP_LMT_SET 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_COPY_MGP_LMT_SET.KEY_HASH
       WHERE ICS_COPY_MGP_LMT_SET.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'CopyMGPLimitSetSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CopyMGPLimitSetSubmission');


-- /ICS_COPY_MGP_LMT_SET/ICS_GEO_COORD
INSERT INTO ics_flow_icis.ICS_GEO_COORD
     SELECT I1.*
              from ICS_COPY_MGP_LMT_SET ICS_COPY_MGP_LMT_SET 
 JOIN ICS_GEO_COORD I1
 ON I1.ICS_COPY_MGP_LMT_SET_ID = ICS_COPY_MGP_LMT_SET.ICS_COPY_MGP_LMT_SET_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_COPY_MGP_LMT_SET.KEY_HASH
       WHERE ICS_COPY_MGP_LMT_SET.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'CopyMGPLimitSetSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CopyMGPLimitSetSubmission');


-- /ICS_COPY_MGP_LMT_SET/ICS_LMT_SET_SCHD
INSERT INTO ics_flow_icis.ICS_LMT_SET_SCHD
     SELECT I2.*
              from ICS_COPY_MGP_LMT_SET ICS_COPY_MGP_LMT_SET 
 JOIN ICS_LMT_SET_SCHD I2
 ON I2.ICS_COPY_MGP_LMT_SET_ID = ICS_COPY_MGP_LMT_SET.ICS_COPY_MGP_LMT_SET_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_COPY_MGP_LMT_SET.KEY_HASH
       WHERE ICS_COPY_MGP_LMT_SET.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'CopyMGPLimitSetSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CopyMGPLimitSetSubmission');


-- /ICS_COPY_MGP_LMT_SET/ICS_LMT_SET_STAT
INSERT INTO ics_flow_icis.ICS_LMT_SET_STAT
     SELECT I3.*
              from ICS_COPY_MGP_LMT_SET ICS_COPY_MGP_LMT_SET 
 JOIN ICS_LMT_SET_STAT I3
 ON I3.ICS_COPY_MGP_LMT_SET_ID = ICS_COPY_MGP_LMT_SET.ICS_COPY_MGP_LMT_SET_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_COPY_MGP_LMT_SET.KEY_HASH
       WHERE ICS_COPY_MGP_LMT_SET.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'CopyMGPLimitSetSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CopyMGPLimitSetSubmission');
	




-- Remove any old records for ICS_COPY_MGPMS_4_REQ
				
-- /ICS_COPY_MGPMS_4_REQ/ICS_MS_4_ACTY_IDENT
DELETE
  FROM ics_flow_icis.ICS_MS_4_ACTY_IDENT
 WHERE ICS_MS_4_ACTY_IDENT.ICS_COPY_MGPMS_4_REQ_ID IN
          (SELECT I3.ICS_COPY_MGPMS_4_REQ_ID
              from ics_flow_icis.ICS_COPY_MGPMS_4_REQ ICS_COPY_MGPMS_4_REQ 
 JOIN ics_flow_icis.ICS_MS_4_ACTY_IDENT I3
 ON I3.ICS_COPY_MGPMS_4_REQ_ID = ICS_COPY_MGPMS_4_REQ.ICS_COPY_MGPMS_4_REQ_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_COPY_MGPMS_4_REQ.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CopyMGPMS4RequirementSubmission')
                 
                 
);

				
-- /ICS_COPY_MGPMS_4_REQ/ICS_GNRL_PRMT_COVERAGE_MS_4_REQ/ICS_MS_4_REGULATED_ENTITY_IDENT
DELETE
  FROM ics_flow_icis.ICS_MS_4_REGULATED_ENTITY_IDENT
 WHERE ICS_MS_4_REGULATED_ENTITY_IDENT.ICS_GNRL_PRMT_COVERAGE_MS_4_REQ_ID IN
          (SELECT I2.ICS_GNRL_PRMT_COVERAGE_MS_4_REQ_ID
              from ics_flow_icis.ICS_COPY_MGPMS_4_REQ ICS_COPY_MGPMS_4_REQ 
 JOIN ics_flow_icis.ICS_GNRL_PRMT_COVERAGE_MS_4_REQ I1
 ON I1.ICS_COPY_MGPMS_4_REQ_ID = ICS_COPY_MGPMS_4_REQ.ICS_COPY_MGPMS_4_REQ_ID 
 JOIN ics_flow_icis.ICS_MS_4_REGULATED_ENTITY_IDENT I2
 ON I2.ICS_GNRL_PRMT_COVERAGE_MS_4_REQ_ID = I1.ICS_GNRL_PRMT_COVERAGE_MS_4_REQ_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_COPY_MGPMS_4_REQ.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CopyMGPMS4RequirementSubmission')
                 
                 
);

				
-- /ICS_COPY_MGPMS_4_REQ/ICS_GNRL_PRMT_COVERAGE_MS_4_REQ
DELETE
  FROM ics_flow_icis.ICS_GNRL_PRMT_COVERAGE_MS_4_REQ
 WHERE ICS_GNRL_PRMT_COVERAGE_MS_4_REQ.ICS_COPY_MGPMS_4_REQ_ID IN
          (SELECT I1.ICS_COPY_MGPMS_4_REQ_ID
              from ics_flow_icis.ICS_COPY_MGPMS_4_REQ ICS_COPY_MGPMS_4_REQ 
 JOIN ics_flow_icis.ICS_GNRL_PRMT_COVERAGE_MS_4_REQ I1
 ON I1.ICS_COPY_MGPMS_4_REQ_ID = ICS_COPY_MGPMS_4_REQ.ICS_COPY_MGPMS_4_REQ_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_COPY_MGPMS_4_REQ.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CopyMGPMS4RequirementSubmission')
                 
                 
);

				
-- /ICS_COPY_MGPMS_4_REQ
DELETE
  FROM ics_flow_icis.ICS_COPY_MGPMS_4_REQ
 WHERE ICS_COPY_MGPMS_4_REQ.ICS_COPY_MGPMS_4_REQ_ID IN
          (SELECT ICS_COPY_MGPMS_4_REQ.ICS_COPY_MGPMS_4_REQ_ID
              from ics_flow_icis.ICS_COPY_MGPMS_4_REQ ICS_COPY_MGPMS_4_REQ 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_COPY_MGPMS_4_REQ.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CopyMGPMS4RequirementSubmission')
                 
                 
);

	
-- Add accepted records for ICS_COPY_MGPMS_4_REQ


-- /ICS_COPY_MGPMS_4_REQ
INSERT INTO ics_flow_icis.ICS_COPY_MGPMS_4_REQ
     SELECT ICS_COPY_MGPMS_4_REQ.*
              from ICS_COPY_MGPMS_4_REQ ICS_COPY_MGPMS_4_REQ 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_COPY_MGPMS_4_REQ.KEY_HASH
       WHERE ICS_COPY_MGPMS_4_REQ.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'CopyMGPMS4RequirementSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CopyMGPMS4RequirementSubmission');


-- /ICS_COPY_MGPMS_4_REQ/ICS_GNRL_PRMT_COVERAGE_MS_4_REQ
INSERT INTO ics_flow_icis.ICS_GNRL_PRMT_COVERAGE_MS_4_REQ
     SELECT I1.*
              from ICS_COPY_MGPMS_4_REQ ICS_COPY_MGPMS_4_REQ 
 JOIN ICS_GNRL_PRMT_COVERAGE_MS_4_REQ I1
 ON I1.ICS_COPY_MGPMS_4_REQ_ID = ICS_COPY_MGPMS_4_REQ.ICS_COPY_MGPMS_4_REQ_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_COPY_MGPMS_4_REQ.KEY_HASH
       WHERE ICS_COPY_MGPMS_4_REQ.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'CopyMGPMS4RequirementSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CopyMGPMS4RequirementSubmission');


-- /ICS_COPY_MGPMS_4_REQ/ICS_GNRL_PRMT_COVERAGE_MS_4_REQ/ICS_MS_4_REGULATED_ENTITY_IDENT
INSERT INTO ics_flow_icis.ICS_MS_4_REGULATED_ENTITY_IDENT
     SELECT I2.*
              from ICS_COPY_MGPMS_4_REQ ICS_COPY_MGPMS_4_REQ 
 JOIN ICS_GNRL_PRMT_COVERAGE_MS_4_REQ I1
 ON I1.ICS_COPY_MGPMS_4_REQ_ID = ICS_COPY_MGPMS_4_REQ.ICS_COPY_MGPMS_4_REQ_ID 
 JOIN ICS_MS_4_REGULATED_ENTITY_IDENT I2
 ON I2.ICS_GNRL_PRMT_COVERAGE_MS_4_REQ_ID = I1.ICS_GNRL_PRMT_COVERAGE_MS_4_REQ_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_COPY_MGPMS_4_REQ.KEY_HASH
       WHERE ICS_COPY_MGPMS_4_REQ.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'CopyMGPMS4RequirementSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CopyMGPMS4RequirementSubmission');


-- /ICS_COPY_MGPMS_4_REQ/ICS_MS_4_ACTY_IDENT
INSERT INTO ics_flow_icis.ICS_MS_4_ACTY_IDENT
     SELECT I3.*
              from ICS_COPY_MGPMS_4_REQ ICS_COPY_MGPMS_4_REQ 
 JOIN ICS_MS_4_ACTY_IDENT I3
 ON I3.ICS_COPY_MGPMS_4_REQ_ID = ICS_COPY_MGPMS_4_REQ.ICS_COPY_MGPMS_4_REQ_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_COPY_MGPMS_4_REQ.KEY_HASH
       WHERE ICS_COPY_MGPMS_4_REQ.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'CopyMGPMS4RequirementSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CopyMGPMS4RequirementSubmission');
	




-- Remove any old records for ICS_CSO_LONG_TERM_CONTROL_PLAN
				
-- /ICS_CSO_LONG_TERM_CONTROL_PLAN/ICS_LTCP_SUMM
DELETE
  FROM ics_flow_icis.ICS_LTCP_SUMM
 WHERE ICS_LTCP_SUMM.ICS_CSO_LONG_TERM_CONTROL_PLAN_ID IN
          (SELECT I4.ICS_CSO_LONG_TERM_CONTROL_PLAN_ID
              from ics_flow_icis.ICS_CSO_LONG_TERM_CONTROL_PLAN ICS_CSO_LONG_TERM_CONTROL_PLAN 
 JOIN ics_flow_icis.ICS_LTCP_SUMM I4
 ON I4.ICS_CSO_LONG_TERM_CONTROL_PLAN_ID = ICS_CSO_LONG_TERM_CONTROL_PLAN.ICS_CSO_LONG_TERM_CONTROL_PLAN_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CSO_LONG_TERM_CONTROL_PLAN.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CSOLongTermControlPlanSubmission')
                 
                 
);

				
-- /ICS_CSO_LONG_TERM_CONTROL_PLAN/ICS_LTCP_MOST_RECENT_REVISION_DETAIL
DELETE
  FROM ics_flow_icis.ICS_LTCP_MOST_RECENT_REVISION_DETAIL
 WHERE ICS_LTCP_MOST_RECENT_REVISION_DETAIL.ICS_CSO_LONG_TERM_CONTROL_PLAN_ID IN
          (SELECT I3.ICS_CSO_LONG_TERM_CONTROL_PLAN_ID
              from ics_flow_icis.ICS_CSO_LONG_TERM_CONTROL_PLAN ICS_CSO_LONG_TERM_CONTROL_PLAN 
 JOIN ics_flow_icis.ICS_LTCP_MOST_RECENT_REVISION_DETAIL I3
 ON I3.ICS_CSO_LONG_TERM_CONTROL_PLAN_ID = ICS_CSO_LONG_TERM_CONTROL_PLAN.ICS_CSO_LONG_TERM_CONTROL_PLAN_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CSO_LONG_TERM_CONTROL_PLAN.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CSOLongTermControlPlanSubmission')
                 
                 
);

				
-- /ICS_CSO_LONG_TERM_CONTROL_PLAN/ICS_LTCP_ENFORCEABLE_MECH_DETAIL
DELETE
  FROM ics_flow_icis.ICS_LTCP_ENFORCEABLE_MECH_DETAIL
 WHERE ICS_LTCP_ENFORCEABLE_MECH_DETAIL.ICS_CSO_LONG_TERM_CONTROL_PLAN_ID IN
          (SELECT I2.ICS_CSO_LONG_TERM_CONTROL_PLAN_ID
              from ics_flow_icis.ICS_CSO_LONG_TERM_CONTROL_PLAN ICS_CSO_LONG_TERM_CONTROL_PLAN 
 JOIN ics_flow_icis.ICS_LTCP_ENFORCEABLE_MECH_DETAIL I2
 ON I2.ICS_CSO_LONG_TERM_CONTROL_PLAN_ID = ICS_CSO_LONG_TERM_CONTROL_PLAN.ICS_CSO_LONG_TERM_CONTROL_PLAN_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CSO_LONG_TERM_CONTROL_PLAN.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CSOLongTermControlPlanSubmission')
                 
                 
);

				
-- /ICS_CSO_LONG_TERM_CONTROL_PLAN/ICS_CSO_CONTROL_MEAS_DETAIL
DELETE
  FROM ics_flow_icis.ICS_CSO_CONTROL_MEAS_DETAIL
 WHERE ICS_CSO_CONTROL_MEAS_DETAIL.ICS_CSO_LONG_TERM_CONTROL_PLAN_ID IN
          (SELECT I1.ICS_CSO_LONG_TERM_CONTROL_PLAN_ID
              from ics_flow_icis.ICS_CSO_LONG_TERM_CONTROL_PLAN ICS_CSO_LONG_TERM_CONTROL_PLAN 
 JOIN ics_flow_icis.ICS_CSO_CONTROL_MEAS_DETAIL I1
 ON I1.ICS_CSO_LONG_TERM_CONTROL_PLAN_ID = ICS_CSO_LONG_TERM_CONTROL_PLAN.ICS_CSO_LONG_TERM_CONTROL_PLAN_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CSO_LONG_TERM_CONTROL_PLAN.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CSOLongTermControlPlanSubmission')
                 
                 
);

				
-- /ICS_CSO_LONG_TERM_CONTROL_PLAN
DELETE
  FROM ics_flow_icis.ICS_CSO_LONG_TERM_CONTROL_PLAN
 WHERE ICS_CSO_LONG_TERM_CONTROL_PLAN.ICS_CSO_LONG_TERM_CONTROL_PLAN_ID IN
          (SELECT ICS_CSO_LONG_TERM_CONTROL_PLAN.ICS_CSO_LONG_TERM_CONTROL_PLAN_ID
              from ics_flow_icis.ICS_CSO_LONG_TERM_CONTROL_PLAN ICS_CSO_LONG_TERM_CONTROL_PLAN 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CSO_LONG_TERM_CONTROL_PLAN.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CSOLongTermControlPlanSubmission')
                 
                 
);

	
-- Add accepted records for ICS_CSO_LONG_TERM_CONTROL_PLAN


-- /ICS_CSO_LONG_TERM_CONTROL_PLAN
INSERT INTO ics_flow_icis.ICS_CSO_LONG_TERM_CONTROL_PLAN
     SELECT ICS_CSO_LONG_TERM_CONTROL_PLAN.*
              from ICS_CSO_LONG_TERM_CONTROL_PLAN ICS_CSO_LONG_TERM_CONTROL_PLAN 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CSO_LONG_TERM_CONTROL_PLAN.KEY_HASH
       WHERE ICS_CSO_LONG_TERM_CONTROL_PLAN.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'CSOLongTermControlPlanSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CSOLongTermControlPlanSubmission');


-- /ICS_CSO_LONG_TERM_CONTROL_PLAN/ICS_CSO_CONTROL_MEAS_DETAIL
INSERT INTO ics_flow_icis.ICS_CSO_CONTROL_MEAS_DETAIL
     SELECT I1.*
              from ICS_CSO_LONG_TERM_CONTROL_PLAN ICS_CSO_LONG_TERM_CONTROL_PLAN 
 JOIN ICS_CSO_CONTROL_MEAS_DETAIL I1
 ON I1.ICS_CSO_LONG_TERM_CONTROL_PLAN_ID = ICS_CSO_LONG_TERM_CONTROL_PLAN.ICS_CSO_LONG_TERM_CONTROL_PLAN_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CSO_LONG_TERM_CONTROL_PLAN.KEY_HASH
       WHERE ICS_CSO_LONG_TERM_CONTROL_PLAN.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'CSOLongTermControlPlanSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CSOLongTermControlPlanSubmission');


-- /ICS_CSO_LONG_TERM_CONTROL_PLAN/ICS_LTCP_ENFORCEABLE_MECH_DETAIL
INSERT INTO ics_flow_icis.ICS_LTCP_ENFORCEABLE_MECH_DETAIL
     SELECT I2.*
              from ICS_CSO_LONG_TERM_CONTROL_PLAN ICS_CSO_LONG_TERM_CONTROL_PLAN 
 JOIN ICS_LTCP_ENFORCEABLE_MECH_DETAIL I2
 ON I2.ICS_CSO_LONG_TERM_CONTROL_PLAN_ID = ICS_CSO_LONG_TERM_CONTROL_PLAN.ICS_CSO_LONG_TERM_CONTROL_PLAN_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CSO_LONG_TERM_CONTROL_PLAN.KEY_HASH
       WHERE ICS_CSO_LONG_TERM_CONTROL_PLAN.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'CSOLongTermControlPlanSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CSOLongTermControlPlanSubmission');


-- /ICS_CSO_LONG_TERM_CONTROL_PLAN/ICS_LTCP_MOST_RECENT_REVISION_DETAIL
INSERT INTO ics_flow_icis.ICS_LTCP_MOST_RECENT_REVISION_DETAIL
     SELECT I3.*
              from ICS_CSO_LONG_TERM_CONTROL_PLAN ICS_CSO_LONG_TERM_CONTROL_PLAN 
 JOIN ICS_LTCP_MOST_RECENT_REVISION_DETAIL I3
 ON I3.ICS_CSO_LONG_TERM_CONTROL_PLAN_ID = ICS_CSO_LONG_TERM_CONTROL_PLAN.ICS_CSO_LONG_TERM_CONTROL_PLAN_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CSO_LONG_TERM_CONTROL_PLAN.KEY_HASH
       WHERE ICS_CSO_LONG_TERM_CONTROL_PLAN.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'CSOLongTermControlPlanSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CSOLongTermControlPlanSubmission');


-- /ICS_CSO_LONG_TERM_CONTROL_PLAN/ICS_LTCP_SUMM
INSERT INTO ics_flow_icis.ICS_LTCP_SUMM
     SELECT I4.*
              from ICS_CSO_LONG_TERM_CONTROL_PLAN ICS_CSO_LONG_TERM_CONTROL_PLAN 
 JOIN ICS_LTCP_SUMM I4
 ON I4.ICS_CSO_LONG_TERM_CONTROL_PLAN_ID = ICS_CSO_LONG_TERM_CONTROL_PLAN.ICS_CSO_LONG_TERM_CONTROL_PLAN_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CSO_LONG_TERM_CONTROL_PLAN.KEY_HASH
       WHERE ICS_CSO_LONG_TERM_CONTROL_PLAN.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'CSOLongTermControlPlanSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CSOLongTermControlPlanSubmission');
	




-- Remove any old records for ICS_CWA_316B_PROG_REP
				
-- /ICS_CWA_316B_PROG_REP/ICS_CWA_316B_TAKE_INFO
DELETE
  FROM ics_flow_icis.ICS_CWA_316B_TAKE_INFO
 WHERE ICS_CWA_316B_TAKE_INFO.ICS_CWA_316B_PROG_REP_ID IN
          (SELECT I1.ICS_CWA_316B_PROG_REP_ID
              from ics_flow_icis.ICS_CWA_316B_PROG_REP ICS_CWA_316B_PROG_REP 
 JOIN ics_flow_icis.ICS_CWA_316B_TAKE_INFO I1
 ON I1.ICS_CWA_316B_PROG_REP_ID = ICS_CWA_316B_PROG_REP.ICS_CWA_316B_PROG_REP_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CWA_316B_PROG_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CWA316bProgramReportSubmission')
                 
                 
);

				
-- /ICS_CWA_316B_PROG_REP
DELETE
  FROM ics_flow_icis.ICS_CWA_316B_PROG_REP
 WHERE ICS_CWA_316B_PROG_REP.ICS_CWA_316B_PROG_REP_ID IN
          (SELECT ICS_CWA_316B_PROG_REP.ICS_CWA_316B_PROG_REP_ID
              from ics_flow_icis.ICS_CWA_316B_PROG_REP ICS_CWA_316B_PROG_REP 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CWA_316B_PROG_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'CWA316bProgramReportSubmission')
                 
                 
);

	
-- Add accepted records for ICS_CWA_316B_PROG_REP


-- /ICS_CWA_316B_PROG_REP
INSERT INTO ics_flow_icis.ICS_CWA_316B_PROG_REP
     SELECT ICS_CWA_316B_PROG_REP.*
              from ICS_CWA_316B_PROG_REP ICS_CWA_316B_PROG_REP 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CWA_316B_PROG_REP.KEY_HASH
       WHERE ICS_CWA_316B_PROG_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'CWA316bProgramReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CWA316bProgramReportSubmission');


-- /ICS_CWA_316B_PROG_REP/ICS_CWA_316B_TAKE_INFO
INSERT INTO ics_flow_icis.ICS_CWA_316B_TAKE_INFO
     SELECT I1.*
              from ICS_CWA_316B_PROG_REP ICS_CWA_316B_PROG_REP 
 JOIN ICS_CWA_316B_TAKE_INFO I1
 ON I1.ICS_CWA_316B_PROG_REP_ID = ICS_CWA_316B_PROG_REP.ICS_CWA_316B_PROG_REP_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_CWA_316B_PROG_REP.KEY_HASH
       WHERE ICS_CWA_316B_PROG_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'CWA316bProgramReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'CWA316bProgramReportSubmission');
	




-- Remove any old records for ICS_DSCH_MON_REP
				
-- /ICS_DSCH_MON_REP/ICS_CO_DSPL_SITE
DELETE
  FROM ics_flow_icis.ICS_CO_DSPL_SITE
 WHERE ICS_CO_DSPL_SITE.ICS_DSCH_MON_REP_ID IN
          (SELECT I8.ICS_DSCH_MON_REP_ID
              from ics_flow_icis.ICS_DSCH_MON_REP ICS_DSCH_MON_REP 
 JOIN ics_flow_icis.ICS_CO_DSPL_SITE I8
 ON I8.ICS_DSCH_MON_REP_ID = ICS_DSCH_MON_REP.ICS_DSCH_MON_REP_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_DSCH_MON_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'DischargeMonitoringReportSubmission')
                 
                 
);

				
-- /ICS_DSCH_MON_REP/ICS_SURF_DSPL_SITE
DELETE
  FROM ics_flow_icis.ICS_SURF_DSPL_SITE
 WHERE ICS_SURF_DSPL_SITE.ICS_DSCH_MON_REP_ID IN
          (SELECT I7.ICS_DSCH_MON_REP_ID
              from ics_flow_icis.ICS_DSCH_MON_REP ICS_DSCH_MON_REP 
 JOIN ics_flow_icis.ICS_SURF_DSPL_SITE I7
 ON I7.ICS_DSCH_MON_REP_ID = ICS_DSCH_MON_REP.ICS_DSCH_MON_REP_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_DSCH_MON_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'DischargeMonitoringReportSubmission')
                 
                 
);

				
-- /ICS_DSCH_MON_REP/ICS_LAND_APPL_SITE/ICS_CROP_TYPES_PLANTED
DELETE
  FROM ics_flow_icis.ICS_CROP_TYPES_PLANTED
 WHERE ICS_CROP_TYPES_PLANTED.ICS_LAND_APPL_SITE_ID IN
          (SELECT I6.ICS_LAND_APPL_SITE_ID
              from ics_flow_icis.ICS_DSCH_MON_REP ICS_DSCH_MON_REP 
 JOIN ics_flow_icis.ICS_LAND_APPL_SITE I4
 ON I4.ICS_DSCH_MON_REP_ID = ICS_DSCH_MON_REP.ICS_DSCH_MON_REP_ID 
 JOIN ics_flow_icis.ICS_CROP_TYPES_PLANTED I6
 ON I6.ICS_LAND_APPL_SITE_ID = I4.ICS_LAND_APPL_SITE_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_DSCH_MON_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'DischargeMonitoringReportSubmission')
                 
                 
);

				
-- /ICS_DSCH_MON_REP/ICS_LAND_APPL_SITE/ICS_CROP_TYPES_HARVESTED
DELETE
  FROM ics_flow_icis.ICS_CROP_TYPES_HARVESTED
 WHERE ICS_CROP_TYPES_HARVESTED.ICS_LAND_APPL_SITE_ID IN
          (SELECT I5.ICS_LAND_APPL_SITE_ID
              from ics_flow_icis.ICS_DSCH_MON_REP ICS_DSCH_MON_REP 
 JOIN ics_flow_icis.ICS_LAND_APPL_SITE I4
 ON I4.ICS_DSCH_MON_REP_ID = ICS_DSCH_MON_REP.ICS_DSCH_MON_REP_ID 
 JOIN ics_flow_icis.ICS_CROP_TYPES_HARVESTED I5
 ON I5.ICS_LAND_APPL_SITE_ID = I4.ICS_LAND_APPL_SITE_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_DSCH_MON_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'DischargeMonitoringReportSubmission')
                 
                 
);

				
-- /ICS_DSCH_MON_REP/ICS_LAND_APPL_SITE
DELETE
  FROM ics_flow_icis.ICS_LAND_APPL_SITE
 WHERE ICS_LAND_APPL_SITE.ICS_DSCH_MON_REP_ID IN
          (SELECT I4.ICS_DSCH_MON_REP_ID
              from ics_flow_icis.ICS_DSCH_MON_REP ICS_DSCH_MON_REP 
 JOIN ics_flow_icis.ICS_LAND_APPL_SITE I4
 ON I4.ICS_DSCH_MON_REP_ID = ICS_DSCH_MON_REP.ICS_DSCH_MON_REP_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_DSCH_MON_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'DischargeMonitoringReportSubmission')
                 
                 
);

				
-- /ICS_DSCH_MON_REP/ICS_INCIN
DELETE
  FROM ics_flow_icis.ICS_INCIN
 WHERE ICS_INCIN.ICS_DSCH_MON_REP_ID IN
          (SELECT I3.ICS_DSCH_MON_REP_ID
              from ics_flow_icis.ICS_DSCH_MON_REP ICS_DSCH_MON_REP 
 JOIN ics_flow_icis.ICS_INCIN I3
 ON I3.ICS_DSCH_MON_REP_ID = ICS_DSCH_MON_REP.ICS_DSCH_MON_REP_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_DSCH_MON_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'DischargeMonitoringReportSubmission')
                 
                 
);

				
-- /ICS_DSCH_MON_REP/ICS_REP_PARAM/ICS_NUM_REP
DELETE
  FROM ics_flow_icis.ICS_NUM_REP
 WHERE ICS_NUM_REP.ICS_REP_PARAM_ID IN
          (SELECT I2.ICS_REP_PARAM_ID
              from ics_flow_icis.ICS_DSCH_MON_REP ICS_DSCH_MON_REP 
 JOIN ics_flow_icis.ICS_REP_PARAM I1
 ON I1.ICS_DSCH_MON_REP_ID = ICS_DSCH_MON_REP.ICS_DSCH_MON_REP_ID 
 JOIN ics_flow_icis.ICS_NUM_REP I2
 ON I2.ICS_REP_PARAM_ID = I1.ICS_REP_PARAM_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_DSCH_MON_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'DischargeMonitoringReportSubmission')
                 
                 
);

				
-- /ICS_DSCH_MON_REP/ICS_REP_PARAM
DELETE
  FROM ics_flow_icis.ICS_REP_PARAM
 WHERE ICS_REP_PARAM.ICS_DSCH_MON_REP_ID IN
          (SELECT I1.ICS_DSCH_MON_REP_ID
              from ics_flow_icis.ICS_DSCH_MON_REP ICS_DSCH_MON_REP 
 JOIN ics_flow_icis.ICS_REP_PARAM I1
 ON I1.ICS_DSCH_MON_REP_ID = ICS_DSCH_MON_REP.ICS_DSCH_MON_REP_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_DSCH_MON_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'DischargeMonitoringReportSubmission')
                 
                 
);

				
-- /ICS_DSCH_MON_REP
DELETE
  FROM ics_flow_icis.ICS_DSCH_MON_REP
 WHERE ICS_DSCH_MON_REP.ICS_DSCH_MON_REP_ID IN
          (SELECT ICS_DSCH_MON_REP.ICS_DSCH_MON_REP_ID
              from ics_flow_icis.ICS_DSCH_MON_REP ICS_DSCH_MON_REP 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_DSCH_MON_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'DischargeMonitoringReportSubmission')
                 
                 
);

	
-- Add accepted records for ICS_DSCH_MON_REP


-- /ICS_DSCH_MON_REP
INSERT INTO ics_flow_icis.ICS_DSCH_MON_REP
     SELECT ICS_DSCH_MON_REP.*
              from ICS_DSCH_MON_REP ICS_DSCH_MON_REP 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_DSCH_MON_REP.KEY_HASH
       WHERE ICS_DSCH_MON_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'DischargeMonitoringReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'DischargeMonitoringReportSubmission');


-- /ICS_DSCH_MON_REP/ICS_REP_PARAM
INSERT INTO ics_flow_icis.ICS_REP_PARAM
     SELECT I1.*
              from ICS_DSCH_MON_REP ICS_DSCH_MON_REP 
 JOIN ICS_REP_PARAM I1
 ON I1.ICS_DSCH_MON_REP_ID = ICS_DSCH_MON_REP.ICS_DSCH_MON_REP_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_DSCH_MON_REP.KEY_HASH
       WHERE ICS_DSCH_MON_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'DischargeMonitoringReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'DischargeMonitoringReportSubmission');


-- /ICS_DSCH_MON_REP/ICS_REP_PARAM/ICS_NUM_REP
INSERT INTO ics_flow_icis.ICS_NUM_REP
     SELECT I2.*
              from ICS_DSCH_MON_REP ICS_DSCH_MON_REP 
 JOIN ICS_REP_PARAM I1
 ON I1.ICS_DSCH_MON_REP_ID = ICS_DSCH_MON_REP.ICS_DSCH_MON_REP_ID 
 JOIN ICS_NUM_REP I2
 ON I2.ICS_REP_PARAM_ID = I1.ICS_REP_PARAM_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_DSCH_MON_REP.KEY_HASH
       WHERE ICS_DSCH_MON_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'DischargeMonitoringReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'DischargeMonitoringReportSubmission');


-- /ICS_DSCH_MON_REP/ICS_INCIN
INSERT INTO ics_flow_icis.ICS_INCIN
     SELECT I3.*
              from ICS_DSCH_MON_REP ICS_DSCH_MON_REP 
 JOIN ICS_INCIN I3
 ON I3.ICS_DSCH_MON_REP_ID = ICS_DSCH_MON_REP.ICS_DSCH_MON_REP_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_DSCH_MON_REP.KEY_HASH
       WHERE ICS_DSCH_MON_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'DischargeMonitoringReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'DischargeMonitoringReportSubmission');


-- /ICS_DSCH_MON_REP/ICS_LAND_APPL_SITE
INSERT INTO ics_flow_icis.ICS_LAND_APPL_SITE
     SELECT I4.*
              from ICS_DSCH_MON_REP ICS_DSCH_MON_REP 
 JOIN ICS_LAND_APPL_SITE I4
 ON I4.ICS_DSCH_MON_REP_ID = ICS_DSCH_MON_REP.ICS_DSCH_MON_REP_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_DSCH_MON_REP.KEY_HASH
       WHERE ICS_DSCH_MON_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'DischargeMonitoringReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'DischargeMonitoringReportSubmission');


-- /ICS_DSCH_MON_REP/ICS_LAND_APPL_SITE/ICS_CROP_TYPES_HARVESTED
INSERT INTO ics_flow_icis.ICS_CROP_TYPES_HARVESTED
     SELECT I5.*
              from ICS_DSCH_MON_REP ICS_DSCH_MON_REP 
 JOIN ICS_LAND_APPL_SITE I4
 ON I4.ICS_DSCH_MON_REP_ID = ICS_DSCH_MON_REP.ICS_DSCH_MON_REP_ID 
 JOIN ICS_CROP_TYPES_HARVESTED I5
 ON I5.ICS_LAND_APPL_SITE_ID = I4.ICS_LAND_APPL_SITE_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_DSCH_MON_REP.KEY_HASH
       WHERE ICS_DSCH_MON_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'DischargeMonitoringReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'DischargeMonitoringReportSubmission');


-- /ICS_DSCH_MON_REP/ICS_LAND_APPL_SITE/ICS_CROP_TYPES_PLANTED
INSERT INTO ics_flow_icis.ICS_CROP_TYPES_PLANTED
     SELECT I6.*
              from ICS_DSCH_MON_REP ICS_DSCH_MON_REP 
 JOIN ICS_LAND_APPL_SITE I4
 ON I4.ICS_DSCH_MON_REP_ID = ICS_DSCH_MON_REP.ICS_DSCH_MON_REP_ID 
 JOIN ICS_CROP_TYPES_PLANTED I6
 ON I6.ICS_LAND_APPL_SITE_ID = I4.ICS_LAND_APPL_SITE_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_DSCH_MON_REP.KEY_HASH
       WHERE ICS_DSCH_MON_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'DischargeMonitoringReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'DischargeMonitoringReportSubmission');


-- /ICS_DSCH_MON_REP/ICS_SURF_DSPL_SITE
INSERT INTO ics_flow_icis.ICS_SURF_DSPL_SITE
     SELECT I7.*
              from ICS_DSCH_MON_REP ICS_DSCH_MON_REP 
 JOIN ICS_SURF_DSPL_SITE I7
 ON I7.ICS_DSCH_MON_REP_ID = ICS_DSCH_MON_REP.ICS_DSCH_MON_REP_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_DSCH_MON_REP.KEY_HASH
       WHERE ICS_DSCH_MON_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'DischargeMonitoringReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'DischargeMonitoringReportSubmission');


-- /ICS_DSCH_MON_REP/ICS_CO_DSPL_SITE
INSERT INTO ics_flow_icis.ICS_CO_DSPL_SITE
     SELECT I8.*
              from ICS_DSCH_MON_REP ICS_DSCH_MON_REP 
 JOIN ICS_CO_DSPL_SITE I8
 ON I8.ICS_DSCH_MON_REP_ID = ICS_DSCH_MON_REP.ICS_DSCH_MON_REP_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_DSCH_MON_REP.KEY_HASH
       WHERE ICS_DSCH_MON_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'DischargeMonitoringReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'DischargeMonitoringReportSubmission');
	




-- Remove any old records for ICS_DMR_VIOL
				
-- /ICS_DMR_VIOL
DELETE
  FROM ics_flow_icis.ICS_DMR_VIOL
 WHERE ICS_DMR_VIOL.ICS_DMR_VIOL_ID IN
          (SELECT ICS_DMR_VIOL.ICS_DMR_VIOL_ID
              from ics_flow_icis.ICS_DMR_VIOL ICS_DMR_VIOL 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_DMR_VIOL.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'DMRViolationSubmission')
                  OR ICS_DMR_VIOL.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

	
-- Add accepted records for ICS_DMR_VIOL


-- /ICS_DMR_VIOL
INSERT INTO ics_flow_icis.ICS_DMR_VIOL
     SELECT ICS_DMR_VIOL.*
              from ICS_DMR_VIOL ICS_DMR_VIOL 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_DMR_VIOL.KEY_HASH
       WHERE ICS_DMR_VIOL.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'DMRViolationSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'DMRViolationSubmission');
	




-- Remove any old records for ICS_EFFLU_TRADE_PRTNER
				
-- /ICS_EFFLU_TRADE_PRTNER/ICS_EFFLU_TRADE_PRTNER_ADDR/ICS_TELEPH
DELETE
  FROM ics_flow_icis.ICS_TELEPH
 WHERE ICS_TELEPH.ICS_EFFLU_TRADE_PRTNER_ADDR_ID IN
          (SELECT I2.ICS_EFFLU_TRADE_PRTNER_ADDR_ID
              from ics_flow_icis.ICS_EFFLU_TRADE_PRTNER ICS_EFFLU_TRADE_PRTNER 
 JOIN ics_flow_icis.ICS_EFFLU_TRADE_PRTNER_ADDR I1
 ON I1.ICS_EFFLU_TRADE_PRTNER_ID = ICS_EFFLU_TRADE_PRTNER.ICS_EFFLU_TRADE_PRTNER_ID 
 JOIN ics_flow_icis.ICS_TELEPH I2
 ON I2.ICS_EFFLU_TRADE_PRTNER_ADDR_ID = I1.ICS_EFFLU_TRADE_PRTNER_ADDR_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_EFFLU_TRADE_PRTNER.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'EffluentTradePartnerSubmission')
                  OR ICS_EFFLU_TRADE_PRTNER.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_EFFLU_TRADE_PRTNER/ICS_EFFLU_TRADE_PRTNER_ADDR
DELETE
  FROM ics_flow_icis.ICS_EFFLU_TRADE_PRTNER_ADDR
 WHERE ICS_EFFLU_TRADE_PRTNER_ADDR.ICS_EFFLU_TRADE_PRTNER_ID IN
          (SELECT I1.ICS_EFFLU_TRADE_PRTNER_ID
              from ics_flow_icis.ICS_EFFLU_TRADE_PRTNER ICS_EFFLU_TRADE_PRTNER 
 JOIN ics_flow_icis.ICS_EFFLU_TRADE_PRTNER_ADDR I1
 ON I1.ICS_EFFLU_TRADE_PRTNER_ID = ICS_EFFLU_TRADE_PRTNER.ICS_EFFLU_TRADE_PRTNER_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_EFFLU_TRADE_PRTNER.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'EffluentTradePartnerSubmission')
                  OR ICS_EFFLU_TRADE_PRTNER.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_EFFLU_TRADE_PRTNER
DELETE
  FROM ics_flow_icis.ICS_EFFLU_TRADE_PRTNER
 WHERE ICS_EFFLU_TRADE_PRTNER.ICS_EFFLU_TRADE_PRTNER_ID IN
          (SELECT ICS_EFFLU_TRADE_PRTNER.ICS_EFFLU_TRADE_PRTNER_ID
              from ics_flow_icis.ICS_EFFLU_TRADE_PRTNER ICS_EFFLU_TRADE_PRTNER 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_EFFLU_TRADE_PRTNER.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'EffluentTradePartnerSubmission')
                  OR ICS_EFFLU_TRADE_PRTNER.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

	
-- Add accepted records for ICS_EFFLU_TRADE_PRTNER


-- /ICS_EFFLU_TRADE_PRTNER
INSERT INTO ics_flow_icis.ICS_EFFLU_TRADE_PRTNER
     SELECT ICS_EFFLU_TRADE_PRTNER.*
              from ICS_EFFLU_TRADE_PRTNER ICS_EFFLU_TRADE_PRTNER 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_EFFLU_TRADE_PRTNER.KEY_HASH
       WHERE ICS_EFFLU_TRADE_PRTNER.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'EffluentTradePartnerSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'EffluentTradePartnerSubmission');


-- /ICS_EFFLU_TRADE_PRTNER/ICS_EFFLU_TRADE_PRTNER_ADDR
INSERT INTO ics_flow_icis.ICS_EFFLU_TRADE_PRTNER_ADDR
     SELECT I1.*
              from ICS_EFFLU_TRADE_PRTNER ICS_EFFLU_TRADE_PRTNER 
 JOIN ICS_EFFLU_TRADE_PRTNER_ADDR I1
 ON I1.ICS_EFFLU_TRADE_PRTNER_ID = ICS_EFFLU_TRADE_PRTNER.ICS_EFFLU_TRADE_PRTNER_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_EFFLU_TRADE_PRTNER.KEY_HASH
       WHERE ICS_EFFLU_TRADE_PRTNER.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'EffluentTradePartnerSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'EffluentTradePartnerSubmission');


-- /ICS_EFFLU_TRADE_PRTNER/ICS_EFFLU_TRADE_PRTNER_ADDR/ICS_TELEPH
INSERT INTO ics_flow_icis.ICS_TELEPH
     SELECT I2.*
              from ICS_EFFLU_TRADE_PRTNER ICS_EFFLU_TRADE_PRTNER 
 JOIN ICS_EFFLU_TRADE_PRTNER_ADDR I1
 ON I1.ICS_EFFLU_TRADE_PRTNER_ID = ICS_EFFLU_TRADE_PRTNER.ICS_EFFLU_TRADE_PRTNER_ID 
 JOIN ICS_TELEPH I2
 ON I2.ICS_EFFLU_TRADE_PRTNER_ADDR_ID = I1.ICS_EFFLU_TRADE_PRTNER_ADDR_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_EFFLU_TRADE_PRTNER.KEY_HASH
       WHERE ICS_EFFLU_TRADE_PRTNER.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'EffluentTradePartnerSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'EffluentTradePartnerSubmission');
	




-- Remove any old records for ICS_ENFRC_ACTN_MILESTONE
				
-- /ICS_ENFRC_ACTN_MILESTONE
DELETE
  FROM ics_flow_icis.ICS_ENFRC_ACTN_MILESTONE
 WHERE ICS_ENFRC_ACTN_MILESTONE.ICS_ENFRC_ACTN_MILESTONE_ID IN
          (SELECT ICS_ENFRC_ACTN_MILESTONE.ICS_ENFRC_ACTN_MILESTONE_ID
              from ics_flow_icis.ICS_ENFRC_ACTN_MILESTONE ICS_ENFRC_ACTN_MILESTONE 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_ENFRC_ACTN_MILESTONE.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'EnforcementActionMilestoneSubmission')
                 
                 
);

	
-- Add accepted records for ICS_ENFRC_ACTN_MILESTONE


-- /ICS_ENFRC_ACTN_MILESTONE
INSERT INTO ics_flow_icis.ICS_ENFRC_ACTN_MILESTONE
     SELECT ICS_ENFRC_ACTN_MILESTONE.*
              from ICS_ENFRC_ACTN_MILESTONE ICS_ENFRC_ACTN_MILESTONE 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_ENFRC_ACTN_MILESTONE.KEY_HASH
       WHERE ICS_ENFRC_ACTN_MILESTONE.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'EnforcementActionMilestoneSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'EnforcementActionMilestoneSubmission');
	




-- Remove any old records for ICS_ENFRC_ACTN_VIOL_LNK
				
-- /ICS_ENFRC_ACTN_VIOL_LNK/ICS_CMPL_SCHD_VIOL
DELETE
  FROM ics_flow_icis.ICS_CMPL_SCHD_VIOL
 WHERE ICS_CMPL_SCHD_VIOL.ICS_ENFRC_ACTN_VIOL_LNK_ID IN
          (SELECT I5.ICS_ENFRC_ACTN_VIOL_LNK_ID
              from ics_flow_icis.ICS_ENFRC_ACTN_VIOL_LNK ICS_ENFRC_ACTN_VIOL_LNK 
 JOIN ics_flow_icis.ICS_CMPL_SCHD_VIOL I5
 ON I5.ICS_ENFRC_ACTN_VIOL_LNK_ID = ICS_ENFRC_ACTN_VIOL_LNK.ICS_ENFRC_ACTN_VIOL_LNK_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_ENFRC_ACTN_VIOL_LNK.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'EnforcementActionViolationLinkageSubmission')
                 
                 
);

				
-- /ICS_ENFRC_ACTN_VIOL_LNK/ICS_SNGL_EVTS_VIOL
DELETE
  FROM ics_flow_icis.ICS_SNGL_EVTS_VIOL
 WHERE ICS_SNGL_EVTS_VIOL.ICS_ENFRC_ACTN_VIOL_LNK_ID IN
          (SELECT I4.ICS_ENFRC_ACTN_VIOL_LNK_ID
              from ics_flow_icis.ICS_ENFRC_ACTN_VIOL_LNK ICS_ENFRC_ACTN_VIOL_LNK 
 JOIN ics_flow_icis.ICS_SNGL_EVTS_VIOL I4
 ON I4.ICS_ENFRC_ACTN_VIOL_LNK_ID = ICS_ENFRC_ACTN_VIOL_LNK.ICS_ENFRC_ACTN_VIOL_LNK_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_ENFRC_ACTN_VIOL_LNK.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'EnforcementActionViolationLinkageSubmission')
                 
                 
);

				
-- /ICS_ENFRC_ACTN_VIOL_LNK/ICS_PRMT_SCHD_VIOL
DELETE
  FROM ics_flow_icis.ICS_PRMT_SCHD_VIOL
 WHERE ICS_PRMT_SCHD_VIOL.ICS_ENFRC_ACTN_VIOL_LNK_ID IN
          (SELECT I3.ICS_ENFRC_ACTN_VIOL_LNK_ID
              from ics_flow_icis.ICS_ENFRC_ACTN_VIOL_LNK ICS_ENFRC_ACTN_VIOL_LNK 
 JOIN ics_flow_icis.ICS_PRMT_SCHD_VIOL I3
 ON I3.ICS_ENFRC_ACTN_VIOL_LNK_ID = ICS_ENFRC_ACTN_VIOL_LNK.ICS_ENFRC_ACTN_VIOL_LNK_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_ENFRC_ACTN_VIOL_LNK.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'EnforcementActionViolationLinkageSubmission')
                 
                 
);

				
-- /ICS_ENFRC_ACTN_VIOL_LNK/ICS_DSCH_MON_REP_VIOL
DELETE
  FROM ics_flow_icis.ICS_DSCH_MON_REP_VIOL
 WHERE ICS_DSCH_MON_REP_VIOL.ICS_ENFRC_ACTN_VIOL_LNK_ID IN
          (SELECT I2.ICS_ENFRC_ACTN_VIOL_LNK_ID
              from ics_flow_icis.ICS_ENFRC_ACTN_VIOL_LNK ICS_ENFRC_ACTN_VIOL_LNK 
 JOIN ics_flow_icis.ICS_DSCH_MON_REP_VIOL I2
 ON I2.ICS_ENFRC_ACTN_VIOL_LNK_ID = ICS_ENFRC_ACTN_VIOL_LNK.ICS_ENFRC_ACTN_VIOL_LNK_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_ENFRC_ACTN_VIOL_LNK.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'EnforcementActionViolationLinkageSubmission')
                 
                 
);

				
-- /ICS_ENFRC_ACTN_VIOL_LNK/ICS_DSCH_MON_REP_PARAM_VIOL
DELETE
  FROM ics_flow_icis.ICS_DSCH_MON_REP_PARAM_VIOL
 WHERE ICS_DSCH_MON_REP_PARAM_VIOL.ICS_ENFRC_ACTN_VIOL_LNK_ID IN
          (SELECT I1.ICS_ENFRC_ACTN_VIOL_LNK_ID
              from ics_flow_icis.ICS_ENFRC_ACTN_VIOL_LNK ICS_ENFRC_ACTN_VIOL_LNK 
 JOIN ics_flow_icis.ICS_DSCH_MON_REP_PARAM_VIOL I1
 ON I1.ICS_ENFRC_ACTN_VIOL_LNK_ID = ICS_ENFRC_ACTN_VIOL_LNK.ICS_ENFRC_ACTN_VIOL_LNK_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_ENFRC_ACTN_VIOL_LNK.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'EnforcementActionViolationLinkageSubmission')
                 
                 
);

				
-- /ICS_ENFRC_ACTN_VIOL_LNK
DELETE
  FROM ics_flow_icis.ICS_ENFRC_ACTN_VIOL_LNK
 WHERE ICS_ENFRC_ACTN_VIOL_LNK.ICS_ENFRC_ACTN_VIOL_LNK_ID IN
          (SELECT ICS_ENFRC_ACTN_VIOL_LNK.ICS_ENFRC_ACTN_VIOL_LNK_ID
              from ics_flow_icis.ICS_ENFRC_ACTN_VIOL_LNK ICS_ENFRC_ACTN_VIOL_LNK 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_ENFRC_ACTN_VIOL_LNK.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'EnforcementActionViolationLinkageSubmission')
                 
                 
);

	
-- Add accepted records for ICS_ENFRC_ACTN_VIOL_LNK


-- /ICS_ENFRC_ACTN_VIOL_LNK
INSERT INTO ics_flow_icis.ICS_ENFRC_ACTN_VIOL_LNK
     SELECT ICS_ENFRC_ACTN_VIOL_LNK.*
              from ICS_ENFRC_ACTN_VIOL_LNK ICS_ENFRC_ACTN_VIOL_LNK 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_ENFRC_ACTN_VIOL_LNK.KEY_HASH
       WHERE ICS_ENFRC_ACTN_VIOL_LNK.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'EnforcementActionViolationLinkageSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'EnforcementActionViolationLinkageSubmission');


-- /ICS_ENFRC_ACTN_VIOL_LNK/ICS_DSCH_MON_REP_PARAM_VIOL
INSERT INTO ics_flow_icis.ICS_DSCH_MON_REP_PARAM_VIOL
     SELECT I1.*
              from ICS_ENFRC_ACTN_VIOL_LNK ICS_ENFRC_ACTN_VIOL_LNK 
 JOIN ICS_DSCH_MON_REP_PARAM_VIOL I1
 ON I1.ICS_ENFRC_ACTN_VIOL_LNK_ID = ICS_ENFRC_ACTN_VIOL_LNK.ICS_ENFRC_ACTN_VIOL_LNK_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_ENFRC_ACTN_VIOL_LNK.KEY_HASH
       WHERE ICS_ENFRC_ACTN_VIOL_LNK.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'EnforcementActionViolationLinkageSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'EnforcementActionViolationLinkageSubmission');


-- /ICS_ENFRC_ACTN_VIOL_LNK/ICS_DSCH_MON_REP_VIOL
INSERT INTO ics_flow_icis.ICS_DSCH_MON_REP_VIOL
     SELECT I2.*
              from ICS_ENFRC_ACTN_VIOL_LNK ICS_ENFRC_ACTN_VIOL_LNK 
 JOIN ICS_DSCH_MON_REP_VIOL I2
 ON I2.ICS_ENFRC_ACTN_VIOL_LNK_ID = ICS_ENFRC_ACTN_VIOL_LNK.ICS_ENFRC_ACTN_VIOL_LNK_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_ENFRC_ACTN_VIOL_LNK.KEY_HASH
       WHERE ICS_ENFRC_ACTN_VIOL_LNK.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'EnforcementActionViolationLinkageSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'EnforcementActionViolationLinkageSubmission');


-- /ICS_ENFRC_ACTN_VIOL_LNK/ICS_PRMT_SCHD_VIOL
INSERT INTO ics_flow_icis.ICS_PRMT_SCHD_VIOL
     SELECT I3.*
              from ICS_ENFRC_ACTN_VIOL_LNK ICS_ENFRC_ACTN_VIOL_LNK 
 JOIN ICS_PRMT_SCHD_VIOL I3
 ON I3.ICS_ENFRC_ACTN_VIOL_LNK_ID = ICS_ENFRC_ACTN_VIOL_LNK.ICS_ENFRC_ACTN_VIOL_LNK_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_ENFRC_ACTN_VIOL_LNK.KEY_HASH
       WHERE ICS_ENFRC_ACTN_VIOL_LNK.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'EnforcementActionViolationLinkageSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'EnforcementActionViolationLinkageSubmission');


-- /ICS_ENFRC_ACTN_VIOL_LNK/ICS_SNGL_EVTS_VIOL
INSERT INTO ics_flow_icis.ICS_SNGL_EVTS_VIOL
     SELECT I4.*
              from ICS_ENFRC_ACTN_VIOL_LNK ICS_ENFRC_ACTN_VIOL_LNK 
 JOIN ICS_SNGL_EVTS_VIOL I4
 ON I4.ICS_ENFRC_ACTN_VIOL_LNK_ID = ICS_ENFRC_ACTN_VIOL_LNK.ICS_ENFRC_ACTN_VIOL_LNK_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_ENFRC_ACTN_VIOL_LNK.KEY_HASH
       WHERE ICS_ENFRC_ACTN_VIOL_LNK.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'EnforcementActionViolationLinkageSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'EnforcementActionViolationLinkageSubmission');


-- /ICS_ENFRC_ACTN_VIOL_LNK/ICS_CMPL_SCHD_VIOL
INSERT INTO ics_flow_icis.ICS_CMPL_SCHD_VIOL
     SELECT I5.*
              from ICS_ENFRC_ACTN_VIOL_LNK ICS_ENFRC_ACTN_VIOL_LNK 
 JOIN ICS_CMPL_SCHD_VIOL I5
 ON I5.ICS_ENFRC_ACTN_VIOL_LNK_ID = ICS_ENFRC_ACTN_VIOL_LNK.ICS_ENFRC_ACTN_VIOL_LNK_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_ENFRC_ACTN_VIOL_LNK.KEY_HASH
       WHERE ICS_ENFRC_ACTN_VIOL_LNK.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'EnforcementActionViolationLinkageSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'EnforcementActionViolationLinkageSubmission');
	




-- Remove any old records for ICS_FINAL_ORDER_VIOL_LNK
				
-- /ICS_FINAL_ORDER_VIOL_LNK/ICS_CMPL_SCHD_VIOL
DELETE
  FROM ics_flow_icis.ICS_CMPL_SCHD_VIOL
 WHERE ICS_CMPL_SCHD_VIOL.ICS_FINAL_ORDER_VIOL_LNK_ID IN
          (SELECT I5.ICS_FINAL_ORDER_VIOL_LNK_ID
              from ics_flow_icis.ICS_FINAL_ORDER_VIOL_LNK ICS_FINAL_ORDER_VIOL_LNK 
 JOIN ics_flow_icis.ICS_CMPL_SCHD_VIOL I5
 ON I5.ICS_FINAL_ORDER_VIOL_LNK_ID = ICS_FINAL_ORDER_VIOL_LNK.ICS_FINAL_ORDER_VIOL_LNK_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_FINAL_ORDER_VIOL_LNK.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'FinalOrderViolationLinkageSubmission')
                 
                 
);

				
-- /ICS_FINAL_ORDER_VIOL_LNK/ICS_SNGL_EVTS_VIOL
DELETE
  FROM ics_flow_icis.ICS_SNGL_EVTS_VIOL
 WHERE ICS_SNGL_EVTS_VIOL.ICS_FINAL_ORDER_VIOL_LNK_ID IN
          (SELECT I4.ICS_FINAL_ORDER_VIOL_LNK_ID
              from ics_flow_icis.ICS_FINAL_ORDER_VIOL_LNK ICS_FINAL_ORDER_VIOL_LNK 
 JOIN ics_flow_icis.ICS_SNGL_EVTS_VIOL I4
 ON I4.ICS_FINAL_ORDER_VIOL_LNK_ID = ICS_FINAL_ORDER_VIOL_LNK.ICS_FINAL_ORDER_VIOL_LNK_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_FINAL_ORDER_VIOL_LNK.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'FinalOrderViolationLinkageSubmission')
                 
                 
);

				
-- /ICS_FINAL_ORDER_VIOL_LNK/ICS_PRMT_SCHD_VIOL
DELETE
  FROM ics_flow_icis.ICS_PRMT_SCHD_VIOL
 WHERE ICS_PRMT_SCHD_VIOL.ICS_FINAL_ORDER_VIOL_LNK_ID IN
          (SELECT I3.ICS_FINAL_ORDER_VIOL_LNK_ID
              from ics_flow_icis.ICS_FINAL_ORDER_VIOL_LNK ICS_FINAL_ORDER_VIOL_LNK 
 JOIN ics_flow_icis.ICS_PRMT_SCHD_VIOL I3
 ON I3.ICS_FINAL_ORDER_VIOL_LNK_ID = ICS_FINAL_ORDER_VIOL_LNK.ICS_FINAL_ORDER_VIOL_LNK_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_FINAL_ORDER_VIOL_LNK.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'FinalOrderViolationLinkageSubmission')
                 
                 
);

				
-- /ICS_FINAL_ORDER_VIOL_LNK/ICS_DSCH_MON_REP_VIOL
DELETE
  FROM ics_flow_icis.ICS_DSCH_MON_REP_VIOL
 WHERE ICS_DSCH_MON_REP_VIOL.ICS_FINAL_ORDER_VIOL_LNK_ID IN
          (SELECT I2.ICS_FINAL_ORDER_VIOL_LNK_ID
              from ics_flow_icis.ICS_FINAL_ORDER_VIOL_LNK ICS_FINAL_ORDER_VIOL_LNK 
 JOIN ics_flow_icis.ICS_DSCH_MON_REP_VIOL I2
 ON I2.ICS_FINAL_ORDER_VIOL_LNK_ID = ICS_FINAL_ORDER_VIOL_LNK.ICS_FINAL_ORDER_VIOL_LNK_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_FINAL_ORDER_VIOL_LNK.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'FinalOrderViolationLinkageSubmission')
                 
                 
);

				
-- /ICS_FINAL_ORDER_VIOL_LNK/ICS_DSCH_MON_REP_PARAM_VIOL
DELETE
  FROM ics_flow_icis.ICS_DSCH_MON_REP_PARAM_VIOL
 WHERE ICS_DSCH_MON_REP_PARAM_VIOL.ICS_FINAL_ORDER_VIOL_LNK_ID IN
          (SELECT I1.ICS_FINAL_ORDER_VIOL_LNK_ID
              from ics_flow_icis.ICS_FINAL_ORDER_VIOL_LNK ICS_FINAL_ORDER_VIOL_LNK 
 JOIN ics_flow_icis.ICS_DSCH_MON_REP_PARAM_VIOL I1
 ON I1.ICS_FINAL_ORDER_VIOL_LNK_ID = ICS_FINAL_ORDER_VIOL_LNK.ICS_FINAL_ORDER_VIOL_LNK_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_FINAL_ORDER_VIOL_LNK.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'FinalOrderViolationLinkageSubmission')
                 
                 
);

				
-- /ICS_FINAL_ORDER_VIOL_LNK
DELETE
  FROM ics_flow_icis.ICS_FINAL_ORDER_VIOL_LNK
 WHERE ICS_FINAL_ORDER_VIOL_LNK.ICS_FINAL_ORDER_VIOL_LNK_ID IN
          (SELECT ICS_FINAL_ORDER_VIOL_LNK.ICS_FINAL_ORDER_VIOL_LNK_ID
              from ics_flow_icis.ICS_FINAL_ORDER_VIOL_LNK ICS_FINAL_ORDER_VIOL_LNK 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_FINAL_ORDER_VIOL_LNK.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'FinalOrderViolationLinkageSubmission')
                 
                 
);

	
-- Add accepted records for ICS_FINAL_ORDER_VIOL_LNK


-- /ICS_FINAL_ORDER_VIOL_LNK
INSERT INTO ics_flow_icis.ICS_FINAL_ORDER_VIOL_LNK
     SELECT ICS_FINAL_ORDER_VIOL_LNK.*
              from ICS_FINAL_ORDER_VIOL_LNK ICS_FINAL_ORDER_VIOL_LNK 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_FINAL_ORDER_VIOL_LNK.KEY_HASH
       WHERE ICS_FINAL_ORDER_VIOL_LNK.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'FinalOrderViolationLinkageSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'FinalOrderViolationLinkageSubmission');


-- /ICS_FINAL_ORDER_VIOL_LNK/ICS_DSCH_MON_REP_PARAM_VIOL
INSERT INTO ics_flow_icis.ICS_DSCH_MON_REP_PARAM_VIOL
     SELECT I1.*
              from ICS_FINAL_ORDER_VIOL_LNK ICS_FINAL_ORDER_VIOL_LNK 
 JOIN ICS_DSCH_MON_REP_PARAM_VIOL I1
 ON I1.ICS_FINAL_ORDER_VIOL_LNK_ID = ICS_FINAL_ORDER_VIOL_LNK.ICS_FINAL_ORDER_VIOL_LNK_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_FINAL_ORDER_VIOL_LNK.KEY_HASH
       WHERE ICS_FINAL_ORDER_VIOL_LNK.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'FinalOrderViolationLinkageSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'FinalOrderViolationLinkageSubmission');


-- /ICS_FINAL_ORDER_VIOL_LNK/ICS_DSCH_MON_REP_VIOL
INSERT INTO ics_flow_icis.ICS_DSCH_MON_REP_VIOL
     SELECT I2.*
              from ICS_FINAL_ORDER_VIOL_LNK ICS_FINAL_ORDER_VIOL_LNK 
 JOIN ICS_DSCH_MON_REP_VIOL I2
 ON I2.ICS_FINAL_ORDER_VIOL_LNK_ID = ICS_FINAL_ORDER_VIOL_LNK.ICS_FINAL_ORDER_VIOL_LNK_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_FINAL_ORDER_VIOL_LNK.KEY_HASH
       WHERE ICS_FINAL_ORDER_VIOL_LNK.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'FinalOrderViolationLinkageSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'FinalOrderViolationLinkageSubmission');


-- /ICS_FINAL_ORDER_VIOL_LNK/ICS_PRMT_SCHD_VIOL
INSERT INTO ics_flow_icis.ICS_PRMT_SCHD_VIOL
     SELECT I3.*
              from ICS_FINAL_ORDER_VIOL_LNK ICS_FINAL_ORDER_VIOL_LNK 
 JOIN ICS_PRMT_SCHD_VIOL I3
 ON I3.ICS_FINAL_ORDER_VIOL_LNK_ID = ICS_FINAL_ORDER_VIOL_LNK.ICS_FINAL_ORDER_VIOL_LNK_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_FINAL_ORDER_VIOL_LNK.KEY_HASH
       WHERE ICS_FINAL_ORDER_VIOL_LNK.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'FinalOrderViolationLinkageSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'FinalOrderViolationLinkageSubmission');


-- /ICS_FINAL_ORDER_VIOL_LNK/ICS_SNGL_EVTS_VIOL
INSERT INTO ics_flow_icis.ICS_SNGL_EVTS_VIOL
     SELECT I4.*
              from ICS_FINAL_ORDER_VIOL_LNK ICS_FINAL_ORDER_VIOL_LNK 
 JOIN ICS_SNGL_EVTS_VIOL I4
 ON I4.ICS_FINAL_ORDER_VIOL_LNK_ID = ICS_FINAL_ORDER_VIOL_LNK.ICS_FINAL_ORDER_VIOL_LNK_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_FINAL_ORDER_VIOL_LNK.KEY_HASH
       WHERE ICS_FINAL_ORDER_VIOL_LNK.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'FinalOrderViolationLinkageSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'FinalOrderViolationLinkageSubmission');


-- /ICS_FINAL_ORDER_VIOL_LNK/ICS_CMPL_SCHD_VIOL
INSERT INTO ics_flow_icis.ICS_CMPL_SCHD_VIOL
     SELECT I5.*
              from ICS_FINAL_ORDER_VIOL_LNK ICS_FINAL_ORDER_VIOL_LNK 
 JOIN ICS_CMPL_SCHD_VIOL I5
 ON I5.ICS_FINAL_ORDER_VIOL_LNK_ID = ICS_FINAL_ORDER_VIOL_LNK.ICS_FINAL_ORDER_VIOL_LNK_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_FINAL_ORDER_VIOL_LNK.KEY_HASH
       WHERE ICS_FINAL_ORDER_VIOL_LNK.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'FinalOrderViolationLinkageSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'FinalOrderViolationLinkageSubmission');
	




-- Remove any old records for ICS_FRML_ENFRC_ACTN
				
-- /ICS_FRML_ENFRC_ACTN/ICS_FINAL_ORDER/ICS_SEP
DELETE
  FROM ics_flow_icis.ICS_SEP
 WHERE ICS_SEP.ICS_FINAL_ORDER_ID IN
          (SELECT I8.ICS_FINAL_ORDER_ID
              from ics_flow_icis.ICS_FRML_ENFRC_ACTN ICS_FRML_ENFRC_ACTN 
 JOIN ics_flow_icis.ICS_FINAL_ORDER I6
 ON I6.ICS_FRML_ENFRC_ACTN_ID = ICS_FRML_ENFRC_ACTN.ICS_FRML_ENFRC_ACTN_ID 
 JOIN ics_flow_icis.ICS_SEP I8
 ON I8.ICS_FINAL_ORDER_ID = I6.ICS_FINAL_ORDER_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_FRML_ENFRC_ACTN.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'FormalEnforcementActionSubmission')
                 
                 
);

				
-- /ICS_FRML_ENFRC_ACTN/ICS_FINAL_ORDER/ICS_FINAL_ORDER_PRMT_IDENT
DELETE
  FROM ics_flow_icis.ICS_FINAL_ORDER_PRMT_IDENT
 WHERE ICS_FINAL_ORDER_PRMT_IDENT.ICS_FINAL_ORDER_ID IN
          (SELECT I7.ICS_FINAL_ORDER_ID
              from ics_flow_icis.ICS_FRML_ENFRC_ACTN ICS_FRML_ENFRC_ACTN 
 JOIN ics_flow_icis.ICS_FINAL_ORDER I6
 ON I6.ICS_FRML_ENFRC_ACTN_ID = ICS_FRML_ENFRC_ACTN.ICS_FRML_ENFRC_ACTN_ID 
 JOIN ics_flow_icis.ICS_FINAL_ORDER_PRMT_IDENT I7
 ON I7.ICS_FINAL_ORDER_ID = I6.ICS_FINAL_ORDER_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_FRML_ENFRC_ACTN.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'FormalEnforcementActionSubmission')
                 
                 
);

				
-- /ICS_FRML_ENFRC_ACTN/ICS_FINAL_ORDER
DELETE
  FROM ics_flow_icis.ICS_FINAL_ORDER
 WHERE ICS_FINAL_ORDER.ICS_FRML_ENFRC_ACTN_ID IN
          (SELECT I6.ICS_FRML_ENFRC_ACTN_ID
              from ics_flow_icis.ICS_FRML_ENFRC_ACTN ICS_FRML_ENFRC_ACTN 
 JOIN ics_flow_icis.ICS_FINAL_ORDER I6
 ON I6.ICS_FRML_ENFRC_ACTN_ID = ICS_FRML_ENFRC_ACTN.ICS_FRML_ENFRC_ACTN_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_FRML_ENFRC_ACTN.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'FormalEnforcementActionSubmission')
                 
                 
);

				
-- /ICS_FRML_ENFRC_ACTN/ICS_PROGS_VIOL
DELETE
  FROM ics_flow_icis.ICS_PROGS_VIOL
 WHERE ICS_PROGS_VIOL.ICS_FRML_ENFRC_ACTN_ID IN
          (SELECT I5.ICS_FRML_ENFRC_ACTN_ID
              from ics_flow_icis.ICS_FRML_ENFRC_ACTN ICS_FRML_ENFRC_ACTN 
 JOIN ics_flow_icis.ICS_PROGS_VIOL I5
 ON I5.ICS_FRML_ENFRC_ACTN_ID = ICS_FRML_ENFRC_ACTN.ICS_FRML_ENFRC_ACTN_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_FRML_ENFRC_ACTN.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'FormalEnforcementActionSubmission')
                 
                 
);

				
-- /ICS_FRML_ENFRC_ACTN/ICS_ENFRC_AGNCY
DELETE
  FROM ics_flow_icis.ICS_ENFRC_AGNCY
 WHERE ICS_ENFRC_AGNCY.ICS_FRML_ENFRC_ACTN_ID IN
          (SELECT I4.ICS_FRML_ENFRC_ACTN_ID
              from ics_flow_icis.ICS_FRML_ENFRC_ACTN ICS_FRML_ENFRC_ACTN 
 JOIN ics_flow_icis.ICS_ENFRC_AGNCY I4
 ON I4.ICS_FRML_ENFRC_ACTN_ID = ICS_FRML_ENFRC_ACTN.ICS_FRML_ENFRC_ACTN_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_FRML_ENFRC_ACTN.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'FormalEnforcementActionSubmission')
                 
                 
);

				
-- /ICS_FRML_ENFRC_ACTN/ICS_ENFRC_ACTN_TYPE
DELETE
  FROM ics_flow_icis.ICS_ENFRC_ACTN_TYPE
 WHERE ICS_ENFRC_ACTN_TYPE.ICS_FRML_ENFRC_ACTN_ID IN
          (SELECT I3.ICS_FRML_ENFRC_ACTN_ID
              from ics_flow_icis.ICS_FRML_ENFRC_ACTN ICS_FRML_ENFRC_ACTN 
 JOIN ics_flow_icis.ICS_ENFRC_ACTN_TYPE I3
 ON I3.ICS_FRML_ENFRC_ACTN_ID = ICS_FRML_ENFRC_ACTN.ICS_FRML_ENFRC_ACTN_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_FRML_ENFRC_ACTN.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'FormalEnforcementActionSubmission')
                 
                 
);

				
-- /ICS_FRML_ENFRC_ACTN/ICS_ENFRC_ACTN_GOV_CONTACT
DELETE
  FROM ics_flow_icis.ICS_ENFRC_ACTN_GOV_CONTACT
 WHERE ICS_ENFRC_ACTN_GOV_CONTACT.ICS_FRML_ENFRC_ACTN_ID IN
          (SELECT I2.ICS_FRML_ENFRC_ACTN_ID
              from ics_flow_icis.ICS_FRML_ENFRC_ACTN ICS_FRML_ENFRC_ACTN 
 JOIN ics_flow_icis.ICS_ENFRC_ACTN_GOV_CONTACT I2
 ON I2.ICS_FRML_ENFRC_ACTN_ID = ICS_FRML_ENFRC_ACTN.ICS_FRML_ENFRC_ACTN_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_FRML_ENFRC_ACTN.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'FormalEnforcementActionSubmission')
                 
                 
);

				
-- /ICS_FRML_ENFRC_ACTN/ICS_PRMT_IDENT
DELETE
  FROM ics_flow_icis.ICS_PRMT_IDENT
 WHERE ICS_PRMT_IDENT.ICS_FRML_ENFRC_ACTN_ID IN
          (SELECT I1.ICS_FRML_ENFRC_ACTN_ID
              from ics_flow_icis.ICS_FRML_ENFRC_ACTN ICS_FRML_ENFRC_ACTN 
 JOIN ics_flow_icis.ICS_PRMT_IDENT I1
 ON I1.ICS_FRML_ENFRC_ACTN_ID = ICS_FRML_ENFRC_ACTN.ICS_FRML_ENFRC_ACTN_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_FRML_ENFRC_ACTN.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'FormalEnforcementActionSubmission')
                 
                 
);

				
-- /ICS_FRML_ENFRC_ACTN
DELETE
  FROM ics_flow_icis.ICS_FRML_ENFRC_ACTN
 WHERE ICS_FRML_ENFRC_ACTN.ICS_FRML_ENFRC_ACTN_ID IN
          (SELECT ICS_FRML_ENFRC_ACTN.ICS_FRML_ENFRC_ACTN_ID
              from ics_flow_icis.ICS_FRML_ENFRC_ACTN ICS_FRML_ENFRC_ACTN 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_FRML_ENFRC_ACTN.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'FormalEnforcementActionSubmission')
                 
                 
);

	
-- Add accepted records for ICS_FRML_ENFRC_ACTN


-- /ICS_FRML_ENFRC_ACTN
INSERT INTO ics_flow_icis.ICS_FRML_ENFRC_ACTN
     SELECT ICS_FRML_ENFRC_ACTN.*
              from ICS_FRML_ENFRC_ACTN ICS_FRML_ENFRC_ACTN 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_FRML_ENFRC_ACTN.KEY_HASH
       WHERE ICS_FRML_ENFRC_ACTN.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'FormalEnforcementActionSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'FormalEnforcementActionSubmission');


-- /ICS_FRML_ENFRC_ACTN/ICS_PRMT_IDENT
INSERT INTO ics_flow_icis.ICS_PRMT_IDENT
     SELECT I1.*
              from ICS_FRML_ENFRC_ACTN ICS_FRML_ENFRC_ACTN 
 JOIN ICS_PRMT_IDENT I1
 ON I1.ICS_FRML_ENFRC_ACTN_ID = ICS_FRML_ENFRC_ACTN.ICS_FRML_ENFRC_ACTN_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_FRML_ENFRC_ACTN.KEY_HASH
       WHERE ICS_FRML_ENFRC_ACTN.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'FormalEnforcementActionSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'FormalEnforcementActionSubmission');


-- /ICS_FRML_ENFRC_ACTN/ICS_ENFRC_ACTN_GOV_CONTACT
INSERT INTO ics_flow_icis.ICS_ENFRC_ACTN_GOV_CONTACT
     SELECT I2.*
              from ICS_FRML_ENFRC_ACTN ICS_FRML_ENFRC_ACTN 
 JOIN ICS_ENFRC_ACTN_GOV_CONTACT I2
 ON I2.ICS_FRML_ENFRC_ACTN_ID = ICS_FRML_ENFRC_ACTN.ICS_FRML_ENFRC_ACTN_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_FRML_ENFRC_ACTN.KEY_HASH
       WHERE ICS_FRML_ENFRC_ACTN.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'FormalEnforcementActionSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'FormalEnforcementActionSubmission');


-- /ICS_FRML_ENFRC_ACTN/ICS_ENFRC_ACTN_TYPE
INSERT INTO ics_flow_icis.ICS_ENFRC_ACTN_TYPE
     SELECT I3.*
              from ICS_FRML_ENFRC_ACTN ICS_FRML_ENFRC_ACTN 
 JOIN ICS_ENFRC_ACTN_TYPE I3
 ON I3.ICS_FRML_ENFRC_ACTN_ID = ICS_FRML_ENFRC_ACTN.ICS_FRML_ENFRC_ACTN_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_FRML_ENFRC_ACTN.KEY_HASH
       WHERE ICS_FRML_ENFRC_ACTN.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'FormalEnforcementActionSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'FormalEnforcementActionSubmission');


-- /ICS_FRML_ENFRC_ACTN/ICS_ENFRC_AGNCY
INSERT INTO ics_flow_icis.ICS_ENFRC_AGNCY
     SELECT I4.*
              from ICS_FRML_ENFRC_ACTN ICS_FRML_ENFRC_ACTN 
 JOIN ICS_ENFRC_AGNCY I4
 ON I4.ICS_FRML_ENFRC_ACTN_ID = ICS_FRML_ENFRC_ACTN.ICS_FRML_ENFRC_ACTN_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_FRML_ENFRC_ACTN.KEY_HASH
       WHERE ICS_FRML_ENFRC_ACTN.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'FormalEnforcementActionSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'FormalEnforcementActionSubmission');


-- /ICS_FRML_ENFRC_ACTN/ICS_PROGS_VIOL
INSERT INTO ics_flow_icis.ICS_PROGS_VIOL
     SELECT I5.*
              from ICS_FRML_ENFRC_ACTN ICS_FRML_ENFRC_ACTN 
 JOIN ICS_PROGS_VIOL I5
 ON I5.ICS_FRML_ENFRC_ACTN_ID = ICS_FRML_ENFRC_ACTN.ICS_FRML_ENFRC_ACTN_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_FRML_ENFRC_ACTN.KEY_HASH
       WHERE ICS_FRML_ENFRC_ACTN.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'FormalEnforcementActionSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'FormalEnforcementActionSubmission');


-- /ICS_FRML_ENFRC_ACTN/ICS_FINAL_ORDER
INSERT INTO ics_flow_icis.ICS_FINAL_ORDER
     SELECT I6.*
              from ICS_FRML_ENFRC_ACTN ICS_FRML_ENFRC_ACTN 
 JOIN ICS_FINAL_ORDER I6
 ON I6.ICS_FRML_ENFRC_ACTN_ID = ICS_FRML_ENFRC_ACTN.ICS_FRML_ENFRC_ACTN_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_FRML_ENFRC_ACTN.KEY_HASH
       WHERE ICS_FRML_ENFRC_ACTN.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'FormalEnforcementActionSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'FormalEnforcementActionSubmission');


-- /ICS_FRML_ENFRC_ACTN/ICS_FINAL_ORDER/ICS_FINAL_ORDER_PRMT_IDENT
INSERT INTO ics_flow_icis.ICS_FINAL_ORDER_PRMT_IDENT
     SELECT I7.*
              from ICS_FRML_ENFRC_ACTN ICS_FRML_ENFRC_ACTN 
 JOIN ICS_FINAL_ORDER I6
 ON I6.ICS_FRML_ENFRC_ACTN_ID = ICS_FRML_ENFRC_ACTN.ICS_FRML_ENFRC_ACTN_ID 
 JOIN ICS_FINAL_ORDER_PRMT_IDENT I7
 ON I7.ICS_FINAL_ORDER_ID = I6.ICS_FINAL_ORDER_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_FRML_ENFRC_ACTN.KEY_HASH
       WHERE ICS_FRML_ENFRC_ACTN.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'FormalEnforcementActionSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'FormalEnforcementActionSubmission');


-- /ICS_FRML_ENFRC_ACTN/ICS_FINAL_ORDER/ICS_SEP
INSERT INTO ics_flow_icis.ICS_SEP
     SELECT I8.*
              from ICS_FRML_ENFRC_ACTN ICS_FRML_ENFRC_ACTN 
 JOIN ICS_FINAL_ORDER I6
 ON I6.ICS_FRML_ENFRC_ACTN_ID = ICS_FRML_ENFRC_ACTN.ICS_FRML_ENFRC_ACTN_ID 
 JOIN ICS_SEP I8
 ON I8.ICS_FINAL_ORDER_ID = I6.ICS_FINAL_ORDER_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_FRML_ENFRC_ACTN.KEY_HASH
       WHERE ICS_FRML_ENFRC_ACTN.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'FormalEnforcementActionSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'FormalEnforcementActionSubmission');
	




-- Remove any old records for ICS_GNRL_PRMT
				
-- /ICS_GNRL_PRMT/ICS_CMPL_TRACK_STAT
DELETE
  FROM ics_flow_icis.ICS_CMPL_TRACK_STAT
 WHERE ICS_CMPL_TRACK_STAT.ICS_GNRL_PRMT_ID IN
          (SELECT I24.ICS_GNRL_PRMT_ID
              from ics_flow_icis.ICS_GNRL_PRMT ICS_GNRL_PRMT 
 JOIN ics_flow_icis.ICS_CMPL_TRACK_STAT I24
 ON I24.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'GeneralPermitSubmission')
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_GNRL_PRMT/ICS_ASSC_PRMT
DELETE
  FROM ics_flow_icis.ICS_ASSC_PRMT
 WHERE ICS_ASSC_PRMT.ICS_GNRL_PRMT_ID IN
          (SELECT I23.ICS_GNRL_PRMT_ID
              from ics_flow_icis.ICS_GNRL_PRMT ICS_GNRL_PRMT 
 JOIN ics_flow_icis.ICS_ASSC_PRMT I23
 ON I23.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'GeneralPermitSubmission')
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_GNRL_PRMT/ICS_ADDR/ICS_TELEPH
DELETE
  FROM ics_flow_icis.ICS_TELEPH
 WHERE ICS_TELEPH.ICS_ADDR_ID IN
          (SELECT I22.ICS_ADDR_ID
              from ics_flow_icis.ICS_GNRL_PRMT ICS_GNRL_PRMT 
 JOIN ics_flow_icis.ICS_ADDR I21
 ON I21.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID 
 JOIN ics_flow_icis.ICS_TELEPH I22
 ON I22.ICS_ADDR_ID = I21.ICS_ADDR_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'GeneralPermitSubmission')
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_GNRL_PRMT/ICS_ADDR
DELETE
  FROM ics_flow_icis.ICS_ADDR
 WHERE ICS_ADDR.ICS_GNRL_PRMT_ID IN
          (SELECT I21.ICS_GNRL_PRMT_ID
              from ics_flow_icis.ICS_GNRL_PRMT ICS_GNRL_PRMT 
 JOIN ics_flow_icis.ICS_ADDR I21
 ON I21.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'GeneralPermitSubmission')
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_GNRL_PRMT/ICS_SIC_CODE
DELETE
  FROM ics_flow_icis.ICS_SIC_CODE
 WHERE ICS_SIC_CODE.ICS_GNRL_PRMT_ID IN
          (SELECT I20.ICS_GNRL_PRMT_ID
              from ics_flow_icis.ICS_GNRL_PRMT ICS_GNRL_PRMT 
 JOIN ics_flow_icis.ICS_SIC_CODE I20
 ON I20.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'GeneralPermitSubmission')
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_GNRL_PRMT/ICS_RESIDUAL_DESGN_DTRMN
DELETE
  FROM ics_flow_icis.ICS_RESIDUAL_DESGN_DTRMN
 WHERE ICS_RESIDUAL_DESGN_DTRMN.ICS_GNRL_PRMT_ID IN
          (SELECT I19.ICS_GNRL_PRMT_ID
              from ics_flow_icis.ICS_GNRL_PRMT ICS_GNRL_PRMT 
 JOIN ics_flow_icis.ICS_RESIDUAL_DESGN_DTRMN I19
 ON I19.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'GeneralPermitSubmission')
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_GNRL_PRMT/ICS_REP_NON_CMPL_STAT
DELETE
  FROM ics_flow_icis.ICS_REP_NON_CMPL_STAT
 WHERE ICS_REP_NON_CMPL_STAT.ICS_GNRL_PRMT_ID IN
          (SELECT I18.ICS_GNRL_PRMT_ID
              from ics_flow_icis.ICS_GNRL_PRMT ICS_GNRL_PRMT 
 JOIN ics_flow_icis.ICS_REP_NON_CMPL_STAT I18
 ON I18.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'GeneralPermitSubmission')
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_GNRL_PRMT/ICS_FAC/ICS_NAICS_CODE
DELETE
  FROM ics_flow_icis.ICS_NAICS_CODE
 WHERE ICS_NAICS_CODE.ICS_FAC_ID IN
          (SELECT I17.ICS_FAC_ID
              from ics_flow_icis.ICS_GNRL_PRMT ICS_GNRL_PRMT 
 JOIN ics_flow_icis.ICS_FAC I7
 ON I7.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID 
 JOIN ics_flow_icis.ICS_NAICS_CODE I17
 ON I17.ICS_FAC_ID = I7.ICS_FAC_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'GeneralPermitSubmission')
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_GNRL_PRMT/ICS_FAC/ICS_ADDR/ICS_TELEPH
DELETE
  FROM ics_flow_icis.ICS_TELEPH
 WHERE ICS_TELEPH.ICS_ADDR_ID IN
          (SELECT I16.ICS_ADDR_ID
              from ics_flow_icis.ICS_GNRL_PRMT ICS_GNRL_PRMT 
 JOIN ics_flow_icis.ICS_FAC I7
 ON I7.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID 
 JOIN ics_flow_icis.ICS_ADDR I15
 ON I15.ICS_FAC_ID = I7.ICS_FAC_ID 
 JOIN ics_flow_icis.ICS_TELEPH I16
 ON I16.ICS_ADDR_ID = I15.ICS_ADDR_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'GeneralPermitSubmission')
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_GNRL_PRMT/ICS_FAC/ICS_ADDR
DELETE
  FROM ics_flow_icis.ICS_ADDR
 WHERE ICS_ADDR.ICS_FAC_ID IN
          (SELECT I15.ICS_FAC_ID
              from ics_flow_icis.ICS_GNRL_PRMT ICS_GNRL_PRMT 
 JOIN ics_flow_icis.ICS_FAC I7
 ON I7.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID 
 JOIN ics_flow_icis.ICS_ADDR I15
 ON I15.ICS_FAC_ID = I7.ICS_FAC_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'GeneralPermitSubmission')
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_GNRL_PRMT/ICS_FAC/ICS_SIC_CODE
DELETE
  FROM ics_flow_icis.ICS_SIC_CODE
 WHERE ICS_SIC_CODE.ICS_FAC_ID IN
          (SELECT I14.ICS_FAC_ID
              from ics_flow_icis.ICS_GNRL_PRMT ICS_GNRL_PRMT 
 JOIN ics_flow_icis.ICS_FAC I7
 ON I7.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID 
 JOIN ics_flow_icis.ICS_SIC_CODE I14
 ON I14.ICS_FAC_ID = I7.ICS_FAC_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'GeneralPermitSubmission')
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_GNRL_PRMT/ICS_FAC/ICS_GEO_COORD
DELETE
  FROM ics_flow_icis.ICS_GEO_COORD
 WHERE ICS_GEO_COORD.ICS_FAC_ID IN
          (SELECT I13.ICS_FAC_ID
              from ics_flow_icis.ICS_GNRL_PRMT ICS_GNRL_PRMT 
 JOIN ics_flow_icis.ICS_FAC I7
 ON I7.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID 
 JOIN ics_flow_icis.ICS_GEO_COORD I13
 ON I13.ICS_FAC_ID = I7.ICS_FAC_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'GeneralPermitSubmission')
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_GNRL_PRMT/ICS_FAC/ICS_FAC_CLASS
DELETE
  FROM ics_flow_icis.ICS_FAC_CLASS
 WHERE ICS_FAC_CLASS.ICS_FAC_ID IN
          (SELECT I12.ICS_FAC_ID
              from ics_flow_icis.ICS_GNRL_PRMT ICS_GNRL_PRMT 
 JOIN ics_flow_icis.ICS_FAC I7
 ON I7.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID 
 JOIN ics_flow_icis.ICS_FAC_CLASS I12
 ON I12.ICS_FAC_ID = I7.ICS_FAC_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'GeneralPermitSubmission')
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_GNRL_PRMT/ICS_FAC/ICS_PLCY
DELETE
  FROM ics_flow_icis.ICS_PLCY
 WHERE ICS_PLCY.ICS_FAC_ID IN
          (SELECT I11.ICS_FAC_ID
              from ics_flow_icis.ICS_GNRL_PRMT ICS_GNRL_PRMT 
 JOIN ics_flow_icis.ICS_FAC I7
 ON I7.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID 
 JOIN ics_flow_icis.ICS_PLCY I11
 ON I11.ICS_FAC_ID = I7.ICS_FAC_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'GeneralPermitSubmission')
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_GNRL_PRMT/ICS_FAC/ICS_ORIG_PROGS
DELETE
  FROM ics_flow_icis.ICS_ORIG_PROGS
 WHERE ICS_ORIG_PROGS.ICS_FAC_ID IN
          (SELECT I10.ICS_FAC_ID
              from ics_flow_icis.ICS_GNRL_PRMT ICS_GNRL_PRMT 
 JOIN ics_flow_icis.ICS_FAC I7
 ON I7.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID 
 JOIN ics_flow_icis.ICS_ORIG_PROGS I10
 ON I10.ICS_FAC_ID = I7.ICS_FAC_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'GeneralPermitSubmission')
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_GNRL_PRMT/ICS_FAC/ICS_CONTACT/ICS_TELEPH
DELETE
  FROM ics_flow_icis.ICS_TELEPH
 WHERE ICS_TELEPH.ICS_CONTACT_ID IN
          (SELECT I9.ICS_CONTACT_ID
              from ics_flow_icis.ICS_GNRL_PRMT ICS_GNRL_PRMT 
 JOIN ics_flow_icis.ICS_FAC I7
 ON I7.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID 
 JOIN ics_flow_icis.ICS_CONTACT I8
 ON I8.ICS_FAC_ID = I7.ICS_FAC_ID 
 JOIN ics_flow_icis.ICS_TELEPH I9
 ON I9.ICS_CONTACT_ID = I8.ICS_CONTACT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'GeneralPermitSubmission')
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_GNRL_PRMT/ICS_FAC/ICS_CONTACT
DELETE
  FROM ics_flow_icis.ICS_CONTACT
 WHERE ICS_CONTACT.ICS_FAC_ID IN
          (SELECT I8.ICS_FAC_ID
              from ics_flow_icis.ICS_GNRL_PRMT ICS_GNRL_PRMT 
 JOIN ics_flow_icis.ICS_FAC I7
 ON I7.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID 
 JOIN ics_flow_icis.ICS_CONTACT I8
 ON I8.ICS_FAC_ID = I7.ICS_FAC_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'GeneralPermitSubmission')
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_GNRL_PRMT/ICS_FAC
DELETE
  FROM ics_flow_icis.ICS_FAC
 WHERE ICS_FAC.ICS_GNRL_PRMT_ID IN
          (SELECT I7.ICS_GNRL_PRMT_ID
              from ics_flow_icis.ICS_GNRL_PRMT ICS_GNRL_PRMT 
 JOIN ics_flow_icis.ICS_FAC I7
 ON I7.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'GeneralPermitSubmission')
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_GNRL_PRMT/ICS_EFFLU_GUIDE
DELETE
  FROM ics_flow_icis.ICS_EFFLU_GUIDE
 WHERE ICS_EFFLU_GUIDE.ICS_GNRL_PRMT_ID IN
          (SELECT I6.ICS_GNRL_PRMT_ID
              from ics_flow_icis.ICS_GNRL_PRMT ICS_GNRL_PRMT 
 JOIN ics_flow_icis.ICS_EFFLU_GUIDE I6
 ON I6.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'GeneralPermitSubmission')
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_GNRL_PRMT/ICS_OTHR_PRMTS
DELETE
  FROM ics_flow_icis.ICS_OTHR_PRMTS
 WHERE ICS_OTHR_PRMTS.ICS_GNRL_PRMT_ID IN
          (SELECT I5.ICS_GNRL_PRMT_ID
              from ics_flow_icis.ICS_GNRL_PRMT ICS_GNRL_PRMT 
 JOIN ics_flow_icis.ICS_OTHR_PRMTS I5
 ON I5.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'GeneralPermitSubmission')
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_GNRL_PRMT/ICS_NPDES_DAT_GRP_NUM
DELETE
  FROM ics_flow_icis.ICS_NPDES_DAT_GRP_NUM
 WHERE ICS_NPDES_DAT_GRP_NUM.ICS_GNRL_PRMT_ID IN
          (SELECT I4.ICS_GNRL_PRMT_ID
              from ics_flow_icis.ICS_GNRL_PRMT ICS_GNRL_PRMT 
 JOIN ics_flow_icis.ICS_NPDES_DAT_GRP_NUM I4
 ON I4.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'GeneralPermitSubmission')
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_GNRL_PRMT/ICS_CONTACT/ICS_TELEPH
DELETE
  FROM ics_flow_icis.ICS_TELEPH
 WHERE ICS_TELEPH.ICS_CONTACT_ID IN
          (SELECT I3.ICS_CONTACT_ID
              from ics_flow_icis.ICS_GNRL_PRMT ICS_GNRL_PRMT 
 JOIN ics_flow_icis.ICS_CONTACT I2
 ON I2.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID 
 JOIN ics_flow_icis.ICS_TELEPH I3
 ON I3.ICS_CONTACT_ID = I2.ICS_CONTACT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'GeneralPermitSubmission')
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_GNRL_PRMT/ICS_CONTACT
DELETE
  FROM ics_flow_icis.ICS_CONTACT
 WHERE ICS_CONTACT.ICS_GNRL_PRMT_ID IN
          (SELECT I2.ICS_GNRL_PRMT_ID
              from ics_flow_icis.ICS_GNRL_PRMT ICS_GNRL_PRMT 
 JOIN ics_flow_icis.ICS_CONTACT I2
 ON I2.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'GeneralPermitSubmission')
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_GNRL_PRMT/ICS_NAICS_CODE
DELETE
  FROM ics_flow_icis.ICS_NAICS_CODE
 WHERE ICS_NAICS_CODE.ICS_GNRL_PRMT_ID IN
          (SELECT I1.ICS_GNRL_PRMT_ID
              from ics_flow_icis.ICS_GNRL_PRMT ICS_GNRL_PRMT 
 JOIN ics_flow_icis.ICS_NAICS_CODE I1
 ON I1.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'GeneralPermitSubmission')
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_GNRL_PRMT
DELETE
  FROM ics_flow_icis.ICS_GNRL_PRMT
 WHERE ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID IN
          (SELECT ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID
              from ics_flow_icis.ICS_GNRL_PRMT ICS_GNRL_PRMT 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'GeneralPermitSubmission')
                  OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

	
-- Add accepted records for ICS_GNRL_PRMT


-- /ICS_GNRL_PRMT
INSERT INTO ics_flow_icis.ICS_GNRL_PRMT
     SELECT ICS_GNRL_PRMT.*
              from ICS_GNRL_PRMT ICS_GNRL_PRMT 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
       WHERE ICS_GNRL_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'GeneralPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission');


-- /ICS_GNRL_PRMT/ICS_NAICS_CODE
INSERT INTO ics_flow_icis.ICS_NAICS_CODE
     SELECT I1.*
              from ICS_GNRL_PRMT ICS_GNRL_PRMT 
 JOIN ICS_NAICS_CODE I1
 ON I1.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
       WHERE ICS_GNRL_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'GeneralPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission');


-- /ICS_GNRL_PRMT/ICS_CONTACT
INSERT INTO ics_flow_icis.ICS_CONTACT
     SELECT I2.*
              from ICS_GNRL_PRMT ICS_GNRL_PRMT 
 JOIN ICS_CONTACT I2
 ON I2.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
       WHERE ICS_GNRL_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'GeneralPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission');


-- /ICS_GNRL_PRMT/ICS_CONTACT/ICS_TELEPH
INSERT INTO ics_flow_icis.ICS_TELEPH
     SELECT I3.*
              from ICS_GNRL_PRMT ICS_GNRL_PRMT 
 JOIN ICS_CONTACT I2
 ON I2.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID 
 JOIN ICS_TELEPH I3
 ON I3.ICS_CONTACT_ID = I2.ICS_CONTACT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
       WHERE ICS_GNRL_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'GeneralPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission');


-- /ICS_GNRL_PRMT/ICS_NPDES_DAT_GRP_NUM
INSERT INTO ics_flow_icis.ICS_NPDES_DAT_GRP_NUM
     SELECT I4.*
              from ICS_GNRL_PRMT ICS_GNRL_PRMT 
 JOIN ICS_NPDES_DAT_GRP_NUM I4
 ON I4.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
       WHERE ICS_GNRL_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'GeneralPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission');


-- /ICS_GNRL_PRMT/ICS_OTHR_PRMTS
INSERT INTO ics_flow_icis.ICS_OTHR_PRMTS
     SELECT I5.*
              from ICS_GNRL_PRMT ICS_GNRL_PRMT 
 JOIN ICS_OTHR_PRMTS I5
 ON I5.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
       WHERE ICS_GNRL_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'GeneralPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission');


-- /ICS_GNRL_PRMT/ICS_EFFLU_GUIDE
INSERT INTO ics_flow_icis.ICS_EFFLU_GUIDE
     SELECT I6.*
              from ICS_GNRL_PRMT ICS_GNRL_PRMT 
 JOIN ICS_EFFLU_GUIDE I6
 ON I6.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
       WHERE ICS_GNRL_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'GeneralPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission');


-- /ICS_GNRL_PRMT/ICS_FAC
INSERT INTO ics_flow_icis.ICS_FAC
     SELECT I7.*
              from ICS_GNRL_PRMT ICS_GNRL_PRMT 
 JOIN ICS_FAC I7
 ON I7.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
       WHERE ICS_GNRL_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'GeneralPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission');


-- /ICS_GNRL_PRMT/ICS_FAC/ICS_CONTACT
INSERT INTO ics_flow_icis.ICS_CONTACT
     SELECT I8.*
              from ICS_GNRL_PRMT ICS_GNRL_PRMT 
 JOIN ICS_FAC I7
 ON I7.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID 
 JOIN ICS_CONTACT I8
 ON I8.ICS_FAC_ID = I7.ICS_FAC_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
       WHERE ICS_GNRL_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'GeneralPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission');


-- /ICS_GNRL_PRMT/ICS_FAC/ICS_CONTACT/ICS_TELEPH
INSERT INTO ics_flow_icis.ICS_TELEPH
     SELECT I9.*
              from ICS_GNRL_PRMT ICS_GNRL_PRMT 
 JOIN ICS_FAC I7
 ON I7.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID 
 JOIN ICS_CONTACT I8
 ON I8.ICS_FAC_ID = I7.ICS_FAC_ID 
 JOIN ICS_TELEPH I9
 ON I9.ICS_CONTACT_ID = I8.ICS_CONTACT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
       WHERE ICS_GNRL_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'GeneralPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission');


-- /ICS_GNRL_PRMT/ICS_FAC/ICS_ORIG_PROGS
INSERT INTO ics_flow_icis.ICS_ORIG_PROGS
     SELECT I10.*
              from ICS_GNRL_PRMT ICS_GNRL_PRMT 
 JOIN ICS_FAC I7
 ON I7.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID 
 JOIN ICS_ORIG_PROGS I10
 ON I10.ICS_FAC_ID = I7.ICS_FAC_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
       WHERE ICS_GNRL_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'GeneralPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission');


-- /ICS_GNRL_PRMT/ICS_FAC/ICS_PLCY
INSERT INTO ics_flow_icis.ICS_PLCY
     SELECT I11.*
              from ICS_GNRL_PRMT ICS_GNRL_PRMT 
 JOIN ICS_FAC I7
 ON I7.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID 
 JOIN ICS_PLCY I11
 ON I11.ICS_FAC_ID = I7.ICS_FAC_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
       WHERE ICS_GNRL_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'GeneralPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission');


-- /ICS_GNRL_PRMT/ICS_FAC/ICS_FAC_CLASS
INSERT INTO ics_flow_icis.ICS_FAC_CLASS
     SELECT I12.*
              from ICS_GNRL_PRMT ICS_GNRL_PRMT 
 JOIN ICS_FAC I7
 ON I7.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID 
 JOIN ICS_FAC_CLASS I12
 ON I12.ICS_FAC_ID = I7.ICS_FAC_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
       WHERE ICS_GNRL_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'GeneralPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission');


-- /ICS_GNRL_PRMT/ICS_FAC/ICS_GEO_COORD
INSERT INTO ics_flow_icis.ICS_GEO_COORD
     SELECT I13.*
              from ICS_GNRL_PRMT ICS_GNRL_PRMT 
 JOIN ICS_FAC I7
 ON I7.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID 
 JOIN ICS_GEO_COORD I13
 ON I13.ICS_FAC_ID = I7.ICS_FAC_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
       WHERE ICS_GNRL_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'GeneralPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission');


-- /ICS_GNRL_PRMT/ICS_FAC/ICS_SIC_CODE
INSERT INTO ics_flow_icis.ICS_SIC_CODE
     SELECT I14.*
              from ICS_GNRL_PRMT ICS_GNRL_PRMT 
 JOIN ICS_FAC I7
 ON I7.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID 
 JOIN ICS_SIC_CODE I14
 ON I14.ICS_FAC_ID = I7.ICS_FAC_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
       WHERE ICS_GNRL_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'GeneralPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission');


-- /ICS_GNRL_PRMT/ICS_FAC/ICS_ADDR
INSERT INTO ics_flow_icis.ICS_ADDR
     SELECT I15.*
              from ICS_GNRL_PRMT ICS_GNRL_PRMT 
 JOIN ICS_FAC I7
 ON I7.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID 
 JOIN ICS_ADDR I15
 ON I15.ICS_FAC_ID = I7.ICS_FAC_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
       WHERE ICS_GNRL_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'GeneralPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission');


-- /ICS_GNRL_PRMT/ICS_FAC/ICS_ADDR/ICS_TELEPH
INSERT INTO ics_flow_icis.ICS_TELEPH
     SELECT I16.*
              from ICS_GNRL_PRMT ICS_GNRL_PRMT 
 JOIN ICS_FAC I7
 ON I7.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID 
 JOIN ICS_ADDR I15
 ON I15.ICS_FAC_ID = I7.ICS_FAC_ID 
 JOIN ICS_TELEPH I16
 ON I16.ICS_ADDR_ID = I15.ICS_ADDR_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
       WHERE ICS_GNRL_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'GeneralPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission');


-- /ICS_GNRL_PRMT/ICS_FAC/ICS_NAICS_CODE
INSERT INTO ics_flow_icis.ICS_NAICS_CODE
     SELECT I17.*
              from ICS_GNRL_PRMT ICS_GNRL_PRMT 
 JOIN ICS_FAC I7
 ON I7.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID 
 JOIN ICS_NAICS_CODE I17
 ON I17.ICS_FAC_ID = I7.ICS_FAC_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
       WHERE ICS_GNRL_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'GeneralPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission');


-- /ICS_GNRL_PRMT/ICS_REP_NON_CMPL_STAT
INSERT INTO ics_flow_icis.ICS_REP_NON_CMPL_STAT
     SELECT I18.*
              from ICS_GNRL_PRMT ICS_GNRL_PRMT 
 JOIN ICS_REP_NON_CMPL_STAT I18
 ON I18.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
       WHERE ICS_GNRL_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'GeneralPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission');


-- /ICS_GNRL_PRMT/ICS_RESIDUAL_DESGN_DTRMN
INSERT INTO ics_flow_icis.ICS_RESIDUAL_DESGN_DTRMN
     SELECT I19.*
              from ICS_GNRL_PRMT ICS_GNRL_PRMT 
 JOIN ICS_RESIDUAL_DESGN_DTRMN I19
 ON I19.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
       WHERE ICS_GNRL_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'GeneralPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission');


-- /ICS_GNRL_PRMT/ICS_SIC_CODE
INSERT INTO ics_flow_icis.ICS_SIC_CODE
     SELECT I20.*
              from ICS_GNRL_PRMT ICS_GNRL_PRMT 
 JOIN ICS_SIC_CODE I20
 ON I20.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
       WHERE ICS_GNRL_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'GeneralPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission');


-- /ICS_GNRL_PRMT/ICS_ADDR
INSERT INTO ics_flow_icis.ICS_ADDR
     SELECT I21.*
              from ICS_GNRL_PRMT ICS_GNRL_PRMT 
 JOIN ICS_ADDR I21
 ON I21.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
       WHERE ICS_GNRL_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'GeneralPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission');


-- /ICS_GNRL_PRMT/ICS_ADDR/ICS_TELEPH
INSERT INTO ics_flow_icis.ICS_TELEPH
     SELECT I22.*
              from ICS_GNRL_PRMT ICS_GNRL_PRMT 
 JOIN ICS_ADDR I21
 ON I21.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID 
 JOIN ICS_TELEPH I22
 ON I22.ICS_ADDR_ID = I21.ICS_ADDR_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
       WHERE ICS_GNRL_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'GeneralPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission');


-- /ICS_GNRL_PRMT/ICS_ASSC_PRMT
INSERT INTO ics_flow_icis.ICS_ASSC_PRMT
     SELECT I23.*
              from ICS_GNRL_PRMT ICS_GNRL_PRMT 
 JOIN ICS_ASSC_PRMT I23
 ON I23.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
       WHERE ICS_GNRL_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'GeneralPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission');


-- /ICS_GNRL_PRMT/ICS_CMPL_TRACK_STAT
INSERT INTO ics_flow_icis.ICS_CMPL_TRACK_STAT
     SELECT I24.*
              from ICS_GNRL_PRMT ICS_GNRL_PRMT 
 JOIN ICS_CMPL_TRACK_STAT I24
 ON I24.ICS_GNRL_PRMT_ID = ICS_GNRL_PRMT.ICS_GNRL_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH
       WHERE ICS_GNRL_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'GeneralPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'GeneralPermitSubmission');
	




-- Remove any old records for ICS_HIST_PRMT_SCHD_EVTS
				
-- /ICS_HIST_PRMT_SCHD_EVTS
DELETE
  FROM ics_flow_icis.ICS_HIST_PRMT_SCHD_EVTS
 WHERE ICS_HIST_PRMT_SCHD_EVTS.ICS_HIST_PRMT_SCHD_EVTS_ID IN
          (SELECT ICS_HIST_PRMT_SCHD_EVTS.ICS_HIST_PRMT_SCHD_EVTS_ID
              from ics_flow_icis.ICS_HIST_PRMT_SCHD_EVTS ICS_HIST_PRMT_SCHD_EVTS 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_HIST_PRMT_SCHD_EVTS.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'HistoricalPermitScheduleEventsSubmission')
                  OR ICS_HIST_PRMT_SCHD_EVTS.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

	
-- Add accepted records for ICS_HIST_PRMT_SCHD_EVTS


-- /ICS_HIST_PRMT_SCHD_EVTS
INSERT INTO ics_flow_icis.ICS_HIST_PRMT_SCHD_EVTS
     SELECT ICS_HIST_PRMT_SCHD_EVTS.*
              from ICS_HIST_PRMT_SCHD_EVTS ICS_HIST_PRMT_SCHD_EVTS 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_HIST_PRMT_SCHD_EVTS.KEY_HASH
       WHERE ICS_HIST_PRMT_SCHD_EVTS.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'HistoricalPermitScheduleEventsSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'HistoricalPermitScheduleEventsSubmission');
	




-- Remove any old records for ICS_INFRML_ENFRC_ACTN
				
-- /ICS_INFRML_ENFRC_ACTN/ICS_PROGS_VIOL
DELETE
  FROM ics_flow_icis.ICS_PROGS_VIOL
 WHERE ICS_PROGS_VIOL.ICS_INFRML_ENFRC_ACTN_ID IN
          (SELECT I4.ICS_INFRML_ENFRC_ACTN_ID
              from ics_flow_icis.ICS_INFRML_ENFRC_ACTN ICS_INFRML_ENFRC_ACTN 
 JOIN ics_flow_icis.ICS_PROGS_VIOL I4
 ON I4.ICS_INFRML_ENFRC_ACTN_ID = ICS_INFRML_ENFRC_ACTN.ICS_INFRML_ENFRC_ACTN_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_INFRML_ENFRC_ACTN.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'InformalEnforcementActionSubmission')
                 
                 
);

				
-- /ICS_INFRML_ENFRC_ACTN/ICS_ENFRC_AGNCY
DELETE
  FROM ics_flow_icis.ICS_ENFRC_AGNCY
 WHERE ICS_ENFRC_AGNCY.ICS_INFRML_ENFRC_ACTN_ID IN
          (SELECT I3.ICS_INFRML_ENFRC_ACTN_ID
              from ics_flow_icis.ICS_INFRML_ENFRC_ACTN ICS_INFRML_ENFRC_ACTN 
 JOIN ics_flow_icis.ICS_ENFRC_AGNCY I3
 ON I3.ICS_INFRML_ENFRC_ACTN_ID = ICS_INFRML_ENFRC_ACTN.ICS_INFRML_ENFRC_ACTN_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_INFRML_ENFRC_ACTN.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'InformalEnforcementActionSubmission')
                 
                 
);

				
-- /ICS_INFRML_ENFRC_ACTN/ICS_ENFRC_ACTN_GOV_CONTACT
DELETE
  FROM ics_flow_icis.ICS_ENFRC_ACTN_GOV_CONTACT
 WHERE ICS_ENFRC_ACTN_GOV_CONTACT.ICS_INFRML_ENFRC_ACTN_ID IN
          (SELECT I2.ICS_INFRML_ENFRC_ACTN_ID
              from ics_flow_icis.ICS_INFRML_ENFRC_ACTN ICS_INFRML_ENFRC_ACTN 
 JOIN ics_flow_icis.ICS_ENFRC_ACTN_GOV_CONTACT I2
 ON I2.ICS_INFRML_ENFRC_ACTN_ID = ICS_INFRML_ENFRC_ACTN.ICS_INFRML_ENFRC_ACTN_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_INFRML_ENFRC_ACTN.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'InformalEnforcementActionSubmission')
                 
                 
);

				
-- /ICS_INFRML_ENFRC_ACTN/ICS_PRMT_IDENT
DELETE
  FROM ics_flow_icis.ICS_PRMT_IDENT
 WHERE ICS_PRMT_IDENT.ICS_INFRML_ENFRC_ACTN_ID IN
          (SELECT I1.ICS_INFRML_ENFRC_ACTN_ID
              from ics_flow_icis.ICS_INFRML_ENFRC_ACTN ICS_INFRML_ENFRC_ACTN 
 JOIN ics_flow_icis.ICS_PRMT_IDENT I1
 ON I1.ICS_INFRML_ENFRC_ACTN_ID = ICS_INFRML_ENFRC_ACTN.ICS_INFRML_ENFRC_ACTN_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_INFRML_ENFRC_ACTN.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'InformalEnforcementActionSubmission')
                 
                 
);

				
-- /ICS_INFRML_ENFRC_ACTN
DELETE
  FROM ics_flow_icis.ICS_INFRML_ENFRC_ACTN
 WHERE ICS_INFRML_ENFRC_ACTN.ICS_INFRML_ENFRC_ACTN_ID IN
          (SELECT ICS_INFRML_ENFRC_ACTN.ICS_INFRML_ENFRC_ACTN_ID
              from ics_flow_icis.ICS_INFRML_ENFRC_ACTN ICS_INFRML_ENFRC_ACTN 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_INFRML_ENFRC_ACTN.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'InformalEnforcementActionSubmission')
                 
                 
);

	
-- Add accepted records for ICS_INFRML_ENFRC_ACTN


-- /ICS_INFRML_ENFRC_ACTN
INSERT INTO ics_flow_icis.ICS_INFRML_ENFRC_ACTN
     SELECT ICS_INFRML_ENFRC_ACTN.*
              from ICS_INFRML_ENFRC_ACTN ICS_INFRML_ENFRC_ACTN 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_INFRML_ENFRC_ACTN.KEY_HASH
       WHERE ICS_INFRML_ENFRC_ACTN.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'InformalEnforcementActionSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'InformalEnforcementActionSubmission');


-- /ICS_INFRML_ENFRC_ACTN/ICS_PRMT_IDENT
INSERT INTO ics_flow_icis.ICS_PRMT_IDENT
     SELECT I1.*
              from ICS_INFRML_ENFRC_ACTN ICS_INFRML_ENFRC_ACTN 
 JOIN ICS_PRMT_IDENT I1
 ON I1.ICS_INFRML_ENFRC_ACTN_ID = ICS_INFRML_ENFRC_ACTN.ICS_INFRML_ENFRC_ACTN_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_INFRML_ENFRC_ACTN.KEY_HASH
       WHERE ICS_INFRML_ENFRC_ACTN.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'InformalEnforcementActionSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'InformalEnforcementActionSubmission');


-- /ICS_INFRML_ENFRC_ACTN/ICS_ENFRC_ACTN_GOV_CONTACT
INSERT INTO ics_flow_icis.ICS_ENFRC_ACTN_GOV_CONTACT
     SELECT I2.*
              from ICS_INFRML_ENFRC_ACTN ICS_INFRML_ENFRC_ACTN 
 JOIN ICS_ENFRC_ACTN_GOV_CONTACT I2
 ON I2.ICS_INFRML_ENFRC_ACTN_ID = ICS_INFRML_ENFRC_ACTN.ICS_INFRML_ENFRC_ACTN_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_INFRML_ENFRC_ACTN.KEY_HASH
       WHERE ICS_INFRML_ENFRC_ACTN.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'InformalEnforcementActionSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'InformalEnforcementActionSubmission');


-- /ICS_INFRML_ENFRC_ACTN/ICS_ENFRC_AGNCY
INSERT INTO ics_flow_icis.ICS_ENFRC_AGNCY
     SELECT I3.*
              from ICS_INFRML_ENFRC_ACTN ICS_INFRML_ENFRC_ACTN 
 JOIN ICS_ENFRC_AGNCY I3
 ON I3.ICS_INFRML_ENFRC_ACTN_ID = ICS_INFRML_ENFRC_ACTN.ICS_INFRML_ENFRC_ACTN_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_INFRML_ENFRC_ACTN.KEY_HASH
       WHERE ICS_INFRML_ENFRC_ACTN.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'InformalEnforcementActionSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'InformalEnforcementActionSubmission');


-- /ICS_INFRML_ENFRC_ACTN/ICS_PROGS_VIOL
INSERT INTO ics_flow_icis.ICS_PROGS_VIOL
     SELECT I4.*
              from ICS_INFRML_ENFRC_ACTN ICS_INFRML_ENFRC_ACTN 
 JOIN ICS_PROGS_VIOL I4
 ON I4.ICS_INFRML_ENFRC_ACTN_ID = ICS_INFRML_ENFRC_ACTN.ICS_INFRML_ENFRC_ACTN_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_INFRML_ENFRC_ACTN.KEY_HASH
       WHERE ICS_INFRML_ENFRC_ACTN.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'InformalEnforcementActionSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'InformalEnforcementActionSubmission');
	




-- Remove any old records for ICS_LMTS
				
-- /ICS_LMTS/ICS_MN_LMT_APPLIES
DELETE
  FROM ics_flow_icis.ICS_MN_LMT_APPLIES
 WHERE ICS_MN_LMT_APPLIES.ICS_LMTS_ID IN
          (SELECT I2.ICS_LMTS_ID
              from ics_flow_icis.ICS_LMTS ICS_LMTS 
 JOIN ics_flow_icis.ICS_MN_LMT_APPLIES I2
 ON I2.ICS_LMTS_ID = ICS_LMTS.ICS_LMTS_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_LMTS.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'LimitsSubmission')
                  OR ICS_LMTS.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_LMTS.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_LMTS/ICS_NUM_COND
DELETE
  FROM ics_flow_icis.ICS_NUM_COND
 WHERE ICS_NUM_COND.ICS_LMTS_ID IN
          (SELECT I1.ICS_LMTS_ID
              from ics_flow_icis.ICS_LMTS ICS_LMTS 
 JOIN ics_flow_icis.ICS_NUM_COND I1
 ON I1.ICS_LMTS_ID = ICS_LMTS.ICS_LMTS_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_LMTS.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'LimitsSubmission')
                  OR ICS_LMTS.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_LMTS.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_LMTS
DELETE
  FROM ics_flow_icis.ICS_LMTS
 WHERE ICS_LMTS.ICS_LMTS_ID IN
          (SELECT ICS_LMTS.ICS_LMTS_ID
              from ics_flow_icis.ICS_LMTS ICS_LMTS 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_LMTS.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'LimitsSubmission')
                  OR ICS_LMTS.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_LMTS.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

	
-- Add accepted records for ICS_LMTS


-- /ICS_LMTS
INSERT INTO ics_flow_icis.ICS_LMTS
     SELECT ICS_LMTS.*
              from ICS_LMTS ICS_LMTS 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_LMTS.KEY_HASH
       WHERE ICS_LMTS.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'LimitsSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'LimitsSubmission');


-- /ICS_LMTS/ICS_NUM_COND
INSERT INTO ics_flow_icis.ICS_NUM_COND
     SELECT I1.*
              from ICS_LMTS ICS_LMTS 
 JOIN ICS_NUM_COND I1
 ON I1.ICS_LMTS_ID = ICS_LMTS.ICS_LMTS_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_LMTS.KEY_HASH
       WHERE ICS_LMTS.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'LimitsSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'LimitsSubmission');


-- /ICS_LMTS/ICS_MN_LMT_APPLIES
INSERT INTO ics_flow_icis.ICS_MN_LMT_APPLIES
     SELECT I2.*
              from ICS_LMTS ICS_LMTS 
 JOIN ICS_MN_LMT_APPLIES I2
 ON I2.ICS_LMTS_ID = ICS_LMTS.ICS_LMTS_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_LMTS.KEY_HASH
       WHERE ICS_LMTS.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'LimitsSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'LimitsSubmission');
	




-- Remove any old records for ICS_LMT_SET
				
-- /ICS_LMT_SET/ICS_LMT_SET_STAT
DELETE
  FROM ics_flow_icis.ICS_LMT_SET_STAT
 WHERE ICS_LMT_SET_STAT.ICS_LMT_SET_ID IN
          (SELECT I3.ICS_LMT_SET_ID
              from ics_flow_icis.ICS_LMT_SET ICS_LMT_SET 
 JOIN ics_flow_icis.ICS_LMT_SET_STAT I3
 ON I3.ICS_LMT_SET_ID = ICS_LMT_SET.ICS_LMT_SET_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_LMT_SET.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'LimitSetSubmission')
                  OR ICS_LMT_SET.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_LMT_SET.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_LMT_SET/ICS_LMT_SET_SCHD
DELETE
  FROM ics_flow_icis.ICS_LMT_SET_SCHD
 WHERE ICS_LMT_SET_SCHD.ICS_LMT_SET_ID IN
          (SELECT I2.ICS_LMT_SET_ID
              from ics_flow_icis.ICS_LMT_SET ICS_LMT_SET 
 JOIN ics_flow_icis.ICS_LMT_SET_SCHD I2
 ON I2.ICS_LMT_SET_ID = ICS_LMT_SET.ICS_LMT_SET_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_LMT_SET.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'LimitSetSubmission')
                  OR ICS_LMT_SET.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_LMT_SET.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_LMT_SET/ICS_LMT_SET_MONTHS_APPL
DELETE
  FROM ics_flow_icis.ICS_LMT_SET_MONTHS_APPL
 WHERE ICS_LMT_SET_MONTHS_APPL.ICS_LMT_SET_ID IN
          (SELECT I1.ICS_LMT_SET_ID
              from ics_flow_icis.ICS_LMT_SET ICS_LMT_SET 
 JOIN ics_flow_icis.ICS_LMT_SET_MONTHS_APPL I1
 ON I1.ICS_LMT_SET_ID = ICS_LMT_SET.ICS_LMT_SET_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_LMT_SET.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'LimitSetSubmission')
                  OR ICS_LMT_SET.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_LMT_SET.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_LMT_SET
DELETE
  FROM ics_flow_icis.ICS_LMT_SET
 WHERE ICS_LMT_SET.ICS_LMT_SET_ID IN
          (SELECT ICS_LMT_SET.ICS_LMT_SET_ID
              from ics_flow_icis.ICS_LMT_SET ICS_LMT_SET 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_LMT_SET.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'LimitSetSubmission')
                  OR ICS_LMT_SET.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_LMT_SET.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

	
-- Add accepted records for ICS_LMT_SET


-- /ICS_LMT_SET
INSERT INTO ics_flow_icis.ICS_LMT_SET
     SELECT ICS_LMT_SET.*
              from ICS_LMT_SET ICS_LMT_SET 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_LMT_SET.KEY_HASH
       WHERE ICS_LMT_SET.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'LimitSetSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'LimitSetSubmission');


-- /ICS_LMT_SET/ICS_LMT_SET_MONTHS_APPL
INSERT INTO ics_flow_icis.ICS_LMT_SET_MONTHS_APPL
     SELECT I1.*
              from ICS_LMT_SET ICS_LMT_SET 
 JOIN ICS_LMT_SET_MONTHS_APPL I1
 ON I1.ICS_LMT_SET_ID = ICS_LMT_SET.ICS_LMT_SET_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_LMT_SET.KEY_HASH
       WHERE ICS_LMT_SET.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'LimitSetSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'LimitSetSubmission');


-- /ICS_LMT_SET/ICS_LMT_SET_SCHD
INSERT INTO ics_flow_icis.ICS_LMT_SET_SCHD
     SELECT I2.*
              from ICS_LMT_SET ICS_LMT_SET 
 JOIN ICS_LMT_SET_SCHD I2
 ON I2.ICS_LMT_SET_ID = ICS_LMT_SET.ICS_LMT_SET_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_LMT_SET.KEY_HASH
       WHERE ICS_LMT_SET.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'LimitSetSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'LimitSetSubmission');


-- /ICS_LMT_SET/ICS_LMT_SET_STAT
INSERT INTO ics_flow_icis.ICS_LMT_SET_STAT
     SELECT I3.*
              from ICS_LMT_SET ICS_LMT_SET 
 JOIN ICS_LMT_SET_STAT I3
 ON I3.ICS_LMT_SET_ID = ICS_LMT_SET.ICS_LMT_SET_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_LMT_SET.KEY_HASH
       WHERE ICS_LMT_SET.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'LimitSetSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'LimitSetSubmission');
	




-- Remove any old records for ICS_MASTER_GNRL_PRMT
				
-- /ICS_MASTER_GNRL_PRMT/ICS_ASSC_PRMT
DELETE
  FROM ics_flow_icis.ICS_ASSC_PRMT
 WHERE ICS_ASSC_PRMT.ICS_MASTER_GNRL_PRMT_ID IN
          (SELECT I8.ICS_MASTER_GNRL_PRMT_ID
              from ics_flow_icis.ICS_MASTER_GNRL_PRMT ICS_MASTER_GNRL_PRMT 
 JOIN ics_flow_icis.ICS_ASSC_PRMT I8
 ON I8.ICS_MASTER_GNRL_PRMT_ID = ICS_MASTER_GNRL_PRMT.ICS_MASTER_GNRL_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_MASTER_GNRL_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'MasterGeneralPermitSubmission')
                  OR ICS_MASTER_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_MASTER_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_MASTER_GNRL_PRMT/ICS_SIC_CODE
DELETE
  FROM ics_flow_icis.ICS_SIC_CODE
 WHERE ICS_SIC_CODE.ICS_MASTER_GNRL_PRMT_ID IN
          (SELECT I7.ICS_MASTER_GNRL_PRMT_ID
              from ics_flow_icis.ICS_MASTER_GNRL_PRMT ICS_MASTER_GNRL_PRMT 
 JOIN ics_flow_icis.ICS_SIC_CODE I7
 ON I7.ICS_MASTER_GNRL_PRMT_ID = ICS_MASTER_GNRL_PRMT.ICS_MASTER_GNRL_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_MASTER_GNRL_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'MasterGeneralPermitSubmission')
                  OR ICS_MASTER_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_MASTER_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_MASTER_GNRL_PRMT/ICS_RESIDUAL_DESGN_DTRMN
DELETE
  FROM ics_flow_icis.ICS_RESIDUAL_DESGN_DTRMN
 WHERE ICS_RESIDUAL_DESGN_DTRMN.ICS_MASTER_GNRL_PRMT_ID IN
          (SELECT I6.ICS_MASTER_GNRL_PRMT_ID
              from ics_flow_icis.ICS_MASTER_GNRL_PRMT ICS_MASTER_GNRL_PRMT 
 JOIN ics_flow_icis.ICS_RESIDUAL_DESGN_DTRMN I6
 ON I6.ICS_MASTER_GNRL_PRMT_ID = ICS_MASTER_GNRL_PRMT.ICS_MASTER_GNRL_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_MASTER_GNRL_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'MasterGeneralPermitSubmission')
                  OR ICS_MASTER_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_MASTER_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_MASTER_GNRL_PRMT/ICS_PRMT_COMP_TYPE
DELETE
  FROM ics_flow_icis.ICS_PRMT_COMP_TYPE
 WHERE ICS_PRMT_COMP_TYPE.ICS_MASTER_GNRL_PRMT_ID IN
          (SELECT I5.ICS_MASTER_GNRL_PRMT_ID
              from ics_flow_icis.ICS_MASTER_GNRL_PRMT ICS_MASTER_GNRL_PRMT 
 JOIN ics_flow_icis.ICS_PRMT_COMP_TYPE I5
 ON I5.ICS_MASTER_GNRL_PRMT_ID = ICS_MASTER_GNRL_PRMT.ICS_MASTER_GNRL_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_MASTER_GNRL_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'MasterGeneralPermitSubmission')
                  OR ICS_MASTER_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_MASTER_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_MASTER_GNRL_PRMT/ICS_OTHR_PRMTS
DELETE
  FROM ics_flow_icis.ICS_OTHR_PRMTS
 WHERE ICS_OTHR_PRMTS.ICS_MASTER_GNRL_PRMT_ID IN
          (SELECT I4.ICS_MASTER_GNRL_PRMT_ID
              from ics_flow_icis.ICS_MASTER_GNRL_PRMT ICS_MASTER_GNRL_PRMT 
 JOIN ics_flow_icis.ICS_OTHR_PRMTS I4
 ON I4.ICS_MASTER_GNRL_PRMT_ID = ICS_MASTER_GNRL_PRMT.ICS_MASTER_GNRL_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_MASTER_GNRL_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'MasterGeneralPermitSubmission')
                  OR ICS_MASTER_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_MASTER_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_MASTER_GNRL_PRMT/ICS_CONTACT/ICS_TELEPH
DELETE
  FROM ics_flow_icis.ICS_TELEPH
 WHERE ICS_TELEPH.ICS_CONTACT_ID IN
          (SELECT I3.ICS_CONTACT_ID
              from ics_flow_icis.ICS_MASTER_GNRL_PRMT ICS_MASTER_GNRL_PRMT 
 JOIN ics_flow_icis.ICS_CONTACT I2
 ON I2.ICS_MASTER_GNRL_PRMT_ID = ICS_MASTER_GNRL_PRMT.ICS_MASTER_GNRL_PRMT_ID 
 JOIN ics_flow_icis.ICS_TELEPH I3
 ON I3.ICS_CONTACT_ID = I2.ICS_CONTACT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_MASTER_GNRL_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'MasterGeneralPermitSubmission')
                  OR ICS_MASTER_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_MASTER_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_MASTER_GNRL_PRMT/ICS_CONTACT
DELETE
  FROM ics_flow_icis.ICS_CONTACT
 WHERE ICS_CONTACT.ICS_MASTER_GNRL_PRMT_ID IN
          (SELECT I2.ICS_MASTER_GNRL_PRMT_ID
              from ics_flow_icis.ICS_MASTER_GNRL_PRMT ICS_MASTER_GNRL_PRMT 
 JOIN ics_flow_icis.ICS_CONTACT I2
 ON I2.ICS_MASTER_GNRL_PRMT_ID = ICS_MASTER_GNRL_PRMT.ICS_MASTER_GNRL_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_MASTER_GNRL_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'MasterGeneralPermitSubmission')
                  OR ICS_MASTER_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_MASTER_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_MASTER_GNRL_PRMT/ICS_NAICS_CODE
DELETE
  FROM ics_flow_icis.ICS_NAICS_CODE
 WHERE ICS_NAICS_CODE.ICS_MASTER_GNRL_PRMT_ID IN
          (SELECT I1.ICS_MASTER_GNRL_PRMT_ID
              from ics_flow_icis.ICS_MASTER_GNRL_PRMT ICS_MASTER_GNRL_PRMT 
 JOIN ics_flow_icis.ICS_NAICS_CODE I1
 ON I1.ICS_MASTER_GNRL_PRMT_ID = ICS_MASTER_GNRL_PRMT.ICS_MASTER_GNRL_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_MASTER_GNRL_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'MasterGeneralPermitSubmission')
                  OR ICS_MASTER_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_MASTER_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_MASTER_GNRL_PRMT
DELETE
  FROM ics_flow_icis.ICS_MASTER_GNRL_PRMT
 WHERE ICS_MASTER_GNRL_PRMT.ICS_MASTER_GNRL_PRMT_ID IN
          (SELECT ICS_MASTER_GNRL_PRMT.ICS_MASTER_GNRL_PRMT_ID
              from ics_flow_icis.ICS_MASTER_GNRL_PRMT ICS_MASTER_GNRL_PRMT 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_MASTER_GNRL_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'MasterGeneralPermitSubmission')
                  OR ICS_MASTER_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_MASTER_GNRL_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

	
-- Add accepted records for ICS_MASTER_GNRL_PRMT


-- /ICS_MASTER_GNRL_PRMT
INSERT INTO ics_flow_icis.ICS_MASTER_GNRL_PRMT
     SELECT ICS_MASTER_GNRL_PRMT.*
              from ICS_MASTER_GNRL_PRMT ICS_MASTER_GNRL_PRMT 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_MASTER_GNRL_PRMT.KEY_HASH
       WHERE ICS_MASTER_GNRL_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'MasterGeneralPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'MasterGeneralPermitSubmission');


-- /ICS_MASTER_GNRL_PRMT/ICS_NAICS_CODE
INSERT INTO ics_flow_icis.ICS_NAICS_CODE
     SELECT I1.*
              from ICS_MASTER_GNRL_PRMT ICS_MASTER_GNRL_PRMT 
 JOIN ICS_NAICS_CODE I1
 ON I1.ICS_MASTER_GNRL_PRMT_ID = ICS_MASTER_GNRL_PRMT.ICS_MASTER_GNRL_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_MASTER_GNRL_PRMT.KEY_HASH
       WHERE ICS_MASTER_GNRL_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'MasterGeneralPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'MasterGeneralPermitSubmission');


-- /ICS_MASTER_GNRL_PRMT/ICS_CONTACT
INSERT INTO ics_flow_icis.ICS_CONTACT
     SELECT I2.*
              from ICS_MASTER_GNRL_PRMT ICS_MASTER_GNRL_PRMT 
 JOIN ICS_CONTACT I2
 ON I2.ICS_MASTER_GNRL_PRMT_ID = ICS_MASTER_GNRL_PRMT.ICS_MASTER_GNRL_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_MASTER_GNRL_PRMT.KEY_HASH
       WHERE ICS_MASTER_GNRL_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'MasterGeneralPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'MasterGeneralPermitSubmission');


-- /ICS_MASTER_GNRL_PRMT/ICS_CONTACT/ICS_TELEPH
INSERT INTO ics_flow_icis.ICS_TELEPH
     SELECT I3.*
              from ICS_MASTER_GNRL_PRMT ICS_MASTER_GNRL_PRMT 
 JOIN ICS_CONTACT I2
 ON I2.ICS_MASTER_GNRL_PRMT_ID = ICS_MASTER_GNRL_PRMT.ICS_MASTER_GNRL_PRMT_ID 
 JOIN ICS_TELEPH I3
 ON I3.ICS_CONTACT_ID = I2.ICS_CONTACT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_MASTER_GNRL_PRMT.KEY_HASH
       WHERE ICS_MASTER_GNRL_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'MasterGeneralPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'MasterGeneralPermitSubmission');


-- /ICS_MASTER_GNRL_PRMT/ICS_OTHR_PRMTS
INSERT INTO ics_flow_icis.ICS_OTHR_PRMTS
     SELECT I4.*
              from ICS_MASTER_GNRL_PRMT ICS_MASTER_GNRL_PRMT 
 JOIN ICS_OTHR_PRMTS I4
 ON I4.ICS_MASTER_GNRL_PRMT_ID = ICS_MASTER_GNRL_PRMT.ICS_MASTER_GNRL_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_MASTER_GNRL_PRMT.KEY_HASH
       WHERE ICS_MASTER_GNRL_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'MasterGeneralPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'MasterGeneralPermitSubmission');


-- /ICS_MASTER_GNRL_PRMT/ICS_PRMT_COMP_TYPE
INSERT INTO ics_flow_icis.ICS_PRMT_COMP_TYPE
     SELECT I5.*
              from ICS_MASTER_GNRL_PRMT ICS_MASTER_GNRL_PRMT 
 JOIN ICS_PRMT_COMP_TYPE I5
 ON I5.ICS_MASTER_GNRL_PRMT_ID = ICS_MASTER_GNRL_PRMT.ICS_MASTER_GNRL_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_MASTER_GNRL_PRMT.KEY_HASH
       WHERE ICS_MASTER_GNRL_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'MasterGeneralPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'MasterGeneralPermitSubmission');


-- /ICS_MASTER_GNRL_PRMT/ICS_RESIDUAL_DESGN_DTRMN
INSERT INTO ics_flow_icis.ICS_RESIDUAL_DESGN_DTRMN
     SELECT I6.*
              from ICS_MASTER_GNRL_PRMT ICS_MASTER_GNRL_PRMT 
 JOIN ICS_RESIDUAL_DESGN_DTRMN I6
 ON I6.ICS_MASTER_GNRL_PRMT_ID = ICS_MASTER_GNRL_PRMT.ICS_MASTER_GNRL_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_MASTER_GNRL_PRMT.KEY_HASH
       WHERE ICS_MASTER_GNRL_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'MasterGeneralPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'MasterGeneralPermitSubmission');


-- /ICS_MASTER_GNRL_PRMT/ICS_SIC_CODE
INSERT INTO ics_flow_icis.ICS_SIC_CODE
     SELECT I7.*
              from ICS_MASTER_GNRL_PRMT ICS_MASTER_GNRL_PRMT 
 JOIN ICS_SIC_CODE I7
 ON I7.ICS_MASTER_GNRL_PRMT_ID = ICS_MASTER_GNRL_PRMT.ICS_MASTER_GNRL_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_MASTER_GNRL_PRMT.KEY_HASH
       WHERE ICS_MASTER_GNRL_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'MasterGeneralPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'MasterGeneralPermitSubmission');


-- /ICS_MASTER_GNRL_PRMT/ICS_ASSC_PRMT
INSERT INTO ics_flow_icis.ICS_ASSC_PRMT
     SELECT I8.*
              from ICS_MASTER_GNRL_PRMT ICS_MASTER_GNRL_PRMT 
 JOIN ICS_ASSC_PRMT I8
 ON I8.ICS_MASTER_GNRL_PRMT_ID = ICS_MASTER_GNRL_PRMT.ICS_MASTER_GNRL_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_MASTER_GNRL_PRMT.KEY_HASH
       WHERE ICS_MASTER_GNRL_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'MasterGeneralPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'MasterGeneralPermitSubmission');
	




-- Remove any old records for ICS_NARR_COND_SCHD
				
-- /ICS_NARR_COND_SCHD/ICS_PRMT_SCHD_EVT
DELETE
  FROM ics_flow_icis.ICS_PRMT_SCHD_EVT
 WHERE ICS_PRMT_SCHD_EVT.ICS_NARR_COND_SCHD_ID IN
          (SELECT I1.ICS_NARR_COND_SCHD_ID
              from ics_flow_icis.ICS_NARR_COND_SCHD ICS_NARR_COND_SCHD 
 JOIN ics_flow_icis.ICS_PRMT_SCHD_EVT I1
 ON I1.ICS_NARR_COND_SCHD_ID = ICS_NARR_COND_SCHD.ICS_NARR_COND_SCHD_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_NARR_COND_SCHD.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'NarrativeConditionScheduleSubmission')
                  OR ICS_NARR_COND_SCHD.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_NARR_COND_SCHD.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_NARR_COND_SCHD
DELETE
  FROM ics_flow_icis.ICS_NARR_COND_SCHD
 WHERE ICS_NARR_COND_SCHD.ICS_NARR_COND_SCHD_ID IN
          (SELECT ICS_NARR_COND_SCHD.ICS_NARR_COND_SCHD_ID
              from ics_flow_icis.ICS_NARR_COND_SCHD ICS_NARR_COND_SCHD 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_NARR_COND_SCHD.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'NarrativeConditionScheduleSubmission')
                  OR ICS_NARR_COND_SCHD.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_NARR_COND_SCHD.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

	
-- Add accepted records for ICS_NARR_COND_SCHD


-- /ICS_NARR_COND_SCHD
INSERT INTO ics_flow_icis.ICS_NARR_COND_SCHD
     SELECT ICS_NARR_COND_SCHD.*
              from ICS_NARR_COND_SCHD ICS_NARR_COND_SCHD 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_NARR_COND_SCHD.KEY_HASH
       WHERE ICS_NARR_COND_SCHD.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'NarrativeConditionScheduleSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'NarrativeConditionScheduleSubmission');


-- /ICS_NARR_COND_SCHD/ICS_PRMT_SCHD_EVT
INSERT INTO ics_flow_icis.ICS_PRMT_SCHD_EVT
     SELECT I1.*
              from ICS_NARR_COND_SCHD ICS_NARR_COND_SCHD 
 JOIN ICS_PRMT_SCHD_EVT I1
 ON I1.ICS_NARR_COND_SCHD_ID = ICS_NARR_COND_SCHD.ICS_NARR_COND_SCHD_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_NARR_COND_SCHD.KEY_HASH
       WHERE ICS_NARR_COND_SCHD.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'NarrativeConditionScheduleSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'NarrativeConditionScheduleSubmission');
	




-- Remove any old records for ICS_NPDES_VARIANCE_PRMT
				
-- /ICS_NPDES_VARIANCE_PRMT
DELETE
  FROM ics_flow_icis.ICS_NPDES_VARIANCE_PRMT
 WHERE ICS_NPDES_VARIANCE_PRMT.ICS_NPDES_VARIANCE_PRMT_ID IN
          (SELECT ICS_NPDES_VARIANCE_PRMT.ICS_NPDES_VARIANCE_PRMT_ID
              from ics_flow_icis.ICS_NPDES_VARIANCE_PRMT ICS_NPDES_VARIANCE_PRMT 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_NPDES_VARIANCE_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'NPDESVariancePermitSubmission')
                 
                 
);

	
-- Add accepted records for ICS_NPDES_VARIANCE_PRMT


-- /ICS_NPDES_VARIANCE_PRMT
INSERT INTO ics_flow_icis.ICS_NPDES_VARIANCE_PRMT
     SELECT ICS_NPDES_VARIANCE_PRMT.*
              from ICS_NPDES_VARIANCE_PRMT ICS_NPDES_VARIANCE_PRMT 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_NPDES_VARIANCE_PRMT.KEY_HASH
       WHERE ICS_NPDES_VARIANCE_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'NPDESVariancePermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'NPDESVariancePermitSubmission');
	




-- Remove any old records for ICS_PARAM_LMTS
				
-- /ICS_PARAM_LMTS/ICS_LMT/ICS_MN_LMT_APPLIES
DELETE
  FROM ics_flow_icis.ICS_MN_LMT_APPLIES
 WHERE ICS_MN_LMT_APPLIES.ICS_LMT_ID IN
          (SELECT I3.ICS_LMT_ID
              from ics_flow_icis.ICS_PARAM_LMTS ICS_PARAM_LMTS 
 JOIN ics_flow_icis.ICS_LMT I1
 ON I1.ICS_PARAM_LMTS_ID = ICS_PARAM_LMTS.ICS_PARAM_LMTS_ID 
 JOIN ics_flow_icis.ICS_MN_LMT_APPLIES I3
 ON I3.ICS_LMT_ID = I1.ICS_LMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PARAM_LMTS.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ParameterLimitsSubmission')
                  OR ICS_PARAM_LMTS.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_PARAM_LMTS.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_PARAM_LMTS/ICS_LMT/ICS_NUM_COND
DELETE
  FROM ics_flow_icis.ICS_NUM_COND
 WHERE ICS_NUM_COND.ICS_LMT_ID IN
          (SELECT I2.ICS_LMT_ID
              from ics_flow_icis.ICS_PARAM_LMTS ICS_PARAM_LMTS 
 JOIN ics_flow_icis.ICS_LMT I1
 ON I1.ICS_PARAM_LMTS_ID = ICS_PARAM_LMTS.ICS_PARAM_LMTS_ID 
 JOIN ics_flow_icis.ICS_NUM_COND I2
 ON I2.ICS_LMT_ID = I1.ICS_LMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PARAM_LMTS.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ParameterLimitsSubmission')
                  OR ICS_PARAM_LMTS.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_PARAM_LMTS.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_PARAM_LMTS/ICS_LMT
DELETE
  FROM ics_flow_icis.ICS_LMT
 WHERE ICS_LMT.ICS_PARAM_LMTS_ID IN
          (SELECT I1.ICS_PARAM_LMTS_ID
              from ics_flow_icis.ICS_PARAM_LMTS ICS_PARAM_LMTS 
 JOIN ics_flow_icis.ICS_LMT I1
 ON I1.ICS_PARAM_LMTS_ID = ICS_PARAM_LMTS.ICS_PARAM_LMTS_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PARAM_LMTS.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ParameterLimitsSubmission')
                  OR ICS_PARAM_LMTS.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_PARAM_LMTS.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_PARAM_LMTS
DELETE
  FROM ics_flow_icis.ICS_PARAM_LMTS
 WHERE ICS_PARAM_LMTS.ICS_PARAM_LMTS_ID IN
          (SELECT ICS_PARAM_LMTS.ICS_PARAM_LMTS_ID
              from ics_flow_icis.ICS_PARAM_LMTS ICS_PARAM_LMTS 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PARAM_LMTS.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ParameterLimitsSubmission')
                  OR ICS_PARAM_LMTS.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_PARAM_LMTS.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

	
-- Add accepted records for ICS_PARAM_LMTS


-- /ICS_PARAM_LMTS
INSERT INTO ics_flow_icis.ICS_PARAM_LMTS
     SELECT ICS_PARAM_LMTS.*
              from ICS_PARAM_LMTS ICS_PARAM_LMTS 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PARAM_LMTS.KEY_HASH
       WHERE ICS_PARAM_LMTS.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'ParameterLimitsSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ParameterLimitsSubmission');


-- /ICS_PARAM_LMTS/ICS_LMT
INSERT INTO ics_flow_icis.ICS_LMT
     SELECT I1.*
              from ICS_PARAM_LMTS ICS_PARAM_LMTS 
 JOIN ICS_LMT I1
 ON I1.ICS_PARAM_LMTS_ID = ICS_PARAM_LMTS.ICS_PARAM_LMTS_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PARAM_LMTS.KEY_HASH
       WHERE ICS_PARAM_LMTS.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'ParameterLimitsSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ParameterLimitsSubmission');


-- /ICS_PARAM_LMTS/ICS_LMT/ICS_NUM_COND
INSERT INTO ics_flow_icis.ICS_NUM_COND
     SELECT I2.*
              from ICS_PARAM_LMTS ICS_PARAM_LMTS 
 JOIN ICS_LMT I1
 ON I1.ICS_PARAM_LMTS_ID = ICS_PARAM_LMTS.ICS_PARAM_LMTS_ID 
 JOIN ICS_NUM_COND I2
 ON I2.ICS_LMT_ID = I1.ICS_LMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PARAM_LMTS.KEY_HASH
       WHERE ICS_PARAM_LMTS.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'ParameterLimitsSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ParameterLimitsSubmission');


-- /ICS_PARAM_LMTS/ICS_LMT/ICS_MN_LMT_APPLIES
INSERT INTO ics_flow_icis.ICS_MN_LMT_APPLIES
     SELECT I3.*
              from ICS_PARAM_LMTS ICS_PARAM_LMTS 
 JOIN ICS_LMT I1
 ON I1.ICS_PARAM_LMTS_ID = ICS_PARAM_LMTS.ICS_PARAM_LMTS_ID 
 JOIN ICS_MN_LMT_APPLIES I3
 ON I3.ICS_LMT_ID = I1.ICS_LMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PARAM_LMTS.KEY_HASH
       WHERE ICS_PARAM_LMTS.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'ParameterLimitsSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ParameterLimitsSubmission');
	




-- Remove any old records for ICS_PRMT_REISSU
				
-- /ICS_PRMT_REISSU
DELETE
  FROM ics_flow_icis.ICS_PRMT_REISSU
 WHERE ICS_PRMT_REISSU.ICS_PRMT_REISSU_ID IN
          (SELECT ICS_PRMT_REISSU.ICS_PRMT_REISSU_ID
              from ics_flow_icis.ICS_PRMT_REISSU ICS_PRMT_REISSU 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRMT_REISSU.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PermitReissuanceSubmission')
                  OR ICS_PRMT_REISSU.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_PRMT_REISSU.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

	
-- Add accepted records for ICS_PRMT_REISSU


-- /ICS_PRMT_REISSU
INSERT INTO ics_flow_icis.ICS_PRMT_REISSU
     SELECT ICS_PRMT_REISSU.*
              from ICS_PRMT_REISSU ICS_PRMT_REISSU 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRMT_REISSU.KEY_HASH
       WHERE ICS_PRMT_REISSU.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'PermitReissuanceSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PermitReissuanceSubmission');
	




-- Remove any old records for ICS_PRMT_FEATR
				
-- /ICS_PRMT_FEATR/ICS_ADDR/ICS_TELEPH
DELETE
  FROM ics_flow_icis.ICS_TELEPH
 WHERE ICS_TELEPH.ICS_ADDR_ID IN
          (SELECT I13.ICS_ADDR_ID
              from ics_flow_icis.ICS_PRMT_FEATR ICS_PRMT_FEATR 
 JOIN ics_flow_icis.ICS_ADDR I12
 ON I12.ICS_PRMT_FEATR_ID = ICS_PRMT_FEATR.ICS_PRMT_FEATR_ID 
 JOIN ics_flow_icis.ICS_TELEPH I13
 ON I13.ICS_ADDR_ID = I12.ICS_ADDR_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRMT_FEATR.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PermittedFeatureSubmission')
                  OR ICS_PRMT_FEATR.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_PRMT_FEATR.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_PRMT_FEATR/ICS_ADDR
DELETE
  FROM ics_flow_icis.ICS_ADDR
 WHERE ICS_ADDR.ICS_PRMT_FEATR_ID IN
          (SELECT I12.ICS_PRMT_FEATR_ID
              from ics_flow_icis.ICS_PRMT_FEATR ICS_PRMT_FEATR 
 JOIN ics_flow_icis.ICS_ADDR I12
 ON I12.ICS_PRMT_FEATR_ID = ICS_PRMT_FEATR.ICS_PRMT_FEATR_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRMT_FEATR.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PermittedFeatureSubmission')
                  OR ICS_PRMT_FEATR.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_PRMT_FEATR.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_PRMT_FEATR/ICS_GEO_COORD
DELETE
  FROM ics_flow_icis.ICS_GEO_COORD
 WHERE ICS_GEO_COORD.ICS_PRMT_FEATR_ID IN
          (SELECT I11.ICS_PRMT_FEATR_ID
              from ics_flow_icis.ICS_PRMT_FEATR ICS_PRMT_FEATR 
 JOIN ics_flow_icis.ICS_GEO_COORD I11
 ON I11.ICS_PRMT_FEATR_ID = ICS_PRMT_FEATR.ICS_PRMT_FEATR_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRMT_FEATR.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PermittedFeatureSubmission')
                  OR ICS_PRMT_FEATR.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_PRMT_FEATR.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_PRMT_FEATR/ICS_PRMT_FEATR_TRTMNT_TYPE
DELETE
  FROM ics_flow_icis.ICS_PRMT_FEATR_TRTMNT_TYPE
 WHERE ICS_PRMT_FEATR_TRTMNT_TYPE.ICS_PRMT_FEATR_ID IN
          (SELECT I10.ICS_PRMT_FEATR_ID
              from ics_flow_icis.ICS_PRMT_FEATR ICS_PRMT_FEATR 
 JOIN ics_flow_icis.ICS_PRMT_FEATR_TRTMNT_TYPE I10
 ON I10.ICS_PRMT_FEATR_ID = ICS_PRMT_FEATR.ICS_PRMT_FEATR_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRMT_FEATR.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PermittedFeatureSubmission')
                  OR ICS_PRMT_FEATR.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_PRMT_FEATR.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_PRMT_FEATR/ICS_PRMT_FEATR_CHAR
DELETE
  FROM ics_flow_icis.ICS_PRMT_FEATR_CHAR
 WHERE ICS_PRMT_FEATR_CHAR.ICS_PRMT_FEATR_ID IN
          (SELECT I9.ICS_PRMT_FEATR_ID
              from ics_flow_icis.ICS_PRMT_FEATR ICS_PRMT_FEATR 
 JOIN ics_flow_icis.ICS_PRMT_FEATR_CHAR I9
 ON I9.ICS_PRMT_FEATR_ID = ICS_PRMT_FEATR.ICS_PRMT_FEATR_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRMT_FEATR.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PermittedFeatureSubmission')
                  OR ICS_PRMT_FEATR.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_PRMT_FEATR.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_PRMT_FEATR/ICS_POLUT_LIST/ICS_TMDL_POLLUTANTS/ICS_TMDL_POLUT
DELETE
  FROM ics_flow_icis.ICS_TMDL_POLUT
 WHERE ICS_TMDL_POLUT.ICS_TMDL_POLLUTANTS_ID IN
          (SELECT I8.ICS_TMDL_POLLUTANTS_ID
              from ics_flow_icis.ICS_PRMT_FEATR ICS_PRMT_FEATR 
 JOIN ics_flow_icis.ICS_POLUT_LIST I5
 ON I5.ICS_PRMT_FEATR_ID = ICS_PRMT_FEATR.ICS_PRMT_FEATR_ID 
 JOIN ics_flow_icis.ICS_TMDL_POLLUTANTS I7
 ON I7.ICS_POLUT_LIST_ID = I5.ICS_POLUT_LIST_ID 
 JOIN ics_flow_icis.ICS_TMDL_POLUT I8
 ON I8.ICS_TMDL_POLLUTANTS_ID = I7.ICS_TMDL_POLLUTANTS_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRMT_FEATR.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PermittedFeatureSubmission')
                  OR ICS_PRMT_FEATR.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_PRMT_FEATR.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_PRMT_FEATR/ICS_POLUT_LIST/ICS_TMDL_POLLUTANTS
DELETE
  FROM ics_flow_icis.ICS_TMDL_POLLUTANTS
 WHERE ICS_TMDL_POLLUTANTS.ICS_POLUT_LIST_ID IN
          (SELECT I7.ICS_POLUT_LIST_ID
              from ics_flow_icis.ICS_PRMT_FEATR ICS_PRMT_FEATR 
 JOIN ics_flow_icis.ICS_POLUT_LIST I5
 ON I5.ICS_PRMT_FEATR_ID = ICS_PRMT_FEATR.ICS_PRMT_FEATR_ID 
 JOIN ics_flow_icis.ICS_TMDL_POLLUTANTS I7
 ON I7.ICS_POLUT_LIST_ID = I5.ICS_POLUT_LIST_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRMT_FEATR.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PermittedFeatureSubmission')
                  OR ICS_PRMT_FEATR.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_PRMT_FEATR.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_PRMT_FEATR/ICS_POLUT_LIST/ICS_IMPAIRED_WTR_POLLUTANTS
DELETE
  FROM ics_flow_icis.ICS_IMPAIRED_WTR_POLLUTANTS
 WHERE ICS_IMPAIRED_WTR_POLLUTANTS.ICS_POLUT_LIST_ID IN
          (SELECT I6.ICS_POLUT_LIST_ID
              from ics_flow_icis.ICS_PRMT_FEATR ICS_PRMT_FEATR 
 JOIN ics_flow_icis.ICS_POLUT_LIST I5
 ON I5.ICS_PRMT_FEATR_ID = ICS_PRMT_FEATR.ICS_PRMT_FEATR_ID 
 JOIN ics_flow_icis.ICS_IMPAIRED_WTR_POLLUTANTS I6
 ON I6.ICS_POLUT_LIST_ID = I5.ICS_POLUT_LIST_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRMT_FEATR.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PermittedFeatureSubmission')
                  OR ICS_PRMT_FEATR.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_PRMT_FEATR.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_PRMT_FEATR/ICS_POLUT_LIST
DELETE
  FROM ics_flow_icis.ICS_POLUT_LIST
 WHERE ICS_POLUT_LIST.ICS_PRMT_FEATR_ID IN
          (SELECT I5.ICS_PRMT_FEATR_ID
              from ics_flow_icis.ICS_PRMT_FEATR ICS_PRMT_FEATR 
 JOIN ics_flow_icis.ICS_POLUT_LIST I5
 ON I5.ICS_PRMT_FEATR_ID = ICS_PRMT_FEATR.ICS_PRMT_FEATR_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRMT_FEATR.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PermittedFeatureSubmission')
                  OR ICS_PRMT_FEATR.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_PRMT_FEATR.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_PRMT_FEATR/ICS_COOLING_WTR_INTAKE_STRCT_INFO/ICS_COOLING_WTR_INTAKE_STRCT_CMPL_METHOD
DELETE
  FROM ics_flow_icis.ICS_COOLING_WTR_INTAKE_STRCT_CMPL_METHOD
 WHERE ICS_COOLING_WTR_INTAKE_STRCT_CMPL_METHOD.ICS_COOLING_WTR_INTAKE_STRCT_INFO_ID IN
          (SELECT I4.ICS_COOLING_WTR_INTAKE_STRCT_INFO_ID
              from ics_flow_icis.ICS_PRMT_FEATR ICS_PRMT_FEATR 
 JOIN ics_flow_icis.ICS_COOLING_WTR_INTAKE_STRCT_INFO I3
 ON I3.ICS_PRMT_FEATR_ID = ICS_PRMT_FEATR.ICS_PRMT_FEATR_ID 
 JOIN ics_flow_icis.ICS_COOLING_WTR_INTAKE_STRCT_CMPL_METHOD I4
 ON I4.ICS_COOLING_WTR_INTAKE_STRCT_INFO_ID = I3.ICS_COOLING_WTR_INTAKE_STRCT_INFO_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRMT_FEATR.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PermittedFeatureSubmission')
                  OR ICS_PRMT_FEATR.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_PRMT_FEATR.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_PRMT_FEATR/ICS_COOLING_WTR_INTAKE_STRCT_INFO
DELETE
  FROM ics_flow_icis.ICS_COOLING_WTR_INTAKE_STRCT_INFO
 WHERE ICS_COOLING_WTR_INTAKE_STRCT_INFO.ICS_PRMT_FEATR_ID IN
          (SELECT I3.ICS_PRMT_FEATR_ID
              from ics_flow_icis.ICS_PRMT_FEATR ICS_PRMT_FEATR 
 JOIN ics_flow_icis.ICS_COOLING_WTR_INTAKE_STRCT_INFO I3
 ON I3.ICS_PRMT_FEATR_ID = ICS_PRMT_FEATR.ICS_PRMT_FEATR_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRMT_FEATR.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PermittedFeatureSubmission')
                  OR ICS_PRMT_FEATR.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_PRMT_FEATR.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_PRMT_FEATR/ICS_CONTACT/ICS_TELEPH
DELETE
  FROM ics_flow_icis.ICS_TELEPH
 WHERE ICS_TELEPH.ICS_CONTACT_ID IN
          (SELECT I2.ICS_CONTACT_ID
              from ics_flow_icis.ICS_PRMT_FEATR ICS_PRMT_FEATR 
 JOIN ics_flow_icis.ICS_CONTACT I1
 ON I1.ICS_PRMT_FEATR_ID = ICS_PRMT_FEATR.ICS_PRMT_FEATR_ID 
 JOIN ics_flow_icis.ICS_TELEPH I2
 ON I2.ICS_CONTACT_ID = I1.ICS_CONTACT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRMT_FEATR.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PermittedFeatureSubmission')
                  OR ICS_PRMT_FEATR.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_PRMT_FEATR.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_PRMT_FEATR/ICS_CONTACT
DELETE
  FROM ics_flow_icis.ICS_CONTACT
 WHERE ICS_CONTACT.ICS_PRMT_FEATR_ID IN
          (SELECT I1.ICS_PRMT_FEATR_ID
              from ics_flow_icis.ICS_PRMT_FEATR ICS_PRMT_FEATR 
 JOIN ics_flow_icis.ICS_CONTACT I1
 ON I1.ICS_PRMT_FEATR_ID = ICS_PRMT_FEATR.ICS_PRMT_FEATR_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRMT_FEATR.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PermittedFeatureSubmission')
                  OR ICS_PRMT_FEATR.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_PRMT_FEATR.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_PRMT_FEATR
DELETE
  FROM ics_flow_icis.ICS_PRMT_FEATR
 WHERE ICS_PRMT_FEATR.ICS_PRMT_FEATR_ID IN
          (SELECT ICS_PRMT_FEATR.ICS_PRMT_FEATR_ID
              from ics_flow_icis.ICS_PRMT_FEATR ICS_PRMT_FEATR 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRMT_FEATR.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PermittedFeatureSubmission')
                  OR ICS_PRMT_FEATR.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_PRMT_FEATR.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

	
-- Add accepted records for ICS_PRMT_FEATR


-- /ICS_PRMT_FEATR
INSERT INTO ics_flow_icis.ICS_PRMT_FEATR
     SELECT ICS_PRMT_FEATR.*
              from ICS_PRMT_FEATR ICS_PRMT_FEATR 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRMT_FEATR.KEY_HASH
       WHERE ICS_PRMT_FEATR.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'PermittedFeatureSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PermittedFeatureSubmission');


-- /ICS_PRMT_FEATR/ICS_CONTACT
INSERT INTO ics_flow_icis.ICS_CONTACT
     SELECT I1.*
              from ICS_PRMT_FEATR ICS_PRMT_FEATR 
 JOIN ICS_CONTACT I1
 ON I1.ICS_PRMT_FEATR_ID = ICS_PRMT_FEATR.ICS_PRMT_FEATR_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRMT_FEATR.KEY_HASH
       WHERE ICS_PRMT_FEATR.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'PermittedFeatureSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PermittedFeatureSubmission');


-- /ICS_PRMT_FEATR/ICS_CONTACT/ICS_TELEPH
INSERT INTO ics_flow_icis.ICS_TELEPH
     SELECT I2.*
              from ICS_PRMT_FEATR ICS_PRMT_FEATR 
 JOIN ICS_CONTACT I1
 ON I1.ICS_PRMT_FEATR_ID = ICS_PRMT_FEATR.ICS_PRMT_FEATR_ID 
 JOIN ICS_TELEPH I2
 ON I2.ICS_CONTACT_ID = I1.ICS_CONTACT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRMT_FEATR.KEY_HASH
       WHERE ICS_PRMT_FEATR.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'PermittedFeatureSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PermittedFeatureSubmission');


-- /ICS_PRMT_FEATR/ICS_COOLING_WTR_INTAKE_STRCT_INFO
INSERT INTO ics_flow_icis.ICS_COOLING_WTR_INTAKE_STRCT_INFO
     SELECT I3.*
              from ICS_PRMT_FEATR ICS_PRMT_FEATR 
 JOIN ICS_COOLING_WTR_INTAKE_STRCT_INFO I3
 ON I3.ICS_PRMT_FEATR_ID = ICS_PRMT_FEATR.ICS_PRMT_FEATR_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRMT_FEATR.KEY_HASH
       WHERE ICS_PRMT_FEATR.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'PermittedFeatureSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PermittedFeatureSubmission');


-- /ICS_PRMT_FEATR/ICS_COOLING_WTR_INTAKE_STRCT_INFO/ICS_COOLING_WTR_INTAKE_STRCT_CMPL_METHOD
INSERT INTO ics_flow_icis.ICS_COOLING_WTR_INTAKE_STRCT_CMPL_METHOD
     SELECT I4.*
              from ICS_PRMT_FEATR ICS_PRMT_FEATR 
 JOIN ICS_COOLING_WTR_INTAKE_STRCT_INFO I3
 ON I3.ICS_PRMT_FEATR_ID = ICS_PRMT_FEATR.ICS_PRMT_FEATR_ID 
 JOIN ICS_COOLING_WTR_INTAKE_STRCT_CMPL_METHOD I4
 ON I4.ICS_COOLING_WTR_INTAKE_STRCT_INFO_ID = I3.ICS_COOLING_WTR_INTAKE_STRCT_INFO_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRMT_FEATR.KEY_HASH
       WHERE ICS_PRMT_FEATR.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'PermittedFeatureSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PermittedFeatureSubmission');


-- /ICS_PRMT_FEATR/ICS_POLUT_LIST
INSERT INTO ics_flow_icis.ICS_POLUT_LIST
     SELECT I5.*
              from ICS_PRMT_FEATR ICS_PRMT_FEATR 
 JOIN ICS_POLUT_LIST I5
 ON I5.ICS_PRMT_FEATR_ID = ICS_PRMT_FEATR.ICS_PRMT_FEATR_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRMT_FEATR.KEY_HASH
       WHERE ICS_PRMT_FEATR.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'PermittedFeatureSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PermittedFeatureSubmission');


-- /ICS_PRMT_FEATR/ICS_POLUT_LIST/ICS_IMPAIRED_WTR_POLLUTANTS
INSERT INTO ics_flow_icis.ICS_IMPAIRED_WTR_POLLUTANTS
     SELECT I6.*
              from ICS_PRMT_FEATR ICS_PRMT_FEATR 
 JOIN ICS_POLUT_LIST I5
 ON I5.ICS_PRMT_FEATR_ID = ICS_PRMT_FEATR.ICS_PRMT_FEATR_ID 
 JOIN ICS_IMPAIRED_WTR_POLLUTANTS I6
 ON I6.ICS_POLUT_LIST_ID = I5.ICS_POLUT_LIST_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRMT_FEATR.KEY_HASH
       WHERE ICS_PRMT_FEATR.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'PermittedFeatureSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PermittedFeatureSubmission');


-- /ICS_PRMT_FEATR/ICS_POLUT_LIST/ICS_TMDL_POLLUTANTS
INSERT INTO ics_flow_icis.ICS_TMDL_POLLUTANTS
     SELECT I7.*
              from ICS_PRMT_FEATR ICS_PRMT_FEATR 
 JOIN ICS_POLUT_LIST I5
 ON I5.ICS_PRMT_FEATR_ID = ICS_PRMT_FEATR.ICS_PRMT_FEATR_ID 
 JOIN ICS_TMDL_POLLUTANTS I7
 ON I7.ICS_POLUT_LIST_ID = I5.ICS_POLUT_LIST_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRMT_FEATR.KEY_HASH
       WHERE ICS_PRMT_FEATR.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'PermittedFeatureSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PermittedFeatureSubmission');


-- /ICS_PRMT_FEATR/ICS_POLUT_LIST/ICS_TMDL_POLLUTANTS/ICS_TMDL_POLUT
INSERT INTO ics_flow_icis.ICS_TMDL_POLUT
     SELECT I8.*
              from ICS_PRMT_FEATR ICS_PRMT_FEATR 
 JOIN ICS_POLUT_LIST I5
 ON I5.ICS_PRMT_FEATR_ID = ICS_PRMT_FEATR.ICS_PRMT_FEATR_ID 
 JOIN ICS_TMDL_POLLUTANTS I7
 ON I7.ICS_POLUT_LIST_ID = I5.ICS_POLUT_LIST_ID 
 JOIN ICS_TMDL_POLUT I8
 ON I8.ICS_TMDL_POLLUTANTS_ID = I7.ICS_TMDL_POLLUTANTS_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRMT_FEATR.KEY_HASH
       WHERE ICS_PRMT_FEATR.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'PermittedFeatureSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PermittedFeatureSubmission');


-- /ICS_PRMT_FEATR/ICS_PRMT_FEATR_CHAR
INSERT INTO ics_flow_icis.ICS_PRMT_FEATR_CHAR
     SELECT I9.*
              from ICS_PRMT_FEATR ICS_PRMT_FEATR 
 JOIN ICS_PRMT_FEATR_CHAR I9
 ON I9.ICS_PRMT_FEATR_ID = ICS_PRMT_FEATR.ICS_PRMT_FEATR_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRMT_FEATR.KEY_HASH
       WHERE ICS_PRMT_FEATR.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'PermittedFeatureSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PermittedFeatureSubmission');


-- /ICS_PRMT_FEATR/ICS_PRMT_FEATR_TRTMNT_TYPE
INSERT INTO ics_flow_icis.ICS_PRMT_FEATR_TRTMNT_TYPE
     SELECT I10.*
              from ICS_PRMT_FEATR ICS_PRMT_FEATR 
 JOIN ICS_PRMT_FEATR_TRTMNT_TYPE I10
 ON I10.ICS_PRMT_FEATR_ID = ICS_PRMT_FEATR.ICS_PRMT_FEATR_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRMT_FEATR.KEY_HASH
       WHERE ICS_PRMT_FEATR.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'PermittedFeatureSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PermittedFeatureSubmission');


-- /ICS_PRMT_FEATR/ICS_GEO_COORD
INSERT INTO ics_flow_icis.ICS_GEO_COORD
     SELECT I11.*
              from ICS_PRMT_FEATR ICS_PRMT_FEATR 
 JOIN ICS_GEO_COORD I11
 ON I11.ICS_PRMT_FEATR_ID = ICS_PRMT_FEATR.ICS_PRMT_FEATR_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRMT_FEATR.KEY_HASH
       WHERE ICS_PRMT_FEATR.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'PermittedFeatureSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PermittedFeatureSubmission');


-- /ICS_PRMT_FEATR/ICS_ADDR
INSERT INTO ics_flow_icis.ICS_ADDR
     SELECT I12.*
              from ICS_PRMT_FEATR ICS_PRMT_FEATR 
 JOIN ICS_ADDR I12
 ON I12.ICS_PRMT_FEATR_ID = ICS_PRMT_FEATR.ICS_PRMT_FEATR_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRMT_FEATR.KEY_HASH
       WHERE ICS_PRMT_FEATR.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'PermittedFeatureSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PermittedFeatureSubmission');


-- /ICS_PRMT_FEATR/ICS_ADDR/ICS_TELEPH
INSERT INTO ics_flow_icis.ICS_TELEPH
     SELECT I13.*
              from ICS_PRMT_FEATR ICS_PRMT_FEATR 
 JOIN ICS_ADDR I12
 ON I12.ICS_PRMT_FEATR_ID = ICS_PRMT_FEATR.ICS_PRMT_FEATR_ID 
 JOIN ICS_TELEPH I13
 ON I13.ICS_ADDR_ID = I12.ICS_ADDR_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRMT_FEATR.KEY_HASH
       WHERE ICS_PRMT_FEATR.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'PermittedFeatureSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PermittedFeatureSubmission');
	




-- Remove any old records for ICS_PRMT_TERM
				
-- /ICS_PRMT_TERM
DELETE
  FROM ics_flow_icis.ICS_PRMT_TERM
 WHERE ICS_PRMT_TERM.ICS_PRMT_TERM_ID IN
          (SELECT ICS_PRMT_TERM.ICS_PRMT_TERM_ID
              from ics_flow_icis.ICS_PRMT_TERM ICS_PRMT_TERM 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRMT_TERM.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PermitTerminationSubmission')
                 
                 
);

	
-- Add accepted records for ICS_PRMT_TERM


-- /ICS_PRMT_TERM
INSERT INTO ics_flow_icis.ICS_PRMT_TERM
     SELECT ICS_PRMT_TERM.*
              from ICS_PRMT_TERM ICS_PRMT_TERM 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRMT_TERM.KEY_HASH
       WHERE ICS_PRMT_TERM.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'PermitTerminationSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PermitTerminationSubmission');
	




-- Remove any old records for ICS_PRMT_TRACK_EVT
				
-- /ICS_PRMT_TRACK_EVT
DELETE
  FROM ics_flow_icis.ICS_PRMT_TRACK_EVT
 WHERE ICS_PRMT_TRACK_EVT.ICS_PRMT_TRACK_EVT_ID IN
          (SELECT ICS_PRMT_TRACK_EVT.ICS_PRMT_TRACK_EVT_ID
              from ics_flow_icis.ICS_PRMT_TRACK_EVT ICS_PRMT_TRACK_EVT 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRMT_TRACK_EVT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PermitTrackingEventSubmission')
                  OR ICS_PRMT_TRACK_EVT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_PRMT_TRACK_EVT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

	
-- Add accepted records for ICS_PRMT_TRACK_EVT


-- /ICS_PRMT_TRACK_EVT
INSERT INTO ics_flow_icis.ICS_PRMT_TRACK_EVT
     SELECT ICS_PRMT_TRACK_EVT.*
              from ICS_PRMT_TRACK_EVT ICS_PRMT_TRACK_EVT 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRMT_TRACK_EVT.KEY_HASH
       WHERE ICS_PRMT_TRACK_EVT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'PermitTrackingEventSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PermitTrackingEventSubmission');
	




-- Remove any old records for ICS_POTW_PRMT
				
-- /ICS_POTW_PRMT/ICS_SATL_COLL_SYSTM
DELETE
  FROM ics_flow_icis.ICS_SATL_COLL_SYSTM
 WHERE ICS_SATL_COLL_SYSTM.ICS_POTW_PRMT_ID IN
          (SELECT I1.ICS_POTW_PRMT_ID
              from ics_flow_icis.ICS_POTW_PRMT ICS_POTW_PRMT 
 JOIN ics_flow_icis.ICS_SATL_COLL_SYSTM I1
 ON I1.ICS_POTW_PRMT_ID = ICS_POTW_PRMT.ICS_POTW_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_POTW_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'POTWPermitSubmission')
                  OR ICS_POTW_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_POTW_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_POTW_PRMT
DELETE
  FROM ics_flow_icis.ICS_POTW_PRMT
 WHERE ICS_POTW_PRMT.ICS_POTW_PRMT_ID IN
          (SELECT ICS_POTW_PRMT.ICS_POTW_PRMT_ID
              from ics_flow_icis.ICS_POTW_PRMT ICS_POTW_PRMT 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_POTW_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'POTWPermitSubmission')
                  OR ICS_POTW_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_POTW_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

	
-- Add accepted records for ICS_POTW_PRMT


-- /ICS_POTW_PRMT
INSERT INTO ics_flow_icis.ICS_POTW_PRMT
     SELECT ICS_POTW_PRMT.*
              from ICS_POTW_PRMT ICS_POTW_PRMT 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_POTW_PRMT.KEY_HASH
       WHERE ICS_POTW_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'POTWPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'POTWPermitSubmission');


-- /ICS_POTW_PRMT/ICS_SATL_COLL_SYSTM
INSERT INTO ics_flow_icis.ICS_SATL_COLL_SYSTM
     SELECT I1.*
              from ICS_POTW_PRMT ICS_POTW_PRMT 
 JOIN ICS_SATL_COLL_SYSTM I1
 ON I1.ICS_POTW_PRMT_ID = ICS_POTW_PRMT.ICS_POTW_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_POTW_PRMT.KEY_HASH
       WHERE ICS_POTW_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'POTWPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'POTWPermitSubmission');
	




-- Remove any old records for ICS_POTW_TRTMNT_TECHNOLOGY_PRMT
				
-- /ICS_POTW_TRTMNT_TECHNOLOGY_PRMT
DELETE
  FROM ics_flow_icis.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT
 WHERE ICS_POTW_TRTMNT_TECHNOLOGY_PRMT.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT_ID IN
          (SELECT ICS_POTW_TRTMNT_TECHNOLOGY_PRMT.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT_ID
              from ics_flow_icis.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT ICS_POTW_TRTMNT_TECHNOLOGY_PRMT 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_POTW_TRTMNT_TECHNOLOGY_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'POTWTreatmentTechnologyPermitSubmission')
                 
                 
);

	
-- Add accepted records for ICS_POTW_TRTMNT_TECHNOLOGY_PRMT


-- /ICS_POTW_TRTMNT_TECHNOLOGY_PRMT
INSERT INTO ics_flow_icis.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT
     SELECT ICS_POTW_TRTMNT_TECHNOLOGY_PRMT.*
              from ICS_POTW_TRTMNT_TECHNOLOGY_PRMT ICS_POTW_TRTMNT_TECHNOLOGY_PRMT 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_POTW_TRTMNT_TECHNOLOGY_PRMT.KEY_HASH
       WHERE ICS_POTW_TRTMNT_TECHNOLOGY_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'POTWTreatmentTechnologyPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'POTWTreatmentTechnologyPermitSubmission');
	




-- Remove any old records for ICS_PRETR_PRMT
				
-- /ICS_PRETR_PRMT/ICS_PRETR_PROG_MOD
DELETE
  FROM ics_flow_icis.ICS_PRETR_PROG_MOD
 WHERE ICS_PRETR_PROG_MOD.ICS_PRETR_PRMT_ID IN
          (SELECT I3.ICS_PRETR_PRMT_ID
              from ics_flow_icis.ICS_PRETR_PRMT ICS_PRETR_PRMT 
 JOIN ics_flow_icis.ICS_PRETR_PROG_MOD I3
 ON I3.ICS_PRETR_PRMT_ID = ICS_PRETR_PRMT.ICS_PRETR_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRETR_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PretreatmentPermitSubmission')
                  OR ICS_PRETR_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_PRETR_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_PRETR_PRMT/ICS_CONTACT/ICS_TELEPH
DELETE
  FROM ics_flow_icis.ICS_TELEPH
 WHERE ICS_TELEPH.ICS_CONTACT_ID IN
          (SELECT I2.ICS_CONTACT_ID
              from ics_flow_icis.ICS_PRETR_PRMT ICS_PRETR_PRMT 
 JOIN ics_flow_icis.ICS_CONTACT I1
 ON I1.ICS_PRETR_PRMT_ID = ICS_PRETR_PRMT.ICS_PRETR_PRMT_ID 
 JOIN ics_flow_icis.ICS_TELEPH I2
 ON I2.ICS_CONTACT_ID = I1.ICS_CONTACT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRETR_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PretreatmentPermitSubmission')
                  OR ICS_PRETR_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_PRETR_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_PRETR_PRMT/ICS_CONTACT
DELETE
  FROM ics_flow_icis.ICS_CONTACT
 WHERE ICS_CONTACT.ICS_PRETR_PRMT_ID IN
          (SELECT I1.ICS_PRETR_PRMT_ID
              from ics_flow_icis.ICS_PRETR_PRMT ICS_PRETR_PRMT 
 JOIN ics_flow_icis.ICS_CONTACT I1
 ON I1.ICS_PRETR_PRMT_ID = ICS_PRETR_PRMT.ICS_PRETR_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRETR_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PretreatmentPermitSubmission')
                  OR ICS_PRETR_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_PRETR_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_PRETR_PRMT
DELETE
  FROM ics_flow_icis.ICS_PRETR_PRMT
 WHERE ICS_PRETR_PRMT.ICS_PRETR_PRMT_ID IN
          (SELECT ICS_PRETR_PRMT.ICS_PRETR_PRMT_ID
              from ics_flow_icis.ICS_PRETR_PRMT ICS_PRETR_PRMT 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRETR_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PretreatmentPermitSubmission')
                  OR ICS_PRETR_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_PRETR_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

	
-- Add accepted records for ICS_PRETR_PRMT


-- /ICS_PRETR_PRMT
INSERT INTO ics_flow_icis.ICS_PRETR_PRMT
     SELECT ICS_PRETR_PRMT.*
              from ICS_PRETR_PRMT ICS_PRETR_PRMT 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRETR_PRMT.KEY_HASH
       WHERE ICS_PRETR_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'PretreatmentPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PretreatmentPermitSubmission');


-- /ICS_PRETR_PRMT/ICS_CONTACT
INSERT INTO ics_flow_icis.ICS_CONTACT
     SELECT I1.*
              from ICS_PRETR_PRMT ICS_PRETR_PRMT 
 JOIN ICS_CONTACT I1
 ON I1.ICS_PRETR_PRMT_ID = ICS_PRETR_PRMT.ICS_PRETR_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRETR_PRMT.KEY_HASH
       WHERE ICS_PRETR_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'PretreatmentPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PretreatmentPermitSubmission');


-- /ICS_PRETR_PRMT/ICS_CONTACT/ICS_TELEPH
INSERT INTO ics_flow_icis.ICS_TELEPH
     SELECT I2.*
              from ICS_PRETR_PRMT ICS_PRETR_PRMT 
 JOIN ICS_CONTACT I1
 ON I1.ICS_PRETR_PRMT_ID = ICS_PRETR_PRMT.ICS_PRETR_PRMT_ID 
 JOIN ICS_TELEPH I2
 ON I2.ICS_CONTACT_ID = I1.ICS_CONTACT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRETR_PRMT.KEY_HASH
       WHERE ICS_PRETR_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'PretreatmentPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PretreatmentPermitSubmission');


-- /ICS_PRETR_PRMT/ICS_PRETR_PROG_MOD
INSERT INTO ics_flow_icis.ICS_PRETR_PROG_MOD
     SELECT I3.*
              from ICS_PRETR_PRMT ICS_PRETR_PRMT 
 JOIN ICS_PRETR_PROG_MOD I3
 ON I3.ICS_PRETR_PRMT_ID = ICS_PRETR_PRMT.ICS_PRETR_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRETR_PRMT.KEY_HASH
       WHERE ICS_PRETR_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'PretreatmentPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PretreatmentPermitSubmission');
	




-- Remove any old records for ICS_PRETR_PROG_REP
				
-- /ICS_PRETR_PROG_REP/ICS_INDST_USR_INVENTORY/ICS_INDST_USR_INFO/ICS_IU_VIOL_INFO/ICS_SNC_PRETR_STND_LMTS_PARAMETERS
DELETE
  FROM ics_flow_icis.ICS_SNC_PRETR_STND_LMTS_PARAMETERS
 WHERE ICS_SNC_PRETR_STND_LMTS_PARAMETERS.ICS_IU_VIOL_INFO_ID IN
          (SELECT I9.ICS_IU_VIOL_INFO_ID
              from ics_flow_icis.ICS_PRETR_PROG_REP ICS_PRETR_PROG_REP 
 JOIN ics_flow_icis.ICS_INDST_USR_INVENTORY I3
 ON I3.ICS_PRETR_PROG_REP_ID = ICS_PRETR_PROG_REP.ICS_PRETR_PROG_REP_ID 
 JOIN ics_flow_icis.ICS_INDST_USR_INFO I4
 ON I4.ICS_INDST_USR_INVENTORY_ID = I3.ICS_INDST_USR_INVENTORY_ID 
 JOIN ics_flow_icis.ICS_IU_VIOL_INFO I7
 ON I7.ICS_INDST_USR_INFO_ID = I4.ICS_INDST_USR_INFO_ID 
 JOIN ics_flow_icis.ICS_SNC_PRETR_STND_LMTS_PARAMETERS I9
 ON I9.ICS_IU_VIOL_INFO_ID = I7.ICS_IU_VIOL_INFO_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRETR_PROG_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PretreatmentProgramReportSubmission')
                 
                 
);

				
-- /ICS_PRETR_PROG_REP/ICS_INDST_USR_INVENTORY/ICS_INDST_USR_INFO/ICS_IU_VIOL_INFO/ICS_SNC_LISTING_MONTHS
DELETE
  FROM ics_flow_icis.ICS_SNC_LISTING_MONTHS
 WHERE ICS_SNC_LISTING_MONTHS.ICS_IU_VIOL_INFO_ID IN
          (SELECT I8.ICS_IU_VIOL_INFO_ID
              from ics_flow_icis.ICS_PRETR_PROG_REP ICS_PRETR_PROG_REP 
 JOIN ics_flow_icis.ICS_INDST_USR_INVENTORY I3
 ON I3.ICS_PRETR_PROG_REP_ID = ICS_PRETR_PROG_REP.ICS_PRETR_PROG_REP_ID 
 JOIN ics_flow_icis.ICS_INDST_USR_INFO I4
 ON I4.ICS_INDST_USR_INVENTORY_ID = I3.ICS_INDST_USR_INVENTORY_ID 
 JOIN ics_flow_icis.ICS_IU_VIOL_INFO I7
 ON I7.ICS_INDST_USR_INFO_ID = I4.ICS_INDST_USR_INFO_ID 
 JOIN ics_flow_icis.ICS_SNC_LISTING_MONTHS I8
 ON I8.ICS_IU_VIOL_INFO_ID = I7.ICS_IU_VIOL_INFO_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRETR_PROG_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PretreatmentProgramReportSubmission')
                 
                 
);

				
-- /ICS_PRETR_PROG_REP/ICS_INDST_USR_INVENTORY/ICS_INDST_USR_INFO/ICS_IU_VIOL_INFO
DELETE
  FROM ics_flow_icis.ICS_IU_VIOL_INFO
 WHERE ICS_IU_VIOL_INFO.ICS_INDST_USR_INFO_ID IN
          (SELECT I7.ICS_INDST_USR_INFO_ID
              from ics_flow_icis.ICS_PRETR_PROG_REP ICS_PRETR_PROG_REP 
 JOIN ics_flow_icis.ICS_INDST_USR_INVENTORY I3
 ON I3.ICS_PRETR_PROG_REP_ID = ICS_PRETR_PROG_REP.ICS_PRETR_PROG_REP_ID 
 JOIN ics_flow_icis.ICS_INDST_USR_INFO I4
 ON I4.ICS_INDST_USR_INVENTORY_ID = I3.ICS_INDST_USR_INVENTORY_ID 
 JOIN ics_flow_icis.ICS_IU_VIOL_INFO I7
 ON I7.ICS_INDST_USR_INFO_ID = I4.ICS_INDST_USR_INFO_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRETR_PROG_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PretreatmentProgramReportSubmission')
                 
                 
);

				
-- /ICS_PRETR_PROG_REP/ICS_INDST_USR_INVENTORY/ICS_INDST_USR_INFO/ICS_IU_ENFRC_ACTN_INFO/ICS_IU_ENF_ACTN_TYPES
DELETE
  FROM ics_flow_icis.ICS_IU_ENF_ACTN_TYPES
 WHERE ICS_IU_ENF_ACTN_TYPES.ICS_IU_ENFRC_ACTN_INFO_ID IN
          (SELECT I6.ICS_IU_ENFRC_ACTN_INFO_ID
              from ics_flow_icis.ICS_PRETR_PROG_REP ICS_PRETR_PROG_REP 
 JOIN ics_flow_icis.ICS_INDST_USR_INVENTORY I3
 ON I3.ICS_PRETR_PROG_REP_ID = ICS_PRETR_PROG_REP.ICS_PRETR_PROG_REP_ID 
 JOIN ics_flow_icis.ICS_INDST_USR_INFO I4
 ON I4.ICS_INDST_USR_INVENTORY_ID = I3.ICS_INDST_USR_INVENTORY_ID 
 JOIN ics_flow_icis.ICS_IU_ENFRC_ACTN_INFO I5
 ON I5.ICS_INDST_USR_INFO_ID = I4.ICS_INDST_USR_INFO_ID 
 JOIN ics_flow_icis.ICS_IU_ENF_ACTN_TYPES I6
 ON I6.ICS_IU_ENFRC_ACTN_INFO_ID = I5.ICS_IU_ENFRC_ACTN_INFO_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRETR_PROG_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PretreatmentProgramReportSubmission')
                 
                 
);

				
-- /ICS_PRETR_PROG_REP/ICS_INDST_USR_INVENTORY/ICS_INDST_USR_INFO/ICS_IU_ENFRC_ACTN_INFO
DELETE
  FROM ics_flow_icis.ICS_IU_ENFRC_ACTN_INFO
 WHERE ICS_IU_ENFRC_ACTN_INFO.ICS_INDST_USR_INFO_ID IN
          (SELECT I5.ICS_INDST_USR_INFO_ID
              from ics_flow_icis.ICS_PRETR_PROG_REP ICS_PRETR_PROG_REP 
 JOIN ics_flow_icis.ICS_INDST_USR_INVENTORY I3
 ON I3.ICS_PRETR_PROG_REP_ID = ICS_PRETR_PROG_REP.ICS_PRETR_PROG_REP_ID 
 JOIN ics_flow_icis.ICS_INDST_USR_INFO I4
 ON I4.ICS_INDST_USR_INVENTORY_ID = I3.ICS_INDST_USR_INVENTORY_ID 
 JOIN ics_flow_icis.ICS_IU_ENFRC_ACTN_INFO I5
 ON I5.ICS_INDST_USR_INFO_ID = I4.ICS_INDST_USR_INFO_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRETR_PROG_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PretreatmentProgramReportSubmission')
                 
                 
);

				
-- /ICS_PRETR_PROG_REP/ICS_INDST_USR_INVENTORY/ICS_INDST_USR_INFO
DELETE
  FROM ics_flow_icis.ICS_INDST_USR_INFO
 WHERE ICS_INDST_USR_INFO.ICS_INDST_USR_INVENTORY_ID IN
          (SELECT I4.ICS_INDST_USR_INVENTORY_ID
              from ics_flow_icis.ICS_PRETR_PROG_REP ICS_PRETR_PROG_REP 
 JOIN ics_flow_icis.ICS_INDST_USR_INVENTORY I3
 ON I3.ICS_PRETR_PROG_REP_ID = ICS_PRETR_PROG_REP.ICS_PRETR_PROG_REP_ID 
 JOIN ics_flow_icis.ICS_INDST_USR_INFO I4
 ON I4.ICS_INDST_USR_INVENTORY_ID = I3.ICS_INDST_USR_INVENTORY_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRETR_PROG_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PretreatmentProgramReportSubmission')
                 
                 
);

				
-- /ICS_PRETR_PROG_REP/ICS_INDST_USR_INVENTORY
DELETE
  FROM ics_flow_icis.ICS_INDST_USR_INVENTORY
 WHERE ICS_INDST_USR_INVENTORY.ICS_PRETR_PROG_REP_ID IN
          (SELECT I3.ICS_PRETR_PROG_REP_ID
              from ics_flow_icis.ICS_PRETR_PROG_REP ICS_PRETR_PROG_REP 
 JOIN ics_flow_icis.ICS_INDST_USR_INVENTORY I3
 ON I3.ICS_PRETR_PROG_REP_ID = ICS_PRETR_PROG_REP.ICS_PRETR_PROG_REP_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRETR_PROG_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PretreatmentProgramReportSubmission')
                 
                 
);

				
-- /ICS_PRETR_PROG_REP/ICS_CONTROL_AUTH_PROG_INFO/ICS_LOC_LMTS_PARAMETERS
DELETE
  FROM ics_flow_icis.ICS_LOC_LMTS_PARAMETERS
 WHERE ICS_LOC_LMTS_PARAMETERS.ICS_CONTROL_AUTH_PROG_INFO_ID IN
          (SELECT I2.ICS_CONTROL_AUTH_PROG_INFO_ID
              from ics_flow_icis.ICS_PRETR_PROG_REP ICS_PRETR_PROG_REP 
 JOIN ics_flow_icis.ICS_CONTROL_AUTH_PROG_INFO I1
 ON I1.ICS_PRETR_PROG_REP_ID = ICS_PRETR_PROG_REP.ICS_PRETR_PROG_REP_ID 
 JOIN ics_flow_icis.ICS_LOC_LMTS_PARAMETERS I2
 ON I2.ICS_CONTROL_AUTH_PROG_INFO_ID = I1.ICS_CONTROL_AUTH_PROG_INFO_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRETR_PROG_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PretreatmentProgramReportSubmission')
                 
                 
);

				
-- /ICS_PRETR_PROG_REP/ICS_CONTROL_AUTH_PROG_INFO
DELETE
  FROM ics_flow_icis.ICS_CONTROL_AUTH_PROG_INFO
 WHERE ICS_CONTROL_AUTH_PROG_INFO.ICS_PRETR_PROG_REP_ID IN
          (SELECT I1.ICS_PRETR_PROG_REP_ID
              from ics_flow_icis.ICS_PRETR_PROG_REP ICS_PRETR_PROG_REP 
 JOIN ics_flow_icis.ICS_CONTROL_AUTH_PROG_INFO I1
 ON I1.ICS_PRETR_PROG_REP_ID = ICS_PRETR_PROG_REP.ICS_PRETR_PROG_REP_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRETR_PROG_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PretreatmentProgramReportSubmission')
                 
                 
);

				
-- /ICS_PRETR_PROG_REP
DELETE
  FROM ics_flow_icis.ICS_PRETR_PROG_REP
 WHERE ICS_PRETR_PROG_REP.ICS_PRETR_PROG_REP_ID IN
          (SELECT ICS_PRETR_PROG_REP.ICS_PRETR_PROG_REP_ID
              from ics_flow_icis.ICS_PRETR_PROG_REP ICS_PRETR_PROG_REP 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRETR_PROG_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'PretreatmentProgramReportSubmission')
                 
                 
);

	
-- Add accepted records for ICS_PRETR_PROG_REP


-- /ICS_PRETR_PROG_REP
INSERT INTO ics_flow_icis.ICS_PRETR_PROG_REP
     SELECT ICS_PRETR_PROG_REP.*
              from ICS_PRETR_PROG_REP ICS_PRETR_PROG_REP 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRETR_PROG_REP.KEY_HASH
       WHERE ICS_PRETR_PROG_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'PretreatmentProgramReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PretreatmentProgramReportSubmission');


-- /ICS_PRETR_PROG_REP/ICS_CONTROL_AUTH_PROG_INFO
INSERT INTO ics_flow_icis.ICS_CONTROL_AUTH_PROG_INFO
     SELECT I1.*
              from ICS_PRETR_PROG_REP ICS_PRETR_PROG_REP 
 JOIN ICS_CONTROL_AUTH_PROG_INFO I1
 ON I1.ICS_PRETR_PROG_REP_ID = ICS_PRETR_PROG_REP.ICS_PRETR_PROG_REP_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRETR_PROG_REP.KEY_HASH
       WHERE ICS_PRETR_PROG_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'PretreatmentProgramReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PretreatmentProgramReportSubmission');


-- /ICS_PRETR_PROG_REP/ICS_CONTROL_AUTH_PROG_INFO/ICS_LOC_LMTS_PARAMETERS
INSERT INTO ics_flow_icis.ICS_LOC_LMTS_PARAMETERS
     SELECT I2.*
              from ICS_PRETR_PROG_REP ICS_PRETR_PROG_REP 
 JOIN ICS_CONTROL_AUTH_PROG_INFO I1
 ON I1.ICS_PRETR_PROG_REP_ID = ICS_PRETR_PROG_REP.ICS_PRETR_PROG_REP_ID 
 JOIN ICS_LOC_LMTS_PARAMETERS I2
 ON I2.ICS_CONTROL_AUTH_PROG_INFO_ID = I1.ICS_CONTROL_AUTH_PROG_INFO_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRETR_PROG_REP.KEY_HASH
       WHERE ICS_PRETR_PROG_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'PretreatmentProgramReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PretreatmentProgramReportSubmission');


-- /ICS_PRETR_PROG_REP/ICS_INDST_USR_INVENTORY
INSERT INTO ics_flow_icis.ICS_INDST_USR_INVENTORY
     SELECT I3.*
              from ICS_PRETR_PROG_REP ICS_PRETR_PROG_REP 
 JOIN ICS_INDST_USR_INVENTORY I3
 ON I3.ICS_PRETR_PROG_REP_ID = ICS_PRETR_PROG_REP.ICS_PRETR_PROG_REP_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRETR_PROG_REP.KEY_HASH
       WHERE ICS_PRETR_PROG_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'PretreatmentProgramReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PretreatmentProgramReportSubmission');


-- /ICS_PRETR_PROG_REP/ICS_INDST_USR_INVENTORY/ICS_INDST_USR_INFO
INSERT INTO ics_flow_icis.ICS_INDST_USR_INFO
     SELECT I4.*
              from ICS_PRETR_PROG_REP ICS_PRETR_PROG_REP 
 JOIN ICS_INDST_USR_INVENTORY I3
 ON I3.ICS_PRETR_PROG_REP_ID = ICS_PRETR_PROG_REP.ICS_PRETR_PROG_REP_ID 
 JOIN ICS_INDST_USR_INFO I4
 ON I4.ICS_INDST_USR_INVENTORY_ID = I3.ICS_INDST_USR_INVENTORY_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRETR_PROG_REP.KEY_HASH
       WHERE ICS_PRETR_PROG_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'PretreatmentProgramReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PretreatmentProgramReportSubmission');


-- /ICS_PRETR_PROG_REP/ICS_INDST_USR_INVENTORY/ICS_INDST_USR_INFO/ICS_IU_ENFRC_ACTN_INFO
INSERT INTO ics_flow_icis.ICS_IU_ENFRC_ACTN_INFO
     SELECT I5.*
              from ICS_PRETR_PROG_REP ICS_PRETR_PROG_REP 
 JOIN ICS_INDST_USR_INVENTORY I3
 ON I3.ICS_PRETR_PROG_REP_ID = ICS_PRETR_PROG_REP.ICS_PRETR_PROG_REP_ID 
 JOIN ICS_INDST_USR_INFO I4
 ON I4.ICS_INDST_USR_INVENTORY_ID = I3.ICS_INDST_USR_INVENTORY_ID 
 JOIN ICS_IU_ENFRC_ACTN_INFO I5
 ON I5.ICS_INDST_USR_INFO_ID = I4.ICS_INDST_USR_INFO_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRETR_PROG_REP.KEY_HASH
       WHERE ICS_PRETR_PROG_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'PretreatmentProgramReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PretreatmentProgramReportSubmission');


-- /ICS_PRETR_PROG_REP/ICS_INDST_USR_INVENTORY/ICS_INDST_USR_INFO/ICS_IU_ENFRC_ACTN_INFO/ICS_IU_ENF_ACTN_TYPES
INSERT INTO ics_flow_icis.ICS_IU_ENF_ACTN_TYPES
     SELECT I6.*
              from ICS_PRETR_PROG_REP ICS_PRETR_PROG_REP 
 JOIN ICS_INDST_USR_INVENTORY I3
 ON I3.ICS_PRETR_PROG_REP_ID = ICS_PRETR_PROG_REP.ICS_PRETR_PROG_REP_ID 
 JOIN ICS_INDST_USR_INFO I4
 ON I4.ICS_INDST_USR_INVENTORY_ID = I3.ICS_INDST_USR_INVENTORY_ID 
 JOIN ICS_IU_ENFRC_ACTN_INFO I5
 ON I5.ICS_INDST_USR_INFO_ID = I4.ICS_INDST_USR_INFO_ID 
 JOIN ICS_IU_ENF_ACTN_TYPES I6
 ON I6.ICS_IU_ENFRC_ACTN_INFO_ID = I5.ICS_IU_ENFRC_ACTN_INFO_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRETR_PROG_REP.KEY_HASH
       WHERE ICS_PRETR_PROG_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'PretreatmentProgramReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PretreatmentProgramReportSubmission');


-- /ICS_PRETR_PROG_REP/ICS_INDST_USR_INVENTORY/ICS_INDST_USR_INFO/ICS_IU_VIOL_INFO
INSERT INTO ics_flow_icis.ICS_IU_VIOL_INFO
     SELECT I7.*
              from ICS_PRETR_PROG_REP ICS_PRETR_PROG_REP 
 JOIN ICS_INDST_USR_INVENTORY I3
 ON I3.ICS_PRETR_PROG_REP_ID = ICS_PRETR_PROG_REP.ICS_PRETR_PROG_REP_ID 
 JOIN ICS_INDST_USR_INFO I4
 ON I4.ICS_INDST_USR_INVENTORY_ID = I3.ICS_INDST_USR_INVENTORY_ID 
 JOIN ICS_IU_VIOL_INFO I7
 ON I7.ICS_INDST_USR_INFO_ID = I4.ICS_INDST_USR_INFO_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRETR_PROG_REP.KEY_HASH
       WHERE ICS_PRETR_PROG_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'PretreatmentProgramReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PretreatmentProgramReportSubmission');


-- /ICS_PRETR_PROG_REP/ICS_INDST_USR_INVENTORY/ICS_INDST_USR_INFO/ICS_IU_VIOL_INFO/ICS_SNC_LISTING_MONTHS
INSERT INTO ics_flow_icis.ICS_SNC_LISTING_MONTHS
     SELECT I8.*
              from ICS_PRETR_PROG_REP ICS_PRETR_PROG_REP 
 JOIN ICS_INDST_USR_INVENTORY I3
 ON I3.ICS_PRETR_PROG_REP_ID = ICS_PRETR_PROG_REP.ICS_PRETR_PROG_REP_ID 
 JOIN ICS_INDST_USR_INFO I4
 ON I4.ICS_INDST_USR_INVENTORY_ID = I3.ICS_INDST_USR_INVENTORY_ID 
 JOIN ICS_IU_VIOL_INFO I7
 ON I7.ICS_INDST_USR_INFO_ID = I4.ICS_INDST_USR_INFO_ID 
 JOIN ICS_SNC_LISTING_MONTHS I8
 ON I8.ICS_IU_VIOL_INFO_ID = I7.ICS_IU_VIOL_INFO_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRETR_PROG_REP.KEY_HASH
       WHERE ICS_PRETR_PROG_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'PretreatmentProgramReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PretreatmentProgramReportSubmission');


-- /ICS_PRETR_PROG_REP/ICS_INDST_USR_INVENTORY/ICS_INDST_USR_INFO/ICS_IU_VIOL_INFO/ICS_SNC_PRETR_STND_LMTS_PARAMETERS
INSERT INTO ics_flow_icis.ICS_SNC_PRETR_STND_LMTS_PARAMETERS
     SELECT I9.*
              from ICS_PRETR_PROG_REP ICS_PRETR_PROG_REP 
 JOIN ICS_INDST_USR_INVENTORY I3
 ON I3.ICS_PRETR_PROG_REP_ID = ICS_PRETR_PROG_REP.ICS_PRETR_PROG_REP_ID 
 JOIN ICS_INDST_USR_INFO I4
 ON I4.ICS_INDST_USR_INVENTORY_ID = I3.ICS_INDST_USR_INVENTORY_ID 
 JOIN ICS_IU_VIOL_INFO I7
 ON I7.ICS_INDST_USR_INFO_ID = I4.ICS_INDST_USR_INFO_ID 
 JOIN ICS_SNC_PRETR_STND_LMTS_PARAMETERS I9
 ON I9.ICS_IU_VIOL_INFO_ID = I7.ICS_IU_VIOL_INFO_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_PRETR_PROG_REP.KEY_HASH
       WHERE ICS_PRETR_PROG_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'PretreatmentProgramReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'PretreatmentProgramReportSubmission');
	




-- Remove any old records for ICS_SCHD_EVT_VIOL
				
-- /ICS_SCHD_EVT_VIOL/ICS_CMPL_SCHD_EVT_VIOL_ELEM
DELETE
  FROM ics_flow_icis.ICS_CMPL_SCHD_EVT_VIOL_ELEM
 WHERE ICS_CMPL_SCHD_EVT_VIOL_ELEM.ICS_SCHD_EVT_VIOL_ID IN
          (SELECT I2.ICS_SCHD_EVT_VIOL_ID
              from ics_flow_icis.ICS_SCHD_EVT_VIOL ICS_SCHD_EVT_VIOL 
 JOIN ics_flow_icis.ICS_CMPL_SCHD_EVT_VIOL_ELEM I2
 ON I2.ICS_SCHD_EVT_VIOL_ID = ICS_SCHD_EVT_VIOL.ICS_SCHD_EVT_VIOL_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SCHD_EVT_VIOL.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ScheduleEventViolationSubmission')
                 
                 
);

				
-- /ICS_SCHD_EVT_VIOL/ICS_PRMT_SCHD_EVT_VIOL_ELEM
DELETE
  FROM ics_flow_icis.ICS_PRMT_SCHD_EVT_VIOL_ELEM
 WHERE ICS_PRMT_SCHD_EVT_VIOL_ELEM.ICS_SCHD_EVT_VIOL_ID IN
          (SELECT I1.ICS_SCHD_EVT_VIOL_ID
              from ics_flow_icis.ICS_SCHD_EVT_VIOL ICS_SCHD_EVT_VIOL 
 JOIN ics_flow_icis.ICS_PRMT_SCHD_EVT_VIOL_ELEM I1
 ON I1.ICS_SCHD_EVT_VIOL_ID = ICS_SCHD_EVT_VIOL.ICS_SCHD_EVT_VIOL_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SCHD_EVT_VIOL.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ScheduleEventViolationSubmission')
                 
                 
);

				
-- /ICS_SCHD_EVT_VIOL
DELETE
  FROM ics_flow_icis.ICS_SCHD_EVT_VIOL
 WHERE ICS_SCHD_EVT_VIOL.ICS_SCHD_EVT_VIOL_ID IN
          (SELECT ICS_SCHD_EVT_VIOL.ICS_SCHD_EVT_VIOL_ID
              from ics_flow_icis.ICS_SCHD_EVT_VIOL ICS_SCHD_EVT_VIOL 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SCHD_EVT_VIOL.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'ScheduleEventViolationSubmission')
                 
                 
);

	
-- Add accepted records for ICS_SCHD_EVT_VIOL


-- /ICS_SCHD_EVT_VIOL
INSERT INTO ics_flow_icis.ICS_SCHD_EVT_VIOL
     SELECT ICS_SCHD_EVT_VIOL.*
              from ICS_SCHD_EVT_VIOL ICS_SCHD_EVT_VIOL 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SCHD_EVT_VIOL.KEY_HASH
       WHERE ICS_SCHD_EVT_VIOL.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'ScheduleEventViolationSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ScheduleEventViolationSubmission');


-- /ICS_SCHD_EVT_VIOL/ICS_PRMT_SCHD_EVT_VIOL_ELEM
INSERT INTO ics_flow_icis.ICS_PRMT_SCHD_EVT_VIOL_ELEM
     SELECT I1.*
              from ICS_SCHD_EVT_VIOL ICS_SCHD_EVT_VIOL 
 JOIN ICS_PRMT_SCHD_EVT_VIOL_ELEM I1
 ON I1.ICS_SCHD_EVT_VIOL_ID = ICS_SCHD_EVT_VIOL.ICS_SCHD_EVT_VIOL_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SCHD_EVT_VIOL.KEY_HASH
       WHERE ICS_SCHD_EVT_VIOL.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'ScheduleEventViolationSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ScheduleEventViolationSubmission');


-- /ICS_SCHD_EVT_VIOL/ICS_CMPL_SCHD_EVT_VIOL_ELEM
INSERT INTO ics_flow_icis.ICS_CMPL_SCHD_EVT_VIOL_ELEM
     SELECT I2.*
              from ICS_SCHD_EVT_VIOL ICS_SCHD_EVT_VIOL 
 JOIN ICS_CMPL_SCHD_EVT_VIOL_ELEM I2
 ON I2.ICS_SCHD_EVT_VIOL_ID = ICS_SCHD_EVT_VIOL.ICS_SCHD_EVT_VIOL_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SCHD_EVT_VIOL.KEY_HASH
       WHERE ICS_SCHD_EVT_VIOL.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'ScheduleEventViolationSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'ScheduleEventViolationSubmission');
	




-- Remove any old records for ICS_SEWER_OVRFLW_BYPASS_EVT_REP
				
-- /ICS_SEWER_OVRFLW_BYPASS_EVT_REP/ICS_SEWER_OVRFLW_BYPASS_REP_EVT/ICS_BYPASS_TRTMNT_PLANT_EQUIPMENT
DELETE
  FROM ics_flow_icis.ICS_BYPASS_TRTMNT_PLANT_EQUIPMENT
 WHERE ICS_BYPASS_TRTMNT_PLANT_EQUIPMENT.ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID IN
          (SELECT I8.ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID
              from ics_flow_icis.ICS_SEWER_OVRFLW_BYPASS_EVT_REP ICS_SEWER_OVRFLW_BYPASS_EVT_REP 
 JOIN ics_flow_icis.ICS_SEWER_OVRFLW_BYPASS_REP_EVT I1
 ON I1.ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID = ICS_SEWER_OVRFLW_BYPASS_EVT_REP.ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID 
 JOIN ics_flow_icis.ICS_BYPASS_TRTMNT_PLANT_EQUIPMENT I8
 ON I8.ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID = I1.ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SEWER_OVRFLW_BYPASS_EVT_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SewerOverflowBypassEventReportSubmission')
                 
                 
);

				
-- /ICS_SEWER_OVRFLW_BYPASS_EVT_REP/ICS_SEWER_OVRFLW_BYPASS_REP_EVT/ICS_SEWER_OVRFLW_TRTMNT
DELETE
  FROM ics_flow_icis.ICS_SEWER_OVRFLW_TRTMNT
 WHERE ICS_SEWER_OVRFLW_TRTMNT.ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID IN
          (SELECT I7.ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID
              from ics_flow_icis.ICS_SEWER_OVRFLW_BYPASS_EVT_REP ICS_SEWER_OVRFLW_BYPASS_EVT_REP 
 JOIN ics_flow_icis.ICS_SEWER_OVRFLW_BYPASS_REP_EVT I1
 ON I1.ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID = ICS_SEWER_OVRFLW_BYPASS_EVT_REP.ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID 
 JOIN ics_flow_icis.ICS_SEWER_OVRFLW_TRTMNT I7
 ON I7.ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID = I1.ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SEWER_OVRFLW_BYPASS_EVT_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SewerOverflowBypassEventReportSubmission')
                 
                 
);

				
-- /ICS_SEWER_OVRFLW_BYPASS_EVT_REP/ICS_SEWER_OVRFLW_BYPASS_REP_EVT/ICS_SEWER_OVRFLW_BYPASS_TYPE
DELETE
  FROM ics_flow_icis.ICS_SEWER_OVRFLW_BYPASS_TYPE
 WHERE ICS_SEWER_OVRFLW_BYPASS_TYPE.ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID IN
          (SELECT I6.ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID
              from ics_flow_icis.ICS_SEWER_OVRFLW_BYPASS_EVT_REP ICS_SEWER_OVRFLW_BYPASS_EVT_REP 
 JOIN ics_flow_icis.ICS_SEWER_OVRFLW_BYPASS_REP_EVT I1
 ON I1.ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID = ICS_SEWER_OVRFLW_BYPASS_EVT_REP.ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID 
 JOIN ics_flow_icis.ICS_SEWER_OVRFLW_BYPASS_TYPE I6
 ON I6.ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID = I1.ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SEWER_OVRFLW_BYPASS_EVT_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SewerOverflowBypassEventReportSubmission')
                 
                 
);

				
-- /ICS_SEWER_OVRFLW_BYPASS_EVT_REP/ICS_SEWER_OVRFLW_BYPASS_REP_EVT/ICS_SEWER_OVRFLW_BYPASS_RCVG_WTR
DELETE
  FROM ics_flow_icis.ICS_SEWER_OVRFLW_BYPASS_RCVG_WTR
 WHERE ICS_SEWER_OVRFLW_BYPASS_RCVG_WTR.ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID IN
          (SELECT I5.ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID
              from ics_flow_icis.ICS_SEWER_OVRFLW_BYPASS_EVT_REP ICS_SEWER_OVRFLW_BYPASS_EVT_REP 
 JOIN ics_flow_icis.ICS_SEWER_OVRFLW_BYPASS_REP_EVT I1
 ON I1.ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID = ICS_SEWER_OVRFLW_BYPASS_EVT_REP.ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID 
 JOIN ics_flow_icis.ICS_SEWER_OVRFLW_BYPASS_RCVG_WTR I5
 ON I5.ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID = I1.ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SEWER_OVRFLW_BYPASS_EVT_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SewerOverflowBypassEventReportSubmission')
                 
                 
);

				
-- /ICS_SEWER_OVRFLW_BYPASS_EVT_REP/ICS_SEWER_OVRFLW_BYPASS_REP_EVT/ICS_SEWER_OVRFLW_BYPASS_IMPACT
DELETE
  FROM ics_flow_icis.ICS_SEWER_OVRFLW_BYPASS_IMPACT
 WHERE ICS_SEWER_OVRFLW_BYPASS_IMPACT.ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID IN
          (SELECT I4.ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID
              from ics_flow_icis.ICS_SEWER_OVRFLW_BYPASS_EVT_REP ICS_SEWER_OVRFLW_BYPASS_EVT_REP 
 JOIN ics_flow_icis.ICS_SEWER_OVRFLW_BYPASS_REP_EVT I1
 ON I1.ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID = ICS_SEWER_OVRFLW_BYPASS_EVT_REP.ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID 
 JOIN ics_flow_icis.ICS_SEWER_OVRFLW_BYPASS_IMPACT I4
 ON I4.ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID = I1.ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SEWER_OVRFLW_BYPASS_EVT_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SewerOverflowBypassEventReportSubmission')
                 
                 
);

				
-- /ICS_SEWER_OVRFLW_BYPASS_EVT_REP/ICS_SEWER_OVRFLW_BYPASS_REP_EVT/ICS_SEWER_OVRFLW_BYPASS_CORR_ACTN
DELETE
  FROM ics_flow_icis.ICS_SEWER_OVRFLW_BYPASS_CORR_ACTN
 WHERE ICS_SEWER_OVRFLW_BYPASS_CORR_ACTN.ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID IN
          (SELECT I3.ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID
              from ics_flow_icis.ICS_SEWER_OVRFLW_BYPASS_EVT_REP ICS_SEWER_OVRFLW_BYPASS_EVT_REP 
 JOIN ics_flow_icis.ICS_SEWER_OVRFLW_BYPASS_REP_EVT I1
 ON I1.ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID = ICS_SEWER_OVRFLW_BYPASS_EVT_REP.ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID 
 JOIN ics_flow_icis.ICS_SEWER_OVRFLW_BYPASS_CORR_ACTN I3
 ON I3.ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID = I1.ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SEWER_OVRFLW_BYPASS_EVT_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SewerOverflowBypassEventReportSubmission')
                 
                 
);

				
-- /ICS_SEWER_OVRFLW_BYPASS_EVT_REP/ICS_SEWER_OVRFLW_BYPASS_REP_EVT/ICS_SEWER_OVRFLW_BYPASS_CAUSE
DELETE
  FROM ics_flow_icis.ICS_SEWER_OVRFLW_BYPASS_CAUSE
 WHERE ICS_SEWER_OVRFLW_BYPASS_CAUSE.ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID IN
          (SELECT I2.ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID
              from ics_flow_icis.ICS_SEWER_OVRFLW_BYPASS_EVT_REP ICS_SEWER_OVRFLW_BYPASS_EVT_REP 
 JOIN ics_flow_icis.ICS_SEWER_OVRFLW_BYPASS_REP_EVT I1
 ON I1.ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID = ICS_SEWER_OVRFLW_BYPASS_EVT_REP.ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID 
 JOIN ics_flow_icis.ICS_SEWER_OVRFLW_BYPASS_CAUSE I2
 ON I2.ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID = I1.ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SEWER_OVRFLW_BYPASS_EVT_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SewerOverflowBypassEventReportSubmission')
                 
                 
);

				
-- /ICS_SEWER_OVRFLW_BYPASS_EVT_REP/ICS_SEWER_OVRFLW_BYPASS_REP_EVT
DELETE
  FROM ics_flow_icis.ICS_SEWER_OVRFLW_BYPASS_REP_EVT
 WHERE ICS_SEWER_OVRFLW_BYPASS_REP_EVT.ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID IN
          (SELECT I1.ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID
              from ics_flow_icis.ICS_SEWER_OVRFLW_BYPASS_EVT_REP ICS_SEWER_OVRFLW_BYPASS_EVT_REP 
 JOIN ics_flow_icis.ICS_SEWER_OVRFLW_BYPASS_REP_EVT I1
 ON I1.ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID = ICS_SEWER_OVRFLW_BYPASS_EVT_REP.ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SEWER_OVRFLW_BYPASS_EVT_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SewerOverflowBypassEventReportSubmission')
                 
                 
);

				
-- /ICS_SEWER_OVRFLW_BYPASS_EVT_REP
DELETE
  FROM ics_flow_icis.ICS_SEWER_OVRFLW_BYPASS_EVT_REP
 WHERE ICS_SEWER_OVRFLW_BYPASS_EVT_REP.ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID IN
          (SELECT ICS_SEWER_OVRFLW_BYPASS_EVT_REP.ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID
              from ics_flow_icis.ICS_SEWER_OVRFLW_BYPASS_EVT_REP ICS_SEWER_OVRFLW_BYPASS_EVT_REP 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SEWER_OVRFLW_BYPASS_EVT_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SewerOverflowBypassEventReportSubmission')
                 
                 
);

	
-- Add accepted records for ICS_SEWER_OVRFLW_BYPASS_EVT_REP


-- /ICS_SEWER_OVRFLW_BYPASS_EVT_REP
INSERT INTO ics_flow_icis.ICS_SEWER_OVRFLW_BYPASS_EVT_REP
     SELECT ICS_SEWER_OVRFLW_BYPASS_EVT_REP.*
              from ICS_SEWER_OVRFLW_BYPASS_EVT_REP ICS_SEWER_OVRFLW_BYPASS_EVT_REP 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SEWER_OVRFLW_BYPASS_EVT_REP.KEY_HASH
       WHERE ICS_SEWER_OVRFLW_BYPASS_EVT_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SewerOverflowBypassEventReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SewerOverflowBypassEventReportSubmission');


-- /ICS_SEWER_OVRFLW_BYPASS_EVT_REP/ICS_SEWER_OVRFLW_BYPASS_REP_EVT
INSERT INTO ics_flow_icis.ICS_SEWER_OVRFLW_BYPASS_REP_EVT
     SELECT I1.*
              from ICS_SEWER_OVRFLW_BYPASS_EVT_REP ICS_SEWER_OVRFLW_BYPASS_EVT_REP 
 JOIN ICS_SEWER_OVRFLW_BYPASS_REP_EVT I1
 ON I1.ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID = ICS_SEWER_OVRFLW_BYPASS_EVT_REP.ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SEWER_OVRFLW_BYPASS_EVT_REP.KEY_HASH
       WHERE ICS_SEWER_OVRFLW_BYPASS_EVT_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SewerOverflowBypassEventReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SewerOverflowBypassEventReportSubmission');


-- /ICS_SEWER_OVRFLW_BYPASS_EVT_REP/ICS_SEWER_OVRFLW_BYPASS_REP_EVT/ICS_SEWER_OVRFLW_BYPASS_CAUSE
INSERT INTO ics_flow_icis.ICS_SEWER_OVRFLW_BYPASS_CAUSE
     SELECT I2.*
              from ICS_SEWER_OVRFLW_BYPASS_EVT_REP ICS_SEWER_OVRFLW_BYPASS_EVT_REP 
 JOIN ICS_SEWER_OVRFLW_BYPASS_REP_EVT I1
 ON I1.ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID = ICS_SEWER_OVRFLW_BYPASS_EVT_REP.ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID 
 JOIN ICS_SEWER_OVRFLW_BYPASS_CAUSE I2
 ON I2.ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID = I1.ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SEWER_OVRFLW_BYPASS_EVT_REP.KEY_HASH
       WHERE ICS_SEWER_OVRFLW_BYPASS_EVT_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SewerOverflowBypassEventReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SewerOverflowBypassEventReportSubmission');


-- /ICS_SEWER_OVRFLW_BYPASS_EVT_REP/ICS_SEWER_OVRFLW_BYPASS_REP_EVT/ICS_SEWER_OVRFLW_BYPASS_CORR_ACTN
INSERT INTO ics_flow_icis.ICS_SEWER_OVRFLW_BYPASS_CORR_ACTN
     SELECT I3.*
              from ICS_SEWER_OVRFLW_BYPASS_EVT_REP ICS_SEWER_OVRFLW_BYPASS_EVT_REP 
 JOIN ICS_SEWER_OVRFLW_BYPASS_REP_EVT I1
 ON I1.ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID = ICS_SEWER_OVRFLW_BYPASS_EVT_REP.ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID 
 JOIN ICS_SEWER_OVRFLW_BYPASS_CORR_ACTN I3
 ON I3.ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID = I1.ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SEWER_OVRFLW_BYPASS_EVT_REP.KEY_HASH
       WHERE ICS_SEWER_OVRFLW_BYPASS_EVT_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SewerOverflowBypassEventReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SewerOverflowBypassEventReportSubmission');


-- /ICS_SEWER_OVRFLW_BYPASS_EVT_REP/ICS_SEWER_OVRFLW_BYPASS_REP_EVT/ICS_SEWER_OVRFLW_BYPASS_IMPACT
INSERT INTO ics_flow_icis.ICS_SEWER_OVRFLW_BYPASS_IMPACT
     SELECT I4.*
              from ICS_SEWER_OVRFLW_BYPASS_EVT_REP ICS_SEWER_OVRFLW_BYPASS_EVT_REP 
 JOIN ICS_SEWER_OVRFLW_BYPASS_REP_EVT I1
 ON I1.ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID = ICS_SEWER_OVRFLW_BYPASS_EVT_REP.ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID 
 JOIN ICS_SEWER_OVRFLW_BYPASS_IMPACT I4
 ON I4.ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID = I1.ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SEWER_OVRFLW_BYPASS_EVT_REP.KEY_HASH
       WHERE ICS_SEWER_OVRFLW_BYPASS_EVT_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SewerOverflowBypassEventReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SewerOverflowBypassEventReportSubmission');


-- /ICS_SEWER_OVRFLW_BYPASS_EVT_REP/ICS_SEWER_OVRFLW_BYPASS_REP_EVT/ICS_SEWER_OVRFLW_BYPASS_RCVG_WTR
INSERT INTO ics_flow_icis.ICS_SEWER_OVRFLW_BYPASS_RCVG_WTR
     SELECT I5.*
              from ICS_SEWER_OVRFLW_BYPASS_EVT_REP ICS_SEWER_OVRFLW_BYPASS_EVT_REP 
 JOIN ICS_SEWER_OVRFLW_BYPASS_REP_EVT I1
 ON I1.ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID = ICS_SEWER_OVRFLW_BYPASS_EVT_REP.ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID 
 JOIN ICS_SEWER_OVRFLW_BYPASS_RCVG_WTR I5
 ON I5.ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID = I1.ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SEWER_OVRFLW_BYPASS_EVT_REP.KEY_HASH
       WHERE ICS_SEWER_OVRFLW_BYPASS_EVT_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SewerOverflowBypassEventReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SewerOverflowBypassEventReportSubmission');


-- /ICS_SEWER_OVRFLW_BYPASS_EVT_REP/ICS_SEWER_OVRFLW_BYPASS_REP_EVT/ICS_SEWER_OVRFLW_BYPASS_TYPE
INSERT INTO ics_flow_icis.ICS_SEWER_OVRFLW_BYPASS_TYPE
     SELECT I6.*
              from ICS_SEWER_OVRFLW_BYPASS_EVT_REP ICS_SEWER_OVRFLW_BYPASS_EVT_REP 
 JOIN ICS_SEWER_OVRFLW_BYPASS_REP_EVT I1
 ON I1.ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID = ICS_SEWER_OVRFLW_BYPASS_EVT_REP.ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID 
 JOIN ICS_SEWER_OVRFLW_BYPASS_TYPE I6
 ON I6.ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID = I1.ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SEWER_OVRFLW_BYPASS_EVT_REP.KEY_HASH
       WHERE ICS_SEWER_OVRFLW_BYPASS_EVT_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SewerOverflowBypassEventReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SewerOverflowBypassEventReportSubmission');


-- /ICS_SEWER_OVRFLW_BYPASS_EVT_REP/ICS_SEWER_OVRFLW_BYPASS_REP_EVT/ICS_SEWER_OVRFLW_TRTMNT
INSERT INTO ics_flow_icis.ICS_SEWER_OVRFLW_TRTMNT
     SELECT I7.*
              from ICS_SEWER_OVRFLW_BYPASS_EVT_REP ICS_SEWER_OVRFLW_BYPASS_EVT_REP 
 JOIN ICS_SEWER_OVRFLW_BYPASS_REP_EVT I1
 ON I1.ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID = ICS_SEWER_OVRFLW_BYPASS_EVT_REP.ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID 
 JOIN ICS_SEWER_OVRFLW_TRTMNT I7
 ON I7.ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID = I1.ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SEWER_OVRFLW_BYPASS_EVT_REP.KEY_HASH
       WHERE ICS_SEWER_OVRFLW_BYPASS_EVT_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SewerOverflowBypassEventReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SewerOverflowBypassEventReportSubmission');


-- /ICS_SEWER_OVRFLW_BYPASS_EVT_REP/ICS_SEWER_OVRFLW_BYPASS_REP_EVT/ICS_BYPASS_TRTMNT_PLANT_EQUIPMENT
INSERT INTO ics_flow_icis.ICS_BYPASS_TRTMNT_PLANT_EQUIPMENT
     SELECT I8.*
              from ICS_SEWER_OVRFLW_BYPASS_EVT_REP ICS_SEWER_OVRFLW_BYPASS_EVT_REP 
 JOIN ICS_SEWER_OVRFLW_BYPASS_REP_EVT I1
 ON I1.ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID = ICS_SEWER_OVRFLW_BYPASS_EVT_REP.ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID 
 JOIN ICS_BYPASS_TRTMNT_PLANT_EQUIPMENT I8
 ON I8.ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID = I1.ICS_SEWER_OVRFLW_BYPASS_REP_EVT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SEWER_OVRFLW_BYPASS_EVT_REP.KEY_HASH
       WHERE ICS_SEWER_OVRFLW_BYPASS_EVT_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SewerOverflowBypassEventReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SewerOverflowBypassEventReportSubmission');
	




-- Remove any old records for ICS_SNGL_EVT_VIOL
				
-- /ICS_SNGL_EVT_VIOL
DELETE
  FROM ics_flow_icis.ICS_SNGL_EVT_VIOL
 WHERE ICS_SNGL_EVT_VIOL.ICS_SNGL_EVT_VIOL_ID IN
          (SELECT ICS_SNGL_EVT_VIOL.ICS_SNGL_EVT_VIOL_ID
              from ics_flow_icis.ICS_SNGL_EVT_VIOL ICS_SNGL_EVT_VIOL 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SNGL_EVT_VIOL.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SingleEventViolationSubmission')
                  OR ICS_SNGL_EVT_VIOL.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

	
-- Add accepted records for ICS_SNGL_EVT_VIOL


-- /ICS_SNGL_EVT_VIOL
INSERT INTO ics_flow_icis.ICS_SNGL_EVT_VIOL
     SELECT ICS_SNGL_EVT_VIOL.*
              from ICS_SNGL_EVT_VIOL ICS_SNGL_EVT_VIOL 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SNGL_EVT_VIOL.KEY_HASH
       WHERE ICS_SNGL_EVT_VIOL.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SingleEventViolationSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SingleEventViolationSubmission');
	




-- Remove any old records for ICS_SW_CNST_PRMT
				
-- /ICS_SW_CNST_PRMT/ICS_CNST_SITE_LIST/ICS_CNST_SITE
DELETE
  FROM ics_flow_icis.ICS_CNST_SITE
 WHERE ICS_CNST_SITE.ICS_CNST_SITE_LIST_ID IN
          (SELECT I11.ICS_CNST_SITE_LIST_ID
              from ics_flow_icis.ICS_SW_CNST_PRMT ICS_SW_CNST_PRMT 
 JOIN ics_flow_icis.ICS_CNST_SITE_LIST I10
 ON I10.ICS_SW_CNST_PRMT_ID = ICS_SW_CNST_PRMT.ICS_SW_CNST_PRMT_ID 
 JOIN ics_flow_icis.ICS_CNST_SITE I11
 ON I11.ICS_CNST_SITE_LIST_ID = I10.ICS_CNST_SITE_LIST_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_CNST_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWConstructionPermitSubmission')
                  OR ICS_SW_CNST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_SW_CNST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_SW_CNST_PRMT/ICS_CNST_SITE_LIST
DELETE
  FROM ics_flow_icis.ICS_CNST_SITE_LIST
 WHERE ICS_CNST_SITE_LIST.ICS_SW_CNST_PRMT_ID IN
          (SELECT I10.ICS_SW_CNST_PRMT_ID
              from ics_flow_icis.ICS_SW_CNST_PRMT ICS_SW_CNST_PRMT 
 JOIN ics_flow_icis.ICS_CNST_SITE_LIST I10
 ON I10.ICS_SW_CNST_PRMT_ID = ICS_SW_CNST_PRMT.ICS_SW_CNST_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_CNST_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWConstructionPermitSubmission')
                  OR ICS_SW_CNST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_SW_CNST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_SW_CNST_PRMT/ICS_TRTMNT_CHEMS_LIST
DELETE
  FROM ics_flow_icis.ICS_TRTMNT_CHEMS_LIST
 WHERE ICS_TRTMNT_CHEMS_LIST.ICS_SW_CNST_PRMT_ID IN
          (SELECT I9.ICS_SW_CNST_PRMT_ID
              from ics_flow_icis.ICS_SW_CNST_PRMT ICS_SW_CNST_PRMT 
 JOIN ics_flow_icis.ICS_TRTMNT_CHEMS_LIST I9
 ON I9.ICS_SW_CNST_PRMT_ID = ICS_SW_CNST_PRMT.ICS_SW_CNST_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_CNST_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWConstructionPermitSubmission')
                  OR ICS_SW_CNST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_SW_CNST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_SW_CNST_PRMT/ICS_ADDR/ICS_TELEPH
DELETE
  FROM ics_flow_icis.ICS_TELEPH
 WHERE ICS_TELEPH.ICS_ADDR_ID IN
          (SELECT I8.ICS_ADDR_ID
              from ics_flow_icis.ICS_SW_CNST_PRMT ICS_SW_CNST_PRMT 
 JOIN ics_flow_icis.ICS_ADDR I7
 ON I7.ICS_SW_CNST_PRMT_ID = ICS_SW_CNST_PRMT.ICS_SW_CNST_PRMT_ID 
 JOIN ics_flow_icis.ICS_TELEPH I8
 ON I8.ICS_ADDR_ID = I7.ICS_ADDR_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_CNST_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWConstructionPermitSubmission')
                  OR ICS_SW_CNST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_SW_CNST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_SW_CNST_PRMT/ICS_ADDR
DELETE
  FROM ics_flow_icis.ICS_ADDR
 WHERE ICS_ADDR.ICS_SW_CNST_PRMT_ID IN
          (SELECT I7.ICS_SW_CNST_PRMT_ID
              from ics_flow_icis.ICS_SW_CNST_PRMT ICS_SW_CNST_PRMT 
 JOIN ics_flow_icis.ICS_ADDR I7
 ON I7.ICS_SW_CNST_PRMT_ID = ICS_SW_CNST_PRMT.ICS_SW_CNST_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_CNST_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWConstructionPermitSubmission')
                  OR ICS_SW_CNST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_SW_CNST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_SW_CNST_PRMT/ICS_GPCF_NOTICE_OF_INTENT/ICS_SUBSECTOR_CODE_PLUS_DESC
DELETE
  FROM ics_flow_icis.ICS_SUBSECTOR_CODE_PLUS_DESC
 WHERE ICS_SUBSECTOR_CODE_PLUS_DESC.ICS_GPCF_NOTICE_OF_INTENT_ID IN
          (SELECT I6.ICS_GPCF_NOTICE_OF_INTENT_ID
              from ics_flow_icis.ICS_SW_CNST_PRMT ICS_SW_CNST_PRMT 
 JOIN ics_flow_icis.ICS_GPCF_NOTICE_OF_INTENT I5
 ON I5.ICS_SW_CNST_PRMT_ID = ICS_SW_CNST_PRMT.ICS_SW_CNST_PRMT_ID 
 JOIN ics_flow_icis.ICS_SUBSECTOR_CODE_PLUS_DESC I6
 ON I6.ICS_GPCF_NOTICE_OF_INTENT_ID = I5.ICS_GPCF_NOTICE_OF_INTENT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_CNST_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWConstructionPermitSubmission')
                  OR ICS_SW_CNST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_SW_CNST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_SW_CNST_PRMT/ICS_GPCF_NOTICE_OF_INTENT
DELETE
  FROM ics_flow_icis.ICS_GPCF_NOTICE_OF_INTENT
 WHERE ICS_GPCF_NOTICE_OF_INTENT.ICS_SW_CNST_PRMT_ID IN
          (SELECT I5.ICS_SW_CNST_PRMT_ID
              from ics_flow_icis.ICS_SW_CNST_PRMT ICS_SW_CNST_PRMT 
 JOIN ics_flow_icis.ICS_GPCF_NOTICE_OF_INTENT I5
 ON I5.ICS_SW_CNST_PRMT_ID = ICS_SW_CNST_PRMT.ICS_SW_CNST_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_CNST_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWConstructionPermitSubmission')
                  OR ICS_SW_CNST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_SW_CNST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_SW_CNST_PRMT/ICS_PROPOSED_POST_CNST_SW_BM_PS
DELETE
  FROM ics_flow_icis.ICS_PROPOSED_POST_CNST_SW_BM_PS
 WHERE ICS_PROPOSED_POST_CNST_SW_BM_PS.ICS_SW_CNST_PRMT_ID IN
          (SELECT I4.ICS_SW_CNST_PRMT_ID
              from ics_flow_icis.ICS_SW_CNST_PRMT ICS_SW_CNST_PRMT 
 JOIN ics_flow_icis.ICS_PROPOSED_POST_CNST_SW_BM_PS I4
 ON I4.ICS_SW_CNST_PRMT_ID = ICS_SW_CNST_PRMT.ICS_SW_CNST_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_CNST_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWConstructionPermitSubmission')
                  OR ICS_SW_CNST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_SW_CNST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_SW_CNST_PRMT/ICS_PROPOSED_CNST_SW_BM_PS
DELETE
  FROM ics_flow_icis.ICS_PROPOSED_CNST_SW_BM_PS
 WHERE ICS_PROPOSED_CNST_SW_BM_PS.ICS_SW_CNST_PRMT_ID IN
          (SELECT I3.ICS_SW_CNST_PRMT_ID
              from ics_flow_icis.ICS_SW_CNST_PRMT ICS_SW_CNST_PRMT 
 JOIN ics_flow_icis.ICS_PROPOSED_CNST_SW_BM_PS I3
 ON I3.ICS_SW_CNST_PRMT_ID = ICS_SW_CNST_PRMT.ICS_SW_CNST_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_CNST_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWConstructionPermitSubmission')
                  OR ICS_SW_CNST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_SW_CNST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_SW_CNST_PRMT/ICS_CONTACT/ICS_TELEPH
DELETE
  FROM ics_flow_icis.ICS_TELEPH
 WHERE ICS_TELEPH.ICS_CONTACT_ID IN
          (SELECT I2.ICS_CONTACT_ID
              from ics_flow_icis.ICS_SW_CNST_PRMT ICS_SW_CNST_PRMT 
 JOIN ics_flow_icis.ICS_CONTACT I1
 ON I1.ICS_SW_CNST_PRMT_ID = ICS_SW_CNST_PRMT.ICS_SW_CNST_PRMT_ID 
 JOIN ics_flow_icis.ICS_TELEPH I2
 ON I2.ICS_CONTACT_ID = I1.ICS_CONTACT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_CNST_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWConstructionPermitSubmission')
                  OR ICS_SW_CNST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_SW_CNST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_SW_CNST_PRMT/ICS_CONTACT
DELETE
  FROM ics_flow_icis.ICS_CONTACT
 WHERE ICS_CONTACT.ICS_SW_CNST_PRMT_ID IN
          (SELECT I1.ICS_SW_CNST_PRMT_ID
              from ics_flow_icis.ICS_SW_CNST_PRMT ICS_SW_CNST_PRMT 
 JOIN ics_flow_icis.ICS_CONTACT I1
 ON I1.ICS_SW_CNST_PRMT_ID = ICS_SW_CNST_PRMT.ICS_SW_CNST_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_CNST_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWConstructionPermitSubmission')
                  OR ICS_SW_CNST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_SW_CNST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_SW_CNST_PRMT
DELETE
  FROM ics_flow_icis.ICS_SW_CNST_PRMT
 WHERE ICS_SW_CNST_PRMT.ICS_SW_CNST_PRMT_ID IN
          (SELECT ICS_SW_CNST_PRMT.ICS_SW_CNST_PRMT_ID
              from ics_flow_icis.ICS_SW_CNST_PRMT ICS_SW_CNST_PRMT 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_CNST_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWConstructionPermitSubmission')
                  OR ICS_SW_CNST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_SW_CNST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

	
-- Add accepted records for ICS_SW_CNST_PRMT


-- /ICS_SW_CNST_PRMT
INSERT INTO ics_flow_icis.ICS_SW_CNST_PRMT
     SELECT ICS_SW_CNST_PRMT.*
              from ICS_SW_CNST_PRMT ICS_SW_CNST_PRMT 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_CNST_PRMT.KEY_HASH
       WHERE ICS_SW_CNST_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SWConstructionPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWConstructionPermitSubmission');


-- /ICS_SW_CNST_PRMT/ICS_CONTACT
INSERT INTO ics_flow_icis.ICS_CONTACT
     SELECT I1.*
              from ICS_SW_CNST_PRMT ICS_SW_CNST_PRMT 
 JOIN ICS_CONTACT I1
 ON I1.ICS_SW_CNST_PRMT_ID = ICS_SW_CNST_PRMT.ICS_SW_CNST_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_CNST_PRMT.KEY_HASH
       WHERE ICS_SW_CNST_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SWConstructionPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWConstructionPermitSubmission');


-- /ICS_SW_CNST_PRMT/ICS_CONTACT/ICS_TELEPH
INSERT INTO ics_flow_icis.ICS_TELEPH
     SELECT I2.*
              from ICS_SW_CNST_PRMT ICS_SW_CNST_PRMT 
 JOIN ICS_CONTACT I1
 ON I1.ICS_SW_CNST_PRMT_ID = ICS_SW_CNST_PRMT.ICS_SW_CNST_PRMT_ID 
 JOIN ICS_TELEPH I2
 ON I2.ICS_CONTACT_ID = I1.ICS_CONTACT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_CNST_PRMT.KEY_HASH
       WHERE ICS_SW_CNST_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SWConstructionPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWConstructionPermitSubmission');


-- /ICS_SW_CNST_PRMT/ICS_PROPOSED_CNST_SW_BM_PS
INSERT INTO ics_flow_icis.ICS_PROPOSED_CNST_SW_BM_PS
     SELECT I3.*
              from ICS_SW_CNST_PRMT ICS_SW_CNST_PRMT 
 JOIN ICS_PROPOSED_CNST_SW_BM_PS I3
 ON I3.ICS_SW_CNST_PRMT_ID = ICS_SW_CNST_PRMT.ICS_SW_CNST_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_CNST_PRMT.KEY_HASH
       WHERE ICS_SW_CNST_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SWConstructionPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWConstructionPermitSubmission');


-- /ICS_SW_CNST_PRMT/ICS_PROPOSED_POST_CNST_SW_BM_PS
INSERT INTO ics_flow_icis.ICS_PROPOSED_POST_CNST_SW_BM_PS
     SELECT I4.*
              from ICS_SW_CNST_PRMT ICS_SW_CNST_PRMT 
 JOIN ICS_PROPOSED_POST_CNST_SW_BM_PS I4
 ON I4.ICS_SW_CNST_PRMT_ID = ICS_SW_CNST_PRMT.ICS_SW_CNST_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_CNST_PRMT.KEY_HASH
       WHERE ICS_SW_CNST_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SWConstructionPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWConstructionPermitSubmission');


-- /ICS_SW_CNST_PRMT/ICS_GPCF_NOTICE_OF_INTENT
INSERT INTO ics_flow_icis.ICS_GPCF_NOTICE_OF_INTENT
     SELECT I5.*
              from ICS_SW_CNST_PRMT ICS_SW_CNST_PRMT 
 JOIN ICS_GPCF_NOTICE_OF_INTENT I5
 ON I5.ICS_SW_CNST_PRMT_ID = ICS_SW_CNST_PRMT.ICS_SW_CNST_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_CNST_PRMT.KEY_HASH
       WHERE ICS_SW_CNST_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SWConstructionPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWConstructionPermitSubmission');


-- /ICS_SW_CNST_PRMT/ICS_GPCF_NOTICE_OF_INTENT/ICS_SUBSECTOR_CODE_PLUS_DESC
INSERT INTO ics_flow_icis.ICS_SUBSECTOR_CODE_PLUS_DESC
     SELECT I6.*
              from ICS_SW_CNST_PRMT ICS_SW_CNST_PRMT 
 JOIN ICS_GPCF_NOTICE_OF_INTENT I5
 ON I5.ICS_SW_CNST_PRMT_ID = ICS_SW_CNST_PRMT.ICS_SW_CNST_PRMT_ID 
 JOIN ICS_SUBSECTOR_CODE_PLUS_DESC I6
 ON I6.ICS_GPCF_NOTICE_OF_INTENT_ID = I5.ICS_GPCF_NOTICE_OF_INTENT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_CNST_PRMT.KEY_HASH
       WHERE ICS_SW_CNST_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SWConstructionPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWConstructionPermitSubmission');


-- /ICS_SW_CNST_PRMT/ICS_ADDR
INSERT INTO ics_flow_icis.ICS_ADDR
     SELECT I7.*
              from ICS_SW_CNST_PRMT ICS_SW_CNST_PRMT 
 JOIN ICS_ADDR I7
 ON I7.ICS_SW_CNST_PRMT_ID = ICS_SW_CNST_PRMT.ICS_SW_CNST_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_CNST_PRMT.KEY_HASH
       WHERE ICS_SW_CNST_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SWConstructionPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWConstructionPermitSubmission');


-- /ICS_SW_CNST_PRMT/ICS_ADDR/ICS_TELEPH
INSERT INTO ics_flow_icis.ICS_TELEPH
     SELECT I8.*
              from ICS_SW_CNST_PRMT ICS_SW_CNST_PRMT 
 JOIN ICS_ADDR I7
 ON I7.ICS_SW_CNST_PRMT_ID = ICS_SW_CNST_PRMT.ICS_SW_CNST_PRMT_ID 
 JOIN ICS_TELEPH I8
 ON I8.ICS_ADDR_ID = I7.ICS_ADDR_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_CNST_PRMT.KEY_HASH
       WHERE ICS_SW_CNST_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SWConstructionPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWConstructionPermitSubmission');


-- /ICS_SW_CNST_PRMT/ICS_TRTMNT_CHEMS_LIST
INSERT INTO ics_flow_icis.ICS_TRTMNT_CHEMS_LIST
     SELECT I9.*
              from ICS_SW_CNST_PRMT ICS_SW_CNST_PRMT 
 JOIN ICS_TRTMNT_CHEMS_LIST I9
 ON I9.ICS_SW_CNST_PRMT_ID = ICS_SW_CNST_PRMT.ICS_SW_CNST_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_CNST_PRMT.KEY_HASH
       WHERE ICS_SW_CNST_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SWConstructionPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWConstructionPermitSubmission');


-- /ICS_SW_CNST_PRMT/ICS_CNST_SITE_LIST
INSERT INTO ics_flow_icis.ICS_CNST_SITE_LIST
     SELECT I10.*
              from ICS_SW_CNST_PRMT ICS_SW_CNST_PRMT 
 JOIN ICS_CNST_SITE_LIST I10
 ON I10.ICS_SW_CNST_PRMT_ID = ICS_SW_CNST_PRMT.ICS_SW_CNST_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_CNST_PRMT.KEY_HASH
       WHERE ICS_SW_CNST_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SWConstructionPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWConstructionPermitSubmission');


-- /ICS_SW_CNST_PRMT/ICS_CNST_SITE_LIST/ICS_CNST_SITE
INSERT INTO ics_flow_icis.ICS_CNST_SITE
     SELECT I11.*
              from ICS_SW_CNST_PRMT ICS_SW_CNST_PRMT 
 JOIN ICS_CNST_SITE_LIST I10
 ON I10.ICS_SW_CNST_PRMT_ID = ICS_SW_CNST_PRMT.ICS_SW_CNST_PRMT_ID 
 JOIN ICS_CNST_SITE I11
 ON I11.ICS_CNST_SITE_LIST_ID = I10.ICS_CNST_SITE_LIST_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_CNST_PRMT.KEY_HASH
       WHERE ICS_SW_CNST_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SWConstructionPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWConstructionPermitSubmission');
	




-- Remove any old records for ICS_SW_INDST_ANNUL_REP
				
-- /ICS_SW_INDST_ANNUL_REP
DELETE
  FROM ics_flow_icis.ICS_SW_INDST_ANNUL_REP
 WHERE ICS_SW_INDST_ANNUL_REP.ICS_SW_INDST_ANNUL_REP_ID IN
          (SELECT ICS_SW_INDST_ANNUL_REP.ICS_SW_INDST_ANNUL_REP_ID
              from ics_flow_icis.ICS_SW_INDST_ANNUL_REP ICS_SW_INDST_ANNUL_REP 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_INDST_ANNUL_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWIndustrialAnnualReportSubmission')
                  OR ICS_SW_INDST_ANNUL_REP.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

	
-- Add accepted records for ICS_SW_INDST_ANNUL_REP


-- /ICS_SW_INDST_ANNUL_REP
INSERT INTO ics_flow_icis.ICS_SW_INDST_ANNUL_REP
     SELECT ICS_SW_INDST_ANNUL_REP.*
              from ICS_SW_INDST_ANNUL_REP ICS_SW_INDST_ANNUL_REP 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_INDST_ANNUL_REP.KEY_HASH
       WHERE ICS_SW_INDST_ANNUL_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SWIndustrialAnnualReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWIndustrialAnnualReportSubmission');
	




-- Remove any old records for ICS_SW_INDST_PRMT
				
-- /ICS_SW_INDST_PRMT/ICS_ADDR/ICS_TELEPH
DELETE
  FROM ics_flow_icis.ICS_TELEPH
 WHERE ICS_TELEPH.ICS_ADDR_ID IN
          (SELECT I9.ICS_ADDR_ID
              from ics_flow_icis.ICS_SW_INDST_PRMT ICS_SW_INDST_PRMT 
 JOIN ics_flow_icis.ICS_ADDR I8
 ON I8.ICS_SW_INDST_PRMT_ID = ICS_SW_INDST_PRMT.ICS_SW_INDST_PRMT_ID 
 JOIN ics_flow_icis.ICS_TELEPH I9
 ON I9.ICS_ADDR_ID = I8.ICS_ADDR_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_INDST_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWIndustrialPermitSubmission')
                  OR ICS_SW_INDST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_SW_INDST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_SW_INDST_PRMT/ICS_ADDR
DELETE
  FROM ics_flow_icis.ICS_ADDR
 WHERE ICS_ADDR.ICS_SW_INDST_PRMT_ID IN
          (SELECT I8.ICS_SW_INDST_PRMT_ID
              from ics_flow_icis.ICS_SW_INDST_PRMT ICS_SW_INDST_PRMT 
 JOIN ics_flow_icis.ICS_ADDR I8
 ON I8.ICS_SW_INDST_PRMT_ID = ICS_SW_INDST_PRMT.ICS_SW_INDST_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_INDST_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWIndustrialPermitSubmission')
                  OR ICS_SW_INDST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_SW_INDST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_SW_INDST_PRMT/ICS_GPCF_NOTICE_OF_TERM
DELETE
  FROM ics_flow_icis.ICS_GPCF_NOTICE_OF_TERM
 WHERE ICS_GPCF_NOTICE_OF_TERM.ICS_SW_INDST_PRMT_ID IN
          (SELECT I7.ICS_SW_INDST_PRMT_ID
              from ics_flow_icis.ICS_SW_INDST_PRMT ICS_SW_INDST_PRMT 
 JOIN ics_flow_icis.ICS_GPCF_NOTICE_OF_TERM I7
 ON I7.ICS_SW_INDST_PRMT_ID = ICS_SW_INDST_PRMT.ICS_SW_INDST_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_INDST_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWIndustrialPermitSubmission')
                  OR ICS_SW_INDST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_SW_INDST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_SW_INDST_PRMT/ICS_GPCF_NOTICE_OF_INTENT/ICS_SUBSECTOR_CODE_PLUS_DESC
DELETE
  FROM ics_flow_icis.ICS_SUBSECTOR_CODE_PLUS_DESC
 WHERE ICS_SUBSECTOR_CODE_PLUS_DESC.ICS_GPCF_NOTICE_OF_INTENT_ID IN
          (SELECT I6.ICS_GPCF_NOTICE_OF_INTENT_ID
              from ics_flow_icis.ICS_SW_INDST_PRMT ICS_SW_INDST_PRMT 
 JOIN ics_flow_icis.ICS_GPCF_NOTICE_OF_INTENT I5
 ON I5.ICS_SW_INDST_PRMT_ID = ICS_SW_INDST_PRMT.ICS_SW_INDST_PRMT_ID 
 JOIN ics_flow_icis.ICS_SUBSECTOR_CODE_PLUS_DESC I6
 ON I6.ICS_GPCF_NOTICE_OF_INTENT_ID = I5.ICS_GPCF_NOTICE_OF_INTENT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_INDST_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWIndustrialPermitSubmission')
                  OR ICS_SW_INDST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_SW_INDST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_SW_INDST_PRMT/ICS_GPCF_NOTICE_OF_INTENT
DELETE
  FROM ics_flow_icis.ICS_GPCF_NOTICE_OF_INTENT
 WHERE ICS_GPCF_NOTICE_OF_INTENT.ICS_SW_INDST_PRMT_ID IN
          (SELECT I5.ICS_SW_INDST_PRMT_ID
              from ics_flow_icis.ICS_SW_INDST_PRMT ICS_SW_INDST_PRMT 
 JOIN ics_flow_icis.ICS_GPCF_NOTICE_OF_INTENT I5
 ON I5.ICS_SW_INDST_PRMT_ID = ICS_SW_INDST_PRMT.ICS_SW_INDST_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_INDST_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWIndustrialPermitSubmission')
                  OR ICS_SW_INDST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_SW_INDST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_SW_INDST_PRMT/ICS_GPCF_NO_EXPOSURE
DELETE
  FROM ics_flow_icis.ICS_GPCF_NO_EXPOSURE
 WHERE ICS_GPCF_NO_EXPOSURE.ICS_SW_INDST_PRMT_ID IN
          (SELECT I4.ICS_SW_INDST_PRMT_ID
              from ics_flow_icis.ICS_SW_INDST_PRMT ICS_SW_INDST_PRMT 
 JOIN ics_flow_icis.ICS_GPCF_NO_EXPOSURE I4
 ON I4.ICS_SW_INDST_PRMT_ID = ICS_SW_INDST_PRMT.ICS_SW_INDST_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_INDST_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWIndustrialPermitSubmission')
                  OR ICS_SW_INDST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_SW_INDST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_SW_INDST_PRMT/ICS_PROPOSED_INDST_SW_BM_PS
DELETE
  FROM ics_flow_icis.ICS_PROPOSED_INDST_SW_BM_PS
 WHERE ICS_PROPOSED_INDST_SW_BM_PS.ICS_SW_INDST_PRMT_ID IN
          (SELECT I3.ICS_SW_INDST_PRMT_ID
              from ics_flow_icis.ICS_SW_INDST_PRMT ICS_SW_INDST_PRMT 
 JOIN ics_flow_icis.ICS_PROPOSED_INDST_SW_BM_PS I3
 ON I3.ICS_SW_INDST_PRMT_ID = ICS_SW_INDST_PRMT.ICS_SW_INDST_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_INDST_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWIndustrialPermitSubmission')
                  OR ICS_SW_INDST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_SW_INDST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_SW_INDST_PRMT/ICS_CONTACT/ICS_TELEPH
DELETE
  FROM ics_flow_icis.ICS_TELEPH
 WHERE ICS_TELEPH.ICS_CONTACT_ID IN
          (SELECT I2.ICS_CONTACT_ID
              from ics_flow_icis.ICS_SW_INDST_PRMT ICS_SW_INDST_PRMT 
 JOIN ics_flow_icis.ICS_CONTACT I1
 ON I1.ICS_SW_INDST_PRMT_ID = ICS_SW_INDST_PRMT.ICS_SW_INDST_PRMT_ID 
 JOIN ics_flow_icis.ICS_TELEPH I2
 ON I2.ICS_CONTACT_ID = I1.ICS_CONTACT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_INDST_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWIndustrialPermitSubmission')
                  OR ICS_SW_INDST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_SW_INDST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_SW_INDST_PRMT/ICS_CONTACT
DELETE
  FROM ics_flow_icis.ICS_CONTACT
 WHERE ICS_CONTACT.ICS_SW_INDST_PRMT_ID IN
          (SELECT I1.ICS_SW_INDST_PRMT_ID
              from ics_flow_icis.ICS_SW_INDST_PRMT ICS_SW_INDST_PRMT 
 JOIN ics_flow_icis.ICS_CONTACT I1
 ON I1.ICS_SW_INDST_PRMT_ID = ICS_SW_INDST_PRMT.ICS_SW_INDST_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_INDST_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWIndustrialPermitSubmission')
                  OR ICS_SW_INDST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_SW_INDST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

				
-- /ICS_SW_INDST_PRMT
DELETE
  FROM ics_flow_icis.ICS_SW_INDST_PRMT
 WHERE ICS_SW_INDST_PRMT.ICS_SW_INDST_PRMT_ID IN
          (SELECT ICS_SW_INDST_PRMT.ICS_SW_INDST_PRMT_ID
              from ics_flow_icis.ICS_SW_INDST_PRMT ICS_SW_INDST_PRMT 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_INDST_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWIndustrialPermitSubmission')
                  OR ICS_SW_INDST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 OR ICS_SW_INDST_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitReissuanceSubmission' AND result_code = 'REI030')
);

	
-- Add accepted records for ICS_SW_INDST_PRMT


-- /ICS_SW_INDST_PRMT
INSERT INTO ics_flow_icis.ICS_SW_INDST_PRMT
     SELECT ICS_SW_INDST_PRMT.*
              from ICS_SW_INDST_PRMT ICS_SW_INDST_PRMT 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_INDST_PRMT.KEY_HASH
       WHERE ICS_SW_INDST_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SWIndustrialPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWIndustrialPermitSubmission');


-- /ICS_SW_INDST_PRMT/ICS_CONTACT
INSERT INTO ics_flow_icis.ICS_CONTACT
     SELECT I1.*
              from ICS_SW_INDST_PRMT ICS_SW_INDST_PRMT 
 JOIN ICS_CONTACT I1
 ON I1.ICS_SW_INDST_PRMT_ID = ICS_SW_INDST_PRMT.ICS_SW_INDST_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_INDST_PRMT.KEY_HASH
       WHERE ICS_SW_INDST_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SWIndustrialPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWIndustrialPermitSubmission');


-- /ICS_SW_INDST_PRMT/ICS_CONTACT/ICS_TELEPH
INSERT INTO ics_flow_icis.ICS_TELEPH
     SELECT I2.*
              from ICS_SW_INDST_PRMT ICS_SW_INDST_PRMT 
 JOIN ICS_CONTACT I1
 ON I1.ICS_SW_INDST_PRMT_ID = ICS_SW_INDST_PRMT.ICS_SW_INDST_PRMT_ID 
 JOIN ICS_TELEPH I2
 ON I2.ICS_CONTACT_ID = I1.ICS_CONTACT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_INDST_PRMT.KEY_HASH
       WHERE ICS_SW_INDST_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SWIndustrialPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWIndustrialPermitSubmission');


-- /ICS_SW_INDST_PRMT/ICS_PROPOSED_INDST_SW_BM_PS
INSERT INTO ics_flow_icis.ICS_PROPOSED_INDST_SW_BM_PS
     SELECT I3.*
              from ICS_SW_INDST_PRMT ICS_SW_INDST_PRMT 
 JOIN ICS_PROPOSED_INDST_SW_BM_PS I3
 ON I3.ICS_SW_INDST_PRMT_ID = ICS_SW_INDST_PRMT.ICS_SW_INDST_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_INDST_PRMT.KEY_HASH
       WHERE ICS_SW_INDST_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SWIndustrialPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWIndustrialPermitSubmission');


-- /ICS_SW_INDST_PRMT/ICS_GPCF_NO_EXPOSURE
INSERT INTO ics_flow_icis.ICS_GPCF_NO_EXPOSURE
     SELECT I4.*
              from ICS_SW_INDST_PRMT ICS_SW_INDST_PRMT 
 JOIN ICS_GPCF_NO_EXPOSURE I4
 ON I4.ICS_SW_INDST_PRMT_ID = ICS_SW_INDST_PRMT.ICS_SW_INDST_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_INDST_PRMT.KEY_HASH
       WHERE ICS_SW_INDST_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SWIndustrialPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWIndustrialPermitSubmission');


-- /ICS_SW_INDST_PRMT/ICS_GPCF_NOTICE_OF_INTENT
INSERT INTO ics_flow_icis.ICS_GPCF_NOTICE_OF_INTENT
     SELECT I5.*
              from ICS_SW_INDST_PRMT ICS_SW_INDST_PRMT 
 JOIN ICS_GPCF_NOTICE_OF_INTENT I5
 ON I5.ICS_SW_INDST_PRMT_ID = ICS_SW_INDST_PRMT.ICS_SW_INDST_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_INDST_PRMT.KEY_HASH
       WHERE ICS_SW_INDST_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SWIndustrialPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWIndustrialPermitSubmission');


-- /ICS_SW_INDST_PRMT/ICS_GPCF_NOTICE_OF_INTENT/ICS_SUBSECTOR_CODE_PLUS_DESC
INSERT INTO ics_flow_icis.ICS_SUBSECTOR_CODE_PLUS_DESC
     SELECT I6.*
              from ICS_SW_INDST_PRMT ICS_SW_INDST_PRMT 
 JOIN ICS_GPCF_NOTICE_OF_INTENT I5
 ON I5.ICS_SW_INDST_PRMT_ID = ICS_SW_INDST_PRMT.ICS_SW_INDST_PRMT_ID 
 JOIN ICS_SUBSECTOR_CODE_PLUS_DESC I6
 ON I6.ICS_GPCF_NOTICE_OF_INTENT_ID = I5.ICS_GPCF_NOTICE_OF_INTENT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_INDST_PRMT.KEY_HASH
       WHERE ICS_SW_INDST_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SWIndustrialPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWIndustrialPermitSubmission');


-- /ICS_SW_INDST_PRMT/ICS_GPCF_NOTICE_OF_TERM
INSERT INTO ics_flow_icis.ICS_GPCF_NOTICE_OF_TERM
     SELECT I7.*
              from ICS_SW_INDST_PRMT ICS_SW_INDST_PRMT 
 JOIN ICS_GPCF_NOTICE_OF_TERM I7
 ON I7.ICS_SW_INDST_PRMT_ID = ICS_SW_INDST_PRMT.ICS_SW_INDST_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_INDST_PRMT.KEY_HASH
       WHERE ICS_SW_INDST_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SWIndustrialPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWIndustrialPermitSubmission');


-- /ICS_SW_INDST_PRMT/ICS_ADDR
INSERT INTO ics_flow_icis.ICS_ADDR
     SELECT I8.*
              from ICS_SW_INDST_PRMT ICS_SW_INDST_PRMT 
 JOIN ICS_ADDR I8
 ON I8.ICS_SW_INDST_PRMT_ID = ICS_SW_INDST_PRMT.ICS_SW_INDST_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_INDST_PRMT.KEY_HASH
       WHERE ICS_SW_INDST_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SWIndustrialPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWIndustrialPermitSubmission');


-- /ICS_SW_INDST_PRMT/ICS_ADDR/ICS_TELEPH
INSERT INTO ics_flow_icis.ICS_TELEPH
     SELECT I9.*
              from ICS_SW_INDST_PRMT ICS_SW_INDST_PRMT 
 JOIN ICS_ADDR I8
 ON I8.ICS_SW_INDST_PRMT_ID = ICS_SW_INDST_PRMT.ICS_SW_INDST_PRMT_ID 
 JOIN ICS_TELEPH I9
 ON I9.ICS_ADDR_ID = I8.ICS_ADDR_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SW_INDST_PRMT.KEY_HASH
       WHERE ICS_SW_INDST_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SWIndustrialPermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWIndustrialPermitSubmission');
	




-- Remove any old records for ICS_SWMS_4_ANNUL_PROG_REP
				
-- /ICS_SWMS_4_ANNUL_PROG_REP/ICS_MS_4_SWMP_CHANGES
DELETE
  FROM ics_flow_icis.ICS_MS_4_SWMP_CHANGES
 WHERE ICS_MS_4_SWMP_CHANGES.ICS_SWMS_4_ANNUL_PROG_REP_ID IN
          (SELECT I8.ICS_SWMS_4_ANNUL_PROG_REP_ID
              from ics_flow_icis.ICS_SWMS_4_ANNUL_PROG_REP ICS_SWMS_4_ANNUL_PROG_REP 
 JOIN ics_flow_icis.ICS_MS_4_SWMP_CHANGES I8
 ON I8.ICS_SWMS_4_ANNUL_PROG_REP_ID = ICS_SWMS_4_ANNUL_PROG_REP.ICS_SWMS_4_ANNUL_PROG_REP_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_ANNUL_PROG_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4AnnualProgramReportSubmission')
                 
                 
);

				
-- /ICS_SWMS_4_ANNUL_PROG_REP/ICS_MS_4_REGULATED_ENTITY_ENFRC/ICS_MS_4_REGULATED_ENTITY_ENFRC_ACTIONS
DELETE
  FROM ics_flow_icis.ICS_MS_4_REGULATED_ENTITY_ENFRC_ACTIONS
 WHERE ICS_MS_4_REGULATED_ENTITY_ENFRC_ACTIONS.ICS_MS_4_REGULATED_ENTITY_ENFRC_ID IN
          (SELECT I7.ICS_MS_4_REGULATED_ENTITY_ENFRC_ID
              from ics_flow_icis.ICS_SWMS_4_ANNUL_PROG_REP ICS_SWMS_4_ANNUL_PROG_REP 
 JOIN ics_flow_icis.ICS_MS_4_REGULATED_ENTITY_ENFRC I6
 ON I6.ICS_SWMS_4_ANNUL_PROG_REP_ID = ICS_SWMS_4_ANNUL_PROG_REP.ICS_SWMS_4_ANNUL_PROG_REP_ID 
 JOIN ics_flow_icis.ICS_MS_4_REGULATED_ENTITY_ENFRC_ACTIONS I7
 ON I7.ICS_MS_4_REGULATED_ENTITY_ENFRC_ID = I6.ICS_MS_4_REGULATED_ENTITY_ENFRC_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_ANNUL_PROG_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4AnnualProgramReportSubmission')
                 
                 
);

				
-- /ICS_SWMS_4_ANNUL_PROG_REP/ICS_MS_4_REGULATED_ENTITY_ENFRC
DELETE
  FROM ics_flow_icis.ICS_MS_4_REGULATED_ENTITY_ENFRC
 WHERE ICS_MS_4_REGULATED_ENTITY_ENFRC.ICS_SWMS_4_ANNUL_PROG_REP_ID IN
          (SELECT I6.ICS_SWMS_4_ANNUL_PROG_REP_ID
              from ics_flow_icis.ICS_SWMS_4_ANNUL_PROG_REP ICS_SWMS_4_ANNUL_PROG_REP 
 JOIN ics_flow_icis.ICS_MS_4_REGULATED_ENTITY_ENFRC I6
 ON I6.ICS_SWMS_4_ANNUL_PROG_REP_ID = ICS_SWMS_4_ANNUL_PROG_REP.ICS_SWMS_4_ANNUL_PROG_REP_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_ANNUL_PROG_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4AnnualProgramReportSubmission')
                 
                 
);

				
-- /ICS_SWMS_4_ANNUL_PROG_REP/ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY/ICS_MS_4_REGULATED_ENTITY_IDENT
DELETE
  FROM ics_flow_icis.ICS_MS_4_REGULATED_ENTITY_IDENT
 WHERE ICS_MS_4_REGULATED_ENTITY_IDENT.ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY_ID IN
          (SELECT I5.ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY_ID
              from ics_flow_icis.ICS_SWMS_4_ANNUL_PROG_REP ICS_SWMS_4_ANNUL_PROG_REP 
 JOIN ics_flow_icis.ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY I4
 ON I4.ICS_SWMS_4_ANNUL_PROG_REP_ID = ICS_SWMS_4_ANNUL_PROG_REP.ICS_SWMS_4_ANNUL_PROG_REP_ID 
 JOIN ics_flow_icis.ICS_MS_4_REGULATED_ENTITY_IDENT I5
 ON I5.ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY_ID = I4.ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_ANNUL_PROG_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4AnnualProgramReportSubmission')
                 
                 
);

				
-- /ICS_SWMS_4_ANNUL_PROG_REP/ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY
DELETE
  FROM ics_flow_icis.ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY
 WHERE ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY.ICS_SWMS_4_ANNUL_PROG_REP_ID IN
          (SELECT I4.ICS_SWMS_4_ANNUL_PROG_REP_ID
              from ics_flow_icis.ICS_SWMS_4_ANNUL_PROG_REP ICS_SWMS_4_ANNUL_PROG_REP 
 JOIN ics_flow_icis.ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY I4
 ON I4.ICS_SWMS_4_ANNUL_PROG_REP_ID = ICS_SWMS_4_ANNUL_PROG_REP.ICS_SWMS_4_ANNUL_PROG_REP_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_ANNUL_PROG_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4AnnualProgramReportSubmission')
                 
                 
);

				
-- /ICS_SWMS_4_ANNUL_PROG_REP/ICS_MS_4_PROG_REP_ANALYSIS/ICS_MS_4_REGULATED_ENTITY_IDENT
DELETE
  FROM ics_flow_icis.ICS_MS_4_REGULATED_ENTITY_IDENT
 WHERE ICS_MS_4_REGULATED_ENTITY_IDENT.ICS_MS_4_PROG_REP_ANALYSIS_ID IN
          (SELECT I3.ICS_MS_4_PROG_REP_ANALYSIS_ID
              from ics_flow_icis.ICS_SWMS_4_ANNUL_PROG_REP ICS_SWMS_4_ANNUL_PROG_REP 
 JOIN ics_flow_icis.ICS_MS_4_PROG_REP_ANALYSIS I2
 ON I2.ICS_SWMS_4_ANNUL_PROG_REP_ID = ICS_SWMS_4_ANNUL_PROG_REP.ICS_SWMS_4_ANNUL_PROG_REP_ID 
 JOIN ics_flow_icis.ICS_MS_4_REGULATED_ENTITY_IDENT I3
 ON I3.ICS_MS_4_PROG_REP_ANALYSIS_ID = I2.ICS_MS_4_PROG_REP_ANALYSIS_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_ANNUL_PROG_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4AnnualProgramReportSubmission')
                 
                 
);

				
-- /ICS_SWMS_4_ANNUL_PROG_REP/ICS_MS_4_PROG_REP_ANALYSIS
DELETE
  FROM ics_flow_icis.ICS_MS_4_PROG_REP_ANALYSIS
 WHERE ICS_MS_4_PROG_REP_ANALYSIS.ICS_SWMS_4_ANNUL_PROG_REP_ID IN
          (SELECT I2.ICS_SWMS_4_ANNUL_PROG_REP_ID
              from ics_flow_icis.ICS_SWMS_4_ANNUL_PROG_REP ICS_SWMS_4_ANNUL_PROG_REP 
 JOIN ics_flow_icis.ICS_MS_4_PROG_REP_ANALYSIS I2
 ON I2.ICS_SWMS_4_ANNUL_PROG_REP_ID = ICS_SWMS_4_ANNUL_PROG_REP.ICS_SWMS_4_ANNUL_PROG_REP_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_ANNUL_PROG_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4AnnualProgramReportSubmission')
                 
                 
);

				
-- /ICS_SWMS_4_ANNUL_PROG_REP/ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO_PROG_REP
DELETE
  FROM ics_flow_icis.ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO_PROG_REP
 WHERE ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO_PROG_REP.ICS_SWMS_4_ANNUL_PROG_REP_ID IN
          (SELECT I1.ICS_SWMS_4_ANNUL_PROG_REP_ID
              from ics_flow_icis.ICS_SWMS_4_ANNUL_PROG_REP ICS_SWMS_4_ANNUL_PROG_REP 
 JOIN ics_flow_icis.ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO_PROG_REP I1
 ON I1.ICS_SWMS_4_ANNUL_PROG_REP_ID = ICS_SWMS_4_ANNUL_PROG_REP.ICS_SWMS_4_ANNUL_PROG_REP_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_ANNUL_PROG_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4AnnualProgramReportSubmission')
                 
                 
);

				
-- /ICS_SWMS_4_ANNUL_PROG_REP
DELETE
  FROM ics_flow_icis.ICS_SWMS_4_ANNUL_PROG_REP
 WHERE ICS_SWMS_4_ANNUL_PROG_REP.ICS_SWMS_4_ANNUL_PROG_REP_ID IN
          (SELECT ICS_SWMS_4_ANNUL_PROG_REP.ICS_SWMS_4_ANNUL_PROG_REP_ID
              from ics_flow_icis.ICS_SWMS_4_ANNUL_PROG_REP ICS_SWMS_4_ANNUL_PROG_REP 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_ANNUL_PROG_REP.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4AnnualProgramReportSubmission')
                 
                 
);

	
-- Add accepted records for ICS_SWMS_4_ANNUL_PROG_REP


-- /ICS_SWMS_4_ANNUL_PROG_REP
INSERT INTO ics_flow_icis.ICS_SWMS_4_ANNUL_PROG_REP
     SELECT ICS_SWMS_4_ANNUL_PROG_REP.*
              from ICS_SWMS_4_ANNUL_PROG_REP ICS_SWMS_4_ANNUL_PROG_REP 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_ANNUL_PROG_REP.KEY_HASH
       WHERE ICS_SWMS_4_ANNUL_PROG_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SWMS4AnnualProgramReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4AnnualProgramReportSubmission');


-- /ICS_SWMS_4_ANNUL_PROG_REP/ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO_PROG_REP
INSERT INTO ics_flow_icis.ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO_PROG_REP
     SELECT I1.*
              from ICS_SWMS_4_ANNUL_PROG_REP ICS_SWMS_4_ANNUL_PROG_REP 
 JOIN ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO_PROG_REP I1
 ON I1.ICS_SWMS_4_ANNUL_PROG_REP_ID = ICS_SWMS_4_ANNUL_PROG_REP.ICS_SWMS_4_ANNUL_PROG_REP_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_ANNUL_PROG_REP.KEY_HASH
       WHERE ICS_SWMS_4_ANNUL_PROG_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SWMS4AnnualProgramReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4AnnualProgramReportSubmission');


-- /ICS_SWMS_4_ANNUL_PROG_REP/ICS_MS_4_PROG_REP_ANALYSIS
INSERT INTO ics_flow_icis.ICS_MS_4_PROG_REP_ANALYSIS
     SELECT I2.*
              from ICS_SWMS_4_ANNUL_PROG_REP ICS_SWMS_4_ANNUL_PROG_REP 
 JOIN ICS_MS_4_PROG_REP_ANALYSIS I2
 ON I2.ICS_SWMS_4_ANNUL_PROG_REP_ID = ICS_SWMS_4_ANNUL_PROG_REP.ICS_SWMS_4_ANNUL_PROG_REP_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_ANNUL_PROG_REP.KEY_HASH
       WHERE ICS_SWMS_4_ANNUL_PROG_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SWMS4AnnualProgramReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4AnnualProgramReportSubmission');


-- /ICS_SWMS_4_ANNUL_PROG_REP/ICS_MS_4_PROG_REP_ANALYSIS/ICS_MS_4_REGULATED_ENTITY_IDENT
INSERT INTO ics_flow_icis.ICS_MS_4_REGULATED_ENTITY_IDENT
     SELECT I3.*
              from ICS_SWMS_4_ANNUL_PROG_REP ICS_SWMS_4_ANNUL_PROG_REP 
 JOIN ICS_MS_4_PROG_REP_ANALYSIS I2
 ON I2.ICS_SWMS_4_ANNUL_PROG_REP_ID = ICS_SWMS_4_ANNUL_PROG_REP.ICS_SWMS_4_ANNUL_PROG_REP_ID 
 JOIN ICS_MS_4_REGULATED_ENTITY_IDENT I3
 ON I3.ICS_MS_4_PROG_REP_ANALYSIS_ID = I2.ICS_MS_4_PROG_REP_ANALYSIS_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_ANNUL_PROG_REP.KEY_HASH
       WHERE ICS_SWMS_4_ANNUL_PROG_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SWMS4AnnualProgramReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4AnnualProgramReportSubmission');


-- /ICS_SWMS_4_ANNUL_PROG_REP/ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY
INSERT INTO ics_flow_icis.ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY
     SELECT I4.*
              from ICS_SWMS_4_ANNUL_PROG_REP ICS_SWMS_4_ANNUL_PROG_REP 
 JOIN ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY I4
 ON I4.ICS_SWMS_4_ANNUL_PROG_REP_ID = ICS_SWMS_4_ANNUL_PROG_REP.ICS_SWMS_4_ANNUL_PROG_REP_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_ANNUL_PROG_REP.KEY_HASH
       WHERE ICS_SWMS_4_ANNUL_PROG_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SWMS4AnnualProgramReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4AnnualProgramReportSubmission');


-- /ICS_SWMS_4_ANNUL_PROG_REP/ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY/ICS_MS_4_REGULATED_ENTITY_IDENT
INSERT INTO ics_flow_icis.ICS_MS_4_REGULATED_ENTITY_IDENT
     SELECT I5.*
              from ICS_SWMS_4_ANNUL_PROG_REP ICS_SWMS_4_ANNUL_PROG_REP 
 JOIN ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY I4
 ON I4.ICS_SWMS_4_ANNUL_PROG_REP_ID = ICS_SWMS_4_ANNUL_PROG_REP.ICS_SWMS_4_ANNUL_PROG_REP_ID 
 JOIN ICS_MS_4_REGULATED_ENTITY_IDENT I5
 ON I5.ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY_ID = I4.ICS_MS_4_PROG_REP_REQS_REGULATED_ENTITY_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_ANNUL_PROG_REP.KEY_HASH
       WHERE ICS_SWMS_4_ANNUL_PROG_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SWMS4AnnualProgramReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4AnnualProgramReportSubmission');


-- /ICS_SWMS_4_ANNUL_PROG_REP/ICS_MS_4_REGULATED_ENTITY_ENFRC
INSERT INTO ics_flow_icis.ICS_MS_4_REGULATED_ENTITY_ENFRC
     SELECT I6.*
              from ICS_SWMS_4_ANNUL_PROG_REP ICS_SWMS_4_ANNUL_PROG_REP 
 JOIN ICS_MS_4_REGULATED_ENTITY_ENFRC I6
 ON I6.ICS_SWMS_4_ANNUL_PROG_REP_ID = ICS_SWMS_4_ANNUL_PROG_REP.ICS_SWMS_4_ANNUL_PROG_REP_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_ANNUL_PROG_REP.KEY_HASH
       WHERE ICS_SWMS_4_ANNUL_PROG_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SWMS4AnnualProgramReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4AnnualProgramReportSubmission');


-- /ICS_SWMS_4_ANNUL_PROG_REP/ICS_MS_4_REGULATED_ENTITY_ENFRC/ICS_MS_4_REGULATED_ENTITY_ENFRC_ACTIONS
INSERT INTO ics_flow_icis.ICS_MS_4_REGULATED_ENTITY_ENFRC_ACTIONS
     SELECT I7.*
              from ICS_SWMS_4_ANNUL_PROG_REP ICS_SWMS_4_ANNUL_PROG_REP 
 JOIN ICS_MS_4_REGULATED_ENTITY_ENFRC I6
 ON I6.ICS_SWMS_4_ANNUL_PROG_REP_ID = ICS_SWMS_4_ANNUL_PROG_REP.ICS_SWMS_4_ANNUL_PROG_REP_ID 
 JOIN ICS_MS_4_REGULATED_ENTITY_ENFRC_ACTIONS I7
 ON I7.ICS_MS_4_REGULATED_ENTITY_ENFRC_ID = I6.ICS_MS_4_REGULATED_ENTITY_ENFRC_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_ANNUL_PROG_REP.KEY_HASH
       WHERE ICS_SWMS_4_ANNUL_PROG_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SWMS4AnnualProgramReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4AnnualProgramReportSubmission');


-- /ICS_SWMS_4_ANNUL_PROG_REP/ICS_MS_4_SWMP_CHANGES
INSERT INTO ics_flow_icis.ICS_MS_4_SWMP_CHANGES
     SELECT I8.*
              from ICS_SWMS_4_ANNUL_PROG_REP ICS_SWMS_4_ANNUL_PROG_REP 
 JOIN ICS_MS_4_SWMP_CHANGES I8
 ON I8.ICS_SWMS_4_ANNUL_PROG_REP_ID = ICS_SWMS_4_ANNUL_PROG_REP.ICS_SWMS_4_ANNUL_PROG_REP_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_ANNUL_PROG_REP.KEY_HASH
       WHERE ICS_SWMS_4_ANNUL_PROG_REP.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SWMS4AnnualProgramReportSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4AnnualProgramReportSubmission');
	




-- Remove any old records for ICS_SWMS_4_PRMT
				
-- /ICS_SWMS_4_PRMT/ICS_MS_4_REGULATED_ENTITY_AREA/ICS_MS_4_REGULATED_ENTITY_AREA_COORD
DELETE
  FROM ics_flow_icis.ICS_MS_4_REGULATED_ENTITY_AREA_COORD
 WHERE ICS_MS_4_REGULATED_ENTITY_AREA_COORD.ICS_MS_4_REGULATED_ENTITY_AREA_ID IN
          (SELECT I27.ICS_MS_4_REGULATED_ENTITY_AREA_ID
              from ics_flow_icis.ICS_SWMS_4_PRMT ICS_SWMS_4_PRMT 
 JOIN ics_flow_icis.ICS_MS_4_REGULATED_ENTITY_AREA I26
 ON I26.ICS_SWMS_4_PRMT_ID = ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_ID 
 JOIN ics_flow_icis.ICS_MS_4_REGULATED_ENTITY_AREA_COORD I27
 ON I27.ICS_MS_4_REGULATED_ENTITY_AREA_ID = I26.ICS_MS_4_REGULATED_ENTITY_AREA_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4PermitSubmission')
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_SWMS_4_PRMT/ICS_MS_4_REGULATED_ENTITY_AREA
DELETE
  FROM ics_flow_icis.ICS_MS_4_REGULATED_ENTITY_AREA
 WHERE ICS_MS_4_REGULATED_ENTITY_AREA.ICS_SWMS_4_PRMT_ID IN
          (SELECT I26.ICS_SWMS_4_PRMT_ID
              from ics_flow_icis.ICS_SWMS_4_PRMT ICS_SWMS_4_PRMT 
 JOIN ics_flow_icis.ICS_MS_4_REGULATED_ENTITY_AREA I26
 ON I26.ICS_SWMS_4_PRMT_ID = ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4PermitSubmission')
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_SWMS_4_PRMT/ICS_MS_4_REGULATED_ENTITY
DELETE
  FROM ics_flow_icis.ICS_MS_4_REGULATED_ENTITY
 WHERE ICS_MS_4_REGULATED_ENTITY.ICS_SWMS_4_PRMT_ID IN
          (SELECT I25.ICS_SWMS_4_PRMT_ID
              from ics_flow_icis.ICS_SWMS_4_PRMT ICS_SWMS_4_PRMT 
 JOIN ics_flow_icis.ICS_MS_4_REGULATED_ENTITY I25
 ON I25.ICS_SWMS_4_PRMT_ID = ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4PermitSubmission')
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_SWMS_4_PRMT/ICS_MS_4_POST_CNST_SW_REQS/ICS_MS_4_POST_CNST_SW_REGULATED_ENTITY_INFO
DELETE
  FROM ics_flow_icis.ICS_MS_4_POST_CNST_SW_REGULATED_ENTITY_INFO
 WHERE ICS_MS_4_POST_CNST_SW_REGULATED_ENTITY_INFO.ICS_MS_4_POST_CNST_SW_REQS_ID IN
          (SELECT I24.ICS_MS_4_POST_CNST_SW_REQS_ID
              from ics_flow_icis.ICS_SWMS_4_PRMT ICS_SWMS_4_PRMT 
 JOIN ics_flow_icis.ICS_MS_4_POST_CNST_SW_REQS I21
 ON I21.ICS_SWMS_4_PRMT_ID = ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_ID 
 JOIN ics_flow_icis.ICS_MS_4_POST_CNST_SW_REGULATED_ENTITY_INFO I24
 ON I24.ICS_MS_4_POST_CNST_SW_REQS_ID = I21.ICS_MS_4_POST_CNST_SW_REQS_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4PermitSubmission')
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_SWMS_4_PRMT/ICS_MS_4_POST_CNST_SW_REQS/ICS_MS_4_POST_CNST_SW_PROCEDURES/ICS_MS_4_REGULATED_ENTITY_IDENT
DELETE
  FROM ics_flow_icis.ICS_MS_4_REGULATED_ENTITY_IDENT
 WHERE ICS_MS_4_REGULATED_ENTITY_IDENT.ICS_MS_4_POST_CNST_SW_PROCEDURES_ID IN
          (SELECT I23.ICS_MS_4_POST_CNST_SW_PROCEDURES_ID
              from ics_flow_icis.ICS_SWMS_4_PRMT ICS_SWMS_4_PRMT 
 JOIN ics_flow_icis.ICS_MS_4_POST_CNST_SW_REQS I21
 ON I21.ICS_SWMS_4_PRMT_ID = ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_ID 
 JOIN ics_flow_icis.ICS_MS_4_POST_CNST_SW_PROCEDURES I22
 ON I22.ICS_MS_4_POST_CNST_SW_REQS_ID = I21.ICS_MS_4_POST_CNST_SW_REQS_ID 
 JOIN ics_flow_icis.ICS_MS_4_REGULATED_ENTITY_IDENT I23
 ON I23.ICS_MS_4_POST_CNST_SW_PROCEDURES_ID = I22.ICS_MS_4_POST_CNST_SW_PROCEDURES_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4PermitSubmission')
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_SWMS_4_PRMT/ICS_MS_4_POST_CNST_SW_REQS/ICS_MS_4_POST_CNST_SW_PROCEDURES
DELETE
  FROM ics_flow_icis.ICS_MS_4_POST_CNST_SW_PROCEDURES
 WHERE ICS_MS_4_POST_CNST_SW_PROCEDURES.ICS_MS_4_POST_CNST_SW_REQS_ID IN
          (SELECT I22.ICS_MS_4_POST_CNST_SW_REQS_ID
              from ics_flow_icis.ICS_SWMS_4_PRMT ICS_SWMS_4_PRMT 
 JOIN ics_flow_icis.ICS_MS_4_POST_CNST_SW_REQS I21
 ON I21.ICS_SWMS_4_PRMT_ID = ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_ID 
 JOIN ics_flow_icis.ICS_MS_4_POST_CNST_SW_PROCEDURES I22
 ON I22.ICS_MS_4_POST_CNST_SW_REQS_ID = I21.ICS_MS_4_POST_CNST_SW_REQS_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4PermitSubmission')
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_SWMS_4_PRMT/ICS_MS_4_POST_CNST_SW_REQS
DELETE
  FROM ics_flow_icis.ICS_MS_4_POST_CNST_SW_REQS
 WHERE ICS_MS_4_POST_CNST_SW_REQS.ICS_SWMS_4_PRMT_ID IN
          (SELECT I21.ICS_SWMS_4_PRMT_ID
              from ics_flow_icis.ICS_SWMS_4_PRMT ICS_SWMS_4_PRMT 
 JOIN ics_flow_icis.ICS_MS_4_POST_CNST_SW_REQS I21
 ON I21.ICS_SWMS_4_PRMT_ID = ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4PermitSubmission')
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_SWMS_4_PRMT/ICS_MS_4_POLLUTION_PREVENTION_REQS/ICS_MS_4_REGULATED_ENTITY_IDENT
DELETE
  FROM ics_flow_icis.ICS_MS_4_REGULATED_ENTITY_IDENT
 WHERE ICS_MS_4_REGULATED_ENTITY_IDENT.ICS_MS_4_POLLUTION_PREVENTION_REQS_ID IN
          (SELECT I20.ICS_MS_4_POLLUTION_PREVENTION_REQS_ID
              from ics_flow_icis.ICS_SWMS_4_PRMT ICS_SWMS_4_PRMT 
 JOIN ics_flow_icis.ICS_MS_4_POLLUTION_PREVENTION_REQS I19
 ON I19.ICS_SWMS_4_PRMT_ID = ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_ID 
 JOIN ics_flow_icis.ICS_MS_4_REGULATED_ENTITY_IDENT I20
 ON I20.ICS_MS_4_POLLUTION_PREVENTION_REQS_ID = I19.ICS_MS_4_POLLUTION_PREVENTION_REQS_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4PermitSubmission')
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_SWMS_4_PRMT/ICS_MS_4_POLLUTION_PREVENTION_REQS
DELETE
  FROM ics_flow_icis.ICS_MS_4_POLLUTION_PREVENTION_REQS
 WHERE ICS_MS_4_POLLUTION_PREVENTION_REQS.ICS_SWMS_4_PRMT_ID IN
          (SELECT I19.ICS_SWMS_4_PRMT_ID
              from ics_flow_icis.ICS_SWMS_4_PRMT ICS_SWMS_4_PRMT 
 JOIN ics_flow_icis.ICS_MS_4_POLLUTION_PREVENTION_REQS I19
 ON I19.ICS_SWMS_4_PRMT_ID = ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4PermitSubmission')
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_SWMS_4_PRMT/ICS_MS_4_PBLC_INVOLVEMENT_REQS/ICS_MS_4_REGULATED_ENTITY_IDENT
DELETE
  FROM ics_flow_icis.ICS_MS_4_REGULATED_ENTITY_IDENT
 WHERE ICS_MS_4_REGULATED_ENTITY_IDENT.ICS_MS_4_PBLC_INVOLVEMENT_REQS_ID IN
          (SELECT I18.ICS_MS_4_PBLC_INVOLVEMENT_REQS_ID
              from ics_flow_icis.ICS_SWMS_4_PRMT ICS_SWMS_4_PRMT 
 JOIN ics_flow_icis.ICS_MS_4_PBLC_INVOLVEMENT_REQS I17
 ON I17.ICS_SWMS_4_PRMT_ID = ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_ID 
 JOIN ics_flow_icis.ICS_MS_4_REGULATED_ENTITY_IDENT I18
 ON I18.ICS_MS_4_PBLC_INVOLVEMENT_REQS_ID = I17.ICS_MS_4_PBLC_INVOLVEMENT_REQS_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4PermitSubmission')
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_SWMS_4_PRMT/ICS_MS_4_PBLC_INVOLVEMENT_REQS
DELETE
  FROM ics_flow_icis.ICS_MS_4_PBLC_INVOLVEMENT_REQS
 WHERE ICS_MS_4_PBLC_INVOLVEMENT_REQS.ICS_SWMS_4_PRMT_ID IN
          (SELECT I17.ICS_SWMS_4_PRMT_ID
              from ics_flow_icis.ICS_SWMS_4_PRMT ICS_SWMS_4_PRMT 
 JOIN ics_flow_icis.ICS_MS_4_PBLC_INVOLVEMENT_REQS I17
 ON I17.ICS_SWMS_4_PRMT_ID = ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4PermitSubmission')
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_SWMS_4_PRMT/ICS_MS_4_PBLC_EDUCATION_REQS/ICS_MS_4_REGULATED_ENTITY_IDENT
DELETE
  FROM ics_flow_icis.ICS_MS_4_REGULATED_ENTITY_IDENT
 WHERE ICS_MS_4_REGULATED_ENTITY_IDENT.ICS_MS_4_PBLC_EDUCATION_REQS_ID IN
          (SELECT I16.ICS_MS_4_PBLC_EDUCATION_REQS_ID
              from ics_flow_icis.ICS_SWMS_4_PRMT ICS_SWMS_4_PRMT 
 JOIN ics_flow_icis.ICS_MS_4_PBLC_EDUCATION_REQS I15
 ON I15.ICS_SWMS_4_PRMT_ID = ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_ID 
 JOIN ics_flow_icis.ICS_MS_4_REGULATED_ENTITY_IDENT I16
 ON I16.ICS_MS_4_PBLC_EDUCATION_REQS_ID = I15.ICS_MS_4_PBLC_EDUCATION_REQS_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4PermitSubmission')
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);
			
-- /ICS_SWMS_4_PRMT/ICS_MS_4_INDST_SW_REQS/ICS_MS_4_INDST_SW_PROCEDURES/ICS_MS_4_REGULATED_ENTITY_IDENT
DELETE
  FROM ics_flow_icis.ICS_MS_4_REGULATED_ENTITY_IDENT
 WHERE ICS_MS_4_REGULATED_ENTITY_IDENT.ICS_MS_4_INDST_SW_PROCEDURES_ID IN
          (SELECT I11.ICS_MS_4_INDST_SW_PROCEDURES_ID
              from ics_flow_icis.ICS_SWMS_4_PRMT ICS_SWMS_4_PRMT 
 JOIN ics_flow_icis.ICS_MS_4_INDST_SW_REQS I9
 ON I9.ICS_SWMS_4_PRMT_ID = ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_ID 
 JOIN ics_flow_icis.ICS_MS_4_INDST_SW_PROCEDURES I10
 ON I10.ICS_MS_4_INDST_SW_REQS_ID = I9.ICS_MS_4_INDST_SW_REQS_ID 
 JOIN ics_flow_icis.ICS_MS_4_REGULATED_ENTITY_IDENT I11
 ON I11.ICS_MS_4_INDST_SW_PROCEDURES_ID = I10.ICS_MS_4_INDST_SW_PROCEDURES_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4PermitSubmission')
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);
        
        		
-- /ICS_SWMS_4_PRMT/ICS_MS_4_INDST_SW_REQS/ICS_MS_4_INDST_SW_PROCEDURES
DELETE
  FROM ics_flow_icis.ICS_MS_4_INDST_SW_PROCEDURES
 WHERE ICS_MS_4_INDST_SW_PROCEDURES.ICS_MS_4_INDST_SW_REQS_ID IN
          (SELECT I10.ICS_MS_4_INDST_SW_REQS_ID
              from ics_flow_icis.ICS_SWMS_4_PRMT ICS_SWMS_4_PRMT 
 JOIN ics_flow_icis.ICS_MS_4_INDST_SW_REQS I9
 ON I9.ICS_SWMS_4_PRMT_ID = ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_ID 
 JOIN ics_flow_icis.ICS_MS_4_INDST_SW_PROCEDURES I10
 ON I10.ICS_MS_4_INDST_SW_REQS_ID = I9.ICS_MS_4_INDST_SW_REQS_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4PermitSubmission')
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_SWMS_4_PRMT/ICS_MS_4_PBLC_EDUCATION_REQS
DELETE
  FROM ics_flow_icis.ICS_MS_4_PBLC_EDUCATION_REQS
 WHERE ICS_MS_4_PBLC_EDUCATION_REQS.ICS_SWMS_4_PRMT_ID IN
          (SELECT I15.ICS_SWMS_4_PRMT_ID
              from ics_flow_icis.ICS_SWMS_4_PRMT ICS_SWMS_4_PRMT 
 JOIN ics_flow_icis.ICS_MS_4_PBLC_EDUCATION_REQS I15
 ON I15.ICS_SWMS_4_PRMT_ID = ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4PermitSubmission')
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_SWMS_4_PRMT/ICS_MS_4_OTHR_APPL_REQS/ICS_MS_4_REGULATED_ENTITY_IDENT
DELETE
  FROM ics_flow_icis.ICS_MS_4_REGULATED_ENTITY_IDENT
 WHERE ICS_MS_4_REGULATED_ENTITY_IDENT.ICS_MS_4_OTHR_APPL_REQS_ID IN
          (SELECT I14.ICS_MS_4_OTHR_APPL_REQS_ID
              from ics_flow_icis.ICS_SWMS_4_PRMT ICS_SWMS_4_PRMT 
 JOIN ics_flow_icis.ICS_MS_4_OTHR_APPL_REQS I13
 ON I13.ICS_SWMS_4_PRMT_ID = ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_ID 
 JOIN ics_flow_icis.ICS_MS_4_REGULATED_ENTITY_IDENT I14
 ON I14.ICS_MS_4_OTHR_APPL_REQS_ID = I13.ICS_MS_4_OTHR_APPL_REQS_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4PermitSubmission')
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_SWMS_4_PRMT/ICS_MS_4_OTHR_APPL_REQS
DELETE
  FROM ics_flow_icis.ICS_MS_4_OTHR_APPL_REQS
 WHERE ICS_MS_4_OTHR_APPL_REQS.ICS_SWMS_4_PRMT_ID IN
          (SELECT I13.ICS_SWMS_4_PRMT_ID
              from ics_flow_icis.ICS_SWMS_4_PRMT ICS_SWMS_4_PRMT 
 JOIN ics_flow_icis.ICS_MS_4_OTHR_APPL_REQS I13
 ON I13.ICS_SWMS_4_PRMT_ID = ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4PermitSubmission')
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_SWMS_4_PRMT/ICS_MS_4_INDST_SW_REQS/ICS_MS_4_INDST_SW_REGULATED_ENTITY_INFO
DELETE
  FROM ics_flow_icis.ICS_MS_4_INDST_SW_REGULATED_ENTITY_INFO
 WHERE ICS_MS_4_INDST_SW_REGULATED_ENTITY_INFO.ICS_MS_4_INDST_SW_REQS_ID IN
          (SELECT I12.ICS_MS_4_INDST_SW_REQS_ID
              from ics_flow_icis.ICS_SWMS_4_PRMT ICS_SWMS_4_PRMT 
 JOIN ics_flow_icis.ICS_MS_4_INDST_SW_REQS I9
 ON I9.ICS_SWMS_4_PRMT_ID = ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_ID 
 JOIN ics_flow_icis.ICS_MS_4_INDST_SW_REGULATED_ENTITY_INFO I12
 ON I12.ICS_MS_4_INDST_SW_REQS_ID = I9.ICS_MS_4_INDST_SW_REQS_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4PermitSubmission')
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);


				
-- /ICS_SWMS_4_PRMT/ICS_MS_4_INDST_SW_REQS
DELETE
  FROM ics_flow_icis.ICS_MS_4_INDST_SW_REQS
 WHERE ICS_MS_4_INDST_SW_REQS.ICS_SWMS_4_PRMT_ID IN
          (SELECT I9.ICS_SWMS_4_PRMT_ID
              from ics_flow_icis.ICS_SWMS_4_PRMT ICS_SWMS_4_PRMT 
 JOIN ics_flow_icis.ICS_MS_4_INDST_SW_REQS I9
 ON I9.ICS_SWMS_4_PRMT_ID = ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4PermitSubmission')
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_SWMS_4_PRMT/ICS_MS_4_ILLICIT_DETECT_REQS/ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO
DELETE
  FROM ics_flow_icis.ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO
 WHERE ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO.ICS_MS_4_ILLICIT_DETECT_REQS_ID IN
          (SELECT I8.ICS_MS_4_ILLICIT_DETECT_REQS_ID
              from ics_flow_icis.ICS_SWMS_4_PRMT ICS_SWMS_4_PRMT 
 JOIN ics_flow_icis.ICS_MS_4_ILLICIT_DETECT_REQS I5
 ON I5.ICS_SWMS_4_PRMT_ID = ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_ID 
 JOIN ics_flow_icis.ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO I8
 ON I8.ICS_MS_4_ILLICIT_DETECT_REQS_ID = I5.ICS_MS_4_ILLICIT_DETECT_REQS_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4PermitSubmission')
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_SWMS_4_PRMT/ICS_MS_4_ILLICIT_DETECT_REQS/ICS_MS_4_ILLICIT_DETECT_PROCEDURES/ICS_MS_4_REGULATED_ENTITY_IDENT
DELETE
  FROM ics_flow_icis.ICS_MS_4_REGULATED_ENTITY_IDENT
 WHERE ICS_MS_4_REGULATED_ENTITY_IDENT.ICS_MS_4_ILLICIT_DETECT_PROCEDURES_ID IN
          (SELECT I7.ICS_MS_4_ILLICIT_DETECT_PROCEDURES_ID
              from ics_flow_icis.ICS_SWMS_4_PRMT ICS_SWMS_4_PRMT 
 JOIN ics_flow_icis.ICS_MS_4_ILLICIT_DETECT_REQS I5
 ON I5.ICS_SWMS_4_PRMT_ID = ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_ID 
 JOIN ics_flow_icis.ICS_MS_4_ILLICIT_DETECT_PROCEDURES I6
 ON I6.ICS_MS_4_ILLICIT_DETECT_REQS_ID = I5.ICS_MS_4_ILLICIT_DETECT_REQS_ID 
 JOIN ics_flow_icis.ICS_MS_4_REGULATED_ENTITY_IDENT I7
 ON I7.ICS_MS_4_ILLICIT_DETECT_PROCEDURES_ID = I6.ICS_MS_4_ILLICIT_DETECT_PROCEDURES_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4PermitSubmission')
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_SWMS_4_PRMT/ICS_MS_4_ILLICIT_DETECT_REQS/ICS_MS_4_ILLICIT_DETECT_PROCEDURES
DELETE
  FROM ics_flow_icis.ICS_MS_4_ILLICIT_DETECT_PROCEDURES
 WHERE ICS_MS_4_ILLICIT_DETECT_PROCEDURES.ICS_MS_4_ILLICIT_DETECT_REQS_ID IN
          (SELECT I6.ICS_MS_4_ILLICIT_DETECT_REQS_ID
              from ics_flow_icis.ICS_SWMS_4_PRMT ICS_SWMS_4_PRMT 
 JOIN ics_flow_icis.ICS_MS_4_ILLICIT_DETECT_REQS I5
 ON I5.ICS_SWMS_4_PRMT_ID = ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_ID 
 JOIN ics_flow_icis.ICS_MS_4_ILLICIT_DETECT_PROCEDURES I6
 ON I6.ICS_MS_4_ILLICIT_DETECT_REQS_ID = I5.ICS_MS_4_ILLICIT_DETECT_REQS_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4PermitSubmission')
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_SWMS_4_PRMT/ICS_MS_4_ILLICIT_DETECT_REQS
DELETE
  FROM ics_flow_icis.ICS_MS_4_ILLICIT_DETECT_REQS
 WHERE ICS_MS_4_ILLICIT_DETECT_REQS.ICS_SWMS_4_PRMT_ID IN
          (SELECT I5.ICS_SWMS_4_PRMT_ID
              from ics_flow_icis.ICS_SWMS_4_PRMT ICS_SWMS_4_PRMT 
 JOIN ics_flow_icis.ICS_MS_4_ILLICIT_DETECT_REQS I5
 ON I5.ICS_SWMS_4_PRMT_ID = ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4PermitSubmission')
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_SWMS_4_PRMT/ICS_MS_4_CNST_SW_REQS/ICS_MS_4_CNST_SW_REGULATED_ENTITY_INFO
DELETE
  FROM ics_flow_icis.ICS_MS_4_CNST_SW_REGULATED_ENTITY_INFO
 WHERE ICS_MS_4_CNST_SW_REGULATED_ENTITY_INFO.ICS_MS_4_CNST_SW_REQS_ID IN
          (SELECT I4.ICS_MS_4_CNST_SW_REQS_ID
              from ics_flow_icis.ICS_SWMS_4_PRMT ICS_SWMS_4_PRMT 
 JOIN ics_flow_icis.ICS_MS_4_CNST_SW_REQS I1
 ON I1.ICS_SWMS_4_PRMT_ID = ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_ID 
 JOIN ics_flow_icis.ICS_MS_4_CNST_SW_REGULATED_ENTITY_INFO I4
 ON I4.ICS_MS_4_CNST_SW_REQS_ID = I1.ICS_MS_4_CNST_SW_REQS_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4PermitSubmission')
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_SWMS_4_PRMT/ICS_MS_4_CNST_SW_REQS/ICS_MS_4_CNST_SW_PROCEDURES/ICS_MS_4_REGULATED_ENTITY_IDENT
DELETE
  FROM ics_flow_icis.ICS_MS_4_REGULATED_ENTITY_IDENT
 WHERE ICS_MS_4_REGULATED_ENTITY_IDENT.ICS_MS_4_CNST_SW_PROCEDURES_ID IN
          (SELECT I3.ICS_MS_4_CNST_SW_PROCEDURES_ID
              from ics_flow_icis.ICS_SWMS_4_PRMT ICS_SWMS_4_PRMT 
 JOIN ics_flow_icis.ICS_MS_4_CNST_SW_REQS I1
 ON I1.ICS_SWMS_4_PRMT_ID = ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_ID 
 JOIN ics_flow_icis.ICS_MS_4_CNST_SW_PROCEDURES I2
 ON I2.ICS_MS_4_CNST_SW_REQS_ID = I1.ICS_MS_4_CNST_SW_REQS_ID 
 JOIN ics_flow_icis.ICS_MS_4_REGULATED_ENTITY_IDENT I3
 ON I3.ICS_MS_4_CNST_SW_PROCEDURES_ID = I2.ICS_MS_4_CNST_SW_PROCEDURES_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4PermitSubmission')
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_SWMS_4_PRMT/ICS_MS_4_CNST_SW_REQS/ICS_MS_4_CNST_SW_PROCEDURES
DELETE
  FROM ics_flow_icis.ICS_MS_4_CNST_SW_PROCEDURES
 WHERE ICS_MS_4_CNST_SW_PROCEDURES.ICS_MS_4_CNST_SW_REQS_ID IN
          (SELECT I2.ICS_MS_4_CNST_SW_REQS_ID
              from ics_flow_icis.ICS_SWMS_4_PRMT ICS_SWMS_4_PRMT 
 JOIN ics_flow_icis.ICS_MS_4_CNST_SW_REQS I1
 ON I1.ICS_SWMS_4_PRMT_ID = ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_ID 
 JOIN ics_flow_icis.ICS_MS_4_CNST_SW_PROCEDURES I2
 ON I2.ICS_MS_4_CNST_SW_REQS_ID = I1.ICS_MS_4_CNST_SW_REQS_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4PermitSubmission')
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_SWMS_4_PRMT/ICS_MS_4_CNST_SW_REQS
DELETE
  FROM ics_flow_icis.ICS_MS_4_CNST_SW_REQS
 WHERE ICS_MS_4_CNST_SW_REQS.ICS_SWMS_4_PRMT_ID IN
          (SELECT I1.ICS_SWMS_4_PRMT_ID
              from ics_flow_icis.ICS_SWMS_4_PRMT ICS_SWMS_4_PRMT 
 JOIN ics_flow_icis.ICS_MS_4_CNST_SW_REQS I1
 ON I1.ICS_SWMS_4_PRMT_ID = ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4PermitSubmission')
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_SWMS_4_PRMT
DELETE
  FROM ics_flow_icis.ICS_SWMS_4_PRMT
 WHERE ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_ID IN
          (SELECT ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_ID
              from ics_flow_icis.ICS_SWMS_4_PRMT ICS_SWMS_4_PRMT 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'SWMS4PermitSubmission')
                  OR ICS_SWMS_4_PRMT.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

	
-- Add accepted records for ICS_SWMS_4_PRMT


-- /ICS_SWMS_4_PRMT
INSERT INTO ics_flow_icis.ICS_SWMS_4_PRMT
     SELECT ICS_SWMS_4_PRMT.*
              from ICS_SWMS_4_PRMT ICS_SWMS_4_PRMT 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
       WHERE ICS_SWMS_4_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SWMS4PermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4PermitSubmission');


-- /ICS_SWMS_4_PRMT/ICS_MS_4_CNST_SW_REQS
INSERT INTO ics_flow_icis.ICS_MS_4_CNST_SW_REQS
     SELECT I1.*
              from ICS_SWMS_4_PRMT ICS_SWMS_4_PRMT 
 JOIN ICS_MS_4_CNST_SW_REQS I1
 ON I1.ICS_SWMS_4_PRMT_ID = ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
       WHERE ICS_SWMS_4_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SWMS4PermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4PermitSubmission');


-- /ICS_SWMS_4_PRMT/ICS_MS_4_CNST_SW_REQS/ICS_MS_4_CNST_SW_PROCEDURES
INSERT INTO ics_flow_icis.ICS_MS_4_CNST_SW_PROCEDURES
     SELECT I2.*
              from ICS_SWMS_4_PRMT ICS_SWMS_4_PRMT 
 JOIN ICS_MS_4_CNST_SW_REQS I1
 ON I1.ICS_SWMS_4_PRMT_ID = ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_ID 
 JOIN ICS_MS_4_CNST_SW_PROCEDURES I2
 ON I2.ICS_MS_4_CNST_SW_REQS_ID = I1.ICS_MS_4_CNST_SW_REQS_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
       WHERE ICS_SWMS_4_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SWMS4PermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4PermitSubmission');


-- /ICS_SWMS_4_PRMT/ICS_MS_4_CNST_SW_REQS/ICS_MS_4_CNST_SW_PROCEDURES/ICS_MS_4_REGULATED_ENTITY_IDENT
INSERT INTO ics_flow_icis.ICS_MS_4_REGULATED_ENTITY_IDENT
     SELECT I3.*
              from ICS_SWMS_4_PRMT ICS_SWMS_4_PRMT 
 JOIN ICS_MS_4_CNST_SW_REQS I1
 ON I1.ICS_SWMS_4_PRMT_ID = ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_ID 
 JOIN ICS_MS_4_CNST_SW_PROCEDURES I2
 ON I2.ICS_MS_4_CNST_SW_REQS_ID = I1.ICS_MS_4_CNST_SW_REQS_ID 
 JOIN ICS_MS_4_REGULATED_ENTITY_IDENT I3
 ON I3.ICS_MS_4_CNST_SW_PROCEDURES_ID = I2.ICS_MS_4_CNST_SW_PROCEDURES_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
       WHERE ICS_SWMS_4_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SWMS4PermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4PermitSubmission');


-- /ICS_SWMS_4_PRMT/ICS_MS_4_CNST_SW_REQS/ICS_MS_4_CNST_SW_REGULATED_ENTITY_INFO
INSERT INTO ics_flow_icis.ICS_MS_4_CNST_SW_REGULATED_ENTITY_INFO
     SELECT I4.*
              from ICS_SWMS_4_PRMT ICS_SWMS_4_PRMT 
 JOIN ICS_MS_4_CNST_SW_REQS I1
 ON I1.ICS_SWMS_4_PRMT_ID = ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_ID 
 JOIN ICS_MS_4_CNST_SW_REGULATED_ENTITY_INFO I4
 ON I4.ICS_MS_4_CNST_SW_REQS_ID = I1.ICS_MS_4_CNST_SW_REQS_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
       WHERE ICS_SWMS_4_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SWMS4PermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4PermitSubmission');


-- /ICS_SWMS_4_PRMT/ICS_MS_4_ILLICIT_DETECT_REQS
INSERT INTO ics_flow_icis.ICS_MS_4_ILLICIT_DETECT_REQS
     SELECT I5.*
              from ICS_SWMS_4_PRMT ICS_SWMS_4_PRMT 
 JOIN ICS_MS_4_ILLICIT_DETECT_REQS I5
 ON I5.ICS_SWMS_4_PRMT_ID = ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
       WHERE ICS_SWMS_4_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SWMS4PermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4PermitSubmission');


-- /ICS_SWMS_4_PRMT/ICS_MS_4_ILLICIT_DETECT_REQS/ICS_MS_4_ILLICIT_DETECT_PROCEDURES
INSERT INTO ics_flow_icis.ICS_MS_4_ILLICIT_DETECT_PROCEDURES
     SELECT I6.*
              from ICS_SWMS_4_PRMT ICS_SWMS_4_PRMT 
 JOIN ICS_MS_4_ILLICIT_DETECT_REQS I5
 ON I5.ICS_SWMS_4_PRMT_ID = ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_ID 
 JOIN ICS_MS_4_ILLICIT_DETECT_PROCEDURES I6
 ON I6.ICS_MS_4_ILLICIT_DETECT_REQS_ID = I5.ICS_MS_4_ILLICIT_DETECT_REQS_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
       WHERE ICS_SWMS_4_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SWMS4PermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4PermitSubmission');


-- /ICS_SWMS_4_PRMT/ICS_MS_4_ILLICIT_DETECT_REQS/ICS_MS_4_ILLICIT_DETECT_PROCEDURES/ICS_MS_4_REGULATED_ENTITY_IDENT
INSERT INTO ics_flow_icis.ICS_MS_4_REGULATED_ENTITY_IDENT
     SELECT I7.*
              from ICS_SWMS_4_PRMT ICS_SWMS_4_PRMT 
 JOIN ICS_MS_4_ILLICIT_DETECT_REQS I5
 ON I5.ICS_SWMS_4_PRMT_ID = ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_ID 
 JOIN ICS_MS_4_ILLICIT_DETECT_PROCEDURES I6
 ON I6.ICS_MS_4_ILLICIT_DETECT_REQS_ID = I5.ICS_MS_4_ILLICIT_DETECT_REQS_ID 
 JOIN ICS_MS_4_REGULATED_ENTITY_IDENT I7
 ON I7.ICS_MS_4_ILLICIT_DETECT_PROCEDURES_ID = I6.ICS_MS_4_ILLICIT_DETECT_PROCEDURES_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
       WHERE ICS_SWMS_4_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SWMS4PermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4PermitSubmission');


-- /ICS_SWMS_4_PRMT/ICS_MS_4_ILLICIT_DETECT_REQS/ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO
INSERT INTO ics_flow_icis.ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO
     SELECT I8.*
              from ICS_SWMS_4_PRMT ICS_SWMS_4_PRMT 
 JOIN ICS_MS_4_ILLICIT_DETECT_REQS I5
 ON I5.ICS_SWMS_4_PRMT_ID = ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_ID 
 JOIN ICS_MS_4_ILLICIT_DETECT_REGULATED_ENTITY_INFO I8
 ON I8.ICS_MS_4_ILLICIT_DETECT_REQS_ID = I5.ICS_MS_4_ILLICIT_DETECT_REQS_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
       WHERE ICS_SWMS_4_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SWMS4PermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4PermitSubmission');


-- /ICS_SWMS_4_PRMT/ICS_MS_4_INDST_SW_REQS
INSERT INTO ics_flow_icis.ICS_MS_4_INDST_SW_REQS
     SELECT I9.*
              from ICS_SWMS_4_PRMT ICS_SWMS_4_PRMT 
 JOIN ICS_MS_4_INDST_SW_REQS I9
 ON I9.ICS_SWMS_4_PRMT_ID = ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
       WHERE ICS_SWMS_4_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SWMS4PermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4PermitSubmission');



-- /ICS_SWMS_4_PRMT/ICS_MS_4_INDST_SW_REQS/ICS_MS_4_INDST_SW_PROCEDURES
INSERT INTO ics_flow_icis.ICS_MS_4_INDST_SW_PROCEDURES
     SELECT I10.*
              from ICS_SWMS_4_PRMT ICS_SWMS_4_PRMT 
 JOIN ICS_MS_4_INDST_SW_REQS I9
 ON I9.ICS_SWMS_4_PRMT_ID = ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_ID 
 JOIN ICS_MS_4_INDST_SW_PROCEDURES I10
 ON I10.ICS_MS_4_INDST_SW_REQS_ID = I9.ICS_MS_4_INDST_SW_REQS_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
       WHERE ICS_SWMS_4_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SWMS4PermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4PermitSubmission');
                  

-- /ICS_SWMS_4_PRMT/ICS_MS_4_INDST_SW_REQS/ICS_MS_4_INDST_SW_PROCEDURES/ICS_MS_4_REGULATED_ENTITY_IDENT
INSERT INTO ics_flow_icis.ICS_MS_4_REGULATED_ENTITY_IDENT
     SELECT I11.*
              from ICS_SWMS_4_PRMT ICS_SWMS_4_PRMT 
 JOIN ICS_MS_4_INDST_SW_REQS I9
 ON I9.ICS_SWMS_4_PRMT_ID = ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_ID 
 JOIN ICS_MS_4_INDST_SW_PROCEDURES I10
 ON I10.ICS_MS_4_INDST_SW_REQS_ID = I9.ICS_MS_4_INDST_SW_REQS_ID 
 JOIN ICS_MS_4_REGULATED_ENTITY_IDENT I11
 ON I11.ICS_MS_4_INDST_SW_PROCEDURES_ID = I10.ICS_MS_4_INDST_SW_PROCEDURES_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
       WHERE ICS_SWMS_4_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SWMS4PermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4PermitSubmission');


-- /ICS_SWMS_4_PRMT/ICS_MS_4_INDST_SW_REQS/ICS_MS_4_INDST_SW_REGULATED_ENTITY_INFO
INSERT INTO ics_flow_icis.ICS_MS_4_INDST_SW_REGULATED_ENTITY_INFO
     SELECT I12.*
              from ICS_SWMS_4_PRMT ICS_SWMS_4_PRMT 
 JOIN ICS_MS_4_INDST_SW_REQS I9
 ON I9.ICS_SWMS_4_PRMT_ID = ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_ID 
 JOIN ICS_MS_4_INDST_SW_REGULATED_ENTITY_INFO I12
 ON I12.ICS_MS_4_INDST_SW_REQS_ID = I9.ICS_MS_4_INDST_SW_REQS_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
       WHERE ICS_SWMS_4_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SWMS4PermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4PermitSubmission');


-- /ICS_SWMS_4_PRMT/ICS_MS_4_OTHR_APPL_REQS
INSERT INTO ics_flow_icis.ICS_MS_4_OTHR_APPL_REQS
     SELECT I13.*
              from ICS_SWMS_4_PRMT ICS_SWMS_4_PRMT 
 JOIN ICS_MS_4_OTHR_APPL_REQS I13
 ON I13.ICS_SWMS_4_PRMT_ID = ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
       WHERE ICS_SWMS_4_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SWMS4PermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4PermitSubmission');


-- /ICS_SWMS_4_PRMT/ICS_MS_4_OTHR_APPL_REQS/ICS_MS_4_REGULATED_ENTITY_IDENT
INSERT INTO ics_flow_icis.ICS_MS_4_REGULATED_ENTITY_IDENT
     SELECT I14.*
              from ICS_SWMS_4_PRMT ICS_SWMS_4_PRMT 
 JOIN ICS_MS_4_OTHR_APPL_REQS I13
 ON I13.ICS_SWMS_4_PRMT_ID = ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_ID 
 JOIN ICS_MS_4_REGULATED_ENTITY_IDENT I14
 ON I14.ICS_MS_4_OTHR_APPL_REQS_ID = I13.ICS_MS_4_OTHR_APPL_REQS_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
       WHERE ICS_SWMS_4_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SWMS4PermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4PermitSubmission');


-- /ICS_SWMS_4_PRMT/ICS_MS_4_PBLC_EDUCATION_REQS
INSERT INTO ics_flow_icis.ICS_MS_4_PBLC_EDUCATION_REQS
     SELECT I15.*
              from ICS_SWMS_4_PRMT ICS_SWMS_4_PRMT 
 JOIN ICS_MS_4_PBLC_EDUCATION_REQS I15
 ON I15.ICS_SWMS_4_PRMT_ID = ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
       WHERE ICS_SWMS_4_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SWMS4PermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4PermitSubmission');




-- /ICS_SWMS_4_PRMT/ICS_MS_4_PBLC_EDUCATION_REQS/ICS_MS_4_REGULATED_ENTITY_IDENT
INSERT INTO ics_flow_icis.ICS_MS_4_REGULATED_ENTITY_IDENT
     SELECT I16.*
              from ICS_SWMS_4_PRMT ICS_SWMS_4_PRMT 
 JOIN ICS_MS_4_PBLC_EDUCATION_REQS I15
 ON I15.ICS_SWMS_4_PRMT_ID = ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_ID 
 JOIN ICS_MS_4_REGULATED_ENTITY_IDENT I16
 ON I16.ICS_MS_4_PBLC_EDUCATION_REQS_ID = I15.ICS_MS_4_PBLC_EDUCATION_REQS_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
       WHERE ICS_SWMS_4_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SWMS4PermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4PermitSubmission');


-- /ICS_SWMS_4_PRMT/ICS_MS_4_PBLC_INVOLVEMENT_REQS
INSERT INTO ics_flow_icis.ICS_MS_4_PBLC_INVOLVEMENT_REQS
     SELECT I17.*
              from ICS_SWMS_4_PRMT ICS_SWMS_4_PRMT 
 JOIN ICS_MS_4_PBLC_INVOLVEMENT_REQS I17
 ON I17.ICS_SWMS_4_PRMT_ID = ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
       WHERE ICS_SWMS_4_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SWMS4PermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4PermitSubmission');


-- /ICS_SWMS_4_PRMT/ICS_MS_4_PBLC_INVOLVEMENT_REQS/ICS_MS_4_REGULATED_ENTITY_IDENT
INSERT INTO ics_flow_icis.ICS_MS_4_REGULATED_ENTITY_IDENT
     SELECT I18.*
              from ICS_SWMS_4_PRMT ICS_SWMS_4_PRMT 
 JOIN ICS_MS_4_PBLC_INVOLVEMENT_REQS I17
 ON I17.ICS_SWMS_4_PRMT_ID = ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_ID 
 JOIN ICS_MS_4_REGULATED_ENTITY_IDENT I18
 ON I18.ICS_MS_4_PBLC_INVOLVEMENT_REQS_ID = I17.ICS_MS_4_PBLC_INVOLVEMENT_REQS_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
       WHERE ICS_SWMS_4_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SWMS4PermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4PermitSubmission');


-- /ICS_SWMS_4_PRMT/ICS_MS_4_POLLUTION_PREVENTION_REQS
INSERT INTO ics_flow_icis.ICS_MS_4_POLLUTION_PREVENTION_REQS
     SELECT I19.*
              from ICS_SWMS_4_PRMT ICS_SWMS_4_PRMT 
 JOIN ICS_MS_4_POLLUTION_PREVENTION_REQS I19
 ON I19.ICS_SWMS_4_PRMT_ID = ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
       WHERE ICS_SWMS_4_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SWMS4PermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4PermitSubmission');


-- /ICS_SWMS_4_PRMT/ICS_MS_4_POLLUTION_PREVENTION_REQS/ICS_MS_4_REGULATED_ENTITY_IDENT
INSERT INTO ics_flow_icis.ICS_MS_4_REGULATED_ENTITY_IDENT
     SELECT I20.*
              from ICS_SWMS_4_PRMT ICS_SWMS_4_PRMT 
 JOIN ICS_MS_4_POLLUTION_PREVENTION_REQS I19
 ON I19.ICS_SWMS_4_PRMT_ID = ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_ID 
 JOIN ICS_MS_4_REGULATED_ENTITY_IDENT I20
 ON I20.ICS_MS_4_POLLUTION_PREVENTION_REQS_ID = I19.ICS_MS_4_POLLUTION_PREVENTION_REQS_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
       WHERE ICS_SWMS_4_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SWMS4PermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4PermitSubmission');


-- /ICS_SWMS_4_PRMT/ICS_MS_4_POST_CNST_SW_REQS
INSERT INTO ics_flow_icis.ICS_MS_4_POST_CNST_SW_REQS
     SELECT I21.*
              from ICS_SWMS_4_PRMT ICS_SWMS_4_PRMT 
 JOIN ICS_MS_4_POST_CNST_SW_REQS I21
 ON I21.ICS_SWMS_4_PRMT_ID = ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
       WHERE ICS_SWMS_4_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SWMS4PermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4PermitSubmission');


-- /ICS_SWMS_4_PRMT/ICS_MS_4_POST_CNST_SW_REQS/ICS_MS_4_POST_CNST_SW_PROCEDURES
INSERT INTO ics_flow_icis.ICS_MS_4_POST_CNST_SW_PROCEDURES
     SELECT I22.*
              from ICS_SWMS_4_PRMT ICS_SWMS_4_PRMT 
 JOIN ICS_MS_4_POST_CNST_SW_REQS I21
 ON I21.ICS_SWMS_4_PRMT_ID = ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_ID 
 JOIN ICS_MS_4_POST_CNST_SW_PROCEDURES I22
 ON I22.ICS_MS_4_POST_CNST_SW_REQS_ID = I21.ICS_MS_4_POST_CNST_SW_REQS_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
       WHERE ICS_SWMS_4_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SWMS4PermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4PermitSubmission');


-- /ICS_SWMS_4_PRMT/ICS_MS_4_POST_CNST_SW_REQS/ICS_MS_4_POST_CNST_SW_PROCEDURES/ICS_MS_4_REGULATED_ENTITY_IDENT
INSERT INTO ics_flow_icis.ICS_MS_4_REGULATED_ENTITY_IDENT
     SELECT I23.*
              from ICS_SWMS_4_PRMT ICS_SWMS_4_PRMT 
 JOIN ICS_MS_4_POST_CNST_SW_REQS I21
 ON I21.ICS_SWMS_4_PRMT_ID = ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_ID 
 JOIN ICS_MS_4_POST_CNST_SW_PROCEDURES I22
 ON I22.ICS_MS_4_POST_CNST_SW_REQS_ID = I21.ICS_MS_4_POST_CNST_SW_REQS_ID 
 JOIN ICS_MS_4_REGULATED_ENTITY_IDENT I23
 ON I23.ICS_MS_4_POST_CNST_SW_PROCEDURES_ID = I22.ICS_MS_4_POST_CNST_SW_PROCEDURES_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
       WHERE ICS_SWMS_4_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SWMS4PermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4PermitSubmission');


-- /ICS_SWMS_4_PRMT/ICS_MS_4_POST_CNST_SW_REQS/ICS_MS_4_POST_CNST_SW_REGULATED_ENTITY_INFO
INSERT INTO ics_flow_icis.ICS_MS_4_POST_CNST_SW_REGULATED_ENTITY_INFO
     SELECT I24.*
              from ICS_SWMS_4_PRMT ICS_SWMS_4_PRMT 
 JOIN ICS_MS_4_POST_CNST_SW_REQS I21
 ON I21.ICS_SWMS_4_PRMT_ID = ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_ID 
 JOIN ICS_MS_4_POST_CNST_SW_REGULATED_ENTITY_INFO I24
 ON I24.ICS_MS_4_POST_CNST_SW_REQS_ID = I21.ICS_MS_4_POST_CNST_SW_REQS_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
       WHERE ICS_SWMS_4_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SWMS4PermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4PermitSubmission');


-- /ICS_SWMS_4_PRMT/ICS_MS_4_REGULATED_ENTITY
INSERT INTO ics_flow_icis.ICS_MS_4_REGULATED_ENTITY
     SELECT I25.*
              from ICS_SWMS_4_PRMT ICS_SWMS_4_PRMT 
 JOIN ICS_MS_4_REGULATED_ENTITY I25
 ON I25.ICS_SWMS_4_PRMT_ID = ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
       WHERE ICS_SWMS_4_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SWMS4PermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4PermitSubmission');


-- /ICS_SWMS_4_PRMT/ICS_MS_4_REGULATED_ENTITY_AREA
INSERT INTO ics_flow_icis.ICS_MS_4_REGULATED_ENTITY_AREA
     SELECT I26.*
              from ICS_SWMS_4_PRMT ICS_SWMS_4_PRMT 
 JOIN ICS_MS_4_REGULATED_ENTITY_AREA I26
 ON I26.ICS_SWMS_4_PRMT_ID = ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
       WHERE ICS_SWMS_4_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SWMS4PermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4PermitSubmission');


-- /ICS_SWMS_4_PRMT/ICS_MS_4_REGULATED_ENTITY_AREA/ICS_MS_4_REGULATED_ENTITY_AREA_COORD
INSERT INTO ics_flow_icis.ICS_MS_4_REGULATED_ENTITY_AREA_COORD
     SELECT I27.*
              from ICS_SWMS_4_PRMT ICS_SWMS_4_PRMT 
 JOIN ICS_MS_4_REGULATED_ENTITY_AREA I26
 ON I26.ICS_SWMS_4_PRMT_ID = ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_ID 
 JOIN ICS_MS_4_REGULATED_ENTITY_AREA_COORD I27
 ON I27.ICS_MS_4_REGULATED_ENTITY_AREA_ID = I26.ICS_MS_4_REGULATED_ENTITY_AREA_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH
       WHERE ICS_SWMS_4_PRMT.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'SWMS4PermitSubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'SWMS4PermitSubmission');
	




-- Remove any old records for ICS_UNPRMT_FAC
				
-- /ICS_UNPRMT_FAC/ICS_ADDR/ICS_TELEPH
DELETE
  FROM ics_flow_icis.ICS_TELEPH
 WHERE ICS_TELEPH.ICS_ADDR_ID IN
          (SELECT I11.ICS_ADDR_ID
              from ics_flow_icis.ICS_UNPRMT_FAC ICS_UNPRMT_FAC 
 JOIN ics_flow_icis.ICS_ADDR I10
 ON I10.ICS_UNPRMT_FAC_ID = ICS_UNPRMT_FAC.ICS_UNPRMT_FAC_ID 
 JOIN ics_flow_icis.ICS_TELEPH I11
 ON I11.ICS_ADDR_ID = I10.ICS_ADDR_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_UNPRMT_FAC.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'UnpermittedFacilitySubmission')
                  OR ICS_UNPRMT_FAC.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_UNPRMT_FAC/ICS_ADDR
DELETE
  FROM ics_flow_icis.ICS_ADDR
 WHERE ICS_ADDR.ICS_UNPRMT_FAC_ID IN
          (SELECT I10.ICS_UNPRMT_FAC_ID
              from ics_flow_icis.ICS_UNPRMT_FAC ICS_UNPRMT_FAC 
 JOIN ics_flow_icis.ICS_ADDR I10
 ON I10.ICS_UNPRMT_FAC_ID = ICS_UNPRMT_FAC.ICS_UNPRMT_FAC_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_UNPRMT_FAC.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'UnpermittedFacilitySubmission')
                  OR ICS_UNPRMT_FAC.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_UNPRMT_FAC/ICS_SIC_CODE
DELETE
  FROM ics_flow_icis.ICS_SIC_CODE
 WHERE ICS_SIC_CODE.ICS_UNPRMT_FAC_ID IN
          (SELECT I9.ICS_UNPRMT_FAC_ID
              from ics_flow_icis.ICS_UNPRMT_FAC ICS_UNPRMT_FAC 
 JOIN ics_flow_icis.ICS_SIC_CODE I9
 ON I9.ICS_UNPRMT_FAC_ID = ICS_UNPRMT_FAC.ICS_UNPRMT_FAC_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_UNPRMT_FAC.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'UnpermittedFacilitySubmission')
                  OR ICS_UNPRMT_FAC.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_UNPRMT_FAC/ICS_GEO_COORD
DELETE
  FROM ics_flow_icis.ICS_GEO_COORD
 WHERE ICS_GEO_COORD.ICS_UNPRMT_FAC_ID IN
          (SELECT I8.ICS_UNPRMT_FAC_ID
              from ics_flow_icis.ICS_UNPRMT_FAC ICS_UNPRMT_FAC 
 JOIN ics_flow_icis.ICS_GEO_COORD I8
 ON I8.ICS_UNPRMT_FAC_ID = ICS_UNPRMT_FAC.ICS_UNPRMT_FAC_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_UNPRMT_FAC.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'UnpermittedFacilitySubmission')
                  OR ICS_UNPRMT_FAC.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_UNPRMT_FAC/ICS_FAC_CLASS
DELETE
  FROM ics_flow_icis.ICS_FAC_CLASS
 WHERE ICS_FAC_CLASS.ICS_UNPRMT_FAC_ID IN
          (SELECT I7.ICS_UNPRMT_FAC_ID
              from ics_flow_icis.ICS_UNPRMT_FAC ICS_UNPRMT_FAC 
 JOIN ics_flow_icis.ICS_FAC_CLASS I7
 ON I7.ICS_UNPRMT_FAC_ID = ICS_UNPRMT_FAC.ICS_UNPRMT_FAC_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_UNPRMT_FAC.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'UnpermittedFacilitySubmission')
                  OR ICS_UNPRMT_FAC.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_UNPRMT_FAC/ICS_PRMT_COMP_TYPE
DELETE
  FROM ics_flow_icis.ICS_PRMT_COMP_TYPE
 WHERE ICS_PRMT_COMP_TYPE.ICS_UNPRMT_FAC_ID IN
          (SELECT I6.ICS_UNPRMT_FAC_ID
              from ics_flow_icis.ICS_UNPRMT_FAC ICS_UNPRMT_FAC 
 JOIN ics_flow_icis.ICS_PRMT_COMP_TYPE I6
 ON I6.ICS_UNPRMT_FAC_ID = ICS_UNPRMT_FAC.ICS_UNPRMT_FAC_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_UNPRMT_FAC.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'UnpermittedFacilitySubmission')
                  OR ICS_UNPRMT_FAC.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_UNPRMT_FAC/ICS_PLCY
DELETE
  FROM ics_flow_icis.ICS_PLCY
 WHERE ICS_PLCY.ICS_UNPRMT_FAC_ID IN
          (SELECT I5.ICS_UNPRMT_FAC_ID
              from ics_flow_icis.ICS_UNPRMT_FAC ICS_UNPRMT_FAC 
 JOIN ics_flow_icis.ICS_PLCY I5
 ON I5.ICS_UNPRMT_FAC_ID = ICS_UNPRMT_FAC.ICS_UNPRMT_FAC_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_UNPRMT_FAC.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'UnpermittedFacilitySubmission')
                  OR ICS_UNPRMT_FAC.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_UNPRMT_FAC/ICS_ORIG_PROGS
DELETE
  FROM ics_flow_icis.ICS_ORIG_PROGS
 WHERE ICS_ORIG_PROGS.ICS_UNPRMT_FAC_ID IN
          (SELECT I4.ICS_UNPRMT_FAC_ID
              from ics_flow_icis.ICS_UNPRMT_FAC ICS_UNPRMT_FAC 
 JOIN ics_flow_icis.ICS_ORIG_PROGS I4
 ON I4.ICS_UNPRMT_FAC_ID = ICS_UNPRMT_FAC.ICS_UNPRMT_FAC_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_UNPRMT_FAC.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'UnpermittedFacilitySubmission')
                  OR ICS_UNPRMT_FAC.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_UNPRMT_FAC/ICS_CONTACT/ICS_TELEPH
DELETE
  FROM ics_flow_icis.ICS_TELEPH
 WHERE ICS_TELEPH.ICS_CONTACT_ID IN
          (SELECT I3.ICS_CONTACT_ID
              from ics_flow_icis.ICS_UNPRMT_FAC ICS_UNPRMT_FAC 
 JOIN ics_flow_icis.ICS_CONTACT I2
 ON I2.ICS_UNPRMT_FAC_ID = ICS_UNPRMT_FAC.ICS_UNPRMT_FAC_ID 
 JOIN ics_flow_icis.ICS_TELEPH I3
 ON I3.ICS_CONTACT_ID = I2.ICS_CONTACT_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_UNPRMT_FAC.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'UnpermittedFacilitySubmission')
                  OR ICS_UNPRMT_FAC.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_UNPRMT_FAC/ICS_CONTACT
DELETE
  FROM ics_flow_icis.ICS_CONTACT
 WHERE ICS_CONTACT.ICS_UNPRMT_FAC_ID IN
          (SELECT I2.ICS_UNPRMT_FAC_ID
              from ics_flow_icis.ICS_UNPRMT_FAC ICS_UNPRMT_FAC 
 JOIN ics_flow_icis.ICS_CONTACT I2
 ON I2.ICS_UNPRMT_FAC_ID = ICS_UNPRMT_FAC.ICS_UNPRMT_FAC_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_UNPRMT_FAC.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'UnpermittedFacilitySubmission')
                  OR ICS_UNPRMT_FAC.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_UNPRMT_FAC/ICS_NAICS_CODE
DELETE
  FROM ics_flow_icis.ICS_NAICS_CODE
 WHERE ICS_NAICS_CODE.ICS_UNPRMT_FAC_ID IN
          (SELECT I1.ICS_UNPRMT_FAC_ID
              from ics_flow_icis.ICS_UNPRMT_FAC ICS_UNPRMT_FAC 
 JOIN ics_flow_icis.ICS_NAICS_CODE I1
 ON I1.ICS_UNPRMT_FAC_ID = ICS_UNPRMT_FAC.ICS_UNPRMT_FAC_ID 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_UNPRMT_FAC.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'UnpermittedFacilitySubmission')
                  OR ICS_UNPRMT_FAC.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

				
-- /ICS_UNPRMT_FAC
DELETE
  FROM ics_flow_icis.ICS_UNPRMT_FAC
 WHERE ICS_UNPRMT_FAC.ICS_UNPRMT_FAC_ID IN
          (SELECT ICS_UNPRMT_FAC.ICS_UNPRMT_FAC_ID
              from ics_flow_icis.ICS_UNPRMT_FAC ICS_UNPRMT_FAC 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_UNPRMT_FAC.KEY_HASH
              WHERE (result_type_code IN ('Accepted','Warning') AND subm_type_name = 'UnpermittedFacilitySubmission')
                  OR ICS_UNPRMT_FAC.prmt_ident IN (SELECT prmt_ident FROM ics_subm_results WHERE subm_type_name = 'PermitTerminationSubmission' AND result_type_code = 'Accepted')
                 
);

	
-- Add accepted records for ICS_UNPRMT_FAC


-- /ICS_UNPRMT_FAC
INSERT INTO ics_flow_icis.ICS_UNPRMT_FAC
     SELECT ICS_UNPRMT_FAC.*
              from ICS_UNPRMT_FAC ICS_UNPRMT_FAC 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_UNPRMT_FAC.KEY_HASH
       WHERE ICS_UNPRMT_FAC.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'UnpermittedFacilitySubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'UnpermittedFacilitySubmission');


-- /ICS_UNPRMT_FAC/ICS_NAICS_CODE
INSERT INTO ics_flow_icis.ICS_NAICS_CODE
     SELECT I1.*
              from ICS_UNPRMT_FAC ICS_UNPRMT_FAC 
 JOIN ICS_NAICS_CODE I1
 ON I1.ICS_UNPRMT_FAC_ID = ICS_UNPRMT_FAC.ICS_UNPRMT_FAC_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_UNPRMT_FAC.KEY_HASH
       WHERE ICS_UNPRMT_FAC.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'UnpermittedFacilitySubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'UnpermittedFacilitySubmission');


-- /ICS_UNPRMT_FAC/ICS_CONTACT
INSERT INTO ics_flow_icis.ICS_CONTACT
     SELECT I2.*
              from ICS_UNPRMT_FAC ICS_UNPRMT_FAC 
 JOIN ICS_CONTACT I2
 ON I2.ICS_UNPRMT_FAC_ID = ICS_UNPRMT_FAC.ICS_UNPRMT_FAC_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_UNPRMT_FAC.KEY_HASH
       WHERE ICS_UNPRMT_FAC.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'UnpermittedFacilitySubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'UnpermittedFacilitySubmission');


-- /ICS_UNPRMT_FAC/ICS_CONTACT/ICS_TELEPH
INSERT INTO ics_flow_icis.ICS_TELEPH
     SELECT I3.*
              from ICS_UNPRMT_FAC ICS_UNPRMT_FAC 
 JOIN ICS_CONTACT I2
 ON I2.ICS_UNPRMT_FAC_ID = ICS_UNPRMT_FAC.ICS_UNPRMT_FAC_ID 
 JOIN ICS_TELEPH I3
 ON I3.ICS_CONTACT_ID = I2.ICS_CONTACT_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_UNPRMT_FAC.KEY_HASH
       WHERE ICS_UNPRMT_FAC.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'UnpermittedFacilitySubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'UnpermittedFacilitySubmission');


-- /ICS_UNPRMT_FAC/ICS_ORIG_PROGS
INSERT INTO ics_flow_icis.ICS_ORIG_PROGS
     SELECT I4.*
              from ICS_UNPRMT_FAC ICS_UNPRMT_FAC 
 JOIN ICS_ORIG_PROGS I4
 ON I4.ICS_UNPRMT_FAC_ID = ICS_UNPRMT_FAC.ICS_UNPRMT_FAC_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_UNPRMT_FAC.KEY_HASH
       WHERE ICS_UNPRMT_FAC.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'UnpermittedFacilitySubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'UnpermittedFacilitySubmission');


-- /ICS_UNPRMT_FAC/ICS_PLCY
INSERT INTO ics_flow_icis.ICS_PLCY
     SELECT I5.*
              from ICS_UNPRMT_FAC ICS_UNPRMT_FAC 
 JOIN ICS_PLCY I5
 ON I5.ICS_UNPRMT_FAC_ID = ICS_UNPRMT_FAC.ICS_UNPRMT_FAC_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_UNPRMT_FAC.KEY_HASH
       WHERE ICS_UNPRMT_FAC.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'UnpermittedFacilitySubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'UnpermittedFacilitySubmission');


-- /ICS_UNPRMT_FAC/ICS_PRMT_COMP_TYPE
INSERT INTO ics_flow_icis.ICS_PRMT_COMP_TYPE
     SELECT I6.*
              from ICS_UNPRMT_FAC ICS_UNPRMT_FAC 
 JOIN ICS_PRMT_COMP_TYPE I6
 ON I6.ICS_UNPRMT_FAC_ID = ICS_UNPRMT_FAC.ICS_UNPRMT_FAC_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_UNPRMT_FAC.KEY_HASH
       WHERE ICS_UNPRMT_FAC.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'UnpermittedFacilitySubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'UnpermittedFacilitySubmission');


-- /ICS_UNPRMT_FAC/ICS_FAC_CLASS
INSERT INTO ics_flow_icis.ICS_FAC_CLASS
     SELECT I7.*
              from ICS_UNPRMT_FAC ICS_UNPRMT_FAC 
 JOIN ICS_FAC_CLASS I7
 ON I7.ICS_UNPRMT_FAC_ID = ICS_UNPRMT_FAC.ICS_UNPRMT_FAC_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_UNPRMT_FAC.KEY_HASH
       WHERE ICS_UNPRMT_FAC.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'UnpermittedFacilitySubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'UnpermittedFacilitySubmission');


-- /ICS_UNPRMT_FAC/ICS_GEO_COORD
INSERT INTO ics_flow_icis.ICS_GEO_COORD
     SELECT I8.*
              from ICS_UNPRMT_FAC ICS_UNPRMT_FAC 
 JOIN ICS_GEO_COORD I8
 ON I8.ICS_UNPRMT_FAC_ID = ICS_UNPRMT_FAC.ICS_UNPRMT_FAC_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_UNPRMT_FAC.KEY_HASH
       WHERE ICS_UNPRMT_FAC.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'UnpermittedFacilitySubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'UnpermittedFacilitySubmission');


-- /ICS_UNPRMT_FAC/ICS_SIC_CODE
INSERT INTO ics_flow_icis.ICS_SIC_CODE
     SELECT I9.*
              from ICS_UNPRMT_FAC ICS_UNPRMT_FAC 
 JOIN ICS_SIC_CODE I9
 ON I9.ICS_UNPRMT_FAC_ID = ICS_UNPRMT_FAC.ICS_UNPRMT_FAC_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_UNPRMT_FAC.KEY_HASH
       WHERE ICS_UNPRMT_FAC.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'UnpermittedFacilitySubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'UnpermittedFacilitySubmission');


-- /ICS_UNPRMT_FAC/ICS_ADDR
INSERT INTO ics_flow_icis.ICS_ADDR
     SELECT I10.*
              from ICS_UNPRMT_FAC ICS_UNPRMT_FAC 
 JOIN ICS_ADDR I10
 ON I10.ICS_UNPRMT_FAC_ID = ICS_UNPRMT_FAC.ICS_UNPRMT_FAC_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_UNPRMT_FAC.KEY_HASH
       WHERE ICS_UNPRMT_FAC.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'UnpermittedFacilitySubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'UnpermittedFacilitySubmission');


-- /ICS_UNPRMT_FAC/ICS_ADDR/ICS_TELEPH
INSERT INTO ics_flow_icis.ICS_TELEPH
     SELECT I11.*
              from ICS_UNPRMT_FAC ICS_UNPRMT_FAC 
 JOIN ICS_ADDR I10
 ON I10.ICS_UNPRMT_FAC_ID = ICS_UNPRMT_FAC.ICS_UNPRMT_FAC_ID 
 JOIN ICS_TELEPH I11
 ON I11.ICS_ADDR_ID = I10.ICS_ADDR_ID 
 
			 JOIN ICS_SUBM_RESULTS ISR on ISR.KEY_HASH = ICS_UNPRMT_FAC.KEY_HASH
       WHERE ICS_UNPRMT_FAC.transaction_type not in ('D','X')
             AND ISR.SUBM_TYPE_NAME = 'UnpermittedFacilitySubmission'
        AND ISR.key_hash IN 
              (SELECT key_hash
                 FROM ics_subm_results
                WHERE result_type_code IN ('Accepted','Warning')
                  AND subm_type_name = 'UnpermittedFacilitySubmission');
	


--Step 4: Copy business keys where ICIS returnes error that key is already present in ICIS

  -- Add keys that already exist in ICIS for module ICS_BASIC_PRMT
  INSERT INTO ics_flow_icis.ICS_BASIC_PRMT (ics_payload_id, ICS_BASIC_PRMT_ID, PRMT_IDENT, key_hash, data_hash)
       SELECT (SELECT ics_payload_id FROM ics_payload WHERE operation='BasicPermitSubmission') as payload_id, SYS_GUID(), PRMT_IDENT, key_hash, '0' as data_hash
         FROM ics_subm_results
        WHERE result_code = 'BP060'
          AND subm_type_name = 'BasicPermitSubmission'
          AND subm_transaction_id = p_transaction_id
          AND key_hash NOT IN (SELECT key_hash FROM ics_flow_icis.ICS_BASIC_PRMT)
     GROUP BY PRMT_IDENT, key_hash;

  -- Add keys that already exist in ICIS for module ICS_BS_PRMT
  INSERT INTO ics_flow_icis.ICS_BS_PRMT (ics_payload_id, ICS_BS_PRMT_ID, PRMT_IDENT, key_hash, data_hash)
       SELECT (SELECT ics_payload_id FROM ics_payload WHERE operation='BiosolidsPermitSubmission') as payload_id, SYS_GUID(), PRMT_IDENT, key_hash, '0' as data_hash
         FROM ics_subm_results
        WHERE result_code = 'PC040'
          AND subm_type_name = 'BiosolidsPermitSubmission'
          AND subm_transaction_id = p_transaction_id
          AND key_hash NOT IN (SELECT key_hash FROM ics_flow_icis.ICS_BS_PRMT)
     GROUP BY PRMT_IDENT, key_hash;

  -- Add keys that already exist in ICIS for module ICS_CAFO_PRMT
  INSERT INTO ics_flow_icis.ICS_CAFO_PRMT (ics_payload_id, ICS_CAFO_PRMT_ID, PRMT_IDENT, key_hash, data_hash)
       SELECT (SELECT ics_payload_id FROM ics_payload WHERE operation='CAFOPermitSubmission') as payload_id, SYS_GUID(), PRMT_IDENT, key_hash, '0' as data_hash
         FROM ics_subm_results
        WHERE result_code = 'PC040'
          AND subm_type_name = 'CAFOPermitSubmission'
          AND subm_transaction_id = p_transaction_id
          AND key_hash NOT IN (SELECT key_hash FROM ics_flow_icis.ICS_CAFO_PRMT)
     GROUP BY PRMT_IDENT, key_hash;

  -- Add keys that already exist in ICIS for module ICS_CMPL_MON
  INSERT INTO ics_flow_icis.ICS_CMPL_MON (ics_payload_id, ICS_CMPL_MON_ID, CMPL_MON_IDENT, key_hash, data_hash)
       SELECT (SELECT ics_payload_id FROM ics_payload WHERE operation='ComplianceMonitoringSubmission') as payload_id, SYS_GUID(), CMPL_MON_IDENT, key_hash, '0' as data_hash
         FROM ics_subm_results
        WHERE result_code = 'CM030'
          AND subm_type_name = 'ComplianceMonitoringSubmission'
          AND subm_transaction_id = p_transaction_id
          AND key_hash NOT IN (SELECT key_hash FROM ics_flow_icis.ICS_CMPL_MON)
     GROUP BY CMPL_MON_IDENT, key_hash;

  -- Add keys that already exist in ICIS for module ICS_COPY_MGP_LMT_SET
  INSERT INTO ics_flow_icis.ICS_COPY_MGP_LMT_SET (ics_payload_id, ICS_COPY_MGP_LMT_SET_ID, PRMT_IDENT,PRMT_FEATR_IDENT,LMT_SET_DESIGNATOR, key_hash, data_hash)
       SELECT (SELECT ics_payload_id FROM ics_payload WHERE operation='CopyMGPLimitSetSubmission') as payload_id, SYS_GUID(), PRMT_IDENT,PRMT_FEATR_IDENT,LMT_SET_DESIGNATOR, key_hash, '0' as data_hash
         FROM ics_subm_results
        WHERE result_code = 'SEV030'
          AND subm_type_name = 'CopyMGPLimitSetSubmission'
          AND subm_transaction_id = p_transaction_id
          AND key_hash NOT IN (SELECT key_hash FROM ics_flow_icis.ICS_COPY_MGP_LMT_SET)
     GROUP BY PRMT_IDENT,PRMT_FEATR_IDENT,LMT_SET_DESIGNATOR, key_hash;

  -- Add keys that already exist in ICIS for module ICS_EFFLU_TRADE_PRTNER
  INSERT INTO ics_flow_icis.ICS_EFFLU_TRADE_PRTNER (ics_payload_id, ICS_EFFLU_TRADE_PRTNER_ID, PRMT_IDENT, PRMT_FEATR_IDENT, LMT_SET_DESIGNATOR, PARAM_CODE, MON_SITE_DESC_CODE, LMT_SEASON_NUM, LMT_START_DATE, LMT_END_DATE, LMT_MOD_EFFECTIVE_DATE, TRADE_ID, key_hash, data_hash)
       SELECT (SELECT ics_payload_id FROM ics_payload WHERE operation='EffluentTradePartnerSubmission') as payload_id, SYS_GUID(), PRMT_IDENT, PRMT_FEATR_IDENT, LMT_SET_DESIGNATOR, PARAM_CODE, MON_SITE_DESC_CODE, LMT_SEASON_NUM, LMT_START_DATE, LMT_END_DATE, LMT_MOD_EFFECTIVE_DATE, TRADE_ID, key_hash, '0' as data_hash
         FROM ics_subm_results
        WHERE result_code = 'ETP030'
          AND subm_type_name = 'EffluentTradePartnerSubmission'
          AND subm_transaction_id = p_transaction_id
          AND key_hash NOT IN (SELECT key_hash FROM ics_flow_icis.ICS_EFFLU_TRADE_PRTNER)
     GROUP BY PRMT_IDENT, PRMT_FEATR_IDENT, LMT_SET_DESIGNATOR, PARAM_CODE, MON_SITE_DESC_CODE, LMT_SEASON_NUM, LMT_START_DATE, LMT_END_DATE, LMT_MOD_EFFECTIVE_DATE, TRADE_ID, key_hash;

  -- Add keys that already exist in ICIS for module ICS_FRML_ENFRC_ACTN
  INSERT INTO ics_flow_icis.ICS_FRML_ENFRC_ACTN (ics_payload_id, ICS_FRML_ENFRC_ACTN_ID, ENFRC_ACTN_IDENT, key_hash, data_hash)
       SELECT (SELECT ics_payload_id FROM ics_payload WHERE operation='FormalEnforcementActionSubmission') as payload_id, SYS_GUID(), ENFRC_ACTN_IDENT, key_hash, '0' as data_hash
         FROM ics_subm_results
        WHERE result_code = 'FEA030'
          AND subm_type_name = 'FormalEnforcementActionSubmission'
          AND subm_transaction_id = p_transaction_id
          AND key_hash NOT IN (SELECT key_hash FROM ics_flow_icis.ICS_FRML_ENFRC_ACTN)
     GROUP BY ENFRC_ACTN_IDENT, key_hash;

  -- Add keys that already exist in ICIS for module ICS_GNRL_PRMT
  INSERT INTO ics_flow_icis.ICS_GNRL_PRMT (ics_payload_id, ICS_GNRL_PRMT_ID, PRMT_IDENT, key_hash, data_hash)
       SELECT (SELECT ics_payload_id FROM ics_payload WHERE operation='GeneralPermitSubmission') as payload_id, SYS_GUID(), PRMT_IDENT, key_hash, '0' as data_hash
         FROM ics_subm_results
        WHERE result_code = 'BP060'
          AND subm_type_name = 'GeneralPermitSubmission'
          AND subm_transaction_id = p_transaction_id
          AND key_hash NOT IN (SELECT key_hash FROM ics_flow_icis.ICS_GNRL_PRMT)
     GROUP BY PRMT_IDENT, key_hash;

  -- Add keys that already exist in ICIS for module ICS_INFRML_ENFRC_ACTN
  INSERT INTO ics_flow_icis.ICS_INFRML_ENFRC_ACTN (ics_payload_id, ICS_INFRML_ENFRC_ACTN_ID, ENFRC_ACTN_IDENT, key_hash, data_hash)
       SELECT (SELECT ics_payload_id FROM ics_payload WHERE operation='InformalEnforcementActionSubmission') as payload_id, SYS_GUID(), ENFRC_ACTN_IDENT, key_hash, '0' as data_hash
         FROM ics_subm_results
        WHERE result_code = 'IEA030'
          AND subm_type_name = 'InformalEnforcementActionSubmission'
          AND subm_transaction_id = p_transaction_id
          AND key_hash NOT IN (SELECT key_hash FROM ics_flow_icis.ICS_INFRML_ENFRC_ACTN)
     GROUP BY ENFRC_ACTN_IDENT, key_hash;

  -- Add keys that already exist in ICIS for module ICS_LMTS
  INSERT INTO ics_flow_icis.ICS_LMTS (ics_payload_id, ICS_LMTS_ID, PRMT_IDENT, PRMT_FEATR_IDENT, LMT_SET_DESIGNATOR, PARAM_CODE, MON_SITE_DESC_CODE, LMT_SEASON_NUM, LMT_START_DATE, LMT_END_DATE, key_hash, data_hash)
       SELECT (SELECT ics_payload_id FROM ics_payload WHERE operation='LimitsSubmission') as payload_id, SYS_GUID(), PRMT_IDENT, PRMT_FEATR_IDENT, LMT_SET_DESIGNATOR, PARAM_CODE, MON_SITE_DESC_CODE, LMT_SEASON_NUM, LMT_START_DATE, LMT_END_DATE, key_hash, '0' as data_hash
         FROM ics_subm_results
        WHERE result_code = 'LTS050'
          AND subm_type_name = 'LimitsSubmission'
          AND subm_transaction_id = p_transaction_id
          AND key_hash NOT IN (SELECT key_hash FROM ics_flow_icis.ICS_LMTS)
     GROUP BY PRMT_IDENT, PRMT_FEATR_IDENT, LMT_SET_DESIGNATOR, PARAM_CODE, MON_SITE_DESC_CODE, LMT_SEASON_NUM, LMT_START_DATE, LMT_END_DATE, key_hash;

  -- Add keys that already exist in ICIS for module ICS_LMT_SET
  INSERT INTO ics_flow_icis.ICS_LMT_SET (ics_payload_id, ICS_LMT_SET_ID, PRMT_IDENT, PRMT_FEATR_IDENT, LMT_SET_DESIGNATOR, key_hash, data_hash)
       SELECT (SELECT ics_payload_id FROM ics_payload WHERE operation='LimitSetSubmission') as payload_id, SYS_GUID(), PRMT_IDENT, PRMT_FEATR_IDENT, LMT_SET_DESIGNATOR, key_hash, '0' as data_hash
         FROM ics_subm_results
        WHERE result_code = 'LS060'
          AND subm_type_name = 'LimitSetSubmission'
          AND subm_transaction_id = p_transaction_id
          AND key_hash NOT IN (SELECT key_hash FROM ics_flow_icis.ICS_LMT_SET)
     GROUP BY PRMT_IDENT, PRMT_FEATR_IDENT, LMT_SET_DESIGNATOR, key_hash;

  -- Add keys that already exist in ICIS for module ICS_MASTER_GNRL_PRMT
  INSERT INTO ics_flow_icis.ICS_MASTER_GNRL_PRMT (ics_payload_id, ICS_MASTER_GNRL_PRMT_ID, PRMT_IDENT, key_hash, data_hash)
       SELECT (SELECT ics_payload_id FROM ics_payload WHERE operation='MasterGeneralPermitSubmission') as payload_id, SYS_GUID(), PRMT_IDENT, key_hash, '0' as data_hash
         FROM ics_subm_results
        WHERE result_code = 'MGP040'
          AND subm_type_name = 'MasterGeneralPermitSubmission'
          AND subm_transaction_id = p_transaction_id
          AND key_hash NOT IN (SELECT key_hash FROM ics_flow_icis.ICS_MASTER_GNRL_PRMT)
     GROUP BY PRMT_IDENT, key_hash;

  -- Add keys that already exist in ICIS for module ICS_PRMT_FEATR
  INSERT INTO ics_flow_icis.ICS_PRMT_FEATR (ics_payload_id, ICS_PRMT_FEATR_ID, PRMT_IDENT, PRMT_FEATR_IDENT, key_hash, data_hash)
       SELECT (SELECT ics_payload_id FROM ics_payload WHERE operation='PermittedFeatureSubmission') as payload_id, SYS_GUID(), PRMT_IDENT, PRMT_FEATR_IDENT, key_hash, '0' as data_hash
         FROM ics_subm_results
        WHERE result_code = 'PF030'
          AND subm_type_name = 'PermittedFeatureSubmission'
          AND subm_transaction_id = p_transaction_id
          AND key_hash NOT IN (SELECT key_hash FROM ics_flow_icis.ICS_PRMT_FEATR)
     GROUP BY PRMT_IDENT, PRMT_FEATR_IDENT, key_hash;

  -- Add keys that already exist in ICIS for module ICS_PRMT_TRACK_EVT
  INSERT INTO ics_flow_icis.ICS_PRMT_TRACK_EVT (ics_payload_id, ICS_PRMT_TRACK_EVT_ID, PRMT_IDENT, PRMT_TRACK_EVT_CODE, PRMT_TRACK_EVT_DATE, key_hash, data_hash)
       SELECT (SELECT ics_payload_id FROM ics_payload WHERE operation='PermitTrackingEventSubmission') as payload_id, SYS_GUID(), PRMT_IDENT, PRMT_TRACK_EVT_CODE, PRMT_TRACK_EVT_DATE, key_hash, '0' as data_hash
         FROM ics_subm_results
        WHERE result_code = 'PTE030'
          AND subm_type_name = 'PermitTrackingEventSubmission'
          AND subm_transaction_id = p_transaction_id
          AND key_hash NOT IN (SELECT key_hash FROM ics_flow_icis.ICS_PRMT_TRACK_EVT)
     GROUP BY PRMT_IDENT, PRMT_TRACK_EVT_CODE, PRMT_TRACK_EVT_DATE, key_hash;

  -- Add keys that already exist in ICIS for module ICS_POTW_PRMT
  INSERT INTO ics_flow_icis.ICS_POTW_PRMT (ics_payload_id, ICS_POTW_PRMT_ID, PRMT_IDENT, key_hash, data_hash)
       SELECT (SELECT ics_payload_id FROM ics_payload WHERE operation='POTWPermitSubmission') as payload_id, SYS_GUID(), PRMT_IDENT, key_hash, '0' as data_hash
         FROM ics_subm_results
        WHERE result_code = 'PC040'
          AND subm_type_name = 'POTWPermitSubmission'
          AND subm_transaction_id = p_transaction_id
          AND key_hash NOT IN (SELECT key_hash FROM ics_flow_icis.ICS_POTW_PRMT)
     GROUP BY PRMT_IDENT, key_hash;

  -- Add keys that already exist in ICIS for module ICS_PRETR_PRMT
  INSERT INTO ics_flow_icis.ICS_PRETR_PRMT (ics_payload_id, ICS_PRETR_PRMT_ID, PRMT_IDENT, key_hash, data_hash)
       SELECT (SELECT ics_payload_id FROM ics_payload WHERE operation='PretreatmentPermitSubmission') as payload_id, SYS_GUID(), PRMT_IDENT, key_hash, '0' as data_hash
         FROM ics_subm_results
        WHERE result_code = 'PC040'
          AND subm_type_name = 'PretreatmentPermitSubmission'
          AND subm_transaction_id = p_transaction_id
          AND key_hash NOT IN (SELECT key_hash FROM ics_flow_icis.ICS_PRETR_PRMT)
     GROUP BY PRMT_IDENT, key_hash;

  -- Add keys that already exist in ICIS for module ICS_SNGL_EVT_VIOL
  INSERT INTO ics_flow_icis.ICS_SNGL_EVT_VIOL (ics_payload_id, ICS_SNGL_EVT_VIOL_ID, PRMT_IDENT, SNGL_EVT_VIOL_CODE, SNGL_EVT_VIOL_DATE, key_hash, data_hash)
       SELECT (SELECT ics_payload_id FROM ics_payload WHERE operation='SingleEventViolationSubmission') as payload_id, SYS_GUID(), PRMT_IDENT, SNGL_EVT_VIOL_CODE, SNGL_EVT_VIOL_DATE, key_hash, '0' as data_hash
         FROM ics_subm_results
        WHERE result_code = 'SEV030'
          AND subm_type_name = 'SingleEventViolationSubmission'
          AND subm_transaction_id = p_transaction_id
          AND key_hash NOT IN (SELECT key_hash FROM ics_flow_icis.ICS_SNGL_EVT_VIOL)
     GROUP BY PRMT_IDENT, SNGL_EVT_VIOL_CODE, SNGL_EVT_VIOL_DATE, key_hash;

  -- Add keys that already exist in ICIS for module ICS_SW_CNST_PRMT
  INSERT INTO ics_flow_icis.ICS_SW_CNST_PRMT (ics_payload_id, ICS_SW_CNST_PRMT_ID, PRMT_IDENT, key_hash, data_hash)
       SELECT (SELECT ics_payload_id FROM ics_payload WHERE operation='SWConstructionPermitSubmission') as payload_id, SYS_GUID(), PRMT_IDENT, key_hash, '0' as data_hash
         FROM ics_subm_results
        WHERE result_code = 'PC040'
          AND subm_type_name = 'SWConstructionPermitSubmission'
          AND subm_transaction_id = p_transaction_id
          AND key_hash NOT IN (SELECT key_hash FROM ics_flow_icis.ICS_SW_CNST_PRMT)
     GROUP BY PRMT_IDENT, key_hash;

  -- Add keys that already exist in ICIS for module ICS_SW_INDST_PRMT
  INSERT INTO ics_flow_icis.ICS_SW_INDST_PRMT (ics_payload_id, ICS_SW_INDST_PRMT_ID, PRMT_IDENT, key_hash, data_hash)
       SELECT (SELECT ics_payload_id FROM ics_payload WHERE operation='SWIndustrialPermitSubmission') as payload_id, SYS_GUID(), PRMT_IDENT, key_hash, '0' as data_hash
         FROM ics_subm_results
        WHERE result_code = 'PC040'
          AND subm_type_name = 'SWIndustrialPermitSubmission'
          AND subm_transaction_id = p_transaction_id
          AND key_hash NOT IN (SELECT key_hash FROM ics_flow_icis.ICS_SW_INDST_PRMT)
     GROUP BY PRMT_IDENT, key_hash;

  -- Add keys that already exist in ICIS for module ICS_UNPRMT_FAC
  INSERT INTO ics_flow_icis.ICS_UNPRMT_FAC (ics_payload_id, ICS_UNPRMT_FAC_ID, PRMT_IDENT, key_hash, data_hash)
       SELECT (SELECT ics_payload_id FROM ics_payload WHERE operation='UnpermittedFacilitySubmission') as payload_id, SYS_GUID(), PRMT_IDENT, key_hash, '0' as data_hash
         FROM ics_subm_results
        WHERE result_code = 'UPF060'
          AND subm_type_name = 'UnpermittedFacilitySubmission'
          AND subm_transaction_id = p_transaction_id
          AND key_hash NOT IN (SELECT key_hash FROM ics_flow_icis.ICS_UNPRMT_FAC)
     GROUP BY PRMT_IDENT, key_hash;
	 

/*
INSERT INTO ics_subm_hist (
       ics_subm_hist_id
     , subm_date_time
     , subm_transaction_id
     , subm_type_name
     , trans_count_new
     , trans_count_chng_repl
     , trans_count_del_mass_del
     , error_count
     , warning_count
     , accepted_count
     , accepted_count_total
     , created_date_time)
SELECT SYS_GUID() AS ics_subm_hist_id
     , (SELECT subm_date_time FROM ics_subm_track WHERE subm_transaction_id = p_transaction_id) as subm_date_time
     , p_transaction_id 
     , operation
     , NVL(trans_count_new, 0)
     , NVL(trans_count_chng_repl, 0)
     , NVL(trans_count_del_mass_del, 0)
     , error_count
     , warning_count
     , accepted_count
     , NVL(accepted_count_total, 0)
     , SYSDATE AS created_date_time
  FROM ics_v_module_count;
 */ 
  
  COMMIT;

EXCEPTION
WHEN OTHERS THEN
    rollback;
    raise;
END;
/	 


declare
userexist integer;
begin
  select count(*) into userexist from dba_users where username='ICS_FLOW_LOCAL_USER';
  if (userexist > 0) then
    execute immediate 'GRANT EXECUTE ON ICS_FLOW_LOCAL.ICS_PROCESS_ACCEPTED_TRANS TO ICS_FLOW_LOCAL_USER';
  end if;
end;
/

