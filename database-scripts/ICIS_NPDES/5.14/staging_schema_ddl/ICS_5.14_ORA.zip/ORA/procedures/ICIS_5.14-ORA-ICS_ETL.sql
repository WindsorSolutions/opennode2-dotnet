CREATE OR REPLACE PROCEDURE ICS_FLOW_LOCAL.ICS_ETL
AS
/*
Copyright (c) 2012, The Environmental Council of the States (ECOS)
All rights reserved.
 
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
 
 * Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
 * Neither the name of the ECOS nor the names of its contributors may
   be used to endorse or promote products derived from this software
   without specific prior written permission.
 
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*//******************************************************************************************************************************
** ProcedureName: ICS_ETL
**
** Description:  This procedure has been developed to extract, transform, and load date from a source information system into
**               a set of LOCAL ICIS staging tables.
**
** Revision History:      
** ----------------------------------------------------------------------------------------------------------------------------
**  Date         Name           Description
** ----------------------------------------------------------------------------------------------------------------------------
** 2025-05-20    CRT (Windsor)    from 5.8 version
**
******************************************************************************************************************************/
BEGIN 

  /*
   *  ETL ICIS DATA
   *  Run the ETL procedures here
   */
   FOR select_rec IN (SELECT 'ADD ICIS EXTRACT LOGIC HERE' FROM DUAL) LOOP
                        
     NULL;

   END LOOP;
   
END ICS_ETL;
/