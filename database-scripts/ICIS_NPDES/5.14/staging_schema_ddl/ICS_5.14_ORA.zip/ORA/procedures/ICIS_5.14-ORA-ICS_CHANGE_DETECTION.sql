CREATE OR REPLACE PROCEDURE ICS_CHANGE_DETECTION 
AS
/*
Copyright (c) 2012, The Environmental Council of the States (ECOS)
All rights reserved.
 
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
 
 * Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
 * Neither the name of the ECOS nor the names of its contributors may
   be used to endorse or promote products derived from this software
   without specific prior written permission.
 
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/

/******************************************************************************************************************************
** ObjectName: ICS_CHANGE_DETECTION
**
** Author: Windsor Solutions, Inc.
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This procedure will detect data changes made within the ICIS schema and then sets the transaction type
**               flags so the data can be bundled and submitted to an exchange partner.
**
** Inputs:  -- NA --  
**
**
** Revision History:      
** ----------------------------------------------------------------------------------------------------------------------------
**  Date         Analyst     Description
** ----------------------------------------------------------------------------------------------------------------------------
** 04/15/2025  CTyler      Rewrite for ICISv5.14 (based on 5.8) 
** 07/03/2025  WRensmith    Bypass auto-gen deletes if no rows are present in the local staging table (NCORE-6649) - CRT translated from ES version
** 07/03/2025  WRensmith    Clear out transaction codes for basic and general permits that are being reissued same day but with prior effective date - CRT translated from ES version
** 04/20/2025  CTyler      Restructured to use optimized ICS_SET_HASHES procedure
** 05/14/2026  CTyler   SingleEventViolation use X not D for delete
**
******************************************************************************************************************************/
  v_sql_statement VARCHAR2(4000);
  v_all_data_hashes VARCHAR2(4000);  
  v_hashed_data_hashes VARCHAR2(32);
  v_ics_cmpl_mon_lnk_id ics_cmpl_mon_lnk.ics_cmpl_mon_lnk_id%TYPE;
  -- v_ics_dmr_prog_rep_lnk_id ics_dmr_prog_rep_lnk.ics_dmr_prog_rep_lnk_id%TYPE;  
  v_ics_enfrc_actn_viol_lnk_id ics_enfrc_actn_viol_lnk.ics_enfrc_actn_viol_lnk_id%TYPE; 
  v_ics_final_order_viol_lnk_id ics_final_order_viol_lnk.ics_final_order_viol_lnk_id%TYPE; 
  v_enabled char(1);
  v_working_data_hash VARCHAR2(4000);
  v_payload_count NUMBER;
  

BEGIN


  --  Initial check to ensure FOR LOOP processing is working 
  --  as expected.  If not, exit and determine why.  Most likely
  --  a read to the ALL_CONSTRAINTS will be required, versus reads
  --  to the USER_CONSTRAINTS view.
  BEGIN
     
     SELECT count(1) 
       INTO v_payload_count
       FROM user_constraints child
       LEFT JOIN user_constraints parent
         ON child.r_constraint_name = parent.constraint_name
      WHERE child.constraint_type = 'R'
        AND parent.table_name = 'ICS_PAYLOAD'                           
      ORDER BY child.table_name;
    
    
---------------------------------------------------------------------------                        
--  ORA-20101: No child tables to ICS_PAYLOAD, check metatdata views!!   --
--  Utilize this SQL Statement instead of the SQL above.                 --
---------------------------------------------------------------------------    
--      SELECT count(1) 
--       INTO v_payload_count
--       FROM all_constraints child
--       LEFT JOIN all_constraints parent
--         ON child.r_constraint_name = parent.constraint_name
--      WHERE child.constraint_type = 'R'
--        AND parent.table_name = 'ICS_PAYLOAD'
--        AND parent.owner = 'ICS_FLOW_LOCAL'
--        AND child.owner = 'ICS_FLOW_LOCAL'
--      ORDER BY child.table_name;
    
    
     IF v_payload_count = 0 THEN
        RAISE_APPLICATION_ERROR (-20101, 'No child tables to ICS_PAYLOAD, check metatdata views!!');
     END IF;
  END;


  /*  Initialize working table ICS_KEY_HASH */
  DELETE FROM ics_key_hash;

  /*  Initialize working table ICS_DATA_HASH */
  DELETE FROM ics_data_hash;
  
  /*  
   * Reset transaction_type on all payload tables  
   */
  FOR payload_type IN (SELECT DISTINCT 
                              child.table_name
                         FROM user_constraints child
                         LEFT JOIN user_constraints parent
                           ON child.r_constraint_name = parent.constraint_name
                        WHERE child.constraint_type = 'R'
                          AND parent.table_name = 'ICS_PAYLOAD'                           
                        ORDER BY child.table_name) LOOP
                        
---------------------------------------------------------------------------                        
--  ORA-20101: No child tables to ICS_PAYLOAD, check metatdata views!!   --
--  Utilize this FOR LOOP instead of the loop above.                     --
---------------------------------------------------------------------------                        
--  FOR payload_type IN (SELECT DISTINCT child.table_name
--                         FROM all_constraints child
--                         LEFT JOIN all_constraints parent
--                           ON child.r_constraint_name = parent.constraint_name
--                        WHERE child.constraint_type = 'R'
--                          AND parent.table_name = 'ICS_PAYLOAD'    
--                          AND parent.owner = 'ICS_FLOW_LOCAL'
--                          AND child.owner = 'ICS_FLOW_LOCAL'
--                        ORDER BY child.table_name) LOOP
       
    /* For each payload type, remove all the transaction codes from the previous run. */
    v_sql_statement := 'UPDATE ' || payload_type.table_name || ' SET TRANSACTION_TYPE = NULL , TRANSACTION_TIMESTAMP = NULL';
    EXECUTE IMMEDIATE v_sql_statement;
  
  END LOOP module_loop;
  
 /*********************************************/  
 /* Set HASHES on TABLES enabled in ICS_PAYLOAD */
 /*********************************************/   
 ICS_SET_HASHES;


  /******************************************************************************************************************************
  ** Description:  The following code sets the new, change, replace, etc... ics transaction_type flags throughout the entire ICS 
  **               schema.  Once these flags are set the data will be marked as either new, changed and will allow the OPENNODE2 
  **               plug-in the ability to pull the data, bundle into .xml, and then submit to an exchange partner.
  ******************************************************************************************************************************/

-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_BASIC_PRMT
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.ICS_BASIC_PRMT 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'BasicPermitSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.ICS_BASIC_PRMT icis where icis.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH AND icis.DATA_HASH != ICS_BASIC_PRMT.DATA_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.ICS_BASIC_PRMT 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'BasicPermitSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.ICS_BASIC_PRMT icis where icis.KEY_HASH = ICS_BASIC_PRMT.KEY_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_BS_ANNUL_PROG_REP
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.ICS_BS_ANNUL_PROG_REP 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'BiosolidsAnnualProgramReportSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.ICS_BS_ANNUL_PROG_REP icis where icis.KEY_HASH = ICS_BS_ANNUL_PROG_REP.KEY_HASH AND icis.DATA_HASH != ICS_BS_ANNUL_PROG_REP.DATA_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.ICS_BS_ANNUL_PROG_REP 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'BiosolidsAnnualProgramReportSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.ICS_BS_ANNUL_PROG_REP icis where icis.KEY_HASH = ICS_BS_ANNUL_PROG_REP.KEY_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_BS_PRMT
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.ICS_BS_PRMT 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'BiosolidsPermitSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.ICS_BS_PRMT icis where icis.KEY_HASH = ICS_BS_PRMT.KEY_HASH AND icis.DATA_HASH != ICS_BS_PRMT.DATA_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.ICS_BS_PRMT 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'BiosolidsPermitSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.ICS_BS_PRMT icis where icis.KEY_HASH = ICS_BS_PRMT.KEY_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_CAFO_ANNUL_PROG_REP
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.ICS_CAFO_ANNUL_PROG_REP 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'CAFOAnnualProgramReportSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.ICS_CAFO_ANNUL_PROG_REP icis where icis.KEY_HASH = ICS_CAFO_ANNUL_PROG_REP.KEY_HASH AND icis.DATA_HASH != ICS_CAFO_ANNUL_PROG_REP.DATA_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.ICS_CAFO_ANNUL_PROG_REP 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'CAFOAnnualProgramReportSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.ICS_CAFO_ANNUL_PROG_REP icis where icis.KEY_HASH = ICS_CAFO_ANNUL_PROG_REP.KEY_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_CAFO_PRMT
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.ICS_CAFO_PRMT 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'CAFOPermitSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.ICS_CAFO_PRMT icis where icis.KEY_HASH = ICS_CAFO_PRMT.KEY_HASH AND icis.DATA_HASH != ICS_CAFO_PRMT.DATA_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.ICS_CAFO_PRMT 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'CAFOPermitSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.ICS_CAFO_PRMT icis where icis.KEY_HASH = ICS_CAFO_PRMT.KEY_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_COLL_SYSTM_PRMT
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.ICS_COLL_SYSTM_PRMT 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'CollectionSystemPermitSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.ICS_COLL_SYSTM_PRMT icis where icis.KEY_HASH = ICS_COLL_SYSTM_PRMT.KEY_HASH AND icis.DATA_HASH != ICS_COLL_SYSTM_PRMT.DATA_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.ICS_COLL_SYSTM_PRMT 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'CollectionSystemPermitSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.ICS_COLL_SYSTM_PRMT icis where icis.KEY_HASH = ICS_COLL_SYSTM_PRMT.KEY_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_CMPL_MON
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.ICS_CMPL_MON 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'ComplianceMonitoringSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.ICS_CMPL_MON icis where icis.KEY_HASH = ICS_CMPL_MON.KEY_HASH AND icis.DATA_HASH != ICS_CMPL_MON.DATA_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.ICS_CMPL_MON 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'ComplianceMonitoringSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.ICS_CMPL_MON icis where icis.KEY_HASH = ICS_CMPL_MON.KEY_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_CMPL_MON_LNK
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.ICS_CMPL_MON_LNK 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'ComplianceMonitoringLinkageSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.ICS_CMPL_MON_LNK icis where icis.KEY_HASH = ICS_CMPL_MON_LNK.KEY_HASH AND icis.DATA_HASH != ICS_CMPL_MON_LNK.DATA_HASH);

-- -- Change/Replace
-- update ICS_FLOW_LOCAL.ICS_CMPL_MON_LNK 
-- set TRANSACTION_TYPE = 'R' WHERE
-- 	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'ComplianceMonitoringLinkageSubmission')
-- 	AND exists (SELECT 1 from ICS_FLOW_ICIS.ICS_CMPL_MON_LNK icis where icis.KEY_HASH = ICS_CMPL_MON_LNK.KEY_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_CMPL_SCHD
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.ICS_CMPL_SCHD 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'ComplianceScheduleSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.ICS_CMPL_SCHD icis where icis.KEY_HASH = ICS_CMPL_SCHD.KEY_HASH AND icis.DATA_HASH != ICS_CMPL_SCHD.DATA_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.ICS_CMPL_SCHD 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'ComplianceScheduleSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.ICS_CMPL_SCHD icis where icis.KEY_HASH = ICS_CMPL_SCHD.KEY_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_COPY_MGP_LMT_SET
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.ICS_COPY_MGP_LMT_SET 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'CopyMGPLimitSetSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.ICS_COPY_MGP_LMT_SET icis where icis.KEY_HASH = ICS_COPY_MGP_LMT_SET.KEY_HASH AND icis.DATA_HASH != ICS_COPY_MGP_LMT_SET.DATA_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.ICS_COPY_MGP_LMT_SET 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'CopyMGPLimitSetSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.ICS_COPY_MGP_LMT_SET icis where icis.KEY_HASH = ICS_COPY_MGP_LMT_SET.KEY_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_COPY_MGPMS_4_REQ
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.ICS_COPY_MGPMS_4_REQ 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'CopyMGPMS4RequirementSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.ICS_COPY_MGPMS_4_REQ icis where icis.KEY_HASH = ICS_COPY_MGPMS_4_REQ.KEY_HASH AND icis.DATA_HASH != ICS_COPY_MGPMS_4_REQ.DATA_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.ICS_COPY_MGPMS_4_REQ 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'CopyMGPMS4RequirementSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.ICS_COPY_MGPMS_4_REQ icis where icis.KEY_HASH = ICS_COPY_MGPMS_4_REQ.KEY_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_CSO_LONG_TERM_CONTROL_PLAN
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.ICS_CSO_LONG_TERM_CONTROL_PLAN 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'CSOLongTermControlPlanSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.ICS_CSO_LONG_TERM_CONTROL_PLAN icis where icis.KEY_HASH = ICS_CSO_LONG_TERM_CONTROL_PLAN.KEY_HASH AND icis.DATA_HASH != ICS_CSO_LONG_TERM_CONTROL_PLAN.DATA_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.ICS_CSO_LONG_TERM_CONTROL_PLAN 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'CSOLongTermControlPlanSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.ICS_CSO_LONG_TERM_CONTROL_PLAN icis where icis.KEY_HASH = ICS_CSO_LONG_TERM_CONTROL_PLAN.KEY_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_CWA_316B_PROG_REP
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.ICS_CWA_316B_PROG_REP 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'CWA316bProgramReportSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.ICS_CWA_316B_PROG_REP icis where icis.KEY_HASH = ICS_CWA_316B_PROG_REP.KEY_HASH AND icis.DATA_HASH != ICS_CWA_316B_PROG_REP.DATA_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.ICS_CWA_316B_PROG_REP 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'CWA316bProgramReportSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.ICS_CWA_316B_PROG_REP icis where icis.KEY_HASH = ICS_CWA_316B_PROG_REP.KEY_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_DSCH_MON_REP
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.ICS_DSCH_MON_REP 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'DischargeMonitoringReportSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.ICS_DSCH_MON_REP icis where icis.KEY_HASH = ICS_DSCH_MON_REP.KEY_HASH AND icis.DATA_HASH != ICS_DSCH_MON_REP.DATA_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.ICS_DSCH_MON_REP 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'DischargeMonitoringReportSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.ICS_DSCH_MON_REP icis where icis.KEY_HASH = ICS_DSCH_MON_REP.KEY_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_DMR_VIOL
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.ICS_DMR_VIOL 
set TRANSACTION_TYPE = 'C' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'DMRViolationSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.ICS_DMR_VIOL icis where icis.KEY_HASH = ICS_DMR_VIOL.KEY_HASH AND icis.DATA_HASH != ICS_DMR_VIOL.DATA_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.ICS_DMR_VIOL 
set TRANSACTION_TYPE = 'C' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'DMRViolationSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.ICS_DMR_VIOL icis where icis.KEY_HASH = ICS_DMR_VIOL.KEY_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_EFFLU_TRADE_PRTNER
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.ICS_EFFLU_TRADE_PRTNER 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'EffluentTradePartnerSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.ICS_EFFLU_TRADE_PRTNER icis where icis.KEY_HASH = ICS_EFFLU_TRADE_PRTNER.KEY_HASH AND icis.DATA_HASH != ICS_EFFLU_TRADE_PRTNER.DATA_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.ICS_EFFLU_TRADE_PRTNER 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'EffluentTradePartnerSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.ICS_EFFLU_TRADE_PRTNER icis where icis.KEY_HASH = ICS_EFFLU_TRADE_PRTNER.KEY_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_ENFRC_ACTN_MILESTONE
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.ICS_ENFRC_ACTN_MILESTONE 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'EnforcementActionMilestoneSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.ICS_ENFRC_ACTN_MILESTONE icis where icis.KEY_HASH = ICS_ENFRC_ACTN_MILESTONE.KEY_HASH AND icis.DATA_HASH != ICS_ENFRC_ACTN_MILESTONE.DATA_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.ICS_ENFRC_ACTN_MILESTONE 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'EnforcementActionMilestoneSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.ICS_ENFRC_ACTN_MILESTONE icis where icis.KEY_HASH = ICS_ENFRC_ACTN_MILESTONE.KEY_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_ENFRC_ACTN_VIOL_LNK
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.ICS_ENFRC_ACTN_VIOL_LNK 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'EnforcementActionViolationLinkageSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.ICS_ENFRC_ACTN_VIOL_LNK icis where icis.KEY_HASH = ICS_ENFRC_ACTN_VIOL_LNK.KEY_HASH AND icis.DATA_HASH != ICS_ENFRC_ACTN_VIOL_LNK.DATA_HASH);

-- -- Change/Replace
-- update ICS_FLOW_LOCAL.ICS_ENFRC_ACTN_VIOL_LNK 
-- set TRANSACTION_TYPE = 'R' WHERE
-- 	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'EnforcementActionViolationLinkageSubmission')
-- 	AND exists (SELECT 1 from ICS_FLOW_ICIS.ICS_ENFRC_ACTN_VIOL_LNK icis where icis.KEY_HASH = ICS_ENFRC_ACTN_VIOL_LNK.KEY_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_FINAL_ORDER_VIOL_LNK
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.ICS_FINAL_ORDER_VIOL_LNK 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'FinalOrderViolationLinkageSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.ICS_FINAL_ORDER_VIOL_LNK icis where icis.KEY_HASH = ICS_FINAL_ORDER_VIOL_LNK.KEY_HASH AND icis.DATA_HASH != ICS_FINAL_ORDER_VIOL_LNK.DATA_HASH);

-- -- Change/Replace
-- update ICS_FLOW_LOCAL.ICS_FINAL_ORDER_VIOL_LNK 
-- set TRANSACTION_TYPE = 'R' WHERE
-- 	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'FinalOrderViolationLinkageSubmission')
-- 	AND exists (SELECT 1 from ICS_FLOW_ICIS.ICS_FINAL_ORDER_VIOL_LNK icis where icis.KEY_HASH = ICS_FINAL_ORDER_VIOL_LNK.KEY_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_FRML_ENFRC_ACTN
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.ICS_FRML_ENFRC_ACTN 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'FormalEnforcementActionSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.ICS_FRML_ENFRC_ACTN icis where icis.KEY_HASH = ICS_FRML_ENFRC_ACTN.KEY_HASH AND icis.DATA_HASH != ICS_FRML_ENFRC_ACTN.DATA_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.ICS_FRML_ENFRC_ACTN 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'FormalEnforcementActionSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.ICS_FRML_ENFRC_ACTN icis where icis.KEY_HASH = ICS_FRML_ENFRC_ACTN.KEY_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_GNRL_PRMT
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.ICS_GNRL_PRMT 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'GeneralPermitSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.ICS_GNRL_PRMT icis where icis.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH AND icis.DATA_HASH != ICS_GNRL_PRMT.DATA_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.ICS_GNRL_PRMT 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'GeneralPermitSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.ICS_GNRL_PRMT icis where icis.KEY_HASH = ICS_GNRL_PRMT.KEY_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_HIST_PRMT_SCHD_EVTS
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.ICS_HIST_PRMT_SCHD_EVTS 
set TRANSACTION_TYPE = 'C' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'HistoricalPermitScheduleEventsSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.ICS_HIST_PRMT_SCHD_EVTS icis where icis.KEY_HASH = ICS_HIST_PRMT_SCHD_EVTS.KEY_HASH AND icis.DATA_HASH != ICS_HIST_PRMT_SCHD_EVTS.DATA_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.ICS_HIST_PRMT_SCHD_EVTS 
set TRANSACTION_TYPE = 'C' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'HistoricalPermitScheduleEventsSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.ICS_HIST_PRMT_SCHD_EVTS icis where icis.KEY_HASH = ICS_HIST_PRMT_SCHD_EVTS.KEY_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_INFRML_ENFRC_ACTN
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.ICS_INFRML_ENFRC_ACTN 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'InformalEnforcementActionSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.ICS_INFRML_ENFRC_ACTN icis where icis.KEY_HASH = ICS_INFRML_ENFRC_ACTN.KEY_HASH AND icis.DATA_HASH != ICS_INFRML_ENFRC_ACTN.DATA_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.ICS_INFRML_ENFRC_ACTN 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'InformalEnforcementActionSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.ICS_INFRML_ENFRC_ACTN icis where icis.KEY_HASH = ICS_INFRML_ENFRC_ACTN.KEY_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_LMTS
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.ICS_LMTS 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'LimitsSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.ICS_LMTS icis where icis.KEY_HASH = ICS_LMTS.KEY_HASH AND icis.DATA_HASH != ICS_LMTS.DATA_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.ICS_LMTS 
set TRANSACTION_TYPE = 'C' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'LimitsSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.ICS_LMTS icis where icis.KEY_HASH = ICS_LMTS.KEY_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_LMT_SET
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.ICS_LMT_SET 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'LimitSetSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.ICS_LMT_SET icis where icis.KEY_HASH = ICS_LMT_SET.KEY_HASH AND icis.DATA_HASH != ICS_LMT_SET.DATA_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.ICS_LMT_SET 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'LimitSetSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.ICS_LMT_SET icis where icis.KEY_HASH = ICS_LMT_SET.KEY_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_MASTER_GNRL_PRMT
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.ICS_MASTER_GNRL_PRMT 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'MasterGeneralPermitSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.ICS_MASTER_GNRL_PRMT icis where icis.KEY_HASH = ICS_MASTER_GNRL_PRMT.KEY_HASH AND icis.DATA_HASH != ICS_MASTER_GNRL_PRMT.DATA_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.ICS_MASTER_GNRL_PRMT 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'MasterGeneralPermitSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.ICS_MASTER_GNRL_PRMT icis where icis.KEY_HASH = ICS_MASTER_GNRL_PRMT.KEY_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_NARR_COND_SCHD
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.ICS_NARR_COND_SCHD 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'NarrativeConditionScheduleSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.ICS_NARR_COND_SCHD icis where icis.KEY_HASH = ICS_NARR_COND_SCHD.KEY_HASH AND icis.DATA_HASH != ICS_NARR_COND_SCHD.DATA_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.ICS_NARR_COND_SCHD 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'NarrativeConditionScheduleSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.ICS_NARR_COND_SCHD icis where icis.KEY_HASH = ICS_NARR_COND_SCHD.KEY_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_NPDES_VARIANCE_PRMT
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.ICS_NPDES_VARIANCE_PRMT 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'NPDESVariancePermitSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.ICS_NPDES_VARIANCE_PRMT icis where icis.KEY_HASH = ICS_NPDES_VARIANCE_PRMT.KEY_HASH AND icis.DATA_HASH != ICS_NPDES_VARIANCE_PRMT.DATA_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.ICS_NPDES_VARIANCE_PRMT 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'NPDESVariancePermitSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.ICS_NPDES_VARIANCE_PRMT icis where icis.KEY_HASH = ICS_NPDES_VARIANCE_PRMT.KEY_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_PARAM_LMTS
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.ICS_PARAM_LMTS 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'ParameterLimitsSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.ICS_PARAM_LMTS icis where icis.KEY_HASH = ICS_PARAM_LMTS.KEY_HASH AND icis.DATA_HASH != ICS_PARAM_LMTS.DATA_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.ICS_PARAM_LMTS 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'ParameterLimitsSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.ICS_PARAM_LMTS icis where icis.KEY_HASH = ICS_PARAM_LMTS.KEY_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_PRMT_REISSU
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.ICS_PRMT_REISSU 
set TRANSACTION_TYPE = 'C' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'PermitReissuanceSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.ICS_PRMT_REISSU icis where icis.KEY_HASH = ICS_PRMT_REISSU.KEY_HASH AND icis.DATA_HASH != ICS_PRMT_REISSU.DATA_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.ICS_PRMT_REISSU 
set TRANSACTION_TYPE = 'C' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'PermitReissuanceSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.ICS_PRMT_REISSU icis where icis.KEY_HASH = ICS_PRMT_REISSU.KEY_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_PRMT_FEATR
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.ICS_PRMT_FEATR 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'PermittedFeatureSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.ICS_PRMT_FEATR icis where icis.KEY_HASH = ICS_PRMT_FEATR.KEY_HASH AND icis.DATA_HASH != ICS_PRMT_FEATR.DATA_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.ICS_PRMT_FEATR 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'PermittedFeatureSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.ICS_PRMT_FEATR icis where icis.KEY_HASH = ICS_PRMT_FEATR.KEY_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_PRMT_TERM
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.ICS_PRMT_TERM 
set TRANSACTION_TYPE = 'C' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'PermitTerminationSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.ICS_PRMT_TERM icis where icis.KEY_HASH = ICS_PRMT_TERM.KEY_HASH AND icis.DATA_HASH != ICS_PRMT_TERM.DATA_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.ICS_PRMT_TERM 
set TRANSACTION_TYPE = 'C' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'PermitTerminationSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.ICS_PRMT_TERM icis where icis.KEY_HASH = ICS_PRMT_TERM.KEY_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_PRMT_TRACK_EVT
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.ICS_PRMT_TRACK_EVT 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'PermitTrackingEventSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.ICS_PRMT_TRACK_EVT icis where icis.KEY_HASH = ICS_PRMT_TRACK_EVT.KEY_HASH AND icis.DATA_HASH != ICS_PRMT_TRACK_EVT.DATA_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.ICS_PRMT_TRACK_EVT 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'PermitTrackingEventSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.ICS_PRMT_TRACK_EVT icis where icis.KEY_HASH = ICS_PRMT_TRACK_EVT.KEY_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_POTW_PRMT
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.ICS_POTW_PRMT 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'POTWPermitSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.ICS_POTW_PRMT icis where icis.KEY_HASH = ICS_POTW_PRMT.KEY_HASH AND icis.DATA_HASH != ICS_POTW_PRMT.DATA_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.ICS_POTW_PRMT 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'POTWPermitSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.ICS_POTW_PRMT icis where icis.KEY_HASH = ICS_POTW_PRMT.KEY_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_POTW_TRTMNT_TECHNOLOGY_PRMT
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'POTWTreatmentTechnologyPermitSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT icis where icis.KEY_HASH = ICS_POTW_TRTMNT_TECHNOLOGY_PRMT.KEY_HASH AND icis.DATA_HASH != ICS_POTW_TRTMNT_TECHNOLOGY_PRMT.DATA_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'POTWTreatmentTechnologyPermitSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT icis where icis.KEY_HASH = ICS_POTW_TRTMNT_TECHNOLOGY_PRMT.KEY_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_PRETR_PRMT
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.ICS_PRETR_PRMT 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'PretreatmentPermitSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.ICS_PRETR_PRMT icis where icis.KEY_HASH = ICS_PRETR_PRMT.KEY_HASH AND icis.DATA_HASH != ICS_PRETR_PRMT.DATA_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.ICS_PRETR_PRMT 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'PretreatmentPermitSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.ICS_PRETR_PRMT icis where icis.KEY_HASH = ICS_PRETR_PRMT.KEY_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_PRETR_PROG_REP
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.ICS_PRETR_PROG_REP 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'PretreatmentProgramReportSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.ICS_PRETR_PROG_REP icis where icis.KEY_HASH = ICS_PRETR_PROG_REP.KEY_HASH AND icis.DATA_HASH != ICS_PRETR_PROG_REP.DATA_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.ICS_PRETR_PROG_REP 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'PretreatmentProgramReportSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.ICS_PRETR_PROG_REP icis where icis.KEY_HASH = ICS_PRETR_PROG_REP.KEY_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_SCHD_EVT_VIOL
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.ICS_SCHD_EVT_VIOL 
set TRANSACTION_TYPE = 'C' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'ScheduleEventViolationSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.ICS_SCHD_EVT_VIOL icis where icis.KEY_HASH = ICS_SCHD_EVT_VIOL.KEY_HASH AND icis.DATA_HASH != ICS_SCHD_EVT_VIOL.DATA_HASH);

-- -- Change/Replace
-- update ICS_FLOW_LOCAL.ICS_SCHD_EVT_VIOL 
-- set TRANSACTION_TYPE = 'C' WHERE
-- 	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'ScheduleEventViolationSubmission')
-- 	AND exists (SELECT 1 from ICS_FLOW_ICIS.ICS_SCHD_EVT_VIOL icis where icis.KEY_HASH = ICS_SCHD_EVT_VIOL.KEY_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_SEWER_OVRFLW_BYPASS_EVT_REP
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.ICS_SEWER_OVRFLW_BYPASS_EVT_REP 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'SewerOverflowBypassEventReportSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.ICS_SEWER_OVRFLW_BYPASS_EVT_REP icis where icis.KEY_HASH = ICS_SEWER_OVRFLW_BYPASS_EVT_REP.KEY_HASH AND icis.DATA_HASH != ICS_SEWER_OVRFLW_BYPASS_EVT_REP.DATA_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.ICS_SEWER_OVRFLW_BYPASS_EVT_REP 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'SewerOverflowBypassEventReportSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.ICS_SEWER_OVRFLW_BYPASS_EVT_REP icis where icis.KEY_HASH = ICS_SEWER_OVRFLW_BYPASS_EVT_REP.KEY_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_SNGL_EVT_VIOL
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.ICS_SNGL_EVT_VIOL 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'SingleEventViolationSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.ICS_SNGL_EVT_VIOL icis where icis.KEY_HASH = ICS_SNGL_EVT_VIOL.KEY_HASH AND icis.DATA_HASH != ICS_SNGL_EVT_VIOL.DATA_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.ICS_SNGL_EVT_VIOL 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'SingleEventViolationSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.ICS_SNGL_EVT_VIOL icis where icis.KEY_HASH = ICS_SNGL_EVT_VIOL.KEY_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_SW_CNST_PRMT
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.ICS_SW_CNST_PRMT 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'SWConstructionPermitSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.ICS_SW_CNST_PRMT icis where icis.KEY_HASH = ICS_SW_CNST_PRMT.KEY_HASH AND icis.DATA_HASH != ICS_SW_CNST_PRMT.DATA_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.ICS_SW_CNST_PRMT 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'SWConstructionPermitSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.ICS_SW_CNST_PRMT icis where icis.KEY_HASH = ICS_SW_CNST_PRMT.KEY_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_SW_INDST_ANNUL_REP
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.ICS_SW_INDST_ANNUL_REP 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'SWIndustrialAnnualReportSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.ICS_SW_INDST_ANNUL_REP icis where icis.KEY_HASH = ICS_SW_INDST_ANNUL_REP.KEY_HASH AND icis.DATA_HASH != ICS_SW_INDST_ANNUL_REP.DATA_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.ICS_SW_INDST_ANNUL_REP 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'SWIndustrialAnnualReportSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.ICS_SW_INDST_ANNUL_REP icis where icis.KEY_HASH = ICS_SW_INDST_ANNUL_REP.KEY_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_SW_INDST_PRMT
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.ICS_SW_INDST_PRMT 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'SWIndustrialPermitSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.ICS_SW_INDST_PRMT icis where icis.KEY_HASH = ICS_SW_INDST_PRMT.KEY_HASH AND icis.DATA_HASH != ICS_SW_INDST_PRMT.DATA_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.ICS_SW_INDST_PRMT 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'SWIndustrialPermitSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.ICS_SW_INDST_PRMT icis where icis.KEY_HASH = ICS_SW_INDST_PRMT.KEY_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_SWMS_4_ANNUL_PROG_REP
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.ICS_SWMS_4_ANNUL_PROG_REP 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'SWMS4AnnualProgramReportSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.ICS_SWMS_4_ANNUL_PROG_REP icis where icis.KEY_HASH = ICS_SWMS_4_ANNUL_PROG_REP.KEY_HASH AND icis.DATA_HASH != ICS_SWMS_4_ANNUL_PROG_REP.DATA_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.ICS_SWMS_4_ANNUL_PROG_REP 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'SWMS4AnnualProgramReportSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.ICS_SWMS_4_ANNUL_PROG_REP icis where icis.KEY_HASH = ICS_SWMS_4_ANNUL_PROG_REP.KEY_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_SWMS_4_PRMT
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.ICS_SWMS_4_PRMT 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'SWMS4PermitSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.ICS_SWMS_4_PRMT icis where icis.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH AND icis.DATA_HASH != ICS_SWMS_4_PRMT.DATA_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.ICS_SWMS_4_PRMT 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'SWMS4PermitSubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.ICS_SWMS_4_PRMT icis where icis.KEY_HASH = ICS_SWMS_4_PRMT.KEY_HASH);


-- ----------------------------------------------------------------------------
-- Set Transactions New (N) and Changes for (R or C)
-- ICS_UNPRMT_FAC
-- ----------------------------------------------------------------------------
-- New
update ICS_FLOW_LOCAL.ICS_UNPRMT_FAC 
set TRANSACTION_TYPE = 'N' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'UnpermittedFacilitySubmission')
	AND not exists (SELECT 1 from ICS_FLOW_ICIS.ICS_UNPRMT_FAC icis where icis.KEY_HASH = ICS_UNPRMT_FAC.KEY_HASH AND icis.DATA_HASH != ICS_UNPRMT_FAC.DATA_HASH);

-- Change/Replace
update ICS_FLOW_LOCAL.ICS_UNPRMT_FAC 
set TRANSACTION_TYPE = 'R' WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND OPERATION = 'UnpermittedFacilitySubmission')
	AND exists (SELECT 1 from ICS_FLOW_ICIS.ICS_UNPRMT_FAC icis where icis.KEY_HASH = ICS_UNPRMT_FAC.KEY_HASH);

	

-- ----------------------------------------------------------------------------
-- Set Delete transactions when enabled
-- ----------------------------------------------------------------------------

-- ICS_BASIC_PRMT
-- ----------------------------------------------------------------------------
 INSERT INTO ICS_FLOW_LOCAL.ICS_BASIC_PRMT
       ( ICS_BASIC_PRMT_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT
       , key_hash
       , data_hash) 
   SELECT 
		SYS_GUID()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT
        , key_hash
        , data_hash
     FROM ics_flow_icis.ICS_BASIC_PRMT icis
WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'BasicPermitSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.ICS_BASIC_PRMT loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.ICS_BASIC_PRMT) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_BS_ANNUL_PROG_REP
-- ----------------------------------------------------------------------------
 INSERT INTO ICS_FLOW_LOCAL.ICS_BS_ANNUL_PROG_REP
       ( ICS_BS_ANNUL_PROG_REP_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT,PROG_REP_FORM_SET_ID,PROG_REP_FORM_ID
       , key_hash
       , data_hash) 
   SELECT 
		SYS_GUID()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT,PROG_REP_FORM_SET_ID,PROG_REP_FORM_ID
        , key_hash
        , data_hash
     FROM ics_flow_icis.ICS_BS_ANNUL_PROG_REP icis
WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'BiosolidsAnnualProgramReportSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.ICS_BS_ANNUL_PROG_REP loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.ICS_BS_ANNUL_PROG_REP) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_BS_PRMT
-- ----------------------------------------------------------------------------
 INSERT INTO ICS_FLOW_LOCAL.ICS_BS_PRMT
       ( ICS_BS_PRMT_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT
       , key_hash
       , data_hash) 
   SELECT 
		SYS_GUID()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT
        , key_hash
        , data_hash
     FROM ics_flow_icis.ICS_BS_PRMT icis
WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'BiosolidsPermitSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.ICS_BS_PRMT loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.ICS_BS_PRMT) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_CAFO_ANNUL_PROG_REP
-- ----------------------------------------------------------------------------
 INSERT INTO ICS_FLOW_LOCAL.ICS_CAFO_ANNUL_PROG_REP
       ( ICS_CAFO_ANNUL_PROG_REP_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT,PROG_REP_FORM_SET_ID,PROG_REP_FORM_ID
       , key_hash
       , data_hash) 
   SELECT 
		SYS_GUID()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT,PROG_REP_FORM_SET_ID,PROG_REP_FORM_ID
        , key_hash
        , data_hash
     FROM ics_flow_icis.ICS_CAFO_ANNUL_PROG_REP icis
WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'CAFOAnnualProgramReportSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.ICS_CAFO_ANNUL_PROG_REP loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.ICS_CAFO_ANNUL_PROG_REP) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_CAFO_PRMT
-- ----------------------------------------------------------------------------
 INSERT INTO ICS_FLOW_LOCAL.ICS_CAFO_PRMT
       ( ICS_CAFO_PRMT_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT
       , key_hash
       , data_hash) 
   SELECT 
		SYS_GUID()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT
        , key_hash
        , data_hash
     FROM ics_flow_icis.ICS_CAFO_PRMT icis
WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'CAFOPermitSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.ICS_CAFO_PRMT loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.ICS_CAFO_PRMT) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_COLL_SYSTM_PRMT
-- ----------------------------------------------------------------------------
 INSERT INTO ICS_FLOW_LOCAL.ICS_COLL_SYSTM_PRMT
       ( ICS_COLL_SYSTM_PRMT_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT,COLL_SYSTM_IDENT
       , key_hash
       , data_hash) 
   SELECT 
		SYS_GUID()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT,COLL_SYSTM_IDENT
        , key_hash
        , data_hash
     FROM ics_flow_icis.ICS_COLL_SYSTM_PRMT icis
WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'CollectionSystemPermitSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.ICS_COLL_SYSTM_PRMT loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.ICS_COLL_SYSTM_PRMT) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_CMPL_MON
-- ----------------------------------------------------------------------------
 INSERT INTO ICS_FLOW_LOCAL.ICS_CMPL_MON
       ( ICS_CMPL_MON_ID
	   ,ics_payload_id
       , transaction_type
       , CMPL_MON_IDENT
       , key_hash
       , data_hash) 
   SELECT 
		SYS_GUID()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , CMPL_MON_IDENT
        , key_hash
        , data_hash
     FROM ics_flow_icis.ICS_CMPL_MON icis
WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'ComplianceMonitoringSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.ICS_CMPL_MON loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.ICS_CMPL_MON) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_CMPL_SCHD
-- ----------------------------------------------------------------------------
 INSERT INTO ICS_FLOW_LOCAL.ICS_CMPL_SCHD
       ( ICS_CMPL_SCHD_ID
	   ,ics_payload_id
       , transaction_type
       , ENFRC_ACTN_IDENT, FINAL_ORDER_IDENT, PRMT_IDENT, CMPL_SCHD_NUM
       , key_hash
       , data_hash) 
   SELECT 
		SYS_GUID()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , ENFRC_ACTN_IDENT, FINAL_ORDER_IDENT, PRMT_IDENT, CMPL_SCHD_NUM
        , key_hash
        , data_hash
     FROM ics_flow_icis.ICS_CMPL_SCHD icis
WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'ComplianceScheduleSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.ICS_CMPL_SCHD loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.ICS_CMPL_SCHD) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_COPY_MGP_LMT_SET
-- ----------------------------------------------------------------------------
 INSERT INTO ICS_FLOW_LOCAL.ICS_COPY_MGP_LMT_SET
       ( ICS_COPY_MGP_LMT_SET_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT,PRMT_FEATR_IDENT,LMT_SET_DESIGNATOR
       , key_hash
       , data_hash) 
   SELECT 
		SYS_GUID()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT,PRMT_FEATR_IDENT,LMT_SET_DESIGNATOR
        , key_hash
        , data_hash
     FROM ics_flow_icis.ICS_COPY_MGP_LMT_SET icis
WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'CopyMGPLimitSetSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.ICS_COPY_MGP_LMT_SET loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.ICS_COPY_MGP_LMT_SET) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_COPY_MGPMS_4_REQ
-- ----------------------------------------------------------------------------
 INSERT INTO ICS_FLOW_LOCAL.ICS_COPY_MGPMS_4_REQ
       ( ICS_COPY_MGPMS_4_REQ_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT
       , key_hash
       , data_hash) 
   SELECT 
		SYS_GUID()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT
        , key_hash
        , data_hash
     FROM ics_flow_icis.ICS_COPY_MGPMS_4_REQ icis
WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'CopyMGPMS4RequirementSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.ICS_COPY_MGPMS_4_REQ loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.ICS_COPY_MGPMS_4_REQ) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_CSO_LONG_TERM_CONTROL_PLAN
-- ----------------------------------------------------------------------------
 INSERT INTO ICS_FLOW_LOCAL.ICS_CSO_LONG_TERM_CONTROL_PLAN
       ( ICS_CSO_LONG_TERM_CONTROL_PLAN_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT
       , key_hash
       , data_hash) 
   SELECT 
		SYS_GUID()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT
        , key_hash
        , data_hash
     FROM ics_flow_icis.ICS_CSO_LONG_TERM_CONTROL_PLAN icis
WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'CSOLongTermControlPlanSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.ICS_CSO_LONG_TERM_CONTROL_PLAN loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.ICS_CSO_LONG_TERM_CONTROL_PLAN) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_CWA_316B_PROG_REP
-- ----------------------------------------------------------------------------
 INSERT INTO ICS_FLOW_LOCAL.ICS_CWA_316B_PROG_REP
       ( ICS_CWA_316B_PROG_REP_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT,PROG_REP_FORM_SET_ID,PROG_REP_FORM_ID
       , key_hash
       , data_hash) 
   SELECT 
		SYS_GUID()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT,PROG_REP_FORM_SET_ID,PROG_REP_FORM_ID
        , key_hash
        , data_hash
     FROM ics_flow_icis.ICS_CWA_316B_PROG_REP icis
WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'CWA316bProgramReportSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.ICS_CWA_316B_PROG_REP loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.ICS_CWA_316B_PROG_REP) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_DSCH_MON_REP
-- ----------------------------------------------------------------------------
 INSERT INTO ICS_FLOW_LOCAL.ICS_DSCH_MON_REP
       ( ICS_DSCH_MON_REP_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT, PRMT_FEATR_IDENT, LMT_SET_DESIGNATOR, MON_PERIOD_END_DATE
       , key_hash
       , data_hash) 
   SELECT 
		SYS_GUID()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT, PRMT_FEATR_IDENT, LMT_SET_DESIGNATOR, MON_PERIOD_END_DATE
        , key_hash
        , data_hash
     FROM ics_flow_icis.ICS_DSCH_MON_REP icis
WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'DischargeMonitoringReportSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.ICS_DSCH_MON_REP loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.ICS_DSCH_MON_REP) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_DMR_VIOL
-- ----------------------------------------------------------------------------
 INSERT INTO ICS_FLOW_LOCAL.ICS_DMR_VIOL
       ( ICS_DMR_VIOL_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT, PRMT_FEATR_IDENT, LMT_SET_DESIGNATOR, MON_PERIOD_END_DATE, PARAM_CODE, MON_SITE_DESC_CODE, LMT_SEASON_NUM, NUM_REP_CODE, NUM_REP_VIOL_CODE
       , key_hash
       , data_hash) 
   SELECT 
		SYS_GUID()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT, PRMT_FEATR_IDENT, LMT_SET_DESIGNATOR, MON_PERIOD_END_DATE, PARAM_CODE, MON_SITE_DESC_CODE, LMT_SEASON_NUM, NUM_REP_CODE, NUM_REP_VIOL_CODE
        , key_hash
        , data_hash
     FROM ics_flow_icis.ICS_DMR_VIOL icis
WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'DMRViolationSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.ICS_DMR_VIOL loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.ICS_DMR_VIOL) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_EFFLU_TRADE_PRTNER
-- ----------------------------------------------------------------------------
 INSERT INTO ICS_FLOW_LOCAL.ICS_EFFLU_TRADE_PRTNER
       ( ICS_EFFLU_TRADE_PRTNER_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT, PRMT_FEATR_IDENT, LMT_SET_DESIGNATOR, PARAM_CODE, MON_SITE_DESC_CODE, LMT_SEASON_NUM, LMT_START_DATE, LMT_END_DATE, LMT_MOD_EFFECTIVE_DATE, TRADE_ID
       , key_hash
       , data_hash) 
   SELECT 
		SYS_GUID()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT, PRMT_FEATR_IDENT, LMT_SET_DESIGNATOR, PARAM_CODE, MON_SITE_DESC_CODE, LMT_SEASON_NUM, LMT_START_DATE, LMT_END_DATE, LMT_MOD_EFFECTIVE_DATE, TRADE_ID
        , key_hash
        , data_hash
     FROM ics_flow_icis.ICS_EFFLU_TRADE_PRTNER icis
WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'EffluentTradePartnerSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.ICS_EFFLU_TRADE_PRTNER loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.ICS_EFFLU_TRADE_PRTNER) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_ENFRC_ACTN_MILESTONE
-- ----------------------------------------------------------------------------
 INSERT INTO ICS_FLOW_LOCAL.ICS_ENFRC_ACTN_MILESTONE
       ( ICS_ENFRC_ACTN_MILESTONE_ID
	   ,ics_payload_id
       , transaction_type
       , ENFRC_ACTN_IDENT, MILESTONE_TYPE_CODE
       , key_hash
       , data_hash) 
   SELECT 
		SYS_GUID()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , ENFRC_ACTN_IDENT, MILESTONE_TYPE_CODE
        , key_hash
        , data_hash
     FROM ics_flow_icis.ICS_ENFRC_ACTN_MILESTONE icis
WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'EnforcementActionMilestoneSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.ICS_ENFRC_ACTN_MILESTONE loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.ICS_ENFRC_ACTN_MILESTONE) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_FRML_ENFRC_ACTN
-- ----------------------------------------------------------------------------
 INSERT INTO ICS_FLOW_LOCAL.ICS_FRML_ENFRC_ACTN
       ( ICS_FRML_ENFRC_ACTN_ID
	   ,ics_payload_id
       , transaction_type
       , ENFRC_ACTN_IDENT
       , key_hash
       , data_hash) 
   SELECT 
		SYS_GUID()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , ENFRC_ACTN_IDENT
        , key_hash
        , data_hash
     FROM ics_flow_icis.ICS_FRML_ENFRC_ACTN icis
WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'FormalEnforcementActionSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.ICS_FRML_ENFRC_ACTN loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.ICS_FRML_ENFRC_ACTN) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_GNRL_PRMT
-- ----------------------------------------------------------------------------
 INSERT INTO ICS_FLOW_LOCAL.ICS_GNRL_PRMT
       ( ICS_GNRL_PRMT_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT
       , key_hash
       , data_hash) 
   SELECT 
		SYS_GUID()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT
        , key_hash
        , data_hash
     FROM ics_flow_icis.ICS_GNRL_PRMT icis
WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'GeneralPermitSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.ICS_GNRL_PRMT loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.ICS_GNRL_PRMT) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_HIST_PRMT_SCHD_EVTS
-- ----------------------------------------------------------------------------
 INSERT INTO ICS_FLOW_LOCAL.ICS_HIST_PRMT_SCHD_EVTS
       ( ICS_HIST_PRMT_SCHD_EVTS_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT, PRMT_EFFECTIVE_DATE, NARR_COND_NUM, SCHD_EVT_CODE, SCHD_DATE
       , key_hash
       , data_hash) 
   SELECT 
		SYS_GUID()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT, PRMT_EFFECTIVE_DATE, NARR_COND_NUM, SCHD_EVT_CODE, SCHD_DATE
        , key_hash
        , data_hash
     FROM ics_flow_icis.ICS_HIST_PRMT_SCHD_EVTS icis
WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'HistoricalPermitScheduleEventsSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.ICS_HIST_PRMT_SCHD_EVTS loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.ICS_HIST_PRMT_SCHD_EVTS) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_INFRML_ENFRC_ACTN
-- ----------------------------------------------------------------------------
 INSERT INTO ICS_FLOW_LOCAL.ICS_INFRML_ENFRC_ACTN
       ( ICS_INFRML_ENFRC_ACTN_ID
	   ,ics_payload_id
       , transaction_type
       , ENFRC_ACTN_IDENT
       , key_hash
       , data_hash) 
   SELECT 
		SYS_GUID()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , ENFRC_ACTN_IDENT
        , key_hash
        , data_hash
     FROM ics_flow_icis.ICS_INFRML_ENFRC_ACTN icis
WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'InformalEnforcementActionSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.ICS_INFRML_ENFRC_ACTN loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.ICS_INFRML_ENFRC_ACTN) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_LMTS
-- ----------------------------------------------------------------------------
 INSERT INTO ICS_FLOW_LOCAL.ICS_LMTS
       ( ICS_LMTS_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT, PRMT_FEATR_IDENT, LMT_SET_DESIGNATOR, PARAM_CODE, MON_SITE_DESC_CODE, LMT_SEASON_NUM, LMT_START_DATE, LMT_END_DATE
       , key_hash
       , data_hash) 
   SELECT 
		SYS_GUID()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT, PRMT_FEATR_IDENT, LMT_SET_DESIGNATOR, PARAM_CODE, MON_SITE_DESC_CODE, LMT_SEASON_NUM, LMT_START_DATE, LMT_END_DATE
        , key_hash
        , data_hash
     FROM ics_flow_icis.ICS_LMTS icis
WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'LimitsSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.ICS_LMTS loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.ICS_LMTS) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_LMT_SET
-- ----------------------------------------------------------------------------
 INSERT INTO ICS_FLOW_LOCAL.ICS_LMT_SET
       ( ICS_LMT_SET_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT, PRMT_FEATR_IDENT, LMT_SET_DESIGNATOR
       , key_hash
       , data_hash) 
   SELECT 
		SYS_GUID()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT, PRMT_FEATR_IDENT, LMT_SET_DESIGNATOR
        , key_hash
        , data_hash
     FROM ics_flow_icis.ICS_LMT_SET icis
WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'LimitSetSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.ICS_LMT_SET loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.ICS_LMT_SET) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_MASTER_GNRL_PRMT
-- ----------------------------------------------------------------------------
 INSERT INTO ICS_FLOW_LOCAL.ICS_MASTER_GNRL_PRMT
       ( ICS_MASTER_GNRL_PRMT_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT
       , key_hash
       , data_hash) 
   SELECT 
		SYS_GUID()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT
        , key_hash
        , data_hash
     FROM ics_flow_icis.ICS_MASTER_GNRL_PRMT icis
WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'MasterGeneralPermitSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.ICS_MASTER_GNRL_PRMT loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.ICS_MASTER_GNRL_PRMT) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_NARR_COND_SCHD
-- ----------------------------------------------------------------------------
 INSERT INTO ICS_FLOW_LOCAL.ICS_NARR_COND_SCHD
       ( ICS_NARR_COND_SCHD_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT, NARR_COND_NUM
       , key_hash
       , data_hash) 
   SELECT 
		SYS_GUID()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT, NARR_COND_NUM
        , key_hash
        , data_hash
     FROM ics_flow_icis.ICS_NARR_COND_SCHD icis
WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'NarrativeConditionScheduleSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.ICS_NARR_COND_SCHD loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.ICS_NARR_COND_SCHD) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_NPDES_VARIANCE_PRMT
-- ----------------------------------------------------------------------------
 INSERT INTO ICS_FLOW_LOCAL.ICS_NPDES_VARIANCE_PRMT
       ( ICS_NPDES_VARIANCE_PRMT_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT,NPDES_VARIANCE_TYPE_CODE,NPDES_VARIANCE_SUBM_DATE
       , key_hash
       , data_hash) 
   SELECT 
		SYS_GUID()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT,NPDES_VARIANCE_TYPE_CODE,NPDES_VARIANCE_SUBM_DATE
        , key_hash
        , data_hash
     FROM ics_flow_icis.ICS_NPDES_VARIANCE_PRMT icis
WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'NPDESVariancePermitSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.ICS_NPDES_VARIANCE_PRMT loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.ICS_NPDES_VARIANCE_PRMT) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_PARAM_LMTS
-- ----------------------------------------------------------------------------
 INSERT INTO ICS_FLOW_LOCAL.ICS_PARAM_LMTS
       ( ICS_PARAM_LMTS_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT, PRMT_FEATR_IDENT, LMT_SET_DESIGNATOR, PARAM_CODE, MON_SITE_DESC_CODE, LMT_SEASON_NUM
       , key_hash
       , data_hash) 
   SELECT 
		SYS_GUID()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT, PRMT_FEATR_IDENT, LMT_SET_DESIGNATOR, PARAM_CODE, MON_SITE_DESC_CODE, LMT_SEASON_NUM
        , key_hash
        , data_hash
     FROM ics_flow_icis.ICS_PARAM_LMTS icis
WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'ParameterLimitsSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.ICS_PARAM_LMTS loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.ICS_PARAM_LMTS) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_PRMT_REISSU
-- ----------------------------------------------------------------------------
 INSERT INTO ICS_FLOW_LOCAL.ICS_PRMT_REISSU
       ( ICS_PRMT_REISSU_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT, PRMT_ISSUE_DATE
       , key_hash
       , data_hash) 
   SELECT 
		SYS_GUID()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT, PRMT_ISSUE_DATE
        , key_hash
        , data_hash
     FROM ics_flow_icis.ICS_PRMT_REISSU icis
WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'PermitReissuanceSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.ICS_PRMT_REISSU loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.ICS_PRMT_REISSU) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_PRMT_FEATR
-- ----------------------------------------------------------------------------
 INSERT INTO ICS_FLOW_LOCAL.ICS_PRMT_FEATR
       ( ICS_PRMT_FEATR_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT, PRMT_FEATR_IDENT
       , key_hash
       , data_hash) 
   SELECT 
		SYS_GUID()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT, PRMT_FEATR_IDENT
        , key_hash
        , data_hash
     FROM ics_flow_icis.ICS_PRMT_FEATR icis
WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'PermittedFeatureSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.ICS_PRMT_FEATR loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.ICS_PRMT_FEATR) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_PRMT_TERM
-- ----------------------------------------------------------------------------
 INSERT INTO ICS_FLOW_LOCAL.ICS_PRMT_TERM
       ( ICS_PRMT_TERM_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT
       , key_hash
       , data_hash) 
   SELECT 
		SYS_GUID()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT
        , key_hash
        , data_hash
     FROM ics_flow_icis.ICS_PRMT_TERM icis
WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'PermitTerminationSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.ICS_PRMT_TERM loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.ICS_PRMT_TERM) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_PRMT_TRACK_EVT
-- ----------------------------------------------------------------------------
 INSERT INTO ICS_FLOW_LOCAL.ICS_PRMT_TRACK_EVT
       ( ICS_PRMT_TRACK_EVT_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT, PRMT_TRACK_EVT_CODE, PRMT_TRACK_EVT_DATE
       , key_hash
       , data_hash) 
   SELECT 
		SYS_GUID()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT, PRMT_TRACK_EVT_CODE, PRMT_TRACK_EVT_DATE
        , key_hash
        , data_hash
     FROM ics_flow_icis.ICS_PRMT_TRACK_EVT icis
WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'PermitTrackingEventSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.ICS_PRMT_TRACK_EVT loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.ICS_PRMT_TRACK_EVT) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_POTW_PRMT
-- ----------------------------------------------------------------------------
 INSERT INTO ICS_FLOW_LOCAL.ICS_POTW_PRMT
       ( ICS_POTW_PRMT_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT
       , key_hash
       , data_hash) 
   SELECT 
		SYS_GUID()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT
        , key_hash
        , data_hash
     FROM ics_flow_icis.ICS_POTW_PRMT icis
WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'POTWPermitSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.ICS_POTW_PRMT loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.ICS_POTW_PRMT) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_POTW_TRTMNT_TECHNOLOGY_PRMT
-- ----------------------------------------------------------------------------
 INSERT INTO ICS_FLOW_LOCAL.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT
       ( ICS_POTW_TRTMNT_TECHNOLOGY_PRMT_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT
       , key_hash
       , data_hash) 
   SELECT 
		SYS_GUID()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT
        , key_hash
        , data_hash
     FROM ics_flow_icis.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT icis
WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'POTWTreatmentTechnologyPermitSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_PRETR_PRMT
-- ----------------------------------------------------------------------------
 INSERT INTO ICS_FLOW_LOCAL.ICS_PRETR_PRMT
       ( ICS_PRETR_PRMT_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT
       , key_hash
       , data_hash) 
   SELECT 
		SYS_GUID()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT
        , key_hash
        , data_hash
     FROM ics_flow_icis.ICS_PRETR_PRMT icis
WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'PretreatmentPermitSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.ICS_PRETR_PRMT loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.ICS_PRETR_PRMT) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_PRETR_PROG_REP
-- ----------------------------------------------------------------------------
 INSERT INTO ICS_FLOW_LOCAL.ICS_PRETR_PROG_REP
       ( ICS_PRETR_PROG_REP_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT,PROG_REP_FORM_SET_ID,PROG_REP_FORM_ID
       , key_hash
       , data_hash) 
   SELECT 
		SYS_GUID()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT,PROG_REP_FORM_SET_ID,PROG_REP_FORM_ID
        , key_hash
        , data_hash
     FROM ics_flow_icis.ICS_PRETR_PROG_REP icis
WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'PretreatmentProgramReportSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.ICS_PRETR_PROG_REP loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.ICS_PRETR_PROG_REP) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_SEWER_OVRFLW_BYPASS_EVT_REP
-- ----------------------------------------------------------------------------
 INSERT INTO ICS_FLOW_LOCAL.ICS_SEWER_OVRFLW_BYPASS_EVT_REP
       ( ICS_SEWER_OVRFLW_BYPASS_EVT_REP_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT,PROG_REP_FORM_SET_ID,PROG_REP_FORM_ID
       , key_hash
       , data_hash) 
   SELECT 
		SYS_GUID()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT,PROG_REP_FORM_SET_ID,PROG_REP_FORM_ID
        , key_hash
        , data_hash
     FROM ics_flow_icis.ICS_SEWER_OVRFLW_BYPASS_EVT_REP icis
WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'SewerOverflowBypassEventReportSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.ICS_SEWER_OVRFLW_BYPASS_EVT_REP loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.ICS_SEWER_OVRFLW_BYPASS_EVT_REP) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_SNGL_EVT_VIOL
-- ----------------------------------------------------------------------------
 INSERT INTO ICS_FLOW_LOCAL.ICS_SNGL_EVT_VIOL
       ( ICS_SNGL_EVT_VIOL_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT, SNGL_EVT_VIOL_CODE, SNGL_EVT_VIOL_DATE
       , key_hash
       , data_hash) 
   SELECT 
		SYS_GUID()
		, icis.ics_payload_id
        , 'X' AS transaction_type
        , PRMT_IDENT, SNGL_EVT_VIOL_CODE, SNGL_EVT_VIOL_DATE
        , key_hash
        , data_hash
     FROM ics_flow_icis.ICS_SNGL_EVT_VIOL icis
WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'SingleEventViolationSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.ICS_SNGL_EVT_VIOL loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.ICS_SNGL_EVT_VIOL) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_SW_CNST_PRMT
-- ----------------------------------------------------------------------------
 INSERT INTO ICS_FLOW_LOCAL.ICS_SW_CNST_PRMT
       ( ICS_SW_CNST_PRMT_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT
       , key_hash
       , data_hash) 
   SELECT 
		SYS_GUID()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT
        , key_hash
        , data_hash
     FROM ics_flow_icis.ICS_SW_CNST_PRMT icis
WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'SWConstructionPermitSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.ICS_SW_CNST_PRMT loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.ICS_SW_CNST_PRMT) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_SW_INDST_ANNUL_REP
-- ----------------------------------------------------------------------------
 INSERT INTO ICS_FLOW_LOCAL.ICS_SW_INDST_ANNUL_REP
       ( ICS_SW_INDST_ANNUL_REP_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT, INDST_SW_ANNUL_REP_RCVD_DATE
       , key_hash
       , data_hash) 
   SELECT 
		SYS_GUID()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT, INDST_SW_ANNUL_REP_RCVD_DATE
        , key_hash
        , data_hash
     FROM ics_flow_icis.ICS_SW_INDST_ANNUL_REP icis
WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'SWIndustrialAnnualReportSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.ICS_SW_INDST_ANNUL_REP loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.ICS_SW_INDST_ANNUL_REP) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_SW_INDST_PRMT
-- ----------------------------------------------------------------------------
 INSERT INTO ICS_FLOW_LOCAL.ICS_SW_INDST_PRMT
       ( ICS_SW_INDST_PRMT_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT
       , key_hash
       , data_hash) 
   SELECT 
		SYS_GUID()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT
        , key_hash
        , data_hash
     FROM ics_flow_icis.ICS_SW_INDST_PRMT icis
WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'SWIndustrialPermitSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.ICS_SW_INDST_PRMT loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.ICS_SW_INDST_PRMT) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_SWMS_4_ANNUL_PROG_REP
-- ----------------------------------------------------------------------------
 INSERT INTO ICS_FLOW_LOCAL.ICS_SWMS_4_ANNUL_PROG_REP
       ( ICS_SWMS_4_ANNUL_PROG_REP_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT,PROG_REP_FORM_SET_ID,PROG_REP_FORM_ID
       , key_hash
       , data_hash) 
   SELECT 
		SYS_GUID()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT,PROG_REP_FORM_SET_ID,PROG_REP_FORM_ID
        , key_hash
        , data_hash
     FROM ics_flow_icis.ICS_SWMS_4_ANNUL_PROG_REP icis
WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'SWMS4AnnualProgramReportSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.ICS_SWMS_4_ANNUL_PROG_REP loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.ICS_SWMS_4_ANNUL_PROG_REP) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_SWMS_4_PRMT
-- ----------------------------------------------------------------------------
 INSERT INTO ICS_FLOW_LOCAL.ICS_SWMS_4_PRMT
       ( ICS_SWMS_4_PRMT_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT
       , key_hash
       , data_hash) 
   SELECT 
		SYS_GUID()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT
        , key_hash
        , data_hash
     FROM ics_flow_icis.ICS_SWMS_4_PRMT icis
WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'SWMS4PermitSubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.ICS_SWMS_4_PRMT loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.ICS_SWMS_4_PRMT) -- do not delete if no other records for saftey
	;	 
	 



-- ICS_UNPRMT_FAC
-- ----------------------------------------------------------------------------
 INSERT INTO ICS_FLOW_LOCAL.ICS_UNPRMT_FAC
       ( ICS_UNPRMT_FAC_ID
	   ,ics_payload_id
       , transaction_type
       , PRMT_IDENT
       , key_hash
       , data_hash) 
   SELECT 
		SYS_GUID()
		, icis.ics_payload_id
        , 'D' AS transaction_type
        , PRMT_IDENT
        , key_hash
        , data_hash
     FROM ics_flow_icis.ICS_UNPRMT_FAC icis
WHERE
	exists (select 1 from ICS_PAYLOAD where ENABLED = 'Y' AND auto_gen_deletes = 'Y' AND OPERATION = 'UnpermittedFacilitySubmission')
	AND not exists (SELECT 1 from ICS_FLOW_LOCAL.ICS_UNPRMT_FAC loc where icis.KEY_HASH = loc.KEY_HASH )
	AND EXISTS (SELECT 1 FROM ICS_FLOW_LOCAL.ICS_UNPRMT_FAC) -- do not delete if no other records for saftey
	;	 
	 
				   
-- ------------------
-- Choice Key Deletes
-- ------------------
-- ICS_CMPL_MON_LNK (3 paths)

delete from ICS_KEY_HASH;

insert into ICS_KEY_HASH 
select ICS_CMPL_MON_LNK.KEY_HASH 
      from ics_flow_icis.ICS_CMPL_MON_LNK ICS_CMPL_MON_LNK 
      where  ICS_CMPL_MON_LNK.KEY_HASH not in (select KEY_HASH from ics_flow_local.ICS_CMPL_MON_LNK)
      and exists (select 1 from ICS_PAYLOAD where OPERATION = 'ComplianceMonitoringLinkageSubmission' and ENABLED = 'Y' and AUTO_GEN_DELETES = 'Y')
      ;
-- ICS_CMPL_MON_LNK - CM LINK
INSERT INTO ics_flow_local.ICS_CMPL_MON_LNK
           (
		   ICS_CMPL_MON_LNK_ID
           ,ICS_PAYLOAD_ID
           ,SRC_SYSTM_IDENT
           ,TRANSACTION_TYPE
           ,TRANSACTION_TIMESTAMP
           ,CMPL_MON_IDENT
           ,KEY_HASH
           ,DATA_HASH
		   )

     SELECT 
 		   ICS_CMPL_MON_LNK.ICS_CMPL_MON_LNK_ID
           ,ICS_CMPL_MON_LNK.ICS_PAYLOAD_ID
           ,ICS_CMPL_MON_LNK.SRC_SYSTM_IDENT
           ,'X' as TRANSACTION_TYPE
           ,ICS_CMPL_MON_LNK.TRANSACTION_TIMESTAMP
           ,ICS_CMPL_MON_LNK.CMPL_MON_IDENT
           ,ICS_CMPL_MON_LNK.KEY_HASH
           ,null DATA_HASH
              from ics_flow_icis.ICS_CMPL_MON_LNK ICS_CMPL_MON_LNK 
              join ics_flow_icis.ICS_LNK_CMPL_MON LNKCM on LNKCM.ICS_CMPL_MON_LNK_ID = ICS_CMPL_MON_LNK.ICS_CMPL_MON_LNK_ID
              where  ICS_CMPL_MON_LNK.KEY_HASH  in (select KEY_HASH from ICS_KEY_HASH)
              
;

 INSERT INTO ics_flow_local.ICS_LNK_CMPL_MON
     SELECT LNKCM.*
              from ics_flow_icis.ICS_CMPL_MON_LNK ICS_CMPL_MON_LNK 
              join ics_flow_icis.ICS_LNK_CMPL_MON LNKCM on LNKCM.ICS_CMPL_MON_LNK_ID = ICS_CMPL_MON_LNK.ICS_CMPL_MON_LNK_ID
              where  ICS_CMPL_MON_LNK.KEY_HASH  in (select KEY_HASH from ICS_KEY_HASH)
 ;
 
 -- ICS_CMPL_MON_LNK - EA Link
 
INSERT INTO ics_flow_local.ICS_CMPL_MON_LNK
           (
		   ICS_CMPL_MON_LNK_ID
           ,ICS_PAYLOAD_ID
           ,SRC_SYSTM_IDENT
           ,TRANSACTION_TYPE
           ,TRANSACTION_TIMESTAMP
           ,CMPL_MON_IDENT
           ,KEY_HASH
           ,DATA_HASH
		   )

     SELECT 
 		   ICS_CMPL_MON_LNK.ICS_CMPL_MON_LNK_ID
           ,ICS_CMPL_MON_LNK.ICS_PAYLOAD_ID
           ,ICS_CMPL_MON_LNK.SRC_SYSTM_IDENT
           ,'X' as TRANSACTION_TYPE
           ,ICS_CMPL_MON_LNK.TRANSACTION_TIMESTAMP
           ,ICS_CMPL_MON_LNK.CMPL_MON_IDENT
           ,ICS_CMPL_MON_LNK.KEY_HASH
           ,null DATA_HASH
          from ics_flow_icis.ICS_CMPL_MON_LNK ICS_CMPL_MON_LNK 
          JOIN ics_flow_icis.ICS_LNK_ENFRC_ACTN I2  ON I2.ICS_CMPL_MON_LNK_ID = ICS_CMPL_MON_LNK.ICS_CMPL_MON_LNK_ID
          where  ICS_CMPL_MON_LNK.KEY_HASH  in (select KEY_HASH from ICS_KEY_HASH)
;

 INSERT INTO ics_flow_local.ICS_LNK_ENFRC_ACTN
   SELECT I2.*
          from ics_flow_icis.ICS_CMPL_MON_LNK ICS_CMPL_MON_LNK 
          JOIN ics_flow_icis.ICS_LNK_ENFRC_ACTN I2  ON I2.ICS_CMPL_MON_LNK_ID = ICS_CMPL_MON_LNK.ICS_CMPL_MON_LNK_ID
          where  ICS_CMPL_MON_LNK.KEY_HASH  in (select KEY_HASH from ICS_KEY_HASH)
;

-- ICS_CMPL_MON_LNK - SEV link
INSERT INTO ics_flow_local.ICS_CMPL_MON_LNK
           (
		   ICS_CMPL_MON_LNK_ID
           ,ICS_PAYLOAD_ID
           ,SRC_SYSTM_IDENT
           ,TRANSACTION_TYPE
           ,TRANSACTION_TIMESTAMP
           ,CMPL_MON_IDENT
           ,KEY_HASH
           ,DATA_HASH
		   )

     SELECT 
 		   ICS_CMPL_MON_LNK.ICS_CMPL_MON_LNK_ID
           ,ICS_CMPL_MON_LNK.ICS_PAYLOAD_ID
           ,ICS_CMPL_MON_LNK.SRC_SYSTM_IDENT
           ,'X' as TRANSACTION_TYPE
           ,ICS_CMPL_MON_LNK.TRANSACTION_TIMESTAMP
           ,ICS_CMPL_MON_LNK.CMPL_MON_IDENT
           ,ICS_CMPL_MON_LNK.KEY_HASH
           ,null DATA_HASH
 from ics_flow_icis.ICS_CMPL_MON_LNK ICS_CMPL_MON_LNK 
 JOIN ics_flow_icis.ICS_LNK_SNGL_EVT I3
 ON I3.ICS_CMPL_MON_LNK_ID = ICS_CMPL_MON_LNK.ICS_CMPL_MON_LNK_ID 
where  ICS_CMPL_MON_LNK.KEY_HASH  in (select KEY_HASH from ICS_KEY_HASH)
;

insert into ICS_LNK_SNGL_EVT
      SELECT I3.*
 from ics_flow_icis.ICS_CMPL_MON_LNK ICS_CMPL_MON_LNK 
 JOIN ics_flow_icis.ICS_LNK_SNGL_EVT I3
 ON I3.ICS_CMPL_MON_LNK_ID = ICS_CMPL_MON_LNK.ICS_CMPL_MON_LNK_ID 
where  ICS_CMPL_MON_LNK.KEY_HASH  in (select KEY_HASH from ICS_KEY_HASH)
;

-- ICS_FINAL_ORDER_VIOL_LNK ------------------------------

delete from ICS_KEY_HASH;

insert into ICS_KEY_HASH
select KEY_HASH from ics_flow_icis.ics_final_order_viol_lnk ics_final_order_viol_lnk
      where  ics_final_order_viol_lnk.KEY_HASH not in (select KEY_HASH from ics_flow_local.ics_final_order_viol_lnk)
      and exists (select 1 from ICS_PAYLOAD where OPERATION = 'FinalOrderViolationLinkageSubmission' and ENABLED = 'Y' and AUTO_GEN_DELETES = 'Y')
      ;
      
  INSERT INTO  ics_final_order_viol_lnk
             ( ics_final_order_viol_lnk_id
             , ics_payload_id
             , src_systm_ident
             , transaction_type
             , transaction_timestamp
             , enfrc_actn_ident
             , final_order_ident
             , key_hash
             , data_hash)
      SELECT ics_final_order_viol_lnk.ics_final_order_viol_lnk_id -- changed from local to icis to be like EA (not sure point of local)
           , (SELECT ics_payload_id
                FROM ics_payload 
               WHERE operation = 'FinalOrderViolationLinkageSubmission') AS ics_payload_id
             , ics_final_order_viol_lnk.src_systm_ident
             , 'X' AS transaction_type
             , ics_final_order_viol_lnk.transaction_timestamp
             , ics_final_order_viol_lnk.enfrc_actn_ident
             , ics_final_order_viol_lnk.final_order_ident
             , ics_final_order_viol_lnk.key_hash
             , ics_final_order_viol_lnk.data_hash
        FROM ics_flow_icis.ics_final_order_viol_lnk ics_final_order_viol_lnk
        JOIN ICS_KEY_HASH KH on KH.KEY_HASH = ics_final_order_viol_lnk.KEY_HASH;
      
      
 
--    ICS_DSCH_MON_REP_PARAM_VIOL
INSERT INTO  ICS_DSCH_MON_REP_PARAM_VIOL
           ( ICS_DSCH_MON_REP_PARAM_VIOL_ID
           , ICS_ENFRC_ACTN_VIOL_LNK_ID
           , ICS_FINAL_ORDER_VIOL_LNK_ID
           , PRMT_IDENT
           , PRMT_FEATR_IDENT
           , LMT_SET_DESIGNATOR
           , MON_PERIOD_END_DATE
           , PARAM_CODE
           , MON_SITE_DESC_CODE
           , LMT_SEASON_NUM
           , DATA_HASH)
      SELECT ics_dsch_mon_rep_param_viol.ICS_DSCH_MON_REP_PARAM_VIOL_ID
           , NULL AS ICS_ENFRC_ACTN_VIOL_LNK_ID
           , ics_dsch_mon_rep_param_viol.ics_final_order_viol_lnk_id as ics_final_order_viol_lnk_id
           , ics_dsch_mon_rep_param_viol.prmt_ident as prmt_ident
           , ics_dsch_mon_rep_param_viol.prmt_featr_ident as prmt_featr_ident
           , ics_dsch_mon_rep_param_viol.lmt_set_designator as lmt_set_designator
           , ics_dsch_mon_rep_param_viol.mon_period_end_date as mon_period_end_date
           , ics_dsch_mon_rep_param_viol.param_code as param_code
           , ics_dsch_mon_rep_param_viol.mon_site_desc_code as mon_site_desc_code
           , ics_dsch_mon_rep_param_viol.lmt_season_num as lmt_season_num
           , ics_dsch_mon_rep_param_viol.data_hash as data_hash
    FROM  ics_flow_icis.ics_final_order_viol_lnk ifov
   join ICS_KEY_HASH KH on KH.KEY_HASH = ifov.KEY_HASH
    JOIN  ICS_FLOW_ICIS.ics_dsch_mon_rep_param_viol ics_dsch_mon_rep_param_viol ON ifov.ics_final_order_viol_lnk_id = ics_dsch_mon_rep_param_viol.ics_final_order_viol_lnk_id
   ;     
      
      
--    ICS_DSCH_MON_REP_VIOL
INSERT INTO  ICS_DSCH_MON_REP_VIOL
           ( ICS_DSCH_MON_REP_VIOL_ID
           , ICS_ENFRC_ACTN_VIOL_LNK_ID
           , ICS_FINAL_ORDER_VIOL_LNK_ID
           , PRMT_IDENT
           , PRMT_FEATR_IDENT
           , LMT_SET_DESIGNATOR
           , MON_PERIOD_END_DATE
           , DATA_HASH)
      SELECT ics_dsch_mon_rep_viol.ICS_DSCH_MON_REP_VIOL_ID
           , NULL AS ICS_ENFRC_ACTN_VIOL_LNK_ID
           , ics_dsch_mon_rep_viol.ics_final_order_viol_lnk_id as ics_final_order_viol_lnk_id
           , ics_dsch_mon_rep_viol.prmt_ident as prmt_ident
           , ics_dsch_mon_rep_viol.prmt_featr_ident as prmt_featr_ident
           , ics_dsch_mon_rep_viol.lmt_set_designator as lmt_set_designator
           , ics_dsch_mon_rep_viol.mon_period_end_date as mon_period_end_date
           , ics_dsch_mon_rep_viol.data_hash as data_hash
   FROM ics_flow_icis.ics_dsch_mon_rep_viol ics_dsch_mon_rep_viol
   JOIN ics_flow_icis.ics_final_order_viol_lnk ifov
     ON ifov.ics_final_order_viol_lnk_id = ics_dsch_mon_rep_viol.ics_final_order_viol_lnk_id
   join ICS_KEY_HASH KH on KH.KEY_HASH = ifov.KEY_HASH;        
 
--    ICS_PRMT_SCHD_VIOL
INSERT INTO  ICS_PRMT_SCHD_VIOL
           ( ICS_PRMT_SCHD_VIOL_ID
           , ICS_ENFRC_ACTN_VIOL_LNK_ID
           , ICS_FINAL_ORDER_VIOL_LNK_ID
           , PRMT_IDENT
           , NARR_COND_NUM
           , SCHD_EVT_CODE
           , SCHD_DATE
           , DATA_HASH)
      SELECT ics_prmt_schd_viol.ICS_PRMT_SCHD_VIOL_ID
           , NULL AS ICS_ENFRC_ACTN_VIOL_LNK_ID
           , ics_prmt_schd_viol.ics_final_order_viol_lnk_id as ics_final_order_viol_lnk_id
           , ics_prmt_schd_viol.prmt_ident as prmt_ident
           , ics_prmt_schd_viol.narr_cond_num as narr_cond_num
           , ics_prmt_schd_viol.schd_evt_code as schd_evt_code
           , ics_prmt_schd_viol.schd_date as schd_date
           , ics_prmt_schd_viol.data_hash as data_hash
   FROM ics_flow_icis.ics_prmt_schd_viol ics_prmt_schd_viol
   JOIN ics_flow_icis.ics_final_order_viol_lnk ifov
     ON ifov.ics_final_order_viol_lnk_id = ics_prmt_schd_viol.ics_final_order_viol_lnk_id
   join ICS_KEY_HASH KH on KH.KEY_HASH = ifov.KEY_HASH;    
      
      
 --    ICS_SNGL_EVTS_VIOL
INSERT INTO ics_sngl_evts_viol
           (ics_sngl_evts_viol_id
           ,ics_enfrc_actn_viol_lnk_id
           ,ics_final_order_viol_lnk_id
           ,prmt_ident
           ,sngl_evt_viol_code
           ,sngl_evt_viol_date
           ,data_hash)
      SELECT ics_sngl_evts_viol.ics_sngl_evts_viol_id
           , NULL as ics_enfrc_actn_viol_lnk_id
           , ics_sngl_evts_viol.ics_final_order_viol_lnk_id as ics_final_order_viol_lnk_id
           , ics_sngl_evts_viol.prmt_ident as prmt_ident
           , ics_sngl_evts_viol.sngl_evt_viol_code as sngl_evt_viol_code
           , ics_sngl_evts_viol.sngl_evt_viol_date as sngl_evt_viol_date
           , ics_sngl_evts_viol.data_hash as data_hash
        FROM ics_flow_icis.ics_sngl_evts_viol ics_sngl_evts_viol
   JOIN ics_flow_icis.ics_final_order_viol_lnk ifov
     ON ifov.ics_final_order_viol_lnk_id = ics_sngl_evts_viol.ics_final_order_viol_lnk_id
   join ICS_KEY_HASH KH on KH.KEY_HASH = ifov.KEY_HASH;    
      
      
 --    ICS_CMPL_SCHD_VIOL
      INSERT INTO ICS_CMPL_SCHD_VIOL
           ( ICS_CMPL_SCHD_VIOL_ID
           , ICS_ENFRC_ACTN_VIOL_LNK_ID
           , ICS_FINAL_ORDER_VIOL_LNK_ID
           , ENFRC_ACTN_IDENT
           , FINAL_ORDER_IDENT
           , PRMT_IDENT
           , CMPL_SCHD_NUM
           , SCHD_EVT_CODE
           , SCHD_DATE
           , DATA_HASH)
      SELECT ics_cmpl_schd_viol.ICS_CMPL_SCHD_VIOL_ID
           , NULL AS ICS_ENFRC_ACTN_VIOL_LNK_ID
           , ics_cmpl_schd_viol.ics_final_order_viol_lnk_id as ics_final_order_viol_lnk_id
           , ics_cmpl_schd_viol.enfrc_actn_ident as enfrc_actn_ident
           , ics_cmpl_schd_viol.final_order_ident as final_order_ident
           , ics_cmpl_schd_viol.prmt_ident as prmt_ident
           , ics_cmpl_schd_viol.cmpl_schd_num as cmpl_schd_num
           , ics_cmpl_schd_viol.schd_evt_code as schd_evt_code
           , ics_cmpl_schd_viol.schd_date as schd_date
           , ics_cmpl_schd_viol.data_hash as data_hash   
        FROM ics_flow_icis.ics_cmpl_schd_viol ics_cmpl_schd_viol
   JOIN ics_flow_icis.ics_final_order_viol_lnk ifov
     ON ifov.ics_final_order_viol_lnk_id = ics_cmpl_schd_viol.ics_final_order_viol_lnk_id
   join ICS_KEY_HASH KH on KH.KEY_HASH = ifov.KEY_HASH;    
      



/* **************************************************
  * ICS_ENFRC_ACTN_VIOL_LNK:  Set Delete Transactions     
  * **************************************************/

delete from ICS_KEY_HASH;

insert into ICS_KEY_HASH
select KEY_HASH from ics_flow_icis.ics_enfrc_actn_viol_lnk ics_enfrc_actn_viol_lnk
      where  ics_enfrc_actn_viol_lnk.KEY_HASH not in (select KEY_HASH from ics_flow_local.ics_enfrc_actn_viol_lnk)
      and exists (select 1 from ICS_PAYLOAD where OPERATION = 'EnforcementActionViolationLinkageSubmission' and ENABLED = 'Y' and AUTO_GEN_DELETES = 'Y')
      ;

 /*  
 *  ICS_ENFRC_ACTN_VIOL_LNK
 */                                     
 INSERT INTO ics_enfrc_actn_viol_lnk
      ( ics_enfrc_actn_viol_lnk_id
      , ics_payload_id
      , src_systm_ident
      , transaction_type
      , transaction_timestamp
      , enfrc_actn_ident
      , key_hash
      , data_hash)
 SELECT ics_enfrc_actn_viol_lnk.ics_enfrc_actn_viol_lnk_id AS ICS_ENFRC_ACTN_VIOL_LNK_ID
      , (SELECT ics_payload_id
           FROM ics_payload 
          WHERE operation = 'EnforcementActionViolationLinkageSubmission') AS ics_payload_id
      , ics_enfrc_actn_viol_lnk.src_systm_ident AS src_systm_ident
      , 'x' AS transaction_type
      , ics_enfrc_actn_viol_lnk.transaction_timestamp AS transaction_timestamp
      , ics_enfrc_actn_viol_lnk.enfrc_actn_ident AS enfrc_actn_ident
      , NULL AS key_hash
      , NULL AS data_hash
   FROM ics_flow_icis.ics_enfrc_actn_viol_lnk ics_enfrc_actn_viol_lnk     	  
 JOIN ICS_KEY_HASH KH on KH.KEY_HASH = ics_enfrc_actn_viol_lnk.KEY_HASH;
      

   /*
   * ICS_PRMT_SCHD_VIOL
   */
   INSERT INTO ics_prmt_schd_viol
       ( ics_prmt_schd_viol_id
       , ics_enfrc_actn_viol_lnk_id
       , ics_final_order_viol_lnk_id
       , prmt_ident
       , narr_cond_num
       , schd_evt_code
       , schd_date
       , data_hash)
  SELECT ics_prmt_schd_viol.ics_prmt_schd_viol_id
       , ics_prmt_schd_viol.ics_enfrc_actn_viol_lnk_id AS ics_enfrc_actn_viol_lnk_id
       , NULL AS ics_final_order_viol_lnk_id
       , ics_prmt_schd_viol.prmt_ident AS prmt_ident
       , ics_prmt_schd_viol.narr_cond_num AS narr_cond_num
       , ics_prmt_schd_viol.schd_evt_code AS schd_evt_code
       , ics_prmt_schd_viol.schd_date AS schd_date
       , ics_prmt_schd_viol.data_hash  AS data_hash
   FROM ics_flow_icis.ics_prmt_schd_viol ics_prmt_schd_viol
   JOIN ics_flow_icis.ics_enfrc_actn_viol_lnk ieav
     ON ieav.ics_enfrc_actn_viol_lnk_id = ics_prmt_schd_viol.ics_enfrc_actn_viol_lnk_id   	  
 JOIN ICS_KEY_HASH KH on KH.KEY_HASH = ieav.KEY_HASH
 ;    
          

  /*
   * ICS_CMPL_SCHD_VIOL
   */
   INSERT INTO ics_cmpl_schd_viol
        ( ics_cmpl_schd_viol_id
        , ics_enfrc_actn_viol_lnk_id
        , ics_final_order_viol_lnk_id
        , enfrc_actn_ident
        , final_order_ident
        , prmt_ident
        , cmpl_schd_num
        , schd_evt_code
        , schd_date
        , data_hash)
   SELECT ics_cmpl_schd_viol.ics_cmpl_schd_viol_id
        , ics_cmpl_schd_viol.ics_enfrc_actn_viol_lnk_id AS ics_enfrc_actn_viol_lnk_id
        , NULL AS ics_final_order_viol_lnk_id
        , ics_cmpl_schd_viol.enfrc_actn_ident AS enfrc_actn_ident
        , ics_cmpl_schd_viol.final_order_ident AS final_order_ident
        , ics_cmpl_schd_viol.prmt_ident AS prmt_ident
        , ics_cmpl_schd_viol.cmpl_schd_num AS cmpl_schd_num
        , ics_cmpl_schd_viol.schd_evt_code AS schd_evt_code
        , ics_cmpl_schd_viol.schd_date AS schd_date
        , ics_cmpl_schd_viol.data_hash AS data_hash
    FROM ics_flow_icis.ics_cmpl_schd_viol ics_cmpl_schd_viol 
   JOIN ics_flow_icis.ics_enfrc_actn_viol_lnk ieav
     ON ieav.ics_enfrc_actn_viol_lnk_id = ics_cmpl_schd_viol.ics_enfrc_actn_viol_lnk_id    
   JOIN ICS_KEY_HASH KH on KH.KEY_HASH = ieav.KEY_HASH
   ;

  /*
   * ICS_DSCH_MON_REP_VIOL
   */
   INSERT INTO ics_dsch_mon_rep_viol
       ( ics_dsch_mon_rep_viol_id
       , ics_enfrc_actn_viol_lnk_id
       , ics_final_order_viol_lnk_id
       , prmt_ident
       , prmt_featr_ident
       , lmt_set_designator
       , mon_period_end_date
       , data_hash)
  SELECT ics_dsch_mon_rep_viol.ics_dsch_mon_rep_viol_id
       , ics_dsch_mon_rep_viol.ics_enfrc_actn_viol_lnk_id AS ics_enfrc_actn_viol_lnk_id
       , NULL AS ics_final_order_viol_lnk_id
       , ics_dsch_mon_rep_viol.prmt_ident AS prmt_ident
       , ics_dsch_mon_rep_viol.prmt_featr_ident AS prmt_featr_ident
       , ics_dsch_mon_rep_viol.lmt_set_designator AS lmt_set_designator
       , ics_dsch_mon_rep_viol.mon_period_end_date AS mon_period_end_date
       , ics_dsch_mon_rep_viol.data_hash AS data_hash
   FROM ics_flow_icis.ics_dsch_mon_rep_viol ics_dsch_mon_rep_viol
   JOIN ics_flow_icis.ics_enfrc_actn_viol_lnk ieav
     ON ieav.ics_enfrc_actn_viol_lnk_id = ics_dsch_mon_rep_viol.ics_enfrc_actn_viol_lnk_id    
   JOIN ICS_KEY_HASH KH on KH.KEY_HASH = ieav.KEY_HASH
   ;    
          


   
  /*
   * ICS_DSCH_MON_REP_PARAM_VIOL
   */
   INSERT INTO ics_dsch_mon_rep_param_viol
        ( ics_dsch_mon_rep_param_viol_id
        , ics_enfrc_actn_viol_lnk_id
        , ics_final_order_viol_lnk_id
        , prmt_ident
        , prmt_featr_ident
        , lmt_set_designator
        , mon_period_end_date
        , param_code
        , mon_site_desc_code
        , lmt_season_num
        , data_hash)
   SELECT ics_dsch_mon_rep_param_viol.ics_dsch_mon_rep_param_viol_id
        , ics_dsch_mon_rep_param_viol.ics_enfrc_actn_viol_lnk_id AS ics_enfrc_actn_viol_lnk_id
        , NULL AS ics_final_order_viol_lnk_id
        , ics_dsch_mon_rep_param_viol.prmt_ident AS prmt_ident
        , ics_dsch_mon_rep_param_viol.prmt_featr_ident AS prmt_featr_ident
        , ics_dsch_mon_rep_param_viol.lmt_set_designator AS lmt_set_designator
        , ics_dsch_mon_rep_param_viol.mon_period_end_date AS mon_period_end_date
        , ics_dsch_mon_rep_param_viol.param_code AS param_code
        , ics_dsch_mon_rep_param_viol.mon_site_desc_code AS mon_site_desc_code
        , ics_dsch_mon_rep_param_viol.lmt_season_num AS lmt_season_num
        , ics_dsch_mon_rep_param_viol.data_hash AS data_hash
    FROM ics_flow_icis.ics_dsch_mon_rep_param_viol ics_dsch_mon_rep_param_viol
   JOIN ics_flow_icis.ics_enfrc_actn_viol_lnk ieav
     ON ieav.ics_enfrc_actn_viol_lnk_id = ics_dsch_mon_rep_param_viol.ics_enfrc_actn_viol_lnk_id    
   JOIN ICS_KEY_HASH KH on KH.KEY_HASH = ieav.KEY_HASH
   ;

  /*
   * ICS_SNGL_EVTS_VIOL 
   */
   INSERT INTO ics_sngl_evts_viol
        ( ics_sngl_evts_viol_id
        , ics_enfrc_actn_viol_lnk_id
        , ics_final_order_viol_lnk_id
        , prmt_ident
        , sngl_evt_viol_code
        , sngl_evt_viol_date
        , data_hash)
   SELECT ics_sngl_evts_viol.ics_sngl_evts_viol_id
        , ics_sngl_evts_viol.ics_enfrc_actn_viol_lnk_id AS ics_enfrc_actn_viol_lnk_id
        , NULL AS ics_final_order_viol_lnk_id
        , ics_sngl_evts_viol.prmt_ident AS prmt_ident
        , ics_sngl_evts_viol.sngl_evt_viol_code AS sngl_evt_viol_code
        , ics_sngl_evts_viol.sngl_evt_viol_date AS sngl_evt_viol_date
        , ics_sngl_evts_viol.data_hash AS data_hash
    FROM ics_flow_icis.ics_sngl_evts_viol ics_sngl_evts_viol
   JOIN ics_flow_icis.ics_enfrc_actn_viol_lnk ieav
     ON ieav.ics_enfrc_actn_viol_lnk_id = ics_sngl_evts_viol.ics_enfrc_actn_viol_lnk_id    
   JOIN ICS_KEY_HASH KH on KH.KEY_HASH = ieav.KEY_HASH
   ;



-- ------------------------------
-- ICS_SCHD_EVT_VIOL
-- ------------------------------

delete from ICS_KEY_HASH;

insert into ICS_KEY_HASH
select KEY_HASH from ics_flow_icis.ICS_SCHD_EVT_VIOL ICS_SCHD_EVT_VIOL
      where  ICS_SCHD_EVT_VIOL.KEY_HASH not in (select KEY_HASH from ics_flow_local.ICS_SCHD_EVT_VIOL)
      and exists (select 1 from ICS_PAYLOAD where OPERATION = 'ScheduleEventViolationSubmission' and ENABLED = 'Y' and AUTO_GEN_DELETES = 'Y')
      ;


insert into ICS_SCHD_EVT_VIOL
      ( ICS_SCHD_EVT_VIOL_id
      , ics_payload_id
      , src_systm_ident
      , transaction_type
      , transaction_timestamp
      , key_hash
      , data_hash)
 SELECT ICS_SCHD_EVT_VIOL.ICS_SCHD_EVT_VIOL_ID AS ICS_SCHD_EVT_VIOL_ID
      , (SELECT ics_payload_id
           FROM ics_payload 
          WHERE operation = 'ScheduleEventViolationSubmission') AS ics_payload_id
      , ICS_SCHD_EVT_VIOL.src_systm_ident AS src_systm_ident
      , 'x' AS transaction_type
      , ICS_SCHD_EVT_VIOL.transaction_timestamp AS transaction_timestamp
      , NULL AS key_hash
      , NULL AS data_hash
   FROM ics_flow_icis.ICS_SCHD_EVT_VIOL ICS_SCHD_EVT_VIOL     	  
 JOIN ICS_KEY_HASH KH on KH.KEY_HASH = ICS_SCHD_EVT_VIOL.KEY_HASH;





INSERT INTO ICS_PRMT_SCHD_EVT_VIOL_ELEM
           (ICS_PRMT_SCHD_EVT_VIOL_ELEM_ID
           ,ICS_SCHD_EVT_VIOL_ID
           ,PRMT_IDENT
           ,NARR_COND_NUM
           ,SCHD_EVT_CODE
           ,SCHD_DATE
           ,SCHD_VIOL_CODE
           )
select
ICS_PRMT_SCHD_EVT_VIOL_ELEM.ICS_PRMT_SCHD_EVT_VIOL_ELEM_ID
           ,ICS_PRMT_SCHD_EVT_VIOL_ELEM.ICS_SCHD_EVT_VIOL_ID
           ,PRMT_IDENT
           ,NARR_COND_NUM
           ,SCHD_EVT_CODE
           ,SCHD_DATE
           ,SCHD_VIOL_CODE
           from ics_flow_icis.ICS_PRMT_SCHD_EVT_VIOL_ELEM ICS_PRMT_SCHD_EVT_VIOL_ELEM
           join ics_flow_icis.ICS_SCHD_EVT_VIOL SEV on SEV.ICS_SCHD_EVT_VIOL_ID = ICS_PRMT_SCHD_EVT_VIOL_ELEM.ICS_SCHD_EVT_VIOL_ID
           join ICS_KEY_HASH kh on kh.KEY_HASH = SEV.key_hash
;






INSERT INTO ICS_CMPL_SCHD_EVT_VIOL_ELEM
           (
           ICS_CMPL_SCHD_EVT_VIOL_ELEM_ID
           ,ICS_SCHD_EVT_VIOL_ID
           ,ENFRC_ACTN_IDENT
           ,FINAL_ORDER_IDENT
           ,PRMT_IDENT
           ,CMPL_SCHD_NUM
           ,SCHD_EVT_CODE
           ,SCHD_DATE
           ,SCHD_VIOL_CODE
           )
select
           ICS_CMPL_SCHD_EVT_VIOL_ELEM.ICS_CMPL_SCHD_EVT_VIOL_ELEM_ID
           ,ICS_CMPL_SCHD_EVT_VIOL_ELEM.ICS_SCHD_EVT_VIOL_ID
           ,ENFRC_ACTN_IDENT
           ,FINAL_ORDER_IDENT
           ,PRMT_IDENT
           ,CMPL_SCHD_NUM
           ,SCHD_EVT_CODE
           ,SCHD_DATE
           ,SCHD_VIOL_CODE
    from ics_flow_icis.ICS_CMPL_SCHD_EVT_VIOL_ELEM 
           join ics_flow_icis.ICS_SCHD_EVT_VIOL SEV on SEV.ICS_SCHD_EVT_VIOL_ID = ICS_CMPL_SCHD_EVT_VIOL_ELEM.ICS_SCHD_EVT_VIOL_ID
           join ICS_KEY_HASH kh on kh.KEY_HASH = SEV.key_hash
    ;



-- ------------------
-- END  Deletes
-- ------------------

     UPDATE ICS_BASIC_PRMT
	 SET TRANSACTION_TYPE = NULL
	 WHERE EXISTS (SELECT 1 
					 FROM ICS_PRMT_REISSU R 
					WHERE R.TRANSACTION_TYPE IS NOT NULL
					  AND R.PRMT_IDENT = ICS_BASIC_PRMT.PRMT_IDENT
					  AND R.PRMT_EFFECTIVE_DATE > ICS_BASIC_PRMT.PRMT_EFFECTIVE_DATE)
	AND ICS_BASIC_PRMT.TRANSACTION_TYPE IS NOT NULL
;
	 UPDATE ICS_GNRL_PRMT
	 SET TRANSACTION_TYPE = NULL
	 WHERE EXISTS (SELECT 1 
					 FROM ICS_PRMT_REISSU R 
					WHERE R.TRANSACTION_TYPE IS NOT NULL
					  AND R.PRMT_IDENT = ICS_GNRL_PRMT.PRMT_IDENT
					  AND R.PRMT_EFFECTIVE_DATE > ICS_GNRL_PRMT.PRMT_EFFECTIVE_DATE)
	  AND ICS_GNRL_PRMT.TRANSACTION_TYPE IS NOT NULL
;


   COMMIT;
   
 EXCEPTION
   WHEN OTHERS THEN
     ROLLBACK;
     RAISE;
     
 END;

