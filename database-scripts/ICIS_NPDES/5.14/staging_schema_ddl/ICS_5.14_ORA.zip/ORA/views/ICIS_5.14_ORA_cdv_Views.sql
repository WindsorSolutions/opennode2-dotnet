

/*******************************************
**                                        **
**  View Set #1:  Change Detection Views  **
**                                        **
*******************************************/



/*************************************************************************************************
** ObjectName: cdv_basic_prmt
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/09/2025   Windsor      recreated for 5.14 baseline.
**
***************************************************************************************************/

CREATE OR REPLACE VIEW cdv_basic_prmt AS 
SELECT DISTINCT ics_module
, ICS_BASIC_PRMT.key_hash
     , CASE ICS_BASIC_PRMT.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ICS_BASIC_PRMT tbl
                  WHERE tbl.ICS_BASIC_PRMT_id = ICS_BASIC_PRMT.ICS_BASIC_PRMT_id)
           ELSE (SELECT key_hash 
                   FROM ICS_BASIC_PRMT tbl
                  WHERE tbl.ICS_BASIC_PRMT_id = ICS_BASIC_PRMT.ICS_BASIC_PRMT_id)
       END AS module_ident
     , ICS_BASIC_PRMT.action_type
     , ICS_BASIC_PRMT.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_BASIC_PRMT.ICS_BASIC_PRMT_id
             , ICS_BASIC_PRMT.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_BASIC_PRMT' as ics_module
          FROM ICS_BASIC_PRMT
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ICS_BASIC_PRMT tbl
                            WHERE tbl.key_hash = ICS_BASIC_PRMT.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_BASIC_PRMT_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_BASIC_PRMT' as ics_module
          FROM ICS_BASIC_PRMT local
          JOIN ics_flow_icis.ICS_BASIC_PRMT icis
            ON (    icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ICS_BASIC_PRMT.ICS_BASIC_PRMT_id
             , ICS_BASIC_PRMT.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_BASIC_PRMT' as ics_module
          FROM ics_flow_icis.ICS_BASIC_PRMT
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ICS_BASIC_PRMT tbl
                            WHERE tbl.key_hash = ICS_BASIC_PRMT.key_hash)) ICS_BASIC_PRMT;





/*************************************************************************************************
** ObjectName: cdv_bs_annul_prog_rep
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/09/2025   Windsor      recreated for 5.14 baseline.
**
***************************************************************************************************/

CREATE OR REPLACE VIEW cdv_bs_annul_prog_rep AS 
SELECT DISTINCT ics_module
, ICS_BS_ANNUL_PROG_REP.key_hash
     , CASE ICS_BS_ANNUL_PROG_REP.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ICS_BS_ANNUL_PROG_REP tbl
                  WHERE tbl.ICS_BS_ANNUL_PROG_REP_id = ICS_BS_ANNUL_PROG_REP.ICS_BS_ANNUL_PROG_REP_id)
           ELSE (SELECT key_hash 
                   FROM ICS_BS_ANNUL_PROG_REP tbl
                  WHERE tbl.ICS_BS_ANNUL_PROG_REP_id = ICS_BS_ANNUL_PROG_REP.ICS_BS_ANNUL_PROG_REP_id)
       END AS module_ident
     , ICS_BS_ANNUL_PROG_REP.action_type
     , ICS_BS_ANNUL_PROG_REP.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_BS_ANNUL_PROG_REP.ICS_BS_ANNUL_PROG_REP_id
             , ICS_BS_ANNUL_PROG_REP.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_BS_ANNUL_PROG_REP' as ics_module
          FROM ICS_BS_ANNUL_PROG_REP
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ICS_BS_ANNUL_PROG_REP tbl
                            WHERE tbl.key_hash = ICS_BS_ANNUL_PROG_REP.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_BS_ANNUL_PROG_REP_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_BS_ANNUL_PROG_REP' as ics_module
          FROM ICS_BS_ANNUL_PROG_REP local
          JOIN ics_flow_icis.ICS_BS_ANNUL_PROG_REP icis
            ON (    icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ICS_BS_ANNUL_PROG_REP.ICS_BS_ANNUL_PROG_REP_id
             , ICS_BS_ANNUL_PROG_REP.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_BS_ANNUL_PROG_REP' as ics_module
          FROM ics_flow_icis.ICS_BS_ANNUL_PROG_REP
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ICS_BS_ANNUL_PROG_REP tbl
                            WHERE tbl.key_hash = ICS_BS_ANNUL_PROG_REP.key_hash)) ICS_BS_ANNUL_PROG_REP;





/*************************************************************************************************
** ObjectName: cdv_bs_prmt
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/09/2025   Windsor      recreated for 5.14 baseline.
**
***************************************************************************************************/

CREATE OR REPLACE VIEW cdv_bs_prmt AS 
SELECT DISTINCT ics_module
, ICS_BS_PRMT.key_hash
     , CASE ICS_BS_PRMT.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ICS_BS_PRMT tbl
                  WHERE tbl.ICS_BS_PRMT_id = ICS_BS_PRMT.ICS_BS_PRMT_id)
           ELSE (SELECT key_hash 
                   FROM ICS_BS_PRMT tbl
                  WHERE tbl.ICS_BS_PRMT_id = ICS_BS_PRMT.ICS_BS_PRMT_id)
       END AS module_ident
     , ICS_BS_PRMT.action_type
     , ICS_BS_PRMT.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_BS_PRMT.ICS_BS_PRMT_id
             , ICS_BS_PRMT.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_BS_PRMT' as ics_module
          FROM ICS_BS_PRMT
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ICS_BS_PRMT tbl
                            WHERE tbl.key_hash = ICS_BS_PRMT.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_BS_PRMT_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_BS_PRMT' as ics_module
          FROM ICS_BS_PRMT local
          JOIN ics_flow_icis.ICS_BS_PRMT icis
            ON (    icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ICS_BS_PRMT.ICS_BS_PRMT_id
             , ICS_BS_PRMT.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_BS_PRMT' as ics_module
          FROM ics_flow_icis.ICS_BS_PRMT
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ICS_BS_PRMT tbl
                            WHERE tbl.key_hash = ICS_BS_PRMT.key_hash)) ICS_BS_PRMT;





/*************************************************************************************************
** ObjectName: cdv_cafo_annul_prog_rep
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/09/2025   Windsor      recreated for 5.14 baseline.
**
***************************************************************************************************/

CREATE OR REPLACE VIEW cdv_cafo_annul_prog_rep AS 
SELECT DISTINCT ics_module
, ICS_CAFO_ANNUL_PROG_REP.key_hash
     , CASE ICS_CAFO_ANNUL_PROG_REP.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ICS_CAFO_ANNUL_PROG_REP tbl
                  WHERE tbl.ICS_CAFO_ANNUL_PROG_REP_id = ICS_CAFO_ANNUL_PROG_REP.ICS_CAFO_ANNUL_PROG_REP_id)
           ELSE (SELECT key_hash 
                   FROM ICS_CAFO_ANNUL_PROG_REP tbl
                  WHERE tbl.ICS_CAFO_ANNUL_PROG_REP_id = ICS_CAFO_ANNUL_PROG_REP.ICS_CAFO_ANNUL_PROG_REP_id)
       END AS module_ident
     , ICS_CAFO_ANNUL_PROG_REP.action_type
     , ICS_CAFO_ANNUL_PROG_REP.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_CAFO_ANNUL_PROG_REP.ICS_CAFO_ANNUL_PROG_REP_id
             , ICS_CAFO_ANNUL_PROG_REP.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_CAFO_ANNUL_PROG_REP' as ics_module
          FROM ICS_CAFO_ANNUL_PROG_REP
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ICS_CAFO_ANNUL_PROG_REP tbl
                            WHERE tbl.key_hash = ICS_CAFO_ANNUL_PROG_REP.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_CAFO_ANNUL_PROG_REP_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_CAFO_ANNUL_PROG_REP' as ics_module
          FROM ICS_CAFO_ANNUL_PROG_REP local
          JOIN ics_flow_icis.ICS_CAFO_ANNUL_PROG_REP icis
            ON (    icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ICS_CAFO_ANNUL_PROG_REP.ICS_CAFO_ANNUL_PROG_REP_id
             , ICS_CAFO_ANNUL_PROG_REP.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_CAFO_ANNUL_PROG_REP' as ics_module
          FROM ics_flow_icis.ICS_CAFO_ANNUL_PROG_REP
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ICS_CAFO_ANNUL_PROG_REP tbl
                            WHERE tbl.key_hash = ICS_CAFO_ANNUL_PROG_REP.key_hash)) ICS_CAFO_ANNUL_PROG_REP;





/*************************************************************************************************
** ObjectName: cdv_cafo_prmt
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/09/2025   Windsor      recreated for 5.14 baseline.
**
***************************************************************************************************/

CREATE OR REPLACE VIEW cdv_cafo_prmt AS 
SELECT DISTINCT ics_module
, ICS_CAFO_PRMT.key_hash
     , CASE ICS_CAFO_PRMT.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ICS_CAFO_PRMT tbl
                  WHERE tbl.ICS_CAFO_PRMT_id = ICS_CAFO_PRMT.ICS_CAFO_PRMT_id)
           ELSE (SELECT key_hash 
                   FROM ICS_CAFO_PRMT tbl
                  WHERE tbl.ICS_CAFO_PRMT_id = ICS_CAFO_PRMT.ICS_CAFO_PRMT_id)
       END AS module_ident
     , ICS_CAFO_PRMT.action_type
     , ICS_CAFO_PRMT.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_CAFO_PRMT.ICS_CAFO_PRMT_id
             , ICS_CAFO_PRMT.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_CAFO_PRMT' as ics_module
          FROM ICS_CAFO_PRMT
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ICS_CAFO_PRMT tbl
                            WHERE tbl.key_hash = ICS_CAFO_PRMT.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_CAFO_PRMT_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_CAFO_PRMT' as ics_module
          FROM ICS_CAFO_PRMT local
          JOIN ics_flow_icis.ICS_CAFO_PRMT icis
            ON (    icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ICS_CAFO_PRMT.ICS_CAFO_PRMT_id
             , ICS_CAFO_PRMT.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_CAFO_PRMT' as ics_module
          FROM ics_flow_icis.ICS_CAFO_PRMT
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ICS_CAFO_PRMT tbl
                            WHERE tbl.key_hash = ICS_CAFO_PRMT.key_hash)) ICS_CAFO_PRMT;





/*************************************************************************************************
** ObjectName: cdv_coll_systm_prmt
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/09/2025   Windsor      recreated for 5.14 baseline.
**
***************************************************************************************************/

CREATE OR REPLACE VIEW cdv_coll_systm_prmt AS 
SELECT DISTINCT ics_module
, ICS_COLL_SYSTM_PRMT.key_hash
     , CASE ICS_COLL_SYSTM_PRMT.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ICS_COLL_SYSTM_PRMT tbl
                  WHERE tbl.ICS_COLL_SYSTM_PRMT_id = ICS_COLL_SYSTM_PRMT.ICS_COLL_SYSTM_PRMT_id)
           ELSE (SELECT key_hash 
                   FROM ICS_COLL_SYSTM_PRMT tbl
                  WHERE tbl.ICS_COLL_SYSTM_PRMT_id = ICS_COLL_SYSTM_PRMT.ICS_COLL_SYSTM_PRMT_id)
       END AS module_ident
     , ICS_COLL_SYSTM_PRMT.action_type
     , ICS_COLL_SYSTM_PRMT.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_COLL_SYSTM_PRMT.ICS_COLL_SYSTM_PRMT_id
             , ICS_COLL_SYSTM_PRMT.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_COLL_SYSTM_PRMT' as ics_module
          FROM ICS_COLL_SYSTM_PRMT
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ICS_COLL_SYSTM_PRMT tbl
                            WHERE tbl.key_hash = ICS_COLL_SYSTM_PRMT.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_COLL_SYSTM_PRMT_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_COLL_SYSTM_PRMT' as ics_module
          FROM ICS_COLL_SYSTM_PRMT local
          JOIN ics_flow_icis.ICS_COLL_SYSTM_PRMT icis
            ON (    icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ICS_COLL_SYSTM_PRMT.ICS_COLL_SYSTM_PRMT_id
             , ICS_COLL_SYSTM_PRMT.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_COLL_SYSTM_PRMT' as ics_module
          FROM ics_flow_icis.ICS_COLL_SYSTM_PRMT
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ICS_COLL_SYSTM_PRMT tbl
                            WHERE tbl.key_hash = ICS_COLL_SYSTM_PRMT.key_hash)) ICS_COLL_SYSTM_PRMT;





/*************************************************************************************************
** ObjectName: cdv_cmpl_mon
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/09/2025   Windsor      recreated for 5.14 baseline.
**
***************************************************************************************************/

CREATE OR REPLACE VIEW cdv_cmpl_mon AS 
SELECT DISTINCT ics_module
, ICS_CMPL_MON.key_hash
     , CASE ICS_CMPL_MON.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ICS_CMPL_MON tbl
                  WHERE tbl.ICS_CMPL_MON_id = ICS_CMPL_MON.ICS_CMPL_MON_id)
           ELSE (SELECT key_hash 
                   FROM ICS_CMPL_MON tbl
                  WHERE tbl.ICS_CMPL_MON_id = ICS_CMPL_MON.ICS_CMPL_MON_id)
       END AS module_ident
     , ICS_CMPL_MON.action_type
     , ICS_CMPL_MON.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_CMPL_MON.ICS_CMPL_MON_id
             , ICS_CMPL_MON.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_CMPL_MON' as ics_module
          FROM ICS_CMPL_MON
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ICS_CMPL_MON tbl
                            WHERE tbl.key_hash = ICS_CMPL_MON.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_CMPL_MON_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_CMPL_MON' as ics_module
          FROM ICS_CMPL_MON local
          JOIN ics_flow_icis.ICS_CMPL_MON icis
            ON (    icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ICS_CMPL_MON.ICS_CMPL_MON_id
             , ICS_CMPL_MON.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_CMPL_MON' as ics_module
          FROM ics_flow_icis.ICS_CMPL_MON
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ICS_CMPL_MON tbl
                            WHERE tbl.key_hash = ICS_CMPL_MON.key_hash)) ICS_CMPL_MON;





/*************************************************************************************************
** ObjectName: cdv_cmpl_mon_lnk
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/09/2025   Windsor      recreated for 5.14 baseline.
**
***************************************************************************************************/

CREATE OR REPLACE VIEW cdv_cmpl_mon_lnk AS 
SELECT DISTINCT ics_module
, ICS_CMPL_MON_LNK.key_hash
     , CASE ICS_CMPL_MON_LNK.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ICS_CMPL_MON_LNK tbl
                  WHERE tbl.ICS_CMPL_MON_LNK_id = ICS_CMPL_MON_LNK.ICS_CMPL_MON_LNK_id)
           ELSE (SELECT key_hash 
                   FROM ICS_CMPL_MON_LNK tbl
                  WHERE tbl.ICS_CMPL_MON_LNK_id = ICS_CMPL_MON_LNK.ICS_CMPL_MON_LNK_id)
       END AS module_ident
     , ICS_CMPL_MON_LNK.action_type
     , ICS_CMPL_MON_LNK.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_CMPL_MON_LNK.ICS_CMPL_MON_LNK_id
             , ICS_CMPL_MON_LNK.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_CMPL_MON_LNK' as ics_module
          FROM ICS_CMPL_MON_LNK
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ICS_CMPL_MON_LNK tbl
                            WHERE tbl.key_hash = ICS_CMPL_MON_LNK.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_CMPL_MON_LNK_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_CMPL_MON_LNK' as ics_module
          FROM ICS_CMPL_MON_LNK local
          JOIN ics_flow_icis.ICS_CMPL_MON_LNK icis
            ON (    icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ICS_CMPL_MON_LNK.ICS_CMPL_MON_LNK_id
             , ICS_CMPL_MON_LNK.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_CMPL_MON_LNK' as ics_module
          FROM ics_flow_icis.ICS_CMPL_MON_LNK
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ICS_CMPL_MON_LNK tbl
                            WHERE tbl.key_hash = ICS_CMPL_MON_LNK.key_hash)) ICS_CMPL_MON_LNK;





/*************************************************************************************************
** ObjectName: cdv_cmpl_schd
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/09/2025   Windsor      recreated for 5.14 baseline.
**
***************************************************************************************************/

CREATE OR REPLACE VIEW cdv_cmpl_schd AS 
SELECT DISTINCT ics_module
, ICS_CMPL_SCHD.key_hash
     , CASE ICS_CMPL_SCHD.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ICS_CMPL_SCHD tbl
                  WHERE tbl.ICS_CMPL_SCHD_id = ICS_CMPL_SCHD.ICS_CMPL_SCHD_id)
           ELSE (SELECT key_hash 
                   FROM ICS_CMPL_SCHD tbl
                  WHERE tbl.ICS_CMPL_SCHD_id = ICS_CMPL_SCHD.ICS_CMPL_SCHD_id)
       END AS module_ident
     , ICS_CMPL_SCHD.action_type
     , ICS_CMPL_SCHD.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_CMPL_SCHD.ICS_CMPL_SCHD_id
             , ICS_CMPL_SCHD.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_CMPL_SCHD' as ics_module
          FROM ICS_CMPL_SCHD
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ICS_CMPL_SCHD tbl
                            WHERE tbl.key_hash = ICS_CMPL_SCHD.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_CMPL_SCHD_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_CMPL_SCHD' as ics_module
          FROM ICS_CMPL_SCHD local
          JOIN ics_flow_icis.ICS_CMPL_SCHD icis
            ON (    icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ICS_CMPL_SCHD.ICS_CMPL_SCHD_id
             , ICS_CMPL_SCHD.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_CMPL_SCHD' as ics_module
          FROM ics_flow_icis.ICS_CMPL_SCHD
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ICS_CMPL_SCHD tbl
                            WHERE tbl.key_hash = ICS_CMPL_SCHD.key_hash)) ICS_CMPL_SCHD;





/*************************************************************************************************
** ObjectName: cdv_copy_mgp_lmt_set
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/09/2025   Windsor      recreated for 5.14 baseline.
**
***************************************************************************************************/

CREATE OR REPLACE VIEW cdv_copy_mgp_lmt_set AS 
SELECT DISTINCT ics_module
, ICS_COPY_MGP_LMT_SET.key_hash
     , CASE ICS_COPY_MGP_LMT_SET.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ICS_COPY_MGP_LMT_SET tbl
                  WHERE tbl.ICS_COPY_MGP_LMT_SET_id = ICS_COPY_MGP_LMT_SET.ICS_COPY_MGP_LMT_SET_id)
           ELSE (SELECT key_hash 
                   FROM ICS_COPY_MGP_LMT_SET tbl
                  WHERE tbl.ICS_COPY_MGP_LMT_SET_id = ICS_COPY_MGP_LMT_SET.ICS_COPY_MGP_LMT_SET_id)
       END AS module_ident
     , ICS_COPY_MGP_LMT_SET.action_type
     , ICS_COPY_MGP_LMT_SET.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_COPY_MGP_LMT_SET.ICS_COPY_MGP_LMT_SET_id
             , ICS_COPY_MGP_LMT_SET.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_COPY_MGP_LMT_SET' as ics_module
          FROM ICS_COPY_MGP_LMT_SET
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ICS_COPY_MGP_LMT_SET tbl
                            WHERE tbl.key_hash = ICS_COPY_MGP_LMT_SET.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_COPY_MGP_LMT_SET_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_COPY_MGP_LMT_SET' as ics_module
          FROM ICS_COPY_MGP_LMT_SET local
          JOIN ics_flow_icis.ICS_COPY_MGP_LMT_SET icis
            ON (    icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ICS_COPY_MGP_LMT_SET.ICS_COPY_MGP_LMT_SET_id
             , ICS_COPY_MGP_LMT_SET.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_COPY_MGP_LMT_SET' as ics_module
          FROM ics_flow_icis.ICS_COPY_MGP_LMT_SET
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ICS_COPY_MGP_LMT_SET tbl
                            WHERE tbl.key_hash = ICS_COPY_MGP_LMT_SET.key_hash)) ICS_COPY_MGP_LMT_SET;





/*************************************************************************************************
** ObjectName: cdv_copy_mgpms_4_req
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/09/2025   Windsor      recreated for 5.14 baseline.
**
***************************************************************************************************/

CREATE OR REPLACE VIEW cdv_copy_mgpms_4_req AS 
SELECT DISTINCT ics_module
, ICS_COPY_MGPMS_4_REQ.key_hash
     , CASE ICS_COPY_MGPMS_4_REQ.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ICS_COPY_MGPMS_4_REQ tbl
                  WHERE tbl.ICS_COPY_MGPMS_4_REQ_id = ICS_COPY_MGPMS_4_REQ.ICS_COPY_MGPMS_4_REQ_id)
           ELSE (SELECT key_hash 
                   FROM ICS_COPY_MGPMS_4_REQ tbl
                  WHERE tbl.ICS_COPY_MGPMS_4_REQ_id = ICS_COPY_MGPMS_4_REQ.ICS_COPY_MGPMS_4_REQ_id)
       END AS module_ident
     , ICS_COPY_MGPMS_4_REQ.action_type
     , ICS_COPY_MGPMS_4_REQ.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_COPY_MGPMS_4_REQ.ICS_COPY_MGPMS_4_REQ_id
             , ICS_COPY_MGPMS_4_REQ.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_COPY_MGPMS_4_REQ' as ics_module
          FROM ICS_COPY_MGPMS_4_REQ
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ICS_COPY_MGPMS_4_REQ tbl
                            WHERE tbl.key_hash = ICS_COPY_MGPMS_4_REQ.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_COPY_MGPMS_4_REQ_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_COPY_MGPMS_4_REQ' as ics_module
          FROM ICS_COPY_MGPMS_4_REQ local
          JOIN ics_flow_icis.ICS_COPY_MGPMS_4_REQ icis
            ON (    icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ICS_COPY_MGPMS_4_REQ.ICS_COPY_MGPMS_4_REQ_id
             , ICS_COPY_MGPMS_4_REQ.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_COPY_MGPMS_4_REQ' as ics_module
          FROM ics_flow_icis.ICS_COPY_MGPMS_4_REQ
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ICS_COPY_MGPMS_4_REQ tbl
                            WHERE tbl.key_hash = ICS_COPY_MGPMS_4_REQ.key_hash)) ICS_COPY_MGPMS_4_REQ;





/*************************************************************************************************
** ObjectName: cdv_cso_long_term_control_plan
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/09/2025   Windsor      recreated for 5.14 baseline.
**
***************************************************************************************************/

CREATE OR REPLACE VIEW cdv_cso_long_term_control_plan AS 
SELECT DISTINCT ics_module
, ICS_CSO_LONG_TERM_CONTROL_PLAN.key_hash
     , CASE ICS_CSO_LONG_TERM_CONTROL_PLAN.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ICS_CSO_LONG_TERM_CONTROL_PLAN tbl
                  WHERE tbl.ICS_CSO_LONG_TERM_CONTROL_PLAN_id = ICS_CSO_LONG_TERM_CONTROL_PLAN.ICS_CSO_LONG_TERM_CONTROL_PLAN_id)
           ELSE (SELECT key_hash 
                   FROM ICS_CSO_LONG_TERM_CONTROL_PLAN tbl
                  WHERE tbl.ICS_CSO_LONG_TERM_CONTROL_PLAN_id = ICS_CSO_LONG_TERM_CONTROL_PLAN.ICS_CSO_LONG_TERM_CONTROL_PLAN_id)
       END AS module_ident
     , ICS_CSO_LONG_TERM_CONTROL_PLAN.action_type
     , ICS_CSO_LONG_TERM_CONTROL_PLAN.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_CSO_LONG_TERM_CONTROL_PLAN.ICS_CSO_LONG_TERM_CONTROL_PLAN_id
             , ICS_CSO_LONG_TERM_CONTROL_PLAN.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_CSO_LONG_TERM_CONTROL_PLAN' as ics_module
          FROM ICS_CSO_LONG_TERM_CONTROL_PLAN
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ICS_CSO_LONG_TERM_CONTROL_PLAN tbl
                            WHERE tbl.key_hash = ICS_CSO_LONG_TERM_CONTROL_PLAN.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_CSO_LONG_TERM_CONTROL_PLAN_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_CSO_LONG_TERM_CONTROL_PLAN' as ics_module
          FROM ICS_CSO_LONG_TERM_CONTROL_PLAN local
          JOIN ics_flow_icis.ICS_CSO_LONG_TERM_CONTROL_PLAN icis
            ON (    icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ICS_CSO_LONG_TERM_CONTROL_PLAN.ICS_CSO_LONG_TERM_CONTROL_PLAN_id
             , ICS_CSO_LONG_TERM_CONTROL_PLAN.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_CSO_LONG_TERM_CONTROL_PLAN' as ics_module
          FROM ics_flow_icis.ICS_CSO_LONG_TERM_CONTROL_PLAN
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ICS_CSO_LONG_TERM_CONTROL_PLAN tbl
                            WHERE tbl.key_hash = ICS_CSO_LONG_TERM_CONTROL_PLAN.key_hash)) ICS_CSO_LONG_TERM_CONTROL_PLAN;





/*************************************************************************************************
** ObjectName: cdv_cwa_316b_prog_rep
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/09/2025   Windsor      recreated for 5.14 baseline.
**
***************************************************************************************************/

CREATE OR REPLACE VIEW cdv_cwa_316b_prog_rep AS 
SELECT DISTINCT ics_module
, ICS_CWA_316B_PROG_REP.key_hash
     , CASE ICS_CWA_316B_PROG_REP.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ICS_CWA_316B_PROG_REP tbl
                  WHERE tbl.ICS_CWA_316B_PROG_REP_id = ICS_CWA_316B_PROG_REP.ICS_CWA_316B_PROG_REP_id)
           ELSE (SELECT key_hash 
                   FROM ICS_CWA_316B_PROG_REP tbl
                  WHERE tbl.ICS_CWA_316B_PROG_REP_id = ICS_CWA_316B_PROG_REP.ICS_CWA_316B_PROG_REP_id)
       END AS module_ident
     , ICS_CWA_316B_PROG_REP.action_type
     , ICS_CWA_316B_PROG_REP.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_CWA_316B_PROG_REP.ICS_CWA_316B_PROG_REP_id
             , ICS_CWA_316B_PROG_REP.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_CWA_316B_PROG_REP' as ics_module
          FROM ICS_CWA_316B_PROG_REP
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ICS_CWA_316B_PROG_REP tbl
                            WHERE tbl.key_hash = ICS_CWA_316B_PROG_REP.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_CWA_316B_PROG_REP_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_CWA_316B_PROG_REP' as ics_module
          FROM ICS_CWA_316B_PROG_REP local
          JOIN ics_flow_icis.ICS_CWA_316B_PROG_REP icis
            ON (    icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ICS_CWA_316B_PROG_REP.ICS_CWA_316B_PROG_REP_id
             , ICS_CWA_316B_PROG_REP.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_CWA_316B_PROG_REP' as ics_module
          FROM ics_flow_icis.ICS_CWA_316B_PROG_REP
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ICS_CWA_316B_PROG_REP tbl
                            WHERE tbl.key_hash = ICS_CWA_316B_PROG_REP.key_hash)) ICS_CWA_316B_PROG_REP;





/*************************************************************************************************
** ObjectName: cdv_dsch_mon_rep
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/09/2025   Windsor      recreated for 5.14 baseline.
**
***************************************************************************************************/

CREATE OR REPLACE VIEW cdv_dsch_mon_rep AS 
SELECT DISTINCT ics_module
, ICS_DSCH_MON_REP.key_hash
     , CASE ICS_DSCH_MON_REP.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ICS_DSCH_MON_REP tbl
                  WHERE tbl.ICS_DSCH_MON_REP_id = ICS_DSCH_MON_REP.ICS_DSCH_MON_REP_id)
           ELSE (SELECT key_hash 
                   FROM ICS_DSCH_MON_REP tbl
                  WHERE tbl.ICS_DSCH_MON_REP_id = ICS_DSCH_MON_REP.ICS_DSCH_MON_REP_id)
       END AS module_ident
     , ICS_DSCH_MON_REP.action_type
     , ICS_DSCH_MON_REP.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_DSCH_MON_REP.ICS_DSCH_MON_REP_id
             , ICS_DSCH_MON_REP.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_DSCH_MON_REP' as ics_module
          FROM ICS_DSCH_MON_REP
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ICS_DSCH_MON_REP tbl
                            WHERE tbl.key_hash = ICS_DSCH_MON_REP.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_DSCH_MON_REP_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_DSCH_MON_REP' as ics_module
          FROM ICS_DSCH_MON_REP local
          JOIN ics_flow_icis.ICS_DSCH_MON_REP icis
            ON (    icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ICS_DSCH_MON_REP.ICS_DSCH_MON_REP_id
             , ICS_DSCH_MON_REP.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_DSCH_MON_REP' as ics_module
          FROM ics_flow_icis.ICS_DSCH_MON_REP
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ICS_DSCH_MON_REP tbl
                            WHERE tbl.key_hash = ICS_DSCH_MON_REP.key_hash)) ICS_DSCH_MON_REP;





/*************************************************************************************************
** ObjectName: cdv_dmr_viol
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/09/2025   Windsor      recreated for 5.14 baseline.
**
***************************************************************************************************/

CREATE OR REPLACE VIEW cdv_dmr_viol AS 
SELECT DISTINCT ics_module
, ICS_DMR_VIOL.key_hash
     , CASE ICS_DMR_VIOL.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ICS_DMR_VIOL tbl
                  WHERE tbl.ICS_DMR_VIOL_id = ICS_DMR_VIOL.ICS_DMR_VIOL_id)
           ELSE (SELECT key_hash 
                   FROM ICS_DMR_VIOL tbl
                  WHERE tbl.ICS_DMR_VIOL_id = ICS_DMR_VIOL.ICS_DMR_VIOL_id)
       END AS module_ident
     , ICS_DMR_VIOL.action_type
     , ICS_DMR_VIOL.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_DMR_VIOL.ICS_DMR_VIOL_id
             , ICS_DMR_VIOL.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_DMR_VIOL' as ics_module
          FROM ICS_DMR_VIOL
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ICS_DMR_VIOL tbl
                            WHERE tbl.key_hash = ICS_DMR_VIOL.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_DMR_VIOL_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_DMR_VIOL' as ics_module
          FROM ICS_DMR_VIOL local
          JOIN ics_flow_icis.ICS_DMR_VIOL icis
            ON (    icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ICS_DMR_VIOL.ICS_DMR_VIOL_id
             , ICS_DMR_VIOL.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_DMR_VIOL' as ics_module
          FROM ics_flow_icis.ICS_DMR_VIOL
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ICS_DMR_VIOL tbl
                            WHERE tbl.key_hash = ICS_DMR_VIOL.key_hash)) ICS_DMR_VIOL;





/*************************************************************************************************
** ObjectName: cdv_efflu_trade_prtner
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/09/2025   Windsor      recreated for 5.14 baseline.
**
***************************************************************************************************/

CREATE OR REPLACE VIEW cdv_efflu_trade_prtner AS 
SELECT DISTINCT ics_module
, ICS_EFFLU_TRADE_PRTNER.key_hash
     , CASE ICS_EFFLU_TRADE_PRTNER.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ICS_EFFLU_TRADE_PRTNER tbl
                  WHERE tbl.ICS_EFFLU_TRADE_PRTNER_id = ICS_EFFLU_TRADE_PRTNER.ICS_EFFLU_TRADE_PRTNER_id)
           ELSE (SELECT key_hash 
                   FROM ICS_EFFLU_TRADE_PRTNER tbl
                  WHERE tbl.ICS_EFFLU_TRADE_PRTNER_id = ICS_EFFLU_TRADE_PRTNER.ICS_EFFLU_TRADE_PRTNER_id)
       END AS module_ident
     , ICS_EFFLU_TRADE_PRTNER.action_type
     , ICS_EFFLU_TRADE_PRTNER.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_EFFLU_TRADE_PRTNER.ICS_EFFLU_TRADE_PRTNER_id
             , ICS_EFFLU_TRADE_PRTNER.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_EFFLU_TRADE_PRTNER' as ics_module
          FROM ICS_EFFLU_TRADE_PRTNER
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ICS_EFFLU_TRADE_PRTNER tbl
                            WHERE tbl.key_hash = ICS_EFFLU_TRADE_PRTNER.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_EFFLU_TRADE_PRTNER_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_EFFLU_TRADE_PRTNER' as ics_module
          FROM ICS_EFFLU_TRADE_PRTNER local
          JOIN ics_flow_icis.ICS_EFFLU_TRADE_PRTNER icis
            ON (    icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ICS_EFFLU_TRADE_PRTNER.ICS_EFFLU_TRADE_PRTNER_id
             , ICS_EFFLU_TRADE_PRTNER.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_EFFLU_TRADE_PRTNER' as ics_module
          FROM ics_flow_icis.ICS_EFFLU_TRADE_PRTNER
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ICS_EFFLU_TRADE_PRTNER tbl
                            WHERE tbl.key_hash = ICS_EFFLU_TRADE_PRTNER.key_hash)) ICS_EFFLU_TRADE_PRTNER;





/*************************************************************************************************
** ObjectName: cdv_enfrc_actn_milestone
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/09/2025   Windsor      recreated for 5.14 baseline.
**
***************************************************************************************************/

CREATE OR REPLACE VIEW cdv_enfrc_actn_milestone AS 
SELECT DISTINCT ics_module
, ICS_ENFRC_ACTN_MILESTONE.key_hash
     , CASE ICS_ENFRC_ACTN_MILESTONE.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ICS_ENFRC_ACTN_MILESTONE tbl
                  WHERE tbl.ICS_ENFRC_ACTN_MILESTONE_id = ICS_ENFRC_ACTN_MILESTONE.ICS_ENFRC_ACTN_MILESTONE_id)
           ELSE (SELECT key_hash 
                   FROM ICS_ENFRC_ACTN_MILESTONE tbl
                  WHERE tbl.ICS_ENFRC_ACTN_MILESTONE_id = ICS_ENFRC_ACTN_MILESTONE.ICS_ENFRC_ACTN_MILESTONE_id)
       END AS module_ident
     , ICS_ENFRC_ACTN_MILESTONE.action_type
     , ICS_ENFRC_ACTN_MILESTONE.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_ENFRC_ACTN_MILESTONE.ICS_ENFRC_ACTN_MILESTONE_id
             , ICS_ENFRC_ACTN_MILESTONE.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_ENFRC_ACTN_MILESTONE' as ics_module
          FROM ICS_ENFRC_ACTN_MILESTONE
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ICS_ENFRC_ACTN_MILESTONE tbl
                            WHERE tbl.key_hash = ICS_ENFRC_ACTN_MILESTONE.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_ENFRC_ACTN_MILESTONE_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_ENFRC_ACTN_MILESTONE' as ics_module
          FROM ICS_ENFRC_ACTN_MILESTONE local
          JOIN ics_flow_icis.ICS_ENFRC_ACTN_MILESTONE icis
            ON (    icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ICS_ENFRC_ACTN_MILESTONE.ICS_ENFRC_ACTN_MILESTONE_id
             , ICS_ENFRC_ACTN_MILESTONE.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_ENFRC_ACTN_MILESTONE' as ics_module
          FROM ics_flow_icis.ICS_ENFRC_ACTN_MILESTONE
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ICS_ENFRC_ACTN_MILESTONE tbl
                            WHERE tbl.key_hash = ICS_ENFRC_ACTN_MILESTONE.key_hash)) ICS_ENFRC_ACTN_MILESTONE;





/*************************************************************************************************
** ObjectName: cdv_enfrc_actn_viol_lnk
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/09/2025   Windsor      recreated for 5.14 baseline.
**
***************************************************************************************************/

CREATE OR REPLACE VIEW cdv_enfrc_actn_viol_lnk AS 
SELECT DISTINCT ics_module
, ICS_ENFRC_ACTN_VIOL_LNK.key_hash
     , CASE ICS_ENFRC_ACTN_VIOL_LNK.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ICS_ENFRC_ACTN_VIOL_LNK tbl
                  WHERE tbl.ICS_ENFRC_ACTN_VIOL_LNK_id = ICS_ENFRC_ACTN_VIOL_LNK.ICS_ENFRC_ACTN_VIOL_LNK_id)
           ELSE (SELECT key_hash 
                   FROM ICS_ENFRC_ACTN_VIOL_LNK tbl
                  WHERE tbl.ICS_ENFRC_ACTN_VIOL_LNK_id = ICS_ENFRC_ACTN_VIOL_LNK.ICS_ENFRC_ACTN_VIOL_LNK_id)
       END AS module_ident
     , ICS_ENFRC_ACTN_VIOL_LNK.action_type
     , ICS_ENFRC_ACTN_VIOL_LNK.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_ENFRC_ACTN_VIOL_LNK.ICS_ENFRC_ACTN_VIOL_LNK_id
             , ICS_ENFRC_ACTN_VIOL_LNK.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_ENFRC_ACTN_VIOL_LNK' as ics_module
          FROM ICS_ENFRC_ACTN_VIOL_LNK
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ICS_ENFRC_ACTN_VIOL_LNK tbl
                            WHERE tbl.key_hash = ICS_ENFRC_ACTN_VIOL_LNK.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_ENFRC_ACTN_VIOL_LNK_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_ENFRC_ACTN_VIOL_LNK' as ics_module
          FROM ICS_ENFRC_ACTN_VIOL_LNK local
          JOIN ics_flow_icis.ICS_ENFRC_ACTN_VIOL_LNK icis
            ON (    icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ICS_ENFRC_ACTN_VIOL_LNK.ICS_ENFRC_ACTN_VIOL_LNK_id
             , ICS_ENFRC_ACTN_VIOL_LNK.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_ENFRC_ACTN_VIOL_LNK' as ics_module
          FROM ics_flow_icis.ICS_ENFRC_ACTN_VIOL_LNK
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ICS_ENFRC_ACTN_VIOL_LNK tbl
                            WHERE tbl.key_hash = ICS_ENFRC_ACTN_VIOL_LNK.key_hash)) ICS_ENFRC_ACTN_VIOL_LNK;





/*************************************************************************************************
** ObjectName: cdv_final_order_viol_lnk
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/09/2025   Windsor      recreated for 5.14 baseline.
**
***************************************************************************************************/

CREATE OR REPLACE VIEW cdv_final_order_viol_lnk AS 
SELECT DISTINCT ics_module
, ICS_FINAL_ORDER_VIOL_LNK.key_hash
     , CASE ICS_FINAL_ORDER_VIOL_LNK.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ICS_FINAL_ORDER_VIOL_LNK tbl
                  WHERE tbl.ICS_FINAL_ORDER_VIOL_LNK_id = ICS_FINAL_ORDER_VIOL_LNK.ICS_FINAL_ORDER_VIOL_LNK_id)
           ELSE (SELECT key_hash 
                   FROM ICS_FINAL_ORDER_VIOL_LNK tbl
                  WHERE tbl.ICS_FINAL_ORDER_VIOL_LNK_id = ICS_FINAL_ORDER_VIOL_LNK.ICS_FINAL_ORDER_VIOL_LNK_id)
       END AS module_ident
     , ICS_FINAL_ORDER_VIOL_LNK.action_type
     , ICS_FINAL_ORDER_VIOL_LNK.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_FINAL_ORDER_VIOL_LNK.ICS_FINAL_ORDER_VIOL_LNK_id
             , ICS_FINAL_ORDER_VIOL_LNK.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_FINAL_ORDER_VIOL_LNK' as ics_module
          FROM ICS_FINAL_ORDER_VIOL_LNK
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ICS_FINAL_ORDER_VIOL_LNK tbl
                            WHERE tbl.key_hash = ICS_FINAL_ORDER_VIOL_LNK.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_FINAL_ORDER_VIOL_LNK_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_FINAL_ORDER_VIOL_LNK' as ics_module
          FROM ICS_FINAL_ORDER_VIOL_LNK local
          JOIN ics_flow_icis.ICS_FINAL_ORDER_VIOL_LNK icis
            ON (    icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ICS_FINAL_ORDER_VIOL_LNK.ICS_FINAL_ORDER_VIOL_LNK_id
             , ICS_FINAL_ORDER_VIOL_LNK.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_FINAL_ORDER_VIOL_LNK' as ics_module
          FROM ics_flow_icis.ICS_FINAL_ORDER_VIOL_LNK
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ICS_FINAL_ORDER_VIOL_LNK tbl
                            WHERE tbl.key_hash = ICS_FINAL_ORDER_VIOL_LNK.key_hash)) ICS_FINAL_ORDER_VIOL_LNK;





/*************************************************************************************************
** ObjectName: cdv_frml_enfrc_actn
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/09/2025   Windsor      recreated for 5.14 baseline.
**
***************************************************************************************************/

CREATE OR REPLACE VIEW cdv_frml_enfrc_actn AS 
SELECT DISTINCT ics_module
, ICS_FRML_ENFRC_ACTN.key_hash
     , CASE ICS_FRML_ENFRC_ACTN.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ICS_FRML_ENFRC_ACTN tbl
                  WHERE tbl.ICS_FRML_ENFRC_ACTN_id = ICS_FRML_ENFRC_ACTN.ICS_FRML_ENFRC_ACTN_id)
           ELSE (SELECT key_hash 
                   FROM ICS_FRML_ENFRC_ACTN tbl
                  WHERE tbl.ICS_FRML_ENFRC_ACTN_id = ICS_FRML_ENFRC_ACTN.ICS_FRML_ENFRC_ACTN_id)
       END AS module_ident
     , ICS_FRML_ENFRC_ACTN.action_type
     , ICS_FRML_ENFRC_ACTN.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_FRML_ENFRC_ACTN.ICS_FRML_ENFRC_ACTN_id
             , ICS_FRML_ENFRC_ACTN.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_FRML_ENFRC_ACTN' as ics_module
          FROM ICS_FRML_ENFRC_ACTN
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ICS_FRML_ENFRC_ACTN tbl
                            WHERE tbl.key_hash = ICS_FRML_ENFRC_ACTN.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_FRML_ENFRC_ACTN_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_FRML_ENFRC_ACTN' as ics_module
          FROM ICS_FRML_ENFRC_ACTN local
          JOIN ics_flow_icis.ICS_FRML_ENFRC_ACTN icis
            ON (    icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ICS_FRML_ENFRC_ACTN.ICS_FRML_ENFRC_ACTN_id
             , ICS_FRML_ENFRC_ACTN.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_FRML_ENFRC_ACTN' as ics_module
          FROM ics_flow_icis.ICS_FRML_ENFRC_ACTN
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ICS_FRML_ENFRC_ACTN tbl
                            WHERE tbl.key_hash = ICS_FRML_ENFRC_ACTN.key_hash)) ICS_FRML_ENFRC_ACTN;





/*************************************************************************************************
** ObjectName: cdv_gnrl_prmt
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/09/2025   Windsor      recreated for 5.14 baseline.
**
***************************************************************************************************/

CREATE OR REPLACE VIEW cdv_gnrl_prmt AS 
SELECT DISTINCT ics_module
, ICS_GNRL_PRMT.key_hash
     , CASE ICS_GNRL_PRMT.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ICS_GNRL_PRMT tbl
                  WHERE tbl.ICS_GNRL_PRMT_id = ICS_GNRL_PRMT.ICS_GNRL_PRMT_id)
           ELSE (SELECT key_hash 
                   FROM ICS_GNRL_PRMT tbl
                  WHERE tbl.ICS_GNRL_PRMT_id = ICS_GNRL_PRMT.ICS_GNRL_PRMT_id)
       END AS module_ident
     , ICS_GNRL_PRMT.action_type
     , ICS_GNRL_PRMT.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_GNRL_PRMT.ICS_GNRL_PRMT_id
             , ICS_GNRL_PRMT.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_GNRL_PRMT' as ics_module
          FROM ICS_GNRL_PRMT
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ICS_GNRL_PRMT tbl
                            WHERE tbl.key_hash = ICS_GNRL_PRMT.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_GNRL_PRMT_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_GNRL_PRMT' as ics_module
          FROM ICS_GNRL_PRMT local
          JOIN ics_flow_icis.ICS_GNRL_PRMT icis
            ON (    icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ICS_GNRL_PRMT.ICS_GNRL_PRMT_id
             , ICS_GNRL_PRMT.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_GNRL_PRMT' as ics_module
          FROM ics_flow_icis.ICS_GNRL_PRMT
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ICS_GNRL_PRMT tbl
                            WHERE tbl.key_hash = ICS_GNRL_PRMT.key_hash)) ICS_GNRL_PRMT;





/*************************************************************************************************
** ObjectName: cdv_hist_prmt_schd_evts
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/09/2025   Windsor      recreated for 5.14 baseline.
**
***************************************************************************************************/

CREATE OR REPLACE VIEW cdv_hist_prmt_schd_evts AS 
SELECT DISTINCT ics_module
, ICS_HIST_PRMT_SCHD_EVTS.key_hash
     , CASE ICS_HIST_PRMT_SCHD_EVTS.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ICS_HIST_PRMT_SCHD_EVTS tbl
                  WHERE tbl.ICS_HIST_PRMT_SCHD_EVTS_id = ICS_HIST_PRMT_SCHD_EVTS.ICS_HIST_PRMT_SCHD_EVTS_id)
           ELSE (SELECT key_hash 
                   FROM ICS_HIST_PRMT_SCHD_EVTS tbl
                  WHERE tbl.ICS_HIST_PRMT_SCHD_EVTS_id = ICS_HIST_PRMT_SCHD_EVTS.ICS_HIST_PRMT_SCHD_EVTS_id)
       END AS module_ident
     , ICS_HIST_PRMT_SCHD_EVTS.action_type
     , ICS_HIST_PRMT_SCHD_EVTS.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_HIST_PRMT_SCHD_EVTS.ICS_HIST_PRMT_SCHD_EVTS_id
             , ICS_HIST_PRMT_SCHD_EVTS.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_HIST_PRMT_SCHD_EVTS' as ics_module
          FROM ICS_HIST_PRMT_SCHD_EVTS
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ICS_HIST_PRMT_SCHD_EVTS tbl
                            WHERE tbl.key_hash = ICS_HIST_PRMT_SCHD_EVTS.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_HIST_PRMT_SCHD_EVTS_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_HIST_PRMT_SCHD_EVTS' as ics_module
          FROM ICS_HIST_PRMT_SCHD_EVTS local
          JOIN ics_flow_icis.ICS_HIST_PRMT_SCHD_EVTS icis
            ON (    icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ICS_HIST_PRMT_SCHD_EVTS.ICS_HIST_PRMT_SCHD_EVTS_id
             , ICS_HIST_PRMT_SCHD_EVTS.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_HIST_PRMT_SCHD_EVTS' as ics_module
          FROM ics_flow_icis.ICS_HIST_PRMT_SCHD_EVTS
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ICS_HIST_PRMT_SCHD_EVTS tbl
                            WHERE tbl.key_hash = ICS_HIST_PRMT_SCHD_EVTS.key_hash)) ICS_HIST_PRMT_SCHD_EVTS;





/*************************************************************************************************
** ObjectName: cdv_infrml_enfrc_actn
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/09/2025   Windsor      recreated for 5.14 baseline.
**
***************************************************************************************************/

CREATE OR REPLACE VIEW cdv_infrml_enfrc_actn AS 
SELECT DISTINCT ics_module
, ICS_INFRML_ENFRC_ACTN.key_hash
     , CASE ICS_INFRML_ENFRC_ACTN.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ICS_INFRML_ENFRC_ACTN tbl
                  WHERE tbl.ICS_INFRML_ENFRC_ACTN_id = ICS_INFRML_ENFRC_ACTN.ICS_INFRML_ENFRC_ACTN_id)
           ELSE (SELECT key_hash 
                   FROM ICS_INFRML_ENFRC_ACTN tbl
                  WHERE tbl.ICS_INFRML_ENFRC_ACTN_id = ICS_INFRML_ENFRC_ACTN.ICS_INFRML_ENFRC_ACTN_id)
       END AS module_ident
     , ICS_INFRML_ENFRC_ACTN.action_type
     , ICS_INFRML_ENFRC_ACTN.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_INFRML_ENFRC_ACTN.ICS_INFRML_ENFRC_ACTN_id
             , ICS_INFRML_ENFRC_ACTN.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_INFRML_ENFRC_ACTN' as ics_module
          FROM ICS_INFRML_ENFRC_ACTN
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ICS_INFRML_ENFRC_ACTN tbl
                            WHERE tbl.key_hash = ICS_INFRML_ENFRC_ACTN.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_INFRML_ENFRC_ACTN_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_INFRML_ENFRC_ACTN' as ics_module
          FROM ICS_INFRML_ENFRC_ACTN local
          JOIN ics_flow_icis.ICS_INFRML_ENFRC_ACTN icis
            ON (    icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ICS_INFRML_ENFRC_ACTN.ICS_INFRML_ENFRC_ACTN_id
             , ICS_INFRML_ENFRC_ACTN.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_INFRML_ENFRC_ACTN' as ics_module
          FROM ics_flow_icis.ICS_INFRML_ENFRC_ACTN
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ICS_INFRML_ENFRC_ACTN tbl
                            WHERE tbl.key_hash = ICS_INFRML_ENFRC_ACTN.key_hash)) ICS_INFRML_ENFRC_ACTN;





/*************************************************************************************************
** ObjectName: cdv_lmts
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/09/2025   Windsor      recreated for 5.14 baseline.
**
***************************************************************************************************/

CREATE OR REPLACE VIEW cdv_lmts AS 
SELECT DISTINCT ics_module
, ICS_LMTS.key_hash
     , CASE ICS_LMTS.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ICS_LMTS tbl
                  WHERE tbl.ICS_LMTS_id = ICS_LMTS.ICS_LMTS_id)
           ELSE (SELECT key_hash 
                   FROM ICS_LMTS tbl
                  WHERE tbl.ICS_LMTS_id = ICS_LMTS.ICS_LMTS_id)
       END AS module_ident
     , ICS_LMTS.action_type
     , ICS_LMTS.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_LMTS.ICS_LMTS_id
             , ICS_LMTS.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_LMTS' as ics_module
          FROM ICS_LMTS
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ICS_LMTS tbl
                            WHERE tbl.key_hash = ICS_LMTS.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_LMTS_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_LMTS' as ics_module
          FROM ICS_LMTS local
          JOIN ics_flow_icis.ICS_LMTS icis
            ON (    icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ICS_LMTS.ICS_LMTS_id
             , ICS_LMTS.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_LMTS' as ics_module
          FROM ics_flow_icis.ICS_LMTS
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ICS_LMTS tbl
                            WHERE tbl.key_hash = ICS_LMTS.key_hash)) ICS_LMTS;





/*************************************************************************************************
** ObjectName: cdv_lmt_set
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/09/2025   Windsor      recreated for 5.14 baseline.
**
***************************************************************************************************/

CREATE OR REPLACE VIEW cdv_lmt_set AS 
SELECT DISTINCT ics_module
, ICS_LMT_SET.key_hash
     , CASE ICS_LMT_SET.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ICS_LMT_SET tbl
                  WHERE tbl.ICS_LMT_SET_id = ICS_LMT_SET.ICS_LMT_SET_id)
           ELSE (SELECT key_hash 
                   FROM ICS_LMT_SET tbl
                  WHERE tbl.ICS_LMT_SET_id = ICS_LMT_SET.ICS_LMT_SET_id)
       END AS module_ident
     , ICS_LMT_SET.action_type
     , ICS_LMT_SET.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_LMT_SET.ICS_LMT_SET_id
             , ICS_LMT_SET.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_LMT_SET' as ics_module
          FROM ICS_LMT_SET
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ICS_LMT_SET tbl
                            WHERE tbl.key_hash = ICS_LMT_SET.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_LMT_SET_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_LMT_SET' as ics_module
          FROM ICS_LMT_SET local
          JOIN ics_flow_icis.ICS_LMT_SET icis
            ON (    icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ICS_LMT_SET.ICS_LMT_SET_id
             , ICS_LMT_SET.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_LMT_SET' as ics_module
          FROM ics_flow_icis.ICS_LMT_SET
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ICS_LMT_SET tbl
                            WHERE tbl.key_hash = ICS_LMT_SET.key_hash)) ICS_LMT_SET;





/*************************************************************************************************
** ObjectName: cdv_master_gnrl_prmt
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/09/2025   Windsor      recreated for 5.14 baseline.
**
***************************************************************************************************/

CREATE OR REPLACE VIEW cdv_master_gnrl_prmt AS 
SELECT DISTINCT ics_module
, ICS_MASTER_GNRL_PRMT.key_hash
     , CASE ICS_MASTER_GNRL_PRMT.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ICS_MASTER_GNRL_PRMT tbl
                  WHERE tbl.ICS_MASTER_GNRL_PRMT_id = ICS_MASTER_GNRL_PRMT.ICS_MASTER_GNRL_PRMT_id)
           ELSE (SELECT key_hash 
                   FROM ICS_MASTER_GNRL_PRMT tbl
                  WHERE tbl.ICS_MASTER_GNRL_PRMT_id = ICS_MASTER_GNRL_PRMT.ICS_MASTER_GNRL_PRMT_id)
       END AS module_ident
     , ICS_MASTER_GNRL_PRMT.action_type
     , ICS_MASTER_GNRL_PRMT.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_MASTER_GNRL_PRMT.ICS_MASTER_GNRL_PRMT_id
             , ICS_MASTER_GNRL_PRMT.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_MASTER_GNRL_PRMT' as ics_module
          FROM ICS_MASTER_GNRL_PRMT
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ICS_MASTER_GNRL_PRMT tbl
                            WHERE tbl.key_hash = ICS_MASTER_GNRL_PRMT.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_MASTER_GNRL_PRMT_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_MASTER_GNRL_PRMT' as ics_module
          FROM ICS_MASTER_GNRL_PRMT local
          JOIN ics_flow_icis.ICS_MASTER_GNRL_PRMT icis
            ON (    icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ICS_MASTER_GNRL_PRMT.ICS_MASTER_GNRL_PRMT_id
             , ICS_MASTER_GNRL_PRMT.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_MASTER_GNRL_PRMT' as ics_module
          FROM ics_flow_icis.ICS_MASTER_GNRL_PRMT
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ICS_MASTER_GNRL_PRMT tbl
                            WHERE tbl.key_hash = ICS_MASTER_GNRL_PRMT.key_hash)) ICS_MASTER_GNRL_PRMT;





/*************************************************************************************************
** ObjectName: cdv_narr_cond_schd
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/09/2025   Windsor      recreated for 5.14 baseline.
**
***************************************************************************************************/

CREATE OR REPLACE VIEW cdv_narr_cond_schd AS 
SELECT DISTINCT ics_module
, ICS_NARR_COND_SCHD.key_hash
     , CASE ICS_NARR_COND_SCHD.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ICS_NARR_COND_SCHD tbl
                  WHERE tbl.ICS_NARR_COND_SCHD_id = ICS_NARR_COND_SCHD.ICS_NARR_COND_SCHD_id)
           ELSE (SELECT key_hash 
                   FROM ICS_NARR_COND_SCHD tbl
                  WHERE tbl.ICS_NARR_COND_SCHD_id = ICS_NARR_COND_SCHD.ICS_NARR_COND_SCHD_id)
       END AS module_ident
     , ICS_NARR_COND_SCHD.action_type
     , ICS_NARR_COND_SCHD.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_NARR_COND_SCHD.ICS_NARR_COND_SCHD_id
             , ICS_NARR_COND_SCHD.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_NARR_COND_SCHD' as ics_module
          FROM ICS_NARR_COND_SCHD
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ICS_NARR_COND_SCHD tbl
                            WHERE tbl.key_hash = ICS_NARR_COND_SCHD.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_NARR_COND_SCHD_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_NARR_COND_SCHD' as ics_module
          FROM ICS_NARR_COND_SCHD local
          JOIN ics_flow_icis.ICS_NARR_COND_SCHD icis
            ON (    icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ICS_NARR_COND_SCHD.ICS_NARR_COND_SCHD_id
             , ICS_NARR_COND_SCHD.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_NARR_COND_SCHD' as ics_module
          FROM ics_flow_icis.ICS_NARR_COND_SCHD
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ICS_NARR_COND_SCHD tbl
                            WHERE tbl.key_hash = ICS_NARR_COND_SCHD.key_hash)) ICS_NARR_COND_SCHD;





/*************************************************************************************************
** ObjectName: cdv_npdes_variance_prmt
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/09/2025   Windsor      recreated for 5.14 baseline.
**
***************************************************************************************************/

CREATE OR REPLACE VIEW cdv_npdes_variance_prmt AS 
SELECT DISTINCT ics_module
, ICS_NPDES_VARIANCE_PRMT.key_hash
     , CASE ICS_NPDES_VARIANCE_PRMT.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ICS_NPDES_VARIANCE_PRMT tbl
                  WHERE tbl.ICS_NPDES_VARIANCE_PRMT_id = ICS_NPDES_VARIANCE_PRMT.ICS_NPDES_VARIANCE_PRMT_id)
           ELSE (SELECT key_hash 
                   FROM ICS_NPDES_VARIANCE_PRMT tbl
                  WHERE tbl.ICS_NPDES_VARIANCE_PRMT_id = ICS_NPDES_VARIANCE_PRMT.ICS_NPDES_VARIANCE_PRMT_id)
       END AS module_ident
     , ICS_NPDES_VARIANCE_PRMT.action_type
     , ICS_NPDES_VARIANCE_PRMT.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_NPDES_VARIANCE_PRMT.ICS_NPDES_VARIANCE_PRMT_id
             , ICS_NPDES_VARIANCE_PRMT.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_NPDES_VARIANCE_PRMT' as ics_module
          FROM ICS_NPDES_VARIANCE_PRMT
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ICS_NPDES_VARIANCE_PRMT tbl
                            WHERE tbl.key_hash = ICS_NPDES_VARIANCE_PRMT.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_NPDES_VARIANCE_PRMT_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_NPDES_VARIANCE_PRMT' as ics_module
          FROM ICS_NPDES_VARIANCE_PRMT local
          JOIN ics_flow_icis.ICS_NPDES_VARIANCE_PRMT icis
            ON (    icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ICS_NPDES_VARIANCE_PRMT.ICS_NPDES_VARIANCE_PRMT_id
             , ICS_NPDES_VARIANCE_PRMT.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_NPDES_VARIANCE_PRMT' as ics_module
          FROM ics_flow_icis.ICS_NPDES_VARIANCE_PRMT
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ICS_NPDES_VARIANCE_PRMT tbl
                            WHERE tbl.key_hash = ICS_NPDES_VARIANCE_PRMT.key_hash)) ICS_NPDES_VARIANCE_PRMT;





/*************************************************************************************************
** ObjectName: cdv_param_lmts
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/09/2025   Windsor      recreated for 5.14 baseline.
**
***************************************************************************************************/

CREATE OR REPLACE VIEW cdv_param_lmts AS 
SELECT DISTINCT ics_module
, ICS_PARAM_LMTS.key_hash
     , CASE ICS_PARAM_LMTS.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ICS_PARAM_LMTS tbl
                  WHERE tbl.ICS_PARAM_LMTS_id = ICS_PARAM_LMTS.ICS_PARAM_LMTS_id)
           ELSE (SELECT key_hash 
                   FROM ICS_PARAM_LMTS tbl
                  WHERE tbl.ICS_PARAM_LMTS_id = ICS_PARAM_LMTS.ICS_PARAM_LMTS_id)
       END AS module_ident
     , ICS_PARAM_LMTS.action_type
     , ICS_PARAM_LMTS.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_PARAM_LMTS.ICS_PARAM_LMTS_id
             , ICS_PARAM_LMTS.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_PARAM_LMTS' as ics_module
          FROM ICS_PARAM_LMTS
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ICS_PARAM_LMTS tbl
                            WHERE tbl.key_hash = ICS_PARAM_LMTS.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_PARAM_LMTS_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_PARAM_LMTS' as ics_module
          FROM ICS_PARAM_LMTS local
          JOIN ics_flow_icis.ICS_PARAM_LMTS icis
            ON (    icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ICS_PARAM_LMTS.ICS_PARAM_LMTS_id
             , ICS_PARAM_LMTS.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_PARAM_LMTS' as ics_module
          FROM ics_flow_icis.ICS_PARAM_LMTS
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ICS_PARAM_LMTS tbl
                            WHERE tbl.key_hash = ICS_PARAM_LMTS.key_hash)) ICS_PARAM_LMTS;





/*************************************************************************************************
** ObjectName: cdv_prmt_reissu
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/09/2025   Windsor      recreated for 5.14 baseline.
**
***************************************************************************************************/

CREATE OR REPLACE VIEW cdv_prmt_reissu AS 
SELECT DISTINCT ics_module
, ICS_PRMT_REISSU.key_hash
     , CASE ICS_PRMT_REISSU.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ICS_PRMT_REISSU tbl
                  WHERE tbl.ICS_PRMT_REISSU_id = ICS_PRMT_REISSU.ICS_PRMT_REISSU_id)
           ELSE (SELECT key_hash 
                   FROM ICS_PRMT_REISSU tbl
                  WHERE tbl.ICS_PRMT_REISSU_id = ICS_PRMT_REISSU.ICS_PRMT_REISSU_id)
       END AS module_ident
     , ICS_PRMT_REISSU.action_type
     , ICS_PRMT_REISSU.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_PRMT_REISSU.ICS_PRMT_REISSU_id
             , ICS_PRMT_REISSU.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_PRMT_REISSU' as ics_module
          FROM ICS_PRMT_REISSU
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ICS_PRMT_REISSU tbl
                            WHERE tbl.key_hash = ICS_PRMT_REISSU.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_PRMT_REISSU_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_PRMT_REISSU' as ics_module
          FROM ICS_PRMT_REISSU local
          JOIN ics_flow_icis.ICS_PRMT_REISSU icis
            ON (    icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ICS_PRMT_REISSU.ICS_PRMT_REISSU_id
             , ICS_PRMT_REISSU.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_PRMT_REISSU' as ics_module
          FROM ics_flow_icis.ICS_PRMT_REISSU
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ICS_PRMT_REISSU tbl
                            WHERE tbl.key_hash = ICS_PRMT_REISSU.key_hash)) ICS_PRMT_REISSU;





/*************************************************************************************************
** ObjectName: cdv_prmt_featr
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/09/2025   Windsor      recreated for 5.14 baseline.
**
***************************************************************************************************/

CREATE OR REPLACE VIEW cdv_prmt_featr AS 
SELECT DISTINCT ics_module
, ICS_PRMT_FEATR.key_hash
     , CASE ICS_PRMT_FEATR.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ICS_PRMT_FEATR tbl
                  WHERE tbl.ICS_PRMT_FEATR_id = ICS_PRMT_FEATR.ICS_PRMT_FEATR_id)
           ELSE (SELECT key_hash 
                   FROM ICS_PRMT_FEATR tbl
                  WHERE tbl.ICS_PRMT_FEATR_id = ICS_PRMT_FEATR.ICS_PRMT_FEATR_id)
       END AS module_ident
     , ICS_PRMT_FEATR.action_type
     , ICS_PRMT_FEATR.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_PRMT_FEATR.ICS_PRMT_FEATR_id
             , ICS_PRMT_FEATR.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_PRMT_FEATR' as ics_module
          FROM ICS_PRMT_FEATR
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ICS_PRMT_FEATR tbl
                            WHERE tbl.key_hash = ICS_PRMT_FEATR.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_PRMT_FEATR_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_PRMT_FEATR' as ics_module
          FROM ICS_PRMT_FEATR local
          JOIN ics_flow_icis.ICS_PRMT_FEATR icis
            ON (    icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ICS_PRMT_FEATR.ICS_PRMT_FEATR_id
             , ICS_PRMT_FEATR.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_PRMT_FEATR' as ics_module
          FROM ics_flow_icis.ICS_PRMT_FEATR
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ICS_PRMT_FEATR tbl
                            WHERE tbl.key_hash = ICS_PRMT_FEATR.key_hash)) ICS_PRMT_FEATR;





/*************************************************************************************************
** ObjectName: cdv_prmt_term
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/09/2025   Windsor      recreated for 5.14 baseline.
**
***************************************************************************************************/

CREATE OR REPLACE VIEW cdv_prmt_term AS 
SELECT DISTINCT ics_module
, ICS_PRMT_TERM.key_hash
     , CASE ICS_PRMT_TERM.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ICS_PRMT_TERM tbl
                  WHERE tbl.ICS_PRMT_TERM_id = ICS_PRMT_TERM.ICS_PRMT_TERM_id)
           ELSE (SELECT key_hash 
                   FROM ICS_PRMT_TERM tbl
                  WHERE tbl.ICS_PRMT_TERM_id = ICS_PRMT_TERM.ICS_PRMT_TERM_id)
       END AS module_ident
     , ICS_PRMT_TERM.action_type
     , ICS_PRMT_TERM.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_PRMT_TERM.ICS_PRMT_TERM_id
             , ICS_PRMT_TERM.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_PRMT_TERM' as ics_module
          FROM ICS_PRMT_TERM
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ICS_PRMT_TERM tbl
                            WHERE tbl.key_hash = ICS_PRMT_TERM.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_PRMT_TERM_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_PRMT_TERM' as ics_module
          FROM ICS_PRMT_TERM local
          JOIN ics_flow_icis.ICS_PRMT_TERM icis
            ON (    icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ICS_PRMT_TERM.ICS_PRMT_TERM_id
             , ICS_PRMT_TERM.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_PRMT_TERM' as ics_module
          FROM ics_flow_icis.ICS_PRMT_TERM
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ICS_PRMT_TERM tbl
                            WHERE tbl.key_hash = ICS_PRMT_TERM.key_hash)) ICS_PRMT_TERM;





/*************************************************************************************************
** ObjectName: cdv_prmt_track_evt
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/09/2025   Windsor      recreated for 5.14 baseline.
**
***************************************************************************************************/

CREATE OR REPLACE VIEW cdv_prmt_track_evt AS 
SELECT DISTINCT ics_module
, ICS_PRMT_TRACK_EVT.key_hash
     , CASE ICS_PRMT_TRACK_EVT.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ICS_PRMT_TRACK_EVT tbl
                  WHERE tbl.ICS_PRMT_TRACK_EVT_id = ICS_PRMT_TRACK_EVT.ICS_PRMT_TRACK_EVT_id)
           ELSE (SELECT key_hash 
                   FROM ICS_PRMT_TRACK_EVT tbl
                  WHERE tbl.ICS_PRMT_TRACK_EVT_id = ICS_PRMT_TRACK_EVT.ICS_PRMT_TRACK_EVT_id)
       END AS module_ident
     , ICS_PRMT_TRACK_EVT.action_type
     , ICS_PRMT_TRACK_EVT.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_PRMT_TRACK_EVT.ICS_PRMT_TRACK_EVT_id
             , ICS_PRMT_TRACK_EVT.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_PRMT_TRACK_EVT' as ics_module
          FROM ICS_PRMT_TRACK_EVT
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ICS_PRMT_TRACK_EVT tbl
                            WHERE tbl.key_hash = ICS_PRMT_TRACK_EVT.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_PRMT_TRACK_EVT_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_PRMT_TRACK_EVT' as ics_module
          FROM ICS_PRMT_TRACK_EVT local
          JOIN ics_flow_icis.ICS_PRMT_TRACK_EVT icis
            ON (    icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ICS_PRMT_TRACK_EVT.ICS_PRMT_TRACK_EVT_id
             , ICS_PRMT_TRACK_EVT.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_PRMT_TRACK_EVT' as ics_module
          FROM ics_flow_icis.ICS_PRMT_TRACK_EVT
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ICS_PRMT_TRACK_EVT tbl
                            WHERE tbl.key_hash = ICS_PRMT_TRACK_EVT.key_hash)) ICS_PRMT_TRACK_EVT;





/*************************************************************************************************
** ObjectName: cdv_potw_prmt
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/09/2025   Windsor      recreated for 5.14 baseline.
**
***************************************************************************************************/

CREATE OR REPLACE VIEW cdv_potw_prmt AS 
SELECT DISTINCT ics_module
, ICS_POTW_PRMT.key_hash
     , CASE ICS_POTW_PRMT.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ICS_POTW_PRMT tbl
                  WHERE tbl.ICS_POTW_PRMT_id = ICS_POTW_PRMT.ICS_POTW_PRMT_id)
           ELSE (SELECT key_hash 
                   FROM ICS_POTW_PRMT tbl
                  WHERE tbl.ICS_POTW_PRMT_id = ICS_POTW_PRMT.ICS_POTW_PRMT_id)
       END AS module_ident
     , ICS_POTW_PRMT.action_type
     , ICS_POTW_PRMT.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_POTW_PRMT.ICS_POTW_PRMT_id
             , ICS_POTW_PRMT.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_POTW_PRMT' as ics_module
          FROM ICS_POTW_PRMT
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ICS_POTW_PRMT tbl
                            WHERE tbl.key_hash = ICS_POTW_PRMT.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_POTW_PRMT_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_POTW_PRMT' as ics_module
          FROM ICS_POTW_PRMT local
          JOIN ics_flow_icis.ICS_POTW_PRMT icis
            ON (    icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ICS_POTW_PRMT.ICS_POTW_PRMT_id
             , ICS_POTW_PRMT.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_POTW_PRMT' as ics_module
          FROM ics_flow_icis.ICS_POTW_PRMT
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ICS_POTW_PRMT tbl
                            WHERE tbl.key_hash = ICS_POTW_PRMT.key_hash)) ICS_POTW_PRMT;





/*************************************************************************************************
** ObjectName: cdv_potw_trtmnt_technology_prmt
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/09/2025   Windsor      recreated for 5.14 baseline.
**
***************************************************************************************************/

CREATE OR REPLACE VIEW cdv_potw_trtmnt_technology_prmt AS 
SELECT DISTINCT ics_module
, ICS_POTW_TRTMNT_TECHNOLOGY_PRMT.key_hash
     , CASE ICS_POTW_TRTMNT_TECHNOLOGY_PRMT.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT tbl
                  WHERE tbl.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT_id = ICS_POTW_TRTMNT_TECHNOLOGY_PRMT.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT_id)
           ELSE (SELECT key_hash 
                   FROM ICS_POTW_TRTMNT_TECHNOLOGY_PRMT tbl
                  WHERE tbl.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT_id = ICS_POTW_TRTMNT_TECHNOLOGY_PRMT.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT_id)
       END AS module_ident
     , ICS_POTW_TRTMNT_TECHNOLOGY_PRMT.action_type
     , ICS_POTW_TRTMNT_TECHNOLOGY_PRMT.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_POTW_TRTMNT_TECHNOLOGY_PRMT.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT_id
             , ICS_POTW_TRTMNT_TECHNOLOGY_PRMT.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_POTW_TRTMNT_TECHNOLOGY_PRMT' as ics_module
          FROM ICS_POTW_TRTMNT_TECHNOLOGY_PRMT
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT tbl
                            WHERE tbl.key_hash = ICS_POTW_TRTMNT_TECHNOLOGY_PRMT.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_POTW_TRTMNT_TECHNOLOGY_PRMT' as ics_module
          FROM ICS_POTW_TRTMNT_TECHNOLOGY_PRMT local
          JOIN ics_flow_icis.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT icis
            ON (    icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ICS_POTW_TRTMNT_TECHNOLOGY_PRMT.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT_id
             , ICS_POTW_TRTMNT_TECHNOLOGY_PRMT.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_POTW_TRTMNT_TECHNOLOGY_PRMT' as ics_module
          FROM ics_flow_icis.ICS_POTW_TRTMNT_TECHNOLOGY_PRMT
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ICS_POTW_TRTMNT_TECHNOLOGY_PRMT tbl
                            WHERE tbl.key_hash = ICS_POTW_TRTMNT_TECHNOLOGY_PRMT.key_hash)) ICS_POTW_TRTMNT_TECHNOLOGY_PRMT;





/*************************************************************************************************
** ObjectName: cdv_pretr_prmt
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/09/2025   Windsor      recreated for 5.14 baseline.
**
***************************************************************************************************/

CREATE OR REPLACE VIEW cdv_pretr_prmt AS 
SELECT DISTINCT ics_module
, ICS_PRETR_PRMT.key_hash
     , CASE ICS_PRETR_PRMT.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ICS_PRETR_PRMT tbl
                  WHERE tbl.ICS_PRETR_PRMT_id = ICS_PRETR_PRMT.ICS_PRETR_PRMT_id)
           ELSE (SELECT key_hash 
                   FROM ICS_PRETR_PRMT tbl
                  WHERE tbl.ICS_PRETR_PRMT_id = ICS_PRETR_PRMT.ICS_PRETR_PRMT_id)
       END AS module_ident
     , ICS_PRETR_PRMT.action_type
     , ICS_PRETR_PRMT.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_PRETR_PRMT.ICS_PRETR_PRMT_id
             , ICS_PRETR_PRMT.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_PRETR_PRMT' as ics_module
          FROM ICS_PRETR_PRMT
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ICS_PRETR_PRMT tbl
                            WHERE tbl.key_hash = ICS_PRETR_PRMT.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_PRETR_PRMT_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_PRETR_PRMT' as ics_module
          FROM ICS_PRETR_PRMT local
          JOIN ics_flow_icis.ICS_PRETR_PRMT icis
            ON (    icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ICS_PRETR_PRMT.ICS_PRETR_PRMT_id
             , ICS_PRETR_PRMT.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_PRETR_PRMT' as ics_module
          FROM ics_flow_icis.ICS_PRETR_PRMT
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ICS_PRETR_PRMT tbl
                            WHERE tbl.key_hash = ICS_PRETR_PRMT.key_hash)) ICS_PRETR_PRMT;





/*************************************************************************************************
** ObjectName: cdv_pretr_prog_rep
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/09/2025   Windsor      recreated for 5.14 baseline.
**
***************************************************************************************************/

CREATE OR REPLACE VIEW cdv_pretr_prog_rep AS 
SELECT DISTINCT ics_module
, ICS_PRETR_PROG_REP.key_hash
     , CASE ICS_PRETR_PROG_REP.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ICS_PRETR_PROG_REP tbl
                  WHERE tbl.ICS_PRETR_PROG_REP_id = ICS_PRETR_PROG_REP.ICS_PRETR_PROG_REP_id)
           ELSE (SELECT key_hash 
                   FROM ICS_PRETR_PROG_REP tbl
                  WHERE tbl.ICS_PRETR_PROG_REP_id = ICS_PRETR_PROG_REP.ICS_PRETR_PROG_REP_id)
       END AS module_ident
     , ICS_PRETR_PROG_REP.action_type
     , ICS_PRETR_PROG_REP.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_PRETR_PROG_REP.ICS_PRETR_PROG_REP_id
             , ICS_PRETR_PROG_REP.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_PRETR_PROG_REP' as ics_module
          FROM ICS_PRETR_PROG_REP
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ICS_PRETR_PROG_REP tbl
                            WHERE tbl.key_hash = ICS_PRETR_PROG_REP.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_PRETR_PROG_REP_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_PRETR_PROG_REP' as ics_module
          FROM ICS_PRETR_PROG_REP local
          JOIN ics_flow_icis.ICS_PRETR_PROG_REP icis
            ON (    icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ICS_PRETR_PROG_REP.ICS_PRETR_PROG_REP_id
             , ICS_PRETR_PROG_REP.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_PRETR_PROG_REP' as ics_module
          FROM ics_flow_icis.ICS_PRETR_PROG_REP
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ICS_PRETR_PROG_REP tbl
                            WHERE tbl.key_hash = ICS_PRETR_PROG_REP.key_hash)) ICS_PRETR_PROG_REP;





/*************************************************************************************************
** ObjectName: cdv_schd_evt_viol
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/09/2025   Windsor      recreated for 5.14 baseline.
**
***************************************************************************************************/

CREATE OR REPLACE VIEW cdv_schd_evt_viol AS 
SELECT DISTINCT ics_module
, ICS_SCHD_EVT_VIOL.key_hash
     , CASE ICS_SCHD_EVT_VIOL.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ICS_SCHD_EVT_VIOL tbl
                  WHERE tbl.ICS_SCHD_EVT_VIOL_id = ICS_SCHD_EVT_VIOL.ICS_SCHD_EVT_VIOL_id)
           ELSE (SELECT key_hash 
                   FROM ICS_SCHD_EVT_VIOL tbl
                  WHERE tbl.ICS_SCHD_EVT_VIOL_id = ICS_SCHD_EVT_VIOL.ICS_SCHD_EVT_VIOL_id)
       END AS module_ident
     , ICS_SCHD_EVT_VIOL.action_type
     , ICS_SCHD_EVT_VIOL.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_SCHD_EVT_VIOL.ICS_SCHD_EVT_VIOL_id
             , ICS_SCHD_EVT_VIOL.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_SCHD_EVT_VIOL' as ics_module
          FROM ICS_SCHD_EVT_VIOL
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ICS_SCHD_EVT_VIOL tbl
                            WHERE tbl.key_hash = ICS_SCHD_EVT_VIOL.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_SCHD_EVT_VIOL_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_SCHD_EVT_VIOL' as ics_module
          FROM ICS_SCHD_EVT_VIOL local
          JOIN ics_flow_icis.ICS_SCHD_EVT_VIOL icis
            ON (    icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ICS_SCHD_EVT_VIOL.ICS_SCHD_EVT_VIOL_id
             , ICS_SCHD_EVT_VIOL.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_SCHD_EVT_VIOL' as ics_module
          FROM ics_flow_icis.ICS_SCHD_EVT_VIOL
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ICS_SCHD_EVT_VIOL tbl
                            WHERE tbl.key_hash = ICS_SCHD_EVT_VIOL.key_hash)) ICS_SCHD_EVT_VIOL;





/*************************************************************************************************
** ObjectName: cdv_sewer_ovrflw_bypass_evt_rep
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/09/2025   Windsor      recreated for 5.14 baseline.
**
***************************************************************************************************/

CREATE OR REPLACE VIEW cdv_sewer_ovrflw_bypass_evt_rep AS 
SELECT DISTINCT ics_module
, ICS_SEWER_OVRFLW_BYPASS_EVT_REP.key_hash
     , CASE ICS_SEWER_OVRFLW_BYPASS_EVT_REP.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ICS_SEWER_OVRFLW_BYPASS_EVT_REP tbl
                  WHERE tbl.ICS_SEWER_OVRFLW_BYPASS_EVT_REP_id = ICS_SEWER_OVRFLW_BYPASS_EVT_REP.ICS_SEWER_OVRFLW_BYPASS_EVT_REP_id)
           ELSE (SELECT key_hash 
                   FROM ICS_SEWER_OVRFLW_BYPASS_EVT_REP tbl
                  WHERE tbl.ICS_SEWER_OVRFLW_BYPASS_EVT_REP_id = ICS_SEWER_OVRFLW_BYPASS_EVT_REP.ICS_SEWER_OVRFLW_BYPASS_EVT_REP_id)
       END AS module_ident
     , ICS_SEWER_OVRFLW_BYPASS_EVT_REP.action_type
     , ICS_SEWER_OVRFLW_BYPASS_EVT_REP.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_SEWER_OVRFLW_BYPASS_EVT_REP.ICS_SEWER_OVRFLW_BYPASS_EVT_REP_id
             , ICS_SEWER_OVRFLW_BYPASS_EVT_REP.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_SEWER_OVRFLW_BYPASS_EVT_REP' as ics_module
          FROM ICS_SEWER_OVRFLW_BYPASS_EVT_REP
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ICS_SEWER_OVRFLW_BYPASS_EVT_REP tbl
                            WHERE tbl.key_hash = ICS_SEWER_OVRFLW_BYPASS_EVT_REP.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_SEWER_OVRFLW_BYPASS_EVT_REP_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_SEWER_OVRFLW_BYPASS_EVT_REP' as ics_module
          FROM ICS_SEWER_OVRFLW_BYPASS_EVT_REP local
          JOIN ics_flow_icis.ICS_SEWER_OVRFLW_BYPASS_EVT_REP icis
            ON (    icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ICS_SEWER_OVRFLW_BYPASS_EVT_REP.ICS_SEWER_OVRFLW_BYPASS_EVT_REP_id
             , ICS_SEWER_OVRFLW_BYPASS_EVT_REP.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_SEWER_OVRFLW_BYPASS_EVT_REP' as ics_module
          FROM ics_flow_icis.ICS_SEWER_OVRFLW_BYPASS_EVT_REP
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ICS_SEWER_OVRFLW_BYPASS_EVT_REP tbl
                            WHERE tbl.key_hash = ICS_SEWER_OVRFLW_BYPASS_EVT_REP.key_hash)) ICS_SEWER_OVRFLW_BYPASS_EVT_REP;





/*************************************************************************************************
** ObjectName: cdv_sngl_evt_viol
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/09/2025   Windsor      recreated for 5.14 baseline.
**
***************************************************************************************************/

CREATE OR REPLACE VIEW cdv_sngl_evt_viol AS 
SELECT DISTINCT ics_module
, ICS_SNGL_EVT_VIOL.key_hash
     , CASE ICS_SNGL_EVT_VIOL.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ICS_SNGL_EVT_VIOL tbl
                  WHERE tbl.ICS_SNGL_EVT_VIOL_id = ICS_SNGL_EVT_VIOL.ICS_SNGL_EVT_VIOL_id)
           ELSE (SELECT key_hash 
                   FROM ICS_SNGL_EVT_VIOL tbl
                  WHERE tbl.ICS_SNGL_EVT_VIOL_id = ICS_SNGL_EVT_VIOL.ICS_SNGL_EVT_VIOL_id)
       END AS module_ident
     , ICS_SNGL_EVT_VIOL.action_type
     , ICS_SNGL_EVT_VIOL.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_SNGL_EVT_VIOL.ICS_SNGL_EVT_VIOL_id
             , ICS_SNGL_EVT_VIOL.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_SNGL_EVT_VIOL' as ics_module
          FROM ICS_SNGL_EVT_VIOL
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ICS_SNGL_EVT_VIOL tbl
                            WHERE tbl.key_hash = ICS_SNGL_EVT_VIOL.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_SNGL_EVT_VIOL_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_SNGL_EVT_VIOL' as ics_module
          FROM ICS_SNGL_EVT_VIOL local
          JOIN ics_flow_icis.ICS_SNGL_EVT_VIOL icis
            ON (    icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ICS_SNGL_EVT_VIOL.ICS_SNGL_EVT_VIOL_id
             , ICS_SNGL_EVT_VIOL.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_SNGL_EVT_VIOL' as ics_module
          FROM ics_flow_icis.ICS_SNGL_EVT_VIOL
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ICS_SNGL_EVT_VIOL tbl
                            WHERE tbl.key_hash = ICS_SNGL_EVT_VIOL.key_hash)) ICS_SNGL_EVT_VIOL;





/*************************************************************************************************
** ObjectName: cdv_sw_cnst_prmt
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/09/2025   Windsor      recreated for 5.14 baseline.
**
***************************************************************************************************/

CREATE OR REPLACE VIEW cdv_sw_cnst_prmt AS 
SELECT DISTINCT ics_module
, ICS_SW_CNST_PRMT.key_hash
     , CASE ICS_SW_CNST_PRMT.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ICS_SW_CNST_PRMT tbl
                  WHERE tbl.ICS_SW_CNST_PRMT_id = ICS_SW_CNST_PRMT.ICS_SW_CNST_PRMT_id)
           ELSE (SELECT key_hash 
                   FROM ICS_SW_CNST_PRMT tbl
                  WHERE tbl.ICS_SW_CNST_PRMT_id = ICS_SW_CNST_PRMT.ICS_SW_CNST_PRMT_id)
       END AS module_ident
     , ICS_SW_CNST_PRMT.action_type
     , ICS_SW_CNST_PRMT.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_SW_CNST_PRMT.ICS_SW_CNST_PRMT_id
             , ICS_SW_CNST_PRMT.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_SW_CNST_PRMT' as ics_module
          FROM ICS_SW_CNST_PRMT
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ICS_SW_CNST_PRMT tbl
                            WHERE tbl.key_hash = ICS_SW_CNST_PRMT.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_SW_CNST_PRMT_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_SW_CNST_PRMT' as ics_module
          FROM ICS_SW_CNST_PRMT local
          JOIN ics_flow_icis.ICS_SW_CNST_PRMT icis
            ON (    icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ICS_SW_CNST_PRMT.ICS_SW_CNST_PRMT_id
             , ICS_SW_CNST_PRMT.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_SW_CNST_PRMT' as ics_module
          FROM ics_flow_icis.ICS_SW_CNST_PRMT
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ICS_SW_CNST_PRMT tbl
                            WHERE tbl.key_hash = ICS_SW_CNST_PRMT.key_hash)) ICS_SW_CNST_PRMT;





/*************************************************************************************************
** ObjectName: cdv_sw_indst_annul_rep
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/09/2025   Windsor      recreated for 5.14 baseline.
**
***************************************************************************************************/

CREATE OR REPLACE VIEW cdv_sw_indst_annul_rep AS 
SELECT DISTINCT ics_module
, ICS_SW_INDST_ANNUL_REP.key_hash
     , CASE ICS_SW_INDST_ANNUL_REP.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ICS_SW_INDST_ANNUL_REP tbl
                  WHERE tbl.ICS_SW_INDST_ANNUL_REP_id = ICS_SW_INDST_ANNUL_REP.ICS_SW_INDST_ANNUL_REP_id)
           ELSE (SELECT key_hash 
                   FROM ICS_SW_INDST_ANNUL_REP tbl
                  WHERE tbl.ICS_SW_INDST_ANNUL_REP_id = ICS_SW_INDST_ANNUL_REP.ICS_SW_INDST_ANNUL_REP_id)
       END AS module_ident
     , ICS_SW_INDST_ANNUL_REP.action_type
     , ICS_SW_INDST_ANNUL_REP.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_SW_INDST_ANNUL_REP.ICS_SW_INDST_ANNUL_REP_id
             , ICS_SW_INDST_ANNUL_REP.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_SW_INDST_ANNUL_REP' as ics_module
          FROM ICS_SW_INDST_ANNUL_REP
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ICS_SW_INDST_ANNUL_REP tbl
                            WHERE tbl.key_hash = ICS_SW_INDST_ANNUL_REP.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_SW_INDST_ANNUL_REP_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_SW_INDST_ANNUL_REP' as ics_module
          FROM ICS_SW_INDST_ANNUL_REP local
          JOIN ics_flow_icis.ICS_SW_INDST_ANNUL_REP icis
            ON (    icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ICS_SW_INDST_ANNUL_REP.ICS_SW_INDST_ANNUL_REP_id
             , ICS_SW_INDST_ANNUL_REP.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_SW_INDST_ANNUL_REP' as ics_module
          FROM ics_flow_icis.ICS_SW_INDST_ANNUL_REP
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ICS_SW_INDST_ANNUL_REP tbl
                            WHERE tbl.key_hash = ICS_SW_INDST_ANNUL_REP.key_hash)) ICS_SW_INDST_ANNUL_REP;





/*************************************************************************************************
** ObjectName: cdv_sw_indst_prmt
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/09/2025   Windsor      recreated for 5.14 baseline.
**
***************************************************************************************************/

CREATE OR REPLACE VIEW cdv_sw_indst_prmt AS 
SELECT DISTINCT ics_module
, ICS_SW_INDST_PRMT.key_hash
     , CASE ICS_SW_INDST_PRMT.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ICS_SW_INDST_PRMT tbl
                  WHERE tbl.ICS_SW_INDST_PRMT_id = ICS_SW_INDST_PRMT.ICS_SW_INDST_PRMT_id)
           ELSE (SELECT key_hash 
                   FROM ICS_SW_INDST_PRMT tbl
                  WHERE tbl.ICS_SW_INDST_PRMT_id = ICS_SW_INDST_PRMT.ICS_SW_INDST_PRMT_id)
       END AS module_ident
     , ICS_SW_INDST_PRMT.action_type
     , ICS_SW_INDST_PRMT.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_SW_INDST_PRMT.ICS_SW_INDST_PRMT_id
             , ICS_SW_INDST_PRMT.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_SW_INDST_PRMT' as ics_module
          FROM ICS_SW_INDST_PRMT
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ICS_SW_INDST_PRMT tbl
                            WHERE tbl.key_hash = ICS_SW_INDST_PRMT.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_SW_INDST_PRMT_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_SW_INDST_PRMT' as ics_module
          FROM ICS_SW_INDST_PRMT local
          JOIN ics_flow_icis.ICS_SW_INDST_PRMT icis
            ON (    icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ICS_SW_INDST_PRMT.ICS_SW_INDST_PRMT_id
             , ICS_SW_INDST_PRMT.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_SW_INDST_PRMT' as ics_module
          FROM ics_flow_icis.ICS_SW_INDST_PRMT
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ICS_SW_INDST_PRMT tbl
                            WHERE tbl.key_hash = ICS_SW_INDST_PRMT.key_hash)) ICS_SW_INDST_PRMT;





/*************************************************************************************************
** ObjectName: cdv_swms_4_annul_prog_rep
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/09/2025   Windsor      recreated for 5.14 baseline.
**
***************************************************************************************************/

CREATE OR REPLACE VIEW cdv_swms_4_annul_prog_rep AS 
SELECT DISTINCT ics_module
, ICS_SWMS_4_ANNUL_PROG_REP.key_hash
     , CASE ICS_SWMS_4_ANNUL_PROG_REP.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ICS_SWMS_4_ANNUL_PROG_REP tbl
                  WHERE tbl.ICS_SWMS_4_ANNUL_PROG_REP_id = ICS_SWMS_4_ANNUL_PROG_REP.ICS_SWMS_4_ANNUL_PROG_REP_id)
           ELSE (SELECT key_hash 
                   FROM ICS_SWMS_4_ANNUL_PROG_REP tbl
                  WHERE tbl.ICS_SWMS_4_ANNUL_PROG_REP_id = ICS_SWMS_4_ANNUL_PROG_REP.ICS_SWMS_4_ANNUL_PROG_REP_id)
       END AS module_ident
     , ICS_SWMS_4_ANNUL_PROG_REP.action_type
     , ICS_SWMS_4_ANNUL_PROG_REP.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_SWMS_4_ANNUL_PROG_REP.ICS_SWMS_4_ANNUL_PROG_REP_id
             , ICS_SWMS_4_ANNUL_PROG_REP.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_SWMS_4_ANNUL_PROG_REP' as ics_module
          FROM ICS_SWMS_4_ANNUL_PROG_REP
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ICS_SWMS_4_ANNUL_PROG_REP tbl
                            WHERE tbl.key_hash = ICS_SWMS_4_ANNUL_PROG_REP.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_SWMS_4_ANNUL_PROG_REP_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_SWMS_4_ANNUL_PROG_REP' as ics_module
          FROM ICS_SWMS_4_ANNUL_PROG_REP local
          JOIN ics_flow_icis.ICS_SWMS_4_ANNUL_PROG_REP icis
            ON (    icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ICS_SWMS_4_ANNUL_PROG_REP.ICS_SWMS_4_ANNUL_PROG_REP_id
             , ICS_SWMS_4_ANNUL_PROG_REP.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_SWMS_4_ANNUL_PROG_REP' as ics_module
          FROM ics_flow_icis.ICS_SWMS_4_ANNUL_PROG_REP
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ICS_SWMS_4_ANNUL_PROG_REP tbl
                            WHERE tbl.key_hash = ICS_SWMS_4_ANNUL_PROG_REP.key_hash)) ICS_SWMS_4_ANNUL_PROG_REP;





/*************************************************************************************************
** ObjectName: cdv_swms_4_prmt
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/09/2025   Windsor      recreated for 5.14 baseline.
**
***************************************************************************************************/

CREATE OR REPLACE VIEW cdv_swms_4_prmt AS 
SELECT DISTINCT ics_module
, ICS_SWMS_4_PRMT.key_hash
     , CASE ICS_SWMS_4_PRMT.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ICS_SWMS_4_PRMT tbl
                  WHERE tbl.ICS_SWMS_4_PRMT_id = ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_id)
           ELSE (SELECT key_hash 
                   FROM ICS_SWMS_4_PRMT tbl
                  WHERE tbl.ICS_SWMS_4_PRMT_id = ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_id)
       END AS module_ident
     , ICS_SWMS_4_PRMT.action_type
     , ICS_SWMS_4_PRMT.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_id
             , ICS_SWMS_4_PRMT.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_SWMS_4_PRMT' as ics_module
          FROM ICS_SWMS_4_PRMT
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ICS_SWMS_4_PRMT tbl
                            WHERE tbl.key_hash = ICS_SWMS_4_PRMT.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_SWMS_4_PRMT_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_SWMS_4_PRMT' as ics_module
          FROM ICS_SWMS_4_PRMT local
          JOIN ics_flow_icis.ICS_SWMS_4_PRMT icis
            ON (    icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ICS_SWMS_4_PRMT.ICS_SWMS_4_PRMT_id
             , ICS_SWMS_4_PRMT.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_SWMS_4_PRMT' as ics_module
          FROM ics_flow_icis.ICS_SWMS_4_PRMT
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ICS_SWMS_4_PRMT tbl
                            WHERE tbl.key_hash = ICS_SWMS_4_PRMT.key_hash)) ICS_SWMS_4_PRMT;





/*************************************************************************************************
** ObjectName: cdv_unprmt_fac
**
** Author: Windsor
**
** Company Name: Windsor Solutions, Inc
**
** Description:  This view identifies data changes within an ICIS module.  This view
**               then drives the database process that sets the appropriate transaction types
**               for each module's key.
**
** Revision History:      
** ------------------------------------------------------------------------------------------------
**  Date         Name        Description
** ------------------------------------------------------------------------------------------------
** 09/09/2025   Windsor      recreated for 5.14 baseline.
**
***************************************************************************************************/

CREATE OR REPLACE VIEW cdv_unprmt_fac AS 
SELECT DISTINCT ics_module
, ICS_UNPRMT_FAC.key_hash
     , CASE ICS_UNPRMT_FAC.action_type
         WHEN 'DELETE'
           THEN (SELECT key_hash
                   FROM ics_flow_icis.ICS_UNPRMT_FAC tbl
                  WHERE tbl.ICS_UNPRMT_FAC_id = ICS_UNPRMT_FAC.ICS_UNPRMT_FAC_id)
           ELSE (SELECT key_hash 
                   FROM ICS_UNPRMT_FAC tbl
                  WHERE tbl.ICS_UNPRMT_FAC_id = ICS_UNPRMT_FAC.ICS_UNPRMT_FAC_id)
       END AS module_ident
     , ICS_UNPRMT_FAC.action_type
     , ICS_UNPRMT_FAC.action_code
  FROM (/*  1 - NEW  */
        SELECT ICS_UNPRMT_FAC.ICS_UNPRMT_FAC_id
             , ICS_UNPRMT_FAC.key_hash
             , 'NEW' AS action_type
             , 1 AS action_code
             , 'ICS_UNPRMT_FAC' as ics_module
          FROM ICS_UNPRMT_FAC
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ics_flow_icis.ICS_UNPRMT_FAC tbl
                            WHERE tbl.key_hash = ICS_UNPRMT_FAC.key_hash)
        UNION
        /*  2 - CHANGE  */
        SELECT local.ICS_UNPRMT_FAC_id
             , local.key_hash
             , 'CHANGE' AS action_type
             , 2 AS action_code
             , 'ICS_UNPRMT_FAC' as ics_module
          FROM ICS_UNPRMT_FAC local
          JOIN ics_flow_icis.ICS_UNPRMT_FAC icis
            ON (    icis.key_hash = local.key_hash
                AND icis.data_hash <> local.data_hash)  
        UNION
        /*  3 - DELETE  */
        SELECT ICS_UNPRMT_FAC.ICS_UNPRMT_FAC_id
             , ICS_UNPRMT_FAC.key_hash
             , 'DELETE' AS action
             , 3 AS action_code
             , 'ICS_UNPRMT_FAC' as ics_module
          FROM ics_flow_icis.ICS_UNPRMT_FAC
         WHERE NOT EXISTS (SELECT 'x'
                             FROM ICS_UNPRMT_FAC tbl
                            WHERE tbl.key_hash = ICS_UNPRMT_FAC.key_hash)) ICS_UNPRMT_FAC;




